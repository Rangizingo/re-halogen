00000000001dd800 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 0000001DD800: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 0000001DD804: F4080300 F8000020
	s_load_b128 s[16:19], s[0:1], 0x38                         // 0000001DD80C: F4080400 F8000038
	s_mov_b32 s20, s3                                          // 0000001DD814: BE940003
	s_ashr_i32 s3, s2, 31                                      // 0000001DD818: 86039F02
	s_load_b32 s21, s[0:1], 0x48                               // 0000001DD81C: F4000540 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000001DD824: BF89FC07
	s_load_b32 s14, s[14:15], null                             // 0000001DD828: F4000387 F8000000
	s_load_b256 s[4:11], s[0:1], null                          // 0000001DD830: F40C0100 F8000000
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000001DD838: 84808202
	s_waitcnt lgkmcnt(0)                                       // 0000001DD83C: BF89FC07
	s_add_i32 s14, s14, s2                                     // 0000001DD840: 810E020E
	s_add_u32 s0, s18, s0                                      // 0000001DD844: 80000012
	s_addc_u32 s1, s19, s1                                     // 0000001DD848: 82010113
	s_add_i32 s3, s14, 1                                       // 0000001DD84C: 8103810E
	s_load_b32 s15, s[0:1], null                               // 0000001DD850: F40003C0 F8000000
	s_ashr_i32 s0, s3, 31                                      // 0000001DD858: 86009F03
	s_mul_hi_i32 s1, s21, s2                                   // 0000001DD85C: 97010215
	s_lshr_b32 s0, s0, 30                                      // 0000001DD860: 85009E00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001DD864: BF870499
	s_add_i32 s3, s3, s0                                       // 0000001DD868: 81030003
	s_and_b32 s18, s3, -4                                      // 0000001DD86C: 8B12C403
	s_ashr_i32 s3, s3, 2                                       // 0000001DD870: 86038203
	s_sub_i32 s0, s14, s18                                     // 0000001DD874: 8180120E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001DD878: BF870009
	s_cmp_gt_i32 s0, -1                                        // 0000001DD87C: BF02C100
	s_mul_i32 s0, s21, s2                                      // 0000001DD880: 96000215
	s_cselect_b32 s19, -1, 0                                   // 0000001DD884: 981380C1
	s_mov_b32 s21, s3                                          // 0000001DD888: BE950003
	s_and_b32 vcc_lo, exec_lo, s19                             // 0000001DD88C: 8B6A137E
	s_cbranch_vccnz 15                                         // 0000001DD890: BFA4000F <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd0>
	s_lshl_b64 s[22:23], s[0:1], 2                             // 0000001DD894: 84968200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001DD898: BF8704D9
	s_add_u32 s21, s16, s22                                    // 0000001DD89C: 80151610
	s_addc_u32 s24, s17, s23                                   // 0000001DD8A0: 82181711
	s_waitcnt lgkmcnt(0)                                       // 0000001DD8A4: BF89FC07
	s_max_i32 s22, s15, 1                                      // 0000001DD8A8: 8A16810F
	s_mov_b32 s23, 0                                           // 0000001DD8AC: BE970080
	s_lshl_b64 s[22:23], s[22:23], 2                           // 0000001DD8B0: 84968216
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001DD8B4: BF870009
	s_add_u32 s21, s21, s22                                    // 0000001DD8B8: 80151615
	s_addc_u32 s23, s24, s23                                   // 0000001DD8BC: 82171718
	s_add_u32 s22, s21, -4                                     // 0000001DD8C0: 8016C415
	s_addc_u32 s23, s23, -1                                    // 0000001DD8C4: 8217C117
	s_load_b32 s21, s[22:23], null                             // 0000001DD8C8: F400054B F8000000
	v_cndmask_b32_e64 v1, 0, 1, s19                            // 0000001DD8D0: D5010001 004D0280
	s_mov_b32 s24, exec_lo                                     // 0000001DD8D8: BE98007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001DD8DC: BF8704B1
	v_readfirstlane_b32 s19, v1                                // 0000001DD8E0: 7E260501
	s_waitcnt lgkmcnt(0)                                       // 0000001DD8E4: BF89FC07
	s_add_i32 s22, s15, s19                                    // 0000001DD8E8: 8116130F
	s_add_i32 s19, s22, 3                                      // 0000001DD8EC: 81138316
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001DD8F0: BF870499
	s_and_b32 s23, s19, -4                                     // 0000001DD8F4: 8B17C413
	.long 0xd4c4007e                                           // 0000001DD8F8: D4C4007E
	v_cndmask_b32_e32 v1, s23, v0, vcc_lo                      // 0000001DD8FC: 02020017
	s_cbranch_execz 47                                         // 0000001DD900: BFA5002F <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1c0>
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v3, 2, v0      // 0000001DD904: CA220100 04020082
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000001DD90C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DD910: BF8700A9
	s_add_u32 s0, s16, s0                                      // 0000001DD914: 80000010
	s_addc_u32 s1, s17, s1                                     // 0000001DD918: 82010111
	.long 0xd7000001                                           // 0000001DD91C: D7000001
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000001DD920: 02020600
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DD924: BF870001
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000001DD928: D5207C02 00010001
	s_mov_b32 s1, 0                                            // 0000001DD930: BE810080
	s_set_inst_prefetch_distance 0x1                           // 0000001DD934: BF840001
	s_branch 20                                                // 0000001DD938: BFA00014 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x18c>
	s_nop 0                                                    // 0000001DD93C: BF800000
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001DD940: 8C7E007E
	v_add_nc_u32_e32 v6, 0x200, v3                             // 0000001DD944: 4A0C06FF 00000200
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001DD94C: 4A0808FF 00000080
	s_waitcnt vmcnt(0)                                         // 0000001DD954: BF8903F7
	ds_store_b32 v3, v5 offset:512                             // 0000001DD958: D8340200 00000503
	.long 0xd7000001                                           // 0000001DD960: D7000001
	v_cndmask_b32_e32 v1, 0x200, v1, vcc_lo                    // 0000001DD964: 020202FF 00000200
	v_mov_b32_e32 v3, v6                                       // 0000001DD96C: 7E060306
	v_cmp_le_i32_e32 vcc_lo, s23, v4                           // 0000001DD970: 7C860817
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001DD974: D5207C02 00020480
	s_or_b32 s1, vcc_lo, s1                                    // 0000001DD97C: 8C01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001DD980: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001DD984: 917E017E
	s_cbranch_execz 13                                         // 0000001DD988: BFA5000D <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1c0>
	s_mov_b32 s0, exec_lo                                      // 0000001DD98C: BE80007E
	.long 0xd4c3007e                                           // 0000001DD990: D4C3007E
	v_cndmask_b32_e32 v1, s15, v4, vcc_lo                      // 0000001DD994: 0202080F
	s_xor_b32 s0, exec_lo, s0                                  // 0000001DD998: 8D00007E
	v_mov_b32_e32 v5, s3                                       // 0000001DD99C: 7E0A0203
	v_cmp_gt_i32_e32 vcc_lo, s22, v4                           // 0000001DD9A0: 7C880816
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001DD9A4: BF870002
	v_cndmask_b32_e32 v5, s21, v5, vcc_lo                      // 0000001DD9A8: 020A0A15
	s_and_not1_saveexec_b32 s0, s0                             // 0000001DD9AC: BE803000
	s_cbranch_execz 65507                                      // 0000001DD9B0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	global_load_b32 v5, v[1:2], off                            // 0000001DD9B4: DC520000 057C0001
	s_branch 65504                                             // 0000001DD9BC: BFA0FFE0 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	s_set_inst_prefetch_distance 0x2                           // 0000001DD9C0: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 0000001DD9C4: 8C7E187E
	v_and_b32_e32 v104, 15, v0                                 // 0000001DD9C8: 36D0008F
	s_mul_i32 s1, s20, 12                                      // 0000001DD9CC: 96018C14
	s_mul_hi_i32 s3, s2, 0x1800                                // 0000001DD9D0: 9703FF02 00001800
	s_mulk_i32 s2, 0x1800                                      // 0000001DD9D8: B8021800
	v_lshrrev_b32_e32 v105, 5, v0                              // 0000001DD9DC: 32D20085
	v_cmp_gt_u32_e32 vcc_lo, 12, v104                          // 0000001DD9E0: 7C98D08C
	s_lshl_b64 s[16:17], s[2:3], 1                             // 0000001DD9E4: 84908102
	v_bfe_u32 v106, v0, 4, 1                                   // 0000001DD9E8: D610006A 02050900
	s_add_u32 s0, s4, s16                                      // 0000001DD9F0: 80001004
	s_addc_u32 s4, s5, s17                                     // 0000001DD9F4: 82041105
	v_dual_cndmask_b32 v1, 0, v104 :: v_dual_mov_b32 v66, 0    // 0000001DD9F8: CA50D080 01420080
	v_lshlrev_b32_e32 v3, 7, v105                              // 0000001DDA00: 3006D287
	v_lshlrev_b32_e32 v107, 6, v105                            // 0000001DDA04: 30D6D286
	v_and_b32_e32 v108, 12, v104                               // 0000001DDA08: 36D8D08C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DDA0C: BF870094
	v_add_lshl_u32 v1, v1, s1, 8                               // 0000001DDA10: D6470001 02200301
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000001DDA18: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DDA1C: BF870091
	.long 0xd73c0001                                           // 0000001DDA20: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000001DDA24: 02020281
	.long 0xd7006a01                                           // 0000001DDA28: D7006A01
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 0000001DDA2C: 02020200
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DDA30: BF870111
	v_add_co_ci_u32_e64 v2, null, s4, v2, vcc_lo               // 0000001DDA34: D5207C02 01AA0404
	.long 0xd7006a01                                           // 0000001DDA3C: D7006A01
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000001DDA40: 02020701
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DDA44: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000001DDA48: D5207C02 01AA0480
	v_lshlrev_b32_e32 v3, 6, v106                              // 0000001DDA50: 3006D486
	s_clause 0x7                                               // 0000001DDA54: BF850007
	global_load_b128 v[36:39], v[1:2], off offset:16           // 0000001DDA58: DC5E0010 247C0001
	global_load_b128 v[32:35], v[1:2], off                     // 0000001DDA60: DC5E0000 207C0001
	global_load_b128 v[44:47], v[1:2], off offset:48           // 0000001DDA68: DC5E0030 2C7C0001
	global_load_b128 v[40:43], v[1:2], off offset:32           // 0000001DDA70: DC5E0020 287C0001
	global_load_b128 v[52:55], v[1:2], off offset:80           // 0000001DDA78: DC5E0050 347C0001
	global_load_b128 v[48:51], v[1:2], off offset:64           // 0000001DDA80: DC5E0040 307C0001
	global_load_b128 v[60:63], v[1:2], off offset:112          // 0000001DDA88: DC5E0070 3C7C0001
	global_load_b128 v[56:59], v[1:2], off offset:96           // 0000001DDA90: DC5E0060 387C0001
	v_and_b32_e32 v1, 32, v0                                   // 0000001DDA98: 360200A0
	v_lshrrev_b32_e32 v2, 6, v0                                // 0000001DDA9C: 32040086
	v_lshlrev_b32_e32 v0, 5, v0                                // 0000001DDAA0: 30000085
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001DDAA4: BF870003
	.long 0xd44a0000                                           // 0000001DDAA8: D44A0000
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000001DDAAC: 02020280
	v_cmp_ne_u32_e32 vcc_lo, 0, v1                             // 0000001DDAB0: 7C9A0280
	v_lshlrev_b32_e32 v1, 9, v105                              // 0000001DDAB4: 3002D289
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001DDAB8: BF890007
	s_barrier                                                  // 0000001DDABC: BFBD0000
	buffer_gl0_inv                                             // 0000001DDAC0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000001DDAC8: BE842000
	s_cbranch_execz 88                                         // 0000001DDACC: BFA50058 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x430>
	ds_load_b32 v4, v108 offset:512                            // 0000001DDAD0: D8D80200 0400006C
	s_ashr_i32 s21, s20, 31                                    // 0000001DDAD8: 86159F14
	v_dual_mov_b32 v75, 0 :: v_dual_and_b32 v6, 0x60, v0       // 0000001DDADC: CA240080 4B0600FF 00000060
	s_lshl_b64 s[16:17], s[20:21], 11                          // 0000001DDAE8: 84908B14
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DDAEC: BF870001
	v_mov_b32_e32 v76, v75                                     // 0000001DDAF0: 7E98034B
	v_mov_b32_e32 v77, v75                                     // 0000001DDAF4: 7E9A034B
	v_mov_b32_e32 v78, v75                                     // 0000001DDAF8: 7E9C034B
	v_mov_b32_e32 v79, v75                                     // 0000001DDAFC: 7E9E034B
	v_mov_b32_e32 v80, v75                                     // 0000001DDB00: 7EA0034B
	v_mov_b32_e32 v81, v75                                     // 0000001DDB04: 7EA2034B
	v_mov_b32_e32 v82, v75                                     // 0000001DDB08: 7EA4034B
	s_waitcnt lgkmcnt(0)                                       // 0000001DDB0C: BF89FC07
	v_ashrrev_i32_e32 v5, 31, v4                               // 0000001DDB10: 340A089F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DDB14: BF870091
	.long 0xd73c0004                                           // 0000001DDB18: D73C0004
	v_cndmask_b32_e32 v1, 12, v4, vcc_lo                       // 0000001DDB1C: 0202088C
	.long 0xd7000004                                           // 0000001DDB20: D7000004
	v_cndmask_b32_e32 v1, s6, v4, vcc_lo                       // 0000001DDB24: 02020806
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DDB28: BF870111
	v_add_co_ci_u32_e64 v5, null, s7, v5, s0                   // 0000001DDB2C: D5207C05 00020A07
	.long 0xd7000004                                           // 0000001DDB34: D7000004
	v_cndmask_b32_e32 v0, v4, v16, vcc_lo                      // 0000001DDB38: 02002104
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DDB3C: BF870111
	v_add_co_ci_u32_e64 v5, null, s17, v5, s0                  // 0000001DDB40: D5207C05 00020A11
	.long 0xd7000004                                           // 0000001DDB48: D7000004
	v_cndmask_b32_e32 v1, v4, v1, vcc_lo                       // 0000001DDB4C: 02020304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DDB50: BF870111
	v_add_co_ci_u32_e64 v5, null, 0, v5, s0                    // 0000001DDB54: D5207C05 00020A80
	.long 0xd700001c                                           // 0000001DDB5C: D700001C
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000001DDB60: 02020D04
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DDB64: BF870001
	v_add_co_ci_u32_e64 v29, null, 0, v5, s0                   // 0000001DDB68: D5207C1D 00020A80
	s_clause 0x7                                               // 0000001DDB70: BF850007
	global_load_b128 v[8:11], v[28:29], off offset:16          // 0000001DDB74: DC5E0010 087C001C
	global_load_b128 v[4:7], v[28:29], off                     // 0000001DDB7C: DC5E0000 047C001C
	global_load_b128 v[16:19], v[28:29], off offset:144        // 0000001DDB84: DC5E0090 107C001C
	global_load_b128 v[12:15], v[28:29], off offset:128        // 0000001DDB8C: DC5E0080 0C7C001C
	global_load_b128 v[24:27], v[28:29], off offset:272        // 0000001DDB94: DC5E0110 187C001C
	global_load_b128 v[20:23], v[28:29], off offset:256        // 0000001DDB9C: DC5E0100 147C001C
	global_load_b128 v[71:74], v[28:29], off offset:400        // 0000001DDBA4: DC5E0190 477C001C
	global_load_b128 v[67:70], v[28:29], off offset:384        // 0000001DDBAC: DC5E0180 437C001C
	s_waitcnt vmcnt(6)                                         // 0000001DDBB4: BF891BF7
	v_wmma_f32_16x16x16_bf16 v[75:82], v[32:39], v[4:11], v[75:82]// 0000001DDBB8: CC41404B 1D2E0920
	v_lshl_or_b32 v4, v2, 10, v3                               // 0000001DDBC0: D6560004 040D1502
	s_waitcnt vmcnt(4)                                         // 0000001DDBC8: BF8913F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DDBCC: BF870112
	v_wmma_f32_16x16x16_bf16 v[75:82], v[40:47], v[12:19], v[75:82]// 0000001DDBD0: CC41404B 1D2E1928
	v_lshl_or_b32 v4, v104, 2, v4                              // 0000001DDBD8: D6560004 04110568
	s_waitcnt vmcnt(2)                                         // 0000001DDBE0: BF890BF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DDBE4: BF870112
	v_wmma_f32_16x16x16_bf16 v[75:82], v[48:55], v[20:27], v[75:82]// 0000001DDBE8: CC41404B 1D2E2930
	v_add_nc_u32_e32 v5, 0x2000, v4                            // 0000001DDBF0: 4A0A08FF 00002000
	v_add_nc_u32_e32 v4, 0x2400, v4                            // 0000001DDBF8: 4A0808FF 00002400
	s_waitcnt vmcnt(0)                                         // 0000001DDC00: BF8903F7
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001DDC04: BF870003
	v_wmma_f32_16x16x16_bf16 v[75:82], v[56:63], v[67:74], v[75:82]// 0000001DDC08: CC41404B 1D2E8738
	ds_store_2addr_b32 v5, v75, v76 offset0:132 offset1:164    // 0000001DDC10: D838A484 004C4B05
	ds_store_2addr_b32 v5, v77, v78 offset0:196 offset1:228    // 0000001DDC18: D838E4C4 004E4D05
	ds_store_2addr_b32 v4, v79, v80 offset0:4 offset1:36       // 0000001DDC20: D8382404 00504F04
	ds_store_2addr_b32 v4, v81, v82 offset0:68 offset1:100     // 0000001DDC28: D8386444 00525104
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001DDC30: 8C7E047E
	s_ashr_i32 s4, s19, 2                                      // 0000001DDC34: 86048213
	s_waitcnt lgkmcnt(0)                                       // 0000001DDC38: BF89FC07
	s_cmp_lt_i32 s4, 1                                         // 0000001DDC3C: BF048104
	s_barrier                                                  // 0000001DDC40: BFBD0000
	s_cbranch_scc1 615                                         // 0000001DDC44: BFA20267 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xde4>
	s_ashr_i32 s21, s20, 31                                    // 0000001DDC48: 86159F14
	v_lshl_or_b32 v2, v2, 10, v3                               // 0000001DDC4C: D6560002 040D1502
	s_lshl_b64 s[16:17], s[20:21], 8                           // 0000001DDC54: 84908814
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000001DDC58: BF870149
	v_dual_mov_b32 v6, s17 :: v_dual_lshlrev_b32 v3, 2, v104   // 0000001DDC5C: CA220011 0602D082
	s_lshl_b64 s[20:21], s[20:21], 11                          // 0000001DDC64: 84948B14
	v_mov_b32_e32 v68, 0                                       // 0000001DDC68: 7E880280
	s_add_u32 s0, s6, s20                                      // 0000001DDC6C: 80001406
	v_or_b32_e32 v4, v3, v2                                    // 0000001DDC70: 38080503
	.long 0xd7000001                                           // 0000001DDC74: D7000001
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 0000001DDC78: 02020200
	v_add_nc_u32_e32 v3, 0x3210, v3                            // 0000001DDC7C: 4A0606FF 00003210
	v_dual_mov_b32 v109, v68 :: v_dual_and_b32 v0, 0x60, v0    // 0000001DDC84: CA240144 6D0000FF 00000060
	v_lshl_or_b32 v7, v105, 2, v106                            // 0000001DDC90: D6560007 05A90569
	s_addc_u32 s5, s7, s21                                     // 0000001DDC98: 82051507
	v_or_b32_e32 v5, s16, v104                                 // 0000001DDC9C: 380AD010
	v_dual_mov_b32 v65, 0 :: v_dual_add_nc_u32 v110, 0x2210, v4// 0000001DDCA0: CA200080 416E08FF 00002210
	v_add_co_ci_u32_e64 v4, null, s5, 0, s0                    // 0000001DDCAC: D5207C04 00010005
	.long 0xd700006f                                           // 0000001DDCB4: D700006F
	v_cndmask_b32_e32 v1, v1, v0, vcc_lo                       // 0000001DDCB8: 02020101
	v_dual_mov_b32 v124, 0xf149f2ca :: v_dual_add_nc_u32 v113, v3, v2// 0000001DDCBC: CA2000FF 7C700503 F149F2CA
	v_dual_mov_b32 v125, 0xf149f2ca :: v_dual_lshlrev_b32 v0, 1, v104// 0000001DDCC8: CA2200FF 7D00D081 F149F2CA
	v_lshl_or_b32 v114, v106, 5, 0x3a10                        // 0000001DDCD4: D6560072 03FD0B6A 00003A10
	v_or_b32_e32 v1, 2, v7                                     // 0000001DDCE0: 38020E82
	v_mul_u32_u24_e32 v2, 30, v104                             // 0000001DDCE4: 1604D09E
	v_add_co_ci_u32_e64 v112, null, 0, v4, s0                  // 0000001DDCE8: D5207C70 00020880
	.long 0xd7000078                                           // 0000001DDCF0: D7000078
	v_cndmask_b32_e32 v1, v5, v107, vcc_lo                     // 0000001DDCF4: 0202D705
	s_lshl2_add_u32 s5, s15, s14                               // 0000001DDCF8: 87850E0F
	v_lshl_add_u32 v115, v7, 6, v3                             // 0000001DDCFC: D6460073 040D0D07
	v_lshl_or_b32 v116, v7, 5, v0                              // 0000001DDD04: D6560074 04010B07
	v_lshl_add_u32 v117, v105, 3, v114                         // 0000001DDD0C: D6460075 05C90769
	v_lshl_add_u32 v118, v1, 6, v3                             // 0000001DDD14: D6460076 040D0D01
	v_lshl_or_b32 v119, v1, 5, v0                              // 0000001DDD1C: D6560077 04010B01
	v_add_co_ci_u32_e64 v121, null, 0, v6, s0                  // 0000001DDD24: D5207C79 00020C80
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v123, v68          // 0000001DDD2C: CA100080 407A0144
	v_add_nc_u32_e32 v122, v0, v2                              // 0000001DDD34: 4AF40500
	v_mov_b32_e32 v24, v68                                     // 0000001DDD38: 7E300344
	v_mov_b32_e32 v25, v68                                     // 0000001DDD3C: 7E320344
	v_mov_b32_e32 v26, v68                                     // 0000001DDD40: 7E340344
	v_mov_b32_e32 v27, v68                                     // 0000001DDD44: 7E360344
	v_mov_b32_e32 v28, v68                                     // 0000001DDD48: 7E380344
	v_mov_b32_e32 v29, v68                                     // 0000001DDD4C: 7E3A0344
	v_mov_b32_e32 v30, v68                                     // 0000001DDD50: 7E3C0344
	v_mov_b32_e32 v31, v68                                     // 0000001DDD54: 7E3E0344
	v_mov_b32_e32 v16, v68                                     // 0000001DDD58: 7E200344
	v_mov_b32_e32 v17, v68                                     // 0000001DDD5C: 7E220344
	v_mov_b32_e32 v18, v68                                     // 0000001DDD60: 7E240344
	v_mov_b32_e32 v19, v68                                     // 0000001DDD64: 7E260344
	v_mov_b32_e32 v20, v68                                     // 0000001DDD68: 7E280344
	v_mov_b32_e32 v21, v68                                     // 0000001DDD6C: 7E2A0344
	v_mov_b32_e32 v22, v68                                     // 0000001DDD70: 7E2C0344
	v_mov_b32_e32 v23, v68                                     // 0000001DDD74: 7E2E0344
	v_mov_b32_e32 v8, v68                                      // 0000001DDD78: 7E100344
	v_mov_b32_e32 v9, v68                                      // 0000001DDD7C: 7E120344
	v_mov_b32_e32 v10, v68                                     // 0000001DDD80: 7E140344
	v_mov_b32_e32 v11, v68                                     // 0000001DDD84: 7E160344
	v_mov_b32_e32 v12, v68                                     // 0000001DDD88: 7E180344
	v_mov_b32_e32 v13, v68                                     // 0000001DDD8C: 7E1A0344
	v_mov_b32_e32 v14, v68                                     // 0000001DDD90: 7E1C0344
	v_mov_b32_e32 v15, v68                                     // 0000001DDD94: 7E1E0344
	v_mov_b32_e32 v0, v68                                      // 0000001DDD98: 7E000344
	v_mov_b32_e32 v1, v68                                      // 0000001DDD9C: 7E020344
	v_mov_b32_e32 v2, v68                                      // 0000001DDDA0: 7E040344
	v_mov_b32_e32 v3, v68                                      // 0000001DDDA4: 7E060344
	v_mov_b32_e32 v4, v68                                      // 0000001DDDA8: 7E080344
	v_mov_b32_e32 v5, v68                                      // 0000001DDDAC: 7E0A0344
	v_mov_b32_e32 v6, v68                                      // 0000001DDDB0: 7E0C0344
	v_mov_b32_e32 v7, v68                                      // 0000001DDDB4: 7E0E0344
	s_sub_i32 s0, s5, s18                                      // 0000001DDDB8: 81801205
	s_mov_b32 s7, 0                                            // 0000001DDDBC: BE870080
	s_add_i32 s5, s0, 1                                        // 0000001DDDC0: 81058100
	s_mov_b32 s6, 0                                            // 0000001DDDC4: BE860080
	s_branch 272                                               // 0000001DDDC8: BFA00110 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xa0c>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001DDDCC: 8C7E0F7E
	v_mov_b32_e32 v65, v127                                    // 0000001DDDD0: 7E82037F
	s_or_b32 exec_lo, exec_lo, s14                             // 0000001DDDD4: 8C7E0E7E
	s_waitcnt lgkmcnt(0)                                       // 0000001DDDD8: BF89FC07
	s_barrier                                                  // 0000001DDDDC: BFBD0000
	ds_load_2addr_stride64_b32 v[66:67], v115 offset1:4        // 0000001DDDE0: D8E00400 42000073
	ds_load_2addr_stride64_b32 v[69:70], v118 offset1:4        // 0000001DDDE8: D8E00400 45000076
	.long 0xd4440000                                           // 0000001DDDF0: D4440000
	v_cndmask_b32_e32 v1, s5, v104, vcc_lo                     // 0000001DDDF4: 0202D005
	s_add_i32 s7, s7, 16                                       // 0000001DDDF8: 81079007
	s_add_i32 s5, s5, -16                                      // 0000001DDDFC: 8105D005
	s_waitcnt lgkmcnt(0)                                       // 0000001DDE00: BF89FC07
	v_dual_add_f32 v66, v66, v67 :: v_dual_add_f32 v69, v69, v70// 0000001DDE04: C9088742 42448D45
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DDE0C: BF870091
	v_dual_mul_f32 v66, 0x3d800000, v66 :: v_dual_mul_f32 v67, 0x3d800000, v69// 0000001DDE10: C8C684FF 42428AFF 3D800000
	v_cndmask_b32_e64 v66, 0xf149f2ca, v66, s0                 // 0000001DDE1C: D5010042 000284FF F149F2CA
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DDE28: BF870112
	v_cndmask_b32_e64 v67, 0xf149f2ca, v67, s0                 // 0000001DDE2C: D5010043 000286FF F149F2CA
	v_mov_b32_dpp v70, v66 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DDE38: 7E8C02FA FF096142
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DDE40: BF870092
	v_mov_b32_dpp v69, v67 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DDE44: 7E8A02FA FF096143
	v_dual_max_f32 v70, v70, v70 :: v_dual_max_f32 v69, v69, v69// 0000001DDE4C: CA948D46 46448B45
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DDE54: BF870091
	v_dual_max_f32 v70, v66, v70 :: v_dual_max_f32 v69, v67, v69// 0000001DDE58: CA948D42 46448B43
	v_mov_b32_dpp v126, v70 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DDE60: 7EFC02FA FF096246
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DDE68: BF870092
	v_mov_b32_dpp v71, v69 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DDE6C: 7E8E02FA FF096245
	v_dual_max_f32 v126, v126, v126 :: v_dual_max_f32 v71, v71, v71// 0000001DDE74: CA94FD7E 7E468F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DDE7C: BF870091
	v_dual_max_f32 v70, v70, v126 :: v_dual_max_f32 v69, v69, v71// 0000001DDE80: CA94FD46 46448F45
	v_mov_b32_dpp v126, v70 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DDE88: 7EFC02FA FF096446
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DDE90: BF870092
	v_mov_b32_dpp v71, v69 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DDE94: 7E8E02FA FF096445
	v_dual_max_f32 v126, v126, v126 :: v_dual_max_f32 v71, v71, v71// 0000001DDE9C: CA94FD7E 7E468F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DDEA4: BF870091
	v_dual_max_f32 v70, v70, v126 :: v_dual_max_f32 v69, v69, v71// 0000001DDEA8: CA94FD46 46448F45
	v_mov_b32_dpp v126, v70 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DDEB0: 7EFC02FA FF096846
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DDEB8: BF870112
	v_mov_b32_dpp v71, v69 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DDEBC: 7E8E02FA FF096845
	v_max3_f32 v126, v124, v70, v126                           // 0000001DDEC4: D61C007E 05FA8D7C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DDECC: BF870122
	v_max3_f32 v71, v125, v69, v71                             // 0000001DDED0: D61C0047 051E8B7D
	.long 0x7f8c3880                                           // 0000001DDED8: 7F8C3880
	v_dual_sub_f32 v124, v124, v126 :: v_dual_sub_f32 v67, v67, v71// 0000001DDEDC: C94AFD7C 7C428F43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DDEE4: BF870091
	v_dual_sub_f32 v69, v66, v126 :: v_dual_mul_f32 v132, 0x3fb8aa3b, v124// 0000001DDEE8: C946FD42 4584F8FF 3FB8AA3B
	v_dual_mul_f32 v66, 0x3fb8aa3b, v67 :: v_dual_mul_f32 v127, 0x3fb8aa3b, v69// 0000001DDEF4: C8C686FF 427E8AFF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001DDF00: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v67, vcc_lo              // 0000001DDF04: 020286FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DDF0C: BF870193
	v_fma_f32 v134, 0x3fb8aa3b, v124, -v132                    // 0000001DDF10: D6130086 8612F8FF 3FB8AA3B
	v_fma_f32 v128, 0x3fb8aa3b, v67, -v66                      // 0000001DDF1C: D6130080 850A86FF 3FB8AA3B
	v_rndne_f32_e32 v129, v66                                  // 0000001DDF28: 7F024742
	v_fma_f32 v130, 0x3fb8aa3b, v69, -v127                     // 0000001DDF2C: D6130082 85FE8AFF 3FB8AA3B
	v_rndne_f32_e32 v131, v127                                 // 0000001DDF38: 7F06477F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DDF3C: BF870113
	v_dual_sub_f32 v125, v125, v71 :: v_dual_sub_f32 v66, v66, v129// 0000001DDF40: C94A8F7D 7D430342
	v_dual_fmac_f32 v130, 0x32a5705f, v69 :: v_dual_sub_f32 v127, v127, v131// 0000001DDF48: C80A8AFF 827F077F 32A5705F
	v_fmac_f32_e32 v128, 0x32a5705f, v67                       // 0000001DDF54: 570086FF 32A5705F
	v_cvt_i32_f32_e32 v129, v129                               // 0000001DDF5C: 7F021181
	v_cvt_i32_f32_e32 v131, v131                               // 0000001DDF60: 7F061183
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DDF64: BF870214
	v_add_f32_e32 v127, v127, v130                             // 0000001DDF68: 06FF057F
	v_dual_mul_f32 v133, 0x3fb8aa3b, v125 :: v_dual_add_f32 v66, v66, v128// 0000001DDF6C: C8C8FAFF 85430142 3FB8AA3B
	v_rndne_f32_e32 v128, v132                                 // 0000001DDF78: 7F004784
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DDF7C: BF870113
	v_exp_f32_e32 v127, v127                                   // 0000001DDF80: 7EFE4B7F
	v_fma_f32 v130, 0x3fb8aa3b, v125, -v133                    // 0000001DDF84: D6130082 8616FAFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DDF90: BF8700A3
	v_exp_f32_e32 v66, v66                                     // 0000001DDF94: 7E844B42
	v_rndne_f32_e32 v135, v133                                 // 0000001DDF98: 7F0E4785
	v_dual_fmac_f32 v134, 0x32a5705f, v124 :: v_dual_sub_f32 v133, v133, v135// 0000001DDF9C: C80AF8FF 86850F85 32A5705F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001DDFA8: BF870296
	.long 0xd71c007f                                           // 0000001DDFAC: D71C007F
	v_cndmask_b32_e32 v1, v127, v131, vcc_lo                   // 0000001DDFB0: 0203077F
	.long 0xd71c0042                                           // 0000001DDFB4: D71C0042
	v_cndmask_b32_e32 v1, v66, v129, vcc_lo                    // 0000001DDFB8: 02030342
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DDFBC: BF8700A1
	v_cndmask_b32_e64 v66, 0, v66, s0                          // 0000001DDFC0: D5010042 00028480
	.long 0xd41b0000                                           // 0000001DDFC8: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v69, vcc_lo              // 0000001DDFCC: 02028AFF C2CE8ED0
	v_cndmask_b32_e64 v127, 0, v127, s0                        // 0000001DDFD4: D501007F 0002FE80
	.long 0xd41e0000                                           // 0000001DDFDC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v67, vcc_lo              // 0000001DDFE0: 020286FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001DDFE8: BF8701B1
	v_cndmask_b32_e64 v66, 0x7f800000, v66, s0                 // 0000001DDFEC: D5010042 000284FF 7F800000
	.long 0xd41e0000                                           // 0000001DDFF8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v69, vcc_lo              // 0000001DDFFC: 02028AFF 42B17218
	v_cvt_i32_f32_e32 v69, v135                                // 0000001DE004: 7E8A1187
	.long 0x7e8c39c2                                           // 0000001DE008: 7E8C39C2
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001DE00C: BF870233
	v_cndmask_b32_e64 v67, 0x7f800000, v127, s0                // 0000001DE010: D5010043 0002FEFF 7F800000
	.long 0x7ffe39c6                                           // 0000001DE01C: 7FFE39C6
	.long 0xd41b0000                                           // 0000001DE020: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v124, vcc_lo             // 0000001DE024: 0202F8FF C2CE8ED0
	v_and_b32_e32 v70, 1, v70                                  // 0000001DE02C: 368C8C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DE030: BF870094
	.long 0x7efe39c3                                           // 0000001DE034: 7EFE39C3
	v_dual_fmac_f32 v130, 0x32a5705f, v125 :: v_dual_and_b32 v127, 1, v127// 0000001DE038: C824FAFF 827EFE81 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001DE044: BF8701A1
	v_dual_sub_f32 v132, v132, v128 :: v_dual_add_f32 v129, v133, v130// 0000001DE048: C9490184 84810585
	v_cvt_i32_f32_e32 v128, v128                               // 0000001DE050: 7F001180
	v_add3_u32 v127, v67, v127, 0x7fff                         // 0000001DE054: D655007F 03FEFF43 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DE060: BF870213
	v_add_f32_e32 v132, v132, v134                             // 0000001DE064: 07090D84
	v_exp_f32_e32 v129, v129                                   // 0000001DE068: 7F024B81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001DE06C: BF870311
	v_exp_f32_e32 v130, v132                                   // 0000001DE070: 7F044B84
	.long 0xd71c0045                                           // 0000001DE074: D71C0045
	v_cndmask_b32_e32 v1, v129, v69, vcc_lo                    // 0000001DE078: 02028B81
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DE07C: BF870095
	.long 0xd71c0080                                           // 0000001DE080: D71C0080
	v_cndmask_b32_e32 v1, v130, v128, vcc_lo                   // 0000001DE084: 02030182
	v_cndmask_b32_e64 v128, 0, v128, s0                        // 0000001DE088: D5010080 00030080
	.long 0xd41b0000                                           // 0000001DE090: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v125, vcc_lo             // 0000001DE094: 0202FAFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001DE09C: BF870131
	v_cndmask_b32_e64 v129, 0, v69, s0                         // 0000001DE0A0: D5010081 00028A80
	.long 0xd41e0000                                           // 0000001DE0A8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v124, vcc_lo             // 0000001DE0AC: 0202F8FF 42B17218
	v_add3_u32 v124, v66, v70, 0x7fff                          // 0000001DE0B4: D655007C 03FE8D42 00007FFF
	v_cndmask_b32_e64 v69, 0x7f800000, v128, s0                // 0000001DE0C0: D5010045 000300FF 7F800000
	.long 0xd41e0000                                           // 0000001DE0CC: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v125, vcc_lo             // 0000001DE0D0: 0202FAFF 42B17218
	v_mov_b32_e32 v125, v71                                    // 0000001DE0D8: 7EFA0347
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DE0DC: BF870193
	v_fma_f32 v109, v109, v69, v67                             // 0000001DE0E0: D613006D 050E8B6D
	v_cndmask_b32_e64 v70, 0x7f800000, v129, s0                // 0000001DE0E8: D5010046 000302FF 7F800000
	ds_store_b16_d16_hi v116, v127                             // 0000001DE0F4: DA840000 00007F74
	ds_store_b16_d16_hi v119, v124                             // 0000001DE0FC: DA840000 00007C77
	ds_store_b64 v117, v[69:70]                                // 0000001DE104: D9340000 00004575
	.long 0xd44a0000                                           // 0000001DE10C: D44A0000
	v_cndmask_b32_e32 v1, s4, v65, vcc_lo                      // 0000001DE110: 02028204
	v_fmac_f32_e32 v66, v123, v70                              // 0000001DE114: 56848D7B
	s_or_b32 s6, s0, s6                                        // 0000001DE118: 8C060600
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DE11C: BF870001
	v_mov_b32_e32 v123, v66                                    // 0000001DE120: 7EF60342
	s_waitcnt lgkmcnt(0)                                       // 0000001DE124: BF89FC07
	s_barrier                                                  // 0000001DE128: BFBD0000
	ds_load_b128 v[134:137], v114                              // 0000001DE12C: DBFC0000 86000072
	ds_load_b128 v[138:141], v114 offset:16                    // 0000001DE134: DBFC0010 8A000072
	v_mov_b32_e32 v124, v126                                   // 0000001DE13C: 7EF8037E
	ds_load_b128 v[126:129], v122                              // 0000001DE140: DBFC0000 7E00007A
	ds_load_b128 v[130:133], v122 offset:16                    // 0000001DE148: DBFC0010 8200007A
	s_waitcnt lgkmcnt(2)                                       // 0000001DE150: BF89FC27
	v_dual_mul_f32 v24, v134, v24 :: v_dual_mul_f32 v29, v139, v29// 0000001DE154: C8C63186 181C3B8B
	v_dual_mul_f32 v25, v135, v25 :: v_dual_mul_f32 v26, v136, v26// 0000001DE15C: C8C63387 191A3588
	v_mul_f32_e32 v31, v141, v31                               // 0000001DE164: 103E3F8D
	v_dual_mul_f32 v27, v137, v27 :: v_dual_mul_f32 v28, v138, v28// 0000001DE168: C8C63789 1B1C398A
	v_dual_mul_f32 v17, v135, v17 :: v_dual_mul_f32 v30, v140, v30// 0000001DE170: C8C62387 111E3D8C
	v_dual_mul_f32 v19, v137, v19 :: v_dual_mul_f32 v16, v134, v16// 0000001DE178: C8C62789 13102186
	v_dual_mul_f32 v21, v139, v21 :: v_dual_mul_f32 v18, v136, v18// 0000001DE180: C8C62B8B 15122588
	v_dual_mul_f32 v23, v141, v23 :: v_dual_mul_f32 v20, v138, v20// 0000001DE188: C8C62F8D 1714298A
	v_dual_mul_f32 v9, v135, v9 :: v_dual_mul_f32 v22, v140, v22// 0000001DE190: C8C61387 09162D8C
	v_dual_mul_f32 v11, v137, v11 :: v_dual_mul_f32 v8, v134, v8// 0000001DE198: C8C61789 0B081186
	v_dual_mul_f32 v13, v139, v13 :: v_dual_mul_f32 v10, v136, v10// 0000001DE1A0: C8C61B8B 0D0A1588
	v_dual_mul_f32 v15, v141, v15 :: v_dual_mul_f32 v12, v138, v12// 0000001DE1A8: C8C61F8D 0F0C198A
	v_dual_mul_f32 v1, v135, v1 :: v_dual_mul_f32 v14, v140, v14// 0000001DE1B0: C8C60387 010E1D8C
	v_dual_mul_f32 v3, v137, v3 :: v_dual_mul_f32 v0, v134, v0 // 0000001DE1B8: C8C60789 03000186
	v_dual_mul_f32 v5, v139, v5 :: v_dual_mul_f32 v2, v136, v2 // 0000001DE1C0: C8C60B8B 05020588
	v_dual_mul_f32 v7, v141, v7 :: v_dual_mul_f32 v4, v138, v4 // 0000001DE1C8: C8C60F8D 0704098A
	v_mul_f32_e32 v6, v140, v6                                 // 0000001DE1D0: 100C0D8C
	s_waitcnt vmcnt(3) lgkmcnt(0)                              // 0000001DE1D4: BF890C07
	v_wmma_f32_16x16x16_bf16 v[24:31], v[126:133], v[72:79], v[24:31]// 0000001DE1D8: CC414018 1C62917E
	s_waitcnt vmcnt(2)                                         // 0000001DE1E0: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[16:23], v[126:133], v[80:87], v[16:23]// 0000001DE1E4: CC414010 1C42A17E
	s_waitcnt vmcnt(1)                                         // 0000001DE1EC: BF8907F7
	v_wmma_f32_16x16x16_bf16 v[8:15], v[126:133], v[88:95], v[8:15]// 0000001DE1F0: CC414008 1C22B17E
	s_waitcnt vmcnt(0)                                         // 0000001DE1F8: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[0:7], v[126:133], v[96:103], v[0:7]// 0000001DE1FC: CC414000 1C02C17E
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000001DE204: 917E067E
	s_cbranch_execz 244                                        // 0000001DE208: BFA500F4 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xddc>
	v_mov_b32_e32 v66, s7                                      // 0000001DE20C: 7E840207
	v_and_b32_e32 v126, 1, v65                                 // 0000001DE210: 36FC8281
	v_add_nc_u32_e32 v127, 1, v65                              // 0000001DE214: 4AFE8281
	ds_load_b128 v[69:72], v66 offset:512                      // 0000001DE218: DBFC0200 45000042
	s_waitcnt lgkmcnt(0)                                       // 0000001DE220: BF89FC07
	v_ashrrev_i32_e32 v67, 31, v69                             // 0000001DE224: 34868A9F
	v_mov_b32_e32 v66, v69                                     // 0000001DE228: 7E840345
	v_ashrrev_i32_e32 v75, 31, v70                             // 0000001DE22C: 34968C9F
	v_mov_b32_e32 v74, v70                                     // 0000001DE230: 7E940346
	v_ashrrev_i32_e32 v70, 31, v71                             // 0000001DE234: 348C8E9F
	v_mov_b32_e32 v69, v71                                     // 0000001DE238: 7E8A0347
	.long 0xd73c0042                                           // 0000001DE23C: D73C0042
	v_cndmask_b32_e32 v1, 9, v66, vcc_lo                       // 0000001DE240: 02028489
	v_ashrrev_i32_e32 v73, 31, v72                             // 0000001DE244: 3492909F
	.long 0xd73c004a                                           // 0000001DE248: D73C004A
	v_cndmask_b32_e32 v1, 9, v74, vcc_lo                       // 0000001DE24C: 02029489
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DE250: BF870194
	.long 0xd73c0045                                           // 0000001DE254: D73C0045
	v_cndmask_b32_e32 v1, 9, v69, vcc_lo                       // 0000001DE258: 02028A89
	.long 0xd73c0047                                           // 0000001DE25C: D73C0047
	v_cndmask_b32_e32 v1, 9, v72, vcc_lo                       // 0000001DE260: 02029089
	.long 0xd7000042                                           // 0000001DE264: D7000042
	v_cndmask_b32_e32 v1, v66, v120, vcc_lo                    // 0000001DE268: 0202F142
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DE26C: BF8700A1
	v_add_co_ci_u32_e64 v67, null, v67, v121, s0               // 0000001DE270: D5207C43 0002F343
	.long 0xd7000049                                           // 0000001DE278: D7000049
	v_cndmask_b32_e32 v1, v74, v120, vcc_lo                    // 0000001DE27C: 0202F14A
	v_add_co_ci_u32_e64 v74, null, v75, v121, s0               // 0000001DE280: D5207C4A 0002F34B
	.long 0xd7000045                                           // 0000001DE288: D7000045
	v_cndmask_b32_e32 v1, v69, v120, vcc_lo                    // 0000001DE28C: 0202F145
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DE290: BF870001
	v_add_co_ci_u32_e64 v70, null, v70, v121, s0               // 0000001DE294: D5207C46 0002F346
	.long 0xd7000047                                           // 0000001DE29C: D7000047
	v_cndmask_b32_e32 v1, v71, v120, vcc_lo                    // 0000001DE2A0: 0202F147
	.long 0xd73c0042                                           // 0000001DE2A4: D73C0042
	v_cndmask_b32_e32 v1, 3, v66, vcc_lo                       // 0000001DE2A8: 02028483
	v_add_co_ci_u32_e64 v72, null, v72, v121, s0               // 0000001DE2AC: D5207C48 0002F348
	.long 0xd73c0049                                           // 0000001DE2B4: D73C0049
	v_cndmask_b32_e32 v1, 3, v73, vcc_lo                       // 0000001DE2B8: 02029283
	.long 0xd73c0045                                           // 0000001DE2BC: D73C0045
	v_cndmask_b32_e32 v1, 3, v69, vcc_lo                       // 0000001DE2C0: 02028A83
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DE2C4: BF8700A3
	.long 0xd73c0047                                           // 0000001DE2C8: D73C0047
	v_cndmask_b32_e32 v1, 3, v71, vcc_lo                       // 0000001DE2CC: 02028E83
	.long 0xd7000042                                           // 0000001DE2D0: D7000042
	v_cndmask_b32_e32 v1, s8, v66, vcc_lo                      // 0000001DE2D4: 02028408
	v_add_co_ci_u32_e64 v67, null, s9, v67, s0                 // 0000001DE2D8: D5207C43 00028609
	.long 0xd700004c                                           // 0000001DE2E0: D700004C
	v_cndmask_b32_e32 v1, s8, v73, vcc_lo                      // 0000001DE2E4: 02029208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DE2E8: BF8700A1
	v_add_co_ci_u32_e64 v77, null, s9, v74, s0                 // 0000001DE2EC: D5207C4D 00029409
	.long 0xd7000045                                           // 0000001DE2F4: D7000045
	v_cndmask_b32_e32 v1, s8, v69, vcc_lo                      // 0000001DE2F8: 02028A08
	v_add_co_ci_u32_e64 v70, null, s9, v70, s0                 // 0000001DE2FC: D5207C46 00028C09
	.long 0xd7000066                                           // 0000001DE304: D7000066
	v_cndmask_b32_e32 v1, s8, v71, vcc_lo                      // 0000001DE308: 02028E08
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DE30C: BF870001
	v_add_co_ci_u32_e64 v103, null, s9, v72, s0                // 0000001DE310: D5207C67 00029009
	s_clause 0xf                                               // 0000001DE318: BF85000F
	global_load_b64 v[72:73], v[66:67], off                    // 0000001DE31C: DC560000 487C0042
	global_load_b64 v[80:81], v[66:67], off offset:128         // 0000001DE324: DC560080 507C0042
	global_load_b64 v[88:89], v[66:67], off offset:256         // 0000001DE32C: DC560100 587C0042
	global_load_b64 v[96:97], v[66:67], off offset:384         // 0000001DE334: DC560180 607C0042
	global_load_b64 v[74:75], v[76:77], off                    // 0000001DE33C: DC560000 4A7C004C
	global_load_b64 v[82:83], v[76:77], off offset:128         // 0000001DE344: DC560080 527C004C
	global_load_b64 v[90:91], v[76:77], off offset:256         // 0000001DE34C: DC560100 5A7C004C
	global_load_b64 v[98:99], v[76:77], off offset:384         // 0000001DE354: DC560180 627C004C
	global_load_b64 v[76:77], v[69:70], off                    // 0000001DE35C: DC560000 4C7C0045
	global_load_b64 v[84:85], v[69:70], off offset:128         // 0000001DE364: DC560080 547C0045
	global_load_b64 v[92:93], v[69:70], off offset:256         // 0000001DE36C: DC560100 5C7C0045
	global_load_b64 v[100:101], v[69:70], off offset:384       // 0000001DE374: DC560180 647C0045
	global_load_b64 v[78:79], v[102:103], off                  // 0000001DE37C: DC560000 4E7C0066
	global_load_b64 v[86:87], v[102:103], off offset:128       // 0000001DE384: DC560080 567C0066
	global_load_b64 v[94:95], v[102:103], off offset:256       // 0000001DE38C: DC560100 5E7C0066
	global_load_b64 v[102:103], v[102:103], off offset:384     // 0000001DE394: DC560180 667C0066
	s_and_saveexec_b32 s0, vcc_lo                              // 0000001DE39C: BE80206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001DE3A0: BF870009
	s_xor_b32 s14, exec_lo, s0                                 // 0000001DE3A4: 8D0E007E
	s_cbranch_execz 63                                         // 0000001DE3A8: BFA5003F <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xca8>
	v_add_nc_u32_e32 v66, s7, v108                             // 0000001DE3AC: 4A84D807
	v_add_nc_u32_e32 v65, 1, v65                               // 0000001DE3B0: 4A828281
	ds_load_b32 v66, v66 offset:512                            // 0000001DE3B4: D8D80200 42000042
	s_waitcnt lgkmcnt(0)                                       // 0000001DE3BC: BF89FC07
	v_ashrrev_i32_e32 v67, 31, v66                             // 0000001DE3C0: 3486849F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DE3C4: BF870091
	.long 0xd73c0042                                           // 0000001DE3C8: D73C0042
	v_cndmask_b32_e32 v1, 12, v66, vcc_lo                      // 0000001DE3CC: 0202848C
	.long 0xd7000042                                           // 0000001DE3D0: D7000042
	v_cndmask_b32_e32 v1, v111, v66, vcc_lo                    // 0000001DE3D4: 0202856F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DE3D8: BF870001
	v_add_co_ci_u32_e64 v67, null, v112, v67, s0               // 0000001DE3DC: D5207C43 00028770
	s_clause 0x7                                               // 0000001DE3E4: BF850007
	global_load_b128 v[131:134], v[66:67], off offset:16       // 0000001DE3E8: DC5E0010 837C0042
	global_load_b128 v[127:130], v[66:67], off                 // 0000001DE3F0: DC5E0000 7F7C0042
	global_load_b128 v[139:142], v[66:67], off offset:144      // 0000001DE3F8: DC5E0090 8B7C0042
	global_load_b128 v[135:138], v[66:67], off offset:128      // 0000001DE400: DC5E0080 877C0042
	global_load_b128 v[147:150], v[66:67], off offset:272      // 0000001DE408: DC5E0110 937C0042
	global_load_b128 v[143:146], v[66:67], off offset:256      // 0000001DE410: DC5E0100 8F7C0042
	global_load_b128 v[155:158], v[66:67], off offset:400      // 0000001DE418: DC5E0190 9B7C0042
	global_load_b128 v[151:154], v[66:67], off offset:384      // 0000001DE420: DC5E0180 977C0042
	v_lshl_add_u32 v66, v126, 11, v110                         // 0000001DE428: D6460042 05B9177E
	ds_load_2addr_b32 v[159:160], v66 offset1:32               // 0000001DE430: D8DC2000 9F000042
	ds_load_2addr_b32 v[161:162], v66 offset0:64 offset1:96    // 0000001DE438: D8DC6040 A1000042
	ds_load_2addr_b32 v[163:164], v66 offset0:128 offset1:160  // 0000001DE440: D8DCA080 A3000042
	ds_load_2addr_b32 v[165:166], v66 offset0:192 offset1:224  // 0000001DE448: D8DCE0C0 A5000042
	s_waitcnt vmcnt(6) lgkmcnt(0)                              // 0000001DE450: BF891807
	v_wmma_f32_16x16x16_bf16 v[159:166], v[32:39], v[127:134], v[159:166]// 0000001DE454: CC41409F 1E7EFF20
	s_waitcnt vmcnt(4)                                         // 0000001DE45C: BF8913F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DE460: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[159:166], v[40:47], v[135:142], v[159:166]// 0000001DE464: CC41409F 1E7F0F28
	s_waitcnt vmcnt(2)                                         // 0000001DE46C: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[159:166], v[48:55], v[143:150], v[159:166]// 0000001DE470: CC41409F 1E7F1F30
	s_waitcnt vmcnt(0)                                         // 0000001DE478: BF8903F7
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DE47C: BF870001
	v_wmma_f32_16x16x16_bf16 v[159:166], v[56:63], v[151:158], v[159:166]// 0000001DE480: CC41409F 1E7F2F38
	ds_store_2addr_b32 v113, v159, v160 offset1:32             // 0000001DE488: D8382000 00A09F71
	ds_store_2addr_b32 v113, v161, v162 offset0:64 offset1:96  // 0000001DE490: D8386040 00A2A171
	ds_store_2addr_b32 v113, v163, v164 offset0:128 offset1:160// 0000001DE498: D838A080 00A4A371
	ds_store_2addr_b32 v113, v165, v166 offset0:192 offset1:224// 0000001DE4A0: D838E0C0 00A6A571
	s_and_not1_saveexec_b32 s14, s14                           // 0000001DE4A8: BE8E300E
	s_cbranch_execz 65097                                      // 0000001DE4AC: BFA5FE49 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x5d4>
	s_mov_b32 s15, exec_lo                                     // 0000001DE4B0: BE8F007E
	.long 0xd4c4007e                                           // 0000001DE4B4: D4C4007E
	v_cndmask_b32_e32 v1, s4, v127, vcc_lo                     // 0000001DE4B8: 0202FE04
	s_cbranch_execz 65091                                      // 0000001DE4BC: BFA5FE43 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x5cc>
	v_add_nc_u32_e32 v65, s7, v108                             // 0000001DE4C0: 4A82D807
	v_mov_b32_e32 v71, v68                                     // 0000001DE4C4: 7E8E0344
	v_mov_b32_e32 v67, v64                                     // 0000001DE4C8: 7E860340
	v_mov_b32_e32 v69, v68                                     // 0000001DE4CC: 7E8A0344
	v_mov_b32_e32 v70, v68                                     // 0000001DE4D0: 7E8C0344
	ds_load_b32 v65, v65 offset:528                            // 0000001DE4D4: D8D80210 41000041
	s_waitcnt lgkmcnt(0)                                       // 0000001DE4DC: BF89FC07
	v_ashrrev_i32_e32 v66, 31, v65                             // 0000001DE4E0: 3484829F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DE4E4: BF870091
	.long 0xd73c0041                                           // 0000001DE4E8: D73C0041
	v_cndmask_b32_e32 v1, 12, v65, vcc_lo                      // 0000001DE4EC: 0202828C
	.long 0xd7000041                                           // 0000001DE4F0: D7000041
	v_cndmask_b32_e32 v1, v111, v65, vcc_lo                    // 0000001DE4F4: 0202836F
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DE4F8: BF870001
	v_add_co_ci_u32_e64 v66, null, v112, v66, s0               // 0000001DE4FC: D5207C42 00028570
	s_clause 0x7                                               // 0000001DE504: BF850007
	global_load_b128 v[132:135], v[65:66], off offset:16       // 0000001DE508: DC5E0010 847C0041
	global_load_b128 v[128:131], v[65:66], off                 // 0000001DE510: DC5E0000 807C0041
	global_load_b128 v[140:143], v[65:66], off offset:144      // 0000001DE518: DC5E0090 8C7C0041
	global_load_b128 v[136:139], v[65:66], off offset:128      // 0000001DE520: DC5E0080 887C0041
	global_load_b128 v[148:151], v[65:66], off offset:272      // 0000001DE528: DC5E0110 947C0041
	global_load_b128 v[144:147], v[65:66], off offset:256      // 0000001DE530: DC5E0100 907C0041
	global_load_b128 v[156:159], v[65:66], off offset:400      // 0000001DE538: DC5E0190 9C7C0041
	global_load_b128 v[152:155], v[65:66], off offset:384      // 0000001DE540: DC5E0180 987C0041
	v_mov_b32_e32 v65, v64                                     // 0000001DE548: 7E820340
	v_mov_b32_e32 v66, v64                                     // 0000001DE54C: 7E840340
	v_dual_mov_b32 v167, v71 :: v_dual_mov_b32 v166, v70       // 0000001DE550: CA100147 A7A60146
	v_dual_mov_b32 v165, v69 :: v_dual_mov_b32 v164, v68       // 0000001DE558: CA100145 A5A40144
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001DE560: BF8700B3
	v_dual_mov_b32 v163, v67 :: v_dual_mov_b32 v162, v66       // 0000001DE564: CA100143 A3A20142
	v_dual_mov_b32 v161, v65 :: v_dual_mov_b32 v160, v64       // 0000001DE56C: CA100141 A1A00140
	v_xor_b32_e32 v65, 1, v126                                 // 0000001DE574: 3A82FC81
	v_lshl_add_u32 v65, v65, 11, v110                          // 0000001DE578: D6460041 05B91741
	s_waitcnt vmcnt(6)                                         // 0000001DE580: BF891BF7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DE584: BF8700A3
	v_wmma_f32_16x16x16_bf16 v[160:167], v[32:39], v[128:135], v[160:167]// 0000001DE588: CC4140A0 1E830120
	s_waitcnt vmcnt(4)                                         // 0000001DE590: BF8913F7
	v_wmma_f32_16x16x16_bf16 v[160:167], v[40:47], v[136:143], v[160:167]// 0000001DE594: CC4140A0 1E831128
	s_waitcnt vmcnt(2)                                         // 0000001DE59C: BF890BF7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DE5A0: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[160:167], v[48:55], v[144:151], v[160:167]// 0000001DE5A4: CC4140A0 1E832130
	s_waitcnt vmcnt(0)                                         // 0000001DE5AC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[160:167], v[56:63], v[152:159], v[160:167]// 0000001DE5B0: CC4140A0 1E833138
	ds_store_2addr_b32 v65, v160, v161 offset1:32              // 0000001DE5B8: D8382000 00A1A041
	ds_store_2addr_b32 v65, v162, v163 offset0:64 offset1:96   // 0000001DE5C0: D8386040 00A3A241
	ds_store_2addr_b32 v65, v164, v165 offset0:128 offset1:160 // 0000001DE5C8: D838A080 00A5A441
	ds_store_2addr_b32 v65, v166, v167 offset0:192 offset1:224 // 0000001DE5D0: D838E0C0 00A7A641
	s_branch 65020                                             // 0000001DE5D8: BFA0FDFC <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x5cc>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001DE5DC: 8C7E067E
	s_branch 25                                                // 0000001DE5E0: BFA00019 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt4xILi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xe48>
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v1, 0               // 0000001DE5E4: CA100080 00000080
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 0000001DE5EC: CA100080 02020080
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 0000001DE5F4: CA100080 04040080
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000001DE5FC: CA100080 08080080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 0000001DE604: CA100080 0A0A0080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 0000001DE60C: CA100080 0C0C0080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v17, 0             // 0000001DE614: CA100080 10100080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 0000001DE61C: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000001DE624: CA100080 14140080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 0000001DE62C: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 0000001DE634: CA100080 1A1A0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0             // 0000001DE63C: CA100080 1C1C0080
	v_mov_b32_e32 v109, 0                                      // 0000001DE644: 7EDA0280
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001DE648: BF870241
	v_add_f32_dpp v6, v109, v109 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DE64C: 060CDAFA FF09616D
	v_add_f32_dpp v7, v66, v66 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DE654: 060E84FA FF096142
	v_dual_mov_b32 v39, s3 :: v_dual_lshlrev_b32 v36, 5, v106  // 0000001DE65C: CA220003 2724D485
	v_or_b32_e32 v34, v107, v104                               // 0000001DE664: 3844D16B
	v_add_f32_dpp v6, v6, v6 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DE668: 060C0CFA FF096206
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001DE670: BF8701A4
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DE674: 060E0EFA FF096207
	s_barrier                                                  // 0000001DE67C: BFBD0000
	v_or_b32_e32 v40, s2, v34                                  // 0000001DE680: 38504402
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DE684: BF870193
	v_add_f32_dpp v6, v6, v6 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DE688: 060C0CFA FF096406
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DE690: 060E0EFA FF096407
	.long 0x7f6c3880                                           // 0000001DE698: 7F6C3880
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DE69C: BF870193
	v_add_f32_dpp v30, v6, v6 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DE6A0: 063C0CFA FF096806
	v_add_f32_dpp v31, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001DE6A8: 063E0EFA FF096807
	v_or_b32_e32 v6, s1, v106                                  // 0000001DE6B0: 380CD401
	v_or_b32_e32 v7, 0x3a10, v36                               // 0000001DE6B4: 380E48FF 00003A10
	.long 0x7f7839b6                                           // 0000001DE6BC: 7F7839B6
	v_div_scale_f32 v32, null, v30, v30, 1.0                   // 0000001DE6C0: D6FC7C20 03CA3D1E
	v_div_scale_f32 v33, null, v31, v31, 1.0                   // 0000001DE6C8: D6FC7C21 03CA3F1F
	v_div_scale_f32 v42, vcc_lo, 1.0, v30, 1.0                 // 0000001DE6D0: D6FC6A2A 03CA3CF2
	v_div_scale_f32 v43, s0, 1.0, v31, 1.0                     // 0000001DE6D8: D6FC002B 03CA3EF2
	v_lshl_add_u32 v41, v105, 3, v7                            // 0000001DE6E0: D6460029 041D0769
	v_rcp_f32_e32 v35, v32                                     // 0000001DE6E8: 7E465520
	v_rcp_f32_e32 v37, v33                                     // 0000001DE6EC: 7E4A5521
	v_lshlrev_b32_e32 v38, 8, v6                               // 0000001DE6F0: 304C0C88
	.long 0x7f7a39b6                                           // 0000001DE6F4: 7F7A39B6
	.long 0x7f7639b6                                           // 0000001DE6F8: 7F7639B6
	.long 0x7f7439b6                                           // 0000001DE6FC: 7F7439B6
	.long 0x7f7239b6                                           // 0000001DE700: 7F7239B6
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001DE704: BF870296
	v_fma_f32 v6, -v32, v35, 1.0                               // 0000001DE708: D6130006 23CA4720
	v_fma_f32 v15, -v33, v37, 1.0                              // 0000001DE710: D613000F 23CA4B21
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DE718: BF870112
	v_dual_fmac_f32 v35, v6, v35 :: v_dual_add_nc_u32 v14, 0x400, v38// 0000001DE71C: C8204706 230E4CFF 00000400
	v_dual_fmac_f32 v37, v15, v37 :: v_dual_add_nc_u32 v22, 0x600, v38// 0000001DE728: C8204B0F 25164CFF 00000600
	v_ashrrev_i32_e32 v7, 31, v38                              // 0000001DE734: 340E4C9F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DE738: BF870213
	v_mul_f32_e32 v45, v42, v35                                // 0000001DE73C: 105A472A
	v_ashrrev_i32_e32 v15, 31, v14                             // 0000001DE740: 341E1C9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DE744: BF870224
	v_mul_f32_e32 v46, v43, v37                                // 0000001DE748: 105C4B2B
	.long 0xd7000106                                           // 0000001DE74C: D7000106
	v_cndmask_b32_e32 v1, v40, v38, vcc_lo                     // 0000001DE750: 02024D28
	v_fma_f32 v48, -v32, v45, v42                              // 0000001DE754: D6130030 24AA5B20
	v_add_nc_u32_e32 v44, 0x800, v38                           // 0000001DE75C: 4A584CFF 00000800
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DE764: BF870224
	v_fma_f32 v49, -v33, v46, v43                              // 0000001DE768: D6130031 24AE5D21
	v_add_co_ci_u32_e64 v7, null, v39, v7, s1                  // 0000001DE770: D5207C07 00060F27
	v_fmac_f32_e32 v45, v48, v35                               // 0000001DE778: 565A4730
	.long 0xd700010e                                           // 0000001DE77C: D700010E
	v_cndmask_b32_e32 v1, v40, v14, vcc_lo                     // 0000001DE780: 02021D28
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DE784: BF870224
	v_fmac_f32_e32 v46, v49, v37                               // 0000001DE788: 565C4B31
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000001DE78C: 342E2C9F
	v_fma_f32 v32, -v32, v45, v42                              // 0000001DE790: D6130020 24AA5B20
	v_add_co_ci_u32_e64 v15, null, v39, v15, s1                // 0000001DE798: D5207C0F 00061F27
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DE7A0: BF870224
	v_fma_f32 v33, -v33, v46, v43                              // 0000001DE7A4: D6130021 24AE5D21
	.long 0xd7000116                                           // 0000001DE7AC: D7000116
	v_cndmask_b32_e32 v1, v40, v22, vcc_lo                     // 0000001DE7B0: 02022D28
	v_div_fmas_f32 v32, v32, v35, v45                          // 0000001DE7B4: D6370020 04B64720
	s_mov_b32 vcc_lo, s0                                       // 0000001DE7BC: BEEA0000
	.long 0xd73c0006                                           // 0000001DE7C0: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000001DE7C4: 02020C81
	v_div_fmas_f32 v33, v33, v37, v46                          // 0000001DE7C8: D6370021 04BA4B21
	v_add_co_ci_u32_e64 v23, null, v39, v23, s1                // 0000001DE7D0: D5207C17 00062F27
	.long 0xd73c000e                                           // 0000001DE7D8: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000001DE7DC: 02021C81
	v_div_fixup_f32 v30, v32, v30, 1.0                         // 0000001DE7E0: D627001E 03CA3D20
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001DE7E8: BF870004
	v_div_fixup_f32 v31, v33, v31, 1.0                         // 0000001DE7EC: D627001F 03CA3F21
	.long 0xd7006a32                                           // 0000001DE7F4: D7006A32
	v_cndmask_b32_e32 v1, s10, v6, vcc_lo                      // 0000001DE7F8: 02020C0A
	.long 0xd73c0016                                           // 0000001DE7FC: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000001DE800: 02022C81
	v_add_nc_u32_e32 v32, 0xa00, v38                           // 0000001DE804: 4A404CFF 00000A00
	v_ashrrev_i32_e32 v47, 31, v44                             // 0000001DE80C: 345E589F
	v_add_co_ci_u32_e64 v51, null, s11, v7, vcc_lo             // 0000001DE810: D5207C33 01AA0E0B
	.long 0xd7006a2a                                           // 0000001DE818: D7006A2A
	v_cndmask_b32_e32 v1, s10, v14, vcc_lo                     // 0000001DE81C: 02021C0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DE820: BF870001
	v_add_co_ci_u32_e64 v43, null, s11, v15, vcc_lo            // 0000001DE824: D5207C2B 01AA1E0B
	ds_store_b64 v41, v[30:31]                                 // 0000001DE82C: D9340000 00001E29
	.long 0xd7006a1e                                           // 0000001DE834: D7006A1E
	v_cndmask_b32_e32 v1, v40, v44, vcc_lo                     // 0000001DE838: 02025928
	v_ashrrev_i32_e32 v33, 31, v32                             // 0000001DE83C: 3442409F
	v_add_co_ci_u32_e64 v31, null, v39, v47, vcc_lo            // 0000001DE840: D5207C1F 01AA5F27
	.long 0xd7006a2c                                           // 0000001DE848: D7006A2C
	v_cndmask_b32_e32 v1, s10, v22, vcc_lo                     // 0000001DE84C: 02022C0A
	v_or_b32_e32 v35, 0x200, v38                               // 0000001DE850: 38464CFF 00000200
	v_add_co_ci_u32_e64 v45, null, s11, v23, vcc_lo            // 0000001DE858: D5207C2D 01AA2E0B
	.long 0xd7006a20                                           // 0000001DE860: D7006A20
	v_cndmask_b32_e32 v1, v40, v32, vcc_lo                     // 0000001DE864: 02024128
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DE868: BF8700A1
	v_add_co_ci_u32_e64 v33, null, v39, v33, vcc_lo            // 0000001DE86C: D5207C21 01AA4327
	.long 0xd7000022                                           // 0000001DE874: D7000022
	v_cndmask_b32_e32 v1, s2, v34, vcc_lo                      // 0000001DE878: 02024402
	v_add_co_ci_u32_e64 v39, null, s3, 0, s0                   // 0000001DE87C: D5207C27 00010003
	v_ashrrev_i32_e32 v40, 31, v35                             // 0000001DE884: 3450469F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DE888: BF870214
	.long 0xd73c0025                                           // 0000001DE88C: D73C0025
	v_cndmask_b32_e32 v1, 1, v32, vcc_lo                       // 0000001DE890: 02024081
	.long 0xd7006a20                                           // 0000001DE894: D7006A20
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000001DE898: 02024722
	.long 0xd73c001e                                           // 0000001DE89C: D73C001E
	v_cndmask_b32_e32 v1, 1, v30, vcc_lo                       // 0000001DE8A0: 02023C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001DE8A4: BF8700B4
	v_add_co_ci_u32_e64 v33, null, v39, v40, vcc_lo            // 0000001DE8A8: D5207C21 01AA5127
	s_waitcnt lgkmcnt(0)                                       // 0000001DE8B0: BF89FC07
	s_barrier                                                  // 0000001DE8B4: BFBD0000
	.long 0xd73c0047                                           // 0000001DE8B8: D73C0047
	v_cndmask_b32_e32 v1, 1, v32, vcc_lo                       // 0000001DE8BC: 02024081
	s_clause 0x1                                               // 0000001DE8C0: BF850001
	global_load_u16 v55, v[50:51], off                         // 0000001DE8C4: DC4A0000 377C0032
	global_load_u16 v56, v[50:51], off offset:1024             // 0000001DE8CC: DC4A0400 387C0032
	.long 0xd7006a2e                                           // 0000001DE8D4: D7006A2E
	v_cndmask_b32_e32 v1, s10, v30, vcc_lo                     // 0000001DE8D8: 02023C0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DE8DC: BF8700A1
	v_add_co_ci_u32_e64 v47, null, s11, v31, vcc_lo            // 0000001DE8E0: D5207C2F 01AA3E0B
	.long 0xd7006a30                                           // 0000001DE8E8: D7006A30
	v_cndmask_b32_e32 v1, s10, v37, vcc_lo                     // 0000001DE8EC: 02024A0A
	v_add_co_ci_u32_e64 v49, null, s11, v38, vcc_lo            // 0000001DE8F0: D5207C31 01AA4C0B
	.long 0xd7006a34                                           // 0000001DE8F8: D7006A34
	v_cndmask_b32_e32 v1, s10, v71, vcc_lo                     // 0000001DE8FC: 02028E0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DE900: BF870001
	v_add_co_ci_u32_e64 v53, null, s11, v72, vcc_lo            // 0000001DE904: D5207C35 01AA900B
	s_clause 0xb                                               // 0000001DE90C: BF85000B
	global_load_u16 v64, v[44:45], off                         // 0000001DE910: DC4A0000 407C002C
	global_load_u16 v63, v[42:43], off                         // 0000001DE918: DC4A0000 3F7C002A
	global_load_u16 v66, v[48:49], off                         // 0000001DE920: DC4A0000 427C0030
	global_load_u16 v65, v[46:47], off                         // 0000001DE928: DC4A0000 417C002E
	global_load_u16 v68, v[52:53], off offset:32               // 0000001DE930: DC4A0020 447C0034
	global_load_u16 v67, v[50:51], off offset:32               // 0000001DE938: DC4A0020 437C0032
	global_load_u16 v70, v[44:45], off offset:32               // 0000001DE940: DC4A0020 467C002C
	global_load_u16 v69, v[42:43], off offset:32               // 0000001DE948: DC4A0020 457C002A
	global_load_u16 v73, v[48:49], off offset:32               // 0000001DE950: DC4A0020 497C0030
	global_load_u16 v74, v[46:47], off offset:32               // 0000001DE958: DC4A0020 4A7C002E
	global_load_u16 v75, v[52:53], off offset:64               // 0000001DE960: DC4A0040 4B7C0034
	global_load_u16 v76, v[50:51], off offset:64               // 0000001DE968: DC4A0040 4C7C0032
	.long 0xd7006a22                                           // 0000001DE970: D7006A22
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 0000001DE974: 02020C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DE978: BF8700A1
	v_add_co_ci_u32_e64 v35, null, s13, v7, vcc_lo             // 0000001DE97C: D5207C23 01AA0E0D
	.long 0xd7006a06                                           // 0000001DE984: D7006A06
	v_cndmask_b32_e32 v1, s12, v14, vcc_lo                     // 0000001DE988: 02021C0C
	v_add_co_ci_u32_e64 v7, null, s13, v15, vcc_lo             // 0000001DE98C: D5207C07 01AA1E0D
	.long 0xd7006a0e                                           // 0000001DE994: D7006A0E
	v_cndmask_b32_e32 v1, s12, v22, vcc_lo                     // 0000001DE998: 02022C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DE99C: BF8700A1
	v_add_co_ci_u32_e64 v15, null, s13, v23, vcc_lo            // 0000001DE9A0: D5207C0F 01AA2E0D
	.long 0xd7006a16                                           // 0000001DE9A8: D7006A16
	v_cndmask_b32_e32 v1, s12, v30, vcc_lo                     // 0000001DE9AC: 02023C0C
	v_add_co_ci_u32_e64 v23, null, s13, v31, vcc_lo            // 0000001DE9B0: D5207C17 01AA3E0D
	ds_load_b128 v[30:33], v36 offset:14864                    // 0000001DE9B8: DBFC3A10 1E000024
	ds_load_b64 v[40:41], v36 offset:14880                     // 0000001DE9C0: D9D83A20 28000024
	.long 0xd7006a24                                           // 0000001DE9C8: D7006A24
	v_cndmask_b32_e32 v1, s12, v37, vcc_lo                     // 0000001DE9CC: 02024A0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DE9D0: BF8700A1
	v_add_co_ci_u32_e64 v37, null, s13, v38, vcc_lo            // 0000001DE9D4: D5207C25 01AA4C0D
	.long 0xd7006a26                                           // 0000001DE9DC: D7006A26
	v_cndmask_b32_e32 v1, s12, v71, vcc_lo                     // 0000001DE9E0: 02028E0C
	v_add_co_ci_u32_e64 v39, null, s13, v72, vcc_lo            // 0000001DE9E4: D5207C27 01AA900D
	s_clause 0x9                                               // 0000001DE9EC: BF850009
	global_load_u16 v62, v[42:43], off offset:64               // 0000001DE9F0: DC4A0040 3E7C002A
	global_load_u16 v50, v[50:51], off offset:96               // 0000001DE9F8: DC4A0060 327C0032
	global_load_u16 v71, v[44:45], off offset:64               // 0000001DEA00: DC4A0040 477C002C
	global_load_u16 v51, v[46:47], off offset:64               // 0000001DEA08: DC4A0040 337C002E
	global_load_u16 v44, v[44:45], off offset:96               // 0000001DEA10: DC4A0060 2C7C002C
	global_load_u16 v42, v[42:43], off offset:96               // 0000001DEA18: DC4A0060 2A7C002A
	global_load_u16 v72, v[48:49], off offset:64               // 0000001DEA20: DC4A0040 487C0030
	global_load_u16 v52, v[52:53], off offset:96               // 0000001DEA28: DC4A0060 347C0034
	global_load_u16 v43, v[48:49], off offset:96               // 0000001DEA30: DC4A0060 2B7C0030
	global_load_u16 v45, v[46:47], off offset:96               // 0000001DEA38: DC4A0060 2D7C002E
	s_waitcnt lgkmcnt(1)                                       // 0000001DEA40: BF89FC17
	v_mul_f32_e32 v18, v18, v32                                // 0000001DEA44: 10244112
	s_waitcnt lgkmcnt(0)                                       // 0000001DEA48: BF89FC07
	v_mul_f32_e32 v20, v20, v40                                // 0000001DEA4C: 10285114
	v_dual_mul_f32 v24, v24, v30 :: v_dual_mul_f32 v29, v29, v41// 0000001DEA50: C8C63D18 181C531D
	v_dual_mul_f32 v26, v26, v32 :: v_dual_mul_f32 v17, v17, v31// 0000001DEA58: C8C6411A 1A103F11
	v_dual_mul_f32 v28, v28, v40 :: v_dual_mul_f32 v19, v19, v33// 0000001DEA60: C8C6511C 1C124313
	v_dual_mul_f32 v27, v27, v33 :: v_dual_mul_f32 v16, v16, v30// 0000001DEA68: C8C6431B 1B103D10
	v_mul_f32_e32 v21, v21, v41                                // 0000001DEA70: 102A5315
	v_dual_mul_f32 v25, v25, v31 :: v_dual_mul_f32 v10, v10, v32// 0000001DEA74: C8C63F19 190A410A
	v_dual_mul_f32 v2, v2, v32 :: v_dual_mul_f32 v9, v9, v31   // 0000001DEA7C: C8C64102 02083F09
	v_mul_f32_e32 v11, v11, v33                                // 0000001DEA84: 1016430B
	v_mul_f32_e32 v13, v13, v41                                // 0000001DEA88: 101A530D
	v_mul_f32_e32 v1, v1, v31                                  // 0000001DEA8C: 10023F01
	v_mul_f32_e32 v3, v3, v33                                  // 0000001DEA90: 10064303
	v_mul_f32_e32 v5, v5, v41                                  // 0000001DEA94: 100A5305
	s_waitcnt vmcnt(23)                                        // 0000001DEA98: BF895FF7
	v_lshlrev_b32_e32 v47, 16, v55                             // 0000001DEA9C: 305E6E90
	s_waitcnt vmcnt(20)                                        // 0000001DEAA0: BF8953F7
	v_lshlrev_b32_e32 v49, 16, v63                             // 0000001DEAA4: 30627E90
	s_waitcnt vmcnt(19)                                        // 0000001DEAA8: BF894FF7
	v_lshlrev_b32_e32 v53, 16, v66                             // 0000001DEAAC: 306A8490
	v_lshlrev_b32_e32 v46, 16, v56                             // 0000001DEAB0: 305C7090
	s_waitcnt vmcnt(18)                                        // 0000001DEAB4: BF894BF7
	v_lshlrev_b32_e32 v55, 16, v65                             // 0000001DEAB8: 306E8290
	s_waitcnt vmcnt(16)                                        // 0000001DEABC: BF8943F7
	v_lshlrev_b32_e32 v63, 16, v67                             // 0000001DEAC0: 307E8690
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v47                  // 0000001DEAC4: 7C3C5EFF 42CE8ED0
	v_dual_mul_f32 v77, 0xbfb8aa3b, v53 :: v_dual_lshlrev_b32 v48, 16, v64// 0000001DEACC: C8E26AFF 4D308090 BFB8AA3B
	s_waitcnt vmcnt(13)                                        // 0000001DEAD8: BF8937F7
	v_dual_mul_f32 v73, 0xbfb8aa3b, v46 :: v_dual_lshlrev_b32 v66, 16, v73// 0000001DEADC: C8E25CFF 49429290 BFB8AA3B
	v_lshlrev_b32_e32 v64, 16, v70                             // 0000001DEAE8: 30808C90
	v_mul_f32_e32 v70, 0xbfb8aa3b, v47                         // 0000001DEAEC: 108C5EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001DEAF4: BF8701B3
	v_dual_mul_f32 v83, 0xbfb8aa3b, v66 :: v_dual_lshlrev_b32 v56, 16, v68// 0000001DEAF8: C8E284FF 53388890 BFB8AA3B
	s_waitcnt vmcnt(11)                                        // 0000001DEB04: BF892FF7
	v_dual_mul_f32 v75, 0xbfb8aa3b, v48 :: v_dual_lshlrev_b32 v68, 16, v75// 0000001DEB08: C8E260FF 4B449690 BFB8AA3B
	v_fma_f32 v86, 0xbfb8aa3b, v47, -v70                       // 0000001DEB14: D6130056 851A5EFF BFB8AA3B
	v_rndne_f32_e32 v87, v70                                   // 0000001DEB20: 7EAE4746
	v_fma_f32 v88, 0xbfb8aa3b, v46, -v73                       // 0000001DEB24: D6130058 85265CFF BFB8AA3B
	v_rndne_f32_e32 v89, v73                                   // 0000001DEB30: 7EB24749
	v_rndne_f32_e32 v93, v75                                   // 0000001DEB34: 7EBA474B
	v_fmac_f32_e32 v86, 0xb2a5705f, v47                        // 0000001DEB38: 56AC5EFF B2A5705F
	v_dual_sub_f32 v70, v70, v87 :: v_dual_lshlrev_b32 v65, 16, v69// 0000001DEB40: C962AF46 46408A90
	s_waitcnt vmcnt(10)                                        // 0000001DEB48: BF892BF7
	v_lshlrev_b32_e32 v69, 16, v76                             // 0000001DEB4C: 308A9890
	v_fma_f32 v92, 0xbfb8aa3b, v48, -v75                       // 0000001DEB50: D613005C 852E60FF BFB8AA3B
	v_rndne_f32_e32 v97, v77                                   // 0000001DEB5C: 7EC2474D
	v_dual_fmac_f32 v88, 0xb2a5705f, v46 :: v_dual_sub_f32 v73, v73, v89// 0000001DEB60: C80A5CFF 5848B349 B2A5705F
	v_dual_sub_f32 v75, v75, v93 :: v_dual_add_f32 v70, v70, v86// 0000001DEB6C: C948BB4B 4B46AD46
	v_dual_mul_f32 v74, 0xbfb8aa3b, v49 :: v_dual_lshlrev_b32 v67, 16, v74// 0000001DEB74: C8E262FF 4A429490 BFB8AA3B
	v_mul_f32_e32 v76, 0xbfb8aa3b, v55                         // 0000001DEB80: 10986EFF BFB8AA3B
	v_dual_mul_f32 v80, 0xbfb8aa3b, v65 :: v_dual_mul_f32 v81, 0xbfb8aa3b, v64// 0000001DEB88: C8C682FF 505080FF BFB8AA3B
	v_fma_f32 v96, 0xbfb8aa3b, v53, -v77                       // 0000001DEB94: D6130060 85366AFF BFB8AA3B
	v_sub_f32_e32 v77, v77, v97                                // 0000001DEBA0: 089AC34D
	v_dual_mul_f32 v84, 0xbfb8aa3b, v69 :: v_dual_add_f32 v73, v73, v88// 0000001DEBA4: C8C88AFF 5448B149 BFB8AA3B
	v_exp_f32_e32 v70, v70                                     // 0000001DEBB0: 7E8C4B46
	v_mul_f32_e32 v79, 0xbfb8aa3b, v56                         // 0000001DEBB4: 109E70FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v49, -v74                       // 0000001DEBBC: D613005A 852A62FF BFB8AA3B
	v_rndne_f32_e32 v91, v74                                   // 0000001DEBC8: 7EB6474A
	v_rndne_f32_e32 v105, v81                                  // 0000001DEBCC: 7ED24751
	v_cvt_i32_f32_e32 v87, v87                                 // 0000001DEBD0: 7EAE1157
	v_exp_f32_e32 v73, v73                                     // 0000001DEBD4: 7E924B49
	v_fma_f32 v100, 0xbfb8aa3b, v56, -v79                      // 0000001DEBD8: D6130064 853E70FF BFB8AA3B
	v_rndne_f32_e32 v101, v79                                  // 0000001DEBE4: 7ECA474F
	v_fma_f32 v104, 0xbfb8aa3b, v64, -v81                      // 0000001DEBE8: D6130068 854680FF BFB8AA3B
	v_cvt_i32_f32_e32 v89, v89                                 // 0000001DEBF4: 7EB21159
	v_sub_f32_e32 v74, v74, v91                                // 0000001DEBF8: 0894B74A
	v_dual_fmac_f32 v92, 0xb2a5705f, v48 :: v_dual_sub_f32 v81, v81, v105// 0000001DEBFC: C80A60FF 5C50D351 B2A5705F
	v_fmac_f32_e32 v90, 0xb2a5705f, v49                        // 0000001DEC08: 56B462FF B2A5705F
	.long 0xd71c0046                                           // 0000001DEC10: D71C0046
	v_cndmask_b32_e32 v1, v70, v87, vcc_lo                     // 0000001DEC14: 0202AF46
	v_fma_f32 v94, 0xbfb8aa3b, v55, -v76                       // 0000001DEC18: D613005E 85326EFF BFB8AA3B
	v_rndne_f32_e32 v95, v76                                   // 0000001DEC24: 7EBE474C
	v_sub_f32_e32 v79, v79, v101                               // 0000001DEC28: 089ECB4F
	v_dual_add_f32 v75, v75, v92 :: v_dual_add_f32 v74, v74, v90// 0000001DEC2C: C908B94B 4B4AB54A
	.long 0xd71c0049                                           // 0000001DEC34: D71C0049
	v_cndmask_b32_e32 v1, v73, v89, vcc_lo                     // 0000001DEC38: 0202B349
	v_cndmask_b32_e32 v70, 0, v70, vcc_lo                      // 0000001DEC3C: 028C8C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 0000001DEC40: 7C3C5CFF 42CE8ED0
	v_fmac_f32_e32 v100, 0xb2a5705f, v56                       // 0000001DEC48: 56C870FF B2A5705F
	v_rndne_f32_e32 v109, v83                                  // 0000001DEC50: 7EDA4753
	v_fmac_f32_e32 v94, 0xb2a5705f, v55                        // 0000001DEC54: 56BC6EFF B2A5705F
	v_exp_f32_e32 v74, v74                                     // 0000001DEC5C: 7E944B4A
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000001DEC60: 02929280
	v_dual_fmac_f32 v96, 0xb2a5705f, v53 :: v_dual_add_f32 v79, v79, v100// 0000001DEC64: C8086AFF 604EC94F B2A5705F
	v_sub_f32_e32 v76, v76, v95                                // 0000001DEC70: 0898BF4C
	v_mul_f32_e32 v78, 0xbfb8aa3b, v63                         // 0000001DEC74: 109C7EFF BFB8AA3B
	v_fma_f32 v108, 0xbfb8aa3b, v66, -v83                      // 0000001DEC7C: D613006C 854E84FF BFB8AA3B
	v_cvt_i32_f32_e32 v91, v91                                 // 0000001DEC88: 7EB6115B
	v_sub_f32_e32 v83, v83, v109                               // 0000001DEC8C: 08A6DB53
	v_dual_add_f32 v77, v77, v96 :: v_dual_add_f32 v76, v76, v94// 0000001DEC90: C908C14D 4D4CBD4C
	v_exp_f32_e32 v75, v75                                     // 0000001DEC98: 7E964B4B
	v_exp_f32_e32 v79, v79                                     // 0000001DEC9C: 7E9E4B4F
	v_fma_f32 v98, 0xbfb8aa3b, v63, -v78                       // 0000001DECA0: D6130062 853A7EFF BFB8AA3B
	v_rndne_f32_e32 v99, v78                                   // 0000001DECAC: 7EC6474E
	v_cvt_i32_f32_e32 v93, v93                                 // 0000001DECB0: 7EBA115D
	v_cvt_i32_f32_e32 v101, v101                               // 0000001DECB4: 7ECA1165
	v_exp_f32_e32 v76, v76                                     // 0000001DECB8: 7E984B4C
	.long 0xd71c004a                                           // 0000001DECBC: D71C004A
	v_cndmask_b32_e32 v1, v74, v91, vcc_lo                     // 0000001DECC0: 0202B74A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001DECC4: 7C3C62FF 42CE8ED0
	v_fma_f32 v102, 0xbfb8aa3b, v65, -v80                      // 0000001DECCC: D6130066 854282FF BFB8AA3B
	v_cvt_i32_f32_e32 v95, v95                                 // 0000001DECD8: 7EBE115F
	v_fmac_f32_e32 v108, 0xb2a5705f, v66                       // 0000001DECDC: 56D884FF B2A5705F
	v_sub_f32_e32 v78, v78, v99                                // 0000001DECE4: 089CC74E
	v_exp_f32_e32 v77, v77                                     // 0000001DECE8: 7E9A4B4D
	.long 0xd71c004b                                           // 0000001DECEC: D71C004B
	v_cndmask_b32_e32 v1, v75, v93, vcc_lo                     // 0000001DECF0: 0202BB4B
	.long 0xd71c004f                                           // 0000001DECF4: D71C004F
	v_cndmask_b32_e32 v1, v79, v101, vcc_lo                    // 0000001DECF8: 0202CB4F
	v_fmac_f32_e32 v104, 0xb2a5705f, v64                       // 0000001DECFC: 56D080FF B2A5705F
	v_fmac_f32_e32 v98, 0xb2a5705f, v63                        // 0000001DED04: 56C47EFF B2A5705F
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000001DED0C: 02949480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 0000001DED10: 7C3C60FF 42CE8ED0
	v_rndne_f32_e32 v103, v80                                  // 0000001DED18: 7ECE4750
	v_cvt_i32_f32_e32 v97, v97                                 // 0000001DED1C: 7EC21161
	v_dual_fmac_f32 v102, 0xb2a5705f, v65 :: v_dual_add_f32 v81, v81, v104// 0000001DED20: C80882FF 6650D151 B2A5705F
	v_dual_add_f32 v83, v83, v108 :: v_dual_add_f32 v78, v78, v98// 0000001DED2C: C908D953 534EC54E
	.long 0xd71c004c                                           // 0000001DED34: D71C004C
	v_cndmask_b32_e32 v1, v76, v95, vcc_lo                     // 0000001DED38: 0202BF4C
	v_cndmask_b32_e32 v75, 0, v75, vcc_lo                      // 0000001DED3C: 02969680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v55                  // 0000001DED40: 7C3C6EFF 42CE8ED0
	.long 0xd71c004d                                           // 0000001DED48: D71C004D
	v_cndmask_b32_e32 v1, v77, v97, vcc_lo                     // 0000001DED4C: 0202C34D
	v_exp_f32_e32 v78, v78                                     // 0000001DED50: 7E9C4B4E
	v_cvt_i32_f32_e32 v99, v99                                 // 0000001DED54: 7EC61163
	v_dual_mul_f32 v82, 0xbfb8aa3b, v67 :: v_dual_mul_f32 v85, 0xbfb8aa3b, v68// 0000001DED58: C8C686FF 525488FF BFB8AA3B
	v_cndmask_b32_e32 v76, 0, v76, vcc_lo                      // 0000001DED64: 02989880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v53                  // 0000001DED68: 7C3C6AFF 42CE8ED0
	v_sub_f32_e32 v80, v80, v103                               // 0000001DED70: 08A0CF50
	v_cvt_i32_f32_e32 v103, v103                               // 0000001DED74: 7ECE1167
	v_exp_f32_e32 v81, v81                                     // 0000001DED78: 7EA24B51
	v_fma_f32 v106, 0xbfb8aa3b, v67, -v82                      // 0000001DED7C: D613006A 854A86FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001DED88: BF870003
	v_dual_cndmask_b32 v77, 0, v77 :: v_dual_add_f32 v80, v80, v102// 0000001DED8C: CA489A80 4D50CD50
	.long 0xd71c004e                                           // 0000001DED94: D71C004E
	v_cndmask_b32_e32 v1, v78, v99, vcc_lo                     // 0000001DED98: 0202C74E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v63                  // 0000001DED9C: 7C3C7EFF 42CE8ED0
	v_rndne_f32_e32 v107, v82                                  // 0000001DEDA4: 7ED64752
	v_cvt_i32_f32_e32 v105, v105                               // 0000001DEDA8: 7ED21169
	v_exp_f32_e32 v80, v80                                     // 0000001DEDAC: 7EA04B50
	v_exp_f32_e32 v83, v83                                     // 0000001DEDB0: 7EA64B53
	v_cndmask_b32_e32 v78, 0, v78, vcc_lo                      // 0000001DEDB4: 029C9C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 0000001DEDB8: 7C3C70FF 42CE8ED0
	v_sub_f32_e32 v82, v82, v107                               // 0000001DEDC0: 08A4D752
	.long 0xd71c0051                                           // 0000001DEDC4: D71C0051
	v_cndmask_b32_e32 v1, v81, v105, vcc_lo                    // 0000001DEDC8: 0202D351
	v_cvt_i32_f32_e32 v107, v107                               // 0000001DEDCC: 7ED6116B
	v_cvt_i32_f32_e32 v109, v109                               // 0000001DEDD0: 7EDA116D
	v_cndmask_b32_e32 v79, 0, v79, vcc_lo                      // 0000001DEDD4: 029E9E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000001DEDD8: 7C3C82FF 42CE8ED0
	.long 0xd71c0050                                           // 0000001DEDE0: D71C0050
	v_cndmask_b32_e32 v1, v80, v103, vcc_lo                    // 0000001DEDE4: 0202CF50
	v_fma_f32 v110, 0xbfb8aa3b, v69, -v84                      // 0000001DEDE8: D613006E 85528AFF BFB8AA3B
	.long 0xd71c0053                                           // 0000001DEDF4: D71C0053
	v_cndmask_b32_e32 v1, v83, v109, vcc_lo                    // 0000001DEDF8: 0202DB53
	v_rndne_f32_e32 v111, v84                                  // 0000001DEDFC: 7EDE4754
	v_rndne_f32_e32 v113, v85                                  // 0000001DEE00: 7EE24755
	v_cndmask_b32_e32 v80, 0, v80, vcc_lo                      // 0000001DEE04: 02A0A080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 0000001DEE08: 7C3C80FF 42CE8ED0
	v_fmac_f32_e32 v106, 0xb2a5705f, v67                       // 0000001DEE10: 56D486FF B2A5705F
	v_fma_f32 v112, 0xbfb8aa3b, v68, -v85                      // 0000001DEE18: D6130070 855688FF BFB8AA3B
	s_waitcnt vmcnt(1)                                         // 0000001DEE24: BF8907F7
	v_dual_cndmask_b32 v81, 0, v81 :: v_dual_lshlrev_b32 v32, 16, v43// 0000001DEE28: CA62A280 51205690
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001DEE30: BF8701B3
	v_add_f32_e32 v82, v82, v106                               // 0000001DEE34: 06A4D552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v67                  // 0000001DEE38: 7C3C86FF 42CE8ED0
	v_fmac_f32_e32 v112, 0xb2a5705f, v68                       // 0000001DEE40: 56E088FF B2A5705F
	v_exp_f32_e32 v82, v82                                     // 0000001DEE48: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DEE4C: BF870095
	.long 0xd71c0052                                           // 0000001DEE50: D71C0052
	v_cndmask_b32_e32 v1, v82, v107, vcc_lo                    // 0000001DEE54: 0202D752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000001DEE58: 02A4A480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v66                  // 0000001DEE5C: 7C3C84FF 42CE8ED0
	v_cndmask_b32_e32 v83, 0, v83, vcc_lo                      // 0000001DEE64: 02A6A680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v47                  // 0000001DEE68: 7C365EFF C2B17218
	v_cndmask_b32_e32 v47, 0x7f800000, v70, vcc_lo             // 0000001DEE70: 025E8CFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 0000001DEE78: 7C365CFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001DEE80: BF870242
	v_dual_fmac_f32 v110, 0xb2a5705f, v69 :: v_dual_add_f32 v47, 1.0, v47// 0000001DEE84: C8088AFF 6E2E5EF2 B2A5705F
	v_cndmask_b32_e32 v46, 0x7f800000, v73, vcc_lo             // 0000001DEE90: 025C92FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001DEE98: 7C3662FF C2B17218
	v_sub_f32_e32 v84, v84, v111                               // 0000001DEEA0: 08A8DF54
	v_div_scale_f32 v70, null, v47, v47, v24                   // 0000001DEEA4: D6FC7C46 04625F2F
	v_cndmask_b32_e32 v49, 0x7f800000, v74, vcc_lo             // 0000001DEEAC: 026294FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 0000001DEEB4: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DEEBC: BF870113
	v_rcp_f32_e32 v97, v70                                     // 0000001DEEC0: 7EC25546
	v_dual_add_f32 v49, 1.0, v49 :: v_dual_cndmask_b32 v48, 0x7f800000, v75// 0000001DEEC4: C91262F2 313096FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v55                  // 0000001DEED0: 7C366EFF C2B17218
	v_cndmask_b32_e32 v55, 0x7f800000, v76, vcc_lo             // 0000001DEED8: 026E98FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v53                  // 0000001DEEE0: 7C366AFF C2B17218
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DEEE8: BF870225
	v_fma_f32 v109, -v70, v97, 1.0                             // 0000001DEEEC: D613006D 23CAC346
	v_div_scale_f32 v76, null, v49, v49, v26                   // 0000001DEEF4: D6FC7C4C 046A6331
	v_add_f32_e32 v55, 1.0, v55                                // 0000001DEEFC: 066E6EF2
	v_cndmask_b32_e32 v53, 0x7f800000, v77, vcc_lo             // 0000001DEF00: 026A9AFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v63                  // 0000001DEF08: 7C367EFF C2B17218
	v_fmac_f32_e32 v97, v109, v97                              // 0000001DEF10: 56C2C36D
	v_rcp_f32_e32 v99, v76                                     // 0000001DEF14: 7EC6554C
	v_div_scale_f32 v77, s1, v26, v49, v26                     // 0000001DEF18: D6FC014D 046A631A
	v_add_f32_e32 v53, 1.0, v53                                // 0000001DEF20: 066A6AF2
	v_cndmask_b32_e32 v63, 0x7f800000, v78, vcc_lo             // 0000001DEF24: 027E9CFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 0000001DEF2C: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 0000001DEF34: BF8702B2
	v_dual_add_f32 v84, v84, v110 :: v_dual_add_f32 v63, 1.0, v63// 0000001DEF38: C908DD54 543E7EF2
	v_cndmask_b32_e32 v56, 0x7f800000, v79, vcc_lo             // 0000001DEF40: 02709EFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000001DEF48: 7C3682FF C2B17218
	v_fma_f32 v114, -v76, v99, 1.0                             // 0000001DEF50: D6130072 23CAC74C
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001DEF58: BF870004
	v_exp_f32_e32 v84, v84                                     // 0000001DEF5C: 7EA84B54
	v_div_scale_f32 v86, null, v63, v63, v16                   // 0000001DEF60: D6FC7C56 04427F3F
	v_div_scale_f32 v87, s5, v16, v63, v16                     // 0000001DEF68: D6FC0557 04427F10
	v_cndmask_b32_e32 v65, 0x7f800000, v80, vcc_lo             // 0000001DEF70: 0282A0FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 0000001DEF78: 7C3680FF C2B17218
	v_div_scale_f32 v80, null, v55, v55, v28                   // 0000001DEF80: D6FC7C50 04726F37
	v_fmac_f32_e32 v99, v114, v99                              // 0000001DEF88: 56C6C772
	v_rcp_f32_e32 v103, v86                                    // 0000001DEF8C: 7ECE5556
	v_add_f32_e32 v65, 1.0, v65                                // 0000001DEF90: 068282F2
	v_cndmask_b32_e32 v64, 0x7f800000, v81, vcc_lo             // 0000001DEF94: 0280A2FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v67                  // 0000001DEF9C: 7C3686FF C2B17218
	v_rcp_f32_e32 v101, v80                                    // 0000001DEFA4: 7ECA5550
	v_div_scale_f32 v81, s3, v28, v55, v28                     // 0000001DEFA8: D6FC0351 04726F1C
	v_div_scale_f32 v90, null, v65, v65, v18                   // 0000001DEFB0: D6FC7C5A 044A8341
	v_dual_mul_f32 v114, v77, v99 :: v_dual_cndmask_b32 v67, 0x7f800000, v82// 0000001DEFB8: C8D2C74D 7242A4FF 7F800000
	v_div_scale_f32 v82, null, v53, v53, v29                   // 0000001DEFC4: D6FC7C52 04766B35
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v66                  // 0000001DEFCC: 7C3684FF C2B17218
	v_fma_f32 v118, -v86, v103, 1.0                            // 0000001DEFD4: D6130076 23CACF56
	v_rcp_f32_e32 v105, v90                                    // 0000001DEFDC: 7ED2555A
	v_add_f32_e32 v67, 1.0, v67                                // 0000001DEFE0: 068686F2
	v_rcp_f32_e32 v102, v82                                    // 0000001DEFE4: 7ECC5552
	v_fma_f32 v116, -v80, v101, 1.0                            // 0000001DEFE8: D6130074 23CACB50
	v_cndmask_b32_e32 v66, 0x7f800000, v83, vcc_lo             // 0000001DEFF0: 0284A6FF 7F800000
	v_div_scale_f32 v83, s4, v29, v53, v29                     // 0000001DEFF8: D6FC0453 04766B1D
	v_div_scale_f32 v73, vcc_lo, v24, v47, v24                 // 0000001DF000: D6FC6A49 04625F18
	v_div_scale_f32 v94, null, v67, v67, v20                   // 0000001DF008: D6FC7C5E 04528743
	v_fmac_f32_e32 v101, v116, v101                            // 0000001DF010: 56CACB74
	v_fmac_f32_e32 v103, v118, v103                            // 0000001DF014: 56CECF76
	v_fma_f32 v120, -v90, v105, 1.0                            // 0000001DF018: D6130078 23CAD35A
	v_mul_f32_e32 v109, v73, v97                               // 0000001DF020: 10DAC349
	v_fma_f32 v117, -v82, v102, 1.0                            // 0000001DF024: D6130075 23CACD52
	v_add_f32_e32 v66, 1.0, v66                                // 0000001DF02C: 068484F2
	v_rcp_f32_e32 v107, v94                                    // 0000001DF030: 7ED6555E
	v_fmac_f32_e32 v105, v120, v105                            // 0000001DF034: 56D2D378
	v_mul_f32_e32 v116, v81, v101                              // 0000001DF038: 10E8CB51
	v_fmac_f32_e32 v102, v117, v102                            // 0000001DF03C: 56CCCD75
	v_add_f32_e32 v48, 1.0, v48                                // 0000001DF040: 066060F2
	v_div_scale_f32 v96, null, v66, v66, v21                   // 0000001DF044: D6FC7C60 04568542
	v_fma_f32 v125, -v76, v114, v77                            // 0000001DF04C: D613007D 2536E54C
	v_fma_f32 v127, -v80, v116, v81                            // 0000001DF054: D613007F 2546E950
	v_mul_f32_e32 v117, v83, v102                              // 0000001DF05C: 10EACD53
	v_div_scale_f32 v78, null, v48, v48, v27                   // 0000001DF060: D6FC7C4E 046E6130
	v_rcp_f32_e32 v108, v96                                    // 0000001DF068: 7ED85560
	v_div_scale_f32 v79, s2, v27, v48, v27                     // 0000001DF06C: D6FC024F 046E611B
	v_fma_f32 v122, -v94, v107, 1.0                            // 0000001DF074: D613007A 23CAD75E
	v_fma_f32 v128, -v82, v117, v83                            // 0000001DF07C: D6130080 254EEB52
	v_rcp_f32_e32 v100, v78                                    // 0000001DF084: 7EC8554E
	v_fmac_f32_e32 v114, v125, v99                             // 0000001DF088: 56E4C77D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DF08C: BF870193
	v_dual_fmac_f32 v116, v127, v101 :: v_dual_fmac_f32 v107, v122, v107// 0000001DF090: C800CB7F 746AD77A
	v_fmac_f32_e32 v117, v128, v102                            // 0000001DF098: 56EACD80
	v_div_scale_f32 v91, s7, v18, v65, v18                     // 0000001DF09C: D6FC075B 044A8312
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001DF0A4: BF8702A6
	v_fma_f32 v123, -v96, v108, 1.0                            // 0000001DF0A8: D613007B 23CAD960
	v_div_scale_f32 v95, s9, v20, v67, v20                     // 0000001DF0B0: D6FC095F 04528714
	v_fma_f32 v115, -v78, v100, 1.0                            // 0000001DF0B8: D6130073 23CAC94E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001DF0C0: BF870253
	v_fmac_f32_e32 v108, v123, v108                            // 0000001DF0C4: 56D8D97B
	v_fma_f32 v123, -v70, v109, v73                            // 0000001DF0C8: D613007B 2526DB46
	v_add_f32_e32 v64, 1.0, v64                                // 0000001DF0D0: 068080F2
	v_mul_f32_e32 v120, v91, v105                              // 0000001DF0D4: 10F0D35B
	v_fmac_f32_e32 v100, v115, v100                            // 0000001DF0D8: 56C8C973
	v_dual_add_f32 v46, 1.0, v46 :: v_dual_fmac_f32 v109, v123, v97// 0000001DF0DC: C9005CF2 2E6CC37B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DF0E4: BF870224
	v_div_scale_f32 v92, null, v64, v64, v19                   // 0000001DF0E8: D6FC7C5C 044E8140
	v_div_scale_f32 v93, s8, v19, v64, v19                     // 0000001DF0F0: D6FC085D 044E8113
	v_mul_f32_e32 v115, v79, v100                              // 0000001DF0F8: 10E6C94F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001DF0FC: BF870004
	v_div_scale_f32 v74, null, v46, v46, v25                   // 0000001DF100: D6FC7C4A 04665D2E
	v_div_scale_f32 v75, s0, v25, v46, v25                     // 0000001DF108: D6FC004B 04665D19
	v_rcp_f32_e32 v106, v92                                    // 0000001DF110: 7ED4555C
	v_fma_f32 v70, -v70, v109, v73                             // 0000001DF114: D6130046 2526DB46
	v_fma_f32 v126, -v78, v115, v79                            // 0000001DF11C: D613007E 253EE74E
	v_rcp_f32_e32 v98, v74                                     // 0000001DF124: 7EC4554A
	v_fma_f32 v131, -v90, v120, v91                            // 0000001DF128: D6130083 256EF15A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DF130: BF870193
	v_div_fmas_f32 v70, v70, v97, v109                         // 0000001DF134: D6370046 05B6C346
	v_fmac_f32_e32 v115, v126, v100                            // 0000001DF13C: 56E6C97E
	s_mov_b32 vcc_lo, s0                                       // 0000001DF140: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001DF144: BF870313
	v_fmac_f32_e32 v120, v131, v105                            // 0000001DF148: 56F0D383
	v_fma_f32 v121, -v92, v106, 1.0                            // 0000001DF14C: D6130079 23CAD55C
	v_div_fixup_f32 v24, v70, v47, v24                         // 0000001DF154: D6270018 04625F46
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DF15C: BF870195
	v_fma_f32 v110, -v74, v98, 1.0                             // 0000001DF160: D613006E 23CAC54A
	v_fmac_f32_e32 v106, v121, v106                            // 0000001DF168: 56D4D579
	v_add_f32_e32 v56, 1.0, v56                                // 0000001DF16C: 067070F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DF170: BF870214
	.long 0x7e7a3998                                           // 0000001DF174: 7E7A3998
	v_fmac_f32_e32 v98, v110, v98                              // 0000001DF178: 56C4C56E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DF17C: BF870214
	v_mul_f32_e32 v121, v93, v106                              // 0000001DF180: 10F2D55D
	v_div_scale_f32 v88, null, v56, v56, v17                   // 0000001DF184: D6FC7C58 04467138
	v_div_scale_f32 v89, s6, v17, v56, v17                     // 0000001DF18C: D6FC0659 04467111
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DF194: BF870214
	v_mul_f32_e32 v110, v75, v98                               // 0000001DF198: 10DCC54B
	v_fma_f32 v132, -v92, v121, v93                            // 0000001DF19C: D6130084 2576F35C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DF1A4: BF870114
	v_rcp_f32_e32 v104, v88                                    // 0000001DF1A8: 7ED05558
	v_fma_f32 v124, -v74, v110, v75                            // 0000001DF1AC: D613007C 252EDD4A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DF1B4: BF870112
	v_fmac_f32_e32 v121, v132, v106                            // 0000001DF1B8: 56F2D584
	v_fmac_f32_e32 v110, v124, v98                             // 0000001DF1BC: 56DCC57C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DF1C0: BF870115
	v_fma_f32 v119, -v88, v104, 1.0                            // 0000001DF1C4: D6130077 23CAD158
	v_fma_f32 v73, -v74, v110, v75                             // 0000001DF1CC: D6130049 252EDD4A
	v_fma_f32 v74, -v76, v114, v77                             // 0000001DF1D4: D613004A 2536E54C
	v_fma_f32 v75, -v78, v115, v79                             // 0000001DF1DC: D613004B 253EE74E
	v_fma_f32 v76, -v80, v116, v81                             // 0000001DF1E4: D613004C 2546E950
	v_fma_f32 v77, -v82, v117, v83                             // 0000001DF1EC: D613004D 254EEB52
	v_div_fmas_f32 v73, v73, v98, v110                         // 0000001DF1F4: D6370049 05BAC549
	s_mov_b32 vcc_lo, s1                                       // 0000001DF1FC: BEEA0001
	v_fmac_f32_e32 v104, v119, v104                            // 0000001DF200: 56D0D177
	v_div_fmas_f32 v74, v74, v99, v114                         // 0000001DF204: D637004A 05CAC74A
	s_mov_b32 vcc_lo, s2                                       // 0000001DF20C: BEEA0002
	v_div_fixup_f32 v25, v73, v46, v25                         // 0000001DF210: D6270019 04665D49
	v_div_fmas_f32 v47, v75, v100, v115                        // 0000001DF218: D637002F 05CEC94B
	s_mov_b32 vcc_lo, s3                                       // 0000001DF220: BEEA0003
	v_div_fixup_f32 v26, v74, v49, v26                         // 0000001DF224: D627001A 046A634A
	v_div_fmas_f32 v46, v76, v101, v116                        // 0000001DF22C: D637002E 05D2CB4C
	s_mov_b32 vcc_lo, s4                                       // 0000001DF234: BEEA0004
	.long 0x7e6c3999                                           // 0000001DF238: 7E6C3999
	v_div_fmas_f32 v49, v77, v102, v117                        // 0000001DF23C: D6370031 05D6CD4D
	v_mul_f32_e32 v119, v89, v104                              // 0000001DF244: 10EED159
	v_div_fixup_f32 v27, v47, v48, v27                         // 0000001DF248: D627001B 046E612F
	s_mov_b32 vcc_lo, s5                                       // 0000001DF250: BEEA0005
	v_fma_f32 v80, -v90, v120, v91                             // 0000001DF254: D6130050 256EF15A
	v_div_fixup_f32 v29, v49, v53, v29                         // 0000001DF25C: D627001D 04766B31
	v_dual_mul_f32 v118, v87, v103 :: v_dual_and_b32 v53, 1, v54// 0000001DF264: C8E4CF57 76346C81
	v_fma_f32 v130, -v88, v119, v89                            // 0000001DF26C: D6130082 2566EF58
	v_fma_f32 v81, -v92, v121, v93                             // 0000001DF274: D6130051 2576F35C
	v_div_fixup_f32 v28, v46, v55, v28                         // 0000001DF27C: D627001C 04726F2E
	.long 0x7e6c399b                                           // 0000001DF284: 7E6C399B
	v_fma_f32 v129, -v86, v118, v87                            // 0000001DF288: D6130081 255EED56
	v_dual_fmac_f32 v119, v130, v104 :: v_dual_and_b32 v48, 1, v61// 0000001DF290: C824D182 77307A81
	.long 0x7e78399a                                           // 0000001DF298: 7E78399A
	.long 0x7e76399c                                           // 0000001DF29C: 7E76399C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DF2A0: BF870214
	v_fmac_f32_e32 v118, v129, v103                            // 0000001DF2A4: 56ECCF81
	v_fma_f32 v79, -v88, v119, v89                             // 0000001DF2A8: D613004F 2566EF58
	v_add3_u32 v24, v24, v48, 0x7fff                           // 0000001DF2B0: D6550018 03FE6118 00007FFF
	v_and_b32_e32 v55, 1, v60                                  // 0000001DF2BC: 366E7881
	v_add3_u32 v25, v25, v53, 0x7fff                           // 0000001DF2C0: D6550019 03FE6B19 00007FFF
	v_fma_f32 v78, -v86, v118, v87                             // 0000001DF2CC: D613004E 255EED56
	v_and_b32_e32 v48, 1, v59                                  // 0000001DF2D4: 36607681
	s_clause 0x1                                               // 0000001DF2D8: BF850001
	global_store_d16_hi_b16 v[34:35], v24, off                 // 0000001DF2DC: DC960000 007C1822
	global_store_d16_hi_b16 v[34:35], v25, off offset:1024     // 0000001DF2E4: DC960400 007C1922
	v_add3_u32 v26, v26, v55, 0x7fff                           // 0000001DF2EC: D655001A 03FE6F1A 00007FFF
	v_div_fmas_f32 v47, v78, v103, v118                        // 0000001DF2F8: D637002F 05DACF4E
	s_mov_b32 vcc_lo, s6                                       // 0000001DF300: BEEA0006
	v_add3_u32 v28, v28, v48, 0x7fff                           // 0000001DF304: D655001C 03FE611C 00007FFF
	v_div_fmas_f32 v46, v79, v104, v119                        // 0000001DF310: D637002E 05DED14F
	s_mov_b32 vcc_lo, s7                                       // 0000001DF318: BEEA0007
	v_div_fixup_f32 v16, v47, v63, v16                         // 0000001DF31C: D6270010 04427F2F
	v_div_fmas_f32 v49, v80, v105, v120                        // 0000001DF324: D6370031 05E2D350
	s_mov_b32 vcc_lo, s8                                       // 0000001DF32C: BEEA0008
	v_div_fixup_f32 v17, v46, v56, v17                         // 0000001DF330: D6270011 0446712E
	v_div_fmas_f32 v47, v81, v106, v121                        // 0000001DF338: D637002F 05E6D551
	v_and_b32_e32 v46, 1, v54                                  // 0000001DF340: 365C6C81
	.long 0x7e6c399d                                           // 0000001DF344: 7E6C399D
	.long 0x7e743990                                           // 0000001DF348: 7E743990
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v69                  // 0000001DF34C: 7C3C8AFF 42CE8ED0
	v_div_fixup_f32 v19, v47, v64, v19                         // 0000001DF354: D6270013 044E812F
	v_add3_u32 v25, v27, v46, 0x7fff                           // 0000001DF35C: D6550019 03FE5D1B 00007FFF
	v_and_b32_e32 v47, 1, v54                                  // 0000001DF368: 365E6C81
	.long 0x7e6c3991                                           // 0000001DF36C: 7E6C3991
	v_and_b32_e32 v24, 1, v58                                  // 0000001DF370: 36307481
	v_div_fixup_f32 v18, v49, v65, v18                         // 0000001DF374: D6270012 044A8331
	v_lshlrev_b32_e32 v49, 16, v71                             // 0000001DF37C: 30628E90
	v_add3_u32 v29, v29, v47, 0x7fff                           // 0000001DF380: D655001D 03FE5F1D 00007FFF
	v_and_b32_e32 v27, 1, v54                                  // 0000001DF38C: 36366C81
	v_add3_u32 v16, v16, v24, 0x7fff                           // 0000001DF390: D6550010 03FE3110 00007FFF
	.long 0x7e6c3993                                           // 0000001DF39C: 7E6C3993
	v_mul_f32_e32 v56, 0xbfb8aa3b, v49                         // 0000001DF3A0: 107062FF BFB8AA3B
	.long 0x7e723992                                           // 0000001DF3A8: 7E723992
	v_add3_u32 v17, v17, v27, 0x7fff                           // 0000001DF3AC: D6550011 03FE3711 00007FFF
	s_clause 0x5                                               // 0000001DF3B8: BF850005
	global_store_d16_hi_b16 v[6:7], v26, off                   // 0000001DF3BC: DC960000 007C1A06
	global_store_d16_hi_b16 v[14:15], v25, off                 // 0000001DF3C4: DC960000 007C190E
	global_store_d16_hi_b16 v[22:23], v28, off                 // 0000001DF3CC: DC960000 007C1C16
	global_store_d16_hi_b16 v[36:37], v29, off                 // 0000001DF3D4: DC960000 007C1D24
	global_store_d16_hi_b16 v[34:35], v16, off offset:32       // 0000001DF3DC: DC960020 007C1022
	global_store_d16_hi_b16 v[38:39], v17, off offset:32       // 0000001DF3E4: DC960020 007C1126
	v_cvt_i32_f32_e32 v25, v111                                // 0000001DF3EC: 7E32116F
	v_div_scale_f32 v16, s0, v21, v66, v21                     // 0000001DF3F0: D6FC0010 04568515
	v_sub_f32_e32 v17, v85, v113                               // 0000001DF3F8: 0822E355
	v_fma_f32 v59, 0xbfb8aa3b, v49, -v56                       // 0000001DF3FC: D613003B 84E262FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DF408: BF870214
	.long 0xd71c0019                                           // 0000001DF40C: D71C0019
	v_cndmask_b32_e32 v1, v84, v25, vcc_lo                     // 0000001DF410: 02023354
	v_dual_mul_f32 v122, v95, v107 :: v_dual_mul_f32 v27, v16, v108// 0000001DF414: C8C6D75F 7A1AD910
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DF41C: BF870214
	v_add_f32_e32 v17, v17, v112                               // 0000001DF420: 0622E111
	v_fmac_f32_e32 v59, 0xb2a5705f, v49                        // 0000001DF424: 567662FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DF42C: BF870214
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000001DF430: 02323280
	v_fma_f32 v26, -v94, v122, v95                             // 0000001DF434: D613001A 257EF55E
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v69                  // 0000001DF43C: 7C368AFF C2B17218
	v_exp_f32_e32 v17, v17                                     // 0000001DF444: 7E224B11
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001DF448: BF8701C2
	v_fmac_f32_e32 v122, v26, v107                             // 0000001DF44C: 56F4D71A
	v_fma_f32 v26, -v96, v27, v16                              // 0000001DF450: D613001A 24423760
	v_cndmask_b32_e32 v25, 0x7f800000, v25, vcc_lo             // 0000001DF458: 023232FF 7F800000
	s_mov_b32 vcc_lo, s9                                       // 0000001DF460: BEEA0009
	v_fma_f32 v29, -v94, v122, v95                             // 0000001DF464: D613001D 257EF55E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001DF46C: BF870233
	v_fmac_f32_e32 v27, v26, v108                              // 0000001DF470: 5636D91A
	v_cvt_i32_f32_e32 v26, v113                                // 0000001DF474: 7E341171
	v_add_f32_e32 v25, 1.0, v25                                // 0000001DF478: 063232F2
	v_div_fmas_f32 v29, v29, v107, v122                        // 0000001DF47C: D637001D 05EAD71D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v68                  // 0000001DF484: 7C3C88FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DF48C: BF870224
	.long 0xd71c0011                                           // 0000001DF490: D71C0011
	v_cndmask_b32_e32 v1, v17, v26, vcc_lo                     // 0000001DF494: 02023511
	v_fma_f32 v16, -v96, v27, v16                              // 0000001DF498: D6130010 24423760
	v_div_fixup_f32 v20, v29, v67, v20                         // 0000001DF4A0: D6270014 0452871D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001DF4A8: BF8701A3
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000001DF4AC: 02222280
	s_mov_b32 vcc_lo, s0                                       // 0000001DF4B0: BEEA0000
	v_div_fmas_f32 v16, v16, v108, v27                         // 0000001DF4B4: D6370010 046ED910
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v68                  // 0000001DF4BC: 7C3688FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DF4C4: BF8700A2
	v_div_fixup_f32 v16, v16, v66, v21                         // 0000001DF4C8: D6270010 04568510
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 0000001DF4D0: 022222FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000001DF4D8: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DF4DC: BF870091
	v_div_scale_f32 v27, null, v17, v17, v9                    // 0000001DF4E0: D6FC7C1B 04262311
	v_rcp_f32_e32 v47, v27                                     // 0000001DF4E8: 7E5E551B
	v_mul_f32_e32 v8, v8, v30                                  // 0000001DF4EC: 10103D08
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DF4F0: BF870091
	v_div_scale_f32 v26, null, v25, v25, v8                    // 0000001DF4F4: D6FC7C1A 04223319
	v_rcp_f32_e32 v21, v26                                     // 0000001DF4FC: 7E2A551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001DF500: BF8701B5
	v_fma_f32 v46, -v26, v21, 1.0                              // 0000001DF504: D613002E 23CA2B1A
	v_and_b32_e32 v24, 1, v54                                  // 0000001DF50C: 36306C81
	.long 0x7e6c3990                                           // 0000001DF510: 7E6C3990
	v_fmac_f32_e32 v21, v46, v21                               // 0000001DF514: 562A2B2E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DF518: BF8700A3
	v_add3_u32 v19, v19, v24, 0x7fff                           // 0000001DF51C: D6550013 03FE3113 00007FFF
	v_lshlrev_b32_e32 v24, 16, v62                             // 0000001DF528: 30307C90
	v_mul_f32_e32 v29, 0xbfb8aa3b, v24                         // 0000001DF52C: 103A30FF BFB8AA3B
	.long 0xd41e0001                                           // 0000001DF534: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v24, vcc_lo              // 0000001DF538: 020230FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001DF540: BF870242
	v_rndne_f32_e32 v55, v29                                   // 0000001DF544: 7E6E471D
	v_and_b32_e32 v28, 1, v57                                  // 0000001DF548: 36387281
	v_fma_f32 v57, -v27, v47, 1.0                              // 0000001DF54C: D6130039 23CA5F1B
	v_fma_f32 v53, 0xbfb8aa3b, v24, -v29                       // 0000001DF554: D6130035 847630FF BFB8AA3B
	v_sub_f32_e32 v29, v29, v55                                // 0000001DF560: 083A6F1D
	v_cvt_i32_f32_e32 v55, v55                                 // 0000001DF564: 7E6E1137
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001DF568: BF870004
	v_fmac_f32_e32 v47, v57, v47                               // 0000001DF56C: 565E5F39
	v_div_scale_f32 v46, vcc_lo, v8, v25, v8                   // 0000001DF570: D6FC6A2E 04223308
	v_fmac_f32_e32 v53, 0xb2a5705f, v24                        // 0000001DF578: 566A30FF B2A5705F
	v_add3_u32 v18, v18, v28, 0x7fff                           // 0000001DF580: D6550012 03FE3912 00007FFF
	.long 0x7e383994                                           // 0000001DF58C: 7E383994
	.long 0x7f3839b6                                           // 0000001DF590: 7F3839B6
	v_mul_f32_e32 v58, v46, v21                                // 0000001DF594: 10742B2E
	v_add_f32_e32 v29, v29, v53                                // 0000001DF598: 063A6B1D
	v_div_scale_f32 v53, s0, v9, v17, v9                       // 0000001DF59C: D6FC0035 04262309
	v_and_b32_e32 v48, 1, v54                                  // 0000001DF5A4: 36606C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DF5A8: BF870214
	v_fma_f32 v57, -v26, v58, v46                              // 0000001DF5AC: D6130039 24BA751A
	v_exp_f32_e32 v29, v29                                     // 0000001DF5B4: 7E3A4B1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DF5B8: BF870193
	v_mul_f32_e32 v61, v53, v47                                // 0000001DF5BC: 107A5F35
	v_add3_u32 v16, v16, v48, 0x7fff                           // 0000001DF5C0: D6550010 03FE6110 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DF5CC: BF870193
	v_fmac_f32_e32 v58, v57, v21                               // 0000001DF5D0: 56742B39
	v_fma_f32 v57, -v27, v61, v53                              // 0000001DF5D4: D6130039 24D67B1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001DF5DC: BF870292
	v_fma_f32 v26, -v26, v58, v46                              // 0000001DF5E0: D613001A 24BA751A
	.long 0xd71c001d                                           // 0000001DF5E8: D71C001D
	v_cndmask_b32_e32 v1, v29, v55, vcc_lo                     // 0000001DF5EC: 02026F1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DF5F0: BF870223
	v_fmac_f32_e32 v61, v57, v47                               // 0000001DF5F4: 567A5F39
	v_rndne_f32_e32 v60, v56                                   // 0000001DF5F8: 7E784738
	v_div_fmas_f32 v21, v26, v21, v58                          // 0000001DF5FC: D6370015 04EA2B1A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DF604: BF870224
	v_cndmask_b32_e64 v29, 0, v29, s1                          // 0000001DF608: D501001D 00063A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000001DF610: 7C3630FF C2B17218
	v_sub_f32_e32 v56, v56, v60                                // 0000001DF618: 08707938
	v_cvt_i32_f32_e32 v46, v60                                 // 0000001DF61C: 7E5C113C
	v_div_fixup_f32 v8, v21, v25, v8                           // 0000001DF620: D6270008 04223315
	.long 0x7f3239b6                                           // 0000001DF628: 7F3239B6
	v_cndmask_b32_e32 v24, 0x7f800000, v29, vcc_lo             // 0000001DF62C: 02303AFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001DF634: 7C3C62FF 42CE8ED0
	v_fma_f32 v27, -v27, v61, v53                              // 0000001DF63C: D613001B 24D67B1B
	.long 0x7e323988                                           // 0000001DF644: 7E323988
	v_add_f32_e32 v56, v56, v59                                // 0000001DF648: 06707738
	v_lshlrev_b32_e32 v29, 16, v51                             // 0000001DF64C: 303A6690
	v_and_b32_e32 v28, 1, v28                                  // 0000001DF650: 36383881
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DF654: BF870214
	v_and_b32_e32 v25, 1, v25                                  // 0000001DF658: 36323281
	v_exp_f32_e32 v48, v56                                     // 0000001DF65C: 7E604B38
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001DF660: BF870291
	v_add3_u32 v8, v8, v25, 0x7fff                             // 0000001DF664: D6550008 03FE3308 00007FFF
	.long 0xd71c001a                                           // 0000001DF670: D71C001A
	v_cndmask_b32_e32 v1, v48, v46, vcc_lo                     // 0000001DF674: 02025D30
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001DF678: BF870001
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000001DF67C: 02343480
	s_mov_b32 vcc_lo, s0                                       // 0000001DF680: BEEA0000
	v_div_fmas_f32 v27, v27, v47, v61                          // 0000001DF684: D637001B 04F65F1B
	v_mul_f32_e32 v47, 0xbfb8aa3b, v29                         // 0000001DF68C: 105E3AFF BFB8AA3B
	v_add3_u32 v20, v20, v28, 0x7fff                           // 0000001DF694: D6550014 03FE3914 00007FFF
	s_clause 0x3                                               // 0000001DF6A0: BF850003
	global_store_d16_hi_b16 v[6:7], v18, off offset:32         // 0000001DF6A4: DC960020 007C1206
	global_store_d16_hi_b16 v[14:15], v19, off offset:32       // 0000001DF6AC: DC960020 007C130E
	global_store_d16_hi_b16 v[22:23], v20, off offset:32       // 0000001DF6B4: DC960020 007C1416
	global_store_d16_hi_b16 v[36:37], v16, off offset:32       // 0000001DF6BC: DC960020 007C1024
	v_div_fixup_f32 v9, v27, v17, v9                           // 0000001DF6C4: D6270009 0426231B
	v_fma_f32 v18, 0xbfb8aa3b, v29, -v47                       // 0000001DF6CC: D6130012 84BE3AFF BFB8AA3B
	v_rndne_f32_e32 v19, v47                                   // 0000001DF6D8: 7E26472F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001DF6DC: 7C3662FF C2B17218
	global_store_d16_hi_b16 v[34:35], v8, off offset:64        // 0000001DF6E4: DC960040 007C0822
	.long 0x7e6c3989                                           // 0000001DF6EC: 7E6C3989
	v_dual_fmac_f32 v18, 0xb2a5705f, v29 :: v_dual_sub_f32 v25, v47, v19// 0000001DF6F0: C80A3AFF 1218272F B2A5705F
	v_add_f32_e32 v24, 1.0, v24                                // 0000001DF6FC: 063030F2
	v_cvt_i32_f32_e32 v19, v19                                 // 0000001DF700: 7E261113
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DF704: BF870214
	v_and_b32_e32 v28, 1, v54                                  // 0000001DF708: 36386C81
	v_add_f32_e32 v18, v25, v18                                // 0000001DF70C: 06242519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DF710: BF870194
	v_div_scale_f32 v17, null, v24, v24, v10                   // 0000001DF714: D6FC7C11 042A3118
	v_add3_u32 v9, v9, v28, 0x7fff                             // 0000001DF71C: D6550009 03FE3909 00007FFF
	v_lshlrev_b32_e32 v28, 16, v72                             // 0000001DF728: 30389090
	global_store_d16_hi_b16 v[38:39], v9, off offset:64        // 0000001DF72C: DC960040 007C0926
	v_mul_f32_e32 v25, 0xbfb8aa3b, v28                         // 0000001DF734: 103238FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001DF73C: BF8701B1
	v_rndne_f32_e32 v51, v25                                   // 0000001DF740: 7E664719
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 0000001DF744: 023434FF 7F800000
	v_fma_f32 v49, 0xbfb8aa3b, v28, -v25                       // 0000001DF74C: D6130031 846638FF BFB8AA3B
	v_sub_f32_e32 v25, v25, v51                                // 0000001DF758: 08326719
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001DF75C: BF8701A3
	v_add_f32_e32 v21, 1.0, v26                                // 0000001DF760: 062A34F2
	v_rcp_f32_e32 v26, v17                                     // 0000001DF764: 7E345511
	v_fmac_f32_e32 v49, 0xb2a5705f, v28                        // 0000001DF768: 566238FF B2A5705F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DF770: BF870092
	v_div_scale_f32 v27, null, v21, v21, v11                   // 0000001DF774: D6FC7C1B 042E2B15
	v_rcp_f32_e32 v46, v27                                     // 0000001DF77C: 7E5C551B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DF780: BF870096
	v_fma_f32 v16, -v17, v26, 1.0                              // 0000001DF784: D6130010 23CA3511
	v_fmac_f32_e32 v26, v16, v26                               // 0000001DF78C: 56343510
	v_div_scale_f32 v16, vcc_lo, v10, v24, v10                 // 0000001DF790: D6FC6A10 042A310A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DF798: BF870115
	v_fma_f32 v20, -v27, v46, 1.0                              // 0000001DF79C: D6130014 23CA5D1B
	v_mul_f32_e32 v47, v16, v26                                // 0000001DF7A4: 105E3510
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001DF7A8: BF8701A2
	v_fmac_f32_e32 v46, v20, v46                               // 0000001DF7AC: 565C5D14
	v_div_scale_f32 v20, s0, v11, v21, v11                     // 0000001DF7B0: D6FC0014 042E2B0B
	v_fma_f32 v8, -v17, v47, v16                               // 0000001DF7B8: D6130008 24425F11
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DF7C0: BF870091
	v_fmac_f32_e32 v47, v8, v26                                // 0000001DF7C4: 565E3508
	v_fma_f32 v9, -v17, v47, v16                               // 0000001DF7C8: D6130009 24425F11
	v_add_f32_e32 v16, v25, v49                                // 0000001DF7D0: 06206319
	.long 0x7f3239b6                                           // 0000001DF7D4: 7F3239B6
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DF7D8: BF870123
	v_div_fmas_f32 v9, v9, v26, v47                            // 0000001DF7DC: D6370009 04BE3509
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001DF7E4: 7C3C3AFF 42CE8ED0
	v_div_fixup_f32 v9, v9, v24, v10                           // 0000001DF7EC: D6270009 042A3109
	v_lshlrev_b32_e32 v24, 16, v52                             // 0000001DF7F4: 30306890
	v_mul_f32_e32 v48, v20, v46                                // 0000001DF7F8: 10605D14
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DF7FC: BF870113
	.long 0x7e323989                                           // 0000001DF800: 7E323989
	v_fma_f32 v8, -v27, v48, v20                               // 0000001DF804: D6130008 2452611B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DF80C: BF870091
	v_dual_fmac_f32 v48, v8, v46 :: v_dual_and_b32 v25, 1, v25 // 0000001DF810: C8245D08 30183281
	v_add3_u32 v9, v9, v25, 0x7fff                             // 0000001DF818: D6550009 03FE3309 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 0000001DF824: BF8702B2
	v_fma_f32 v17, -v27, v48, v20                              // 0000001DF828: D6130011 2452611B
	v_mul_f32_e32 v27, 0xbfb8aa3b, v24                         // 0000001DF830: 103630FF BFB8AA3B
	v_exp_f32_e32 v18, v18                                     // 0000001DF838: 7E244B12
	.long 0xd71c0008                                           // 0000001DF83C: D71C0008
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000001DF840: 02022712
	v_cvt_i32_f32_e32 v18, v51                                 // 0000001DF844: 7E241133
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001DF848: BF870002
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo                        // 0000001DF84C: 02101080
	s_mov_b32 vcc_lo, s0                                       // 0000001DF850: BEEA0000
	v_div_fmas_f32 v17, v17, v46, v48                          // 0000001DF854: D6370011 04C25D11
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001DF85C: 7C363AFF C2B17218
	v_fma_f32 v29, 0xbfb8aa3b, v24, -v27                       // 0000001DF864: D613001D 846E30FF BFB8AA3B
	v_rndne_f32_e32 v46, v27                                   // 0000001DF870: 7E5C471B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DF874: BF870224
	v_div_fixup_f32 v10, v17, v21, v11                         // 0000001DF878: D627000A 042E2B11
	v_cndmask_b32_e32 v8, 0x7f800000, v8, vcc_lo               // 0000001DF880: 021010FF 7F800000
	v_fmac_f32_e32 v29, 0xb2a5705f, v24                        // 0000001DF888: 563A30FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DF890: BF870214
	v_dual_sub_f32 v27, v27, v46 :: v_dual_mul_f32 v12, v12, v40// 0000001DF894: C9465D1B 1B0C510C
	.long 0x7e6c398a                                           // 0000001DF89C: 7E6C398A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DF8A0: BF870224
	v_add_f32_e32 v8, 1.0, v8                                  // 0000001DF8A4: 061010F2
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v28                  // 0000001DF8A8: 7C3C38FF 42CE8ED0
	v_add_f32_e32 v27, v27, v29                                // 0000001DF8B0: 06363B1B
	v_cvt_i32_f32_e32 v46, v46                                 // 0000001DF8B4: 7E5C112E
	v_and_b32_e32 v47, 1, v54                                  // 0000001DF8B8: 365E6C81
	v_exp_f32_e32 v16, v16                                     // 0000001DF8BC: 7E204B10
	v_div_scale_f32 v17, null, v8, v8, v12                     // 0000001DF8C0: D6FC7C11 04321108
	v_exp_f32_e32 v27, v27                                     // 0000001DF8C8: 7E364B1B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DF8CC: BF870112
	v_add3_u32 v10, v10, v47, 0x7fff                           // 0000001DF8D0: D655000A 03FE5F0A 00007FFF
	v_rcp_f32_e32 v19, v17                                     // 0000001DF8DC: 7E265511
	s_delay_alu instid0(TRANS32_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 0000001DF8E0: BF870327
	.long 0xd71c000b                                           // 0000001DF8E4: D71C000B
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 0000001DF8E8: 02022510
	v_lshlrev_b32_e32 v16, 16, v50                             // 0000001DF8EC: 30206490
	.long 0xd71c001b                                           // 0000001DF8F0: D71C001B
	v_cndmask_b32_e32 v1, v27, v46, vcc_lo                     // 0000001DF8F4: 02025D1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001DF8F8: BF8702A3
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 0000001DF8FC: 02161680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v28                  // 0000001DF900: 7C3638FF C2B17218
	v_fma_f32 v28, -v17, v19, 1.0                              // 0000001DF908: D613001C 23CA2711
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DF910: BF870113
	v_cndmask_b32_e32 v11, 0x7f800000, v11, vcc_lo             // 0000001DF914: 021616FF 7F800000
	v_fmac_f32_e32 v19, v28, v19                               // 0000001DF91C: 5626271C
	v_div_scale_f32 v28, vcc_lo, v12, v8, v12                  // 0000001DF920: D6FC6A1C 0432110C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DF928: BF870113
	v_add_f32_e32 v11, 1.0, v11                                // 0000001DF92C: 061616F2
	v_dual_mul_f32 v29, v28, v19 :: v_dual_mul_f32 v18, 0xbfb8aa3b, v16// 0000001DF930: C8C6271C 1D1220FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DF93C: BF870112
	v_div_scale_f32 v26, null, v11, v11, v13                   // 0000001DF940: D6FC7C1A 0436170B
	v_fma_f32 v20, 0xbfb8aa3b, v16, -v18                       // 0000001DF948: D6130014 844A20FF BFB8AA3B
	v_rndne_f32_e32 v21, v18                                   // 0000001DF954: 7E2A4712
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DF958: BF870112
	v_fmac_f32_e32 v20, 0xb2a5705f, v16                        // 0000001DF95C: 562820FF B2A5705F
	v_sub_f32_e32 v18, v18, v21                                // 0000001DF964: 08242B12
	v_cvt_i32_f32_e32 v21, v21                                 // 0000001DF968: 7E2A1115
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001DF96C: BF8700A2
	v_add_f32_e32 v18, v18, v20                                // 0000001DF970: 06242912
	v_rcp_f32_e32 v20, v26                                     // 0000001DF974: 7E28551A
	v_exp_f32_e32 v18, v18                                     // 0000001DF978: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001DF97C: BF870296
	v_fma_f32 v48, -v26, v20, 1.0                              // 0000001DF980: D6130030 23CA291A
	.long 0xd71c0012                                           // 0000001DF988: D71C0012
	v_cndmask_b32_e32 v1, v18, v21, vcc_lo                     // 0000001DF98C: 02022B12
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001DF990: BF870132
	v_fmac_f32_e32 v20, v48, v20                               // 0000001DF994: 56282930
	v_div_scale_f32 v21, s0, v13, v11, v13                     // 0000001DF998: D6FC0015 0436170D
	v_fma_f32 v48, -v17, v29, v28                              // 0000001DF9A0: D6130030 24723B11
	v_mul_f32_e32 v49, v21, v20                                // 0000001DF9A8: 10622915
	.long 0xd41e0001                                           // 0000001DF9AC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v16, vcc_lo              // 0000001DF9B0: 020220FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DF9B8: BF870113
	v_fmac_f32_e32 v29, v48, v19                               // 0000001DF9BC: 563A2730
	v_cndmask_b32_e64 v18, 0, v18, s1                          // 0000001DF9C0: D5010012 00062480
	.long 0xd41b0001                                           // 0000001DF9C8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v16, vcc_lo              // 0000001DF9CC: 020220FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DF9D4: BF870113
	v_fma_f32 v17, -v17, v29, v28                              // 0000001DF9D8: D6130011 24723B11
	v_cndmask_b32_e64 v16, 0x7f800000, v18, s1                 // 0000001DF9E0: D5010010 000624FF 7F800000
	v_fma_f32 v18, -v26, v49, v21                              // 0000001DF9EC: D6130012 2456631A
	v_mul_f32_e32 v0, v0, v30                                  // 0000001DF9F4: 10003D00
	.long 0xd41e0001                                           // 0000001DF9F8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v24, vcc_lo              // 0000001DF9FC: 020230FF 42CE8ED0
	v_div_fmas_f32 v17, v17, v19, v29                          // 0000001DFA04: D6370011 04762711
	v_add_f32_e32 v16, 1.0, v16                                // 0000001DFA0C: 062020F2
	v_fmac_f32_e32 v49, v18, v20                               // 0000001DFA10: 56622912
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000001DFA14: 7C3630FF C2B17218
	v_cndmask_b32_e64 v18, 0, v27, s1                          // 0000001DFA1C: D5010012 00063680
	v_div_fixup_f32 v8, v17, v8, v12                           // 0000001DFA24: D6270008 04321111
	v_div_scale_f32 v27, null, v16, v16, v0                    // 0000001DFA2C: D6FC7C1B 04022110
	v_fma_f32 v19, -v26, v49, v21                              // 0000001DFA34: D6130013 2456631A
	v_lshlrev_b32_e32 v17, 16, v42                             // 0000001DFA3C: 30225490
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001DFA40: 022424FF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001DFA48: BEEA0000
	v_rcp_f32_e32 v21, v27                                     // 0000001DFA4C: 7E2A551B
	v_div_fmas_f32 v19, v19, v20, v49                          // 0000001DFA50: D6370013 04C62913
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 0000001DFA58: 102822FF BFB8AA3B
	v_mul_f32_e32 v42, 0xbfb8aa3b, v32                         // 0000001DFA60: 105440FF BFB8AA3B
	.long 0x7e303988                                           // 0000001DFA68: 7E303988
	.long 0x7f3039b6                                           // 0000001DFA6C: 7F3039B6
	v_div_fixup_f32 v11, v19, v11, v13                         // 0000001DFA70: D627000B 04361713
	v_fma_f32 v28, 0xbfb8aa3b, v17, -v20                       // 0000001DFA78: D613001C 845222FF BFB8AA3B
	v_rndne_f32_e32 v29, v20                                   // 0000001DFA84: 7E3A4714
	v_fma_f32 v43, 0xbfb8aa3b, v32, -v42                       // 0000001DFA88: D613002B 84AA40FF BFB8AA3B
	v_fma_f32 v13, -v27, v21, 1.0                              // 0000001DFA94: D613000D 23CA2B1B
	.long 0x7e6c398b                                           // 0000001DFA9C: 7E6C398B
	v_fmac_f32_e32 v28, 0xb2a5705f, v17                        // 0000001DFAA0: 563822FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DFAA8: BF870214
	v_dual_sub_f32 v20, v20, v29 :: v_dual_fmac_f32 v43, 0xb2a5705f, v32// 0000001DFAAC: C9403B14 142A40FF B2A5705F
	v_fmac_f32_e32 v21, v13, v21                               // 0000001DFAB8: 562A2B0D
	v_div_scale_f32 v13, vcc_lo, v0, v16, v0                   // 0000001DFABC: D6FC6A0D 04022100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DFAC4: BF870091
	v_dual_add_f32 v20, v20, v28 :: v_dual_mul_f32 v25, v13, v21// 0000001DFAC8: C9063914 14182B0D
	v_exp_f32_e32 v20, v20                                     // 0000001DFAD0: 7E284B14
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DFAD4: BF870091
	v_fma_f32 v30, -v27, v25, v13                              // 0000001DFAD8: D613001E 2436331B
	v_fmac_f32_e32 v25, v30, v21                               // 0000001DFAE0: 56322B1E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DFAE4: BF870091
	v_fma_f32 v13, -v27, v25, v13                              // 0000001DFAE8: D613000D 2436331B
	v_div_fmas_f32 v13, v13, v21, v25                          // 0000001DFAF0: D637000D 04662B0D
	v_cvt_i32_f32_e32 v25, v29                                 // 0000001DFAF8: 7E32111D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000001DFAFC: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001DFB04: BF870003
	v_div_fixup_f32 v0, v13, v16, v0                           // 0000001DFB08: D6270000 0402210D
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001DFB10: BF870185
	.long 0xd71c0014                                           // 0000001DFB14: D71C0014
	v_cndmask_b32_e32 v1, v20, v25, vcc_lo                     // 0000001DFB18: 02023314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001DFB1C: BF870121
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001DFB20: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000001DFB24: 7C3622FF C2B17218
	v_cndmask_b32_e32 v17, 0x7f800000, v20, vcc_lo             // 0000001DFB2C: 022228FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DFB34: BF870091
	v_dual_add_f32 v17, 1.0, v17 :: v_dual_lshlrev_b32 v28, 16, v44// 0000001DFB38: C92222F2 111C5890
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_mul_f32 v27, 0xbfb8aa3b, v28// 0000001DFB40: C90624F2 121A38FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v28                  // 0000001DFB4C: 7C3C38FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DFB54: BF870192
	v_div_scale_f32 v12, null, v18, v18, v1                    // 0000001DFB58: D6FC7C0C 04062512
	v_fma_f32 v29, 0xbfb8aa3b, v28, -v27                       // 0000001DFB60: D613001D 846E38FF BFB8AA3B
	v_rndne_f32_e32 v30, v27                                   // 0000001DFB6C: 7E3C471B
	v_and_b32_e32 v26, 1, v54                                  // 0000001DFB70: 36346C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DFB74: BF870194
	v_rcp_f32_e32 v19, v12                                     // 0000001DFB78: 7E26550C
	v_fmac_f32_e32 v29, 0xb2a5705f, v28                        // 0000001DFB7C: 563A38FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DFB84: BF870193
	v_sub_f32_e32 v25, v27, v30                                // 0000001DFB88: 08323D1B
	v_add3_u32 v11, v11, v26, 0x7fff                           // 0000001DFB8C: D655000B 03FE350B 00007FFF
	v_div_scale_f32 v26, s0, v1, v18, v1                       // 0000001DFB98: D6FC001A 04062501
	v_cvt_i32_f32_e32 v30, v30                                 // 0000001DFBA0: 7E3C111E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001DFBA4: BF870294
	v_add_f32_e32 v25, v25, v29                                // 0000001DFBA8: 06323B19
	v_fma_f32 v31, -v12, v19, 1.0                              // 0000001DFBAC: D613001F 23CA270C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DFBB4: BF870092
	v_exp_f32_e32 v25, v25                                     // 0000001DFBB8: 7E324B19
	v_fmac_f32_e32 v19, v31, v19                               // 0000001DFBBC: 5626271F
	s_waitcnt vmcnt(0)                                         // 0000001DFBC0: BF8903F7
	v_lshlrev_b32_e32 v31, 16, v45                             // 0000001DFBC4: 303E5A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DFBC8: BF870091
	v_dual_mul_f32 v27, 0xbfb8aa3b, v31 :: v_dual_and_b32 v24, 1, v24// 0000001DFBCC: C8E43EFF 1B183081 BFB8AA3B
	v_add3_u32 v8, v8, v24, 0x7fff                             // 0000001DFBD8: D6550008 03FE3108 00007FFF
	s_clause 0x3                                               // 0000001DFBE4: BF850003
	global_store_d16_hi_b16 v[6:7], v9, off offset:64          // 0000001DFBE8: DC960040 007C0906
	global_store_d16_hi_b16 v[14:15], v10, off offset:64       // 0000001DFBF0: DC960040 007C0A0E
	global_store_d16_hi_b16 v[22:23], v8, off offset:64        // 0000001DFBF8: DC960040 007C0816
	global_store_d16_hi_b16 v[36:37], v11, off offset:64       // 0000001DFC00: DC960040 007C0B24
	v_rndne_f32_e32 v20, v27                                   // 0000001DFC08: 7E28471B
	v_mul_f32_e32 v24, v26, v19                                // 0000001DFC0C: 1030271A
	v_fma_f32 v29, 0xbfb8aa3b, v31, -v27                       // 0000001DFC10: D613001D 846E3EFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DFC1C: BF870193
	v_sub_f32_e32 v27, v27, v20                                // 0000001DFC20: 0836291B
	v_fma_f32 v21, -v12, v24, v26                              // 0000001DFC24: D6130015 246A310C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001DFC2C: BF8701A3
	v_fmac_f32_e32 v29, 0xb2a5705f, v31                        // 0000001DFC30: 563A3EFF B2A5705F
	v_cvt_i32_f32_e32 v20, v20                                 // 0000001DFC38: 7E281114
	v_fmac_f32_e32 v24, v21, v19                               // 0000001DFC3C: 56302715
	.long 0xd71c0015                                           // 0000001DFC40: D71C0015
	v_cndmask_b32_e32 v1, v25, v30, vcc_lo                     // 0000001DFC44: 02023D19
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001DFC48: BF870224
	v_add_f32_e32 v27, v27, v29                                // 0000001DFC4C: 06363B1B
	v_div_scale_f32 v25, null, v17, v17, v2                    // 0000001DFC50: D6FC7C19 040A2311
	v_fma_f32 v12, -v12, v24, v26                              // 0000001DFC58: D613000C 246A310C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000001DFC60: BF870154
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 0000001DFC64: 022A2A80
	v_rndne_f32_e32 v44, v42                                   // 0000001DFC68: 7E58472A
	v_exp_f32_e32 v27, v27                                     // 0000001DFC6C: 7E364B1B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v28                  // 0000001DFC70: 7C3638FF C2B17218
	v_rcp_f32_e32 v30, v25                                     // 0000001DFC78: 7E3C5519
	v_sub_f32_e32 v42, v42, v44                                // 0000001DFC7C: 0854592A
	v_cvt_i32_f32_e32 v26, v44                                 // 0000001DFC80: 7E34112C
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001DFC84: 022A2AFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v31                  // 0000001DFC8C: 7C3C3EFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001DFC94: BF870314
	v_add_f32_e32 v29, v42, v43                                // 0000001DFC98: 063A572A
	.long 0xd71c0014                                           // 0000001DFC9C: D71C0014
	v_cndmask_b32_e32 v1, v27, v20, vcc_lo                     // 0000001DFCA0: 0202291B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001DFCA4: BF870294
	v_add_f32_e32 v21, 1.0, v21                                // 0000001DFCA8: 062A2AF2
	v_fma_f32 v27, -v25, v30, 1.0                              // 0000001DFCAC: D613001B 23CA3D19
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DFCB4: BF870194
	v_exp_f32_e32 v29, v29                                     // 0000001DFCB8: 7E3A4B1D
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001DFCBC: 02282880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 0000001DFCC0: BF8702B3
	v_div_scale_f32 v28, null, v21, v21, v3                    // 0000001DFCC4: D6FC7C1C 040E2B15
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 0000001DFCCC: 7C3C40FF 42CE8ED0
	v_fmac_f32_e32 v30, v27, v30                               // 0000001DFCD4: 563C3D1B
	.long 0xd71c001a                                           // 0000001DFCD8: D71C001A
	v_cndmask_b32_e32 v1, v29, v26, vcc_lo                     // 0000001DFCDC: 0202351D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DFCE0: BF870094
	v_rcp_f32_e32 v29, v28                                     // 0000001DFCE4: 7E3A551C
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000001DFCE8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v31                  // 0000001DFCEC: 7C363EFF C2B17218
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001DFCF4: BF870135
	v_fma_f32 v27, -v28, v29, 1.0                              // 0000001DFCF8: D613001B 23CA3B1C
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 0000001DFD00: 022828FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 0000001DFD08: 7C3640FF C2B17218
	v_dual_fmac_f32 v29, v27, v29 :: v_dual_add_f32 v20, 1.0, v20// 0000001DFD10: C8083B1B 1D1428F2
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 0000001DFD18: 023434FF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001DFD20: BEEA0000
	v_div_scale_f32 v10, s0, v3, v21, v3                       // 0000001DFD24: D6FC000A 040E2B03
	v_mul_f32_e32 v4, v4, v40                                  // 0000001DFD2C: 10085104
	v_div_fmas_f32 v12, v12, v19, v24                          // 0000001DFD30: D637000C 0462270C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DFD38: BF870193
	v_mul_f32_e32 v13, v10, v29                                // 0000001DFD3C: 101A3B0A
	v_div_scale_f32 v19, null, v20, v20, v4                    // 0000001DFD40: D6FC7C13 04122914
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001DFD48: BF870233
	v_div_fixup_f32 v1, v12, v18, v1                           // 0000001DFD4C: D6270001 0406250C
	.long 0x7e243980                                           // 0000001DFD54: 7E243980
	.long 0x7f2439b6                                           // 0000001DFD58: 7F2439B6
	v_rcp_f32_e32 v31, v19                                     // 0000001DFD5C: 7E3E5513
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001DFD60: BF870293
	.long 0x7e6c3981                                           // 0000001DFD64: 7E6C3981
	v_fma_f32 v11, -v19, v31, 1.0                              // 0000001DFD68: D613000B 23CA3F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001DFD70: BF8701B1
	v_dual_fmac_f32 v31, v11, v31 :: v_dual_add_f32 v24, 1.0, v26// 0000001DFD74: C8083F0B 1F1834F2
	v_div_scale_f32 v26, vcc_lo, v2, v17, v2                   // 0000001DFD7C: D6FC6A1A 040A2302
	v_div_scale_f32 v11, s1, v4, v20, v4                       // 0000001DFD84: D6FC010B 04122904
	v_div_scale_f32 v32, null, v24, v24, v5                    // 0000001DFD8C: D6FC7C20 04163118
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DFD94: BF870112
	v_dual_mul_f32 v27, v11, v31 :: v_dual_mul_f32 v8, v26, v30// 0000001DFD98: C8C63F0B 1B083D1A
	v_rcp_f32_e32 v9, v32                                      // 0000001DFDA0: 7E125520
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DFDA4: BF870091
	v_fma_f32 v12, -v25, v8, v26                               // 0000001DFDA8: D613000C 246A1119
	v_fmac_f32_e32 v8, v12, v30                                // 0000001DFDB0: 56103D0C
	v_fma_f32 v12, -v28, v13, v10                              // 0000001DFDB4: D613000C 242A1B1C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DFDBC: BF870195
	v_fma_f32 v16, -v32, v9, 1.0                               // 0000001DFDC0: D6130010 23CA1320
	v_fma_f32 v25, -v25, v8, v26                               // 0000001DFDC8: D6130019 246A1119
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DFDD0: BF870193
	v_fmac_f32_e32 v13, v12, v29                               // 0000001DFDD4: 561A3B0C
	v_fmac_f32_e32 v9, v16, v9                                 // 0000001DFDD8: 56121310
	v_div_scale_f32 v16, s2, v5, v24, v5                       // 0000001DFDDC: D6FC0210 04163105
	v_fma_f32 v12, -v19, v27, v11                              // 0000001DFDE4: D613000C 242E3713
	v_div_fmas_f32 v8, v25, v30, v8                            // 0000001DFDEC: D6370008 04223D19
	v_fma_f32 v10, -v28, v13, v10                              // 0000001DFDF4: D613000A 242A1B1C
	s_mov_b32 vcc_lo, s0                                       // 0000001DFDFC: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001DFE00: BF870113
	v_dual_fmac_f32 v27, v12, v31 :: v_dual_and_b32 v12, 1, v54// 0000001DFE04: C8243F0C 1B0C6C81
	v_div_fmas_f32 v10, v10, v29, v13                          // 0000001DFE0C: D637000A 04363B0A
	v_div_fixup_f32 v2, v8, v17, v2                            // 0000001DFE14: D6270002 040A2308
	s_mov_b32 vcc_lo, s1                                       // 0000001DFE1C: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001DFE20: BF870243
	v_fma_f32 v8, -v19, v27, v11                               // 0000001DFE24: D6130008 242E3713
	.long 0x7f1639b6                                           // 0000001DFE2C: 7F1639B6
	v_div_fixup_f32 v3, v10, v21, v3                           // 0000001DFE30: D6270003 040E2B0A
	v_add3_u32 v1, v1, v12, 0x7fff                             // 0000001DFE38: D6550001 03FE1901 00007FFF
	v_div_fmas_f32 v8, v8, v31, v27                            // 0000001DFE44: D6370008 046E3F08
	s_mov_b32 vcc_lo, s2                                       // 0000001DFE4C: BEEA0002
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001DFE50: BF8701A3
	.long 0x7e6c3983                                           // 0000001DFE54: 7E6C3983
	v_mul_f32_e32 v26, v16, v9                                 // 0000001DFE58: 10341310
	v_div_fixup_f32 v4, v8, v20, v4                            // 0000001DFE5C: D6270004 04122908
	.long 0x7e103982                                           // 0000001DFE64: 7E103982
	.long 0x7f1039b6                                           // 0000001DFE68: 7F1039B6
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001DFE6C: BF870214
	v_fma_f32 v25, -v32, v26, v16                              // 0000001DFE70: D6130019 24423520
	.long 0x7e163984                                           // 0000001DFE78: 7E163984
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001DFE7C: BF870193
	v_and_b32_e32 v8, 1, v8                                    // 0000001DFE80: 36101081
	v_fmac_f32_e32 v26, v25, v9                                // 0000001DFE84: 56341319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001DFE88: BF870091
	v_fma_f32 v10, -v32, v26, v16                              // 0000001DFE8C: D613000A 24423520
	v_div_fmas_f32 v9, v10, v9, v26                            // 0000001DFE94: D6370009 046A130A
	v_and_b32_e32 v10, 1, v18                                  // 0000001DFE9C: 36142481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001DFEA0: BF8701A2
	v_div_fixup_f32 v5, v9, v24, v5                            // 0000001DFEA4: D6270005 04163109
	v_and_b32_e32 v9, 1, v54                                   // 0000001DFEAC: 36126C81
	v_add3_u32 v0, v0, v10, 0x7fff                             // 0000001DFEB0: D6550000 03FE1500 00007FFF
	v_and_b32_e32 v10, 1, v11                                  // 0000001DFEBC: 36141681
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001DFEC0: BF870004
	.long 0x7e6c3985                                           // 0000001DFEC4: 7E6C3985
	global_store_d16_hi_b16 v[34:35], v0, off offset:96        // 0000001DFEC8: DC960060 007C0022
	v_add3_u32 v0, v2, v8, 0x7fff                              // 0000001DFED0: D6550000 03FE1102 00007FFF
	v_add3_u32 v2, v3, v9, 0x7fff                              // 0000001DFEDC: D6550002 03FE1303 00007FFF
	v_and_b32_e32 v11, 1, v54                                  // 0000001DFEE8: 36166C81
	v_add3_u32 v3, v4, v10, 0x7fff                             // 0000001DFEEC: D6550003 03FE1504 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001DFEF8: BF870002
	v_add3_u32 v4, v5, v11, 0x7fff                             // 0000001DFEFC: D6550004 03FE1705 00007FFF
	s_clause 0x4                                               // 0000001DFF08: BF850004
	global_store_d16_hi_b16 v[38:39], v1, off offset:96        // 0000001DFF0C: DC960060 007C0126
	global_store_d16_hi_b16 v[6:7], v0, off offset:96          // 0000001DFF14: DC960060 007C0006
	global_store_d16_hi_b16 v[14:15], v2, off offset:96        // 0000001DFF1C: DC960060 007C020E
	global_store_d16_hi_b16 v[22:23], v3, off offset:96        // 0000001DFF24: DC960060 007C0316
	global_store_d16_hi_b16 v[36:37], v4, off offset:96        // 0000001DFF2C: DC960060 007C0424
	s_nop 0                                                    // 0000001DFF34: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001DFF38: BFB60003
	s_endpgm                                                   // 0000001DFF3C: BFB00000
