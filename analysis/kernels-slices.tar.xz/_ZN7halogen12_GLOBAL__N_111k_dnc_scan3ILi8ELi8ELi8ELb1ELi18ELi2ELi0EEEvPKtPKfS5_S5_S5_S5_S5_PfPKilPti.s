00000000000d5000 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000D5000: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000D5004: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000D500C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000D5014: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000D5018: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000D501C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000D5020: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000D5028: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000D502C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000D5030: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000D5034: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000D503C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000D5040: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000D5044: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000D5048: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000D504C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000D5050: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000D5054: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000D5058: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000D505C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000D5064: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000D506C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000D5070: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000D5074: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000D5078: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000D507C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000D5080: 821E191E
	.long 0xd7001f02                                           // 0000000D5084: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000D5088: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000D508C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000D5094: BE9E0080
	s_nop 0                                                    // 0000000D5098: BF800000
	s_nop 0                                                    // 0000000D509C: BF800000
	s_nop 0                                                    // 0000000D50A0: BF800000
	s_nop 0                                                    // 0000000D50A4: BF800000
	s_nop 0                                                    // 0000000D50A8: BF800000
	s_nop 0                                                    // 0000000D50AC: BF800000
	s_nop 0                                                    // 0000000D50B0: BF800000
	s_nop 0                                                    // 0000000D50B4: BF800000
	s_nop 0                                                    // 0000000D50B8: BF800000
	s_nop 0                                                    // 0000000D50BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000D50C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000D50C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D50CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000D50D0: 300C1089
	.long 0xd7006a06                                           // 0000000D50D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000D50D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D50DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000D50E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000D50E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000D50F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000D50F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000D50FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000D5108: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000D510C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000D5110: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000D5118: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000D511C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000D5120: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000D5124: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 0000000D512C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000D5134: 32040084
	s_mov_b32 s0, 0                                            // 0000000D5138: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000D513C: BF89FC07
	s_barrier                                                  // 0000000D5140: BFBD0000
	buffer_gl0_inv                                             // 0000000D5144: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000D514C: BF02801E
	s_cbranch_scc1 12                                          // 0000000D5150: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000D5154: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000D515C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D5164: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 0000000D5168: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000D5170: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000D5174: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000D5178: 916A007E
	s_cbranch_vccz 2                                           // 0000000D517C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2200                                              // 0000000D5180: BFA00898 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23e4>
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000D5184: 304E0A82
	s_add_i32 s0, s30, 63                                      // 0000000D5188: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000D518C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000D5194: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000D5198: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000D519C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000D51A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000000D51A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000000D51AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000D51B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000D51B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000D51B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000D51BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000D51C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000D51C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000000D51C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000D51D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000D51D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000D51DC: B00A0204
	.long 0xd7000b2c                                           // 0000000D51E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000000D51E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000D51E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000000D51EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000000D51F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000D5200: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 0000000D5204: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 0000000D5210: 3816500A
	.long 0xd7000a05                                           // 0000000D5214: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000D5218: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D521C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000D5220: D5207C06 00290001
	.long 0xd7000107                                           // 0000000D5228: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000D522C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D5230: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000D5234: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000D523C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000D5240: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000D5244: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000D524C: 84848E02
	.long 0xd700010b                                           // 0000000D5250: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000D5254: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000D5258: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000D525C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000D5264: 8205050F
	.long 0xd700010d                                           // 0000000D5268: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000D526C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D5270: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000D5274: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000D527C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000D5280: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000D5288: D5207C10 00061880
	.long 0xd7000111                                           // 0000000D5290: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000D5294: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D529C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000D52A0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000D52A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000D52AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000D52B4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000D52BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000D52C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D52C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000D52CC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000D52D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000D52D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000D52E0: D5207C18 00061880
	.long 0xd7000119                                           // 0000000D52E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000D52EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D52F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000D52F8: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000D5300: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000D5304: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 0000000D530C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 0000000D5314: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000D5318: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 0000000D5320: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 0000000D5324: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 0000000D532C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000D5334: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 0000000D533C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 0000000D5344: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 0000000D534C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 0000000D5354: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 0000000D535C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 0000000D5364: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 0000000D536C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 0000000D5374: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 0000000D537C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 0000000D5384: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 0000000D538C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 0000000D5394: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 0000000D539C: BE850080
	s_mov_b32 s6, 0x44800000                                   // 0000000D53A0: BE8600FF 44800000
	s_mov_b32 s7, 0x3a800000                                   // 0000000D53A8: BE8700FF 3A800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000D53B0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000D53B4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000D53BC: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000D53C0: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000D53C4: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000D53C8: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000D53CC: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000D53D0: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000D53D4: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000D53D8: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000D53DC: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000D53E4: BE84206A
	s_cbranch_execz 77                                         // 0000000D53E8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x520>
	v_or_b32_e32 v29, s11, v0                                  // 0000000D53EC: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D53F0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000D53F4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000D53FC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5400: BF870091
	.long 0xd73c001d                                           // 0000000D5404: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000D5408: 02023A82
	.long 0xd700011d                                           // 0000000D540C: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000D5410: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D5414: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000D5418: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000D5420: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D5428: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000D542C: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000D5430: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000D543C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 0000000D5440: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 0000000D544C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000D5450: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000D545C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000D5460: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 0000000D5464: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000D5470: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D5474: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 0000000D5478: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 0000000D5480: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000D5484: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 0000000D548C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000D5494: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 0000000D5498: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D549C: BF870193
	v_exp_f32_e32 v32, v32                                     // 0000000D54A0: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 0000000D54A4: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000D54A8: BF870296
	.long 0xd71c0020                                           // 0000000D54AC: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000D54B0: 02024520
	.long 0xd71c001f                                           // 0000000D54B4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000D54B8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D54BC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000D54C0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000D54C8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000D54CC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000D54D4: D5010020 00064080
	.long 0xd41e0001                                           // 0000000D54DC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000D54E0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D54E8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000D54EC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000D54F8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000D54FC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000D5504: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 0000000D5510: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 0000000D5518: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D5520: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000D5524: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000D552C: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D5530: BF89FC07
	s_barrier                                                  // 0000000D5534: BFBD0000
	buffer_gl0_inv                                             // 0000000D5538: E0AC0000 00000000
	s_branch 15                                                // 0000000D5540: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D5544: 8C7E047E
	.long 0xd700011d                                           // 0000000D5548: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000D554C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D5554: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D5558: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000D5560: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000D5564: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000D5568: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000D556C: BF89FC07
	s_barrier                                                  // 0000000D5570: BFBD0000
	buffer_gl0_inv                                             // 0000000D5574: E0AC0000 00000000
	s_cbranch_scc1 702                                         // 0000000D557C: BFA202BE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000D5580: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 0000000D5588: CA100128 21220126
	s_mov_b32 s13, 0                                           // 0000000D5590: BE8D0080
	s_nop 0                                                    // 0000000D5594: BF800000
	s_nop 0                                                    // 0000000D5598: BF800000
	s_nop 0                                                    // 0000000D559C: BF800000
	s_nop 0                                                    // 0000000D55A0: BF800000
	s_nop 0                                                    // 0000000D55A4: BF800000
	s_nop 0                                                    // 0000000D55A8: BF800000
	s_nop 0                                                    // 0000000D55AC: BF800000
	s_nop 0                                                    // 0000000D55B0: BF800000
	s_nop 0                                                    // 0000000D55B4: BF800000
	s_nop 0                                                    // 0000000D55B8: BF800000
	s_nop 0                                                    // 0000000D55BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000000D55C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000D55C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000D55D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000D55D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D55DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000D55E0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000D55E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000D55EC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000D55F4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000D55F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000000D55FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000D5604: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000D560C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000D5610: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000D5614: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D5618: BF89FC07
	s_barrier                                                  // 0000000D561C: BFBD0000
	buffer_gl0_inv                                             // 0000000D5620: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000D5628: BE842000
	s_cbranch_execz 65477                                      // 0000000D562C: BFA5FFC5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 0000000D5630: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 0000000D5638: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 0000000D5640: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 0000000D5648: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000D5650: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 0000000D5658: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 0000000D5660: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 0000000D5668: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 0000000D5670: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 0000000D5678: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 0000000D5680: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 0000000D5688: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 0000000D5690: D8DCFFEE 50000001
	v_or3_b32 v70, s12, s11, v2                                // 0000000D5698: D6580046 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D56A0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 0000000D56A4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 0000000D56AC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 0000000D56B0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D56B4: BF870091
	.long 0xd7000146                                           // 0000000D56B8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 0000000D56BC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 0000000D56C0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 0000000D56C8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 0000000D56D0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 0000000D56D4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D56DC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 0000000D56E0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 0000000D56E8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 0000000D56EC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 0000000D56F4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 0000000D56FC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 0000000D5704: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 0000000D570C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 0000000D5714: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5718: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 0000000D571C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 0000000D5724: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 0000000D572C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5730: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 0000000D5734: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 0000000D573C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 0000000D5744: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5748: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 0000000D574C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 0000000D5754: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 0000000D575C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D5760: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000D5764: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 0000000D576C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 0000000D5774: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 0000000D577C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 0000000D5784: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 0000000D578C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000D5794: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 0000000D579C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000D57A4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 0000000D57AC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 0000000D57B4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D57B8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 0000000D57BC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 0000000D57C4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D57CC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 0000000D57D0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 0000000D57D8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 0000000D57E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D57E4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 0000000D57E8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 0000000D57F0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 0000000D57F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D57FC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 0000000D5800: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 0000000D5808: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 0000000D5810: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 0000000D5818: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000D5820: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 0000000D5828: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 0000000D5830: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 0000000D5838: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 0000000D5840: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 0000000D5848: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 0000000D5850: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5854: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 0000000D5858: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 0000000D5860: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 0000000D5868: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D586C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000D5870: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000D5878: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000D5880: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5884: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 0000000D5888: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 0000000D5890: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 0000000D5898: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D589C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000D58A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 0000000D58A8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 0000000D58B0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 0000000D58B8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 0000000D58C0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 0000000D58C8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 0000000D58D0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000D58D8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000D58E0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 0000000D58E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000D58F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D58F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000D58F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000D5900: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000D5908: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D590C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 0000000D5910: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 0000000D5918: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 0000000D5920: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5924: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 0000000D5928: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 0000000D5930: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 0000000D5938: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D593C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 0000000D5940: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 0000000D5948: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 0000000D5950: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 0000000D5958: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 0000000D5960: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 0000000D5968: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 0000000D5970: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 0000000D5978: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 0000000D5980: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 0000000D5988: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 0000000D5990: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5994: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000D5998: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000D59A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000D59A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D59AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000D59B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000D59B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000D59C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D59C4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 0000000D59C8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 0000000D59D0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 0000000D59D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D59DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000D59E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 0000000D59E8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 0000000D59F0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 0000000D59F8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 0000000D5A00: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 0000000D5A08: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 0000000D5A10: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000D5A18: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000D5A20: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 0000000D5A28: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000D5A30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5A34: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000D5A38: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000D5A40: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000D5A48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5A4C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000D5A50: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000D5A58: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000D5A60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5A64: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000D5A68: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000D5A70: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000D5A78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D5A7C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000D5A80: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 0000000D5A88: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 0000000D5A90: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 0000000D5A98: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 0000000D5AA0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 0000000D5AA8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 0000000D5AB0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 0000000D5AB8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 0000000D5AC0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 0000000D5AC8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000D5AD0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5AD4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000D5AD8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000D5AE0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000D5AE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5AEC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000D5AF0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000D5AF8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000D5B00: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5B04: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000D5B08: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000D5B10: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000D5B18: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D5B1C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000D5B20: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 0000000D5B28: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 0000000D5B30: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 0000000D5B38: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 0000000D5B40: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 0000000D5B48: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 0000000D5B50: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000D5B58: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000D5B60: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 0000000D5B68: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000D5B70: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5B74: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000D5B78: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000D5B80: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000D5B88: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5B8C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000D5B90: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000D5B98: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000D5BA0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5BA4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000D5BA8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000D5BB0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000D5BB8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D5BBC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000D5BC0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 0000000D5BC8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 0000000D5BD0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 0000000D5BD8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 0000000D5BE0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 0000000D5BE8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 0000000D5BF0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 0000000D5BF8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 0000000D5C00: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 0000000D5C08: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000D5C10: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5C14: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000D5C18: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000D5C20: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000D5C28: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5C2C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000D5C30: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000D5C38: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000D5C40: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5C44: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000D5C48: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000D5C50: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000D5C58: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D5C5C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000D5C60: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 0000000D5C68: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 0000000D5C70: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 0000000D5C78: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 0000000D5C80: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 0000000D5C88: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 0000000D5C90: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000D5C98: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000D5CA0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 0000000D5CA8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000D5CB0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5CB4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000D5CB8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000D5CC0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000D5CC8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5CCC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000D5CD0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000D5CD8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000D5CE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5CE4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000D5CE8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000D5CF0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000D5CF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D5CFC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000D5D00: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 0000000D5D08: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 0000000D5D10: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 0000000D5D18: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 0000000D5D20: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 0000000D5D28: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 0000000D5D30: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 0000000D5D38: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 0000000D5D40: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 0000000D5D48: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000D5D50: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5D54: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000D5D58: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000D5D60: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000D5D68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5D6C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000D5D70: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000D5D78: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000D5D80: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5D84: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000D5D88: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000D5D90: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000D5D98: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D5D9C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000D5DA0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 0000000D5DA8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 0000000D5DB0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 0000000D5DB8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 0000000D5DC0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 0000000D5DC8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 0000000D5DD0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000D5DD8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000D5DE0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 0000000D5DE8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000D5DF0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5DF4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000D5DF8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000D5E00: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000D5E08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5E0C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000D5E10: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000D5E18: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000D5E20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5E24: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000D5E28: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000D5E30: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000D5E38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D5E3C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000D5E40: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 0000000D5E48: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 0000000D5E50: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 0000000D5E58: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 0000000D5E60: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 0000000D5E68: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 0000000D5E70: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 0000000D5E78: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 0000000D5E80: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 0000000D5E88: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000D5E90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5E94: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000D5E98: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000D5EA0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000D5EA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5EAC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000D5EB0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000D5EB8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000D5EC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5EC4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000D5EC8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000D5ED0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000D5ED8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D5EDC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000D5EE0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 0000000D5EE8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 0000000D5EF0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 0000000D5EF8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 0000000D5F00: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 0000000D5F08: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 0000000D5F10: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000D5F18: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000D5F20: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 0000000D5F28: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000D5F30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5F34: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000D5F38: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000D5F40: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000D5F48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5F4C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000D5F50: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000D5F58: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000D5F60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5F64: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000D5F68: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000D5F70: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000D5F78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D5F7C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000D5F80: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 0000000D5F88: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 0000000D5F90: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 0000000D5F98: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 0000000D5FA0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 0000000D5FA8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 0000000D5FB0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 0000000D5FB8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 0000000D5FC0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 0000000D5FC8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000D5FD0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5FD4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000D5FD8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000D5FE0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000D5FE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D5FEC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000D5FF0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000D5FF8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000D6000: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D6004: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000D6008: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000D6010: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000D6018: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D601C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 0000000D6020: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 0000000D6028: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 0000000D6030: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D6034: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 0000000D6038: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 0000000D6040: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 0000000D6048: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D604C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 0000000D6050: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s12, v[4:5]            // 0000000D6058: D6FE7C1F 041018FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 0000000D6064: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 0000000D606C: D8340000 0000201F
	s_branch 64819                                             // 0000000D6074: BFA0FD33 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	v_mov_b32_e32 v30, v14                                     // 0000000D6078: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000D607C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000D6084: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 0000000D6088: 7E46032B
	s_mov_b32 s12, 0                                           // 0000000D608C: BE8C0080
	s_branch 21                                                // 0000000D6090: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000D6094: 8C7E0D7E
	.long 0xd700011f                                           // 0000000D6098: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000D609C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D60A4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000D60A8: D5207C20 00064080
	.long 0xd700011d                                           // 0000000D60B0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000D60B4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000D60BC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D60C0: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000D60C8: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000D60CC: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000D60D0: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000D60D4: BC7C0000
	s_barrier                                                  // 0000000D60D8: BFBD0000
	buffer_gl0_inv                                             // 0000000D60DC: E0AC0000 00000000
	s_cbranch_scc1 198                                         // 0000000D60E4: BFA200C6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1400>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D60E8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000D60EC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000D60F4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000D60F8: 7E780326
	s_mov_b32 s13, 0                                           // 0000000D60FC: BE8D0080
	global_load_b32 v61, v[33:34], off                         // 0000000D6100: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000D6108: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000D6110: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000D6114: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D611C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000D6120: D5207C22 00064480
	.long 0xd4490004                                           // 0000000D6128: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000D612C: 020278FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000D6134: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000D6138: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000000D613C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 0000000D6144: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000D614C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000D6150: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000D6154: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D6158: BF89FC07
	s_barrier                                                  // 0000000D615C: BFBD0000
	buffer_gl0_inv                                             // 0000000D6160: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000D6168: BE8D2000
	s_cbranch_execz 65481                                      // 0000000D616C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s12, v2                                  // 0000000D6170: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D6174: BF870091
	v_or_b32_e32 v36, s11, v33                                 // 0000000D6178: 3848420B
	.long 0xd4440001                                           // 0000000D617C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 0000000D6180: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000D6184: 8B7E017E
	s_cbranch_execz 65474                                      // 0000000D6188: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_mov_b32_e32 v60, 0                                       // 0000000D618C: 7E780280
	s_mov_b32 s1, 0                                            // 0000000D6190: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000D6194: BF870009
	v_lshl_add_u32 v34, s1, 2, v46                             // 0000000D6198: D6460022 04B90401
	s_add_i32 s4, s1, 8                                        // 0000000D61A0: 81048801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000D61A4: B6810078
	ds_load_2addr_b32 v[70:71], v34 offset1:1                  // 0000000D61A8: D8DC0100 46000022
	ds_load_2addr_b32 v[72:73], v34 offset0:2 offset1:3        // 0000000D61B0: D8DC0302 48000022
	ds_load_2addr_b32 v[74:75], v34 offset0:4 offset1:5        // 0000000D61B8: D8DC0504 4A000022
	ds_load_2addr_b32 v[76:77], v34 offset0:6 offset1:7        // 0000000D61C0: D8DC0706 4C000022
	v_mad_u64_u32 v[61:62], null, 0x44, s1, v[1:2]             // 0000000D61C8: D6FE7C3D 040402FF 00000044
	s_mov_b32 s1, s4                                           // 0000000D61D4: BE810004
	ds_load_2addr_b32 v[62:63], v61 offset1:17                 // 0000000D61D8: D8DC1100 3E00003D
	ds_load_2addr_b32 v[64:65], v61 offset0:34 offset1:51      // 0000000D61E0: D8DC3322 4000003D
	ds_load_2addr_b32 v[66:67], v61 offset0:68 offset1:85      // 0000000D61E8: D8DC5544 4200003D
	ds_load_2addr_b32 v[68:69], v61 offset0:102 offset1:119    // 0000000D61F0: D8DC7766 4400003D
	s_waitcnt lgkmcnt(7)                                       // 0000000D61F8: BF89FC77
	v_fma_mixlo_f16 v61, v70, s6, 0                            // 0000000D61FC: CC21003D 02000D46
	s_waitcnt lgkmcnt(6)                                       // 0000000D6204: BF89FC67
	v_fma_mixlo_f16 v70, v72, s6, 0                            // 0000000D6208: CC210046 02000D48
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D6210: BF870002
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D6214: CC20003D 8A000F3D
	s_waitcnt lgkmcnt(3)                                       // 0000000D621C: BF89FC37
	v_fma_mixlo_f16 v34, v62, s6, 0                            // 0000000D6220: CC210022 02000D3E
	v_fma_mixlo_f16 v62, v63, s6, 0                            // 0000000D6228: CC21003E 02000D3F
	v_fma_mixlo_f16 v63, v71, s6, 0                            // 0000000D6230: CC21003F 02000D47
	s_waitcnt lgkmcnt(2)                                       // 0000000D6238: BF89FC27
	v_fma_mixlo_f16 v64, v64, s6, 0                            // 0000000D623C: CC210040 02000D40
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D6244: CC200022 8A000F22
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D624C: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D6254: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000D625C: BF870214
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D6260: CC200040 8A000F40
	v_fmac_f32_e32 v60, v61, v34                               // 0000000D6268: 5678453D
	v_fma_mixlo_f16 v34, v65, s6, 0                            // 0000000D626C: CC210022 02000D41
	v_fma_mixlo_f16 v61, v73, s6, 0                            // 0000000D6274: CC21003D 02000D49
	v_fma_mix_f32 v65, v70, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D627C: CC200041 8A000F46
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D6284: BF870004
	v_fmac_f32_e32 v60, v63, v62                               // 0000000D6288: 56787D3F
	s_waitcnt lgkmcnt(1)                                       // 0000000D628C: BF89FC17
	v_fma_mixlo_f16 v62, v66, s6, 0                            // 0000000D6290: CC21003E 02000D42
	v_fma_mixlo_f16 v63, v74, s6, 0                            // 0000000D6298: CC21003F 02000D4A
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D62A0: CC200022 8A000F22
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D62A8: CC20003D 8A000F3D
	v_fmac_f32_e32 v60, v65, v64                               // 0000000D62B0: 56788141
	v_fma_mixlo_f16 v64, v67, s6, 0                            // 0000000D62B4: CC210040 02000D43
	v_fma_mixlo_f16 v65, v75, s6, 0                            // 0000000D62BC: CC210041 02000D4B
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D62C4: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D62CC: CC20003F 8A000F3F
	v_fmac_f32_e32 v60, v61, v34                               // 0000000D62D4: 5678453D
	s_waitcnt lgkmcnt(0)                                       // 0000000D62D8: BF89FC07
	v_fma_mixlo_f16 v34, v68, s6, 0                            // 0000000D62DC: CC210022 02000D44
	v_fma_mixlo_f16 v61, v76, s6, 0                            // 0000000D62E4: CC21003D 02000D4C
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D62EC: CC200040 8A000F40
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D62F4: CC200041 8A000F41
	v_fmac_f32_e32 v60, v63, v62                               // 0000000D62FC: 56787D3F
	v_fma_mixlo_f16 v62, v69, s6, 0                            // 0000000D6300: CC21003E 02000D45
	v_fma_mixlo_f16 v63, v77, s6, 0                            // 0000000D6308: CC21003F 02000D4D
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D6310: CC200022 8A000F22
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D6318: CC20003D 8A000F3D
	v_fmac_f32_e32 v60, v65, v64                               // 0000000D6320: 56788141
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D6324: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000D632C: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D6334: BF870093
	v_fmac_f32_e32 v60, v61, v34                               // 0000000D6338: 5678453D
	v_fmac_f32_e32 v60, v63, v62                               // 0000000D633C: 56787D3F
	s_cbranch_scc1 65428                                       // 0000000D6340: BFA2FF94 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1194>
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000D6344: 30424282
	v_mov_b32_e32 v61, v1                                      // 0000000D6348: 7E7A0301
	s_mov_b32 s14, 0                                           // 0000000D634C: BE8E0080
	ds_load_b32 v62, v33 offset:17440                          // 0000000D6350: D8D84420 3E000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000D6358: CA10011E 2220011D
	s_waitcnt lgkmcnt(0)                                       // 0000000D6360: BF89FC07
	v_mul_f32_e32 v60, v60, v62                                // 0000000D6364: 10787D3C
	v_mov_b32_e32 v62, v35                                     // 0000000D6368: 7E7C0323
	s_nop 0                                                    // 0000000D636C: BF800000
	s_nop 0                                                    // 0000000D6370: BF800000
	s_nop 0                                                    // 0000000D6374: BF800000
	s_nop 0                                                    // 0000000D6378: BF800000
	s_nop 0                                                    // 0000000D637C: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000D6380: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000D6388: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000D6390: 4A7C7CC1
	.long 0xd7000121                                           // 0000000D6394: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000D6398: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000D639C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000D63A0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000D63A8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000D63AC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000D63B0: 4A7A7AFF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000D63B8: 8C0E0E04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D63BC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 0000000D63C0: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000D63C4: 917E0E7E
	s_cbranch_execnz 65517                                     // 0000000D63C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1380>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000D63CC: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D63D0: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 0000000D63D4: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 0000000D63DC: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 0000000D63E8: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 0000000D63F4: DC960000 007C2421
	s_branch 65317                                             // 0000000D63FC: BFA0FF25 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000D6400: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 0000000D6408: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000D640C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000D6410: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000D6418: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000D641C: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000D6424: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000D642C: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000D6430: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000D6434: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000D643C: A0010401
	s_mov_b32 s4, 0                                            // 0000000D6440: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000D6444: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000D6448: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000D644C: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000D6450: BF870585
	.long 0xd71c001d                                           // 0000000D6454: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000D6458: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000D645C: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000D6460: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000D6468: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000D646C: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000D6474: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000000D6478: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000D647C: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000D6488: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000D6490: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D6498: BF870001
	.long 0xd4490001                                           // 0000000D649C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000D64A0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000D64A8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000D64AC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000D64B0: 1040411E
	ds_store_b32 v29, v32                                      // 0000000D64B4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000D64BC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D64C4: 917E047E
	s_cbranch_execnz 65519                                     // 0000000D64C8: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1488>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D64CC: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000D64D0: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 0000000D64D8: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 0000000D64E0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D64E4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D64E8: BF89FC07
	s_barrier                                                  // 0000000D64EC: BFBD0000
	buffer_gl0_inv                                             // 0000000D64F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000D64F8: BF800000
	s_nop 0                                                    // 0000000D64FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D6500: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 0000000D6508: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D6510: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D6518: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D651C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000D6524: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D6528: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D6530: BF870004
	.long 0xd4490004                                           // 0000000D6534: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D6538: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D6540: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D6544: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D6548: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 0000000D654C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000D6554: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D655C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D6560: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1500>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D6564: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D6568: BF89FC07
	s_barrier                                                  // 0000000D656C: BFBD0000
	buffer_gl0_inv                                             // 0000000D6570: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000D6578: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000000D6580: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000000D6588: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000000D6590: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000D6598: 7E780300
	s_mov_b32 s4, 0                                            // 0000000D659C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D65A0: BF840001
	s_nop 0                                                    // 0000000D65A4: BF800000
	s_nop 0                                                    // 0000000D65A8: BF800000
	s_nop 0                                                    // 0000000D65AC: BF800000
	s_nop 0                                                    // 0000000D65B0: BF800000
	s_nop 0                                                    // 0000000D65B4: BF800000
	s_nop 0                                                    // 0000000D65B8: BF800000
	s_nop 0                                                    // 0000000D65BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D65C0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000D65C4: 327A7884
	.long 0xd4490001                                           // 0000000D65C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000D65CC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000D65D4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000D65D8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D65E4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000D65E8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000D65F0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000D65F8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000D6600: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000D6608: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000D6610: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000D6618: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000D6620: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000D6624: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D6630: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000D6634: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000D6638: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000D6640: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000D6644: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000D6648: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000D664C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D6650: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000D6654: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000D6658: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000D665C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D6660: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000D6664: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000D6670: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000D6678: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D6680: 917E047E
	s_cbranch_execnz 65486                                     // 0000000D6684: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000D6688: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D668C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000000D6690: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000D6698: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000D66A0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D66A4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D66A8: BF89FC07
	s_barrier                                                  // 0000000D66AC: BFBD0000
	buffer_gl0_inv                                             // 0000000D66B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000D66B8: BF800000
	s_nop 0                                                    // 0000000D66BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D66C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 0000000D66C8: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D66D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D66D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D66DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D66E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D66E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D66F0: BF870004
	.long 0xd4490004                                           // 0000000D66F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D66F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D6700: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D6704: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D6708: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000D670C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D6714: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D671C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D6720: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D6724: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D6728: BF89FC07
	s_barrier                                                  // 0000000D672C: BFBD0000
	buffer_gl0_inv                                             // 0000000D6730: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000D6738: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000000D6740: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000000D6748: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000000D6750: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000D6758: 7E780300
	s_mov_b32 s4, 0                                            // 0000000D675C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D6760: BF840001
	s_nop 0                                                    // 0000000D6764: BF800000
	s_nop 0                                                    // 0000000D6768: BF800000
	s_nop 0                                                    // 0000000D676C: BF800000
	s_nop 0                                                    // 0000000D6770: BF800000
	s_nop 0                                                    // 0000000D6774: BF800000
	s_nop 0                                                    // 0000000D6778: BF800000
	s_nop 0                                                    // 0000000D677C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D6780: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000D6784: 327A7884
	.long 0xd4490001                                           // 0000000D6788: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000D678C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000D6794: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000D6798: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D67A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000D67A8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000D67B0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000D67B8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000D67C0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000D67C8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000D67D0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000D67D8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000D67E0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000D67E4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D67F0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000D67F4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000D67F8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000D6800: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000D6804: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000D6808: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000D680C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D6810: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000D6814: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000D6818: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000D681C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D6820: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000D6824: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000D6830: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000D6838: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D6840: 917E047E
	s_cbranch_execnz 65486                                     // 0000000D6844: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1780>
	s_set_inst_prefetch_distance 0x2                           // 0000000D6848: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D684C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000000D6850: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000D6858: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000D6860: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D6864: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D6868: BF89FC07
	s_barrier                                                  // 0000000D686C: BFBD0000
	buffer_gl0_inv                                             // 0000000D6870: E0AC0000 00000000
	s_nop 0                                                    // 0000000D6878: BF800000
	s_nop 0                                                    // 0000000D687C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D6880: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000000D6888: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D6890: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D6898: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D689C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D68A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D68A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D68B0: BF870004
	.long 0xd4490004                                           // 0000000D68B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D68B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D68C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D68C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D68C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000D68CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D68D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D68DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D68E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1880>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D68E4: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000D68E8: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000D68F0: BF89FC07
	s_barrier                                                  // 0000000D68F4: BFBD0000
	buffer_gl0_inv                                             // 0000000D68F8: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000D6900: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 0000000D6904: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 0000000D690C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 0000000D6914: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 0000000D691C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000D6924: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D6928: BF840001
	s_nop 0                                                    // 0000000D692C: BF800000
	s_nop 0                                                    // 0000000D6930: BF800000
	s_nop 0                                                    // 0000000D6934: BF800000
	s_nop 0                                                    // 0000000D6938: BF800000
	s_nop 0                                                    // 0000000D693C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000D6940: 327C7A84
	.long 0xd4490001                                           // 0000000D6944: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000D6948: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D6950: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000D6954: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000D6958: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D6964: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000D6968: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000D6970: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000D6978: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000D6980: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000D6988: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000D6990: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000D6998: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000D69A0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000D69A4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D69A8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000D69AC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000D69B8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000D69C0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000D69C4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000D69C8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000D69CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D69D0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000D69D4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000D69D8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000D69DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D69E0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000D69E4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000D69F0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000D69F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D6A00: 917E047E
	s_cbranch_execnz 65486                                     // 0000000D6A04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_set_inst_prefetch_distance 0x2                           // 0000000D6A08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D6A0C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000D6A10: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000D6A18: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000D6A20: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D6A24: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D6A28: BF89FC07
	s_barrier                                                  // 0000000D6A2C: BFBD0000
	buffer_gl0_inv                                             // 0000000D6A30: E0AC0000 00000000
	s_nop 0                                                    // 0000000D6A38: BF800000
	s_nop 0                                                    // 0000000D6A3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D6A40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000000D6A48: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D6A50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D6A58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D6A5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D6A64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D6A68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D6A70: BF870004
	.long 0xd4490004                                           // 0000000D6A74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D6A78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D6A80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D6A84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D6A88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000D6A8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D6A94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D6A9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D6AA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D6AA4: 8C7E0A7E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000D6AA8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000D6AB0: BF89FC07
	s_barrier                                                  // 0000000D6AB4: BFBD0000
	buffer_gl0_inv                                             // 0000000D6AB8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 0000000D6AC0: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 0000000D6AC8: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 0000000D6AD0: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 0000000D6AD8: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000D6AE0: 7E780300
	s_mov_b32 s4, 0                                            // 0000000D6AE4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D6AE8: BF840001
	s_nop 0                                                    // 0000000D6AEC: BF800000
	s_nop 0                                                    // 0000000D6AF0: BF800000
	s_nop 0                                                    // 0000000D6AF4: BF800000
	s_nop 0                                                    // 0000000D6AF8: BF800000
	s_nop 0                                                    // 0000000D6AFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D6B00: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000D6B04: 327A7884
	.long 0xd4490001                                           // 0000000D6B08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000D6B0C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000D6B14: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000D6B18: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D6B24: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000D6B28: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000D6B30: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000D6B38: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000D6B40: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000D6B48: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000D6B50: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000D6B58: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000D6B60: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000D6B64: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D6B70: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000D6B74: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000D6B78: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000D6B80: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000D6B84: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000D6B88: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000D6B8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D6B90: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000D6B94: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000D6B98: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000D6B9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D6BA0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000D6BA4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000D6BB0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000D6BB8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D6BC0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000D6BC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_set_inst_prefetch_distance 0x2                           // 0000000D6BC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D6BCC: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 0000000D6BD0: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000D6BD8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000D6BE0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D6BE4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D6BE8: BF89FC07
	s_barrier                                                  // 0000000D6BEC: BFBD0000
	buffer_gl0_inv                                             // 0000000D6BF0: E0AC0000 00000000
	s_nop 0                                                    // 0000000D6BF8: BF800000
	s_nop 0                                                    // 0000000D6BFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D6C00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 0000000D6C08: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D6C10: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D6C18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D6C1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D6C24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D6C28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D6C30: BF870004
	.long 0xd4490004                                           // 0000000D6C34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D6C38: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D6C40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D6C44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D6C48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000D6C4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D6C54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D6C5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D6C60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D6C64: 8C7E0A7E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000000D6C68: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000D6C70: BF89FC07
	s_barrier                                                  // 0000000D6C74: BFBD0000
	buffer_gl0_inv                                             // 0000000D6C78: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000000D6C80: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000000D6C84: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000000D6C8C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000000D6C94: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000000D6C9C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000D6CA4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D6CA8: BF840001
	s_nop 0                                                    // 0000000D6CAC: BF800000
	s_nop 0                                                    // 0000000D6CB0: BF800000
	s_nop 0                                                    // 0000000D6CB4: BF800000
	s_nop 0                                                    // 0000000D6CB8: BF800000
	s_nop 0                                                    // 0000000D6CBC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 0000000D6CC0: 327C7884
	.long 0xd4490001                                           // 0000000D6CC4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000D6CC8: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D6CD0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000D6CD4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000D6CD8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D6CE4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000D6CE8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000D6CF0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000D6CF8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000D6D00: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000D6D08: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000D6D10: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000D6D18: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000D6D20: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000D6D24: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D6D28: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000D6D2C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000D6D38: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000D6D40: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000D6D44: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000D6D48: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000D6D4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D6D50: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000D6D54: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000D6D58: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000D6D5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D6D60: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000000D6D64: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 0000000D6D70: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000D6D74: BF870002
	v_mov_b32_e32 v60, v63                                     // 0000000D6D78: 7E78033F
	ds_store_b32 v62, v70                                      // 0000000D6D7C: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D6D84: 917E047E
	s_cbranch_execnz 65485                                     // 0000000D6D88: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_set_inst_prefetch_distance 0x2                           // 0000000D6D8C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D6D90: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000000D6D94: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000D6D9C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000D6DA4: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D6DA8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D6DAC: BF89FC07
	s_barrier                                                  // 0000000D6DB0: BFBD0000
	buffer_gl0_inv                                             // 0000000D6DB4: E0AC0000 00000000
	s_nop 0                                                    // 0000000D6DBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D6DC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 0000000D6DC8: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D6DD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D6DD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D6DDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D6DE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D6DE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D6DF0: BF870004
	.long 0xd4490004                                           // 0000000D6DF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D6DF8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D6E00: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D6E04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D6E08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000D6E0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D6E14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D6E1C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D6E20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D6E24: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000000D6E28: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000D6E30: BF89FC07
	s_barrier                                                  // 0000000D6E34: BFBD0000
	buffer_gl0_inv                                             // 0000000D6E38: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000000D6E40: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000000D6E48: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000000D6E50: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000000D6E58: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000D6E60: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000D6E64: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D6E68: BF840001
	s_nop 0                                                    // 0000000D6E6C: BF800000
	s_nop 0                                                    // 0000000D6E70: BF800000
	s_nop 0                                                    // 0000000D6E74: BF800000
	s_nop 0                                                    // 0000000D6E78: BF800000
	s_nop 0                                                    // 0000000D6E7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D6E80: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000D6E84: 327C7A84
	.long 0xd4490001                                           // 0000000D6E88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000D6E8C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000D6E94: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000D6E98: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D6EA4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000D6EA8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000D6EB0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000D6EB8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000D6EC0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000D6EC8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000D6ED0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000D6ED8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000D6EE0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000D6EE4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D6EE8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000D6EEC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000D6EF8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000D6F00: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000D6F04: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000D6F08: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000D6F0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D6F10: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000D6F14: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000D6F18: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000D6F1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D6F20: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000D6F24: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000D6F30: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000D6F38: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D6F40: 917E047E
	s_cbranch_execnz 65486                                     // 0000000D6F44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e80>
	s_set_inst_prefetch_distance 0x2                           // 0000000D6F48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D6F4C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 0000000D6F50: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000D6F58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000D6F60: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D6F64: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D6F68: BF89FC07
	s_barrier                                                  // 0000000D6F6C: BFBD0000
	buffer_gl0_inv                                             // 0000000D6F70: E0AC0000 00000000
	s_nop 0                                                    // 0000000D6F78: BF800000
	s_nop 0                                                    // 0000000D6F7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D6F80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000D6F88: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D6F90: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D6F98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D6F9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D6FA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D6FA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D6FB0: BF870004
	.long 0xd4490004                                           // 0000000D6FB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D6FB8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D6FC0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D6FC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D6FC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000D6FCC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D6FD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D6FDC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D6FE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D6FE4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000D6FE8: BF89FC07
	s_barrier                                                  // 0000000D6FEC: BFBD0000
	buffer_gl0_inv                                             // 0000000D6FF0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 0000000D6FF8: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 0000000D7000: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 0000000D7008: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 0000000D7010: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000D7018: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000D701C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D7020: BF840001
	s_nop 0                                                    // 0000000D7024: BF800000
	s_nop 0                                                    // 0000000D7028: BF800000
	s_nop 0                                                    // 0000000D702C: BF800000
	s_nop 0                                                    // 0000000D7030: BF800000
	s_nop 0                                                    // 0000000D7034: BF800000
	s_nop 0                                                    // 0000000D7038: BF800000
	s_nop 0                                                    // 0000000D703C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D7040: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000D7044: 327C7A84
	.long 0xd4490001                                           // 0000000D7048: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000D704C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000D7054: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000D7058: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D7064: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000D7068: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000D7070: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000D7078: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000D7080: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000D7088: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000D7090: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000D7098: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000D70A0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000D70A4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D70A8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000D70AC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000D70B8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000D70C0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000D70C4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000D70C8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000D70CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D70D0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000D70D4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000D70D8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000D70DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D70E0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000D70E4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000D70F0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000D70F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D7100: 917E047E
	s_cbranch_execnz 65486                                     // 0000000D7104: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_set_inst_prefetch_distance 0x2                           // 0000000D7108: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D710C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000D7110: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000D7118: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000D7120: 7E420326
	s_mov_b32 s10, 0                                           // 0000000D7124: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000D7128: BF89FC07
	s_barrier                                                  // 0000000D712C: BFBD0000
	buffer_gl0_inv                                             // 0000000D7130: E0AC0000 00000000
	s_nop 0                                                    // 0000000D7138: BF800000
	s_nop 0                                                    // 0000000D713C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000D7140: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000000D7148: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000D7150: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000D7158: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000D715C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000D7164: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000D7168: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000D7170: BF870004
	.long 0xd4490004                                           // 0000000D7174: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000D7178: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000D7180: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000D7184: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000D7188: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000D718C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000D7194: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000D719C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000D71A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2140>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000D71A4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000D71A8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000D71B0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000D71B8: BF89FC07
	s_barrier                                                  // 0000000D71BC: BFBD0000
	buffer_gl0_inv                                             // 0000000D71C0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 0000000D71C8: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 0000000D71D0: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000D71D8: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 0000000D71E0: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000D71E8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000D71EC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000D71F0: BF840001
	s_nop 0                                                    // 0000000D71F4: BF800000
	s_nop 0                                                    // 0000000D71F8: BF800000
	s_nop 0                                                    // 0000000D71FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000D7200: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000D7204: 327A7884
	.long 0xd4490001                                           // 0000000D7208: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000D720C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000D7214: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000D7218: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000D7224: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000D7228: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000D7230: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000D7238: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000D7240: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000D7248: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000D7250: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000D7258: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000D7260: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000D7264: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000D7270: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000D7274: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000D7278: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000D7280: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000D7284: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000D7288: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000D728C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D7290: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000D7294: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000D7298: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000D729C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D72A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000D72A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000D72B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000D72B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000D72C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000D72C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2200>
	s_set_inst_prefetch_distance 0x2                           // 0000000D72C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000D72CC: 8C7E047E
	.long 0xd7000107                                           // 0000000D72D0: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000D72D4: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D72DC: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000D72E0: D5207C08 00061080
	.long 0xd7000109                                           // 0000000D72E8: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000D72EC: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000D72F4: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000D72FC: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000D7300: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D7308: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000D730C: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000D7314: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000D7318: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000D7320: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000D7328: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000D732C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D7334: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000D7338: D5207C10 00062080
	.long 0xd7000111                                           // 0000000D7340: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000D7344: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000D734C: D5207C12 00062480
	.long 0xd7000113                                           // 0000000D7354: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000D7358: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D7360: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000D7364: D5207C14 00062880
	.long 0xd7000115                                           // 0000000D736C: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000D7370: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000D7378: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000D7380: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000D7384: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000D738C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000D7390: D5207C18 00063080
	.long 0xd7000119                                           // 0000000D7398: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000D739C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000D73A4: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000D73AC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000D73B0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000D73B8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000D73BC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000D73C4: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000D73C8: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000D73CC: BF062105
	s_barrier                                                  // 0000000D73D0: BFBD0000
	buffer_gl0_inv                                             // 0000000D73D4: E0AC0000 00000000
	s_cbranch_scc0 63477                                       // 0000000D73DC: BFA1F7F5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b4>
	v_mov_b32_e32 v4, v38                                      // 0000000D73E0: 7E080326
	s_add_u32 s0, s28, s20                                     // 0000000D73E4: 8000141C
	.long 0xd73c0000                                           // 0000000D73E8: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000D73EC: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000D73F0: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000D73F4: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000D73F8: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000D73FC: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000D7400: 82010103
	.long 0xd7006a00                                           // 0000000D7404: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000D7408: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000D740C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000D7410: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000D7418: BE810080
	.long 0xd7006a00                                           // 0000000D741C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 0000000D7420: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000D7424: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000D742C: BF870092
	.long 0xd7006a00                                           // 0000000D7430: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000D7434: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000D7438: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 0000000D7440: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000D7448: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000000D7450: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000D7458: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000D745C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000D7464: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000D7468: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000D746C: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000D7474: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000D7478: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000D7480: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000D7488: 917E017E
	s_cbranch_execnz 65516                                     // 0000000D748C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi18ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	s_endpgm                                                   // 0000000D7490: BFB00000
		...

