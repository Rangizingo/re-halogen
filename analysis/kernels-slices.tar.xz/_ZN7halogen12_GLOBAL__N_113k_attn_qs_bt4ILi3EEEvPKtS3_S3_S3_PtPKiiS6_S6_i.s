00000000001d6800 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 0000001D6800: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 0000001D6804: F4080300 F8000020
	s_load_b128 s[16:19], s[0:1], 0x38                         // 0000001D680C: F4080400 F8000038
	s_mov_b32 s20, s3                                          // 0000001D6814: BE940003
	s_ashr_i32 s3, s2, 31                                      // 0000001D6818: 86039F02
	s_waitcnt lgkmcnt(0)                                       // 0000001D681C: BF89FC07
	s_load_b32 s22, s[14:15], null                             // 0000001D6820: F4000587 F8000000
	s_clause 0x1                                               // 0000001D6828: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 0000001D682C: F40C0100 F8000000
	s_load_b32 s14, s[0:1], 0x48                               // 0000001D6834: F4000380 F8000048
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000001D683C: 84808202
	s_waitcnt lgkmcnt(0)                                       // 0000001D6840: BF89FC07
	s_add_i32 s22, s22, s2                                     // 0000001D6844: 81160216
	s_add_u32 s0, s18, s0                                      // 0000001D6848: 80000012
	s_addc_u32 s1, s19, s1                                     // 0000001D684C: 82010113
	s_add_i32 s3, s22, 1                                       // 0000001D6850: 81038116
	s_load_b32 s18, s[0:1], null                               // 0000001D6854: F4000480 F8000000
	s_ashr_i32 s0, s3, 31                                      // 0000001D685C: 86009F03
	s_mul_hi_i32 s1, s14, s2                                   // 0000001D6860: 9701020E
	s_lshr_b32 s0, s0, 30                                      // 0000001D6864: 85009E00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001D6868: BF870499
	s_add_i32 s3, s3, s0                                       // 0000001D686C: 81030003
	s_and_b32 s19, s3, -4                                      // 0000001D6870: 8B13C403
	s_ashr_i32 s3, s3, 2                                       // 0000001D6874: 86038203
	s_sub_i32 s0, s22, s19                                     // 0000001D6878: 81801316
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D687C: BF870009
	s_cmp_gt_i32 s0, -1                                        // 0000001D6880: BF02C100
	s_mul_i32 s0, s14, s2                                      // 0000001D6884: 9600020E
	s_cselect_b32 s15, -1, 0                                   // 0000001D6888: 980F80C1
	s_mov_b32 s14, s3                                          // 0000001D688C: BE8E0003
	s_and_b32 vcc_lo, exec_lo, s15                             // 0000001D6890: 8B6A0F7E
	s_cbranch_vccnz 15                                         // 0000001D6894: BFA4000F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd4>
	s_lshl_b64 s[24:25], s[0:1], 2                             // 0000001D6898: 84988200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001D689C: BF8704D9
	s_add_u32 s14, s16, s24                                    // 0000001D68A0: 800E1810
	s_addc_u32 s21, s17, s25                                   // 0000001D68A4: 82151911
	s_waitcnt lgkmcnt(0)                                       // 0000001D68A8: BF89FC07
	s_max_i32 s24, s18, 1                                      // 0000001D68AC: 8A188112
	s_mov_b32 s25, 0                                           // 0000001D68B0: BE990080
	s_lshl_b64 s[24:25], s[24:25], 2                           // 0000001D68B4: 84988218
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D68B8: BF870009
	s_add_u32 s14, s14, s24                                    // 0000001D68BC: 800E180E
	s_addc_u32 s21, s21, s25                                   // 0000001D68C0: 82151915
	s_add_u32 s24, s14, -4                                     // 0000001D68C4: 8018C40E
	s_addc_u32 s25, s21, -1                                    // 0000001D68C8: 8219C115
	s_load_b32 s14, s[24:25], null                             // 0000001D68CC: F400038C F8000000
	v_cndmask_b32_e64 v1, 0, 1, s15                            // 0000001D68D4: D5010001 003D0280
	s_mov_b32 s24, exec_lo                                     // 0000001D68DC: BE98007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001D68E0: BF8704B1
	v_readfirstlane_b32 s15, v1                                // 0000001D68E4: 7E1E0501
	s_waitcnt lgkmcnt(0)                                       // 0000001D68E8: BF89FC07
	s_add_i32 s15, s18, s15                                    // 0000001D68EC: 810F0F12
	s_add_i32 s21, s15, 3                                      // 0000001D68F0: 8115830F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001D68F4: BF870499
	s_and_b32 s23, s21, -4                                     // 0000001D68F8: 8B17C415
	.long 0xd4c4007e                                           // 0000001D68FC: D4C4007E
	v_cndmask_b32_e32 v1, s23, v0, vcc_lo                      // 0000001D6900: 02020017
	s_cbranch_execz 46                                         // 0000001D6904: BFA5002E <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1c0>
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v3, 2, v0      // 0000001D6908: CA220100 04020082
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000001D6910: 84808200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D6914: BF8700A9
	s_add_u32 s0, s16, s0                                      // 0000001D6918: 80000010
	s_addc_u32 s1, s17, s1                                     // 0000001D691C: 82010111
	.long 0xd7000001                                           // 0000001D6920: D7000001
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000001D6924: 02020600
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D6928: BF870001
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000001D692C: D5207C02 00010001
	s_mov_b32 s1, 0                                            // 0000001D6934: BE810080
	s_set_inst_prefetch_distance 0x1                           // 0000001D6938: BF840001
	s_branch 19                                                // 0000001D693C: BFA00013 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x18c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001D6940: 8C7E007E
	v_add_nc_u32_e32 v6, 0x200, v3                             // 0000001D6944: 4A0C06FF 00000200
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001D694C: 4A0808FF 00000080
	s_waitcnt vmcnt(0)                                         // 0000001D6954: BF8903F7
	ds_store_b32 v3, v5 offset:512                             // 0000001D6958: D8340200 00000503
	.long 0xd7000001                                           // 0000001D6960: D7000001
	v_cndmask_b32_e32 v1, 0x200, v1, vcc_lo                    // 0000001D6964: 020202FF 00000200
	v_mov_b32_e32 v3, v6                                       // 0000001D696C: 7E060306
	v_cmp_le_i32_e32 vcc_lo, s23, v4                           // 0000001D6970: 7C860817
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001D6974: D5207C02 00020480
	s_or_b32 s1, vcc_lo, s1                                    // 0000001D697C: 8C01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D6980: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001D6984: 917E017E
	s_cbranch_execz 13                                         // 0000001D6988: BFA5000D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1c0>
	s_mov_b32 s0, exec_lo                                      // 0000001D698C: BE80007E
	.long 0xd4c3007e                                           // 0000001D6990: D4C3007E
	v_cndmask_b32_e32 v1, s18, v4, vcc_lo                      // 0000001D6994: 02020812
	s_xor_b32 s0, exec_lo, s0                                  // 0000001D6998: 8D00007E
	v_mov_b32_e32 v5, s3                                       // 0000001D699C: 7E0A0203
	v_cmp_gt_i32_e32 vcc_lo, s15, v4                           // 0000001D69A0: 7C88080F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001D69A4: BF870002
	v_cndmask_b32_e32 v5, s14, v5, vcc_lo                      // 0000001D69A8: 020A0A0E
	s_and_not1_saveexec_b32 s0, s0                             // 0000001D69AC: BE803000
	s_cbranch_execz 65507                                      // 0000001D69B0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	global_load_b32 v5, v[1:2], off                            // 0000001D69B4: DC520000 057C0001
	s_branch 65504                                             // 0000001D69BC: BFA0FFE0 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	s_set_inst_prefetch_distance 0x2                           // 0000001D69C0: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 0000001D69C4: 8C7E187E
	v_and_b32_e32 v137, 15, v0                                 // 0000001D69C8: 3712008F
	v_bfe_u32 v140, v0, 4, 1                                   // 0000001D69CC: D610008C 02050900
	s_mul_i32 s3, s20, 12                                      // 0000001D69D4: 96038C14
	s_mul_hi_i32 s15, s2, 0x1800                               // 0000001D69D8: 970FFF02 00001800
	s_mul_i32 s14, s2, 0x1800                                  // 0000001D69E0: 960EFF02 00001800
	v_cmp_gt_u32_e32 vcc_lo, 12, v137                          // 0000001D69E8: 7C99128C
	v_lshrrev_b32_e32 v138, 5, v0                              // 0000001D69EC: 33140085
	s_lshl_b64 s[0:1], s[14:15], 1                             // 0000001D69F0: 8480810E
	s_ashr_i32 s16, s21, 2                                     // 0000001D69F4: 86108215
	s_add_u32 s0, s4, s0                                       // 0000001D69F8: 80000004
	v_dual_cndmask_b32 v1, 0, v137 :: v_dual_lshlrev_b32 v136, 5, v140// 0000001D69FC: CA631280 01891885
	s_addc_u32 s1, s5, s1                                      // 0000001D6A04: 82010105
	v_mov_b32_e32 v159, 0                                      // 0000001D6A08: 7F3E0280
	v_lshlrev_b32_e32 v139, 6, v138                            // 0000001D6A0C: 31171486
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001D6A10: BF8700B3
	v_add_lshl_u32 v1, v1, s3, 8                               // 0000001D6A14: D6470001 02200701
	s_mov_b32 s4, 0                                            // 0000001D6A1C: BE840080
	s_cmp_gt_i32 s16, 0                                        // 0000001D6A20: BF028010
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000001D6A24: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D6A28: BF870121
	.long 0xd73c0002                                           // 0000001D6A2C: D73C0002
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000001D6A30: 02020281
	v_lshlrev_b32_e32 v1, 7, v138                              // 0000001D6A34: 30031487
	.long 0xd7006a02                                           // 0000001D6A38: D7006A02
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 0000001D6A3C: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D6A40: BF870111
	v_add_co_ci_u32_e64 v3, null, s1, v3, vcc_lo               // 0000001D6A44: D5207C03 01AA0601
	.long 0xd7006a02                                           // 0000001D6A4C: D7006A02
	v_cndmask_b32_e32 v1, v2, v1, vcc_lo                       // 0000001D6A50: 02020302
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D6A54: BF870001
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000001D6A58: D5207C03 01AA0680
	s_clause 0x7                                               // 0000001D6A60: BF850007
	global_load_b128 v[36:39], v[2:3], off offset:16           // 0000001D6A64: DC5E0010 247C0002
	global_load_b128 v[32:35], v[2:3], off                     // 0000001D6A6C: DC5E0000 207C0002
	global_load_b128 v[44:47], v[2:3], off offset:48           // 0000001D6A74: DC5E0030 2C7C0002
	global_load_b128 v[40:43], v[2:3], off offset:32           // 0000001D6A7C: DC5E0020 287C0002
	global_load_b128 v[52:55], v[2:3], off offset:80           // 0000001D6A84: DC5E0050 347C0002
	global_load_b128 v[48:51], v[2:3], off offset:64           // 0000001D6A8C: DC5E0040 307C0002
	global_load_b128 v[60:63], v[2:3], off offset:112          // 0000001D6A94: DC5E0070 3C7C0002
	global_load_b128 v[56:59], v[2:3], off offset:96           // 0000001D6A9C: DC5E0060 387C0002
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001D6AA4: BF890007
	s_barrier                                                  // 0000001D6AA8: BFBD0000
	buffer_gl0_inv                                             // 0000001D6AAC: E0AC0000 00000000
	s_cbranch_scc0 563                                         // 0000001D6AB4: BFA10233 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xb84>
	v_dual_mov_b32 v153, 0xf149f2ca :: v_dual_and_b32 v4, 12, v137// 0000001D6AB8: CA2400FF 9905128C F149F2CA
	s_ashr_i32 s21, s20, 31                                    // 0000001D6AC4: 86159F14
	v_dual_mov_b32 v64, 0 :: v_dual_lshlrev_b32 v5, 9, v138    // 0000001D6AC8: CA220080 40051489
	ds_load_b32 v2, v4 offset:512                              // 0000001D6AD0: D8D80200 02000004
	v_lshlrev_b32_e32 v0, 5, v0                                // 0000001D6AD8: 30000085
	s_lshl_b64 s[0:1], s[20:21], 11                            // 0000001D6ADC: 84808B14
	v_or_b32_e32 v144, 0x200, v4                               // 0000001D6AE0: 392008FF 00000200
	s_add_u32 s0, s6, s0                                       // 0000001D6AE8: 80000006
	s_addc_u32 s1, s7, s1                                      // 0000001D6AEC: 82010107
	.long 0xd7000005                                           // 0000001D6AF0: D7000005
	v_cndmask_b32_e32 v1, s0, v5, vcc_lo                       // 0000001D6AF4: 02020A00
	v_dual_mov_b32 v65, v64 :: v_dual_and_b32 v0, 0x60, v0     // 0000001D6AF8: CA240140 410000FF 00000060
	v_mov_b32_e32 v67, v64                                     // 0000001D6B04: 7E860340
	v_add_co_ci_u32_e64 v6, null, s1, 0, s0                    // 0000001D6B08: D5207C06 00010001
	v_mov_b32_e32 v69, v64                                     // 0000001D6B10: 7E8A0340
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6B14: BF870094
	.long 0xd7006a8d                                           // 0000001D6B18: D7006A8D
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000001D6B1C: 02020105
	v_add_co_ci_u32_e64 v142, null, 0, v6, vcc_lo              // 0000001D6B20: D5207C8E 01AA0C80
	v_lshlrev_b32_e32 v0, 6, v140                              // 0000001D6B28: 30011886
	s_lshl_b64 s[0:1], s[20:21], 8                             // 0000001D6B2C: 84808814
	s_waitcnt lgkmcnt(0)                                       // 0000001D6B30: BF89FC07
	v_ashrrev_i32_e32 v3, 31, v2                               // 0000001D6B34: 3406049F
	v_or_b32_e32 v145, 0x3210, v136                            // 0000001D6B38: 392310FF 00003210
	v_dual_mov_b32 v4, s1 :: v_dual_lshlrev_b32 v147, 5, v137  // 0000001D6B40: CA220001 04931285
	v_lshl_or_b32 v0, v137, 2, v0                              // 0000001D6B48: D6560000 04010589
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D6B50: BF870234
	.long 0xd73c0002                                           // 0000001D6B54: D73C0002
	v_cndmask_b32_e32 v1, 12, v2, vcc_lo                       // 0000001D6B58: 0202048C
	v_lshl_or_b32 v5, v137, 1, v136                            // 0000001D6B5C: D6560005 06210389
	v_or_b32_e32 v6, 64, v1                                    // 0000001D6B64: 380C02C0
	v_dual_mov_b32 v143, v64 :: v_dual_add_nc_u32 v0, 0x2210, v0// 0000001D6B68: CA200140 8F0000FF 00002210
	v_lshl_add_u32 v148, v138, 3, v145                         // 0000001D6B74: D6460094 0645078A
	.long 0xd7006a02                                           // 0000001D6B7C: D7006A02
	v_cndmask_b32_e32 v1, v141, v2, vcc_lo                     // 0000001D6B80: 0202058D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D6B84: BF870211
	v_add_co_ci_u32_e64 v3, null, v142, v3, vcc_lo             // 0000001D6B88: D5207C03 01AA078E
	v_lshl_or_b32 v146, v138, 10, v0                           // 0000001D6B90: D6560092 0401158A
	v_dual_mov_b32 v159, v64 :: v_dual_add_nc_u32 v152, v5, v6 // 0000001D6B98: CA200140 9F980D05
	s_clause 0x7                                               // 0000001D6BA0: BF850007
	global_load_b128 v[76:79], v[2:3], off offset:400          // 0000001D6BA4: DC5E0190 4C7C0002
	global_load_b128 v[72:75], v[2:3], off offset:384          // 0000001D6BAC: DC5E0180 487C0002
	global_load_b128 v[84:87], v[2:3], off offset:272          // 0000001D6BB4: DC5E0110 547C0002
	global_load_b128 v[80:83], v[2:3], off offset:256          // 0000001D6BBC: DC5E0100 507C0002
	global_load_b128 v[92:95], v[2:3], off offset:144          // 0000001D6BC4: DC5E0090 5C7C0002
	global_load_b128 v[88:91], v[2:3], off offset:128          // 0000001D6BCC: DC5E0080 587C0002
	global_load_b128 v[100:103], v[2:3], off offset:16         // 0000001D6BD4: DC5E0010 647C0002
	global_load_b128 v[96:99], v[2:3], off                     // 0000001D6BDC: DC5E0000 607C0002
	v_dual_mov_b32 v71, v64 :: v_dual_lshlrev_b32 v2, 8, v138  // 0000001D6BE4: CA220140 47031488
	v_or_b32_e32 v3, s0, v137                                  // 0000001D6BEC: 38071200
	s_lshl2_add_u32 s0, s18, s22                               // 0000001D6BF0: 87801612
	v_dual_mov_b32 v68, v64 :: v_dual_add_nc_u32 v157, v5, v1  // 0000001D6BF4: CA200140 449C0305
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D6BFC: BF870193
	v_dual_mov_b32 v158, 0xf149f2ca :: v_dual_add_nc_u32 v151, v0, v2// 0000001D6C00: CA2000FF 9E960500 F149F2CA
	.long 0xd7006a95                                           // 0000001D6C0C: D7006A95
	v_cndmask_b32_e32 v1, v3, v139, vcc_lo                     // 0000001D6C10: 02031703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D6C14: BF870191
	v_add_co_ci_u32_e64 v150, null, 0, v4, vcc_lo              // 0000001D6C18: D5207C96 01AA0880
	v_dual_mov_b32 v66, v64 :: v_dual_add_nc_u32 v155, 0x800, v151// 0000001D6C20: CA200140 429B2EFF 00000800
	v_mov_b32_e32 v70, v64                                     // 0000001D6C2C: 7E8C0340
	v_dual_mov_b32 v25, v64 :: v_dual_add_nc_u32 v154, 0x400, v151// 0000001D6C30: CA200140 199B2EFF 00000400
	v_dual_mov_b32 v27, v64 :: v_dual_add_nc_u32 v156, 0xc00, v151// 0000001D6C3C: CA200140 1B9D2EFF 00000C00
	v_mov_b32_e32 v24, v64                                     // 0000001D6C48: 7E300340
	v_mov_b32_e32 v26, v64                                     // 0000001D6C4C: 7E340340
	v_mov_b32_e32 v28, v64                                     // 0000001D6C50: 7E380340
	v_mov_b32_e32 v29, v64                                     // 0000001D6C54: 7E3A0340
	v_mov_b32_e32 v30, v64                                     // 0000001D6C58: 7E3C0340
	v_mov_b32_e32 v31, v64                                     // 0000001D6C5C: 7E3E0340
	v_mov_b32_e32 v16, v64                                     // 0000001D6C60: 7E200340
	v_mov_b32_e32 v17, v64                                     // 0000001D6C64: 7E220340
	v_mov_b32_e32 v18, v64                                     // 0000001D6C68: 7E240340
	v_mov_b32_e32 v19, v64                                     // 0000001D6C6C: 7E260340
	v_mov_b32_e32 v20, v64                                     // 0000001D6C70: 7E280340
	v_mov_b32_e32 v21, v64                                     // 0000001D6C74: 7E2A0340
	v_mov_b32_e32 v22, v64                                     // 0000001D6C78: 7E2C0340
	v_mov_b32_e32 v23, v64                                     // 0000001D6C7C: 7E2E0340
	v_mov_b32_e32 v8, v64                                      // 0000001D6C80: 7E100340
	v_mov_b32_e32 v9, v64                                      // 0000001D6C84: 7E120340
	v_mov_b32_e32 v10, v64                                     // 0000001D6C88: 7E140340
	v_mov_b32_e32 v11, v64                                     // 0000001D6C8C: 7E160340
	v_mov_b32_e32 v12, v64                                     // 0000001D6C90: 7E180340
	v_mov_b32_e32 v13, v64                                     // 0000001D6C94: 7E1A0340
	v_mov_b32_e32 v14, v64                                     // 0000001D6C98: 7E1C0340
	v_mov_b32_e32 v15, v64                                     // 0000001D6C9C: 7E1E0340
	v_mov_b32_e32 v0, v64                                      // 0000001D6CA0: 7E000340
	v_mov_b32_e32 v1, v64                                      // 0000001D6CA4: 7E020340
	v_mov_b32_e32 v2, v64                                      // 0000001D6CA8: 7E040340
	v_mov_b32_e32 v3, v64                                      // 0000001D6CAC: 7E060340
	v_mov_b32_e32 v4, v64                                      // 0000001D6CB0: 7E080340
	v_mov_b32_e32 v5, v64                                      // 0000001D6CB4: 7E0A0340
	v_mov_b32_e32 v6, v64                                      // 0000001D6CB8: 7E0C0340
	v_mov_b32_e32 v7, v64                                      // 0000001D6CBC: 7E0E0340
	s_sub_i32 s0, s0, s19                                      // 0000001D6CC0: 81801300
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001D6CC4: BF870009
	s_add_i32 s5, s0, 1                                        // 0000001D6CC8: 81058100
	s_mov_b32 s0, 0                                            // 0000001D6CCC: BE800080
	v_mov_b32_e32 v104, s4                                     // 0000001D6CD0: 7ED00204
	s_add_i32 s6, s0, 1                                        // 0000001D6CD4: 81068100
	s_waitcnt vmcnt(0)                                         // 0000001D6CD8: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[160:167], v[32:39], v[96:103], v[64:71]// 0000001D6CDC: CC4140A0 1D02C120
	s_cmp_lt_i32 s6, s16                                       // 0000001D6CE4: BF041006
	ds_load_b128 v[96:99], v104 offset:512                     // 0000001D6CE8: DBFC0200 60000068
	s_cselect_b32 s0, s6, s0                                   // 0000001D6CF0: 98000006
	v_wmma_f32_16x16x16_bf16 v[160:167], v[40:47], v[88:95], v[160:167]// 0000001D6CF4: CC4140A0 1E82B128
	v_lshl_add_u32 v88, s0, 4, v144                            // 0000001D6CFC: D6460058 06410800
	s_add_i32 s4, s4, 16                                       // 0000001D6D04: 81049004
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001D6D08: BF870002
	v_wmma_f32_16x16x16_bf16 v[160:167], v[48:55], v[80:87], v[160:167]// 0000001D6D0C: CC4140A0 1E82A130
	ds_load_b32 v80, v88                                       // 0000001D6D14: D8D80000 50000058
	v_wmma_f32_16x16x16_bf16 v[160:167], v[56:63], v[72:79], v[160:167]// 0000001D6D1C: CC4140A0 1E829138
	s_waitcnt lgkmcnt(1)                                       // 0000001D6D24: BF89FC17
	v_ashrrev_i32_e32 v73, 31, v96                             // 0000001D6D28: 3492C09F
	v_mov_b32_e32 v72, v96                                     // 0000001D6D2C: 7E900360
	v_ashrrev_i32_e32 v75, 31, v97                             // 0000001D6D30: 3496C29F
	v_mov_b32_e32 v74, v97                                     // 0000001D6D34: 7E940361
	v_ashrrev_i32_e32 v77, 31, v98                             // 0000001D6D38: 349AC49F
	v_mov_b32_e32 v76, v98                                     // 0000001D6D3C: 7E980362
	.long 0xd73c0048                                           // 0000001D6D40: D73C0048
	v_cndmask_b32_e32 v1, 9, v72, vcc_lo                       // 0000001D6D44: 02029089
	v_ashrrev_i32_e32 v100, 31, v99                            // 0000001D6D48: 34C8C69F
	.long 0xd73c004a                                           // 0000001D6D4C: D73C004A
	v_cndmask_b32_e32 v1, 9, v74, vcc_lo                       // 0000001D6D50: 02029489
	s_waitcnt lgkmcnt(0)                                       // 0000001D6D54: BF89FC07
	v_ashrrev_i32_e32 v81, 31, v80                             // 0000001D6D58: 34A2A09F
	.long 0xd73c004c                                           // 0000001D6D5C: D73C004C
	v_cndmask_b32_e32 v1, 9, v76, vcc_lo                       // 0000001D6D60: 02029889
	.long 0xd73c004e                                           // 0000001D6D64: D73C004E
	v_cndmask_b32_e32 v1, 9, v99, vcc_lo                       // 0000001D6D68: 0202C689
	.long 0xd7006a48                                           // 0000001D6D6C: D7006A48
	v_cndmask_b32_e32 v1, v72, v149, vcc_lo                    // 0000001D6D70: 02032B48
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D6D74: BF8700A1
	v_add_co_ci_u32_e64 v73, null, v73, v150, vcc_lo           // 0000001D6D78: D5207C49 01AB2D49
	.long 0xd7006a4a                                           // 0000001D6D80: D7006A4A
	v_cndmask_b32_e32 v1, v74, v149, vcc_lo                    // 0000001D6D84: 02032B4A
	v_add_co_ci_u32_e64 v75, null, v75, v150, vcc_lo           // 0000001D6D88: D5207C4B 01AB2D4B
	.long 0xd7006a4c                                           // 0000001D6D90: D7006A4C
	v_cndmask_b32_e32 v1, v76, v149, vcc_lo                    // 0000001D6D94: 02032B4C
	.long 0xd73c0050                                           // 0000001D6D98: D73C0050
	v_cndmask_b32_e32 v1, 12, v80, vcc_lo                      // 0000001D6D9C: 0202A08C
	v_add_co_ci_u32_e64 v77, null, v77, v150, vcc_lo           // 0000001D6DA0: D5207C4D 01AB2D4D
	.long 0xd7006a4e                                           // 0000001D6DA8: D7006A4E
	v_cndmask_b32_e32 v1, v78, v149, vcc_lo                    // 0000001D6DAC: 02032B4E
	.long 0xd73c0068                                           // 0000001D6DB0: D73C0068
	v_cndmask_b32_e32 v1, 3, v72, vcc_lo                       // 0000001D6DB4: 02029083
	v_add_co_ci_u32_e64 v79, null, v79, v150, vcc_lo           // 0000001D6DB8: D5207C4F 01AB2D4F
	.long 0xd73c006a                                           // 0000001D6DC0: D73C006A
	v_cndmask_b32_e32 v1, 3, v74, vcc_lo                       // 0000001D6DC4: 02029483
	.long 0xd73c006c                                           // 0000001D6DC8: D73C006C
	v_cndmask_b32_e32 v1, 3, v76, vcc_lo                       // 0000001D6DCC: 02029883
	.long 0xd7006a48                                           // 0000001D6DD0: D7006A48
	v_cndmask_b32_e32 v1, v141, v80, vcc_lo                    // 0000001D6DD4: 0202A18D
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001D6DD8: BF8700B4
	.long 0xd73c006e                                           // 0000001D6DDC: D73C006E
	v_cndmask_b32_e32 v1, 3, v78, vcc_lo                       // 0000001D6DE0: 02029C83
	v_add_co_ci_u32_e64 v73, null, v142, v81, vcc_lo           // 0000001D6DE4: D5207C49 01AAA38E
	.long 0xd7006a72                                           // 0000001D6DEC: D7006A72
	v_cndmask_b32_e32 v1, s8, v104, vcc_lo                     // 0000001D6DF0: 0202D008
	v_add_co_ci_u32_e64 v115, null, s9, v105, vcc_lo           // 0000001D6DF4: D5207C73 01AAD209
	.long 0xd7006a74                                           // 0000001D6DFC: D7006A74
	v_cndmask_b32_e32 v1, s8, v106, vcc_lo                     // 0000001D6E00: 0202D408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D6E04: BF8700A1
	v_add_co_ci_u32_e64 v117, null, s9, v107, vcc_lo           // 0000001D6E08: D5207C75 01AAD609
	.long 0xd7006a76                                           // 0000001D6E10: D7006A76
	v_cndmask_b32_e32 v1, s8, v108, vcc_lo                     // 0000001D6E14: 0202D808
	v_add_co_ci_u32_e64 v119, null, s9, v109, vcc_lo           // 0000001D6E18: D5207C77 01AADA09
	.long 0xd7006a86                                           // 0000001D6E20: D7006A86
	v_cndmask_b32_e32 v1, s8, v110, vcc_lo                     // 0000001D6E24: 0202DC08
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D6E28: BF870001
	v_add_co_ci_u32_e64 v135, null, s9, v111, vcc_lo           // 0000001D6E2C: D5207C87 01AADE09
	s_clause 0x7                                               // 0000001D6E34: BF850007
	global_load_b128 v[100:103], v[72:73], off offset:16       // 0000001D6E38: DC5E0010 647C0048
	global_load_b128 v[96:99], v[72:73], off                   // 0000001D6E40: DC5E0000 607C0048
	global_load_b128 v[92:95], v[72:73], off offset:144        // 0000001D6E48: DC5E0090 5C7C0048
	global_load_b128 v[88:91], v[72:73], off offset:128        // 0000001D6E50: DC5E0080 587C0048
	global_load_b128 v[84:87], v[72:73], off offset:272        // 0000001D6E58: DC5E0110 547C0048
	global_load_b128 v[80:83], v[72:73], off offset:256        // 0000001D6E60: DC5E0100 507C0048
	global_load_b128 v[76:79], v[72:73], off offset:400        // 0000001D6E68: DC5E0190 4C7C0048
	global_load_b128 v[72:75], v[72:73], off offset:384        // 0000001D6E70: DC5E0180 487C0048
	s_clause 0xf                                               // 0000001D6E78: BF85000F
	global_load_b64 v[104:105], v[114:115], off                // 0000001D6E7C: DC560000 687C0072
	global_load_b64 v[112:113], v[114:115], off offset:128     // 0000001D6E84: DC560080 707C0072
	global_load_b64 v[120:121], v[114:115], off offset:256     // 0000001D6E8C: DC560100 787C0072
	global_load_b64 v[128:129], v[114:115], off offset:384     // 0000001D6E94: DC560180 807C0072
	global_load_b64 v[106:107], v[116:117], off                // 0000001D6E9C: DC560000 6A7C0074
	global_load_b64 v[114:115], v[116:117], off offset:128     // 0000001D6EA4: DC560080 727C0074
	global_load_b64 v[122:123], v[116:117], off offset:256     // 0000001D6EAC: DC560100 7A7C0074
	global_load_b64 v[130:131], v[116:117], off offset:384     // 0000001D6EB4: DC560180 827C0074
	global_load_b64 v[108:109], v[118:119], off                // 0000001D6EBC: DC560000 6C7C0076
	global_load_b64 v[116:117], v[118:119], off offset:128     // 0000001D6EC4: DC560080 747C0076
	global_load_b64 v[124:125], v[118:119], off offset:256     // 0000001D6ECC: DC560100 7C7C0076
	global_load_b64 v[132:133], v[118:119], off offset:384     // 0000001D6ED4: DC560180 847C0076
	global_load_b64 v[110:111], v[134:135], off                // 0000001D6EDC: DC560000 6E7C0086
	global_load_b64 v[118:119], v[134:135], off offset:128     // 0000001D6EE4: DC560080 767C0086
	global_load_b64 v[126:127], v[134:135], off offset:256     // 0000001D6EEC: DC560100 7E7C0086
	global_load_b64 v[134:135], v[134:135], off offset:384     // 0000001D6EF4: DC560180 867C0086
	ds_store_2addr_b32 v146, v160, v161 offset1:32             // 0000001D6EFC: D8382000 00A1A092
	ds_store_2addr_b32 v146, v162, v163 offset0:64 offset1:96  // 0000001D6F04: D8386040 00A3A292
	ds_store_2addr_b32 v146, v164, v165 offset0:128 offset1:160// 0000001D6F0C: D838A080 00A5A492
	ds_store_2addr_b32 v146, v166, v167 offset0:192 offset1:224// 0000001D6F14: D838E0C0 00A7A692
	v_mov_b32_e32 v160, v159                                   // 0000001D6F1C: 7F40039F
	v_cmp_gt_i32_e32 vcc_lo, s5, v137                          // 0000001D6F20: 7C891205
	.long 0xd59c40a1                                           // 0000001D6F24: D59C40A1
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 0000001D6F28: 02010080
	s_add_i32 s5, s5, -16                                      // 0000001D6F2C: 8105D005
	s_cmp_eq_u32 s16, s6                                       // 0000001D6F30: BF060610
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D6F34: BF870001
	.long 0xd59c48a2                                           // 0000001D6F38: D59C48A2
	v_cndmask_b32_e32 v0, v161, v128, vcc_lo                   // 0000001D6F3C: 020101A1
	s_waitcnt lgkmcnt(0)                                       // 0000001D6F40: BF89FC07
	s_barrier                                                  // 0000001D6F44: BFBD0000
	ds_load_2addr_b32 v[163:164], v151 offset1:32              // 0000001D6F48: D8DC2000 A3000097
	ds_load_2addr_b32 v[165:166], v154 offset1:32              // 0000001D6F50: D8DC2000 A500009A
	ds_load_2addr_b32 v[167:168], v155 offset1:32              // 0000001D6F58: D8DC2000 A700009B
	ds_load_2addr_b32 v[169:170], v156 offset1:32              // 0000001D6F60: D8DC2000 A900009C
	s_waitcnt lgkmcnt(2)                                       // 0000001D6F68: BF89FC27
	v_add_f32_e32 v159, v163, v165                             // 0000001D6F6C: 073F4BA3
	v_add_f32_e32 v163, v164, v166                             // 0000001D6F70: 07474DA4
	s_waitcnt lgkmcnt(1)                                       // 0000001D6F74: BF89FC17
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D6F78: BF870112
	v_add_f32_e32 v159, v159, v167                             // 0000001D6F7C: 073F4F9F
	v_add_f32_e32 v163, v163, v168                             // 0000001D6F80: 074751A3
	s_waitcnt lgkmcnt(0)                                       // 0000001D6F84: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6F88: BF870092
	v_add_f32_e32 v159, v159, v169                             // 0000001D6F8C: 073F539F
	v_mul_f32_e32 v159, 0x3d800000, v159                       // 0000001D6F90: 113F3EFF 3D800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6F98: BF870091
	v_cndmask_b32_e32 v159, 0xf149f2ca, v159, vcc_lo           // 0000001D6F9C: 033F3EFF F149F2CA
	v_mov_b32_dpp v164, v159 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D6FA4: 7F4802FA FF09619F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6FAC: BF870091
	v_max_f32_e32 v164, v164, v164                             // 0000001D6FB0: 214949A4
	v_max_f32_e32 v164, v159, v164                             // 0000001D6FB4: 2149499F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6FB8: BF870091
	v_mov_b32_dpp v166, v164 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D6FBC: 7F4C02FA FF0962A4
	v_max_f32_e32 v166, v166, v166                             // 0000001D6FC4: 214D4DA6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6FC8: BF870091
	v_max_f32_e32 v164, v164, v166                             // 0000001D6FCC: 21494DA4
	v_mov_b32_dpp v166, v164 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D6FD0: 7F4C02FA FF0964A4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6FD8: BF870091
	v_max_f32_e32 v166, v166, v166                             // 0000001D6FDC: 214D4DA6
	v_max_f32_e32 v164, v164, v166                             // 0000001D6FE0: 21494DA4
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6FE4: BF870091
	v_mov_b32_dpp v166, v164 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D6FE8: 7F4C02FA FF0968A4
	v_max3_f32 v164, v153, v164, v166                          // 0000001D6FF0: D61C00A4 069B4999
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D6FF8: BF870091
	v_dual_add_f32 v163, v163, v170 :: v_dual_sub_f32 v166, v153, v164// 0000001D6FFC: C90B55A3 A3A74999
	v_mul_f32_e32 v163, 0x3d800000, v163                       // 0000001D7004: 114746FF 3D800000
	v_sub_f32_e32 v159, v159, v164                             // 0000001D700C: 093F499F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D7010: BF8701A3
	v_dual_mov_b32 v153, v164 :: v_dual_mul_f32 v164, 0x3fb8aa3b, v166// 0000001D7014: CA0601A4 99A54CFF 3FB8AA3B
	.long 0xd41b0002                                           // 0000001D7020: D41B0002
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v166, vcc_lo             // 0000001D7024: 02034CFF C2CE8ED0
	v_mul_f32_e32 v168, 0x3fb8aa3b, v159                       // 0000001D702C: 11513EFF 3FB8AA3B
	.long 0xd41b0000                                           // 0000001D7034: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v159, vcc_lo             // 0000001D7038: 02033EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D7040: BF870004
	v_rndne_f32_e32 v174, v164                                 // 0000001D7044: 7F5C47A4
	v_cndmask_b32_e32 v163, 0xf149f2ca, v163, vcc_lo           // 0000001D7048: 034746FF F149F2CA
	v_fma_f32 v170, 0x3fb8aa3b, v166, -v164                    // 0000001D7050: D61300AA 86934CFF 3FB8AA3B
	v_rndne_f32_e32 v176, v168                                 // 0000001D705C: 7F6047A8
	v_fma_f32 v172, 0x3fb8aa3b, v159, -v168                    // 0000001D7060: D61300AC 86A33EFF 3FB8AA3B
	v_sub_f32_e32 v164, v164, v174                             // 0000001D706C: 09495DA4
	v_mov_b32_dpp v165, v163 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D7070: 7F4A02FA FF0961A3
	v_fmac_f32_e32 v170, 0x32a5705f, v166                      // 0000001D7078: 57554CFF 32A5705F
	v_sub_f32_e32 v168, v168, v176                             // 0000001D7080: 095161A8
	v_cvt_i32_f32_e32 v174, v174                               // 0000001D7084: 7F5C11AE
	v_cvt_i32_f32_e32 v176, v176                               // 0000001D7088: 7F6011B0
	v_dual_max_f32 v165, v165, v165 :: v_dual_fmac_f32 v172, 0x32a5705f, v159// 0000001D708C: CA814BA5 A5AD3EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D7098: BF870111
	v_dual_add_f32 v164, v164, v170 :: v_dual_max_f32 v165, v163, v165// 0000001D709C: C91555A4 A4A54BA3
	v_add_f32_e32 v168, v168, v172                             // 0000001D70A4: 075159A8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D70A8: BF870112
	v_exp_f32_e32 v164, v164                                   // 0000001D70AC: 7F484BA4
	v_mov_b32_dpp v167, v165 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D70B0: 7F4E02FA FF0962A5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D70B8: BF870092
	v_exp_f32_e32 v168, v168                                   // 0000001D70BC: 7F504BA8
	v_max_f32_e32 v167, v167, v167                             // 0000001D70C0: 214F4FA7
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D70C4: BF870116
	.long 0xd71c00a4                                           // 0000001D70C8: D71C00A4
	v_cndmask_b32_e32 v1, v164, v174, vcc_lo                   // 0000001D70CC: 02035DA4
	v_max_f32_e32 v165, v165, v167                             // 0000001D70D0: 214B4FA5
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D70D4: BF870195
	.long 0xd71c00a8                                           // 0000001D70D8: D71C00A8
	v_cndmask_b32_e32 v1, v168, v176, vcc_lo                   // 0000001D70DC: 020361A8
	v_cndmask_b32_e64 v164, 0, v164, s2                        // 0000001D70E0: D50100A4 000B4880
	.long 0xd41e0002                                           // 0000001D70E8: D41E0002
	v_cndmask_b32_e32 v1, 0x42b17218, v166, vcc_lo             // 0000001D70EC: 02034CFF 42B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D70F4: BF870214
	v_mov_b32_dpp v167, v165 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D70F8: 7F4E02FA FF0964A5
	v_cndmask_b32_e64 v166, 0, v168, s0                        // 0000001D7100: D50100A6 00035080
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D7108: BF870193
	v_cndmask_b32_e64 v176, 0x7f800000, v164, s2               // 0000001D710C: D50100B0 000B48FF 7F800000
	v_max_f32_e32 v167, v167, v167                             // 0000001D7118: 214F4FA7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D711C: BF870091
	v_max_f32_e32 v165, v165, v167                             // 0000001D7120: 214B4FA5
	v_mov_b32_dpp v167, v165 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D7124: 7F4E02FA FF0968A5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D712C: BF870091
	v_max3_f32 v165, v158, v165, v167                          // 0000001D7130: D61C00A5 069F4B9E
	v_sub_f32_e32 v163, v163, v165                             // 0000001D7138: 09474BA3
	v_dual_sub_f32 v167, v158, v165 :: v_dual_mov_b32 v158, v165// 0000001D713C: C9514B9E A79E01A5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D7144: BF870112
	v_mul_f32_e32 v165, 0x3fb8aa3b, v163                       // 0000001D7148: 114B46FF 3FB8AA3B
	v_mul_f32_e32 v169, 0x3fb8aa3b, v167                       // 0000001D7150: 11534EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v163                 // 0000001D7158: 7C3746FF C2CE8ED0
	.long 0xd41b0001                                           // 0000001D7160: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v167, vcc_lo             // 0000001D7164: 02034EFF C2CE8ED0
	.long 0xd41e0000                                           // 0000001D716C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v167, vcc_lo             // 0000001D7170: 02034EFF 42B17218
	v_fma_f32 v171, 0x3fb8aa3b, v163, -v165                    // 0000001D7178: D61300AB 869746FF 3FB8AA3B
	v_fma_f32 v173, 0x3fb8aa3b, v167, -v169                    // 0000001D7184: D61300AD 86A74EFF 3FB8AA3B
	v_rndne_f32_e32 v175, v165                                 // 0000001D7190: 7F5E47A5
	v_rndne_f32_e32 v177, v169                                 // 0000001D7194: 7F6247A9
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D7198: BF870214
	v_fmac_f32_e32 v171, 0x32a5705f, v163                      // 0000001D719C: 575746FF 32A5705F
	v_fmac_f32_e32 v173, 0x32a5705f, v167                      // 0000001D71A4: 575B4EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D71AC: BF870214
	v_sub_f32_e32 v165, v165, v175                             // 0000001D71B0: 094B5FA5
	v_sub_f32_e32 v169, v169, v177                             // 0000001D71B4: 095363A9
	v_cvt_i32_f32_e32 v175, v175                               // 0000001D71B8: 7F5E11AF
	v_cvt_i32_f32_e32 v177, v177                               // 0000001D71BC: 7F6211B1
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D71C0: BF870214
	v_add_f32_e32 v165, v165, v171                             // 0000001D71C4: 074B57A5
	v_add_f32_e32 v169, v169, v173                             // 0000001D71C8: 07535BA9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D71CC: BF870092
	v_exp_f32_e32 v165, v165                                   // 0000001D71D0: 7F4A4BA5
	v_exp_f32_e32 v169, v169                                   // 0000001D71D4: 7F524BA9
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001D71D8: BF870296
	.long 0xd71c00a5                                           // 0000001D71DC: D71C00A5
	v_cndmask_b32_e32 v1, v165, v175, vcc_lo                   // 0000001D71E0: 02035FA5
	.long 0xd71c00a9                                           // 0000001D71E4: D71C00A9
	v_cndmask_b32_e32 v1, v169, v177, vcc_lo                   // 0000001D71E8: 020363A9
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D71EC: BF8701A2
	v_cndmask_b32_e32 v165, 0, v165, vcc_lo                    // 0000001D71F0: 034B4A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v163                 // 0000001D71F4: 7C3D46FF 42B17218
	v_cndmask_b32_e64 v163, 0, v169, s1                        // 0000001D71FC: D50100A3 00075280
	.long 0xd41e0001                                           // 0000001D7204: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v159, vcc_lo             // 0000001D7208: 02033EFF 42B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D7210: BF870194
	v_cndmask_b32_e32 v159, 0x7f800000, v165, vcc_lo           // 0000001D7214: 033F4AFF 7F800000
	v_cndmask_b32_e64 v177, 0x7f800000, v163, s0               // 0000001D721C: D50100B1 000346FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D7228: BF8701A3
	v_cndmask_b32_e64 v166, 0x7f800000, v166, s1               // 0000001D722C: D50100A6 00074CFF 7F800000
	s_mov_b32 s0, s6                                           // 0000001D7238: BE800006
	.long 0xd59c08a1                                           // 0000001D723C: D59C08A1
	v_cndmask_b32_e32 v0, v159, v128, vcc_lo                   // 0000001D7240: 0201019F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D7244: BF870192
	.long 0xd59c08a2                                           // 0000001D7248: D59C08A2
	v_cndmask_b32_e32 v0, v166, v128, vcc_lo                   // 0000001D724C: 020101A6
	v_fma_f32 v143, v143, v176, v166                           // 0000001D7250: D613008F 069B618F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D7258: BF870193
	v_and_b32_e32 v161, 1, v161                                // 0000001D725C: 37434281
	v_and_b32_e32 v162, 1, v162                                // 0000001D7260: 37454481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D7264: BF870112
	v_add3_u32 v161, v159, v161, 0x7fff                        // 0000001D7268: D65500A1 03FF439F 00007FFF
	v_add3_u32 v162, v166, v162, 0x7fff                        // 0000001D7274: D65500A2 03FF45A6 00007FFF
	ds_store_b16_d16_hi v157, v162                             // 0000001D7280: DA840000 0000A29D
	ds_store_b16_d16_hi v152, v161                             // 0000001D7288: DA840000 0000A198
	ds_store_b64 v148, v[176:177]                              // 0000001D7290: D9340000 0000B094
	s_waitcnt lgkmcnt(0)                                       // 0000001D7298: BF89FC07
	s_barrier                                                  // 0000001D729C: BFBD0000
	ds_load_b128 v[169:172], v145                              // 0000001D72A0: DBFC0000 A9000091
	ds_load_b128 v[173:176], v145 offset:16                    // 0000001D72A8: DBFC0010 AD000091
	ds_load_b128 v[161:164], v147                              // 0000001D72B0: DBFC0000 A1000093
	ds_load_b128 v[165:168], v147 offset:16                    // 0000001D72B8: DBFC0010 A5000093
	s_waitcnt lgkmcnt(3)                                       // 0000001D72C0: BF89FC37
	v_dual_mul_f32 v24, v169, v24 :: v_dual_mul_f32 v25, v170, v25// 0000001D72C4: C8C631A9 181833AA
	v_mul_f32_e32 v0, v169, v0                                 // 0000001D72CC: 100001A9
	v_dual_mul_f32 v26, v171, v26 :: v_dual_mul_f32 v27, v172, v27// 0000001D72D0: C8C635AB 1A1A37AC
	s_waitcnt lgkmcnt(2)                                       // 0000001D72D8: BF89FC27
	v_mul_f32_e32 v20, v173, v20                               // 0000001D72DC: 102829AD
	v_dual_mul_f32 v28, v173, v28 :: v_dual_mul_f32 v29, v174, v29// 0000001D72E0: C8C639AD 1C1C3BAE
	v_mul_f32_e32 v22, v175, v22                               // 0000001D72E8: 102C2DAF
	v_dual_mul_f32 v30, v175, v30 :: v_dual_mul_f32 v31, v176, v31// 0000001D72EC: C8C63DAF 1E1E3FB0
	v_mul_f32_e32 v12, v173, v12                               // 0000001D72F4: 101819AD
	v_dual_mul_f32 v16, v169, v16 :: v_dual_mul_f32 v17, v170, v17// 0000001D72F8: C8C621A9 101023AA
	v_mul_f32_e32 v14, v175, v14                               // 0000001D7300: 101C1DAF
	v_dual_mul_f32 v18, v171, v18 :: v_dual_mul_f32 v19, v172, v19// 0000001D7304: C8C625AB 121227AC
	v_mul_f32_e32 v4, v173, v4                                 // 0000001D730C: 100809AD
	v_dual_mul_f32 v8, v169, v8 :: v_dual_mul_f32 v9, v170, v9 // 0000001D7310: C8C611A9 080813AA
	v_mul_f32_e32 v6, v175, v6                                 // 0000001D7318: 100C0DAF
	v_dual_mul_f32 v10, v171, v10 :: v_dual_mul_f32 v11, v172, v11// 0000001D731C: C8C615AB 0A0A17AC
	v_dual_mul_f32 v1, v170, v1 :: v_dual_mul_f32 v2, v171, v2 // 0000001D7324: C8C603AA 010205AB
	v_mul_f32_e32 v3, v172, v3                                 // 0000001D732C: 100607AC
	v_mul_f32_e32 v21, v174, v21                               // 0000001D7330: 102A2BAE
	v_mul_f32_e32 v23, v176, v23                               // 0000001D7334: 102E2FB0
	v_mul_f32_e32 v13, v174, v13                               // 0000001D7338: 101A1BAE
	v_mul_f32_e32 v15, v176, v15                               // 0000001D733C: 101E1FB0
	v_mul_f32_e32 v5, v174, v5                                 // 0000001D7340: 100A0BAE
	v_mul_f32_e32 v7, v176, v7                                 // 0000001D7344: 100E0FB0
	v_fmac_f32_e32 v159, v160, v177                            // 0000001D7348: 573F63A0
	s_waitcnt vmcnt(3) lgkmcnt(0)                              // 0000001D734C: BF890C07
	v_wmma_f32_16x16x16_bf16 v[24:31], v[161:168], v[104:111], v[24:31]// 0000001D7350: CC414018 1C62D1A1
	s_waitcnt vmcnt(2)                                         // 0000001D7358: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[16:23], v[161:168], v[112:119], v[16:23]// 0000001D735C: CC414010 1C42E1A1
	s_waitcnt vmcnt(1)                                         // 0000001D7364: BF8907F7
	v_wmma_f32_16x16x16_bf16 v[8:15], v[161:168], v[120:127], v[8:15]// 0000001D7368: CC414008 1C22F1A1
	s_waitcnt vmcnt(0)                                         // 0000001D7370: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[0:7], v[161:168], v[128:135], v[0:7]// 0000001D7374: CC414000 1C0301A1
	s_cbranch_scc0 65108                                       // 0000001D737C: BFA1FE54 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x4d0>
	s_branch 25                                                // 0000001D7380: BFA00019 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt4ILi3EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xbe8>
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v1, 0               // 0000001D7384: CA100080 00000080
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v3, 0               // 0000001D738C: CA100080 02020080
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 0000001D7394: CA100080 04040080
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v9, 0               // 0000001D739C: CA100080 08080080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v11, 0             // 0000001D73A4: CA100080 0A0A0080
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 0000001D73AC: CA100080 0C0C0080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v17, 0             // 0000001D73B4: CA100080 10100080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v19, 0             // 0000001D73BC: CA100080 12120080
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v21, 0             // 0000001D73C4: CA100080 14140080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v25, 0             // 0000001D73CC: CA100080 18180080
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v27, 0             // 0000001D73D4: CA100080 1A1A0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v29, 0             // 0000001D73DC: CA100080 1C1C0080
	v_mov_b32_e32 v143, 0                                      // 0000001D73E4: 7F1E0280
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D73E8: BF870111
	v_add_f32_dpp v7, v159, v159 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D73EC: 060F3EFA FF09619F
	v_add_f32_dpp v6, v143, v143 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D73F4: 060D1EFA FF09618F
	v_or_b32_e32 v35, v139, v137                               // 0000001D73FC: 3847138B
	s_barrier                                                  // 0000001D7400: BFBD0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D7404: BF870193
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D7408: 060E0EFA FF096207
	v_add_f32_dpp v6, v6, v6 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D7410: 060C0CFA FF096206
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D7418: BF870223
	v_or_b32_e32 v40, s14, v35                                 // 0000001D741C: 3850460E
	.long 0x7f6c3880                                           // 0000001D7420: 7F6C3880
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D7424: 060E0EFA FF096407
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D742C: BF870194
	v_add_f32_dpp v6, v6, v6 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D7430: 060C0CFA FF096406
	.long 0x7f7839b6                                           // 0000001D7438: 7F7839B6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D743C: BF870193
	v_add_f32_dpp v31, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D7440: 063E0EFA FF096807
	v_add_f32_dpp v30, v6, v6 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001D7448: 063C0CFA FF096806
	v_or_b32_e32 v6, s3, v140                                  // 0000001D7450: 380D1803
	v_or_b32_e32 v7, 0x3210, v136                              // 0000001D7454: 380F10FF 00003210
	.long 0x7f7239b6                                           // 0000001D745C: 7F7239B6
	v_div_scale_f32 v33, null, v31, v31, 1.0                   // 0000001D7460: D6FC7C21 03CA3F1F
	v_div_scale_f32 v32, null, v30, v30, 1.0                   // 0000001D7468: D6FC7C20 03CA3D1E
	v_div_scale_f32 v42, vcc_lo, 1.0, v30, 1.0                 // 0000001D7470: D6FC6A2A 03CA3CF2
	v_lshl_add_u32 v39, v138, 3, v7                            // 0000001D7478: D6460027 041D078A
	.long 0x7f7a39b6                                           // 0000001D7480: 7F7A39B6
	v_rcp_f32_e32 v37, v33                                     // 0000001D7484: 7E4A5521
	v_rcp_f32_e32 v34, v32                                     // 0000001D7488: 7E445520
	.long 0x7f7639b6                                           // 0000001D748C: 7F7639B6
	.long 0x7f7439b6                                           // 0000001D7490: 7F7439B6
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001D7494: BF8702A6
	v_fma_f32 v15, -v33, v37, 1.0                              // 0000001D7498: D613000F 23CA4B21
	v_lshlrev_b32_e32 v36, 8, v6                               // 0000001D74A0: 30480C88
	v_fma_f32 v6, -v32, v34, 1.0                               // 0000001D74A4: D6130006 23CA4520
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D74AC: BF870193
	v_dual_fmac_f32 v37, v15, v37 :: v_dual_mov_b32 v38, s15   // 0000001D74B0: C8104B0F 2526000F
	v_add_nc_u32_e32 v41, 0x800, v36                           // 0000001D74B8: 4A5248FF 00000800
	v_ashrrev_i32_e32 v7, 31, v36                              // 0000001D74C0: 340E489F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D74C4: BF870234
	v_fmac_f32_e32 v34, v6, v34                                // 0000001D74C8: 56444506
	.long 0xd7000006                                           // 0000001D74CC: D7000006
	v_cndmask_b32_e32 v1, v40, v36, vcc_lo                     // 0000001D74D0: 02024928
	v_add_nc_u32_e32 v14, 0x400, v36                           // 0000001D74D4: 4A1C48FF 00000400
	v_add_co_ci_u32_e64 v7, null, v38, v7, s0                  // 0000001D74DC: D5207C07 00020F26
	v_div_scale_f32 v43, s0, 1.0, v31, 1.0                     // 0000001D74E4: D6FC002B 03CA3EF2
	v_mul_f32_e32 v44, v42, v34                                // 0000001D74EC: 1058452A
	v_add_nc_u32_e32 v22, 0x600, v36                           // 0000001D74F0: 4A2C48FF 00000600
	v_ashrrev_i32_e32 v15, 31, v14                             // 0000001D74F8: 341E1C9F
	.long 0xd700010e                                           // 0000001D74FC: D700010E
	v_cndmask_b32_e32 v1, v40, v14, vcc_lo                     // 0000001D7500: 02021D28
	v_mul_f32_e32 v46, v43, v37                                // 0000001D7504: 105C4B2B
	v_fma_f32 v47, -v32, v44, v42                              // 0000001D7508: D613002F 24AA5920
	v_ashrrev_i32_e32 v23, 31, v22                             // 0000001D7510: 342E2C9F
	v_add_co_ci_u32_e64 v15, null, v38, v15, s1                // 0000001D7514: D5207C0F 00061F26
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D751C: BF870214
	v_fma_f32 v48, -v33, v46, v43                              // 0000001D7520: D6130030 24AE5D21
	v_fmac_f32_e32 v44, v47, v34                               // 0000001D7528: 5658452F
	.long 0xd7000116                                           // 0000001D752C: D7000116
	v_cndmask_b32_e32 v1, v40, v22, vcc_lo                     // 0000001D7530: 02022D28
	.long 0xd73c0006                                           // 0000001D7534: D73C0006
	v_cndmask_b32_e32 v1, 1, v6, vcc_lo                        // 0000001D7538: 02020C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D753C: BF870214
	v_fmac_f32_e32 v46, v48, v37                               // 0000001D7540: 565C4B30
	v_fma_f32 v32, -v32, v44, v42                              // 0000001D7544: D6130020 24AA5920
	v_add_co_ci_u32_e64 v23, null, v38, v23, s1                // 0000001D754C: D5207C17 00062F26
	.long 0xd73c000e                                           // 0000001D7554: D73C000E
	v_cndmask_b32_e32 v1, 1, v14, vcc_lo                       // 0000001D7558: 02021C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D755C: BF870214
	v_fma_f32 v33, -v33, v46, v43                              // 0000001D7560: D6130021 24AE5D21
	v_div_fmas_f32 v32, v32, v34, v44                          // 0000001D7568: D6370020 04B24520
	s_mov_b32 vcc_lo, s0                                       // 0000001D7570: BEEA0000
	.long 0xd73c0016                                           // 0000001D7574: D73C0016
	v_cndmask_b32_e32 v1, 1, v22, vcc_lo                       // 0000001D7578: 02022C81
	v_ashrrev_i32_e32 v45, 31, v41                             // 0000001D757C: 345A529F
	v_div_fmas_f32 v33, v33, v37, v46                          // 0000001D7580: D6370021 04BA4B21
	v_div_fixup_f32 v30, v32, v30, 1.0                         // 0000001D7588: D627001E 03CA3D20
	.long 0xd7006a32                                           // 0000001D7590: D7006A32
	v_cndmask_b32_e32 v1, s10, v6, vcc_lo                      // 0000001D7594: 02020C0A
	v_add_nc_u32_e32 v32, 0xa00, v36                           // 0000001D7598: 4A4048FF 00000A00
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001D75A0: BF8700B4
	v_div_fixup_f32 v31, v33, v31, 1.0                         // 0000001D75A4: D627001F 03CA3F21
	v_add_co_ci_u32_e64 v51, null, s11, v7, vcc_lo             // 0000001D75AC: D5207C33 01AA0E0B
	.long 0xd7006a2a                                           // 0000001D75B4: D7006A2A
	v_cndmask_b32_e32 v1, s10, v14, vcc_lo                     // 0000001D75B8: 02021C0A
	v_add_co_ci_u32_e64 v43, null, s11, v15, vcc_lo            // 0000001D75BC: D5207C2B 01AA1E0B
	ds_store_b64 v39, v[30:31]                                 // 0000001D75C4: D9340000 00001E27
	.long 0xd7006a1e                                           // 0000001D75CC: D7006A1E
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                     // 0000001D75D0: 02025328
	v_ashrrev_i32_e32 v33, 31, v32                             // 0000001D75D4: 3442409F
	v_add_co_ci_u32_e64 v31, null, v38, v45, vcc_lo            // 0000001D75D8: D5207C1F 01AA5B26
	.long 0xd7006a2c                                           // 0000001D75E0: D7006A2C
	v_cndmask_b32_e32 v1, s10, v22, vcc_lo                     // 0000001D75E4: 02022C0A
	v_or_b32_e32 v34, 0x200, v36                               // 0000001D75E8: 384448FF 00000200
	v_add_co_ci_u32_e64 v45, null, s11, v23, vcc_lo            // 0000001D75F0: D5207C2D 01AA2E0B
	.long 0xd7006a20                                           // 0000001D75F8: D7006A20
	v_cndmask_b32_e32 v1, v40, v32, vcc_lo                     // 0000001D75FC: 02024128
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D7600: BF8700A1
	v_add_co_ci_u32_e64 v33, null, v38, v33, vcc_lo            // 0000001D7604: D5207C21 01AA4326
	.long 0xd7000023                                           // 0000001D760C: D7000023
	v_cndmask_b32_e32 v1, s14, v35, vcc_lo                     // 0000001D7610: 0202460E
	v_add_co_ci_u32_e64 v38, null, s15, 0, s0                  // 0000001D7614: D5207C26 0001000F
	v_ashrrev_i32_e32 v39, 31, v34                             // 0000001D761C: 344E449F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D7620: BF870214
	.long 0xd73c0024                                           // 0000001D7624: D73C0024
	v_cndmask_b32_e32 v1, 1, v32, vcc_lo                       // 0000001D7628: 02024081
	.long 0xd7006a20                                           // 0000001D762C: D7006A20
	v_cndmask_b32_e32 v1, v35, v34, vcc_lo                     // 0000001D7630: 02024523
	.long 0xd73c001e                                           // 0000001D7634: D73C001E
	v_cndmask_b32_e32 v1, 1, v30, vcc_lo                       // 0000001D7638: 02023C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001D763C: BF8700B4
	v_add_co_ci_u32_e64 v33, null, v38, v39, vcc_lo            // 0000001D7640: D5207C21 01AA4F26
	s_waitcnt lgkmcnt(0)                                       // 0000001D7648: BF89FC07
	s_barrier                                                  // 0000001D764C: BFBD0000
	.long 0xd73c0026                                           // 0000001D7650: D73C0026
	v_cndmask_b32_e32 v1, 1, v32, vcc_lo                       // 0000001D7654: 02024081
	s_clause 0x1                                               // 0000001D7658: BF850001
	global_load_u16 v55, v[50:51], off                         // 0000001D765C: DC4A0000 377C0032
	global_load_u16 v56, v[50:51], off offset:1024             // 0000001D7664: DC4A0400 387C0032
	.long 0xd7006a2e                                           // 0000001D766C: D7006A2E
	v_cndmask_b32_e32 v1, s10, v30, vcc_lo                     // 0000001D7670: 02023C0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D7674: BF8700A1
	v_add_co_ci_u32_e64 v47, null, s11, v31, vcc_lo            // 0000001D7678: D5207C2F 01AA3E0B
	.long 0xd7006a30                                           // 0000001D7680: D7006A30
	v_cndmask_b32_e32 v1, s10, v36, vcc_lo                     // 0000001D7684: 0202480A
	v_add_co_ci_u32_e64 v49, null, s11, v37, vcc_lo            // 0000001D7688: D5207C31 01AA4A0B
	.long 0xd7006a34                                           // 0000001D7690: D7006A34
	v_cndmask_b32_e32 v1, s10, v38, vcc_lo                     // 0000001D7694: 02024C0A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001D7698: BF870001
	v_add_co_ci_u32_e64 v53, null, s11, v39, vcc_lo            // 0000001D769C: D5207C35 01AA4E0B
	s_clause 0xb                                               // 0000001D76A4: BF85000B
	global_load_u16 v64, v[44:45], off                         // 0000001D76A8: DC4A0000 407C002C
	global_load_u16 v63, v[42:43], off                         // 0000001D76B0: DC4A0000 3F7C002A
	global_load_u16 v66, v[48:49], off                         // 0000001D76B8: DC4A0000 427C0030
	global_load_u16 v65, v[46:47], off                         // 0000001D76C0: DC4A0000 417C002E
	global_load_u16 v68, v[52:53], off offset:32               // 0000001D76C8: DC4A0020 447C0034
	global_load_u16 v67, v[50:51], off offset:32               // 0000001D76D0: DC4A0020 437C0032
	global_load_u16 v70, v[44:45], off offset:32               // 0000001D76D8: DC4A0020 467C002C
	global_load_u16 v69, v[42:43], off offset:32               // 0000001D76E0: DC4A0020 457C002A
	global_load_u16 v73, v[48:49], off offset:32               // 0000001D76E8: DC4A0020 497C0030
	global_load_u16 v74, v[46:47], off offset:32               // 0000001D76F0: DC4A0020 4A7C002E
	global_load_u16 v75, v[52:53], off offset:64               // 0000001D76F8: DC4A0040 4B7C0034
	global_load_u16 v76, v[50:51], off offset:64               // 0000001D7700: DC4A0040 4C7C0032
	.long 0xd7006a22                                           // 0000001D7708: D7006A22
	v_cndmask_b32_e32 v1, s12, v6, vcc_lo                      // 0000001D770C: 02020C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D7710: BF8700A1
	v_add_co_ci_u32_e64 v35, null, s13, v7, vcc_lo             // 0000001D7714: D5207C23 01AA0E0D
	.long 0xd7006a06                                           // 0000001D771C: D7006A06
	v_cndmask_b32_e32 v1, s12, v14, vcc_lo                     // 0000001D7720: 02021C0C
	v_add_co_ci_u32_e64 v7, null, s13, v15, vcc_lo             // 0000001D7724: D5207C07 01AA1E0D
	.long 0xd7006a0e                                           // 0000001D772C: D7006A0E
	v_cndmask_b32_e32 v1, s12, v22, vcc_lo                     // 0000001D7730: 02022C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D7734: BF8700A1
	v_add_co_ci_u32_e64 v15, null, s13, v23, vcc_lo            // 0000001D7738: D5207C0F 01AA2E0D
	.long 0xd7006a16                                           // 0000001D7740: D7006A16
	v_cndmask_b32_e32 v1, s12, v30, vcc_lo                     // 0000001D7744: 02023C0C
	v_add_co_ci_u32_e64 v23, null, s13, v31, vcc_lo            // 0000001D7748: D5207C17 01AA3E0D
	ds_load_b128 v[30:33], v136 offset:12816                   // 0000001D7750: DBFC3210 1E000088
	ds_load_b64 v[40:41], v136 offset:12832                    // 0000001D7758: D9D83220 28000088
	s_clause 0x9                                               // 0000001D7760: BF850009
	global_load_u16 v62, v[42:43], off offset:64               // 0000001D7764: DC4A0040 3E7C002A
	global_load_u16 v50, v[50:51], off offset:96               // 0000001D776C: DC4A0060 327C0032
	global_load_u16 v71, v[44:45], off offset:64               // 0000001D7774: DC4A0040 477C002C
	global_load_u16 v51, v[46:47], off offset:64               // 0000001D777C: DC4A0040 337C002E
	global_load_u16 v44, v[44:45], off offset:96               // 0000001D7784: DC4A0060 2C7C002C
	global_load_u16 v42, v[42:43], off offset:96               // 0000001D778C: DC4A0060 2A7C002A
	global_load_u16 v72, v[48:49], off offset:64               // 0000001D7794: DC4A0040 487C0030
	global_load_u16 v52, v[52:53], off offset:96               // 0000001D779C: DC4A0060 347C0034
	global_load_u16 v43, v[48:49], off offset:96               // 0000001D77A4: DC4A0060 2B7C0030
	global_load_u16 v45, v[46:47], off offset:96               // 0000001D77AC: DC4A0060 2D7C002E
	.long 0xd7006a24                                           // 0000001D77B4: D7006A24
	v_cndmask_b32_e32 v1, s12, v36, vcc_lo                     // 0000001D77B8: 0202480C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D77BC: BF8700A1
	v_add_co_ci_u32_e64 v37, null, s13, v37, vcc_lo            // 0000001D77C0: D5207C25 01AA4A0D
	.long 0xd7006a26                                           // 0000001D77C8: D7006A26
	v_cndmask_b32_e32 v1, s12, v38, vcc_lo                     // 0000001D77CC: 02024C0C
	v_add_co_ci_u32_e64 v39, null, s13, v39, vcc_lo            // 0000001D77D0: D5207C27 01AA4E0D
	s_waitcnt lgkmcnt(1)                                       // 0000001D77D8: BF89FC17
	v_mul_f32_e32 v26, v26, v32                                // 0000001D77DC: 1034411A
	v_mul_f32_e32 v24, v24, v30                                // 0000001D77E0: 10303D18
	v_mul_f32_e32 v16, v16, v30                                // 0000001D77E4: 10203D10
	s_waitcnt lgkmcnt(0)                                       // 0000001D77E8: BF89FC07
	v_mul_f32_e32 v28, v28, v40                                // 0000001D77EC: 1038511C
	v_dual_mul_f32 v18, v18, v32 :: v_dual_mul_f32 v29, v29, v41// 0000001D77F0: C8C64112 121C531D
	v_mul_f32_e32 v25, v25, v31                                // 0000001D77F8: 10323F19
	v_mul_f32_e32 v27, v27, v33                                // 0000001D77FC: 1036431B
	v_mul_f32_e32 v21, v21, v41                                // 0000001D7800: 102A5315
	v_mul_f32_e32 v17, v17, v31                                // 0000001D7804: 10223F11
	v_dual_mul_f32 v19, v19, v33 :: v_dual_mul_f32 v8, v8, v30 // 0000001D7808: C8C64313 13083D08
	v_mul_f32_e32 v10, v10, v32                                // 0000001D7810: 1014410A
	v_mul_f32_e32 v2, v2, v32                                  // 0000001D7814: 10044102
	v_mul_f32_e32 v12, v12, v40                                // 0000001D7818: 1018510C
	v_mul_f32_e32 v0, v0, v30                                  // 0000001D781C: 10003D00
	v_dual_mul_f32 v4, v4, v40 :: v_dual_mul_f32 v9, v9, v31   // 0000001D7820: C8C65104 04083F09
	v_mul_f32_e32 v11, v11, v33                                // 0000001D7828: 1016430B
	v_mul_f32_e32 v13, v13, v41                                // 0000001D782C: 101A530D
	v_mul_f32_e32 v1, v1, v31                                  // 0000001D7830: 10023F01
	v_mul_f32_e32 v3, v3, v33                                  // 0000001D7834: 10064303
	v_mul_f32_e32 v5, v5, v41                                  // 0000001D7838: 100A5305
	s_waitcnt vmcnt(23)                                        // 0000001D783C: BF895FF7
	v_lshlrev_b32_e32 v47, 16, v55                             // 0000001D7840: 305E6E90
	s_waitcnt vmcnt(20)                                        // 0000001D7844: BF8953F7
	v_lshlrev_b32_e32 v49, 16, v63                             // 0000001D7848: 30627E90
	s_waitcnt vmcnt(19)                                        // 0000001D784C: BF894FF7
	v_lshlrev_b32_e32 v53, 16, v66                             // 0000001D7850: 306A8490
	v_lshlrev_b32_e32 v46, 16, v56                             // 0000001D7854: 305C7090
	s_waitcnt vmcnt(18)                                        // 0000001D7858: BF894BF7
	v_lshlrev_b32_e32 v55, 16, v65                             // 0000001D785C: 306E8290
	s_waitcnt vmcnt(16)                                        // 0000001D7860: BF8943F7
	v_lshlrev_b32_e32 v63, 16, v67                             // 0000001D7864: 307E8690
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v47                  // 0000001D7868: 7C3C5EFF 42CE8ED0
	v_dual_mul_f32 v77, 0xbfb8aa3b, v53 :: v_dual_mul_f32 v20, v20, v40// 0000001D7870: C8C66AFF 4D145114 BFB8AA3B
	s_waitcnt vmcnt(13)                                        // 0000001D787C: BF8937F7
	v_dual_mul_f32 v73, 0xbfb8aa3b, v46 :: v_dual_lshlrev_b32 v66, 16, v73// 0000001D7880: C8E25CFF 49429290 BFB8AA3B
	v_lshlrev_b32_e32 v65, 16, v69                             // 0000001D788C: 30828A90
	s_waitcnt vmcnt(10)                                        // 0000001D7890: BF892BF7
	v_lshlrev_b32_e32 v69, 16, v76                             // 0000001D7894: 308A9890
	v_fma_f32 v96, 0xbfb8aa3b, v53, -v77                       // 0000001D7898: D6130060 85366AFF BFB8AA3B
	v_rndne_f32_e32 v97, v77                                   // 0000001D78A4: 7EC2474D
	v_rndne_f32_e32 v89, v73                                   // 0000001D78A8: 7EB24749
	v_lshlrev_b32_e32 v56, 16, v68                             // 0000001D78AC: 30708890
	v_fma_f32 v88, 0xbfb8aa3b, v46, -v73                       // 0000001D78B0: D6130058 85265CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D78BC: BF870214
	v_dual_mul_f32 v78, 0xbfb8aa3b, v63 :: v_dual_sub_f32 v77, v77, v97// 0000001D78C0: C8CA7EFF 4E4CC34D BFB8AA3B
	v_sub_f32_e32 v73, v73, v89                                // 0000001D78CC: 0892B349
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001D78D0: BF8701C4
	v_mul_f32_e32 v79, 0xbfb8aa3b, v56                         // 0000001D78D4: 109E70FF BFB8AA3B
	v_dual_mul_f32 v83, 0xbfb8aa3b, v66 :: v_dual_lshlrev_b32 v48, 16, v64// 0000001D78DC: C8E284FF 53308090 BFB8AA3B
	v_lshlrev_b32_e32 v64, 16, v70                             // 0000001D78E8: 30808C90
	v_mul_f32_e32 v70, 0xbfb8aa3b, v47                         // 0000001D78EC: 108C5EFF BFB8AA3B
	v_dual_mul_f32 v75, 0xbfb8aa3b, v48 :: v_dual_lshlrev_b32 v68, 16, v75// 0000001D78F4: C8E260FF 4B449690 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D7900: BF870214
	v_rndne_f32_e32 v109, v83                                  // 0000001D7904: 7EDA4753
	v_mul_f32_e32 v81, 0xbfb8aa3b, v64                         // 0000001D7908: 10A280FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D7910: BF870004
	v_fma_f32 v86, 0xbfb8aa3b, v47, -v70                       // 0000001D7914: D6130056 851A5EFF BFB8AA3B
	v_rndne_f32_e32 v87, v70                                   // 0000001D7920: 7EAE4746
	v_fma_f32 v108, 0xbfb8aa3b, v66, -v83                      // 0000001D7924: D613006C 854E84FF BFB8AA3B
	v_fmac_f32_e32 v96, 0xb2a5705f, v53                        // 0000001D7930: 56C06AFF B2A5705F
	v_rndne_f32_e32 v105, v81                                  // 0000001D7938: 7ED24751
	v_fmac_f32_e32 v86, 0xb2a5705f, v47                        // 0000001D793C: 56AC5EFF B2A5705F
	v_dual_sub_f32 v70, v70, v87 :: v_dual_sub_f32 v83, v83, v109// 0000001D7944: C94AAF46 4652DB53
	v_fma_f32 v104, 0xbfb8aa3b, v64, -v81                      // 0000001D794C: D6130068 854680FF BFB8AA3B
	v_dual_fmac_f32 v88, 0xb2a5705f, v46 :: v_dual_add_f32 v77, v77, v96// 0000001D7958: C8085CFF 584CC14D B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D7964: BF870233
	v_dual_sub_f32 v81, v81, v105 :: v_dual_add_f32 v70, v70, v86// 0000001D7968: C948D351 5146AD46
	v_dual_mul_f32 v74, 0xbfb8aa3b, v49 :: v_dual_lshlrev_b32 v67, 16, v74// 0000001D7970: C8E262FF 4A429490 BFB8AA3B
	v_dual_mul_f32 v85, 0xbfb8aa3b, v68 :: v_dual_mul_f32 v80, 0xbfb8aa3b, v65// 0000001D797C: C8C688FF 555082FF BFB8AA3B
	v_add_f32_e32 v73, v73, v88                                // 0000001D7988: 0692B149
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D798C: BF870194
	v_exp_f32_e32 v70, v70                                     // 0000001D7990: 7E8C4B46
	v_fma_f32 v90, 0xbfb8aa3b, v49, -v74                       // 0000001D7994: D613005A 852A62FF BFB8AA3B
	v_rndne_f32_e32 v91, v74                                   // 0000001D79A0: 7EB6474A
	v_fma_f32 v100, 0xbfb8aa3b, v56, -v79                      // 0000001D79A4: D6130064 853E70FF BFB8AA3B
	v_rndne_f32_e32 v101, v79                                  // 0000001D79B0: 7ECA474F
	v_cvt_i32_f32_e32 v87, v87                                 // 0000001D79B4: 7EAE1157
	v_exp_f32_e32 v73, v73                                     // 0000001D79B8: 7E924B49
	v_mul_f32_e32 v82, 0xbfb8aa3b, v67                         // 0000001D79BC: 10A486FF BFB8AA3B
	v_fma_f32 v92, 0xbfb8aa3b, v48, -v75                       // 0000001D79C4: D613005C 852E60FF BFB8AA3B
	v_rndne_f32_e32 v93, v75                                   // 0000001D79D0: 7EBA474B
	v_mul_f32_e32 v76, 0xbfb8aa3b, v55                         // 0000001D79D4: 10986EFF BFB8AA3B
	v_cvt_i32_f32_e32 v89, v89                                 // 0000001D79DC: 7EB21159
	v_dual_fmac_f32 v100, 0xb2a5705f, v56 :: v_dual_sub_f32 v79, v79, v101// 0000001D79E0: C80A70FF 644ECB4F B2A5705F
	v_fmac_f32_e32 v90, 0xb2a5705f, v49                        // 0000001D79EC: 56B462FF B2A5705F
	v_fmac_f32_e32 v104, 0xb2a5705f, v64                       // 0000001D79F4: 56D080FF B2A5705F
	v_sub_f32_e32 v74, v74, v91                                // 0000001D79FC: 0894B74A
	v_exp_f32_e32 v77, v77                                     // 0000001D7A00: 7E9A4B4D
	.long 0xd71c0046                                           // 0000001D7A04: D71C0046
	v_cndmask_b32_e32 v1, v70, v87, vcc_lo                     // 0000001D7A08: 0202AF46
	v_sub_f32_e32 v75, v75, v93                                // 0000001D7A0C: 0896BB4B
	v_fma_f32 v94, 0xbfb8aa3b, v55, -v76                       // 0000001D7A10: D613005E 85326EFF BFB8AA3B
	v_rndne_f32_e32 v95, v76                                   // 0000001D7A1C: 7EBE474C
	v_cvt_i32_f32_e32 v97, v97                                 // 0000001D7A20: 7EC21161
	v_add_f32_e32 v79, v79, v100                               // 0000001D7A24: 069EC94F
	v_dual_add_f32 v81, v81, v104 :: v_dual_add_f32 v74, v74, v90// 0000001D7A28: C908D151 514AB54A
	.long 0xd71c0049                                           // 0000001D7A30: D71C0049
	v_cndmask_b32_e32 v1, v73, v89, vcc_lo                     // 0000001D7A34: 0202B349
	v_cndmask_b32_e32 v70, 0, v70, vcc_lo                      // 0000001D7A38: 028C8C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 0000001D7A3C: 7C3C5CFF 42CE8ED0
	v_fmac_f32_e32 v92, 0xb2a5705f, v48                        // 0000001D7A44: 56B860FF B2A5705F
	v_fmac_f32_e32 v108, 0xb2a5705f, v66                       // 0000001D7A4C: 56D884FF B2A5705F
	v_fmac_f32_e32 v94, 0xb2a5705f, v55                        // 0000001D7A54: 56BC6EFF B2A5705F
	v_exp_f32_e32 v74, v74                                     // 0000001D7A5C: 7E944B4A
	v_exp_f32_e32 v81, v81                                     // 0000001D7A60: 7EA24B51
	.long 0xd71c004d                                           // 0000001D7A64: D71C004D
	v_cndmask_b32_e32 v1, v77, v97, vcc_lo                     // 0000001D7A68: 0202C34D
	v_dual_sub_f32 v76, v76, v95 :: v_dual_cndmask_b32 v73, 0, v73// 0000001D7A6C: C952BF4C 4C489280
	v_dual_mul_f32 v84, 0xbfb8aa3b, v69 :: v_dual_add_f32 v75, v75, v92// 0000001D7A74: C8C88AFF 544AB94B BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v63, -v78                       // 0000001D7A80: D6130062 853A7EFF BFB8AA3B
	v_rndne_f32_e32 v99, v78                                   // 0000001D7A8C: 7EC6474E
	v_cvt_i32_f32_e32 v91, v91                                 // 0000001D7A90: 7EB6115B
	v_cvt_i32_f32_e32 v105, v105                               // 0000001D7A94: 7ED21169
	v_dual_add_f32 v83, v83, v108 :: v_dual_add_f32 v76, v76, v94// 0000001D7A98: C908D953 534CBD4C
	v_exp_f32_e32 v75, v75                                     // 0000001D7AA0: 7E964B4B
	v_cvt_i32_f32_e32 v93, v93                                 // 0000001D7AA4: 7EBA115D
	v_sub_f32_e32 v78, v78, v99                                // 0000001D7AA8: 089CC74E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D7AAC: BF870003
	v_exp_f32_e32 v83, v83                                     // 0000001D7AB0: 7EA64B53
	v_exp_f32_e32 v76, v76                                     // 0000001D7AB4: 7E984B4C
	.long 0xd71c004a                                           // 0000001D7AB8: D71C004A
	v_cndmask_b32_e32 v1, v74, v91, vcc_lo                     // 0000001D7ABC: 0202B74A
	.long 0xd71c0051                                           // 0000001D7AC0: D71C0051
	v_cndmask_b32_e32 v1, v81, v105, vcc_lo                    // 0000001D7AC4: 0202D351
	v_fmac_f32_e32 v98, 0xb2a5705f, v63                        // 0000001D7AC8: 56C47EFF B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001D7AD0: 7C3C62FF 42CE8ED0
	v_fma_f32 v102, 0xbfb8aa3b, v65, -v80                      // 0000001D7AD8: D6130066 854282FF BFB8AA3B
	v_rndne_f32_e32 v103, v80                                  // 0000001D7AE4: 7ECE4750
	v_cvt_i32_f32_e32 v95, v95                                 // 0000001D7AE8: 7EBE115F
	v_cvt_i32_f32_e32 v109, v109                               // 0000001D7AEC: 7EDA116D
	v_add_f32_e32 v78, v78, v98                                // 0000001D7AF0: 069CC54E
	.long 0xd71c004b                                           // 0000001D7AF4: D71C004B
	v_cndmask_b32_e32 v1, v75, v93, vcc_lo                     // 0000001D7AF8: 0202BB4B
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000001D7AFC: 02949480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 0000001D7B00: 7C3C60FF 42CE8ED0
	v_sub_f32_e32 v80, v80, v103                               // 0000001D7B08: 08A0CF50
	v_exp_f32_e32 v78, v78                                     // 0000001D7B0C: 7E9C4B4E
	.long 0xd71c004c                                           // 0000001D7B10: D71C004C
	v_cndmask_b32_e32 v1, v76, v95, vcc_lo                     // 0000001D7B14: 0202BF4C
	.long 0xd71c0053                                           // 0000001D7B18: D71C0053
	v_cndmask_b32_e32 v1, v83, v109, vcc_lo                    // 0000001D7B1C: 0202DB53
	v_dual_fmac_f32 v102, 0xb2a5705f, v65 :: v_dual_cndmask_b32 v75, 0, v75// 0000001D7B20: C81282FF 664A9680 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v55                  // 0000001D7B2C: 7C3C6EFF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v67, -v82                      // 0000001D7B34: D613006A 854A86FF BFB8AA3B
	v_rndne_f32_e32 v107, v82                                  // 0000001D7B40: 7ED64752
	v_cvt_i32_f32_e32 v99, v99                                 // 0000001D7B44: 7EC61163
	v_add_f32_e32 v80, v80, v102                               // 0000001D7B48: 06A0CD50
	v_exp_f32_e32 v79, v79                                     // 0000001D7B4C: 7E9E4B4F
	v_cndmask_b32_e32 v76, 0, v76, vcc_lo                      // 0000001D7B50: 02989880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v53                  // 0000001D7B54: 7C3C6AFF 42CE8ED0
	v_cvt_i32_f32_e32 v101, v101                               // 0000001D7B5C: 7ECA1165
	v_fmac_f32_e32 v106, 0xb2a5705f, v67                       // 0000001D7B60: 56D486FF B2A5705F
	v_sub_f32_e32 v82, v82, v107                               // 0000001D7B68: 08A4D752
	v_exp_f32_e32 v80, v80                                     // 0000001D7B6C: 7EA04B50
	.long 0xd71c004e                                           // 0000001D7B70: D71C004E
	v_cndmask_b32_e32 v1, v78, v99, vcc_lo                     // 0000001D7B74: 0202C74E
	v_cndmask_b32_e32 v77, 0, v77, vcc_lo                      // 0000001D7B78: 029A9A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v63                  // 0000001D7B7C: 7C3C7EFF 42CE8ED0
	v_cvt_i32_f32_e32 v103, v103                               // 0000001D7B84: 7ECE1167
	v_add_f32_e32 v82, v82, v106                               // 0000001D7B88: 06A4D552
	.long 0xd71c004f                                           // 0000001D7B8C: D71C004F
	v_cndmask_b32_e32 v1, v79, v101, vcc_lo                    // 0000001D7B90: 0202CB4F
	v_cvt_i32_f32_e32 v107, v107                               // 0000001D7B94: 7ED6116B
	v_cndmask_b32_e32 v78, 0, v78, vcc_lo                      // 0000001D7B98: 029C9C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 0000001D7B9C: 7C3C70FF 42CE8ED0
	v_exp_f32_e32 v82, v82                                     // 0000001D7BA4: 7EA44B52
	.long 0xd71c0050                                           // 0000001D7BA8: D71C0050
	v_cndmask_b32_e32 v1, v80, v103, vcc_lo                    // 0000001D7BAC: 0202CF50
	v_rndne_f32_e32 v111, v84                                  // 0000001D7BB0: 7EDE4754
	v_fma_f32 v110, 0xbfb8aa3b, v69, -v84                      // 0000001D7BB4: D613006E 85528AFF BFB8AA3B
	v_cndmask_b32_e32 v79, 0, v79, vcc_lo                      // 0000001D7BC0: 029E9E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000001D7BC4: 7C3C82FF 42CE8ED0
	v_fma_f32 v112, 0xbfb8aa3b, v68, -v85                      // 0000001D7BCC: D6130070 855688FF BFB8AA3B
	v_rndne_f32_e32 v113, v85                                  // 0000001D7BD8: 7EE24755
	s_waitcnt vmcnt(1)                                         // 0000001D7BDC: BF8907F7
	v_lshlrev_b32_e32 v32, 16, v43                             // 0000001D7BE0: 30405690
	v_cndmask_b32_e32 v80, 0, v80, vcc_lo                      // 0000001D7BE4: 02A0A080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 0000001D7BE8: 7C3C80FF 42CE8ED0
	.long 0xd71c0052                                           // 0000001D7BF0: D71C0052
	v_cndmask_b32_e32 v1, v82, v107, vcc_lo                    // 0000001D7BF4: 0202D752
	v_dual_fmac_f32 v112, 0xb2a5705f, v68 :: v_dual_cndmask_b32 v81, 0, v81// 0000001D7BF8: C81288FF 7050A280 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v67                  // 0000001D7C04: 7C3C86FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D7C0C: BF870003
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000001D7C10: 02A4A480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v66                  // 0000001D7C14: 7C3C84FF 42CE8ED0
	v_cndmask_b32_e32 v83, 0, v83, vcc_lo                      // 0000001D7C1C: 02A6A680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v47                  // 0000001D7C20: 7C365EFF C2B17218
	v_cndmask_b32_e32 v47, 0x7f800000, v70, vcc_lo             // 0000001D7C28: 025E8CFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 0000001D7C30: 7C365CFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D7C38: BF870122
	v_dual_add_f32 v47, 1.0, v47 :: v_dual_cndmask_b32 v46, 0x7f800000, v73// 0000001D7C3C: C9125EF2 2F2E92FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001D7C48: 7C3662FF C2B17218
	v_div_scale_f32 v70, null, v47, v47, v24                   // 0000001D7C50: D6FC7C46 04625F2F
	v_cndmask_b32_e32 v49, 0x7f800000, v74, vcc_lo             // 0000001D7C58: 026294FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 0000001D7C60: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D7C68: BF870113
	v_rcp_f32_e32 v98, v70                                     // 0000001D7C6C: 7EC45546
	v_dual_add_f32 v49, 1.0, v49 :: v_dual_cndmask_b32 v48, 0x7f800000, v75// 0000001D7C70: C91262F2 313096FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v55                  // 0000001D7C7C: 7C366EFF C2B17218
	v_cndmask_b32_e32 v55, 0x7f800000, v76, vcc_lo             // 0000001D7C84: 026E98FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v53                  // 0000001D7C8C: 7C366AFF C2B17218
	v_sub_f32_e32 v84, v84, v111                               // 0000001D7C94: 08A8DF54
	v_fmac_f32_e32 v110, 0xb2a5705f, v69                       // 0000001D7C98: 56DC8AFF B2A5705F
	v_div_scale_f32 v76, null, v49, v49, v26                   // 0000001D7CA0: D6FC7C4C 046A6331
	v_add_f32_e32 v55, 1.0, v55                                // 0000001D7CA8: 066E6EF2
	v_cndmask_b32_e32 v53, 0x7f800000, v77, vcc_lo             // 0000001D7CAC: 026A9AFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v63                  // 0000001D7CB4: 7C367EFF C2B17218
	v_div_scale_f32 v77, s1, v26, v49, v26                     // 0000001D7CBC: D6FC014D 046A631A
	v_rcp_f32_e32 v100, v76                                    // 0000001D7CC4: 7EC8554C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001D7CC8: BF870133
	v_add_f32_e32 v53, 1.0, v53                                // 0000001D7CCC: 066A6AF2
	v_cndmask_b32_e32 v63, 0x7f800000, v78, vcc_lo             // 0000001D7CD0: 027E9CFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 0000001D7CD8: 7C3670FF C2B17218
	v_add_f32_e32 v63, 1.0, v63                                // 0000001D7CE0: 067E7EF2
	v_cndmask_b32_e32 v56, 0x7f800000, v79, vcc_lo             // 0000001D7CE4: 02709EFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000001D7CEC: 7C3682FF C2B17218
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D7CF4: BF870215
	v_fma_f32 v115, -v76, v100, 1.0                            // 0000001D7CF8: D6130073 23CAC94C
	v_div_scale_f32 v86, null, v63, v63, v16                   // 0000001D7D00: D6FC7C56 04427F3F
	v_div_scale_f32 v87, s5, v16, v63, v16                     // 0000001D7D08: D6FC0557 04427F10
	v_cndmask_b32_e32 v65, 0x7f800000, v80, vcc_lo             // 0000001D7D10: 0282A0FF 7F800000
	v_div_scale_f32 v80, null, v55, v55, v28                   // 0000001D7D18: D6FC7C50 04726F37
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 0000001D7D20: 7C3680FF C2B17218
	v_rcp_f32_e32 v104, v86                                    // 0000001D7D28: 7ED05556
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D7D2C: BF870193
	v_dual_fmac_f32 v100, v115, v100 :: v_dual_add_f32 v65, 1.0, v65// 0000001D7D30: C808C973 644082F2
	v_rcp_f32_e32 v102, v80                                    // 0000001D7D38: 7ECC5550
	v_cndmask_b32_e32 v64, 0x7f800000, v81, vcc_lo             // 0000001D7D3C: 0280A2FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v67                  // 0000001D7D44: 7C3686FF C2B17218
	v_div_scale_f32 v81, s3, v28, v55, v28                     // 0000001D7D4C: D6FC0351 04726F1C
	v_mul_f32_e32 v115, v77, v100                              // 0000001D7D54: 10E6C94D
	v_div_scale_f32 v90, null, v65, v65, v18                   // 0000001D7D58: D6FC7C5A 044A8341
	v_div_scale_f32 v91, s7, v18, v65, v18                     // 0000001D7D60: D6FC075B 044A8312
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001D7D68: BF870256
	v_fma_f32 v119, -v86, v104, 1.0                            // 0000001D7D6C: D6130077 23CAD156
	v_cndmask_b32_e32 v67, 0x7f800000, v82, vcc_lo             // 0000001D7D74: 0286A4FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v66                  // 0000001D7D7C: 7C3684FF C2B17218
	v_fma_f32 v117, -v80, v102, 1.0                            // 0000001D7D84: D6130075 23CACD50
	v_div_scale_f32 v82, null, v53, v53, v29                   // 0000001D7D8C: D6FC7C52 04766B35
	v_dual_fmac_f32 v104, v119, v104 :: v_dual_add_f32 v67, 1.0, v67// 0000001D7D94: C808D177 684286F2
	v_fma_f32 v126, -v76, v115, v77                            // 0000001D7D9C: D613007E 2536E74C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D7DA4: BF870194
	v_fmac_f32_e32 v102, v117, v102                            // 0000001D7DA8: 56CCCD75
	v_dual_cndmask_b32 v66, 0x7f800000, v83 :: v_dual_mul_f32 v119, v87, v104// 0000001D7DAC: CA46A6FF 4276D157 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D7DB8: BF8701A4
	v_div_scale_f32 v94, null, v67, v67, v20                   // 0000001D7DBC: D6FC7C5E 04528743
	v_rcp_f32_e32 v103, v82                                    // 0000001D7DC4: 7ECE5552
	v_mul_f32_e32 v117, v81, v102                              // 0000001D7DC8: 10EACD51
	v_fmac_f32_e32 v115, v126, v100                            // 0000001D7DCC: 56E6C97E
	v_fma_f32 v130, -v86, v119, v87                            // 0000001D7DD0: D6130082 255EEF56
	v_add_f32_e32 v46, 1.0, v46                                // 0000001D7DD8: 065C5CF2
	v_add_f32_e32 v66, 1.0, v66                                // 0000001D7DDC: 068484F2
	v_fma_f32 v128, -v80, v117, v81                            // 0000001D7DE0: D6130080 2546EB50
	v_add_f32_e32 v48, 1.0, v48                                // 0000001D7DE8: 066060F2
	v_fmac_f32_e32 v119, v130, v104                            // 0000001D7DEC: 56EED182
	v_div_scale_f32 v74, null, v46, v46, v25                   // 0000001D7DF0: D6FC7C4A 04665D2E
	v_rcp_f32_e32 v108, v94                                    // 0000001D7DF8: 7ED8555E
	v_fmac_f32_e32 v117, v128, v102                            // 0000001D7DFC: 56EACD80
	v_div_scale_f32 v78, null, v48, v48, v27                   // 0000001D7E00: D6FC7C4E 046E6130
	v_div_scale_f32 v96, null, v66, v66, v21                   // 0000001D7E08: D6FC7C60 04568542
	v_rcp_f32_e32 v99, v74                                     // 0000001D7E10: 7EC6554A
	v_fma_f32 v118, -v82, v103, 1.0                            // 0000001D7E14: D6130076 23CACF52
	v_add_f32_e32 v84, v84, v110                               // 0000001D7E1C: 06A8DD54
	v_rcp_f32_e32 v101, v78                                    // 0000001D7E20: 7ECA554E
	v_rcp_f32_e32 v109, v96                                    // 0000001D7E24: 7EDA5560
	v_fma_f32 v110, -v70, v98, 1.0                             // 0000001D7E28: D613006E 23CAC546
	v_fma_f32 v123, -v94, v108, 1.0                            // 0000001D7E30: D613007B 23CAD95E
	v_div_scale_f32 v73, vcc_lo, v24, v47, v24                 // 0000001D7E38: D6FC6A49 04625F18
	v_div_scale_f32 v75, s0, v25, v46, v25                     // 0000001D7E40: D6FC004B 04665D19
	v_div_scale_f32 v95, s9, v20, v67, v20                     // 0000001D7E48: D6FC095F 04528714
	v_fma_f32 v114, -v74, v99, 1.0                             // 0000001D7E50: D6130072 23CAC74A
	v_fmac_f32_e32 v98, v110, v98                              // 0000001D7E58: 56C4C56E
	v_fmac_f32_e32 v108, v123, v108                            // 0000001D7E5C: 56D8D97B
	v_fma_f32 v116, -v78, v101, 1.0                            // 0000001D7E60: D6130074 23CACB4E
	v_fma_f32 v124, -v96, v109, 1.0                            // 0000001D7E68: D613007C 23CADB60
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001D7E70: BF8701C4
	v_dual_fmac_f32 v99, v114, v99 :: v_dual_mul_f32 v110, v73, v98// 0000001D7E74: C806C772 636EC549
	v_rcp_f32_e32 v106, v90                                    // 0000001D7E7C: 7ED4555A
	v_mul_f32_e32 v123, v95, v108                              // 0000001D7E80: 10F6D95F
	v_div_scale_f32 v79, s2, v27, v48, v27                     // 0000001D7E84: D6FC024F 046E611B
	v_dual_mul_f32 v114, v75, v99 :: v_dual_fmac_f32 v101, v116, v101// 0000001D7E8C: C8C0C74B 7264CB74
	v_fmac_f32_e32 v109, v124, v109                            // 0000001D7E94: 56DADB7C
	v_fma_f32 v124, -v70, v110, v73                            // 0000001D7E98: D613007C 2526DD46
	v_div_scale_f32 v83, s4, v29, v53, v29                     // 0000001D7EA0: D6FC0453 04766B1D
	v_fmac_f32_e32 v103, v118, v103                            // 0000001D7EA8: 56CECF76
	v_fma_f32 v125, -v74, v114, v75                            // 0000001D7EAC: D613007D 252EE54A
	v_mul_f32_e32 v116, v79, v101                              // 0000001D7EB4: 10E8CB4F
	v_fmac_f32_e32 v110, v124, v98                             // 0000001D7EB8: 56DCC57C
	v_fma_f32 v121, -v90, v106, 1.0                            // 0000001D7EBC: D6130079 23CAD55A
	v_mul_f32_e32 v118, v83, v103                              // 0000001D7EC4: 10ECCF53
	v_fmac_f32_e32 v114, v125, v99                             // 0000001D7EC8: 56E4C77D
	v_fma_f32 v127, -v78, v116, v79                            // 0000001D7ECC: D613007F 253EE94E
	v_fma_f32 v70, -v70, v110, v73                             // 0000001D7ED4: D6130046 2526DD46
	v_fmac_f32_e32 v106, v121, v106                            // 0000001D7EDC: 56D4D579
	v_fma_f32 v129, -v82, v118, v83                            // 0000001D7EE0: D6130081 254EED52
	v_fma_f32 v73, -v74, v114, v75                             // 0000001D7EE8: D6130049 252EE54A
	v_fmac_f32_e32 v116, v127, v101                            // 0000001D7EF0: 56E8CB7F
	v_div_fmas_f32 v70, v70, v98, v110                         // 0000001D7EF4: D6370046 05BAC546
	s_mov_b32 vcc_lo, s0                                       // 0000001D7EFC: BEEA0000
	v_fma_f32 v74, -v76, v115, v77                             // 0000001D7F00: D613004A 2536E74C
	v_dual_mul_f32 v121, v91, v106 :: v_dual_fmac_f32 v118, v129, v103// 0000001D7F08: C8C0D55B 7976CF81
	v_div_fmas_f32 v73, v73, v99, v114                         // 0000001D7F10: D6370049 05CAC749
	v_fma_f32 v75, -v78, v116, v79                             // 0000001D7F18: D613004B 253EE94E
	s_mov_b32 vcc_lo, s1                                       // 0000001D7F20: BEEA0001
	v_fma_f32 v76, -v80, v117, v81                             // 0000001D7F24: D613004C 2546EB50
	v_div_fmas_f32 v74, v74, v100, v115                        // 0000001D7F2C: D637004A 05CEC94A
	s_mov_b32 vcc_lo, s2                                       // 0000001D7F34: BEEA0002
	v_fma_f32 v132, -v90, v121, v91                            // 0000001D7F38: D6130084 256EF35A
	v_add_f32_e32 v56, 1.0, v56                                // 0000001D7F40: 067070F2
	v_fma_f32 v77, -v82, v118, v83                             // 0000001D7F44: D613004D 254EED52
	v_div_fixup_f32 v25, v73, v46, v25                         // 0000001D7F4C: D6270019 04665D49
	v_div_fixup_f32 v24, v70, v47, v24                         // 0000001D7F54: D6270018 04625F46
	v_div_fmas_f32 v47, v75, v101, v116                        // 0000001D7F5C: D637002F 05D2CB4B
	s_mov_b32 vcc_lo, s3                                       // 0000001D7F64: BEEA0003
	v_fmac_f32_e32 v121, v132, v106                            // 0000001D7F68: 56F2D584
	v_div_fmas_f32 v46, v76, v102, v117                        // 0000001D7F6C: D637002E 05D6CD4C
	s_mov_b32 vcc_lo, s4                                       // 0000001D7F74: BEEA0004
	v_div_scale_f32 v88, null, v56, v56, v17                   // 0000001D7F78: D6FC7C58 04467138
	v_div_fixup_f32 v26, v74, v49, v26                         // 0000001D7F80: D627001A 046A634A
	v_div_fmas_f32 v49, v77, v103, v118                        // 0000001D7F88: D6370031 05DACF4D
	.long 0x7e6c3999                                           // 0000001D7F90: 7E6C3999
	v_add_f32_e32 v64, 1.0, v64                                // 0000001D7F94: 068080F2
	v_rcp_f32_e32 v105, v88                                    // 0000001D7F98: 7ED25558
	v_div_scale_f32 v89, s6, v17, v56, v17                     // 0000001D7F9C: D6FC0659 04467111
	v_div_fixup_f32 v29, v49, v53, v29                         // 0000001D7FA4: D627001D 04766B31
	v_and_b32_e32 v53, 1, v54                                  // 0000001D7FAC: 366A6C81
	v_div_scale_f32 v92, null, v64, v64, v19                   // 0000001D7FB0: D6FC7C5C 044E8140
	v_div_scale_f32 v93, s8, v19, v64, v19                     // 0000001D7FB8: D6FC085D 044E8113
	v_fma_f32 v78, -v86, v119, v87                             // 0000001D7FC0: D613004E 255EEF56
	v_div_fixup_f32 v27, v47, v48, v27                         // 0000001D7FC8: D627001B 046E612F
	s_mov_b32 vcc_lo, s5                                       // 0000001D7FD0: BEEA0005
	v_rcp_f32_e32 v107, v92                                    // 0000001D7FD4: 7ED6555C
	v_fma_f32 v120, -v88, v105, 1.0                            // 0000001D7FD8: D6130078 23CAD358
	v_fma_f32 v80, -v90, v121, v91                             // 0000001D7FE0: D6130050 256EF35A
	v_div_fmas_f32 v47, v78, v104, v119                        // 0000001D7FE8: D637002F 05DED14E
	s_mov_b32 vcc_lo, s6                                       // 0000001D7FF0: BEEA0006
	.long 0x7e7a3998                                           // 0000001D7FF4: 7E7A3998
	v_fmac_f32_e32 v105, v120, v105                            // 0000001D7FF8: 56D2D378
	v_div_fixup_f32 v28, v46, v55, v28                         // 0000001D7FFC: D627001C 04726F2E
	.long 0x7e6c399b                                           // 0000001D8004: 7E6C399B
	v_div_fixup_f32 v16, v47, v63, v16                         // 0000001D8008: D6270010 04427F2F
	v_fma_f32 v122, -v92, v107, 1.0                            // 0000001D8010: D613007A 23CAD75C
	v_mul_f32_e32 v120, v89, v105                              // 0000001D8018: 10F0D359
	v_and_b32_e32 v48, 1, v61                                  // 0000001D801C: 36607A81
	.long 0x7e78399a                                           // 0000001D8020: 7E78399A
	.long 0x7e76399c                                           // 0000001D8024: 7E76399C
	v_fmac_f32_e32 v107, v122, v107                            // 0000001D8028: 56D6D77A
	v_fma_f32 v131, -v88, v120, v89                            // 0000001D802C: D6130083 2566F158
	v_add3_u32 v24, v24, v48, 0x7fff                           // 0000001D8034: D6550018 03FE6118 00007FFF
	.long 0x7e743990                                           // 0000001D8040: 7E743990
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D8044: BF870214
	v_dual_mul_f32 v122, v93, v107 :: v_dual_and_b32 v55, 1, v60// 0000001D8048: C8E4D75D 7A367881
	v_fmac_f32_e32 v120, v131, v105                            // 0000001D8050: 56F0D383
	v_add3_u32 v25, v25, v53, 0x7fff                           // 0000001D8054: D6550019 03FE6B19 00007FFF
	v_and_b32_e32 v48, 1, v59                                  // 0000001D8060: 36607681
	s_clause 0x1                                               // 0000001D8064: BF850001
	global_store_d16_hi_b16 v[34:35], v24, off                 // 0000001D8068: DC960000 007C1822
	global_store_d16_hi_b16 v[34:35], v25, off offset:1024     // 0000001D8070: DC960400 007C1922
	v_fma_f32 v133, -v92, v122, v93                            // 0000001D8078: D6130085 2576F55C
	v_fma_f32 v79, -v88, v120, v89                             // 0000001D8080: D613004F 2566F158
	v_and_b32_e32 v24, 1, v58                                  // 0000001D8088: 36307481
	v_add3_u32 v26, v26, v55, 0x7fff                           // 0000001D808C: D655001A 03FE6F1A 00007FFF
	v_add3_u32 v28, v28, v48, 0x7fff                           // 0000001D8098: D655001C 03FE611C 00007FFF
	v_fmac_f32_e32 v122, v133, v107                            // 0000001D80A4: 56F4D785
	v_div_fmas_f32 v46, v79, v105, v120                        // 0000001D80A8: D637002E 05E2D34F
	s_mov_b32 vcc_lo, s7                                       // 0000001D80B0: BEEA0007
	v_exp_f32_e32 v84, v84                                     // 0000001D80B4: 7EA84B54
	v_div_fmas_f32 v49, v80, v106, v121                        // 0000001D80B8: D6370031 05E6D550
	v_fma_f32 v81, -v92, v122, v93                             // 0000001D80C0: D6130051 2576F55C
	s_mov_b32 vcc_lo, s8                                       // 0000001D80C8: BEEA0008
	v_div_fixup_f32 v17, v46, v56, v17                         // 0000001D80CC: D6270011 0446712E
	v_and_b32_e32 v46, 1, v54                                  // 0000001D80D4: 365C6C81
	.long 0x7e6c399d                                           // 0000001D80D8: 7E6C399D
	v_div_fmas_f32 v47, v81, v107, v122                        // 0000001D80DC: D637002F 05EAD751
	v_add3_u32 v16, v16, v24, 0x7fff                           // 0000001D80E4: D6550010 03FE3110 00007FFF
	v_div_scale_f32 v97, s10, v21, v66, v21                    // 0000001D80F0: D6FC0A61 04568515
	v_add3_u32 v25, v27, v46, 0x7fff                           // 0000001D80F8: D6550019 03FE5D1B 00007FFF
	v_cvt_i32_f32_e32 v24, v111                                // 0000001D8104: 7E30116F
	v_div_fixup_f32 v19, v47, v64, v19                         // 0000001D8108: D6270013 044E812F
	v_and_b32_e32 v47, 1, v54                                  // 0000001D8110: 365E6C81
	.long 0x7e6c3991                                           // 0000001D8114: 7E6C3991
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v69                  // 0000001D8118: 7C3C8AFF 42CE8ED0
	.long 0xd71c0018                                           // 0000001D8120: D71C0018
	v_cndmask_b32_e32 v1, v84, v24, vcc_lo                     // 0000001D8124: 02023154
	v_div_fixup_f32 v18, v49, v65, v18                         // 0000001D8128: D6270012 044A8331
	v_add3_u32 v29, v29, v47, 0x7fff                           // 0000001D8130: D655001D 03FE5F1D 00007FFF
	v_and_b32_e32 v27, 1, v54                                  // 0000001D813C: 36366C81
	.long 0x7e6c3993                                           // 0000001D8140: 7E6C3993
	v_cndmask_b32_e32 v24, 0, v24, vcc_lo                      // 0000001D8144: 02303080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v69                  // 0000001D8148: 7C368AFF C2B17218
	.long 0x7e723992                                           // 0000001D8150: 7E723992
	v_add3_u32 v17, v17, v27, 0x7fff                           // 0000001D8154: D6550011 03FE3711 00007FFF
	s_clause 0x5                                               // 0000001D8160: BF850005
	global_store_d16_hi_b16 v[6:7], v26, off                   // 0000001D8164: DC960000 007C1A06
	global_store_d16_hi_b16 v[14:15], v25, off                 // 0000001D816C: DC960000 007C190E
	global_store_d16_hi_b16 v[22:23], v28, off                 // 0000001D8174: DC960000 007C1C16
	global_store_d16_hi_b16 v[36:37], v29, off                 // 0000001D817C: DC960000 007C1D24
	global_store_d16_hi_b16 v[34:35], v16, off offset:32       // 0000001D8184: DC960020 007C1022
	global_store_d16_hi_b16 v[38:39], v17, off offset:32       // 0000001D818C: DC960020 007C1126
	v_sub_f32_e32 v16, v85, v113                               // 0000001D8194: 0820E355
	v_fma_f32 v25, -v94, v123, v95                             // 0000001D8198: D6130019 257EF75E
	v_dual_mul_f32 v26, v97, v109 :: v_dual_and_b32 v17, 1, v54// 0000001D81A0: C8E4DB61 1A106C81
	v_cndmask_b32_e32 v24, 0x7f800000, v24, vcc_lo             // 0000001D81A8: 023030FF 7F800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D81B0: BF870214
	v_add_f32_e32 v16, v16, v112                               // 0000001D81B4: 0620E110
	v_fmac_f32_e32 v123, v25, v108                             // 0000001D81B8: 56F6D919
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D81BC: BF870004
	v_fma_f32 v25, -v96, v26, v97                              // 0000001D81C0: D6130019 25863560
	s_mov_b32 vcc_lo, s9                                       // 0000001D81C8: BEEA0009
	v_add_f32_e32 v24, 1.0, v24                                // 0000001D81CC: 063030F2
	v_exp_f32_e32 v16, v16                                     // 0000001D81D0: 7E204B10
	v_fma_f32 v28, -v94, v123, v95                             // 0000001D81D4: D613001C 257EF75E
	v_fmac_f32_e32 v26, v25, v109                              // 0000001D81DC: 5634DB19
	v_cvt_i32_f32_e32 v25, v113                                // 0000001D81E0: 7E321171
	v_and_b32_e32 v27, 1, v57                                  // 0000001D81E4: 36367281
	v_add3_u32 v17, v19, v17, 0x7fff                           // 0000001D81E8: D6550011 03FE2313 00007FFF
	v_div_fmas_f32 v28, v28, v108, v123                        // 0000001D81F4: D637001C 05EED91C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v68                  // 0000001D81FC: 7C3C88FF 42CE8ED0
	v_lshlrev_b32_e32 v49, 16, v71                             // 0000001D8204: 30628E90
	v_add3_u32 v18, v18, v27, 0x7fff                           // 0000001D8208: D6550012 03FE3712 00007FFF
	.long 0xd71c0010                                           // 0000001D8214: D71C0010
	v_cndmask_b32_e32 v1, v16, v25, vcc_lo                     // 0000001D8218: 02023310
	v_fma_f32 v25, -v96, v26, v97                              // 0000001D821C: D6130019 25863560
	v_div_fixup_f32 v20, v28, v67, v20                         // 0000001D8224: D6270014 0452871C
	v_mul_f32_e32 v56, 0xbfb8aa3b, v49                         // 0000001D822C: 107062FF BFB8AA3B
	.long 0x7f3839b6                                           // 0000001D8234: 7F3839B6
	v_cndmask_b32_e32 v16, 0, v16, vcc_lo                      // 0000001D8238: 02202080
	s_mov_b32 vcc_lo, s10                                      // 0000001D823C: BEEA000A
	.long 0x7e383994                                           // 0000001D8240: 7E383994
	v_div_fmas_f32 v25, v25, v109, v26                         // 0000001D8244: D6370019 046ADB19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v68                  // 0000001D824C: 7C3688FF C2B17218
	v_div_scale_f32 v26, null, v24, v24, v8                    // 0000001D8254: D6FC7C1A 04223118
	v_fma_f32 v59, 0xbfb8aa3b, v49, -v56                       // 0000001D825C: D613003B 84E262FF BFB8AA3B
	v_rndne_f32_e32 v60, v56                                   // 0000001D8268: 7E784738
	v_div_fixup_f32 v19, v25, v66, v21                         // 0000001D826C: D6270013 04568519
	v_cndmask_b32_e32 v16, 0x7f800000, v16, vcc_lo             // 0000001D8274: 022020FF 7F800000
	v_rcp_f32_e32 v21, v26                                     // 0000001D827C: 7E2A551A
	v_lshlrev_b32_e32 v25, 16, v62                             // 0000001D8280: 30327C90
	v_fmac_f32_e32 v59, 0xb2a5705f, v49                        // 0000001D8284: 567662FF B2A5705F
	.long 0x7e6c3993                                           // 0000001D828C: 7E6C3993
	v_add_f32_e32 v16, 1.0, v16                                // 0000001D8290: 062020F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D8294: BF870224
	v_dual_sub_f32 v56, v56, v60 :: v_dual_mul_f32 v29, 0xbfb8aa3b, v25// 0000001D8298: C9467938 381C32FF BFB8AA3B
	.long 0xd41e0001                                           // 0000001D82A4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001D82A8: 020232FF 42CE8ED0
	v_and_b32_e32 v48, 1, v54                                  // 0000001D82B0: 36606C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001D82B4: BF870294
	v_div_scale_f32 v27, null, v16, v16, v9                    // 0000001D82B8: D6FC7C1B 04262110
	v_fma_f32 v46, -v26, v21, 1.0                              // 0000001D82C0: D613002E 23CA2B1A
	v_fma_f32 v53, 0xbfb8aa3b, v25, -v29                       // 0000001D82C8: D6130035 847632FF BFB8AA3B
	v_rndne_f32_e32 v55, v29                                   // 0000001D82D4: 7E6E471D
	v_add_f32_e32 v56, v56, v59                                // 0000001D82D8: 06707738
	v_rcp_f32_e32 v47, v27                                     // 0000001D82DC: 7E5E551B
	v_fmac_f32_e32 v21, v46, v21                               // 0000001D82E0: 562A2B2E
	v_div_scale_f32 v46, vcc_lo, v8, v24, v8                   // 0000001D82E4: D6FC6A2E 04223108
	v_fmac_f32_e32 v53, 0xb2a5705f, v25                        // 0000001D82EC: 566A32FF B2A5705F
	v_sub_f32_e32 v29, v29, v55                                // 0000001D82F4: 083A6F1D
	v_cvt_i32_f32_e32 v55, v55                                 // 0000001D82F8: 7E6E1137
	v_add3_u32 v19, v19, v48, 0x7fff                           // 0000001D82FC: D6550013 03FE6113 00007FFF
	v_mul_f32_e32 v58, v46, v21                                // 0000001D8308: 10742B2E
	v_exp_f32_e32 v48, v56                                     // 0000001D830C: 7E604B38
	v_add_f32_e32 v29, v29, v53                                // 0000001D8310: 063A6B1D
	v_fma_f32 v57, -v27, v47, 1.0                              // 0000001D8314: D6130039 23CA5F1B
	v_div_scale_f32 v53, s0, v9, v16, v9                       // 0000001D831C: D6FC0035 04262109
	v_and_b32_e32 v28, 1, v28                                  // 0000001D8324: 36383881
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D8328: BF870194
	v_exp_f32_e32 v29, v29                                     // 0000001D832C: 7E3A4B1D
	v_fmac_f32_e32 v47, v57, v47                               // 0000001D8330: 565E5F39
	v_fma_f32 v57, -v26, v58, v46                              // 0000001D8334: D6130039 24BA751A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D833C: BF870003
	v_add3_u32 v20, v20, v28, 0x7fff                           // 0000001D8340: D6550014 03FE3914 00007FFF
	s_clause 0x3                                               // 0000001D834C: BF850003
	global_store_d16_hi_b16 v[6:7], v18, off offset:32         // 0000001D8350: DC960020 007C1206
	global_store_d16_hi_b16 v[14:15], v17, off offset:32       // 0000001D8358: DC960020 007C110E
	global_store_d16_hi_b16 v[22:23], v20, off offset:32       // 0000001D8360: DC960020 007C1416
	global_store_d16_hi_b16 v[36:37], v19, off offset:32       // 0000001D8368: DC960020 007C1324
	v_fmac_f32_e32 v58, v57, v21                               // 0000001D8370: 56742B39
	v_mul_f32_e32 v61, v53, v47                                // 0000001D8374: 107A5F35
	.long 0xd71c001d                                           // 0000001D8378: D71C001D
	v_cndmask_b32_e32 v1, v29, v55, vcc_lo                     // 0000001D837C: 02026F1D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D8380: BF870193
	v_fma_f32 v26, -v26, v58, v46                              // 0000001D8384: D613001A 24BA751A
	v_fma_f32 v57, -v27, v61, v53                              // 0000001D838C: D6130039 24D67B1B
	v_cvt_i32_f32_e32 v46, v60                                 // 0000001D8394: 7E5C113C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D8398: BF870214
	v_cndmask_b32_e64 v29, 0, v29, s1                          // 0000001D839C: D501001D 00063A80
	v_div_fmas_f32 v21, v26, v21, v58                          // 0000001D83A4: D6370015 04EA2B1A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001D83AC: 7C3632FF C2B17218
	v_fmac_f32_e32 v61, v57, v47                               // 0000001D83B4: 567A5F39
	.long 0xd71c001a                                           // 0000001D83B8: D71C001A
	v_cndmask_b32_e32 v1, v48, v46, vcc_lo                     // 0000001D83BC: 02025D30
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D83C0: BF870004
	v_div_fixup_f32 v8, v21, v24, v8                           // 0000001D83C4: D6270008 04223115
	v_cndmask_b32_e32 v25, 0x7f800000, v29, vcc_lo             // 0000001D83CC: 02323AFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001D83D4: 7C3C62FF 42CE8ED0
	v_fma_f32 v27, -v27, v61, v53                              // 0000001D83DC: D613001B 24D67B1B
	v_lshlrev_b32_e32 v29, 16, v51                             // 0000001D83E4: 303A6690
	.long 0x7e303988                                           // 0000001D83E8: 7E303988
	v_dual_add_f32 v25, 1.0, v25 :: v_dual_cndmask_b32 v26, 0, v26// 0000001D83EC: C91232F2 191A3480
	s_mov_b32 vcc_lo, s0                                       // 0000001D83F4: BEEA0000
	.long 0x7f3039b6                                           // 0000001D83F8: 7F3039B6
	v_div_fmas_f32 v27, v27, v47, v61                          // 0000001D83FC: D637001B 04F65F1B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001D8404: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D840C: BF870193
	v_dual_mul_f32 v47, 0xbfb8aa3b, v29 :: v_dual_and_b32 v24, 1, v24// 0000001D8410: C8E43AFF 2F183081 BFB8AA3B
	v_div_fixup_f32 v9, v27, v16, v9                           // 0000001D841C: D6270009 0426211B
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 0000001D8424: 023434FF 7F800000
	v_div_scale_f32 v16, null, v25, v25, v10                   // 0000001D842C: D6FC7C10 042A3319
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D8434: BF870004
	v_fma_f32 v18, 0xbfb8aa3b, v29, -v47                       // 0000001D8438: D6130012 84BE3AFF BFB8AA3B
	v_rndne_f32_e32 v19, v47                                   // 0000001D8444: 7E26472F
	.long 0x7e6c3989                                           // 0000001D8448: 7E6C3989
	v_add_f32_e32 v21, 1.0, v26                                // 0000001D844C: 062A34F2
	v_rcp_f32_e32 v26, v16                                     // 0000001D8450: 7E345510
	v_add3_u32 v8, v8, v24, 0x7fff                             // 0000001D8454: D6550008 03FE3108 00007FFF
	v_fmac_f32_e32 v18, 0xb2a5705f, v29                        // 0000001D8460: 56243AFF B2A5705F
	v_and_b32_e32 v28, 1, v54                                  // 0000001D8468: 36386C81
	v_div_scale_f32 v27, null, v21, v21, v11                   // 0000001D846C: D6FC7C1B 042E2B15
	v_sub_f32_e32 v24, v47, v19                                // 0000001D8474: 0830272F
	global_store_d16_hi_b16 v[34:35], v8, off offset:64        // 0000001D8478: DC960040 007C0822
	v_cvt_i32_f32_e32 v19, v19                                 // 0000001D8480: 7E261113
	v_add3_u32 v9, v9, v28, 0x7fff                             // 0000001D8484: D6550009 03FE3909 00007FFF
	v_rcp_f32_e32 v46, v27                                     // 0000001D8490: 7E5C551B
	v_fma_f32 v17, -v16, v26, 1.0                              // 0000001D8494: D6130011 23CA3510
	v_lshlrev_b32_e32 v28, 16, v72                             // 0000001D849C: 30389090
	v_add_f32_e32 v18, v24, v18                                // 0000001D84A0: 06242518
	global_store_d16_hi_b16 v[38:39], v9, off offset:64        // 0000001D84A4: DC960040 007C0926
	v_fmac_f32_e32 v26, v17, v26                               // 0000001D84AC: 56343511
	v_div_scale_f32 v17, vcc_lo, v10, v25, v10                 // 0000001D84B0: D6FC6A11 042A330A
	v_mul_f32_e32 v24, 0xbfb8aa3b, v28                         // 0000001D84B8: 103038FF BFB8AA3B
	v_exp_f32_e32 v18, v18                                     // 0000001D84C0: 7E244B12
	v_fma_f32 v20, -v27, v46, 1.0                              // 0000001D84C4: D6130014 23CA5D1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D84CC: BF870193
	v_mul_f32_e32 v47, v17, v26                                // 0000001D84D0: 105E3511
	v_fma_f32 v49, 0xbfb8aa3b, v28, -v24                       // 0000001D84D4: D6130031 846238FF BFB8AA3B
	v_rndne_f32_e32 v51, v24                                   // 0000001D84E0: 7E664718
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D84E4: BF870234
	v_fmac_f32_e32 v46, v20, v46                               // 0000001D84E8: 565C5D14
	v_div_scale_f32 v20, s0, v11, v21, v11                     // 0000001D84EC: D6FC0014 042E2B0B
	v_fma_f32 v8, -v16, v47, v17                               // 0000001D84F4: D6130008 24465F10
	v_dual_fmac_f32 v49, 0xb2a5705f, v28 :: v_dual_sub_f32 v24, v24, v51// 0000001D84FC: C80A38FF 31186718 B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D8508: BF870193
	v_mul_f32_e32 v48, v20, v46                                // 0000001D850C: 10605D14
	v_fmac_f32_e32 v47, v8, v26                                // 0000001D8510: 565E3508
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D8514: BF870112
	v_fma_f32 v8, -v27, v48, v20                               // 0000001D8518: D6130008 2452611B
	v_fma_f32 v9, -v16, v47, v17                               // 0000001D8520: D6130009 24465F10
	v_add_f32_e32 v16, v24, v49                                // 0000001D8528: 06206318
	v_lshlrev_b32_e32 v24, 16, v52                             // 0000001D852C: 30306890
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D8530: BF870004
	v_fmac_f32_e32 v48, v8, v46                                // 0000001D8534: 56605D08
	.long 0xd71c0008                                           // 0000001D8538: D71C0008
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000001D853C: 02022712
	v_div_fmas_f32 v9, v9, v26, v47                            // 0000001D8540: D6370009 04BE3509
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001D8548: 7C3C3AFF 42CE8ED0
	v_exp_f32_e32 v16, v16                                     // 0000001D8550: 7E204B10
	v_fma_f32 v17, -v27, v48, v20                              // 0000001D8554: D6130011 2452611B
	v_cvt_i32_f32_e32 v18, v51                                 // 0000001D855C: 7E241133
	v_div_fixup_f32 v9, v9, v25, v10                           // 0000001D8560: D6270009 042A3309
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo                        // 0000001D8568: 02101080
	s_mov_b32 vcc_lo, s0                                       // 0000001D856C: BEEA0000
	v_mul_f32_e32 v27, 0xbfb8aa3b, v24                         // 0000001D8570: 103630FF BFB8AA3B
	v_div_fmas_f32 v17, v17, v46, v48                          // 0000001D8578: D6370011 04C25D11
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001D8580: 7C363AFF C2B17218
	.long 0x7e323989                                           // 0000001D8588: 7E323989
	.long 0x7f3239b6                                           // 0000001D858C: 7F3239B6
	v_fma_f32 v29, 0xbfb8aa3b, v24, -v27                       // 0000001D8590: D613001D 846E30FF BFB8AA3B
	v_div_fixup_f32 v10, v17, v21, v11                         // 0000001D859C: D627000A 042E2B11
	v_cndmask_b32_e32 v8, 0x7f800000, v8, vcc_lo               // 0000001D85A4: 021010FF 7F800000
	.long 0xd71c000b                                           // 0000001D85AC: D71C000B
	v_cndmask_b32_e32 v1, v16, v18, vcc_lo                     // 0000001D85B0: 02022510
	v_lshlrev_b32_e32 v16, 16, v50                             // 0000001D85B4: 30206490
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v28                  // 0000001D85B8: 7C3C38FF 42CE8ED0
	v_rndne_f32_e32 v46, v27                                   // 0000001D85C0: 7E5C471B
	v_add_f32_e32 v8, 1.0, v8                                  // 0000001D85C4: 061010F2
	v_fmac_f32_e32 v29, 0xb2a5705f, v24                        // 0000001D85C8: 563A30FF B2A5705F
	v_dual_mul_f32 v18, 0xbfb8aa3b, v16 :: v_dual_cndmask_b32 v11, 0, v11// 0000001D85D0: C8D220FF 120A1680 BFB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v28                  // 0000001D85DC: 7C3638FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D85E4: BF870224
	v_div_scale_f32 v17, null, v8, v8, v12                     // 0000001D85E8: D6FC7C11 04321108
	v_sub_f32_e32 v27, v27, v46                                // 0000001D85F0: 08365D1B
	v_fma_f32 v20, 0xbfb8aa3b, v16, -v18                       // 0000001D85F4: D6130014 844A20FF BFB8AA3B
	v_rndne_f32_e32 v21, v18                                   // 0000001D8600: 7E2A4712
	v_cndmask_b32_e32 v11, 0x7f800000, v11, vcc_lo             // 0000001D8604: 021616FF 7F800000
	v_rcp_f32_e32 v19, v17                                     // 0000001D860C: 7E265511
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D8610: BF870113
	v_dual_add_f32 v27, v27, v29 :: v_dual_fmac_f32 v20, 0xb2a5705f, v16// 0000001D8614: C9003B1B 1B1420FF B2A5705F
	v_dual_sub_f32 v18, v18, v21 :: v_dual_add_f32 v11, 1.0, v11// 0000001D8620: C9482B12 120A16F2
	v_cvt_i32_f32_e32 v21, v21                                 // 0000001D8628: 7E2A1115
	.long 0xd41e0001                                           // 0000001D862C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v16, vcc_lo              // 0000001D8630: 020220FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D8638: BF870194
	v_exp_f32_e32 v27, v27                                     // 0000001D863C: 7E364B1B
	v_add_f32_e32 v18, v18, v20                                // 0000001D8640: 06242912
	v_div_scale_f32 v26, null, v11, v11, v13                   // 0000001D8644: D6FC7C1A 0436170B
	s_delay_alu instid0(TRANS32_DEP_2)                         // 0000001D864C: BF870006
	v_fma_f32 v28, -v17, v19, 1.0                              // 0000001D8650: D613001C 23CA2711
	v_cvt_i32_f32_e32 v46, v46                                 // 0000001D8658: 7E5C112E
	v_and_b32_e32 v25, 1, v25                                  // 0000001D865C: 36323281
	v_exp_f32_e32 v18, v18                                     // 0000001D8660: 7E244B12
	v_rcp_f32_e32 v20, v26                                     // 0000001D8664: 7E28551A
	v_fmac_f32_e32 v19, v28, v19                               // 0000001D8668: 5626271C
	v_div_scale_f32 v28, vcc_lo, v12, v8, v12                  // 0000001D866C: D6FC6A1C 0432110C
	.long 0xd71c001b                                           // 0000001D8674: D71C001B
	v_cndmask_b32_e32 v1, v27, v46, vcc_lo                     // 0000001D8678: 02025D1B
	v_add3_u32 v9, v9, v25, 0x7fff                             // 0000001D867C: D6550009 03FE3309 00007FFF
	.long 0x7e6c398a                                           // 0000001D8688: 7E6C398A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001D868C: BF870314
	v_mul_f32_e32 v29, v28, v19                                // 0000001D8690: 103A271C
	.long 0xd71c0012                                           // 0000001D8694: D71C0012
	v_cndmask_b32_e32 v1, v18, v21, vcc_lo                     // 0000001D8698: 02022B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D869C: BF870235
	v_fma_f32 v48, -v26, v20, 1.0                              // 0000001D86A0: D6130030 23CA291A
	v_div_scale_f32 v21, s0, v13, v11, v13                     // 0000001D86A8: D6FC0015 0436170D
	v_and_b32_e32 v47, 1, v54                                  // 0000001D86B0: 365E6C81
	v_cndmask_b32_e64 v18, 0, v18, s1                          // 0000001D86B4: D5010012 00062480
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001D86BC: BF870244
	v_fmac_f32_e32 v20, v48, v20                               // 0000001D86C0: 56282930
	.long 0xd41b0001                                           // 0000001D86C4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v16, vcc_lo              // 0000001D86C8: 020220FF C2B17218
	v_fma_f32 v48, -v17, v29, v28                              // 0000001D86D0: D6130030 24723B11
	v_add3_u32 v10, v10, v47, 0x7fff                           // 0000001D86D8: D655000A 03FE5F0A 00007FFF
	v_mul_f32_e32 v49, v21, v20                                // 0000001D86E4: 10622915
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D86E8: BF870214
	v_cndmask_b32_e64 v16, 0x7f800000, v18, s1                 // 0000001D86EC: D5010010 000624FF 7F800000
	v_fmac_f32_e32 v29, v48, v19                               // 0000001D86F8: 563A2730
	.long 0xd41e0001                                           // 0000001D86FC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v24, vcc_lo              // 0000001D8700: 020230FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D8708: BF870214
	v_fma_f32 v18, -v26, v49, v21                              // 0000001D870C: D6130012 2456631A
	v_add_f32_e32 v16, 1.0, v16                                // 0000001D8714: 062020F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D8718: BF870194
	v_fma_f32 v17, -v17, v29, v28                              // 0000001D871C: D6130011 24723B11
	v_fmac_f32_e32 v49, v18, v20                               // 0000001D8724: 56622912
	v_cndmask_b32_e64 v18, 0, v27, s1                          // 0000001D8728: D5010012 00063680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D8730: BF870214
	v_div_scale_f32 v27, null, v16, v16, v0                    // 0000001D8734: D6FC7C1B 04022110
	v_div_fmas_f32 v17, v17, v19, v29                          // 0000001D873C: D6370011 04762711
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000001D8744: 7C3630FF C2B17218
	v_fma_f32 v19, -v26, v49, v21                              // 0000001D874C: D6130013 2456631A
	.long 0x7f3039b6                                           // 0000001D8754: 7F3039B6
	v_rcp_f32_e32 v21, v27                                     // 0000001D8758: 7E2A551B
	v_div_fixup_f32 v8, v17, v8, v12                           // 0000001D875C: D6270008 04321111
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001D8764: 022424FF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001D876C: BEEA0000
	v_lshlrev_b32_e32 v17, 16, v42                             // 0000001D8770: 30225490
	v_div_fmas_f32 v19, v19, v20, v49                          // 0000001D8774: D6370013 04C62913
	.long 0x7e303988                                           // 0000001D877C: 7E303988
	v_add_f32_e32 v18, 1.0, v18                                // 0000001D8780: 062424F2
	v_mul_f32_e32 v42, 0xbfb8aa3b, v32                         // 0000001D8784: 105440FF BFB8AA3B
	v_mul_f32_e32 v20, 0xbfb8aa3b, v17                         // 0000001D878C: 102822FF BFB8AA3B
	v_div_fixup_f32 v11, v19, v11, v13                         // 0000001D8794: D627000B 04361713
	v_fma_f32 v13, -v27, v21, 1.0                              // 0000001D879C: D613000D 23CA2B1B
	v_div_scale_f32 v12, null, v18, v18, v1                    // 0000001D87A4: D6FC7C0C 04062512
	v_and_b32_e32 v24, 1, v24                                  // 0000001D87AC: 36303081
	v_fma_f32 v28, 0xbfb8aa3b, v17, -v20                       // 0000001D87B0: D613001C 845222FF BFB8AA3B
	v_rndne_f32_e32 v29, v20                                   // 0000001D87BC: 7E3A4714
	v_fmac_f32_e32 v21, v13, v21                               // 0000001D87C0: 562A2B0D
	v_div_scale_f32 v13, vcc_lo, v0, v16, v0                   // 0000001D87C4: D6FC6A0D 04022100
	v_rcp_f32_e32 v19, v12                                     // 0000001D87CC: 7E26550C
	v_fmac_f32_e32 v28, 0xb2a5705f, v17                        // 0000001D87D0: 563822FF B2A5705F
	v_sub_f32_e32 v20, v20, v29                                // 0000001D87D8: 08283B14
	.long 0x7e6c398b                                           // 0000001D87DC: 7E6C398B
	v_mul_f32_e32 v25, v13, v21                                // 0000001D87E0: 10322B0D
	v_add3_u32 v8, v8, v24, 0x7fff                             // 0000001D87E4: D6550008 03FE3108 00007FFF
	v_fma_f32 v43, 0xbfb8aa3b, v32, -v42                       // 0000001D87F0: D613002B 84AA40FF BFB8AA3B
	v_add_f32_e32 v20, v20, v28                                // 0000001D87FC: 06283914
	v_lshlrev_b32_e32 v28, 16, v44                             // 0000001D8800: 30385890
	v_fma_f32 v30, -v27, v25, v13                              // 0000001D8804: D613001E 2436331B
	v_fma_f32 v31, -v12, v19, 1.0                              // 0000001D880C: D613001F 23CA270C
	v_and_b32_e32 v26, 1, v54                                  // 0000001D8814: 36346C81
	v_exp_f32_e32 v20, v20                                     // 0000001D8818: 7E284B14
	v_rndne_f32_e32 v44, v42                                   // 0000001D881C: 7E58472A
	v_fmac_f32_e32 v25, v30, v21                               // 0000001D8820: 56322B1E
	v_fmac_f32_e32 v19, v31, v19                               // 0000001D8824: 5626271F
	s_waitcnt vmcnt(0)                                         // 0000001D8828: BF8903F7
	v_lshlrev_b32_e32 v31, 16, v45                             // 0000001D882C: 303E5A90
	v_add3_u32 v11, v11, v26, 0x7fff                           // 0000001D8830: D655000B 03FE350B 00007FFF
	v_div_scale_f32 v26, s0, v1, v18, v1                       // 0000001D883C: D6FC001A 04062501
	v_fma_f32 v13, -v27, v25, v13                              // 0000001D8844: D613000D 2436331B
	v_mul_f32_e32 v27, 0xbfb8aa3b, v28                         // 0000001D884C: 103638FF BFB8AA3B
	v_fmac_f32_e32 v43, 0xb2a5705f, v32                        // 0000001D8854: 565640FF B2A5705F
	v_sub_f32_e32 v42, v42, v44                                // 0000001D885C: 0854592A
	v_mul_f32_e32 v24, v26, v19                                // 0000001D8860: 1030271A
	v_div_fmas_f32 v13, v13, v21, v25                          // 0000001D8864: D637000D 04662B0D
	v_cvt_i32_f32_e32 v25, v29                                 // 0000001D886C: 7E32111D
	v_fma_f32 v29, 0xbfb8aa3b, v28, -v27                       // 0000001D8870: D613001D 846E38FF BFB8AA3B
	v_rndne_f32_e32 v30, v27                                   // 0000001D887C: 7E3C471B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000001D8880: 7C3C22FF 42CE8ED0
	v_fma_f32 v21, -v12, v24, v26                              // 0000001D8888: D6130015 246A310C
	.long 0xd71c0014                                           // 0000001D8890: D71C0014
	v_cndmask_b32_e32 v1, v20, v25, vcc_lo                     // 0000001D8894: 02023314
	v_fmac_f32_e32 v29, 0xb2a5705f, v28                        // 0000001D8898: 563A38FF B2A5705F
	v_sub_f32_e32 v25, v27, v30                                // 0000001D88A0: 08323D1B
	v_mul_f32_e32 v27, 0xbfb8aa3b, v31                         // 0000001D88A4: 10363EFF BFB8AA3B
	v_cvt_i32_f32_e32 v30, v30                                 // 0000001D88AC: 7E3C111E
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001D88B0: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000001D88B4: 7C3622FF C2B17218
	v_add_f32_e32 v25, v25, v29                                // 0000001D88BC: 06323B19
	v_fma_f32 v29, 0xbfb8aa3b, v31, -v27                       // 0000001D88C0: D613001D 846E3EFF BFB8AA3B
	v_fmac_f32_e32 v24, v21, v19                               // 0000001D88CC: 56302715
	s_clause 0x3                                               // 0000001D88D0: BF850003
	global_store_d16_hi_b16 v[6:7], v9, off offset:64          // 0000001D88D4: DC960040 007C0906
	global_store_d16_hi_b16 v[14:15], v10, off offset:64       // 0000001D88DC: DC960040 007C0A0E
	global_store_d16_hi_b16 v[22:23], v8, off offset:64        // 0000001D88E4: DC960040 007C0816
	global_store_d16_hi_b16 v[36:37], v11, off offset:64       // 0000001D88EC: DC960040 007C0B24
	v_cndmask_b32_e32 v17, 0x7f800000, v20, vcc_lo             // 0000001D88F4: 022228FF 7F800000
	v_rndne_f32_e32 v20, v27                                   // 0000001D88FC: 7E28471B
	v_exp_f32_e32 v25, v25                                     // 0000001D8900: 7E324B19
	v_fmac_f32_e32 v29, 0xb2a5705f, v31                        // 0000001D8904: 563A3EFF B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v28                  // 0000001D890C: 7C3C38FF 42CE8ED0
	v_fma_f32 v12, -v12, v24, v26                              // 0000001D8914: D613000C 246A310C
	v_sub_f32_e32 v27, v27, v20                                // 0000001D891C: 0836291B
	v_cvt_i32_f32_e32 v20, v20                                 // 0000001D8920: 7E281114
	v_cvt_i32_f32_e32 v26, v44                                 // 0000001D8924: 7E34112C
	v_add_f32_e32 v17, 1.0, v17                                // 0000001D8928: 062222F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001D892C: BF870294
	v_add_f32_e32 v27, v27, v29                                // 0000001D8930: 06363B1B
	.long 0xd71c0015                                           // 0000001D8934: D71C0015
	v_cndmask_b32_e32 v1, v25, v30, vcc_lo                     // 0000001D8938: 02023D19
	v_add_f32_e32 v29, v42, v43                                // 0000001D893C: 063A572A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D8940: BF870214
	v_div_scale_f32 v25, null, v17, v17, v2                    // 0000001D8944: D6FC7C19 040A2311
	v_exp_f32_e32 v27, v27                                     // 0000001D894C: 7E364B1B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D8950: BF870193
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 0000001D8954: 022A2A80
	v_exp_f32_e32 v29, v29                                     // 0000001D8958: 7E3A4B1D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v28                  // 0000001D895C: 7C3638FF C2B17218
	v_rcp_f32_e32 v30, v25                                     // 0000001D8964: 7E3C5519
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_3)// 0000001D8968: BF8703A2
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001D896C: 022A2AFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v31                  // 0000001D8974: 7C3C3EFF 42CE8ED0
	.long 0xd71c0014                                           // 0000001D897C: D71C0014
	v_cndmask_b32_e32 v1, v27, v20, vcc_lo                     // 0000001D8980: 0202291B
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D8984: BF870216
	.long 0xd71c001a                                           // 0000001D8988: D71C001A
	v_cndmask_b32_e32 v1, v29, v26, vcc_lo                     // 0000001D898C: 0202351D
	v_add_f32_e32 v21, 1.0, v21                                // 0000001D8990: 062A2AF2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D8994: BF870215
	v_fma_f32 v27, -v25, v30, 1.0                              // 0000001D8998: D613001B 23CA3D19
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001D89A0: 02282880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 0000001D89A4: 7C3C40FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D89AC: BF870214
	v_div_scale_f32 v28, null, v21, v21, v3                    // 0000001D89B0: D6FC7C1C 040E2B15
	v_fmac_f32_e32 v30, v27, v30                               // 0000001D89B8: 563C3D1B
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000001D89BC: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v31                  // 0000001D89C0: 7C363EFF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001D89C8: BF870134
	v_rcp_f32_e32 v29, v28                                     // 0000001D89CC: 7E3A551C
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 0000001D89D0: 022828FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 0000001D89D8: 7C3640FF C2B17218
	v_add_f32_e32 v20, 1.0, v20                                // 0000001D89E0: 062828F2
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 0000001D89E4: 023434FF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001D89EC: BEEA0000
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001D89F0: BF870005
	v_fma_f32 v27, -v28, v29, 1.0                              // 0000001D89F4: D613001B 23CA3B1C
	v_div_fmas_f32 v12, v12, v19, v24                          // 0000001D89FC: D637000C 0462270C
	v_div_scale_f32 v19, null, v20, v20, v4                    // 0000001D8A04: D6FC7C13 04122914
	v_add_f32_e32 v24, 1.0, v26                                // 0000001D8A0C: 063034F2
	v_div_scale_f32 v26, vcc_lo, v2, v17, v2                   // 0000001D8A10: D6FC6A1A 040A2302
	v_fmac_f32_e32 v29, v27, v29                               // 0000001D8A18: 563A3B1B
	v_div_scale_f32 v10, s0, v3, v21, v3                       // 0000001D8A1C: D6FC000A 040E2B03
	v_rcp_f32_e32 v31, v19                                     // 0000001D8A24: 7E3E5513
	v_div_scale_f32 v32, null, v24, v24, v5                    // 0000001D8A28: D6FC7C20 04163118
	v_mul_f32_e32 v8, v26, v30                                 // 0000001D8A30: 10103D1A
	v_div_fixup_f32 v1, v12, v18, v1                           // 0000001D8A34: D6270001 0406250C
	.long 0x7f2439b6                                           // 0000001D8A3C: 7F2439B6
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D8A40: BF870194
	v_rcp_f32_e32 v9, v32                                      // 0000001D8A44: 7E125520
	v_fma_f32 v12, -v25, v8, v26                               // 0000001D8A48: D613000C 246A1119
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001D8A50: BF870313
	.long 0x7e6c3981                                           // 0000001D8A54: 7E6C3981
	v_fma_f32 v11, -v19, v31, 1.0                              // 0000001D8A58: D613000B 23CA3F13
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D8A60: BF870121
	v_dual_fmac_f32 v8, v12, v30 :: v_dual_fmac_f32 v31, v11, v31// 0000001D8A64: C8003D0C 081E3F0B
	v_div_scale_f32 v11, s1, v4, v20, v4                       // 0000001D8A6C: D6FC010B 04122904
	v_fma_f32 v25, -v25, v8, v26                               // 0000001D8A74: D6130019 246A1119
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001D8A7C: BF870002
	v_mul_f32_e32 v27, v11, v31                                // 0000001D8A80: 10363F0B
	v_div_fixup_f32 v0, v13, v16, v0                           // 0000001D8A84: D6270000 0402210D
	v_mul_f32_e32 v13, v10, v29                                // 0000001D8A8C: 101A3B0A
	v_fma_f32 v16, -v32, v9, 1.0                               // 0000001D8A90: D6130010 23CA1320
	v_div_fmas_f32 v8, v25, v30, v8                            // 0000001D8A98: D6370008 04223D19
	s_mov_b32 vcc_lo, s0                                       // 0000001D8AA0: BEEA0000
	.long 0x7e243980                                           // 0000001D8AA4: 7E243980
	v_fma_f32 v12, -v28, v13, v10                              // 0000001D8AA8: D613000C 242A1B1C
	v_fmac_f32_e32 v9, v16, v9                                 // 0000001D8AB0: 56121310
	v_div_scale_f32 v16, s2, v5, v24, v5                       // 0000001D8AB4: D6FC0210 04163105
	v_div_fixup_f32 v2, v8, v17, v2                            // 0000001D8ABC: D6270002 040A2308
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D8AC4: BF870224
	v_fmac_f32_e32 v13, v12, v29                               // 0000001D8AC8: 561A3B0C
	v_fma_f32 v12, -v19, v27, v11                              // 0000001D8ACC: D613000C 242E3713
	v_mul_f32_e32 v26, v16, v9                                 // 0000001D8AD4: 10341310
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D8AD8: BF870193
	v_fma_f32 v10, -v28, v13, v10                              // 0000001D8ADC: D613000A 242A1B1C
	v_fmac_f32_e32 v27, v12, v31                               // 0000001D8AE4: 56363F0C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D8AE8: BF870223
	v_fma_f32 v25, -v32, v26, v16                              // 0000001D8AEC: D6130019 24423520
	v_and_b32_e32 v12, 1, v54                                  // 0000001D8AF4: 36186C81
	v_div_fmas_f32 v10, v10, v29, v13                          // 0000001D8AF8: D637000A 04363B0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D8B00: BF870214
	v_fma_f32 v8, -v19, v27, v11                               // 0000001D8B04: D6130008 242E3713
	v_fmac_f32_e32 v26, v25, v9                                // 0000001D8B0C: 56341319
	s_mov_b32 vcc_lo, s1                                       // 0000001D8B10: BEEA0001
	.long 0x7f1639b6                                           // 0000001D8B14: 7F1639B6
	v_div_fixup_f32 v3, v10, v21, v3                           // 0000001D8B18: D6270003 040E2B0A
	v_div_fmas_f32 v8, v8, v31, v27                            // 0000001D8B20: D6370008 046E3F08
	v_fma_f32 v10, -v32, v26, v16                              // 0000001D8B28: D613000A 24423520
	s_mov_b32 vcc_lo, s2                                       // 0000001D8B30: BEEA0002
	v_add3_u32 v1, v1, v12, 0x7fff                             // 0000001D8B34: D6550001 03FE1901 00007FFF
	.long 0x7e6c3983                                           // 0000001D8B40: 7E6C3983
	v_div_fixup_f32 v4, v8, v20, v4                            // 0000001D8B44: D6270004 04122908
	v_div_fmas_f32 v9, v10, v9, v26                            // 0000001D8B4C: D6370009 046A130A
	v_and_b32_e32 v10, 1, v18                                  // 0000001D8B54: 36142481
	.long 0x7e103982                                           // 0000001D8B58: 7E103982
	.long 0x7f1039b6                                           // 0000001D8B5C: 7F1039B6
	.long 0x7e163984                                           // 0000001D8B60: 7E163984
	v_div_fixup_f32 v5, v9, v24, v5                            // 0000001D8B64: D6270005 04163109
	v_and_b32_e32 v9, 1, v54                                   // 0000001D8B6C: 36126C81
	v_add3_u32 v0, v0, v10, 0x7fff                             // 0000001D8B70: D6550000 03FE1500 00007FFF
	v_and_b32_e32 v8, 1, v8                                    // 0000001D8B7C: 36101081
	v_and_b32_e32 v10, 1, v11                                  // 0000001D8B80: 36141681
	.long 0x7e6c3985                                           // 0000001D8B84: 7E6C3985
	global_store_d16_hi_b16 v[34:35], v0, off offset:96        // 0000001D8B88: DC960060 007C0022
	v_add3_u32 v0, v2, v8, 0x7fff                              // 0000001D8B90: D6550000 03FE1102 00007FFF
	v_add3_u32 v2, v3, v9, 0x7fff                              // 0000001D8B9C: D6550002 03FE1303 00007FFF
	v_and_b32_e32 v11, 1, v54                                  // 0000001D8BA8: 36166C81
	v_add3_u32 v3, v4, v10, 0x7fff                             // 0000001D8BAC: D6550003 03FE1504 00007FFF
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001D8BB8: BF870002
	v_add3_u32 v4, v5, v11, 0x7fff                             // 0000001D8BBC: D6550004 03FE1705 00007FFF
	s_clause 0x4                                               // 0000001D8BC8: BF850004
	global_store_d16_hi_b16 v[38:39], v1, off offset:96        // 0000001D8BCC: DC960060 007C0126
	global_store_d16_hi_b16 v[6:7], v0, off offset:96          // 0000001D8BD4: DC960060 007C0006
	global_store_d16_hi_b16 v[14:15], v2, off offset:96        // 0000001D8BDC: DC960060 007C020E
	global_store_d16_hi_b16 v[22:23], v3, off offset:96        // 0000001D8BE4: DC960060 007C0316
	global_store_d16_hi_b16 v[36:37], v4, off offset:96        // 0000001D8BEC: DC960060 007C0424
	s_nop 0                                                    // 0000001D8BF4: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001D8BF8: BFB60003
	s_endpgm                                                   // 0000001D8BFC: BFB00000

