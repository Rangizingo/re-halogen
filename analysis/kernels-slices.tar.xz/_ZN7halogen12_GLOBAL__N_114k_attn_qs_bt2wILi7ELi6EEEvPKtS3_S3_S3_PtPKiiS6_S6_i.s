0000000000185a00 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi6EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi6EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 000000185A00: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 000000185A04: F4080300 F8000020
	s_load_b128 s[24:27], s[0:1], 0x38                         // 000000185A0C: F4080600 F8000038
	s_mov_b32 s20, s3                                          // 000000185A14: BE940003
	s_ashr_i32 s3, s2, 31                                      // 000000185A18: 86039F02
	s_waitcnt lgkmcnt(0)                                       // 000000185A1C: BF89FC07
	s_load_b32 s6, s[14:15], null                              // 000000185A20: F4000187 F8000000
	s_load_b32 s30, s[0:1], 0x48                               // 000000185A28: F4000780 F8000048
	s_lshl_b64 s[4:5], s[2:3], 2                               // 000000185A30: 84848202
	s_waitcnt lgkmcnt(0)                                       // 000000185A34: BF89FC07
	s_add_i32 s3, s6, s2                                       // 000000185A38: 81030206
	s_add_u32 s14, s26, s4                                     // 000000185A3C: 800E041A
	s_addc_u32 s15, s27, s5                                    // 000000185A40: 820F051B
	s_load_b256 s[4:11], s[0:1], null                          // 000000185A44: F40C0100 F8000000
	s_load_b32 s1, s[14:15], null                              // 000000185A4C: F4000047 F8000000
	s_add_i32 s16, s3, 1                                       // 000000185A54: 81108103
	s_mul_hi_i32 s15, s30, s2                                  // 000000185A58: 970F021E
	s_ashr_i32 s0, s16, 31                                     // 000000185A5C: 86009F10
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000185A60: BF870499
	s_lshr_b32 s0, s0, 30                                      // 000000185A64: 85009E00
	s_add_i32 s0, s16, s0                                      // 000000185A68: 81000010
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000185A6C: BF870499
	s_and_b32 s14, s0, -4                                      // 000000185A70: 8B0EC400
	s_sub_i32 s16, s3, s14                                     // 000000185A74: 81900E03
	s_ashr_i32 s3, s0, 2                                       // 000000185A78: 86038200
	s_cmp_gt_i32 s16, -1                                       // 000000185A7C: BF02C110
	s_mul_i32 s14, s30, s2                                     // 000000185A80: 960E021E
	s_cselect_b32 s17, -1, 0                                   // 000000185A84: 981180C1
	s_lshl_b64 s[14:15], s[14:15], 2                           // 000000185A88: 848E820E
	s_mov_b32 s26, s3                                          // 000000185A8C: BE9A0003
	s_add_u32 s14, s24, s14                                    // 000000185A90: 800E0E18
	s_addc_u32 s15, s25, s15                                   // 000000185A94: 820F0F19
	s_and_b32 vcc_lo, exec_lo, s17                             // 000000185A98: 8B6A117E
	s_cbranch_vccnz 11                                         // 000000185A9C: BFA4000B <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi6EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xcc>
	s_waitcnt lgkmcnt(0)                                       // 000000185AA0: BF89FC07
	s_max_i32 s18, s1, 1                                       // 000000185AA4: 8A128101
	s_mov_b32 s19, 0                                           // 000000185AA8: BE930080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000185AAC: BF870499
	s_lshl_b64 s[18:19], s[18:19], 2                           // 000000185AB0: 84928212
	s_add_u32 s0, s14, s18                                     // 000000185AB4: 8000120E
	s_addc_u32 s19, s15, s19                                   // 000000185AB8: 8213130F
	s_add_u32 s18, s0, -4                                      // 000000185ABC: 8012C400
	s_addc_u32 s19, s19, -1                                    // 000000185AC0: 8213C113
	s_load_b32 s26, s[18:19], null                             // 000000185AC4: F4000689 F8000000
	s_mov_b32 s18, exec_lo                                     // 000000185ACC: BE92007E
	v_cmpx_gt_u32_e32 0x180, v0                                // 000000185AD0: 7D9800FF 00000180
	s_cbranch_execz 64                                         // 000000185AD8: BFA50040 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi6EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1dc>
	v_and_b32_e32 v1, 31, v0                                   // 000000185ADC: 3602009F
	s_mul_i32 s22, s20, 0xc00                                  // 000000185AE0: 9616FF14 00000C00
	v_lshlrev_b32_e32 v2, 4, v0                                // 000000185AE8: 30040084
	s_ashr_i32 s23, s22, 31                                    // 000000185AEC: 86179F16
	s_mul_i32 s19, s2, 0x3000                                  // 000000185AF0: 9613FF02 00003000
	s_lshl_b64 s[22:23], s[22:23], 1                           // 000000185AF8: 84968116
	v_lshlrev_b32_e32 v1, 4, v1                                // 000000185AFC: 30020284
	s_waitcnt lgkmcnt(0)                                       // 000000185B00: BF89FC07
	s_add_u32 s4, s4, s22                                      // 000000185B04: 80041604
	s_addc_u32 s5, s5, s23                                     // 000000185B08: 82051705
	s_mul_hi_i32 s0, s2, 0x3000                                // 000000185B0C: 9700FF02 00003000
	s_add_u32 s4, s4, s19                                      // 000000185B14: 80041304
	v_and_or_b32 v4, 0x200, v2, v1                             // 000000185B18: D6570004 040604FF 00000200
	s_addc_u32 s0, s5, s0                                      // 000000185B24: 82000005
	.long 0xd7000401                                           // 000000185B28: D7000401
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 000000185B2C: 02020404
	v_lshl_or_b32 v3, v0, 3, 0xfffffe00                        // 000000185B30: D6560003 03FD0700 FFFFFE00
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 000000185B3C: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 000000185B44: BE840080
	s_nop 0                                                    // 000000185B48: BF800000
	s_nop 0                                                    // 000000185B4C: BF800000
	s_nop 0                                                    // 000000185B50: BF800000
	s_nop 0                                                    // 000000185B54: BF800000
	s_nop 0                                                    // 000000185B58: BF800000
	s_nop 0                                                    // 000000185B5C: BF800000
	s_nop 0                                                    // 000000185B60: BF800000
	s_nop 0                                                    // 000000185B64: BF800000
	s_nop 0                                                    // 000000185B68: BF800000
	s_nop 0                                                    // 000000185B6C: BF800000
	s_nop 0                                                    // 000000185B70: BF800000
	s_nop 0                                                    // 000000185B74: BF800000
	s_nop 0                                                    // 000000185B78: BF800000
	s_nop 0                                                    // 000000185B7C: BF800000
	global_load_b128 v[5:8], v[1:2], off                       // 000000185B80: DC5E0000 057C0001
	v_add_nc_u32_e32 v9, 0x400, v4                             // 000000185B88: 4A1208FF 00000400
	v_add_nc_u32_e32 v3, 0x200, v3                             // 000000185B90: 4A0606FF 00000200
	.long 0xd7006a01                                           // 000000185B98: D7006A01
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 000000185B9C: 020202FF 00000400
	s_delay_alu instid0(VALU_DEP_1)                            // 000000185BA4: BF870001
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 000000185BA8: D5207C02 01AA0480
	s_waitcnt vmcnt(0)                                         // 000000185BB0: BF8903F7
	ds_store_b128 v4, v[5:8] offset:1024                       // 000000185BB4: DB7C0400 00000504
	v_mov_b32_e32 v4, v9                                       // 000000185BBC: 7E080309
	.long 0xd4490000                                           // 000000185BC0: D4490000
	v_cndmask_b32_e32 v1, 0x9ff, v3, vcc_lo                    // 000000185BC4: 020206FF 000009FF
	s_or_b32 s4, s0, s4                                        // 000000185BCC: 8C040400
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000185BD0: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000185BD4: 917E047E
	s_cbranch_execnz 65513                                     // 000000185BD8: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi6EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x180>
	s_or_b32 exec_lo, exec_lo, s18                             // 000000185BDC: 8C7E127E
	v_cndmask_b32_e64 v1, 0, 1, s17                            // 000000185BE0: D5010001 00450280
	v_lshrrev_b32_e32 v7, 5, v0                                // 000000185BE8: 320E0085
	s_waitcnt lgkmcnt(0)                                       // 000000185BEC: BF89FC07
	s_barrier                                                  // 000000185BF0: BFBD0000
	buffer_gl0_inv                                             // 000000185BF4: E0AC0000 00000000
	v_readfirstlane_b32 s0, v1                                 // 000000185BFC: 7E000501
	v_lshlrev_b32_e32 v182, 7, v7                              // 000000185C00: 316C0E87
	s_add_i32 s27, s1, s0                                      // 000000185C04: 811B0001
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000185C08: BF870499
	s_add_i32 s0, s27, 3                                       // 000000185C0C: 8100831B
	s_ashr_i32 s28, s0, 2                                      // 000000185C10: 861C8200
	s_mov_b32 s0, 0                                            // 000000185C14: BE800080
	s_cmp_gt_i32 s28, 0                                        // 000000185C18: BF02801C
	s_cbranch_scc1 2                                           // 000000185C1C: BFA20002 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi6EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x228>
	v_lshlrev_b32_e32 v8, 7, v7                                // 000000185C20: 30100E87
	s_branch 1                                                 // 000000185C24: BFA00001 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi6EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x22c>
	s_mov_b32 s0, -1                                           // 000000185C28: BE8000C1
	v_mov_b32_e32 v38, 0                                       // 000000185C2C: 7E4C0280
	v_and_b32_e32 v180, 15, v0                                 // 000000185C30: 3768008F
	v_bfe_u32 v181, v0, 4, 1                                   // 000000185C34: D61000B5 02050900
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000185C3C: 916A007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000185C40: BF870003
	v_mov_b32_e32 v37, v38                                     // 000000185C44: 7E4A0326
	v_mov_b32_e32 v36, v38                                     // 000000185C48: 7E480326
	v_mov_b32_e32 v35, v38                                     // 000000185C4C: 7E460326
	v_mov_b32_e32 v34, v38                                     // 000000185C50: 7E440326
	v_mov_b32_e32 v33, v38                                     // 000000185C54: 7E420326
	v_mov_b32_e32 v46, v38                                     // 000000185C58: 7E5C0326
	v_mov_b32_e32 v45, v38                                     // 000000185C5C: 7E5A0326
	v_mov_b32_e32 v44, v38                                     // 000000185C60: 7E580326
	v_mov_b32_e32 v43, v38                                     // 000000185C64: 7E560326
	v_mov_b32_e32 v42, v38                                     // 000000185C68: 7E540326
	v_mov_b32_e32 v41, v38                                     // 000000185C6C: 7E520326
	v_mov_b32_e32 v54, v38                                     // 000000185C70: 7E6C0326
	v_mov_b32_e32 v53, v38                                     // 000000185C74: 7E6A0326
	v_mov_b32_e32 v52, v38                                     // 000000185C78: 7E680326
	v_mov_b32_e32 v51, v38                                     // 000000185C7C: 7E660326
	v_mov_b32_e32 v50, v38                                     // 000000185C80: 7E640326
	v_mov_b32_e32 v49, v38                                     // 000000185C84: 7E620326
	v_mov_b32_e32 v62, v38                                     // 000000185C88: 7E7C0326
	v_mov_b32_e32 v61, v38                                     // 000000185C8C: 7E7A0326
	v_mov_b32_e32 v60, v38                                     // 000000185C90: 7E780326
	v_mov_b32_e32 v59, v38                                     // 000000185C94: 7E760326
	v_mov_b32_e32 v58, v38                                     // 000000185C98: 7E740326
	v_mov_b32_e32 v57, v38                                     // 000000185C9C: 7E720326
	v_mov_b32_e32 v30, v38                                     // 000000185CA0: 7E3C0326
	v_mov_b32_e32 v29, v38                                     // 000000185CA4: 7E3A0326
	v_mov_b32_e32 v28, v38                                     // 000000185CA8: 7E380326
	v_mov_b32_e32 v27, v38                                     // 000000185CAC: 7E360326
	v_mov_b32_e32 v26, v38                                     // 000000185CB0: 7E340326
	v_mov_b32_e32 v25, v38                                     // 000000185CB4: 7E320326
	v_mov_b32_e32 v22, v38                                     // 000000185CB8: 7E2C0326
	v_mov_b32_e32 v21, v38                                     // 000000185CBC: 7E2A0326
	v_mov_b32_e32 v20, v38                                     // 000000185CC0: 7E280326
	v_mov_b32_e32 v19, v38                                     // 000000185CC4: 7E260326
	v_mov_b32_e32 v18, v38                                     // 000000185CC8: 7E240326
	v_mov_b32_e32 v17, v38                                     // 000000185CCC: 7E220326
	v_mov_b32_e32 v14, v38                                     // 000000185CD0: 7E1C0326
	v_mov_b32_e32 v13, v38                                     // 000000185CD4: 7E1A0326
	v_mov_b32_e32 v12, v38                                     // 000000185CD8: 7E180326
	v_mov_b32_e32 v11, v38                                     // 000000185CDC: 7E160326
	v_mov_b32_e32 v10, v38                                     // 000000185CE0: 7E140326
	v_mov_b32_e32 v9, v38                                      // 000000185CE4: 7E120326
	v_mov_b32_e32 v6, v38                                      // 000000185CE8: 7E0C0326
	v_mov_b32_e32 v5, v38                                      // 000000185CEC: 7E0A0326
	v_mov_b32_e32 v4, v38                                      // 000000185CF0: 7E080326
	v_mov_b32_e32 v3, v38                                      // 000000185CF4: 7E060326
	v_mov_b32_e32 v2, v38                                      // 000000185CF8: 7E040326
	v_mov_b32_e32 v1, v38                                      // 000000185CFC: 7E020326
	v_mov_b32_e32 v107, v38                                    // 000000185D00: 7ED60326
	v_mov_b32_e32 v178, v38                                    // 000000185D04: 7F640326
	v_mov_b32_e32 v106, v38                                    // 000000185D08: 7ED40326
	v_mov_b32_e32 v179, v38                                    // 000000185D0C: 7F660326
	v_mov_b32_e32 v105, v38                                    // 000000185D10: 7ED20326
	v_mov_b32_e32 v177, v38                                    // 000000185D14: 7F620326
	s_cbranch_vccnz 1271                                       // 000000185D18: BFA404F7 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi6EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x16f8>
	v_lshlrev_b32_e32 v1, 6, v181                              // 000000185D1C: 30036A86
	v_dual_mov_b32 v177, 0 :: v_dual_lshlrev_b32 v2, 2, v180   // 000000185D20: CA220080 B1036882
	v_cmp_gt_u32_e32 vcc_lo, 12, v180                          // 000000185D28: 7C99688C
	s_ashr_i32 s21, s20, 31                                    // 000000185D2C: 86159F14
	s_lshl2_add_u32 s0, s1, s16                                // 000000185D30: 87801001
	s_delay_alu instid0(VALU_DEP_2)                            // 000000185D34: BF870002
	v_or3_b32 v1, v1, v2, 0x1c00                               // 000000185D38: D6580001 03FE0501 00001C00
	v_dual_mov_b32 v65, 0 :: v_dual_lshlrev_b32 v0, 5, v0      // 000000185D44: CA220080 41000085
	v_dual_cndmask_b32 v3, 0, v180 :: v_dual_lshlrev_b32 v2, 10, v7// 000000185D4C: CA636880 03020E8A
	s_lshl_b64 s[4:5], s[20:21], 11                            // 000000185D54: 84848B14
	s_add_i32 s29, s0, 1                                       // 000000185D58: 811D8100
	s_load_b128 s[16:19], s[14:15], null                       // 000000185D5C: F4080407 F8000000
	s_add_i32 s30, s30, -4                                     // 000000185D64: 811EC41E
	s_add_u32 s0, s6, s4                                       // 000000185D68: 80000406
	s_addc_u32 s4, s7, s5                                      // 000000185D6C: 82040507
	v_dual_mov_b32 v69, v65 :: v_dual_and_b32 v0, 0x60, v0     // 000000185D70: CA240141 450000FF 00000060
	.long 0xd7000005                                           // 000000185D7C: D7000005
	v_cndmask_b32_e32 v1, s0, v2, vcc_lo                       // 000000185D80: 02020400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000185D84: BF8701A1
	v_add_co_ci_u32_e64 v6, null, s4, 0, s0                    // 000000185D88: D5207C06 00010004
	v_dual_mov_b32 v67, v65 :: v_dual_lshlrev_b32 v4, 9, v7    // 000000185D90: CA220141 43040E89
	.long 0xd7000000                                           // 000000185D98: D7000000
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 000000185D9C: 02020105
	s_delay_alu instid0(VALU_DEP_1)                            // 000000185DA0: BF870001
	v_add_co_ci_u32_e64 v184, null, 0, v6, s0                  // 000000185DA4: D5207CB8 00020C80
	v_xor_b32_e32 v5, 1, v7                                    // 000000185DAC: 3A0A0E81
	v_dual_mov_b32 v71, v65 :: v_dual_lshlrev_b32 v6, 5, v181  // 000000185DB0: CA220141 47076A85
	v_dual_mov_b32 v193, 0xf149f2ca :: v_dual_lshlrev_b32 v8, 1, v180// 000000185DB8: CA2200FF C1096881 F149F2CA
	v_lshl_add_u32 v3, v3, 9, 0x400                            // 000000185DC4: D6460003 03FD1303 00000400
	v_dual_mov_b32 v192, 0xf149f2ca :: v_dual_lshlrev_b32 v7, 8, v7// 000000185DD0: CA2200FF C0060E88 F149F2CA
	s_lshl_b64 s[4:5], s[20:21], 8                             // 000000185DDC: 84848814
	v_lshrrev_b32_e32 v183, 2, v180                            // 000000185DE0: 336F6882
	v_dual_mov_b32 v194, 0xf149f2ca :: v_dual_add_nc_u32 v185, v1, v2// 000000185DE4: CA2000FF C2B80501 F149F2CA
	v_lshl_add_u32 v186, v5, 10, v1                            // 000000185DF0: D64600BA 04051505
	v_or3_b32 v187, v4, v6, v8                                 // 000000185DF8: D65800BB 04220D04
	v_lshl_or_b32 v188, v180, 5, v4                            // 000000185E00: D65600BC 04110BB4
	v_or3_b32 v189, s4, v180, v182                             // 000000185E08: D65800BD 06DB6804
	v_dual_mov_b32 v190, s5 :: v_dual_add_nc_u32 v191, v3, v7  // 000000185E10: CA200005 BEBE0F03
	v_mov_b32_e32 v66, v65                                     // 000000185E18: 7E840341
	v_dual_mov_b32 v68, v65 :: v_dual_mov_b32 v195, 0xf149f2ca // 000000185E1C: CA100141 44C200FF F149F2CA
	v_dual_mov_b32 v70, v65 :: v_dual_mov_b32 v197, 0xf149f2ca // 000000185E28: CA100141 46C400FF F149F2CA
	v_dual_mov_b32 v72, v65 :: v_dual_mov_b32 v105, 0          // 000000185E34: CA100141 48680080
	v_dual_mov_b32 v196, 0xf149f2ca :: v_dual_mov_b32 v179, 0  // 000000185E3C: CA1000FF C4B20080 F149F2CA
	v_dual_mov_b32 v198, 0xf149f2ca :: v_dual_mov_b32 v107, 0  // 000000185E48: CA1000FF C66A0080 F149F2CA
	v_dual_mov_b32 v200, 0xf149f2ca :: v_dual_mov_b32 v199, 0  // 000000185E54: CA1000FF C8C60080 F149F2CA
	v_dual_mov_b32 v106, 0 :: v_dual_mov_b32 v201, 0           // 000000185E60: CA100080 6AC80080
	v_dual_mov_b32 v178, 0 :: v_dual_mov_b32 v1, 0             // 000000185E68: CA100080 B2000080
	v_dual_mov_b32 v2, v177 :: v_dual_mov_b32 v9, 0            // 000000185E70: CA1001B1 02080080
	v_mov_b32_e32 v3, v177                                     // 000000185E78: 7E0603B1
	v_dual_mov_b32 v4, v177 :: v_dual_mov_b32 v17, 0           // 000000185E7C: CA1001B1 04100080
	v_mov_b32_e32 v5, v177                                     // 000000185E84: 7E0A03B1
	v_dual_mov_b32 v6, v177 :: v_dual_mov_b32 v25, 0           // 000000185E88: CA1001B1 06180080
	v_mov_b32_e32 v7, v177                                     // 000000185E90: 7E0E03B1
	v_dual_mov_b32 v8, v177 :: v_dual_mov_b32 v57, 0           // 000000185E94: CA1001B1 08380080
	v_dual_mov_b32 v10, v177 :: v_dual_mov_b32 v49, 0          // 000000185E9C: CA1001B1 0A300080
	v_mov_b32_e32 v11, v177                                    // 000000185EA4: 7E1603B1
	v_dual_mov_b32 v12, v177 :: v_dual_mov_b32 v41, 0          // 000000185EA8: CA1001B1 0C280080
	v_mov_b32_e32 v13, v177                                    // 000000185EB0: 7E1A03B1
	v_dual_mov_b32 v14, v177 :: v_dual_mov_b32 v33, 0          // 000000185EB4: CA1001B1 0E200080
	v_mov_b32_e32 v15, v177                                    // 000000185EBC: 7E1E03B1
	v_mov_b32_e32 v16, v177                                    // 000000185EC0: 7E2003B1
	v_mov_b32_e32 v18, v177                                    // 000000185EC4: 7E2403B1
	v_mov_b32_e32 v19, v177                                    // 000000185EC8: 7E2603B1
	v_mov_b32_e32 v20, v177                                    // 000000185ECC: 7E2803B1
	v_mov_b32_e32 v21, v177                                    // 000000185ED0: 7E2A03B1
	v_mov_b32_e32 v22, v177                                    // 000000185ED4: 7E2C03B1
	v_mov_b32_e32 v23, v177                                    // 000000185ED8: 7E2E03B1
	v_mov_b32_e32 v24, v177                                    // 000000185EDC: 7E3003B1
	v_mov_b32_e32 v26, v177                                    // 000000185EE0: 7E3403B1
	v_mov_b32_e32 v27, v177                                    // 000000185EE4: 7E3603B1
	v_mov_b32_e32 v28, v177                                    // 000000185EE8: 7E3803B1
	v_mov_b32_e32 v29, v177                                    // 000000185EEC: 7E3A03B1
	v_mov_b32_e32 v30, v177                                    // 000000185EF0: 7E3C03B1
	v_mov_b32_e32 v31, v177                                    // 000000185EF4: 7E3E03B1
	v_mov_b32_e32 v32, v177                                    // 000000185EF8: 7E4003B1
	v_mov_b32_e32 v58, v177                                    // 000000185EFC: 7E7403B1
	v_mov_b32_e32 v59, v177                                    // 000000185F00: 7E7603B1
	v_mov_b32_e32 v60, v177                                    // 000000185F04: 7E7803B1
	v_mov_b32_e32 v61, v177                                    // 000000185F08: 7E7A03B1
	v_mov_b32_e32 v62, v177                                    // 000000185F0C: 7E7C03B1
	v_mov_b32_e32 v63, v177                                    // 000000185F10: 7E7E03B1
	v_mov_b32_e32 v64, v177                                    // 000000185F14: 7E8003B1
	v_mov_b32_e32 v50, v177                                    // 000000185F18: 7E6403B1
	v_mov_b32_e32 v51, v177                                    // 000000185F1C: 7E6603B1
	v_mov_b32_e32 v52, v177                                    // 000000185F20: 7E6803B1
	v_mov_b32_e32 v53, v177                                    // 000000185F24: 7E6A03B1
	v_mov_b32_e32 v54, v177                                    // 000000185F28: 7E6C03B1
	v_mov_b32_e32 v55, v177                                    // 000000185F2C: 7E6E03B1
	v_mov_b32_e32 v56, v177                                    // 000000185F30: 7E7003B1
	v_mov_b32_e32 v42, v177                                    // 000000185F34: 7E5403B1
	v_mov_b32_e32 v43, v177                                    // 000000185F38: 7E5603B1
	v_mov_b32_e32 v44, v177                                    // 000000185F3C: 7E5803B1
	v_mov_b32_e32 v45, v177                                    // 000000185F40: 7E5A03B1
	v_mov_b32_e32 v46, v177                                    // 000000185F44: 7E5C03B1
	v_mov_b32_e32 v47, v177                                    // 000000185F48: 7E5E03B1
	v_mov_b32_e32 v48, v177                                    // 000000185F4C: 7E6003B1
	v_mov_b32_e32 v34, v177                                    // 000000185F50: 7E4403B1
	v_mov_b32_e32 v35, v177                                    // 000000185F54: 7E4603B1
	v_mov_b32_e32 v36, v177                                    // 000000185F58: 7E4803B1
	v_mov_b32_e32 v37, v177                                    // 000000185F5C: 7E4A03B1
	v_mov_b32_e32 v38, v177                                    // 000000185F60: 7E4C03B1
	v_mov_b32_e32 v39, v177                                    // 000000185F64: 7E4E03B1
	v_mov_b32_e32 v40, v177                                    // 000000185F68: 7E5003B1
	s_mov_b32 s21, 0                                           // 000000185F6C: BE950080
	v_cmp_eq_u32_e32 vcc_lo, 2, v183                           // 000000185F70: 7C956E82
	s_branch 1068                                              // 000000185F74: BFA0042C <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi6EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1628>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000185F78: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000185F7C: BF870099
	s_or_b32 exec_lo, exec_lo, s17                             // 000000185F80: 8C7E117E
	v_ashrrev_i32_e32 v74, 31, v73                             // 000000185F84: 3494929F
	s_ashr_i32 s17, s16, 31                                    // 000000185F88: 86119F10
	s_ashr_i32 s23, s22, 31                                    // 000000185F8C: 86179F16
	s_lshl_b64 s[16:17], s[16:17], 9                           // 000000185F90: 84908910
	s_ashr_i32 s19, s18, 31                                    // 000000185F94: 86139F12
	.long 0xd73c0049                                           // 000000185F98: D73C0049
	v_cndmask_b32_e32 v1, 12, v73, vcc_lo                      // 000000185F9C: 0202928C
	s_lshl_b64 s[22:23], s[22:23], 9                           // 000000185FA0: 84968916
	s_ashr_i32 s25, s24, 31                                    // 000000185FA4: 86199F18
	s_lshl_b64 s[18:19], s[18:19], 9                           // 000000185FA8: 84928912
	s_lshl_b64 s[24:25], s[24:25], 9                           // 000000185FAC: 84988918
	s_add_i32 s28, s28, -1                                     // 000000185FB0: 811CC11C
	.long 0xd70000d5                                           // 000000185FB4: D70000D5
	v_cndmask_b32_e32 v1, v0, v73, vcc_lo                      // 000000185FB8: 02029300
	s_delay_alu instid0(VALU_DEP_1)                            // 000000185FBC: BF870001
	v_add_co_ci_u32_e64 v214, null, v184, v74, s0              // 000000185FC0: D5207CD6 000295B8
	ds_load_b128 v[145:148], v191                              // 000000185FC8: DBFC0000 910000BF
	ds_load_b128 v[149:152], v191 offset:16                    // 000000185FD0: DBFC0010 950000BF
	ds_load_b128 v[205:208], v191 offset:32                    // 000000185FD8: DBFC0020 CD0000BF
	ds_load_b128 v[209:212], v191 offset:48                    // 000000185FE0: DBFC0030 D10000BF
	ds_load_b128 v[77:80], v191 offset:80                      // 000000185FE8: DBFC0050 4D0000BF
	ds_load_b128 v[73:76], v191 offset:64                      // 000000185FF0: DBFC0040 490000BF
	ds_load_b128 v[85:88], v191 offset:112                     // 000000185FF8: DBFC0070 550000BF
	ds_load_b128 v[81:84], v191 offset:96                      // 000000186000: DBFC0060 510000BF
	ds_load_b128 v[93:96], v191 offset:144                     // 000000186008: DBFC0090 5D0000BF
	ds_load_b128 v[89:92], v191 offset:128                     // 000000186010: DBFC0080 590000BF
	ds_load_b128 v[101:104], v191 offset:176                   // 000000186018: DBFC00B0 650000BF
	ds_load_b128 v[97:100], v191 offset:160                    // 000000186020: DBFC00A0 610000BF
	ds_load_b128 v[117:120], v191 offset:208                   // 000000186028: DBFC00D0 750000BF
	ds_load_b128 v[113:116], v191 offset:192                   // 000000186030: DBFC00C0 710000BF
	ds_load_b128 v[125:128], v191 offset:240                   // 000000186038: DBFC00F0 7D0000BF
	ds_load_b128 v[121:124], v191 offset:224                   // 000000186040: DBFC00E0 790000BF
	s_clause 0x9                                               // 000000186048: BF850009
	global_load_b128 v[133:136], v[213:214], off offset:16     // 00000018604C: DC5E0010 857C00D5
	global_load_b128 v[129:132], v[213:214], off               // 000000186054: DC5E0000 817C00D5
	global_load_b128 v[141:144], v[213:214], off offset:144    // 00000018605C: DC5E0090 8D7C00D5
	global_load_b128 v[137:140], v[213:214], off offset:128    // 000000186064: DC5E0080 897C00D5
	global_load_b128 v[173:176], v[213:214], off offset:272    // 00000018606C: DC5E0110 AD7C00D5
	global_load_b128 v[169:172], v[213:214], off offset:256    // 000000186074: DC5E0100 A97C00D5
	global_load_b128 v[165:168], v[213:214], off offset:400    // 00000018607C: DC5E0190 A57C00D5
	global_load_b128 v[161:164], v[213:214], off offset:384    // 000000186084: DC5E0180 A17C00D5
	global_load_b128 v[157:160], v[213:214], off offset:528    // 00000018608C: DC5E0210 9D7C00D5
	global_load_b128 v[153:156], v[213:214], off offset:512    // 000000186094: DC5E0200 997C00D5
	s_waitcnt vmcnt(8) lgkmcnt(0)                              // 00000018609C: BF892007
	v_wmma_f32_16x16x16_bf16 v[105:112], v[145:152], v[129:136], v[65:72]// 0000001860A0: CC414069 1D070391
	s_clause 0x3                                               // 0000001860A8: BF850003
	global_load_b128 v[149:152], v[213:214], off offset:656    // 0000001860AC: DC5E0290 957C00D5
	global_load_b128 v[145:148], v[213:214], off offset:640    // 0000001860B4: DC5E0280 917C00D5
	global_load_b128 v[133:136], v[213:214], off offset:784    // 0000001860BC: DC5E0310 857C00D5
	global_load_b128 v[129:132], v[213:214], off offset:768    // 0000001860C4: DC5E0300 817C00D5
	s_waitcnt vmcnt(10)                                        // 0000001860CC: BF892BF7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[205:212], v[137:144], v[105:112]// 0000001860D0: CC414069 1DA713CD
	s_clause 0x1                                               // 0000001860D8: BF850001
	global_load_b128 v[141:144], v[213:214], off offset:912    // 0000001860DC: DC5E0390 8D7C00D5
	global_load_b128 v[137:140], v[213:214], off offset:896    // 0000001860E4: DC5E0380 897C00D5
	.long 0xd59c40cd                                           // 0000001860EC: D59C40CD
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 0000001860F0: 02010080
	s_waitcnt vmcnt(10)                                        // 0000001860F4: BF892BF7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[73:80], v[169:176], v[105:112]// 0000001860F8: CC414069 1DA75349
	.long 0xd7000049                                           // 000000186100: D7000049
	v_cndmask_b32_e32 v1, s16, v189, vcc_lo                    // 000000186104: 02037A10
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000186108: BF8701A1
	v_add_co_ci_u32_e64 v74, null, s17, v190, s0               // 00000018610C: D5207C4A 00037C11
	s_waitcnt vmcnt(8)                                         // 000000186114: BF8923F7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[81:88], v[161:168], v[105:112]// 000000186118: CC414069 1DA74351
	.long 0xd700004b                                           // 000000186120: D700004B
	v_cndmask_b32_e32 v1, s22, v189, vcc_lo                    // 000000186124: 02037A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000186128: BF8701A1
	v_add_co_ci_u32_e64 v76, null, s23, v190, s0               // 00000018612C: D5207C4C 00037C17
	s_waitcnt vmcnt(6)                                         // 000000186134: BF891BF7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[89:96], v[153:160], v[105:112]// 000000186138: CC414069 1DA73359
	.long 0xd700004d                                           // 000000186140: D700004D
	v_cndmask_b32_e32 v1, s18, v189, vcc_lo                    // 000000186144: 02037A12
	s_delay_alu instid0(VALU_DEP_1)                            // 000000186148: BF870001
	v_add_co_ci_u32_e64 v78, null, s19, v190, s0               // 00000018614C: D5207C4E 00037C13
	.long 0xd700004f                                           // 000000186154: D700004F
	v_cndmask_b32_e32 v1, s24, v189, vcc_lo                    // 000000186158: 02037A18
	.long 0xd73c0049                                           // 00000018615C: D73C0049
	v_cndmask_b32_e32 v1, 3, v73, vcc_lo                       // 000000186160: 02029283
	v_add_co_ci_u32_e64 v80, null, s25, v190, s0               // 000000186164: D5207C50 00037C19
	.long 0xd73c004b                                           // 00000018616C: D73C004B
	v_cndmask_b32_e32 v1, 3, v75, vcc_lo                       // 000000186170: 02029683
	.long 0xd73c004d                                           // 000000186174: D73C004D
	v_cndmask_b32_e32 v1, 3, v77, vcc_lo                       // 000000186178: 02029A83
	.long 0xd59c485a                                           // 00000018617C: D59C485A
	v_cndmask_b32_e32 v0, v205, v128, vcc_lo                   // 000000186180: 020101CD
	s_delay_alu instid0(VALU_DEP_4)                            // 000000186184: BF870004
	.long 0xd73c004f                                           // 000000186188: D73C004F
	v_cndmask_b32_e32 v1, 3, v79, vcc_lo                       // 00000018618C: 02029E83
	.long 0xd59c4859                                           // 000000186190: D59C4859
	v_cndmask_b32_e32 v0, v205, v128, vcc_lo                   // 000000186194: 020101CD
	.long 0xd59c485b                                           // 000000186198: D59C485B
	v_cndmask_b32_e32 v0, v205, v128, vcc_lo                   // 00000018619C: 020101CD
	.long 0xd59c485c                                           // 0000001861A0: D59C485C
	v_cndmask_b32_e32 v0, v205, v128, vcc_lo                   // 0000001861A4: 020101CD
	s_mov_b32 s19, s7                                          // 0000001861A8: BE930007
	s_mov_b32 s18, s6                                          // 0000001861AC: BE920006
	s_mov_b32 s17, s5                                          // 0000001861B0: BE910005
	s_mov_b32 s16, s4                                          // 0000001861B4: BE900004
	s_waitcnt vmcnt(4)                                         // 0000001861B8: BF8913F7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[97:104], v[145:152], v[105:112]// 0000001861BC: CC414069 1DA72361
	.long 0xd7000067                                           // 0000001861C4: D7000067
	v_cndmask_b32_e32 v1, s8, v73, vcc_lo                      // 0000001861C8: 02029208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001861CC: BF8701A1
	v_add_co_ci_u32_e64 v104, null, s9, v74, s0                // 0000001861D0: D5207C68 00029409
	s_waitcnt vmcnt(2)                                         // 0000001861D8: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[113:120], v[129:136], v[105:112]// 0000001861DC: CC414069 1DA70371
	.long 0xd7000065                                           // 0000001861E4: D7000065
	v_cndmask_b32_e32 v1, s8, v75, vcc_lo                      // 0000001861E8: 02029608
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001861EC: BF8701A1
	v_add_co_ci_u32_e64 v102, null, s9, v76, s0                // 0000001861F0: D5207C66 00029809
	s_waitcnt vmcnt(0)                                         // 0000001861F8: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[105:112], v[121:128], v[137:144], v[105:112]// 0000001861FC: CC414069 1DA71379
	.long 0xd7000063                                           // 000000186204: D7000063
	v_cndmask_b32_e32 v1, s8, v77, vcc_lo                      // 000000186208: 02029A08
	ds_store_2addr_b32 v185, v105, v106 offset1:32             // 00000018620C: D8382000 006A69B9
	ds_store_2addr_b32 v185, v107, v108 offset0:64 offset1:96  // 000000186214: D8386040 006C6BB9
	ds_store_2addr_b32 v185, v109, v110 offset0:128 offset1:160// 00000018621C: D838A080 006E6DB9
	ds_store_2addr_b32 v185, v111, v112 offset0:192 offset1:224// 000000186224: D838E0C0 00706FB9
	v_add_co_ci_u32_e64 v100, null, s9, v78, s0                // 00000018622C: D5207C64 00029C09
	.long 0xd7000061                                           // 000000186234: D7000061
	v_cndmask_b32_e32 v1, s8, v79, vcc_lo                      // 000000186238: 02029E08
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018623C: BF870001
	v_add_co_ci_u32_e64 v98, null, s9, v80, s0                 // 000000186240: D5207C62 0002A009
	.long 0xd4440000                                           // 000000186248: D4440000
	v_cndmask_b32_e32 v1, s29, v180, vcc_lo                    // 00000018624C: 0203681D
	s_add_i32 s29, s29, -16                                    // 000000186250: 811DD01D
	s_cmp_lg_u32 s28, 0                                        // 000000186254: BF07801C
	s_waitcnt lgkmcnt(0)                                       // 000000186258: BF89FC07
	s_barrier                                                  // 00000018625C: BFBD0000
	buffer_gl0_inv                                             // 000000186260: E0AC0000 00000000
	ds_load_2addr_b32 v[81:82], v186 offset1:32                // 000000186268: D8DC2000 510000BA
	ds_load_2addr_b32 v[83:84], v186 offset0:64 offset1:96     // 000000186270: D8DC6040 530000BA
	ds_load_2addr_b32 v[85:86], v186 offset0:128 offset1:160   // 000000186278: D8DCA080 550000BA
	ds_load_2addr_b32 v[87:88], v186 offset0:192 offset1:224   // 000000186280: D8DCE0C0 570000BA
	s_waitcnt lgkmcnt(3)                                       // 000000186288: BF89FC37
	v_dual_add_f32 v73, v106, v82 :: v_dual_add_f32 v74, v105, v81// 00000018628C: C908A56A 494AA369
	s_waitcnt lgkmcnt(2)                                       // 000000186294: BF89FC27
	v_dual_add_f32 v75, v108, v84 :: v_dual_add_f32 v76, v107, v83// 000000186298: C908A96C 4B4CA76B
	s_waitcnt lgkmcnt(1)                                       // 0000001862A0: BF89FC17
	v_dual_add_f32 v77, v110, v86 :: v_dual_add_f32 v78, v109, v85// 0000001862A4: C908AD6E 4D4EAB6D
	v_dual_mul_f32 v73, 0x3d800000, v73 :: v_dual_mul_f32 v74, 0x3d800000, v74// 0000001862AC: C8C692FF 494A94FF 3D800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001862B8: BF8701B3
	v_dual_mul_f32 v75, 0x3d800000, v75 :: v_dual_mul_f32 v76, 0x3d800000, v76// 0000001862BC: C8C696FF 4B4C98FF 3D800000
	s_waitcnt lgkmcnt(0)                                       // 0000001862C8: BF89FC07
	v_dual_add_f32 v79, v112, v88 :: v_dual_add_f32 v80, v111, v87// 0000001862CC: C908B170 4F50AF6F
	v_cndmask_b32_e64 v73, 0xf149f2ca, v73, s0                 // 0000001862D4: D5010049 000292FF F149F2CA
	v_cndmask_b32_e64 v74, 0xf149f2ca, v74, s0                 // 0000001862E0: D501004A 000294FF F149F2CA
	v_dual_mul_f32 v77, 0x3d800000, v77 :: v_dual_mul_f32 v78, 0x3d800000, v78// 0000001862EC: C8C69AFF 4D4E9CFF 3D800000
	v_cndmask_b32_e64 v75, 0xf149f2ca, v75, s0                 // 0000001862F8: D501004B 000296FF F149F2CA
	v_cndmask_b32_e64 v76, 0xf149f2ca, v76, s0                 // 000000186304: D501004C 000298FF F149F2CA
	s_delay_alu instid0(VALU_DEP_4)                            // 000000186310: BF870004
	v_mov_b32_dpp v81, v74 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186314: 7EA202FA FF09614A
	v_mov_b32_dpp v82, v73 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018631C: 7EA402FA FF096149
	v_dual_mul_f32 v79, 0x3d800000, v79 :: v_dual_mul_f32 v80, 0x3d800000, v80// 000000186324: C8C69EFF 4F50A0FF 3D800000
	v_cndmask_b32_e64 v77, 0xf149f2ca, v77, s0                 // 000000186330: D501004D 00029AFF F149F2CA
	v_cndmask_b32_e64 v78, 0xf149f2ca, v78, s0                 // 00000018633C: D501004E 00029CFF F149F2CA
	v_mov_b32_dpp v83, v76 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186348: 7EA602FA FF09614C
	v_mov_b32_dpp v84, v75 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186350: 7EA802FA FF09614B
	v_dual_max_f32 v81, v81, v81 :: v_dual_max_f32 v82, v82, v82// 000000186358: CA94A351 5152A552
	v_cndmask_b32_e64 v79, 0xf149f2ca, v79, s0                 // 000000186360: D501004F 00029EFF F149F2CA
	v_cndmask_b32_e64 v80, 0xf149f2ca, v80, s0                 // 00000018636C: D5010050 0002A0FF F149F2CA
	v_mov_b32_dpp v85, v78 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186378: 7EAA02FA FF09614E
	v_mov_b32_dpp v86, v77 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186380: 7EAC02FA FF09614D
	v_dual_max_f32 v83, v83, v83 :: v_dual_max_f32 v84, v84, v84// 000000186388: CA94A753 5354A954
	v_dual_max_f32 v81, v74, v81 :: v_dual_max_f32 v82, v73, v82// 000000186390: CA94A34A 5152A549
	v_mov_b32_dpp v87, v80 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186398: 7EAE02FA FF096150
	v_mov_b32_dpp v88, v79 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001863A0: 7EB002FA FF09614F
	v_dual_max_f32 v85, v85, v85 :: v_dual_max_f32 v86, v86, v86// 0000001863A8: CA94AB55 5556AD56
	v_dual_max_f32 v83, v76, v83 :: v_dual_max_f32 v84, v75, v84// 0000001863B0: CA94A74C 5354A94B
	v_mov_b32_dpp v93, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001863B8: 7EBA02FA FF096251
	v_mov_b32_dpp v94, v82 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001863C0: 7EBC02FA FF096252
	v_dual_max_f32 v87, v87, v87 :: v_dual_max_f32 v88, v88, v88// 0000001863C8: CA94AF57 5758B158
	v_dual_max_f32 v85, v78, v85 :: v_dual_max_f32 v86, v77, v86// 0000001863D0: CA94AB4E 5556AD4D
	v_mov_b32_dpp v95, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001863D8: 7EBE02FA FF096253
	v_mov_b32_dpp v96, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001863E0: 7EC002FA FF096254
	v_dual_max_f32 v93, v93, v93 :: v_dual_max_f32 v94, v94, v94// 0000001863E8: CA94BB5D 5D5EBD5E
	v_dual_max_f32 v87, v80, v87 :: v_dual_max_f32 v88, v79, v88// 0000001863F0: CA94AF50 5758B14F
	v_mov_b32_dpp v105, v85 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001863F8: 7ED202FA FF096255
	v_mov_b32_dpp v106, v86 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186400: 7ED402FA FF096256
	v_dual_max_f32 v95, v95, v95 :: v_dual_max_f32 v96, v96, v96// 000000186408: CA94BF5F 5F60C160
	v_dual_max_f32 v81, v81, v93 :: v_dual_max_f32 v82, v82, v94// 000000186410: CA94BB51 5152BD52
	v_mov_b32_dpp v107, v87 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186418: 7ED602FA FF096257
	v_mov_b32_dpp v108, v88 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186420: 7ED802FA FF096258
	v_dual_max_f32 v105, v105, v105 :: v_dual_max_f32 v106, v106, v106// 000000186428: CA94D369 696AD56A
	v_dual_max_f32 v83, v83, v95 :: v_dual_max_f32 v84, v84, v96// 000000186430: CA94BF53 5354C154
	v_mov_b32_dpp v93, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186438: 7EBA02FA FF096451
	v_mov_b32_dpp v94, v82 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186440: 7EBC02FA FF096452
	v_dual_max_f32 v107, v107, v107 :: v_dual_max_f32 v108, v108, v108// 000000186448: CA94D76B 6B6CD96C
	v_dual_max_f32 v85, v85, v105 :: v_dual_max_f32 v86, v86, v106// 000000186450: CA94D355 5556D556
	v_mov_b32_dpp v95, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186458: 7EBE02FA FF096453
	v_mov_b32_dpp v96, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186460: 7EC002FA FF096454
	v_dual_max_f32 v93, v93, v93 :: v_dual_max_f32 v94, v94, v94// 000000186468: CA94BB5D 5D5EBD5E
	v_dual_max_f32 v87, v87, v107 :: v_dual_max_f32 v88, v88, v108// 000000186470: CA94D757 5758D958
	v_mov_b32_dpp v105, v85 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186478: 7ED202FA FF096455
	v_mov_b32_dpp v106, v86 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186480: 7ED402FA FF096456
	v_dual_max_f32 v95, v95, v95 :: v_dual_max_f32 v96, v96, v96// 000000186488: CA94BF5F 5F60C160
	v_dual_max_f32 v81, v81, v93 :: v_dual_max_f32 v82, v82, v94// 000000186490: CA94BB51 5152BD52
	v_mov_b32_dpp v107, v87 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186498: 7ED602FA FF096457
	v_mov_b32_dpp v108, v88 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001864A0: 7ED802FA FF096458
	v_dual_max_f32 v105, v105, v105 :: v_dual_max_f32 v106, v106, v106// 0000001864A8: CA94D369 696AD56A
	v_dual_max_f32 v83, v83, v95 :: v_dual_max_f32 v84, v84, v96// 0000001864B0: CA94BF53 5354C154
	v_mov_b32_dpp v93, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001864B8: 7EBA02FA FF096851
	v_mov_b32_dpp v94, v82 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001864C0: 7EBC02FA FF096852
	v_dual_max_f32 v107, v107, v107 :: v_dual_max_f32 v108, v108, v108// 0000001864C8: CA94D76B 6B6CD96C
	v_dual_max_f32 v85, v85, v105 :: v_dual_max_f32 v86, v86, v106// 0000001864D0: CA94D355 5556D556
	v_mov_b32_dpp v95, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001864D8: 7EBE02FA FF096853
	v_mov_b32_dpp v96, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001864E0: 7EC002FA FF096854
	v_max3_f32 v111, v192, v81, v93                            // 0000001864E8: D61C006F 0576A3C0
	v_max3_f32 v112, v193, v82, v94                            // 0000001864F0: D61C0070 057AA5C1
	v_dual_max_f32 v87, v87, v107 :: v_dual_max_f32 v88, v88, v108// 0000001864F8: CA94D757 5758D958
	v_mov_b32_dpp v105, v85 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186500: 7ED202FA FF096855
	v_mov_b32_dpp v106, v86 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186508: 7ED402FA FF096856
	v_max3_f32 v113, v194, v83, v95                            // 000000186510: D61C0071 057EA7C2
	v_max3_f32 v114, v195, v84, v96                            // 000000186518: D61C0072 0582A9C3
	v_dual_sub_f32 v74, v74, v111 :: v_dual_sub_f32 v73, v73, v112// 000000186520: C94ADF4A 4A48E149
	v_mov_b32_dpp v107, v87 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186528: 7ED602FA FF096857
	v_mov_b32_dpp v108, v88 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000186530: 7ED802FA FF096858
	v_max3_f32 v115, v196, v85, v105                           // 000000186538: D61C0073 05A6ABC4
	v_max3_f32 v116, v197, v86, v106                           // 000000186540: D61C0074 05AAADC5
	v_dual_sub_f32 v76, v76, v113 :: v_dual_sub_f32 v75, v75, v114// 000000186548: C94AE34C 4C4AE54B
	v_dual_mul_f32 v81, 0x3fb8aa3b, v73 :: v_dual_mul_f32 v82, 0x3fb8aa3b, v74// 000000186550: C8C692FF 515294FF 3FB8AA3B
	v_max3_f32 v117, v198, v87, v107                           // 00000018655C: D61C0075 05AEAFC6
	v_max3_f32 v118, v200, v88, v108                           // 000000186564: D61C0076 05B2B1C8
	v_dual_sub_f32 v78, v78, v115 :: v_dual_sub_f32 v77, v77, v116// 00000018656C: C94AE74E 4E4CE94D
	v_dual_mul_f32 v83, 0x3fb8aa3b, v75 :: v_dual_mul_f32 v84, 0x3fb8aa3b, v76// 000000186574: C8C696FF 535498FF 3FB8AA3B
	v_fma_f32 v93, 0x3fb8aa3b, v73, -v81                       // 000000186580: D613005D 854692FF 3FB8AA3B
	v_rndne_f32_e32 v94, v81                                   // 00000018658C: 7EBC4751
	v_dual_sub_f32 v80, v80, v117 :: v_dual_sub_f32 v79, v79, v118// 000000186590: C94AEB50 504EED4F
	v_dual_mul_f32 v85, 0x3fb8aa3b, v77 :: v_dual_mul_f32 v86, 0x3fb8aa3b, v78// 000000186598: C8C69AFF 55569CFF 3FB8AA3B
	v_fma_f32 v95, 0x3fb8aa3b, v74, -v82                       // 0000001865A4: D613005F 854A94FF 3FB8AA3B
	v_rndne_f32_e32 v96, v82                                   // 0000001865B0: 7EC04752
	v_rndne_f32_e32 v108, v84                                  // 0000001865B4: 7ED84754
	v_fmac_f32_e32 v93, 0x32a5705f, v73                        // 0000001865B8: 56BA92FF 32A5705F
	v_sub_f32_e32 v81, v81, v94                                // 0000001865C0: 08A2BD51
	v_dual_mul_f32 v87, 0x3fb8aa3b, v79 :: v_dual_mul_f32 v88, 0x3fb8aa3b, v80// 0000001865C4: C8C69EFF 5758A0FF 3FB8AA3B
	v_fma_f32 v105, 0x3fb8aa3b, v75, -v83                      // 0000001865D0: D6130069 854E96FF 3FB8AA3B
	v_rndne_f32_e32 v106, v83                                  // 0000001865DC: 7ED44753
	v_fma_f32 v107, 0x3fb8aa3b, v76, -v84                      // 0000001865E0: D613006B 855298FF 3FB8AA3B
	v_rndne_f32_e32 v120, v86                                  // 0000001865EC: 7EF04756
	v_dual_fmac_f32 v95, 0x32a5705f, v74 :: v_dual_sub_f32 v82, v82, v96// 0000001865F0: C80A94FF 5F52C152 32A5705F
	v_dual_sub_f32 v84, v84, v108 :: v_dual_add_f32 v81, v81, v93// 0000001865FC: C948D954 5450BB51
	v_fma_f32 v119, 0x3fb8aa3b, v78, -v86                      // 000000186604: D6130077 855A9CFF 3FB8AA3B
	v_rndne_f32_e32 v124, v88                                  // 000000186610: 7EF84758
	v_dual_fmac_f32 v105, 0x32a5705f, v75 :: v_dual_sub_f32 v86, v86, v120// 000000186614: C80A96FF 6956F156 32A5705F
	v_dual_sub_f32 v83, v83, v106 :: v_dual_add_f32 v82, v82, v95// 000000186620: C948D553 5352BF52
	v_exp_f32_e32 v81, v81                                     // 000000186628: 7EA24B51
	v_fma_f32 v109, 0x3fb8aa3b, v77, -v85                      // 00000018662C: D613006D 85569AFF 3FB8AA3B
	v_rndne_f32_e32 v110, v85                                  // 000000186638: 7EDC4755
	v_fma_f32 v123, 0x3fb8aa3b, v80, -v88                      // 00000018663C: D613007B 8562A0FF 3FB8AA3B
	v_cvt_i32_f32_e32 v94, v94                                 // 000000186648: 7EBC115E
	v_fmac_f32_e32 v119, 0x32a5705f, v78                       // 00000018664C: 56EE9CFF 32A5705F
	v_fmac_f32_e32 v107, 0x32a5705f, v76                       // 000000186654: 56D698FF 32A5705F
	v_dual_sub_f32 v88, v88, v124 :: v_dual_add_f32 v83, v83, v105// 00000018665C: C948F958 5852D353
	v_exp_f32_e32 v82, v82                                     // 000000186664: 7EA44B52
	v_cvt_i32_f32_e32 v96, v96                                 // 000000186668: 7EC01160
	v_fmac_f32_e32 v123, 0x32a5705f, v80                       // 00000018666C: 56F6A0FF 32A5705F
	v_dual_sub_f32 v85, v85, v110 :: v_dual_add_f32 v86, v86, v119// 000000186674: C948DD55 5556EF56
	v_dual_fmac_f32 v109, 0x32a5705f, v77 :: v_dual_add_f32 v84, v84, v107// 00000018667C: C8089AFF 6D54D754 32A5705F
	v_exp_f32_e32 v83, v83                                     // 000000186688: 7EA64B53
	.long 0xd71c0051                                           // 00000018668C: D71C0051
	v_cndmask_b32_e32 v1, v81, v94, vcc_lo                     // 000000186690: 0202BD51
	.long 0xd41b0000                                           // 000000186694: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v73, vcc_lo              // 000000186698: 020292FF C2CE8ED0
	v_fma_f32 v121, 0x3fb8aa3b, v79, -v87                      // 0000001866A0: D6130079 855E9EFF 3FB8AA3B
	v_rndne_f32_e32 v122, v87                                  // 0000001866AC: 7EF44757
	v_cvt_i32_f32_e32 v106, v106                               // 0000001866B0: 7ED4116A
	v_dual_add_f32 v88, v88, v123 :: v_dual_add_f32 v85, v85, v109// 0000001866B4: C908F758 5854DB55
	v_exp_f32_e32 v84, v84                                     // 0000001866BC: 7EA84B54
	.long 0xd71c0052                                           // 0000001866C0: D71C0052
	v_cndmask_b32_e32 v1, v82, v96, vcc_lo                     // 0000001866C4: 0202C152
	v_cndmask_b32_e64 v81, 0, v81, s0                          // 0000001866C8: D5010051 0002A280
	.long 0xd41b0000                                           // 0000001866D0: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v74, vcc_lo              // 0000001866D4: 020294FF C2CE8ED0
	v_cvt_i32_f32_e32 v108, v108                               // 0000001866DC: 7ED8116C
	v_fmac_f32_e32 v121, 0x32a5705f, v79                       // 0000001866E0: 56F29EFF 32A5705F
	v_sub_f32_e32 v87, v87, v122                               // 0000001866E8: 08AEF557
	v_exp_f32_e32 v85, v85                                     // 0000001866EC: 7EAA4B55
	.long 0xd71c0053                                           // 0000001866F0: D71C0053
	v_cndmask_b32_e32 v1, v83, v106, vcc_lo                    // 0000001866F4: 0202D553
	v_cndmask_b32_e64 v82, 0, v82, s0                          // 0000001866F8: D5010052 0002A480
	.long 0xd41b0000                                           // 000000186700: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v75, vcc_lo              // 000000186704: 020296FF C2CE8ED0
	v_cvt_i32_f32_e32 v110, v110                               // 00000018670C: 7EDC116E
	v_add_f32_e32 v87, v87, v121                               // 000000186710: 06AEF357
	v_exp_f32_e32 v86, v86                                     // 000000186714: 7EAC4B56
	.long 0xd71c0054                                           // 000000186718: D71C0054
	v_cndmask_b32_e32 v1, v84, v108, vcc_lo                    // 00000018671C: 0202D954
	v_cndmask_b32_e64 v83, 0, v83, s0                          // 000000186720: D5010053 0002A680
	.long 0xd41b0000                                           // 000000186728: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v76, vcc_lo              // 00000018672C: 020298FF C2CE8ED0
	v_cvt_i32_f32_e32 v120, v120                               // 000000186734: 7EF01178
	v_exp_f32_e32 v87, v87                                     // 000000186738: 7EAE4B57
	.long 0xd71c0055                                           // 00000018673C: D71C0055
	v_cndmask_b32_e32 v1, v85, v110, vcc_lo                    // 000000186740: 0202DD55
	v_exp_f32_e32 v88, v88                                     // 000000186744: 7EB04B58
	v_cndmask_b32_e64 v84, 0, v84, s0                          // 000000186748: D5010054 0002A880
	.long 0xd41b0000                                           // 000000186750: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v77, vcc_lo              // 000000186754: 02029AFF C2CE8ED0
	v_cvt_i32_f32_e32 v93, v122                                // 00000018675C: 7EBA117A
	.long 0xd71c0056                                           // 000000186760: D71C0056
	v_cndmask_b32_e32 v1, v86, v120, vcc_lo                    // 000000186764: 0202F156
	v_cvt_i32_f32_e32 v95, v124                                // 000000186768: 7EBE117C
	s_delay_alu instid0(VALU_DEP_4)                            // 00000018676C: BF870004
	v_cndmask_b32_e64 v85, 0, v85, s0                          // 000000186770: D5010055 0002AA80
	.long 0xd41b0000                                           // 000000186778: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v78, vcc_lo              // 00000018677C: 02029CFF C2CE8ED0
	.long 0xd71c0057                                           // 000000186784: D71C0057
	v_cndmask_b32_e32 v1, v87, v93, vcc_lo                     // 000000186788: 0202BB57
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 00000018678C: BF870205
	.long 0xd71c0058                                           // 000000186790: D71C0058
	v_cndmask_b32_e32 v1, v88, v95, vcc_lo                     // 000000186794: 0202BF58
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000186798: BF8700A3
	v_cndmask_b32_e64 v86, 0, v86, s0                          // 00000018679C: D5010056 0002AC80
	.long 0xd41b0000                                           // 0000001867A4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v79, vcc_lo              // 0000001867A8: 02029EFF C2CE8ED0
	v_cndmask_b32_e64 v87, 0, v87, s0                          // 0000001867B0: D5010057 0002AE80
	.long 0xd41b0000                                           // 0000001867B8: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v80, vcc_lo              // 0000001867BC: 0202A0FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001867C4: BF8700A1
	v_cndmask_b32_e64 v88, 0, v88, s0                          // 0000001867C8: D5010058 0002B080
	.long 0xd41e0000                                           // 0000001867D0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v73, vcc_lo              // 0000001867D4: 020292FF 42B17218
	v_cndmask_b32_e64 v105, 0x7f800000, v81, s0                // 0000001867DC: D5010069 0002A2FF 7F800000
	.long 0xd41e0000                                           // 0000001867E8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v74, vcc_lo              // 0000001867EC: 020294FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001867F4: BF870112
	.long 0xd59c08cd                                           // 0000001867F8: D59C08CD
	v_cndmask_b32_e32 v0, v105, v128, vcc_lo                   // 0000001867FC: 02010169
	v_cndmask_b32_e64 v109, 0x7f800000, v82, s0                // 000000186800: D501006D 0002A4FF 7F800000
	.long 0xd41e0000                                           // 00000018680C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v75, vcc_lo              // 000000186810: 020296FF 42B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000186818: BF870193
	v_and_b32_e32 v73, 1, v205                                 // 00000018681C: 36939A81
	.long 0x7eb239ed                                           // 000000186820: 7EB239ED
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000186824: BF870223
	v_cndmask_b32_e64 v106, 0x7f800000, v83, s0                // 000000186828: D501006A 0002A6FF 7F800000
	.long 0xd41e0000                                           // 000000186834: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v76, vcc_lo              // 000000186838: 020298FF 42B17218
	v_add3_u32 v73, v105, v73, 0x7fff                          // 000000186840: D6550049 03FE9369 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000018684C: BF870214
	v_and_b32_e32 v75, 1, v89                                  // 000000186850: 3696B281
	.long 0xd59c08cd                                           // 000000186854: D59C08CD
	v_cndmask_b32_e32 v0, v106, v128, vcc_lo                   // 000000186858: 0201016A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000018685C: BF870224
	v_cndmask_b32_e64 v110, 0x7f800000, v84, s0                // 000000186860: D501006E 0002A8FF 7F800000
	.long 0xd41e0000                                           // 00000018686C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v77, vcc_lo              // 000000186870: 02029AFF 42B17218
	v_add3_u32 v75, v109, v75, 0x7fff                          // 000000186878: D655004B 03FE976D 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000186884: BF870214
	v_and_b32_e32 v74, 1, v205                                 // 000000186888: 36959A81
	.long 0x7eb439ee                                           // 00000018688C: 7EB439EE
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000186890: BF870224
	v_cndmask_b32_e64 v107, 0x7f800000, v85, s0                // 000000186894: D501006B 0002AAFF 7F800000
	.long 0xd41e0000                                           // 0000001868A0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v78, vcc_lo              // 0000001868A4: 02029CFF 42B17218
	v_add3_u32 v74, v106, v74, 0x7fff                          // 0000001868AC: D655004A 03FE956A 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001868B8: BF870214
	v_and_b32_e32 v76, 1, v90                                  // 0000001868BC: 3698B481
	.long 0xd59c08cd                                           // 0000001868C0: D59C08CD
	v_cndmask_b32_e32 v0, v107, v128, vcc_lo                   // 0000001868C4: 0201016B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001868C8: BF870224
	v_cndmask_b32_e64 v119, 0x7f800000, v86, s0                // 0000001868CC: D5010077 0002ACFF 7F800000
	.long 0xd41e0000                                           // 0000001868D8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v79, vcc_lo              // 0000001868DC: 02029EFF 42B17218
	v_add3_u32 v76, v110, v76, 0x7fff                          // 0000001868E4: D655004C 03FE996E 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001868F0: BF870214
	v_and_b32_e32 v78, 1, v205                                 // 0000001868F4: 369D9A81
	.long 0x7eb639f7                                           // 0000001868F8: 7EB639F7
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001868FC: BF870224
	v_cndmask_b32_e64 v108, 0x7f800000, v87, s0                // 000000186900: D501006C 0002AEFF 7F800000
	.long 0xd41e0000                                           // 00000018690C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v80, vcc_lo              // 000000186910: 0202A0FF 42B17218
	v_add3_u32 v78, v107, v78, 0x7fff                          // 000000186918: D655004E 03FE9D6B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000186924: BF870214
	v_and_b32_e32 v77, 1, v91                                  // 000000186928: 369AB681
	.long 0xd59c08cd                                           // 00000018692C: D59C08CD
	v_cndmask_b32_e32 v0, v108, v128, vcc_lo                   // 000000186930: 0201016C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000186934: BF870194
	v_cndmask_b32_e64 v168, 0x7f800000, v88, s0                // 000000186938: D50100A8 0002B0FF 7F800000
	v_add3_u32 v77, v119, v77, 0x7fff                          // 000000186944: D655004D 03FE9B77 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000186950: BF870193
	v_and_b32_e32 v80, 1, v205                                 // 000000186954: 36A19A81
	.long 0xd59c085c                                           // 000000186958: D59C085C
	v_cndmask_b32_e32 v0, v168, v128, vcc_lo                   // 00000018695C: 020101A8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000186960: BF870112
	v_add3_u32 v80, v108, v80, 0x7fff                          // 000000186964: D6550050 03FEA16C 00007FFF
	v_and_b32_e32 v79, 1, v92                                  // 000000186970: 369EB881
	s_delay_alu instid0(VALU_DEP_1)                            // 000000186974: BF870001
	v_add3_u32 v79, v168, v79, 0x7fff                          // 000000186978: D655004F 03FE9FA8 00007FFF
	ds_store_b16_d16_hi v187, v75                              // 000000186984: DA840000 00004BBB
	ds_store_b16_d16_hi v187, v73 offset:64                    // 00000018698C: DA840040 000049BB
	ds_store_b16_d16_hi v187, v76 offset:128                   // 000000186994: DA840080 00004CBB
	ds_store_b16_d16_hi v187, v74 offset:192                   // 00000018699C: DA8400C0 00004ABB
	ds_store_b16_d16_hi v187, v77 offset:256                   // 0000001869A4: DA840100 00004DBB
	ds_store_b16_d16_hi v187, v78 offset:320                   // 0000001869AC: DA840140 00004EBB
	ds_store_b16_d16_hi v187, v79 offset:384                   // 0000001869B4: DA840180 00004FBB
	ds_store_b16_d16_hi v187, v80 offset:448                   // 0000001869BC: DA8401C0 000050BB
	ds_load_b128 v[73:76], v188                                // 0000001869C4: DBFC0000 490000BC
	ds_load_b128 v[77:80], v188 offset:16                      // 0000001869CC: DBFC0010 4D0000BC
	s_clause 0x1f                                              // 0000001869D4: BF85001F
	global_load_b64 v[81:82], v[103:104], off                  // 0000001869D8: DC560000 517C0067
	global_load_b64 v[89:90], v[103:104], off offset:128       // 0000001869E0: DC560080 597C0067
	global_load_b64 v[120:121], v[103:104], off offset:256     // 0000001869E8: DC560100 787C0067
	global_load_b64 v[128:129], v[103:104], off offset:384     // 0000001869F0: DC560180 807C0067
	global_load_b64 v[83:84], v[101:102], off                  // 0000001869F8: DC560000 537C0065
	global_load_b64 v[91:92], v[101:102], off offset:128       // 000000186A00: DC560080 5B7C0065
	global_load_b64 v[122:123], v[101:102], off offset:256     // 000000186A08: DC560100 7A7C0065
	global_load_b64 v[130:131], v[101:102], off offset:384     // 000000186A10: DC560180 827C0065
	global_load_b64 v[85:86], v[99:100], off                   // 000000186A18: DC560000 557C0063
	global_load_b64 v[93:94], v[99:100], off offset:128        // 000000186A20: DC560080 5D7C0063
	global_load_b64 v[124:125], v[99:100], off offset:256      // 000000186A28: DC560100 7C7C0063
	global_load_b64 v[132:133], v[99:100], off offset:384      // 000000186A30: DC560180 847C0063
	global_load_b64 v[87:88], v[97:98], off                    // 000000186A38: DC560000 577C0061
	global_load_b64 v[95:96], v[97:98], off offset:128         // 000000186A40: DC560080 5F7C0061
	global_load_b64 v[126:127], v[97:98], off offset:256       // 000000186A48: DC560100 7E7C0061
	global_load_b64 v[134:135], v[97:98], off offset:384       // 000000186A50: DC560180 867C0061
	global_load_b64 v[136:137], v[103:104], off offset:512     // 000000186A58: DC560200 887C0067
	global_load_b64 v[144:145], v[103:104], off offset:640     // 000000186A60: DC560280 907C0067
	global_load_b64 v[152:153], v[103:104], off offset:768     // 000000186A68: DC560300 987C0067
	global_load_b64 v[160:161], v[103:104], off offset:896     // 000000186A70: DC560380 A07C0067
	global_load_b64 v[138:139], v[101:102], off offset:512     // 000000186A78: DC560200 8A7C0065
	global_load_b64 v[146:147], v[101:102], off offset:640     // 000000186A80: DC560280 927C0065
	global_load_b64 v[154:155], v[101:102], off offset:768     // 000000186A88: DC560300 9A7C0065
	global_load_b64 v[162:163], v[101:102], off offset:896     // 000000186A90: DC560380 A27C0065
	global_load_b64 v[140:141], v[99:100], off offset:512      // 000000186A98: DC560200 8C7C0063
	global_load_b64 v[148:149], v[99:100], off offset:640      // 000000186AA0: DC560280 947C0063
	global_load_b64 v[156:157], v[99:100], off offset:768      // 000000186AA8: DC560300 9C7C0063
	global_load_b64 v[164:165], v[99:100], off offset:896      // 000000186AB0: DC560380 A47C0063
	global_load_b64 v[142:143], v[97:98], off offset:512       // 000000186AB8: DC560200 8E7C0061
	global_load_b64 v[150:151], v[97:98], off offset:640       // 000000186AC0: DC560280 967C0061
	global_load_b64 v[158:159], v[97:98], off offset:768       // 000000186AC8: DC560300 9E7C0061
	global_load_b64 v[166:167], v[97:98], off offset:896       // 000000186AD0: DC560380 A67C0061
	v_dual_sub_f32 v98, v193, v112 :: v_dual_sub_f32 v99, v194, v113// 000000186AD8: C94AE1C1 6262E3C2
	v_sub_f32_e32 v100, v195, v114                             // 000000186AE0: 08C8E5C3
	v_sub_f32_e32 v104, v200, v118                             // 000000186AE4: 08D0EDC8
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000186AE8: BF8701B3
	v_dual_mov_b32 v193, v112 :: v_dual_mul_f32 v112, 0x3fb8aa3b, v98// 000000186AEC: CA060170 C170C4FF 3FB8AA3B
	v_dual_sub_f32 v101, v196, v115 :: v_dual_sub_f32 v102, v197, v116// 000000186AF8: C94AE7C4 6566E9C5
	v_dual_sub_f32 v97, v192, v111 :: v_dual_mov_b32 v200, v118// 000000186B00: C950DFC0 61C80176
	v_rndne_f32_e32 v172, v112                                 // 000000186B08: 7F584770
	v_dual_mov_b32 v195, v114 :: v_dual_mul_f32 v114, 0x3fb8aa3b, v100// 000000186B0C: CA060172 C372C8FF 3FB8AA3B
	v_dual_sub_f32 v103, v198, v117 :: v_dual_mov_b32 v192, v111// 000000186B18: C950EBC6 67C0016F
	v_mul_f32_e32 v118, 0x3fb8aa3b, v104                       // 000000186B20: 10ECD0FF 3FB8AA3B
	v_mov_b32_e32 v194, v113                                   // 000000186B28: 7F840371
	s_delay_alu instid0(VALU_DEP_4)                            // 000000186B2C: BF870004
	v_rndne_f32_e32 v176, v114                                 // 000000186B30: 7F604772
	v_dual_mov_b32 v197, v116 :: v_dual_mul_f32 v116, 0x3fb8aa3b, v102// 000000186B34: CA060174 C574CCFF 3FB8AA3B
	v_fma_f32 v175, 0x3fb8aa3b, v100, -v114                    // 000000186B40: D61300AF 85CAC8FF 3FB8AA3B
	v_fma_f32 v171, 0x3fb8aa3b, v98, -v112                     // 000000186B4C: D61300AB 85C2C4FF 3FB8AA3B
	v_fma_f32 v211, 0x3fb8aa3b, v104, -v118                    // 000000186B58: D61300D3 85DAD0FF 3FB8AA3B
	v_rndne_f32_e32 v212, v118                                 // 000000186B64: 7FA84776
	v_rndne_f32_e32 v208, v116                                 // 000000186B68: 7FA04774
	v_mul_f32_e32 v111, 0x3fb8aa3b, v97                        // 000000186B6C: 10DEC2FF 3FB8AA3B
	v_fma_f32 v207, 0x3fb8aa3b, v102, -v116                    // 000000186B74: D61300CF 85D2CCFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000186B80: BF870214
	v_dual_mul_f32 v113, 0x3fb8aa3b, v99 :: v_dual_sub_f32 v118, v118, v212// 000000186B84: C8CAC6FF 7177A976 3FB8AA3B
	v_sub_f32_e32 v116, v116, v208                             // 000000186B90: 08E9A174
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000186B94: BF870244
	v_fma_f32 v169, 0x3fb8aa3b, v97, -v111                     // 000000186B98: D61300A9 85BEC2FF 3FB8AA3B
	v_rndne_f32_e32 v170, v111                                 // 000000186BA4: 7F54476F
	v_fmac_f32_e32 v175, 0x32a5705f, v100                      // 000000186BA8: 575EC8FF 32A5705F
	v_dual_sub_f32 v114, v114, v176 :: v_dual_fmac_f32 v207, 0x32a5705f, v102// 000000186BB0: C9416172 72CECCFF 32A5705F
	v_fmac_f32_e32 v169, 0x32a5705f, v97                       // 000000186BBC: 5752C2FF 32A5705F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000186BC4: BF870004
	v_sub_f32_e32 v111, v111, v170                             // 000000186BC8: 08DF556F
	v_fma_f32 v173, 0x3fb8aa3b, v99, -v113                     // 000000186BCC: D61300AD 85C6C6FF 3FB8AA3B
	v_rndne_f32_e32 v174, v113                                 // 000000186BD8: 7F5C4771
	v_sub_f32_e32 v112, v112, v172                             // 000000186BDC: 08E15970
	v_fmac_f32_e32 v211, 0x32a5705f, v104                      // 000000186BE0: 57A6D0FF 32A5705F
	v_dual_fmac_f32 v171, 0x32a5705f, v98 :: v_dual_add_f32 v114, v114, v175// 000000186BE8: C808C4FF AB735F72 32A5705F
	v_dual_add_f32 v116, v116, v207 :: v_dual_add_f32 v111, v111, v169// 000000186BF4: C9099F74 746F536F
	v_dual_mov_b32 v196, v115 :: v_dual_fmac_f32 v173, 0x32a5705f, v99// 000000186BFC: CA000173 C4ACC6FF 32A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000186C08: BF870214
	v_dual_sub_f32 v113, v113, v174 :: v_dual_add_f32 v118, v118, v211// 000000186C0C: C9495D71 7177A776
	v_dual_mul_f32 v115, 0x3fb8aa3b, v101 :: v_dual_add_f32 v112, v112, v171// 000000186C14: C8C8CAFF 73715770 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000186C20: BF8701A4
	v_exp_f32_e32 v111, v111                                   // 000000186C24: 7EDE4B6F
	v_cvt_i32_f32_e32 v170, v170                               // 000000186C28: 7F5411AA
	v_add_f32_e32 v113, v113, v173                             // 000000186C2C: 06E35B71
	s_delay_alu instid0(VALU_DEP_3)                            // 000000186C30: BF870003
	v_fma_f32 v205, 0x3fb8aa3b, v101, -v115                    // 000000186C34: D61300CD 85CECAFF 3FB8AA3B
	v_rndne_f32_e32 v206, v115                                 // 000000186C40: 7F9C4773
	v_exp_f32_e32 v112, v112                                   // 000000186C44: 7EE04B70
	v_dual_mov_b32 v198, v117 :: v_dual_mul_f32 v117, 0x3fb8aa3b, v103// 000000186C48: CA060175 C674CEFF 3FB8AA3B
	v_cvt_i32_f32_e32 v172, v172                               // 000000186C54: 7F5811AC
	v_fmac_f32_e32 v205, 0x32a5705f, v101                      // 000000186C58: 579ACAFF 32A5705F
	v_sub_f32_e32 v115, v115, v206                             // 000000186C60: 08E79D73
	v_exp_f32_e32 v113, v113                                   // 000000186C64: 7EE24B71
	.long 0xd71c006f                                           // 000000186C68: D71C006F
	v_cndmask_b32_e32 v1, v111, v170, vcc_lo                   // 000000186C6C: 0203556F
	.long 0xd41b0000                                           // 000000186C70: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v97, vcc_lo              // 000000186C74: 0202C2FF C2CE8ED0
	v_fma_f32 v209, 0x3fb8aa3b, v103, -v117                    // 000000186C7C: D61300D1 85D6CEFF 3FB8AA3B
	v_rndne_f32_e32 v210, v117                                 // 000000186C88: 7FA44775
	v_cvt_i32_f32_e32 v174, v174                               // 000000186C8C: 7F5C11AE
	v_add_f32_e32 v115, v115, v205                             // 000000186C90: 06E79B73
	v_exp_f32_e32 v114, v114                                   // 000000186C94: 7EE44B72
	.long 0xd71c0070                                           // 000000186C98: D71C0070
	v_cndmask_b32_e32 v1, v112, v172, vcc_lo                   // 000000186C9C: 02035970
	v_cndmask_b32_e64 v111, 0, v111, s0                        // 000000186CA0: D501006F 0002DE80
	.long 0xd41b0000                                           // 000000186CA8: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v98, vcc_lo              // 000000186CAC: 0202C4FF C2CE8ED0
	v_cvt_i32_f32_e32 v176, v176                               // 000000186CB4: 7F6011B0
	v_fmac_f32_e32 v209, 0x32a5705f, v103                      // 000000186CB8: 57A2CEFF 32A5705F
	v_sub_f32_e32 v117, v117, v210                             // 000000186CC0: 08EBA575
	v_exp_f32_e32 v115, v115                                   // 000000186CC4: 7EE64B73
	.long 0xd71c0071                                           // 000000186CC8: D71C0071
	v_cndmask_b32_e32 v1, v113, v174, vcc_lo                   // 000000186CCC: 02035D71
	v_cndmask_b32_e64 v112, 0, v112, s0                        // 000000186CD0: D5010070 0002E080
	.long 0xd41b0000                                           // 000000186CD8: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v99, vcc_lo              // 000000186CDC: 0202C6FF C2CE8ED0
	v_cvt_i32_f32_e32 v206, v206                               // 000000186CE4: 7F9C11CE
	v_add_f32_e32 v117, v117, v209                             // 000000186CE8: 06EBA375
	v_exp_f32_e32 v116, v116                                   // 000000186CEC: 7EE84B74
	.long 0xd71c0072                                           // 000000186CF0: D71C0072
	v_cndmask_b32_e32 v1, v114, v176, vcc_lo                   // 000000186CF4: 02036172
	v_cndmask_b32_e64 v113, 0, v113, s0                        // 000000186CF8: D5010071 0002E280
	.long 0xd41b0000                                           // 000000186D00: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v100, vcc_lo             // 000000186D04: 0202C8FF C2CE8ED0
	v_cvt_i32_f32_e32 v208, v208                               // 000000186D0C: 7FA011D0
	v_exp_f32_e32 v117, v117                                   // 000000186D10: 7EEA4B75
	.long 0xd71c0073                                           // 000000186D14: D71C0073
	v_cndmask_b32_e32 v1, v115, v206, vcc_lo                   // 000000186D18: 02039D73
	v_exp_f32_e32 v118, v118                                   // 000000186D1C: 7EEC4B76
	v_cndmask_b32_e64 v114, 0, v114, s0                        // 000000186D20: D5010072 0002E480
	.long 0xd41b0000                                           // 000000186D28: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v101, vcc_lo             // 000000186D2C: 0202CAFF C2CE8ED0
	v_cvt_i32_f32_e32 v169, v210                               // 000000186D34: 7F5211D2
	.long 0xd71c0074                                           // 000000186D38: D71C0074
	v_cndmask_b32_e32 v1, v116, v208, vcc_lo                   // 000000186D3C: 0203A174
	v_cvt_i32_f32_e32 v171, v212                               // 000000186D40: 7F5611D4
	s_delay_alu instid0(VALU_DEP_4)                            // 000000186D44: BF870004
	v_cndmask_b32_e64 v115, 0, v115, s0                        // 000000186D48: D5010073 0002E680
	.long 0xd41b0000                                           // 000000186D50: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v102, vcc_lo             // 000000186D54: 0202CCFF C2CE8ED0
	.long 0xd71c0075                                           // 000000186D5C: D71C0075
	v_cndmask_b32_e32 v1, v117, v169, vcc_lo                   // 000000186D60: 02035375
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 000000186D64: BF870205
	.long 0xd71c0076                                           // 000000186D68: D71C0076
	v_cndmask_b32_e32 v1, v118, v171, vcc_lo                   // 000000186D6C: 02035776
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000186D70: BF8700A3
	v_cndmask_b32_e64 v116, 0, v116, s0                        // 000000186D74: D5010074 0002E880
	.long 0xd41b0000                                           // 000000186D7C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v103, vcc_lo             // 000000186D80: 0202CEFF C2CE8ED0
	v_cndmask_b32_e64 v117, 0, v117, s0                        // 000000186D88: D5010075 0002EA80
	.long 0xd41b0000                                           // 000000186D90: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v104, vcc_lo             // 000000186D94: 0202D0FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000186D9C: BF8700A1
	v_cndmask_b32_e64 v118, 0, v118, s0                        // 000000186DA0: D5010076 0002EC80
	.long 0xd41e0000                                           // 000000186DA8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v97, vcc_lo              // 000000186DAC: 0202C2FF 42B17218
	v_cndmask_b32_e64 v97, 0x7f800000, v111, s0                // 000000186DB4: D5010061 0002DEFF 7F800000
	.long 0xd41e0000                                           // 000000186DC0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v98, vcc_lo              // 000000186DC4: 0202C4FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000186DCC: BF870112
	v_mul_f32_e32 v9, v9, v97                                  // 000000186DD0: 1012C309
	v_cndmask_b32_e64 v98, 0x7f800000, v112, s0                // 000000186DD4: D5010062 0002E0FF 7F800000
	.long 0xd41e0000                                           // 000000186DE0: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v99, vcc_lo              // 000000186DE4: 0202C6FF 42B17218
	v_mul_f32_e32 v1, v1, v97                                  // 000000186DEC: 1002C301
	v_fma_f32 v177, v177, v97, v109                            // 000000186DF0: D61300B1 05B6C3B1
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000186DF8: BF870214
	v_mul_f32_e32 v58, v58, v98                                // 000000186DFC: 1074C53A
	v_cndmask_b32_e64 v99, 0x7f800000, v113, s0                // 000000186E00: D5010063 0002E2FF 7F800000
	.long 0xd41e0000                                           // 000000186E0C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v100, vcc_lo             // 000000186E10: 0202C8FF 42B17218
	v_mul_f32_e32 v50, v50, v98                                // 000000186E18: 1064C532
	v_mul_f32_e32 v42, v42, v98                                // 000000186E1C: 1054C52A
	v_mul_f32_e32 v34, v34, v98                                // 000000186E20: 1044C522
	v_mul_f32_e32 v26, v26, v98                                // 000000186E24: 1034C51A
	v_cndmask_b32_e64 v100, 0x7f800000, v114, s0               // 000000186E28: D5010064 0002E4FF 7F800000
	.long 0xd41e0000                                           // 000000186E34: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v101, vcc_lo             // 000000186E38: 0202CAFF 42B17218
	v_dual_mul_f32 v17, v17, v97 :: v_dual_mul_f32 v18, v18, v98// 000000186E40: C8C6C311 1112C512
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000186E48: BF870193
	v_dual_mul_f32 v19, v19, v99 :: v_dual_mul_f32 v60, v60, v100// 000000186E4C: C8C6C713 133CC93C
	v_cndmask_b32_e64 v101, 0x7f800000, v115, s0               // 000000186E54: D5010065 0002E6FF 7F800000
	.long 0xd41e0000                                           // 000000186E60: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v102, vcc_lo             // 000000186E64: 0202CCFF 42B17218
	v_mul_f32_e32 v52, v52, v100                               // 000000186E6C: 1068C934
	v_mul_f32_e32 v44, v44, v100                               // 000000186E70: 1058C92C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000186E74: BF870214
	v_dual_mul_f32 v36, v36, v100 :: v_dual_mul_f32 v61, v61, v101// 000000186E78: C8C6C924 243CCB3D
	v_cndmask_b32_e64 v102, 0x7f800000, v116, s0               // 000000186E80: D5010066 0002E8FF 7F800000
	.long 0xd41e0000                                           // 000000186E8C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v103, vcc_lo             // 000000186E90: 0202CEFF 42B17218
	v_mul_f32_e32 v57, v57, v97                                // 000000186E98: 1072C339
	v_mul_f32_e32 v49, v49, v97                                // 000000186E9C: 1062C331
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000186EA0: BF870214
	v_dual_mul_f32 v53, v53, v101 :: v_dual_mul_f32 v62, v62, v102// 000000186EA4: C8C6CB35 353ECD3E
	v_cndmask_b32_e64 v103, 0x7f800000, v117, s0               // 000000186EAC: D5010067 0002EAFF 7F800000
	.long 0xd41e0000                                           // 000000186EB8: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v104, vcc_lo             // 000000186EBC: 0202D0FF 42B17218
	v_dual_mul_f32 v54, v54, v102 :: v_dual_mul_f32 v41, v41, v97// 000000186EC4: C8C6CD36 3628C329
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000186ECC: BF870223
	v_dual_mul_f32 v22, v22, v102 :: v_dual_mul_f32 v63, v63, v103// 000000186ED0: C8C6CD16 163ECF3F
	v_mul_f32_e32 v28, v28, v100                               // 000000186ED8: 1038C91C
	v_cndmask_b32_e64 v104, 0x7f800000, v118, s0               // 000000186EDC: D5010068 0002ECFF 7F800000
	v_mul_f32_e32 v59, v59, v99                                // 000000186EE8: 1076C73B
	v_mul_f32_e32 v51, v51, v99                                // 000000186EEC: 1066C733
	v_dual_mul_f32 v55, v55, v103 :: v_dual_mul_f32 v20, v20, v100// 000000186EF0: C8C6CF37 3714C914
	s_delay_alu instid0(VALU_DEP_4)                            // 000000186EF8: BF870004
	v_mul_f32_e32 v64, v64, v104                               // 000000186EFC: 1080D140
	v_dual_mul_f32 v56, v56, v104 :: v_dual_mul_f32 v43, v43, v99// 000000186F00: C8C6D138 382AC72B
	v_dual_mul_f32 v24, v24, v104 :: v_dual_mul_f32 v45, v45, v101// 000000186F08: C8C6D118 182CCB2D
	v_mul_f32_e32 v10, v10, v98                                // 000000186F10: 1014C50A
	v_dual_mul_f32 v46, v46, v102 :: v_dual_mul_f32 v47, v47, v103// 000000186F14: C8C6CD2E 2E2ECF2F
	v_mul_f32_e32 v12, v12, v100                               // 000000186F1C: 1018C90C
	v_dual_mul_f32 v48, v48, v104 :: v_dual_mul_f32 v33, v33, v97// 000000186F20: C8C6D130 3020C321
	v_dual_mul_f32 v14, v14, v102 :: v_dual_mul_f32 v35, v35, v99// 000000186F28: C8C6CD0E 0E22C723
	v_dual_mul_f32 v16, v16, v104 :: v_dual_mul_f32 v37, v37, v101// 000000186F30: C8C6D110 1024CB25
	v_mul_f32_e32 v2, v2, v98                                  // 000000186F38: 1004C502
	v_dual_mul_f32 v38, v38, v102 :: v_dual_mul_f32 v39, v39, v103// 000000186F3C: C8C6CD26 2626CF27
	v_mul_f32_e32 v4, v4, v100                                 // 000000186F44: 1008C904
	v_dual_mul_f32 v40, v40, v104 :: v_dual_mul_f32 v25, v25, v97// 000000186F48: C8C6D128 2818C319
	v_dual_mul_f32 v6, v6, v102 :: v_dual_mul_f32 v27, v27, v99// 000000186F50: C8C6CD06 061AC71B
	v_fmac_f32_e32 v108, v201, v104                            // 000000186F58: 56D8D1C9
	v_dual_mul_f32 v29, v29, v101 :: v_dual_mul_f32 v8, v8, v104// 000000186F5C: C8C6CB1D 1D08D108
	v_dual_mul_f32 v30, v30, v102 :: v_dual_mul_f32 v31, v31, v103// 000000186F64: C8C6CD1E 1E1ECF1F
	v_dual_mul_f32 v32, v32, v104 :: v_dual_mul_f32 v21, v21, v101// 000000186F6C: C8C6D120 2014CB15
	v_mul_f32_e32 v23, v23, v103                               // 000000186F74: 102ECF17
	v_mul_f32_e32 v11, v11, v99                                // 000000186F78: 1016C70B
	v_mul_f32_e32 v13, v13, v101                               // 000000186F7C: 101ACB0D
	v_mul_f32_e32 v15, v15, v103                               // 000000186F80: 101ECF0F
	v_mul_f32_e32 v3, v3, v99                                  // 000000186F84: 1006C703
	v_mul_f32_e32 v5, v5, v101                                 // 000000186F88: 100ACB05
	v_mul_f32_e32 v7, v7, v103                                 // 000000186F8C: 100ECF07
	v_fma_f32 v179, v179, v99, v110                            // 000000186F90: D61300B3 05BAC7B3
	v_fma_f32 v178, v178, v101, v119                           // 000000186F98: D61300B2 05DECBB2
	v_fma_f32 v199, v199, v103, v168                           // 000000186FA0: D61300C7 06A2CFC7
	v_dual_fmac_f32 v105, v204, v98 :: v_dual_fmac_f32 v106, v203, v100// 000000186FA8: C800C5CC 696AC9CB
	v_fmac_f32_e32 v107, v202, v102                            // 000000186FB0: 56D6CDCA
	v_mov_b32_e32 v201, v108                                   // 000000186FB4: 7F92036C
	s_waitcnt vmcnt(19) lgkmcnt(0)                             // 000000186FB8: BF894C07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[73:80], v[81:88], v[57:64]// 000000186FBC: CC414039 1CE6A349
	s_waitcnt vmcnt(18)                                        // 000000186FC4: BF894BF7
	v_wmma_f32_16x16x16_bf16 v[49:56], v[73:80], v[89:96], v[49:56]// 000000186FC8: CC414031 1CC6B349
	s_waitcnt vmcnt(17)                                        // 000000186FD0: BF8947F7
	v_wmma_f32_16x16x16_bf16 v[41:48], v[73:80], v[120:127], v[41:48]// 000000186FD4: CC414029 1CA6F149
	s_waitcnt vmcnt(16)                                        // 000000186FDC: BF8943F7
	v_wmma_f32_16x16x16_bf16 v[33:40], v[73:80], v[128:135], v[33:40]// 000000186FE0: CC414021 1C870149
	s_waitcnt vmcnt(3)                                         // 000000186FE8: BF890FF7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[73:80], v[136:143], v[25:32]// 000000186FEC: CC414019 1C671149
	s_waitcnt vmcnt(2)                                         // 000000186FF4: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[17:24], v[73:80], v[144:151], v[17:24]// 000000186FF8: CC414011 1C472149
	s_waitcnt vmcnt(1)                                         // 000000187000: BF8907F7
	v_wmma_f32_16x16x16_bf16 v[9:16], v[73:80], v[152:159], v[9:16]// 000000187004: CC414009 1C273149
	s_waitcnt vmcnt(0)                                         // 00000018700C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[1:8], v[73:80], v[160:167], v[1:8]// 000000187010: CC414001 1C074149
	s_barrier                                                  // 000000187018: BFBD0000
	buffer_gl0_inv                                             // 00000018701C: E0AC0000 00000000
	s_cbranch_scc0 51                                          // 000000187024: BFA10033 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi6EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x16f4>
	s_mov_b32 s0, s21                                          // 000000187028: BE800015
	s_add_i32 s21, s21, 4                                      // 00000018702C: 81158415
	v_dual_mov_b32 v202, v107 :: v_dual_mov_b32 v203, v106     // 000000187030: CA10016B CACA016A
	s_min_i32 s4, s21, s30                                     // 000000187038: 89041E15
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000018703C: BF870499
	s_ashr_i32 s5, s4, 31                                      // 000000187040: 86059F04
	s_lshl_b64 s[4:5], s[4:5], 2                               // 000000187044: 84848204
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000187048: BF870009
	s_add_u32 s4, s14, s4                                      // 00000018704C: 8004040E
	s_addc_u32 s5, s15, s5                                     // 000000187050: 8205050F
	s_cmp_lt_i32 s0, s27                                       // 000000187054: BF041B00
	s_cselect_b32 s6, s3, s26                                  // 000000187058: 98061A03
	s_cmp_lt_i32 s0, s1                                        // 00000018705C: BF040100
	s_waitcnt lgkmcnt(0)                                       // 000000187060: BF89FC07
	s_cselect_b32 s16, s16, s6                                 // 000000187064: 98100610
	s_add_i32 s22, s0, 1                                       // 000000187068: 81168100
	s_load_b128 s[4:7], s[4:5], null                           // 00000018706C: F4080102 F8000000
	s_cmp_lt_i32 s22, s27                                      // 000000187074: BF041B16
	v_dual_mov_b32 v204, v105 :: v_dual_mov_b32 v73, s16       // 000000187078: CA100169 CC480010
	s_cselect_b32 s23, s3, s26                                 // 000000187080: 98171A03
	s_cmp_lt_i32 s22, s1                                       // 000000187084: BF040116
	s_cselect_b32 s22, s17, s23                                // 000000187088: 98161711
	s_add_i32 s17, s0, 2                                       // 00000018708C: 81118200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 000000187090: BF8704D9
	s_cmp_lt_i32 s17, s27                                      // 000000187094: BF041B11
	s_cselect_b32 s23, s3, s26                                 // 000000187098: 98171A03
	s_cmp_lt_i32 s17, s1                                       // 00000018709C: BF040111
	s_cselect_b32 s18, s18, s23                                // 0000001870A0: 98121712
	s_add_i32 s17, s0, 3                                       // 0000001870A4: 81118300
	s_cmp_lt_i32 s17, s27                                      // 0000001870A8: BF041B11
	s_cselect_b32 s23, s3, s26                                 // 0000001870AC: 98171A03
	s_cmp_lt_i32 s17, s1                                       // 0000001870B0: BF040111
	s_mov_b32 s17, exec_lo                                     // 0000001870B4: BE91007E
	s_cselect_b32 s24, s19, s23                                // 0000001870B8: 98181713
	v_cmpx_lt_i32_e32 0, v183                                  // 0000001870BC: 7D836E80
	s_cbranch_execz 64430                                      // 0000001870C0: BFA5FBAE <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi6EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x57c>
	.long 0xd44d0000                                           // 0000001870C4: D44D0000
	v_cndmask_b32_e32 v1, 1, v183, vcc_lo                      // 0000001870C8: 02036E81
	s_and_saveexec_b32 s19, s0                                 // 0000001870CC: BE932000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001870D0: BF870009
	s_xor_b32 s0, exec_lo, s19                                 // 0000001870D4: 8D00137E
	v_mov_b32_e32 v73, s18                                     // 0000001870D8: 7E920212
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001870DC: BF870001
	v_cndmask_b32_e32 v73, s24, v73, vcc_lo                    // 0000001870E0: 02929218
	s_and_not1_saveexec_b32 s0, s0                             // 0000001870E4: BE803000
	s_cbranch_execz 64419                                      // 0000001870E8: BFA5FBA3 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi6EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x578>
	v_mov_b32_e32 v73, s22                                     // 0000001870EC: 7E920216
	s_branch 64417                                             // 0000001870F0: BFA0FBA1 <_ZN7halogen12_GLOBAL__N_114k_attn_qs_bt2wILi7ELi6EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x578>
	v_mov_b32_e32 v8, v182                                     // 0000001870F4: 7E1003B6
	s_mul_i32 s0, s20, 12                                      // 0000001870F8: 96008C14
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001870FC: BF870001
	v_or_b32_e32 v7, v8, v180                                  // 000000187100: 380F6908
	v_or_b32_e32 v0, s0, v181                                  // 000000187104: 38016A00
	v_mov_b32_dpp v78, v107 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187108: 7E9C02FA FF09616B
	v_mov_b32_dpp v75, v106 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187110: 7E9602FA FF09616A
	v_mov_b32_dpp v74, v179 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187118: 7E9402FA FF0961B3
	v_mov_b32_dpp v76, v178 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187120: 7E9802FA FF0961B2
	v_lshlrev_b32_e32 v0, 8, v0                                // 000000187128: 30000088
	v_mov_b32_e32 v8, 0                                        // 00000018712C: 7E100280
	v_dual_add_f32 v78, v107, v78 :: v_dual_add_f32 v81, v106, v75// 000000187130: C9089D6B 4E50976A
	v_add_f32_e32 v83, v179, v74                               // 000000187138: 06A695B3
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000018713C: BF870214
	v_add_nc_u32_e32 v23, 0x400, v0                            // 000000187140: 4A2E00FF 00000400
	v_mad_i64_i32 v[7:8], null, 0x1800, s2, v[7:8]             // 000000187148: D6FF7C07 041C04FF 00001800
	v_ashrrev_i32_e32 v16, 31, v0                              // 000000187154: 3420009F
	v_add_nc_u32_e32 v31, 0x600, v0                            // 000000187158: 4A3E00FF 00000600
	v_add_nc_u32_e32 v39, 0x800, v0                            // 000000187160: 4A4E00FF 00000800
	v_ashrrev_i32_e32 v24, 31, v23                             // 000000187168: 34302E9F
	v_or_b32_e32 v65, 0x200, v0                                // 00000018716C: 388200FF 00000200
	v_add_f32_dpp v81, v81, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187174: 06A2A2FA FF096251
	v_ashrrev_i32_e32 v32, 31, v31                             // 00000018717C: 34403E9F
	.long 0xd7006a0f                                           // 000000187180: D7006A0F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 000000187184: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000187188: BF8700A1
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 00000018718C: D5207C10 01AA2108
	.long 0xd7006a17                                           // 000000187194: D7006A17
	v_cndmask_b32_e32 v1, v7, v23, vcc_lo                      // 000000187198: 02022F07
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 00000018719C: D5207C18 01AA3108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001871A4: BF870233
	.long 0xd73c000f                                           // 0000001871A8: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000001871AC: 02021E81
	v_add_nc_u32_e32 v0, 0xa00, v0                             // 0000001871B0: 4A0000FF 00000A00
	v_ashrrev_i32_e32 v40, 31, v39                             // 0000001871B8: 34504E9F
	.long 0xd73c0017                                           // 0000001871BC: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000001871C0: 02022E81
	v_ashrrev_i32_e32 v66, 31, v65                             // 0000001871C4: 3484829F
	v_add_f32_dpp v78, v78, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001871C8: 069C9CFA FF09624E
	.long 0xd7006a45                                           // 0000001871D0: D7006A45
	v_cndmask_b32_e32 v1, s10, v15, vcc_lo                     // 0000001871D4: 02021E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001871D8: BF8700A1
	v_add_co_ci_u32_e64 v70, null, s11, v16, vcc_lo            // 0000001871DC: D5207C46 01AA200B
	.long 0xd7006a1f                                           // 0000001871E4: D7006A1F
	v_cndmask_b32_e32 v1, v7, v31, vcc_lo                      // 0000001871E8: 02023F07
	v_add_co_ci_u32_e64 v32, null, v8, v32, vcc_lo             // 0000001871EC: D5207C20 01AA4108
	.long 0xd7006a37                                           // 0000001871F4: D7006A37
	v_cndmask_b32_e32 v1, s10, v23, vcc_lo                     // 0000001871F8: 02022E0A
	v_ashrrev_i32_e32 v48, 31, v0                              // 0000001871FC: 3460009F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000187200: BF8700B3
	.long 0xd73c001f                                           // 000000187204: D73C001F
	v_cndmask_b32_e32 v1, 1, v31, vcc_lo                       // 000000187208: 02023E81
	v_add_co_ci_u32_e64 v56, null, s11, v24, vcc_lo            // 00000018720C: D5207C38 01AA300B
	.long 0xd7006a27                                           // 000000187214: D7006A27
	v_cndmask_b32_e32 v1, v7, v39, vcc_lo                      // 000000187218: 02024F07
	v_add_co_ci_u32_e64 v40, null, v8, v40, vcc_lo             // 00000018721C: D5207C28 01AA5108
	.long 0xd7006a2f                                           // 000000187224: D7006A2F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 000000187228: 02020107
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018722C: BF870001
	v_add_co_ci_u32_e64 v48, null, v8, v48, vcc_lo             // 000000187230: D5207C30 01AA6108
	.long 0xd7006a3f                                           // 000000187238: D7006A3F
	v_cndmask_b32_e32 v1, s10, v31, vcc_lo                     // 00000018723C: 02023E0A
	global_load_u16 v73, v[69:70], off offset:1024             // 000000187240: DC4A0400 497C0045
	v_add_co_ci_u32_e64 v64, null, s11, v32, vcc_lo            // 000000187248: D5207C40 01AA400B
	.long 0xd7006a07                                           // 000000187250: D7006A07
	v_cndmask_b32_e32 v1, v7, v65, vcc_lo                      // 000000187254: 02028307
	s_clause 0x2                                               // 000000187258: BF850002
	global_load_u16 v80, v[69:70], off                         // 00000018725C: DC4A0000 507C0045
	global_load_u16 v82, v[69:70], off offset:32               // 000000187264: DC4A0020 527C0045
	global_load_u16 v103, v[69:70], off offset:64              // 00000018726C: DC4A0040 677C0045
	v_add_co_ci_u32_e64 v8, null, v8, v66, vcc_lo              // 000000187274: D5207C08 01AA8508
	.long 0xd73c0027                                           // 00000018727C: D73C0027
	v_cndmask_b32_e32 v1, 1, v39, vcc_lo                       // 000000187280: 02024E81
	.long 0xd73c002f                                           // 000000187284: D73C002F
	v_cndmask_b32_e32 v1, 1, v47, vcc_lo                       // 000000187288: 02025E81
	v_add_f32_dpp v83, v83, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 00000018728C: 06A6A6FA FF096253
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000187294: BF8700C4
	.long 0xd73c0056                                           // 000000187298: D73C0056
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 00000018729C: 02020E81
	v_mov_b32_dpp v8, v105 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001872A0: 7E1002FA FF096169
	v_mov_b32_dpp v7, v177 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001872A8: 7E0E02FA FF0961B1
	.long 0xd7006a43                                           // 0000001872B0: D7006A43
	v_cndmask_b32_e32 v1, s10, v39, vcc_lo                     // 0000001872B4: 02024E0A
	v_add_co_ci_u32_e64 v68, null, s11, v40, vcc_lo            // 0000001872B8: D5207C44 01AA500B
	.long 0xd7006a41                                           // 0000001872C0: D7006A41
	v_cndmask_b32_e32 v1, s10, v47, vcc_lo                     // 0000001872C4: 02025E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001872C8: BF8700A1
	v_add_co_ci_u32_e64 v66, null, s11, v48, vcc_lo            // 0000001872CC: D5207C42 01AA600B
	.long 0xd7006a47                                           // 0000001872D4: D7006A47
	v_cndmask_b32_e32 v1, s10, v86, vcc_lo                     // 0000001872D8: 0202AC0A
	v_add_co_ci_u32_e64 v72, null, s11, v87, vcc_lo            // 0000001872DC: D5207C48 01AAAE0B
	s_clause 0x9                                               // 0000001872E4: BF850009
	global_load_u16 v99, v[63:64], off                         // 0000001872E8: DC4A0000 637C003F
	global_load_u16 v98, v[55:56], off                         // 0000001872F0: DC4A0000 627C0037
	global_load_u16 v101, v[65:66], off                        // 0000001872F8: DC4A0000 657C0041
	global_load_u16 v100, v[67:68], off                        // 000000187300: DC4A0000 647C0043
	global_load_u16 v102, v[71:72], off offset:32              // 000000187308: DC4A0020 667C0047
	global_load_u16 v94, v[63:64], off offset:32               // 000000187310: DC4A0020 5E7C003F
	global_load_u16 v93, v[55:56], off offset:32               // 000000187318: DC4A0020 5D7C0037
	global_load_u16 v96, v[65:66], off offset:32               // 000000187320: DC4A0020 607C0041
	global_load_u16 v95, v[67:68], off offset:32               // 000000187328: DC4A0020 5F7C0043
	global_load_u16 v97, v[71:72], off offset:64               // 000000187330: DC4A0040 617C0047
	v_add_f32_e32 v8, v105, v8                                 // 000000187338: 06101169
	v_add_f32_e32 v7, v177, v7                                 // 00000018733C: 060E0FB1
	v_add_f32_dpp v83, v83, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187340: 06A6A6FA FF096453
	v_add_f32_dpp v81, v81, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187348: 06A2A2FA FF096451
	v_add_f32_dpp v78, v78, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187350: 069C9CFA FF09644E
	v_add_f32_dpp v8, v8, v8 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187358: 061010FA FF096208
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187360: 060E0EFA FF096207
	v_add_f32_dpp v89, v83, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187368: 06B2A6FA FF096853
	v_add_f32_dpp v88, v81, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187370: 06B0A2FA FF096851
	v_add_f32_dpp v81, v78, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187378: 06A29CFA FF09684E
	v_add_f32_dpp v8, v8, v8 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187380: 061010FA FF096408
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187388: 060E0EFA FF096407
	v_div_scale_f32 v109, null, v89, v89, 1.0                  // 000000187390: D6FC7C6D 03CAB359
	v_div_scale_f32 v110, null, v88, v88, 1.0                  // 000000187398: D6FC7C6E 03CAB158
	v_div_scale_f32 v115, null, v81, v81, 1.0                  // 0000001873A0: D6FC7C73 03CAA351
	v_add_f32_dpp v107, v8, v8 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001873A8: 06D610FA FF096808
	v_add_f32_dpp v108, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001873B0: 06D80EFA FF096807
	.long 0xd7000507                                           // 0000001873B8: D7000507
	v_cndmask_b32_e32 v1, s12, v15, vcc_lo                     // 0000001873BC: 02021E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001873C0: BF8700B1
	v_add_co_ci_u32_e64 v8, null, s13, v16, s5                 // 0000001873C4: D5207C08 0016200D
	v_rcp_f32_e32 v91, v109                                    // 0000001873CC: 7EB6556D
	.long 0xd700050f                                           // 0000001873D0: D700050F
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 0000001873D4: 02022E0C
	v_add_co_ci_u32_e64 v16, null, s13, v24, s5                // 0000001873D8: D5207C10 0016300D
	.long 0xd7000517                                           // 0000001873E0: D7000517
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 0000001873E4: 02023E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001873E8: BF8700A1
	v_add_co_ci_u32_e64 v24, null, s13, v32, s5                // 0000001873EC: D5207C18 0016400D
	.long 0xd700051f                                           // 0000001873F4: D700051F
	v_cndmask_b32_e32 v1, s12, v39, vcc_lo                     // 0000001873F8: 02024E0C
	v_add_co_ci_u32_e64 v32, null, s13, v40, s5                // 0000001873FC: D5207C20 0016500D
	.long 0xd7000527                                           // 000000187404: D7000527
	v_cndmask_b32_e32 v1, s12, v47, vcc_lo                     // 000000187408: 02025E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000018740C: BF8700A1
	v_add_co_ci_u32_e64 v40, null, s13, v48, s5                // 000000187410: D5207C28 0016600D
	.long 0xd700052f                                           // 000000187418: D700052F
	v_cndmask_b32_e32 v1, s12, v86, vcc_lo                     // 00000018741C: 0202AC0C
	v_add_co_ci_u32_e64 v48, null, s13, v87, s5                // 000000187420: D5207C30 0016AE0D
	s_clause 0x1f                                              // 000000187428: BF85001F
	global_load_u16 v78, v[69:70], off offset:96               // 00000018742C: DC4A0060 4E7C0045
	global_load_u16 v86, v[69:70], off offset:128              // 000000187434: DC4A0080 567C0045
	global_load_u16 v87, v[69:70], off offset:160              // 00000018743C: DC4A00A0 577C0045
	global_load_u16 v92, v[69:70], off offset:192              // 000000187444: DC4A00C0 5C7C0045
	global_load_u16 v69, v[69:70], off offset:224              // 00000018744C: DC4A00E0 457C0045
	global_load_u16 v138, v[55:56], off offset:64              // 000000187454: DC4A0040 8A7C0037
	global_load_u16 v133, v[55:56], off offset:96              // 00000018745C: DC4A0060 857C0037
	global_load_u16 v128, v[55:56], off offset:128             // 000000187464: DC4A0080 807C0037
	global_load_u16 v124, v[55:56], off offset:160             // 00000018746C: DC4A00A0 7C7C0037
	global_load_u16 v104, v[55:56], off offset:192             // 000000187474: DC4A00C0 687C0037
	global_load_u16 v137, v[63:64], off offset:64              // 00000018747C: DC4A0040 897C003F
	global_load_u16 v132, v[63:64], off offset:96              // 000000187484: DC4A0060 847C003F
	global_load_u16 v127, v[63:64], off offset:128             // 00000018748C: DC4A0080 7F7C003F
	global_load_u16 v123, v[63:64], off offset:160             // 000000187494: DC4A00A0 7B7C003F
	global_load_u16 v70, v[63:64], off offset:192              // 00000018749C: DC4A00C0 467C003F
	global_load_u16 v56, v[55:56], off offset:224              // 0000001874A4: DC4A00E0 387C0037
	global_load_u16 v140, v[67:68], off offset:64              // 0000001874AC: DC4A0040 8C7C0043
	global_load_u16 v135, v[67:68], off offset:96              // 0000001874B4: DC4A0060 877C0043
	global_load_u16 v130, v[67:68], off offset:128             // 0000001874BC: DC4A0080 827C0043
	global_load_u16 v126, v[67:68], off offset:160             // 0000001874C4: DC4A00A0 7E7C0043
	global_load_u16 v106, v[67:68], off offset:192             // 0000001874CC: DC4A00C0 6A7C0043
	global_load_u16 v55, v[63:64], off offset:224              // 0000001874D4: DC4A00E0 377C003F
	global_load_u16 v139, v[65:66], off offset:64              // 0000001874DC: DC4A0040 8B7C0041
	global_load_u16 v134, v[65:66], off offset:96              // 0000001874E4: DC4A0060 867C0041
	global_load_u16 v129, v[65:66], off offset:128             // 0000001874EC: DC4A0080 817C0041
	global_load_u16 v125, v[65:66], off offset:160             // 0000001874F4: DC4A00A0 7D7C0041
	global_load_u16 v105, v[65:66], off offset:192             // 0000001874FC: DC4A00C0 697C0041
	global_load_u16 v63, v[67:68], off offset:224              // 000000187504: DC4A00E0 3F7C0043
	global_load_u16 v141, v[71:72], off offset:96              // 00000018750C: DC4A0060 8D7C0047
	global_load_u16 v136, v[71:72], off offset:128             // 000000187514: DC4A0080 887C0047
	global_load_u16 v131, v[71:72], off offset:160             // 00000018751C: DC4A00A0 837C0047
	global_load_u16 v68, v[71:72], off offset:192              // 000000187524: DC4A00C0 447C0047
	s_clause 0x1                                               // 00000018752C: BF850001
	global_load_u16 v67, v[71:72], off offset:224              // 000000187530: DC4A00E0 437C0047
	global_load_u16 v64, v[65:66], off offset:224              // 000000187538: DC4A00E0 407C0041
	v_fma_f32 v71, -v109, v91, 1.0                             // 000000187540: D6130047 23CAB76D
	v_add_f32_e32 v84, v178, v76                               // 000000187548: 06A899B2
	v_div_scale_f32 v117, null, v108, v108, 1.0                // 00000018754C: D6FC7C75 03CAD96C
	v_div_scale_f32 v118, null, v107, v107, 1.0                // 000000187554: D6FC7C76 03CAD76B
	v_rcp_f32_e32 v90, v110                                    // 00000018755C: 7EB4556E
	v_fmac_f32_e32 v91, v71, v91                               // 000000187560: 56B6B747
	v_add_f32_dpp v84, v84, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187564: 06A8A8FA FF096254
	v_rcp_f32_e32 v122, v117                                   // 00000018756C: 7EF45575
	v_rcp_f32_e32 v121, v118                                   // 000000187570: 7EF25576
	v_div_scale_f32 v119, vcc_lo, 1.0, v108, 1.0               // 000000187574: D6FC6A77 03CAD8F2
	v_div_scale_f32 v120, s4, 1.0, v107, 1.0                   // 00000018757C: D6FC0478 03CAD6F2
	v_add_f32_dpp v84, v84, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 000000187584: 06A8A8FA FF096454
	v_div_scale_f32 v112, s2, 1.0, v89, 1.0                    // 00000018758C: D6FC0270 03CAB2F2
	v_div_scale_f32 v116, s1, 1.0, v81, 1.0                    // 000000187594: D6FC0174 03CAA2F2
	v_fma_f32 v72, -v110, v90, 1.0                             // 00000018759C: D6130048 23CAB56E
	v_div_scale_f32 v113, s3, 1.0, v88, 1.0                    // 0000001875A4: D6FC0371 03CAB0F2
	v_add_f32_dpp v83, v84, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001875AC: 06A6A8FA FF096854
	v_fma_f32 v65, -v117, v122, 1.0                            // 0000001875B4: D6130041 23CAF575
	v_fma_f32 v66, -v118, v121, 1.0                            // 0000001875BC: D6130042 23CAF376
	v_fmac_f32_e32 v90, v72, v90                               // 0000001875C4: 56B4B548
	v_rcp_f32_e32 v84, v115                                    // 0000001875C8: 7EA85573
	v_div_scale_f32 v111, null, v83, v83, 1.0                  // 0000001875CC: D6FC7C6F 03CAA753
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001875D4: BF870233
	v_dual_fmac_f32 v122, v65, v122 :: v_dual_fmac_f32 v121, v66, v121// 0000001875D8: C800F541 7A78F342
	v_div_scale_f32 v114, s0, 1.0, v83, 1.0                    // 0000001875E0: D6FC0072 03CAA6F2
	v_dual_mul_f32 v71, v112, v91 :: v_dual_mul_f32 v72, v113, v90// 0000001875E8: C8C6B770 4748B571
	v_rcp_f32_e32 v85, v111                                    // 0000001875F0: 7EAA556F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001875F4: BF870313
	v_dual_mul_f32 v65, v119, v122 :: v_dual_mul_f32 v66, v120, v121// 0000001875F8: C8C6F577 4142F378
	v_fma_f32 v143, -v115, v84, 1.0                            // 000000187600: D613008F 23CAA973
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000187608: BF870223
	v_fma_f32 v146, -v109, v71, v112                           // 00000018760C: D6130092 25C28F6D
	v_fma_f32 v147, -v110, v72, v113                           // 000000187614: D6130093 25C6916E
	v_fma_f32 v144, -v117, v65, v119                           // 00000018761C: D6130090 25DE8375
	v_fma_f32 v145, -v118, v66, v120                           // 000000187624: D6130091 25E28576
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000018762C: BF870214
	v_dual_fmac_f32 v84, v143, v84 :: v_dual_fmac_f32 v71, v146, v91// 000000187630: C800A98F 5446B792
	v_fmac_f32_e32 v72, v147, v90                              // 000000187638: 5690B593
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000018763C: BF870215
	v_fma_f32 v142, -v111, v85, 1.0                            // 000000187640: D613008E 23CAAB6F
	v_dual_fmac_f32 v65, v144, v122 :: v_dual_fmac_f32 v66, v145, v121// 000000187648: C800F590 4142F391
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000187650: BF870224
	v_mul_f32_e32 v143, v116, v84                              // 000000187654: 111EA974
	v_fma_f32 v109, -v109, v71, v112                           // 000000187658: D613006D 25C28F6D
	v_fmac_f32_e32 v85, v142, v85                              // 000000187660: 56AAAB8E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000187664: BF870004
	v_fma_f32 v117, -v117, v65, v119                           // 000000187668: D6130075 25DE8375
	v_fma_f32 v118, -v118, v66, v120                           // 000000187670: D6130076 25E28576
	v_fma_f32 v144, -v115, v143, v116                          // 000000187678: D6130090 25D31F73
	.long 0x7f003880                                           // 000000187680: 7F003880
	v_mul_f32_e32 v142, v114, v85                              // 000000187684: 111CAB72
	v_div_fmas_f32 v65, v117, v122, v65                        // 000000187688: D6370041 0506F575
	s_mov_b32 vcc_lo, s4                                       // 000000187690: BEEA0004
	v_div_fmas_f32 v117, v118, v121, v66                       // 000000187694: D6370075 050AF376
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000018769C: BF870193
	v_fma_f32 v148, -v111, v142, v114                          // 0000001876A0: D6130094 25CB1D6F
	v_div_fixup_f32 v66, v65, v108, 1.0                        // 0000001876A8: D6270042 03CAD941
	v_fma_f32 v108, -v110, v72, v113                           // 0000001876B0: D613006C 25C6916E
	.long 0x7f9e3980                                           // 0000001876B8: 7F9E3980
	v_div_fixup_f32 v65, v117, v107, 1.0                       // 0000001876BC: D6270041 03CAD775
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001876C4: BF870234
	v_dual_fmac_f32 v142, v148, v85 :: v_dual_mul_f32 v57, v57, v66// 0000001876C8: C806AB94 8E388539
	v_fmac_f32_e32 v143, v144, v84                             // 0000001876D0: 571EA990
	.long 0x7f983980                                           // 0000001876D4: 7F983980
	v_mul_f32_e32 v58, v58, v65                                // 0000001876D8: 1074833A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001876DC: BF870004
	v_fma_f32 v107, -v111, v142, v114                          // 0000001876E0: D613006B 25CB1D6F
	v_mul_f32_e32 v111, v49, v66                               // 0000001876E8: 10DE8531
	v_fma_f32 v110, -v115, v143, v116                          // 0000001876EC: D613006E 25D31F73
	.long 0x7f9a3980                                           // 0000001876F4: 7F9A3980
	.long 0x7f963980                                           // 0000001876F8: 7F963980
	.long 0x7f943980                                           // 0000001876FC: 7F943980
	v_dual_mul_f32 v33, v33, v66 :: v_dual_mul_f32 v26, v26, v65// 000000187700: C8C68521 211A831A
	v_mul_f32_e32 v25, v25, v66                                // 000000187708: 10328519
	v_mul_f32_e32 v17, v17, v66                                // 00000018770C: 10228511
	v_mul_f32_e32 v9, v9, v66                                  // 000000187710: 10128509
	v_dual_mul_f32 v1, v1, v66 :: v_dual_mul_f32 v18, v18, v65 // 000000187714: C8C68501 01128312
	v_mul_f32_e32 v42, v42, v65                                // 00000018771C: 1054832A
	v_mul_f32_e32 v34, v34, v65                                // 000000187720: 10448322
	v_mul_f32_e32 v10, v10, v65                                // 000000187724: 1014830A
	v_mul_f32_e32 v2, v2, v65                                  // 000000187728: 10048302
	s_waitcnt vmcnt(47)                                        // 00000018772C: BF89BFF7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000187730: 30929290
	s_waitcnt vmcnt(46)                                        // 000000187734: BF89BBF7
	v_dual_mul_f32 v80, v50, v65 :: v_dual_lshlrev_b32 v49, 16, v80// 000000187738: C8E28332 5030A090
	s_waitcnt vmcnt(45)                                        // 000000187740: BF89B7F7
	v_lshlrev_b32_e32 v50, 16, v82                             // 000000187744: 3064A490
	s_waitcnt vmcnt(44)                                        // 000000187748: BF89B3F7
	v_lshlrev_b32_e32 v82, 16, v103                            // 00000018774C: 30A4CE90
	s_delay_alu instid0(VALU_DEP_1)                            // 000000187750: BF870001
	v_mul_f32_e32 v114, 0xbfb8aa3b, v82                        // 000000187754: 10E4A4FF BFB8AA3B
	v_mul_f32_e32 v112, 0xbfb8aa3b, v73                        // 00000018775C: 10E092FF BFB8AA3B
	v_mul_f32_e32 v103, 0xbfb8aa3b, v49                        // 000000187764: 10CE62FF BFB8AA3B
	v_mul_f32_e32 v113, 0xbfb8aa3b, v50                        // 00000018776C: 10E264FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000187774: 7C3C62FF 42CE8ED0
	v_rndne_f32_e32 v152, v114                                 // 00000018777C: 7F304772
	v_fma_f32 v117, 0xbfb8aa3b, v73, -v112                     // 000000187780: D6130075 85C292FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v49, -v103                     // 00000018778C: D6130073 859E62FF BFB8AA3B
	v_rndne_f32_e32 v116, v103                                 // 000000187798: 7EE84767
	s_waitcnt vmcnt(40)                                        // 00000018779C: BF89A3F7
	v_lshlrev_b32_e32 v100, 16, v100                           // 0000001877A0: 30C8C890
	v_lshlrev_b32_e32 v98, 16, v98                             // 0000001877A4: 30C4C490
	v_rndne_f32_e32 v118, v112                                 // 0000001877A8: 7EEC4770
	v_lshlrev_b32_e32 v101, 16, v101                           // 0000001877AC: 30CACA90
	v_lshlrev_b32_e32 v99, 16, v99                             // 0000001877B0: 30C6C690
	s_waitcnt vmcnt(37)                                        // 0000001877B4: BF8997F7
	v_lshlrev_b32_e32 v93, 16, v93                             // 0000001877B8: 30BABA90
	v_dual_mul_f32 v121, 0xbfb8aa3b, v100 :: v_dual_lshlrev_b32 v102, 16, v102// 0000001877BC: C8E2C8FF 7966CC90 BFB8AA3B
	v_mul_f32_e32 v119, 0xbfb8aa3b, v98                        // 0000001877C8: 10EEC4FF BFB8AA3B
	v_fma_f32 v151, 0xbfb8aa3b, v82, -v114                     // 0000001877D0: D6130097 85CAA4FF BFB8AA3B
	v_dual_fmac_f32 v115, 0xb2a5705f, v49 :: v_dual_sub_f32 v112, v112, v118// 0000001877DC: C80A62FF 7370ED70 B2A5705F
	v_dual_fmac_f32 v117, 0xb2a5705f, v73 :: v_dual_sub_f32 v114, v114, v152// 0000001877E8: C80A92FF 75733172 B2A5705F
	v_dual_sub_f32 v103, v103, v116 :: v_dual_mul_f32 v122, 0xbfb8aa3b, v101// 0000001877F4: C946E967 677ACAFF BFB8AA3B
	v_mul_f32_e32 v120, 0xbfb8aa3b, v99                        // 000000187800: 10F0C6FF BFB8AA3B
	v_fma_f32 v145, 0xbfb8aa3b, v50, -v113                     // 000000187808: D6130091 85C664FF BFB8AA3B
	v_rndne_f32_e32 v146, v113                                 // 000000187814: 7F244771
	v_dual_mul_f32 v147, 0xbfb8aa3b, v93 :: v_dual_mul_f32 v144, 0xbfb8aa3b, v102// 000000187818: C8C6BAFF 9390CCFF BFB8AA3B
	v_fma_f32 v154, 0xbfb8aa3b, v98, -v119                     // 000000187824: D613009A 85DEC4FF BFB8AA3B
	v_dual_add_f32 v112, v112, v117 :: v_dual_add_f32 v103, v103, v115// 000000187830: C908EB70 7066E767
	v_fma_f32 v156, 0xbfb8aa3b, v99, -v120                     // 000000187838: D613009C 85E2C6FF BFB8AA3B
	v_fma_f32 v158, 0xbfb8aa3b, v100, -v121                    // 000000187844: D613009E 85E6C8FF BFB8AA3B
	v_rndne_f32_e32 v163, v144                                 // 000000187850: 7F464790
	v_fmac_f32_e32 v145, 0xb2a5705f, v50                       // 000000187854: 572264FF B2A5705F
	v_sub_f32_e32 v113, v113, v146                             // 00000018785C: 08E32571
	v_fmac_f32_e32 v154, 0xb2a5705f, v98                       // 000000187860: 5734C4FF B2A5705F
	v_exp_f32_e32 v103, v103                                   // 000000187868: 7ECE4B67
	s_waitcnt vmcnt(35)                                        // 00000018786C: BF898FF7
	v_lshlrev_b32_e32 v95, 16, v95                             // 000000187870: 30BEBE90
	s_waitcnt vmcnt(34)                                        // 000000187874: BF898BF7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000187878: 30C2C290
	v_lshlrev_b32_e32 v96, 16, v96                             // 00000018787C: 30C0C090
	v_cvt_i32_f32_e32 v116, v116                               // 000000187880: 7EE81174
	v_rndne_f32_e32 v155, v119                                 // 000000187884: 7F364777
	v_fma_f32 v160, 0xbfb8aa3b, v101, -v122                    // 000000187888: D61300A0 85EACAFF BFB8AA3B
	v_rndne_f32_e32 v161, v122                                 // 000000187894: 7F42477A
	v_fma_f32 v162, 0xbfb8aa3b, v102, -v144                    // 000000187898: D61300A2 8642CCFF BFB8AA3B
	v_fmac_f32_e32 v156, 0xb2a5705f, v99                       // 0000001878A4: 5738C6FF B2A5705F
	v_fmac_f32_e32 v158, 0xb2a5705f, v100                      // 0000001878AC: 573CC8FF B2A5705F
	v_dual_sub_f32 v144, v144, v163 :: v_dual_add_f32 v113, v113, v145// 0000001878B4: C9494790 90712371
	v_exp_f32_e32 v112, v112                                   // 0000001878BC: 7EE04B70
	v_dual_mul_f32 v149, 0xbfb8aa3b, v95 :: v_dual_lshlrev_b32 v94, 16, v94// 0000001878C0: C8E2BEFF 955EBC90 BFB8AA3B
	v_dual_mul_f32 v153, 0xbfb8aa3b, v97 :: v_dual_mul_f32 v150, 0xbfb8aa3b, v96// 0000001878CC: C8C6C2FF 9996C0FF BFB8AA3B
	v_cvt_i32_f32_e32 v118, v118                               // 0000001878D8: 7EEC1176
	v_rndne_f32_e32 v157, v120                                 // 0000001878DC: 7F3A4778
	v_dual_fmac_f32 v151, 0xb2a5705f, v82 :: v_dual_fmac_f32 v160, 0xb2a5705f, v101// 0000001878E0: C800A4FF 97A0CAFF B2A5705F
	v_dual_sub_f32 v115, v119, v155 :: v_dual_sub_f32 v122, v122, v161// 0000001878EC: C94B3777 737B437A
	v_exp_f32_e32 v113, v113                                   // 0000001878F4: 7EE24B71
	.long 0xd71c0067                                           // 0000001878F8: D71C0067
	v_cndmask_b32_e32 v1, v103, v116, vcc_lo                   // 0000001878FC: 0202E967
	v_mul_f32_e32 v148, 0xbfb8aa3b, v94                        // 000000187900: 1128BCFF BFB8AA3B
	v_rndne_f32_e32 v159, v121                                 // 000000187908: 7F3E4779
	v_cvt_i32_f32_e32 v146, v146                               // 00000018790C: 7F241192
	v_fma_f32 v164, 0xbfb8aa3b, v93, -v147                     // 000000187910: D61300A4 864EBAFF BFB8AA3B
	v_fma_f32 v168, 0xbfb8aa3b, v95, -v149                     // 00000018791C: D61300A8 8656BEFF BFB8AA3B
	v_fma_f32 v170, 0xbfb8aa3b, v96, -v150                     // 000000187928: D61300AA 865AC0FF BFB8AA3B
	v_rndne_f32_e32 v171, v150                                 // 000000187934: 7F564796
	v_dual_sub_f32 v119, v120, v157 :: v_dual_fmac_f32 v162, 0xb2a5705f, v102// 000000187938: C9413B78 77A2CCFF B2A5705F
	v_dual_add_f32 v122, v122, v160 :: v_dual_cndmask_b32 v103, 0, v103// 000000187944: C913417A 7A66CE80
	.long 0xd71c0070                                           // 00000018794C: D71C0070
	v_cndmask_b32_e32 v1, v112, v118, vcc_lo                   // 000000187950: 0202ED70
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000187954: 7C3C92FF 42CE8ED0
	v_rndne_f32_e32 v165, v147                                 // 00000018795C: 7F4A4793
	v_fma_f32 v166, 0xbfb8aa3b, v94, -v148                     // 000000187960: D61300A6 8652BCFF BFB8AA3B
	v_dual_sub_f32 v121, v121, v159 :: v_dual_fmac_f32 v164, 0xb2a5705f, v93// 00000018796C: C9413F79 79A4BAFF B2A5705F
	v_dual_fmac_f32 v168, 0xb2a5705f, v95 :: v_dual_add_f32 v115, v115, v154// 000000187978: C808BEFF A8733573 B2A5705F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000187984: BF870002
	v_dual_fmac_f32 v170, 0xb2a5705f, v96 :: v_dual_add_f32 v121, v121, v158// 000000187988: C808C0FF AA793D79 B2A5705F
	v_dual_sub_f32 v150, v150, v171 :: v_dual_add_f32 v119, v119, v156// 000000187994: C9495796 96773977
	.long 0xd71c0071                                           // 00000018799C: D71C0071
	v_cndmask_b32_e32 v1, v113, v146, vcc_lo                   // 0000001879A0: 02032571
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 0000001879A4: 02E0E080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v50                  // 0000001879A8: 7C3C64FF 42CE8ED0
	v_dual_sub_f32 v145, v147, v165 :: v_dual_fmac_f32 v166, 0xb2a5705f, v94// 0000001879B0: C9414B93 91A6BCFF B2A5705F
	v_add_f32_e32 v144, v144, v162                             // 0000001879BC: 07214590
	v_dual_add_f32 v150, v150, v170 :: v_dual_cndmask_b32 v113, 0, v113// 0000001879C0: C9135596 9670E280
	v_exp_f32_e32 v115, v115                                   // 0000001879C8: 7EE64B73
	v_exp_f32_e32 v119, v119                                   // 0000001879CC: 7EEE4B77
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001879D0: 7C3662FF C2B17218
	v_cvt_i32_f32_e32 v117, v155                               // 0000001879D8: 7EEA119B
	v_cvt_i32_f32_e32 v120, v157                               // 0000001879DC: 7EF0119D
	v_add_f32_e32 v145, v145, v164                             // 0000001879E0: 07234991
	v_exp_f32_e32 v144, v144                                   // 0000001879E4: 7F204B90
	v_cndmask_b32_e32 v49, 0x7f800000, v103, vcc_lo            // 0000001879E8: 0262CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000001879F0: 7C3692FF C2B17218
	v_cvt_i32_f32_e32 v155, v159                               // 0000001879F8: 7F36119F
	v_cvt_i32_f32_e32 v159, v163                               // 0000001879FC: 7F3E11A3
	v_exp_f32_e32 v121, v121                                   // 000000187A00: 7EF24B79
	.long 0xd71c0073                                           // 000000187A04: D71C0073
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                   // 000000187A08: 0202EB73
	.long 0xd71c0075                                           // 000000187A0C: D71C0075
	v_cndmask_b32_e32 v1, v119, v120, vcc_lo                   // 000000187A10: 0202F177
	v_cndmask_b32_e32 v73, 0x7f800000, v112, vcc_lo            // 000000187A14: 0292E0FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v98                  // 000000187A1C: 7C3CC4FF 42CE8ED0
	v_exp_f32_e32 v122, v122                                   // 000000187A24: 7EF44B7A
	.long 0xd71c0078                                           // 000000187A28: D71C0078
	v_cndmask_b32_e32 v1, v144, v159, vcc_lo                   // 000000187A2C: 02033F90
	v_rndne_f32_e32 v167, v148                                 // 000000187A30: 7F4E4794
	v_cvt_i32_f32_e32 v157, v161                               // 000000187A34: 7F3A11A1
	v_cndmask_b32_e32 v103, 0, v115, vcc_lo                    // 000000187A38: 02CEE680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v99                  // 000000187A3C: 7C3CC6FF 42CE8ED0
	.long 0xd71c0076                                           // 000000187A44: D71C0076
	v_cndmask_b32_e32 v1, v121, v155, vcc_lo                   // 000000187A48: 02033779
	v_rndne_f32_e32 v169, v149                                 // 000000187A4C: 7F524795
	v_sub_f32_e32 v148, v148, v167                             // 000000187A50: 09294F94
	v_exp_f32_e32 v145, v145                                   // 000000187A54: 7F224B91
	v_cndmask_b32_e32 v112, 0, v117, vcc_lo                    // 000000187A58: 02E0EA80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 000000187A5C: 7C3CC8FF 42CE8ED0
	.long 0xd71c0077                                           // 000000187A64: D71C0077
	v_cndmask_b32_e32 v1, v122, v157, vcc_lo                   // 000000187A68: 02033B7A
	v_dual_sub_f32 v149, v149, v169 :: v_dual_add_f32 v148, v148, v166// 000000187A6C: C9495395 95954D94
	v_cvt_i32_f32_e32 v147, v165                               // 000000187A74: 7F2611A5
	v_cndmask_b32_e32 v115, 0, v118, vcc_lo                    // 000000187A78: 02E6EC80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v101                 // 000000187A7C: 7C3CCAFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000187A84: BF870004
	v_add_f32_e32 v149, v149, v168                             // 000000187A88: 072B5195
	v_exp_f32_e32 v148, v148                                   // 000000187A8C: 7F284B94
	v_exp_f32_e32 v116, v150                                   // 000000187A90: 7EE84B96
	v_cvt_i32_f32_e32 v161, v167                               // 000000187A94: 7F4211A7
	v_cndmask_b32_e32 v117, 0, v119, vcc_lo                    // 000000187A98: 02EAEE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 000000187A9C: 7C3CCCFF 42CE8ED0
	v_cvt_i32_f32_e32 v165, v171                               // 000000187AA4: 7F4A11AB
	v_exp_f32_e32 v149, v149                                   // 000000187AA8: 7F2A4B95
	.long 0xd71c0079                                           // 000000187AAC: D71C0079
	v_cndmask_b32_e32 v1, v145, v147, vcc_lo                   // 000000187AB0: 02032791
	v_cvt_i32_f32_e32 v163, v169                               // 000000187AB4: 7F4611A9
	v_cndmask_b32_e32 v118, 0, v120, vcc_lo                    // 000000187AB8: 02ECF080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v50                  // 000000187ABC: 7C3664FF C2B17218
	.long 0xd71c007a                                           // 000000187AC4: D71C007A
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 000000187AC8: 02034394
	.long 0xd71c0074                                           // 000000187ACC: D71C0074
	v_cndmask_b32_e32 v1, v116, v165, vcc_lo                   // 000000187AD0: 02034B74
	v_add_f32_e32 v120, 1.0, v49                               // 000000187AD4: 06F062F2
	.long 0xd41b0005                                           // 000000187AD8: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v94, vcc_lo              // 000000187ADC: 0202BCFF C2B17218
	v_cndmask_b32_e32 v50, 0x7f800000, v113, vcc_lo            // 000000187AE4: 0264E2FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v93                  // 000000187AEC: 7C3CBAFF 42CE8ED0
	.long 0xd71c0090                                           // 000000187AF4: D71C0090
	v_cndmask_b32_e32 v1, v149, v163, vcc_lo                   // 000000187AF8: 02034795
	v_cndmask_b32_e32 v113, 0, v121, vcc_lo                    // 000000187AFC: 02E2F280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v94                  // 000000187B00: 7C3CBCFF 42CE8ED0
	v_div_scale_f32 v121, null, v120, v120, v57                // 000000187B08: D6FC7C79 04E6F178
	v_cndmask_b32_e32 v119, 0, v122, vcc_lo                    // 000000187B10: 02EEF480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v95                  // 000000187B14: 7C3CBEFF 42CE8ED0
	v_cndmask_b32_e32 v49, 0, v144, vcc_lo                     // 000000187B1C: 02632080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 000000187B20: 7C3CC0FF 42CE8ED0
	v_cndmask_b32_e32 v116, 0, v116, vcc_lo                    // 000000187B28: 02E8E880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v98                  // 000000187B2C: 7C36C4FF C2B17218
	v_cndmask_b32_e32 v98, 0x7f800000, v103, vcc_lo            // 000000187B34: 02C4CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v99                  // 000000187B3C: 7C36C6FF C2B17218
	v_rcp_f32_e32 v103, v121                                   // 000000187B44: 7ECE5579
	v_cndmask_b32_e64 v94, 0x7f800000, v119, s5                // 000000187B48: D501005E 0016EEFF 7F800000
	.long 0xd41b0005                                           // 000000187B54: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v95, vcc_lo              // 000000187B58: 0202BEFF C2B17218
	v_dual_add_f32 v98, 1.0, v98 :: v_dual_cndmask_b32 v99, 0x7f800000, v112// 000000187B60: C912C4F2 6262E0FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 000000187B6C: 7C36C8FF C2B17218
	v_dual_add_f32 v73, 1.0, v73 :: v_dual_cndmask_b32 v100, 0x7f800000, v115// 000000187B74: C91292F2 4964E6FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000187B80: BF870121
	v_div_scale_f32 v122, null, v73, v73, v58                  // 000000187B84: D6FC7C7A 04EA9349
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v101                 // 000000187B8C: 7C36CAFF C2B17218
	v_rcp_f32_e32 v112, v122                                   // 000000187B94: 7EE0557A
	v_cndmask_b32_e32 v101, 0x7f800000, v117, vcc_lo           // 000000187B98: 02CAEAFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 000000187BA0: 7C36CCFF C2B17218
	v_cndmask_b32_e32 v102, 0x7f800000, v118, vcc_lo           // 000000187BA8: 02CCECFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v93                  // 000000187BB0: 7C36BAFF C2B17218
	v_div_scale_f32 v118, s4, v58, v73, v58                    // 000000187BB8: D6FC0476 04EA933A
	v_cndmask_b32_e64 v95, 0x7f800000, v49, s5                 // 000000187BC0: D501005F 001662FF 7F800000
	.long 0xd41b0005                                           // 000000187BCC: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v96, vcc_lo              // 000000187BD0: 0202C0FF C2B17218
	v_dual_add_f32 v102, 1.0, v102 :: v_dual_cndmask_b32 v93, 0x7f800000, v113// 000000187BD8: C912CCF2 665CE2FF 7F800000
	v_div_scale_f32 v117, vcc_lo, v57, v120, v57               // 000000187BE4: D6FC6A75 04E6F139
	v_add_f32_e32 v115, 1.0, v50                               // 000000187BEC: 06E664F2
	v_fma_f32 v50, -v121, v103, 1.0                            // 000000187BF0: D6130032 23CACF79
	v_fma_f32 v113, -v122, v112, 1.0                           // 000000187BF8: D6130071 23CAE17A
	v_div_scale_f32 v119, null, v102, v102, v80                // 000000187C00: D6FC7C77 0542CD66
	v_cndmask_b32_e64 v96, 0x7f800000, v116, s5                // 000000187C08: D5010060 0016E8FF 7F800000
	v_dual_add_f32 v94, 1.0, v94 :: v_dual_add_f32 v95, 1.0, v95// 000000187C14: C908BCF2 5E5EBEF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000187C1C: BF870214
	v_dual_fmac_f32 v103, v50, v103 :: v_dual_fmac_f32 v112, v113, v112// 000000187C20: C800CF32 6770E171
	v_rcp_f32_e32 v146, v119                                   // 000000187C28: 7F245577
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000187C2C: BF870111
	v_mul_f32_e32 v50, v117, v103                              // 000000187C30: 1064CF75
	v_mul_f32_e32 v144, v118, v112                             // 000000187C34: 1120E176
	v_div_scale_f32 v113, null, v115, v115, v111               // 000000187C38: D6FC7C71 05BEE773
	v_div_scale_f32 v116, s5, v111, v115, v111                 // 000000187C40: D6FC0574 05BEE76F
	v_add_f32_e32 v93, 1.0, v93                                // 000000187C48: 06BABAF2
	v_fma_f32 v49, -v121, v50, v117                            // 000000187C4C: D6130031 25D66579
	v_fma_f32 v147, -v122, v144, v118                          // 000000187C54: D6130093 25DB217A
	v_rcp_f32_e32 v145, v113                                   // 000000187C5C: 7F225571
	v_add_f32_e32 v99, 1.0, v99                                // 000000187C60: 06C6C6F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000187C64: BF870193
	v_fmac_f32_e32 v50, v49, v103                              // 000000187C68: 5664CF31
	v_fmac_f32_e32 v144, v147, v112                            // 000000187C6C: 5720E193
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000187C70: BF870112
	v_fma_f32 v117, -v121, v50, v117                           // 000000187C74: D6130075 25D66579
	v_fma_f32 v118, -v122, v144, v118                          // 000000187C7C: D6130076 25DB217A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000187C84: BF870225
	v_fma_f32 v49, -v113, v145, 1.0                            // 000000187C88: D6130031 23CB2371
	v_fma_f32 v121, -v119, v146, 1.0                           // 000000187C90: D6130079 23CB2577
	v_div_fmas_f32 v103, v117, v103, v50                       // 000000187C98: D6370067 04CACF75
	s_mov_b32 vcc_lo, s4                                       // 000000187CA0: BEEA0004
	s_delay_alu instid0(VALU_DEP_3)                            // 000000187CA4: BF870003
	v_fmac_f32_e32 v145, v49, v145                             // 000000187CA8: 57232331
	v_div_fmas_f32 v112, v118, v112, v144                      // 000000187CAC: D6370070 0642E176
	s_mov_b32 vcc_lo, s2                                       // 000000187CB4: BEEA0002
	v_fmac_f32_e32 v146, v121, v146                            // 000000187CB8: 57252579
	v_div_fmas_f32 v50, v109, v91, v71                         // 000000187CBC: D6370032 051EB76D
	s_mov_b32 vcc_lo, s3                                       // 000000187CC4: BEEA0003
	v_div_fixup_f32 v57, v103, v120, v57                       // 000000187CC8: D6270039 04E6F167
	v_div_fmas_f32 v71, v108, v90, v72                         // 000000187CD0: D6370047 0522B56C
	v_div_scale_f32 v72, s2, v80, v102, v80                    // 000000187CD8: D6FC0248 0542CD50
	v_div_fixup_f32 v50, v50, v89, 1.0                         // 000000187CE0: D6270032 03CAB332
	v_add_f32_e32 v90, 1.0, v100                               // 000000187CE8: 06B4C8F2
	v_add_f32_e32 v96, 1.0, v96                                // 000000187CEC: 06C0C0F2
	v_div_fixup_f32 v49, v71, v88, 1.0                         // 000000187CF0: D6270031 03CAB147
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000187CF8: BF870244
	v_dual_mul_f32 v88, v116, v145 :: v_dual_mul_f32 v59, v59, v50// 000000187CFC: C8C72374 583A653B
	v_add_f32_e32 v71, 1.0, v101                               // 000000187D04: 068ECAF2
	v_mul_f32_e32 v103, v51, v50                               // 000000187D08: 10CE6533
	.long 0x7e9e39b9                                           // 000000187D0C: 7E9E39B9
	v_fma_f32 v91, -v113, v88, v116                            // 000000187D10: D613005B 25D2B171
	v_mul_f32_e32 v89, v72, v146                               // 000000187D18: 10B32548
	v_div_scale_f32 v100, null, v98, v98, v59                  // 000000187D1C: D6FC7C64 04EEC562
	v_div_fixup_f32 v58, v112, v73, v58                        // 000000187D24: D627003A 04EA9370
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000187D2C: BF870214
	v_dual_fmac_f32 v88, v91, v145 :: v_dual_and_b32 v79, 1, v79// 000000187D30: C825235B 584E9E81
	v_fma_f32 v101, -v119, v89, v72                            // 000000187D38: D6130065 2522B377
	v_mul_f32_e32 v60, v60, v49                                // 000000187D40: 1078633C
	v_rcp_f32_e32 v91, v100                                    // 000000187D44: 7EB65564
	.long 0x7e0039ba                                           // 000000187D48: 7E0039BA
	v_fma_f32 v109, -v113, v88, v116                           // 000000187D4C: D613006D 25D2B171
	v_fmac_f32_e32 v89, v101, v146                             // 000000187D54: 56B32565
	v_div_scale_f32 v108, null, v99, v99, v60                  // 000000187D58: D6FC7C6C 04F2C763
	v_mul_f32_e32 v113, v52, v49                               // 000000187D60: 10E26334
	v_div_scale_f32 v116, vcc_lo, v59, v98, v59                // 000000187D64: D6FC6A74 04EEC53B
	v_div_scale_f32 v122, s4, v103, v93, v103                  // 000000187D6C: D6FC047A 059EBB67
	v_div_scale_f32 v117, null, v93, v93, v103                 // 000000187D74: D6FC7C75 059EBB5D
	v_rcp_f32_e32 v101, v108                                   // 000000187D7C: 7ECA556C
	v_fma_f32 v51, -v100, v91, 1.0                             // 000000187D80: D6130033 23CAB764
	v_fma_f32 v72, -v119, v89, v72                             // 000000187D88: D6130048 2522B377
	v_add3_u32 v57, v57, v79, 0x7fff                           // 000000187D90: D6550039 03FE9F39 00007FFF
	v_rcp_f32_e32 v112, v117                                   // 000000187D9C: 7EE05575
	v_dual_mul_f32 v43, v43, v50 :: v_dual_mul_f32 v44, v44, v49// 000000187DA0: C8C6652B 2B2C632C
	v_dual_mul_f32 v36, v36, v49 :: v_dual_mul_f32 v35, v35, v50// 000000187DA8: C8C66324 24226523
	v_mul_f32_e32 v28, v28, v49                                // 000000187DB0: 1038631C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000187DB4: BF870246
	v_fma_f32 v52, -v108, v101, 1.0                            // 000000187DB8: D6130034 23CACB6C
	v_dual_mul_f32 v20, v20, v49 :: v_dual_mul_f32 v27, v27, v50// 000000187DC0: C8C66314 141A651B
	v_dual_mul_f32 v12, v12, v49 :: v_dual_mul_f32 v19, v19, v50// 000000187DC8: C8C6630C 0C126513
	v_mul_f32_e32 v4, v4, v49                                  // 000000187DD0: 10086304
	v_fmac_f32_e32 v101, v52, v101                             // 000000187DD4: 56CACB34
	v_fmac_f32_e32 v91, v51, v91                               // 000000187DD8: 56B6B733
	v_div_scale_f32 v51, s3, v60, v99, v60                     // 000000187DDC: D6FC0333 04F2C73C
	v_mul_f32_e32 v11, v11, v50                                // 000000187DE4: 1016650B
	v_mul_f32_e32 v3, v3, v50                                  // 000000187DE8: 10066503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000187DEC: BF870093
	v_mul_f32_e32 v118, v51, v101                              // 000000187DF0: 10ECCB33
	v_fma_f32 v121, -v108, v118, v51                           // 000000187DF4: D6130079 24CEED6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000187DFC: BF870121
	v_fmac_f32_e32 v118, v121, v101                            // 000000187E00: 56ECCB79
	v_mul_f32_e32 v52, v116, v91                               // 000000187E04: 1068B774
	v_fma_f32 v51, -v108, v118, v51                            // 000000187E08: D6130033 24CEED6C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000187E10: BF870092
	v_fma_f32 v120, -v100, v52, v116                           // 000000187E14: D6130078 25D26964
	v_fmac_f32_e32 v52, v120, v91                              // 000000187E1C: 5668B778
	v_fma_f32 v120, -v117, v112, 1.0                           // 000000187E20: D6130078 23CAE175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000187E28: BF870092
	v_fma_f32 v100, -v100, v52, v116                           // 000000187E2C: D6130064 25D26964
	v_div_fmas_f32 v91, v100, v91, v52                         // 000000187E34: D637005B 04D2B764
	s_mov_b32 vcc_lo, s3                                       // 000000187E3C: BEEA0003
	v_div_fmas_f32 v100, v51, v101, v118                       // 000000187E40: D6370064 05DACB33
	s_mov_b32 vcc_lo, s0                                       // 000000187E48: BEEA0000
	s_delay_alu instid0(VALU_DEP_2)                            // 000000187E4C: BF870002
	v_div_fixup_f32 v59, v91, v98, v59                         // 000000187E50: D627003B 04EEC55B
	v_div_fmas_f32 v51, v107, v85, v142                        // 000000187E58: D6370033 063AAB6B
	s_mov_b32 vcc_lo, s1                                       // 000000187E60: BEEA0001
	v_div_fixup_f32 v60, v100, v99, v60                        // 000000187E64: D627003C 04F2C764
	v_div_fmas_f32 v84, v110, v84, v143                        // 000000187E6C: D6370054 063EA96E
	v_and_b32_e32 v85, 1, v0                                   // 000000187E74: 36AA0081
	v_div_fixup_f32 v52, v51, v83, 1.0                         // 000000187E78: D6270034 03CAA733
	.long 0x7e9a39bb                                           // 000000187E80: 7E9A39BB
	.long 0x7e0039bc                                           // 000000187E84: 7E0039BC
	v_div_fixup_f32 v51, v84, v81, 1.0                         // 000000187E88: D6270033 03CAA354
	v_add3_u32 v58, v58, v85, 0x7fff                           // 000000187E90: D655003A 03FEAB3A 00007FFF
	v_mul_f32_e32 v61, v61, v52                                // 000000187E9C: 107A693D
	s_clause 0x1                                               // 000000187EA0: BF850001
	global_store_d16_hi_b16 v[7:8], v57, off                   // 000000187EA4: DC960000 007C3907
	global_store_d16_hi_b16 v[7:8], v58, off offset:1024       // 000000187EAC: DC960400 007C3A07
	v_mul_f32_e32 v62, v62, v51                                // 000000187EB4: 107C673E
	v_div_scale_f32 v73, null, v94, v94, v113                  // 000000187EB8: D6FC7C49 05C6BD5E
	v_div_scale_f32 v121, s6, v113, v94, v113                  // 000000187EC0: D6FC0679 05C6BD71
	v_mul_f32_e32 v54, v54, v51                                // 000000187EC8: 106C6736
	v_div_scale_f32 v85, null, v90, v90, v61                   // 000000187ECC: D6FC7C55 04F6B55A
	v_mul_f32_e32 v53, v53, v52                                // 000000187ED4: 106A6935
	v_rcp_f32_e32 v119, v73                                    // 000000187ED8: 7EEE5549
	v_div_scale_f32 v99, vcc_lo, v61, v90, v61                 // 000000187EDC: D6FC6A63 04F6B53D
	v_div_scale_f32 v116, null, v96, v96, v54                  // 000000187EE4: D6FC7C74 04DAC160
	v_mul_f32_e32 v37, v37, v52                                // 000000187EEC: 104A6925
	v_div_scale_f32 v100, null, v95, v95, v53                  // 000000187EF0: D6FC7C64 04D6BF5F
	v_div_scale_f32 v110, s1, v53, v95, v53                    // 000000187EF8: D6FC016E 04D6BF35
	v_dual_mul_f32 v22, v22, v51 :: v_dual_mul_f32 v29, v29, v52// 000000187F00: C8C66716 161C691D
	v_mul_f32_e32 v14, v14, v51                                // 000000187F08: 101C670E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000187F0C: BF870314
	v_rcp_f32_e32 v107, v100                                   // 000000187F10: 7ED65564
	v_fma_f32 v144, -v73, v119, 1.0                            // 000000187F14: D6130090 23CAEF49
	v_mul_f32_e32 v21, v21, v52                                // 000000187F1C: 102A6915
	v_mul_f32_e32 v13, v13, v52                                // 000000187F20: 101A690D
	v_dual_mul_f32 v5, v5, v52 :: v_dual_mul_f32 v6, v6, v51   // 000000187F24: C8C66905 05066706
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000187F2C: BF870094
	v_fmac_f32_e32 v119, v144, v119                            // 000000187F30: 56EEEF90
	v_dual_fmac_f32 v112, v120, v112 :: v_dual_mul_f32 v81, v121, v119// 000000187F34: C806E178 7050EF79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000187F3C: BF870111
	v_mul_f32_e32 v83, v122, v112                              // 000000187F40: 10A6E17A
	v_fma_f32 v84, -v73, v81, v121                             // 000000187F44: D6130054 25E6A349
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000187F4C: BF870092
	v_fma_f32 v79, -v117, v83, v122                            // 000000187F50: D613004F 25EAA775
	v_fmac_f32_e32 v83, v79, v112                              // 000000187F58: 56A6E14F
	v_div_scale_f32 v79, null, v71, v71, v62                   // 000000187F5C: D6FC7C4F 04FA8F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000187F64: BF870291
	v_rcp_f32_e32 v91, v79                                     // 000000187F68: 7EB6554F
	v_fma_f32 v98, -v79, v91, 1.0                              // 000000187F6C: D6130062 23CAB74F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000187F74: BF870131
	v_dual_fmac_f32 v91, v98, v91 :: v_dual_and_b32 v98, 1, v0 // 000000187F78: C824B762 5B620081
	v_fmac_f32_e32 v81, v84, v119                              // 000000187F80: 56A2EF54
	v_rcp_f32_e32 v84, v85                                     // 000000187F84: 7EA85555
	v_add3_u32 v60, v60, v98, 0x7fff                           // 000000187F88: D655003C 03FEC53C 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000187F94: BF870292
	v_fma_f32 v58, -v73, v81, v121                             // 000000187F98: D613003A 25E6A349
	v_fma_f32 v73, -v85, v84, 1.0                              // 000000187FA0: D6130049 23CAA955
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000187FA8: BF8700A1
	v_fmac_f32_e32 v84, v73, v84                               // 000000187FAC: 56A8A949
	v_div_scale_f32 v73, s0, v62, v71, v62                     // 000000187FB0: D6FC0049 04FA8F3E
	v_dual_mul_f32 v101, v99, v84 :: v_dual_mul_f32 v108, v73, v91// 000000187FB8: C8C6A963 656CB749
	v_fma_f32 v57, -v117, v83, v122                            // 000000187FC0: D6130039 25EAA775
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000187FC8: BF870092
	v_fma_f32 v117, -v79, v108, v73                            // 000000187FCC: D6130075 2526D94F
	v_dual_fmac_f32 v108, v117, v91 :: v_dual_and_b32 v77, 1, v77// 000000187FD4: C824B775 6C4C9A81
	s_delay_alu instid0(VALU_DEP_1)                            // 000000187FDC: BF870001
	v_add3_u32 v59, v59, v77, 0x7fff                           // 000000187FE0: D655003B 03FE9B3B 00007FFF
	v_fma_f32 v77, -v85, v101, v99                             // 000000187FEC: D613004D 258ECB55
	global_store_d16_hi_b16 v[15:16], v59, off                 // 000000187FF4: DC960000 007C3B0F
	v_fma_f32 v59, -v100, v107, 1.0                            // 000000187FFC: D613003B 23CAD764
	global_store_d16_hi_b16 v[23:24], v60, off                 // 000000188004: DC960000 007C3C17
	v_fmac_f32_e32 v107, v59, v107                             // 00000018800C: 56D6D73B
	v_fmac_f32_e32 v101, v77, v84                              // 000000188010: 56CAA94D
	v_fma_f32 v59, -v79, v108, v73                             // 000000188014: D613003B 2526D94F
	v_rcp_f32_e32 v77, v116                                    // 00000018801C: 7E9A5574
	s_waitcnt vmcnt(23)                                        // 000000188020: BF895FF7
	v_lshlrev_b32_e32 v79, 16, v137                            // 000000188024: 309F1290
	v_mul_f32_e32 v41, v41, v66                                // 000000188028: 10528529
	v_fma_f32 v60, -v85, v101, v99                             // 00000018802C: D613003C 258ECB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 000000188034: BF870141
	v_div_fmas_f32 v60, v60, v84, v101                         // 000000188038: D637003C 0596A93C
	s_mov_b32 vcc_lo, s0                                       // 000000188040: BEEA0000
	v_div_fmas_f32 v59, v59, v91, v108                         // 000000188044: D637003B 05B2B73B
	s_mov_b32 vcc_lo, s2                                       // 00000018804C: BEEA0002
	v_div_fixup_f32 v60, v60, v90, v61                         // 000000188050: D627003C 04F6B53C
	v_div_fmas_f32 v72, v72, v146, v89                         // 000000188058: D6370048 05672548
	s_mov_b32 vcc_lo, s5                                       // 000000188060: BEEA0005
	v_div_fixup_f32 v59, v59, v71, v62                         // 000000188064: D627003B 04FA8F3B
	v_div_fmas_f32 v61, v109, v145, v88                        // 00000018806C: D637003D 0563236D
	.long 0x7e9839bc                                           // 000000188074: 7E9839BC
	v_div_fixup_f32 v62, v72, v102, v80                        // 000000188078: D627003E 0542CD48
	s_mov_b32 vcc_lo, s4                                       // 000000188080: BEEA0004
	.long 0x7e0039bb                                           // 000000188084: 7E0039BB
	v_div_fixup_f32 v61, v61, v115, v111                       // 000000188088: D627003D 05BEE73D
	v_and_b32_e32 v72, 1, v76                                  // 000000188090: 36909881
	.long 0x7e9639be                                           // 000000188094: 7E9639BE
	v_div_fmas_f32 v57, v57, v112, v83                         // 000000188098: D6370039 054EE139
	v_and_b32_e32 v71, 1, v0                                   // 0000001880A0: 368E0081
	.long 0x7e0039bd                                           // 0000001880A4: 7E0039BD
	v_add3_u32 v60, v60, v72, 0x7fff                           // 0000001880A8: D655003C 03FE913C 00007FFF
	v_fma_f32 v72, 0xbfb8aa3b, v97, -v153                      // 0000001880B4: D6130048 8666C2FF BFB8AA3B
	s_mov_b32 vcc_lo, s6                                       // 0000001880C0: BEEA0006
	v_add3_u32 v59, v59, v71, 0x7fff                           // 0000001880C4: D655003B 03FE8F3B 00007FFF
	v_div_fmas_f32 v58, v58, v119, v81                         // 0000001880D0: D637003A 0546EF3A
	v_div_fixup_f32 v57, v57, v93, v103                        // 0000001880D8: D6270039 059EBB39
	v_dual_fmac_f32 v72, 0xb2a5705f, v97 :: v_dual_and_b32 v73, 1, v75// 0000001880E0: C824C2FF 48489681 B2A5705F
	v_and_b32_e32 v75, 1, v0                                   // 0000001880EC: 36960081
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001880F0: BF870004
	v_div_fixup_f32 v58, v58, v94, v113                        // 0000001880F4: D627003A 05C6BD3A
	s_clause 0x1                                               // 0000001880FC: BF850001
	global_store_d16_hi_b16 v[31:32], v60, off                 // 000000188100: DC960000 007C3C1F
	global_store_d16_hi_b16 v[39:40], v59, off                 // 000000188108: DC960000 007C3B27
	v_fma_f32 v60, -v116, v77, 1.0                             // 000000188110: D613003C 23CA9B74
	v_add3_u32 v62, v62, v73, 0x7fff                           // 000000188118: D655003E 03FE933E 00007FFF
	v_add3_u32 v61, v61, v75, 0x7fff                           // 000000188124: D655003D 03FE973D 00007FFF
	s_clause 0x1                                               // 000000188130: BF850001
	global_store_d16_hi_b16 v[7:8], v61, off offset:32         // 000000188134: DC960020 007C3D07
	global_store_d16_hi_b16 v[47:48], v62, off offset:32       // 00000018813C: DC960020 007C3E2F
	v_add_f32_e32 v61, v114, v151                              // 000000188144: 067B2F72
	.long 0x7e0039ba                                           // 000000188148: 7E0039BA
	.long 0x7e9439b9                                           // 00000018814C: 7E9439B9
	v_rndne_f32_e32 v73, v153                                  // 000000188150: 7E924799
	v_fmac_f32_e32 v77, v60, v77                               // 000000188154: 569A9B3C
	v_exp_f32_e32 v60, v61                                     // 000000188158: 7E784B3D
	v_div_scale_f32 v61, s0, v54, v96, v54                     // 00000018815C: D6FC003D 04DAC136
	v_and_b32_e32 v59, 1, v0                                   // 000000188164: 36760081
	v_dual_sub_f32 v74, v153, v73 :: v_dual_and_b32 v71, 1, v74// 000000188168: C9649399 4A469481
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v82                  // 000000188170: 7C3CA4FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 000000188178: BF870004
	v_mul_f32_e32 v76, v61, v77                                // 00000018817C: 10989B3D
	v_mul_f32_e32 v62, v110, v107                              // 000000188180: 107CD76E
	v_add3_u32 v58, v58, v59, 0x7fff                           // 000000188184: D655003A 03FE773A 00007FFF
	v_cvt_i32_f32_e32 v59, v152                                // 000000188190: 7E761198
	v_add_f32_e32 v72, v74, v72                                // 000000188194: 0690914A
	v_add3_u32 v57, v57, v71, 0x7fff                           // 000000188198: D6550039 03FE8F39 00007FFF
	v_fma_f32 v75, -v100, v62, v110                            // 0000001881A4: D613004B 25BA7D64
	v_mul_f32_e32 v80, 0xbfb8aa3b, v79                         // 0000001881AC: 10A09EFF BFB8AA3B
	.long 0xd71c003b                                           // 0000001881B4: D71C003B
	v_cndmask_b32_e32 v1, v60, v59, vcc_lo                     // 0000001881B8: 0202773C
	v_fma_f32 v60, -v116, v76, v61                             // 0000001881BC: D613003C 24F69974
	v_exp_f32_e32 v71, v72                                     // 0000001881C4: 7E8E4B48
	v_fmac_f32_e32 v62, v75, v107                              // 0000001881C8: 567CD74B
	global_store_d16_hi_b16 v[15:16], v57, off offset:32       // 0000001881CC: DC960020 007C390F
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 0000001881D4: 02767680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v82                  // 0000001881D8: 7C36A4FF C2B17218
	v_fmac_f32_e32 v76, v60, v77                               // 0000001881E0: 56989B3C
	v_fma_f32 v72, -v100, v62, v110                            // 0000001881E4: D6130048 25BA7D64
	v_cvt_i32_f32_e32 v60, v73                                 // 0000001881EC: 7E781149
	global_store_d16_hi_b16 v[23:24], v58, off offset:32       // 0000001881F0: DC960020 007C3A17
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 0000001881F8: 027676FF 7F800000
	s_mov_b32 vcc_lo, s1                                       // 000000188200: BEEA0001
	v_fma_f32 v61, -v116, v76, v61                             // 000000188204: D613003D 24F69974
	v_div_fmas_f32 v62, v72, v107, v62                         // 00000018820C: D637003E 04FAD748
	.long 0xd71c003c                                           // 000000188214: D71C003C
	v_cndmask_b32_e32 v1, v71, v60, vcc_lo                     // 000000188218: 02027947
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000018821C: 7C3CC2FF 42CE8ED0
	.long 0x7f903980                                           // 000000188224: 7F903980
	v_fma_f32 v82, 0xbfb8aa3b, v79, -v80                       // 000000188228: D6130052 85429EFF BFB8AA3B
	v_div_fixup_f32 v53, v62, v95, v53                         // 000000188234: D6270035 04D6BF3E
	v_rndne_f32_e32 v83, v80                                   // 00000018823C: 7EA64750
	v_cndmask_b32_e32 v60, 0, v60, vcc_lo                      // 000000188240: 02787880
	s_mov_b32 vcc_lo, s0                                       // 000000188244: BEEA0000
	v_div_fmas_f32 v61, v61, v77, v76                          // 000000188248: D637003D 05329B3D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000188250: 7C36C2FF C2B17218
	.long 0x7e9039b5                                           // 000000188258: 7E9039B5
	v_sub_f32_e32 v80, v80, v83                                // 00000018825C: 08A0A750
	v_fmac_f32_e32 v82, 0xb2a5705f, v79                        // 000000188260: 56A49EFF B2A5705F
	v_div_fixup_f32 v54, v61, v96, v54                         // 000000188268: D6270036 04DAC13D
	v_dual_cndmask_b32 v60, 0x7f800000, v60 :: v_dual_lshlrev_b32 v61, 16, v138// 000000188270: CA6278FF 3C3D1490 7F800000
	v_and_b32_e32 v72, 1, v72                                  // 00000018827C: 36909081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000188280: BF870214
	v_add_f32_e32 v80, v80, v82                                // 000000188284: 06A0A550
	.long 0x7e0039b6                                           // 000000188288: 7E0039B6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000018828C: BF870234
	v_add_f32_e32 v60, 1.0, v60                                // 000000188290: 067878F2
	v_mul_f32_e32 v62, 0xbfb8aa3b, v61                         // 000000188294: 107C7AFF BFB8AA3B
	v_add3_u32 v53, v53, v72, 0x7fff                           // 00000018829C: D6550035 03FE9135 00007FFF
	v_and_b32_e32 v77, 1, v0                                   // 0000001882A8: 369A0081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001882AC: BF870214
	v_div_scale_f32 v58, null, v60, v60, v42                   // 0000001882B0: D6FC7C3A 04AA793C
	v_fma_f32 v75, 0xbfb8aa3b, v61, -v62                       // 0000001882B8: D613004B 84FA7AFF BFB8AA3B
	v_rndne_f32_e32 v76, v62                                   // 0000001882C4: 7E98473E
	global_store_d16_hi_b16 v[31:32], v53, off offset:32       // 0000001882C8: DC960020 007C351F
	v_add3_u32 v54, v54, v77, 0x7fff                           // 0000001882D0: D6550036 03FE9B36 00007FFF
	v_rcp_f32_e32 v74, v58                                     // 0000001882DC: 7E94553A
	v_sub_f32_e32 v62, v62, v76                                // 0000001882E0: 087C993E
	v_cvt_i32_f32_e32 v76, v76                                 // 0000001882E4: 7E98114C
	global_store_d16_hi_b16 v[39:40], v54, off offset:32       // 0000001882E8: DC960020 007C3627
	v_fma_f32 v81, -v58, v74, 1.0                              // 0000001882F0: D6130051 23CA953A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001882F8: BF870091
	v_dual_add_f32 v59, 1.0, v59 :: v_dual_fmac_f32 v74, v81, v74// 0000001882FC: C90076F2 3B4A9551
	v_div_scale_f32 v71, null, v59, v59, v41                   // 000000188304: D6FC7C47 04A6773B
	v_div_scale_f32 v81, s0, v42, v60, v42                     // 00000018830C: D6FC0051 04AA792A
	v_fmac_f32_e32 v75, 0xb2a5705f, v61                        // 000000188314: 56967AFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000018831C: BF870113
	v_rcp_f32_e32 v57, v71                                     // 000000188320: 7E725547
	v_mul_f32_e32 v84, v81, v74                                // 000000188324: 10A89551
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000188328: BF8701A2
	v_add_f32_e32 v62, v62, v75                                // 00000018832C: 067C973E
	.long 0xd41e0001                                           // 000000188330: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v61, vcc_lo              // 000000188334: 02027AFF 42CE8ED0
	v_fma_f32 v72, -v58, v84, v81                              // 00000018833C: D6130048 2546A93A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000188344: BF870313
	v_exp_f32_e32 v62, v62                                     // 000000188348: 7E7C4B3E
	v_fma_f32 v73, -v71, v57, 1.0                              // 00000018834C: D6130049 23CA7347
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000188354: BF8701A2
	v_fmac_f32_e32 v84, v72, v74                               // 000000188358: 56A89548
	v_cvt_i32_f32_e32 v72, v83                                 // 00000018835C: 7E901153
	v_fmac_f32_e32 v57, v73, v57                               // 000000188360: 56727349
	v_div_scale_f32 v73, vcc_lo, v41, v59, v41                 // 000000188364: D6FC6A49 04A67729
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000018836C: BF8701B5
	.long 0xd71c003e                                           // 000000188370: D71C003E
	v_cndmask_b32_e32 v1, v62, v76, vcc_lo                     // 000000188374: 0202993E
	v_exp_f32_e32 v76, v80                                     // 000000188378: 7E984B50
	v_fma_f32 v58, -v58, v84, v81                              // 00000018837C: D613003A 2546A93A
	v_mul_f32_e32 v75, v73, v57                                // 000000188384: 10967349
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000188388: BF8701A3
	v_cndmask_b32_e64 v62, 0, v62, s1                          // 00000018838C: D501003E 00067C80
	.long 0xd41b0001                                           // 000000188394: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v61, vcc_lo              // 000000188398: 02027AFF C2B17218
	v_fma_f32 v77, -v71, v75, v73                              // 0000001883A0: D613004D 25269747
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001883A8: BF870292
	v_cndmask_b32_e64 v61, 0x7f800000, v62, s1                 // 0000001883AC: D501003D 00067CFF 7F800000
	.long 0xd71c003e                                           // 0000001883B8: D71C003E
	v_cndmask_b32_e32 v1, v76, v72, vcc_lo                     // 0000001883BC: 0202914C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001883C0: BF870093
	v_fmac_f32_e32 v75, v77, v57                               // 0000001883C4: 5696734D
	v_fma_f32 v71, -v71, v75, v73                              // 0000001883C8: D6130047 25269747
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001883D0: BF870121
	v_div_fmas_f32 v57, v71, v57, v75                          // 0000001883D4: D6370039 052E7347
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v79                  // 0000001883DC: 7C3C9EFF 42CE8ED0
	v_div_fixup_f32 v41, v57, v59, v41                         // 0000001883E4: D6270029 04A67739
	v_cndmask_b32_e32 v62, 0, v62, vcc_lo                      // 0000001883EC: 027C7C80
	s_mov_b32 vcc_lo, s0                                       // 0000001883F0: BEEA0000
	.long 0x7f763980                                           // 0000001883F4: 7F763980
	v_div_fmas_f32 v58, v58, v74, v84                          // 0000001883F8: D637003A 0552953A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v79                  // 000000188400: 7C369EFF C2B17218
	v_add_f32_e32 v61, 1.0, v61                                // 000000188408: 067A7AF2
	.long 0x7e7639a9                                           // 00000018840C: 7E7639A9
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000188410: BF870224
	v_div_fixup_f32 v42, v58, v60, v42                         // 000000188414: D627002A 04AA793A
	v_cndmask_b32_e32 v62, 0x7f800000, v62, vcc_lo             // 00000018841C: 027C7CFF 7F800000
	v_div_scale_f32 v71, null, v61, v61, v43                   // 000000188424: D6FC7C47 04AE7B3D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000018842C: BF870113
	.long 0x7e0039aa                                           // 000000188430: 7E0039AA
	v_rcp_f32_e32 v53, v71                                     // 000000188434: 7E6A5547
	s_waitcnt vmcnt(17)                                        // 000000188438: BF8947F7
	v_lshlrev_b32_e32 v60, 16, v140                            // 00000018843C: 30791890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000188440: BF870092
	v_dual_add_f32 v58, 1.0, v62 :: v_dual_and_b32 v75, 1, v0  // 000000188444: C9247CF2 3A4A0081
	v_add3_u32 v42, v42, v75, 0x7fff                           // 00000018844C: D655002A 03FE972A 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000188458: BF870095
	v_fma_f32 v62, -v71, v53, 1.0                              // 00000018845C: D613003E 23CA6B47
	v_fmac_f32_e32 v53, v62, v53                               // 000000188464: 566A6B3E
	v_mul_f32_e32 v57, 0xbfb8aa3b, v60                         // 000000188468: 107278FF BFB8AA3B
	v_div_scale_f32 v54, null, v58, v58, v44                   // 000000188470: D6FC7C36 04B2753A
	v_div_scale_f32 v62, vcc_lo, v43, v61, v43                 // 000000188478: D6FC6A3E 04AE7B2B
	.long 0xd41e0001                                           // 000000188480: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v60, vcc_lo              // 000000188484: 020278FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000018848C: BF870214
	v_fma_f32 v73, 0xbfb8aa3b, v60, -v57                       // 000000188490: D6130049 84E678FF BFB8AA3B
	v_rcp_f32_e32 v72, v54                                     // 00000018849C: 7E905536
	v_rndne_f32_e32 v74, v57                                   // 0000001884A0: 7E944739
	s_waitcnt vmcnt(11)                                        // 0000001884A4: BF892FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001884A8: BF870092
	v_dual_fmac_f32 v73, 0xb2a5705f, v60 :: v_dual_lshlrev_b32 v76, 16, v139// 0000001884AC: C82278FF 494D1690 B2A5705F
	v_mul_f32_e32 v77, 0xbfb8aa3b, v76                         // 0000001884B8: 109A98FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001884C0: BF8701A5
	v_fma_f32 v79, -v54, v72, 1.0                              // 0000001884C4: D613004F 23CA9136
	v_sub_f32_e32 v57, v57, v74                                // 0000001884CC: 08729539
	v_fma_f32 v80, 0xbfb8aa3b, v76, -v77                       // 0000001884D0: D6130050 853698FF BFB8AA3B
	v_and_b32_e32 v59, 1, v59                                  // 0000001884DC: 36767681
	v_rndne_f32_e32 v81, v77                                   // 0000001884E0: 7EA2474D
	v_fmac_f32_e32 v72, v79, v72                               // 0000001884E4: 5690914F
	v_div_scale_f32 v79, s0, v44, v58, v44                     // 0000001884E8: D6FC004F 04B2752C
	v_dual_add_f32 v57, v57, v73 :: v_dual_fmac_f32 v80, 0xb2a5705f, v76// 0000001884F0: C9009339 395098FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001884FC: BF870224
	v_sub_f32_e32 v77, v77, v81                                // 000000188500: 089AA34D
	v_add3_u32 v41, v41, v59, 0x7fff                           // 000000188504: D6550029 03FE7729 00007FFF
	v_mul_f32_e32 v82, v79, v72                                // 000000188510: 10A4914F
	s_delay_alu instid0(VALU_DEP_4)                            // 000000188514: BF870004
	v_exp_f32_e32 v57, v57                                     // 000000188518: 7E724B39
	v_cvt_i32_f32_e32 v74, v74                                 // 00000018851C: 7E94114A
	v_add_f32_e32 v77, v77, v80                                // 000000188520: 069AA14D
	global_store_d16_hi_b16 v[7:8], v41, off offset:64         // 000000188524: DC960040 007C2907
	v_fma_f32 v59, -v54, v82, v79                              // 00000018852C: D613003B 253EA536
	v_mul_f32_e32 v73, v62, v53                                // 000000188534: 10926B3E
	global_store_d16_hi_b16 v[47:48], v42, off offset:64       // 000000188538: DC960040 007C2A2F
	v_fmac_f32_e32 v82, v59, v72                               // 000000188540: 56A4913B
	v_fma_f32 v75, -v71, v73, v62                              // 000000188544: D613004B 24FA9347
	.long 0xd71c0039                                           // 00000018854C: D71C0039
	v_cndmask_b32_e32 v1, v57, v74, vcc_lo                     // 000000188550: 02029539
	v_exp_f32_e32 v74, v77                                     // 000000188554: 7E944B4D
	v_cvt_i32_f32_e32 v59, v81                                 // 000000188558: 7E761151
	v_fma_f32 v54, -v54, v82, v79                              // 00000018855C: D6130036 253EA536
	v_fmac_f32_e32 v73, v75, v53                               // 000000188564: 56926B4B
	v_cndmask_b32_e64 v57, 0, v57, s1                          // 000000188568: D5010039 00067280
	.long 0xd41b0001                                           // 000000188570: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v60, vcc_lo              // 000000188574: 020278FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000018857C: BF870293
	v_fma_f32 v62, -v71, v73, v62                              // 000000188580: D613003E 24FA9347
	.long 0xd71c003b                                           // 000000188588: D71C003B
	v_cndmask_b32_e32 v1, v74, v59, vcc_lo                     // 00000018858C: 0202774A
	s_waitcnt vmcnt(5)                                         // 000000188590: BF8917F7
	v_lshlrev_b32_e32 v74, 16, v141                            // 000000188594: 30951A90
	v_cndmask_b32_e64 v57, 0x7f800000, v57, s1                 // 000000188598: D5010039 000672FF 7F800000
	v_div_fmas_f32 v53, v62, v53, v73                          // 0000001885A4: D6370035 05266B3E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v76                  // 0000001885AC: 7C3C98FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001885B4: BF870194
	v_mul_f32_e32 v75, 0xbfb8aa3b, v74                         // 0000001885B8: 109694FF BFB8AA3B
	v_div_fixup_f32 v43, v53, v61, v43                         // 0000001885C0: D627002B 04AE7B35
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 0000001885C8: 02767680
	s_mov_b32 vcc_lo, s0                                       // 0000001885CC: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001885D0: BF8701B3
	v_fma_f32 v77, 0xbfb8aa3b, v74, -v75                       // 0000001885D4: D613004D 852E94FF BFB8AA3B
	v_div_fmas_f32 v54, v54, v72, v82                          // 0000001885E0: D6370036 054A9136
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v76                  // 0000001885E8: 7C3698FF C2B17218
	v_fmac_f32_e32 v77, 0xb2a5705f, v74                        // 0000001885F0: 569A94FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001885F8: BF870003
	v_div_fixup_f32 v41, v54, v58, v44                         // 0000001885FC: D6270029 04B27536
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 000000188604: 027676FF 7F800000
	v_mul_f32_e32 v44, v46, v51                                // 00000018860C: 1058672E
	v_lshlrev_b32_e32 v58, 16, v78                             // 000000188610: 30749C90
	v_rndne_f32_e32 v78, v75                                   // 000000188614: 7E9C474B
	.long 0x7e0039a9                                           // 000000188618: 7E0039A9
	v_add_f32_e32 v54, 1.0, v59                                // 00000018861C: 066C76F2
	.long 0x7e7639ab                                           // 000000188620: 7E7639AB
	v_mul_f32_e32 v53, 0xbfb8aa3b, v58                         // 000000188624: 106A74FF BFB8AA3B
	.long 0x7f763980                                           // 00000018862C: 7F763980
	v_sub_f32_e32 v75, v75, v78                                // 000000188630: 08969D4B
	v_div_scale_f32 v42, null, v54, v54, v44                   // 000000188634: D6FC7C2A 04B26D36
	.long 0xd41e0001                                           // 00000018863C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v58, vcc_lo              // 000000188640: 020274FF 42CE8ED0
	v_fma_f32 v71, 0xbfb8aa3b, v58, -v53                       // 000000188648: D6130047 84D674FF BFB8AA3B
	v_rndne_f32_e32 v72, v53                                   // 000000188654: 7E904735
	v_and_b32_e32 v59, 1, v59                                  // 000000188658: 36767681
	v_rcp_f32_e32 v62, v42                                     // 00000018865C: 7E7C552A
	v_add_f32_e32 v75, v75, v77                                // 000000188660: 06969B4B
	v_fmac_f32_e32 v71, 0xb2a5705f, v58                        // 000000188664: 568E74FF B2A5705F
	v_sub_f32_e32 v53, v53, v72                                // 00000018866C: 086A9135
	v_cvt_i32_f32_e32 v72, v72                                 // 000000188670: 7E901148
	v_add3_u32 v43, v43, v59, 0x7fff                           // 000000188674: D655002B 03FE772B 00007FFF
	v_and_b32_e32 v73, 1, v0                                   // 000000188680: 36920081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000188684: BF870294
	v_add_f32_e32 v53, v53, v71                                // 000000188688: 066A8F35
	v_fma_f32 v76, -v42, v62, 1.0                              // 00000018868C: D613004C 23CA7D2A
	v_mul_f32_e32 v45, v45, v52                                // 000000188694: 105A692D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000188698: BF870214
	v_add3_u32 v41, v41, v73, 0x7fff                           // 00000018869C: D6550029 03FE9329 00007FFF
	v_exp_f32_e32 v53, v53                                     // 0000001886A8: 7E6A4B35
	global_store_d16_hi_b16 v[15:16], v43, off offset:64       // 0000001886AC: DC960040 007C2B0F
	v_fmac_f32_e32 v62, v76, v62                               // 0000001886B4: 567C7D4C
	v_div_scale_f32 v76, s0, v44, v54, v44                     // 0000001886B8: D6FC004C 04B26D2C
	global_store_d16_hi_b16 v[23:24], v41, off offset:64       // 0000001886C0: DC960040 007C2917
	v_mul_f32_e32 v79, v76, v62                                // 0000001886C8: 109E7D4C
	.long 0xd71c0035                                           // 0000001886CC: D71C0035
	v_cndmask_b32_e32 v1, v53, v72, vcc_lo                     // 0000001886D0: 02029135
	v_exp_f32_e32 v72, v75                                     // 0000001886D4: 7E904B4B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001886D8: BF870112
	v_fma_f32 v59, -v42, v79, v76                              // 0000001886DC: D613003B 25329F2A
	v_cndmask_b32_e64 v53, 0, v53, s1                          // 0000001886E4: D5010035 00066A80
	.long 0xd41b0001                                           // 0000001886EC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v58, vcc_lo              // 0000001886F0: 020274FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001886F8: BF8701A3
	v_fmac_f32_e32 v79, v59, v62                               // 0000001886FC: 569E7D3B
	v_cvt_i32_f32_e32 v59, v78                                 // 000000188700: 7E76114E
	v_cndmask_b32_e64 v53, 0x7f800000, v53, s1                 // 000000188704: D5010035 00066AFF 7F800000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000188710: BF870003
	v_fma_f32 v42, -v42, v79, v76                              // 000000188714: D613002A 25329F2A
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 00000018871C: BF870185
	.long 0xd71c003a                                           // 000000188720: D71C003A
	v_cndmask_b32_e32 v1, v72, v59, vcc_lo                     // 000000188724: 02027748
	v_dual_add_f32 v57, 1.0, v57 :: v_dual_lshlrev_b32 v72, 16, v132// 000000188728: C92272F2 39490890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000188730: BF870091
	v_div_scale_f32 v60, null, v57, v57, v45                   // 000000188734: D6FC7C3C 04B67339
	v_rcp_f32_e32 v46, v60                                     // 00000018873C: 7E5C553C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000188740: BF870095
	v_fma_f32 v61, -v60, v46, 1.0                              // 000000188744: D613003D 23CA5D3C
	v_fmac_f32_e32 v46, v61, v46                               // 00000018874C: 565C5D3D
	v_div_scale_f32 v61, vcc_lo, v45, v57, v45                 // 000000188750: D6FC6A3D 04B6732D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000188758: BF870091
	v_mul_f32_e32 v71, v61, v46                                // 00000018875C: 108E5D3D
	v_fma_f32 v73, -v60, v71, v61                              // 000000188760: D6130049 24F68F3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000188768: BF870121
	v_fmac_f32_e32 v71, v73, v46                               // 00000018876C: 568E5D49
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 000000188770: 109290FF BFB8AA3B
	v_fma_f32 v60, -v60, v71, v61                              // 000000188778: D613003C 24F68F3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000188780: BF8701A2
	v_fma_f32 v75, 0xbfb8aa3b, v72, -v73                       // 000000188784: D613004B 852690FF BFB8AA3B
	v_rndne_f32_e32 v76, v73                                   // 000000188790: 7E984749
	v_div_fmas_f32 v46, v60, v46, v71                          // 000000188794: D637002E 051E5D3C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v74                  // 00000018879C: 7C3C94FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001887A4: BF870214
	v_fmac_f32_e32 v75, 0xb2a5705f, v72                        // 0000001887A8: 569690FF B2A5705F
	v_dual_sub_f32 v73, v73, v76 :: v_dual_cndmask_b32 v58, 0, v58// 0000001887B0: C9529949 493A7480
	s_mov_b32 vcc_lo, s0                                       // 0000001887B8: BEEA0000
	v_div_fixup_f32 v45, v46, v57, v45                         // 0000001887BC: D627002D 04B6732E
	v_div_fmas_f32 v42, v42, v62, v79                          // 0000001887C4: D637002A 053E7D2A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v74                  // 0000001887CC: 7C3694FF C2B17218
	.long 0x7f723980                                           // 0000001887D4: 7F723980
	v_add_f32_e32 v73, v73, v75                                // 0000001887D8: 06929749
	.long 0x7e7239ad                                           // 0000001887DC: 7E7239AD
	v_div_fixup_f32 v42, v42, v54, v44                         // 0000001887E0: D627002A 04B26D2A
	v_cndmask_b32_e32 v58, 0x7f800000, v58, vcc_lo             // 0000001887E8: 027474FF 7F800000
	v_lshlrev_b32_e32 v54, 16, v133                            // 0000001887F0: 306D0A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001887F4: BF870214
	v_and_b32_e32 v57, 1, v57                                  // 0000001887F8: 36727281
	.long 0x7e0039aa                                           // 0000001887FC: 7E0039AA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000188800: BF870214
	v_add_f32_e32 v44, 1.0, v58                                // 000000188804: 065874F2
	v_mul_f32_e32 v46, 0xbfb8aa3b, v54                         // 000000188808: 105C6CFF BFB8AA3B
	.long 0xd41e0001                                           // 000000188810: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v54, vcc_lo              // 000000188814: 02026CFF 42CE8ED0
	v_add3_u32 v45, v45, v57, 0x7fff                           // 00000018881C: D655002D 03FE732D 00007FFF
	v_and_b32_e32 v71, 1, v0                                   // 000000188828: 368E0081
	v_div_scale_f32 v41, null, v44, v44, v34                   // 00000018882C: D6FC7C29 048A592C
	v_fma_f32 v61, 0xbfb8aa3b, v54, -v46                       // 000000188834: D613003D 84BA6CFF BFB8AA3B
	v_rndne_f32_e32 v62, v46                                   // 000000188840: 7E7C472E
	global_store_d16_hi_b16 v[31:32], v45, off offset:64       // 000000188844: DC960040 007C2D1F
	v_add3_u32 v42, v42, v71, 0x7fff                           // 00000018884C: D655002A 03FE8F2A 00007FFF
	v_rcp_f32_e32 v60, v41                                     // 000000188858: 7E785529
	v_fmac_f32_e32 v61, 0xb2a5705f, v54                        // 00000018885C: 567A6CFF B2A5705F
	v_sub_f32_e32 v46, v46, v62                                // 000000188864: 085C7D2E
	v_cvt_i32_f32_e32 v62, v62                                 // 000000188868: 7E7C113E
	v_lshlrev_b32_e32 v45, 16, v135                            // 00000018886C: 305B0E90
	global_store_d16_hi_b16 v[39:40], v42, off offset:64       // 000000188870: DC960040 007C2A27
	v_add_f32_e32 v46, v46, v61                                // 000000188878: 065C7B2E
	v_fma_f32 v74, -v41, v60, 1.0                              // 00000018887C: D613004A 23CA7929
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000188884: BF870092
	v_exp_f32_e32 v46, v46                                     // 000000188888: 7E5C4B2E
	v_fmac_f32_e32 v60, v74, v60                               // 00000018888C: 5678794A
	v_div_scale_f32 v74, s0, v34, v44, v34                     // 000000188890: D6FC004A 048A5922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000188898: BF870291
	v_mul_f32_e32 v77, v74, v60                                // 00000018889C: 109A794A
	.long 0xd71c002e                                           // 0000001888A0: D71C002E
	v_cndmask_b32_e32 v1, v46, v62, vcc_lo                     // 0000001888A4: 02027D2E
	v_exp_f32_e32 v62, v73                                     // 0000001888A8: 7E7C4B49
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001888AC: BF870112
	v_fma_f32 v57, -v41, v77, v74                              // 0000001888B0: D6130039 252A9B29
	v_cndmask_b32_e64 v46, 0, v46, s1                          // 0000001888B8: D501002E 00065C80
	.long 0xd41b0001                                           // 0000001888C0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v54, vcc_lo              // 0000001888C4: 02026CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001888CC: BF8701A3
	v_fmac_f32_e32 v77, v57, v60                               // 0000001888D0: 569A7939
	v_cvt_i32_f32_e32 v57, v76                                 // 0000001888D4: 7E72114C
	v_cndmask_b32_e64 v46, 0x7f800000, v46, s1                 // 0000001888D8: D501002E 00065CFF 7F800000
	.long 0xd41e0001                                           // 0000001888E4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v45, vcc_lo              // 0000001888E8: 02025AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001888F0: BF870004
	v_fma_f32 v41, -v41, v77, v74                              // 0000001888F4: D6130029 252A9B29
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 0000001888FC: BF870205
	.long 0xd71c0036                                           // 000000188900: D71C0036
	v_cndmask_b32_e32 v1, v62, v57, vcc_lo                     // 000000188904: 0202733E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000188908: BF870124
	v_dual_add_f32 v53, 1.0, v53 :: v_dual_add_f32 v46, 1.0, v46// 00000018890C: C9086AF2 352E5CF2
	v_lshlrev_b32_e32 v62, 16, v134                            // 000000188914: 307D0C90
	v_div_scale_f32 v59, null, v53, v53, v33                   // 000000188918: D6FC7C3B 04866B35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000188920: BF870113
	v_div_scale_f32 v57, null, v46, v46, v35                   // 000000188924: D6FC7C39 048E5D2E
	v_rcp_f32_e32 v43, v59                                     // 00000018892C: 7E56553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000188930: BF870095
	v_fma_f32 v58, -v59, v43, 1.0                              // 000000188934: D613003A 23CA573B
	v_fmac_f32_e32 v43, v58, v43                               // 00000018893C: 5656573A
	v_div_scale_f32 v58, vcc_lo, v33, v53, v33                 // 000000188940: D6FC6A3A 04866B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000188948: BF870091
	v_mul_f32_e32 v61, v58, v43                                // 00000018894C: 107A573A
	v_fma_f32 v71, -v59, v61, v58                              // 000000188950: D6130047 24EA7B3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000188958: BF870121
	v_fmac_f32_e32 v61, v71, v43                               // 00000018895C: 567A5747
	v_mul_f32_e32 v71, 0xbfb8aa3b, v62                         // 000000188960: 108E7CFF BFB8AA3B
	v_fma_f32 v58, -v59, v61, v58                              // 000000188968: D613003A 24EA7B3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000188970: BF8701A2
	v_fma_f32 v73, 0xbfb8aa3b, v62, -v71                       // 000000188974: D6130049 851E7CFF BFB8AA3B
	v_rndne_f32_e32 v74, v71                                   // 000000188980: 7E944747
	v_div_fmas_f32 v43, v58, v43, v61                          // 000000188984: D637002B 04F6573A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000018898C: 7C3C90FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000188994: BF870214
	v_fmac_f32_e32 v73, 0xb2a5705f, v62                        // 000000188998: 56927CFF B2A5705F
	v_sub_f32_e32 v71, v71, v74                                // 0000001889A0: 088E9547
	v_cndmask_b32_e32 v54, 0, v54, vcc_lo                      // 0000001889A4: 026C6C80
	s_mov_b32 vcc_lo, s0                                       // 0000001889A8: BEEA0000
	v_div_fixup_f32 v33, v43, v53, v33                         // 0000001889AC: D6270021 04866B2B
	v_div_fmas_f32 v41, v41, v60, v77                          // 0000001889B4: D6370029 05367929
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000001889BC: 7C3690FF C2B17218
	v_mul_f32_e32 v43, 0xbfb8aa3b, v45                         // 0000001889C4: 10565AFF BFB8AA3B
	.long 0x7f6a3980                                           // 0000001889CC: 7F6A3980
	.long 0x7e6a39a1                                           // 0000001889D0: 7E6A39A1
	v_div_fixup_f32 v34, v41, v44, v34                         // 0000001889D4: D6270022 048A5929
	v_cndmask_b32_e32 v54, 0x7f800000, v54, vcc_lo             // 0000001889DC: 026C6CFF 7F800000
	v_rcp_f32_e32 v41, v57                                     // 0000001889E4: 7E525539
	v_fma_f32 v59, 0xbfb8aa3b, v45, -v43                       // 0000001889E8: D613003B 84AE5AFF BFB8AA3B
	v_rndne_f32_e32 v60, v43                                   // 0000001889F4: 7E78472B
	.long 0x7e0039a2                                           // 0000001889F8: 7E0039A2
	v_dual_add_f32 v44, 1.0, v54 :: v_dual_and_b32 v53, 1, v53 // 0000001889FC: C9246CF2 2C346A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000188A04: BF870214
	v_fmac_f32_e32 v59, 0xb2a5705f, v45                        // 000000188A08: 56765AFF B2A5705F
	v_sub_f32_e32 v43, v43, v60                                // 000000188A10: 0856792B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000188A14: BF870214
	v_and_b32_e32 v61, 1, v0                                   // 000000188A18: 367A0081
	v_div_scale_f32 v42, null, v44, v44, v36                   // 000000188A1C: D6FC7C2A 0492592C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000188A24: BF870005
	v_fma_f32 v54, -v57, v41, 1.0                              // 000000188A28: D6130036 23CA5339
	v_cvt_i32_f32_e32 v60, v60                                 // 000000188A30: 7E78113C
	v_add_f32_e32 v43, v43, v59                                // 000000188A34: 0656772B
	v_add3_u32 v34, v34, v61, 0x7fff                           // 000000188A38: D6550022 03FE7B22 00007FFF
	v_rcp_f32_e32 v58, v42                                     // 000000188A44: 7E74552A
	v_fmac_f32_e32 v41, v54, v41                               // 000000188A48: 56525336
	v_div_scale_f32 v54, vcc_lo, v35, v46, v35                 // 000000188A4C: D6FC6A36 048E5D23
	v_exp_f32_e32 v43, v43                                     // 000000188A54: 7E564B2B
	v_add_f32_e32 v71, v71, v73                                // 000000188A58: 068E9347
	v_add3_u32 v33, v33, v53, 0x7fff                           // 000000188A5C: D6550021 03FE6B21 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000188A68: BF870313
	v_mul_f32_e32 v59, v54, v41                                // 000000188A6C: 10765336
	v_fma_f32 v72, -v42, v58, 1.0                              // 000000188A70: D6130048 23CA752A
	global_store_d16_hi_b16 v[7:8], v33, off offset:96         // 000000188A78: DC960060 007C2107
	v_fma_f32 v61, -v57, v59, v54                              // 000000188A80: D613003D 24DA7739
	.long 0xd71c002b                                           // 000000188A88: D71C002B
	v_cndmask_b32_e32 v1, v43, v60, vcc_lo                     // 000000188A8C: 0202792B
	v_exp_f32_e32 v60, v71                                     // 000000188A90: 7E784B47
	v_fmac_f32_e32 v58, v72, v58                               // 000000188A94: 56747548
	v_div_scale_f32 v72, s0, v36, v44, v36                     // 000000188A98: D6FC0048 04925924
	v_fmac_f32_e32 v59, v61, v41                               // 000000188AA0: 5676533D
	v_cndmask_b32_e64 v43, 0, v43, s1                          // 000000188AA4: D501002B 00065680
	.long 0xd41b0001                                           // 000000188AAC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v45, vcc_lo              // 000000188AB0: 02025AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v34, off offset:96       // 000000188AB8: DC960060 007C222F
	v_mul_f32_e32 v75, v72, v58                                // 000000188AC0: 10967548
	v_fma_f32 v54, -v57, v59, v54                              // 000000188AC4: D6130036 24DA7739
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 000000188ACC: D501002B 000656FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000188AD8: BF870193
	v_fma_f32 v53, -v42, v75, v72                              // 000000188ADC: D6130035 2522972A
	v_div_fmas_f32 v41, v54, v41, v59                          // 000000188AE4: D6370029 04EE5336
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v62                  // 000000188AEC: 7C3C7CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000188AF4: BF870214
	v_add_f32_e32 v43, 1.0, v43                                // 000000188AF8: 065656F2
	v_fmac_f32_e32 v75, v53, v58                               // 000000188AFC: 56967535
	v_cvt_i32_f32_e32 v53, v74                                 // 000000188B00: 7E6A114A
	v_div_fixup_f32 v35, v41, v46, v35                         // 000000188B04: D6270023 048E5D29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000188B0C: BF870193
	v_fma_f32 v42, -v42, v75, v72                              // 000000188B10: D613002A 2522972A
	.long 0xd71c002d                                           // 000000188B18: D71C002D
	v_cndmask_b32_e32 v1, v60, v53, vcc_lo                     // 000000188B1C: 02026B3C
	v_div_scale_f32 v53, null, v43, v43, v37                   // 000000188B20: D6FC7C35 0496572B
	s_waitcnt vmcnt(4)                                         // 000000188B28: BF8913F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000188B2C: BF8700A2
	v_dual_cndmask_b32 v45, 0, v45 :: v_dual_lshlrev_b32 v60, 16, v136// 000000188B30: CA625A80 2D3D1090
	s_mov_b32 vcc_lo, s0                                       // 000000188B38: BEEA0000
	v_mul_f32_e32 v61, 0xbfb8aa3b, v60                         // 000000188B3C: 107A78FF BFB8AA3B
	v_div_fmas_f32 v42, v42, v58, v75                          // 000000188B44: D637002A 052E752A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v62                  // 000000188B4C: 7C367CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000188B54: BF870193
	v_fma_f32 v71, 0xbfb8aa3b, v60, -v61                       // 000000188B58: D6130047 84F678FF BFB8AA3B
	v_div_fixup_f32 v33, v42, v44, v36                         // 000000188B64: D6270021 0492592A
	v_dual_cndmask_b32 v45, 0x7f800000, v45 :: v_dual_mul_f32 v36, v38, v51// 000000188B6C: CA465AFF 2D246726 7F800000
	v_lshlrev_b32_e32 v44, 16, v86                             // 000000188B78: 3058AC90
	v_rcp_f32_e32 v38, v53                                     // 000000188B7C: 7E4C5535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000188B80: BF870193
	.long 0x7e0039a1                                           // 000000188B84: 7E0039A1
	v_add_f32_e32 v42, 1.0, v45                                // 000000188B88: 06545AF2
	v_rndne_f32_e32 v72, v61                                   // 000000188B8C: 7E90473D
	v_mul_f32_e32 v41, 0xbfb8aa3b, v44                         // 000000188B90: 105258FF BFB8AA3B
	.long 0x7e5a39a3                                           // 000000188B98: 7E5A39A3
	.long 0x7f5a3980                                           // 000000188B9C: 7F5A3980
	v_div_scale_f32 v34, null, v42, v42, v36                   // 000000188BA0: D6FC7C22 0492552A
	v_and_b32_e32 v59, 1, v0                                   // 000000188BA8: 36760081
	v_fma_f32 v57, 0xbfb8aa3b, v44, -v41                       // 000000188BAC: D6130039 84A658FF BFB8AA3B
	v_rndne_f32_e32 v58, v41                                   // 000000188BB8: 7E744729
	v_fma_f32 v46, -v53, v38, 1.0                              // 000000188BBC: D613002E 23CA4D35
	v_rcp_f32_e32 v54, v34                                     // 000000188BC4: 7E6C5522
	v_fmac_f32_e32 v71, 0xb2a5705f, v60                        // 000000188BC8: 568E78FF B2A5705F
	v_fmac_f32_e32 v57, 0xb2a5705f, v44                        // 000000188BD0: 567258FF B2A5705F
	v_sub_f32_e32 v41, v41, v58                                // 000000188BD8: 08527529
	v_fmac_f32_e32 v38, v46, v38                               // 000000188BDC: 564C4D2E
	v_div_scale_f32 v46, vcc_lo, v37, v43, v37                 // 000000188BE0: D6FC6A2E 04965725
	v_sub_f32_e32 v61, v61, v72                                // 000000188BE8: 087A913D
	v_and_b32_e32 v45, 1, v45                                  // 000000188BEC: 365A5A81
	v_add_f32_e32 v41, v41, v57                                // 000000188BF0: 06527329
	v_add3_u32 v33, v33, v59, 0x7fff                           // 000000188BF4: D6550021 03FE7721 00007FFF
	v_fma_f32 v62, -v34, v54, 1.0                              // 000000188C00: D613003E 23CA6D22
	v_mul_f32_e32 v57, v46, v38                                // 000000188C08: 10724D2E
	v_cvt_i32_f32_e32 v58, v58                                 // 000000188C0C: 7E74113A
	v_exp_f32_e32 v41, v41                                     // 000000188C10: 7E524B29
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 000000188C14: BF870253
	v_dual_add_f32 v61, v61, v71 :: v_dual_fmac_f32 v54, v62, v54// 000000188C18: C9008F3D 3D366D3E
	v_div_scale_f32 v62, s0, v36, v42, v36                     // 000000188C20: D6FC003E 04925524
	v_fma_f32 v59, -v53, v57, v46                              // 000000188C28: D613003B 24BA7335
	v_add3_u32 v35, v35, v45, 0x7fff                           // 000000188C30: D6550023 03FE5B23 00007FFF
	.long 0xd41e0001                                           // 000000188C3C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v44, vcc_lo              // 000000188C40: 020258FF 42CE8ED0
	v_mul_f32_e32 v73, v62, v54                                // 000000188C48: 10926D3E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000188C4C: BF870294
	v_fmac_f32_e32 v57, v59, v38                               // 000000188C50: 56724D3B
	.long 0xd71c0029                                           // 000000188C54: D71C0029
	v_cndmask_b32_e32 v1, v41, v58, vcc_lo                     // 000000188C58: 02027529
	v_exp_f32_e32 v58, v61                                     // 000000188C5C: 7E744B3D
	global_store_d16_hi_b16 v[15:16], v35, off offset:96       // 000000188C60: DC960060 007C230F
	v_fma_f32 v45, -v34, v73, v62                              // 000000188C68: D613002D 24FA9322
	v_fma_f32 v46, -v53, v57, v46                              // 000000188C70: D613002E 24BA7335
	v_cndmask_b32_e64 v41, 0, v41, s1                          // 000000188C78: D5010029 00065280
	.long 0xd41b0001                                           // 000000188C80: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v44, vcc_lo              // 000000188C84: 020258FF C2B17218
	global_store_d16_hi_b16 v[23:24], v33, off offset:96       // 000000188C8C: DC960060 007C2117
	v_fmac_f32_e32 v73, v45, v54                               // 000000188C94: 56926D2D
	v_cvt_i32_f32_e32 v45, v72                                 // 000000188C98: 7E5A1148
	v_div_fmas_f32 v38, v46, v38, v57                          // 000000188C9C: D6370026 04E64D2E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v60                  // 000000188CA4: 7C3C78FF 42CE8ED0
	v_cndmask_b32_e64 v41, 0x7f800000, v41, s1                 // 000000188CAC: D5010029 000652FF 7F800000
	v_fma_f32 v34, -v34, v73, v62                              // 000000188CB8: D6130022 24FA9322
	.long 0xd71c002c                                           // 000000188CC0: D71C002C
	v_cndmask_b32_e32 v1, v58, v45, vcc_lo                     // 000000188CC4: 02025B3A
	v_div_fixup_f32 v37, v38, v43, v37                         // 000000188CC8: D6270025 04965726
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000188CD0: BF870224
	v_dual_add_f32 v41, 1.0, v41 :: v_dual_lshlrev_b32 v58, 16, v127// 000000188CD4: C92252F2 293AFE90
	.long 0x7f563980                                           // 000000188CDC: 7F563980
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 000000188CE0: 02585880
	s_mov_b32 vcc_lo, s0                                       // 000000188CE4: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 000000188CE8: BF870003
	v_mul_f32_e32 v59, 0xbfb8aa3b, v58                         // 000000188CEC: 107674FF BFB8AA3B
	v_div_fmas_f32 v34, v34, v54, v73                          // 000000188CF4: D6370022 05266D22
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v60                  // 000000188CFC: 7C3678FF C2B17218
	v_div_scale_f32 v45, null, v41, v41, v25                   // 000000188D04: D6FC7C2D 04665329
	.long 0x7e5639a5                                           // 000000188D0C: 7E5639A5
	v_fma_f32 v61, 0xbfb8aa3b, v58, -v59                       // 000000188D10: D613003D 84EE74FF BFB8AA3B
	v_div_fixup_f32 v34, v34, v42, v36                         // 000000188D1C: D6270022 04925522
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo             // 000000188D24: 025858FF 7F800000
	v_lshlrev_b32_e32 v42, 16, v128                            // 000000188D2C: 30550090
	v_rcp_f32_e32 v35, v45                                     // 000000188D30: 7E46552D
	v_rndne_f32_e32 v62, v59                                   // 000000188D34: 7E7C473B
	.long 0x7e0039a2                                           // 000000188D38: 7E0039A2
	v_add_f32_e32 v36, 1.0, v44                                // 000000188D3C: 064858F2
	v_mul_f32_e32 v38, 0xbfb8aa3b, v42                         // 000000188D40: 104C54FF BFB8AA3B
	v_fmac_f32_e32 v61, 0xb2a5705f, v58                        // 000000188D48: 567A74FF B2A5705F
	v_sub_f32_e32 v59, v59, v62                                // 000000188D50: 08767D3B
	v_and_b32_e32 v57, 1, v0                                   // 000000188D54: 36720081
	v_div_scale_f32 v33, null, v36, v36, v26                   // 000000188D58: D6FC7C21 046A4924
	v_fma_f32 v53, 0xbfb8aa3b, v42, -v38                       // 000000188D60: D6130035 849A54FF BFB8AA3B
	v_rndne_f32_e32 v54, v38                                   // 000000188D6C: 7E6C4726
	v_fma_f32 v44, -v45, v35, 1.0                              // 000000188D70: D613002C 23CA472D
	v_and_b32_e32 v43, 1, v43                                  // 000000188D78: 36565681
	v_rcp_f32_e32 v46, v33                                     // 000000188D7C: 7E5C5521
	v_fmac_f32_e32 v53, 0xb2a5705f, v42                        // 000000188D80: 566A54FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000188D88: BF870243
	v_dual_sub_f32 v38, v38, v54 :: v_dual_fmac_f32 v35, v44, v35// 000000188D8C: C9406D26 2622472C
	v_div_scale_f32 v44, vcc_lo, v25, v41, v25                 // 000000188D94: D6FC6A2C 04665319
	v_add3_u32 v34, v34, v57, 0x7fff                           // 000000188D9C: D6550022 03FE7322 00007FFF
	v_cvt_i32_f32_e32 v54, v54                                 // 000000188DA8: 7E6C1136
	v_add_f32_e32 v38, v38, v53                                // 000000188DAC: 064C6B26
	v_add_f32_e32 v59, v59, v61                                // 000000188DB0: 06767B3B
	v_mul_f32_e32 v53, v44, v35                                // 000000188DB4: 106A472C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000188DB8: BF870005
	v_fma_f32 v60, -v33, v46, 1.0                              // 000000188DBC: D613003C 23CA5D21
	v_add3_u32 v37, v37, v43, 0x7fff                           // 000000188DC4: D6550025 03FE5725 00007FFF
	v_exp_f32_e32 v38, v38                                     // 000000188DD0: 7E4C4B26
	.long 0xd41e0001                                           // 000000188DD4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v42, vcc_lo              // 000000188DD8: 020254FF 42CE8ED0
	v_fma_f32 v57, -v45, v53, v44                              // 000000188DE0: D6130039 24B26B2D
	v_fmac_f32_e32 v46, v60, v46                               // 000000188DE8: 565C5D3C
	v_div_scale_f32 v60, s0, v26, v36, v26                     // 000000188DEC: D6FC003C 046A491A
	global_store_d16_hi_b16 v[31:32], v37, off offset:96       // 000000188DF4: DC960060 007C251F
	v_lshlrev_b32_e32 v37, 16, v130                            // 000000188DFC: 304B0490
	v_fmac_f32_e32 v53, v57, v35                               // 000000188E00: 566A4739
	global_store_d16_hi_b16 v[39:40], v34, off offset:96       // 000000188E04: DC960060 007C2227
	v_mul_f32_e32 v71, v60, v46                                // 000000188E0C: 108E5D3C
	.long 0xd71c0026                                           // 000000188E10: D71C0026
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 000000188E14: 02026D26
	v_exp_f32_e32 v54, v59                                     // 000000188E18: 7E6C4B3B
	v_fma_f32 v44, -v45, v53, v44                              // 000000188E1C: D613002C 24B26B2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000188E24: BF870193
	v_fma_f32 v43, -v33, v71, v60                              // 000000188E28: D613002B 24F28F21
	v_cndmask_b32_e64 v38, 0, v38, s1                          // 000000188E30: D5010026 00064C80
	.long 0xd41b0001                                           // 000000188E38: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v42, vcc_lo              // 000000188E3C: 020254FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 000000188E44: BF870004
	v_div_fmas_f32 v35, v44, v35, v53                          // 000000188E48: D6370023 04D6472C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v58                  // 000000188E50: 7C3C74FF 42CE8ED0
	v_fmac_f32_e32 v71, v43, v46                               // 000000188E58: 568E5D2B
	v_cvt_i32_f32_e32 v43, v62                                 // 000000188E5C: 7E56113E
	v_cndmask_b32_e64 v38, 0x7f800000, v38, s1                 // 000000188E60: D5010026 00064CFF 7F800000
	v_div_fixup_f32 v25, v35, v41, v25                         // 000000188E6C: D6270019 04665323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v37                         // 000000188E74: 10464AFF BFB8AA3B
	v_fma_f32 v33, -v33, v71, v60                              // 000000188E7C: D6130021 24F28F21
	.long 0xd71c002a                                           // 000000188E84: D71C002A
	v_cndmask_b32_e32 v1, v54, v43, vcc_lo                     // 000000188E88: 02025736
	v_add_f32_e32 v38, 1.0, v38                                // 000000188E8C: 064C4CF2
	v_lshlrev_b32_e32 v54, 16, v129                            // 000000188E90: 306D0290
	v_fma_f32 v45, 0xbfb8aa3b, v37, -v35                       // 000000188E94: D613002D 848E4AFF BFB8AA3B
	.long 0x7e523999                                           // 000000188EA0: 7E523999
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 000000188EA4: 02545480
	s_mov_b32 vcc_lo, s0                                       // 000000188EA8: BEEA0000
	v_div_scale_f32 v43, null, v38, v38, v27                   // 000000188EAC: D6FC7C2B 046E4D26
	v_div_fmas_f32 v33, v33, v46, v71                          // 000000188EB4: D6370021 051E5D21
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v58                  // 000000188EBC: 7C3674FF C2B17218
	v_rndne_f32_e32 v46, v35                                   // 000000188EC4: 7E5C4723
	v_fmac_f32_e32 v45, 0xb2a5705f, v37                        // 000000188EC8: 565A4AFF B2A5705F
	v_mul_f32_e32 v57, 0xbfb8aa3b, v54                         // 000000188ED0: 10726CFF BFB8AA3B
	v_div_fixup_f32 v26, v33, v36, v26                         // 000000188ED8: D627001A 046A4921
	v_cndmask_b32_e32 v42, 0x7f800000, v42, vcc_lo             // 000000188EE0: 025454FF 7F800000
	v_rcp_f32_e32 v33, v43                                     // 000000188EE8: 7E42552B
	v_sub_f32_e32 v35, v35, v46                                // 000000188EEC: 08465D23
	v_fma_f32 v59, 0xbfb8aa3b, v54, -v57                       // 000000188EF0: D613003B 84E66CFF BFB8AA3B
	.long 0x7e00399a                                           // 000000188EFC: 7E00399A
	v_add_f32_e32 v36, 1.0, v42                                // 000000188F00: 064854F2
	v_rndne_f32_e32 v60, v57                                   // 000000188F04: 7E784739
	v_add_f32_e32 v35, v35, v45                                // 000000188F08: 06465B23
	.long 0x7f523980                                           // 000000188F0C: 7F523980
	v_and_b32_e32 v53, 1, v0                                   // 000000188F10: 366A0081
	v_div_scale_f32 v34, null, v36, v36, v28                   // 000000188F14: D6FC7C22 04724924
	v_fma_f32 v42, -v43, v33, 1.0                              // 000000188F1C: D613002A 23CA432B
	v_exp_f32_e32 v35, v35                                     // 000000188F24: 7E464B23
	v_fmac_f32_e32 v59, 0xb2a5705f, v54                        // 000000188F28: 56766CFF B2A5705F
	v_sub_f32_e32 v57, v57, v60                                // 000000188F30: 08727939
	v_rcp_f32_e32 v44, v34                                     // 000000188F34: 7E585522
	v_fmac_f32_e32 v33, v42, v33                               // 000000188F38: 5642432A
	v_div_scale_f32 v42, vcc_lo, v27, v38, v27                 // 000000188F3C: D6FC6A2A 046E4D1B
	v_and_b32_e32 v41, 1, v41                                  // 000000188F44: 36525281
	v_add3_u32 v26, v26, v53, 0x7fff                           // 000000188F48: D655001A 03FE6B1A 00007FFF
	v_cvt_i32_f32_e32 v46, v46                                 // 000000188F54: 7E5C112E
	v_add_f32_e32 v57, v57, v59                                // 000000188F58: 06727739
	v_mul_f32_e32 v45, v42, v33                                // 000000188F5C: 105A432A
	v_add3_u32 v25, v25, v41, 0x7fff                           // 000000188F60: D6550019 03FE5319 00007FFF
	.long 0xd41e0001                                           // 000000188F6C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v37, vcc_lo              // 000000188F70: 02024AFF 42CE8ED0
	v_fma_f32 v58, -v34, v44, 1.0                              // 000000188F78: D613003A 23CA5922
	.long 0xd71c0023                                           // 000000188F80: D71C0023
	v_cndmask_b32_e32 v1, v35, v46, vcc_lo                     // 000000188F84: 02025D23
	v_fma_f32 v53, -v43, v45, v42                              // 000000188F88: D6130035 24AA5B2B
	v_exp_f32_e32 v46, v57                                     // 000000188F90: 7E5C4B39
	global_store_d16_hi_b16 v[7:8], v25, off offset:128        // 000000188F94: DC960080 007C1907
	v_fmac_f32_e32 v44, v58, v44                               // 000000188F9C: 5658593A
	v_div_scale_f32 v58, s0, v28, v36, v28                     // 000000188FA0: D6FC003A 0472491C
	v_fmac_f32_e32 v45, v53, v33                               // 000000188FA8: 565A4335
	v_cndmask_b32_e64 v35, 0, v35, s1                          // 000000188FAC: D5010023 00064680
	.long 0xd41b0001                                           // 000000188FB4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v37, vcc_lo              // 000000188FB8: 02024AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v26, off offset:128      // 000000188FC0: DC960080 007C1A2F
	v_mul_f32_e32 v61, v58, v44                                // 000000188FC8: 107A593A
	v_fma_f32 v42, -v43, v45, v42                              // 000000188FCC: D613002A 24AA5B2B
	v_cndmask_b32_e64 v35, 0x7f800000, v35, s1                 // 000000188FD4: D5010023 000646FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000188FE0: BF870193
	v_fma_f32 v41, -v34, v61, v58                              // 000000188FE4: D6130029 24EA7B22
	v_div_fmas_f32 v33, v42, v33, v45                          // 000000188FEC: D6370021 04B6432A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v54                  // 000000188FF4: 7C3C6CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000188FFC: BF870214
	v_add_f32_e32 v35, 1.0, v35                                // 000000189000: 064646F2
	v_fmac_f32_e32 v61, v41, v44                               // 000000189004: 567A5929
	v_cvt_i32_f32_e32 v41, v60                                 // 000000189008: 7E52113C
	v_div_fixup_f32 v27, v33, v38, v27                         // 00000018900C: D627001B 046E4D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000189014: BF870193
	v_fma_f32 v34, -v34, v61, v58                              // 000000189018: D6130022 24EA7B22
	.long 0xd71c0025                                           // 000000189020: D71C0025
	v_cndmask_b32_e32 v1, v46, v41, vcc_lo                     // 000000189024: 0202532E
	v_div_scale_f32 v41, null, v35, v35, v29                   // 000000189028: D6FC7C29 04764723
	s_waitcnt vmcnt(3)                                         // 000000189030: BF890FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000189034: BF8700A2
	v_dual_cndmask_b32 v37, 0, v37 :: v_dual_lshlrev_b32 v46, 16, v131// 000000189038: CA624A80 252F0690
	s_mov_b32 vcc_lo, s0                                       // 000000189040: BEEA0000
	v_mul_f32_e32 v53, 0xbfb8aa3b, v46                         // 000000189044: 106A5CFF BFB8AA3B
	v_div_fmas_f32 v34, v34, v44, v61                          // 00000018904C: D6370022 04F65922
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v54                  // 000000189054: 7C366CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000018905C: BF870193
	v_fma_f32 v57, 0xbfb8aa3b, v46, -v53                       // 000000189060: D6130039 84D65CFF BFB8AA3B
	v_div_fixup_f32 v25, v34, v36, v28                         // 00000018906C: D6270019 04724922
	v_dual_cndmask_b32 v37, 0x7f800000, v37 :: v_dual_mul_f32 v28, v30, v51// 000000189074: CA464AFF 251C671E 7F800000
	v_lshlrev_b32_e32 v36, 16, v87                             // 000000189080: 3048AE90
	v_rcp_f32_e32 v30, v41                                     // 000000189084: 7E3C5529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000189088: BF870193
	.long 0x7e003999                                           // 00000018908C: 7E003999
	v_add_f32_e32 v34, 1.0, v37                                // 000000189090: 06444AF2
	v_rndne_f32_e32 v58, v53                                   // 000000189094: 7E744735
	v_mul_f32_e32 v33, 0xbfb8aa3b, v36                         // 000000189098: 104248FF BFB8AA3B
	.long 0x7e4a399b                                           // 0000001890A0: 7E4A399B
	.long 0x7f4a3980                                           // 0000001890A4: 7F4A3980
	v_div_scale_f32 v26, null, v34, v34, v28                   // 0000001890A8: D6FC7C1A 04724522
	v_and_b32_e32 v45, 1, v0                                   // 0000001890B0: 365A0081
	v_fma_f32 v43, 0xbfb8aa3b, v36, -v33                       // 0000001890B4: D613002B 848648FF BFB8AA3B
	v_rndne_f32_e32 v44, v33                                   // 0000001890C0: 7E584721
	v_fma_f32 v38, -v41, v30, 1.0                              // 0000001890C4: D6130026 23CA3D29
	v_rcp_f32_e32 v42, v26                                     // 0000001890CC: 7E54551A
	v_fmac_f32_e32 v57, 0xb2a5705f, v46                        // 0000001890D0: 56725CFF B2A5705F
	v_fmac_f32_e32 v43, 0xb2a5705f, v36                        // 0000001890D8: 565648FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001890E0: BF870243
	v_dual_sub_f32 v33, v33, v44 :: v_dual_fmac_f32 v30, v38, v30// 0000001890E4: C9405921 211E3D26
	v_div_scale_f32 v38, vcc_lo, v29, v35, v29                 // 0000001890EC: D6FC6A26 0476471D
	v_sub_f32_e32 v53, v53, v58                                // 0000001890F4: 086A7535
	v_and_b32_e32 v37, 1, v37                                  // 0000001890F8: 364A4A81
	v_add_f32_e32 v33, v33, v43                                // 0000001890FC: 06425721
	v_add3_u32 v25, v25, v45, 0x7fff                           // 000000189100: D6550019 03FE5B19 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000018910C: BF8701C5
	v_fma_f32 v54, -v26, v42, 1.0                              // 000000189110: D6130036 23CA551A
	v_mul_f32_e32 v43, v38, v30                                // 000000189118: 10563D26
	v_cvt_i32_f32_e32 v44, v44                                 // 00000018911C: 7E58112C
	v_exp_f32_e32 v33, v33                                     // 000000189120: 7E424B21
	v_dual_add_f32 v53, v53, v57 :: v_dual_fmac_f32 v42, v54, v42// 000000189124: C9007335 352A5536
	v_div_scale_f32 v54, s0, v28, v34, v28                     // 00000018912C: D6FC0036 0472451C
	v_fma_f32 v45, -v41, v43, v38                              // 000000189134: D613002D 249A5729
	v_add3_u32 v27, v27, v37, 0x7fff                           // 00000018913C: D655001B 03FE4B1B 00007FFF
	.long 0xd41e0001                                           // 000000189148: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v36, vcc_lo              // 00000018914C: 020248FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000189154: BF870214
	v_mul_f32_e32 v59, v54, v42                                // 000000189158: 10765536
	v_fmac_f32_e32 v43, v45, v30                               // 00000018915C: 56563D2D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000189160: BF870005
	.long 0xd71c0021                                           // 000000189164: D71C0021
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 000000189168: 02025921
	v_exp_f32_e32 v44, v53                                     // 00000018916C: 7E584B35
	global_store_d16_hi_b16 v[15:16], v27, off offset:128      // 000000189170: DC960080 007C1B0F
	v_fma_f32 v37, -v26, v59, v54                              // 000000189178: D6130025 24DA771A
	v_fma_f32 v38, -v41, v43, v38                              // 000000189180: D6130026 249A5729
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 000000189188: D5010021 00064280
	.long 0xd41b0001                                           // 000000189190: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v36, vcc_lo              // 000000189194: 020248FF C2B17218
	global_store_d16_hi_b16 v[23:24], v25, off offset:128      // 00000018919C: DC960080 007C1917
	v_fmac_f32_e32 v59, v37, v42                               // 0000001891A4: 56765525
	v_cvt_i32_f32_e32 v37, v58                                 // 0000001891A8: 7E4A113A
	v_div_fmas_f32 v30, v38, v30, v43                          // 0000001891AC: D637001E 04AE3D26
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 0000001891B4: 7C3C5CFF 42CE8ED0
	v_cndmask_b32_e64 v33, 0x7f800000, v33, s1                 // 0000001891BC: D5010021 000642FF 7F800000
	v_fma_f32 v26, -v26, v59, v54                              // 0000001891C8: D613001A 24DA771A
	.long 0xd71c0024                                           // 0000001891D0: D71C0024
	v_cndmask_b32_e32 v1, v44, v37, vcc_lo                     // 0000001891D4: 02024B2C
	v_div_fixup_f32 v29, v30, v35, v29                         // 0000001891D8: D627001D 0476471E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001891E0: BF870224
	v_dual_add_f32 v33, 1.0, v33 :: v_dual_lshlrev_b32 v44, 16, v123// 0000001891E4: C92242F2 212CF690
	.long 0x7f463980                                           // 0000001891EC: 7F463980
	v_cndmask_b32_e32 v36, 0, v36, vcc_lo                      // 0000001891F0: 02484880
	s_mov_b32 vcc_lo, s0                                       // 0000001891F4: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001891F8: BF870003
	v_mul_f32_e32 v45, 0xbfb8aa3b, v44                         // 0000001891FC: 105A58FF BFB8AA3B
	v_div_fmas_f32 v26, v26, v42, v59                          // 000000189204: D637001A 04EE551A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 00000018920C: 7C365CFF C2B17218
	v_div_scale_f32 v37, null, v33, v33, v17                   // 000000189214: D6FC7C25 04464321
	.long 0x7e46399d                                           // 00000018921C: 7E46399D
	v_fma_f32 v53, 0xbfb8aa3b, v44, -v45                       // 000000189220: D6130035 84B658FF BFB8AA3B
	v_div_fixup_f32 v26, v26, v34, v28                         // 00000018922C: D627001A 0472451A
	v_cndmask_b32_e32 v36, 0x7f800000, v36, vcc_lo             // 000000189234: 024848FF 7F800000
	v_lshlrev_b32_e32 v34, 16, v124                            // 00000018923C: 3044F890
	v_rcp_f32_e32 v27, v37                                     // 000000189240: 7E365525
	v_rndne_f32_e32 v54, v45                                   // 000000189244: 7E6C472D
	.long 0x7e00399a                                           // 000000189248: 7E00399A
	v_add_f32_e32 v28, 1.0, v36                                // 00000018924C: 063848F2
	v_mul_f32_e32 v30, 0xbfb8aa3b, v34                         // 000000189250: 103C44FF BFB8AA3B
	v_fmac_f32_e32 v53, 0xb2a5705f, v44                        // 000000189258: 566A58FF B2A5705F
	v_sub_f32_e32 v45, v45, v54                                // 000000189260: 085A6D2D
	v_and_b32_e32 v43, 1, v0                                   // 000000189264: 36560081
	v_div_scale_f32 v25, null, v28, v28, v18                   // 000000189268: D6FC7C19 044A391C
	v_fma_f32 v41, 0xbfb8aa3b, v34, -v30                       // 000000189270: D6130029 847A44FF BFB8AA3B
	v_rndne_f32_e32 v42, v30                                   // 00000018927C: 7E54471E
	v_fma_f32 v36, -v37, v27, 1.0                              // 000000189280: D6130024 23CA3725
	v_and_b32_e32 v35, 1, v35                                  // 000000189288: 36464681
	v_rcp_f32_e32 v38, v25                                     // 00000018928C: 7E4C5519
	v_fmac_f32_e32 v41, 0xb2a5705f, v34                        // 000000189290: 565244FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000189298: BF870243
	v_dual_sub_f32 v30, v30, v42 :: v_dual_fmac_f32 v27, v36, v27// 00000018929C: C940551E 1E1A3724
	v_div_scale_f32 v36, vcc_lo, v17, v33, v17                 // 0000001892A4: D6FC6A24 04464311
	v_add3_u32 v26, v26, v43, 0x7fff                           // 0000001892AC: D655001A 03FE571A 00007FFF
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001892B8: 7E54112A
	v_add_f32_e32 v30, v30, v41                                // 0000001892BC: 063C531E
	v_add_f32_e32 v45, v45, v53                                // 0000001892C0: 065A6B2D
	v_mul_f32_e32 v41, v36, v27                                // 0000001892C4: 10523724
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001892C8: BF870005
	v_fma_f32 v46, -v25, v38, 1.0                              // 0000001892CC: D613002E 23CA4D19
	v_add3_u32 v29, v29, v35, 0x7fff                           // 0000001892D4: D655001D 03FE471D 00007FFF
	v_exp_f32_e32 v30, v30                                     // 0000001892E0: 7E3C4B1E
	.long 0xd41e0001                                           // 0000001892E4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v34, vcc_lo              // 0000001892E8: 020244FF 42CE8ED0
	v_fma_f32 v43, -v37, v41, v36                              // 0000001892F0: D613002B 24925325
	v_fmac_f32_e32 v38, v46, v38                               // 0000001892F8: 564C4D2E
	v_div_scale_f32 v46, s0, v18, v28, v18                     // 0000001892FC: D6FC002E 044A3912
	s_clause 0x1                                               // 000000189304: BF850001
	global_store_d16_hi_b16 v[31:32], v29, off offset:128      // 000000189308: DC960080 007C1D1F
	global_store_d16_hi_b16 v[39:40], v26, off offset:128      // 000000189310: DC960080 007C1A27
	v_dual_fmac_f32 v41, v43, v27 :: v_dual_lshlrev_b32 v26, 16, v126// 000000189318: C822372B 291AFC90
	v_mul_f32_e32 v57, v46, v38                                // 000000189320: 10724D2E
	.long 0xd71c001e                                           // 000000189324: D71C001E
	v_cndmask_b32_e32 v1, v30, v42, vcc_lo                     // 000000189328: 0202551E
	v_exp_f32_e32 v42, v45                                     // 00000018932C: 7E544B2D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000189330: BF870003
	v_fma_f32 v36, -v37, v41, v36                              // 000000189334: D6130024 24925325
	.long 0x7f3a3980                                           // 00000018933C: 7F3A3980
	v_fma_f32 v35, -v25, v57, v46                              // 000000189340: D6130023 24BA7319
	v_cndmask_b32_e64 v30, 0, v30, s1                          // 000000189348: D501001E 00063C80
	.long 0xd41b0001                                           // 000000189350: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v34, vcc_lo              // 000000189354: 020244FF C2B17218
	v_div_fmas_f32 v27, v36, v27, v41                          // 00000018935C: D637001B 04A63724
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v44                  // 000000189364: 7C3C58FF 42CE8ED0
	v_fmac_f32_e32 v57, v35, v38                               // 00000018936C: 56724D23
	v_cvt_i32_f32_e32 v35, v54                                 // 000000189370: 7E461136
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 000000189374: D501001E 00063CFF 7F800000
	v_div_fixup_f32 v17, v27, v33, v17                         // 000000189380: D6270011 0446431B
	v_mul_f32_e32 v33, 0xbfb8aa3b, v26                         // 000000189388: 104234FF BFB8AA3B
	v_fma_f32 v25, -v25, v57, v46                              // 000000189390: D6130019 24BA7319
	.long 0xd71c0022                                           // 000000189398: D71C0022
	v_cndmask_b32_e32 v1, v42, v35, vcc_lo                     // 00000018939C: 0202472A
	v_add_f32_e32 v30, 1.0, v30                                // 0000001893A0: 063C3CF2
	.long 0xd41e0001                                           // 0000001893A4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v26, vcc_lo              // 0000001893A8: 020234FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v26, -v33                       // 0000001893B0: D6130029 848634FF BFB8AA3B
	v_rndne_f32_e32 v42, v33                                   // 0000001893BC: 7E544721
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000001893C0: 02444480
	s_mov_b32 vcc_lo, s0                                       // 0000001893C4: BEEA0000
	v_div_scale_f32 v35, null, v30, v30, v19                   // 0000001893C8: D6FC7C23 044E3D1E
	v_div_fmas_f32 v25, v25, v38, v57                          // 0000001893D0: D6370019 04E64D19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v44                  // 0000001893D8: 7C3658FF C2B17218
	v_dual_fmac_f32 v41, 0xb2a5705f, v26 :: v_dual_lshlrev_b32 v38, 16, v125// 0000001893E0: C82234FF 2926FA90 B2A5705F
	v_sub_f32_e32 v33, v33, v42                                // 0000001893EC: 08425521
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001893F0: BF870004
	v_div_fixup_f32 v18, v25, v28, v18                         // 0000001893F4: D6270012 044A3919
	v_cndmask_b32_e32 v34, 0x7f800000, v34, vcc_lo             // 0000001893FC: 024444FF 7F800000
	v_rcp_f32_e32 v25, v35                                     // 000000189404: 7E325523
	v_mul_f32_e32 v43, 0xbfb8aa3b, v38                         // 000000189408: 10564CFF BFB8AA3B
	v_add_f32_e32 v33, v33, v41                                // 000000189410: 06425321
	.long 0x7e003992                                           // 000000189414: 7E003992
	v_add_f32_e32 v28, 1.0, v34                                // 000000189418: 063844F2
	v_cvt_i32_f32_e32 v42, v42                                 // 00000018941C: 7E54112A
	v_fma_f32 v46, 0xbfb8aa3b, v38, -v43                       // 000000189420: D613002E 84AE4CFF BFB8AA3B
	v_rndne_f32_e32 v53, v43                                   // 00000018942C: 7E6A472B
	v_exp_f32_e32 v33, v33                                     // 000000189430: 7E424B21
	v_div_scale_f32 v27, null, v28, v28, v20                   // 000000189434: D6FC7C1B 0452391C
	v_fma_f32 v34, -v35, v25, 1.0                              // 00000018943C: D6130022 23CA3323
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000189444: BF870223
	v_dual_fmac_f32 v46, 0xb2a5705f, v38 :: v_dual_sub_f32 v43, v43, v53// 000000189448: C80A4CFF 2E2A6B2B B2A5705F
	v_div_scale_f32 v41, s0, v20, v28, v20                     // 000000189454: D6FC0029 04523914
	v_rcp_f32_e32 v36, v27                                     // 00000018945C: 7E48551B
	s_delay_alu instid0(VALU_DEP_3)                            // 000000189460: BF870003
	v_fmac_f32_e32 v25, v34, v25                               // 000000189464: 56323322
	v_div_scale_f32 v34, vcc_lo, v19, v30, v19                 // 000000189468: D6FC6A22 044E3D13
	v_and_b32_e32 v37, 1, v0                                   // 000000189470: 364A0081
	v_add_f32_e32 v43, v43, v46                                // 000000189474: 06565D2B
	.long 0xd71c0021                                           // 000000189478: D71C0021
	v_cndmask_b32_e32 v1, v33, v42, vcc_lo                     // 00000018947C: 02025521
	.long 0x7e3a3991                                           // 000000189480: 7E3A3991
	v_mul_f32_e32 v45, v34, v25                                // 000000189484: 105A3322
	v_add3_u32 v18, v18, v37, 0x7fff                           // 000000189488: D6550012 03FE4B12 00007FFF
	v_exp_f32_e32 v37, v43                                     // 000000189494: 7E4A4B2B
	v_fma_f32 v44, -v27, v36, 1.0                              // 000000189498: D613002C 23CA491B
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 0000001894A0: D5010021 00064280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001894A8: BF870122
	v_dual_fmac_f32 v36, v44, v36 :: v_dual_and_b32 v29, 1, v29// 0000001894AC: C824492C 241C3A81
	v_fma_f32 v44, -v35, v45, v34                              // 0000001894B4: D613002C 248A5B23
	v_add3_u32 v17, v17, v29, 0x7fff                           // 0000001894BC: D6550011 03FE3B11 00007FFF
	v_lshlrev_b32_e32 v29, 16, v92                             // 0000001894C8: 303AB890
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001894CC: BF870003
	v_dual_mul_f32 v54, v41, v36 :: v_dual_fmac_f32 v45, v44, v25// 0000001894D0: C8C04929 362C332C
	s_clause 0x1                                               // 0000001894D8: BF850001
	global_store_d16_hi_b16 v[7:8], v17, off offset:160        // 0000001894DC: DC9600A0 007C1107
	global_store_d16_hi_b16 v[47:48], v18, off offset:160      // 0000001894E4: DC9600A0 007C122F
	v_fma_f32 v44, -v27, v54, v41                              // 0000001894EC: D613002C 24A66D1B
	v_fma_f32 v34, -v35, v45, v34                              // 0000001894F4: D6130022 248A5B23
	v_cvt_i32_f32_e32 v35, v53                                 // 0000001894FC: 7E461135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000189500: BF870193
	v_fmac_f32_e32 v54, v44, v36                               // 000000189504: 566C492C
	v_div_fmas_f32 v25, v34, v25, v45                          // 000000189508: D6370019 04B63322
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v26                  // 000000189510: 7C3634FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 000000189518: BF870004
	.long 0xd71c0022                                           // 00000018951C: D71C0022
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 000000189520: 02024725
	v_mul_f32_e32 v35, 0xbfb8aa3b, v29                         // 000000189524: 10463AFF BFB8AA3B
	v_fma_f32 v27, -v27, v54, v41                              // 00000018952C: D613001B 24A66D1B
	v_div_fixup_f32 v17, v25, v30, v19                         // 000000189534: D6270011 044E3D19
	v_cndmask_b32_e32 v26, 0x7f800000, v33, vcc_lo             // 00000018953C: 023442FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 000000189544: 7C3C4CFF 42CE8ED0
	.long 0x7f3c3980                                           // 00000018954C: 7F3C3980
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000189550: BF870214
	.long 0x7e3c3991                                           // 000000189554: 7E3C3991
	v_add_f32_e32 v26, 1.0, v26                                // 000000189558: 063434F2
	v_cndmask_b32_e32 v33, 0, v34, vcc_lo                      // 00000018955C: 02424480
	s_mov_b32 vcc_lo, s0                                       // 000000189560: BEEA0000
	v_div_fmas_f32 v27, v27, v36, v54                          // 000000189564: D637001B 04DA491B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 00000018956C: 7C364CFF C2B17218
	v_rndne_f32_e32 v36, v35                                   // 000000189574: 7E484723
	s_waitcnt vmcnt(2)                                         // 000000189578: BF890BF7
	v_lshlrev_b32_e32 v38, 16, v68                             // 00000018957C: 304C8890
	v_and_b32_e32 v30, 1, v30                                  // 000000189580: 363C3C81
	v_div_fixup_f32 v20, v27, v28, v20                         // 000000189584: D6270014 0452391B
	v_cndmask_b32_e32 v33, 0x7f800000, v33, vcc_lo             // 00000018958C: 024242FF 7F800000
	v_div_scale_f32 v27, null, v26, v26, v21                   // 000000189594: D6FC7C1B 0456351A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000018959C: BF870214
	v_add3_u32 v17, v17, v30, 0x7fff                           // 0000001895A0: D6550011 03FE3D11 00007FFF
	.long 0x7e003994                                           // 0000001895AC: 7E003994
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001895B0: BF870214
	v_add_f32_e32 v28, 1.0, v33                                // 0000001895B4: 063842F2
	v_rcp_f32_e32 v19, v27                                     // 0000001895B8: 7E26551B
	global_store_d16_hi_b16 v[15:16], v17, off offset:160      // 0000001895BC: DC9600A0 007C110F
	v_and_b32_e32 v33, 1, v0                                   // 0000001895C4: 36420081
	v_div_scale_f32 v25, null, v28, v28, v22                   // 0000001895C8: D6FC7C19 045A391C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001895D0: BF870112
	v_add3_u32 v20, v20, v33, 0x7fff                           // 0000001895D4: D6550014 03FE4314 00007FFF
	v_rcp_f32_e32 v34, v25                                     // 0000001895E0: 7E445519
	v_fma_f32 v18, -v27, v19, 1.0                              // 0000001895E4: D6130012 23CA271B
	v_fma_f32 v33, 0xbfb8aa3b, v29, -v35                       // 0000001895EC: D6130021 848E3AFF BFB8AA3B
	v_sub_f32_e32 v35, v35, v36                                // 0000001895F8: 08464923
	v_cvt_i32_f32_e32 v36, v36                                 // 0000001895FC: 7E481124
	global_store_d16_hi_b16 v[23:24], v20, off offset:160      // 000000189600: DC9600A0 007C1417
	v_fmac_f32_e32 v19, v18, v19                               // 000000189608: 56262712
	v_div_scale_f32 v18, vcc_lo, v21, v26, v21                 // 00000018960C: D6FC6A12 04563515
	v_fmac_f32_e32 v33, 0xb2a5705f, v29                        // 000000189614: 56423AFF B2A5705F
	v_fma_f32 v37, -v25, v34, 1.0                              // 00000018961C: D6130025 23CA4519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000189624: BF870193
	v_mul_f32_e32 v41, v18, v19                                // 000000189628: 10522712
	v_add_f32_e32 v33, v35, v33                                // 00000018962C: 06424323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v38                         // 000000189630: 10464CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000189638: BF870004
	v_fmac_f32_e32 v34, v37, v34                               // 00000018963C: 56444525
	v_div_scale_f32 v37, s0, v22, v28, v22                     // 000000189640: D6FC0025 045A3916
	v_fma_f32 v30, -v27, v41, v18                              // 000000189648: D613001E 244A531B
	v_exp_f32_e32 v33, v33                                     // 000000189650: 7E424B21
	v_fma_f32 v43, 0xbfb8aa3b, v38, -v35                       // 000000189654: D613002B 848E4CFF BFB8AA3B
	v_rndne_f32_e32 v44, v35                                   // 000000189660: 7E584723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000189664: BF870193
	v_dual_mul_f32 v42, v37, v34 :: v_dual_fmac_f32 v41, v30, v19// 000000189668: C8C04525 2A28271E
	v_fmac_f32_e32 v43, 0xb2a5705f, v38                        // 000000189670: 56564CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000189678: BF870193
	v_sub_f32_e32 v35, v35, v44                                // 00000018967C: 08465923
	v_fma_f32 v30, -v25, v42, v37                              // 000000189680: D613001E 24965519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000189688: BF870294
	v_fma_f32 v17, -v27, v41, v18                              // 00000018968C: D6130011 244A531B
	.long 0xd71c0012                                           // 000000189694: D71C0012
	v_cndmask_b32_e32 v1, v33, v36, vcc_lo                     // 000000189698: 02024921
	v_cvt_i32_f32_e32 v20, v44                                 // 00000018969C: 7E28112C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001896A0: BF870214
	v_dual_add_f32 v27, v35, v43 :: v_dual_fmac_f32 v42, v30, v34// 0000001896A4: C9005723 1B2A451E
	v_div_fmas_f32 v17, v17, v19, v41                          // 0000001896AC: D6370011 04A62711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001896B4: 7C3C3AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001896BC: BF870213
	v_fma_f32 v19, -v25, v42, v37                              // 0000001896C0: D6130013 24965519
	v_exp_f32_e32 v25, v27                                     // 0000001896C8: 7E324B1B
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001896CC: 02242480
	s_mov_b32 vcc_lo, s0                                       // 0000001896D0: BEEA0000
	v_div_fixup_f32 v17, v17, v26, v21                         // 0000001896D4: D6270011 04563511
	v_div_fmas_f32 v19, v19, v34, v42                          // 0000001896DC: D6370013 04AA4513
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001896E4: 7C363AFF C2B17218
	.long 0x7f2a3980                                           // 0000001896EC: 7F2A3980
	v_lshlrev_b32_e32 v34, 16, v70                             // 0000001896F0: 30448C90
	.long 0x7e2a3991                                           // 0000001896F4: 7E2A3991
	v_div_fixup_f32 v19, v19, v28, v22                         // 0000001896F8: D6270013 045A3913
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 000000189700: 022424FF 7F800000
	.long 0xd71c0014                                           // 000000189708: D71C0014
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 00000018970C: 02022919
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 000000189710: 7C3C4CFF 42CE8ED0
	v_lshlrev_b32_e32 v25, 16, v104                            // 000000189718: 3032D090
	.long 0x7e003993                                           // 00000018971C: 7E003993
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_and_b32 v21, 1, v21 // 000000189720: C92424F2 12142A81
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 000000189728: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 00000018972C: 7C364CFF C2B17218
	v_mul_f32_e32 v27, 0xbfb8aa3b, v25                         // 000000189734: 103632FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000018973C: BF870234
	v_div_scale_f32 v22, null, v18, v18, v9                    // 000000189740: D6FC7C16 04262512
	v_dual_mul_f32 v37, 0xbfb8aa3b, v34 :: v_dual_and_b32 v28, 1, v0// 000000189748: C8E444FF 251C0081 BFB8AA3B
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 000000189754: 022828FF 7F800000
	v_fma_f32 v29, 0xbfb8aa3b, v25, -v27                       // 00000018975C: D613001D 846E32FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000189768: BF8701B4
	v_rcp_f32_e32 v26, v22                                     // 00000018976C: 7E345516
	v_rndne_f32_e32 v30, v27                                   // 000000189770: 7E3C471B
	v_add3_u32 v17, v17, v21, 0x7fff                           // 000000189774: D6550011 03FE2B11 00007FFF
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_fmac_f32 v29, 0xb2a5705f, v25// 000000189780: C90028F2 141C32FF B2A5705F
	v_add3_u32 v19, v19, v28, 0x7fff                           // 00000018978C: D6550013 03FE3913 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000189798: BF870224
	v_sub_f32_e32 v27, v27, v30                                // 00000018979C: 08363D1B
	v_rndne_f32_e32 v28, v37                                   // 0000001897A0: 7E384725
	v_div_scale_f32 v33, null, v20, v20, v10                   // 0000001897A4: D6FC7C21 042A2914
	v_cvt_i32_f32_e32 v30, v30                                 // 0000001897AC: 7E3C111E
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001897B0: BF870005
	v_fma_f32 v35, -v22, v26, 1.0                              // 0000001897B4: D6130023 23CA3516
	v_add_f32_e32 v21, v27, v29                                // 0000001897BC: 062A3B1B
	v_fma_f32 v27, 0xbfb8aa3b, v34, -v37                       // 0000001897C0: D613001B 849644FF BFB8AA3B
	v_rcp_f32_e32 v36, v33                                     // 0000001897CC: 7E485521
	v_div_scale_f32 v29, vcc_lo, v9, v18, v9                   // 0000001897D0: D6FC6A1D 04262509
	v_fmac_f32_e32 v26, v35, v26                               // 0000001897D8: 56343523
	v_exp_f32_e32 v21, v21                                     // 0000001897DC: 7E2A4B15
	v_fmac_f32_e32 v27, 0xb2a5705f, v34                        // 0000001897E0: 563644FF B2A5705F
	v_sub_f32_e32 v37, v37, v28                                // 0000001897E8: 084A3925
	global_store_d16_hi_b16 v[31:32], v17, off offset:160      // 0000001897EC: DC9600A0 007C111F
	v_mul_f32_e32 v38, v29, v26                                // 0000001897F4: 104C351D
	.long 0xd41e0001                                           // 0000001897F8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001897FC: 020232FF 42CE8ED0
	v_cvt_i32_f32_e32 v28, v28                                 // 000000189804: 7E38111C
	v_fma_f32 v35, -v33, v36, 1.0                              // 000000189808: D6130023 23CA4921
	v_add_f32_e32 v27, v37, v27                                // 000000189810: 06363725
	global_store_d16_hi_b16 v[39:40], v19, off offset:160      // 000000189814: DC9600A0 007C1327
	.long 0xd71c0011                                           // 00000018981C: D71C0011
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                     // 000000189820: 02023D15
	v_fma_f32 v21, -v22, v38, v29                              // 000000189824: D6130015 24764D16
	v_fmac_f32_e32 v36, v35, v36                               // 00000018982C: 56484923
	v_div_scale_f32 v35, s0, v10, v20, v10                     // 000000189830: D6FC0023 042A290A
	v_exp_f32_e32 v27, v27                                     // 000000189838: 7E364B1B
	v_cndmask_b32_e64 v17, 0, v17, s1                          // 00000018983C: D5010011 00062280
	v_fmac_f32_e32 v38, v21, v26                               // 000000189844: 564C3515
	.long 0xd41b0001                                           // 000000189848: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v25, vcc_lo              // 00000018984C: 020232FF C2B17218
	v_dual_mul_f32 v30, v35, v36 :: v_dual_lshlrev_b32 v19, 16, v106// 000000189854: C8E24923 1E12D490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000018985C: BF870193
	v_fma_f32 v22, -v22, v38, v29                              // 000000189860: D6130016 24764D16
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 000000189868: D5010011 000622FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000189874: BF870213
	v_fma_f32 v21, -v33, v30, v35                              // 000000189878: D6130015 248E3D21
	.long 0xd41e0001                                           // 000000189880: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v19, vcc_lo              // 000000189884: 020226FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000018988C: BF870224
	v_div_fmas_f32 v22, v22, v26, v38                          // 000000189890: D6370016 049A3516
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 000000189898: 7C3C44FF 42CE8ED0
	v_fmac_f32_e32 v30, v21, v36                               // 0000001898A0: 563C4915
	.long 0xd71c0015                                           // 0000001898A4: D71C0015
	v_cndmask_b32_e32 v1, v27, v28, vcc_lo                     // 0000001898A8: 0202391B
	v_add_f32_e32 v17, 1.0, v17                                // 0000001898AC: 062222F2
	v_div_fixup_f32 v9, v22, v18, v9                           // 0000001898B0: D6270009 04262516
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001898B8: BF870214
	v_fma_f32 v25, -v33, v30, v35                              // 0000001898BC: D6130019 248E3D21
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 0000001898C4: 022A2A80
	s_mov_b32 vcc_lo, s0                                       // 0000001898C8: BEEA0000
	v_div_scale_f32 v26, null, v17, v17, v11                   // 0000001898CC: D6FC7C1A 042E2311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001898D4: BF870233
	v_div_fmas_f32 v25, v25, v36, v30                          // 0000001898D8: D6370019 047A4919
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 0000001898E0: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v34, 16, v105                            // 0000001898E8: 3044D290
	v_rcp_f32_e32 v27, v26                                     // 0000001898EC: 7E36551A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001898F0: BF870003
	v_div_fixup_f32 v10, v25, v20, v10                         // 0000001898F4: D627000A 042A2919
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001898FC: 022A2AFF 7F800000
	v_mul_f32_e32 v25, 0xbfb8aa3b, v19                         // 000000189904: 103226FF BFB8AA3B
	v_div_scale_f32 v33, vcc_lo, v11, v17, v11                 // 00000018990C: D6FC6A21 042E230B
	v_mul_f32_e32 v36, 0xbfb8aa3b, v34                         // 000000189914: 104844FF BFB8AA3B
	.long 0x7e00398a                                           // 00000018991C: 7E00398A
	v_add_f32_e32 v18, 1.0, v21                                // 000000189920: 06242AF2
	v_fma_f32 v29, 0xbfb8aa3b, v19, -v25                       // 000000189924: D613001D 846626FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000189930: BF870005
	v_fma_f32 v21, -v26, v27, 1.0                              // 000000189934: D6130015 23CA371A
	v_rndne_f32_e32 v30, v25                                   // 00000018993C: 7E3C4719
	v_and_b32_e32 v28, 1, v0                                   // 000000189940: 36380081
	v_div_scale_f32 v22, null, v18, v18, v12                   // 000000189944: D6FC7C16 04322512
	v_fmac_f32_e32 v29, 0xb2a5705f, v19                        // 00000018994C: 563A26FF B2A5705F
	v_fmac_f32_e32 v27, v21, v27                               // 000000189954: 56363715
	v_sub_f32_e32 v25, v25, v30                                // 000000189958: 08323D19
	.long 0x7e283989                                           // 00000018995C: 7E283989
	v_rcp_f32_e32 v21, v22                                     // 000000189960: 7E2A5516
	.long 0x7f283980                                           // 000000189964: 7F283980
	v_mul_f32_e32 v35, v33, v27                                // 000000189968: 10463721
	v_add_f32_e32 v25, v25, v29                                // 00000018996C: 06323B19
	v_fma_f32 v37, 0xbfb8aa3b, v34, -v36                       // 000000189970: D6130025 849244FF BFB8AA3B
	v_rndne_f32_e32 v38, v36                                   // 00000018997C: 7E4C4724
	v_add3_u32 v10, v10, v28, 0x7fff                           // 000000189980: D655000A 03FE390A 00007FFF
	v_and_b32_e32 v20, 1, v20                                  // 00000018998C: 36282881
	v_fma_f32 v29, -v26, v35, v33                              // 000000189990: D613001D 2486471A
	v_exp_f32_e32 v25, v25                                     // 000000189998: 7E324B19
	v_fma_f32 v28, -v22, v21, 1.0                              // 00000018999C: D613001C 23CA2B16
	v_fmac_f32_e32 v37, 0xb2a5705f, v34                        // 0000001899A4: 564A44FF B2A5705F
	v_sub_f32_e32 v36, v36, v38                                // 0000001899AC: 08484D24
	v_add3_u32 v9, v9, v20, 0x7fff                             // 0000001899B0: D6550009 03FE2909 00007FFF
	v_cvt_i32_f32_e32 v20, v30                                 // 0000001899BC: 7E28111E
	v_fmac_f32_e32 v21, v28, v21                               // 0000001899C0: 562A2B1C
	v_div_scale_f32 v28, s0, v12, v18, v12                     // 0000001899C4: D6FC001C 0432250C
	v_dual_fmac_f32 v35, v29, v27 :: v_dual_add_f32 v30, v36, v37// 0000001899CC: C808371D 231E4B24
	global_store_d16_hi_b16 v[7:8], v9, off offset:192         // 0000001899D4: DC9600C0 007C0907
	.long 0xd71c0009                                           // 0000001899DC: D71C0009
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000001899E0: 02022919
	v_mul_f32_e32 v29, v28, v21                                // 0000001899E4: 103A2B1C
	v_fma_f32 v20, -v26, v35, v33                              // 0000001899E8: D6130014 2486471A
	v_exp_f32_e32 v26, v30                                     // 0000001899F0: 7E344B1E
	global_store_d16_hi_b16 v[47:48], v10, off offset:192      // 0000001899F4: DC9600C0 007C0A2F
	v_cndmask_b32_e64 v9, 0, v9, s1                            // 0000001899FC: D5010009 00061280
	v_fma_f32 v25, -v22, v29, v28                              // 000000189A04: D6130019 24723B16
	v_div_fmas_f32 v20, v20, v27, v35                          // 000000189A0C: D6370014 048E3714
	v_cvt_i32_f32_e32 v27, v38                                 // 000000189A14: 7E361126
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v19                  // 000000189A18: 7C3626FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000189A20: BF870214
	v_fmac_f32_e32 v29, v25, v21                               // 000000189A24: 563A2B19
	v_div_fixup_f32 v11, v20, v17, v11                         // 000000189A28: D627000B 042E2314
	s_delay_alu instid0(VALU_DEP_4)                            // 000000189A30: BF870004
	.long 0xd71c0011                                           // 000000189A34: D71C0011
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000189A38: 0202371A
	v_cndmask_b32_e32 v9, 0x7f800000, v9, vcc_lo               // 000000189A3C: 021212FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 000000189A44: 7C3C44FF 42CE8ED0
	v_fma_f32 v19, -v22, v29, v28                              // 000000189A4C: D6130013 24723B16
	s_waitcnt vmcnt(1)                                         // 000000189A54: BF8907F7
	v_lshlrev_b32_e32 v25, 16, v67                             // 000000189A58: 30328690
	.long 0x7e2c398b                                           // 000000189A5C: 7E2C398B
	v_add_f32_e32 v9, 1.0, v9                                  // 000000189A60: 061212F2
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000189A64: 02222280
	s_mov_b32 vcc_lo, s0                                       // 000000189A68: BEEA0000
	v_mul_f32_e32 v30, 0xbfb8aa3b, v25                         // 000000189A6C: 103C32FF BFB8AA3B
	v_div_fmas_f32 v19, v19, v21, v29                          // 000000189A74: D6370013 04762B13
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 000000189A7C: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v21, 16, v69                             // 000000189A84: 302A8A90
	v_div_scale_f32 v20, null, v9, v9, v13                     // 000000189A88: D6FC7C14 04361309
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v30                       // 000000189A90: D6130022 847A32FF BFB8AA3B
	v_div_fixup_f32 v12, v19, v18, v12                         // 000000189A9C: D627000C 04322513
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 000000189AA4: 022222FF 7F800000
	v_mul_f32_e32 v19, 0xbfb8aa3b, v21                         // 000000189AAC: 10262AFF BFB8AA3B
	v_rcp_f32_e32 v18, v20                                     // 000000189AB4: 7E245514
	v_rndne_f32_e32 v35, v30                                   // 000000189AB8: 7E46471E
	v_fmac_f32_e32 v34, 0xb2a5705f, v25                        // 000000189ABC: 564432FF B2A5705F
	v_add_f32_e32 v17, 1.0, v17                                // 000000189AC4: 062222F2
	v_fma_f32 v27, 0xbfb8aa3b, v21, -v19                       // 000000189AC8: D613001B 844E2AFF BFB8AA3B
	v_rndne_f32_e32 v28, v19                                   // 000000189AD4: 7E384713
	.long 0xd41e0001                                           // 000000189AD8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v21, vcc_lo              // 000000189ADC: 02022AFF 42CE8ED0
	.long 0x7e00398c                                           // 000000189AE4: 7E00398C
	v_div_scale_f32 v26, null, v17, v17, v14                   // 000000189AE8: D6FC7C1A 043A2311
	v_fmac_f32_e32 v27, 0xb2a5705f, v21                        // 000000189AF0: 56362AFF B2A5705F
	v_sub_f32_e32 v19, v19, v28                                // 000000189AF8: 08263913
	v_fma_f32 v29, -v20, v18, 1.0                              // 000000189AFC: D613001D 23CA2514
	v_cvt_i32_f32_e32 v28, v28                                 // 000000189B04: 7E38111C
	v_rcp_f32_e32 v33, v26                                     // 000000189B08: 7E42551A
	.long 0x7f2c3980                                           // 000000189B0C: 7F2C3980
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000189B10: BF8701B3
	v_dual_add_f32 v19, v19, v27 :: v_dual_fmac_f32 v18, v29, v18// 000000189B14: C9003713 1312251D
	v_div_scale_f32 v27, vcc_lo, v13, v9, v13                  // 000000189B1C: D6FC6A1B 0436130D
	v_dual_sub_f32 v29, v30, v35 :: v_dual_and_b32 v36, 1, v0  // 000000189B24: C964471E 1D240081
	v_exp_f32_e32 v19, v19                                     // 000000189B2C: 7E264B13
	v_and_b32_e32 v22, 1, v22                                  // 000000189B30: 362C2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 000000189B34: BF870313
	v_mul_f32_e32 v37, v27, v18                                // 000000189B38: 104A251B
	v_fma_f32 v30, -v26, v33, 1.0                              // 000000189B3C: D613001E 23CA431A
	v_add_f32_e32 v29, v29, v34                                // 000000189B44: 063A451D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000189B48: BF870214
	v_add3_u32 v10, v11, v22, 0x7fff                           // 000000189B4C: D655000A 03FE2D0B 00007FFF
	v_fma_f32 v34, -v20, v37, v27                              // 000000189B58: D6130022 246E4B14
	s_delay_alu instid0(VALU_DEP_4)                            // 000000189B60: BF870004
	v_fmac_f32_e32 v33, v30, v33                               // 000000189B64: 5642431E
	v_div_scale_f32 v30, s0, v14, v17, v14                     // 000000189B68: D6FC001E 043A230E
	v_exp_f32_e32 v29, v29                                     // 000000189B70: 7E3A4B1D
	.long 0xd71c0013                                           // 000000189B74: D71C0013
	v_cndmask_b32_e32 v1, v19, v28, vcc_lo                     // 000000189B78: 02023913
	v_fmac_f32_e32 v37, v34, v18                               // 000000189B7C: 564A2522
	v_cvt_i32_f32_e32 v34, v35                                 // 000000189B80: 7E441123
	v_mul_f32_e32 v28, v30, v33                                // 000000189B84: 1038431E
	v_add3_u32 v11, v12, v36, 0x7fff                           // 000000189B88: D655000B 03FE490C 00007FFF
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 000000189B94: D5010013 00062680
	.long 0xd41b0001                                           // 000000189B9C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v21, vcc_lo              // 000000189BA0: 02022AFF C2B17218
	v_fma_f32 v20, -v20, v37, v27                              // 000000189BA8: D6130014 246E4B14
	v_fma_f32 v35, -v26, v28, v30                              // 000000189BB0: D6130023 247A391A
	.long 0xd71c001b                                           // 000000189BB8: D71C001B
	v_cndmask_b32_e32 v1, v29, v34, vcc_lo                     // 000000189BBC: 0202451D
	global_store_d16_hi_b16 v[15:16], v10, off offset:192      // 000000189BC0: DC9600C0 007C0A0F
	v_cndmask_b32_e64 v19, 0x7f800000, v19, s1                 // 000000189BC8: D5010013 000626FF 7F800000
	.long 0xd41e0001                                           // 000000189BD4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 000000189BD8: 020232FF 42CE8ED0
	v_fmac_f32_e32 v28, v35, v33                               // 000000189BE0: 56384323
	v_div_fmas_f32 v18, v20, v18, v37                          // 000000189BE4: D6370012 04962514
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000189BEC: 7C3632FF C2B17218
	v_add_f32_e32 v19, 1.0, v19                                // 000000189BF4: 062626F2
	v_cndmask_b32_e64 v21, 0, v27, s1                          // 000000189BF8: D5010015 00063680
	v_fma_f32 v20, -v26, v28, v30                              // 000000189C00: D6130014 247A391A
	v_div_fixup_f32 v9, v18, v9, v13                           // 000000189C08: D6270009 04361312
	global_store_d16_hi_b16 v[23:24], v11, off offset:192      // 000000189C10: DC9600C0 007C0B17
	v_div_scale_f32 v26, null, v19, v19, v1                    // 000000189C18: D6FC7C1A 04062713
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 000000189C20: 022A2AFF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 000000189C28: BEEA0000
	v_lshlrev_b32_e32 v18, 16, v56                             // 000000189C2C: 30247090
	v_div_fmas_f32 v20, v20, v33, v28                          // 000000189C30: D6370014 04724314
	v_rcp_f32_e32 v25, v26                                     // 000000189C38: 7E32551A
	v_add_f32_e32 v21, 1.0, v21                                // 000000189C3C: 062A2AF2
	v_lshlrev_b32_e32 v29, 16, v55                             // 000000189C40: 303A6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000189C44: BF870223
	v_div_fixup_f32 v12, v20, v17, v14                         // 000000189C48: D627000C 043A2314
	.long 0x7e223989                                           // 000000189C50: 7E223989
	v_div_scale_f32 v14, null, v21, v21, v2                    // 000000189C54: D6FC7C0E 040A2B15
	.long 0x7f223980                                           // 000000189C5C: 7F223980
	v_mul_f32_e32 v30, 0xbfb8aa3b, v29                         // 000000189C60: 103C3AFF BFB8AA3B
	.long 0x7e00398c                                           // 000000189C68: 7E00398C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000189C6C: BF8701B5
	v_fma_f32 v10, -v26, v25, 1.0                              // 000000189C70: D613000A 23CA331A
	v_rcp_f32_e32 v13, v14                                     // 000000189C78: 7E1A550E
	v_and_b32_e32 v17, 1, v17                                  // 000000189C7C: 36222281
	v_and_b32_e32 v11, 1, v0                                   // 000000189C80: 36160081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000189C84: BF870223
	v_fmac_f32_e32 v25, v10, v25                               // 000000189C88: 5632330A
	v_div_scale_f32 v10, vcc_lo, v1, v19, v1                   // 000000189C8C: D6FC6A0A 04062701
	v_add3_u32 v9, v9, v17, 0x7fff                             // 000000189C94: D6550009 03FE2309 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000189CA0: BF870224
	v_add3_u32 v11, v12, v11, 0x7fff                           // 000000189CA4: D655000B 03FE170C 00007FFF
	v_mul_f32_e32 v12, 0xbfb8aa3b, v18                         // 000000189CB0: 101824FF BFB8AA3B
	v_mul_f32_e32 v20, v10, v25                                // 000000189CB8: 1028330A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 000000189CBC: BF870005
	v_fma_f32 v22, -v14, v13, 1.0                              // 000000189CC0: D6130016 23CA1B0E
	s_clause 0x1                                               // 000000189CC8: BF850001
	global_store_d16_hi_b16 v[31:32], v9, off offset:192       // 000000189CCC: DC9600C0 007C091F
	global_store_d16_hi_b16 v[39:40], v11, off offset:192      // 000000189CD4: DC9600C0 007C0B27
	v_fma_f32 v27, 0xbfb8aa3b, v18, -v12                       // 000000189CDC: D613001B 843224FF BFB8AA3B
	v_fma_f32 v17, -v26, v20, v10                              // 000000189CE8: D6130011 242A291A
	v_fmac_f32_e32 v13, v22, v13                               // 000000189CF0: 561A1B16
	v_div_scale_f32 v22, s0, v2, v21, v2                       // 000000189CF4: D6FC0016 040A2B02
	v_rndne_f32_e32 v28, v12                                   // 000000189CFC: 7E38470C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000189D00: BF870114
	v_dual_fmac_f32 v27, 0xb2a5705f, v18 :: v_dual_fmac_f32 v20, v17, v25// 000000189D04: C80024FF 1B143311 B2A5705F
	v_dual_mul_f32 v17, v22, v13 :: v_dual_sub_f32 v12, v12, v28// 000000189D10: C8CA1B16 110C390C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000189D18: BF8701A2
	v_fma_f32 v9, -v26, v20, v10                               // 000000189D1C: D6130009 242A291A
	v_fma_f32 v26, 0xbfb8aa3b, v29, -v30                       // 000000189D24: D613001A 847A3AFF BFB8AA3B
	v_fma_f32 v10, -v14, v17, v22                              // 000000189D30: D613000A 245A230E
	s_delay_alu instid0(VALU_DEP_4)                            // 000000189D38: BF870004
	v_add_f32_e32 v12, v12, v27                                // 000000189D3C: 0618370C
	v_rndne_f32_e32 v27, v30                                   // 000000189D40: 7E36471E
	v_div_fmas_f32 v9, v9, v25, v20                            // 000000189D44: D6370009 04523309
	v_fmac_f32_e32 v26, 0xb2a5705f, v29                        // 000000189D4C: 56343AFF B2A5705F
	v_fmac_f32_e32 v17, v10, v13                               // 000000189D54: 56221B0A
	v_exp_f32_e32 v10, v12                                     // 000000189D58: 7E144B0C
	v_sub_f32_e32 v12, v30, v27                                // 000000189D5C: 0818371E
	v_lshlrev_b32_e32 v20, 16, v63                             // 000000189D60: 30287E90
	v_cvt_i32_f32_e32 v25, v28                                 // 000000189D64: 7E32111C
	v_fma_f32 v14, -v14, v17, v22                              // 000000189D68: D613000E 245A230E
	s_waitcnt vmcnt(0)                                         // 000000189D70: BF8903F7
	v_lshlrev_b32_e32 v22, 16, v64                             // 000000189D74: 302C8090
	v_add_f32_e32 v12, v12, v26                                // 000000189D78: 0618350C
	v_mul_f32_e32 v26, 0xbfb8aa3b, v20                         // 000000189D7C: 103428FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v18                  // 000000189D84: 7C3C24FF 42CE8ED0
	v_cvt_i32_f32_e32 v27, v27                                 // 000000189D8C: 7E36111B
	v_mul_f32_e32 v28, 0xbfb8aa3b, v22                         // 000000189D90: 10382CFF BFB8AA3B
	.long 0xd71c000a                                           // 000000189D98: D71C000A
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 000000189D9C: 0202330A
	v_fma_f32 v25, 0xbfb8aa3b, v20, -v26                       // 000000189DA0: D6130019 846A28FF BFB8AA3B
	v_rndne_f32_e32 v30, v26                                   // 000000189DAC: 7E3C471A
	v_exp_f32_e32 v12, v12                                     // 000000189DB0: 7E184B0C
	v_fma_f32 v33, 0xbfb8aa3b, v22, -v28                       // 000000189DB4: D6130021 84722CFF BFB8AA3B
	v_rndne_f32_e32 v34, v28                                   // 000000189DC0: 7E44471C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000189DC4: BF870223
	v_dual_fmac_f32 v25, 0xb2a5705f, v20 :: v_dual_sub_f32 v26, v26, v30// 000000189DC8: C80A28FF 191A3D1A B2A5705F
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000189DD4: 02141480
	v_fmac_f32_e32 v33, 0xb2a5705f, v22                        // 000000189DD8: 56422CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 000000189DE0: BF8702B4
	v_sub_f32_e32 v28, v28, v34                                // 000000189DE4: 0838451C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v18                  // 000000189DE8: 7C3624FF C2B17218
	v_add_f32_e32 v25, v26, v25                                // 000000189DF0: 0632331A
	.long 0xd71c000c                                           // 000000189DF4: D71C000C
	v_cndmask_b32_e32 v1, v12, v27, vcc_lo                     // 000000189DF8: 0202370C
	v_cvt_i32_f32_e32 v27, v34                                 // 000000189DFC: 7E361122
	v_add_f32_e32 v26, v28, v33                                // 000000189E00: 0634431C
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo             // 000000189E04: 021414FF 7F800000
	v_exp_f32_e32 v18, v25                                     // 000000189E0C: 7E244B19
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 000000189E10: 7C3C3AFF 42CE8ED0
	v_div_fixup_f32 v1, v9, v19, v1                            // 000000189E18: D6270001 04062709
	v_exp_f32_e32 v25, v26                                     // 000000189E20: 7E324B1A
	v_cvt_i32_f32_e32 v26, v30                                 // 000000189E24: 7E34111E
	v_add_f32_e32 v10, 1.0, v10                                // 000000189E28: 061414F2
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 000000189E2C: 02181880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 000000189E30: 7C363AFF C2B17218
	.long 0x7e443981                                           // 000000189E38: 7E443981
	.long 0x7f443980                                           // 000000189E3C: 7F443980
	.long 0xd71c0012                                           // 000000189E40: D71C0012
	v_cndmask_b32_e32 v1, v18, v26, vcc_lo                     // 000000189E44: 02023512
	v_div_scale_f32 v26, null, v10, v10, v3                    // 000000189E48: D6FC7C1A 040E150A
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 000000189E50: 021818FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v20                  // 000000189E58: 7C3C28FF 42CE8ED0
	.long 0xd71c0019                                           // 000000189E60: D71C0019
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 000000189E64: 02023719
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000189E68: BF870194
	v_rcp_f32_e32 v27, v26                                     // 000000189E6C: 7E36551A
	v_add_f32_e32 v12, 1.0, v12                                // 000000189E70: 061818F2
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000189E74: 02242480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v22                  // 000000189E78: 7C3C2CFF 42CE8ED0
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000189E80: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v20                  // 000000189E84: 7C3628FF C2B17218
	v_div_scale_f32 v20, null, v12, v12, v4                    // 000000189E8C: D6FC7C14 0412190C
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 000000189E94: 022424FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v22                  // 000000189E9C: 7C362CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000189EA4: BF870113
	v_rcp_f32_e32 v28, v20                                     // 000000189EA8: 7E385514
	v_add_f32_e32 v18, 1.0, v18                                // 000000189EAC: 062424F2
	v_cndmask_b32_e32 v22, 0x7f800000, v25, vcc_lo             // 000000189EB0: 022C32FF 7F800000
	v_fma_f32 v25, -v26, v27, 1.0                              // 000000189EB8: D6130019 23CA371A
	s_mov_b32 vcc_lo, s0                                       // 000000189EC0: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000189EC4: BF870193
	v_div_scale_f32 v29, null, v18, v18, v5                    // 000000189EC8: D6FC7C1D 04162512
	v_add_f32_e32 v22, 1.0, v22                                // 000000189ED0: 062C2CF2
	v_div_fmas_f32 v13, v14, v13, v17                          // 000000189ED4: D637000D 04461B0E
	v_fmac_f32_e32 v27, v25, v27                               // 000000189EDC: 56363719
	v_div_scale_f32 v17, vcc_lo, v3, v10, v3                   // 000000189EE0: D6FC6A11 040E1503
	v_rcp_f32_e32 v14, v29                                     // 000000189EE8: 7E1C551D
	v_div_scale_f32 v25, null, v22, v22, v6                    // 000000189EEC: D6FC7C19 041A2D16
	v_fma_f32 v30, -v20, v28, 1.0                              // 000000189EF4: D613001E 23CA3914
	v_div_fixup_f32 v2, v13, v21, v2                           // 000000189EFC: D6270002 040A2B0D
	v_mul_f32_e32 v11, v17, v27                                // 000000189F04: 10163711
	v_div_scale_f32 v21, s0, v4, v12, v4                       // 000000189F08: D6FC0015 04121904
	v_rcp_f32_e32 v13, v25                                     // 000000189F10: 7E1A5519
	v_fmac_f32_e32 v28, v30, v28                               // 000000189F14: 5638391E
	.long 0x7e003982                                           // 000000189F18: 7E003982
	v_fma_f32 v9, -v26, v11, v17                               // 000000189F1C: D6130009 2446171A
	v_fma_f32 v30, -v29, v14, 1.0                              // 000000189F24: D613001E 23CA1D1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000189F2C: BF870114
	v_mul_f32_e32 v19, v21, v28                                // 000000189F30: 10263915
	v_dual_fmac_f32 v11, v9, v27 :: v_dual_fmac_f32 v14, v30, v14// 000000189F34: C8003709 0B0E1D1E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000189F3C: BF870225
	v_fma_f32 v33, -v25, v13, 1.0                              // 000000189F40: D6130021 23CA1B19
	v_div_scale_f32 v30, s1, v5, v18, v5                       // 000000189F48: D6FC011E 04162505
	v_fma_f32 v9, -v20, v19, v21                               // 000000189F50: D6130009 24562714
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000189F58: BF870214
	v_fma_f32 v17, -v26, v11, v17                              // 000000189F5C: D6130011 2446171A
	v_fmac_f32_e32 v13, v33, v13                               // 000000189F64: 561A1B21
	v_div_scale_f32 v33, s2, v6, v22, v6                       // 000000189F68: D6FC0221 041A2D06
	v_mul_f32_e32 v35, v30, v14                                // 000000189F70: 10461D1E
	v_fmac_f32_e32 v19, v9, v28                                // 000000189F74: 56263909
	v_div_fmas_f32 v11, v17, v27, v11                          // 000000189F78: D637000B 042E3711
	s_mov_b32 vcc_lo, s0                                       // 000000189F80: BEEA0000
	v_mul_f32_e32 v26, v33, v13                                // 000000189F84: 10341B21
	v_fma_f32 v9, -v29, v35, v30                               // 000000189F88: D6130009 247A471D
	v_fma_f32 v17, -v20, v19, v21                              // 000000189F90: D6130011 24562714
	v_div_fixup_f32 v3, v11, v10, v3                           // 000000189F98: D6270003 040E150B
	v_and_b32_e32 v11, 1, v34                                  // 000000189FA0: 36164481
	v_fma_f32 v20, -v25, v26, v33                              // 000000189FA4: D6130014 24863519
	v_fmac_f32_e32 v35, v9, v14                                // 000000189FAC: 56461D09
	v_div_fmas_f32 v9, v17, v28, v19                           // 000000189FB0: D6370009 044E3911
	s_mov_b32 vcc_lo, s1                                       // 000000189FB8: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000189FBC: BF870193
	v_dual_fmac_f32 v26, v20, v13 :: v_dual_and_b32 v17, 1, v0 // 000000189FC0: C8241B14 1A100081
	v_fma_f32 v10, -v29, v35, v30                              // 000000189FC8: D613000A 247A471D
	s_delay_alu instid0(VALU_DEP_3)                            // 000000189FD0: BF870003
	v_div_fixup_f32 v4, v9, v12, v4                            // 000000189FD4: D6270004 04121909
	.long 0x7f183980                                           // 000000189FDC: 7F183980
	v_add3_u32 v1, v1, v11, 0x7fff                             // 000000189FE0: D6550001 03FE1701 00007FFF
	v_fma_f32 v9, -v25, v26, v33                               // 000000189FEC: D6130009 24863519
	v_div_fmas_f32 v10, v10, v14, v35                          // 000000189FF4: D637000A 048E1D0A
	s_mov_b32 vcc_lo, s2                                       // 000000189FFC: BEEA0002
	.long 0x7e003984                                           // 00000018A000: 7E003984
	v_add3_u32 v2, v2, v17, 0x7fff                             // 00000018A004: D6550002 03FE2302 00007FFF
	v_div_fmas_f32 v9, v9, v13, v26                            // 00000018A010: D6370009 046A1B09
	v_div_fixup_f32 v5, v10, v18, v5                           // 00000018A018: D6270005 0416250A
	.long 0x7e143983                                           // 00000018A020: 7E143983
	.long 0x7f143980                                           // 00000018A024: 7F143980
	global_store_d16_hi_b16 v[7:8], v1, off offset:224         // 00000018A028: DC9600E0 007C0107
	v_div_fixup_f32 v6, v9, v22, v6                            // 00000018A030: D6270006 041A2D09
	.long 0x7e183985                                           // 00000018A038: 7E183985
	v_and_b32_e32 v9, 1, v0                                    // 00000018A03C: 36120081
	v_and_b32_e32 v10, 1, v10                                  // 00000018A040: 36141481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000018A044: BF870214
	.long 0x7e003986                                           // 00000018A048: 7E003986
	v_and_b32_e32 v11, 1, v12                                  // 00000018A04C: 36161881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000018A050: BF870223
	v_add3_u32 v1, v3, v10, 0x7fff                             // 00000018A054: D6550001 03FE1503 00007FFF
	v_add3_u32 v3, v4, v9, 0x7fff                              // 00000018A060: D6550003 03FE1304 00007FFF
	v_and_b32_e32 v0, 1, v0                                    // 00000018A06C: 36000081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000018A070: BF870114
	v_add3_u32 v4, v5, v11, 0x7fff                             // 00000018A074: D6550004 03FE1705 00007FFF
	v_add3_u32 v0, v6, v0, 0x7fff                              // 00000018A080: D6550000 03FE0106 00007FFF
	s_clause 0x4                                               // 00000018A08C: BF850004
	global_store_d16_hi_b16 v[47:48], v2, off offset:224       // 00000018A090: DC9600E0 007C022F
	global_store_d16_hi_b16 v[15:16], v1, off offset:224       // 00000018A098: DC9600E0 007C010F
	global_store_d16_hi_b16 v[23:24], v3, off offset:224       // 00000018A0A0: DC9600E0 007C0317
	global_store_d16_hi_b16 v[31:32], v4, off offset:224       // 00000018A0A8: DC9600E0 007C041F
	global_store_d16_hi_b16 v[39:40], v0, off offset:224       // 00000018A0B0: DC9600E0 007C0027
	s_nop 0                                                    // 00000018A0B8: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000018A0BC: BFB60003
	s_endpgm                                                   // 00000018A0C0: BFB00000
		...

