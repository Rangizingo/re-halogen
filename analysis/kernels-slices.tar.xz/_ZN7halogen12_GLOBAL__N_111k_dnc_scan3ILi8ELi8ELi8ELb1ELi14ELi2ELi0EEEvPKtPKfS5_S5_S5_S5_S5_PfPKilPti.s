00000000000bb600 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000BB600: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000BB604: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000BB60C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000BB614: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000BB618: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000BB61C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000BB620: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000BB628: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000BB62C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000BB630: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000BB634: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000BB63C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000BB640: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000BB644: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000BB648: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000BB64C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000BB650: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000BB654: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000BB658: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000BB65C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000BB664: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000BB66C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000BB670: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000BB674: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000BB678: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000BB67C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000BB680: 821E191E
	.long 0xd7001f02                                           // 0000000BB684: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000BB688: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000BB68C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000BB694: BE9E0080
	s_nop 0                                                    // 0000000BB698: BF800000
	s_nop 0                                                    // 0000000BB69C: BF800000
	s_nop 0                                                    // 0000000BB6A0: BF800000
	s_nop 0                                                    // 0000000BB6A4: BF800000
	s_nop 0                                                    // 0000000BB6A8: BF800000
	s_nop 0                                                    // 0000000BB6AC: BF800000
	s_nop 0                                                    // 0000000BB6B0: BF800000
	s_nop 0                                                    // 0000000BB6B4: BF800000
	s_nop 0                                                    // 0000000BB6B8: BF800000
	s_nop 0                                                    // 0000000BB6BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000BB6C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000BB6C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB6CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000BB6D0: 300C1089
	.long 0xd7006a06                                           // 0000000BB6D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000BB6D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BB6DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000BB6E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000BB6E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000BB6F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000BB6F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000BB6FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000BB708: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000BB70C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000BB710: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000BB718: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000BB71C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000BB720: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000BB724: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 0000000BB72C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000BB734: 32040084
	s_mov_b32 s0, 0                                            // 0000000BB738: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000BB73C: BF89FC07
	s_barrier                                                  // 0000000BB740: BFBD0000
	buffer_gl0_inv                                             // 0000000BB744: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000BB74C: BF02801E
	s_cbranch_scc1 12                                          // 0000000BB750: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000BB754: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000BB75C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BB764: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 0000000BB768: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000BB770: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000BB774: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000BB778: 916A007E
	s_cbranch_vccz 2                                           // 0000000BB77C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2200                                              // 0000000BB780: BFA00898 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23e4>
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000BB784: 304E0A82
	s_add_i32 s0, s30, 63                                      // 0000000BB788: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000BB78C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000BB794: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000BB798: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000BB79C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000BB7A0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000000BB7A4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000000BB7AC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000BB7B0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000BB7B4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000BB7B8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000BB7BC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000BB7C0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000BB7C4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000000BB7C8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000BB7D4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000BB7D8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000BB7DC: B00A0204
	.long 0xd7000b2c                                           // 0000000BB7E0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000000BB7E4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000BB7E8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000000BB7EC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000000BB7F4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000BB800: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 0000000BB804: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 0000000BB810: 3816500A
	.long 0xd7000a05                                           // 0000000BB814: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000BB818: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000BB81C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000BB820: D5207C06 00290001
	.long 0xd7000107                                           // 0000000BB828: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000BB82C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BB830: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000BB834: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000BB83C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000BB840: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000BB844: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000BB84C: 84848E02
	.long 0xd700010b                                           // 0000000BB850: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000BB854: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000BB858: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000BB85C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000BB864: 8205050F
	.long 0xd700010d                                           // 0000000BB868: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000BB86C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BB870: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000BB874: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000BB87C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000BB880: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000BB888: D5207C10 00061880
	.long 0xd7000111                                           // 0000000BB890: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000BB894: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BB89C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000BB8A0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000BB8A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000BB8AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000BB8B4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000BB8BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000BB8C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BB8C8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000BB8CC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000BB8D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000BB8D8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000BB8E0: D5207C18 00061880
	.long 0xd7000119                                           // 0000000BB8E8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000BB8EC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BB8F4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000BB8F8: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000BB900: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000BB904: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 0000000BB90C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 0000000BB914: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000BB918: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 0000000BB920: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 0000000BB924: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 0000000BB92C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000BB934: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 0000000BB93C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 0000000BB944: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 0000000BB94C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 0000000BB954: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 0000000BB95C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 0000000BB964: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 0000000BB96C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 0000000BB974: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 0000000BB97C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 0000000BB984: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 0000000BB98C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 0000000BB994: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 0000000BB99C: BE850080
	s_mov_b32 s6, 0x42800000                                   // 0000000BB9A0: BE8600FF 42800000
	s_mov_b32 s7, 0x3c800000                                   // 0000000BB9A8: BE8700FF 3C800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000BB9B0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000BB9B4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000BB9BC: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000BB9C0: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000BB9C4: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000BB9C8: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000BB9CC: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000BB9D0: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000BB9D4: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000BB9D8: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000BB9DC: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000BB9E4: BE84206A
	s_cbranch_execz 77                                         // 0000000BB9E8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x520>
	v_or_b32_e32 v29, s11, v0                                  // 0000000BB9EC: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BB9F0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000BB9F4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000BB9FC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBA00: BF870091
	.long 0xd73c001d                                           // 0000000BBA04: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000BBA08: 02023A82
	.long 0xd700011d                                           // 0000000BBA0C: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000BBA10: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BBA14: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000BBA18: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000BBA20: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BBA28: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000BBA2C: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000BBA30: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000BBA3C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 0000000BBA40: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 0000000BBA4C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000BBA50: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000BBA5C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000BBA60: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 0000000BBA64: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000BBA70: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BBA74: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 0000000BBA78: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 0000000BBA80: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000BBA84: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 0000000BBA8C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000BBA94: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 0000000BBA98: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000BBA9C: BF870193
	v_exp_f32_e32 v32, v32                                     // 0000000BBAA0: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 0000000BBAA4: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000BBAA8: BF870296
	.long 0xd71c0020                                           // 0000000BBAAC: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000BBAB0: 02024520
	.long 0xd71c001f                                           // 0000000BBAB4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000BBAB8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BBABC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000BBAC0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000BBAC8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000BBACC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000BBAD4: D5010020 00064080
	.long 0xd41e0001                                           // 0000000BBADC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000BBAE0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BBAE8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000BBAEC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000BBAF8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000BBAFC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000BBB04: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 0000000BBB10: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 0000000BBB18: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BBB20: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000BBB24: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000BBB2C: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BBB30: BF89FC07
	s_barrier                                                  // 0000000BBB34: BFBD0000
	buffer_gl0_inv                                             // 0000000BBB38: E0AC0000 00000000
	s_branch 15                                                // 0000000BBB40: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BBB44: 8C7E047E
	.long 0xd700011d                                           // 0000000BBB48: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000BBB4C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BBB54: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BBB58: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000BBB60: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000BBB64: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000BBB68: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000BBB6C: BF89FC07
	s_barrier                                                  // 0000000BBB70: BFBD0000
	buffer_gl0_inv                                             // 0000000BBB74: E0AC0000 00000000
	s_cbranch_scc1 702                                         // 0000000BBB7C: BFA202BE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000BBB80: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 0000000BBB88: CA100128 21220126
	s_mov_b32 s13, 0                                           // 0000000BBB90: BE8D0080
	s_nop 0                                                    // 0000000BBB94: BF800000
	s_nop 0                                                    // 0000000BBB98: BF800000
	s_nop 0                                                    // 0000000BBB9C: BF800000
	s_nop 0                                                    // 0000000BBBA0: BF800000
	s_nop 0                                                    // 0000000BBBA4: BF800000
	s_nop 0                                                    // 0000000BBBA8: BF800000
	s_nop 0                                                    // 0000000BBBAC: BF800000
	s_nop 0                                                    // 0000000BBBB0: BF800000
	s_nop 0                                                    // 0000000BBBB4: BF800000
	s_nop 0                                                    // 0000000BBBB8: BF800000
	s_nop 0                                                    // 0000000BBBBC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000000BBBC0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000BBBC8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000BBBD0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000BBBD4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000BBBDC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000BBBE0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000BBBE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000BBBEC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000BBBF4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000BBBF8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000000BBBFC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000BBC04: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000BBC0C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000BBC10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000BBC14: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000BBC18: BF89FC07
	s_barrier                                                  // 0000000BBC1C: BFBD0000
	buffer_gl0_inv                                             // 0000000BBC20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000BBC28: BE842000
	s_cbranch_execz 65477                                      // 0000000BBC2C: BFA5FFC5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 0000000BBC30: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 0000000BBC38: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 0000000BBC40: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 0000000BBC48: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000BBC50: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 0000000BBC58: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 0000000BBC60: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 0000000BBC68: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 0000000BBC70: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 0000000BBC78: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 0000000BBC80: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 0000000BBC88: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 0000000BBC90: D8DCFFEE 50000001
	v_or3_b32 v70, s12, s11, v2                                // 0000000BBC98: D6580046 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBCA0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 0000000BBCA4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 0000000BBCAC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 0000000BBCB0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBCB4: BF870091
	.long 0xd7000146                                           // 0000000BBCB8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 0000000BBCBC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 0000000BBCC0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 0000000BBCC8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 0000000BBCD0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 0000000BBCD4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BBCDC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 0000000BBCE0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 0000000BBCE8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 0000000BBCEC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 0000000BBCF4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 0000000BBCFC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 0000000BBD04: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 0000000BBD0C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 0000000BBD14: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBD18: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 0000000BBD1C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 0000000BBD24: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 0000000BBD2C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBD30: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 0000000BBD34: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 0000000BBD3C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 0000000BBD44: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBD48: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 0000000BBD4C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 0000000BBD54: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 0000000BBD5C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BBD60: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000BBD64: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 0000000BBD6C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 0000000BBD74: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 0000000BBD7C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 0000000BBD84: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 0000000BBD8C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000BBD94: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 0000000BBD9C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000BBDA4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 0000000BBDAC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 0000000BBDB4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBDB8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 0000000BBDBC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 0000000BBDC4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBDCC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 0000000BBDD0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 0000000BBDD8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 0000000BBDE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBDE4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 0000000BBDE8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 0000000BBDF0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 0000000BBDF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BBDFC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 0000000BBE00: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 0000000BBE08: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 0000000BBE10: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 0000000BBE18: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000BBE20: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 0000000BBE28: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 0000000BBE30: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 0000000BBE38: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 0000000BBE40: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 0000000BBE48: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 0000000BBE50: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBE54: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 0000000BBE58: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 0000000BBE60: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 0000000BBE68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBE6C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000BBE70: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000BBE78: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000BBE80: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBE84: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 0000000BBE88: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 0000000BBE90: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 0000000BBE98: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BBE9C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000BBEA0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 0000000BBEA8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 0000000BBEB0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 0000000BBEB8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 0000000BBEC0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 0000000BBEC8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 0000000BBED0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000BBED8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000BBEE0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 0000000BBEE8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000BBEF0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBEF4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000BBEF8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000BBF00: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000BBF08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBF0C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 0000000BBF10: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 0000000BBF18: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 0000000BBF20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBF24: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 0000000BBF28: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 0000000BBF30: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 0000000BBF38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BBF3C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 0000000BBF40: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 0000000BBF48: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 0000000BBF50: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 0000000BBF58: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 0000000BBF60: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 0000000BBF68: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 0000000BBF70: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 0000000BBF78: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 0000000BBF80: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 0000000BBF88: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 0000000BBF90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBF94: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000BBF98: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000BBFA0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000BBFA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBFAC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000BBFB0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000BBFB8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000BBFC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BBFC4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 0000000BBFC8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 0000000BBFD0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 0000000BBFD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BBFDC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000BBFE0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 0000000BBFE8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 0000000BBFF0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 0000000BBFF8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 0000000BC000: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 0000000BC008: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 0000000BC010: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000BC018: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000BC020: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 0000000BC028: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000BC030: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC034: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000BC038: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000BC040: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000BC048: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC04C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000BC050: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000BC058: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000BC060: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC064: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000BC068: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BC070: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BC078: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BC07C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000BC080: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 0000000BC088: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 0000000BC090: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 0000000BC098: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 0000000BC0A0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 0000000BC0A8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 0000000BC0B0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 0000000BC0B8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 0000000BC0C0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 0000000BC0C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000BC0D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC0D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000BC0D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000BC0E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000BC0E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC0EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000BC0F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000BC0F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000BC100: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC104: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000BC108: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BC110: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BC118: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BC11C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000BC120: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 0000000BC128: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 0000000BC130: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 0000000BC138: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 0000000BC140: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 0000000BC148: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 0000000BC150: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000BC158: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000BC160: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 0000000BC168: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000BC170: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC174: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000BC178: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000BC180: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000BC188: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC18C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000BC190: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000BC198: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000BC1A0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC1A4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000BC1A8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BC1B0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BC1B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BC1BC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000BC1C0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 0000000BC1C8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 0000000BC1D0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 0000000BC1D8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 0000000BC1E0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 0000000BC1E8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 0000000BC1F0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 0000000BC1F8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 0000000BC200: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 0000000BC208: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000BC210: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC214: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000BC218: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000BC220: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000BC228: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC22C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000BC230: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000BC238: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000BC240: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC244: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000BC248: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BC250: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BC258: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BC25C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000BC260: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 0000000BC268: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 0000000BC270: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 0000000BC278: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 0000000BC280: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 0000000BC288: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 0000000BC290: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000BC298: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000BC2A0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 0000000BC2A8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000BC2B0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC2B4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000BC2B8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000BC2C0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000BC2C8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC2CC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000BC2D0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000BC2D8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000BC2E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC2E4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000BC2E8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BC2F0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BC2F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BC2FC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000BC300: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 0000000BC308: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 0000000BC310: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 0000000BC318: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 0000000BC320: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 0000000BC328: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 0000000BC330: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 0000000BC338: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 0000000BC340: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 0000000BC348: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000BC350: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC354: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000BC358: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000BC360: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000BC368: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC36C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000BC370: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000BC378: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000BC380: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC384: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000BC388: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BC390: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BC398: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BC39C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000BC3A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 0000000BC3A8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 0000000BC3B0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 0000000BC3B8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 0000000BC3C0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 0000000BC3C8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 0000000BC3D0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000BC3D8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000BC3E0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 0000000BC3E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000BC3F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC3F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000BC3F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000BC400: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000BC408: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC40C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000BC410: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000BC418: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000BC420: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC424: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000BC428: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BC430: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BC438: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BC43C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000BC440: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 0000000BC448: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 0000000BC450: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 0000000BC458: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 0000000BC460: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 0000000BC468: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 0000000BC470: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 0000000BC478: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 0000000BC480: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 0000000BC488: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000BC490: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC494: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000BC498: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000BC4A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000BC4A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC4AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000BC4B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000BC4B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000BC4C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC4C4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000BC4C8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BC4D0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BC4D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BC4DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000BC4E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 0000000BC4E8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 0000000BC4F0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 0000000BC4F8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 0000000BC500: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 0000000BC508: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 0000000BC510: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000BC518: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000BC520: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 0000000BC528: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000BC530: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC534: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000BC538: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000BC540: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000BC548: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC54C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000BC550: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000BC558: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000BC560: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC564: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000BC568: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BC570: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BC578: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BC57C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000BC580: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 0000000BC588: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 0000000BC590: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 0000000BC598: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 0000000BC5A0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 0000000BC5A8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 0000000BC5B0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 0000000BC5B8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 0000000BC5C0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 0000000BC5C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000BC5D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC5D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000BC5D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000BC5E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000BC5E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC5EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000BC5F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000BC5F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000BC600: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC604: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000BC608: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000BC610: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000BC618: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC61C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 0000000BC620: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 0000000BC628: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 0000000BC630: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC634: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 0000000BC638: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 0000000BC640: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 0000000BC648: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BC64C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 0000000BC650: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s12, v[4:5]            // 0000000BC658: D6FE7C1F 041018FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 0000000BC664: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 0000000BC66C: D8340000 0000201F
	s_branch 64819                                             // 0000000BC674: BFA0FD33 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x544>
	v_mov_b32_e32 v30, v14                                     // 0000000BC678: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000BC67C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000BC684: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 0000000BC688: 7E46032B
	s_mov_b32 s12, 0                                           // 0000000BC68C: BE8C0080
	s_branch 21                                                // 0000000BC690: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000BC694: 8C7E0D7E
	.long 0xd700011f                                           // 0000000BC698: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000BC69C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BC6A4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000BC6A8: D5207C20 00064080
	.long 0xd700011d                                           // 0000000BC6B0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000BC6B4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000BC6BC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BC6C0: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000BC6C8: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000BC6CC: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000BC6D0: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000BC6D4: BC7C0000
	s_barrier                                                  // 0000000BC6D8: BFBD0000
	buffer_gl0_inv                                             // 0000000BC6DC: E0AC0000 00000000
	s_cbranch_scc1 198                                         // 0000000BC6E4: BFA200C6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1400>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BC6E8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000BC6EC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000BC6F4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000BC6F8: 7E780326
	s_mov_b32 s13, 0                                           // 0000000BC6FC: BE8D0080
	global_load_b32 v61, v[33:34], off                         // 0000000BC700: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000BC708: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000BC710: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000BC714: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000BC71C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000BC720: D5207C22 00064480
	.long 0xd4490004                                           // 0000000BC728: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000BC72C: 020278FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000BC734: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000BC738: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000000BC73C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 0000000BC744: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000BC74C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000BC750: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000BC754: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000BC758: BF89FC07
	s_barrier                                                  // 0000000BC75C: BFBD0000
	buffer_gl0_inv                                             // 0000000BC760: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000BC768: BE8D2000
	s_cbranch_execz 65481                                      // 0000000BC76C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s12, v2                                  // 0000000BC770: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC774: BF870091
	v_or_b32_e32 v36, s11, v33                                 // 0000000BC778: 3848420B
	.long 0xd4440001                                           // 0000000BC77C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 0000000BC780: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000BC784: 8B7E017E
	s_cbranch_execz 65474                                      // 0000000BC788: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_mov_b32_e32 v60, 0                                       // 0000000BC78C: 7E780280
	s_mov_b32 s1, 0                                            // 0000000BC790: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000BC794: BF870009
	v_lshl_add_u32 v34, s1, 2, v46                             // 0000000BC798: D6460022 04B90401
	s_add_i32 s4, s1, 8                                        // 0000000BC7A0: 81048801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000BC7A4: B6810078
	ds_load_2addr_b32 v[70:71], v34 offset1:1                  // 0000000BC7A8: D8DC0100 46000022
	ds_load_2addr_b32 v[72:73], v34 offset0:2 offset1:3        // 0000000BC7B0: D8DC0302 48000022
	ds_load_2addr_b32 v[74:75], v34 offset0:4 offset1:5        // 0000000BC7B8: D8DC0504 4A000022
	ds_load_2addr_b32 v[76:77], v34 offset0:6 offset1:7        // 0000000BC7C0: D8DC0706 4C000022
	v_mad_u64_u32 v[61:62], null, 0x44, s1, v[1:2]             // 0000000BC7C8: D6FE7C3D 040402FF 00000044
	s_mov_b32 s1, s4                                           // 0000000BC7D4: BE810004
	ds_load_2addr_b32 v[62:63], v61 offset1:17                 // 0000000BC7D8: D8DC1100 3E00003D
	ds_load_2addr_b32 v[64:65], v61 offset0:34 offset1:51      // 0000000BC7E0: D8DC3322 4000003D
	ds_load_2addr_b32 v[66:67], v61 offset0:68 offset1:85      // 0000000BC7E8: D8DC5544 4200003D
	ds_load_2addr_b32 v[68:69], v61 offset0:102 offset1:119    // 0000000BC7F0: D8DC7766 4400003D
	s_waitcnt lgkmcnt(7)                                       // 0000000BC7F8: BF89FC77
	v_fma_mixlo_f16 v61, v70, s6, 0                            // 0000000BC7FC: CC21003D 02000D46
	s_waitcnt lgkmcnt(6)                                       // 0000000BC804: BF89FC67
	v_fma_mixlo_f16 v70, v72, s6, 0                            // 0000000BC808: CC210046 02000D48
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BC810: BF870002
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC814: CC20003D 8A000F3D
	s_waitcnt lgkmcnt(3)                                       // 0000000BC81C: BF89FC37
	v_fma_mixlo_f16 v34, v62, s6, 0                            // 0000000BC820: CC210022 02000D3E
	v_fma_mixlo_f16 v62, v63, s6, 0                            // 0000000BC828: CC21003E 02000D3F
	v_fma_mixlo_f16 v63, v71, s6, 0                            // 0000000BC830: CC21003F 02000D47
	s_waitcnt lgkmcnt(2)                                       // 0000000BC838: BF89FC27
	v_fma_mixlo_f16 v64, v64, s6, 0                            // 0000000BC83C: CC210040 02000D40
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC844: CC200022 8A000F22
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC84C: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC854: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000BC85C: BF870214
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC860: CC200040 8A000F40
	v_fmac_f32_e32 v60, v61, v34                               // 0000000BC868: 5678453D
	v_fma_mixlo_f16 v34, v65, s6, 0                            // 0000000BC86C: CC210022 02000D41
	v_fma_mixlo_f16 v61, v73, s6, 0                            // 0000000BC874: CC21003D 02000D49
	v_fma_mix_f32 v65, v70, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC87C: CC200041 8A000F46
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BC884: BF870004
	v_fmac_f32_e32 v60, v63, v62                               // 0000000BC888: 56787D3F
	s_waitcnt lgkmcnt(1)                                       // 0000000BC88C: BF89FC17
	v_fma_mixlo_f16 v62, v66, s6, 0                            // 0000000BC890: CC21003E 02000D42
	v_fma_mixlo_f16 v63, v74, s6, 0                            // 0000000BC898: CC21003F 02000D4A
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC8A0: CC200022 8A000F22
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC8A8: CC20003D 8A000F3D
	v_fmac_f32_e32 v60, v65, v64                               // 0000000BC8B0: 56788141
	v_fma_mixlo_f16 v64, v67, s6, 0                            // 0000000BC8B4: CC210040 02000D43
	v_fma_mixlo_f16 v65, v75, s6, 0                            // 0000000BC8BC: CC210041 02000D4B
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC8C4: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC8CC: CC20003F 8A000F3F
	v_fmac_f32_e32 v60, v61, v34                               // 0000000BC8D4: 5678453D
	s_waitcnt lgkmcnt(0)                                       // 0000000BC8D8: BF89FC07
	v_fma_mixlo_f16 v34, v68, s6, 0                            // 0000000BC8DC: CC210022 02000D44
	v_fma_mixlo_f16 v61, v76, s6, 0                            // 0000000BC8E4: CC21003D 02000D4C
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC8EC: CC200040 8A000F40
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC8F4: CC200041 8A000F41
	v_fmac_f32_e32 v60, v63, v62                               // 0000000BC8FC: 56787D3F
	v_fma_mixlo_f16 v62, v69, s6, 0                            // 0000000BC900: CC21003E 02000D45
	v_fma_mixlo_f16 v63, v77, s6, 0                            // 0000000BC908: CC21003F 02000D4D
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC910: CC200022 8A000F22
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC918: CC20003D 8A000F3D
	v_fmac_f32_e32 v60, v65, v64                               // 0000000BC920: 56788141
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC924: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000BC92C: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BC934: BF870093
	v_fmac_f32_e32 v60, v61, v34                               // 0000000BC938: 5678453D
	v_fmac_f32_e32 v60, v63, v62                               // 0000000BC93C: 56787D3F
	s_cbranch_scc1 65428                                       // 0000000BC940: BFA2FF94 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1194>
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000BC944: 30424282
	v_mov_b32_e32 v61, v1                                      // 0000000BC948: 7E7A0301
	s_mov_b32 s14, 0                                           // 0000000BC94C: BE8E0080
	ds_load_b32 v62, v33 offset:17440                          // 0000000BC950: D8D84420 3E000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000BC958: CA10011E 2220011D
	s_waitcnt lgkmcnt(0)                                       // 0000000BC960: BF89FC07
	v_mul_f32_e32 v60, v60, v62                                // 0000000BC964: 10787D3C
	v_mov_b32_e32 v62, v35                                     // 0000000BC968: 7E7C0323
	s_nop 0                                                    // 0000000BC96C: BF800000
	s_nop 0                                                    // 0000000BC970: BF800000
	s_nop 0                                                    // 0000000BC974: BF800000
	s_nop 0                                                    // 0000000BC978: BF800000
	s_nop 0                                                    // 0000000BC97C: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000BC980: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000BC988: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000BC990: 4A7C7CC1
	.long 0xd7000121                                           // 0000000BC994: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000BC998: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000BC99C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000BC9A0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000BC9A8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000BC9AC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000BC9B0: 4A7A7AFF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000BC9B8: 8C0E0E04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BC9BC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 0000000BC9C0: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000BC9C4: 917E0E7E
	s_cbranch_execnz 65517                                     // 0000000BC9C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1380>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000BC9CC: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BC9D0: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 0000000BC9D4: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 0000000BC9DC: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 0000000BC9E8: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 0000000BC9F4: DC960000 007C2421
	s_branch 65317                                             // 0000000BC9FC: BFA0FF25 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000BCA00: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 0000000BCA08: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000BCA0C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000BCA10: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000BCA18: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000BCA1C: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000BCA24: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000BCA2C: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000BCA30: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000BCA34: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000BCA3C: A0010401
	s_mov_b32 s4, 0                                            // 0000000BCA40: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000BCA44: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000BCA48: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000BCA4C: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000BCA50: BF870585
	.long 0xd71c001d                                           // 0000000BCA54: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000BCA58: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000BCA5C: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000BCA60: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000BCA68: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000BCA6C: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000BCA74: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000000BCA78: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000BCA7C: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000BCA88: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000BCA90: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BCA98: BF870001
	.long 0xd4490001                                           // 0000000BCA9C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000BCAA0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000BCAA8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000BCAAC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000BCAB0: 1040411E
	ds_store_b32 v29, v32                                      // 0000000BCAB4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000BCABC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BCAC4: 917E047E
	s_cbranch_execnz 65519                                     // 0000000BCAC8: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1488>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BCACC: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000BCAD0: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 0000000BCAD8: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 0000000BCAE0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BCAE4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BCAE8: BF89FC07
	s_barrier                                                  // 0000000BCAEC: BFBD0000
	buffer_gl0_inv                                             // 0000000BCAF0: E0AC0000 00000000
	s_nop 0                                                    // 0000000BCAF8: BF800000
	s_nop 0                                                    // 0000000BCAFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BCB00: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 0000000BCB08: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BCB10: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BCB18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BCB1C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000BCB24: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BCB28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BCB30: BF870004
	.long 0xd4490004                                           // 0000000BCB34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BCB38: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BCB40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BCB44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BCB48: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 0000000BCB4C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000BCB54: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BCB5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BCB60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1500>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BCB64: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000BCB68: BF89FC07
	s_barrier                                                  // 0000000BCB6C: BFBD0000
	buffer_gl0_inv                                             // 0000000BCB70: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000BCB78: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000000BCB80: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000000BCB88: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000000BCB90: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000BCB98: 7E780300
	s_mov_b32 s4, 0                                            // 0000000BCB9C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BCBA0: BF840001
	s_nop 0                                                    // 0000000BCBA4: BF800000
	s_nop 0                                                    // 0000000BCBA8: BF800000
	s_nop 0                                                    // 0000000BCBAC: BF800000
	s_nop 0                                                    // 0000000BCBB0: BF800000
	s_nop 0                                                    // 0000000BCBB4: BF800000
	s_nop 0                                                    // 0000000BCBB8: BF800000
	s_nop 0                                                    // 0000000BCBBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BCBC0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000BCBC4: 327A7884
	.long 0xd4490001                                           // 0000000BCBC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000BCBCC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000BCBD4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000BCBD8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BCBE4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000BCBE8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000BCBF0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000BCBF8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000BCC00: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000BCC08: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000BCC10: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000BCC18: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000BCC20: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000BCC24: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BCC30: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000BCC34: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000BCC38: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000BCC40: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000BCC44: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000BCC48: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000BCC4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCC50: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000BCC54: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000BCC58: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000BCC5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCC60: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000BCC64: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000BCC70: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000BCC78: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BCC80: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BCC84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000BCC88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BCC8C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000000BCC90: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BCC98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BCCA0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BCCA4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BCCA8: BF89FC07
	s_barrier                                                  // 0000000BCCAC: BFBD0000
	buffer_gl0_inv                                             // 0000000BCCB0: E0AC0000 00000000
	s_nop 0                                                    // 0000000BCCB8: BF800000
	s_nop 0                                                    // 0000000BCCBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BCCC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 0000000BCCC8: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BCCD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BCCD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BCCDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BCCE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BCCE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BCCF0: BF870004
	.long 0xd4490004                                           // 0000000BCCF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BCCF8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BCD00: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BCD04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BCD08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BCD0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BCD14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BCD1C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BCD20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BCD24: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000BCD28: BF89FC07
	s_barrier                                                  // 0000000BCD2C: BFBD0000
	buffer_gl0_inv                                             // 0000000BCD30: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000BCD38: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000000BCD40: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000000BCD48: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000000BCD50: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000BCD58: 7E780300
	s_mov_b32 s4, 0                                            // 0000000BCD5C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BCD60: BF840001
	s_nop 0                                                    // 0000000BCD64: BF800000
	s_nop 0                                                    // 0000000BCD68: BF800000
	s_nop 0                                                    // 0000000BCD6C: BF800000
	s_nop 0                                                    // 0000000BCD70: BF800000
	s_nop 0                                                    // 0000000BCD74: BF800000
	s_nop 0                                                    // 0000000BCD78: BF800000
	s_nop 0                                                    // 0000000BCD7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BCD80: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000BCD84: 327A7884
	.long 0xd4490001                                           // 0000000BCD88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000BCD8C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000BCD94: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000BCD98: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BCDA4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000BCDA8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000BCDB0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000BCDB8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000BCDC0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000BCDC8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000BCDD0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000BCDD8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000BCDE0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000BCDE4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BCDF0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000BCDF4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000BCDF8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000BCE00: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000BCE04: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000BCE08: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000BCE0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCE10: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000BCE14: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000BCE18: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000BCE1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCE20: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000BCE24: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000BCE30: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000BCE38: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BCE40: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BCE44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1780>
	s_set_inst_prefetch_distance 0x2                           // 0000000BCE48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BCE4C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000000BCE50: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BCE58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BCE60: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BCE64: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BCE68: BF89FC07
	s_barrier                                                  // 0000000BCE6C: BFBD0000
	buffer_gl0_inv                                             // 0000000BCE70: E0AC0000 00000000
	s_nop 0                                                    // 0000000BCE78: BF800000
	s_nop 0                                                    // 0000000BCE7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BCE80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000000BCE88: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BCE90: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BCE98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BCE9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BCEA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BCEA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BCEB0: BF870004
	.long 0xd4490004                                           // 0000000BCEB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BCEB8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BCEC0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BCEC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BCEC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BCECC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BCED4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BCEDC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BCEE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1880>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BCEE4: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000BCEE8: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000BCEF0: BF89FC07
	s_barrier                                                  // 0000000BCEF4: BFBD0000
	buffer_gl0_inv                                             // 0000000BCEF8: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000BCF00: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 0000000BCF04: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 0000000BCF0C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 0000000BCF14: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 0000000BCF1C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000BCF24: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BCF28: BF840001
	s_nop 0                                                    // 0000000BCF2C: BF800000
	s_nop 0                                                    // 0000000BCF30: BF800000
	s_nop 0                                                    // 0000000BCF34: BF800000
	s_nop 0                                                    // 0000000BCF38: BF800000
	s_nop 0                                                    // 0000000BCF3C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000BCF40: 327C7A84
	.long 0xd4490001                                           // 0000000BCF44: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000BCF48: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BCF50: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000BCF54: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000BCF58: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BCF64: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000BCF68: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000BCF70: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000BCF78: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000BCF80: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000BCF88: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000BCF90: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000BCF98: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000BCFA0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000BCFA4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BCFA8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000BCFAC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000BCFB8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000BCFC0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000BCFC4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000BCFC8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000BCFCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCFD0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000BCFD4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000BCFD8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000BCFDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BCFE0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000BCFE4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000BCFF0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000BCFF8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BD000: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BD004: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_set_inst_prefetch_distance 0x2                           // 0000000BD008: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BD00C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000BD010: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BD018: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BD020: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BD024: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BD028: BF89FC07
	s_barrier                                                  // 0000000BD02C: BFBD0000
	buffer_gl0_inv                                             // 0000000BD030: E0AC0000 00000000
	s_nop 0                                                    // 0000000BD038: BF800000
	s_nop 0                                                    // 0000000BD03C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BD040: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000000BD048: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BD050: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BD058: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BD05C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BD064: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BD068: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BD070: BF870004
	.long 0xd4490004                                           // 0000000BD074: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BD078: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BD080: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BD084: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BD088: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BD08C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BD094: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BD09C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BD0A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BD0A4: 8C7E0A7E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000BD0A8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000BD0B0: BF89FC07
	s_barrier                                                  // 0000000BD0B4: BFBD0000
	buffer_gl0_inv                                             // 0000000BD0B8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 0000000BD0C0: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 0000000BD0C8: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 0000000BD0D0: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 0000000BD0D8: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000BD0E0: 7E780300
	s_mov_b32 s4, 0                                            // 0000000BD0E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BD0E8: BF840001
	s_nop 0                                                    // 0000000BD0EC: BF800000
	s_nop 0                                                    // 0000000BD0F0: BF800000
	s_nop 0                                                    // 0000000BD0F4: BF800000
	s_nop 0                                                    // 0000000BD0F8: BF800000
	s_nop 0                                                    // 0000000BD0FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD100: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000BD104: 327A7884
	.long 0xd4490001                                           // 0000000BD108: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000BD10C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000BD114: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000BD118: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BD124: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000BD128: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000BD130: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000BD138: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000BD140: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000BD148: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000BD150: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000BD158: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000BD160: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000BD164: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BD170: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000BD174: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000BD178: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000BD180: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000BD184: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000BD188: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000BD18C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD190: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000BD194: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000BD198: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000BD19C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD1A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000BD1A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000BD1B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000BD1B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BD1C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BD1C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_set_inst_prefetch_distance 0x2                           // 0000000BD1C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BD1CC: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 0000000BD1D0: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BD1D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BD1E0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BD1E4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BD1E8: BF89FC07
	s_barrier                                                  // 0000000BD1EC: BFBD0000
	buffer_gl0_inv                                             // 0000000BD1F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000BD1F8: BF800000
	s_nop 0                                                    // 0000000BD1FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BD200: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 0000000BD208: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BD210: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BD218: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BD21C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BD224: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BD228: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BD230: BF870004
	.long 0xd4490004                                           // 0000000BD234: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BD238: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BD240: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BD244: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BD248: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BD24C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BD254: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BD25C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BD260: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BD264: 8C7E0A7E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000000BD268: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000BD270: BF89FC07
	s_barrier                                                  // 0000000BD274: BFBD0000
	buffer_gl0_inv                                             // 0000000BD278: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000000BD280: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000000BD284: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000000BD28C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000000BD294: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000000BD29C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000BD2A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BD2A8: BF840001
	s_nop 0                                                    // 0000000BD2AC: BF800000
	s_nop 0                                                    // 0000000BD2B0: BF800000
	s_nop 0                                                    // 0000000BD2B4: BF800000
	s_nop 0                                                    // 0000000BD2B8: BF800000
	s_nop 0                                                    // 0000000BD2BC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 0000000BD2C0: 327C7884
	.long 0xd4490001                                           // 0000000BD2C4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000BD2C8: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BD2D0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000BD2D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000BD2D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BD2E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000BD2E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000BD2F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000BD2F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000BD300: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000BD308: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000BD310: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000BD318: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000BD320: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000BD324: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BD328: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000BD32C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000BD338: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000BD340: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000BD344: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000BD348: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000BD34C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD350: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000BD354: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000BD358: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000BD35C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD360: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000000BD364: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 0000000BD370: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000BD374: BF870002
	v_mov_b32_e32 v60, v63                                     // 0000000BD378: 7E78033F
	ds_store_b32 v62, v70                                      // 0000000BD37C: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BD384: 917E047E
	s_cbranch_execnz 65485                                     // 0000000BD388: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_set_inst_prefetch_distance 0x2                           // 0000000BD38C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BD390: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000000BD394: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BD39C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BD3A4: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BD3A8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BD3AC: BF89FC07
	s_barrier                                                  // 0000000BD3B0: BFBD0000
	buffer_gl0_inv                                             // 0000000BD3B4: E0AC0000 00000000
	s_nop 0                                                    // 0000000BD3BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BD3C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 0000000BD3C8: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BD3D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BD3D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BD3DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BD3E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BD3E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BD3F0: BF870004
	.long 0xd4490004                                           // 0000000BD3F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BD3F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BD400: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BD404: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BD408: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BD40C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BD414: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BD41C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BD420: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BD424: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000000BD428: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000BD430: BF89FC07
	s_barrier                                                  // 0000000BD434: BFBD0000
	buffer_gl0_inv                                             // 0000000BD438: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000000BD440: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000000BD448: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000000BD450: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000000BD458: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000BD460: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000BD464: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BD468: BF840001
	s_nop 0                                                    // 0000000BD46C: BF800000
	s_nop 0                                                    // 0000000BD470: BF800000
	s_nop 0                                                    // 0000000BD474: BF800000
	s_nop 0                                                    // 0000000BD478: BF800000
	s_nop 0                                                    // 0000000BD47C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD480: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000BD484: 327C7A84
	.long 0xd4490001                                           // 0000000BD488: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000BD48C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000BD494: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000BD498: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BD4A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000BD4A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000BD4B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000BD4B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000BD4C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000BD4C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000BD4D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000BD4D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000BD4E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000BD4E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BD4E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000BD4EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000BD4F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000BD500: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000BD504: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000BD508: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000BD50C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD510: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000BD514: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000BD518: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000BD51C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD520: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000BD524: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000BD530: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000BD538: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BD540: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BD544: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e80>
	s_set_inst_prefetch_distance 0x2                           // 0000000BD548: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BD54C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 0000000BD550: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BD558: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BD560: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BD564: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BD568: BF89FC07
	s_barrier                                                  // 0000000BD56C: BFBD0000
	buffer_gl0_inv                                             // 0000000BD570: E0AC0000 00000000
	s_nop 0                                                    // 0000000BD578: BF800000
	s_nop 0                                                    // 0000000BD57C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BD580: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000BD588: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BD590: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BD598: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BD59C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BD5A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BD5A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BD5B0: BF870004
	.long 0xd4490004                                           // 0000000BD5B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BD5B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BD5C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BD5C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BD5C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BD5CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BD5D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BD5DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BD5E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BD5E4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000BD5E8: BF89FC07
	s_barrier                                                  // 0000000BD5EC: BFBD0000
	buffer_gl0_inv                                             // 0000000BD5F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 0000000BD5F8: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 0000000BD600: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 0000000BD608: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 0000000BD610: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000BD618: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000BD61C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BD620: BF840001
	s_nop 0                                                    // 0000000BD624: BF800000
	s_nop 0                                                    // 0000000BD628: BF800000
	s_nop 0                                                    // 0000000BD62C: BF800000
	s_nop 0                                                    // 0000000BD630: BF800000
	s_nop 0                                                    // 0000000BD634: BF800000
	s_nop 0                                                    // 0000000BD638: BF800000
	s_nop 0                                                    // 0000000BD63C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD640: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000BD644: 327C7A84
	.long 0xd4490001                                           // 0000000BD648: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000BD64C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000BD654: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000BD658: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BD664: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000BD668: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000BD670: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000BD678: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000BD680: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000BD688: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000BD690: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000BD698: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000BD6A0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000BD6A4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BD6A8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000BD6AC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000BD6B8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000BD6C0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000BD6C4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000BD6C8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000BD6CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD6D0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000BD6D4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000BD6D8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000BD6DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD6E0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000BD6E4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000BD6F0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000BD6F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BD700: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BD704: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_set_inst_prefetch_distance 0x2                           // 0000000BD708: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BD70C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000BD710: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000BD718: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000BD720: 7E420326
	s_mov_b32 s10, 0                                           // 0000000BD724: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000BD728: BF89FC07
	s_barrier                                                  // 0000000BD72C: BFBD0000
	buffer_gl0_inv                                             // 0000000BD730: E0AC0000 00000000
	s_nop 0                                                    // 0000000BD738: BF800000
	s_nop 0                                                    // 0000000BD73C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000BD740: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000000BD748: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000BD750: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000BD758: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000BD75C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000BD764: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000BD768: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000BD770: BF870004
	.long 0xd4490004                                           // 0000000BD774: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000BD778: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000BD780: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000BD784: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000BD788: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000BD78C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000BD794: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000BD79C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000BD7A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2140>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000BD7A4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000BD7A8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000BD7B0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000BD7B8: BF89FC07
	s_barrier                                                  // 0000000BD7BC: BFBD0000
	buffer_gl0_inv                                             // 0000000BD7C0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 0000000BD7C8: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 0000000BD7D0: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000BD7D8: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 0000000BD7E0: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000BD7E8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000BD7EC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000BD7F0: BF840001
	s_nop 0                                                    // 0000000BD7F4: BF800000
	s_nop 0                                                    // 0000000BD7F8: BF800000
	s_nop 0                                                    // 0000000BD7FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000BD800: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000BD804: 327A7884
	.long 0xd4490001                                           // 0000000BD808: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000BD80C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000BD814: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000BD818: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000BD824: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000BD828: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000BD830: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000BD838: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000BD840: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000BD848: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000BD850: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000BD858: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000BD860: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000BD864: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000BD870: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000BD874: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000BD878: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000BD880: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000BD884: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000BD888: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000BD88C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD890: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000BD894: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000BD898: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000BD89C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BD8A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000BD8A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000BD8B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000BD8B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000BD8C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000BD8C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2200>
	s_set_inst_prefetch_distance 0x2                           // 0000000BD8C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000BD8CC: 8C7E047E
	.long 0xd7000107                                           // 0000000BD8D0: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000BD8D4: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BD8DC: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000BD8E0: D5207C08 00061080
	.long 0xd7000109                                           // 0000000BD8E8: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000BD8EC: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000BD8F4: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000BD8FC: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000BD900: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BD908: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000BD90C: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000BD914: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000BD918: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000BD920: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000BD928: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000BD92C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BD934: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000BD938: D5207C10 00062080
	.long 0xd7000111                                           // 0000000BD940: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000BD944: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000BD94C: D5207C12 00062480
	.long 0xd7000113                                           // 0000000BD954: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000BD958: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BD960: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000BD964: D5207C14 00062880
	.long 0xd7000115                                           // 0000000BD96C: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000BD970: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000BD978: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000BD980: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000BD984: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000BD98C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000BD990: D5207C18 00063080
	.long 0xd7000119                                           // 0000000BD998: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000BD99C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000BD9A4: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000BD9AC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000BD9B0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000BD9B8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000BD9BC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000BD9C4: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000BD9C8: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000BD9CC: BF062105
	s_barrier                                                  // 0000000BD9D0: BFBD0000
	buffer_gl0_inv                                             // 0000000BD9D4: E0AC0000 00000000
	s_cbranch_scc0 63477                                       // 0000000BD9DC: BFA1F7F5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b4>
	v_mov_b32_e32 v4, v38                                      // 0000000BD9E0: 7E080326
	s_add_u32 s0, s28, s20                                     // 0000000BD9E4: 8000141C
	.long 0xd73c0000                                           // 0000000BD9E8: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000BD9EC: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000BD9F0: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000BD9F4: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000BD9F8: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000BD9FC: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000BDA00: 82010103
	.long 0xd7006a00                                           // 0000000BDA04: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000BDA08: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000BDA0C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000BDA10: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000BDA18: BE810080
	.long 0xd7006a00                                           // 0000000BDA1C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 0000000BDA20: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000BDA24: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000BDA2C: BF870092
	.long 0xd7006a00                                           // 0000000BDA30: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000BDA34: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000BDA38: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 0000000BDA40: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000BDA48: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000000BDA50: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000BDA58: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000BDA5C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000BDA64: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000BDA68: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000BDA6C: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000BDA74: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000BDA78: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000BDA80: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000BDA88: 917E017E
	s_cbranch_execnz 65516                                     // 0000000BDA8C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi14ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	s_endpgm                                                   // 0000000BDA90: BFB00000
		...

