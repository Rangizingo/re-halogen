000000000023f800 <_ZN7halogen12_GLOBAL__N_118k_ngram_ctx_updateEPKiPxi>:
; _ZN7halogen12_GLOBAL__N_118k_ngram_ctx_updateEPKiPxi():
	v_or_b32_e32 v0, s2, v0                                    // 00000023F800: 38000002
	s_mov_b32 s2, exec_lo                                      // 00000023F804: BE82007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000023F808: BF870001
	v_cmpx_eq_u32_e32 0, v0                                    // 00000023F80C: 7D940080
	s_cbranch_execz 62                                         // 00000023F810: BFA5003E <_ZN7halogen12_GLOBAL__N_118k_ngram_ctx_updateEPKiPxi+0x10c>
	s_clause 0x1                                               // 00000023F814: BF850001
	s_load_b32 s4, s[0:1], 0x10                                // 00000023F818: F4000100 F8000010
	s_load_b128 s[0:3], s[0:1], null                           // 00000023F820: F4080000 F8000000
	s_waitcnt lgkmcnt(0)                                       // 00000023F828: BF89FC07
	s_cmp_lt_i32 s4, 2                                         // 00000023F82C: BF048204
	s_cbranch_scc0 9                                           // 00000023F830: BFA10009 <_ZN7halogen12_GLOBAL__N_118k_ngram_ctx_updateEPKiPxi+0x58>
	s_ashr_i32 s5, s4, 31                                      // 00000023F834: 86059F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000023F838: BF870499
	s_lshl_b64 s[6:7], s[4:5], 3                               // 00000023F83C: 84868304
	s_add_u32 s6, s2, s6                                       // 00000023F840: 80060602
	s_addc_u32 s7, s3, s7                                      // 00000023F844: 82070703
	s_load_b64 s[6:7], s[6:7], null                            // 00000023F848: F4040183 F8000000
	s_cbranch_execz 1                                          // 00000023F850: BFA50001 <_ZN7halogen12_GLOBAL__N_118k_ngram_ctx_updateEPKiPxi+0x58>
	s_branch 12                                                // 00000023F854: BFA0000C <_ZN7halogen12_GLOBAL__N_118k_ngram_ctx_updateEPKiPxi+0x88>
	s_mov_b32 s5, 0                                            // 00000023F858: BE850080
	s_waitcnt lgkmcnt(0)                                       // 00000023F85C: BF89FC07
	s_lshl_b64 s[6:7], s[4:5], 2                               // 00000023F860: 84868204
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000023F864: BF870009
	s_add_u32 s5, s0, s6                                       // 00000023F868: 80050600
	s_addc_u32 s7, s1, s7                                      // 00000023F86C: 82070701
	s_add_u32 s6, s5, -8                                       // 00000023F870: 8006C805
	s_addc_u32 s7, s7, -1                                      // 00000023F874: 8207C107
	s_load_b32 s6, s[6:7], null                                // 00000023F878: F4000183 F8000000
	s_waitcnt lgkmcnt(0)                                       // 00000023F880: BF89FC07
	s_ashr_i32 s7, s6, 31                                      // 00000023F884: 86079F06
	s_cmp_gt_i32 s4, 0                                         // 00000023F888: BF028004
	s_mov_b32 s10, 0                                           // 00000023F88C: BE8A0080
	s_cbranch_scc1 10                                          // 00000023F890: BFA2000A <_ZN7halogen12_GLOBAL__N_118k_ngram_ctx_updateEPKiPxi+0xbc>
	s_ashr_i32 s5, s4, 31                                      // 00000023F894: 86059F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000023F898: BF870499
	s_lshl_b64 s[8:9], s[4:5], 3                               // 00000023F89C: 84888304
	s_add_u32 s8, s2, s8                                       // 00000023F8A0: 80080802
	s_addc_u32 s9, s3, s9                                      // 00000023F8A4: 82090903
	s_load_b64 s[8:9], s[8:9], 0x8                             // 00000023F8A8: F4040204 F8000008
	s_and_not1_b32 vcc_lo, exec_lo, s10                        // 00000023F8B0: 916A0A7E
	s_cbranch_vccz 1                                           // 00000023F8B4: BFA30001 <_ZN7halogen12_GLOBAL__N_118k_ngram_ctx_updateEPKiPxi+0xbc>
	s_branch 12                                                // 00000023F8B8: BFA0000C <_ZN7halogen12_GLOBAL__N_118k_ngram_ctx_updateEPKiPxi+0xec>
	s_mov_b32 s5, 0                                            // 00000023F8BC: BE850080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000023F8C0: BF870499
	s_lshl_b64 s[4:5], s[4:5], 2                               // 00000023F8C4: 84848204
	s_add_u32 s0, s0, s4                                       // 00000023F8C8: 80000400
	s_addc_u32 s1, s1, s5                                      // 00000023F8CC: 82010501
	s_add_u32 s0, s0, -4                                       // 00000023F8D0: 8000C400
	s_addc_u32 s1, s1, -1                                      // 00000023F8D4: 8201C101
	s_waitcnt lgkmcnt(0)                                       // 00000023F8D8: BF89FC07
	s_load_b32 s8, s[0:1], null                                // 00000023F8DC: F4000200 F8000000
	s_waitcnt lgkmcnt(0)                                       // 00000023F8E4: BF89FC07
	s_ashr_i32 s9, s8, 31                                      // 00000023F8E8: 86099F08
	s_waitcnt lgkmcnt(0)                                       // 00000023F8EC: BF89FC07
	v_dual_mov_b32 v0, s6 :: v_dual_mov_b32 v1, s7             // 00000023F8F0: CA100006 00000007
	v_dual_mov_b32 v2, s8 :: v_dual_mov_b32 v3, s9             // 00000023F8F8: CA100008 02020009
	v_mov_b32_e32 v4, 0                                        // 00000023F900: 7E080280
	global_store_b128 v4, v[0:3], s[2:3]                       // 00000023F904: DC760000 00020004
	s_endpgm                                                   // 00000023F90C: BFB00000
		...

