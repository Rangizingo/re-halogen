000000000023c900 <_ZN7halogen12_GLOBAL__N_112k_ngram_histEPKiPKxiPx>:
; _ZN7halogen12_GLOBAL__N_112k_ngram_histEPKiPKxiPx():
	s_clause 0x1                                               // 00000023C900: BF850001
	s_load_b32 s8, s[0:1], 0x10                                // 00000023C904: F4000200 F8000010
	s_load_b32 s3, s[0:1], 0x2c                                // 00000023C90C: F40000C0 F800002C
	s_waitcnt lgkmcnt(0)                                       // 00000023C914: BF89FC07
	s_add_i32 s8, s8, 2                                        // 00000023C918: 81088208
	s_add_u32 s4, s0, 32                                       // 00000023C91C: 8004A000
	s_addc_u32 s5, s1, 0                                       // 00000023C920: 82058001
	s_and_b32 s9, s3, 0xffff                                   // 00000023C924: 8B09FF03 0000FFFF
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000023C92C: BF870009
	v_mad_u64_u32 v[0:1], null, s2, s9, v[0:1]                 // 00000023C930: D6FE7C00 04001202
	s_mov_b32 s2, exec_lo                                      // 00000023C938: BE82007E
	.long 0xd4c4007e                                           // 00000023C93C: D4C4007E
	v_cndmask_b32_e32 v1, s8, v0, vcc_lo                       // 00000023C940: 02020008
	s_cbranch_execz 62                                         // 00000023C944: BFA5003E <_ZN7halogen12_GLOBAL__N_112k_ngram_histEPKiPKxiPx+0x140>
	s_load_b32 s10, s[4:5], null                               // 00000023C948: F4000282 F8000000
	s_clause 0x1                                               // 00000023C950: BF850001
	s_load_b128 s[4:7], s[0:1], null                           // 00000023C954: F4080100 F8000000
	s_load_b64 s[2:3], s[0:1], 0x18                            // 00000023C95C: F4040080 F8000018
	v_mov_b32_e32 v4, 0                                        // 00000023C964: 7E080280
	s_waitcnt lgkmcnt(0)                                       // 00000023C968: BF89FC07
	s_mul_i32 s1, s10, s9                                      // 00000023C96C: 9601090A
	s_mov_b32 s9, 0                                            // 00000023C970: BE890080
	s_set_inst_prefetch_distance 0x1                           // 00000023C974: BF840001
	s_branch 18                                                // 00000023C978: BFA00012 <_ZN7halogen12_GLOBAL__N_112k_ngram_histEPKiPKxiPx+0xc4>
	s_nop 0                                                    // 00000023C97C: BF800000
	s_or_b32 exec_lo, exec_lo, s0                              // 00000023C980: 8C7E007E
	.long 0xd73c0005                                           // 00000023C984: D73C0005
	v_cndmask_b32_e32 v1, 3, v0, vcc_lo                        // 00000023C988: 02020083
	v_add_nc_u32_e32 v0, s1, v0                                // 00000023C98C: 4A000001
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000023C990: BF870191
	v_cmp_le_i32_e32 vcc_lo, s8, v0                            // 00000023C994: 7C860008
	.long 0xd7000005                                           // 00000023C998: D7000005
	v_cndmask_b32_e32 v1, s2, v5, vcc_lo                       // 00000023C99C: 02020A02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000023C9A0: BF870001
	v_add_co_ci_u32_e64 v6, null, s3, v6, s0                   // 00000023C9A4: D5207C06 00020C03
	s_or_b32 s9, vcc_lo, s9                                    // 00000023C9AC: 8C09096A
	s_waitcnt vmcnt(0)                                         // 00000023C9B0: BF8903F7
	global_store_b64 v[5:6], v[2:3], off                       // 00000023C9B4: DC6E0000 007C0205
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 00000023C9BC: 917E097E
	s_cbranch_execz 31                                         // 00000023C9C0: BFA5001F <_ZN7halogen12_GLOBAL__N_112k_ngram_histEPKiPKxiPx+0x140>
	s_mov_b32 s0, exec_lo                                      // 00000023C9C4: BE80007E
	v_cmpx_lt_i32_e32 1, v0                                    // 00000023C9C8: 7D820081
	s_xor_b32 s0, exec_lo, s0                                  // 00000023C9CC: 8D00007E
	s_cbranch_execz 13                                         // 00000023C9D0: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_ngram_histEPKiPKxiPx+0x108>
	v_mov_b32_e32 v1, v4                                       // 00000023C9D4: 7E020304
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023C9D8: BF870091
	.long 0xd73c0002                                           // 00000023C9DC: D73C0002
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000023C9E0: 02020082
	.long 0xd7006a02                                           // 00000023C9E4: D7006A02
	v_cndmask_b32_e32 v1, s4, v2, vcc_lo                       // 00000023C9E8: 02020404
	s_delay_alu instid0(VALU_DEP_1)                            // 00000023C9EC: BF870001
	v_add_co_ci_u32_e64 v3, null, s5, v3, vcc_lo               // 00000023C9F0: D5207C03 01AA0605
	global_load_b32 v2, v[2:3], off offset:-8                  // 00000023C9F8: DC521FF8 027C0002
	s_waitcnt vmcnt(0)                                         // 00000023CA00: BF8903F7
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000023CA04: 3406049F
	s_and_not1_saveexec_b32 s0, s0                             // 00000023CA08: BE803000
	s_cbranch_execz 65500                                      // 00000023CA0C: BFA5FFDC <_ZN7halogen12_GLOBAL__N_112k_ngram_histEPKiPKxiPx+0x80>
	v_ashrrev_i32_e32 v1, 31, v0                               // 00000023CA10: 3402009F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023CA14: BF870091
	.long 0xd73c0002                                           // 00000023CA18: D73C0002
	v_cndmask_b32_e32 v1, 3, v0, vcc_lo                        // 00000023CA1C: 02020083
	.long 0xd7006a02                                           // 00000023CA20: D7006A02
	v_cndmask_b32_e32 v1, s6, v2, vcc_lo                       // 00000023CA24: 02020406
	s_delay_alu instid0(VALU_DEP_1)                            // 00000023CA28: BF870001
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 00000023CA2C: D5207C03 01AA0607
	global_load_b64 v[2:3], v[2:3], off                        // 00000023CA34: DC560000 027C0002
	s_branch 65488                                             // 00000023CA3C: BFA0FFD0 <_ZN7halogen12_GLOBAL__N_112k_ngram_histEPKiPKxiPx+0x80>
	s_set_inst_prefetch_distance 0x2                           // 00000023CA40: BF840002
	s_endpgm                                                   // 00000023CA44: BFB00000
		...

