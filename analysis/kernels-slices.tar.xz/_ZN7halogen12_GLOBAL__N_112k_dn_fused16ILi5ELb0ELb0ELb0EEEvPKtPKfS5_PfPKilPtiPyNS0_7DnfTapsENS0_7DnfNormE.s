000000000003b500 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE>:
; _ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE():
	s_clause 0x1                                               // 00000003B500: BF850001
	s_load_b256 s[20:27], s[0:1], 0x20                         // 00000003B504: F40C0500 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 00000003B50C: F40C0200 F8000000
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 5, v0       // 00000003B514: CA220080 02020085
	s_ashr_i32 s3, s2, 31                                      // 00000003B51C: 86039F02
	s_mov_b32 s28, 0                                           // 00000003B520: BE9C0080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003B524: BF870001
	v_and_b32_e32 v3, 0x200, v3                                // 00000003B528: 360606FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 00000003B530: BF89FC07
	s_load_b32 s16, s[20:21], null                             // 00000003B534: F400040A F8000000
	v_readfirstlane_b32 s20, v0                                // 00000003B53C: 7E280500
	s_lshl_b64 s[4:5], s[22:23], 2                             // 00000003B540: 84848216
	s_lshr_b32 s21, s20, 5                                     // 00000003B544: 85158514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000003B548: BF8704D9
	s_lshl_b32 s33, s21, 4                                     // 00000003B54C: 84218415
	s_add_u32 s4, s14, s4                                      // 00000003B550: 8004040E
	v_and_or_b32 v1, v0, 15, s33                               // 00000003B554: D6570001 00851F00
	s_addc_u32 s5, s15, s5                                     // 00000003B55C: 8205050F
	s_lshl_b64 s[6:7], s[2:3], 16                              // 00000003B560: 84869002
	s_add_u32 s4, s4, s6                                       // 00000003B564: 80040604
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003B568: BF870001
	.long 0xd73c0001                                           // 00000003B56C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000003B570: 02020282
	s_addc_u32 s5, s5, s7                                      // 00000003B574: 82050705
	s_waitcnt lgkmcnt(0)                                       // 00000003B578: BF89FC07
	s_mul_i32 s14, s16, 0x9000000                              // 00000003B57C: 960EFF10 09000000
	s_mul_hi_i32 s15, s16, 0x9000000                           // 00000003B584: 970FFF10 09000000
	s_add_u32 s4, s4, s14                                      // 00000003B58C: 80040E04
	s_addc_u32 s5, s5, s15                                     // 00000003B590: 82050F05
	.long 0xd7006a01                                           // 00000003B594: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000003B598: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000003B59C: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000003B5A0: D5207C02 01AA0405
	s_or_b32 s5, s21, s2                                       // 00000003B5A8: 8C050215
	.long 0xd7006abb                                           // 00000003B5AC: D7006ABB
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 00000003B5B0: 02020701
	v_add_co_ci_u32_e64 v188, null, 0, v2, vcc_lo              // 00000003B5B4: D5207CBC 01AA0480
	s_cselect_b32 s38, 0, -1                                   // 00000003B5BC: 9826C180
	.long 0xd7006a09                                           // 00000003B5C0: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v187, vcc_lo                 // 00000003B5C4: 020376FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003B5CC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v188, vcc_lo             // 00000003B5D0: D5207C0A 01AB7880
	.long 0xd7006a34                                           // 00000003B5D8: D7006A34
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000003B5DC: 0201FFBB
	.long 0x00002000                                           // 00000003B5E0: 00002000
	v_add_co_ci_u32_e64 v53, null, 0, v188, vcc_lo             // 00000003B5E4: D5207C35 01AB7880
	.long 0xd7006a0d                                           // 00000003B5EC: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v187, vcc_lo                 // 00000003B5F0: 020376FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003B5F8: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v188, vcc_lo             // 00000003B5FC: D5207C0E 01AB7880
	.long 0xd7006a0f                                           // 00000003B604: D7006A0F
	v_cndmask_b32_e32 v1, 0x3000, v187, vcc_lo                 // 00000003B608: 020376FF 00003000
	v_add_co_ci_u32_e64 v16, null, 0, v188, vcc_lo             // 00000003B610: D5207C10 01AB7880
	.long 0xd7006a3c                                           // 00000003B618: D7006A3C
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000003B61C: 0201FFBB
	.long 0x00004000                                           // 00000003B620: 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003B624: BF870001
	v_add_co_ci_u32_e64 v61, null, 0, v188, vcc_lo             // 00000003B628: D5207C3D 01AB7880
	.long 0xd7006a11                                           // 00000003B630: D7006A11
	v_cndmask_b32_e32 v1, 0x4000, v187, vcc_lo                 // 00000003B634: 020376FF 00004000
	s_clause 0x7                                               // 00000003B63C: BF850007
	global_load_b32 v5, v[187:188], off                        // 00000003B640: DC520000 057C00BB
	global_load_b32 v6, v[187:188], off offset:1024            // 00000003B648: DC520400 067C00BB
	global_load_b32 v7, v[187:188], off offset:2048            // 00000003B650: DC520800 077C00BB
	global_load_b32 v8, v[187:188], off offset:3072            // 00000003B658: DC520C00 087C00BB
	global_load_b32 v2, v[9:10], off offset:1024               // 00000003B660: DC520400 027C0009
	global_load_b32 v3, v[9:10], off offset:2048               // 00000003B668: DC520800 037C0009
	global_load_b32 v4, v[9:10], off offset:3072               // 00000003B670: DC520C00 047C0009
	global_load_b32 v1, v[13:14], off offset:1024              // 00000003B678: DC520400 017C000D
	v_add_co_ci_u32_e64 v18, null, 0, v188, vcc_lo             // 00000003B680: D5207C12 01AB7880
	s_clause 0x7                                               // 00000003B688: BF850007
	global_load_b32 v12, v[13:14], off offset:2048             // 00000003B68C: DC520800 0C7C000D
	global_load_b32 v13, v[13:14], off offset:3072             // 00000003B694: DC520C00 0D7C000D
	global_load_b32 v9, v[15:16], off offset:1024              // 00000003B69C: DC520400 097C000F
	global_load_b32 v10, v[15:16], off offset:2048             // 00000003B6A4: DC520800 0A7C000F
	global_load_b32 v11, v[15:16], off offset:3072             // 00000003B6AC: DC520C00 0B7C000F
	global_load_b32 v14, v[17:18], off offset:1024             // 00000003B6B4: DC520400 0E7C0011
	global_load_b32 v15, v[17:18], off offset:2048             // 00000003B6BC: DC520800 0F7C0011
	global_load_b32 v16, v[17:18], off offset:3072             // 00000003B6C4: DC520C00 107C0011
	.long 0xd7006a11                                           // 00000003B6CC: D7006A11
	v_cndmask_b32_e32 v1, 0x5000, v187, vcc_lo                 // 00000003B6D0: 020376FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003B6D8: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v188, vcc_lo             // 00000003B6DC: D5207C12 01AB7880
	.long 0xd7006a41                                           // 00000003B6E4: D7006A41
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000003B6E8: 0201FFBB
	.long 0x00006000                                           // 00000003B6EC: 00006000
	v_add_co_ci_u32_e64 v66, null, 0, v188, vcc_lo             // 00000003B6F0: D5207C42 01AB7880
	.long 0xd7006a17                                           // 00000003B6F8: D7006A17
	v_cndmask_b32_e32 v1, 0x6000, v187, vcc_lo                 // 00000003B6FC: 020376FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003B704: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v188, vcc_lo             // 00000003B708: D5207C18 01AB7880
	.long 0xd7006a19                                           // 00000003B710: D7006A19
	v_cndmask_b32_e32 v1, 0x7000, v187, vcc_lo                 // 00000003B714: 020376FF 00007000
	v_add_co_ci_u32_e64 v26, null, 0, v188, vcc_lo             // 00000003B71C: D5207C1A 01AB7880
	.long 0xd7006a29                                           // 00000003B724: D7006A29
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000003B728: 0201FFBB
	.long 0x00008000                                           // 00000003B72C: 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003B730: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v188, vcc_lo             // 00000003B734: D5207C2A 01AB7880
	.long 0xd7006a20                                           // 00000003B73C: D7006A20
	v_cndmask_b32_e32 v1, 0x8000, v187, vcc_lo                 // 00000003B740: 020376FF 00008000
	v_add_co_ci_u32_e64 v33, null, 0, v188, vcc_lo             // 00000003B748: D5207C21 01AB7880
	.long 0xd7006a22                                           // 00000003B750: D7006A22
	v_cndmask_b32_e32 v1, 0x9000, v187, vcc_lo                 // 00000003B754: 020376FF 00009000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003B75C: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v188, vcc_lo             // 00000003B760: D5207C23 01AB7880
	.long 0xd7006a2b                                           // 00000003B768: D7006A2B
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000003B76C: 0201FFBB
	.long 0x0000a000                                           // 00000003B770: 0000A000
	v_add_co_ci_u32_e64 v44, null, 0, v188, vcc_lo             // 00000003B774: D5207C2C 01AB7880
	.long 0xd7006a25                                           // 00000003B77C: D7006A25
	v_cndmask_b32_e32 v1, 0xa000, v187, vcc_lo                 // 00000003B780: 020376FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003B788: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v188, vcc_lo             // 00000003B78C: D5207C26 01AB7880
	.long 0xd7006a27                                           // 00000003B794: D7006A27
	v_cndmask_b32_e32 v1, 0xb000, v187, vcc_lo                 // 00000003B798: 020376FF 0000B000
	v_add_co_ci_u32_e64 v40, null, 0, v188, vcc_lo             // 00000003B7A0: D5207C28 01AB7880
	.long 0xd7006a2d                                           // 00000003B7A8: D7006A2D
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000003B7AC: 0201FFBB
	.long 0x0000c000                                           // 00000003B7B0: 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003B7B4: BF8700A1
	v_add_co_ci_u32_e64 v46, null, 0, v188, vcc_lo             // 00000003B7B8: D5207C2E 01AB7880
	.long 0xd7006a2f                                           // 00000003B7C0: D7006A2F
	v_cndmask_b32_e32 v1, 0xc000, v187, vcc_lo                 // 00000003B7C4: 020376FF 0000C000
	v_add_co_ci_u32_e64 v48, null, 0, v188, vcc_lo             // 00000003B7CC: D5207C30 01AB7880
	.long 0xd7006a36                                           // 00000003B7D4: D7006A36
	v_cndmask_b32_e32 v1, 0xd000, v187, vcc_lo                 // 00000003B7D8: 020376FF 0000D000
	s_clause 0x17                                              // 00000003B7E0: BF850017
	global_load_b32 v20, v[17:18], off offset:1024             // 00000003B7E4: DC520400 147C0011
	global_load_b32 v21, v[17:18], off offset:2048             // 00000003B7EC: DC520800 157C0011
	global_load_b32 v22, v[17:18], off offset:3072             // 00000003B7F4: DC520C00 167C0011
	global_load_b32 v17, v[23:24], off offset:1024             // 00000003B7FC: DC520400 117C0017
	global_load_b32 v18, v[23:24], off offset:2048             // 00000003B804: DC520800 127C0017
	global_load_b32 v19, v[23:24], off offset:3072             // 00000003B80C: DC520C00 137C0017
	global_load_b32 v23, v[25:26], off offset:1024             // 00000003B814: DC520400 177C0019
	global_load_b32 v24, v[25:26], off offset:2048             // 00000003B81C: DC520800 187C0019
	global_load_b32 v31, v[25:26], off offset:3072             // 00000003B824: DC520C00 1F7C0019
	global_load_b32 v28, v[32:33], off offset:1024             // 00000003B82C: DC520400 1C7C0020
	global_load_b32 v29, v[32:33], off offset:2048             // 00000003B834: DC520800 1D7C0020
	global_load_b32 v30, v[32:33], off offset:3072             // 00000003B83C: DC520C00 1E7C0020
	global_load_b32 v25, v[34:35], off offset:1024             // 00000003B844: DC520400 197C0022
	global_load_b32 v26, v[34:35], off offset:2048             // 00000003B84C: DC520800 1A7C0022
	global_load_b32 v27, v[34:35], off offset:3072             // 00000003B854: DC520C00 1B7C0022
	global_load_b32 v32, v[37:38], off offset:1024             // 00000003B85C: DC520400 207C0025
	global_load_b32 v36, v[37:38], off offset:2048             // 00000003B864: DC520800 247C0025
	global_load_b32 v37, v[37:38], off offset:3072             // 00000003B86C: DC520C00 257C0025
	global_load_b32 v33, v[39:40], off offset:1024             // 00000003B874: DC520400 217C0027
	global_load_b32 v34, v[39:40], off offset:2048             // 00000003B87C: DC520800 227C0027
	global_load_b32 v35, v[39:40], off offset:3072             // 00000003B884: DC520C00 237C0027
	global_load_b32 v38, v[47:48], off offset:1024             // 00000003B88C: DC520400 267C002F
	global_load_b32 v39, v[47:48], off offset:2048             // 00000003B894: DC520800 277C002F
	global_load_b32 v40, v[47:48], off offset:3072             // 00000003B89C: DC520C00 287C002F
	v_add_co_ci_u32_e64 v55, null, 0, v188, vcc_lo             // 00000003B8A4: D5207C37 01AB7880
	.long 0xd7006a2f                                           // 00000003B8AC: D7006A2F
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000003B8B0: 0201FFBB
	.long 0x0000e000                                           // 00000003B8B4: 0000E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003B8B8: BF8700A1
	v_add_co_ci_u32_e64 v48, null, 0, v188, vcc_lo             // 00000003B8BC: D5207C30 01AB7880
	.long 0xd7006a3e                                           // 00000003B8C4: D7006A3E
	v_cndmask_b32_e32 v1, 0xe000, v187, vcc_lo                 // 00000003B8C8: 020376FF 0000E000
	v_add_co_ci_u32_e64 v63, null, 0, v188, vcc_lo             // 00000003B8D0: D5207C3F 01AB7880
	.long 0xd7006a43                                           // 00000003B8D8: D7006A43
	v_cndmask_b32_e32 v1, 0xf000, v187, vcc_lo                 // 00000003B8DC: 020376FF 0000F000
	s_clause 0x7                                               // 00000003B8E4: BF850007
	global_load_b32 v51, v[41:42], off offset:-4096            // 00000003B8E8: DC521000 337C0029
	global_load_b32 v58, v[41:42], off                         // 00000003B8F0: DC520000 3A7C0029
	global_load_b32 v50, v[43:44], off offset:-4096            // 00000003B8F8: DC521000 327C002B
	global_load_b32 v56, v[43:44], off                         // 00000003B900: DC520000 387C002B
	global_load_b32 v44, v[45:46], off offset:-4096            // 00000003B908: DC521000 2C7C002D
	global_load_b32 v43, v[45:46], off                         // 00000003B910: DC520000 2B7C002D
	global_load_b32 v42, v[47:48], off offset:-4096            // 00000003B918: DC521000 2A7C002F
	global_load_b32 v41, v[47:48], off                         // 00000003B920: DC520000 297C002F
	v_add_co_ci_u32_e64 v68, null, 0, v188, vcc_lo             // 00000003B928: D5207C44 01AB7880
	s_clause 0xf                                               // 00000003B930: BF85000F
	global_load_b32 v48, v[54:55], off offset:1024             // 00000003B934: DC520400 307C0036
	global_load_b32 v49, v[54:55], off offset:2048             // 00000003B93C: DC520800 317C0036
	global_load_b32 v55, v[54:55], off offset:3072             // 00000003B944: DC520C00 377C0036
	global_load_b32 v45, v[62:63], off offset:1024             // 00000003B94C: DC520400 2D7C003E
	global_load_b32 v46, v[62:63], off offset:2048             // 00000003B954: DC520800 2E7C003E
	global_load_b32 v47, v[62:63], off offset:3072             // 00000003B95C: DC520C00 2F7C003E
	global_load_b32 v57, v[67:68], off                         // 00000003B964: DC520000 397C0043
	global_load_b32 v59, v[67:68], off offset:1024             // 00000003B96C: DC520400 3B7C0043
	global_load_b32 v54, v[52:53], off offset:-4096            // 00000003B974: DC521000 367C0034
	global_load_b32 v64, v[52:53], off                         // 00000003B97C: DC520000 407C0034
	global_load_b32 v53, v[60:61], off offset:-4096            // 00000003B984: DC521000 357C003C
	global_load_b32 v63, v[60:61], off                         // 00000003B98C: DC520000 3F7C003C
	global_load_b32 v52, v[65:66], off offset:-4096            // 00000003B994: DC521000 347C0041
	global_load_b32 v62, v[65:66], off                         // 00000003B99C: DC520000 3E7C0041
	global_load_b32 v60, v[67:68], off offset:2048             // 00000003B9A4: DC520800 3C7C0043
	global_load_b32 v61, v[67:68], off offset:3072             // 00000003B9AC: DC520C00 3D7C0043
	v_lshlrev_b32_e32 v65, 3, v0                               // 00000003B9B4: 30820083
	s_cbranch_scc1 1                                           // 00000003B9B8: BFA20001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4c0>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 00000003B9BC: BE9C4D83
	s_load_b32 s39, s[0:1], 0x38                               // 00000003B9C0: F40009C0 F8000038
	v_lshrrev_b32_e32 v69, 4, v0                               // 00000003B9C8: 328A0084
	s_mul_hi_i32 s4, s2, 0x55555556                            // 00000003B9CC: 9704FF02 55555556
	v_and_b32_e32 v67, 0x78, v65                               // 00000003B9D4: 368682FF 00000078
	s_lshr_b32 s14, s4, 31                                     // 00000003B9DC: 850E9F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000003B9E0: BF870499
	s_add_i32 s4, s4, s14                                      // 00000003B9E4: 81040E04
	s_lshl_b32 s14, s4, 7                                      // 00000003B9E8: 840E8704
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003B9EC: BF870001
	v_lshlrev_b32_e32 v67, 1, v67                              // 00000003B9F0: 30868681
	s_ashr_i32 s15, s14, 31                                    // 00000003B9F4: 860F9F0E
	s_mov_b32 s4, exec_lo                                      // 00000003B9F8: BE84007E
	s_lshl_b64 s[14:15], s[14:15], 1                           // 00000003B9FC: 848E810E
	s_waitcnt lgkmcnt(0)                                       // 00000003BA00: BF89FC07
	s_add_i32 s40, s39, -1                                     // 00000003BA04: 8128C127
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BA08: BF870099
	v_min_i32_e32 v66, s40, v69                                // 00000003BA0C: 22848A28
	v_mad_i64_i32 v[65:66], null, 0x5000, v66, s[8:9]          // 00000003BA10: D6FF7C41 002284FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BA1C: BF870091
	.long 0xd7006a41                                           // 00000003BA20: D7006A41
	v_cndmask_b32_e32 v0, v65, v14, vcc_lo                     // 00000003BA24: 02001D41
	v_add_co_ci_u32_e64 v66, null, s15, v66, vcc_lo            // 00000003BA28: D5207C42 01AA840F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BA30: BF870092
	.long 0xd7006a41                                           // 00000003BA34: D7006A41
	v_cndmask_b32_e32 v1, v65, v67, vcc_lo                     // 00000003BA38: 02028741
	v_add_co_ci_u32_e64 v66, null, 0, v66, vcc_lo              // 00000003BA3C: D5207C42 01AA8480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BA44: BF870092
	.long 0xd7006a43                                           // 00000003BA48: D7006A43
	v_cndmask_b32_e32 v1, 0x1000, v65, vcc_lo                  // 00000003BA4C: 020282FF 00001000
	v_add_co_ci_u32_e64 v68, null, 0, v66, vcc_lo              // 00000003BA54: D5207C44 01AA8480
	s_clause 0x1                                               // 00000003BA5C: BF850001
	global_load_b128 v[74:77], v[65:66], off                   // 00000003BA60: DC5E0000 4A7C0041
	global_load_b128 v[78:81], v[67:68], off                   // 00000003BA68: DC5E0000 4E7C0043
	.long 0xd4c3007e                                           // 00000003BA70: D4C3007E
	v_cndmask_b32_e32 v1, s39, v69, vcc_lo                     // 00000003BA74: 02028A27
	s_cbranch_execz 11                                         // 00000003BA78: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5a8>
	s_waitcnt vmcnt(1)                                         // 00000003BA7C: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 00000003BA80: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003BA84: BF870001
	v_mov_b32_e32 v75, v76                                     // 00000003BA88: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 00000003BA8C: 7E94034C
	s_waitcnt vmcnt(0)                                         // 00000003BA90: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 00000003BA94: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 00000003BA98: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 00000003BA9C: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 00000003BAA0: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 00000003BAA4: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000003BAA8: 8C7E047E
	v_cmp_gt_u32_e32 vcc_lo, 16, v0                            // 00000003BAAC: 7C980090
	.long 0xd4440004                                           // 00000003BAB0: D4440004
	v_cndmask_b32_e32 v1, s39, v0, vcc_lo                      // 00000003BAB4: 02020027
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v140, 0            // 00000003BAB8: CA100080 418C0080
	s_and_b32 s16, vcc_lo, s4                                  // 00000003BAC0: 8B10046A
	scratch_store_b32 off, v65, off                            // 00000003BAC4: DC690000 007C4100
	s_and_saveexec_b32 s4, s16                                 // 00000003BACC: BE842010
	s_cbranch_execz 30                                         // 00000003BAD0: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x64c>
	v_mul_u32_u24_e32 v65, 0xc0, v0                            // 00000003BAD4: 168200FF 000000C0
	s_lshl_b64 s[16:17], s[2:3], 2                             // 00000003BADC: 84908202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BAE0: BF870091
	.long 0xd7001242                                           // 00000003BAE4: D7001242
	v_cndmask_b32_e32 v1, s10, v65, vcc_lo                     // 00000003BAE8: 0202820A
	v_add_co_ci_u32_e64 v67, null, s11, 0, s18                 // 00000003BAEC: D5207C43 0049000B
	.long 0xd7001244                                           // 00000003BAF4: D7001244
	v_cndmask_b32_e32 v1, s12, v65, vcc_lo                     // 00000003BAF8: 0202820C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003BAFC: BF870211
	v_add_co_ci_u32_e64 v69, null, s13, 0, s18                 // 00000003BB00: D5207C45 0049000D
	.long 0xd7006a41                                           // 00000003BB08: D7006A41
	v_cndmask_b32_e32 v0, v66, v16, vcc_lo                     // 00000003BB0C: 02002142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003BB10: BF870211
	v_add_co_ci_u32_e64 v66, null, s17, v67, vcc_lo            // 00000003BB14: D5207C42 01AA8611
	.long 0xd7006a43                                           // 00000003BB1C: D7006A43
	v_cndmask_b32_e32 v0, v68, v16, vcc_lo                     // 00000003BB20: 02002144
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003BB24: BF870001
	v_add_co_ci_u32_e64 v68, null, s17, v69, vcc_lo            // 00000003BB28: D5207C44 01AA8A11
	global_load_b32 v140, v[65:66], off                        // 00000003BB30: DC520000 8C7C0041
	global_load_b32 v65, v[67:68], off                         // 00000003BB38: DC520000 417C0043
	s_waitcnt vmcnt(0)                                         // 00000003BB40: BF8903F7
	scratch_store_b32 off, v65, off                            // 00000003BB44: DC690000 007C4100
	s_or_b32 exec_lo, exec_lo, s4                              // 00000003BB4C: 8C7E047E
	s_waitcnt vmcnt(62)                                        // 00000003BB50: BF89FBF7
	v_dual_mul_f32 v139, 0x43800000, v5 :: v_dual_mul_f32 v138, 0x43800000, v6// 00000003BB54: C8C60AFF 8B8A0CFF 43800000
	v_dual_mul_f32 v137, 0x43800000, v7 :: v_dual_mul_f32 v136, 0x43800000, v8// 00000003BB60: C8C60EFF 898810FF 43800000
	s_waitcnt vmcnt(9)                                         // 00000003BB6C: BF8927F7
	v_dual_mul_f32 v135, 0x43800000, v54 :: v_dual_mul_f32 v54, 0x43800000, v4// 00000003BB70: C8C66CFF 873608FF 43800000
	v_dual_mul_f32 v134, 0x43800000, v2 :: v_dual_mul_f32 v133, 0x43800000, v3// 00000003BB7C: C8C604FF 868406FF 43800000
	s_waitcnt vmcnt(8)                                         // 00000003BB88: BF8923F7
	v_dual_mul_f32 v132, 0x43800000, v64 :: v_dual_mul_f32 v131, 0x43800000, v1// 00000003BB8C: C8C680FF 848202FF 43800000
	v_dual_mul_f32 v130, 0x43800000, v12 :: v_dual_mul_f32 v129, 0x43800000, v13// 00000003BB98: C8C618FF 82801AFF 43800000
	s_waitcnt vmcnt(7)                                         // 00000003BBA4: BF891FF7
	v_dual_mul_f32 v128, 0x43800000, v53 :: v_dual_mul_f32 v53, 0x43800000, v11// 00000003BBA8: C8C66AFF 803416FF 43800000
	v_dual_mul_f32 v127, 0x43800000, v9 :: v_dual_mul_f32 v126, 0x43800000, v10// 00000003BBB4: C8C612FF 7F7E14FF 43800000
	s_waitcnt vmcnt(6)                                         // 00000003BBC0: BF891BF7
	v_dual_mul_f32 v125, 0x43800000, v63 :: v_dual_mul_f32 v124, 0x43800000, v14// 00000003BBC4: C8C67EFF 7D7C1CFF 43800000
	v_dual_mul_f32 v123, 0x43800000, v15 :: v_dual_mul_f32 v122, 0x43800000, v16// 00000003BBD0: C8C61EFF 7B7A20FF 43800000
	s_waitcnt vmcnt(5)                                         // 00000003BBDC: BF8917F7
	v_dual_mul_f32 v121, 0x43800000, v52 :: v_dual_mul_f32 v52, 0x43800000, v22// 00000003BBE0: C8C668FF 79342CFF 43800000
	v_dual_mul_f32 v120, 0x43800000, v20 :: v_dual_mul_f32 v119, 0x43800000, v21// 00000003BBEC: C8C628FF 78762AFF 43800000
	s_waitcnt vmcnt(4)                                         // 00000003BBF8: BF8913F7
	v_dual_mul_f32 v118, 0x43800000, v62 :: v_dual_mul_f32 v117, 0x43800000, v17// 00000003BBFC: C8C67CFF 767422FF 43800000
	v_dual_mul_f32 v116, 0x43800000, v18 :: v_dual_mul_f32 v115, 0x43800000, v19// 00000003BC08: C8C624FF 747226FF 43800000
	v_dual_mul_f32 v114, 0x43800000, v51 :: v_dual_mul_f32 v111, 0x43800000, v58// 00000003BC14: C8C666FF 726E74FF 43800000
	v_dual_mul_f32 v113, 0x43800000, v23 :: v_dual_mul_f32 v112, 0x43800000, v24// 00000003BC20: C8C62EFF 717030FF 43800000
	v_dual_mul_f32 v51, 0x43800000, v31 :: v_dual_mul_f32 v110, 0x43800000, v28// 00000003BC2C: C8C63EFF 336E38FF 43800000
	v_dual_mul_f32 v109, 0x43800000, v29 :: v_dual_mul_f32 v108, 0x43800000, v30// 00000003BC38: C8C63AFF 6D6C3CFF 43800000
	v_dual_mul_f32 v107, 0x43800000, v50 :: v_dual_mul_f32 v106, 0x43800000, v25// 00000003BC44: C8C664FF 6B6A32FF 43800000
	v_dual_mul_f32 v105, 0x43800000, v26 :: v_dual_mul_f32 v50, 0x43800000, v27// 00000003BC50: C8C634FF 693236FF 43800000
	v_dual_mul_f32 v104, 0x43800000, v56 :: v_dual_mul_f32 v101, 0x43800000, v37// 00000003BC5C: C8C670FF 68644AFF 43800000
	v_dual_mul_f32 v103, 0x43800000, v32 :: v_dual_mul_f32 v98, 0x43800000, v34// 00000003BC68: C8C640FF 676244FF 43800000
	v_dual_mul_f32 v102, 0x43800000, v36 :: v_dual_mul_f32 v99, 0x43800000, v33// 00000003BC74: C8C648FF 666242FF 43800000
	v_dual_mul_f32 v100, 0x43800000, v44 :: v_dual_mul_f32 v97, 0x43800000, v43// 00000003BC80: C8C658FF 646056FF 43800000
	v_dual_mul_f32 v58, 0x43800000, v35 :: v_dual_mul_f32 v93, 0x43800000, v42// 00000003BC8C: C8C646FF 3A5C54FF 43800000
	v_dual_mul_f32 v96, 0x43800000, v38 :: v_dual_mul_f32 v95, 0x43800000, v39// 00000003BC98: C8C64CFF 605E4EFF 43800000
	v_dual_mul_f32 v94, 0x43800000, v40 :: v_dual_mul_f32 v91, 0x43800000, v49// 00000003BCA4: C8C650FF 5E5A62FF 43800000
	v_dual_mul_f32 v92, 0x43800000, v48 :: v_dual_mul_f32 v141, 0x43800000, v45// 00000003BCB0: C8C660FF 5C8C5AFF 43800000
	v_dual_mul_f32 v152, 0x43800000, v55 :: v_dual_mul_f32 v191, 0x43800000, v57// 00000003BCBC: C8C66EFF 98BE72FF 43800000
	v_dual_mul_f32 v90, 0x43800000, v41 :: v_dual_mul_f32 v189, 0x43800000, v59// 00000003BCC8: C8C652FF 5ABC76FF 43800000
	s_waitcnt vmcnt(2)                                         // 00000003BCD4: BF890BF7
	v_dual_mul_f32 v150, 0x43800000, v46 :: v_dual_mul_f32 v151, 0x43800000, v61// 00000003BCD8: C8C65CFF 96967AFF 43800000
	v_mul_f32_e32 v142, 0x43800000, v47                        // 00000003BCE4: 111C5EFF 43800000
	v_mul_f32_e32 v190, 0x43800000, v60                        // 00000003BCEC: 117C78FF 43800000
	s_cmp_lt_i32 s39, 1                                        // 00000003BCF4: BF048127
	s_cbranch_scc1 4718                                        // 00000003BCF8: BFA2126E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x51b4>
	s_add_u32 s30, s8, s14                                     // 00000003BCFC: 801E0E08
	s_addc_u32 s31, s9, s15                                    // 00000003BD00: 821F0F09
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000003BD04: 848E8202
	s_load_b64 s[26:27], s[0:1], 0x68                          // 00000003BD08: F4040680 F8000068
	s_add_u32 s10, s10, s14                                    // 00000003BD10: 800A0E0A
	s_addc_u32 s11, s11, s15                                   // 00000003BD14: 820B0F0B
	s_add_u32 s34, s12, s14                                    // 00000003BD18: 80220E0C
	s_addc_u32 s35, s13, s15                                   // 00000003BD1C: 82230F0D
	s_add_i32 s3, s39, 15                                      // 00000003BD20: 81038F27
	s_load_b256 s[12:19], s[0:1], 0x48                         // 00000003BD24: F40C0300 F8000048
	s_ashr_i32 s4, s3, 31                                      // 00000003BD2C: 86049F03
	.long 0xd71f008f                                           // 00000003BD30: D71F008F
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000003BD34: 020100C1
	s_lshr_b32 s4, s4, 28                                      // 00000003BD38: 85049C04
	v_mov_b32_e32 v1, 0                                        // 00000003BD3C: 7E020280
	s_add_i32 s3, s3, s4                                       // 00000003BD40: 81030403
	v_mov_b32_e32 v149, 0x1000504                              // 00000003BD44: 7F2A02FF 01000504
	s_waitcnt lgkmcnt(0)                                       // 00000003BD4C: BF89FC07
	s_ashr_i32 s15, s3, 4                                      // 00000003BD50: 860F8403
	s_cmp_lg_u32 s21, 0                                        // 00000003BD54: BF078015
	s_movk_i32 s3, 0x5f40                                      // 00000003BD58: B0035F40
	s_cselect_b32 s41, -1, 0                                   // 00000003BD5C: 982980C1
	s_lshl_b32 s22, s2, 7                                      // 00000003BD60: 84168702
	v_and_b32_e32 v2, 16, v143                                 // 00000003BD64: 36051E90
	s_ashr_i32 s23, s22, 31                                    // 00000003BD68: 86179F16
	s_cmp_gt_u32 s20, 63                                       // 00000003BD6C: BF08BF14
	v_xor_b32_e32 v146, 2, v143                                // 00000003BD70: 3B251E82
	s_cselect_b32 s42, -1, 0                                   // 00000003BD74: 982A80C1
	s_cmp_eq_u32 s21, 0                                        // 00000003BD78: BF068015
	v_add_nc_u32_e32 v144, 16, v2                              // 00000003BD7C: 4B200490
	s_cselect_b32 s2, -1, 0                                    // 00000003BD80: 980280C1
	v_xor_b32_e32 v147, 4, v143                                // 00000003BD84: 3B271E84
	s_and_b32 s4, s2, exec_lo                                  // 00000003BD88: 8B047E02
	s_cselect_b32 s43, s3, 0x5f80                              // 00000003BD8C: 982BFF03 00005F80
	s_lshl_b64 s[36:37], s[22:23], 1                           // 00000003BD94: 84A48116
	v_xor_b32_e32 v148, 8, v143                                // 00000003BD98: 3B291E88
	s_add_u32 s44, s24, s36                                    // 00000003BD9C: 802C2418
	s_addc_u32 s45, s25, s37                                   // 00000003BDA0: 822D2519
	s_max_i32 s46, s15, 1                                      // 00000003BDA4: 8A2E810F
	s_add_u32 s16, s16, s6                                     // 00000003BDA8: 80100610
	s_addc_u32 s17, s17, s7                                    // 00000003BDAC: 82110711
	s_add_u32 s18, s18, s6                                     // 00000003BDB0: 80120612
	s_mov_b32 s20, 0                                           // 00000003BDB4: BE940080
	s_addc_u32 s19, s19, s7                                    // 00000003BDB8: 82130713
	s_add_u32 s47, s26, s6                                     // 00000003BDBC: 802F061A
	s_addc_u32 s7, s27, s7                                     // 00000003BDC0: 8207071B
	s_mov_b32 s48, 0x41800000                                  // 00000003BDC4: BEB000FF 41800000
	s_movk_i32 s49, 0x1800                                     // 00000003BDCC: B0311800
	s_movk_i32 s50, 0x2900                                     // 00000003BDD0: B0322900
	s_mov_b32 s21, s20                                         // 00000003BDD4: BE950014
	s_mov_b32 s22, s20                                         // 00000003BDD8: BE960014
	s_mov_b32 s23, s20                                         // 00000003BDDC: BE970014
	s_mov_b32 s24, s20                                         // 00000003BDE0: BE980014
	s_mov_b32 s25, s20                                         // 00000003BDE4: BE990014
	s_mov_b32 s26, s20                                         // 00000003BDE8: BE9A0014
	s_mov_b32 s27, s20                                         // 00000003BDEC: BE9B0014
	s_mov_b32 s51, 0x3d800000                                  // 00000003BDF0: BEB300FF 3D800000
	s_mov_b32 s52, 0x76543210                                  // 00000003BDF8: BEB400FF 76543210
	s_mov_b32 s53, s20                                         // 00000003BE00: BEB50014
	s_mov_b32 s6, s20                                          // 00000003BE04: BE860014
	s_branch 10                                                // 00000003BE08: BFA0000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x934>
	v_mov_b32_e32 v151, v65                                    // 00000003BE0C: 7F2E0341
	v_mov_b32_e32 v152, v57                                    // 00000003BE10: 7F300339
	v_mov_b32_e32 v58, v49                                     // 00000003BE14: 7E740331
	v_mov_b32_e32 v50, v9                                      // 00000003BE18: 7E640309
	v_mov_b32_e32 v51, v17                                     // 00000003BE1C: 7E660311
	v_mov_b32_e32 v52, v25                                     // 00000003BE20: 7E680319
	v_mov_b32_e32 v53, v33                                     // 00000003BE24: 7E6A0321
	v_mov_b32_e32 v54, v41                                     // 00000003BE28: 7E6C0329
	s_cmp_eq_u32 s53, s46                                      // 00000003BE2C: BF062E35
	s_cbranch_scc1 4630                                        // 00000003BE30: BFA21216 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x518c>
	v_mov_b32_e32 v44, v0                                      // 00000003BE34: 7E580300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000003BE38: BF8701B1
	v_ashrrev_i32_e32 v2, 4, v44                               // 00000003BE3C: 34045884
	v_and_b32_e32 v55, 15, v44                                 // 00000003BE40: 366E588F
	.long 0xd4440003                                           // 00000003BE44: D4440003
	v_cndmask_b32_e32 v1, 16, v44, vcc_lo                      // 00000003BE48: 02025890
	.long 0xd72c0003                                           // 00000003BE4C: D72C0003
	v_cndmask_b32_e32 v1, 0x110, v2, vcc_lo                    // 00000003BE50: 020204FF 00000110
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003BE58: BF870001
	v_lshl_add_u32 v3, v55, 4, v3                              // 00000003BE5C: D6460003 040D0937
	s_waitcnt vmcnt(1)                                         // 00000003BE64: BF8907F7
	ds_store_b128 v3, v[74:77] offset:10496                    // 00000003BE68: DB7C2900 00004A03
	s_waitcnt vmcnt(0)                                         // 00000003BE70: BF8903F7
	ds_store_b128 v3, v[78:81] offset:6144                     // 00000003BE74: DB7C1800 00004E03
	s_and_saveexec_b32 s4, s3                                  // 00000003BE7C: BE842003
	s_cbranch_execz 6                                          // 00000003BE80: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x99c>
	scratch_load_b32 v4, off, off                              // 00000003BE84: DC510000 047C0000
	v_lshlrev_b32_e32 v3, 2, v44                               // 00000003BE8C: 30065882
	s_waitcnt vmcnt(0)                                         // 00000003BE90: BF8903F7
	ds_store_b32 v3, v4 offset:24064                           // 00000003BE94: D8345E00 00000403
	s_or_b32 exec_lo, exec_lo, s4                              // 00000003BE9C: 8C7E047E
	v_and_b32_e32 v34, 1, v44                                  // 00000003BEA0: 36445881
	s_lshl_b32 s54, s53, 4                                     // 00000003BEA4: 84368435
	v_or_b32_e32 v153, s33, v55                                // 00000003BEA8: 39326E21
	s_mov_b32 s29, exec_lo                                     // 00000003BEAC: BE9D007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003BEB0: BF870112
	v_or_b32_e32 v15, s54, v34                                 // 00000003BEB4: 381E4436
	v_and_b32_e32 v6, 0x7ffffffe, v153                         // 00000003BEB8: 360D32FF 7FFFFFFE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000003BEC0: BF870232
	v_min_i32_e32 v3, s40, v15                                 // 00000003BEC4: 22061E28
	v_or_b32_e32 v5, 2, v15                                    // 00000003BEC8: 380A1E82
	v_or_b32_e32 v7, 4, v15                                    // 00000003BECC: 380E1E84
	v_lshlrev_b32_e32 v19, 1, v6                               // 00000003BED0: 30260C81
	v_or_b32_e32 v8, 6, v15                                    // 00000003BED4: 38101E86
	v_mad_i64_i32 v[3:4], null, 0x5000, v3, s[8:9]             // 00000003BED8: D6FF7C03 002206FF 00005000
	v_min_i32_e32 v5, s40, v5                                  // 00000003BEE4: 220A0A28
	v_min_i32_e32 v7, s40, v7                                  // 00000003BEE8: 220E0E28
	v_or_b32_e32 v17, 12, v15                                  // 00000003BEEC: 38221E8C
	v_min_i32_e32 v8, s40, v8                                  // 00000003BEF0: 22101028
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003BEF4: BF8700A4
	v_mad_i64_i32 v[5:6], null, 0x5000, v5, s[8:9]             // 00000003BEF8: D6FF7C05 00220AFF 00005000
	.long 0xd7006a09                                           // 00000003BF04: D7006A09
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000003BF08: 02004903
	v_add_co_ci_u32_e64 v10, null, s37, v4, vcc_lo             // 00000003BF0C: D5207C0A 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v7, s[8:9]             // 00000003BF14: D6FF7C03 00220EFF 00005000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BF20: BF870093
	.long 0xd7006a07                                           // 00000003BF24: D7006A07
	v_cndmask_b32_e32 v1, v9, v19, vcc_lo                      // 00000003BF28: 02022709
	v_add_co_ci_u32_e64 v9, null, 0, v10, vcc_lo               // 00000003BF2C: D5207C09 01AA1480
	.long 0xd7006a0a                                           // 00000003BF34: D7006A0A
	v_cndmask_b32_e32 v0, v5, v36, vcc_lo                      // 00000003BF38: 02004905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003BF3C: BF870211
	v_add_co_ci_u32_e64 v11, null, s37, v6, vcc_lo             // 00000003BF40: D5207C0B 01AA0C25
	.long 0xd7006a05                                           // 00000003BF48: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 00000003BF4C: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003BF54: BF870211
	v_add_co_ci_u32_e64 v6, null, 0, v9, vcc_lo                // 00000003BF58: D5207C06 01AA1280
	.long 0xd7006a07                                           // 00000003BF60: D7006A07
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 00000003BF64: 0202270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003BF68: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v11, vcc_lo               // 00000003BF6C: D5207C09 01AA1680
	.long 0xd7006a0a                                           // 00000003BF74: D7006A0A
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000003BF78: 02004903
	v_add_co_ci_u32_e64 v11, null, s37, v4, vcc_lo             // 00000003BF7C: D5207C0B 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v8, s[8:9]             // 00000003BF84: D6FF7C03 002210FF 00005000
	.long 0xd7006a07                                           // 00000003BF90: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 00000003BF94: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003BF9C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v9, vcc_lo                // 00000003BFA0: D5207C08 01AA1280
	.long 0xd7006a09                                           // 00000003BFA8: D7006A09
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 00000003BFAC: 0202270A
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo              // 00000003BFB0: D5207C0A 01AA1680
	v_or_b32_e32 v11, 8, v15                                   // 00000003BFB8: 38161E88
	.long 0xd7006a03                                           // 00000003BFBC: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000003BFC0: 02004903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003BFC4: BF870191
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 00000003BFC8: D5207C04 01AA0825
	v_min_i32_e32 v11, s40, v11                                // 00000003BFD0: 22161628
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003BFD4: BF870093
	.long 0xd7006a0c                                           // 00000003BFD8: D7006A0C
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000003BFDC: 02022703
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000003BFE0: D5207C0D 01AA0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003BFE8: BF8700A3
	v_mad_i64_i32 v[3:4], null, 0x5000, v11, s[8:9]            // 00000003BFEC: D6FF7C03 002216FF 00005000
	.long 0xd7006a09                                           // 00000003BFF8: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v9, vcc_lo                   // 00000003BFFC: 020212FF 00002000
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 00000003C004: D5207C0A 01AA1480
	.long 0xd7006a0b                                           // 00000003C00C: D7006A0B
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 00000003C010: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000003C018: BF8700B1
	v_add_co_ci_u32_e64 v12, null, 0, v13, vcc_lo              // 00000003C01C: D5207C0C 01AA1A80
	v_or_b32_e32 v13, 10, v15                                  // 00000003C024: 381A1E8A
	.long 0xd7006a03                                           // 00000003C028: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000003C02C: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 00000003C030: D5207C04 01AA0825
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003C038: BF870193
	v_min_i32_e32 v13, s40, v13                                // 00000003C03C: 221A1A28
	.long 0xd7006a0e                                           // 00000003C040: D7006A0E
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000003C044: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003C048: BF870191
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000003C04C: D5207C10 01AA0880
	v_mad_i64_i32 v[3:4], null, 0x5000, v13, s[8:9]            // 00000003C054: D6FF7C03 00221AFF 00005000
	v_or_b32_e32 v15, 14, v15                                  // 00000003C060: 381E1E8E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C064: BF870094
	.long 0xd7006a0d                                           // 00000003C068: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v14, vcc_lo                  // 00000003C06C: 02021CFF 00002000
	v_add_co_ci_u32_e64 v14, null, 0, v16, vcc_lo              // 00000003C074: D5207C0E 01AA2080
	v_min_i32_e32 v16, s40, v17                                // 00000003C07C: 22202228
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003C080: BF8700A4
	v_min_i32_e32 v15, s40, v15                                // 00000003C084: 221E1E28
	.long 0xd7006a11                                           // 00000003C088: D7006A11
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000003C08C: 02004903
	v_add_co_ci_u32_e64 v18, null, s37, v4, vcc_lo             // 00000003C090: D5207C12 01AA0825
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003C098: BF870194
	v_mad_i64_i32 v[3:4], null, 0x5000, v16, s[8:9]            // 00000003C09C: D6FF7C03 002220FF 00005000
	.long 0xd7006a11                                           // 00000003C0A8: D7006A11
	v_cndmask_b32_e32 v1, v17, v19, vcc_lo                     // 00000003C0AC: 02022711
	v_mad_i64_i32 v[15:16], null, 0x5000, v15, s[8:9]          // 00000003C0B0: D6FF7C0F 00221EFF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003C0BC: BF870194
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 00000003C0C0: D5207C12 01AA2480
	.long 0xd7006a11                                           // 00000003C0C8: D7006A11
	v_cndmask_b32_e32 v1, 0x2000, v17, vcc_lo                  // 00000003C0CC: 020222FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003C0D4: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 00000003C0D8: D5207C12 01AA2480
	.long 0xd7006a03                                           // 00000003C0E0: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000003C0E4: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 00000003C0E8: D5207C04 01AA0825
	.long 0xd7006a0f                                           // 00000003C0F0: D7006A0F
	v_cndmask_b32_e32 v0, v15, v36, vcc_lo                     // 00000003C0F4: 0200490F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003C0F8: BF870211
	v_add_co_ci_u32_e64 v16, null, s37, v16, vcc_lo            // 00000003C0FC: D5207C10 01AA2025
	.long 0xd7006a03                                           // 00000003C104: D7006A03
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000003C108: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003C10C: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000003C110: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 00000003C118: D7006A0F
	v_cndmask_b32_e32 v1, v15, v19, vcc_lo                     // 00000003C11C: 0202270F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003C120: BF870211
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 00000003C124: D5207C10 01AA2080
	.long 0xd7006a03                                           // 00000003C12C: D7006A03
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 00000003C130: 020206FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003C138: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000003C13C: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 00000003C144: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v15, vcc_lo                  // 00000003C148: 02021EFF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003C150: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 00000003C154: D5207C10 01AA2080
	s_clause 0x7                                               // 00000003C15C: BF850007
	global_load_b32 v42, v[5:6], off                           // 00000003C160: DC520000 2A7C0005
	global_load_b32 v41, v[7:8], off                           // 00000003C168: DC520000 297C0007
	global_load_b32 v40, v[9:10], off                          // 00000003C170: DC520000 287C0009
	global_load_b32 v39, v[11:12], off                         // 00000003C178: DC520000 277C000B
	global_load_b32 v38, v[13:14], off                         // 00000003C180: DC520000 267C000D
	global_load_b32 v37, v[17:18], off                         // 00000003C188: DC520000 257C0011
	global_load_b32 v35, v[3:4], off                           // 00000003C190: DC520000 237C0003
	global_load_b32 v36, v[15:16], off                         // 00000003C198: DC520000 247C000F
	v_lshlrev_b32_e32 v5, 16, v78                              // 00000003C1A0: 300A9C90
	v_and_b32_e32 v4, 0xffff0000, v74                          // 00000003C1A4: 360894FF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v75                          // 00000003C1AC: 361096FF FFFF0000
	v_lshlrev_b32_e32 v3, 16, v74                              // 00000003C1B4: 30069490
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000003C1B8: BF8701A4
	v_dual_mul_f32 v5, v5, v5 :: v_dual_lshlrev_b32 v12, 16, v80// 00000003C1BC: C8E20B05 050CA090
	v_lshlrev_b32_e32 v7, 16, v75                              // 00000003C1C4: 300E9690
	v_dual_mul_f32 v3, v3, v3 :: v_dual_and_b32 v6, 0xffff0000, v78// 00000003C1C8: C8E40703 03069CFF FFFF0000
	v_mul_f32_e32 v4, v4, v4                                   // 00000003C1D4: 10080904
	v_and_b32_e32 v13, 0xffff0000, v80                         // 00000003C1D8: 361AA0FF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v76                         // 00000003C1E0: 361498FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000003C1E8: BF8701B4
	v_dual_mul_f32 v6, v6, v6 :: v_dual_and_b32 v11, 0xffff0000, v77// 00000003C1EC: C8E40D06 060A9AFF FFFF0000
	v_mul_f32_e32 v12, v12, v12                                // 00000003C1F8: 1018190C
	v_add_f32_e32 v3, v3, v4                                   // 00000003C1FC: 06060903
	v_dual_add_f32 v4, v5, v6 :: v_dual_lshlrev_b32 v9, 16, v76// 00000003C200: C9220D05 04089890
	v_dual_mul_f32 v5, v7, v7 :: v_dual_mul_f32 v6, v8, v8     // 00000003C208: C8C60F07 05061108
	v_lshlrev_b32_e32 v7, 16, v79                              // 00000003C210: 300E9E90
	v_dual_mul_f32 v13, v13, v13 :: v_dual_and_b32 v8, 0xffff0000, v79// 00000003C214: C8E41B0D 0D089EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003C220: BF870113
	v_dual_add_f32 v5, v5, v6 :: v_dual_and_b32 v14, 0xffff0000, v81// 00000003C224: C9240D05 050EA2FF FFFF0000
	v_dual_mul_f32 v6, v7, v7 :: v_dual_mul_f32 v7, v8, v8     // 00000003C230: C8C60F07 06061108
	v_dual_mul_f32 v8, v9, v9 :: v_dual_mul_f32 v9, v10, v10   // 00000003C238: C8C61309 0808150A
	v_lshlrev_b32_e32 v10, 16, v77                             // 00000003C240: 30149A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003C244: BF870113
	v_dual_add_f32 v6, v6, v7 :: v_dual_add_f32 v7, v12, v13   // 00000003C248: C9080F06 06061B0C
	v_dual_add_f32 v8, v8, v9 :: v_dual_mul_f32 v9, v10, v10   // 00000003C250: C9061308 0808150A
	v_dual_mul_f32 v10, v11, v11 :: v_dual_lshlrev_b32 v11, 16, v81// 00000003C258: C8E2170B 0A0AA290
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003C260: BF870113
	v_add_f32_e32 v4, v4, v6                                   // 00000003C264: 06080D04
	v_dual_add_f32 v9, v9, v10 :: v_dual_mul_f32 v10, v11, v11 // 00000003C268: C9061509 090A170B
	v_mul_f32_e32 v11, v14, v14                                // 00000003C270: 10161D0E
	v_add_f32_e32 v3, v3, v5                                   // 00000003C274: 06060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003C278: BF870123
	v_add_f32_e32 v5, v8, v9                                   // 00000003C27C: 060A1308
	v_xor_b32_e32 v9, 1, v143                                  // 00000003C280: 3A131E81
	v_dual_add_f32 v8, v10, v11 :: v_dual_add_f32 v3, v3, v5   // 00000003C284: C908170A 08020B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000003C28C: BF8701A2
	v_cmp_lt_u32_e32 vcc_lo, v9, v144                          // 00000003C290: 7C932109
	v_cndmask_b32_e32 v9, v143, v9, vcc_lo                     // 00000003C294: 0212138F
	v_add_f32_e32 v5, v7, v8                                   // 00000003C298: 060A1107
	v_cmp_lt_u32_e32 vcc_lo, v146, v144                        // 00000003C29C: 7C932192
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003C2A0: BF870193
	v_lshlrev_b32_e32 v6, 2, v9                                // 00000003C2A4: 300C1282
	v_dual_add_f32 v4, v4, v5 :: v_dual_cndmask_b32 v7, v143, v146// 00000003C2A8: C9120B04 0407258F
	v_cmp_lt_u32_e32 vcc_lo, v147, v144                        // 00000003C2B0: 7C932193
	ds_bpermute_b32 v5, v6, v3                                 // 00000003C2B4: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 00000003C2BC: DACC0000 06000406
	s_waitcnt lgkmcnt(0)                                       // 00000003C2C4: BF89FC07
	v_dual_add_f32 v4, v4, v6 :: v_dual_add_f32 v3, v3, v5     // 00000003C2C8: C9080D04 04020B03
	v_lshlrev_b32_e32 v5, 2, v7                                // 00000003C2D0: 300A0E82
	ds_bpermute_b32 v6, v5, v3                                 // 00000003C2D4: DACC0000 06000305
	ds_bpermute_b32 v5, v5, v4                                 // 00000003C2DC: DACC0000 05000405
	v_cndmask_b32_e32 v7, v143, v147, vcc_lo                   // 00000003C2E4: 020F278F
	v_cmp_lt_u32_e32 vcc_lo, v148, v144                        // 00000003C2E8: 7C932194
	s_waitcnt lgkmcnt(0)                                       // 00000003C2EC: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v5     // 00000003C2F0: C9080D03 03040B04
	s_delay_alu instid0(VALU_DEP_3)                            // 00000003C2F8: BF870003
	v_dual_cndmask_b32 v7, v143, v148 :: v_dual_lshlrev_b32 v6, 2, v7// 00000003C2FC: CA63298F 07060E82
	ds_bpermute_b32 v5, v6, v3                                 // 00000003C304: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 00000003C30C: DACC0000 06000406
	v_lshlrev_b32_e32 v7, 2, v7                                // 00000003C314: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 00000003C318: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000003C31C: C9080B03 03040D04
	ds_bpermute_b32 v5, v7, v3                                 // 00000003C324: DACC0000 05000307
	ds_bpermute_b32 v6, v7, v4                                 // 00000003C32C: DACC0000 06000407
	v_cmpx_eq_u32_e32 0, v55                                   // 00000003C334: 7D946E80
	s_cbranch_execnz 3323                                      // 00000003C338: BFA60CFB <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4228>
	s_or_b32 exec_lo, exec_lo, s29                             // 00000003C33C: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003C340: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 00000003C344: 916A267E
	s_cbranch_vccz 3363                                        // 00000003C348: BFA30D23 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x42d8>
	v_and_b32_e32 v43, 31, v44                                 // 00000003C34C: 3656589F
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 00000003C350: 916A027E
	s_cbranch_vccz 3364                                        // 00000003C354: BFA30D24 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x42e8>
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 00000003C358: 916A267E
	s_cbranch_vccz 3485                                        // 00000003C35C: BFA30D9D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44d4>
	s_add_i32 s53, s53, 1                                      // 00000003C360: 81358135
	s_waitcnt lgkmcnt(0)                                       // 00000003C364: BF89FC07
	s_barrier                                                  // 00000003C368: BFBD0000
	s_cmp_ge_i32 s53, s15                                      // 00000003C36C: BF030F35
	s_cbranch_scc1 71                                          // 00000003C370: BFA20047 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xf90>
	s_lshl_b32 s4, s53, 4                                      // 00000003C374: 84048435
	v_lshlrev_b32_e32 v4, 4, v44                               // 00000003C378: 30085884
	s_waitcnt lgkmcnt(0)                                       // 00000003C37C: BF89FC07
	v_add_nc_u32_e32 v6, s4, v2                                // 00000003C380: 4A0C0404
	s_mov_b32 s29, exec_lo                                     // 00000003C384: BE9D007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003C388: BF870112
	v_and_b32_e32 v4, 0xf0, v4                                 // 00000003C38C: 360808FF 000000F0
	v_min_i32_e32 v2, s40, v6                                  // 00000003C394: 22040C28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C398: BF870091
	v_mad_i64_i32 v[2:3], null, 0x5000, v2, s[30:31]           // 00000003C39C: D6FF7C02 007A04FF 00005000
	.long 0xd7006a02                                           // 00000003C3A8: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000003C3AC: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003C3B0: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000003C3B4: D5207C03 01AA0680
	.long 0xd7006a04                                           // 00000003C3BC: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000003C3C0: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003C3C8: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 00000003C3CC: D5207C05 01AA0680
	s_clause 0x1                                               // 00000003C3D4: BF850001
	global_load_b128 v[74:77], v[2:3], off                     // 00000003C3D8: DC5E0000 4A7C0002
	global_load_b128 v[78:81], v[4:5], off                     // 00000003C3E0: DC5E0000 4E7C0004
	.long 0xd4c3007e                                           // 00000003C3E8: D4C3007E
	v_cndmask_b32_e32 v1, s39, v6, vcc_lo                      // 00000003C3EC: 02020C27
	s_cbranch_execz 11                                         // 00000003C3F0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xf20>
	s_waitcnt vmcnt(1)                                         // 00000003C3F4: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 00000003C3F8: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003C3FC: BF870001
	v_mov_b32_e32 v75, v76                                     // 00000003C400: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 00000003C404: 7E94034C
	s_waitcnt vmcnt(0)                                         // 00000003C408: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 00000003C40C: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 00000003C410: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 00000003C414: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 00000003C418: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 00000003C41C: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s29                             // 00000003C420: 8C7E1D7E
	s_and_saveexec_b32 s29, s3                                 // 00000003C424: BE9D2003
	s_cbranch_execz 23                                         // 00000003C428: BFA50017 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xf88>
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v2, s4, v44      // 00000003C42C: CA200080 03025804
	v_mov_b32_e32 v140, 0                                      // 00000003C434: 7F180280
	s_mov_b32 s3, exec_lo                                      // 00000003C438: BE83007E
	scratch_store_b32 off, v3, off                             // 00000003C43C: DC690000 007C0300
	.long 0xd4c4007e                                           // 00000003C444: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000003C448: 02020427
	s_cbranch_execz 13                                         // 00000003C44C: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xf84>
	v_mad_i64_i32 v[3:4], null, 0xc0, v2, s[10:11]             // 00000003C450: D6FF7C03 002A04FF 000000C0
	v_mad_i64_i32 v[5:6], null, 0xc0, v2, s[34:35]             // 00000003C45C: D6FF7C05 008A04FF 000000C0
	global_load_b32 v140, v[3:4], off                          // 00000003C468: DC520000 8C7C0003
	global_load_b32 v2, v[5:6], off                            // 00000003C470: DC520000 027C0005
	s_waitcnt vmcnt(0)                                         // 00000003C478: BF8903F7
	scratch_store_b32 off, v2, off                             // 00000003C47C: DC690000 007C0200
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003C484: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003C488: BF870009
	s_or_b32 exec_lo, exec_lo, s29                             // 00000003C48C: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003C490: BF870009
	s_and_b32 vcc_lo, exec_lo, s42                             // 00000003C494: 8B6A2A7E
	s_mov_b32 s3, -1                                           // 00000003C498: BE8300C1
	s_cbranch_vccz 80                                          // 00000003C49C: BFA30050 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10e0>
	v_and_b32_e32 v2, -16, v44                                 // 00000003C4A0: 360458D0
	s_mov_b32 s3, exec_lo                                      // 00000003C4A4: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003C4A8: BF870001
	v_cmpx_eq_u32_e32 64, v2                                   // 00000003C4AC: 7D9404C0
	s_cbranch_execz 73                                         // 00000003C4B0: BFA50049 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10d8>
	v_lshlrev_b32_e32 v4, 2, v44                               // 00000003C4B4: 30085882
	s_waitcnt lgkmcnt(0)                                       // 00000003C4B8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003C4BC: BF870001
	v_add_nc_u32_e32 v5, 0x5c00, v4                            // 00000003C4C0: 4A0A08FF 00005C00
	ds_load_2addr_b32 v[2:3], v5 offset0:64 offset1:80         // 00000003C4C8: D8DC5040 02000005
	ds_load_b32 v6, v1 offset:24188                            // 00000003C4D0: D8D85E7C 06000001
	s_waitcnt lgkmcnt(1)                                       // 00000003C4D8: BF89FC17
	v_mul_f32_e32 v7, 0x3fb8aa3b, v3                           // 00000003C4DC: 100E06FF 3FB8AA3B
	ds_load_b32 v8, v4 offset:24128                            // 00000003C4E4: D8D85E40 08000004
	s_waitcnt lgkmcnt(1)                                       // 00000003C4EC: BF89FC17
	v_sub_f32_e32 v6, v6, v3                                   // 00000003C4F0: 080C0706
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000003C4F4: 7C3606FF C2CE8ED0
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v7                          // 00000003C4FC: D6130009 841E06FF 3FB8AA3B
	v_rndne_f32_e32 v10, v7                                    // 00000003C508: 7E144707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003C50C: BF870114
	v_mul_f32_e32 v11, 0x3fb8aa3b, v6                          // 00000003C510: 10160CFF 3FB8AA3B
	v_sub_f32_e32 v7, v7, v10                                  // 00000003C518: 080E1507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000003C51C: BF8701C2
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v11                        // 00000003C520: D613000C 842E0CFF 3FB8AA3B
	v_fmac_f32_e32 v9, 0x32a5705f, v3                          // 00000003C52C: 561206FF 32A5705F
	v_cvt_i32_f32_e32 v10, v10                                 // 00000003C534: 7E14110A
	v_rndne_f32_e32 v13, v11                                   // 00000003C538: 7E1A470B
	v_dual_fmac_f32 v12, 0x32a5705f, v6 :: v_dual_add_f32 v7, v7, v9// 00000003C53C: C8080CFF 0C061307 32A5705F
	s_waitcnt lgkmcnt(0)                                       // 00000003C548: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003C54C: BF870112
	v_dual_sub_f32 v9, v11, v13 :: v_dual_mul_f32 v2, v8, v2   // 00000003C550: C9461B0B 09020508
	v_exp_f32_e32 v7, v7                                       // 00000003C558: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003C55C: BF870125
	.long 0xd71c0007                                           // 00000003C560: D71C0007
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 00000003C564: 02021507
	v_cvt_i32_f32_e32 v10, v13                                 // 00000003C568: 7E14110D
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 00000003C56C: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000003C570: 7C3C06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000003C578: BF8701B2
	v_cndmask_b32_e32 v3, 0x7f800000, v7, vcc_lo               // 00000003C57C: 02060EFF 7F800000
	v_add_f32_e32 v9, v9, v12                                  // 00000003C584: 06121909
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 00000003C588: 7C360CFF C2CE8ED0
	v_mul_f32_e32 v2, v3, v2                                   // 00000003C590: 10040503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C594: BF870093
	v_exp_f32_e32 v9, v9                                       // 00000003C598: 7E124B09
	v_mul_f32_e32 v2, 0x41800000, v2                           // 00000003C59C: 100404FF 41800000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C5A4: BF870095
	.long 0xd71c0009                                           // 00000003C5A8: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000003C5AC: 02021509
	v_cndmask_b32_e32 v7, 0, v9, vcc_lo                        // 00000003C5B0: 020E1280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 00000003C5B4: 7C3C0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000003C5BC: BF870002
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 00000003C5C0: 020C0EFF 7F800000
	ds_store_b32 v4, v3 offset:24064                           // 00000003C5C8: D8345E00 00000304
	ds_store_2addr_b32 v5, v6, v2 offset0:96 offset1:112       // 00000003C5D0: D8387060 00020605
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003C5D8: 8C7E037E
	s_mov_b32 s3, 0                                            // 00000003C5DC: BE830080
	v_lshrrev_b32_e32 v154, 4, v43                             // 00000003C5E0: 33345684
	v_mul_u32_u24_e32 v57, 0x110, v55                          // 00000003C5E4: 16726EFF 00000110
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 00000003C5EC: 916A037E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000003C5F0: BF870002
	v_lshlrev_b32_e32 v56, 2, v154                             // 00000003C5F4: 30713482
	s_cbranch_vccnz 871                                        // 00000003C5F8: BFA40367 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1e98>
	v_mad_u32_u24 v2, 0x110, v55, s49                          // 00000003C5FC: D60B0002 00C66EFF 00000110
	s_and_b32 s3, s2, exec_lo                                  // 00000003C608: 8B037E02
	s_cselect_b32 s3, 0, 0x1100                                // 00000003C60C: 9803FF80 00001100
	v_mad_u32_u24 v3, 0x110, v55, s50                          // 00000003C614: D60B0003 00CA6EFF 00000110
	ds_load_b128 v[10:13], v57 offset:6144                     // 00000003C620: DBFC1800 0A000039
	ds_load_b128 v[14:17], v57 offset:6160                     // 00000003C628: DBFC1810 0E000039
	v_add_nc_u32_e32 v4, s3, v2                                // 00000003C630: 4A080403
	v_mov_b32_e32 v8, v1                                       // 00000003C634: 7E100301
	s_waitcnt lgkmcnt(0)                                       // 00000003C638: BF89FC07
	v_mov_b32_e32 v5, v1                                       // 00000003C63C: 7E0A0301
	v_cndmask_b32_e64 v45, v3, v2, s2                          // 00000003C640: D501002D 000A0503
	v_mov_b32_e32 v3, v1                                       // 00000003C648: 7E060301
	ds_load_b128 v[18:21], v4                                  // 00000003C64C: DBFC0000 12000004
	ds_load_b128 v[22:25], v4 offset:16                        // 00000003C654: DBFC0010 16000004
	ds_load_b128 v[26:29], v57 offset:6176                     // 00000003C65C: DBFC1820 1A000039
	ds_load_b128 v[30:33], v57 offset:6192                     // 00000003C664: DBFC1830 1E000039
	ds_load_b128 v[59:62], v45 offset:32                       // 00000003C66C: DBFC0020 3B00002D
	ds_load_b128 v[63:66], v45 offset:48                       // 00000003C674: DBFC0030 3F00002D
	ds_load_b128 v[155:158], v45 offset:64                     // 00000003C67C: DBFC0040 9B00002D
	ds_load_b128 v[159:162], v45 offset:80                     // 00000003C684: DBFC0050 9F00002D
	ds_load_b128 v[167:170], v57 offset:6224                   // 00000003C68C: DBFC1850 A7000039
	ds_load_b128 v[163:166], v57 offset:6208                   // 00000003C694: DBFC1840 A3000039
	v_mov_b32_e32 v2, v1                                       // 00000003C69C: 7E040301
	v_mov_b32_e32 v4, v1                                       // 00000003C6A0: 7E080301
	v_mov_b32_e32 v6, v1                                       // 00000003C6A4: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000003C6A8: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 00000003C6AC: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003C6B0: BF870212
	v_mov_b32_e32 v8, v7                                       // 00000003C6B4: 7E100307
	v_mov_b32_e32 v7, v6                                       // 00000003C6B8: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 00000003C6BC: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 00000003C6C0: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 00000003C6C4: 7E080303
	v_mov_b32_e32 v3, v2                                       // 00000003C6C8: 7E060302
	v_mov_b32_e32 v2, v1                                       // 00000003C6CC: 7E040301
	ds_load_b128 v[175:178], v57 offset:6256                   // 00000003C6D0: DBFC1870 AF000039
	ds_load_b128 v[171:174], v57 offset:6240                   // 00000003C6D8: DBFC1860 AB000039
	ds_load_b128 v[183:186], v45 offset:112                    // 00000003C6E0: DBFC0070 B700002D
	ds_load_b128 v[179:182], v45 offset:96                     // 00000003C6E8: DBFC0060 B300002D
	v_or_b32_e32 v49, 6, v154                                  // 00000003C6F0: 38633486
	v_or_b32_e32 v48, 8, v154                                  // 00000003C6F4: 38613488
	v_or_b32_e32 v47, 10, v154                                 // 00000003C6F8: 385F348A
	s_waitcnt lgkmcnt(12)                                      // 00000003C6FC: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 00000003C700: CC414002 1C0A1512
	ds_load_b128 v[14:17], v57 offset:6288                     // 00000003C708: DBFC1890 0E000039
	ds_load_b128 v[10:13], v57 offset:6272                     // 00000003C710: DBFC1880 0A000039
	ds_load_b128 v[22:25], v45 offset:144                      // 00000003C718: DBFC0090 1600002D
	ds_load_b128 v[18:21], v45 offset:128                      // 00000003C720: DBFC0080 1200002D
	s_and_not1_b32 vcc_lo, exec_lo, s41                        // 00000003C728: 916A297E
	s_mov_b32 s3, -1                                           // 00000003C72C: BE8300C1
	s_waitcnt lgkmcnt(12)                                      // 00000003C730: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[59:66], v[26:33], v[2:9]// 00000003C734: CC414002 1C0A353B
	ds_load_b128 v[30:33], v57 offset:6320                     // 00000003C73C: DBFC18B0 1E000039
	ds_load_b128 v[26:29], v57 offset:6304                     // 00000003C744: DBFC18A0 1A000039
	ds_load_b128 v[65:68], v45 offset:176                      // 00000003C74C: DBFC00B0 4100002D
	ds_load_b128 v[61:64], v45 offset:160                      // 00000003C754: DBFC00A0 3D00002D
	v_lshlrev_b32_e32 v60, 2, v55                              // 00000003C75C: 30786E82
	v_or_b32_e32 v59, 4, v154                                  // 00000003C760: 38773484
	s_waitcnt lgkmcnt(12)                                      // 00000003C764: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[155:162], v[163:170], v[2:9]// 00000003C768: CC414002 1C0B479B
	ds_load_b128 v[159:162], v57 offset:6352                   // 00000003C770: DBFC18D0 9F000039
	ds_load_b128 v[155:158], v57 offset:6336                   // 00000003C778: DBFC18C0 9B000039
	v_add_nc_u32_e32 v46, 64, v60                              // 00000003C780: 4A5C78C0
	ds_load_b128 v[167:170], v57 offset:6384                   // 00000003C784: DBFC18F0 A7000039
	ds_load_b128 v[163:166], v57 offset:6368                   // 00000003C78C: DBFC18E0 A3000039
	s_waitcnt lgkmcnt(12)                                      // 00000003C794: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[179:186], v[171:178], v[2:9]// 00000003C798: CC414002 1C0B57B3
	ds_load_b128 v[175:178], v45 offset:208                    // 00000003C7A0: DBFC00D0 AF00002D
	ds_load_b128 v[171:174], v45 offset:192                    // 00000003C7A8: DBFC00C0 AB00002D
	s_waitcnt lgkmcnt(10)                                      // 00000003C7B0: BF89FCA7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 00000003C7B4: CC414002 1C0A1512
	v_add_nc_u32_e32 v10, 0x5c00, v56                          // 00000003C7BC: 4A1470FF 00005C00
	v_add_nc_u32_e32 v11, s43, v56                             // 00000003C7C4: 4A16702B
	ds_load_b128 v[183:186], v45 offset:240                    // 00000003C7C8: DBFC00F0 B700002D
	ds_load_b128 v[179:182], v45 offset:224                    // 00000003C7D0: DBFC00E0 B300002D
	ds_load_2addr_stride64_b32 v[12:13], v46 offset0:94 offset1:95// 00000003C7D8: D8E05F5E 0C00002E
	v_or_b32_e32 v46, 12, v154                                 // 00000003C7E0: 385D348C
	s_waitcnt lgkmcnt(9)                                       // 00000003C7E4: BF89FC97
	v_wmma_f32_16x16x16_bf16 v[2:9], v[61:68], v[26:33], v[2:9]// 00000003C7E8: CC414002 1C0A353D
	ds_load_2addr_b32 v[28:29], v10 offset0:144 offset1:146    // 00000003C7F0: D8DC9290 1C00000A
	ds_load_2addr_b32 v[24:25], v10 offset0:148 offset1:150    // 00000003C7F8: D8DC9694 1800000A
	ds_load_2addr_b32 v[20:21], v10 offset0:152 offset1:154    // 00000003C800: D8DC9A98 1400000A
	ds_load_2addr_b32 v[16:17], v10 offset0:156 offset1:158    // 00000003C808: D8DC9E9C 1000000A
	ds_load_2addr_b32 v[26:27], v11 offset1:2                  // 00000003C810: D8DC0200 1A00000B
	ds_load_2addr_b32 v[22:23], v11 offset0:4 offset1:6        // 00000003C818: D8DC0604 1600000B
	ds_load_2addr_b32 v[18:19], v11 offset0:8 offset1:10       // 00000003C820: D8DC0A08 1200000B
	ds_load_2addr_b32 v[14:15], v11 offset0:12 offset1:14      // 00000003C828: D8DC0E0C 0E00000B
	v_or_b32_e32 v61, 2, v154                                  // 00000003C830: 387B3482
	v_or_b32_e32 v45, 14, v154                                 // 00000003C834: 385B348E
	s_waitcnt lgkmcnt(11)                                      // 00000003C838: BF89FCB7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[171:178], v[155:162], v[2:9]// 00000003C83C: CC414002 1C0B37AB
	s_waitcnt lgkmcnt(9)                                       // 00000003C844: BF89FC97
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003C848: BF870001
	v_wmma_f32_16x16x16_bf16 v[2:9], v[179:186], v[163:170], v[2:9]// 00000003C84C: CC414002 1C0B47B3
	s_cbranch_vccnz 353                                        // 00000003C854: BFA40161 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x18dc>
	.long 0x7e143880                                           // 00000003C858: 7E143880
	s_mov_b32 s3, exec_lo                                      // 00000003C85C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003C860: BF870001
	.long 0x7f14390a                                           // 00000003C864: 7F14390A
	.long 0xd4cb007e                                           // 00000003C868: D4CB007E
	v_cndmask_b32_e32 v1, v55, v154, vcc_lo                    // 00000003C86C: 02033537
	s_cbranch_execz 34                                         // 00000003C870: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x13fc>
	s_waitcnt lgkmcnt(7)                                       // 00000003C874: BF89FC77
	v_sub_f32_e32 v11, v28, v12                                // 00000003C878: 0816191C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C87C: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v11                         // 00000003C880: 103C16FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v11, -v30                       // 00000003C888: D613001F 847A16FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 00000003C894: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C898: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v11 :: v_dual_sub_f32 v30, v30, v32// 00000003C89C: C80A16FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 00000003C8A8: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 00000003C8AC: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000003C8B0: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003C8B8: BF870293
	v_exp_f32_e32 v30, v30                                     // 00000003C8BC: 7E3C4B1E
	.long 0xd71c001e                                           // 00000003C8C0: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 00000003C8C4: 02023F1E
	s_waitcnt lgkmcnt(3)                                       // 00000003C8C8: BF89FC37
	v_mul_f32_e32 v31, v2, v26                                 // 00000003C8CC: 103E3502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003C8D0: BF870122
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 00000003C8D4: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000003C8D8: 7C3C16FF 42B17218
	v_dual_cndmask_b32 v11, 0x7f800000, v30 :: v_dual_mul_f32 v30, v13, v31// 00000003C8E0: CA463CFF 0B1E3F0D 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C8EC: BF870091
	v_mul_f32_e32 v11, v11, v30                                // 00000003C8F0: 10163D0B
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 00000003C8F4: CC22000A 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003C8FC: 8C7E037E
	v_mul_u32_u24_e32 v11, 48, v154                            // 00000003C900: 161734B0
	s_mov_b32 s3, exec_lo                                      // 00000003C904: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003C908: BF870001
	v_lshl_add_u32 v11, v55, 1, v11                            // 00000003C90C: D646000B 042D0337
	ds_store_b16_d16_hi v11, v10 offset:23296                  // 00000003C914: DA845B00 00000A0B
	.long 0xd4cb007e                                           // 00000003C91C: D4CB007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 00000003C920: 02027B37
	s_cbranch_execz 34                                         // 00000003C924: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x14b0>
	s_waitcnt lgkmcnt(8)                                       // 00000003C928: BF89FC87
	v_sub_f32_e32 v10, v29, v12                                // 00000003C92C: 0814191D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C930: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v10                         // 00000003C934: 103C14FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v30                       // 00000003C93C: D613001F 847A14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 00000003C948: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C94C: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v10 :: v_dual_sub_f32 v30, v30, v32// 00000003C950: C80A14FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 00000003C95C: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 00000003C960: 7E3E1120
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003C964: BF870292
	v_exp_f32_e32 v30, v30                                     // 00000003C968: 7E3C4B1E
	.long 0xd71c001e                                           // 00000003C96C: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 00000003C970: 02023F1E
	s_waitcnt lgkmcnt(4)                                       // 00000003C974: BF89FC47
	v_mul_f32_e32 v31, v3, v27                                 // 00000003C978: 103E3703
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000003C97C: 7C3614FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003C984: BF870123
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 00000003C988: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000003C98C: 7C3C14FF 42B17218
	v_cndmask_b32_e32 v10, 0x7f800000, v30, vcc_lo             // 00000003C994: 02143CFF 7F800000
	v_mul_f32_e32 v30, v13, v31                                // 00000003C99C: 103C3F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003C9A0: BF870091
	v_mul_f32_e32 v10, v10, v30                                // 00000003C9A4: 10143D0A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 00000003C9A8: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003C9B0: 8C7E037E
	.long 0x7f143880                                           // 00000003C9B4: 7F143880
	v_or_b32_e32 v30, 0x5b00, v11                              // 00000003C9B8: 383C16FF 00005B00
	s_mov_b32 s3, exec_lo                                      // 00000003C9C0: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000003C9C4: BF870002
	.long 0x7e16398a                                           // 00000003C9C8: 7E16398A
	ds_store_b16 v30, v10 offset:96                            // 00000003C9CC: D87C0060 00000A1E
	.long 0xd4cb007e                                           // 00000003C9D4: D4CB007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 00000003C9D8: 02027737
	s_cbranch_execz 35                                         // 00000003C9DC: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x156c>
	s_waitcnt lgkmcnt(8)                                       // 00000003C9E0: BF89FC87
	v_sub_f32_e32 v11, v24, v12                                // 00000003C9E4: 08161918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003C9E8: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000003C9EC: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000003C9F4: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000003C9FC: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000003CA08: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CA0C: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000003CA10: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000003CA1C: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000003CA20: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003CA24: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000003CA28: 7E3E4B1F
	.long 0xd71c001f                                           // 00000003CA2C: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000003CA30: 0202411F
	s_waitcnt lgkmcnt(4)                                       // 00000003CA34: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003CA38: BF870121
	v_dual_mul_f32 v32, v4, v22 :: v_dual_cndmask_b32 v31, 0, v31// 00000003CA3C: C8D22D04 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000003CA44: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000003CA4C: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CA54: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 00000003CA58: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 00000003CA5C: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003CA60: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000003CA64: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003CA6C: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003CA70: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000003CA74: BE83007E
	ds_store_b16 v30, v11 offset:192                           // 00000003CA78: D87C00C0 00000B1E
	.long 0xd4cb007e                                           // 00000003CA80: D4CB007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 00000003CA84: 02026337
	s_cbranch_execz 35                                         // 00000003CA88: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1618>
	s_waitcnt lgkmcnt(9)                                       // 00000003CA8C: BF89FC97
	v_sub_f32_e32 v10, v25, v12                                // 00000003CA90: 08141919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CA94: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000003CA98: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000003CAA0: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000003CAAC: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003CAB0: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000003CAB4: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000003CABC: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000003CAC0: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000003CAC4: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000003CAC8: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000003CACC: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000003CAD4: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000003CAD8: BF870135
	.long 0xd71c000b                                           // 00000003CADC: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000003CAE0: 02023F0B
	s_waitcnt lgkmcnt(5)                                       // 00000003CAE4: BF89FC57
	v_mul_f32_e32 v31, v5, v23                                 // 00000003CAE8: 103E2F05
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000003CAEC: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000003CAF0: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003CAF8: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000003CAFC: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000003CB04: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CB08: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000003CB0C: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 00000003CB10: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003CB18: 8C7E037E
	.long 0x7e143880                                           // 00000003CB1C: 7E143880
	s_mov_b32 s3, exec_lo                                      // 00000003CB20: BE83007E
	ds_store_b16_d16_hi v30, v10 offset:288                    // 00000003CB24: DA840120 00000A1E
	.long 0x7e16390a                                           // 00000003CB2C: 7E16390A
	.long 0xd4cb007e                                           // 00000003CB30: D4CB007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 00000003CB34: 02026137
	s_cbranch_execz 34                                         // 00000003CB38: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x16c4>
	s_waitcnt lgkmcnt(9)                                       // 00000003CB3C: BF89FC97
	v_sub_f32_e32 v11, v20, v12                                // 00000003CB40: 08161914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CB44: BF870091
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000003CB48: 103E16FF 3FB8AA3B
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000003CB50: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000003CB5C: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CB60: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000003CB64: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000003CB70: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000003CB74: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003CB78: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000003CB7C: 7E3E4B1F
	.long 0xd71c001f                                           // 00000003CB80: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000003CB84: 0202411F
	s_waitcnt lgkmcnt(5)                                       // 00000003CB88: BF89FC57
	v_mul_f32_e32 v32, v6, v18                                 // 00000003CB8C: 10402506
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000003CB90: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003CB98: BF870123
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 00000003CB9C: 023E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000003CBA0: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000003CBA8: 02163EFF 7F800000
	v_mul_f32_e32 v31, v13, v32                                // 00000003CBB0: 103E410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CBB4: BF870091
	v_mul_f32_e32 v11, v11, v31                                // 00000003CBB8: 10163F0B
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000003CBBC: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003CBC4: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003CBC8: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000003CBCC: BE83007E
	ds_store_b16 v30, v11 offset:384                           // 00000003CBD0: D87C0180 00000B1E
	.long 0xd4cb007e                                           // 00000003CBD8: D4CB007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 00000003CBDC: 02025F37
	s_cbranch_execz 35                                         // 00000003CBE0: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1770>
	s_waitcnt lgkmcnt(10)                                      // 00000003CBE4: BF89FCA7
	v_sub_f32_e32 v10, v21, v12                                // 00000003CBE8: 08141915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CBEC: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000003CBF0: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000003CBF8: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000003CC04: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003CC08: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000003CC0C: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000003CC14: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000003CC18: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000003CC1C: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000003CC20: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000003CC24: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000003CC2C: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000003CC30: BF870135
	.long 0xd71c000b                                           // 00000003CC34: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000003CC38: 02023F0B
	s_waitcnt lgkmcnt(6)                                       // 00000003CC3C: BF89FC67
	v_mul_f32_e32 v31, v7, v19                                 // 00000003CC40: 103E2707
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000003CC44: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000003CC48: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003CC50: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000003CC54: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000003CC5C: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CC60: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000003CC64: 1014170A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 00000003CC68: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003CC70: 8C7E037E
	.long 0x7f143880                                           // 00000003CC74: 7F143880
	s_mov_b32 s3, exec_lo                                      // 00000003CC78: BE83007E
	ds_store_b16 v30, v10 offset:480                           // 00000003CC7C: D87C01E0 00000A1E
	.long 0x7e16398a                                           // 00000003CC84: 7E16398A
	.long 0xd4cb007e                                           // 00000003CC88: D4CB007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 00000003CC8C: 02025D37
	s_cbranch_execz 35                                         // 00000003CC90: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1820>
	s_waitcnt lgkmcnt(10)                                      // 00000003CC94: BF89FCA7
	v_sub_f32_e32 v11, v16, v12                                // 00000003CC98: 08161910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003CC9C: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000003CCA0: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000003CCA8: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000003CCB0: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000003CCBC: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CCC0: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000003CCC4: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000003CCD0: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000003CCD4: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003CCD8: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000003CCDC: 7E3E4B1F
	.long 0xd71c001f                                           // 00000003CCE0: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000003CCE4: 0202411F
	s_waitcnt lgkmcnt(6)                                       // 00000003CCE8: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003CCEC: BF870121
	v_dual_mul_f32 v32, v8, v14 :: v_dual_cndmask_b32 v31, 0, v31// 00000003CCF0: C8D21D08 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000003CCF8: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000003CD00: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CD08: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 00000003CD0C: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 00000003CD10: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003CD14: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000003CD18: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003CD20: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003CD24: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000003CD28: BE83007E
	ds_store_b16 v30, v11 offset:576                           // 00000003CD2C: D87C0240 00000B1E
	.long 0xd4cb007e                                           // 00000003CD34: D4CB007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 00000003CD38: 02025B37
	s_cbranch_execz 35                                         // 00000003CD3C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x18cc>
	s_waitcnt lgkmcnt(11)                                      // 00000003CD40: BF89FCB7
	v_sub_f32_e32 v10, v17, v12                                // 00000003CD44: 08141911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CD48: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000003CD4C: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000003CD54: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000003CD60: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003CD64: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000003CD68: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000003CD70: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000003CD74: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000003CD78: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000003CD7C: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000003CD80: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000003CD88: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000003CD8C: BF870135
	.long 0xd71c000b                                           // 00000003CD90: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000003CD94: 02023F0B
	s_waitcnt lgkmcnt(7)                                       // 00000003CD98: BF89FC77
	v_mul_f32_e32 v31, v9, v15                                 // 00000003CD9C: 103E1F09
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000003CDA0: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000003CDA4: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003CDAC: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000003CDB0: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000003CDB8: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CDBC: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000003CDC0: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 00000003CDC4: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003CDCC: 8C7E037E
	s_mov_b32 s3, 0                                            // 00000003CDD0: BE830080
	ds_store_b16_d16_hi v30, v10 offset:672                    // 00000003CDD4: DA8402A0 00000A1E
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000003CDDC: 8B6A037E
	s_cbranch_vccz 365                                         // 00000003CDE0: BFA3016D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1e98>
	v_or_b32_e32 v10, 0x5e40, v56                              // 00000003CDE4: 381470FF 00005E40
	v_mov_b32_e32 v63, 0                                       // 00000003CDEC: 7E7E0280
	v_mov_b32_e32 v65, 0                                       // 00000003CDF0: 7E820280
	s_mov_b32 s3, exec_lo                                      // 00000003CDF4: BE83007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000003CDF8: BF870003
	v_subrev_nc_u32_e32 v64, 64, v10                           // 00000003CDFC: 4E8014C0
	ds_load_2addr_b32 v[32:33], v64 offset0:2 offset1:4        // 00000003CE00: D8DC0402 20000040
	ds_load_2addr_b32 v[30:31], v64 offset0:6 offset1:8        // 00000003CE08: D8DC0806 1E000040
	ds_load_2addr_b32 v[10:11], v64 offset0:10 offset1:12      // 00000003CE10: D8DC0C0A 0A000040
	ds_load_b32 v62, v64 offset:56                             // 00000003CE18: D8D80038 3E000040
	.long 0xd4c9007e                                           // 00000003CE20: D4C9007E
	v_cndmask_b32_e32 v1, v55, v154, vcc_lo                    // 00000003CE24: 02033537
	s_cbranch_execz 37                                         // 00000003CE28: BFA50025 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x19c0>
	s_waitcnt lgkmcnt(11)                                      // 00000003CE2C: BF89FCB7
	v_sub_f32_e32 v28, v28, v12                                // 00000003CE30: 0838191C
	ds_load_b32 v64, v64                                       // 00000003CE34: D8D80000 40000040
	s_waitcnt lgkmcnt(8)                                       // 00000003CE3C: BF89FC87
	v_dual_mul_f32 v2, v2, v26 :: v_dual_mul_f32 v65, 0x3fb8aa3b, v28// 00000003CE40: C8C63502 024038FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003CE4C: BF870111
	v_mul_f32_e32 v2, v13, v2                                  // 00000003CE50: 1004050D
	v_fma_f32 v66, 0x3fb8aa3b, v28, -v65                       // 00000003CE54: D6130042 850638FF 3FB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000003CE60: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000003CE64: BF8701C1
	v_dual_sub_f32 v65, v65, v67 :: v_dual_fmac_f32 v66, 0x32a5705f, v28// 00000003CE68: C9408741 414238FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v28                  // 00000003CE74: 7C3638FF C2CE8ED0
	s_waitcnt lgkmcnt(0)                                       // 00000003CE7C: BF89FC07
	v_mul_f32_e32 v2, v64, v2                                  // 00000003CE80: 10040540
	v_add_f32_e32 v65, v65, v66                                // 00000003CE84: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000003CE88: 7E841143
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003CE8C: BF870292
	v_exp_f32_e32 v65, v65                                     // 00000003CE90: 7E824B41
	.long 0xd71c0041                                           // 00000003CE94: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000003CE98: 02028541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003CE9C: BF870121
	v_cndmask_b32_e32 v26, 0, v65, vcc_lo                      // 00000003CEA0: 02348280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v28                  // 00000003CEA4: 7C3C38FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 00000003CEAC: 023434FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003CEB4: BF870001
	.long 0xd5080041                                           // 00000003CEB8: D5080041
	v_sub_co_ci_u32_e32 v1, vcc_lo, v2, v26, vcc_lo            // 00000003CEBC: 42023502
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003CEC0: 8C7E037E
	v_or_b32_e32 v2, 0x5e40, v60                               // 00000003CEC4: 380478FF 00005E40
	s_waitcnt lgkmcnt(7)                                       // 00000003CECC: BF89FC77
	v_lshlrev_b32_e32 v26, 6, v154                             // 00000003CED0: 30353486
	s_mov_b32 s3, exec_lo                                      // 00000003CED4: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003CED8: BF870001
	v_add3_u32 v2, v2, v26, 0xfffff8c0                         // 00000003CEDC: D6550002 03FE3502 FFFFF8C0
	ds_store_b32 v2, v65                                       // 00000003CEE8: D8340000 00004102
	.long 0xd4c9007e                                           // 00000003CEF0: D4C9007E
	v_cndmask_b32_e32 v1, v55, v61, vcc_lo                     // 00000003CEF4: 02027B37
	s_cbranch_execz 33                                         // 00000003CEF8: BFA50021 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1a80>
	v_dual_sub_f32 v26, v29, v12 :: v_dual_mul_f32 v3, v3, v27 // 00000003CEFC: C946191D 1A023703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003CF04: BF870121
	v_dual_mul_f32 v28, 0x3fb8aa3b, v26 :: v_dual_mul_f32 v3, v13, v3// 00000003CF08: C8C634FF 1C02070D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v26                  // 00000003CF14: 7C3634FF C2CE8ED0
	v_fma_f32 v29, 0x3fb8aa3b, v26, -v28                       // 00000003CF1C: D613001D 847234FF 3FB8AA3B
	v_rndne_f32_e32 v60, v28                                   // 00000003CF28: 7E78471C
	s_waitcnt lgkmcnt(4)                                       // 00000003CF2C: BF89FC47
	v_mul_f32_e32 v3, v32, v3                                  // 00000003CF30: 10060720
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003CF34: BF870092
	v_dual_fmac_f32 v29, 0x32a5705f, v26 :: v_dual_sub_f32 v28, v28, v60// 00000003CF38: C80A34FF 1D1C791C 32A5705F
	v_add_f32_e32 v28, v28, v29                                // 00000003CF44: 06383B1C
	v_cvt_i32_f32_e32 v29, v60                                 // 00000003CF48: 7E3A113C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003CF4C: BF870292
	v_exp_f32_e32 v28, v28                                     // 00000003CF50: 7E384B1C
	.long 0xd71c001c                                           // 00000003CF54: D71C001C
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                     // 00000003CF58: 02023B1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003CF5C: BF870121
	v_cndmask_b32_e32 v27, 0, v28, vcc_lo                      // 00000003CF60: 02363880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v26                  // 00000003CF64: 7C3C34FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v27, vcc_lo             // 00000003CF6C: 023436FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003CF74: BF870001
	.long 0xd508003f                                           // 00000003CF78: D508003F
	v_sub_co_ci_u32_e32 v1, vcc_lo, v3, v26, vcc_lo            // 00000003CF7C: 42023503
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003CF80: 8C7E037E
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v26, 0              // 00000003CF84: CA100080 031A0080
	s_mov_b32 s3, exec_lo                                      // 00000003CF8C: BE83007E
	ds_store_b32 v2, v63 offset:128                            // 00000003CF90: D8340080 00003F02
	.long 0xd4c9007e                                           // 00000003CF98: D4C9007E
	v_cndmask_b32_e32 v1, v55, v59, vcc_lo                     // 00000003CF9C: 02027737
	s_cbranch_execz 35                                         // 00000003CFA0: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b30>
	v_sub_f32_e32 v24, v24, v12                                // 00000003CFA4: 08301918
	s_waitcnt lgkmcnt(8)                                       // 00000003CFA8: BF89FC87
	v_mul_f32_e32 v4, v4, v22                                  // 00000003CFAC: 10082D04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000003CFB0: BF8701A2
	v_mul_f32_e32 v26, 0x3fb8aa3b, v24                         // 00000003CFB4: 103430FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v24                  // 00000003CFBC: 7C3630FF C2CE8ED0
	v_mul_f32_e32 v4, v13, v4                                  // 00000003CFC4: 1008090D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000003CFC8: BF8701B3
	v_fma_f32 v27, 0x3fb8aa3b, v24, -v26                       // 00000003CFCC: D613001B 846A30FF 3FB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000003CFD8: 7E38471A
	s_waitcnt lgkmcnt(5)                                       // 00000003CFDC: BF89FC57
	v_mul_f32_e32 v4, v33, v4                                  // 00000003CFE0: 10080921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003CFE4: BF870193
	v_fmac_f32_e32 v27, 0x32a5705f, v24                        // 00000003CFE8: 563630FF 32A5705F
	v_sub_f32_e32 v26, v26, v28                                // 00000003CFF0: 0834391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003CFF4: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000003CFF8: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000003CFFC: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000003D000: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D004: BF870095
	.long 0xd71c001a                                           // 00000003D008: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000003D00C: 0202371A
	v_cndmask_b32_e32 v22, 0, v26, vcc_lo                      // 00000003D010: 022C3480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v24                  // 00000003D014: 7C3C30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D01C: BF870092
	v_cndmask_b32_e32 v22, 0x7f800000, v22, vcc_lo             // 00000003D020: 022C2CFF 7F800000
	.long 0xd508001a                                           // 00000003D028: D508001A
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v22, vcc_lo            // 00000003D02C: 42022D04
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003D030: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D034: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000003D038: BE83007E
	ds_store_b32 v2, v26 offset:256                            // 00000003D03C: D8340100 00001A02
	.long 0xd4c9007e                                           // 00000003D044: D4C9007E
	v_cndmask_b32_e32 v1, v55, v49, vcc_lo                     // 00000003D048: 02026337
	s_cbranch_execz 34                                         // 00000003D04C: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1bd8>
	v_sub_f32_e32 v3, v25, v12                                 // 00000003D050: 08061919
	s_waitcnt lgkmcnt(9)                                       // 00000003D054: BF89FC97
	v_mul_f32_e32 v5, v5, v23                                  // 00000003D058: 100A2F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D05C: BF870091
	v_dual_mul_f32 v4, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, v13, v5// 00000003D060: C8C606FF 04040B0D 3FB8AA3B
	v_fma_f32 v22, 0x3fb8aa3b, v3, -v4                         // 00000003D06C: D6130016 841206FF 3FB8AA3B
	v_rndne_f32_e32 v24, v4                                    // 00000003D078: 7E304704
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003D07C: BF870112
	v_fmac_f32_e32 v22, 0x32a5705f, v3                         // 00000003D080: 562C06FF 32A5705F
	v_sub_f32_e32 v4, v4, v24                                  // 00000003D088: 08083104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000003D08C: BF8701B1
	v_add_f32_e32 v4, v4, v22                                  // 00000003D090: 06082D04
	v_cvt_i32_f32_e32 v22, v24                                 // 00000003D094: 7E2C1118
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000003D098: 7C3606FF C2CE8ED0
	v_exp_f32_e32 v4, v4                                       // 00000003D0A0: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D0A4: BF870095
	.long 0xd71c0004                                           // 00000003D0A8: D71C0004
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 00000003D0AC: 02022D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 00000003D0B0: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000003D0B4: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(5)                                       // 00000003D0BC: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D0C0: BF870092
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v30, v5// 00000003D0C4: CA4608FF 03040B1E 7F800000
	.long 0xd5080003                                           // 00000003D0D0: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000003D0D4: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003D0D8: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000003D0DC: CA100080 04040080
	s_mov_b32 s3, exec_lo                                      // 00000003D0E4: BE83007E
	ds_store_b32 v2, v3 offset:384                             // 00000003D0E8: D8340180 00000302
	.long 0xd4c9007e                                           // 00000003D0F0: D4C9007E
	v_cndmask_b32_e32 v1, v55, v48, vcc_lo                     // 00000003D0F4: 02026137
	s_cbranch_execz 34                                         // 00000003D0F8: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1c84>
	s_waitcnt lgkmcnt(9)                                       // 00000003D0FC: BF89FC97
	v_dual_sub_f32 v3, v20, v12 :: v_dual_mul_f32 v6, v6, v18  // 00000003D100: C9461914 03062506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003D108: BF870121
	v_dual_mul_f32 v5, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v6, v13, v6// 00000003D10C: C8C606FF 05060D0D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000003D118: 7C3606FF C2CE8ED0
	v_fma_f32 v20, 0x3fb8aa3b, v3, -v5                         // 00000003D120: D6130014 841606FF 3FB8AA3B
	v_rndne_f32_e32 v22, v5                                    // 00000003D12C: 7E2C4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D130: BF870091
	v_dual_fmac_f32 v20, 0x32a5705f, v3 :: v_dual_sub_f32 v5, v5, v22// 00000003D134: C80A06FF 14042D05 32A5705F
	v_add_f32_e32 v5, v5, v20                                  // 00000003D140: 060A2905
	v_cvt_i32_f32_e32 v20, v22                                 // 00000003D144: 7E281116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000003D148: BF870292
	v_exp_f32_e32 v5, v5                                       // 00000003D14C: 7E0A4B05
	.long 0xd71c0005                                           // 00000003D150: D71C0005
	v_cndmask_b32_e32 v1, v5, v20, vcc_lo                      // 00000003D154: 02022905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003D158: BF870121
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 00000003D15C: 020A0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000003D160: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v3, 0x7f800000, v5, vcc_lo               // 00000003D168: 02060AFF 7F800000
	s_waitcnt lgkmcnt(6)                                       // 00000003D170: BF89FC67
	v_mul_f32_e32 v5, v31, v6                                  // 00000003D174: 100A0D1F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D178: BF870001
	.long 0xd5080005                                           // 00000003D17C: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v3, vcc_lo             // 00000003D180: 42020705
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003D184: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D188: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000003D18C: BE83007E
	ds_store_b32 v2, v5 offset:512                             // 00000003D190: D8340200 00000502
	.long 0xd4c9007e                                           // 00000003D198: D4C9007E
	v_cndmask_b32_e32 v1, v55, v47, vcc_lo                     // 00000003D19C: 02025F37
	s_cbranch_execz 35                                         // 00000003D1A0: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1d30>
	v_sub_f32_e32 v3, v21, v12                                 // 00000003D1A4: 08061915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D1A8: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000003D1AC: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 00000003D1B4: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 00000003D1C0: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003D1C4: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000003D1C8: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000003D1CC: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 00000003D1D4: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003D1DC: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 00000003D1E0: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 00000003D1E4: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000003D1E8: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003D1EC: BF8700A5
	.long 0xd71c0004                                           // 00000003D1F0: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000003D1F4: 02020B04
	s_waitcnt lgkmcnt(10)                                      // 00000003D1F8: BF89FCA7
	v_dual_mul_f32 v5, v7, v19 :: v_dual_cndmask_b32 v4, 0, v4 // 00000003D1FC: C8D22707 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000003D204: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000003D208: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000003D20C: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(6)                                       // 00000003D214: BF89FC67
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v10, v5// 00000003D218: CA4608FF 03040B0A 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D224: BF870001
	.long 0xd5080004                                           // 00000003D228: D5080004
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000003D22C: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003D230: 8C7E037E
	v_mov_b32_e32 v3, 0                                        // 00000003D234: 7E060280
	v_mov_b32_e32 v5, 0                                        // 00000003D238: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 00000003D23C: BE83007E
	ds_store_b32 v2, v4 offset:640                             // 00000003D240: D8340280 00000402
	.long 0xd4c9007e                                           // 00000003D248: D4C9007E
	v_cndmask_b32_e32 v1, v55, v46, vcc_lo                     // 00000003D24C: 02025D37
	s_cbranch_execz 35                                         // 00000003D250: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1de0>
	v_sub_f32_e32 v4, v16, v12                                 // 00000003D254: 08081910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D258: BF870091
	v_mul_f32_e32 v5, 0x3fb8aa3b, v4                           // 00000003D25C: 100A08FF 3FB8AA3B
	v_fma_f32 v6, 0x3fb8aa3b, v4, -v5                          // 00000003D264: D6130006 841608FF 3FB8AA3B
	v_rndne_f32_e32 v7, v5                                     // 00000003D270: 7E0E4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003D274: BF870221
	v_sub_f32_e32 v5, v5, v7                                   // 00000003D278: 080A0F05
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 00000003D27C: 7C3608FF C2CE8ED0
	v_fmac_f32_e32 v6, 0x32a5705f, v4                          // 00000003D284: 560C08FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003D28C: BF870121
	v_add_f32_e32 v5, v5, v6                                   // 00000003D290: 060A0D05
	v_cvt_i32_f32_e32 v6, v7                                   // 00000003D294: 7E0C1107
	v_exp_f32_e32 v5, v5                                       // 00000003D298: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003D29C: BF8700A5
	.long 0xd71c0005                                           // 00000003D2A0: D71C0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 00000003D2A4: 02020D05
	s_waitcnt lgkmcnt(10)                                      // 00000003D2A8: BF89FCA7
	v_dual_mul_f32 v6, v8, v14 :: v_dual_cndmask_b32 v5, 0, v5 // 00000003D2AC: C8D21D08 06040A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000003D2B4: BF870131
	v_mul_f32_e32 v6, v13, v6                                  // 00000003D2B8: 100C0D0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 00000003D2BC: 7C3C08FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 00000003D2C4: BF89FC77
	v_dual_cndmask_b32 v4, 0x7f800000, v5 :: v_dual_mul_f32 v5, v11, v6// 00000003D2C8: CA460AFF 04040D0B 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D2D4: BF870001
	.long 0xd5080005                                           // 00000003D2D8: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v4, vcc_lo             // 00000003D2DC: 42020905
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003D2E0: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D2E4: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000003D2E8: BE83007E
	ds_store_b32 v2, v5 offset:768                             // 00000003D2EC: D8340300 00000502
	.long 0xd4c9007e                                           // 00000003D2F4: D4C9007E
	v_cndmask_b32_e32 v1, v55, v45, vcc_lo                     // 00000003D2F8: 02025B37
	s_cbranch_execz 35                                         // 00000003D2FC: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1e8c>
	v_sub_f32_e32 v3, v17, v12                                 // 00000003D300: 08061911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D304: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000003D308: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 00000003D310: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 00000003D31C: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003D320: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000003D324: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000003D328: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 00000003D330: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003D338: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 00000003D33C: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 00000003D340: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000003D344: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003D348: BF8700A5
	.long 0xd71c0004                                           // 00000003D34C: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000003D350: 02020B04
	s_waitcnt lgkmcnt(11)                                      // 00000003D354: BF89FCB7
	v_dual_mul_f32 v5, v9, v15 :: v_dual_cndmask_b32 v4, 0, v4 // 00000003D358: C8D21F09 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000003D360: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000003D364: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000003D368: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 00000003D370: BF89FC77
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v62, v5// 00000003D374: CA4608FF 03040B3E 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D380: BF870001
	.long 0xd5080003                                           // 00000003D384: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000003D388: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003D38C: 8C7E037E
	ds_store_b32 v2, v3 offset:896                             // 00000003D390: D8340380 00000302
	s_waitcnt lgkmcnt(0)                                       // 00000003D398: BF89FC07
	s_barrier                                                  // 00000003D39C: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s41                             // 00000003D3A0: 8B6A297E
	s_mov_b32 s3, -1                                           // 00000003D3A4: BE8300C1
	s_cbranch_vccz 175                                         // 00000003D3A8: BFA300AF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2168>
	s_mov_b32 s3, exec_lo                                      // 00000003D3AC: BE83007E
	v_cmpx_gt_i32_e32 0x120, v44                               // 00000003D3B0: 7D8858FF 00000120
	s_cbranch_execz 169                                        // 00000003D3B8: BFA500A9 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2160>
	v_add_nc_u32_e32 v2, 0xffffff00, v44                       // 00000003D3BC: 4A0458FF FFFFFF00
	s_mov_b32 s4, 0                                            // 00000003D3C4: BE840080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D3C8: BF870001
	v_mov_b32_e32 v3, v2                                       // 00000003D3CC: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003D3D0: BF8700A1
	v_add_nc_u32_e32 v3, 0xe0, v3                              // 00000003D3D4: 4A0606FF 000000E0
	s_waitcnt lgkmcnt(0)                                       // 00000003D3DC: BF89FC07
	v_ashrrev_i32_e32 v16, 7, v3                               // 00000003D3E0: 34200687
	v_and_b32_e32 v12, 0x7f, v3                                // 00000003D3E4: 361806FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D3EC: BF870092
	.long 0xd72c0004                                           // 00000003D3F0: D72C0004
	v_cndmask_b32_e32 v1, 0x880, v16, vcc_lo                   // 00000003D3F4: 020220FF 00000880
	v_lshl_add_u32 v4, v12, 1, v4                              // 00000003D3FC: D6460004 0411030C
	ds_load_u16 v20, v4 offset:7776                            // 00000003D404: D8F01E60 14000004
	ds_load_u16 v21, v4 offset:7232                            // 00000003D40C: D8F01C40 15000004
	ds_load_u16 v22, v4 offset:6688                            // 00000003D414: D8F01A20 16000004
	ds_load_u16 v23, v4 offset:6144                            // 00000003D41C: D8F01800 17000004
	ds_load_u16 v24, v4 offset:6416                            // 00000003D424: D8F01910 18000004
	s_waitcnt lgkmcnt(3)                                       // 00000003D42C: BF89FC37
	v_lshlrev_b32_e32 v21, 16, v21                             // 00000003D430: 302A2A90
	s_waitcnt lgkmcnt(1)                                       // 00000003D434: BF89FC17
	v_lshlrev_b32_e32 v23, 16, v23                             // 00000003D438: 302E2E90
	v_lshlrev_b32_e32 v17, 5, v16                              // 00000003D43C: 30222085
	ds_load_u16 v25, v4 offset:6960                            // 00000003D440: D8F01B30 19000004
	ds_load_u16 v26, v4 offset:7504                            // 00000003D448: D8F01D50 1A000004
	ds_load_u16 v27, v4 offset:8048                            // 00000003D450: D8F01F70 1B000004
	ds_load_b128 v[4:7], v17 offset:24384                      // 00000003D458: DBFC5F40 04000011
	ds_load_b128 v[8:11], v17 offset:24400                     // 00000003D460: DBFC5F50 08000011
	v_lshlrev_b32_e32 v20, 16, v20                             // 00000003D468: 30282890
	s_waitcnt lgkmcnt(0)                                       // 00000003D46C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D470: BF870091
	v_dual_mul_f32 v10, v10, v20 :: v_dual_lshlrev_b32 v25, 16, v25// 00000003D474: C8E2290A 0A183290
	v_dual_mul_f32 v7, v7, v25 :: v_dual_lshlrev_b32 v24, 16, v24// 00000003D47C: C8E23307 07183090
	v_mul_f32_e32 v8, v8, v21                                  // 00000003D484: 10102B08
	s_delay_alu instid0(VALU_DEP_2)                            // 00000003D488: BF870002
	v_dual_mul_f32 v4, v4, v23 :: v_dual_mul_f32 v5, v5, v24   // 00000003D48C: C8C62F04 04043105
	v_mul_u32_u24_e32 v18, 48, v12                             // 00000003D494: 162418B0
	ds_load_b128 v[12:15], v17 offset:24192                    // 00000003D498: DBFC5E80 0C000011
	v_lshlrev_b32_e32 v26, 16, v26                             // 00000003D4A0: 30343490
	v_lshlrev_b32_e32 v27, 16, v27                             // 00000003D4A4: 30363690
	v_lshl_add_u32 v28, v16, 4, v18                            // 00000003D4A8: D646001C 04490910
	ds_load_b128 v[16:19], v17 offset:24208                    // 00000003D4B0: DBFC5E90 10000011
	s_waitcnt lgkmcnt(1)                                       // 00000003D4B8: BF89FC17
	v_mul_f32_e32 v12, v12, v4                                 // 00000003D4BC: 1018090C
	v_mul_f32_e32 v4, v13, v5                                  // 00000003D4C0: 10080B0D
	v_dual_mul_f32 v11, v11, v27 :: v_dual_lshlrev_b32 v22, 16, v22// 00000003D4C4: C8E2370B 0B162C90
	v_mul_f32_e32 v5, v15, v7                                  // 00000003D4CC: 100A0F0F
	v_mul_f32_e32 v9, v9, v26                                  // 00000003D4D0: 10123509
	s_waitcnt lgkmcnt(0)                                       // 00000003D4D4: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000003D4D8: BF870243
	v_dual_mul_f32 v7, v16, v8 :: v_dual_mul_f32 v6, v6, v22   // 00000003D4DC: C8C61110 07062D06
	v_cmp_lt_i32_e32 vcc_lo, 31, v3                            // 00000003D4E4: 7C82069F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 00000003D4E8: CC220004 02006104
	v_dual_mul_f32 v8, v17, v9 :: v_dual_mul_f32 v9, v18, v10  // 00000003D4F0: C8C61311 08081512
	v_mul_f32_e32 v6, v14, v6                                  // 00000003D4F8: 100C0D0E
	v_mul_f32_e32 v10, v19, v11                                // 00000003D4FC: 10141713
	v_fma_mixlo_f16 v4, v12, s48, 0                            // 00000003D500: CC210004 0200610C
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 00000003D508: CC220005 02006105
	s_or_b32 s4, vcc_lo, s4                                    // 00000003D510: 8C04046A
	v_fma_mixlo_f16 v5, v6, s48, 0                             // 00000003D514: CC210005 02006106
	v_fma_mixhi_f16 v6, v8, s48, 0                             // 00000003D51C: CC220006 02006108
	v_fma_mixlo_f16 v6, v7, s48, 0                             // 00000003D524: CC210006 02006107
	v_fma_mixhi_f16 v7, v10, s48, 0                            // 00000003D52C: CC220007 0200610A
	v_fma_mixlo_f16 v7, v9, s48, 0                             // 00000003D534: CC210007 02006109
	ds_store_b128 v28, v[4:7]                                  // 00000003D53C: DB7C0000 0000041C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000003D544: 917E047E
	s_cbranch_execnz 65441                                     // 00000003D548: BFA6FFA1 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1ed0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000003D54C: 8C7E047E
	v_lshl_add_u32 v3, v44, 3, 0xffffff00                      // 00000003D550: D6460003 03FD072C FFFFFF00
	s_mov_b32 s4, 0                                            // 00000003D55C: BE840080
	v_add_nc_u32_e32 v2, 0xe0, v2                              // 00000003D560: 4A0404FF 000000E0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000003D568: BF8701A2
	v_and_b32_e32 v4, 0x78, v3                                 // 00000003D56C: 360806FF 00000078
	v_add_nc_u32_e32 v3, 0x700, v3                             // 00000003D574: 4A0606FF 00000700
	v_ashrrev_i32_e32 v5, 4, v2                                // 00000003D57C: 340A0484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003D580: BF870121
	.long 0xd72c0006                                           // 00000003D584: D72C0006
	v_cndmask_b32_e32 v1, 0x110, v5, vcc_lo                    // 00000003D588: 02020AFF 00000110
	v_lshlrev_b32_e32 v8, 2, v5                                // 00000003D590: 30100A82
	v_lshl_add_u32 v9, v4, 1, v6                               // 00000003D594: D6460009 04190304
	ds_load_b128 v[4:7], v9 offset:10496                       // 00000003D59C: DBFC2900 04000009
	ds_load_b32 v8, v8 offset:24448                            // 00000003D5A4: D8D85F80 08000008
	s_waitcnt lgkmcnt(1)                                       // 00000003D5AC: BF89FC17
	v_and_b32_e32 v12, 0xffff0000, v6                          // 00000003D5B0: 36180CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000003D5B8: 300C0C90
	v_and_b32_e32 v13, 0xffff0000, v7                          // 00000003D5BC: 361A0EFF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v4                          // 00000003D5C4: 361408FF FFFF0000
	v_lshlrev_b32_e32 v4, 16, v4                               // 00000003D5CC: 30080890
	v_and_b32_e32 v11, 0xffff0000, v5                          // 00000003D5D0: 36160AFF FFFF0000
	v_lshlrev_b32_e32 v5, 16, v5                               // 00000003D5D8: 300A0A90
	s_waitcnt lgkmcnt(0)                                       // 00000003D5DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000003D5E0: BF8701A3
	v_dual_mul_f32 v14, v8, v4 :: v_dual_lshlrev_b32 v7, 16, v7// 00000003D5E4: C8E20908 0E060E90
	v_mul_f32_e32 v4, v8, v10                                  // 00000003D5EC: 10081508
	v_mul_f32_e32 v10, v8, v5                                  // 00000003D5F0: 10140B08
	v_mul_f32_e32 v5, v8, v11                                  // 00000003D5F4: 100A1708
	v_mul_f32_e32 v11, v8, v6                                  // 00000003D5F8: 10160D08
	v_mul_f32_e32 v6, v8, v12                                  // 00000003D5FC: 100C1908
	v_mul_f32_e32 v12, v8, v7                                  // 00000003D600: 10180F08
	v_mul_f32_e32 v7, v8, v13                                  // 00000003D604: 100E1B08
	v_cmp_lt_i32_e32 vcc_lo, 31, v2                            // 00000003D608: 7C82049F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 00000003D60C: CC220004 02006104
	v_fma_mixlo_f16 v4, v14, s48, 0                            // 00000003D614: CC210004 0200610E
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 00000003D61C: CC220005 02006105
	v_fma_mixlo_f16 v5, v10, s48, 0                            // 00000003D624: CC210005 0200610A
	v_fma_mixhi_f16 v6, v6, s48, 0                             // 00000003D62C: CC220006 02006106
	v_fma_mixlo_f16 v6, v11, s48, 0                            // 00000003D634: CC210006 0200610B
	v_fma_mixhi_f16 v7, v7, s48, 0                             // 00000003D63C: CC220007 02006107
	v_fma_mixlo_f16 v7, v12, s48, 0                            // 00000003D644: CC210007 0200610C
	s_or_b32 s4, vcc_lo, s4                                    // 00000003D64C: 8C04046A
	ds_store_b128 v9, v[4:7] offset:10496                      // 00000003D650: DB7C2900 00000409
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000003D658: 917E047E
	s_cbranch_execnz 65472                                     // 00000003D65C: BFA6FFC0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2060>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003D660: 8C7E037E
	s_mov_b32 s3, 0                                            // 00000003D664: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003D668: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 00000003D66C: 916A037E
	s_cbranch_vccnz 533                                        // 00000003D670: BFA40215 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x29c8>
	s_mov_b32 s3, exec_lo                                      // 00000003D674: BE83007E
	v_cmpx_gt_u32_e32 16, v43                                  // 00000003D678: 7D985690
	s_cbranch_execz 529                                        // 00000003D67C: BFA50211 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x29c4>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000003D680: 7C945680
	s_waitcnt lgkmcnt(0)                                       // 00000003D684: BF89FC07
	ds_load_b96 v[14:16], v1 offset:23280                      // 00000003D688: DBF85AF0 0E000001
	ds_load_b128 v[59:62], v1 offset:23248                     // 00000003D690: DBFC5AD0 3B000001
	ds_load_b128 v[63:66], v1 offset:23264                     // 00000003D698: DBFC5AE0 3F000001
	ds_load_b128 v[10:13], v1 offset:23168                     // 00000003D6A0: DBFC5A80 0A000001
	ds_load_b128 v[6:9], v1 offset:23184                       // 00000003D6A8: DBFC5A90 06000001
	ds_load_b128 v[2:5], v1 offset:23200                       // 00000003D6B0: DBFC5AA0 02000001
	ds_load_b64 v[17:18], v1 offset:23216                      // 00000003D6B8: D9D85AB0 11000001
	v_cndmask_b32_e64 v44, 0, 1.0, vcc_lo                      // 00000003D6C0: D501002C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 00000003D6C8: 7C945681
	ds_load_b128 v[45:48], v1 offset:23232                     // 00000003D6CC: DBFC5AC0 2D000001
	v_cndmask_b32_e64 v33, 0, 1.0, vcc_lo                      // 00000003D6D4: D5010021 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 00000003D6DC: 7C945682
	v_cndmask_b32_e64 v32, 0, 1.0, vcc_lo                      // 00000003D6E0: D5010020 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 00000003D6E8: 7C945683
	v_cndmask_b32_e64 v31, 0, 1.0, vcc_lo                      // 00000003D6EC: D501001F 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 00000003D6F4: 7C945684
	v_cndmask_b32_e64 v29, 0, 1.0, vcc_lo                      // 00000003D6F8: D501001D 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 00000003D700: 7C945685
	v_cndmask_b32_e64 v30, 0, 1.0, vcc_lo                      // 00000003D704: D501001E 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 00000003D70C: 7C945686
	v_cndmask_b32_e64 v28, 0, 1.0, vcc_lo                      // 00000003D710: D501001C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 00000003D718: 7C945687
	v_cndmask_b32_e64 v27, 0, 1.0, vcc_lo                      // 00000003D71C: D501001B 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 00000003D724: 7C945688
	v_cndmask_b32_e64 v25, 0, 1.0, vcc_lo                      // 00000003D728: D5010019 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 00000003D730: 7C945689
	v_cndmask_b32_e64 v23, 0, 1.0, vcc_lo                      // 00000003D734: D5010017 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000003D73C: 7C94568A
	v_cndmask_b32_e64 v26, 0, 1.0, vcc_lo                      // 00000003D740: D501001A 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 00000003D748: 7C94568B
	v_cndmask_b32_e64 v24, 0, 1.0, vcc_lo                      // 00000003D74C: D5010018 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 00000003D754: 7C94568C
	v_cndmask_b32_e64 v20, 0, 1.0, vcc_lo                      // 00000003D758: D5010014 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 00000003D760: 7C94568D
	v_cndmask_b32_e64 v22, 0, 1.0, vcc_lo                      // 00000003D764: D5010016 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 00000003D76C: 7C94568E
	v_cndmask_b32_e64 v21, 0, 1.0, vcc_lo                      // 00000003D770: D5010015 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 00000003D778: 7C94568F
	v_cndmask_b32_e64 v19, 0, 1.0, vcc_lo                      // 00000003D77C: D5010013 01A9E480
	s_waitcnt lgkmcnt(7)                                       // 00000003D784: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000003D788: BF8700B1
	v_fmac_f32_e32 v22, v19, v15                               // 00000003D78C: 562C1F13
	v_fmac_f32_e32 v21, v19, v16                               // 00000003D790: 562A2113
	s_waitcnt lgkmcnt(1)                                       // 00000003D794: BF89FC17
	v_dual_fmac_f32 v23, v19, v64 :: v_dual_fmac_f32 v22, v21, v18// 00000003D798: C8008113 17162515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000003D7A0: BF8700D1
	v_dual_fmac_f32 v26, v19, v65 :: v_dual_fmac_f32 v23, v21, v3// 00000003D7A4: C8008313 1A160715
	v_fmac_f32_e32 v25, v19, v63                               // 00000003D7AC: 56327F13
	ds_load_b32 v18, v1 offset:22880                           // 00000003D7B0: D8D85960 12000001
	v_fmac_f32_e32 v26, v21, v4                                // 00000003D7B8: 56340915
	v_dual_fmac_f32 v28, v19, v61 :: v_dual_fmac_f32 v25, v21, v2// 00000003D7BC: C8007B13 1C180515
	v_dual_fmac_f32 v29, v19, v59 :: v_dual_fmac_f32 v28, v21, v8// 00000003D7C4: C8007713 1D1C1115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D7CC: BF870091
	v_dual_fmac_f32 v30, v19, v60 :: v_dual_fmac_f32 v29, v21, v6// 00000003D7D0: C8007913 1E1C0D15
	v_dual_fmac_f32 v27, v19, v62 :: v_dual_fmac_f32 v30, v21, v7// 00000003D7D8: C8007D13 1B1E0F15
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D7E0: BF870091
	v_dual_fmac_f32 v24, v19, v66 :: v_dual_fmac_f32 v27, v21, v9// 00000003D7E4: C8008513 181A1315
	v_fmac_f32_e32 v24, v21, v5                                // 00000003D7EC: 56300B15
	ds_load_b128 v[2:5], v1 offset:23072                       // 00000003D7F0: DBFC5A20 02000001
	s_waitcnt lgkmcnt(2)                                       // 00000003D7F8: BF89FC27
	v_fmac_f32_e32 v31, v19, v48                               // 00000003D7FC: 563E6113
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003D800: BF870091
	v_dual_fmac_f32 v32, v19, v47 :: v_dual_fmac_f32 v31, v21, v13// 00000003D804: C8005F13 201E1B15
	v_dual_fmac_f32 v33, v19, v46 :: v_dual_fmac_f32 v32, v21, v12// 00000003D80C: C8005D13 21201915
	v_fmac_f32_e32 v44, v19, v45                               // 00000003D814: 56585B13
	ds_load_b128 v[45:48], v1 offset:24064                     // 00000003D818: DBFC5E00 2D000001
	v_dual_fmac_f32 v33, v21, v11 :: v_dual_fmac_f32 v20, v19, v14// 00000003D820: C8001715 21141D13
	ds_load_b128 v[59:62], v1 offset:23104                     // 00000003D828: DBFC5A40 3B000001
	ds_load_b128 v[63:66], v1 offset:23136                     // 00000003D830: DBFC5A60 3F000001
	ds_load_b128 v[67:70], v1 offset:23120                     // 00000003D838: DBFC5A50 43000001
	ds_load_b32 v14, v1 offset:23152                           // 00000003D840: D8D85A70 0E000001
	v_fmac_f32_e32 v44, v21, v10                               // 00000003D848: 56581515
	ds_load_b128 v[6:9], v1 offset:23056                       // 00000003D84C: DBFC5A10 06000001
	ds_load_b128 v[10:13], v1 offset:23040                     // 00000003D854: DBFC5A00 0A000001
	s_waitcnt lgkmcnt(5)                                       // 00000003D85C: BF89FC57
	v_fmac_f32_e32 v44, v22, v59                               // 00000003D860: 56587716
	v_dual_fmac_f32 v33, v22, v60 :: v_dual_fmac_f32 v20, v21, v17// 00000003D864: C8007916 21142315
	s_waitcnt lgkmcnt(3)                                       // 00000003D86C: BF89FC37
	v_fmac_f32_e32 v29, v22, v67                               // 00000003D870: 563A8716
	v_fmac_f32_e32 v31, v22, v62                               // 00000003D874: 563E7D16
	s_waitcnt lgkmcnt(2)                                       // 00000003D878: BF89FC27
	v_fmac_f32_e32 v20, v22, v14                               // 00000003D87C: 56281D16
	ds_load_b128 v[14:17], v1 offset:22976                     // 00000003D880: DBFC59C0 0E000001
	v_fmac_f32_e32 v24, v22, v66                               // 00000003D888: 56308516
	v_fmac_f32_e32 v32, v22, v61                               // 00000003D88C: 56407B16
	ds_load_b64 v[66:67], v1 offset:22944                      // 00000003D890: D9D859A0 42000001
	s_waitcnt lgkmcnt(2)                                       // 00000003D898: BF89FC27
	v_fmac_f32_e32 v33, v20, v11                               // 00000003D89C: 56421714
	v_fmac_f32_e32 v24, v20, v5                                // 00000003D8A0: 56300B14
	s_waitcnt lgkmcnt(1)                                       // 00000003D8A4: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000003D8A8: BF8701B1
	v_dual_fmac_f32 v33, v24, v15 :: v_dual_fmac_f32 v30, v22, v68// 00000003D8AC: C8001F18 211E8916
	v_fmac_f32_e32 v29, v20, v6                                // 00000003D8B4: 563A0D14
	v_dual_fmac_f32 v25, v22, v63 :: v_dual_fmac_f32 v44, v20, v10// 00000003D8B8: C8007F16 192C1514
	v_dual_fmac_f32 v23, v22, v64 :: v_dual_fmac_f32 v30, v20, v7// 00000003D8C0: C8008116 171E0F14
	v_fmac_f32_e32 v26, v22, v65                               // 00000003D8C8: 56348316
	ds_load_b128 v[59:62], v1 offset:22992                     // 00000003D8CC: DBFC59D0 3B000001
	ds_load_b96 v[63:65], v1 offset:23008                      // 00000003D8D4: DBF859E0 3F000001
	v_dual_fmac_f32 v28, v22, v69 :: v_dual_fmac_f32 v25, v20, v2// 00000003D8DC: C8008B16 1C180514
	v_dual_fmac_f32 v27, v22, v70 :: v_dual_fmac_f32 v32, v20, v12// 00000003D8E4: C8008D16 1B201914
	v_fmac_f32_e32 v23, v20, v3                                // 00000003D8EC: 562E0714
	v_fmac_f32_e32 v26, v20, v4                                // 00000003D8F0: 56340914
	v_fmac_f32_e32 v31, v20, v13                               // 00000003D8F4: 563E1B14
	s_delay_alu instid0(VALU_DEP_4)                            // 00000003D8F8: BF870004
	v_fmac_f32_e32 v27, v20, v9                                // 00000003D8FC: 56361314
	ds_load_b128 v[2:5], v1 offset:22848                       // 00000003D900: DBFC5940 02000001
	s_waitcnt lgkmcnt(1)                                       // 00000003D908: BF89FC17
	v_fmac_f32_e32 v26, v24, v65                               // 00000003D90C: 56348318
	v_fmac_f32_e32 v28, v20, v8                                // 00000003D910: 56381114
	ds_load_b128 v[6:9], v1 offset:22928                       // 00000003D914: DBFC5990 06000001
	ds_load_b128 v[10:13], v1 offset:22912                     // 00000003D91C: DBFC5980 0A000001
	v_fmac_f32_e32 v29, v24, v59                               // 00000003D924: 563A7718
	s_waitcnt lgkmcnt(1)                                       // 00000003D928: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D92C: BF870001
	v_fmac_f32_e32 v29, v26, v6                                // 00000003D930: 563A0D1A
	v_fmac_f32_e32 v31, v24, v17                               // 00000003D934: 563E2318
	v_fmac_f32_e32 v44, v24, v14                               // 00000003D938: 56581D18
	v_fmac_f32_e32 v23, v24, v64                               // 00000003D93C: 562E8118
	v_fmac_f32_e32 v32, v24, v16                               // 00000003D940: 56402118
	ds_load_b128 v[14:17], v1 offset:22864                     // 00000003D944: DBFC5950 0E000001
	v_fmac_f32_e32 v23, v26, v67                               // 00000003D94C: 562E871A
	s_waitcnt lgkmcnt(0)                                       // 00000003D950: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D954: BF870001
	v_fmac_f32_e32 v29, v23, v14                               // 00000003D958: 563A1D17
	v_fmac_f32_e32 v27, v24, v62                               // 00000003D95C: 56367D18
	v_fmac_f32_e32 v30, v24, v60                               // 00000003D960: 563C7918
	v_fmac_f32_e32 v25, v24, v63                               // 00000003D964: 56327F18
	v_dual_fmac_f32 v33, v26, v11 :: v_dual_fmac_f32 v28, v24, v61// 00000003D968: C800171A 211C7B18
	ds_load_b128 v[59:62], v1 offset:22800                     // 00000003D970: DBFC5910 3B000001
	v_fmac_f32_e32 v32, v26, v12                               // 00000003D978: 5640191A
	v_fmac_f32_e32 v31, v26, v13                               // 00000003D97C: 563E1B1A
	v_fmac_f32_e32 v44, v26, v10                               // 00000003D980: 5658151A
	ds_load_b128 v[10:13], v1 offset:22784                     // 00000003D984: DBFC5900 0A000001
	ds_load_b96 v[63:65], v1 offset:22736                      // 00000003D98C: DBF858D0 3F000001
	v_fmac_f32_e32 v27, v26, v9                                // 00000003D994: 5636131A
	v_fmac_f32_e32 v30, v26, v7                                // 00000003D998: 563C0F1A
	v_fmac_f32_e32 v25, v26, v66                               // 00000003D99C: 5632851A
	v_fmac_f32_e32 v28, v26, v8                                // 00000003D9A0: 5638111A
	ds_load_b128 v[6:9], v1 offset:22720                       // 00000003D9A4: DBFC58C0 06000001
	ds_load_b64 v[66:67], v1 offset:22672                      // 00000003D9AC: D9D85890 42000001
	v_fmac_f32_e32 v33, v23, v3                                // 00000003D9B4: 56420717
	v_fmac_f32_e32 v25, v23, v18                               // 00000003D9B8: 56322517
	v_fmac_f32_e32 v28, v23, v16                               // 00000003D9BC: 56382117
	v_fmac_f32_e32 v27, v23, v17                               // 00000003D9C0: 56362317
	v_fmac_f32_e32 v30, v23, v15                               // 00000003D9C4: 563C1F17
	ds_load_b128 v[14:17], v1 offset:22528                     // 00000003D9C8: DBFC5800 0E000001
	s_waitcnt lgkmcnt(5)                                       // 00000003D9D0: BF89FC57
	v_fmac_f32_e32 v27, v25, v62                               // 00000003D9D4: 56367D19
	v_fmac_f32_e32 v28, v25, v61                               // 00000003D9D8: 56387B19
	v_fmac_f32_e32 v30, v25, v60                               // 00000003D9DC: 563C7919
	s_waitcnt lgkmcnt(3)                                       // 00000003D9E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003D9E4: BF870112
	v_fmac_f32_e32 v28, v27, v65                               // 00000003D9E8: 5638831B
	v_fmac_f32_e32 v30, v27, v64                               // 00000003D9EC: 563C811B
	s_waitcnt lgkmcnt(1)                                       // 00000003D9F0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003D9F4: BF870001
	v_fmac_f32_e32 v30, v28, v67                               // 00000003D9F8: 563C871C
	v_dual_fmac_f32 v44, v23, v2 :: v_dual_fmac_f32 v33, v25, v11// 00000003D9FC: C8000517 2C201719
	v_fmac_f32_e32 v31, v23, v5                                // 00000003DA04: 563E0B17
	v_fmac_f32_e32 v32, v23, v4                                // 00000003DA08: 56400917
	ds_load_b128 v[2:5], v1 offset:22656                       // 00000003DA0C: DBFC5880 02000001
	v_fmac_f32_e32 v44, v25, v10                               // 00000003DA14: 56581519
	v_fmac_f32_e32 v29, v25, v59                               // 00000003DA18: 563A7719
	v_fmac_f32_e32 v31, v25, v13                               // 00000003DA1C: 563E1B19
	v_fmac_f32_e32 v32, v25, v12                               // 00000003DA20: 56401919
	ds_load_b128 v[10:13], v1 offset:22592                     // 00000003DA24: DBFC5840 0A000001
	ds_load_b32 v18, v1 offset:22608                           // 00000003DA2C: D8D85850 12000001
	v_fmac_f32_e32 v33, v27, v7                                // 00000003DA34: 56420F1B
	v_fmac_f32_e32 v29, v27, v63                               // 00000003DA38: 563A7F1B
	ds_load_b64 v[59:60], v1 offset:22400                      // 00000003DA3C: D9D85780 3B000001
	v_dual_fmac_f32 v32, v27, v8 :: v_dual_fmac_f32 v29, v28, v66// 00000003DA44: C800111B 201C851C
	ds_load_b128 v[63:66], v1 offset:24304                     // 00000003DA4C: DBFC5EF0 3F000001
	s_waitcnt lgkmcnt(2)                                       // 00000003DA54: BF89FC27
	v_fmac_f32_e32 v29, v30, v18                               // 00000003DA58: 563A251E
	v_dual_fmac_f32 v44, v27, v6 :: v_dual_fmac_f32 v33, v28, v3// 00000003DA5C: C8000D1B 2C20071C
	v_fmac_f32_e32 v31, v27, v9                                // 00000003DA64: 563E131B
	ds_load_b96 v[6:8], v1 offset:22464                        // 00000003DA68: DBF857C0 06000001
	ds_load_b32 v9, v1 offset:22336                            // 00000003DA70: D8D85740 09000001
	v_fmac_f32_e32 v44, v28, v2                                // 00000003DA78: 5658051C
	v_fmac_f32_e32 v32, v28, v4                                // 00000003DA7C: 5640091C
	v_fmac_f32_e32 v31, v28, v5                                // 00000003DA80: 563E0B1C
	v_fmac_f32_e32 v33, v30, v11                               // 00000003DA84: 5642171E
	ds_load_b128 v[2:5], v1 offset:24256                       // 00000003DA88: DBFC5EC0 02000001
	v_fmac_f32_e32 v44, v30, v10                               // 00000003DA90: 5658151E
	v_fmac_f32_e32 v32, v30, v12                               // 00000003DA94: 5640191E
	v_fmac_f32_e32 v31, v30, v13                               // 00000003DA98: 563E1B1E
	v_fmac_f32_e32 v33, v29, v15                               // 00000003DA9C: 56421F1D
	s_waitcnt lgkmcnt(3)                                       // 00000003DAA0: BF89FC37
	v_mul_f32_e32 v72, v65, v21                                // 00000003DAA4: 10902B41
	v_fmac_f32_e32 v44, v29, v14                               // 00000003DAA8: 56581D1D
	v_fmac_f32_e32 v32, v29, v16                               // 00000003DAAC: 5640211D
	v_fmac_f32_e32 v31, v29, v17                               // 00000003DAB0: 563E231D
	s_waitcnt lgkmcnt(2)                                       // 00000003DAB4: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003DAB8: BF8700A1
	v_fmac_f32_e32 v32, v31, v8                                // 00000003DABC: 5640111F
	v_fmac_f32_e32 v33, v31, v7                                // 00000003DAC0: 56420F1F
	v_dual_fmac_f32 v44, v31, v6 :: v_dual_fmac_f32 v33, v32, v60// 00000003DAC4: C8000D1F 2C207920
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003DACC: BF870001
	v_fmac_f32_e32 v44, v32, v59                               // 00000003DAD0: 56587720
	ds_load_b128 v[59:62], v1 offset:24288                     // 00000003DAD4: DBFC5EE0 3B000001
	s_waitcnt lgkmcnt(1)                                       // 00000003DADC: BF89FC17
	v_fma_mixlo_f16 v49, v5, v31, 0                            // 00000003DAE0: CC210031 02023F05
	v_mul_f32_e32 v15, v3, v33                                 // 00000003DAE8: 101E4303
	v_fmac_f32_e32 v44, v33, v9                                // 00000003DAEC: 56581321
	ds_load_b128 v[6:9], v1 offset:24272                       // 00000003DAF0: DBFC5ED0 06000001
	ds_load_b128 v[10:13], v1 offset:24112                     // 00000003DAF8: DBFC5E30 0A000001
	v_fma_mixlo_f16 v18, v3, v33, 0                            // 00000003DB00: CC210012 02024303
	v_mul_f32_e32 v14, v2, v44                                 // 00000003DB08: 101C5902
	v_fma_mixlo_f16 v2, v2, v44, 0                             // 00000003DB0C: CC210002 02025902
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003DB14: BF870113
	v_fma_mix_f32 v15, v18, -1.0, v15 op_sel_hi:[1,1,0]        // 00000003DB18: CC20000F 1C3DE712
	v_fma_mix_f32 v3, v2, -1.0, v14 op_sel_hi:[1,1,0]          // 00000003DB20: CC200003 1C39E702
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000003DB28: BF870232
	.long 0x7f1c150f                                           // 00000003DB2C: 7F1C150F
	v_mul_f32_e32 v15, v4, v32                                 // 00000003DB30: 101E4104
	.long 0x7f043912                                           // 00000003DB34: 7F043912
	v_cvt_f16_f32_e32 v14, v3                                  // 00000003DB38: 7E1C1503
	v_fma_mixlo_f16 v3, v4, v32, 0                             // 00000003DB3C: CC210003 02024104
	v_mul_f32_e32 v4, v5, v31                                  // 00000003DB44: 10083F05
	s_waitcnt lgkmcnt(2)                                       // 00000003DB48: BF89FC27
	v_fma_mixlo_f16 v69, v60, v23, 0                           // 00000003DB4C: CC210045 02022F3C
	s_waitcnt lgkmcnt(1)                                       // 00000003DB54: BF89FC17
	v_mul_f32_e32 v16, v7, v30                                 // 00000003DB58: 10203D07
	v_fma_mixlo_f16 v67, v7, v30, 0                            // 00000003DB5C: CC210043 02023D07
	v_fma_mix_f32 v7, v3, -1.0, v15 op_sel_hi:[1,1,0]          // 00000003DB64: CC200007 1C3DE703
	v_mul_f32_e32 v5, v6, v29                                  // 00000003DB6C: 100A3B06
	v_fma_mixlo_f16 v68, v9, v27, 0                            // 00000003DB70: CC210044 02023709
	.long 0x7f063931                                           // 00000003DB78: 7F063931
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000003DB7C: BF8701D4
	v_cvt_f16_f32_e32 v15, v7                                  // 00000003DB80: 7E1E1507
	v_mul_f32_e32 v7, v8, v28                                  // 00000003DB84: 100E3908
	v_fma_mix_f32 v17, v49, -1.0, v4 op_sel_hi:[1,1,0]         // 00000003DB88: CC200011 1C11E731
	v_fma_mixlo_f16 v4, v6, v29, 0                             // 00000003DB90: CC210004 02023B06
	v_fma_mix_f32 v6, v67, -1.0, v16 op_sel_hi:[1,1,0]         // 00000003DB98: CC200006 1C41E743
	.long 0x7f1e1511                                           // 00000003DBA0: 7F1E1511
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000003DBA4: BF870193
	v_fma_mix_f32 v5, v4, -1.0, v5 op_sel_hi:[1,1,0]           // 00000003DBA8: CC200005 1C15E704
	.long 0x7f201506                                           // 00000003DBB0: 7F201506
	v_fma_mixlo_f16 v6, v59, v25, 0                            // 00000003DBB4: CC210006 0202333B
	.long 0x7f083943                                           // 00000003DBBC: 7F083943
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000003DBC0: BF8701C4
	v_cvt_f16_f32_e32 v16, v5                                  // 00000003DBC4: 7E201505
	v_fma_mixlo_f16 v5, v8, v28, 0                             // 00000003DBC8: CC210005 02023908
	v_dual_mul_f32 v8, v9, v27 :: v_dual_mul_f32 v9, v59, v25  // 00000003DBD0: C8C63709 0808333B
	v_dual_mul_f32 v59, v60, v23 :: v_dual_mul_f32 v60, v61, v26// 00000003DBD8: C8C62F3C 3B3C353D
	v_fma_mix_f32 v7, v5, -1.0, v7 op_sel_hi:[1,1,0]           // 00000003DBE0: CC200007 1C1DE705
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003DBE8: BF870213
	v_fma_mix_f32 v8, v68, -1.0, v8 op_sel_hi:[1,1,0]          // 00000003DBEC: CC200008 1C21E744
	v_fma_mix_f32 v9, v6, -1.0, v9 op_sel_hi:[1,1,0]           // 00000003DBF4: CC200009 1C25E706
	s_delay_alu instid0(VALU_DEP_4)                            // 00000003DBFC: BF870004
	v_fma_mix_f32 v70, v69, -1.0, v59 op_sel_hi:[1,1,0]        // 00000003DC00: CC200046 1CEDE745
	.long 0x7f0c3945                                           // 00000003DC08: 7F0C3945
	v_cvt_f16_f32_e32 v17, v7                                  // 00000003DC0C: 7E221507
	v_fma_mixlo_f16 v7, v61, v26, 0                            // 00000003DC10: CC210007 0202353D
	.long 0x7f221508                                           // 00000003DC18: 7F221508
	v_cvt_f16_f32_e32 v59, v9                                  // 00000003DC1C: 7E761509
	.long 0x7f761546                                           // 00000003DC20: 7F761546
	v_mul_f32_e32 v9, v62, v24                                 // 00000003DC24: 1012313E
	v_fma_mix_f32 v8, v7, -1.0, v60 op_sel_hi:[1,1,0]          // 00000003DC28: CC200008 1CF1E707
	v_fma_mixlo_f16 v70, v62, v24, 0                           // 00000003DC30: CC210046 0202313E
	v_dual_mul_f32 v61, v63, v20 :: v_dual_mul_f32 v62, v64, v22// 00000003DC38: C8C6293F 3D3E2D40
	v_fma_mixlo_f16 v64, v64, v22, 0                           // 00000003DC40: CC210040 02022D40
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003DC48: BF870214
	v_cvt_f16_f32_e32 v60, v8                                  // 00000003DC4C: 7E781508
	v_fma_mix_f32 v71, v70, -1.0, v9 op_sel_hi:[1,1,0]         // 00000003DC50: CC200047 1C25E746
	v_fma_mixlo_f16 v8, v63, v20, 0                            // 00000003DC58: CC210008 0202293F
	v_fma_mixlo_f16 v9, v65, v21, 0                            // 00000003DC60: CC210009 02022B41
	v_fma_mix_f32 v62, v64, -1.0, v62 op_sel_hi:[1,1,0]        // 00000003DC68: CC20003E 1CF9E740
	v_mul_f32_e32 v65, v66, v19                                // 00000003DC70: 10822742
	v_fma_mixlo_f16 v66, v66, v19, 0                           // 00000003DC74: CC210042 02022742
	v_fma_mix_f32 v61, v8, -1.0, v61 op_sel_hi:[1,1,0]         // 00000003DC7C: CC20003D 1CF5E708
	v_fma_mix_f32 v63, v9, -1.0, v72 op_sel_hi:[1,1,0]         // 00000003DC84: CC20003F 1D21E709
	.long 0x7f781547                                           // 00000003DC8C: 7F781547
	.long 0x7f103940                                           // 00000003DC90: 7F103940
	v_fma_mix_f32 v71, v66, -1.0, v65 op_sel_hi:[1,1,0]        // 00000003DC94: CC200047 1D05E742
	v_cvt_f16_f32_e32 v61, v61                                 // 00000003DC9C: 7E7A153D
	.long 0x7f7a153e                                           // 00000003DCA0: 7F7A153E
	v_cvt_f16_f32_e32 v62, v63                                 // 00000003DCA4: 7E7C153F
	.long 0x7f123942                                           // 00000003DCA8: 7F123942
	ds_load_b128 v[63:66], v1 offset:24080                     // 00000003DCAC: DBFC5E10 3F000001
	v_mul_u32_u24_e32 v72, 48, v43                             // 00000003DCB4: 169056B0
	.long 0x7f0e3946                                           // 00000003DCB8: 7F0E3946
	.long 0x7f0a3944                                           // 00000003DCBC: 7F0A3944
	v_mul_f32_e32 v18, v45, v44                                // 00000003DCC0: 1024592D
	v_fma_mixlo_f16 v43, v45, v44, 0                           // 00000003DCC4: CC21002B 0202592D
	v_mul_f32_e32 v44, v46, v33                                // 00000003DCCC: 1058432E
	v_fma_mixlo_f16 v33, v46, v33, 0                           // 00000003DCD0: CC210021 0202432E
	ds_store_b128 v72, v[6:9] offset:19216                     // 00000003DCD8: DB7C4B10 00000648
	ds_store_b128 v72, v[2:5] offset:19200                     // 00000003DCE0: DB7C4B00 00000248
	ds_load_b128 v[2:5], v1 offset:24096                       // 00000003DCE8: DBFC5E20 02000001
	v_dual_mul_f32 v7, v47, v32 :: v_dual_mul_f32 v8, v48, v31 // 00000003DCF0: C8C6412F 07083F30
	v_fma_mix_f32 v44, v33, -1.0, v44 op_sel_hi:[1,1,0]        // 00000003DCF8: CC20002C 1CB1E721
	.long 0x7f7c1547                                           // 00000003DD00: 7F7C1547
	s_delay_alu instid0(VALU_DEP_2)                            // 00000003DD04: BF870002
	.long 0x7f0c152c                                           // 00000003DD08: 7F0C152C
	v_fma_mixlo_f16 v44, v47, v32, 0                           // 00000003DD0C: CC21002C 0202412F
	s_waitcnt lgkmcnt(3)                                       // 00000003DD14: BF89FC37
	v_mul_f32_e32 v9, v63, v29                                 // 00000003DD18: 10123B3F
	v_fma_mix_f32 v18, v43, -1.0, v18 op_sel_hi:[1,1,0]        // 00000003DD1C: CC200012 1C49E72B
	v_fma_mixlo_f16 v45, v63, v29, 0                           // 00000003DD24: CC21002D 02023B3F
	v_fma_mix_f32 v7, v44, -1.0, v7 op_sel_hi:[1,1,0]          // 00000003DD2C: CC200007 1C1DE72C
	v_fma_mixlo_f16 v46, v65, v28, 0                           // 00000003DD34: CC21002E 02023941
	.long 0x7f563921                                           // 00000003DD3C: 7F563921
	v_cvt_f16_f32_e32 v6, v18                                  // 00000003DD40: 7E0C1512
	v_fma_mixlo_f16 v18, v48, v31, 0                           // 00000003DD44: CC210012 02023F30
	v_mul_f32_e32 v31, v64, v30                                // 00000003DD4C: 103E3D40
	v_fma_mixlo_f16 v30, v64, v30, 0                           // 00000003DD50: CC21001E 02023D40
	v_fma_mix_f32 v9, v45, -1.0, v9 op_sel_hi:[1,1,0]          // 00000003DD58: CC200009 1C25E72D
	v_cvt_f16_f32_e32 v7, v7                                   // 00000003DD60: 7E0E1507
	.long 0x7f583912                                           // 00000003DD64: 7F583912
	s_delay_alu instid0(VALU_DEP_4)                            // 00000003DD68: BF870004
	v_fma_mix_f32 v29, v30, -1.0, v31 op_sel_hi:[1,1,0]        // 00000003DD6C: CC20001D 1C7DE71E
	v_mul_f32_e32 v31, v65, v28                                // 00000003DD74: 103E3941
	v_fma_mix_f32 v8, v18, -1.0, v8 op_sel_hi:[1,1,0]          // 00000003DD78: CC200008 1C21E712
	v_mul_f32_e32 v28, v66, v27                                // 00000003DD80: 10383742
	v_fma_mixlo_f16 v27, v66, v27, 0                           // 00000003DD84: CC21001B 02023742
	.long 0x7f5a391e                                           // 00000003DD8C: 7F5A391E
	s_delay_alu instid0(VALU_DEP_4)                            // 00000003DD90: BF870004
	.long 0x7f0e1508                                           // 00000003DD94: 7F0E1508
	v_cvt_f16_f32_e32 v8, v9                                   // 00000003DD98: 7E101509
	.long 0x7f10151d                                           // 00000003DD9C: 7F10151D
	v_fma_mix_f32 v9, v46, -1.0, v31 op_sel_hi:[1,1,0]         // 00000003DDA0: CC200009 1C7DE72E
	s_waitcnt lgkmcnt(0)                                       // 00000003DDA8: BF89FC07
	v_mul_f32_e32 v29, v2, v25                                 // 00000003DDAC: 103A3302
	v_fma_mixlo_f16 v2, v2, v25, 0                             // 00000003DDB0: CC210002 02023302
	v_mul_f32_e32 v25, v3, v23                                 // 00000003DDB8: 10322F03
	v_fma_mixlo_f16 v31, v3, v23, 0                            // 00000003DDBC: CC21001F 02022F03
	v_fma_mix_f32 v3, v27, -1.0, v28 op_sel_hi:[1,1,0]         // 00000003DDC4: CC200003 1C71E71B
	v_cvt_f16_f32_e32 v9, v9                                   // 00000003DDCC: 7E121509
	v_mul_f32_e32 v23, v4, v26                                 // 00000003DDD0: 102E3504
	.long 0x7f5c391b                                           // 00000003DDD4: 7F5C391B
	v_fma_mix_f32 v25, v31, -1.0, v25 op_sel_hi:[1,1,0]        // 00000003DDD8: CC200019 1C65E71F
	.long 0x7f121503                                           // 00000003DDE0: 7F121503
	v_fma_mixlo_f16 v3, v4, v26, 0                             // 00000003DDE4: CC210003 02023504
	v_mul_f32_e32 v26, v11, v22                                // 00000003DDEC: 10342D0B
	v_fma_mix_f32 v28, v2, -1.0, v29 op_sel_hi:[1,1,0]         // 00000003DDF0: CC20001C 1C75E702
	v_fma_mixlo_f16 v11, v11, v22, 0                           // 00000003DDF8: CC21000B 02022D0B
	.long 0x7f04391f                                           // 00000003DE00: 7F04391F
	v_fma_mix_f32 v4, v3, -1.0, v23 op_sel_hi:[1,1,0]          // 00000003DE04: CC200004 1C5DE703
	.long 0x7f2e1519                                           // 00000003DE0C: 7F2E1519
	v_cvt_f16_f32_e32 v23, v28                                 // 00000003DE10: 7E2E151C
	v_mul_f32_e32 v25, v5, v24                                 // 00000003DE14: 10323105
	v_fma_mixlo_f16 v28, v5, v24, 0                            // 00000003DE18: CC21001C 02023105
	v_cvt_f16_f32_e32 v24, v4                                  // 00000003DE20: 7E301504
	v_mul_f32_e32 v5, v10, v20                                 // 00000003DE24: 100A290A
	v_fma_mixlo_f16 v4, v10, v20, 0                            // 00000003DE28: CC210004 0202290A
	v_fma_mix_f32 v20, v11, -1.0, v26 op_sel_hi:[1,1,0]        // 00000003DE30: CC200014 1C69E70B
	v_fma_mix_f32 v22, v28, -1.0, v25 op_sel_hi:[1,1,0]        // 00000003DE38: CC200016 1C65E71C
	v_mul_f32_e32 v25, v12, v21                                // 00000003DE40: 10322B0C
	.long 0x7f06391c                                           // 00000003DE44: 7F06391C
	v_fma_mix_f32 v10, v4, -1.0, v5 op_sel_hi:[1,1,0]          // 00000003DE48: CC20000A 1C15E704
	v_fma_mixlo_f16 v5, v12, v21, 0                            // 00000003DE50: CC210005 02022B0C
	v_mul_f32_e32 v21, v13, v19                                // 00000003DE58: 102A270D
	v_fma_mixlo_f16 v13, v13, v19, 0                           // 00000003DE5C: CC21000D 0202270D
	.long 0x7f08390b                                           // 00000003DE64: 7F08390B
	.long 0x7f301516                                           // 00000003DE68: 7F301516
	v_fma_mix_f32 v12, v5, -1.0, v25 op_sel_hi:[1,1,0]         // 00000003DE6C: CC20000C 1C65E705
	v_cvt_f16_f32_e32 v25, v10                                 // 00000003DE74: 7E32150A
	v_fma_mix_f32 v10, v13, -1.0, v21 op_sel_hi:[1,1,0]        // 00000003DE78: CC20000A 1C55E70D
	.long 0x7f0a390d                                           // 00000003DE80: 7F0A390D
	.long 0x7f321514                                           // 00000003DE84: 7F321514
	v_cvt_f16_f32_e32 v26, v12                                 // 00000003DE88: 7E34150C
	s_delay_alu instid0(VALU_DEP_4)                            // 00000003DE8C: BF870004
	.long 0x7f34150a                                           // 00000003DE90: 7F34150A
	ds_store_b128 v72, v[59:62] offset:19984                   // 00000003DE94: DB7C4E10 00003B48
	ds_store_b128 v72, v[14:17] offset:19968                   // 00000003DE9C: DB7C4E00 00000E48
	ds_store_b128 v72, v[2:5] offset:20752                     // 00000003DEA4: DB7C5110 00000248
	ds_store_b128 v72, v[43:46] offset:20736                   // 00000003DEAC: DB7C5100 00002B48
	ds_store_b128 v72, v[23:26] offset:21520                   // 00000003DEB4: DB7C5410 00001748
	ds_store_b128 v72, v[6:9] offset:21504                     // 00000003DEBC: DB7C5400 00000648
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003DEC4: 8C7E037E
	v_lshlrev_b32_e32 v59, 1, v153                             // 00000003DEC8: 30773281
	s_waitcnt lgkmcnt(0)                                       // 00000003DECC: BF89FC07
	s_barrier                                                  // 00000003DED0: BFBD0000
	v_cmp_eq_u32_e32 vcc_lo, 0, v34                            // 00000003DED4: 7C944480
	v_mul_u32_u24_e32 v60, 48, v55                             // 00000003DED8: 16786EB0
	s_cmp_lt_i32 s54, s39                                      // 00000003DEDC: BF042736
	ds_load_u16 v2, v59 offset:6416                            // 00000003DEE0: D8F01910 0200003B
	ds_load_u16 v3, v59 offset:7776                            // 00000003DEE8: D8F01E60 0300003B
	ds_load_u16 v4, v59 offset:7232                            // 00000003DEF0: D8F01C40 0400003B
	s_waitcnt lgkmcnt(0)                                       // 00000003DEF8: BF89FC07
	ds_load_u16 v5, v59 offset:6688                            // 00000003DEFC: D8F01A20 0500003B
	ds_load_u16 v6, v59 offset:6144                            // 00000003DF04: D8F01800 0600003B
	ds_load_b128 v[22:25], v60 offset:19984                    // 00000003DF0C: DBFC4E10 1600003C
	ds_load_b128 v[18:21], v60 offset:19968                    // 00000003DF14: DBFC4E00 1200003C
	ds_load_b128 v[26:29], v60 offset:19200                    // 00000003DF1C: DBFC4B00 1A00003C
	ds_load_b128 v[30:33], v60 offset:19216                    // 00000003DF24: DBFC4B10 1E00003C
	s_cselect_b32 s3, -1, 0                                    // 00000003DF2C: 980380C1
	s_or_b32 s4, s54, 1                                        // 00000003DF30: 8C048136
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000003DF34: BF870159
	s_cmp_lt_i32 s4, s39                                       // 00000003DF38: BF042704
	s_cselect_b32 s4, -1, 0                                    // 00000003DF3C: 980480C1
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000003DF40: 30040490
	s_waitcnt lgkmcnt(4)                                       // 00000003DF44: BF89FC47
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000003DF48: 300C0C90
	.long 0x7f141502                                           // 00000003DF4C: 7F141502
	ds_load_u16 v2, v59 offset:6960                            // 00000003DF50: D8F01B30 0200003B
	v_cvt_f16_f32_e32 v10, v6                                  // 00000003DF58: 7E141506
	s_waitcnt lgkmcnt(0)                                       // 00000003DF5C: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000003DF60: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003DF64: BF8700A1
	.long 0x7f161502                                           // 00000003DF68: 7F161502
	v_lshlrev_b32_e32 v2, 16, v5                               // 00000003DF6C: 30040A90
	v_cvt_f16_f32_e32 v11, v2                                  // 00000003DF70: 7E161502
	ds_load_u16 v2, v59 offset:7504                            // 00000003DF74: D8F01D50 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000003DF7C: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000003DF80: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003DF84: BF8700A1
	.long 0x7f181502                                           // 00000003DF88: 7F181502
	v_lshlrev_b32_e32 v2, 16, v4                               // 00000003DF8C: 30040890
	v_cvt_f16_f32_e32 v12, v2                                  // 00000003DF90: 7E181502
	ds_load_u16 v2, v59 offset:8048                            // 00000003DF94: D8F01F70 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000003DF9C: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000003DFA0: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003DFA4: BF8700A1
	.long 0x7f1a1502                                           // 00000003DFA8: 7F1A1502
	v_lshlrev_b32_e32 v2, 16, v3                               // 00000003DFAC: 30040690
	v_cvt_f16_f32_e32 v13, v2                                  // 00000003DFB0: 7E1A1502
	ds_load_u16 v2, v59 offset:8592                            // 00000003DFB4: D8F02190 0200003B
	ds_load_u16 v3, v59 offset:9952                            // 00000003DFBC: D8F026E0 0300003B
	ds_load_u16 v4, v59 offset:9408                            // 00000003DFC4: D8F024C0 0400003B
	ds_load_u16 v5, v59 offset:8864                            // 00000003DFCC: D8F022A0 0500003B
	ds_load_u16 v6, v59 offset:8320                            // 00000003DFD4: D8F02080 0600003B
	s_waitcnt lgkmcnt(4)                                       // 00000003DFDC: BF89FC47
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000003DFE0: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000003DFE4: BF8700B1
	.long 0x7f1c1502                                           // 00000003DFE8: 7F1C1502
	s_waitcnt lgkmcnt(0)                                       // 00000003DFEC: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v6                               // 00000003DFF0: 30040C90
	v_cvt_f16_f32_e32 v14, v2                                  // 00000003DFF4: 7E1C1502
	ds_load_u16 v2, v59 offset:9136                            // 00000003DFF8: D8F023B0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000003E000: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000003E004: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E008: BF8700A1
	.long 0x7f1e1502                                           // 00000003E00C: 7F1E1502
	v_lshlrev_b32_e32 v2, 16, v5                               // 00000003E010: 30040A90
	v_cvt_f16_f32_e32 v15, v2                                  // 00000003E014: 7E1E1502
	ds_load_u16 v2, v59 offset:9680                            // 00000003E018: D8F025D0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000003E020: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000003E024: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E028: BF8700A1
	.long 0x7f201502                                           // 00000003E02C: 7F201502
	v_lshlrev_b32_e32 v2, 16, v4                               // 00000003E030: 30040890
	v_cvt_f16_f32_e32 v16, v2                                  // 00000003E034: 7E201502
	ds_load_u16 v2, v59 offset:10224                           // 00000003E038: D8F027F0 0200003B
	s_waitcnt lgkmcnt(0)                                       // 00000003E040: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000003E044: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E048: BF8700A1
	.long 0x7f221502                                           // 00000003E04C: 7F221502
	v_lshlrev_b32_e32 v2, 16, v3                               // 00000003E050: 30040690
	v_cvt_f16_f32_e32 v17, v2                                  // 00000003E054: 7E221502
	v_dual_mov_b32 v2, s20 :: v_dual_mov_b32 v3, s21           // 00000003E058: CA100014 02020015
	v_dual_mov_b32 v4, s22 :: v_dual_mov_b32 v5, s23           // 00000003E060: CA100016 04040017
	v_dual_mov_b32 v6, s24 :: v_dual_mov_b32 v7, s25           // 00000003E068: CA100018 06060019
	v_dual_mov_b32 v8, s26 :: v_dual_mov_b32 v9, s27           // 00000003E070: CA10001A 0808001B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000003E078: BF870121
	v_wmma_f32_16x16x16_f16 v[61:68], v[18:25], v[10:17], v[2:9]// 00000003E07C: CC40403D 1C0A1512
	v_mov_b32_e32 v18, 0                                       // 00000003E084: 7E240280
	v_wmma_f32_16x16x16_f16 v[61:68], v[26:33], v[10:17], v[61:68]// 00000003E088: CC40403D 1CF6151A
	v_dual_mov_b32 v10, 0 :: v_dual_cndmask_b32 v11, 0x7060302, v149// 00000003E090: CA120080 0A0B2AFF 07060302
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 00000003E09C: CA100080 0C0C0080
	v_mov_b32_e32 v14, 0                                       // 00000003E0A4: 7E1C0280
	s_waitcnt vmcnt(7)                                         // 00000003E0A8: BF891FF7
	s_delay_alu instid0(VALU_DEP_3)                            // 00000003E0AC: BF870003
	v_mov_b32_dpp v10, v42 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000003E0B0: 7E1402FA FF00B12A
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 00000003E0B8: CA100080 0F100080
	v_mov_b32_e32 v17, 0                                       // 00000003E0C0: 7E220280
	s_waitcnt vmcnt(6)                                         // 00000003E0C4: BF891BF7
	v_mov_b32_dpp v12, v41 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000003E0C8: 7E1802FA FF00B129
	v_perm_b32 v10, v42, v10, v11                              // 00000003E0D0: D644000A 042E152A
	s_waitcnt vmcnt(5)                                         // 00000003E0D8: BF8917F7
	v_mov_b32_dpp v13, v40 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000003E0DC: 7E1A02FA FF00B128
	s_waitcnt vmcnt(4)                                         // 00000003E0E4: BF8913F7
	v_mov_b32_dpp v14, v39 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000003E0E8: 7E1C02FA FF00B127
	s_waitcnt vmcnt(3)                                         // 00000003E0F0: BF890FF7
	v_mov_b32_dpp v15, v38 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000003E0F4: 7E1E02FA FF00B126
	s_waitcnt vmcnt(2)                                         // 00000003E0FC: BF890BF7
	v_mov_b32_dpp v16, v37 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000003E100: 7E2002FA FF00B125
	s_waitcnt vmcnt(1)                                         // 00000003E108: BF8907F7
	v_mov_b32_dpp v17, v35 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000003E10C: 7E2202FA FF00B123
	s_waitcnt vmcnt(0)                                         // 00000003E114: BF8903F7
	v_mov_b32_dpp v18, v36 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000003E118: 7E2402FA FF00B124
	v_perm_b32 v12, v41, v12, v11                              // 00000003E120: D644000C 042E1929
	v_perm_b32 v13, v40, v13, v11                              // 00000003E128: D644000D 042E1B28
	v_perm_b32 v14, v39, v14, v11                              // 00000003E130: D644000E 042E1D27
	v_perm_b32 v15, v38, v15, v11                              // 00000003E138: D644000F 042E1F26
	v_perm_b32 v16, v37, v16, v11                              // 00000003E140: D6440010 042E2125
	v_perm_b32 v17, v35, v17, v11                              // 00000003E148: D6440011 042E2323
	v_perm_b32 v11, v36, v18, v11                              // 00000003E150: D644000B 042E2524
	v_lshlrev_b32_e32 v18, 16, v10                             // 00000003E158: 30241490
	v_and_b32_e32 v19, 0xffff0000, v10                         // 00000003E15C: 362614FF FFFF0000
	ds_load_b128 v[30:33], v60 offset:21520                    // 00000003E164: DBFC5410 1E00003C
	ds_load_b128 v[26:29], v60 offset:21504                    // 00000003E16C: DBFC5400 1A00003C
	ds_load_b128 v[38:41], v60 offset:20752                    // 00000003E174: DBFC5110 2600003C
	ds_load_b128 v[34:37], v60 offset:20736                    // 00000003E17C: DBFC5100 2200003C
	v_cmp_eq_u32_e32 vcc_lo, 0, v154                           // 00000003E184: 7C953480
	v_cvt_f16_f32_e32 v10, v18                                 // 00000003E188: 7E141512
	.long 0x7f141513                                           // 00000003E18C: 7F141513
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003E190: BF870112
	v_cndmask_b16 v18, 0, v10, s3                              // 00000003E194: D65D0012 000E1480
	v_cndmask_b16 v18, 0, v10, s4                              // 00000003E19C: D65D5012 00121480
	v_lshlrev_b32_e32 v10, 16, v12                             // 00000003E1A4: 30141890
	s_or_b32 s3, s54, 2                                        // 00000003E1A8: 8C038236
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E1AC: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003E1B0: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003E1B4: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003E1B8: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003E1BC: BF870481
	v_cndmask_b16 v19, 0, v10, s3                              // 00000003E1C0: D65D0013 000E1480
	v_and_b32_e32 v10, 0xffff0000, v12                         // 00000003E1C8: 361418FF FFFF0000
	s_or_b32 s3, s54, 3                                        // 00000003E1D0: 8C038336
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E1D4: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003E1D8: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003E1DC: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003E1E0: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003E1E4: BF870481
	v_cndmask_b16 v19, 0, v10, s3                              // 00000003E1E8: D65D4013 000E1480
	v_lshlrev_b32_e32 v10, 16, v13                             // 00000003E1F0: 30141A90
	s_or_b32 s3, s54, 4                                        // 00000003E1F4: 8C038436
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E1F8: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003E1FC: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003E200: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003E204: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003E208: BF870481
	v_cndmask_b16 v20, 0, v10, s3                              // 00000003E20C: D65D0014 000E1480
	v_and_b32_e32 v10, 0xffff0000, v13                         // 00000003E214: 36141AFF FFFF0000
	s_or_b32 s3, s54, 5                                        // 00000003E21C: 8C038536
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E220: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003E224: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003E228: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003E22C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003E230: BF870481
	v_cndmask_b16 v20, 0, v10, s3                              // 00000003E234: D65D4014 000E1480
	v_lshlrev_b32_e32 v10, 16, v14                             // 00000003E23C: 30141C90
	s_or_b32 s3, s54, 6                                        // 00000003E240: 8C038636
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E244: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003E248: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003E24C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003E250: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003E254: BF870481
	v_cndmask_b16 v21, 0, v10, s3                              // 00000003E258: D65D0015 000E1480
	v_and_b32_e32 v10, 0xffff0000, v14                         // 00000003E260: 36141CFF FFFF0000
	s_or_b32 s3, s54, 7                                        // 00000003E268: 8C038736
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E26C: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003E270: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003E274: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003E278: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003E27C: BF870481
	v_cndmask_b16 v21, 0, v10, s3                              // 00000003E280: D65D4015 000E1480
	v_lshlrev_b32_e32 v10, 16, v15                             // 00000003E288: 30141E90
	s_or_b32 s3, s54, 8                                        // 00000003E28C: 8C038836
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E290: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003E294: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003E298: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003E29C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003E2A0: BF870481
	v_cndmask_b16 v22, 0, v10, s3                              // 00000003E2A4: D65D0016 000E1480
	v_and_b32_e32 v10, 0xffff0000, v15                         // 00000003E2AC: 36141EFF FFFF0000
	s_or_b32 s3, s54, 9                                        // 00000003E2B4: 8C038936
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E2B8: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003E2BC: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003E2C0: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003E2C4: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003E2C8: BF870481
	v_cndmask_b16 v22, 0, v10, s3                              // 00000003E2CC: D65D4016 000E1480
	v_lshlrev_b32_e32 v10, 16, v16                             // 00000003E2D4: 30142090
	s_or_b32 s3, s54, 10                                       // 00000003E2D8: 8C038A36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E2DC: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003E2E0: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003E2E4: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003E2E8: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003E2EC: BF870481
	v_cndmask_b16 v23, 0, v10, s3                              // 00000003E2F0: D65D0017 000E1480
	v_and_b32_e32 v10, 0xffff0000, v16                         // 00000003E2F8: 361420FF FFFF0000
	s_or_b32 s3, s54, 11                                       // 00000003E300: 8C038B36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E304: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003E308: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003E30C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003E310: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003E314: BF870481
	v_cndmask_b16 v23, 0, v10, s3                              // 00000003E318: D65D4017 000E1480
	v_lshlrev_b32_e32 v10, 16, v17                             // 00000003E320: 30142290
	s_or_b32 s3, s54, 12                                       // 00000003E324: 8C038C36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E328: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003E32C: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003E330: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003E334: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003E338: BF870481
	v_cndmask_b16 v24, 0, v10, s3                              // 00000003E33C: D65D0018 000E1480
	v_and_b32_e32 v10, 0xffff0000, v17                         // 00000003E344: 361422FF FFFF0000
	s_or_b32 s3, s54, 13                                       // 00000003E34C: 8C038D36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E350: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003E354: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003E358: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003E35C: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003E360: BF870481
	v_cndmask_b16 v24, 0, v10, s3                              // 00000003E364: D65D4018 000E1480
	v_lshlrev_b32_e32 v10, 16, v11                             // 00000003E36C: 30141690
	s_or_b32 s3, s54, 14                                       // 00000003E370: 8C038E36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E374: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003E378: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003E37C: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003E380: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003E384: BF870481
	v_cndmask_b16 v25, 0, v10, s3                              // 00000003E388: D65D0019 000E1480
	v_and_b32_e32 v10, 0xffff0000, v11                         // 00000003E390: 361416FF FFFF0000
	s_or_b32 s3, s54, 15                                       // 00000003E398: 8C038F36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E39C: BF870099
	s_cmp_lt_i32 s3, s39                                       // 00000003E3A0: BF042703
	v_cvt_f16_f32_e32 v10, v10                                 // 00000003E3A4: 7E14150A
	s_cselect_b32 s3, -1, 0                                    // 00000003E3A8: 980380C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000003E3AC: BF870481
	v_cndmask_b16 v25, 0, v10, s3                              // 00000003E3B0: D65D4019 000E1480
	s_waitcnt lgkmcnt(2)                                       // 00000003E3B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003E3BC: BF8700A1
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[18:25], v[2:9]// 00000003E3C0: CC40400A 1C0A251A
	s_waitcnt lgkmcnt(0)                                       // 00000003E3C8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[34:41], v[18:25], v[10:17]// 00000003E3CC: CC40400A 1C2A2522
	v_cvt_f16_f32_e32 v18, v61                                 // 00000003E3D4: 7E24153D
	v_mad_u32_u24 v22, 0x110, v154, v59                        // 00000003E3D8: D60B0016 04EF34FF 00000110
	.long 0x7f24153e                                           // 00000003E3E4: 7F24153E
	v_cvt_f16_f32_e32 v19, v63                                 // 00000003E3E8: 7E26153F
	.long 0x7f261540                                           // 00000003E3EC: 7F261540
	v_cvt_f16_f32_e32 v20, v65                                 // 00000003E3F0: 7E281541
	.long 0x7f281542                                           // 00000003E3F4: 7F281542
	v_cvt_f16_f32_e32 v21, v67                                 // 00000003E3F8: 7E2A1543
	.long 0x7f2a1544                                           // 00000003E3FC: 7F2A1544
	ds_store_b16 v22, v18 offset:14848                         // 00000003E400: D87C3A00 00001216
	ds_store_b16_d16_hi v22, v18 offset:15392                  // 00000003E408: DA843C20 00001216
	ds_store_b16 v22, v19 offset:15936                         // 00000003E410: D87C3E40 00001316
	ds_store_b16_d16_hi v22, v19 offset:16480                  // 00000003E418: DA844060 00001316
	ds_store_b16 v22, v20 offset:17024                         // 00000003E420: D87C4280 00001416
	ds_store_b16_d16_hi v22, v20 offset:17568                  // 00000003E428: DA8444A0 00001416
	ds_store_b16 v22, v21 offset:18112                         // 00000003E430: D87C46C0 00001516
	ds_store_b16_d16_hi v22, v21 offset:18656                  // 00000003E438: DA8448E0 00001516
	v_fma_mixlo_f16 v18, v139, s51, 0                          // 00000003E440: CC210012 0200678B
	v_fma_mixhi_f16 v18, v138, s51, 0                          // 00000003E448: CC220012 0200678A
	v_mov_b32_e32 v20, 0x3020706                               // 00000003E450: 7E2802FF 03020706
	v_cndmask_b32_e32 v61, 0x5040100, v149, vcc_lo             // 00000003E458: 027B2AFF 05040100
	s_waitcnt lgkmcnt(0)                                       // 00000003E460: BF89FC07
	s_barrier                                                  // 00000003E464: BFBD0000
	ds_load_b128 v[46:49], v57 offset:14864                    // 00000003E468: DBFC3A10 2E000039
	ds_load_b128 v[42:45], v57 offset:14848                    // 00000003E470: DBFC3A00 2A000039
	ds_load_b128 v[67:70], v57 offset:14896                    // 00000003E478: DBFC3A30 43000039
	ds_load_b128 v[63:66], v57 offset:14880                    // 00000003E480: DBFC3A20 3F000039
	v_dual_mov_b32 v19, v18 :: v_dual_cndmask_b32 v62, 0x7060302, v20// 00000003E488: CA120112 133E28FF 07060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E494: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000003E498: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v26, v18, v19, v61                              // 00000003E4A4: D644001A 04F62712
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000003E4AC: BF8700B3
	v_perm_b32 v27, v18, v19, v62                              // 00000003E4B0: D644001B 04FA2712
	v_fma_mixlo_f16 v18, v137, s51, 0                          // 00000003E4B8: CC210012 02006789
	v_fma_mixhi_f16 v18, v136, s51, 0                          // 00000003E4C0: CC220012 02006788
	v_mov_b32_e32 v19, v18                                     // 00000003E4C8: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E4CC: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000003E4D0: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v28, v18, v19, v61                              // 00000003E4DC: D644001C 04F62712
	v_perm_b32 v29, v18, v19, v62                              // 00000003E4E4: D644001D 04FA2712
	v_fma_mixlo_f16 v18, v135, s51, 0                          // 00000003E4EC: CC210012 02006787
	v_fma_mixhi_f16 v18, v134, s51, 0                          // 00000003E4F4: CC220012 02006786
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E4FC: BF870091
	v_mov_b32_e32 v19, v18                                     // 00000003E500: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000003E504: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000003E510: BF8700C1
	v_perm_b32 v30, v18, v19, v61                              // 00000003E514: D644001E 04F62712
	v_perm_b32 v31, v18, v19, v62                              // 00000003E51C: D644001F 04FA2712
	v_fma_mixlo_f16 v18, v133, s51, 0                          // 00000003E524: CC210012 02006785
	v_fma_mixhi_f16 v18, v54, s51, 0                           // 00000003E52C: CC220012 02006736
	v_mov_b32_e32 v19, v18                                     // 00000003E534: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E538: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000003E53C: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v32, v18, v19, v61                              // 00000003E548: D6440020 04F62712
	v_perm_b32 v33, v18, v19, v62                              // 00000003E550: D6440021 04FA2712
	v_fma_mixlo_f16 v18, v132, s51, 0                          // 00000003E558: CC210012 02006784
	v_fma_mixhi_f16 v18, v131, s51, 0                          // 00000003E560: CC220012 02006783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E568: BF870091
	v_mov_b32_e32 v19, v18                                     // 00000003E56C: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000003E570: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000003E57C: BF8700C1
	v_perm_b32 v34, v18, v19, v61                              // 00000003E580: D6440022 04F62712
	v_perm_b32 v35, v18, v19, v62                              // 00000003E588: D6440023 04FA2712
	v_fma_mixlo_f16 v18, v130, s51, 0                          // 00000003E590: CC210012 02006782
	v_fma_mixhi_f16 v18, v129, s51, 0                          // 00000003E598: CC220012 02006781
	v_mov_b32_e32 v19, v18                                     // 00000003E5A0: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E5A4: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000003E5A8: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v36, v18, v19, v61                              // 00000003E5B4: D6440024 04F62712
	v_perm_b32 v37, v18, v19, v62                              // 00000003E5BC: D6440025 04FA2712
	v_fma_mixlo_f16 v18, v128, s51, 0                          // 00000003E5C4: CC210012 02006780
	v_fma_mixhi_f16 v18, v127, s51, 0                          // 00000003E5CC: CC220012 0200677F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E5D4: BF870091
	v_mov_b32_e32 v19, v18                                     // 00000003E5D8: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000003E5DC: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000003E5E8: BF8700C1
	v_perm_b32 v38, v18, v19, v61                              // 00000003E5EC: D6440026 04F62712
	v_perm_b32 v39, v18, v19, v62                              // 00000003E5F4: D6440027 04FA2712
	v_fma_mixlo_f16 v18, v126, s51, 0                          // 00000003E5FC: CC210012 0200677E
	v_fma_mixhi_f16 v18, v53, s51, 0                           // 00000003E604: CC220012 02006735
	v_mov_b32_e32 v19, v18                                     // 00000003E60C: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003E610: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000003E614: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v40, v18, v19, v61                              // 00000003E620: D6440028 04F62712
	v_perm_b32 v41, v18, v19, v62                              // 00000003E628: D6440029 04FA2712
	s_waitcnt lgkmcnt(2)                                       // 00000003E630: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[26:33], v[2:9]// 00000003E634: CC404012 1C0A352A
	s_waitcnt lgkmcnt(0)                                       // 00000003E63C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003E640: BF870001
	v_wmma_f32_16x16x16_f16 v[18:25], v[63:70], v[34:41], v[18:25]// 00000003E644: CC404012 1C4A453F
	ds_load_b128 v[63:66], v57 offset:10496                    // 00000003E64C: DBFC2900 3F000039
	ds_load_b128 v[67:70], v57 offset:10512                    // 00000003E654: DBFC2910 43000039
	s_waitcnt lgkmcnt(0)                                       // 00000003E65C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[63:70], v[26:33], v[2:9]// 00000003E660: CC40402A 1C0A353F
	ds_load_b128 v[26:29], v57 offset:10528                    // 00000003E668: DBFC2920 1A000039
	ds_load_b128 v[30:33], v57 offset:10544                    // 00000003E670: DBFC2930 1E000039
	s_waitcnt lgkmcnt(0)                                       // 00000003E678: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[26:33], v[34:41], v[42:49]// 00000003E67C: CC40402A 1CAA451A
	v_fma_mixlo_f16 v27, v125, s51, 0                          // 00000003E684: CC21001B 0200677D
	v_fma_mixhi_f16 v27, v124, s51, 0                          // 00000003E68C: CC22001B 0200677C
	v_fma_mixlo_f16 v29, v123, s51, 0                          // 00000003E694: CC21001D 0200677B
	v_fma_mixhi_f16 v29, v122, s51, 0                          // 00000003E69C: CC22001D 0200677A
	v_fma_mixlo_f16 v31, v121, s51, 0                          // 00000003E6A4: CC21001F 02006779
	v_fma_mixhi_f16 v31, v120, s51, 0                          // 00000003E6AC: CC22001F 02006778
	v_fma_mixlo_f16 v33, v119, s51, 0                          // 00000003E6B4: CC210021 02006777
	v_fma_mixhi_f16 v33, v52, s51, 0                           // 00000003E6BC: CC220021 02006734
	v_mov_b32_e32 v28, v27                                     // 00000003E6C4: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000003E6C8: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000003E6CC: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003E6D0: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000003E6D4: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000003E6D8: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003E6E4: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000003E6E8: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000003E6F4: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003E700: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000003E704: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000003E710: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000003E718: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000003E720: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000003E728: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000003E730: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000003E738: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000003E740: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000003E748: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14928                    // 00000003E750: DBFC3A50 26000039
	ds_load_b128 v[34:37], v57 offset:14912                    // 00000003E758: DBFC3A40 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000003E760: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000003E764: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10576                    // 00000003E76C: DBFC2950 26000039
	ds_load_b128 v[34:37], v57 offset:10560                    // 00000003E774: DBFC2940 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000003E77C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000003E780: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v118, s51, 0                          // 00000003E788: CC21001B 02006776
	v_fma_mixhi_f16 v27, v117, s51, 0                          // 00000003E790: CC22001B 02006775
	v_fma_mixlo_f16 v29, v116, s51, 0                          // 00000003E798: CC21001D 02006774
	v_fma_mixhi_f16 v29, v115, s51, 0                          // 00000003E7A0: CC22001D 02006773
	v_fma_mixlo_f16 v31, v114, s51, 0                          // 00000003E7A8: CC21001F 02006772
	v_fma_mixhi_f16 v31, v113, s51, 0                          // 00000003E7B0: CC22001F 02006771
	v_fma_mixlo_f16 v33, v112, s51, 0                          // 00000003E7B8: CC210021 02006770
	v_fma_mixhi_f16 v33, v51, s51, 0                           // 00000003E7C0: CC220021 02006733
	v_mov_b32_e32 v28, v27                                     // 00000003E7C8: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000003E7CC: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000003E7D0: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003E7D4: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000003E7D8: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000003E7DC: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003E7E8: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000003E7EC: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000003E7F8: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003E804: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000003E808: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000003E814: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000003E81C: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000003E824: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000003E82C: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000003E834: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000003E83C: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000003E844: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000003E84C: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14960                    // 00000003E854: DBFC3A70 26000039
	ds_load_b128 v[34:37], v57 offset:14944                    // 00000003E85C: DBFC3A60 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000003E864: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000003E868: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10608                    // 00000003E870: DBFC2970 26000039
	ds_load_b128 v[34:37], v57 offset:10592                    // 00000003E878: DBFC2960 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000003E880: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000003E884: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v111, s51, 0                          // 00000003E88C: CC21001B 0200676F
	v_fma_mixhi_f16 v27, v110, s51, 0                          // 00000003E894: CC22001B 0200676E
	v_fma_mixlo_f16 v29, v109, s51, 0                          // 00000003E89C: CC21001D 0200676D
	v_fma_mixhi_f16 v29, v108, s51, 0                          // 00000003E8A4: CC22001D 0200676C
	v_fma_mixlo_f16 v31, v107, s51, 0                          // 00000003E8AC: CC21001F 0200676B
	v_fma_mixhi_f16 v31, v106, s51, 0                          // 00000003E8B4: CC22001F 0200676A
	v_fma_mixlo_f16 v33, v105, s51, 0                          // 00000003E8BC: CC210021 02006769
	v_fma_mixhi_f16 v33, v50, s51, 0                           // 00000003E8C4: CC220021 02006732
	v_mov_b32_e32 v28, v27                                     // 00000003E8CC: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000003E8D0: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000003E8D4: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003E8D8: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000003E8DC: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000003E8E0: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003E8EC: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000003E8F0: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000003E8FC: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003E908: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000003E90C: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000003E918: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000003E920: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000003E928: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000003E930: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000003E938: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000003E940: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000003E948: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000003E950: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:14992                    // 00000003E958: DBFC3A90 26000039
	ds_load_b128 v[34:37], v57 offset:14976                    // 00000003E960: DBFC3A80 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000003E968: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000003E96C: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10640                    // 00000003E974: DBFC2990 26000039
	ds_load_b128 v[34:37], v57 offset:10624                    // 00000003E97C: DBFC2980 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000003E984: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000003E988: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v104, s51, 0                          // 00000003E990: CC21001B 02006768
	v_fma_mixhi_f16 v27, v103, s51, 0                          // 00000003E998: CC22001B 02006767
	v_fma_mixlo_f16 v29, v102, s51, 0                          // 00000003E9A0: CC21001D 02006766
	v_fma_mixhi_f16 v29, v101, s51, 0                          // 00000003E9A8: CC22001D 02006765
	v_fma_mixlo_f16 v31, v100, s51, 0                          // 00000003E9B0: CC21001F 02006764
	v_fma_mixhi_f16 v31, v99, s51, 0                           // 00000003E9B8: CC22001F 02006763
	v_fma_mixlo_f16 v33, v98, s51, 0                           // 00000003E9C0: CC210021 02006762
	v_fma_mixhi_f16 v33, v58, s51, 0                           // 00000003E9C8: CC220021 0200673A
	v_mov_b32_e32 v28, v27                                     // 00000003E9D0: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000003E9D4: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000003E9D8: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003E9DC: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000003E9E0: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000003E9E4: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003E9F0: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000003E9F4: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000003EA00: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003EA0C: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000003EA10: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000003EA1C: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000003EA24: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000003EA2C: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000003EA34: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000003EA3C: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000003EA44: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000003EA4C: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000003EA54: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15024                    // 00000003EA5C: DBFC3AB0 26000039
	ds_load_b128 v[34:37], v57 offset:15008                    // 00000003EA64: DBFC3AA0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000003EA6C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000003EA70: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10672                    // 00000003EA78: DBFC29B0 26000039
	ds_load_b128 v[34:37], v57 offset:10656                    // 00000003EA80: DBFC29A0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000003EA88: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000003EA8C: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v97, s51, 0                           // 00000003EA94: CC21001B 02006761
	v_fma_mixhi_f16 v27, v96, s51, 0                           // 00000003EA9C: CC22001B 02006760
	v_fma_mixlo_f16 v29, v95, s51, 0                           // 00000003EAA4: CC21001D 0200675F
	v_fma_mixhi_f16 v29, v94, s51, 0                           // 00000003EAAC: CC22001D 0200675E
	v_fma_mixlo_f16 v31, v93, s51, 0                           // 00000003EAB4: CC21001F 0200675D
	v_fma_mixhi_f16 v31, v92, s51, 0                           // 00000003EABC: CC22001F 0200675C
	v_fma_mixlo_f16 v33, v91, s51, 0                           // 00000003EAC4: CC210021 0200675B
	v_fma_mixhi_f16 v33, v152, s51, 0                          // 00000003EACC: CC220021 02006798
	v_mov_b32_e32 v28, v27                                     // 00000003EAD4: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000003EAD8: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000003EADC: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003EAE0: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000003EAE4: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000003EAE8: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003EAF4: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000003EAF8: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000003EB04: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003EB10: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000003EB14: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000003EB20: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000003EB28: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000003EB30: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000003EB38: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000003EB40: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000003EB48: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000003EB50: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000003EB58: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15056                    // 00000003EB60: DBFC3AD0 26000039
	ds_load_b128 v[34:37], v57 offset:15040                    // 00000003EB68: DBFC3AC0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000003EB70: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000003EB74: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10704                    // 00000003EB7C: DBFC29D0 26000039
	ds_load_b128 v[34:37], v57 offset:10688                    // 00000003EB84: DBFC29C0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000003EB8C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000003EB90: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v90, s51, 0                           // 00000003EB98: CC21001B 0200675A
	v_fma_mixhi_f16 v27, v141, s51, 0                          // 00000003EBA0: CC22001B 0200678D
	v_fma_mixlo_f16 v29, v150, s51, 0                          // 00000003EBA8: CC21001D 02006796
	v_fma_mixhi_f16 v29, v142, s51, 0                          // 00000003EBB0: CC22001D 0200678E
	v_fma_mixlo_f16 v31, v191, s51, 0                          // 00000003EBB8: CC21001F 020067BF
	v_fma_mixhi_f16 v31, v189, s51, 0                          // 00000003EBC0: CC22001F 020067BD
	v_fma_mixlo_f16 v33, v190, s51, 0                          // 00000003EBC8: CC210021 020067BE
	v_fma_mixhi_f16 v33, v151, s51, 0                          // 00000003EBD0: CC220021 02006797
	v_mov_b32_e32 v28, v27                                     // 00000003EBD8: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000003EBDC: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000003EBE0: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003EBE4: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000003EBE8: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000003EBEC: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003EBF8: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000003EBFC: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000003EC08: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003EC14: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000003EC18: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 00000003EC24: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 00000003EC2C: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 00000003EC34: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 00000003EC3C: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 00000003EC44: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 00000003EC4C: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 00000003EC54: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 00000003EC5C: D6440021 04FA4521
	ds_load_b128 v[38:41], v57 offset:15088                    // 00000003EC64: DBFC3AF0 26000039
	ds_load_b128 v[34:37], v57 offset:15072                    // 00000003EC6C: DBFC3AE0 22000039
	s_waitcnt lgkmcnt(0)                                       // 00000003EC74: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000003EC78: CC404012 1C4A3522
	ds_load_b128 v[38:41], v57 offset:10736                    // 00000003EC80: DBFC29F0 26000039
	ds_load_b128 v[34:37], v57 offset:10720                    // 00000003EC88: DBFC29E0 22000039
	v_dual_mul_f32 v18, 0x3b800000, v18 :: v_dual_mul_f32 v19, 0x3b800000, v19// 00000003EC90: C8C624FF 121226FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v20 :: v_dual_mul_f32 v21, 0x3b800000, v21// 00000003EC9C: C8C628FF 14142AFF 3B800000
	v_mul_f32_e32 v22, 0x3b800000, v22                         // 00000003ECA8: 102C2CFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000003ECB0: BF870223
	v_sub_f32_e32 v10, v10, v18                                // 00000003ECB4: 0814250A
	v_or_b32_e32 v18, s54, v154                                // 00000003ECB8: 38253436
	v_dual_sub_f32 v11, v11, v19 :: v_dual_sub_f32 v12, v12, v20// 00000003ECBC: C94A270B 0B0C290C
	v_sub_f32_e32 v13, v13, v21                                // 00000003ECC4: 081A2B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003ECC8: BF870214
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 00000003ECCC: CC21000A 0200610A
	v_or_b32_e32 v19, 2, v18                                   // 00000003ECD4: 38262482
	.long 0xd4440003                                           // 00000003ECD8: D4440003
	v_cndmask_b32_e32 v1, s39, v18, vcc_lo                     // 00000003ECDC: 02022427
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 00000003ECE0: CC22000A 0200610B
	v_dual_mul_f32 v23, 0x3b800000, v23 :: v_dual_sub_f32 v14, v14, v22// 00000003ECE8: C8CA2EFF 170E2D0E 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000003ECF4: BF870214
	v_cmp_gt_i32_e32 vcc_lo, s39, v19                          // 00000003ECF8: 7C882627
	v_cndmask_b16 v10, 0, v10, s3                              // 00000003ECFC: D65D000A 000E1480
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000003ED04: BF8701D3
	v_dual_mul_f32 v24, 0x3b800000, v24 :: v_dual_sub_f32 v15, v15, v23// 00000003ED08: C8CA30FF 180E2F0F 3B800000
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 00000003ED14: 103232FF 3B800000
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000003ED1C: D65D500A 01AA1480
	s_waitcnt lgkmcnt(0)                                       // 00000003ED24: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000003ED28: CC40402A 1CAA3522
	v_dual_sub_f32 v16, v16, v24 :: v_dual_sub_f32 v17, v17, v25// 00000003ED30: C94A3110 10103311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000003ED38: BF8700C3
	v_mov_b32_e32 v11, v10                                     // 00000003ED3C: 7E16030A
	ds_load_b128 v[19:22], v60 offset:23296                    // 00000003ED40: DBFC5B00 1300003C
	ds_load_b128 v[23:26], v60 offset:23312                    // 00000003ED48: DBFC5B10 1700003C
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000003ED50: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v66, v10, v11, v61                              // 00000003ED5C: D6440042 04F6170A
	v_perm_b32 v67, v10, v11, v62                              // 00000003ED64: D6440043 04FA170A
	v_or_b32_e32 v10, 4, v18                                   // 00000003ED6C: 38142484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003ED70: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 00000003ED74: 7C881427
	v_or_b32_e32 v10, 6, v18                                   // 00000003ED78: 38142486
	.long 0xd4440004                                           // 00000003ED7C: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 00000003ED80: 02021427
	v_fma_mixlo_f16 v10, v12, s48, 0                           // 00000003ED84: CC21000A 0200610C
	v_fma_mixhi_f16 v10, v13, s48, 0                           // 00000003ED8C: CC22000A 0200610D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003ED94: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000003ED98: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s4                              // 00000003EDA0: D65D500A 00121480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003EDA8: BF870091
	v_mov_b32_e32 v11, v10                                     // 00000003EDAC: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000003EDB0: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000003EDBC: BF8700B1
	v_perm_b32 v68, v10, v11, v61                              // 00000003EDC0: D6440044 04F6170A
	v_perm_b32 v69, v10, v11, v62                              // 00000003EDC8: D6440045 04FA170A
	v_or_b32_e32 v10, 8, v18                                   // 00000003EDD0: 38142488
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 00000003EDD4: 7C881427
	v_or_b32_e32 v10, 10, v18                                  // 00000003EDD8: 3814248A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000003EDDC: BF870131
	.long 0xd4440004                                           // 00000003EDE0: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 00000003EDE4: 02021427
	v_fma_mixlo_f16 v10, v14, s48, 0                           // 00000003EDE8: CC21000A 0200610E
	v_fma_mixhi_f16 v10, v15, s48, 0                           // 00000003EDF0: CC22000A 0200610F
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000003EDF8: D65D000A 01AA1480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003EE00: BF870092
	v_cndmask_b16 v10, 0, v10, s4                              // 00000003EE04: D65D500A 00121480
	v_mov_b32_e32 v11, v10                                     // 00000003EE0C: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003EE10: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000003EE14: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v70, v10, v11, v61                              // 00000003EE20: D6440046 04F6170A
	v_perm_b32 v71, v10, v11, v62                              // 00000003EE28: D6440047 04FA170A
	v_or_b32_e32 v10, 12, v18                                  // 00000003EE30: 3814248C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003EE34: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v10                          // 00000003EE38: 7C881427
	v_or_b32_e32 v10, 14, v18                                  // 00000003EE3C: 3814248E
	.long 0xd4440004                                           // 00000003EE40: D4440004
	v_cndmask_b32_e32 v1, s39, v10, vcc_lo                     // 00000003EE44: 02021427
	v_fma_mixlo_f16 v10, v16, s48, 0                           // 00000003EE48: CC21000A 02006110
	v_fma_mixhi_f16 v10, v17, s48, 0                           // 00000003EE50: CC22000A 02006111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000003EE58: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 00000003EE5C: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s4                              // 00000003EE64: D65D500A 00121480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003EE6C: BF870091
	v_mov_b32_e32 v11, v10                                     // 00000003EE70: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000003EE74: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000003EE80: BF8700B1
	v_perm_b32 v72, v10, v11, v61                              // 00000003EE84: D6440048 04F6170A
	v_perm_b32 v73, v10, v11, v62                              // 00000003EE8C: D6440049 04FA170A
	s_waitcnt lgkmcnt(0)                                       // 00000003EE94: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[19:26], v[66:73], v[2:9]// 00000003EE98: CC40400A 1C0A8513
	.long 0xd7000402                                           // 00000003EEA0: D7000402
	v_cndmask_b32_e32 v1, s44, v59, vcc_lo                     // 00000003EEA4: 0202762C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003EEA8: BF870001
	v_add_co_ci_u32_e64 v3, null, s45, 0, s4                   // 00000003EEAC: D5207C03 0011002D
	s_and_saveexec_b32 s4, s3                                  // 00000003EEB4: BE842003
	s_cbranch_execz 19                                         // 00000003EEB8: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3a08>
	ds_load_b32 v4, v56 offset:24320                           // 00000003EEBC: D8D85F00 04000038
	s_waitcnt lgkmcnt(0)                                       // 00000003EEC4: BF89FC07
	v_mul_f32_e32 v4, v42, v4                                  // 00000003EEC8: 1008092A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003EECC: BF870091
	v_add_f32_e32 v4, v10, v4                                  // 00000003EED0: 0608090A
	v_mul_f32_e32 v6, 0x3b800000, v4                           // 00000003EED4: 100C08FF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v18, v[2:3]            // 00000003EEDC: D6FE7C04 040A24FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003EEE8: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000003EEEC: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000003EEF4: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000003EF00: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s4                              // 00000003EF08: 8C7E047E
	v_or3_b32 v4, v154, s54, 2                                 // 00000003EF0C: D6580004 02086D9A
	s_mov_b32 s3, exec_lo                                      // 00000003EF14: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003EF18: BF870001
	.long 0xd4c4007e                                           // 00000003EF1C: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000003EF20: 02020827
	s_cbranch_execz 19                                         // 00000003EF24: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3a74>
	ds_load_b32 v5, v56 offset:24328                           // 00000003EF28: D8D85F08 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000003EF30: BF89FC07
	v_mul_f32_e32 v5, v43, v5                                  // 00000003EF34: 100A0B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003EF38: BF870091
	v_add_f32_e32 v5, v11, v5                                  // 00000003EF3C: 060A0B0B
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000003EF40: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000003EF48: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003EF54: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000003EF58: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000003EF60: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000003EF6C: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003EF74: 8C7E037E
	v_or3_b32 v4, v154, s54, 4                                 // 00000003EF78: D6580004 02106D9A
	s_mov_b32 s3, exec_lo                                      // 00000003EF80: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003EF84: BF870001
	.long 0xd4c4007e                                           // 00000003EF88: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000003EF8C: 02020827
	s_cbranch_execz 19                                         // 00000003EF90: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3ae0>
	ds_load_b32 v5, v56 offset:24336                           // 00000003EF94: D8D85F10 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000003EF9C: BF89FC07
	v_mul_f32_e32 v5, v44, v5                                  // 00000003EFA0: 100A0B2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003EFA4: BF870091
	v_add_f32_e32 v5, v12, v5                                  // 00000003EFA8: 060A0B0C
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000003EFAC: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000003EFB4: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003EFC0: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000003EFC4: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000003EFCC: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000003EFD8: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003EFE0: 8C7E037E
	v_or3_b32 v4, v154, s54, 6                                 // 00000003EFE4: D6580004 02186D9A
	s_mov_b32 s3, exec_lo                                      // 00000003EFEC: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003EFF0: BF870001
	.long 0xd4c4007e                                           // 00000003EFF4: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000003EFF8: 02020827
	s_cbranch_execz 19                                         // 00000003EFFC: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3b4c>
	ds_load_b32 v5, v56 offset:24344                           // 00000003F000: D8D85F18 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000003F008: BF89FC07
	v_mul_f32_e32 v5, v45, v5                                  // 00000003F00C: 100A0B2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F010: BF870091
	v_add_f32_e32 v5, v13, v5                                  // 00000003F014: 060A0B0D
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000003F018: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000003F020: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F02C: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000003F030: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000003F038: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000003F044: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003F04C: 8C7E037E
	v_or3_b32 v4, v154, s54, 8                                 // 00000003F050: D6580004 02206D9A
	s_mov_b32 s3, exec_lo                                      // 00000003F058: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003F05C: BF870001
	.long 0xd4c4007e                                           // 00000003F060: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000003F064: 02020827
	s_cbranch_execz 19                                         // 00000003F068: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3bb8>
	ds_load_b32 v5, v56 offset:24352                           // 00000003F06C: D8D85F20 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000003F074: BF89FC07
	v_mul_f32_e32 v5, v46, v5                                  // 00000003F078: 100A0B2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F07C: BF870091
	v_add_f32_e32 v5, v14, v5                                  // 00000003F080: 060A0B0E
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000003F084: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000003F08C: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F098: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000003F09C: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000003F0A4: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000003F0B0: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003F0B8: 8C7E037E
	v_or3_b32 v4, v154, s54, 10                                // 00000003F0BC: D6580004 02286D9A
	s_mov_b32 s3, exec_lo                                      // 00000003F0C4: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003F0C8: BF870001
	.long 0xd4c4007e                                           // 00000003F0CC: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000003F0D0: 02020827
	s_cbranch_execz 19                                         // 00000003F0D4: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3c24>
	ds_load_b32 v5, v56 offset:24360                           // 00000003F0D8: D8D85F28 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000003F0E0: BF89FC07
	v_mul_f32_e32 v5, v47, v5                                  // 00000003F0E4: 100A0B2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F0E8: BF870091
	v_add_f32_e32 v5, v15, v5                                  // 00000003F0EC: 060A0B0F
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000003F0F0: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000003F0F8: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F104: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000003F108: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000003F110: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000003F11C: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003F124: 8C7E037E
	v_or3_b32 v4, v154, s54, 12                                // 00000003F128: D6580004 02306D9A
	s_mov_b32 s3, exec_lo                                      // 00000003F130: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003F134: BF870001
	.long 0xd4c4007e                                           // 00000003F138: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000003F13C: 02020827
	s_cbranch_execz 19                                         // 00000003F140: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3c90>
	ds_load_b32 v5, v56 offset:24368                           // 00000003F144: D8D85F30 05000038
	s_waitcnt lgkmcnt(0)                                       // 00000003F14C: BF89FC07
	v_mul_f32_e32 v5, v48, v5                                  // 00000003F150: 100A0B30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F154: BF870091
	v_add_f32_e32 v5, v16, v5                                  // 00000003F158: 060A0B10
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 00000003F15C: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000003F164: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F170: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 00000003F174: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 00000003F17C: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000003F188: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003F190: 8C7E037E
	v_or3_b32 v4, v154, s54, 14                                // 00000003F194: D6580004 02386D9A
	s_mov_b32 s3, exec_lo                                      // 00000003F19C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003F1A0: BF870001
	.long 0xd4c4007e                                           // 00000003F1A4: D4C4007E
	v_cndmask_b32_e32 v1, s39, v4, vcc_lo                      // 00000003F1A8: 02020827
	s_cbranch_execz 19                                         // 00000003F1AC: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3cfc>
	ds_load_b32 v5, v56 offset:24376                           // 00000003F1B0: D8D85F38 05000038
	v_mad_u64_u32 v[2:3], null, 0x3000, v4, v[2:3]             // 00000003F1B8: D6FE7C02 040A08FF 00003000
	s_waitcnt lgkmcnt(0)                                       // 00000003F1C4: BF89FC07
	v_mul_f32_e32 v5, v49, v5                                  // 00000003F1C8: 100A0B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F1CC: BF870091
	v_add_f32_e32 v5, v17, v5                                  // 00000003F1D0: 060A0B11
	v_mul_f32_e32 v5, 0x3b800000, v5                           // 00000003F1D4: 100A0AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F1DC: BF870091
	v_bfe_u32 v6, v5, 16, 1                                    // 00000003F1E0: D6100006 02052105
	v_add3_u32 v4, v5, v6, 0x7fff                              // 00000003F1E8: D6550004 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000003F1F4: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000003F1FC: 8C7E037E
	ds_load_b32 v56, v1 offset:24188                           // 00000003F200: D8D85E7C 38000001
	v_mad_u32_u24 v2, v55, 48, 0x4b00                          // 00000003F208: D60B0002 03FD6137 00004B00
	s_add_i32 s54, s54, 16                                     // 00000003F214: 81369036
	v_mov_b32_e32 v178, s27                                    // 00000003F218: 7F64021B
	v_dual_mov_b32 v176, s25 :: v_dual_mov_b32 v173, s22       // 00000003F21C: CA100019 B0AC0016
	s_delay_alu instid0(VALU_DEP_3)                            // 00000003F224: BF870003
	v_dual_mov_b32 v174, s23 :: v_dual_add_nc_u32 v55, 0xffffb500, v2// 00000003F228: CA200017 AE3604FF FFFFB500
	v_dual_mov_b32 v171, s20 :: v_dual_mov_b32 v172, s21       // 00000003F234: CA100014 ABAC0015
	ds_load_b128 v[159:162], v55 offset:2320                   // 00000003F23C: DBFC0910 9F000037
	ds_load_b128 v[155:158], v55 offset:2304                   // 00000003F244: DBFC0900 9B000037
	ds_load_b128 v[167:170], v55 offset:3088                   // 00000003F24C: DBFC0C10 A7000037
	ds_load_b128 v[163:166], v55 offset:3072                   // 00000003F254: DBFC0C00 A3000037
	ds_load_b128 v[2:5], v55                                   // 00000003F25C: DBFC0000 02000037
	ds_load_b128 v[6:9], v55 offset:16                         // 00000003F264: DBFC0010 06000037
	ds_load_b128 v[82:85], v55 offset:4608                     // 00000003F26C: DBFC1200 52000037
	ds_load_b128 v[183:186], v55 offset:3856                   // 00000003F274: DBFC0F10 B7000037
	ds_load_b128 v[179:182], v55 offset:3840                   // 00000003F27C: DBFC0F00 B3000037
	ds_load_b128 v[86:89], v55 offset:4624                     // 00000003F284: DBFC1210 56000037
	v_mov_b32_e32 v177, s26                                    // 00000003F28C: 7F62021A
	v_mov_b32_e32 v175, s24                                    // 00000003F290: 7F5E0218
	s_waitcnt lgkmcnt(10)                                      // 00000003F294: BF89FCA7
	v_readfirstlane_b32 s3, v56                                // 00000003F298: 7E060538
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v56                  // 00000003F29C: 7C3670FF C2CE8ED0
	s_mul_f32 s3, s3, 0x3fb8aa3b                               // 00000003F2A4: A203FF03 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 00000003F2AC: BF87000B
	s_xor_b32 s4, s3, 0x80000000                               // 00000003F2B0: 8D04FF03 80000000
	s_cmp_lg_u32 s12, s54                                      // 00000003F2B8: BF07360C
	v_fma_f32 v10, 0x3fb8aa3b, v56, s4                         // 00000003F2BC: D613000A 001270FF 3FB8AA3B
	s_rndne_f32 s4, s3                                         // 00000003F2C8: BE846303
	s_waitcnt lgkmcnt(4)                                       // 00000003F2CC: BF89FC47
	v_wmma_f32_16x16x16_f16 v[34:41], v[2:9], v[66:73], v[171:178]// 00000003F2D0: CC404022 1EAE8502
	s_delay_alu instid0(VALU_DEP_2)                            // 00000003F2D8: BF870002
	v_fmac_f32_e32 v10, 0x32a5705f, v56                        // 00000003F2DC: 561470FF 32A5705F
	s_sub_f32 s3, s3, s4                                       // 00000003F2E4: A0830403
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_3)    // 00000003F2E8: BF870581
	v_add_f32_e32 v18, s3, v10                                 // 00000003F2EC: 06241403
	s_cvt_i32_f32 s3, s4                                       // 00000003F2F0: BE836604
	ds_load_b128 v[14:17], v55 offset:784                      // 00000003F2F4: DBFC0310 0E000037
	ds_load_b128 v[10:13], v55 offset:768                      // 00000003F2FC: DBFC0300 0A000037
	ds_load_b128 v[46:49], v55 offset:1552                     // 00000003F304: DBFC0610 2E000037
	ds_load_b128 v[42:45], v55 offset:1536                     // 00000003F30C: DBFC0600 2A000037
	v_exp_f32_e32 v18, v18                                     // 00000003F314: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F318: BF870095
	.long 0xd71c0012                                           // 00000003F31C: D71C0012
	v_cndmask_b32_e32 v0, v18, v3, vcc_lo                      // 00000003F320: 02000712
	v_cndmask_b32_e32 v2, 0, v18, vcc_lo                       // 00000003F324: 02042480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v56                  // 00000003F328: 7C3C70FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F330: BF870092
	v_cndmask_b32_e32 v145, 0x7f800000, v2, vcc_lo             // 00000003F334: 032204FF 7F800000
	v_fmac_f32_e32 v41, v54, v145                              // 00000003F33C: 56532336
	s_waitcnt lgkmcnt(2)                                       // 00000003F340: BF89FC27
	v_wmma_f32_16x16x16_f16 v[26:33], v[10:17], v[66:73], v[171:178]// 00000003F344: CC40401A 1EAE850A
	v_wmma_f32_16x16x16_f16 v[10:17], v[155:162], v[66:73], v[171:178]// 00000003F34C: CC40400A 1EAE859B
	ds_load_b128 v[159:162], v55 offset:5392                   // 00000003F354: DBFC1510 9F000037
	ds_load_b128 v[155:158], v55 offset:5376                   // 00000003F35C: DBFC1500 9B000037
	s_waitcnt lgkmcnt(2)                                       // 00000003F364: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[66:73], v[171:178]// 00000003F368: CC404012 1EAE852A
	v_wmma_f32_16x16x16_f16 v[2:9], v[163:170], v[66:73], v[171:178]// 00000003F370: CC404002 1EAE85A3
	v_wmma_f32_16x16x16_f16 v[42:49], v[179:186], v[66:73], v[171:178]// 00000003F378: CC40402A 1EAE85B3
	v_fma_f32 v138, v138, v145, v35                            // 00000003F380: D613008A 048F238A
	v_fma_f32 v136, v136, v145, v37                            // 00000003F388: D6130088 04972388
	v_fma_f32 v135, v135, v145, v38                            // 00000003F390: D6130087 049B2387
	v_fma_f32 v131, v131, v145, v27                            // 00000003F398: D6130083 046F2383
	v_fmac_f32_e32 v33, v53, v145                              // 00000003F3A0: 56432335
	v_fmac_f32_e32 v25, v52, v145                              // 00000003F3A4: 56332334
	v_fmac_f32_e32 v17, v51, v145                              // 00000003F3A8: 56232333
	v_fmac_f32_e32 v9, v50, v145                               // 00000003F3AC: 56132332
	v_wmma_f32_16x16x16_f16 v[50:57], v[82:89], v[66:73], v[171:178]// 00000003F3B0: CC404032 1EAE8552
	v_fmac_f32_e32 v49, v58, v145                              // 00000003F3B8: 5663233A
	v_fma_f32 v139, v139, v145, v34                            // 00000003F3BC: D613008B 048B238B
	v_fma_f32 v137, v137, v145, v36                            // 00000003F3C4: D6130089 04932389
	s_waitcnt lgkmcnt(0)                                       // 00000003F3CC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[58:65], v[155:162], v[66:73], v[171:178]// 00000003F3D0: CC40403A 1EAE859B
	v_fma_f32 v134, v134, v145, v39                            // 00000003F3D8: D6130086 049F2386
	v_fma_f32 v133, v133, v145, v40                            // 00000003F3E0: D6130085 04A32385
	v_fma_f32 v132, v132, v145, v26                            // 00000003F3E8: D6130084 046B2384
	v_fma_f32 v130, v130, v145, v28                            // 00000003F3F0: D6130082 04732382
	v_fma_f32 v129, v129, v145, v29                            // 00000003F3F8: D6130081 04772381
	v_fma_f32 v128, v128, v145, v30                            // 00000003F400: D6130080 047B2380
	v_fma_f32 v127, v127, v145, v31                            // 00000003F408: D613007F 047F237F
	v_fma_f32 v126, v126, v145, v32                            // 00000003F410: D613007E 0483237E
	v_fma_f32 v125, v125, v145, v18                            // 00000003F418: D613007D 044B237D
	v_fma_f32 v124, v124, v145, v19                            // 00000003F420: D613007C 044F237C
	v_fma_f32 v123, v123, v145, v20                            // 00000003F428: D613007B 0453237B
	v_fma_f32 v122, v122, v145, v21                            // 00000003F430: D613007A 0457237A
	v_fma_f32 v121, v121, v145, v22                            // 00000003F438: D6130079 045B2379
	v_fma_f32 v120, v120, v145, v23                            // 00000003F440: D6130078 045F2378
	v_fma_f32 v119, v119, v145, v24                            // 00000003F448: D6130077 04632377
	v_fma_f32 v118, v118, v145, v10                            // 00000003F450: D6130076 042B2376
	v_fma_f32 v117, v117, v145, v11                            // 00000003F458: D6130075 042F2375
	v_fma_f32 v116, v116, v145, v12                            // 00000003F460: D6130074 04332374
	v_fma_f32 v115, v115, v145, v13                            // 00000003F468: D6130073 04372373
	v_fma_f32 v114, v114, v145, v14                            // 00000003F470: D6130072 043B2372
	v_fma_f32 v113, v113, v145, v15                            // 00000003F478: D6130071 043F2371
	v_fma_f32 v112, v112, v145, v16                            // 00000003F480: D6130070 04432370
	v_fma_f32 v111, v111, v145, v2                             // 00000003F488: D613006F 040B236F
	v_fma_f32 v110, v110, v145, v3                             // 00000003F490: D613006E 040F236E
	v_fma_f32 v109, v109, v145, v4                             // 00000003F498: D613006D 0413236D
	v_fma_f32 v108, v108, v145, v5                             // 00000003F4A0: D613006C 0417236C
	v_fma_f32 v107, v107, v145, v6                             // 00000003F4A8: D613006B 041B236B
	v_fma_f32 v106, v106, v145, v7                             // 00000003F4B0: D613006A 041F236A
	v_fma_f32 v105, v105, v145, v8                             // 00000003F4B8: D6130069 04232369
	v_fma_f32 v104, v104, v145, v42                            // 00000003F4C0: D6130068 04AB2368
	v_fma_f32 v103, v103, v145, v43                            // 00000003F4C8: D6130067 04AF2367
	v_fma_f32 v102, v102, v145, v44                            // 00000003F4D0: D6130066 04B32366
	v_fma_f32 v101, v101, v145, v45                            // 00000003F4D8: D6130065 04B72365
	v_fma_f32 v100, v100, v145, v46                            // 00000003F4E0: D6130064 04BB2364
	v_fma_f32 v99, v99, v145, v47                              // 00000003F4E8: D6130063 04BF2363
	v_fma_f32 v98, v98, v145, v48                              // 00000003F4F0: D6130062 04C32362
	v_fma_f32 v97, v97, v145, v50                              // 00000003F4F8: D6130061 04CB2361
	v_fma_f32 v96, v96, v145, v51                              // 00000003F500: D6130060 04CF2360
	v_fma_f32 v95, v95, v145, v52                              // 00000003F508: D613005F 04D3235F
	v_fma_f32 v94, v94, v145, v53                              // 00000003F510: D613005E 04D7235E
	v_fma_f32 v93, v93, v145, v54                              // 00000003F518: D613005D 04DB235D
	v_fma_f32 v92, v92, v145, v55                              // 00000003F520: D613005C 04DF235C
	v_fma_f32 v91, v91, v145, v56                              // 00000003F528: D613005B 04E3235B
	v_fmac_f32_e32 v57, v152, v145                             // 00000003F530: 56732398
	v_fma_f32 v90, v90, v145, v58                              // 00000003F534: D613005A 04EB235A
	v_fma_f32 v141, v141, v145, v59                            // 00000003F53C: D613008D 04EF238D
	v_fma_f32 v150, v150, v145, v60                            // 00000003F544: D6130096 04F32396
	v_fma_f32 v142, v142, v145, v61                            // 00000003F54C: D613008E 04F7238E
	v_fma_f32 v191, v191, v145, v62                            // 00000003F554: D61300BF 04FB23BF
	v_fma_f32 v189, v189, v145, v63                            // 00000003F55C: D61300BD 04FF23BD
	v_fma_f32 v190, v190, v145, v64                            // 00000003F564: D61300BE 050323BE
	v_dual_fmac_f32 v65, v151, v145 :: v_dual_mul_f32 v6, 0x3b800000, v128// 00000003F56C: C8072397 410700FF 3B800000
	v_lshl_add_u32 v2, v154, 7, v153                           // 00000003F578: D6460002 06650F9A
	v_dual_mul_f32 v69, 0x3b800000, v139 :: v_dual_mul_f32 v152, 0x3b800000, v41// 00000003F580: C8C716FF 459852FF 3B800000
	v_dual_mul_f32 v70, 0x3b800000, v138 :: v_dual_mul_f32 v71, 0x3b800000, v137// 00000003F58C: C8C714FF 464712FF 3B800000
	v_mul_f32_e32 v64, 0x3b800000, v127                        // 00000003F598: 1080FEFF 3B800000
	v_mul_f32_e32 v72, 0x3b800000, v136                        // 00000003F5A0: 109110FF 3B800000
	v_dual_mul_f32 v4, 0x3b800000, v135 :: v_dual_mul_f32 v73, 0x3b800000, v134// 00000003F5A8: C8C70EFF 04490CFF 3B800000
	v_dual_mul_f32 v60, 0x3b800000, v123 :: v_dual_mul_f32 v151, 0x3b800000, v133// 00000003F5B4: C8C6F6FF 3C970AFF 3B800000
	v_dual_mul_f32 v66, 0x3b800000, v126 :: v_dual_mul_f32 v5, 0x3b800000, v132// 00000003F5C0: C8C6FCFF 420508FF 3B800000
	v_mul_f32_e32 v8, 0x3b800000, v121                         // 00000003F5CC: 1010F2FF 3B800000
	v_mul_f32_e32 v68, 0x3b800000, v131                        // 00000003F5D4: 108906FF 3B800000
	v_dual_mul_f32 v62, 0x3b800000, v130 :: v_dual_mul_f32 v63, 0x3b800000, v129// 00000003F5DC: C8C704FF 3E3F02FF 3B800000
	v_dual_mul_f32 v52, 0x3b800000, v120 :: v_dual_mul_f32 v67, 0x3b800000, v33// 00000003F5E8: C8C6F0FF 344242FF 3B800000
	v_dual_mul_f32 v10, 0x3b800000, v118 :: v_dual_mul_f32 v7, 0x3b800000, v125// 00000003F5F4: C8C6ECFF 0A06FAFF 3B800000
	v_mul_f32_e32 v56, 0x3b800000, v116                        // 00000003F600: 1070E8FF 3B800000
	v_dual_mul_f32 v59, 0x3b800000, v124 :: v_dual_mul_f32 v54, 0x3b800000, v25// 00000003F608: C8C6F8FF 3B3632FF 3B800000
	v_dual_mul_f32 v61, 0x3b800000, v122 :: v_dual_mul_f32 v58, 0x3b800000, v115// 00000003F614: C8C6F4FF 3D3AE6FF 3B800000
	v_dual_mul_f32 v53, 0x3b800000, v119 :: v_dual_mul_f32 v50, 0x3b800000, v113// 00000003F620: C8C6EEFF 3532E2FF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v117 :: v_dual_mul_f32 v12, 0x3b800000, v111// 00000003F62C: C8C6EAFF 370CDEFF 3B800000
	v_dual_mul_f32 v11, 0x3b800000, v114 :: v_dual_mul_f32 v40, 0x3b800000, v17// 00000003F638: C8C6E4FF 0B2822FF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v112 :: v_dual_mul_f32 v44, 0x3b800000, v109// 00000003F644: C8C6E0FF 332CDAFF 3B800000
	v_dual_mul_f32 v43, 0x3b800000, v110 :: v_dual_mul_f32 v14, 0x3b800000, v107// 00000003F650: C8C6DCFF 2B0ED6FF 3B800000
	v_dual_mul_f32 v45, 0x3b800000, v108 :: v_dual_mul_f32 v46, 0x3b800000, v106// 00000003F65C: C8C6D8FF 2D2ED4FF 3B800000
	v_dual_mul_f32 v47, 0x3b800000, v105 :: v_dual_mul_f32 v42, 0x3b800000, v103// 00000003F668: C8C6D2FF 2F2ACEFF 3B800000
	v_dual_mul_f32 v48, 0x3b800000, v9 :: v_dual_mul_f32 v15, 0x3b800000, v104// 00000003F674: C8C612FF 300ED0FF 3B800000
	v_dual_mul_f32 v35, 0x3b800000, v102 :: v_dual_mul_f32 v36, 0x3b800000, v101// 00000003F680: C8C6CCFF 2324CAFF 3B800000
	v_dual_mul_f32 v27, 0x3b800000, v100 :: v_dual_mul_f32 v38, 0x3b800000, v98// 00000003F68C: C8C6C8FF 1B26C4FF 3B800000
	v_dual_mul_f32 v37, 0x3b800000, v99 :: v_dual_mul_f32 v28, 0x3b800000, v97// 00000003F698: C8C6C6FF 251CC2FF 3B800000
	v_dual_mul_f32 v39, 0x3b800000, v49 :: v_dual_mul_f32 v32, 0x3b800000, v95// 00000003F6A4: C8C662FF 2720BEFF 3B800000
	v_dual_mul_f32 v31, 0x3b800000, v96 :: v_dual_mul_f32 v34, 0x3b800000, v94// 00000003F6B0: C8C6C0FF 1F22BCFF 3B800000
	v_dual_mul_f32 v29, 0x3b800000, v93 :: v_dual_mul_f32 v20, 0x3b800000, v92// 00000003F6BC: C8C6BAFF 1D14B8FF 3B800000
	v_dual_mul_f32 v21, 0x3b800000, v91 :: v_dual_mul_f32 v22, 0x3b800000, v57// 00000003F6C8: C8C6B6FF 151672FF 3B800000
	v_dual_mul_f32 v30, 0x3b800000, v90 :: v_dual_mul_f32 v23, 0x3b800000, v141// 00000003F6D4: C8C6B4FF 1E171AFF 3B800000
	v_dual_mul_f32 v24, 0x3b800000, v150 :: v_dual_mul_f32 v13, 0x3b800000, v65// 00000003F6E0: C8C72CFF 180C82FF 3B800000
	v_mul_f32_e32 v26, 0x3b800000, v142                        // 00000003F6EC: 10351CFF 3B800000
	v_dual_mul_f32 v16, 0x3b800000, v191 :: v_dual_mul_f32 v19, 0x3b800000, v190// 00000003F6F4: C8C77EFF 10137CFF 3B800000
	v_mul_f32_e32 v18, 0x3b800000, v189                        // 00000003F700: 10257AFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 00000003F708: BF89FC07
	s_barrier                                                  // 00000003F70C: BFBD0000
	s_cbranch_scc0 182                                         // 00000003F710: BFA100B6 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44ec>
	s_cmp_lg_u32 s13, s54                                      // 00000003F714: BF07360D
	s_cbranch_scc0 450                                         // 00000003F718: BFA101C2 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4924>
	s_cmp_lg_u32 s14, s54                                      // 00000003F71C: BF07360E
	s_cbranch_scc1 61882                                       // 00000003F720: BFA2F1BA <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	s_branch 717                                               // 00000003F724: BFA002CD <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4d5c>
	s_waitcnt lgkmcnt(0)                                       // 00000003F728: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000003F72C: C9080B03 03040D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F734: BF870091
	v_dual_add_f32 v3, 0x358637bd, v3 :: v_dual_add_f32 v4, 0x358637bd, v4// 00000003F738: C90806FF 030408FF 358637BD
	v_dual_mul_f32 v5, 0x4b800000, v3 :: v_dual_mul_f32 v6, 0x4b800000, v4// 00000003F744: C8C606FF 050608FF 4B800000
	.long 0xd4140004                                           // 00000003F750: D4140004
	v_cndmask_b32_e32 v1, 0x800000, v4, vcc_lo                 // 00000003F754: 020208FF 00800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v3                      // 00000003F75C: 7C2806FF 00800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F764: BF870092
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 00000003F768: D5010004 00120D04
	v_rsq_f32_e32 v4, v4                                       // 00000003F770: 7E085D04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F774: BF870095
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_mul_f32 v6, 0x45800000, v4// 00000003F778: CA460B03 030608FF 45800000
	v_rsq_f32_e32 v3, v3                                       // 00000003F784: 7E065D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 00000003F788: BF870321
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 00000003F78C: D5010004 00120D04
	v_rsq_f32_e32 v6, 0x43000000                               // 00000003F794: 7E0C5CFF 43000000
	v_mul_f32_e32 v5, 0x45800000, v3                           // 00000003F79C: 100A06FF 45800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003F7A4: BF870001
	v_cndmask_b32_e32 v3, v3, v5, vcc_lo                       // 00000003F7A8: 02060B03
	v_lshlrev_b32_e32 v5, 2, v2                                // 00000003F7AC: 300A0482
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_2)   // 00000003F7B0: BF870105
	v_mul_f32_e32 v3, v6, v3                                   // 00000003F7B4: 10060706
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000003F7B8: BF8704B2
	v_add_nc_u32_e32 v5, 0x5c00, v5                            // 00000003F7BC: 4A0A0AFF 00005C00
	ds_store_2addr_b32 v5, v4, v3 offset0:208 offset1:224      // 00000003F7C4: D838E0D0 00030405
	s_or_b32 exec_lo, exec_lo, s29                             // 00000003F7CC: 8C7E1D7E
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 00000003F7D0: 916A267E
	s_cbranch_vccnz 62173                                      // 00000003F7D4: BFA4F2DD <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xe4c>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 00000003F7D8: BE9C4D83
	v_and_b32_e32 v43, 31, v44                                 // 00000003F7DC: 3656589F
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 00000003F7E0: 916A027E
	s_cbranch_vccnz 62172                                      // 00000003F7E4: BFA4F2DC <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xe58>
	.long 0xd7600045                                           // 00000003F7E8: D7600045
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                   // 00000003F7EC: 0201018C
	.long 0xd7600044                                           // 00000003F7F0: D7600044
	v_cndmask_b32_e32 v0, v140, v129, vcc_lo                   // 00000003F7F4: 0201038C
	.long 0xd7600043                                           // 00000003F7F8: D7600043
	v_cndmask_b32_e32 v0, v140, v130, vcc_lo                   // 00000003F7FC: 0201058C
	.long 0xd7600042                                           // 00000003F800: D7600042
	v_cndmask_b32_e32 v0, v140, v131, vcc_lo                   // 00000003F804: 0201078C
	.long 0xd7600041                                           // 00000003F808: D7600041
	v_cndmask_b32_e32 v0, v140, v132, vcc_lo                   // 00000003F80C: 0201098C
	.long 0xd7600040                                           // 00000003F810: D7600040
	v_cndmask_b32_e32 v0, v140, v133, vcc_lo                   // 00000003F814: 02010B8C
	.long 0xd760003f                                           // 00000003F818: D760003F
	v_cndmask_b32_e32 v0, v140, v134, vcc_lo                   // 00000003F81C: 02010D8C
	.long 0xd760003e                                           // 00000003F820: D760003E
	v_cndmask_b32_e32 v0, v140, v135, vcc_lo                   // 00000003F824: 02010F8C
	.long 0xd760003d                                           // 00000003F828: D760003D
	v_cndmask_b32_e32 v0, v140, v136, vcc_lo                   // 00000003F82C: 0201118C
	.long 0xd760003c                                           // 00000003F830: D760003C
	v_cndmask_b32_e32 v0, v140, v137, vcc_lo                   // 00000003F834: 0201138C
	.long 0xd760003b                                           // 00000003F838: D760003B
	v_cndmask_b32_e32 v0, v140, v138, vcc_lo                   // 00000003F83C: 0201158C
	.long 0xd760003a                                           // 00000003F840: D760003A
	v_cndmask_b32_e32 v0, v140, v139, vcc_lo                   // 00000003F844: 0201178C
	.long 0xd7600039                                           // 00000003F848: D7600039
	v_cndmask_b32_e32 v0, v140, v140, vcc_lo                   // 00000003F84C: 0201198C
	.long 0xd7600038                                           // 00000003F850: D7600038
	v_cndmask_b32_e32 v0, v140, v141, vcc_lo                   // 00000003F854: 02011B8C
	.long 0xd7600037                                           // 00000003F858: D7600037
	v_cndmask_b32_e32 v0, v140, v142, vcc_lo                   // 00000003F85C: 02011D8C
	s_waitcnt lgkmcnt(0)                                       // 00000003F860: BF89FC07
	.long 0xd760001d                                           // 00000003F864: D760001D
	v_cndmask_b32_e32 v0, v140, v143, vcc_lo                   // 00000003F868: 02011F8C
	s_mov_b32 s4, exec_lo                                      // 00000003F86C: BE84007E
	v_cmpx_gt_u32_e32 16, v43                                  // 00000003F870: 7D985690
	s_cbranch_execz 83                                         // 00000003F874: BFA50053 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44c4>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000003F878: 7C945680
	s_add_f32 s69, s69, 0                                      // 00000003F87C: A0458045
	v_lshlrev_b32_e32 v4, 2, v43                               // 00000003F880: 30085682
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000003F884: BF8704BA
	s_add_f32 s68, s69, s68                                    // 00000003F888: A0444445
	v_cndmask_b32_e64 v3, 0, s69, vcc_lo                       // 00000003F88C: D5010003 01A88A80
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 00000003F894: 7C945681
	s_add_f32 s67, s68, s67                                    // 00000003F898: A0434344
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003F89C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s68, vcc_lo                      // 00000003F8A0: D5010003 01A88903
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 00000003F8A8: 7C945682
	s_add_f32 s66, s67, s66                                    // 00000003F8AC: A0424243
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003F8B0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s67, vcc_lo                      // 00000003F8B4: D5010003 01A88703
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 00000003F8BC: 7C945683
	s_add_f32 s65, s66, s65                                    // 00000003F8C0: A0414142
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003F8C4: BF8704A2
	v_cndmask_b32_e64 v3, v3, s66, vcc_lo                      // 00000003F8C8: D5010003 01A88503
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 00000003F8D0: 7C945684
	s_add_f32 s64, s65, s64                                    // 00000003F8D4: A0404041
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003F8D8: BF8704A2
	v_cndmask_b32_e64 v3, v3, s65, vcc_lo                      // 00000003F8DC: D5010003 01A88303
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 00000003F8E4: 7C945685
	s_add_f32 s63, s64, s63                                    // 00000003F8E8: A03F3F40
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003F8EC: BF8704A2
	v_cndmask_b32_e64 v3, v3, s64, vcc_lo                      // 00000003F8F0: D5010003 01A88103
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 00000003F8F8: 7C945686
	s_add_f32 s62, s63, s62                                    // 00000003F8FC: A03E3E3F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003F900: BF8704A2
	v_cndmask_b32_e64 v3, v3, s63, vcc_lo                      // 00000003F904: D5010003 01A87F03
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 00000003F90C: 7C945687
	s_add_f32 s61, s62, s61                                    // 00000003F910: A03D3D3E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003F914: BF8704A2
	v_cndmask_b32_e64 v3, v3, s62, vcc_lo                      // 00000003F918: D5010003 01A87D03
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 00000003F920: 7C945688
	s_add_f32 s60, s61, s60                                    // 00000003F924: A03C3C3D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003F928: BF8704A2
	v_cndmask_b32_e64 v3, v3, s61, vcc_lo                      // 00000003F92C: D5010003 01A87B03
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 00000003F934: 7C945689
	s_add_f32 s59, s60, s59                                    // 00000003F938: A03B3B3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003F93C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s60, vcc_lo                      // 00000003F940: D5010003 01A87903
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000003F948: 7C94568A
	s_add_f32 s58, s59, s58                                    // 00000003F94C: A03A3A3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003F950: BF8704A2
	v_cndmask_b32_e64 v3, v3, s59, vcc_lo                      // 00000003F954: D5010003 01A87703
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 00000003F95C: 7C94568B
	s_add_f32 s57, s58, s57                                    // 00000003F960: A039393A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003F964: BF8704A2
	v_cndmask_b32_e64 v3, v3, s58, vcc_lo                      // 00000003F968: D5010003 01A87503
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 00000003F970: 7C94568C
	s_add_f32 s56, s57, s56                                    // 00000003F974: A0383839
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003F978: BF8704A2
	v_cndmask_b32_e64 v3, v3, s57, vcc_lo                      // 00000003F97C: D5010003 01A87303
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 00000003F984: 7C94568D
	s_add_f32 s55, s56, s55                                    // 00000003F988: A0373738
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000003F98C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s56, vcc_lo                      // 00000003F990: D5010003 01A87103
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 00000003F998: 7C94568E
	s_add_f32 s29, s55, s29                                    // 00000003F99C: A01D1D37
	s_delay_alu instid0(VALU_DEP_2)                            // 00000003F9A0: BF870002
	v_cndmask_b32_e64 v3, v3, s55, vcc_lo                      // 00000003F9A4: D5010003 01A86F03
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 00000003F9AC: 7C94568F
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 00000003F9B0: BF870482
	v_cndmask_b32_e64 v3, v3, s29, vcc_lo                      // 00000003F9B4: D5010003 01A83B03
	ds_store_b32 v4, v3 offset:24128                           // 00000003F9BC: D8345E40 00000304
	s_or_b32 exec_lo, exec_lo, s4                              // 00000003F9C4: 8C7E047E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003F9C8: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 00000003F9CC: 916A267E
	s_cbranch_vccnz 62051                                      // 00000003F9D0: BFA4F263 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xe60>
	s_sendmsg_rtn_b64 s[56:57], sendmsg(MSG_RTN_GET_REALTIME)  // 00000003F9D4: BEB84D83
	s_waitcnt lgkmcnt(0)                                       // 00000003F9D8: BF89FC07
	s_sub_i32 s4, s6, s28                                      // 00000003F9DC: 81841C06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000003F9E0: BF870009
	s_add_i32 s6, s4, s56                                      // 00000003F9E4: 81063804
	s_branch 62045                                             // 00000003F9E8: BFA0F25D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xe60>
	v_mov_b32_e32 v82, v2                                      // 00000003F9EC: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003F9F0: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 00000003F9F4: 34A6A49F
	.long 0xd73c0052                                           // 00000003F9F8: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 00000003F9FC: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003FA00: BF870091
	.long 0xd7006a52                                           // 00000003FA04: D7006A52
	v_cndmask_b32_e32 v1, s16, v82, vcc_lo                     // 00000003FA08: 0202A410
	v_add_co_ci_u32_e64 v83, null, s17, v83, vcc_lo            // 00000003FA0C: D5207C53 01AAA611
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003FA14: BF870092
	.long 0xd7006a54                                           // 00000003FA18: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 00000003FA1C: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000003FA24: D5207C55 01AAA680
	.long 0xd7006a56                                           // 00000003FA2C: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000003FA30: 0201FF52
	.long 0x00002000                                           // 00000003FA34: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003FA38: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 00000003FA3C: D5207C57 01AAA680
	.long 0xd7006a58                                           // 00000003FA44: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 00000003FA48: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000003FA50: D5207C59 01AAA680
	s_clause 0x7                                               // 00000003FA58: BF850007
	global_store_b32 v[82:83], v69, off                        // 00000003FA5C: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 00000003FA64: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 00000003FA6C: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 00000003FA74: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 00000003FA7C: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 00000003FA84: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 00000003FA8C: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 00000003FA94: DC6A0400 007C4458
	.long 0xd7006a54                                           // 00000003FA9C: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 00000003FAA0: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003FAA8: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000003FAAC: D5207C55 01AAA680
	.long 0xd7006a99                                           // 00000003FAB4: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000003FAB8: 0201FF52
	.long 0x00004000                                           // 00000003FABC: 00004000
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 00000003FAC0: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 00000003FAC8: D7006A9B
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 00000003FACC: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003FAD4: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000003FAD8: D5207C9C 01AAA680
	s_clause 0x7                                               // 00000003FAE0: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 00000003FAE4: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 00000003FAEC: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 00000003FAF4: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 00000003FAFC: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 00000003FB04: DC6A0C00 007C4354
	global_store_b32 v[155:156], v59, off offset:1024          // 00000003FB0C: DC6A0400 007C3B9B
	global_store_b32 v[155:156], v60, off offset:2048          // 00000003FB14: DC6A0800 007C3C9B
	global_store_b32 v[155:156], v61, off offset:3072          // 00000003FB1C: DC6A0C00 007C3D9B
	.long 0xd7006a54                                           // 00000003FB24: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 00000003FB28: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003FB30: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000003FB34: D5207C55 01AAA680
	.long 0xd7006a58                                           // 00000003FB3C: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000003FB40: 0201FF52
	.long 0x00006000                                           // 00000003FB44: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000003FB48: D5207C59 01AAA680
	.long 0xd7006a9b                                           // 00000003FB50: D7006A9B
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 00000003FB54: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003FB5C: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000003FB60: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000003FB68: D7006A9D
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 00000003FB6C: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000003FB74: D5207C9E 01AAA680
	.long 0xd7006a9f                                           // 00000003FB7C: D7006A9F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000003FB80: 0201FF52
	.long 0x00008000                                           // 00000003FB84: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003FB88: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v83, vcc_lo             // 00000003FB8C: D5207CA0 01AAA680
	s_clause 0x7                                               // 00000003FB94: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 00000003FB98: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 00000003FBA0: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 00000003FBA8: DC6A0C00 007C3654
	global_store_b32 v[155:156], v55, off offset:1024          // 00000003FBB0: DC6A0400 007C379B
	global_store_b32 v[155:156], v56, off offset:2048          // 00000003FBB8: DC6A0800 007C389B
	global_store_b32 v[155:156], v58, off offset:3072          // 00000003FBC0: DC6A0C00 007C3A9B
	global_store_b32 v[157:158], v50, off offset:1024          // 00000003FBC8: DC6A0400 007C329D
	global_store_b32 v[157:158], v51, off offset:2048          // 00000003FBD0: DC6A0800 007C339D
	.long 0xd7006a54                                           // 00000003FBD8: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 00000003FBDC: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003FBE4: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000003FBE8: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000003FBF0: D7006A9B
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 00000003FBF4: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000003FBFC: D5207C9C 01AAA680
	.long 0xd7006aa1                                           // 00000003FC04: D7006AA1
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000003FC08: 0201FF52
	.long 0x0000a000                                           // 00000003FC0C: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003FC10: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v83, vcc_lo             // 00000003FC14: D5207CA2 01AAA680
	.long 0xd7006aa3                                           // 00000003FC1C: D7006AA3
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 00000003FC20: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000003FC28: D5207CA4 01AAA680
	s_clause 0x7                                               // 00000003FC30: BF850007
	global_store_b32 v[157:158], v40, off offset:3072          // 00000003FC34: DC6A0C00 007C289D
	global_store_b32 v[84:85], v43, off offset:1024            // 00000003FC3C: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 00000003FC44: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 00000003FC4C: DC6A0C00 007C2D54
	global_store_b32 v[155:156], v46, off offset:1024          // 00000003FC54: DC6A0400 007C2E9B
	global_store_b32 v[155:156], v47, off offset:2048          // 00000003FC5C: DC6A0800 007C2F9B
	global_store_b32 v[155:156], v48, off offset:3072          // 00000003FC64: DC6A0C00 007C309B
	global_store_b32 v[163:164], v42, off offset:1024          // 00000003FC6C: DC6A0400 007C2AA3
	.long 0xd7006a54                                           // 00000003FC74: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 00000003FC78: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003FC80: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000003FC84: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 00000003FC8C: D7006A9B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000003FC90: 0201FF52
	.long 0x0000c000                                           // 00000003FC94: 0000C000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000003FC98: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000003FCA0: D7006A9D
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 00000003FCA4: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003FCAC: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000003FCB0: D5207C9E 01AAA680
	s_clause 0x7                                               // 00000003FCB8: BF850007
	global_store_b32 v[163:164], v35, off offset:2048          // 00000003FCBC: DC6A0800 007C23A3
	global_store_b32 v[163:164], v36, off offset:3072          // 00000003FCC4: DC6A0C00 007C24A3
	global_store_b32 v[84:85], v37, off offset:1024            // 00000003FCCC: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 00000003FCD4: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 00000003FCDC: DC6A0C00 007C2754
	global_store_b32 v[157:158], v31, off offset:1024          // 00000003FCE4: DC6A0400 007C1F9D
	global_store_b32 v[157:158], v32, off offset:2048          // 00000003FCEC: DC6A0800 007C209D
	global_store_b32 v[157:158], v34, off offset:3072          // 00000003FCF4: DC6A0C00 007C229D
	.long 0xd7006a54                                           // 00000003FCFC: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 00000003FD00: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003FD08: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000003FD0C: D5207C55 01AAA680
	.long 0xd7006a9d                                           // 00000003FD14: D7006A9D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000003FD18: 0201FF52
	.long 0x0000e000                                           // 00000003FD1C: 0000E000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000003FD20: D5207C9E 01AAA680
	.long 0xd7006aa3                                           // 00000003FD28: D7006AA3
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 00000003FD2C: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003FD34: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 00000003FD38: D5207CA4 01AAA680
	.long 0xd7006a52                                           // 00000003FD40: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 00000003FD44: 0202A4FF 0000F000
	s_clause 0x7                                               // 00000003FD4C: BF850007
	global_store_b32 v[159:160], v11, off offset:-4096         // 00000003FD50: DC6A1000 007C0B9F
	global_store_b32 v[159:160], v12, off                      // 00000003FD58: DC6A0000 007C0C9F
	global_store_b32 v[161:162], v14, off offset:-4096         // 00000003FD60: DC6A1000 007C0EA1
	global_store_b32 v[161:162], v15, off                      // 00000003FD68: DC6A0000 007C0FA1
	global_store_b32 v[155:156], v27, off offset:-4096         // 00000003FD70: DC6A1000 007C1B9B
	global_store_b32 v[155:156], v28, off                      // 00000003FD78: DC6A0000 007C1C9B
	global_store_b32 v[157:158], v29, off offset:-4096         // 00000003FD80: DC6A1000 007C1D9D
	global_store_b32 v[157:158], v30, off                      // 00000003FD88: DC6A0000 007C1E9D
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 00000003FD90: D5207C53 01AAA680
	s_clause 0xf                                               // 00000003FD98: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 00000003FD9C: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 00000003FDA4: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 00000003FDAC: DC6A0C00 007C1654
	global_store_b32 v[163:164], v23, off offset:1024          // 00000003FDB4: DC6A0400 007C17A3
	global_store_b32 v[163:164], v24, off offset:2048          // 00000003FDBC: DC6A0800 007C18A3
	global_store_b32 v[163:164], v26, off offset:3072          // 00000003FDC4: DC6A0C00 007C1AA3
	global_store_b32 v[82:83], v16, off                        // 00000003FDCC: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 00000003FDD4: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 00000003FDDC: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 00000003FDE4: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 00000003FDEC: DC6A0000 007C0556
	global_store_b32 v[153:154], v6, off offset:-4096          // 00000003FDF4: DC6A1000 007C0699
	global_store_b32 v[153:154], v7, off                       // 00000003FDFC: DC6A0000 007C0799
	global_store_b32 v[88:89], v8, off offset:-4096            // 00000003FE04: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 00000003FE0C: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 00000003FE14: DC6A0C00 007C0D52
	s_cmp_lg_u32 s13, s54                                      // 00000003FE1C: BF07360D
	s_cbranch_scc1 65086                                       // 00000003FE20: BFA2FE3E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x421c>
	v_mov_b32_e32 v82, v2                                      // 00000003FE24: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003FE28: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 00000003FE2C: 34A6A49F
	.long 0xd73c0052                                           // 00000003FE30: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 00000003FE34: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003FE38: BF870091
	.long 0xd7006a52                                           // 00000003FE3C: D7006A52
	v_cndmask_b32_e32 v1, s18, v82, vcc_lo                     // 00000003FE40: 0202A412
	v_add_co_ci_u32_e64 v83, null, s19, v83, vcc_lo            // 00000003FE44: D5207C53 01AAA613
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000003FE4C: BF870092
	.long 0xd7006a54                                           // 00000003FE50: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 00000003FE54: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000003FE5C: D5207C55 01AAA680
	.long 0xd7006a56                                           // 00000003FE64: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000003FE68: 0201FF52
	.long 0x00002000                                           // 00000003FE6C: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003FE70: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 00000003FE74: D5207C57 01AAA680
	.long 0xd7006a58                                           // 00000003FE7C: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 00000003FE80: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000003FE88: D5207C59 01AAA680
	s_clause 0x7                                               // 00000003FE90: BF850007
	global_store_b32 v[82:83], v69, off                        // 00000003FE94: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 00000003FE9C: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 00000003FEA4: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 00000003FEAC: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 00000003FEB4: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 00000003FEBC: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 00000003FEC4: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 00000003FECC: DC6A0400 007C4458
	.long 0xd7006a54                                           // 00000003FED4: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 00000003FED8: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003FEE0: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000003FEE4: D5207C55 01AAA680
	.long 0xd7006a99                                           // 00000003FEEC: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000003FEF0: 0201FF52
	.long 0x00004000                                           // 00000003FEF4: 00004000
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 00000003FEF8: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 00000003FF00: D7006A9B
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 00000003FF04: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003FF0C: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000003FF10: D5207C9C 01AAA680
	s_clause 0x7                                               // 00000003FF18: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 00000003FF1C: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 00000003FF24: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 00000003FF2C: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 00000003FF34: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 00000003FF3C: DC6A0C00 007C4354
	global_store_b32 v[155:156], v59, off offset:1024          // 00000003FF44: DC6A0400 007C3B9B
	global_store_b32 v[155:156], v60, off offset:2048          // 00000003FF4C: DC6A0800 007C3C9B
	global_store_b32 v[155:156], v61, off offset:3072          // 00000003FF54: DC6A0C00 007C3D9B
	.long 0xd7006a54                                           // 00000003FF5C: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 00000003FF60: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003FF68: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000003FF6C: D5207C55 01AAA680
	.long 0xd7006a58                                           // 00000003FF74: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000003FF78: 0201FF52
	.long 0x00006000                                           // 00000003FF7C: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 00000003FF80: D5207C59 01AAA680
	.long 0xd7006a9b                                           // 00000003FF88: D7006A9B
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 00000003FF8C: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000003FF94: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 00000003FF98: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 00000003FFA0: D7006A9D
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 00000003FFA4: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 00000003FFAC: D5207C9E 01AAA680
	.long 0xd7006a9f                                           // 00000003FFB4: D7006A9F
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 00000003FFB8: 0201FF52
	.long 0x00008000                                           // 00000003FFBC: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000003FFC0: BF870001
	v_add_co_ci_u32_e64 v160, null, 0, v83, vcc_lo             // 00000003FFC4: D5207CA0 01AAA680
	s_clause 0x7                                               // 00000003FFCC: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 00000003FFD0: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 00000003FFD8: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 00000003FFE0: DC6A0C00 007C3654
	global_store_b32 v[155:156], v55, off offset:1024          // 00000003FFE8: DC6A0400 007C379B
	global_store_b32 v[155:156], v56, off offset:2048          // 00000003FFF0: DC6A0800 007C389B
	global_store_b32 v[155:156], v58, off offset:3072          // 00000003FFF8: DC6A0C00 007C3A9B
	global_store_b32 v[157:158], v50, off offset:1024          // 000000040000: DC6A0400 007C329D
	global_store_b32 v[157:158], v51, off offset:2048          // 000000040008: DC6A0800 007C339D
	.long 0xd7006a54                                           // 000000040010: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 000000040014: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004001C: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000040020: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 000000040028: D7006A9B
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 00000004002C: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000040034: D5207C9C 01AAA680
	.long 0xd7006aa1                                           // 00000004003C: D7006AA1
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000040040: 0201FF52
	.long 0x0000a000                                           // 000000040044: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040048: BF8700A1
	v_add_co_ci_u32_e64 v162, null, 0, v83, vcc_lo             // 00000004004C: D5207CA2 01AAA680
	.long 0xd7006aa3                                           // 000000040054: D7006AA3
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 000000040058: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 000000040060: D5207CA4 01AAA680
	s_clause 0x7                                               // 000000040068: BF850007
	global_store_b32 v[157:158], v40, off offset:3072          // 00000004006C: DC6A0C00 007C289D
	global_store_b32 v[84:85], v43, off offset:1024            // 000000040074: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 00000004007C: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 000000040084: DC6A0C00 007C2D54
	global_store_b32 v[155:156], v46, off offset:1024          // 00000004008C: DC6A0400 007C2E9B
	global_store_b32 v[155:156], v47, off offset:2048          // 000000040094: DC6A0800 007C2F9B
	global_store_b32 v[155:156], v48, off offset:3072          // 00000004009C: DC6A0C00 007C309B
	global_store_b32 v[163:164], v42, off offset:1024          // 0000000400A4: DC6A0400 007C2AA3
	.long 0xd7006a54                                           // 0000000400AC: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 0000000400B0: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000400B8: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000400BC: D5207C55 01AAA680
	.long 0xd7006a9b                                           // 0000000400C4: D7006A9B
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000400C8: 0201FF52
	.long 0x0000c000                                           // 0000000400CC: 0000C000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 0000000400D0: D5207C9C 01AAA680
	.long 0xd7006a9d                                           // 0000000400D8: D7006A9D
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 0000000400DC: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000400E4: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 0000000400E8: D5207C9E 01AAA680
	s_clause 0x7                                               // 0000000400F0: BF850007
	global_store_b32 v[163:164], v35, off offset:2048          // 0000000400F4: DC6A0800 007C23A3
	global_store_b32 v[163:164], v36, off offset:3072          // 0000000400FC: DC6A0C00 007C24A3
	global_store_b32 v[84:85], v37, off offset:1024            // 000000040104: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 00000004010C: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 000000040114: DC6A0C00 007C2754
	global_store_b32 v[157:158], v31, off offset:1024          // 00000004011C: DC6A0400 007C1F9D
	global_store_b32 v[157:158], v32, off offset:2048          // 000000040124: DC6A0800 007C209D
	global_store_b32 v[157:158], v34, off offset:3072          // 00000004012C: DC6A0C00 007C229D
	.long 0xd7006a54                                           // 000000040134: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 000000040138: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040140: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000040144: D5207C55 01AAA680
	.long 0xd7006a9d                                           // 00000004014C: D7006A9D
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000040150: 0201FF52
	.long 0x0000e000                                           // 000000040154: 0000E000
	v_add_co_ci_u32_e64 v158, null, 0, v83, vcc_lo             // 000000040158: D5207C9E 01AAA680
	.long 0xd7006aa3                                           // 000000040160: D7006AA3
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 000000040164: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000004016C: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v83, vcc_lo             // 000000040170: D5207CA4 01AAA680
	.long 0xd7006a52                                           // 000000040178: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 00000004017C: 0202A4FF 0000F000
	s_clause 0x7                                               // 000000040184: BF850007
	global_store_b32 v[159:160], v11, off offset:-4096         // 000000040188: DC6A1000 007C0B9F
	global_store_b32 v[159:160], v12, off                      // 000000040190: DC6A0000 007C0C9F
	global_store_b32 v[161:162], v14, off offset:-4096         // 000000040198: DC6A1000 007C0EA1
	global_store_b32 v[161:162], v15, off                      // 0000000401A0: DC6A0000 007C0FA1
	global_store_b32 v[155:156], v27, off offset:-4096         // 0000000401A8: DC6A1000 007C1B9B
	global_store_b32 v[155:156], v28, off                      // 0000000401B0: DC6A0000 007C1C9B
	global_store_b32 v[157:158], v29, off offset:-4096         // 0000000401B8: DC6A1000 007C1D9D
	global_store_b32 v[157:158], v30, off                      // 0000000401C0: DC6A0000 007C1E9D
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 0000000401C8: D5207C53 01AAA680
	s_clause 0xf                                               // 0000000401D0: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 0000000401D4: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 0000000401DC: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 0000000401E4: DC6A0C00 007C1654
	global_store_b32 v[163:164], v23, off offset:1024          // 0000000401EC: DC6A0400 007C17A3
	global_store_b32 v[163:164], v24, off offset:2048          // 0000000401F4: DC6A0800 007C18A3
	global_store_b32 v[163:164], v26, off offset:3072          // 0000000401FC: DC6A0C00 007C1AA3
	global_store_b32 v[82:83], v16, off                        // 000000040204: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 00000004020C: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 000000040214: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 00000004021C: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 000000040224: DC6A0000 007C0556
	global_store_b32 v[153:154], v6, off offset:-4096          // 00000004022C: DC6A1000 007C0699
	global_store_b32 v[153:154], v7, off                       // 000000040234: DC6A0000 007C0799
	global_store_b32 v[88:89], v8, off offset:-4096            // 00000004023C: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 000000040244: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 00000004024C: DC6A0C00 007C0D52
	s_cmp_lg_u32 s14, s54                                      // 000000040254: BF07360E
	s_cbranch_scc1 61164                                       // 000000040258: BFA2EEEC <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000004025C: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000040260: BF870091
	.long 0xd73c0002                                           // 000000040264: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000040268: 02020482
	.long 0xd7006a02                                           // 00000004026C: D7006A02
	v_cndmask_b32_e32 v1, s47, v2, vcc_lo                      // 000000040270: 0202042F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000040274: BF870111
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 000000040278: D5207C03 01AA0607
	.long 0xd7006a52                                           // 000000040280: D7006A52
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 000000040284: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004028C: BF8700A1
	v_add_co_ci_u32_e64 v83, null, 0, v3, vcc_lo               // 000000040290: D5207C53 01AA0680
	.long 0xd7006a54                                           // 000000040298: D7006A54
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000004029C: 0201FF02
	.long 0x00002000                                           // 0000000402A0: 00002000
	v_add_co_ci_u32_e64 v85, null, 0, v3, vcc_lo               // 0000000402A4: D5207C55 01AA0680
	.long 0xd7006a56                                           // 0000000402AC: D7006A56
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 0000000402B0: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000402B8: BF870001
	v_add_co_ci_u32_e64 v87, null, 0, v3, vcc_lo               // 0000000402BC: D5207C57 01AA0680
	s_clause 0x7                                               // 0000000402C4: BF850007
	global_store_b32 v[2:3], v69, off                          // 0000000402C8: DC6A0000 007C4502
	global_store_b32 v[2:3], v70, off offset:1024              // 0000000402D0: DC6A0400 007C4602
	global_store_b32 v[2:3], v71, off offset:2048              // 0000000402D8: DC6A0800 007C4702
	global_store_b32 v[2:3], v72, off offset:3072              // 0000000402E0: DC6A0C00 007C4802
	global_store_b32 v[82:83], v73, off offset:1024            // 0000000402E8: DC6A0400 007C4952
	global_store_b32 v[82:83], v151, off offset:2048           // 0000000402F0: DC6A0800 007C9752
	global_store_b32 v[82:83], v152, off offset:3072           // 0000000402F8: DC6A0C00 007C9852
	global_store_b32 v[86:87], v68, off offset:1024            // 000000040300: DC6A0400 007C4456
	.long 0xd7006a44                                           // 000000040308: D7006A44
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 00000004030C: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040314: BF8700A1
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 000000040318: D5207C45 01AA0680
	.long 0xd7006a46                                           // 000000040320: D7006A46
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000040324: 0201FF02
	.long 0x00004000                                           // 000000040328: 00004000
	v_add_co_ci_u32_e64 v71, null, 0, v3, vcc_lo               // 00000004032C: D5207C47 01AA0680
	.long 0xd7006a48                                           // 000000040334: D7006A48
	v_cndmask_b32_e32 v1, 0x4000, v2, vcc_lo                   // 000000040338: 020204FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000040340: BF870001
	v_add_co_ci_u32_e64 v73, null, 0, v3, vcc_lo               // 000000040344: D5207C49 01AA0680
	s_clause 0x7                                               // 00000004034C: BF850007
	global_store_b32 v[86:87], v62, off offset:2048            // 000000040350: DC6A0800 007C3E56
	global_store_b32 v[86:87], v63, off offset:3072            // 000000040358: DC6A0C00 007C3F56
	global_store_b32 v[68:69], v64, off offset:1024            // 000000040360: DC6A0400 007C4044
	global_store_b32 v[68:69], v66, off offset:2048            // 000000040368: DC6A0800 007C4244
	global_store_b32 v[68:69], v67, off offset:3072            // 000000040370: DC6A0C00 007C4344
	global_store_b32 v[72:73], v59, off offset:1024            // 000000040378: DC6A0400 007C3B48
	global_store_b32 v[72:73], v60, off offset:2048            // 000000040380: DC6A0800 007C3C48
	global_store_b32 v[72:73], v61, off offset:3072            // 000000040388: DC6A0C00 007C3D48
	.long 0xd7006a3b                                           // 000000040390: D7006A3B
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 000000040394: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004039C: BF8700A1
	v_add_co_ci_u32_e64 v60, null, 0, v3, vcc_lo               // 0000000403A0: D5207C3C 01AA0680
	.long 0xd7006a3d                                           // 0000000403A8: D7006A3D
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 0000000403AC: 0201FF02
	.long 0x00006000                                           // 0000000403B0: 00006000
	v_add_co_ci_u32_e64 v62, null, 0, v3, vcc_lo               // 0000000403B4: D5207C3E 01AA0680
	.long 0xd7006a3f                                           // 0000000403BC: D7006A3F
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 0000000403C0: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000403C8: BF8700A1
	v_add_co_ci_u32_e64 v64, null, 0, v3, vcc_lo               // 0000000403CC: D5207C40 01AA0680
	.long 0xd7006a42                                           // 0000000403D4: D7006A42
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 0000000403D8: 020204FF 00007000
	v_add_co_ci_u32_e64 v67, null, 0, v3, vcc_lo               // 0000000403E0: D5207C43 01AA0680
	.long 0xd7006a44                                           // 0000000403E8: D7006A44
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 0000000403EC: 0201FF02
	.long 0x00008000                                           // 0000000403F0: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000403F4: BF870001
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 0000000403F8: D5207C45 01AA0680
	s_clause 0x7                                               // 000000040400: BF850007
	global_store_b32 v[59:60], v52, off offset:1024            // 000000040404: DC6A0400 007C343B
	global_store_b32 v[59:60], v53, off offset:2048            // 00000004040C: DC6A0800 007C353B
	global_store_b32 v[59:60], v54, off offset:3072            // 000000040414: DC6A0C00 007C363B
	global_store_b32 v[63:64], v55, off offset:1024            // 00000004041C: DC6A0400 007C373F
	global_store_b32 v[63:64], v56, off offset:2048            // 000000040424: DC6A0800 007C383F
	global_store_b32 v[63:64], v58, off offset:3072            // 00000004042C: DC6A0C00 007C3A3F
	global_store_b32 v[66:67], v50, off offset:1024            // 000000040434: DC6A0400 007C3242
	global_store_b32 v[66:67], v51, off offset:2048            // 00000004043C: DC6A0800 007C3342
	.long 0xd7006a32                                           // 000000040444: D7006A32
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 000000040448: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040450: BF8700A1
	v_add_co_ci_u32_e64 v51, null, 0, v3, vcc_lo               // 000000040454: D5207C33 01AA0680
	.long 0xd7006a34                                           // 00000004045C: D7006A34
	v_cndmask_b32_e32 v1, 0x9000, v2, vcc_lo                   // 000000040460: 020204FF 00009000
	v_add_co_ci_u32_e64 v53, null, 0, v3, vcc_lo               // 000000040468: D5207C35 01AA0680
	.long 0xd7006a36                                           // 000000040470: D7006A36
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000040474: 0201FF02
	.long 0x0000a000                                           // 000000040478: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000004047C: BF8700A1
	v_add_co_ci_u32_e64 v55, null, 0, v3, vcc_lo               // 000000040480: D5207C37 01AA0680
	.long 0xd7006a3a                                           // 000000040488: D7006A3A
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 00000004048C: 020204FF 0000A000
	v_add_co_ci_u32_e64 v59, null, 0, v3, vcc_lo               // 000000040494: D5207C3B 01AA0680
	s_clause 0x7                                               // 00000004049C: BF850007
	global_store_b32 v[66:67], v40, off offset:3072            // 0000000404A0: DC6A0C00 007C2842
	global_store_b32 v[50:51], v43, off offset:1024            // 0000000404A8: DC6A0400 007C2B32
	global_store_b32 v[50:51], v44, off offset:2048            // 0000000404B0: DC6A0800 007C2C32
	global_store_b32 v[50:51], v45, off offset:3072            // 0000000404B8: DC6A0C00 007C2D32
	global_store_b32 v[52:53], v46, off offset:1024            // 0000000404C0: DC6A0400 007C2E34
	global_store_b32 v[52:53], v47, off offset:2048            // 0000000404C8: DC6A0800 007C2F34
	global_store_b32 v[52:53], v48, off offset:3072            // 0000000404D0: DC6A0C00 007C3034
	global_store_b32 v[58:59], v42, off offset:1024            // 0000000404D8: DC6A0400 007C2A3A
	.long 0xd7006a2a                                           // 0000000404E0: D7006A2A
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 0000000404E4: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000404EC: BF8700A1
	v_add_co_ci_u32_e64 v43, null, 0, v3, vcc_lo               // 0000000404F0: D5207C2B 01AA0680
	.long 0xd7006a2c                                           // 0000000404F8: D7006A2C
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 0000000404FC: 0201FF02
	.long 0x0000c000                                           // 000000040500: 0000C000
	v_add_co_ci_u32_e64 v45, null, 0, v3, vcc_lo               // 000000040504: D5207C2D 01AA0680
	.long 0xd7006a2e                                           // 00000004050C: D7006A2E
	v_cndmask_b32_e32 v1, 0xc000, v2, vcc_lo                   // 000000040510: 020204FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000040518: BF870001
	v_add_co_ci_u32_e64 v47, null, 0, v3, vcc_lo               // 00000004051C: D5207C2F 01AA0680
	s_clause 0x7                                               // 000000040524: BF850007
	global_store_b32 v[58:59], v35, off offset:2048            // 000000040528: DC6A0800 007C233A
	global_store_b32 v[58:59], v36, off offset:3072            // 000000040530: DC6A0C00 007C243A
	global_store_b32 v[42:43], v37, off offset:1024            // 000000040538: DC6A0400 007C252A
	global_store_b32 v[42:43], v38, off offset:2048            // 000000040540: DC6A0800 007C262A
	global_store_b32 v[42:43], v39, off offset:3072            // 000000040548: DC6A0C00 007C272A
	global_store_b32 v[46:47], v31, off offset:1024            // 000000040550: DC6A0400 007C1F2E
	global_store_b32 v[46:47], v32, off offset:2048            // 000000040558: DC6A0800 007C202E
	global_store_b32 v[46:47], v34, off offset:3072            // 000000040560: DC6A0C00 007C222E
	.long 0xd7006a1f                                           // 000000040568: D7006A1F
	v_cndmask_b32_e32 v1, 0xd000, v2, vcc_lo                   // 00000004056C: 020204FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000040574: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v3, vcc_lo               // 000000040578: D5207C20 01AA0680
	.long 0xd7006a22                                           // 000000040580: D7006A22
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000040584: 0201FF02
	.long 0x0000e000                                           // 000000040588: 0000E000
	v_add_co_ci_u32_e64 v35, null, 0, v3, vcc_lo               // 00000004058C: D5207C23 01AA0680
	.long 0xd7006a24                                           // 000000040594: D7006A24
	v_cndmask_b32_e32 v1, 0xe000, v2, vcc_lo                   // 000000040598: 020204FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000405A0: BF870001
	v_add_co_ci_u32_e64 v37, null, 0, v3, vcc_lo               // 0000000405A4: D5207C25 01AA0680
	.long 0xd7006a02                                           // 0000000405AC: D7006A02
	v_cndmask_b32_e32 v1, 0xf000, v2, vcc_lo                   // 0000000405B0: 020204FF 0000F000
	s_clause 0x7                                               // 0000000405B8: BF850007
	global_store_b32 v[68:69], v11, off offset:-4096           // 0000000405BC: DC6A1000 007C0B44
	global_store_b32 v[68:69], v12, off                        // 0000000405C4: DC6A0000 007C0C44
	global_store_b32 v[54:55], v14, off offset:-4096           // 0000000405CC: DC6A1000 007C0E36
	global_store_b32 v[54:55], v15, off                        // 0000000405D4: DC6A0000 007C0F36
	global_store_b32 v[44:45], v27, off offset:-4096           // 0000000405DC: DC6A1000 007C1B2C
	global_store_b32 v[44:45], v28, off                        // 0000000405E4: DC6A0000 007C1C2C
	global_store_b32 v[34:35], v29, off offset:-4096           // 0000000405EC: DC6A1000 007C1D22
	global_store_b32 v[34:35], v30, off                        // 0000000405F4: DC6A0000 007C1E22
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000000405FC: D5207C03 01AA0680
	s_clause 0xf                                               // 000000040604: BF85000F
	global_store_b32 v[31:32], v20, off offset:1024            // 000000040608: DC6A0400 007C141F
	global_store_b32 v[31:32], v21, off offset:2048            // 000000040610: DC6A0800 007C151F
	global_store_b32 v[31:32], v22, off offset:3072            // 000000040618: DC6A0C00 007C161F
	global_store_b32 v[36:37], v23, off offset:1024            // 000000040620: DC6A0400 007C1724
	global_store_b32 v[36:37], v24, off offset:2048            // 000000040628: DC6A0800 007C1824
	global_store_b32 v[36:37], v26, off offset:3072            // 000000040630: DC6A0C00 007C1A24
	global_store_b32 v[2:3], v16, off                          // 000000040638: DC6A0000 007C1002
	global_store_b32 v[2:3], v18, off offset:1024              // 000000040640: DC6A0400 007C1202
	global_store_b32 v[2:3], v19, off offset:2048              // 000000040648: DC6A0800 007C1302
	global_store_b32 v[84:85], v4, off offset:-4096            // 000000040650: DC6A1000 007C0454
	global_store_b32 v[84:85], v5, off                         // 000000040658: DC6A0000 007C0554
	global_store_b32 v[70:71], v6, off offset:-4096            // 000000040660: DC6A1000 007C0646
	global_store_b32 v[70:71], v7, off                         // 000000040668: DC6A0000 007C0746
	global_store_b32 v[61:62], v8, off offset:-4096            // 000000040670: DC6A1000 007C083D
	global_store_b32 v[61:62], v10, off                        // 000000040678: DC6A0000 007C0A3D
	global_store_b32 v[2:3], v13, off offset:3072              // 000000040680: DC6A0C00 007C0D02
	s_branch 60896                                             // 000000040688: BFA0EDE0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x90c>
	v_mov_b32_e32 v54, v41                                     // 00000004068C: 7E6C0329
	v_mov_b32_e32 v53, v33                                     // 000000040690: 7E6A0321
	v_mov_b32_e32 v52, v25                                     // 000000040694: 7E680319
	v_mov_b32_e32 v51, v17                                     // 000000040698: 7E660311
	v_mov_b32_e32 v50, v9                                      // 00000004069C: 7E640309
	v_mov_b32_e32 v58, v49                                     // 0000000406A0: 7E740331
	v_mov_b32_e32 v152, v57                                    // 0000000406A4: 7F300339
	v_mov_b32_e32 v151, v65                                    // 0000000406A8: 7F2E0341
	s_mov_b32 s7, 0                                            // 0000000406AC: BE870080
	s_branch 1                                                 // 0000000406B0: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x51b8>
	s_mov_b64 s[6:7], 0                                        // 0000000406B4: BE860180
	v_dual_mul_f32 v3, 0x3b800000, v139 :: v_dual_mul_f32 v4, 0x3b800000, v138// 0000000406B8: C8C716FF 030514FF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v137 :: v_dual_mul_f32 v6, 0x3b800000, v136// 0000000406C4: C8C712FF 050710FF 3B800000
	.long 0xd7006a01                                           // 0000000406D0: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000406D4: 0201FFBB
	.long 0x00002000                                           // 0000000406D8: 00002000
	v_dual_mul_f32 v7, 0x3b800000, v135 :: v_dual_mul_f32 v8, 0x3b800000, v134// 0000000406DC: C8C70EFF 07090CFF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 0000000406E8: D5207C02 01AB7880
	v_dual_mul_f32 v9, 0x3b800000, v133 :: v_dual_mul_f32 v10, 0x3b800000, v54// 0000000406F0: C8C70AFF 090A6CFF 3B800000
	s_clause 0x7                                               // 0000000406FC: BF850007
	global_store_b32 v[187:188], v3, off                       // 000000040700: DC6A0000 007C03BB
	global_store_b32 v[187:188], v4, off offset:1024           // 000000040708: DC6A0400 007C04BB
	global_store_b32 v[187:188], v5, off offset:2048           // 000000040710: DC6A0800 007C05BB
	global_store_b32 v[187:188], v6, off offset:3072           // 000000040718: DC6A0C00 007C06BB
	global_store_b32 v[1:2], v7, off offset:-4096              // 000000040720: DC6A1000 007C0701
	global_store_b32 v[1:2], v8, off offset:-3072              // 000000040728: DC6A1400 007C0801
	global_store_b32 v[1:2], v9, off offset:-2048              // 000000040730: DC6A1800 007C0901
	global_store_b32 v[1:2], v10, off offset:-1024             // 000000040738: DC6A1C00 007C0A01
	v_dual_mul_f32 v5, 0x3b800000, v132 :: v_dual_mul_f32 v6, 0x3b800000, v131// 000000040740: C8C708FF 050706FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v130 :: v_dual_mul_f32 v8, 0x3b800000, v129// 00000004074C: C8C704FF 070902FF 3B800000
	.long 0xd7006a03                                           // 000000040758: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004075C: 0201FFBB
	.long 0x00004000                                           // 000000040760: 00004000
	v_dual_mul_f32 v9, 0x3b800000, v128 :: v_dual_mul_f32 v10, 0x3b800000, v127// 000000040764: C8C700FF 090AFEFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000040770: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v126 :: v_dual_mul_f32 v12, 0x3b800000, v53// 000000040778: C8C6FCFF 0B0C6AFF 3B800000
	s_clause 0x7                                               // 000000040784: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000040788: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000040790: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 000000040798: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 0000000407A0: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 0000000407A8: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 0000000407B0: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 0000000407B8: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 0000000407C0: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v125 :: v_dual_mul_f32 v6, 0x3b800000, v124// 0000000407C8: C8C6FAFF 0506F8FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v123 :: v_dual_mul_f32 v8, 0x3b800000, v122// 0000000407D4: C8C6F6FF 0708F4FF 3B800000
	.long 0xd7006a01                                           // 0000000407E0: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000407E4: 0201FFBB
	.long 0x00006000                                           // 0000000407E8: 00006000
	v_dual_mul_f32 v9, 0x3b800000, v121 :: v_dual_mul_f32 v10, 0x3b800000, v120// 0000000407EC: C8C6F2FF 090AF0FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 0000000407F8: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v119 :: v_dual_mul_f32 v12, 0x3b800000, v52// 000000040800: C8C6EEFF 0B0C68FF 3B800000
	s_clause 0x7                                               // 00000004080C: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000040810: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 000000040818: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000040820: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 000000040828: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000040830: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000040838: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000040840: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000040848: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v118 :: v_dual_mul_f32 v6, 0x3b800000, v117// 000000040850: C8C6ECFF 0506EAFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v116 :: v_dual_mul_f32 v8, 0x3b800000, v115// 00000004085C: C8C6E8FF 0708E6FF 3B800000
	.long 0xd7006a03                                           // 000000040868: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004086C: 0201FFBB
	.long 0x00008000                                           // 000000040870: 00008000
	v_dual_mul_f32 v9, 0x3b800000, v114 :: v_dual_mul_f32 v10, 0x3b800000, v113// 000000040874: C8C6E4FF 090AE2FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000040880: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v112 :: v_dual_mul_f32 v12, 0x3b800000, v51// 000000040888: C8C6E0FF 0B0C66FF 3B800000
	s_clause 0x7                                               // 000000040894: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000040898: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 0000000408A0: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 0000000408A8: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 0000000408B0: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 0000000408B8: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 0000000408C0: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 0000000408C8: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 0000000408D0: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v111 :: v_dual_mul_f32 v6, 0x3b800000, v110// 0000000408D8: C8C6DEFF 0506DCFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v109 :: v_dual_mul_f32 v8, 0x3b800000, v108// 0000000408E4: C8C6DAFF 0708D8FF 3B800000
	.long 0xd7006a01                                           // 0000000408F0: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 0000000408F4: 0201FFBB
	.long 0x0000a000                                           // 0000000408F8: 0000A000
	v_dual_mul_f32 v9, 0x3b800000, v107 :: v_dual_mul_f32 v10, 0x3b800000, v106// 0000000408FC: C8C6D6FF 090AD4FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 000000040908: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v105 :: v_dual_mul_f32 v12, 0x3b800000, v50// 000000040910: C8C6D2FF 0B0C64FF 3B800000
	s_clause 0x7                                               // 00000004091C: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000040920: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 000000040928: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000040930: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 000000040938: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000040940: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000040948: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000040950: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000040958: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v104 :: v_dual_mul_f32 v6, 0x3b800000, v103// 000000040960: C8C6D0FF 0506CEFF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v102 :: v_dual_mul_f32 v8, 0x3b800000, v101// 00000004096C: C8C6CCFF 0708CAFF 3B800000
	.long 0xd7006a03                                           // 000000040978: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 00000004097C: 0201FFBB
	.long 0x0000c000                                           // 000000040980: 0000C000
	v_dual_mul_f32 v9, 0x3b800000, v100 :: v_dual_mul_f32 v10, 0x3b800000, v99// 000000040984: C8C6C8FF 090AC6FF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000040990: D5207C04 01AB7880
	v_mul_f32_e32 v11, 0x3b800000, v98                         // 000000040998: 1016C4FF 3B800000
	v_mul_f32_e32 v12, 0x3b800000, v58                         // 0000000409A0: 101874FF 3B800000
	s_clause 0x7                                               // 0000000409A8: BF850007
	global_store_b32 v[1:2], v5, off                           // 0000000409AC: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 0000000409B4: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 0000000409BC: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 0000000409C4: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-4096              // 0000000409CC: DC6A1000 007C0903
	global_store_b32 v[3:4], v10, off offset:-3072             // 0000000409D4: DC6A1400 007C0A03
	global_store_b32 v[3:4], v11, off offset:-2048             // 0000000409DC: DC6A1800 007C0B03
	global_store_b32 v[3:4], v12, off offset:-1024             // 0000000409E4: DC6A1C00 007C0C03
	v_dual_mul_f32 v5, 0x3b800000, v97 :: v_dual_mul_f32 v6, 0x3b800000, v96// 0000000409EC: C8C6C2FF 0506C0FF 3B800000
	v_dual_mul_f32 v7, 0x3b800000, v95 :: v_dual_mul_f32 v8, 0x3b800000, v94// 0000000409F8: C8C6BEFF 0708BCFF 3B800000
	.long 0xd7006a01                                           // 000000040A04: D7006A01
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000040A08: 0201FFBB
	.long 0x0000e000                                           // 000000040A0C: 0000E000
	v_dual_mul_f32 v9, 0x3b800000, v93 :: v_dual_mul_f32 v10, 0x3b800000, v92// 000000040A10: C8C6BAFF 090AB8FF 3B800000
	v_add_co_ci_u32_e64 v2, null, 0, v188, vcc_lo              // 000000040A1C: D5207C02 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v91 :: v_dual_mul_f32 v12, 0x3b800000, v152// 000000040A24: C8C6B6FF 0B0D30FF 3B800000
	s_clause 0x7                                               // 000000040A30: BF850007
	global_store_b32 v[3:4], v5, off                           // 000000040A34: DC6A0000 007C0503
	global_store_b32 v[3:4], v6, off offset:1024               // 000000040A3C: DC6A0400 007C0603
	global_store_b32 v[3:4], v7, off offset:2048               // 000000040A44: DC6A0800 007C0703
	global_store_b32 v[3:4], v8, off offset:3072               // 000000040A4C: DC6A0C00 007C0803
	global_store_b32 v[1:2], v9, off offset:-4096              // 000000040A54: DC6A1000 007C0901
	global_store_b32 v[1:2], v10, off offset:-3072             // 000000040A5C: DC6A1400 007C0A01
	global_store_b32 v[1:2], v11, off offset:-2048             // 000000040A64: DC6A1800 007C0B01
	global_store_b32 v[1:2], v12, off offset:-1024             // 000000040A6C: DC6A1C00 007C0C01
	v_dual_mul_f32 v5, 0x3b800000, v90 :: v_dual_mul_f32 v6, 0x3b800000, v141// 000000040A74: C8C6B4FF 05071AFF 3B800000
	v_and_or_b32 v0, v0, 31, s5                                // 000000040A80: D6570000 00153F00
	v_dual_mul_f32 v7, 0x3b800000, v150 :: v_dual_mul_f32 v10, 0x3b800000, v189// 000000040A88: C8C72CFF 070B7AFF 3B800000
	.long 0xd7006a03                                           // 000000040A94: D7006A03
	v_cndmask_b32_e32 v0, v187, v255, vcc_lo                   // 000000040A98: 0201FFBB
	.long 0x0000fc00                                           // 000000040A9C: 0000FC00
	v_dual_mul_f32 v8, 0x3b800000, v142 :: v_dual_mul_f32 v9, 0x3b800000, v191// 000000040AA0: C8C71CFF 08097EFF 3B800000
	v_add_co_ci_u32_e64 v4, null, 0, v188, vcc_lo              // 000000040AAC: D5207C04 01AB7880
	v_dual_mul_f32 v11, 0x3b800000, v190 :: v_dual_mul_f32 v12, 0x3b800000, v151// 000000040AB4: C8C77CFF 0B0D2EFF 3B800000
	s_clause 0x7                                               // 000000040AC0: BF850007
	global_store_b32 v[1:2], v5, off                           // 000000040AC4: DC6A0000 007C0501
	global_store_b32 v[1:2], v6, off offset:1024               // 000000040ACC: DC6A0400 007C0601
	global_store_b32 v[1:2], v7, off offset:2048               // 000000040AD4: DC6A0800 007C0701
	global_store_b32 v[1:2], v8, off offset:3072               // 000000040ADC: DC6A0C00 007C0801
	global_store_b32 v[3:4], v9, off offset:-3072              // 000000040AE4: DC6A1400 007C0903
	global_store_b32 v[3:4], v10, off offset:-2048             // 000000040AEC: DC6A1800 007C0A03
	global_store_b32 v[3:4], v11, off offset:-1024             // 000000040AF4: DC6A1C00 007C0B03
	global_store_b32 v[3:4], v12, off                          // 000000040AFC: DC6A0000 007C0C03
	s_mov_b32 s2, exec_lo                                      // 000000040B04: BE82007E
	v_cmpx_eq_u32_e32 0, v0                                    // 000000040B08: 7D940080
	s_cbranch_execz 8                                          // 000000040B0C: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi5ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5630>
	s_load_b64 s[0:1], s[0:1], 0x40                            // 000000040B10: F4040000 F8000040
	v_mov_b32_e32 v0, s6                                       // 000000040B18: 7E000206
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, s7              // 000000040B1C: CA100080 02000007
	s_waitcnt lgkmcnt(0)                                       // 000000040B24: BF89FC07
	global_store_b64 v2, v[0:1], s[0:1] offset:32              // 000000040B28: DC6E0020 00000002
	s_endpgm                                                   // 000000040B30: BFB00000
		...

