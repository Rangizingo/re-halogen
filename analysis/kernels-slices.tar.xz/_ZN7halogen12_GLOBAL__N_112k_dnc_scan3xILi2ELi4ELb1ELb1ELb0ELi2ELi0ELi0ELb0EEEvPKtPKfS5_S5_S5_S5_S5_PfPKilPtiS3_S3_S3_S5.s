00000000001e4200 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE():
	s_load_b256 s[16:23], s[0:1], 0x38                         // 0000001E4200: F40C0400 F8000038
	v_mov_b32_e32 v17, v0                                      // 0000001E4208: 7E220300
	s_lshl_b32 s6, s3, 6                                       // 0000001E420C: 84068603
	s_ashr_i32 s3, s2, 31                                      // 0000001E4210: 86039F02
	s_ashr_i32 s7, s6, 31                                      // 0000001E4214: 86079F06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001E4218: BF870091
	v_and_b32_e32 v1, 63, v17                                  // 0000001E421C: 360222BF
	v_lshlrev_b32_e32 v0, 2, v1                                // 0000001E4220: 30000282
	v_mul_u32_u24_e32 v2, 0x210, v1                            // 0000001E4224: 160402FF 00000210
	v_mov_b32_e32 v5, v17                                      // 0000001E422C: 7E0A0311
	s_waitcnt lgkmcnt(0)                                       // 0000001E4230: BF89FC07
	s_load_b32 s4, s[18:19], null                              // 0000001E4234: F4000109 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000001E423C: 84928214
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001E4240: BF8704B9
	s_add_u32 s5, s16, s18                                     // 0000001E4244: 80051210
	s_addc_u32 s8, s17, s19                                    // 0000001E4248: 82081311
	s_lshl_b64 s[34:35], s[2:3], 16                            // 0000001E424C: 84A29002
	s_add_u32 s5, s5, s34                                      // 0000001E4250: 80052205
	s_addc_u32 s8, s8, s35                                     // 0000001E4254: 82082308
	s_waitcnt lgkmcnt(0)                                       // 0000001E4258: BF89FC07
	s_mul_i32 s46, s4, 0x9000000                               // 0000001E425C: 962EFF04 09000000
	s_mul_hi_i32 s33, s4, 0x9000000                            // 0000001E4264: 9721FF04 09000000
	s_add_u32 s4, s5, s46                                      // 0000001E426C: 80042E05
	s_addc_u32 s5, s8, s33                                     // 0000001E4270: 82052108
	s_lshl_b64 s[44:45], s[6:7], 2                             // 0000001E4274: 84AC8206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001E4278: BF8700B9
	s_add_u32 s4, s4, s44                                      // 0000001E427C: 80042C04
	s_addc_u32 s5, s5, s45                                     // 0000001E4280: 82052D05
	.long 0xd7000403                                           // 0000001E4284: D7000403
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 0000001E4288: 02020004
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 0000001E428C: D5207C04 00110005
	s_mov_b32 s4, 0                                            // 0000001E4294: BE840080
	s_nop 0                                                    // 0000001E4298: BF800000
	s_nop 0                                                    // 0000001E429C: BF800000
	s_nop 0                                                    // 0000001E42A0: BF800000
	s_nop 0                                                    // 0000001E42A4: BF800000
	s_nop 0                                                    // 0000001E42A8: BF800000
	s_nop 0                                                    // 0000001E42AC: BF800000
	s_nop 0                                                    // 0000001E42B0: BF800000
	s_nop 0                                                    // 0000001E42B4: BF800000
	s_nop 0                                                    // 0000001E42B8: BF800000
	s_nop 0                                                    // 0000001E42BC: BF800000
	v_lshrrev_b32_e32 v0, 6, v5                                // 0000001E42C0: 32000A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001E42C4: BF870121
	v_lshlrev_b32_e32 v6, 9, v0                                // 0000001E42C8: 300C0089
	v_lshl_add_u32 v0, v0, 2, v2                               // 0000001E42CC: D6460000 04090500
	.long 0xd7006a06                                           // 0000001E42D4: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000001E42D8: 02020D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001E42DC: BF8700D1
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000001E42E0: D5207C07 01AA0880
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v5                        // 0000001E42E8: 7C920AFF 00001F7F
	global_load_b32 v6, v[6:7], off                            // 0000001E42F0: DC520000 067C0006
	v_add_nc_u32_e32 v7, 0x80, v5                              // 0000001E42F8: 4A0E0AFF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 0000001E4300: 8C04046A
	v_mov_b32_e32 v5, v7                                       // 0000001E4304: 7E0A0307
	s_waitcnt vmcnt(0)                                         // 0000001E4308: BF8903F7
	ds_store_b32 v0, v6                                        // 0000001E430C: D8340000 00000600
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001E4314: 917E047E
	s_cbranch_execnz 65513                                     // 0000001E4318: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001E431C: 8C7E047E
	s_load_b32 s47, s[0:1], 0x58                               // 0000001E4320: F4000BC0 F8000058
	v_dual_mov_b32 v163, 0 :: v_dual_lshlrev_b32 v18, 2, v1    // 0000001E4328: CA220080 A3120282
	v_or_b32_e32 v0, 0xffffff80, v17                           // 0000001E4330: 380022FF FFFFFF80
	v_lshlrev_b32_e32 v5, 3, v17                               // 0000001E4338: 300A2283
	v_mul_u32_u24_e32 v3, 0x210, v1                            // 0000001E433C: 160602FF 00000210
	v_lshrrev_b32_e32 v4, 4, v17                               // 0000001E4344: 32082284
	s_mov_b32 s4, 0                                            // 0000001E4348: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000001E434C: BF89FC07
	scratch_store_b32 off, v0, off                             // 0000001E4350: DC690000 007C0000
	s_barrier                                                  // 0000001E4358: BFBD0000
	s_waitcnt_vscnt null, 0x0                                  // 0000001E435C: BC7C0000
	buffer_gl0_inv                                             // 0000001E4360: E0AC0000 00000000
	s_cmp_gt_i32 s47, 0                                        // 0000001E4368: BF02802F
	s_cbranch_scc1 12                                          // 0000001E436C: BFA2000C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x1a0>
	v_or_b32_e32 v6, 0xffffff80, v17                           // 0000001E4370: 380C22FF FFFFFF80
	v_dual_mov_b32 v7, v163 :: v_dual_and_b32 v162, 0x200, v5  // 0000001E4378: CA2401A3 07A20AFF 00000200
	v_and_or_b32 v178, v4, 4, v3                               // 0000001E4384: D65700B2 040D0904
	v_dual_mov_b32 v1, s44 :: v_dual_mov_b32 v2, s45           // 0000001E438C: CA10002C 0102002D
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 0000001E4394: 916A047E
	s_cbranch_vccz 1                                           // 0000001E4398: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x1a0>
	s_branch 8258                                              // 0000001E439C: BFA02042 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x82a8>
	s_clause 0x1                                               // 0000001E43A0: BF850001
	s_load_b128 s[12:15], s[0:1], 0x10                         // 0000001E43A4: F4080300 F8000010
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000001E43AC: F4040200 F8000020
	s_add_i32 s4, s47, 63                                      // 0000001E43B4: 8104BF2F
	v_lshlrev_b32_e32 v1, 2, v17                               // 0000001E43B8: 30022282
	s_ashr_i32 s5, s4, 31                                      // 0000001E43BC: 86059F04
	v_dual_mov_b32 v163, 0 :: v_dual_and_b32 v162, 0x200, v5   // 0000001E43C0: CA240080 A3A20AFF 00000200
	s_lshr_b32 s5, s5, 26                                      // 0000001E43CC: 85059A05
	s_load_b256 s[36:43], s[0:1], 0x80                         // 0000001E43D0: F40C0900 F8000080
	s_add_i32 s10, s4, s5                                      // 0000001E43D8: 810A0504
	s_lshl_b64 s[4:5], s[2:3], 9                               // 0000001E43DC: 84848902
	s_ashr_i32 s48, s10, 6                                     // 0000001E43E0: 8630860A
	v_mov_b32_e32 v5, v163                                     // 0000001E43E4: 7E0A03A3
	s_mov_b32 s21, 0xcc00                                      // 0000001E43E8: BE9500FF 0000CC00
	v_and_or_b32 v178, v4, 4, v3                               // 0000001E43F0: D65700B2 040D0904
	s_waitcnt lgkmcnt(0)                                       // 0000001E43F8: BF89FC07
	s_mov_b32 s39, 0x41800000                                  // 0000001E43FC: BEA700FF 41800000
	s_clause 0x2                                               // 0000001E4404: BF850002
	scratch_store_b32 off, v18, off offset:120                 // 0000001E4408: DC690078 007C1200
	scratch_store_b32 off, v5, off offset:124                  // 0000001E4410: DC69007C 007C0500
	scratch_store_b32 off, v17, off offset:76                  // 0000001E4418: DC69004C 007C1100
	s_add_u32 s4, s12, s4                                      // 0000001E4420: 8004040C
	s_addc_u32 s5, s13, s5                                     // 0000001E4424: 8205050D
	s_add_i32 s49, s47, -1                                     // 0000001E4428: 8131C12F
	.long 0xd7001402                                           // 0000001E442C: D7001402
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000001E4430: 02020204
	s_mul_i32 s10, s49, 48                                     // 0000001E4434: 960AB031
	s_mul_hi_i32 s11, s49, 48                                  // 0000001E4438: 970BB031
	s_add_u32 s10, s10, s2                                     // 0000001E443C: 800A020A
	s_addc_u32 s11, s11, s3                                    // 0000001E4440: 820B030B
	v_add_co_ci_u32_e64 v6, null, s5, 0, s20                   // 0000001E4444: D5207C06 00510005
	s_lshl_b64 s[10:11], s[10:11], 9                           // 0000001E444C: 848A890A
	.long 0xd7006a00                                           // 0000001E4450: D7006A00
	v_cndmask_b32_e32 v1, 0x17a000, v2, vcc_lo                 // 0000001E4454: 020204FF 0017A000
	s_add_u32 s10, s12, s10                                    // 0000001E445C: 800A0A0C
	s_addc_u32 s11, s13, s11                                   // 0000001E4460: 820B0B0D
	.long 0xd7000aae                                           // 0000001E4464: D7000AAE
	v_cndmask_b32_e32 v1, s10, v1, vcc_lo                      // 0000001E4468: 0202020A
	v_add_co_ci_u32_e64 v7, null, 0, v6, vcc_lo                // 0000001E446C: D5207C07 01AA0C80
	v_add_co_ci_u32_e64 v175, null, s11, 0, s10                // 0000001E4474: D5207CAF 0029000B
	.long 0xd7006a09                                           // 0000001E447C: D7006A09
	v_cndmask_b32_e32 v1, 0x174000, v2, vcc_lo                 // 0000001E4480: 020204FF 00174000
	s_cmp_gt_u32 s47, 63                                       // 0000001E4488: BF08BF2F
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001E448C: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4494: 986A80C1
	s_cmp_gt_u32 s47, 62                                       // 0000001E4498: BF08BE2F
	v_dual_cndmask_b32 v8, v175, v7 :: v_dual_cndmask_b32 v7, v174, v0// 0000001E449C: CA520FAF 080601AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E44A4: 986A80C1
	s_cmp_gt_u32 s47, 61                                       // 0000001E44A8: BF08BD2F
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001E44AC: CA5215AF 0A0813AE
	.long 0xd7006a00                                           // 0000001E44B4: D7006A00
	v_cndmask_b32_e32 v1, 0x16e000, v2, vcc_lo                 // 0000001E44B8: 020204FF 0016E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E44C0: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v6, vcc_lo               // 0000001E44C4: D5207C0B 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E44CC: 986A80C1
	global_load_b32 v223, v[7:8], off                          // 0000001E44D0: DC520000 DF7C0007
	s_cmp_gt_u32 s47, 60                                       // 0000001E44D8: BF08BC2F
	v_cndmask_b32_e32 v8, v175, v11, vcc_lo                    // 0000001E44DC: 021017AF
	global_load_b32 v7, v[9:10], off                           // 0000001E44E0: DC520000 077C0009
	s_clause 0x2                                               // 0000001E44E8: BF850002
	s_load_b64 s[10:11], s[0:1], 0x70                          // 0000001E44EC: F4040280 F8000070
	s_load_b128 s[28:31], s[0:1], 0x60                         // 0000001E44F4: F4080700 F8000060
	s_load_b64 s[0:1], s[0:1], 0xa0                            // 0000001E44FC: F4040000 F80000A0
	s_waitcnt vmcnt(0)                                         // 0000001E4504: BF8903F7
	scratch_store_b32 off, v7, off offset:56                   // 0000001E4508: DC690038 007C0700
	v_cndmask_b32_e32 v7, v174, v0, vcc_lo                     // 0000001E4510: 020E01AE
	.long 0xd7006a00                                           // 0000001E4514: D7006A00
	v_cndmask_b32_e32 v1, 0x168000, v2, vcc_lo                 // 0000001E4518: 020204FF 00168000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E4520: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v6, vcc_lo                // 0000001E4524: D5207C09 01AA0C80
	.long 0xd7006a0b                                           // 0000001E452C: D7006A0B
	v_cndmask_b32_e32 v1, 0x162000, v2, vcc_lo                 // 0000001E4530: 020204FF 00162000
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001E4538: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4540: 986A80C1
	s_cmp_gt_u32 s47, 59                                       // 0000001E4544: BF08BB2F
	v_dual_cndmask_b32 v10, v175, v9 :: v_dual_cndmask_b32 v9, v174, v0// 0000001E4548: CA5213AF 0A0801AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4550: 986A80C1
	s_cmp_gt_u32 s47, 58                                       // 0000001E4554: BF08BA2F
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001E4558: CA5219AF 0C0A17AE
	.long 0xd7006a00                                           // 0000001E4560: D7006A00
	v_cndmask_b32_e32 v1, 0x15c000, v2, vcc_lo                 // 0000001E4564: 020204FF 0015C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E456C: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v6, vcc_lo               // 0000001E4570: D5207C0D 01AA0C80
	.long 0xd7006a0f                                           // 0000001E4578: D7006A0F
	v_cndmask_b32_e32 v1, 0x156000, v2, vcc_lo                 // 0000001E457C: 020204FF 00156000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001E4584: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E458C: 986A80C1
	s_cmp_gt_u32 s47, 57                                       // 0000001E4590: BF08B92F
	v_dual_cndmask_b32 v14, v175, v13 :: v_dual_cndmask_b32 v13, v174, v0// 0000001E4594: CA521BAF 0E0C01AE
	global_load_b32 v177, v[7:8], off                          // 0000001E459C: DC520000 B17C0007
	global_load_b32 v176, v[9:10], off                         // 0000001E45A4: DC520000 B07C0009
	global_load_b32 v172, v[11:12], off                        // 0000001E45AC: DC520000 AC7C000B
	global_load_b32 v0, v[13:14], off                          // 0000001E45B4: DC520000 007C000D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E45BC: 986A80C1
	s_cmp_gt_u32 s47, 56                                       // 0000001E45C0: BF08B82F
	v_dual_cndmask_b32 v16, v175, v16 :: v_dual_cndmask_b32 v15, v174, v15// 0000001E45C4: CA5221AF 100E1FAE
	global_load_b32 v222, v[15:16], off                        // 0000001E45CC: DC520000 DE7C000F
	s_waitcnt vmcnt(1)                                         // 0000001E45D4: BF8907F7
	scratch_store_b32 off, v0, off offset:52                   // 0000001E45D8: DC690034 007C0000
	.long 0xd7006a00                                           // 0000001E45E0: D7006A00
	v_cndmask_b32_e32 v1, 0x150000, v2, vcc_lo                 // 0000001E45E4: 020204FF 00150000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E45EC: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v6, vcc_lo                // 0000001E45F0: D5207C07 01AA0C80
	.long 0xd7006a09                                           // 0000001E45F8: D7006A09
	v_cndmask_b32_e32 v1, 0x14a000, v2, vcc_lo                 // 0000001E45FC: 020204FF 0014A000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001E4604: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E460C: 986A80C1
	s_cmp_gt_u32 s47, 55                                       // 0000001E4610: BF08B72F
	v_dual_cndmask_b32 v8, v175, v7 :: v_dual_cndmask_b32 v7, v174, v0// 0000001E4614: CA520FAF 080601AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E461C: 986A80C1
	s_cmp_gt_u32 s47, 54                                       // 0000001E4620: BF08B62F
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001E4624: CA5215AF 0A0813AE
	.long 0xd7006a00                                           // 0000001E462C: D7006A00
	v_cndmask_b32_e32 v1, 0x144000, v2, vcc_lo                 // 0000001E4630: 020204FF 00144000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E4638: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v6, vcc_lo               // 0000001E463C: D5207C0B 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4644: 986A80C1
	global_load_b32 v221, v[7:8], off                          // 0000001E4648: DC520000 DD7C0007
	s_cmp_gt_u32 s47, 53                                       // 0000001E4650: BF08B52F
	v_cndmask_b32_e32 v8, v175, v11, vcc_lo                    // 0000001E4654: 021017AF
	global_load_b32 v7, v[9:10], off                           // 0000001E4658: DC520000 077C0009
	s_waitcnt vmcnt(0)                                         // 0000001E4660: BF8903F7
	scratch_store_b32 off, v7, off offset:48                   // 0000001E4664: DC690030 007C0700
	v_cndmask_b32_e32 v7, v174, v0, vcc_lo                     // 0000001E466C: 020E01AE
	.long 0xd7006a00                                           // 0000001E4670: D7006A00
	v_cndmask_b32_e32 v1, 0x13e000, v2, vcc_lo                 // 0000001E4674: 020204FF 0013E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E467C: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v6, vcc_lo                // 0000001E4680: D5207C09 01AA0C80
	.long 0xd7006a0b                                           // 0000001E4688: D7006A0B
	v_cndmask_b32_e32 v1, 0x138000, v2, vcc_lo                 // 0000001E468C: 020204FF 00138000
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001E4694: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E469C: 986A80C1
	s_cmp_gt_u32 s47, 52                                       // 0000001E46A0: BF08B42F
	v_dual_cndmask_b32 v10, v175, v9 :: v_dual_cndmask_b32 v9, v174, v0// 0000001E46A4: CA5213AF 0A0801AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E46AC: 986A80C1
	s_cmp_gt_u32 s47, 51                                       // 0000001E46B0: BF08B32F
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001E46B4: CA5219AF 0C0A17AE
	.long 0xd7006a00                                           // 0000001E46BC: D7006A00
	v_cndmask_b32_e32 v1, 0x132000, v2, vcc_lo                 // 0000001E46C0: 020204FF 00132000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E46C8: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v6, vcc_lo               // 0000001E46CC: D5207C0D 01AA0C80
	.long 0xd7006a0f                                           // 0000001E46D4: D7006A0F
	v_cndmask_b32_e32 v1, 0x12c000, v2, vcc_lo                 // 0000001E46D8: 020204FF 0012C000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001E46E0: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E46E8: 986A80C1
	s_cmp_gt_u32 s47, 50                                       // 0000001E46EC: BF08B22F
	v_dual_cndmask_b32 v14, v175, v13 :: v_dual_cndmask_b32 v13, v174, v0// 0000001E46F0: CA521BAF 0E0C01AE
	global_load_b32 v186, v[7:8], off                          // 0000001E46F8: DC520000 BA7C0007
	global_load_b32 v255, v[9:10], off                         // 0000001E4700: DC520000 FF7C0009
	global_load_b32 v254, v[11:12], off                        // 0000001E4708: DC520000 FE7C000B
	global_load_b32 v0, v[13:14], off                          // 0000001E4710: DC520000 007C000D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4718: 986A80C1
	s_cmp_gt_u32 s47, 49                                       // 0000001E471C: BF08B12F
	v_dual_cndmask_b32 v16, v175, v16 :: v_dual_cndmask_b32 v15, v174, v15// 0000001E4720: CA5221AF 100E1FAE
	global_load_b32 v220, v[15:16], off                        // 0000001E4728: DC520000 DC7C000F
	s_waitcnt vmcnt(1)                                         // 0000001E4730: BF8907F7
	scratch_store_b32 off, v0, off offset:44                   // 0000001E4734: DC69002C 007C0000
	.long 0xd7006a00                                           // 0000001E473C: D7006A00
	v_cndmask_b32_e32 v1, 0x126000, v2, vcc_lo                 // 0000001E4740: 020204FF 00126000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E4748: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v6, vcc_lo                // 0000001E474C: D5207C07 01AA0C80
	.long 0xd7006a09                                           // 0000001E4754: D7006A09
	v_cndmask_b32_e32 v1, 0x120000, v2, vcc_lo                 // 0000001E4758: 020204FF 00120000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001E4760: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4768: 986A80C1
	s_cmp_gt_u32 s47, 48                                       // 0000001E476C: BF08B02F
	v_dual_cndmask_b32 v8, v175, v7 :: v_dual_cndmask_b32 v7, v174, v0// 0000001E4770: CA520FAF 080601AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4778: 986A80C1
	s_cmp_gt_u32 s47, 47                                       // 0000001E477C: BF08AF2F
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001E4780: CA5215AF 0A0813AE
	.long 0xd7006a00                                           // 0000001E4788: D7006A00
	v_cndmask_b32_e32 v1, 0x11a000, v2, vcc_lo                 // 0000001E478C: 020204FF 0011A000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E4794: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v6, vcc_lo               // 0000001E4798: D5207C0B 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E47A0: 986A80C1
	global_load_b32 v219, v[7:8], off                          // 0000001E47A4: DC520000 DB7C0007
	s_cmp_gt_u32 s47, 46                                       // 0000001E47AC: BF08AE2F
	v_cndmask_b32_e32 v8, v175, v11, vcc_lo                    // 0000001E47B0: 021017AF
	global_load_b32 v7, v[9:10], off                           // 0000001E47B4: DC520000 077C0009
	s_waitcnt vmcnt(0)                                         // 0000001E47BC: BF8903F7
	scratch_store_b32 off, v7, off offset:40                   // 0000001E47C0: DC690028 007C0700
	v_cndmask_b32_e32 v7, v174, v0, vcc_lo                     // 0000001E47C8: 020E01AE
	.long 0xd7006a00                                           // 0000001E47CC: D7006A00
	v_cndmask_b32_e32 v1, 0x114000, v2, vcc_lo                 // 0000001E47D0: 020204FF 00114000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E47D8: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v6, vcc_lo                // 0000001E47DC: D5207C09 01AA0C80
	.long 0xd7006a0b                                           // 0000001E47E4: D7006A0B
	v_cndmask_b32_e32 v1, 0x10e000, v2, vcc_lo                 // 0000001E47E8: 020204FF 0010E000
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001E47F0: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E47F8: 986A80C1
	s_cmp_gt_u32 s47, 45                                       // 0000001E47FC: BF08AD2F
	v_dual_cndmask_b32 v10, v175, v9 :: v_dual_cndmask_b32 v9, v174, v0// 0000001E4800: CA5213AF 0A0801AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4808: 986A80C1
	s_cmp_gt_u32 s47, 44                                       // 0000001E480C: BF08AC2F
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001E4810: CA5219AF 0C0A17AE
	.long 0xd7006a00                                           // 0000001E4818: D7006A00
	v_cndmask_b32_e32 v1, 0x108000, v2, vcc_lo                 // 0000001E481C: 020204FF 00108000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E4824: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v6, vcc_lo               // 0000001E4828: D5207C0D 01AA0C80
	.long 0xd7006a0f                                           // 0000001E4830: D7006A0F
	v_cndmask_b32_e32 v1, 0x102000, v2, vcc_lo                 // 0000001E4834: 020204FF 00102000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001E483C: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4844: 986A80C1
	s_cmp_gt_u32 s47, 43                                       // 0000001E4848: BF08AB2F
	v_dual_cndmask_b32 v14, v175, v13 :: v_dual_cndmask_b32 v13, v174, v0// 0000001E484C: CA521BAF 0E0C01AE
	global_load_b32 v253, v[7:8], off                          // 0000001E4854: DC520000 FD7C0007
	global_load_b32 v252, v[9:10], off                         // 0000001E485C: DC520000 FC7C0009
	global_load_b32 v251, v[11:12], off                        // 0000001E4864: DC520000 FB7C000B
	global_load_b32 v0, v[13:14], off                          // 0000001E486C: DC520000 007C000D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4874: 986A80C1
	s_cmp_gt_u32 s47, 42                                       // 0000001E4878: BF08AA2F
	v_dual_cndmask_b32 v16, v175, v16 :: v_dual_cndmask_b32 v15, v174, v15// 0000001E487C: CA5221AF 100E1FAE
	global_load_b32 v218, v[15:16], off                        // 0000001E4884: DC520000 DA7C000F
	s_waitcnt vmcnt(1)                                         // 0000001E488C: BF8907F7
	scratch_store_b32 off, v0, off offset:36                   // 0000001E4890: DC690024 007C0000
	.long 0xd7006a00                                           // 0000001E4898: D7006A00
	v_cndmask_b32_e32 v1, 0xfc000, v2, vcc_lo                  // 0000001E489C: 020204FF 000FC000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E48A4: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v6, vcc_lo                // 0000001E48A8: D5207C07 01AA0C80
	.long 0xd7006a09                                           // 0000001E48B0: D7006A09
	v_cndmask_b32_e32 v1, 0xf6000, v2, vcc_lo                  // 0000001E48B4: 020204FF 000F6000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001E48BC: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E48C4: 986A80C1
	s_cmp_gt_u32 s47, 41                                       // 0000001E48C8: BF08A92F
	v_dual_cndmask_b32 v8, v175, v7 :: v_dual_cndmask_b32 v7, v174, v0// 0000001E48CC: CA520FAF 080601AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E48D4: 986A80C1
	s_cmp_gt_u32 s47, 40                                       // 0000001E48D8: BF08A82F
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001E48DC: CA5215AF 0A0813AE
	.long 0xd7006a00                                           // 0000001E48E4: D7006A00
	v_cndmask_b32_e32 v1, 0xf0000, v2, vcc_lo                  // 0000001E48E8: 020204FF 000F0000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E48F0: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v6, vcc_lo               // 0000001E48F4: D5207C0B 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E48FC: 986A80C1
	global_load_b32 v217, v[7:8], off                          // 0000001E4900: DC520000 D97C0007
	s_cmp_gt_u32 s47, 39                                       // 0000001E4908: BF08A72F
	v_cndmask_b32_e32 v8, v175, v11, vcc_lo                    // 0000001E490C: 021017AF
	global_load_b32 v7, v[9:10], off                           // 0000001E4910: DC520000 077C0009
	s_waitcnt vmcnt(0)                                         // 0000001E4918: BF8903F7
	scratch_store_b32 off, v7, off offset:32                   // 0000001E491C: DC690020 007C0700
	v_cndmask_b32_e32 v7, v174, v0, vcc_lo                     // 0000001E4924: 020E01AE
	.long 0xd7006a00                                           // 0000001E4928: D7006A00
	v_cndmask_b32_e32 v1, 0xea000, v2, vcc_lo                  // 0000001E492C: 020204FF 000EA000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E4934: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v6, vcc_lo                // 0000001E4938: D5207C09 01AA0C80
	.long 0xd7006a0b                                           // 0000001E4940: D7006A0B
	v_cndmask_b32_e32 v1, 0xe4000, v2, vcc_lo                  // 0000001E4944: 020204FF 000E4000
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001E494C: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4954: 986A80C1
	s_cmp_gt_u32 s47, 38                                       // 0000001E4958: BF08A62F
	v_dual_cndmask_b32 v10, v175, v9 :: v_dual_cndmask_b32 v9, v174, v0// 0000001E495C: CA5213AF 0A0801AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4964: 986A80C1
	s_cmp_gt_u32 s47, 37                                       // 0000001E4968: BF08A52F
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001E496C: CA5219AF 0C0A17AE
	.long 0xd7006a00                                           // 0000001E4974: D7006A00
	v_cndmask_b32_e32 v1, 0xde000, v2, vcc_lo                  // 0000001E4978: 020204FF 000DE000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E4980: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v6, vcc_lo               // 0000001E4984: D5207C0D 01AA0C80
	.long 0xd7006a0f                                           // 0000001E498C: D7006A0F
	v_cndmask_b32_e32 v1, 0xd8000, v2, vcc_lo                  // 0000001E4990: 020204FF 000D8000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001E4998: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E49A0: 986A80C1
	s_cmp_gt_u32 s47, 36                                       // 0000001E49A4: BF08A42F
	v_dual_cndmask_b32 v14, v175, v13 :: v_dual_cndmask_b32 v13, v174, v0// 0000001E49A8: CA521BAF 0E0C01AE
	global_load_b32 v250, v[7:8], off                          // 0000001E49B0: DC520000 FA7C0007
	global_load_b32 v249, v[9:10], off                         // 0000001E49B8: DC520000 F97C0009
	global_load_b32 v248, v[11:12], off                        // 0000001E49C0: DC520000 F87C000B
	global_load_b32 v0, v[13:14], off                          // 0000001E49C8: DC520000 007C000D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E49D0: 986A80C1
	s_cmp_gt_u32 s47, 35                                       // 0000001E49D4: BF08A32F
	v_dual_cndmask_b32 v16, v175, v16 :: v_dual_cndmask_b32 v15, v174, v15// 0000001E49D8: CA5221AF 100E1FAE
	global_load_b32 v216, v[15:16], off                        // 0000001E49E0: DC520000 D87C000F
	s_waitcnt vmcnt(1)                                         // 0000001E49E8: BF8907F7
	scratch_store_b32 off, v0, off offset:28                   // 0000001E49EC: DC69001C 007C0000
	.long 0xd7006a00                                           // 0000001E49F4: D7006A00
	v_cndmask_b32_e32 v1, 0xd2000, v2, vcc_lo                  // 0000001E49F8: 020204FF 000D2000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E4A00: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v6, vcc_lo                // 0000001E4A04: D5207C07 01AA0C80
	.long 0xd7006a09                                           // 0000001E4A0C: D7006A09
	v_cndmask_b32_e32 v1, 0xcc000, v2, vcc_lo                  // 0000001E4A10: 020204FF 000CC000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001E4A18: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4A20: 986A80C1
	s_cmp_gt_u32 s47, 34                                       // 0000001E4A24: BF08A22F
	v_dual_cndmask_b32 v8, v175, v7 :: v_dual_cndmask_b32 v7, v174, v0// 0000001E4A28: CA520FAF 080601AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4A30: 986A80C1
	s_cmp_gt_u32 s47, 33                                       // 0000001E4A34: BF08A12F
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001E4A38: CA5215AF 0A0813AE
	.long 0xd7006a00                                           // 0000001E4A40: D7006A00
	v_cndmask_b32_e32 v1, 0xc6000, v2, vcc_lo                  // 0000001E4A44: 020204FF 000C6000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E4A4C: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v6, vcc_lo               // 0000001E4A50: D5207C0B 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4A58: 986A80C1
	global_load_b32 v215, v[7:8], off                          // 0000001E4A5C: DC520000 D77C0007
	v_dual_cndmask_b32 v7, v174, v0 :: v_dual_cndmask_b32 v8, v175, v11// 0000001E4A64: CA5201AE 070817AF
	.long 0xd7006a00                                           // 0000001E4A6C: D7006A00
	v_cndmask_b32_e32 v1, 0xc0000, v2, vcc_lo                  // 0000001E4A70: 020204FF 000C0000
	global_load_b32 v184, v[9:10], off                         // 0000001E4A78: DC520000 B87C0009
	v_add_co_ci_u32_e64 v9, null, 0, v6, vcc_lo                // 0000001E4A80: D5207C09 01AA0C80
	.long 0xd7006a0b                                           // 0000001E4A88: D7006A0B
	v_cndmask_b32_e32 v1, 0xba000, v2, vcc_lo                  // 0000001E4A8C: 020204FF 000BA000
	s_cmp_gt_u32 s47, 32                                       // 0000001E4A94: BF08A02F
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001E4A98: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4AA0: 986A80C1
	s_cmp_gt_u32 s47, 31                                       // 0000001E4AA4: BF089F2F
	v_dual_cndmask_b32 v10, v175, v9 :: v_dual_cndmask_b32 v9, v174, v0// 0000001E4AA8: CA5213AF 0A0801AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4AB0: 986A80C1
	s_cmp_gt_u32 s47, 30                                       // 0000001E4AB4: BF089E2F
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001E4AB8: CA5219AF 0C0A17AE
	.long 0xd7006a00                                           // 0000001E4AC0: D7006A00
	v_cndmask_b32_e32 v1, 0xb4000, v2, vcc_lo                  // 0000001E4AC4: 020204FF 000B4000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E4ACC: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v6, vcc_lo               // 0000001E4AD0: D5207C0D 01AA0C80
	.long 0xd7006a0f                                           // 0000001E4AD8: D7006A0F
	v_cndmask_b32_e32 v1, 0xae000, v2, vcc_lo                  // 0000001E4ADC: 020204FF 000AE000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001E4AE4: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4AEC: 986A80C1
	s_cmp_gt_u32 s47, 29                                       // 0000001E4AF0: BF089D2F
	v_dual_cndmask_b32 v14, v175, v13 :: v_dual_cndmask_b32 v13, v174, v0// 0000001E4AF4: CA521BAF 0E0C01AE
	global_load_b32 v247, v[7:8], off                          // 0000001E4AFC: DC520000 F77C0007
	global_load_b32 v246, v[9:10], off                         // 0000001E4B04: DC520000 F67C0009
	global_load_b32 v245, v[11:12], off                        // 0000001E4B0C: DC520000 F57C000B
	global_load_b32 v0, v[13:14], off                          // 0000001E4B14: DC520000 007C000D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4B1C: 986A80C1
	s_cmp_gt_u32 s47, 28                                       // 0000001E4B20: BF089C2F
	v_dual_cndmask_b32 v16, v175, v16 :: v_dual_cndmask_b32 v15, v174, v15// 0000001E4B24: CA5221AF 100E1FAE
	global_load_b32 v214, v[15:16], off                        // 0000001E4B2C: DC520000 D67C000F
	s_waitcnt vmcnt(1)                                         // 0000001E4B34: BF8907F7
	scratch_store_b32 off, v0, off offset:24                   // 0000001E4B38: DC690018 007C0000
	.long 0xd7006a00                                           // 0000001E4B40: D7006A00
	v_cndmask_b32_e32 v1, 0xa8000, v2, vcc_lo                  // 0000001E4B44: 020204FF 000A8000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E4B4C: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v6, vcc_lo                // 0000001E4B50: D5207C07 01AA0C80
	.long 0xd7006a09                                           // 0000001E4B58: D7006A09
	v_cndmask_b32_e32 v1, 0xa2000, v2, vcc_lo                  // 0000001E4B5C: 020204FF 000A2000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001E4B64: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4B6C: 986A80C1
	s_cmp_gt_u32 s47, 27                                       // 0000001E4B70: BF089B2F
	v_dual_cndmask_b32 v8, v175, v7 :: v_dual_cndmask_b32 v7, v174, v0// 0000001E4B74: CA520FAF 080601AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4B7C: 986A80C1
	s_cmp_gt_u32 s47, 26                                       // 0000001E4B80: BF089A2F
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001E4B84: CA5215AF 0A0813AE
	.long 0xd7006a00                                           // 0000001E4B8C: D7006A00
	v_cndmask_b32_e32 v1, 0x9c000, v2, vcc_lo                  // 0000001E4B90: 020204FF 0009C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E4B98: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v6, vcc_lo               // 0000001E4B9C: D5207C0B 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4BA4: 986A80C1
	global_load_b32 v213, v[7:8], off                          // 0000001E4BA8: DC520000 D57C0007
	s_cmp_gt_u32 s47, 25                                       // 0000001E4BB0: BF08992F
	v_cndmask_b32_e32 v8, v175, v11, vcc_lo                    // 0000001E4BB4: 021017AF
	global_load_b32 v7, v[9:10], off                           // 0000001E4BB8: DC520000 077C0009
	s_waitcnt vmcnt(0)                                         // 0000001E4BC0: BF8903F7
	scratch_store_b32 off, v7, off offset:20                   // 0000001E4BC4: DC690014 007C0700
	v_cndmask_b32_e32 v7, v174, v0, vcc_lo                     // 0000001E4BCC: 020E01AE
	.long 0xd7006a00                                           // 0000001E4BD0: D7006A00
	v_cndmask_b32_e32 v1, 0x96000, v2, vcc_lo                  // 0000001E4BD4: 020204FF 00096000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E4BDC: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v6, vcc_lo                // 0000001E4BE0: D5207C09 01AA0C80
	.long 0xd7006a0b                                           // 0000001E4BE8: D7006A0B
	v_cndmask_b32_e32 v1, 0x90000, v2, vcc_lo                  // 0000001E4BEC: 020204FF 00090000
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001E4BF4: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4BFC: 986A80C1
	s_cmp_gt_u32 s47, 24                                       // 0000001E4C00: BF08982F
	v_dual_cndmask_b32 v10, v175, v9 :: v_dual_cndmask_b32 v9, v174, v0// 0000001E4C04: CA5213AF 0A0801AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4C0C: 986A80C1
	s_cmp_gt_u32 s47, 23                                       // 0000001E4C10: BF08972F
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001E4C14: CA5219AF 0C0A17AE
	.long 0xd7006a00                                           // 0000001E4C1C: D7006A00
	v_cndmask_b32_e32 v1, 0x8a000, v2, vcc_lo                  // 0000001E4C20: 020204FF 0008A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E4C28: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v6, vcc_lo               // 0000001E4C2C: D5207C0D 01AA0C80
	.long 0xd7006a0f                                           // 0000001E4C34: D7006A0F
	v_cndmask_b32_e32 v1, 0x84000, v2, vcc_lo                  // 0000001E4C38: 020204FF 00084000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001E4C40: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4C48: 986A80C1
	s_cmp_gt_u32 s47, 22                                       // 0000001E4C4C: BF08962F
	v_dual_cndmask_b32 v14, v175, v13 :: v_dual_cndmask_b32 v13, v174, v0// 0000001E4C50: CA521BAF 0E0C01AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4C58: 986A80C1
	s_cmp_gt_u32 s47, 21                                       // 0000001E4C5C: BF08952F
	v_dual_cndmask_b32 v16, v175, v16 :: v_dual_cndmask_b32 v15, v174, v15// 0000001E4C60: CA5221AF 100E1FAE
	.long 0xd7006a00                                           // 0000001E4C68: D7006A00
	v_cndmask_b32_e32 v1, 0x7e000, v2, vcc_lo                  // 0000001E4C6C: 020204FF 0007E000
	global_load_b32 v244, v[7:8], off                          // 0000001E4C74: DC520000 F47C0007
	global_load_b32 v243, v[9:10], off                         // 0000001E4C7C: DC520000 F37C0009
	global_load_b32 v242, v[11:12], off                        // 0000001E4C84: DC520000 F27C000B
	global_load_b32 v173, v[13:14], off                        // 0000001E4C8C: DC520000 AD7C000D
	global_load_b32 v212, v[15:16], off                        // 0000001E4C94: DC520000 D47C000F
	v_add_co_ci_u32_e64 v7, null, 0, v6, vcc_lo                // 0000001E4C9C: D5207C07 01AA0C80
	.long 0xd7006a09                                           // 0000001E4CA4: D7006A09
	v_cndmask_b32_e32 v1, 0x78000, v2, vcc_lo                  // 0000001E4CA8: 020204FF 00078000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E4CB0: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001E4CB4: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4CBC: 986A80C1
	s_cmp_gt_u32 s47, 20                                       // 0000001E4CC0: BF08942F
	v_dual_cndmask_b32 v8, v175, v7 :: v_dual_cndmask_b32 v7, v174, v0// 0000001E4CC4: CA520FAF 080601AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4CCC: 986A80C1
	s_cmp_gt_u32 s47, 19                                       // 0000001E4CD0: BF08932F
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001E4CD4: CA5215AF 0A0813AE
	.long 0xd7006a00                                           // 0000001E4CDC: D7006A00
	v_cndmask_b32_e32 v1, 0x72000, v2, vcc_lo                  // 0000001E4CE0: 020204FF 00072000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E4CE8: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v6, vcc_lo               // 0000001E4CEC: D5207C0B 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4CF4: 986A80C1
	global_load_b32 v211, v[7:8], off                          // 0000001E4CF8: DC520000 D37C0007
	v_dual_cndmask_b32 v7, v174, v0 :: v_dual_cndmask_b32 v8, v175, v11// 0000001E4D00: CA5201AE 070817AF
	.long 0xd7006a00                                           // 0000001E4D08: D7006A00
	v_cndmask_b32_e32 v1, 0x6c000, v2, vcc_lo                  // 0000001E4D0C: 020204FF 0006C000
	global_load_b32 v181, v[9:10], off                         // 0000001E4D14: DC520000 B57C0009
	v_add_co_ci_u32_e64 v9, null, 0, v6, vcc_lo                // 0000001E4D1C: D5207C09 01AA0C80
	.long 0xd7006a0b                                           // 0000001E4D24: D7006A0B
	v_cndmask_b32_e32 v1, 0x66000, v2, vcc_lo                  // 0000001E4D28: 020204FF 00066000
	s_cmp_gt_u32 s47, 18                                       // 0000001E4D30: BF08922F
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001E4D34: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4D3C: 986A80C1
	s_cmp_gt_u32 s47, 17                                       // 0000001E4D40: BF08912F
	v_dual_cndmask_b32 v10, v175, v9 :: v_dual_cndmask_b32 v9, v174, v0// 0000001E4D44: CA5213AF 0A0801AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4D4C: 986A80C1
	s_cmp_gt_u32 s47, 16                                       // 0000001E4D50: BF08902F
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001E4D54: CA5219AF 0C0A17AE
	.long 0xd7006a00                                           // 0000001E4D5C: D7006A00
	v_cndmask_b32_e32 v1, 0x60000, v2, vcc_lo                  // 0000001E4D60: 020204FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E4D68: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v6, vcc_lo               // 0000001E4D6C: D5207C0D 01AA0C80
	.long 0xd7006a0f                                           // 0000001E4D74: D7006A0F
	v_cndmask_b32_e32 v1, 0x5a000, v2, vcc_lo                  // 0000001E4D78: 020204FF 0005A000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001E4D80: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4D88: 986A80C1
	s_cmp_gt_u32 s47, 15                                       // 0000001E4D8C: BF088F2F
	v_dual_cndmask_b32 v14, v175, v13 :: v_dual_cndmask_b32 v13, v174, v0// 0000001E4D90: CA521BAF 0E0C01AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4D98: 986A80C1
	s_cmp_gt_u32 s47, 14                                       // 0000001E4D9C: BF088E2F
	v_dual_cndmask_b32 v16, v175, v16 :: v_dual_cndmask_b32 v15, v174, v15// 0000001E4DA0: CA5221AF 100E1FAE
	.long 0xd7006a00                                           // 0000001E4DA8: D7006A00
	v_cndmask_b32_e32 v1, 0x54000, v2, vcc_lo                  // 0000001E4DAC: 020204FF 00054000
	global_load_b32 v241, v[7:8], off                          // 0000001E4DB4: DC520000 F17C0007
	global_load_b32 v240, v[9:10], off                         // 0000001E4DBC: DC520000 F07C0009
	global_load_b32 v239, v[11:12], off                        // 0000001E4DC4: DC520000 EF7C000B
	global_load_b32 v228, v[13:14], off                        // 0000001E4DCC: DC520000 E47C000D
	global_load_b32 v171, v[15:16], off                        // 0000001E4DD4: DC520000 AB7C000F
	v_add_co_ci_u32_e64 v7, null, 0, v6, vcc_lo                // 0000001E4DDC: D5207C07 01AA0C80
	.long 0xd7006a09                                           // 0000001E4DE4: D7006A09
	v_cndmask_b32_e32 v1, 0x4e000, v2, vcc_lo                  // 0000001E4DE8: 020204FF 0004E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E4DF0: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001E4DF4: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4DFC: 986A80C1
	s_cmp_gt_u32 s47, 13                                       // 0000001E4E00: BF088D2F
	v_dual_cndmask_b32 v8, v175, v7 :: v_dual_cndmask_b32 v7, v174, v0// 0000001E4E04: CA520FAF 080601AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4E0C: 986A80C1
	s_cmp_gt_u32 s47, 12                                       // 0000001E4E10: BF088C2F
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001E4E14: CA5215AF 0A0813AE
	.long 0xd7006a00                                           // 0000001E4E1C: D7006A00
	v_cndmask_b32_e32 v1, 0x48000, v2, vcc_lo                  // 0000001E4E20: 020204FF 00048000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E4E28: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v6, vcc_lo               // 0000001E4E2C: D5207C0B 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4E34: 986A80C1
	global_load_b32 v170, v[7:8], off                          // 0000001E4E38: DC520000 AA7C0007
	v_dual_cndmask_b32 v7, v174, v0 :: v_dual_cndmask_b32 v8, v175, v11// 0000001E4E40: CA5201AE 070817AF
	.long 0xd7006a00                                           // 0000001E4E48: D7006A00
	v_cndmask_b32_e32 v1, 0x42000, v2, vcc_lo                  // 0000001E4E4C: 020204FF 00042000
	global_load_b32 v227, v[9:10], off                         // 0000001E4E54: DC520000 E37C0009
	v_add_co_ci_u32_e64 v9, null, 0, v6, vcc_lo                // 0000001E4E5C: D5207C09 01AA0C80
	.long 0xd7006a0b                                           // 0000001E4E64: D7006A0B
	v_cndmask_b32_e32 v1, 0x3c000, v2, vcc_lo                  // 0000001E4E68: 020204FF 0003C000
	s_cmp_gt_u32 s47, 11                                       // 0000001E4E70: BF088B2F
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001E4E74: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4E7C: 986A80C1
	s_cmp_gt_u32 s47, 10                                       // 0000001E4E80: BF088A2F
	v_dual_cndmask_b32 v10, v175, v9 :: v_dual_cndmask_b32 v9, v174, v0// 0000001E4E84: CA5213AF 0A0801AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4E8C: 986A80C1
	s_cmp_gt_u32 s47, 9                                        // 0000001E4E90: BF08892F
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001E4E94: CA5219AF 0C0A17AE
	.long 0xd7006a00                                           // 0000001E4E9C: D7006A00
	v_cndmask_b32_e32 v1, 0x36000, v2, vcc_lo                  // 0000001E4EA0: 020204FF 00036000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E4EA8: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v6, vcc_lo               // 0000001E4EAC: D5207C0D 01AA0C80
	.long 0xd7006a0f                                           // 0000001E4EB4: D7006A0F
	v_cndmask_b32_e32 v1, 0x30000, v2, vcc_lo                  // 0000001E4EB8: 020204FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v6, vcc_lo               // 0000001E4EC0: D5207C10 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4EC8: 986A80C1
	s_cmp_gt_u32 s47, 8                                        // 0000001E4ECC: BF08882F
	v_dual_cndmask_b32 v14, v175, v13 :: v_dual_cndmask_b32 v13, v174, v0// 0000001E4ED0: CA521BAF 0E0C01AE
	global_load_b32 v238, v[7:8], off                          // 0000001E4ED8: DC520000 EE7C0007
	global_load_b32 v237, v[9:10], off                         // 0000001E4EE0: DC520000 ED7C0009
	global_load_b32 v236, v[11:12], off                        // 0000001E4EE8: DC520000 EC7C000B
	global_load_b32 v0, v[13:14], off                          // 0000001E4EF0: DC520000 007C000D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4EF8: 986A80C1
	s_cmp_gt_u32 s47, 7                                        // 0000001E4EFC: BF08872F
	v_dual_cndmask_b32 v16, v175, v16 :: v_dual_cndmask_b32 v15, v174, v15// 0000001E4F00: CA5221AF 100E1FAE
	global_load_b32 v169, v[15:16], off                        // 0000001E4F08: DC520000 A97C000F
	s_waitcnt vmcnt(1)                                         // 0000001E4F10: BF8907F7
	scratch_store_b32 off, v0, off offset:16                   // 0000001E4F14: DC690010 007C0000
	.long 0xd7006a00                                           // 0000001E4F1C: D7006A00
	v_cndmask_b32_e32 v1, 0x2a000, v2, vcc_lo                  // 0000001E4F20: 020204FF 0002A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E4F28: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v6, vcc_lo                // 0000001E4F2C: D5207C07 01AA0C80
	.long 0xd7006a09                                           // 0000001E4F34: D7006A09
	v_cndmask_b32_e32 v1, 0x24000, v2, vcc_lo                  // 0000001E4F38: 020204FF 00024000
	v_add_co_ci_u32_e64 v10, null, 0, v6, vcc_lo               // 0000001E4F40: D5207C0A 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4F48: 986A80C1
	s_cmp_gt_u32 s47, 6                                        // 0000001E4F4C: BF08862F
	v_dual_cndmask_b32 v8, v175, v7 :: v_dual_cndmask_b32 v7, v174, v0// 0000001E4F50: CA520FAF 080601AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4F58: 986A80C1
	s_cmp_gt_u32 s47, 5                                        // 0000001E4F5C: BF08852F
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001E4F60: CA5215AF 0A0813AE
	.long 0xd7006a00                                           // 0000001E4F68: D7006A00
	v_cndmask_b32_e32 v1, 0x1e000, v2, vcc_lo                  // 0000001E4F6C: 020204FF 0001E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E4F74: BF870001
	v_add_co_ci_u32_e64 v11, null, 0, v6, vcc_lo               // 0000001E4F78: D5207C0B 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4F80: 986A80C1
	global_load_b32 v168, v[7:8], off                          // 0000001E4F84: DC520000 A87C0007
	s_cmp_gt_u32 s47, 4                                        // 0000001E4F8C: BF08842F
	v_cndmask_b32_e32 v8, v175, v11, vcc_lo                    // 0000001E4F90: 021017AF
	global_load_b32 v7, v[9:10], off                           // 0000001E4F94: DC520000 077C0009
	s_waitcnt vmcnt(0)                                         // 0000001E4F9C: BF8903F7
	scratch_store_b32 off, v7, off offset:12                   // 0000001E4FA0: DC69000C 007C0700
	v_cndmask_b32_e32 v7, v174, v0, vcc_lo                     // 0000001E4FA8: 020E01AE
	.long 0xd7006a00                                           // 0000001E4FAC: D7006A00
	v_cndmask_b32_e32 v1, 0x18000, v2, vcc_lo                  // 0000001E4FB0: 020204FF 00018000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E4FB8: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v6, vcc_lo                // 0000001E4FBC: D5207C09 01AA0C80
	.long 0xd7006a0b                                           // 0000001E4FC4: D7006A0B
	v_cndmask_b32_e32 v1, 0x12000, v2, vcc_lo                  // 0000001E4FC8: 020204FF 00012000
	v_add_co_ci_u32_e64 v12, null, 0, v6, vcc_lo               // 0000001E4FD0: D5207C0C 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4FD8: 986A80C1
	s_cmp_gt_u32 s47, 3                                        // 0000001E4FDC: BF08832F
	v_dual_cndmask_b32 v10, v175, v9 :: v_dual_cndmask_b32 v9, v174, v0// 0000001E4FE0: CA5213AF 0A0801AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E4FE8: 986A80C1
	s_cmp_gt_u32 s47, 2                                        // 0000001E4FEC: BF08822F
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001E4FF0: CA5219AF 0C0A17AE
	.long 0xd7006a00                                           // 0000001E4FF8: D7006A00
	v_cndmask_b32_e32 v1, 0xc000, v2, vcc_lo                   // 0000001E4FFC: 020204FF 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E5004: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v6, vcc_lo               // 0000001E5008: D5207C0D 01AA0C80
	.long 0xd7006a02                                           // 0000001E5010: D7006A02
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 0000001E5014: 020204FF 00006000
	v_add_co_ci_u32_e64 v6, null, 0, v6, vcc_lo                // 0000001E501C: D5207C06 01AA0C80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E5024: 986A80C1
	s_cmp_eq_u32 s47, 1                                        // 0000001E5028: BF06812F
	v_dual_cndmask_b32 v14, v175, v13 :: v_dual_cndmask_b32 v13, v174, v0// 0000001E502C: CA521BAF 0E0C01AE
	global_load_b32 v235, v[7:8], off                          // 0000001E5034: DC520000 EB7C0007
	global_load_b32 v234, v[9:10], off                         // 0000001E503C: DC520000 EA7C0009
	global_load_b32 v233, v[11:12], off                        // 0000001E5044: DC520000 E97C000B
	global_load_b32 v0, v[13:14], off                          // 0000001E504C: DC520000 007C000D
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E5054: 986A80C1
	v_dual_cndmask_b32 v16, v6, v175 :: v_dual_and_b32 v7, 15, v17// 0000001E5058: CA655F06 1006228F
	v_cndmask_b32_e32 v15, v2, v174, vcc_lo                    // 0000001E5060: 021F5D02
	v_or_b32_e32 v8, 0xf000, v1                                // 0000001E5064: 381002FF 0000F000
	s_add_i32 s50, s2, 0xbd0                                   // 0000001E506C: 8132FF02 00000BD0
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001E5074: BF870003
	v_mad_u32_u24 v185, 0x90, v7, s21                          // 0000001E5078: D60B00B9 00560EFF 00000090
	v_mul_u32_u24_e32 v183, 0x210, v7                          // 0000001E5084: 176E0EFF 00000210
	scratch_store_b32 off, v8, off offset:88                   // 0000001E508C: DC690058 007C0800
	s_waitcnt vmcnt(0)                                         // 0000001E5094: BF8903F7
	scratch_store_b32 off, v0, off offset:8                    // 0000001E5098: DC690008 007C0000
	global_load_b32 v0, v[15:16], off                          // 0000001E50A0: DC520000 007C000F
	global_load_b32 v2, v1, s[4:5]                             // 0000001E50A8: DC520000 02040001
	.long 0xd4490005                                           // 0000001E50B0: D4490005
	v_cndmask_b32_e32 v1, 63, v17, vcc_lo                      // 0000001E50B4: 020222BF
	s_waitcnt vmcnt(0)                                         // 0000001E50B8: BF8903F7
	scratch_store_b32 off, v2, off offset:4                    // 0000001E50BC: DC690004 007C0200
	.long 0xd7000402                                           // 0000001E50C4: D7000402
	v_cndmask_b32_e32 v1, s12, v1, vcc_lo                      // 0000001E50C8: 0202020C
	v_add_nc_u32_e32 v1, 0xf100, v1                            // 0000001E50CC: 4A0202FF 0000F100
	s_movk_i32 s12, 0x90                                       // 0000001E50D4: B00C0090
	scratch_store_b32 off, v2, off offset:80                   // 0000001E50D8: DC690050 007C0200
	v_add_co_ci_u32_e64 v2, null, s13, 0, s4                   // 0000001E50E0: D5207C02 0011000D
	scratch_store_b32 off, v1, off offset:92                   // 0000001E50E8: DC69005C 007C0100
	s_add_u32 s13, s8, s44                                     // 0000001E50F0: 800D2C08
	v_bfe_u32 v1, v17, 4, 1                                    // 0000001E50F4: D6100001 02050911
	scratch_store_b32 off, v2, off offset:84                   // 0000001E50FC: DC690054 007C0200
	v_lshrrev_b32_e32 v2, 5, v17                               // 0000001E5104: 32042285
	s_addc_u32 s20, s9, s45                                    // 0000001E5108: 82142D09
	s_lshl_b32 s8, s2, 7                                       // 0000001E510C: 84088702
	.long 0xd44c0004                                           // 0000001E5110: D44C0004
	v_cndmask_b32_e32 v1, 64, v17, vcc_lo                      // 0000001E5114: 020222C0
	s_ashr_i32 s9, s8, 31                                      // 0000001E5118: 86099F08
	v_lshlrev_b32_e32 v6, 4, v2                                // 0000001E511C: 300C0484
	v_mul_u32_u24_e32 v8, 0x2100, v2                           // 0000001E5120: 161004FF 00002100
	s_lshl_b64 s[8:9], s[8:9], 1                               // 0000001E5128: 84888108
	v_mad_u32_u24 v224, 0x900, v2, v185                        // 0000001E512C: D60B00E0 06E604FF 00000900
	s_add_u32 s8, s22, s8                                      // 0000001E5138: 80080816
	v_or_b32_e32 v9, v6, v7                                    // 0000001E513C: 38120F06
	v_or_b32_e32 v10, v6, v1                                   // 0000001E5140: 38140306
	v_mad_u32_u24 v6, 0x210, v7, v8                            // 0000001E5144: D60B0006 04220EFF 00000210
	s_addc_u32 s9, s23, s9                                     // 0000001E5150: 82090917
	s_lshl_b64 s[6:7], s[6:7], 1                               // 0000001E5154: 84868106
	v_lshlrev_b32_e32 v8, 7, v9                                // 0000001E5158: 30101287
	s_add_u32 s8, s8, s6                                       // 0000001E515C: 80080608
	v_lshl_or_b32 v226, v1, 2, v6                              // 0000001E5160: D65600E2 04190501
	v_lshlrev_b32_e32 v1, 2, v7                                // 0000001E5168: 30020E82
	s_clause 0x1                                               // 0000001E516C: BF850001
	scratch_store_b32 off, v9, off offset:60                   // 0000001E5170: DC69003C 007C0900
	scratch_store_b32 off, v10, off offset:64                  // 0000001E5178: DC690040 007C0A00
	s_waitcnt lgkmcnt(0)                                       // 0000001E5180: BF89FC07
	.long 0xd7000606                                           // 0000001E5184: D7000606
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 0000001E5188: 0202100A
	s_addc_u32 s9, s9, s7                                      // 0000001E518C: 82090709
	s_max_i32 s51, s48, 1                                      // 0000001E5190: 8A338130
	v_mad_u32_u24 v182, v17, s12, 0x8400                       // 0000001E5194: D60B00B6 03FC1911 00008400
	scratch_store_b32 off, v6, off offset:68                   // 0000001E51A0: DC690044 007C0600
	v_add_co_ci_u32_e64 v6, null, s11, 0, s6                   // 0000001E51A8: D5207C06 0019000B
	.long 0xd70006e5                                           // 0000001E51B0: D70006E5
	v_cndmask_b32_e32 v1, s13, v1, vcc_lo                      // 0000001E51B4: 0202020D
	v_lshlrev_b32_e32 v1, 1, v7                                // 0000001E51B8: 30020E81
	v_add_co_ci_u32_e64 v230, null, s20, 0, s6                 // 0000001E51BC: D5207CE6 00190014
	.long 0xd44d0006                                           // 0000001E51C4: D44D0006
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 0000001E51C8: 02020480
	scratch_store_b32 off, v6, off offset:72                   // 0000001E51CC: DC690048 007C0600
	.long 0xd70008a4                                           // 0000001E51D4: D70008A4
	v_cndmask_b32_e32 v1, s8, v1, vcc_lo                       // 0000001E51D8: 02020208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001E51DC: BF8700C1
	v_add_co_ci_u32_e64 v165, null, s9, 0, s8                  // 0000001E51E0: D5207CA5 00210009
	s_add_u32 s8, s44, s34                                     // 0000001E51E8: 8008222C
	s_addc_u32 s9, s45, s35                                    // 0000001E51EC: 8209232D
	.long 0xd7000801                                           // 0000001E51F0: D7000801
	v_cndmask_b32_e32 v1, s8, v162, vcc_lo                     // 0000001E51F4: 02034408
	v_add_co_ci_u32_e64 v2, null, s9, 0, s8                    // 0000001E51F8: D5207C02 00210009
	v_mad_u32_u24 v225, v7, s12, 0x8400                        // 0000001E5200: D60B00E1 03FC1907 00008400
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001E520C: BF870093
	.long 0xd7006a01                                           // 0000001E5210: D7006A01
	v_cndmask_b32_e32 v1, v1, v18, vcc_lo                      // 0000001E5214: 02022501
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000001E5218: D5207C02 01AA0480
	v_lshl_add_u32 v231, v10, 1, v185                          // 0000001E5220: D64600E7 06E5030A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001E5228: BF870093
	.long 0xd7006a05                                           // 0000001E522C: D7006A05
	v_cndmask_b32_e32 v1, s40, v1, vcc_lo                      // 0000001E5230: 02020228
	v_add_co_ci_u32_e64 v6, null, s41, v2, vcc_lo              // 0000001E5234: D5207C06 01AA0429
	.long 0xd7006a03                                           // 0000001E523C: D7006A03
	v_cndmask_b32_e32 v1, s42, v1, vcc_lo                      // 0000001E5240: 0202022A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E5244: BF870001
	v_add_co_ci_u32_e64 v4, null, s43, v2, vcc_lo              // 0000001E5248: D5207C04 01AA042B
	.long 0xd7006a01                                           // 0000001E5250: D7006A01
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 0000001E5254: 02020200
	.long 0xd4490007                                           // 0000001E5258: D4490007
	v_cndmask_b32_e32 v1, 0x5f, v17, vcc_lo                    // 0000001E525C: 020222FF 0000005F
	v_lshl_or_b32 v232, v10, 2, 0xf100                         // 0000001E5264: D65600E8 03FD050A 0000F100
	v_add_co_ci_u32_e64 v2, null, s1, v2, vcc_lo               // 0000001E5270: D5207C02 01AA0401
	s_mov_b32 s20, 0                                           // 0000001E5278: BE940080
	s_clause 0x2                                               // 0000001E527C: BF850002
	scratch_store_b64 off, v[5:6], off offset:96               // 0000001E5280: DC6D0060 007C0500
	scratch_store_b64 off, v[3:4], off offset:104              // 0000001E5288: DC6D0068 007C0300
	scratch_store_b64 off, v[1:2], off offset:112              // 0000001E5290: DC6D0070 007C0100
	s_mov_b32 s21, s20                                         // 0000001E5298: BE950014
	s_mov_b32 s22, s20                                         // 0000001E529C: BE960014
	s_mov_b32 s23, s20                                         // 0000001E52A0: BE970014
	s_mov_b32 s24, s20                                         // 0000001E52A4: BE980014
	s_mov_b32 s25, s20                                         // 0000001E52A8: BE990014
	s_mov_b32 s26, s20                                         // 0000001E52AC: BE9A0014
	s_mov_b32 s27, s20                                         // 0000001E52B0: BE9B0014
	s_mov_b32 s40, s20                                         // 0000001E52B4: BEA80014
	s_branch 3                                                 // 0000001E52B8: BFA00003 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x10c8>
	s_cmp_eq_u32 s1, s51                                       // 0000001E52BC: BF063301
	s_mov_b32 s40, s1                                          // 0000001E52C0: BEA80001
	s_cbranch_scc1 7279                                        // 0000001E52C4: BFA21C6F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8284>
	s_mul_i32 s0, s40, 0xc00                                   // 0000001E52C8: 9600FF28 00000C00
	s_lshl_b32 s42, s40, 6                                     // 0000001E52D0: 842A8628
	s_add_i32 s0, s50, s0                                      // 0000001E52D4: 81000032
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001E52D8: BF870499
	s_ashr_i32 s1, s0, 31                                      // 0000001E52DC: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000001E52E0: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001E52E4: BF870009
	s_add_u32 s0, s14, s0                                      // 0000001E52E8: 8000000E
	s_addc_u32 s1, s15, s1                                     // 0000001E52EC: 8201010F
	global_load_b32 v1, v163, s[0:1]                           // 0000001E52F0: DC520000 010000A3
	s_waitcnt vmcnt(0)                                         // 0000001E52F8: BF8903F7
	v_readfirstlane_b32 s41, v1                                // 0000001E52FC: 7E520501
	s_and_saveexec_b32 s0, s4                                  // 0000001E5300: BE802004
	s_cbranch_execz 77                                         // 0000001E5304: BFA5004D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x123c>
	scratch_load_b32 v1, off, off offset:76                    // 0000001E5308: DC51004C 017C0000
	s_waitcnt vmcnt(0)                                         // 0000001E5310: BF8903F7
	v_or_b32_e32 v1, s42, v1                                   // 0000001E5314: 3802022A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001E5318: BF870091
	v_mad_u64_u32 v[1:2], null, v1, 48, s[2:3]                 // 0000001E531C: D6FE7C01 00096101
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000001E5324: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001E5328: BF870091
	.long 0xd73c0001                                           // 0000001E532C: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000001E5330: 02020282
	.long 0xd7006a01                                           // 0000001E5334: D7006A01
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000001E5338: 0202020E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001E533C: BF8700C1
	v_add_co_ci_u32_e64 v2, null, s15, v2, vcc_lo              // 0000001E5340: D5207C02 01AA040F
	global_load_b32 v1, v[1:2], off                            // 0000001E5348: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001E5350: BF8903F7
	v_sub_f32_e32 v2, s41, v1                                  // 0000001E5354: 08040229
	v_dual_mul_f32 v4, 0x3fb8aa3b, v1 :: v_dual_mul_f32 v3, 0x3fb8aa3b, v2// 0000001E5358: C8C602FF 040204FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001E5364: BF8701A1
	v_rndne_f32_e32 v8, v4                                     // 0000001E5368: 7E104704
	v_fma_f32 v7, 0x3fb8aa3b, v1, -v4                          // 0000001E536C: D6130007 841202FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v2, -v3                          // 0000001E5378: D6130005 840E04FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 0000001E5384: 7E0C4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001E5388: BF870191
	v_dual_sub_f32 v4, v4, v8 :: v_dual_sub_f32 v3, v3, v6     // 0000001E538C: C94A1104 04020D03
	v_fmac_f32_e32 v5, 0x32a5705f, v2                          // 0000001E5394: 560A04FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2                   // 0000001E539C: 7C3604FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001E53A4: BF8701B2
	v_add_f32_e32 v3, v3, v5                                   // 0000001E53A8: 06060B03
	v_cvt_i32_f32_e32 v5, v6                                   // 0000001E53AC: 7E0A1106
	v_cvt_i32_f32_e32 v6, v8                                   // 0000001E53B0: 7E0C1108
	v_exp_f32_e32 v3, v3                                       // 0000001E53B4: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001E53B8: BF870095
	.long 0xd71c0003                                           // 0000001E53BC: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000001E53C0: 02020B03
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 0000001E53C4: 02060680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 0000001E53C8: 7C3602FF C2CE8ED0
	v_fmac_f32_e32 v7, 0x32a5705f, v1                          // 0000001E53D0: 560E02FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001E53D8: BF870091
	v_add_f32_e32 v4, v4, v7                                   // 0000001E53DC: 06080F04
	v_exp_f32_e32 v4, v4                                       // 0000001E53E0: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001E53E4: BF870095
	.long 0xd71c0004                                           // 0000001E53E8: D71C0004
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000001E53EC: 02020D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 0000001E53F0: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2                   // 0000001E53F4: 7C3C04FF 42B17218
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo               // 0000001E53FC: 020406FF 7F800000
	scratch_load_b32 v3, off, off offset:88                    // 0000001E5404: DC510058 037C0000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 0000001E540C: 7C3C02FF 42B17218
	v_cndmask_b32_e32 v1, 0x7f800000, v4, vcc_lo               // 0000001E5414: 020208FF 7F800000
	s_waitcnt vmcnt(0)                                         // 0000001E541C: BF8903F7
	ds_store_b32 v3, v2                                        // 0000001E5420: D8340000 00000203
	scratch_load_b32 v2, off, off offset:92                    // 0000001E5428: DC51005C 027C0000
	s_waitcnt vmcnt(0)                                         // 0000001E5430: BF8903F7
	ds_store_b32 v2, v1                                        // 0000001E5434: D8340000 00000102
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001E543C: 8C7E007E
	scratch_load_b32 v1, off, off offset:60                    // 0000001E5440: DC51003C 017C0000
	s_waitcnt vmcnt(0)                                         // 0000001E5448: BF8903F7
	v_add_nc_u32_e32 v3, s42, v1                               // 0000001E544C: 4A06022A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001E5450: BF870091
	v_min_i32_e32 v1, s49, v3                                  // 0000001E5454: 22020631
	v_mad_i64_i32 v[1:2], null, v1, 48, s[2:3]                 // 0000001E5458: D6FF7C01 00096101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001E5460: BF870091
	.long 0xd73c000c                                           // 0000001E5464: D73C000C
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000001E5468: 02020288
	.long 0xd7006a01                                           // 0000001E546C: D7006A01
	v_cndmask_b32_e32 v1, s30, v12, vcc_lo                     // 0000001E5470: 0202181E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E5474: BF870001
	v_add_co_ci_u32_e64 v2, null, s31, v13, vcc_lo             // 0000001E5478: D5207C02 01AA1A1F
	v_cmp_le_i32_e32 vcc_lo, s47, v3                           // 0000001E5480: 7C86062F
	s_clause 0xf                                               // 0000001E5484: BF85000F
	global_load_b128 v[153:156], v[1:2], off                   // 0000001E5488: DC5E0000 997C0001
	global_load_b128 v[157:160], v[1:2], off offset:16         // 0000001E5490: DC5E0010 9D7C0001
	global_load_b128 v[145:148], v[1:2], off offset:32         // 0000001E5498: DC5E0020 917C0001
	global_load_b128 v[149:152], v[1:2], off offset:48         // 0000001E54A0: DC5E0030 957C0001
	global_load_b128 v[89:92], v[1:2], off offset:64           // 0000001E54A8: DC5E0040 597C0001
	global_load_b128 v[93:96], v[1:2], off offset:80           // 0000001E54B0: DC5E0050 5D7C0001
	global_load_b128 v[81:84], v[1:2], off offset:96           // 0000001E54B8: DC5E0060 517C0001
	global_load_b128 v[85:88], v[1:2], off offset:112          // 0000001E54C0: DC5E0070 557C0001
	global_load_b128 v[57:60], v[1:2], off offset:128          // 0000001E54C8: DC5E0080 397C0001
	global_load_b128 v[61:64], v[1:2], off offset:144          // 0000001E54D0: DC5E0090 3D7C0001
	global_load_b128 v[73:76], v[1:2], off offset:160          // 0000001E54D8: DC5E00A0 497C0001
	global_load_b128 v[77:80], v[1:2], off offset:176          // 0000001E54E0: DC5E00B0 4D7C0001
	global_load_b128 v[65:68], v[1:2], off offset:192          // 0000001E54E8: DC5E00C0 417C0001
	global_load_b128 v[69:72], v[1:2], off offset:208          // 0000001E54F0: DC5E00D0 457C0001
	global_load_b128 v[49:52], v[1:2], off offset:224          // 0000001E54F8: DC5E00E0 317C0001
	global_load_b128 v[53:56], v[1:2], off offset:240          // 0000001E5500: DC5E00F0 357C0001
	s_and_saveexec_b32 s0, vcc_lo                              // 0000001E5508: BE80206A
	s_cbranch_execz 81                                         // 0000001E550C: BFA50051 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x1454>
	s_waitcnt vmcnt(15)                                        // 0000001E5510: BF893FF7
	v_mov_b32_e32 v153, 0                                      // 0000001E5514: 7F320280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E5518: BF870001
	v_mov_b32_e32 v154, v153                                   // 0000001E551C: 7F340399
	v_mov_b32_e32 v155, v153                                   // 0000001E5520: 7F360399
	v_mov_b32_e32 v156, v153                                   // 0000001E5524: 7F380399
	s_waitcnt vmcnt(14)                                        // 0000001E5528: BF893BF7
	v_mov_b32_e32 v157, v153                                   // 0000001E552C: 7F3A0399
	v_mov_b32_e32 v158, v153                                   // 0000001E5530: 7F3C0399
	v_mov_b32_e32 v159, v153                                   // 0000001E5534: 7F3E0399
	v_mov_b32_e32 v160, v153                                   // 0000001E5538: 7F400399
	s_waitcnt vmcnt(13)                                        // 0000001E553C: BF8937F7
	v_mov_b32_e32 v145, v153                                   // 0000001E5540: 7F220399
	v_mov_b32_e32 v146, v153                                   // 0000001E5544: 7F240399
	v_mov_b32_e32 v147, v153                                   // 0000001E5548: 7F260399
	v_mov_b32_e32 v148, v153                                   // 0000001E554C: 7F280399
	s_waitcnt vmcnt(12)                                        // 0000001E5550: BF8933F7
	v_mov_b32_e32 v149, v153                                   // 0000001E5554: 7F2A0399
	v_mov_b32_e32 v150, v153                                   // 0000001E5558: 7F2C0399
	v_mov_b32_e32 v151, v153                                   // 0000001E555C: 7F2E0399
	v_mov_b32_e32 v152, v153                                   // 0000001E5560: 7F300399
	s_waitcnt vmcnt(11)                                        // 0000001E5564: BF892FF7
	v_mov_b32_e32 v89, v153                                    // 0000001E5568: 7EB20399
	v_mov_b32_e32 v90, v153                                    // 0000001E556C: 7EB40399
	v_mov_b32_e32 v91, v153                                    // 0000001E5570: 7EB60399
	v_mov_b32_e32 v92, v153                                    // 0000001E5574: 7EB80399
	s_waitcnt vmcnt(10)                                        // 0000001E5578: BF892BF7
	v_mov_b32_e32 v93, v153                                    // 0000001E557C: 7EBA0399
	v_mov_b32_e32 v94, v153                                    // 0000001E5580: 7EBC0399
	v_mov_b32_e32 v95, v153                                    // 0000001E5584: 7EBE0399
	v_mov_b32_e32 v96, v153                                    // 0000001E5588: 7EC00399
	s_waitcnt vmcnt(9)                                         // 0000001E558C: BF8927F7
	v_mov_b32_e32 v81, v153                                    // 0000001E5590: 7EA20399
	v_mov_b32_e32 v82, v153                                    // 0000001E5594: 7EA40399
	v_mov_b32_e32 v83, v153                                    // 0000001E5598: 7EA60399
	v_mov_b32_e32 v84, v153                                    // 0000001E559C: 7EA80399
	s_waitcnt vmcnt(8)                                         // 0000001E55A0: BF8923F7
	v_mov_b32_e32 v85, v153                                    // 0000001E55A4: 7EAA0399
	v_mov_b32_e32 v86, v153                                    // 0000001E55A8: 7EAC0399
	v_mov_b32_e32 v87, v153                                    // 0000001E55AC: 7EAE0399
	v_mov_b32_e32 v88, v153                                    // 0000001E55B0: 7EB00399
	s_waitcnt vmcnt(7)                                         // 0000001E55B4: BF891FF7
	v_mov_b32_e32 v57, v153                                    // 0000001E55B8: 7E720399
	v_mov_b32_e32 v58, v153                                    // 0000001E55BC: 7E740399
	v_mov_b32_e32 v59, v153                                    // 0000001E55C0: 7E760399
	v_mov_b32_e32 v60, v153                                    // 0000001E55C4: 7E780399
	s_waitcnt vmcnt(6)                                         // 0000001E55C8: BF891BF7
	v_mov_b32_e32 v61, v153                                    // 0000001E55CC: 7E7A0399
	v_mov_b32_e32 v62, v153                                    // 0000001E55D0: 7E7C0399
	v_mov_b32_e32 v63, v153                                    // 0000001E55D4: 7E7E0399
	v_mov_b32_e32 v64, v153                                    // 0000001E55D8: 7E800399
	s_waitcnt vmcnt(5)                                         // 0000001E55DC: BF8917F7
	v_mov_b32_e32 v73, v153                                    // 0000001E55E0: 7E920399
	v_mov_b32_e32 v74, v153                                    // 0000001E55E4: 7E940399
	v_mov_b32_e32 v75, v153                                    // 0000001E55E8: 7E960399
	v_mov_b32_e32 v76, v153                                    // 0000001E55EC: 7E980399
	s_waitcnt vmcnt(4)                                         // 0000001E55F0: BF8913F7
	v_mov_b32_e32 v77, v153                                    // 0000001E55F4: 7E9A0399
	v_mov_b32_e32 v78, v153                                    // 0000001E55F8: 7E9C0399
	v_mov_b32_e32 v79, v153                                    // 0000001E55FC: 7E9E0399
	v_mov_b32_e32 v80, v153                                    // 0000001E5600: 7EA00399
	s_waitcnt vmcnt(3)                                         // 0000001E5604: BF890FF7
	v_mov_b32_e32 v65, v153                                    // 0000001E5608: 7E820399
	v_mov_b32_e32 v66, v153                                    // 0000001E560C: 7E840399
	v_mov_b32_e32 v67, v153                                    // 0000001E5610: 7E860399
	v_mov_b32_e32 v68, v153                                    // 0000001E5614: 7E880399
	s_waitcnt vmcnt(2)                                         // 0000001E5618: BF890BF7
	v_mov_b32_e32 v69, v153                                    // 0000001E561C: 7E8A0399
	v_mov_b32_e32 v70, v153                                    // 0000001E5620: 7E8C0399
	v_mov_b32_e32 v71, v153                                    // 0000001E5624: 7E8E0399
	v_mov_b32_e32 v72, v153                                    // 0000001E5628: 7E900399
	s_waitcnt vmcnt(1)                                         // 0000001E562C: BF8907F7
	v_mov_b32_e32 v49, v153                                    // 0000001E5630: 7E620399
	v_mov_b32_e32 v50, v153                                    // 0000001E5634: 7E640399
	v_mov_b32_e32 v51, v153                                    // 0000001E5638: 7E660399
	v_mov_b32_e32 v52, v153                                    // 0000001E563C: 7E680399
	s_waitcnt vmcnt(0)                                         // 0000001E5640: BF8903F7
	v_mov_b32_e32 v53, v153                                    // 0000001E5644: 7E6A0399
	v_mov_b32_e32 v54, v153                                    // 0000001E5648: 7E6C0399
	v_mov_b32_e32 v55, v153                                    // 0000001E564C: 7E6E0399
	v_mov_b32_e32 v56, v153                                    // 0000001E5650: 7E700399
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001E5654: 8C7E007E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001E5658: BF890007
	s_waitcnt_vscnt null, 0x0                                  // 0000001E565C: BC7C0000
	s_barrier                                                  // 0000001E5660: BFBD0000
	buffer_gl0_inv                                             // 0000001E5664: E0AC0000 00000000
	s_clause 0x1                                               // 0000001E566C: BF850001
	scratch_load_b32 v5, off, off offset:4                     // 0000001E5670: DC510004 057C0000
	scratch_load_b32 v10, off, off offset:16                   // 0000001E5678: DC510010 0A7C0000
	ds_load_b128 v[1:4], v163 offset:61440                     // 0000001E5680: DBFCF000 010000A3
	ds_load_b128 v[14:17], v163 offset:61456                   // 0000001E5688: DBFCF010 0E0000A3
	ds_load_b128 v[18:21], v163 offset:61472                   // 0000001E5690: DBFCF020 120000A3
	s_cmp_lt_i32 s42, s47                                      // 0000001E5698: BF042F2A
	.long 0xd59c00a1                                           // 0000001E569C: D59C00A1
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 0000001E56A0: 02010080
	s_cselect_b32 s0, -1, 0                                    // 0000001E56A4: 980080C1
	s_or_b32 s1, s42, 1                                        // 0000001E56A8: 8C01812A
	scratch_load_b32 v26, off, off offset:40                   // 0000001E56AC: DC510028 1A7C0000
	s_cmp_lt_i32 s1, s47                                       // 0000001E56B4: BF042F01
	s_cselect_b32 s1, -1, 0                                    // 0000001E56B8: 980180C1
	s_or_b32 s8, s42, 2                                        // 0000001E56BC: 8C08822A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001E56C0: BF8704B9
	s_cmp_lt_i32 s8, s47                                       // 0000001E56C4: BF042F08
	s_cselect_b32 s8, -1, 0                                    // 0000001E56C8: 980880C1
	s_or_b32 s9, s42, 3                                        // 0000001E56CC: 8C09832A
	s_cmp_lt_i32 s9, s47                                       // 0000001E56D0: BF042F09
	s_waitcnt lgkmcnt(2)                                       // 0000001E56D4: BF89FC27
	v_mul_f32_e32 v2, v0, v2                                   // 0000001E56D8: 10040500
	s_cselect_b32 s9, -1, 0                                    // 0000001E56DC: 980980C1
	s_or_b32 s10, s42, 4                                       // 0000001E56E0: 8C0A842A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001E56E4: BF870009
	s_cmp_lt_i32 s10, s47                                      // 0000001E56E8: BF042F0A
	s_waitcnt vmcnt(2)                                         // 0000001E56EC: BF890BF7
	v_mul_f32_e32 v1, v5, v1                                   // 0000001E56F0: 10020305
	scratch_load_b32 v5, off, off offset:8                     // 0000001E56F4: DC510008 057C0000
	v_fma_mixlo_f16 v1, v1, s39, 0                             // 0000001E56FC: CC210001 02004F01
	v_fma_mixhi_f16 v1, v2, s39, 0                             // 0000001E5704: CC220001 02004F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001E570C: BF870112
	v_cndmask_b16 v1, 0, v1, s0                                // 0000001E5710: D65D0001 00020280
	v_cndmask_b16 v1, 0, v1, s1                                // 0000001E5718: D65D5001 00060280
	s_cselect_b32 s0, -1, 0                                    // 0000001E5720: 980080C1
	s_or_b32 s1, s42, 5                                        // 0000001E5724: 8C01852A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001E5728: BF870009
	s_cmp_lt_i32 s1, s47                                       // 0000001E572C: BF042F01
	s_cselect_b32 s1, -1, 0                                    // 0000001E5730: 980180C1
	s_waitcnt vmcnt(0)                                         // 0000001E5734: BF8903F7
	v_mul_f32_e32 v3, v5, v3                                   // 0000001E5738: 10060705
	ds_load_b128 v[5:8], v163 offset:61488                     // 0000001E573C: DBFCF030 050000A3
	s_waitcnt lgkmcnt(1)                                       // 0000001E5744: BF89FC17
	v_mul_f32_e32 v10, v10, v19                                // 0000001E5748: 1014270A
	v_fma_mixlo_f16 v2, v3, s39, 0                             // 0000001E574C: CC210002 02004F03
	v_dual_mul_f32 v3, v233, v4 :: v_dual_mul_f32 v4, v234, v14// 0000001E5754: C8C609E9 03041DEA
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001E575C: BF870112
	v_cndmask_b16 v2, 0, v2, s8                                // 0000001E5760: D65D0002 00220480
	v_fma_mixhi_f16 v2, v3, s39, 0                             // 0000001E5768: CC220002 02004F03
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001E5770: BF870003
	v_fma_mixlo_f16 v3, v4, s39, 0                             // 0000001E5774: CC210003 02004F04
	scratch_load_b32 v4, off, off offset:12                    // 0000001E577C: DC51000C 047C0000
	v_mul_f32_e32 v9, v235, v15                                // 0000001E5784: 10121FEB
	v_cndmask_b16 v2, 0, v2, s9                                // 0000001E5788: D65D5002 00260480
	v_cndmask_b16 v3, 0, v3, s0                                // 0000001E5790: D65D0003 00020680
	s_or_b32 s0, s42, 6                                        // 0000001E5798: 8C00862A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001E579C: BF8700C9
	s_cmp_lt_i32 s0, s47                                       // 0000001E57A0: BF042F00
	s_waitcnt lgkmcnt(0)                                       // 0000001E57A4: BF89FC07
	v_mul_f32_e32 v14, v238, v5                                // 0000001E57A8: 101C0BEE
	s_cselect_b32 s0, -1, 0                                    // 0000001E57AC: 980080C1
	v_fma_mixhi_f16 v5, v14, s39, 0                            // 0000001E57B0: CC220005 02004F0E
	s_waitcnt vmcnt(0)                                         // 0000001E57B8: BF8903F7
	v_mul_f32_e32 v4, v4, v16                                  // 0000001E57BC: 10082104
	v_fma_mixhi_f16 v3, v9, s39, 0                             // 0000001E57C0: CC220003 02004F09
	v_mul_f32_e32 v9, v168, v17                                // 0000001E57C8: 101223A8
	ds_load_b128 v[14:17], v163 offset:61504                   // 0000001E57CC: DBFCF040 0E0000A3
	v_mul_f32_e32 v11, v236, v20                               // 0000001E57D4: 101629EC
	v_fma_mixlo_f16 v4, v4, s39, 0                             // 0000001E57D8: CC210004 02004F04
	v_cndmask_b16 v3, 0, v3, s1                                // 0000001E57E0: D65D5003 00060680
	s_or_b32 s1, s42, 7                                        // 0000001E57E8: 8C01872A
	v_fma_mixhi_f16 v4, v9, s39, 0                             // 0000001E57EC: CC220004 02004F09
	s_cmp_lt_i32 s1, s47                                       // 0000001E57F4: BF042F01
	v_mul_f32_e32 v9, v169, v18                                // 0000001E57F8: 101225A9
	s_cselect_b32 s1, -1, 0                                    // 0000001E57FC: 980180C1
	s_or_b32 s8, s42, 8                                        // 0000001E5800: 8C08882A
	v_cndmask_b16 v4, 0, v4, s0                                // 0000001E5804: D65D0004 00020880
	s_cmp_lt_i32 s8, s47                                       // 0000001E580C: BF042F08
	v_cndmask_b16 v4, 0, v4, s1                                // 0000001E5810: D65D5004 00060880
	s_cselect_b32 s0, -1, 0                                    // 0000001E5818: 980080C1
	s_or_b32 s1, s42, 9                                        // 0000001E581C: 8C01892A
	v_fma_mixlo_f16 v9, v9, s39, 0                             // 0000001E5820: CC210009 02004F09
	s_cmp_lt_i32 s1, s47                                       // 0000001E5828: BF042F01
	v_fma_mixhi_f16 v9, v10, s39, 0                            // 0000001E582C: CC220009 02004F0A
	s_cselect_b32 s1, -1, 0                                    // 0000001E5834: 980180C1
	s_or_b32 s8, s42, 10                                       // 0000001E5838: 8C088A2A
	v_fma_mixlo_f16 v10, v11, s39, 0                           // 0000001E583C: CC21000A 02004F0B
	s_cmp_lt_i32 s8, s47                                       // 0000001E5844: BF042F08
	v_cndmask_b16 v9, 0, v9, s0                                // 0000001E5848: D65D0009 00021280
	s_cselect_b32 s0, -1, 0                                    // 0000001E5850: 980080C1
	v_mul_f32_e32 v11, v237, v21                               // 0000001E5854: 10162BED
	v_cndmask_b16 v10, 0, v10, s0                              // 0000001E5858: D65D000A 00021480
	s_or_b32 s0, s42, 11                                       // 0000001E5860: 8C008B2A
	v_cndmask_b16 v9, 0, v9, s1                                // 0000001E5864: D65D5009 00061280
	s_cmp_lt_i32 s0, s47                                       // 0000001E586C: BF042F00
	v_fma_mixlo_f16 v5, v11, s39, 0                            // 0000001E5870: CC210005 02004F0B
	s_cselect_b32 s0, -1, 0                                    // 0000001E5878: 980080C1
	s_or_b32 s1, s42, 12                                       // 0000001E587C: 8C018C2A
	scratch_load_b32 v21, off, off offset:32                   // 0000001E5880: DC510020 157C0000
	s_cmp_lt_i32 s1, s47                                       // 0000001E5888: BF042F01
	v_cndmask_b16 v10, 0, v5, s0                               // 0000001E588C: D65D400A 00020A80
	s_cselect_b32 s1, -1, 0                                    // 0000001E5894: 980180C1
	s_or_b32 s8, s42, 13                                       // 0000001E5898: 8C088D2A
	v_cndmask_b16 v11, 0, v5, s1                               // 0000001E589C: D65D100B 00060A80
	s_cmp_lt_i32 s8, s47                                       // 0000001E58A4: BF042F08
	v_mul_f32_e32 v5, v227, v6                                 // 0000001E58A8: 100A0DE3
	s_cselect_b32 s1, -1, 0                                    // 0000001E58AC: 980180C1
	s_or_b32 s8, s42, 14                                       // 0000001E58B0: 8C088E2A
	v_dual_mul_f32 v6, v170, v7 :: v_dual_mul_f32 v7, v171, v8 // 0000001E58B4: C8C60FAA 060611AB
	s_cmp_lt_i32 s8, s47                                       // 0000001E58BC: BF042F08
	v_fma_mixlo_f16 v5, v5, s39, 0                             // 0000001E58C0: CC210005 02004F05
	s_cselect_b32 s8, -1, 0                                    // 0000001E58C8: 980880C1
	s_or_b32 s9, s42, 15                                       // 0000001E58CC: 8C098F2A
	v_fma_mixhi_f16 v5, v6, s39, 0                             // 0000001E58D0: CC220005 02004F06
	v_fma_mixlo_f16 v6, v7, s39, 0                             // 0000001E58D8: CC210006 02004F07
	s_cmp_lt_i32 s9, s47                                       // 0000001E58E0: BF042F09
	v_cndmask_b16 v11, 0, v5, s1                               // 0000001E58E4: D65D400B 00060A80
	s_cselect_b32 s1, -1, 0                                    // 0000001E58EC: 980180C1
	.long 0xd7000065                                           // 0000001E58F0: D7000065
	v_cndmask_b32_e32 v1, s28, v12, vcc_lo                     // 0000001E58F4: 0202181C
	v_cndmask_b16 v12, 0, v5, s8                               // 0000001E58F8: D65D100C 00220A80
	v_cndmask_b16 v12, 0, v6, s1                               // 0000001E5900: D65D400C 00060C80
	ds_load_b128 v[5:8], v163 offset:61520                     // 0000001E5908: DBFCF050 050000A3
	ds_store_b128 v182, v[1:4]                                 // 0000001E5910: DB7C0000 000001B6
	ds_store_b128 v182, v[9:12] offset:16                      // 0000001E5918: DB7C0010 000009B6
	ds_load_b128 v[9:12], v163 offset:61536                    // 0000001E5920: DBFCF060 090000A3
	s_waitcnt lgkmcnt(4)                                       // 0000001E5928: BF89FC47
	v_dual_mul_f32 v2, v239, v15 :: v_dual_mul_f32 v3, v241, v17// 0000001E592C: C8C61FEF 020223F1
	v_add_co_ci_u32_e64 v102, null, s29, v13, s0               // 0000001E5934: D5207C66 00021A1D
	s_or_b32 s0, s42, 16                                       // 0000001E593C: 8C00902A
	v_fma_mixhi_f16 v1, v2, s39, 0                             // 0000001E5940: CC220001 02004F02
	v_mul_f32_e32 v2, v240, v16                                // 0000001E5948: 100421F0
	s_cmp_lt_i32 s0, s47                                       // 0000001E594C: BF042F00
	ds_load_b128 v[17:20], v163 offset:61600                   // 0000001E5950: DBFCF0A0 110000A3
	s_cselect_b32 s0, -1, 0                                    // 0000001E5958: 980080C1
	s_or_b32 s1, s42, 17                                       // 0000001E595C: 8C01912A
	v_fma_mixlo_f16 v2, v2, s39, 0                             // 0000001E5960: CC210002 02004F02
	v_fma_mixhi_f16 v2, v3, s39, 0                             // 0000001E5968: CC220002 02004F03
	s_cmp_lt_i32 s1, s47                                       // 0000001E5970: BF042F01
	s_clause 0x1                                               // 0000001E5974: BF850001
	global_load_b128 v[121:124], v[101:102], off               // 0000001E5978: DC5E0000 797C0065
	global_load_b128 v[125:128], v[101:102], off offset:16     // 0000001E5980: DC5E0010 7D7C0065
	s_waitcnt lgkmcnt(4)                                       // 0000001E5988: BF89FC47
	v_dual_mul_f32 v4, v181, v5 :: v_dual_mul_f32 v5, v212, v7 // 0000001E598C: C8C60BB5 04040FD4
	s_clause 0x5                                               // 0000001E5994: BF850005
	global_load_b128 v[105:108], v[101:102], off offset:32     // 0000001E5998: DC5E0020 697C0065
	global_load_b128 v[109:112], v[101:102], off offset:48     // 0000001E59A0: DC5E0030 6D7C0065
	global_load_b128 v[41:44], v[101:102], off offset:64       // 0000001E59A8: DC5E0040 297C0065
	global_load_b128 v[45:48], v[101:102], off offset:80       // 0000001E59B0: DC5E0050 2D7C0065
	global_load_b128 v[33:36], v[101:102], off offset:96       // 0000001E59B8: DC5E0060 217C0065
	global_load_b128 v[37:40], v[101:102], off offset:112      // 0000001E59C0: DC5E0070 257C0065
	v_fma_mixlo_f16 v3, v4, s39, 0                             // 0000001E59C8: CC210003 02004F04
	v_mul_f32_e32 v4, v211, v6                                 // 0000001E59D0: 10080DD3
	v_mul_f32_e32 v6, v173, v8                                 // 0000001E59D4: 100C11AD
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001E59D8: BF8701A2
	v_fma_mixhi_f16 v3, v4, s39, 0                             // 0000001E59DC: CC220003 02004F04
	v_fma_mixlo_f16 v4, v5, s39, 0                             // 0000001E59E4: CC210004 02004F05
	v_fma_mixhi_f16 v4, v6, s39, 0                             // 0000001E59EC: CC220004 02004F06
	ds_load_b128 v[5:8], v163 offset:61552                     // 0000001E59F4: DBFCF070 050000A3
	s_waitcnt lgkmcnt(2)                                       // 0000001E59FC: BF89FC27
	v_dual_mul_f32 v9, v242, v9 :: v_dual_mul_f32 v10, v243, v10// 0000001E5A00: C8C613F2 090A15F3
	v_mul_f32_e32 v13, v228, v14                               // 0000001E5A08: 101A1DE4
	s_waitcnt lgkmcnt(1)                                       // 0000001E5A0C: BF89FC17
	v_mul_f32_e32 v17, v250, v17                               // 0000001E5A10: 102223FA
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001E5A14: BF870003
	v_fma_mixlo_f16 v9, v9, s39, 0                             // 0000001E5A18: CC210009 02004F09
	v_fma_mixhi_f16 v9, v10, s39, 0                            // 0000001E5A20: CC220009 02004F0A
	v_mul_f32_e32 v10, v244, v11                               // 0000001E5A28: 101417F4
	scratch_load_b32 v11, off, off offset:20                   // 0000001E5A2C: DC510014 0B7C0000
	v_fma_mixlo_f16 v10, v10, s39, 0                           // 0000001E5A34: CC21000A 02004F0A
	s_waitcnt vmcnt(9)                                         // 0000001E5A3C: BF8927F7
	v_mul_f32_e32 v18, v21, v18                                // 0000001E5A40: 10242515
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001E5A44: CC210011 02004F11
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001E5A4C: BF870002
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001E5A50: CC220011 02004F12
	v_dual_mul_f32 v18, v217, v19 :: v_dual_mul_f32 v19, v218, v20// 0000001E5A58: C8C627D9 121229DA
	ds_load_b128 v[20:23], v163 offset:61632                   // 0000001E5A60: DBFCF0C0 140000A3
	v_fma_mixlo_f16 v18, v18, s39, 0                           // 0000001E5A68: CC210012 02004F12
	v_fma_mixhi_f16 v18, v19, s39, 0                           // 0000001E5A70: CC220012 02004F13
	scratch_load_b32 v19, off, off offset:36                   // 0000001E5A78: DC510024 137C0000
	s_waitcnt lgkmcnt(0)                                       // 0000001E5A80: BF89FC07
	v_mul_f32_e32 v26, v26, v20                                // 0000001E5A84: 1034291A
	v_mul_f32_e32 v22, v220, v22                               // 0000001E5A88: 102C2DDC
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001E5A8C: BF870002
	v_fma_mixlo_f16 v32, v26, s39, 0                           // 0000001E5A90: CC210020 02004F1A
	s_waitcnt vmcnt(1)                                         // 0000001E5A98: BF8907F7
	v_dual_mul_f32 v11, v11, v12 :: v_dual_mul_f32 v12, v213, v5// 0000001E5A9C: C8C6190B 0B0C0BD5
	v_fma_mixlo_f16 v1, v13, s39, 0                            // 0000001E5AA4: CC210001 02004F0D
	ds_load_b128 v[13:16], v163 offset:61568                   // 0000001E5AAC: DBFCF080 0D0000A3
	v_fma_mixlo_f16 v5, v11, s39, 0                            // 0000001E5AB4: CC210005 02004F0B
	v_fma_mixhi_f16 v5, v12, s39, 0                            // 0000001E5ABC: CC220005 02004F0C
	v_cndmask_b16 v1, 0, v1, s0                                // 0000001E5AC4: D65D0001 00020280
	s_cselect_b32 s0, -1, 0                                    // 0000001E5ACC: 980080C1
	s_or_b32 s1, s42, 18                                       // 0000001E5AD0: 8C01922A
	v_cndmask_b16 v1, 0, v1, s0                                // 0000001E5AD4: D65D5001 00020280
	s_cmp_lt_i32 s1, s47                                       // 0000001E5ADC: BF042F01
	s_cselect_b32 s0, -1, 0                                    // 0000001E5AE0: 980080C1
	s_or_b32 s1, s42, 19                                       // 0000001E5AE4: 8C01932A
	v_cndmask_b16 v2, 0, v2, s0                                // 0000001E5AE8: D65D0002 00020480
	s_cmp_lt_i32 s1, s47                                       // 0000001E5AF0: BF042F01
	s_cselect_b32 s1, -1, 0                                    // 0000001E5AF4: 980180C1
	s_or_b32 s8, s42, 20                                       // 0000001E5AF8: 8C08942A
	v_cndmask_b16 v2, 0, v2, s1                                // 0000001E5AFC: D65D5002 00060480
	s_cmp_lt_i32 s8, s47                                       // 0000001E5B04: BF042F08
	s_cselect_b32 s0, -1, 0                                    // 0000001E5B08: 980080C1
	s_or_b32 s1, s42, 21                                       // 0000001E5B0C: 8C01952A
	v_cndmask_b16 v3, 0, v3, s0                                // 0000001E5B10: D65D0003 00020680
	s_cmp_lt_i32 s1, s47                                       // 0000001E5B18: BF042F01
	s_cselect_b32 s0, -1, 0                                    // 0000001E5B1C: 980080C1
	s_or_b32 s1, s42, 22                                       // 0000001E5B20: 8C01962A
	v_cndmask_b16 v3, 0, v3, s0                                // 0000001E5B24: D65D5003 00020680
	s_cmp_lt_i32 s1, s47                                       // 0000001E5B2C: BF042F01
	s_cselect_b32 s1, -1, 0                                    // 0000001E5B30: 980180C1
	s_or_b32 s8, s42, 23                                       // 0000001E5B34: 8C08972A
	v_cndmask_b16 v4, 0, v4, s1                                // 0000001E5B38: D65D0004 00060880
	s_cmp_lt_i32 s8, s47                                       // 0000001E5B40: BF042F08
	s_cselect_b32 s0, -1, 0                                    // 0000001E5B44: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000001E5B48: BF8704A9
	v_cndmask_b16 v4, 0, v4, s0                                // 0000001E5B4C: D65D5004 00020880
	s_or_b32 s0, s42, 24                                       // 0000001E5B54: 8C00982A
	s_cmp_lt_i32 s0, s47                                       // 0000001E5B58: BF042F00
	s_cselect_b32 s0, -1, 0                                    // 0000001E5B5C: 980080C1
	s_or_b32 s1, s42, 25                                       // 0000001E5B60: 8C01992A
	v_cndmask_b16 v9, 0, v9, s0                                // 0000001E5B64: D65D0009 00021280
	s_cmp_lt_i32 s1, s47                                       // 0000001E5B6C: BF042F01
	s_cselect_b32 s0, -1, 0                                    // 0000001E5B70: 980080C1
	s_or_b32 s1, s42, 26                                       // 0000001E5B74: 8C019A2A
	v_cndmask_b16 v9, 0, v9, s0                                // 0000001E5B78: D65D5009 00021280
	s_cmp_lt_i32 s1, s47                                       // 0000001E5B80: BF042F01
	s_cselect_b32 s0, -1, 0                                    // 0000001E5B84: 980080C1
	s_or_b32 s1, s42, 27                                       // 0000001E5B88: 8C019B2A
	v_cndmask_b16 v10, 0, v10, s0                              // 0000001E5B8C: D65D000A 00021480
	s_cmp_lt_i32 s1, s47                                       // 0000001E5B94: BF042F01
	s_cselect_b32 s1, -1, 0                                    // 0000001E5B98: 980180C1
	s_or_b32 s8, s42, 28                                       // 0000001E5B9C: 8C089C2A
	v_cndmask_b16 v10, 0, v5, s1                               // 0000001E5BA0: D65D400A 00060A80
	s_cmp_lt_i32 s8, s47                                       // 0000001E5BA8: BF042F08
	s_cselect_b32 s0, -1, 0                                    // 0000001E5BAC: 980080C1
	s_or_b32 s1, s42, 29                                       // 0000001E5BB0: 8C019D2A
	v_cndmask_b16 v11, 0, v5, s0                               // 0000001E5BB4: D65D100B 00020A80
	v_mul_f32_e32 v5, v214, v6                                 // 0000001E5BBC: 100A0DD6
	scratch_load_b32 v6, off, off offset:24                    // 0000001E5BC0: DC510018 067C0000
	s_cmp_lt_i32 s1, s47                                       // 0000001E5BC8: BF042F01
	s_cselect_b32 s0, -1, 0                                    // 0000001E5BCC: 980080C1
	s_or_b32 s1, s42, 30                                       // 0000001E5BD0: 8C019E2A
	v_fma_mixlo_f16 v5, v5, s39, 0                             // 0000001E5BD4: CC210005 02004F05
	s_cmp_lt_i32 s1, s47                                       // 0000001E5BDC: BF042F01
	s_cselect_b32 s1, -1, 0                                    // 0000001E5BE0: 980180C1
	s_or_b32 s8, s42, 31                                       // 0000001E5BE4: 8C089F2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001E5BE8: BF8700D1
	v_cndmask_b16 v11, 0, v5, s0                               // 0000001E5BEC: D65D400B 00020A80
	s_cmp_lt_i32 s8, s47                                       // 0000001E5BF4: BF042F08
	s_cselect_b32 s0, -1, 0                                    // 0000001E5BF8: 980080C1
	s_waitcnt vmcnt(0)                                         // 0000001E5BFC: BF8903F7
	v_dual_mul_f32 v6, v6, v7 :: v_dual_mul_f32 v7, v245, v8   // 0000001E5C00: C8C60F06 060611F5
	v_fma_mixhi_f16 v5, v6, s39, 0                             // 0000001E5C08: CC220005 02004F06
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001E5C10: BF870112
	v_fma_mixhi_f16 v12, v7, s39, 0                            // 0000001E5C14: CC22000C 02004F07
	v_cndmask_b16 v12, 0, v5, s1                               // 0000001E5C1C: D65D100C 00060A80
	ds_load_b128 v[5:8], v163 offset:61584                     // 0000001E5C24: DBFCF090 050000A3
	s_waitcnt lgkmcnt(1)                                       // 0000001E5C2C: BF89FC17
	v_mul_f32_e32 v13, v246, v13                               // 0000001E5C30: 101A1BF6
	v_cndmask_b16 v12, 0, v12, s0                              // 0000001E5C34: D65D500C 00021880
	s_or_b32 s0, s42, 32                                       // 0000001E5C3C: 8C00A02A
	v_mul_f32_e32 v14, v247, v14                               // 0000001E5C40: 101C1DF7
	s_cmp_lt_i32 s0, s47                                       // 0000001E5C44: BF042F00
	v_fma_mixlo_f16 v13, v13, s39, 0                           // 0000001E5C48: CC21000D 02004F0D
	s_cselect_b32 s0, -1, 0                                    // 0000001E5C50: 980080C1
	s_or_b32 s1, s42, 33                                       // 0000001E5C54: 8C01A12A
	v_fma_mixhi_f16 v13, v14, s39, 0                           // 0000001E5C58: CC22000D 02004F0E
	s_cmp_lt_i32 s1, s47                                       // 0000001E5C60: BF042F01
	v_cndmask_b16 v13, 0, v13, s0                              // 0000001E5C64: D65D000D 00021A80
	s_cselect_b32 s0, -1, 0                                    // 0000001E5C6C: 980080C1
	s_or_b32 s1, s42, 34                                       // 0000001E5C70: 8C01A22A
	v_mul_f32_e32 v14, v184, v15                               // 0000001E5C74: 101C1FB8
	s_cmp_lt_i32 s1, s47                                       // 0000001E5C78: BF042F01
	v_cndmask_b16 v13, 0, v13, s0                              // 0000001E5C7C: D65D500D 00021A80
	s_cselect_b32 s0, -1, 0                                    // 0000001E5C84: 980080C1
	s_or_b32 s1, s42, 35                                       // 0000001E5C88: 8C01A32A
	s_waitcnt lgkmcnt(0)                                       // 0000001E5C8C: BF89FC07
	v_dual_mul_f32 v15, v215, v16 :: v_dual_mul_f32 v16, v216, v5// 0000001E5C90: C8C621D7 0F100BD8
	s_cmp_lt_i32 s1, s47                                       // 0000001E5C98: BF042F01
	v_fma_mixlo_f16 v14, v14, s39, 0                           // 0000001E5C9C: CC21000E 02004F0E
	s_cselect_b32 s1, -1, 0                                    // 0000001E5CA4: 980180C1
	s_or_b32 s8, s42, 36                                       // 0000001E5CA8: 8C08A42A
	v_fma_mixlo_f16 v5, v15, s39, 0                            // 0000001E5CAC: CC210005 02004F0F
	v_fma_mixhi_f16 v5, v16, s39, 0                            // 0000001E5CB4: CC220005 02004F10
	s_cmp_lt_i32 s8, s47                                       // 0000001E5CBC: BF042F08
	v_cndmask_b16 v14, 0, v14, s0                              // 0000001E5CC0: D65D000E 00021C80
	s_cselect_b32 s0, -1, 0                                    // 0000001E5CC8: 980080C1
	v_cndmask_b16 v14, 0, v5, s1                               // 0000001E5CCC: D65D400E 00060A80
	v_cndmask_b16 v15, 0, v5, s0                               // 0000001E5CD4: D65D100F 00020A80
	scratch_load_b32 v5, off, off offset:28                    // 0000001E5CDC: DC51001C 057C0000
	s_or_b32 s1, s42, 37                                       // 0000001E5CE4: 8C01A52A
	ds_store_b128 v182, v[1:4] offset:32                       // 0000001E5CE8: DB7C0020 000001B6
	ds_store_b128 v182, v[9:12] offset:48                      // 0000001E5CF0: DB7C0030 000009B6
	s_cmp_lt_i32 s1, s47                                       // 0000001E5CF8: BF042F01
	s_cselect_b32 s0, -1, 0                                    // 0000001E5CFC: 980080C1
	s_or_b32 s1, s42, 38                                       // 0000001E5D00: 8C01A62A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001E5D04: BF8704B9
	s_cmp_lt_i32 s1, s47                                       // 0000001E5D08: BF042F01
	s_cselect_b32 s1, -1, 0                                    // 0000001E5D0C: 980180C1
	s_or_b32 s8, s42, 39                                       // 0000001E5D10: 8C08A72A
	s_cmp_lt_i32 s8, s47                                       // 0000001E5D14: BF042F08
	s_waitcnt vmcnt(0)                                         // 0000001E5D18: BF8903F7
	v_dual_mul_f32 v5, v5, v6 :: v_dual_mul_f32 v6, v248, v7   // 0000001E5D1C: C8C60D05 05060FF8
	v_mul_f32_e32 v7, v249, v8                                 // 0000001E5D24: 100E11F9
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001E5D28: BF870192
	v_fma_mixlo_f16 v5, v5, s39, 0                             // 0000001E5D2C: CC210005 02004F05
	v_fma_mixhi_f16 v5, v6, s39, 0                             // 0000001E5D34: CC220005 02004F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001E5D3C: BF870193
	v_fma_mixhi_f16 v16, v7, s39, 0                            // 0000001E5D40: CC220010 02004F07
	v_cndmask_b16 v15, 0, v5, s0                               // 0000001E5D48: D65D400F 00020A80
	s_cselect_b32 s0, -1, 0                                    // 0000001E5D50: 980080C1
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000001E5D54: BF8704C3
	v_cndmask_b16 v16, 0, v5, s1                               // 0000001E5D58: D65D1010 00060A80
	ds_load_b128 v[5:8], v163 offset:61616                     // 0000001E5D60: DBFCF0B0 050000A3
	v_cndmask_b16 v16, 0, v16, s0                              // 0000001E5D68: D65D5010 00022080
	s_or_b32 s0, s42, 40                                       // 0000001E5D70: 8C00A82A
	s_cmp_lt_i32 s0, s47                                       // 0000001E5D74: BF042F00
	s_cselect_b32 s0, -1, 0                                    // 0000001E5D78: 980080C1
	s_or_b32 s1, s42, 41                                       // 0000001E5D7C: 8C01A92A
	v_cndmask_b16 v17, 0, v17, s0                              // 0000001E5D80: D65D0011 00022280
	s_cmp_lt_i32 s1, s47                                       // 0000001E5D88: BF042F01
	s_cselect_b32 s0, -1, 0                                    // 0000001E5D8C: 980080C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000001E5D90: BF8704A9
	v_cndmask_b16 v17, 0, v17, s0                              // 0000001E5D94: D65D5011 00022280
	s_or_b32 s0, s42, 42                                       // 0000001E5D9C: 8C00AA2A
	s_cmp_lt_i32 s0, s47                                       // 0000001E5DA0: BF042F00
	s_cselect_b32 s0, -1, 0                                    // 0000001E5DA4: 980080C1
	s_or_b32 s1, s42, 43                                       // 0000001E5DA8: 8C01AB2A
	v_cndmask_b16 v18, 0, v18, s0                              // 0000001E5DAC: D65D0012 00022480
	s_cmp_lt_i32 s1, s47                                       // 0000001E5DB4: BF042F01
	s_waitcnt lgkmcnt(0)                                       // 0000001E5DB8: BF89FC07
	v_mul_f32_e32 v5, v19, v5                                  // 0000001E5DBC: 100A0B13
	s_cselect_b32 s0, -1, 0                                    // 0000001E5DC0: 980080C1
	s_or_b32 s1, s42, 44                                       // 0000001E5DC4: 8C01AC2A
	v_cndmask_b16 v18, 0, v18, s0                              // 0000001E5DC8: D65D5012 00022480
	s_cmp_lt_i32 s1, s47                                       // 0000001E5DD0: BF042F01
	v_mul_f32_e32 v6, v251, v6                                 // 0000001E5DD4: 100C0DFB
	s_cselect_b32 s0, -1, 0                                    // 0000001E5DD8: 980080C1
	s_or_b32 s1, s42, 45                                       // 0000001E5DDC: 8C01AD2A
	v_fma_mixlo_f16 v5, v5, s39, 0                             // 0000001E5DE0: CC210005 02004F05
	s_cmp_lt_i32 s1, s47                                       // 0000001E5DE8: BF042F01
	v_fma_mixhi_f16 v5, v6, s39, 0                             // 0000001E5DEC: CC220005 02004F06
	s_cselect_b32 s1, -1, 0                                    // 0000001E5DF4: 980180C1
	s_or_b32 s8, s42, 46                                       // 0000001E5DF8: 8C08AE2A
	v_mul_f32_e32 v6, v252, v7                                 // 0000001E5DFC: 100C0FFC
	s_cmp_lt_i32 s8, s47                                       // 0000001E5E00: BF042F08
	v_cndmask_b16 v19, 0, v5, s0                               // 0000001E5E04: D65D0013 00020A80
	s_cselect_b32 s0, -1, 0                                    // 0000001E5E0C: 980080C1
	s_or_b32 s8, s42, 47                                       // 0000001E5E10: 8C08AF2A
	v_fma_mixlo_f16 v24, v6, s39, 0                            // 0000001E5E14: CC210018 02004F06
	s_cmp_lt_i32 s8, s47                                       // 0000001E5E1C: BF042F08
	v_cndmask_b16 v19, 0, v5, s1                               // 0000001E5E20: D65D5013 00060A80
	v_mul_f32_e32 v25, v253, v8                                // 0000001E5E28: 103211FD
	s_cselect_b32 s1, -1, 0                                    // 0000001E5E2C: 980180C1
	s_or_b32 s8, s42, 48                                       // 0000001E5E30: 8C08B02A
	v_cndmask_b16 v20, 0, v24, s0                              // 0000001E5E34: D65D0014 00023080
	s_cmp_lt_i32 s8, s47                                       // 0000001E5E3C: BF042F08
	v_fma_mixhi_f16 v20, v25, s39, 0                           // 0000001E5E40: CC220014 02004F19
	s_cselect_b32 s0, -1, 0                                    // 0000001E5E48: 980080C1
	ds_load_b128 v[5:8], v163 offset:61648                     // 0000001E5E4C: DBFCF0D0 050000A3
	v_cndmask_b16 v97, 0, v32, s0                              // 0000001E5E54: D65D0061 00024080
	s_or_b32 s0, s42, 49                                       // 0000001E5E5C: 8C00B12A
	v_mul_f32_e32 v21, v219, v21                               // 0000001E5E60: 102A2BDB
	s_cmp_lt_i32 s0, s47                                       // 0000001E5E64: BF042F00
	v_cndmask_b16 v20, 0, v20, s1                              // 0000001E5E68: D65D5014 00062880
	s_cselect_b32 s0, -1, 0                                    // 0000001E5E70: 980080C1
	s_or_b32 s1, s42, 50                                       // 0000001E5E74: 8C01B22A
	v_fma_mixlo_f16 v21, v21, s39, 0                           // 0000001E5E78: CC210015 02004F15
	v_fma_mixhi_f16 v21, v22, s39, 0                           // 0000001E5E80: CC220015 02004F16
	s_cmp_lt_i32 s1, s47                                       // 0000001E5E88: BF042F01
	ds_load_b128 v[24:27], v163 offset:61664                   // 0000001E5E8C: DBFCF0E0 180000A3
	ds_load_b128 v[28:31], v163 offset:61680                   // 0000001E5E94: DBFCF0F0 1C0000A3
	s_cselect_b32 s1, -1, 0                                    // 0000001E5E9C: 980180C1
	v_cndmask_b16 v97, 0, v21, s0                              // 0000001E5EA0: D65D4061 00022A80
	v_cndmask_b16 v98, 0, v21, s1                              // 0000001E5EA8: D65D1062 00062A80
	scratch_load_b32 v21, off, off offset:44                   // 0000001E5EB0: DC51002C 157C0000
	s_or_b32 s8, s42, 51                                       // 0000001E5EB8: 8C08B32A
	ds_store_b128 v182, v[13:16] offset:64                     // 0000001E5EBC: DB7C0040 00000DB6
	ds_store_b128 v182, v[17:20] offset:80                     // 0000001E5EC4: DB7C0050 000011B6
	s_cmp_lt_i32 s8, s47                                       // 0000001E5ECC: BF042F08
	s_cselect_b32 s0, -1, 0                                    // 0000001E5ED0: 980080C1
	s_or_b32 s1, s42, 52                                       // 0000001E5ED4: 8C01B42A
	s_waitcnt lgkmcnt(4)                                       // 0000001E5ED8: BF89FC47
	v_mul_f32_e32 v6, v255, v6                                 // 0000001E5EDC: 100C0DFF
	s_cmp_lt_i32 s1, s47                                       // 0000001E5EE0: BF042F01
	v_mul_f32_e32 v22, v254, v5                                // 0000001E5EE4: 102C0BFE
	s_cselect_b32 s1, -1, 0                                    // 0000001E5EE8: 980180C1
	s_or_b32 s8, s42, 53                                       // 0000001E5EEC: 8C08B52A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001E5EF0: BF870099
	s_cmp_lt_i32 s8, s47                                       // 0000001E5EF4: BF042F08
	v_fma_mixhi_f16 v5, v22, s39, 0                            // 0000001E5EF8: CC220005 02004F16
	s_waitcnt lgkmcnt(2)                                       // 0000001E5F00: BF89FC27
	v_mul_f32_e32 v22, v223, v31                               // 0000001E5F04: 102C3FDF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001E5F08: BF8700B2
	v_cndmask_b16 v99, 0, v5, s1                               // 0000001E5F0C: D65D1063 00060A80
	s_waitcnt vmcnt(0)                                         // 0000001E5F14: BF8903F7
	v_mul_f32_e32 v21, v21, v23                                // 0000001E5F18: 102A2F15
	v_fma_mixlo_f16 v5, v21, s39, 0                            // 0000001E5F1C: CC210005 02004F15
	scratch_load_b32 v21, off, off offset:56                   // 0000001E5F24: DC510038 157C0000
	v_cndmask_b16 v98, 0, v5, s0                               // 0000001E5F2C: D65D4062 00020A80
	v_mul_f32_e32 v5, v186, v7                                 // 0000001E5F34: 100A0FBA
	v_fma_mixlo_f16 v6, v6, s39, 0                             // 0000001E5F38: CC210006 02004F06
	s_cselect_b32 s0, -1, 0                                    // 0000001E5F40: 980080C1
	scratch_load_b32 v7, off, off offset:52                    // 0000001E5F44: DC510034 077C0000
	v_fma_mixlo_f16 v5, v5, s39, 0                             // 0000001E5F4C: CC210005 02004F05
	v_cndmask_b16 v99, 0, v6, s0                               // 0000001E5F54: D65D4063 00020C80
	scratch_load_b32 v6, off, off offset:48                    // 0000001E5F5C: DC510030 067C0000
	s_or_b32 s0, s42, 54                                       // 0000001E5F64: 8C00B62A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001E5F68: BF870009
	s_cmp_lt_i32 s0, s47                                       // 0000001E5F6C: BF042F00
	s_cselect_b32 s0, -1, 0                                    // 0000001E5F70: 980080C1
	s_or_b32 s1, s42, 55                                       // 0000001E5F74: 8C01B72A
	v_cndmask_b16 v100, 0, v5, s0                              // 0000001E5F78: D65D0064 00020A80
	s_cmp_lt_i32 s1, s47                                       // 0000001E5F80: BF042F01
	s_cselect_b32 s1, -1, 0                                    // 0000001E5F84: 980180C1
	s_or_b32 s8, s42, 56                                       // 0000001E5F88: 8C08B82A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001E5F8C: BF870009
	s_cmp_lt_i32 s8, s47                                       // 0000001E5F90: BF042F08
	s_cselect_b32 s0, -1, 0                                    // 0000001E5F94: 980080C1
	s_waitcnt vmcnt(2)                                         // 0000001E5F98: BF890BF7
	v_mul_f32_e32 v21, v21, v30                                // 0000001E5F9C: 102A3D15
	s_waitcnt vmcnt(0)                                         // 0000001E5FA0: BF8903F7
	v_dual_mul_f32 v7, v7, v26 :: v_dual_mul_f32 v6, v6, v8    // 0000001E5FA4: C8C63507 07061106
	v_mul_f32_e32 v8, v176, v28                                // 0000001E5FAC: 101039B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001E5FB0: BF870122
	v_fma_mixhi_f16 v5, v6, s39, 0                             // 0000001E5FB4: CC220005 02004F06
	v_mul_f32_e32 v6, v222, v25                                // 0000001E5FBC: 100C33DE
	v_cndmask_b16 v100, 0, v5, s1                              // 0000001E5FC0: D65D5064 00060A80
	v_mul_f32_e32 v5, v221, v24                                // 0000001E5FC8: 100A31DD
	s_or_b32 s1, s42, 57                                       // 0000001E5FCC: 8C01B92A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001E5FD0: BF870099
	s_cmp_lt_i32 s1, s47                                       // 0000001E5FD4: BF042F01
	v_fma_mixlo_f16 v5, v5, s39, 0                             // 0000001E5FD8: CC210005 02004F05
	s_cselect_b32 s1, -1, 0                                    // 0000001E5FE0: 980180C1
	s_or_b32 s8, s42, 58                                       // 0000001E5FE4: 8C08BA2A
	v_fma_mixhi_f16 v5, v6, s39, 0                             // 0000001E5FE8: CC220005 02004F06
	v_fma_mixlo_f16 v6, v7, s39, 0                             // 0000001E5FF0: CC210006 02004F07
	s_cmp_lt_i32 s8, s47                                       // 0000001E5FF8: BF042F08
	v_cndmask_b16 v5, 0, v5, s0                                // 0000001E5FFC: D65D0005 00020A80
	s_cselect_b32 s0, -1, 0                                    // 0000001E6004: 980080C1
	v_mul_f32_e32 v7, v172, v27                                // 0000001E6008: 100E37AC
	v_cndmask_b16 v6, 0, v6, s0                                // 0000001E600C: D65D0006 00020C80
	s_or_b32 s0, s42, 59                                       // 0000001E6014: 8C00BB2A
	v_cndmask_b16 v5, 0, v5, s1                                // 0000001E6018: D65D5005 00060A80
	s_cmp_lt_i32 s0, s47                                       // 0000001E6020: BF042F00
	v_fma_mixhi_f16 v6, v7, s39, 0                             // 0000001E6024: CC220006 02004F07
	s_cselect_b32 s0, -1, 0                                    // 0000001E602C: 980080C1
	s_or_b32 s1, s42, 60                                       // 0000001E6030: 8C01BC2A
	v_fma_mixlo_f16 v7, v8, s39, 0                             // 0000001E6034: CC210007 02004F08
	s_cmp_lt_i32 s1, s47                                       // 0000001E603C: BF042F01
	v_mul_f32_e32 v8, v177, v29                                // 0000001E6040: 10103BB1
	s_cselect_b32 s1, -1, 0                                    // 0000001E6044: 980180C1
	s_or_b32 s8, s42, 61                                       // 0000001E6048: 8C08BD2A
	v_cndmask_b16 v6, 0, v6, s0                                // 0000001E604C: D65D5006 00020C80
	s_cmp_lt_i32 s8, s47                                       // 0000001E6054: BF042F08
	v_cndmask_b16 v7, 0, v7, s1                                // 0000001E6058: D65D0007 00060E80
	s_cselect_b32 s0, -1, 0                                    // 0000001E6060: 980080C1
	s_or_b32 s1, s42, 62                                       // 0000001E6064: 8C01BE2A
	v_fma_mixhi_f16 v7, v8, s39, 0                             // 0000001E6068: CC220007 02004F08
	s_cmp_lt_i32 s1, s47                                       // 0000001E6070: BF042F01
	v_fma_mixlo_f16 v8, v21, s39, 0                            // 0000001E6074: CC210008 02004F15
	s_cselect_b32 s1, -1, 0                                    // 0000001E607C: 980180C1
	s_or_b32 s8, s42, 63                                       // 0000001E6080: 8C08BF2A
	v_fma_mixhi_f16 v8, v22, s39, 0                            // 0000001E6084: CC220008 02004F16
	s_cmp_lt_i32 s8, s47                                       // 0000001E608C: BF042F08
	v_cndmask_b16 v7, 0, v7, s0                                // 0000001E6090: D65D5007 00020E80
	s_cselect_b32 s0, -1, 0                                    // 0000001E6098: 980080C1
	v_cndmask_b16 v8, 0, v8, s1                                // 0000001E609C: D65D0008 00061080
	v_cndmask_b16 v8, 0, v8, s0                                // 0000001E60A4: D65D5008 00021080
	ds_store_b128 v182, v[97:100] offset:96                    // 0000001E60AC: DB7C0060 000061B6
	ds_store_b128 v182, v[5:8] offset:112                      // 0000001E60B4: DB7C0070 000005B6
	s_clause 0x7                                               // 0000001E60BC: BF850007
	global_load_b128 v[25:28], v[101:102], off offset:128      // 0000001E60C0: DC5E0080 197C0065
	global_load_b128 v[29:32], v[101:102], off offset:144      // 0000001E60C8: DC5E0090 1D7C0065
	global_load_b128 v[17:20], v[101:102], off offset:160      // 0000001E60D0: DC5E00A0 117C0065
	global_load_b128 v[21:24], v[101:102], off offset:176      // 0000001E60D8: DC5E00B0 157C0065
	global_load_b128 v[9:12], v[101:102], off offset:192       // 0000001E60E0: DC5E00C0 097C0065
	global_load_b128 v[13:16], v[101:102], off offset:208      // 0000001E60E8: DC5E00D0 0D7C0065
	global_load_b128 v[1:4], v[101:102], off offset:224        // 0000001E60F0: DC5E00E0 017C0065
	global_load_b128 v[5:8], v[101:102], off offset:240        // 0000001E60F8: DC5E00F0 057C0065
	s_and_saveexec_b32 s0, vcc_lo                              // 0000001E6100: BE80206A
	s_cbranch_execz 73                                         // 0000001E6104: BFA50049 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x202c>
	v_mov_b32_e32 v121, 0                                      // 0000001E6108: 7EF20280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E610C: BF870001
	v_mov_b32_e32 v122, v121                                   // 0000001E6110: 7EF40379
	v_mov_b32_e32 v123, v121                                   // 0000001E6114: 7EF60379
	v_mov_b32_e32 v124, v121                                   // 0000001E6118: 7EF80379
	v_mov_b32_e32 v125, v121                                   // 0000001E611C: 7EFA0379
	v_mov_b32_e32 v126, v121                                   // 0000001E6120: 7EFC0379
	v_mov_b32_e32 v127, v121                                   // 0000001E6124: 7EFE0379
	v_mov_b32_e32 v128, v121                                   // 0000001E6128: 7F000379
	v_mov_b32_e32 v105, v121                                   // 0000001E612C: 7ED20379
	v_mov_b32_e32 v106, v121                                   // 0000001E6130: 7ED40379
	v_mov_b32_e32 v107, v121                                   // 0000001E6134: 7ED60379
	v_mov_b32_e32 v108, v121                                   // 0000001E6138: 7ED80379
	v_mov_b32_e32 v109, v121                                   // 0000001E613C: 7EDA0379
	v_mov_b32_e32 v110, v121                                   // 0000001E6140: 7EDC0379
	v_mov_b32_e32 v111, v121                                   // 0000001E6144: 7EDE0379
	v_mov_b32_e32 v112, v121                                   // 0000001E6148: 7EE00379
	v_mov_b32_e32 v41, v121                                    // 0000001E614C: 7E520379
	v_mov_b32_e32 v42, v121                                    // 0000001E6150: 7E540379
	v_mov_b32_e32 v43, v121                                    // 0000001E6154: 7E560379
	v_mov_b32_e32 v44, v121                                    // 0000001E6158: 7E580379
	v_mov_b32_e32 v45, v121                                    // 0000001E615C: 7E5A0379
	v_mov_b32_e32 v46, v121                                    // 0000001E6160: 7E5C0379
	v_mov_b32_e32 v47, v121                                    // 0000001E6164: 7E5E0379
	v_mov_b32_e32 v48, v121                                    // 0000001E6168: 7E600379
	v_mov_b32_e32 v33, v121                                    // 0000001E616C: 7E420379
	v_mov_b32_e32 v34, v121                                    // 0000001E6170: 7E440379
	v_mov_b32_e32 v35, v121                                    // 0000001E6174: 7E460379
	v_mov_b32_e32 v36, v121                                    // 0000001E6178: 7E480379
	v_mov_b32_e32 v37, v121                                    // 0000001E617C: 7E4A0379
	v_mov_b32_e32 v38, v121                                    // 0000001E6180: 7E4C0379
	v_mov_b32_e32 v39, v121                                    // 0000001E6184: 7E4E0379
	v_mov_b32_e32 v40, v121                                    // 0000001E6188: 7E500379
	s_waitcnt vmcnt(7)                                         // 0000001E618C: BF891FF7
	v_mov_b32_e32 v25, v121                                    // 0000001E6190: 7E320379
	v_mov_b32_e32 v26, v121                                    // 0000001E6194: 7E340379
	v_mov_b32_e32 v27, v121                                    // 0000001E6198: 7E360379
	v_mov_b32_e32 v28, v121                                    // 0000001E619C: 7E380379
	s_waitcnt vmcnt(6)                                         // 0000001E61A0: BF891BF7
	v_mov_b32_e32 v29, v121                                    // 0000001E61A4: 7E3A0379
	v_mov_b32_e32 v30, v121                                    // 0000001E61A8: 7E3C0379
	v_mov_b32_e32 v31, v121                                    // 0000001E61AC: 7E3E0379
	v_mov_b32_e32 v32, v121                                    // 0000001E61B0: 7E400379
	s_waitcnt vmcnt(5)                                         // 0000001E61B4: BF8917F7
	v_mov_b32_e32 v17, v121                                    // 0000001E61B8: 7E220379
	v_mov_b32_e32 v18, v121                                    // 0000001E61BC: 7E240379
	v_mov_b32_e32 v19, v121                                    // 0000001E61C0: 7E260379
	v_mov_b32_e32 v20, v121                                    // 0000001E61C4: 7E280379
	s_waitcnt vmcnt(4)                                         // 0000001E61C8: BF8913F7
	v_mov_b32_e32 v21, v121                                    // 0000001E61CC: 7E2A0379
	v_mov_b32_e32 v22, v121                                    // 0000001E61D0: 7E2C0379
	v_mov_b32_e32 v23, v121                                    // 0000001E61D4: 7E2E0379
	v_mov_b32_e32 v24, v121                                    // 0000001E61D8: 7E300379
	s_waitcnt vmcnt(3)                                         // 0000001E61DC: BF890FF7
	v_mov_b32_e32 v9, v121                                     // 0000001E61E0: 7E120379
	v_mov_b32_e32 v10, v121                                    // 0000001E61E4: 7E140379
	v_mov_b32_e32 v11, v121                                    // 0000001E61E8: 7E160379
	v_mov_b32_e32 v12, v121                                    // 0000001E61EC: 7E180379
	s_waitcnt vmcnt(2)                                         // 0000001E61F0: BF890BF7
	v_mov_b32_e32 v13, v121                                    // 0000001E61F4: 7E1A0379
	v_mov_b32_e32 v14, v121                                    // 0000001E61F8: 7E1C0379
	v_mov_b32_e32 v15, v121                                    // 0000001E61FC: 7E1E0379
	v_mov_b32_e32 v16, v121                                    // 0000001E6200: 7E200379
	s_waitcnt vmcnt(1)                                         // 0000001E6204: BF8907F7
	v_mov_b32_e32 v1, v121                                     // 0000001E6208: 7E020379
	v_mov_b32_e32 v2, v121                                     // 0000001E620C: 7E040379
	v_mov_b32_e32 v3, v121                                     // 0000001E6210: 7E060379
	v_mov_b32_e32 v4, v121                                     // 0000001E6214: 7E080379
	s_waitcnt vmcnt(0)                                         // 0000001E6218: BF8903F7
	v_mov_b32_e32 v5, v121                                     // 0000001E621C: 7E0A0379
	v_mov_b32_e32 v6, v121                                     // 0000001E6220: 7E0C0379
	v_mov_b32_e32 v7, v121                                     // 0000001E6224: 7E0E0379
	v_mov_b32_e32 v8, v121                                     // 0000001E6228: 7E100379
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001E622C: 8C7E007E
	ds_load_b128 v[97:100], v183                               // 0000001E6230: DBFC0000 610000B7
	ds_load_b128 v[101:104], v183 offset:16                    // 0000001E6238: DBFC0010 650000B7
	ds_load_b128 v[113:116], v183 offset:32                    // 0000001E6240: DBFC0020 710000B7
	ds_load_b128 v[117:120], v183 offset:48                    // 0000001E6248: DBFC0030 750000B7
	ds_load_b128 v[129:132], v183 offset:8448                  // 0000001E6250: DBFC2100 810000B7
	ds_load_b128 v[133:136], v183 offset:8464                  // 0000001E6258: DBFC2110 850000B7
	ds_load_b128 v[137:140], v183 offset:8480                  // 0000001E6260: DBFC2120 890000B7
	ds_load_b128 v[141:144], v183 offset:8496                  // 0000001E6268: DBFC2130 8D0000B7
	ds_load_b128 v[187:190], v183 offset:16896                 // 0000001E6270: DBFC4200 BB0000B7
	v_dual_mov_b32 v210, s27 :: v_dual_mov_b32 v209, s26       // 0000001E6278: CA10001B D2D0001A
	v_dual_mov_b32 v208, s25 :: v_dual_mov_b32 v207, s24       // 0000001E6280: CA100019 D0CE0018
	v_dual_mov_b32 v206, s23 :: v_dual_mov_b32 v205, s22       // 0000001E6288: CA100017 CECC0016
	v_dual_mov_b32 v204, s21 :: v_dual_mov_b32 v203, s20       // 0000001E6290: CA100015 CCCA0014
	s_mul_i32 s0, s40, 48                                      // 0000001E6298: 9600B028
	s_mul_hi_u32 s1, s40, 48                                   // 0000001E629C: 9681B028
	s_add_u32 s0, s0, s2                                       // 0000001E62A0: 80000200
	s_waitcnt lgkmcnt(8)                                       // 0000001E62A4: BF89FC87
	v_fma_mixlo_f16 v97, v97, s39, 0                           // 0000001E62A8: CC210061 02004F61
	v_fma_mixhi_f16 v97, v98, s39, 0                           // 0000001E62B0: CC220061 02004F62
	v_fma_mixlo_f16 v98, v99, s39, 0                           // 0000001E62B8: CC210062 02004F63
	s_waitcnt lgkmcnt(7)                                       // 0000001E62C0: BF89FC77
	v_fma_mixlo_f16 v99, v101, s39, 0                          // 0000001E62C4: CC210063 02004F65
	s_waitcnt lgkmcnt(6)                                       // 0000001E62CC: BF89FC67
	v_fma_mixlo_f16 v101, v113, s39, 0                         // 0000001E62D0: CC210065 02004F71
	v_fma_mixhi_f16 v101, v114, s39, 0                         // 0000001E62D8: CC220065 02004F72
	s_waitcnt lgkmcnt(4)                                       // 0000001E62E0: BF89FC47
	v_fma_mixlo_f16 v113, v129, s39, 0                         // 0000001E62E4: CC210071 02004F81
	v_fma_mixhi_f16 v113, v130, s39, 0                         // 0000001E62EC: CC220071 02004F82
	v_fma_mixlo_f16 v114, v131, s39, 0                         // 0000001E62F4: CC210072 02004F83
	v_fma_mixhi_f16 v114, v132, s39, 0                         // 0000001E62FC: CC220072 02004F84
	ds_load_b128 v[129:132], v183 offset:16912                 // 0000001E6304: DBFC4210 810000B7
	v_fma_mixhi_f16 v98, v100, s39, 0                          // 0000001E630C: CC220062 02004F64
	v_fma_mixhi_f16 v99, v102, s39, 0                          // 0000001E6314: CC220063 02004F66
	v_fma_mixhi_f16 v100, v104, s39, 0                         // 0000001E631C: CC220064 02004F68
	v_fma_mixlo_f16 v102, v115, s39, 0                         // 0000001E6324: CC210066 02004F73
	v_fma_mixhi_f16 v102, v116, s39, 0                         // 0000001E632C: CC220066 02004F74
	v_fma_mixlo_f16 v104, v119, s39, 0                         // 0000001E6334: CC210068 02004F77
	v_fma_mixhi_f16 v104, v120, s39, 0                         // 0000001E633C: CC220068 02004F78
	s_waitcnt lgkmcnt(4)                                       // 0000001E6344: BF89FC47
	v_fma_mixlo_f16 v115, v133, s39, 0                         // 0000001E6348: CC210073 02004F85
	v_fma_mixhi_f16 v115, v134, s39, 0                         // 0000001E6350: CC220073 02004F86
	v_fma_mixlo_f16 v116, v135, s39, 0                         // 0000001E6358: CC210074 02004F87
	v_fma_mixhi_f16 v116, v136, s39, 0                         // 0000001E6360: CC220074 02004F88
	s_waitcnt lgkmcnt(2)                                       // 0000001E6368: BF89FC27
	v_fma_mixlo_f16 v119, v141, s39, 0                         // 0000001E636C: CC210077 02004F8D
	ds_load_b128 v[133:136], v183 offset:16928                 // 0000001E6374: DBFC4220 850000B7
	v_fma_mixhi_f16 v119, v142, s39, 0                         // 0000001E637C: CC220077 02004F8E
	v_fma_mixlo_f16 v120, v143, s39, 0                         // 0000001E6384: CC210078 02004F8F
	v_fma_mixhi_f16 v120, v144, s39, 0                         // 0000001E638C: CC220078 02004F90
	s_waitcnt lgkmcnt(2)                                       // 0000001E6394: BF89FC27
	v_fma_mixlo_f16 v187, v187, s39, 0                         // 0000001E6398: CC2100BB 02004FBB
	v_fma_mixhi_f16 v187, v188, s39, 0                         // 0000001E63A0: CC2200BB 02004FBC
	v_fma_mixlo_f16 v188, v189, s39, 0                         // 0000001E63A8: CC2100BC 02004FBD
	v_fma_mixhi_f16 v188, v190, s39, 0                         // 0000001E63B0: CC2200BC 02004FBE
	ds_load_b128 v[141:144], v183 offset:25344                 // 0000001E63B8: DBFC6300 8D0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E63C0: BF89FC27
	v_fma_mixlo_f16 v189, v129, s39, 0                         // 0000001E63C4: CC2100BD 02004F81
	v_fma_mixhi_f16 v189, v130, s39, 0                         // 0000001E63CC: CC2200BD 02004F82
	v_fma_mixlo_f16 v190, v131, s39, 0                         // 0000001E63D4: CC2100BE 02004F83
	v_fma_mixhi_f16 v190, v132, s39, 0                         // 0000001E63DC: CC2200BE 02004F84
	ds_load_b128 v[129:132], v183 offset:25360                 // 0000001E63E4: DBFC6310 810000B7
	v_fma_mixlo_f16 v100, v103, s39, 0                         // 0000001E63EC: CC210064 02004F67
	v_fma_mixlo_f16 v103, v117, s39, 0                         // 0000001E63F4: CC210067 02004F75
	v_fma_mixhi_f16 v103, v118, s39, 0                         // 0000001E63FC: CC220067 02004F76
	v_fma_mixlo_f16 v117, v137, s39, 0                         // 0000001E6404: CC210075 02004F89
	v_fma_mixhi_f16 v117, v138, s39, 0                         // 0000001E640C: CC220075 02004F8A
	v_fma_mixlo_f16 v118, v139, s39, 0                         // 0000001E6414: CC210076 02004F8B
	v_fma_mixhi_f16 v118, v140, s39, 0                         // 0000001E641C: CC220076 02004F8C
	ds_load_b128 v[137:140], v183 offset:16944                 // 0000001E6424: DBFC4230 890000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E642C: BF89FC37
	v_fma_mixlo_f16 v191, v133, s39, 0                         // 0000001E6430: CC2100BF 02004F85
	v_fma_mixhi_f16 v191, v134, s39, 0                         // 0000001E6438: CC2200BF 02004F86
	v_fma_mixlo_f16 v192, v135, s39, 0                         // 0000001E6440: CC2100C0 02004F87
	v_fma_mixhi_f16 v192, v136, s39, 0                         // 0000001E6448: CC2200C0 02004F88
	ds_load_b128 v[133:136], v183 offset:25376                 // 0000001E6450: DBFC6320 850000B7
	s_addc_u32 s1, s1, s3                                      // 0000001E6458: 82010301
	s_waitcnt lgkmcnt(3)                                       // 0000001E645C: BF89FC37
	v_fma_mixlo_f16 v195, v141, s39, 0                         // 0000001E6460: CC2100C3 02004F8D
	v_fma_mixhi_f16 v195, v142, s39, 0                         // 0000001E6468: CC2200C3 02004F8E
	v_fma_mixlo_f16 v196, v143, s39, 0                         // 0000001E6470: CC2100C4 02004F8F
	v_fma_mixhi_f16 v196, v144, s39, 0                         // 0000001E6478: CC2200C4 02004F90
	s_lshl_b64 s[0:1], s[0:1], 13                              // 0000001E6480: 84808D00
	s_waitcnt lgkmcnt(2)                                       // 0000001E6484: BF89FC27
	v_fma_mixlo_f16 v197, v129, s39, 0                         // 0000001E6488: CC2100C5 02004F81
	v_fma_mixhi_f16 v197, v130, s39, 0                         // 0000001E6490: CC2200C5 02004F82
	v_fma_mixlo_f16 v198, v131, s39, 0                         // 0000001E6498: CC2100C6 02004F83
	v_fma_mixhi_f16 v198, v132, s39, 0                         // 0000001E64A0: CC2200C6 02004F84
	ds_load_b128 v[129:132], v183 offset:25392                 // 0000001E64A8: DBFC6330 810000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E64B0: BF89FC27
	v_fma_mixlo_f16 v193, v137, s39, 0                         // 0000001E64B4: CC2100C1 02004F89
	v_fma_mixhi_f16 v193, v138, s39, 0                         // 0000001E64BC: CC2200C1 02004F8A
	v_fma_mixlo_f16 v194, v139, s39, 0                         // 0000001E64C4: CC2100C2 02004F8B
	v_fma_mixhi_f16 v194, v140, s39, 0                         // 0000001E64CC: CC2200C2 02004F8C
	v_wmma_f32_16x16x16_f16 v[137:144], v[153:160], v[97:104], v[203:210]// 0000001E64D4: CC404089 1F2EC399
	s_waitcnt lgkmcnt(1)                                       // 0000001E64DC: BF89FC17
	v_fma_mixlo_f16 v199, v133, s39, 0                         // 0000001E64E0: CC2100C7 02004F85
	v_fma_mixhi_f16 v199, v134, s39, 0                         // 0000001E64E8: CC2200C7 02004F86
	v_fma_mixlo_f16 v200, v135, s39, 0                         // 0000001E64F0: CC2100C8 02004F87
	v_fma_mixhi_f16 v200, v136, s39, 0                         // 0000001E64F8: CC2200C8 02004F88
	s_waitcnt lgkmcnt(0)                                       // 0000001E6500: BF89FC07
	v_fma_mixlo_f16 v201, v129, s39, 0                         // 0000001E6504: CC2100C9 02004F81
	v_fma_mixhi_f16 v201, v130, s39, 0                         // 0000001E650C: CC2200C9 02004F82
	v_fma_mixlo_f16 v202, v131, s39, 0                         // 0000001E6514: CC2100CA 02004F83
	v_fma_mixhi_f16 v202, v132, s39, 0                         // 0000001E651C: CC2200CA 02004F84
	v_wmma_f32_16x16x16_f16 v[129:136], v[153:160], v[113:120], v[203:210]// 0000001E6524: CC404081 1F2EE399
	v_wmma_f32_16x16x16_f16 v[113:120], v[153:160], v[187:194], v[203:210]// 0000001E652C: CC404071 1F2F7799
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001E6534: BF870003
	v_wmma_f32_16x16x16_f16 v[97:104], v[153:160], v[195:202], v[203:210]// 0000001E6538: CC404061 1F2F8799
	ds_load_b128 v[153:156], v183 offset:64                    // 0000001E6540: DBFC0040 990000B7
	ds_load_b128 v[157:160], v183 offset:80                    // 0000001E6548: DBFC0050 9D0000B7
	ds_load_b128 v[187:190], v183 offset:96                    // 0000001E6550: DBFC0060 BB0000B7
	ds_load_b128 v[191:194], v183 offset:112                   // 0000001E6558: DBFC0070 BF0000B7
	ds_load_b128 v[201:204], v183 offset:25824                 // 0000001E6560: DBFC64E0 C90000B7
	ds_load_b128 v[195:198], v183 offset:17200                 // 0000001E6568: DBFC4330 C30000B7
	s_waitcnt lgkmcnt(5)                                       // 0000001E6570: BF89FC57
	v_fma_mixlo_f16 v153, v153, s39, 0                         // 0000001E6574: CC210099 02004F99
	v_fma_mixhi_f16 v153, v154, s39, 0                         // 0000001E657C: CC220099 02004F9A
	v_fma_mixlo_f16 v154, v155, s39, 0                         // 0000001E6584: CC21009A 02004F9B
	s_waitcnt lgkmcnt(4)                                       // 0000001E658C: BF89FC47
	v_fma_mixlo_f16 v155, v157, s39, 0                         // 0000001E6590: CC21009B 02004F9D
	v_fma_mixhi_f16 v155, v158, s39, 0                         // 0000001E6598: CC22009B 02004F9E
	s_waitcnt lgkmcnt(3)                                       // 0000001E65A0: BF89FC37
	v_fma_mixlo_f16 v157, v187, s39, 0                         // 0000001E65A4: CC21009D 02004FBB
	v_fma_mixhi_f16 v157, v188, s39, 0                         // 0000001E65AC: CC22009D 02004FBC
	v_fma_mixlo_f16 v158, v189, s39, 0                         // 0000001E65B4: CC21009E 02004FBD
	v_fma_mixhi_f16 v158, v190, s39, 0                         // 0000001E65BC: CC22009E 02004FBE
	ds_load_b128 v[187:190], v183 offset:8512                  // 0000001E65C4: DBFC2140 BB0000B7
	v_fma_mixhi_f16 v154, v156, s39, 0                         // 0000001E65CC: CC22009A 02004F9C
	v_fma_mixlo_f16 v156, v159, s39, 0                         // 0000001E65D4: CC21009C 02004F9F
	v_fma_mixhi_f16 v156, v160, s39, 0                         // 0000001E65DC: CC22009C 02004FA0
	s_waitcnt lgkmcnt(3)                                       // 0000001E65E4: BF89FC37
	v_fma_mixlo_f16 v159, v191, s39, 0                         // 0000001E65E8: CC21009F 02004FBF
	v_fma_mixhi_f16 v159, v192, s39, 0                         // 0000001E65F0: CC22009F 02004FC0
	v_fma_mixlo_f16 v160, v193, s39, 0                         // 0000001E65F8: CC2100A0 02004FC1
	v_fma_mixhi_f16 v160, v194, s39, 0                         // 0000001E6600: CC2200A0 02004FC2
	ds_load_b128 v[191:194], v183 offset:8528                  // 0000001E6608: DBFC2150 BF0000B7
	v_wmma_f32_16x16x16_f16 v[137:144], v[145:152], v[153:160], v[137:144]// 0000001E6610: CC404089 1E273391
	ds_load_b128 v[157:160], v183 offset:8544                  // 0000001E6618: DBFC2160 9D0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E6620: BF89FC27
	v_fma_mixlo_f16 v153, v187, s39, 0                         // 0000001E6624: CC210099 02004FBB
	v_fma_mixhi_f16 v153, v188, s39, 0                         // 0000001E662C: CC220099 02004FBC
	v_fma_mixlo_f16 v154, v189, s39, 0                         // 0000001E6634: CC21009A 02004FBD
	v_fma_mixhi_f16 v154, v190, s39, 0                         // 0000001E663C: CC22009A 02004FBE
	ds_load_b128 v[187:190], v183 offset:8560                  // 0000001E6644: DBFC2170 BB0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E664C: BF89FC27
	v_fma_mixlo_f16 v155, v191, s39, 0                         // 0000001E6650: CC21009B 02004FBF
	v_fma_mixhi_f16 v155, v192, s39, 0                         // 0000001E6658: CC22009B 02004FC0
	v_fma_mixlo_f16 v156, v193, s39, 0                         // 0000001E6660: CC21009C 02004FC1
	v_fma_mixhi_f16 v156, v194, s39, 0                         // 0000001E6668: CC22009C 02004FC2
	ds_load_b128 v[191:194], v183 offset:16960                 // 0000001E6670: DBFC4240 BF0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E6678: BF89FC27
	v_fma_mixlo_f16 v157, v157, s39, 0                         // 0000001E667C: CC21009D 02004F9D
	v_fma_mixhi_f16 v157, v158, s39, 0                         // 0000001E6684: CC22009D 02004F9E
	v_fma_mixlo_f16 v158, v159, s39, 0                         // 0000001E668C: CC21009E 02004F9F
	v_fma_mixhi_f16 v158, v160, s39, 0                         // 0000001E6694: CC22009E 02004FA0
	s_waitcnt lgkmcnt(1)                                       // 0000001E669C: BF89FC17
	v_fma_mixlo_f16 v159, v187, s39, 0                         // 0000001E66A0: CC21009F 02004FBB
	v_fma_mixhi_f16 v159, v188, s39, 0                         // 0000001E66A8: CC22009F 02004FBC
	v_fma_mixlo_f16 v160, v189, s39, 0                         // 0000001E66B0: CC2100A0 02004FBD
	v_fma_mixhi_f16 v160, v190, s39, 0                         // 0000001E66B8: CC2200A0 02004FBE
	ds_load_b128 v[187:190], v183 offset:16976                 // 0000001E66C0: DBFC4250 BB0000B7
	v_wmma_f32_16x16x16_f16 v[129:136], v[145:152], v[153:160], v[129:136]// 0000001E66C8: CC404081 1E073391
	ds_load_b128 v[157:160], v183 offset:16992                 // 0000001E66D0: DBFC4260 9D0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E66D8: BF89FC27
	v_fma_mixlo_f16 v153, v191, s39, 0                         // 0000001E66DC: CC210099 02004FBF
	v_fma_mixhi_f16 v153, v192, s39, 0                         // 0000001E66E4: CC220099 02004FC0
	v_fma_mixlo_f16 v154, v193, s39, 0                         // 0000001E66EC: CC21009A 02004FC1
	v_fma_mixhi_f16 v154, v194, s39, 0                         // 0000001E66F4: CC22009A 02004FC2
	ds_load_b128 v[191:194], v183 offset:25408                 // 0000001E66FC: DBFC6340 BF0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E6704: BF89FC27
	v_fma_mixlo_f16 v155, v187, s39, 0                         // 0000001E6708: CC21009B 02004FBB
	v_fma_mixhi_f16 v155, v188, s39, 0                         // 0000001E6710: CC22009B 02004FBC
	v_fma_mixlo_f16 v156, v189, s39, 0                         // 0000001E6718: CC21009C 02004FBD
	v_fma_mixhi_f16 v156, v190, s39, 0                         // 0000001E6720: CC22009C 02004FBE
	ds_load_b128 v[187:190], v183 offset:17008                 // 0000001E6728: DBFC4270 BB0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E6730: BF89FC27
	v_fma_mixlo_f16 v157, v157, s39, 0                         // 0000001E6734: CC21009D 02004F9D
	v_fma_mixhi_f16 v157, v158, s39, 0                         // 0000001E673C: CC22009D 02004F9E
	v_fma_mixlo_f16 v158, v159, s39, 0                         // 0000001E6744: CC21009E 02004F9F
	v_fma_mixhi_f16 v158, v160, s39, 0                         // 0000001E674C: CC22009E 02004FA0
	s_waitcnt lgkmcnt(0)                                       // 0000001E6754: BF89FC07
	v_fma_mixlo_f16 v159, v187, s39, 0                         // 0000001E6758: CC21009F 02004FBB
	v_fma_mixhi_f16 v159, v188, s39, 0                         // 0000001E6760: CC22009F 02004FBC
	v_fma_mixlo_f16 v160, v189, s39, 0                         // 0000001E6768: CC2100A0 02004FBD
	v_fma_mixhi_f16 v160, v190, s39, 0                         // 0000001E6770: CC2200A0 02004FBE
	ds_load_b128 v[187:190], v183 offset:25424                 // 0000001E6778: DBFC6350 BB0000B7
	v_wmma_f32_16x16x16_f16 v[113:120], v[145:152], v[153:160], v[113:120]// 0000001E6780: CC404071 1DC73391
	ds_load_b128 v[157:160], v183 offset:25440                 // 0000001E6788: DBFC6360 9D0000B7
	v_fma_mixlo_f16 v153, v191, s39, 0                         // 0000001E6790: CC210099 02004FBF
	v_fma_mixhi_f16 v153, v192, s39, 0                         // 0000001E6798: CC220099 02004FC0
	v_fma_mixlo_f16 v154, v193, s39, 0                         // 0000001E67A0: CC21009A 02004FC1
	v_fma_mixhi_f16 v154, v194, s39, 0                         // 0000001E67A8: CC22009A 02004FC2
	ds_load_b128 v[191:194], v183 offset:128                   // 0000001E67B0: DBFC0080 BF0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E67B8: BF89FC27
	v_fma_mixlo_f16 v155, v187, s39, 0                         // 0000001E67BC: CC21009B 02004FBB
	v_fma_mixhi_f16 v155, v188, s39, 0                         // 0000001E67C4: CC22009B 02004FBC
	v_fma_mixlo_f16 v156, v189, s39, 0                         // 0000001E67CC: CC21009C 02004FBD
	v_fma_mixhi_f16 v156, v190, s39, 0                         // 0000001E67D4: CC22009C 02004FBE
	ds_load_b128 v[187:190], v183 offset:25456                 // 0000001E67DC: DBFC6370 BB0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E67E4: BF89FC27
	v_fma_mixlo_f16 v157, v157, s39, 0                         // 0000001E67E8: CC21009D 02004F9D
	v_fma_mixhi_f16 v157, v158, s39, 0                         // 0000001E67F0: CC22009D 02004F9E
	v_fma_mixlo_f16 v158, v159, s39, 0                         // 0000001E67F8: CC21009E 02004F9F
	v_fma_mixhi_f16 v158, v160, s39, 0                         // 0000001E6800: CC22009E 02004FA0
	s_waitcnt lgkmcnt(0)                                       // 0000001E6808: BF89FC07
	v_fma_mixlo_f16 v159, v187, s39, 0                         // 0000001E680C: CC21009F 02004FBB
	v_fma_mixhi_f16 v159, v188, s39, 0                         // 0000001E6814: CC22009F 02004FBC
	v_fma_mixlo_f16 v160, v189, s39, 0                         // 0000001E681C: CC2100A0 02004FBD
	v_fma_mixhi_f16 v160, v190, s39, 0                         // 0000001E6824: CC2200A0 02004FBE
	ds_load_b128 v[187:190], v183 offset:144                   // 0000001E682C: DBFC0090 BB0000B7
	v_wmma_f32_16x16x16_f16 v[97:104], v[145:152], v[153:160], v[97:104]// 0000001E6834: CC404061 1D873391
	ds_load_b128 v[149:152], v183 offset:160                   // 0000001E683C: DBFC00A0 950000B7
	ds_load_b128 v[153:156], v183 offset:176                   // 0000001E6844: DBFC00B0 990000B7
	ds_load_b128 v[157:160], v183 offset:8576                  // 0000001E684C: DBFC2180 9D0000B7
	v_fma_mixlo_f16 v145, v191, s39, 0                         // 0000001E6854: CC210091 02004FBF
	v_fma_mixhi_f16 v145, v192, s39, 0                         // 0000001E685C: CC220091 02004FC0
	v_fma_mixlo_f16 v146, v193, s39, 0                         // 0000001E6864: CC210092 02004FC1
	v_fma_mixhi_f16 v146, v194, s39, 0                         // 0000001E686C: CC220092 02004FC2
	ds_load_b128 v[191:194], v183 offset:8608                  // 0000001E6874: DBFC21A0 BF0000B7
	s_waitcnt lgkmcnt(4)                                       // 0000001E687C: BF89FC47
	v_fma_mixlo_f16 v147, v187, s39, 0                         // 0000001E6880: CC210093 02004FBB
	v_fma_mixhi_f16 v147, v188, s39, 0                         // 0000001E6888: CC220093 02004FBC
	v_fma_mixlo_f16 v148, v189, s39, 0                         // 0000001E6890: CC210094 02004FBD
	v_fma_mixhi_f16 v148, v190, s39, 0                         // 0000001E6898: CC220094 02004FBE
	ds_load_b128 v[187:190], v183 offset:8592                  // 0000001E68A0: DBFC2190 BB0000B7
	s_waitcnt lgkmcnt(4)                                       // 0000001E68A8: BF89FC47
	v_fma_mixlo_f16 v149, v149, s39, 0                         // 0000001E68AC: CC210095 02004F95
	v_fma_mixhi_f16 v149, v150, s39, 0                         // 0000001E68B4: CC220095 02004F96
	v_fma_mixlo_f16 v150, v151, s39, 0                         // 0000001E68BC: CC210096 02004F97
	v_fma_mixhi_f16 v150, v152, s39, 0                         // 0000001E68C4: CC220096 02004F98
	s_waitcnt lgkmcnt(3)                                       // 0000001E68CC: BF89FC37
	v_fma_mixlo_f16 v151, v153, s39, 0                         // 0000001E68D0: CC210097 02004F99
	v_fma_mixhi_f16 v151, v154, s39, 0                         // 0000001E68D8: CC220097 02004F9A
	v_fma_mixlo_f16 v152, v155, s39, 0                         // 0000001E68E0: CC210098 02004F9B
	v_fma_mixhi_f16 v152, v156, s39, 0                         // 0000001E68E8: CC220098 02004F9C
	ds_load_b128 v[153:156], v183 offset:8624                  // 0000001E68F0: DBFC21B0 990000B7
	v_wmma_f32_16x16x16_f16 v[137:144], v[89:96], v[145:152], v[137:144]// 0000001E68F8: CC404089 1E272359
	s_waitcnt lgkmcnt(3)                                       // 0000001E6900: BF89FC37
	v_fma_mixlo_f16 v145, v157, s39, 0                         // 0000001E6904: CC210091 02004F9D
	v_fma_mixhi_f16 v145, v158, s39, 0                         // 0000001E690C: CC220091 02004F9E
	v_fma_mixlo_f16 v146, v159, s39, 0                         // 0000001E6914: CC210092 02004F9F
	v_fma_mixhi_f16 v146, v160, s39, 0                         // 0000001E691C: CC220092 02004FA0
	ds_load_b128 v[157:160], v183 offset:17024                 // 0000001E6924: DBFC4280 9D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E692C: BF89FC37
	v_fma_mixlo_f16 v149, v191, s39, 0                         // 0000001E6930: CC210095 02004FBF
	s_waitcnt lgkmcnt(2)                                       // 0000001E6938: BF89FC27
	v_fma_mixlo_f16 v147, v187, s39, 0                         // 0000001E693C: CC210093 02004FBB
	v_fma_mixhi_f16 v147, v188, s39, 0                         // 0000001E6944: CC220093 02004FBC
	v_fma_mixlo_f16 v148, v189, s39, 0                         // 0000001E694C: CC210094 02004FBD
	v_fma_mixhi_f16 v148, v190, s39, 0                         // 0000001E6954: CC220094 02004FBE
	ds_load_b128 v[187:190], v183 offset:17040                 // 0000001E695C: DBFC4290 BB0000B7
	v_fma_mixhi_f16 v149, v192, s39, 0                         // 0000001E6964: CC220095 02004FC0
	v_fma_mixlo_f16 v150, v193, s39, 0                         // 0000001E696C: CC210096 02004FC1
	v_fma_mixhi_f16 v150, v194, s39, 0                         // 0000001E6974: CC220096 02004FC2
	ds_load_b128 v[191:194], v183 offset:17056                 // 0000001E697C: DBFC42A0 BF0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E6984: BF89FC37
	v_fma_mixlo_f16 v151, v153, s39, 0                         // 0000001E6988: CC210097 02004F99
	v_fma_mixhi_f16 v151, v154, s39, 0                         // 0000001E6990: CC220097 02004F9A
	v_fma_mixlo_f16 v152, v155, s39, 0                         // 0000001E6998: CC210098 02004F9B
	v_fma_mixhi_f16 v152, v156, s39, 0                         // 0000001E69A0: CC220098 02004F9C
	ds_load_b128 v[153:156], v183 offset:17072                 // 0000001E69A8: DBFC42B0 990000B7
	v_wmma_f32_16x16x16_f16 v[129:136], v[89:96], v[145:152], v[129:136]// 0000001E69B0: CC404081 1E072359
	s_waitcnt lgkmcnt(3)                                       // 0000001E69B8: BF89FC37
	v_fma_mixlo_f16 v145, v157, s39, 0                         // 0000001E69BC: CC210091 02004F9D
	v_fma_mixhi_f16 v145, v158, s39, 0                         // 0000001E69C4: CC220091 02004F9E
	v_fma_mixlo_f16 v146, v159, s39, 0                         // 0000001E69CC: CC210092 02004F9F
	v_fma_mixhi_f16 v146, v160, s39, 0                         // 0000001E69D4: CC220092 02004FA0
	ds_load_b128 v[157:160], v183 offset:25472                 // 0000001E69DC: DBFC6380 9D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E69E4: BF89FC37
	v_fma_mixlo_f16 v147, v187, s39, 0                         // 0000001E69E8: CC210093 02004FBB
	v_fma_mixhi_f16 v147, v188, s39, 0                         // 0000001E69F0: CC220093 02004FBC
	v_fma_mixlo_f16 v148, v189, s39, 0                         // 0000001E69F8: CC210094 02004FBD
	v_fma_mixhi_f16 v148, v190, s39, 0                         // 0000001E6A00: CC220094 02004FBE
	ds_load_b128 v[187:190], v183 offset:25488                 // 0000001E6A08: DBFC6390 BB0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E6A10: BF89FC37
	v_fma_mixlo_f16 v149, v191, s39, 0                         // 0000001E6A14: CC210095 02004FBF
	v_fma_mixhi_f16 v149, v192, s39, 0                         // 0000001E6A1C: CC220095 02004FC0
	v_fma_mixlo_f16 v150, v193, s39, 0                         // 0000001E6A24: CC210096 02004FC1
	v_fma_mixhi_f16 v150, v194, s39, 0                         // 0000001E6A2C: CC220096 02004FC2
	ds_load_b128 v[191:194], v183 offset:25504                 // 0000001E6A34: DBFC63A0 BF0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E6A3C: BF89FC37
	v_fma_mixlo_f16 v151, v153, s39, 0                         // 0000001E6A40: CC210097 02004F99
	v_fma_mixhi_f16 v151, v154, s39, 0                         // 0000001E6A48: CC220097 02004F9A
	v_fma_mixlo_f16 v152, v155, s39, 0                         // 0000001E6A50: CC210098 02004F9B
	v_fma_mixhi_f16 v152, v156, s39, 0                         // 0000001E6A58: CC220098 02004F9C
	ds_load_b128 v[153:156], v183 offset:25520                 // 0000001E6A60: DBFC63B0 990000B7
	v_wmma_f32_16x16x16_f16 v[113:120], v[89:96], v[145:152], v[113:120]// 0000001E6A68: CC404071 1DC72359
	s_waitcnt lgkmcnt(3)                                       // 0000001E6A70: BF89FC37
	v_fma_mixlo_f16 v145, v157, s39, 0                         // 0000001E6A74: CC210091 02004F9D
	v_fma_mixhi_f16 v145, v158, s39, 0                         // 0000001E6A7C: CC220091 02004F9E
	v_fma_mixlo_f16 v146, v159, s39, 0                         // 0000001E6A84: CC210092 02004F9F
	v_fma_mixhi_f16 v146, v160, s39, 0                         // 0000001E6A8C: CC220092 02004FA0
	ds_load_b128 v[157:160], v183 offset:192                   // 0000001E6A94: DBFC00C0 9D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E6A9C: BF89FC37
	v_fma_mixlo_f16 v147, v187, s39, 0                         // 0000001E6AA0: CC210093 02004FBB
	v_fma_mixhi_f16 v147, v188, s39, 0                         // 0000001E6AA8: CC220093 02004FBC
	v_fma_mixlo_f16 v148, v189, s39, 0                         // 0000001E6AB0: CC210094 02004FBD
	v_fma_mixhi_f16 v148, v190, s39, 0                         // 0000001E6AB8: CC220094 02004FBE
	ds_load_b128 v[187:190], v183 offset:208                   // 0000001E6AC0: DBFC00D0 BB0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E6AC8: BF89FC37
	v_fma_mixlo_f16 v149, v191, s39, 0                         // 0000001E6ACC: CC210095 02004FBF
	v_fma_mixhi_f16 v149, v192, s39, 0                         // 0000001E6AD4: CC220095 02004FC0
	v_fma_mixlo_f16 v150, v193, s39, 0                         // 0000001E6ADC: CC210096 02004FC1
	v_fma_mixhi_f16 v150, v194, s39, 0                         // 0000001E6AE4: CC220096 02004FC2
	ds_load_b128 v[191:194], v183 offset:224                   // 0000001E6AEC: DBFC00E0 BF0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E6AF4: BF89FC37
	v_fma_mixlo_f16 v151, v153, s39, 0                         // 0000001E6AF8: CC210097 02004F99
	v_fma_mixhi_f16 v151, v154, s39, 0                         // 0000001E6B00: CC220097 02004F9A
	v_fma_mixlo_f16 v152, v155, s39, 0                         // 0000001E6B08: CC210098 02004F9B
	v_fma_mixhi_f16 v152, v156, s39, 0                         // 0000001E6B10: CC220098 02004F9C
	ds_load_b128 v[153:156], v183 offset:240                   // 0000001E6B18: DBFC00F0 990000B7
	v_wmma_f32_16x16x16_f16 v[97:104], v[89:96], v[145:152], v[97:104]// 0000001E6B20: CC404061 1D872359
	ds_load_b128 v[145:148], v183 offset:8640                  // 0000001E6B28: DBFC21C0 910000B7
	ds_load_b128 v[149:152], v183 offset:8656                  // 0000001E6B30: DBFC21D0 950000B7
	s_waitcnt lgkmcnt(5)                                       // 0000001E6B38: BF89FC57
	v_fma_mixlo_f16 v89, v157, s39, 0                          // 0000001E6B3C: CC210059 02004F9D
	v_fma_mixhi_f16 v89, v158, s39, 0                          // 0000001E6B44: CC220059 02004F9E
	v_fma_mixlo_f16 v90, v159, s39, 0                          // 0000001E6B4C: CC21005A 02004F9F
	v_fma_mixhi_f16 v90, v160, s39, 0                          // 0000001E6B54: CC22005A 02004FA0
	s_waitcnt lgkmcnt(4)                                       // 0000001E6B5C: BF89FC47
	v_fma_mixlo_f16 v91, v187, s39, 0                          // 0000001E6B60: CC21005B 02004FBB
	v_fma_mixhi_f16 v91, v188, s39, 0                          // 0000001E6B68: CC22005B 02004FBC
	v_fma_mixlo_f16 v92, v189, s39, 0                          // 0000001E6B70: CC21005C 02004FBD
	v_fma_mixhi_f16 v92, v190, s39, 0                          // 0000001E6B78: CC22005C 02004FBE
	ds_load_b128 v[157:160], v183 offset:8672                  // 0000001E6B80: DBFC21E0 9D0000B7
	ds_load_b128 v[187:190], v183 offset:8688                  // 0000001E6B88: DBFC21F0 BB0000B7
	s_waitcnt lgkmcnt(5)                                       // 0000001E6B90: BF89FC57
	v_fma_mixlo_f16 v93, v191, s39, 0                          // 0000001E6B94: CC21005D 02004FBF
	v_fma_mixhi_f16 v93, v192, s39, 0                          // 0000001E6B9C: CC22005D 02004FC0
	v_fma_mixlo_f16 v94, v193, s39, 0                          // 0000001E6BA4: CC21005E 02004FC1
	v_fma_mixhi_f16 v94, v194, s39, 0                          // 0000001E6BAC: CC22005E 02004FC2
	s_waitcnt lgkmcnt(4)                                       // 0000001E6BB4: BF89FC47
	v_fma_mixlo_f16 v95, v153, s39, 0                          // 0000001E6BB8: CC21005F 02004F99
	v_fma_mixhi_f16 v95, v154, s39, 0                          // 0000001E6BC0: CC22005F 02004F9A
	v_fma_mixlo_f16 v96, v155, s39, 0                          // 0000001E6BC8: CC210060 02004F9B
	v_fma_mixhi_f16 v96, v156, s39, 0                          // 0000001E6BD0: CC220060 02004F9C
	s_waitcnt lgkmcnt(3)                                       // 0000001E6BD8: BF89FC37
	v_fma_mixlo_f16 v145, v145, s39, 0                         // 0000001E6BDC: CC210091 02004F91
	v_fma_mixhi_f16 v145, v146, s39, 0                         // 0000001E6BE4: CC220091 02004F92
	v_fma_mixlo_f16 v146, v147, s39, 0                         // 0000001E6BEC: CC210092 02004F93
	v_fma_mixhi_f16 v146, v148, s39, 0                         // 0000001E6BF4: CC220092 02004F94
	ds_load_b128 v[153:156], v183 offset:17088                 // 0000001E6BFC: DBFC42C0 990000B7
	ds_load_b128 v[191:194], v183 offset:17104                 // 0000001E6C04: DBFC42D0 BF0000B7
	s_waitcnt lgkmcnt(4)                                       // 0000001E6C0C: BF89FC47
	v_fma_mixlo_f16 v147, v149, s39, 0                         // 0000001E6C10: CC210093 02004F95
	v_fma_mixhi_f16 v147, v150, s39, 0                         // 0000001E6C18: CC220093 02004F96
	v_fma_mixlo_f16 v148, v151, s39, 0                         // 0000001E6C20: CC210094 02004F97
	v_fma_mixhi_f16 v148, v152, s39, 0                         // 0000001E6C28: CC220094 02004F98
	s_waitcnt lgkmcnt(3)                                       // 0000001E6C30: BF89FC37
	v_fma_mixlo_f16 v149, v157, s39, 0                         // 0000001E6C34: CC210095 02004F9D
	v_fma_mixhi_f16 v149, v158, s39, 0                         // 0000001E6C3C: CC220095 02004F9E
	v_fma_mixlo_f16 v150, v159, s39, 0                         // 0000001E6C44: CC210096 02004F9F
	v_fma_mixhi_f16 v150, v160, s39, 0                         // 0000001E6C4C: CC220096 02004FA0
	ds_load_b128 v[157:160], v183 offset:17120                 // 0000001E6C54: DBFC42E0 9D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E6C5C: BF89FC37
	v_fma_mixlo_f16 v151, v187, s39, 0                         // 0000001E6C60: CC210097 02004FBB
	v_fma_mixhi_f16 v151, v188, s39, 0                         // 0000001E6C68: CC220097 02004FBC
	v_fma_mixlo_f16 v152, v189, s39, 0                         // 0000001E6C70: CC210098 02004FBD
	v_fma_mixhi_f16 v152, v190, s39, 0                         // 0000001E6C78: CC220098 02004FBE
	ds_load_b128 v[187:190], v183 offset:17136                 // 0000001E6C80: DBFC42F0 BB0000B7
	v_wmma_f32_16x16x16_f16 v[137:144], v[81:88], v[89:96], v[137:144]// 0000001E6C88: CC404089 1E26B351
	v_wmma_f32_16x16x16_f16 v[129:136], v[81:88], v[145:152], v[129:136]// 0000001E6C90: CC404081 1E072351
	s_waitcnt lgkmcnt(3)                                       // 0000001E6C98: BF89FC37
	v_fma_mixlo_f16 v89, v153, s39, 0                          // 0000001E6C9C: CC210059 02004F99
	v_fma_mixhi_f16 v89, v154, s39, 0                          // 0000001E6CA4: CC220059 02004F9A
	v_fma_mixlo_f16 v90, v155, s39, 0                          // 0000001E6CAC: CC21005A 02004F9B
	v_fma_mixhi_f16 v90, v156, s39, 0                          // 0000001E6CB4: CC22005A 02004F9C
	ds_load_b128 v[153:156], v183 offset:25536                 // 0000001E6CBC: DBFC63C0 990000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E6CC4: BF89FC37
	v_fma_mixlo_f16 v91, v191, s39, 0                          // 0000001E6CC8: CC21005B 02004FBF
	v_fma_mixhi_f16 v91, v192, s39, 0                          // 0000001E6CD0: CC22005B 02004FC0
	v_fma_mixlo_f16 v92, v193, s39, 0                          // 0000001E6CD8: CC21005C 02004FC1
	v_fma_mixhi_f16 v92, v194, s39, 0                          // 0000001E6CE0: CC22005C 02004FC2
	ds_load_b128 v[191:194], v183 offset:25552                 // 0000001E6CE8: DBFC63D0 BF0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E6CF0: BF89FC37
	v_fma_mixlo_f16 v93, v157, s39, 0                          // 0000001E6CF4: CC21005D 02004F9D
	v_fma_mixhi_f16 v93, v158, s39, 0                          // 0000001E6CFC: CC22005D 02004F9E
	v_fma_mixlo_f16 v94, v159, s39, 0                          // 0000001E6D04: CC21005E 02004F9F
	v_fma_mixhi_f16 v94, v160, s39, 0                          // 0000001E6D0C: CC22005E 02004FA0
	ds_load_b128 v[157:160], v183 offset:25568                 // 0000001E6D14: DBFC63E0 9D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E6D1C: BF89FC37
	v_fma_mixlo_f16 v95, v187, s39, 0                          // 0000001E6D20: CC21005F 02004FBB
	v_fma_mixhi_f16 v95, v188, s39, 0                          // 0000001E6D28: CC22005F 02004FBC
	v_fma_mixlo_f16 v96, v189, s39, 0                          // 0000001E6D30: CC210060 02004FBD
	v_fma_mixhi_f16 v96, v190, s39, 0                          // 0000001E6D38: CC220060 02004FBE
	ds_load_b128 v[187:190], v183 offset:25584                 // 0000001E6D40: DBFC63F0 BB0000B7
	v_wmma_f32_16x16x16_f16 v[113:120], v[81:88], v[89:96], v[113:120]// 0000001E6D48: CC404071 1DC6B351
	s_waitcnt lgkmcnt(3)                                       // 0000001E6D50: BF89FC37
	v_fma_mixlo_f16 v145, v153, s39, 0                         // 0000001E6D54: CC210091 02004F99
	v_fma_mixhi_f16 v145, v154, s39, 0                         // 0000001E6D5C: CC220091 02004F9A
	v_fma_mixlo_f16 v146, v155, s39, 0                         // 0000001E6D64: CC210092 02004F9B
	v_fma_mixhi_f16 v146, v156, s39, 0                         // 0000001E6D6C: CC220092 02004F9C
	ds_load_b128 v[153:156], v183 offset:256                   // 0000001E6D74: DBFC0100 990000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E6D7C: BF89FC37
	v_fma_mixlo_f16 v147, v191, s39, 0                         // 0000001E6D80: CC210093 02004FBF
	v_fma_mixhi_f16 v147, v192, s39, 0                         // 0000001E6D88: CC220093 02004FC0
	v_fma_mixlo_f16 v148, v193, s39, 0                         // 0000001E6D90: CC210094 02004FC1
	v_fma_mixhi_f16 v148, v194, s39, 0                         // 0000001E6D98: CC220094 02004FC2
	ds_load_b128 v[191:194], v183 offset:272                   // 0000001E6DA0: DBFC0110 BF0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E6DA8: BF89FC37
	v_fma_mixlo_f16 v149, v157, s39, 0                         // 0000001E6DAC: CC210095 02004F9D
	v_fma_mixhi_f16 v149, v158, s39, 0                         // 0000001E6DB4: CC220095 02004F9E
	v_fma_mixlo_f16 v150, v159, s39, 0                         // 0000001E6DBC: CC210096 02004F9F
	v_fma_mixhi_f16 v150, v160, s39, 0                         // 0000001E6DC4: CC220096 02004FA0
	ds_load_b128 v[157:160], v183 offset:288                   // 0000001E6DCC: DBFC0120 9D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E6DD4: BF89FC37
	v_fma_mixlo_f16 v151, v187, s39, 0                         // 0000001E6DD8: CC210097 02004FBB
	v_fma_mixhi_f16 v151, v188, s39, 0                         // 0000001E6DE0: CC220097 02004FBC
	v_fma_mixlo_f16 v152, v189, s39, 0                         // 0000001E6DE8: CC210098 02004FBD
	v_fma_mixhi_f16 v152, v190, s39, 0                         // 0000001E6DF0: CC220098 02004FBE
	ds_load_b128 v[187:190], v183 offset:304                   // 0000001E6DF8: DBFC0130 BB0000B7
	ds_load_b128 v[90:93], v183 offset:8704                    // 0000001E6E00: DBFC2200 5A0000B7
	v_wmma_f32_16x16x16_f16 v[97:104], v[81:88], v[145:152], v[97:104]// 0000001E6E08: CC404061 1D872351
	s_waitcnt lgkmcnt(4)                                       // 0000001E6E10: BF89FC47
	v_fma_mixlo_f16 v82, v153, s39, 0                          // 0000001E6E14: CC210052 02004F99
	v_fma_mixhi_f16 v82, v154, s39, 0                          // 0000001E6E1C: CC220052 02004F9A
	v_fma_mixlo_f16 v83, v155, s39, 0                          // 0000001E6E24: CC210053 02004F9B
	v_fma_mixhi_f16 v83, v156, s39, 0                          // 0000001E6E2C: CC220053 02004F9C
	scratch_load_b32 v81, off, off offset:68                   // 0000001E6E34: DC510044 517C0000
	s_waitcnt lgkmcnt(3)                                       // 0000001E6E3C: BF89FC37
	v_fma_mixlo_f16 v84, v191, s39, 0                          // 0000001E6E40: CC210054 02004FBF
	v_fma_mixhi_f16 v84, v192, s39, 0                          // 0000001E6E48: CC220054 02004FC0
	v_fma_mixlo_f16 v85, v193, s39, 0                          // 0000001E6E50: CC210055 02004FC1
	v_fma_mixhi_f16 v85, v194, s39, 0                          // 0000001E6E58: CC220055 02004FC2
	ds_load_b128 v[147:150], v183 offset:8720                  // 0000001E6E60: DBFC2210 930000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E6E68: BF89FC37
	v_fma_mixlo_f16 v86, v157, s39, 0                          // 0000001E6E6C: CC210056 02004F9D
	v_fma_mixhi_f16 v86, v158, s39, 0                          // 0000001E6E74: CC220056 02004F9E
	v_fma_mixlo_f16 v87, v159, s39, 0                          // 0000001E6E7C: CC210057 02004F9F
	v_fma_mixhi_f16 v87, v160, s39, 0                          // 0000001E6E84: CC220057 02004FA0
	ds_load_b128 v[151:154], v183 offset:8736                  // 0000001E6E8C: DBFC2220 970000B7
	ds_load_b128 v[155:158], v183 offset:8752                  // 0000001E6E94: DBFC2230 9B0000B7
	s_waitcnt lgkmcnt(4)                                       // 0000001E6E9C: BF89FC47
	v_fma_mixlo_f16 v88, v187, s39, 0                          // 0000001E6EA0: CC210058 02004FBB
	v_fma_mixhi_f16 v88, v188, s39, 0                          // 0000001E6EA8: CC220058 02004FBC
	v_fma_mixlo_f16 v89, v189, s39, 0                          // 0000001E6EB0: CC210059 02004FBD
	v_fma_mixhi_f16 v89, v190, s39, 0                          // 0000001E6EB8: CC220059 02004FBE
	ds_load_b128 v[187:190], v183 offset:17152                 // 0000001E6EC0: DBFC4300 BB0000B7
	s_waitcnt lgkmcnt(4)                                       // 0000001E6EC8: BF89FC47
	v_fma_mixlo_f16 v145, v90, s39, 0                          // 0000001E6ECC: CC210091 02004F5A
	v_fma_mixhi_f16 v145, v91, s39, 0                          // 0000001E6ED4: CC220091 02004F5B
	v_fma_mixlo_f16 v146, v92, s39, 0                          // 0000001E6EDC: CC210092 02004F5C
	v_wmma_f32_16x16x16_f16 v[137:144], v[57:64], v[82:89], v[137:144]// 0000001E6EE4: CC404089 1E26A539
	scratch_load_b32 v82, off, off offset:72                   // 0000001E6EEC: DC510048 527C0000
	v_fma_mixhi_f16 v146, v93, s39, 0                          // 0000001E6EF4: CC220092 02004F5D
	ds_load_b128 v[90:93], v183 offset:17168                   // 0000001E6EFC: DBFC4310 5A0000B7
	ds_load_b128 v[191:194], v183 offset:17184                 // 0000001E6F04: DBFC4320 BF0000B7
	s_waitcnt lgkmcnt(5)                                       // 0000001E6F0C: BF89FC57
	v_fma_mixlo_f16 v147, v147, s39, 0                         // 0000001E6F10: CC210093 02004F93
	v_fma_mixhi_f16 v147, v148, s39, 0                         // 0000001E6F18: CC220093 02004F94
	v_fma_mixlo_f16 v148, v149, s39, 0                         // 0000001E6F20: CC210094 02004F95
	v_fma_mixhi_f16 v148, v150, s39, 0                         // 0000001E6F28: CC220094 02004F96
	v_fma_mixlo_f16 v159, v195, s39, 0                         // 0000001E6F30: CC21009F 02004FC3
	s_waitcnt lgkmcnt(4)                                       // 0000001E6F38: BF89FC47
	v_fma_mixlo_f16 v149, v151, s39, 0                         // 0000001E6F3C: CC210095 02004F97
	v_fma_mixhi_f16 v149, v152, s39, 0                         // 0000001E6F44: CC220095 02004F98
	v_fma_mixlo_f16 v150, v153, s39, 0                         // 0000001E6F4C: CC210096 02004F99
	v_fma_mixhi_f16 v150, v154, s39, 0                         // 0000001E6F54: CC220096 02004F9A
	s_waitcnt lgkmcnt(3)                                       // 0000001E6F5C: BF89FC37
	v_fma_mixlo_f16 v151, v155, s39, 0                         // 0000001E6F60: CC210097 02004F9B
	v_fma_mixhi_f16 v151, v156, s39, 0                         // 0000001E6F68: CC220097 02004F9C
	v_fma_mixlo_f16 v152, v157, s39, 0                         // 0000001E6F70: CC210098 02004F9D
	v_fma_mixhi_f16 v152, v158, s39, 0                         // 0000001E6F78: CC220098 02004F9E
	s_waitcnt lgkmcnt(2)                                       // 0000001E6F80: BF89FC27
	v_fma_mixlo_f16 v153, v187, s39, 0                         // 0000001E6F84: CC210099 02004FBB
	v_fma_mixhi_f16 v153, v188, s39, 0                         // 0000001E6F8C: CC220099 02004FBC
	v_fma_mixlo_f16 v154, v189, s39, 0                         // 0000001E6F94: CC21009A 02004FBD
	v_fma_mixhi_f16 v154, v190, s39, 0                         // 0000001E6F9C: CC22009A 02004FBE
	ds_load_b128 v[187:190], v183 offset:25600                 // 0000001E6FA4: DBFC6400 BB0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E6FAC: BF89FC27
	v_fma_mixlo_f16 v155, v90, s39, 0                          // 0000001E6FB0: CC21009B 02004F5A
	v_fma_mixhi_f16 v155, v91, s39, 0                          // 0000001E6FB8: CC22009B 02004F5B
	v_fma_mixlo_f16 v156, v92, s39, 0                          // 0000001E6FC0: CC21009C 02004F5C
	v_fma_mixhi_f16 v156, v93, s39, 0                          // 0000001E6FC8: CC22009C 02004F5D
	ds_load_b128 v[90:93], v183 offset:25616                   // 0000001E6FD0: DBFC6410 5A0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E6FD8: BF89FC27
	v_fma_mixlo_f16 v157, v191, s39, 0                         // 0000001E6FDC: CC21009D 02004FBF
	v_fma_mixhi_f16 v157, v192, s39, 0                         // 0000001E6FE4: CC22009D 02004FC0
	v_fma_mixlo_f16 v158, v193, s39, 0                         // 0000001E6FEC: CC21009E 02004FC1
	v_fma_mixhi_f16 v158, v194, s39, 0                         // 0000001E6FF4: CC22009E 02004FC2
	ds_load_b128 v[191:194], v183 offset:25632                 // 0000001E6FFC: DBFC6420 BF0000B7
	v_fma_mixhi_f16 v159, v196, s39, 0                         // 0000001E7004: CC22009F 02004FC4
	v_fma_mixlo_f16 v160, v197, s39, 0                         // 0000001E700C: CC2100A0 02004FC5
	v_fma_mixhi_f16 v160, v198, s39, 0                         // 0000001E7014: CC2200A0 02004FC6
	ds_load_b128 v[195:198], v183 offset:25648                 // 0000001E701C: DBFC6430 C30000B7
	v_wmma_f32_16x16x16_f16 v[129:136], v[57:64], v[145:152], v[129:136]// 0000001E7024: CC404081 1E072339
	v_wmma_f32_16x16x16_f16 v[113:120], v[57:64], v[153:160], v[113:120]// 0000001E702C: CC404071 1DC73339
	ds_load_b128 v[151:154], v183 offset:8816                  // 0000001E7034: DBFC2270 970000B7
	s_waitcnt lgkmcnt(4)                                       // 0000001E703C: BF89FC47
	v_fma_mixlo_f16 v83, v187, s39, 0                          // 0000001E7040: CC210053 02004FBB
	v_fma_mixhi_f16 v83, v188, s39, 0                          // 0000001E7048: CC220053 02004FBC
	v_fma_mixlo_f16 v84, v189, s39, 0                          // 0000001E7050: CC210054 02004FBD
	v_fma_mixhi_f16 v84, v190, s39, 0                          // 0000001E7058: CC220054 02004FBE
	ds_load_b128 v[187:190], v183 offset:320                   // 0000001E7060: DBFC0140 BB0000B7
	s_waitcnt lgkmcnt(4)                                       // 0000001E7068: BF89FC47
	v_fma_mixlo_f16 v85, v90, s39, 0                           // 0000001E706C: CC210055 02004F5A
	v_fma_mixhi_f16 v85, v91, s39, 0                           // 0000001E7074: CC220055 02004F5B
	v_fma_mixlo_f16 v86, v92, s39, 0                           // 0000001E707C: CC210056 02004F5C
	v_fma_mixhi_f16 v86, v93, s39, 0                           // 0000001E7084: CC220056 02004F5D
	ds_load_b128 v[91:94], v183 offset:336                     // 0000001E708C: DBFC0150 5B0000B7
	s_waitcnt lgkmcnt(4)                                       // 0000001E7094: BF89FC47
	v_fma_mixlo_f16 v87, v191, s39, 0                          // 0000001E7098: CC210057 02004FBF
	v_fma_mixhi_f16 v87, v192, s39, 0                          // 0000001E70A0: CC220057 02004FC0
	v_fma_mixlo_f16 v88, v193, s39, 0                          // 0000001E70A8: CC210058 02004FC1
	v_fma_mixhi_f16 v88, v194, s39, 0                          // 0000001E70B0: CC220058 02004FC2
	s_waitcnt lgkmcnt(3)                                       // 0000001E70B8: BF89FC37
	v_fma_mixlo_f16 v89, v195, s39, 0                          // 0000001E70BC: CC210059 02004FC3
	v_fma_mixhi_f16 v89, v196, s39, 0                          // 0000001E70C4: CC220059 02004FC4
	v_fma_mixlo_f16 v90, v197, s39, 0                          // 0000001E70CC: CC21005A 02004FC5
	v_fma_mixhi_f16 v90, v198, s39, 0                          // 0000001E70D4: CC22005A 02004FC6
	ds_load_b128 v[191:194], v183 offset:352                   // 0000001E70DC: DBFC0160 BF0000B7
	ds_load_b128 v[195:198], v183 offset:368                   // 0000001E70E4: DBFC0170 C30000B7
	ds_load_b128 v[155:158], v183 offset:17216                 // 0000001E70EC: DBFC4340 9B0000B7
	s_waitcnt lgkmcnt(5)                                       // 0000001E70F4: BF89FC57
	v_fma_mixlo_f16 v151, v151, s39, 0                         // 0000001E70F8: CC210097 02004F97
	v_wmma_f32_16x16x16_f16 v[97:104], v[57:64], v[83:90], v[97:104]// 0000001E7100: CC404061 1D86A739
	ds_load_b128 v[57:60], v183 offset:8768                    // 0000001E7108: DBFC2240 390000B7
	ds_load_b128 v[61:64], v183 offset:8784                    // 0000001E7110: DBFC2250 3D0000B7
	s_waitcnt lgkmcnt(6)                                       // 0000001E7118: BF89FC67
	v_fma_mixlo_f16 v83, v187, s39, 0                          // 0000001E711C: CC210053 02004FBB
	v_fma_mixhi_f16 v83, v188, s39, 0                          // 0000001E7124: CC220053 02004FBC
	v_fma_mixlo_f16 v84, v189, s39, 0                          // 0000001E712C: CC210054 02004FBD
	v_fma_mixhi_f16 v84, v190, s39, 0                          // 0000001E7134: CC220054 02004FBE
	s_waitcnt lgkmcnt(5)                                       // 0000001E713C: BF89FC57
	v_fma_mixlo_f16 v85, v91, s39, 0                           // 0000001E7140: CC210055 02004F5B
	v_fma_mixhi_f16 v85, v92, s39, 0                           // 0000001E7148: CC220055 02004F5C
	v_fma_mixlo_f16 v86, v93, s39, 0                           // 0000001E7150: CC210056 02004F5D
	v_fma_mixhi_f16 v86, v94, s39, 0                           // 0000001E7158: CC220056 02004F5E
	ds_load_b128 v[91:94], v183 offset:8800                    // 0000001E7160: DBFC2260 5B0000B7
	v_fma_mixhi_f16 v151, v152, s39, 0                         // 0000001E7168: CC220097 02004F98
	v_fma_mixlo_f16 v152, v153, s39, 0                         // 0000001E7170: CC210098 02004F99
	ds_load_b128 v[187:190], v183 offset:25664                 // 0000001E7178: DBFC6440 BB0000B7
	v_fma_mixhi_f16 v152, v154, s39, 0                         // 0000001E7180: CC220098 02004F9A
	s_waitcnt lgkmcnt(6)                                       // 0000001E7188: BF89FC67
	v_fma_mixlo_f16 v87, v191, s39, 0                          // 0000001E718C: CC210057 02004FBF
	v_fma_mixhi_f16 v87, v192, s39, 0                          // 0000001E7194: CC220057 02004FC0
	v_fma_mixlo_f16 v88, v193, s39, 0                          // 0000001E719C: CC210058 02004FC1
	v_fma_mixhi_f16 v88, v194, s39, 0                          // 0000001E71A4: CC220058 02004FC2
	s_waitcnt lgkmcnt(5)                                       // 0000001E71AC: BF89FC57
	v_fma_mixlo_f16 v89, v195, s39, 0                          // 0000001E71B0: CC210059 02004FC3
	s_waitcnt lgkmcnt(3)                                       // 0000001E71B8: BF89FC37
	v_fma_mixlo_f16 v145, v57, s39, 0                          // 0000001E71BC: CC210091 02004F39
	v_fma_mixhi_f16 v145, v58, s39, 0                          // 0000001E71C4: CC220091 02004F3A
	v_fma_mixlo_f16 v146, v59, s39, 0                          // 0000001E71CC: CC210092 02004F3B
	v_fma_mixhi_f16 v146, v60, s39, 0                          // 0000001E71D4: CC220092 02004F3C
	ds_load_b128 v[57:60], v183 offset:17232                   // 0000001E71DC: DBFC4350 390000B7
	v_fma_mixhi_f16 v89, v196, s39, 0                          // 0000001E71E4: CC220059 02004FC4
	v_fma_mixlo_f16 v90, v197, s39, 0                          // 0000001E71EC: CC21005A 02004FC5
	v_fma_mixhi_f16 v90, v198, s39, 0                          // 0000001E71F4: CC22005A 02004FC6
	s_waitcnt lgkmcnt(3)                                       // 0000001E71FC: BF89FC37
	v_fma_mixlo_f16 v147, v61, s39, 0                          // 0000001E7200: CC210093 02004F3D
	v_fma_mixhi_f16 v147, v62, s39, 0                          // 0000001E7208: CC220093 02004F3E
	v_fma_mixlo_f16 v148, v63, s39, 0                          // 0000001E7210: CC210094 02004F3F
	v_fma_mixhi_f16 v148, v64, s39, 0                          // 0000001E7218: CC220094 02004F40
	s_waitcnt lgkmcnt(2)                                       // 0000001E7220: BF89FC27
	v_fma_mixlo_f16 v149, v91, s39, 0                          // 0000001E7224: CC210095 02004F5B
	ds_load_b128 v[61:64], v183 offset:17248                   // 0000001E722C: DBFC4360 3D0000B7
	v_fma_mixhi_f16 v149, v92, s39, 0                          // 0000001E7234: CC220095 02004F5C
	v_fma_mixlo_f16 v150, v93, s39, 0                          // 0000001E723C: CC210096 02004F5D
	v_fma_mixhi_f16 v150, v94, s39, 0                          // 0000001E7244: CC220096 02004F5E
	ds_load_b128 v[91:94], v183 offset:17264                   // 0000001E724C: DBFC4370 5B0000B7
	v_fma_mixlo_f16 v153, v155, s39, 0                         // 0000001E7254: CC210099 02004F9B
	v_fma_mixhi_f16 v153, v156, s39, 0                         // 0000001E725C: CC220099 02004F9C
	ds_load_b128 v[191:194], v183 offset:25680                 // 0000001E7264: DBFC6450 BF0000B7
	ds_load_b128 v[195:198], v183 offset:25696                 // 0000001E726C: DBFC6460 C30000B7
	v_fma_mixlo_f16 v154, v157, s39, 0                         // 0000001E7274: CC21009A 02004F9D
	v_fma_mixhi_f16 v154, v158, s39, 0                         // 0000001E727C: CC22009A 02004F9E
	s_waitcnt lgkmcnt(4)                                       // 0000001E7284: BF89FC47
	v_fma_mixlo_f16 v155, v57, s39, 0                          // 0000001E7288: CC21009B 02004F39
	v_fma_mixhi_f16 v155, v58, s39, 0                          // 0000001E7290: CC22009B 02004F3A
	v_fma_mixlo_f16 v156, v59, s39, 0                          // 0000001E7298: CC21009C 02004F3B
	v_fma_mixhi_f16 v156, v60, s39, 0                          // 0000001E72A0: CC22009C 02004F3C
	ds_load_b128 v[57:60], v183 offset:25712                   // 0000001E72A8: DBFC6470 390000B7
	v_wmma_f32_16x16x16_f16 v[137:144], v[73:80], v[83:90], v[137:144]// 0000001E72B0: CC404089 1E26A749
	v_fma_mixlo_f16 v83, v187, s39, 0                          // 0000001E72B8: CC210053 02004FBB
	v_fma_mixhi_f16 v83, v188, s39, 0                          // 0000001E72C0: CC220053 02004FBC
	v_fma_mixlo_f16 v84, v189, s39, 0                          // 0000001E72C8: CC210054 02004FBD
	s_waitcnt lgkmcnt(4)                                       // 0000001E72D0: BF89FC47
	v_fma_mixlo_f16 v157, v61, s39, 0                          // 0000001E72D4: CC21009D 02004F3D
	v_fma_mixhi_f16 v157, v62, s39, 0                          // 0000001E72DC: CC22009D 02004F3E
	v_fma_mixlo_f16 v158, v63, s39, 0                          // 0000001E72E4: CC21009E 02004F3F
	v_fma_mixhi_f16 v158, v64, s39, 0                          // 0000001E72EC: CC22009E 02004F40
	s_waitcnt lgkmcnt(3)                                       // 0000001E72F4: BF89FC37
	v_fma_mixlo_f16 v159, v91, s39, 0                          // 0000001E72F8: CC21009F 02004F5B
	v_fma_mixhi_f16 v159, v92, s39, 0                          // 0000001E7300: CC22009F 02004F5C
	v_fma_mixlo_f16 v160, v93, s39, 0                          // 0000001E7308: CC2100A0 02004F5D
	v_fma_mixhi_f16 v160, v94, s39, 0                          // 0000001E7310: CC2200A0 02004F5E
	v_fma_mixhi_f16 v84, v190, s39, 0                          // 0000001E7318: CC220054 02004FBE
	s_waitcnt lgkmcnt(2)                                       // 0000001E7320: BF89FC27
	v_fma_mixlo_f16 v85, v191, s39, 0                          // 0000001E7324: CC210055 02004FBF
	v_fma_mixhi_f16 v85, v192, s39, 0                          // 0000001E732C: CC220055 02004FC0
	v_fma_mixlo_f16 v86, v193, s39, 0                          // 0000001E7334: CC210056 02004FC1
	v_fma_mixhi_f16 v86, v194, s39, 0                          // 0000001E733C: CC220056 02004FC2
	s_waitcnt lgkmcnt(1)                                       // 0000001E7344: BF89FC17
	v_fma_mixlo_f16 v87, v195, s39, 0                          // 0000001E7348: CC210057 02004FC3
	v_fma_mixhi_f16 v87, v196, s39, 0                          // 0000001E7350: CC220057 02004FC4
	v_fma_mixlo_f16 v88, v197, s39, 0                          // 0000001E7358: CC210058 02004FC5
	v_fma_mixhi_f16 v88, v198, s39, 0                          // 0000001E7360: CC220058 02004FC6
	s_waitcnt lgkmcnt(0)                                       // 0000001E7368: BF89FC07
	v_fma_mixlo_f16 v89, v57, s39, 0                           // 0000001E736C: CC210059 02004F39
	v_fma_mixhi_f16 v89, v58, s39, 0                           // 0000001E7374: CC220059 02004F3A
	v_fma_mixlo_f16 v90, v59, s39, 0                           // 0000001E737C: CC21005A 02004F3B
	v_fma_mixhi_f16 v90, v60, s39, 0                           // 0000001E7384: CC22005A 02004F3C
	ds_load_b128 v[91:94], v183 offset:384                     // 0000001E738C: DBFC0180 5B0000B7
	ds_load_b128 v[187:190], v183 offset:400                   // 0000001E7394: DBFC0190 BB0000B7
	v_wmma_f32_16x16x16_f16 v[129:136], v[73:80], v[145:152], v[129:136]// 0000001E739C: CC404081 1E072349
	v_wmma_f32_16x16x16_f16 v[113:120], v[73:80], v[153:160], v[113:120]// 0000001E73A4: CC404071 1DC73349
	v_wmma_f32_16x16x16_f16 v[97:104], v[73:80], v[83:90], v[97:104]// 0000001E73AC: CC404061 1D86A749
	ds_load_b128 v[73:76], v183 offset:8832                    // 0000001E73B4: DBFC2280 490000B7
	ds_load_b128 v[77:80], v183 offset:8848                    // 0000001E73BC: DBFC2290 4D0000B7
	ds_load_b128 v[191:194], v183 offset:416                   // 0000001E73C4: DBFC01A0 BF0000B7
	ds_load_b128 v[195:198], v183 offset:432                   // 0000001E73CC: DBFC01B0 C30000B7
	ds_load_b128 v[151:154], v183 offset:8880                  // 0000001E73D4: DBFC22B0 970000B7
	ds_load_b128 v[155:158], v183 offset:17280                 // 0000001E73DC: DBFC4380 9B0000B7
	s_waitcnt lgkmcnt(7)                                       // 0000001E73E4: BF89FC77
	v_fma_mixlo_f16 v83, v91, s39, 0                           // 0000001E73E8: CC210053 02004F5B
	v_fma_mixhi_f16 v83, v92, s39, 0                           // 0000001E73F0: CC220053 02004F5C
	v_fma_mixlo_f16 v84, v93, s39, 0                           // 0000001E73F8: CC210054 02004F5D
	v_fma_mixhi_f16 v84, v94, s39, 0                           // 0000001E7400: CC220054 02004F5E
	ds_load_b128 v[91:94], v183 offset:8864                    // 0000001E7408: DBFC22A0 5B0000B7
	s_waitcnt lgkmcnt(6)                                       // 0000001E7410: BF89FC67
	v_fma_mixlo_f16 v145, v73, s39, 0                          // 0000001E7414: CC210091 02004F49
	v_fma_mixhi_f16 v145, v74, s39, 0                          // 0000001E741C: CC220091 02004F4A
	v_fma_mixlo_f16 v146, v75, s39, 0                          // 0000001E7424: CC210092 02004F4B
	v_fma_mixhi_f16 v146, v76, s39, 0                          // 0000001E742C: CC220092 02004F4C
	ds_load_b128 v[73:76], v183 offset:17296                   // 0000001E7434: DBFC4390 490000B7
	v_fma_mixlo_f16 v85, v187, s39, 0                          // 0000001E743C: CC210055 02004FBB
	v_fma_mixhi_f16 v85, v188, s39, 0                          // 0000001E7444: CC220055 02004FBC
	v_fma_mixlo_f16 v86, v189, s39, 0                          // 0000001E744C: CC210056 02004FBD
	v_fma_mixhi_f16 v86, v190, s39, 0                          // 0000001E7454: CC220056 02004FBE
	s_waitcnt lgkmcnt(5)                                       // 0000001E745C: BF89FC57
	v_fma_mixlo_f16 v87, v191, s39, 0                          // 0000001E7460: CC210057 02004FBF
	v_fma_mixhi_f16 v87, v192, s39, 0                          // 0000001E7468: CC220057 02004FC0
	v_fma_mixlo_f16 v88, v193, s39, 0                          // 0000001E7470: CC210058 02004FC1
	v_fma_mixhi_f16 v88, v194, s39, 0                          // 0000001E7478: CC220058 02004FC2
	s_waitcnt lgkmcnt(4)                                       // 0000001E7480: BF89FC47
	v_fma_mixlo_f16 v89, v195, s39, 0                          // 0000001E7484: CC210059 02004FC3
	v_fma_mixhi_f16 v89, v196, s39, 0                          // 0000001E748C: CC220059 02004FC4
	v_fma_mixlo_f16 v90, v197, s39, 0                          // 0000001E7494: CC21005A 02004FC5
	v_fma_mixhi_f16 v90, v198, s39, 0                          // 0000001E749C: CC22005A 02004FC6
	v_fma_mixlo_f16 v147, v77, s39, 0                          // 0000001E74A4: CC210093 02004F4D
	v_fma_mixhi_f16 v147, v78, s39, 0                          // 0000001E74AC: CC220093 02004F4E
	v_fma_mixlo_f16 v148, v79, s39, 0                          // 0000001E74B4: CC210094 02004F4F
	v_fma_mixhi_f16 v148, v80, s39, 0                          // 0000001E74BC: CC220094 02004F50
	s_waitcnt lgkmcnt(1)                                       // 0000001E74C4: BF89FC17
	v_fma_mixlo_f16 v149, v91, s39, 0                          // 0000001E74C8: CC210095 02004F5B
	ds_load_b128 v[77:80], v183 offset:17312                   // 0000001E74D0: DBFC43A0 4D0000B7
	v_fma_mixhi_f16 v149, v92, s39, 0                          // 0000001E74D8: CC220095 02004F5C
	v_fma_mixlo_f16 v150, v93, s39, 0                          // 0000001E74E0: CC210096 02004F5D
	v_fma_mixhi_f16 v150, v94, s39, 0                          // 0000001E74E8: CC220096 02004F5E
	v_fma_mixlo_f16 v151, v151, s39, 0                         // 0000001E74F0: CC210097 02004F97
	ds_load_b128 v[91:94], v183 offset:17328                   // 0000001E74F8: DBFC43B0 5B0000B7
	v_fma_mixhi_f16 v151, v152, s39, 0                         // 0000001E7500: CC220097 02004F98
	v_fma_mixlo_f16 v152, v153, s39, 0                         // 0000001E7508: CC210098 02004F99
	ds_load_b128 v[187:190], v183 offset:25728                 // 0000001E7510: DBFC6480 BB0000B7
	ds_load_b128 v[191:194], v183 offset:25744                 // 0000001E7518: DBFC6490 BF0000B7
	v_fma_mixlo_f16 v153, v155, s39, 0                         // 0000001E7520: CC210099 02004F9B
	v_fma_mixhi_f16 v153, v156, s39, 0                         // 0000001E7528: CC220099 02004F9C
	s_waitcnt lgkmcnt(4)                                       // 0000001E7530: BF89FC47
	v_fma_mixlo_f16 v155, v73, s39, 0                          // 0000001E7534: CC21009B 02004F49
	v_fma_mixhi_f16 v155, v74, s39, 0                          // 0000001E753C: CC22009B 02004F4A
	v_fma_mixlo_f16 v156, v75, s39, 0                          // 0000001E7544: CC21009C 02004F4B
	ds_load_b128 v[195:198], v183 offset:25760                 // 0000001E754C: DBFC64A0 C30000B7
	v_fma_mixhi_f16 v156, v76, s39, 0                          // 0000001E7554: CC22009C 02004F4C
	ds_load_b128 v[73:76], v183 offset:25776                   // 0000001E755C: DBFC64B0 490000B7
	v_fma_mixhi_f16 v152, v154, s39, 0                         // 0000001E7564: CC220098 02004F9A
	v_fma_mixlo_f16 v154, v157, s39, 0                         // 0000001E756C: CC21009A 02004F9D
	v_fma_mixhi_f16 v154, v158, s39, 0                         // 0000001E7574: CC22009A 02004F9E
	s_waitcnt lgkmcnt(5)                                       // 0000001E757C: BF89FC57
	v_fma_mixlo_f16 v157, v77, s39, 0                          // 0000001E7580: CC21009D 02004F4D
	v_fma_mixhi_f16 v157, v78, s39, 0                          // 0000001E7588: CC22009D 02004F4E
	v_fma_mixlo_f16 v158, v79, s39, 0                          // 0000001E7590: CC21009E 02004F4F
	v_fma_mixhi_f16 v158, v80, s39, 0                          // 0000001E7598: CC22009E 02004F50
	s_waitcnt lgkmcnt(4)                                       // 0000001E75A0: BF89FC47
	v_fma_mixlo_f16 v159, v91, s39, 0                          // 0000001E75A4: CC21009F 02004F5B
	v_fma_mixhi_f16 v159, v92, s39, 0                          // 0000001E75AC: CC22009F 02004F5C
	v_fma_mixlo_f16 v160, v93, s39, 0                          // 0000001E75B4: CC2100A0 02004F5D
	v_fma_mixhi_f16 v160, v94, s39, 0                          // 0000001E75BC: CC2200A0 02004F5E
	v_wmma_f32_16x16x16_f16 v[137:144], v[65:72], v[83:90], v[137:144]// 0000001E75C4: CC404089 1E26A741
	s_waitcnt lgkmcnt(3)                                       // 0000001E75CC: BF89FC37
	v_fma_mixlo_f16 v83, v187, s39, 0                          // 0000001E75D0: CC210053 02004FBB
	v_fma_mixhi_f16 v83, v188, s39, 0                          // 0000001E75D8: CC220053 02004FBC
	v_fma_mixlo_f16 v84, v189, s39, 0                          // 0000001E75E0: CC210054 02004FBD
	v_fma_mixhi_f16 v84, v190, s39, 0                          // 0000001E75E8: CC220054 02004FBE
	s_waitcnt lgkmcnt(2)                                       // 0000001E75F0: BF89FC27
	v_fma_mixlo_f16 v85, v191, s39, 0                          // 0000001E75F4: CC210055 02004FBF
	v_fma_mixhi_f16 v85, v192, s39, 0                          // 0000001E75FC: CC220055 02004FC0
	v_fma_mixlo_f16 v86, v193, s39, 0                          // 0000001E7604: CC210056 02004FC1
	v_fma_mixhi_f16 v86, v194, s39, 0                          // 0000001E760C: CC220056 02004FC2
	s_waitcnt lgkmcnt(1)                                       // 0000001E7614: BF89FC17
	v_fma_mixlo_f16 v87, v195, s39, 0                          // 0000001E7618: CC210057 02004FC3
	v_fma_mixhi_f16 v87, v196, s39, 0                          // 0000001E7620: CC220057 02004FC4
	v_fma_mixlo_f16 v88, v197, s39, 0                          // 0000001E7628: CC210058 02004FC5
	v_fma_mixhi_f16 v88, v198, s39, 0                          // 0000001E7630: CC220058 02004FC6
	s_waitcnt lgkmcnt(0)                                       // 0000001E7638: BF89FC07
	v_fma_mixlo_f16 v89, v73, s39, 0                           // 0000001E763C: CC210059 02004F49
	v_fma_mixhi_f16 v89, v74, s39, 0                           // 0000001E7644: CC220059 02004F4A
	v_fma_mixlo_f16 v90, v75, s39, 0                           // 0000001E764C: CC21005A 02004F4B
	v_fma_mixhi_f16 v90, v76, s39, 0                           // 0000001E7654: CC22005A 02004F4C
	ds_load_b128 v[91:94], v183 offset:448                     // 0000001E765C: DBFC01C0 5B0000B7
	ds_load_b128 v[187:190], v183 offset:464                   // 0000001E7664: DBFC01D0 BB0000B7
	v_wmma_f32_16x16x16_f16 v[129:136], v[65:72], v[145:152], v[129:136]// 0000001E766C: CC404081 1E072341
	v_wmma_f32_16x16x16_f16 v[113:120], v[65:72], v[153:160], v[113:120]// 0000001E7674: CC404071 1DC73341
	v_wmma_f32_16x16x16_f16 v[97:104], v[65:72], v[83:90], v[97:104]// 0000001E767C: CC404061 1D86A741
	ds_load_b128 v[65:68], v183 offset:8896                    // 0000001E7684: DBFC22C0 410000B7
	ds_load_b128 v[69:72], v183 offset:8912                    // 0000001E768C: DBFC22D0 450000B7
	ds_load_b128 v[191:194], v183 offset:480                   // 0000001E7694: DBFC01E0 BF0000B7
	ds_load_b128 v[195:198], v183 offset:496                   // 0000001E769C: DBFC01F0 C30000B7
	ds_load_b128 v[83:86], v183 offset:8928                    // 0000001E76A4: DBFC22E0 530000B7
	ds_load_b128 v[87:90], v183 offset:8944                    // 0000001E76AC: DBFC22F0 570000B7
	s_waitcnt lgkmcnt(7)                                       // 0000001E76B4: BF89FC77
	v_fma_mixlo_f16 v145, v91, s39, 0                          // 0000001E76B8: CC210091 02004F5B
	v_fma_mixhi_f16 v145, v92, s39, 0                          // 0000001E76C0: CC220091 02004F5C
	v_fma_mixlo_f16 v146, v93, s39, 0                          // 0000001E76C8: CC210092 02004F5D
	v_fma_mixhi_f16 v146, v94, s39, 0                          // 0000001E76D0: CC220092 02004F5E
	ds_load_b128 v[91:94], v183 offset:17344                   // 0000001E76D8: DBFC43C0 5B0000B7
	s_waitcnt lgkmcnt(6)                                       // 0000001E76E0: BF89FC67
	v_fma_mixlo_f16 v153, v65, s39, 0                          // 0000001E76E4: CC210099 02004F41
	v_fma_mixhi_f16 v153, v66, s39, 0                          // 0000001E76EC: CC220099 02004F42
	v_fma_mixlo_f16 v154, v67, s39, 0                          // 0000001E76F4: CC21009A 02004F43
	v_fma_mixhi_f16 v154, v68, s39, 0                          // 0000001E76FC: CC22009A 02004F44
	ds_load_b128 v[65:68], v183 offset:17360                   // 0000001E7704: DBFC43D0 410000B7
	v_fma_mixlo_f16 v148, v189, s39, 0                         // 0000001E770C: CC210094 02004FBD
	v_fma_mixhi_f16 v148, v190, s39, 0                         // 0000001E7714: CC220094 02004FBE
	s_waitcnt lgkmcnt(4)                                       // 0000001E771C: BF89FC47
	v_fma_mixlo_f16 v152, v197, s39, 0                         // 0000001E7720: CC210098 02004FC5
	v_fma_mixhi_f16 v152, v198, s39, 0                         // 0000001E7728: CC220098 02004FC6
	v_fma_mixlo_f16 v155, v69, s39, 0                          // 0000001E7730: CC21009B 02004F45
	v_fma_mixhi_f16 v155, v70, s39, 0                          // 0000001E7738: CC22009B 02004F46
	v_fma_mixlo_f16 v156, v71, s39, 0                          // 0000001E7740: CC21009C 02004F47
	v_fma_mixhi_f16 v156, v72, s39, 0                          // 0000001E7748: CC22009C 02004F48
	ds_load_b128 v[69:72], v183 offset:17376                   // 0000001E7750: DBFC43E0 450000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E7758: BF89FC37
	v_fma_mixlo_f16 v159, v87, s39, 0                          // 0000001E775C: CC21009F 02004F57
	v_fma_mixhi_f16 v159, v88, s39, 0                          // 0000001E7764: CC22009F 02004F58
	v_fma_mixlo_f16 v160, v89, s39, 0                          // 0000001E776C: CC2100A0 02004F59
	v_fma_mixhi_f16 v160, v90, s39, 0                          // 0000001E7774: CC2200A0 02004F5A
	ds_load_b128 v[87:90], v183 offset:25792                   // 0000001E777C: DBFC64C0 570000B7
	ds_load_b128 v[197:200], v183 offset:25808                 // 0000001E7784: DBFC64D0 C50000B7
	v_fma_mixlo_f16 v147, v187, s39, 0                         // 0000001E778C: CC210093 02004FBB
	v_fma_mixhi_f16 v147, v188, s39, 0                         // 0000001E7794: CC220093 02004FBC
	v_fma_mixlo_f16 v149, v191, s39, 0                         // 0000001E779C: CC210095 02004FBF
	v_fma_mixhi_f16 v149, v192, s39, 0                         // 0000001E77A4: CC220095 02004FC0
	s_waitcnt lgkmcnt(3)                                       // 0000001E77AC: BF89FC37
	v_fma_mixlo_f16 v189, v65, s39, 0                          // 0000001E77B0: CC2100BD 02004F41
	v_fma_mixhi_f16 v189, v66, s39, 0                          // 0000001E77B8: CC2200BD 02004F42
	v_fma_mixlo_f16 v190, v67, s39, 0                          // 0000001E77C0: CC2100BE 02004F43
	v_fma_mixhi_f16 v190, v68, s39, 0                          // 0000001E77C8: CC2200BE 02004F44
	ds_load_b128 v[65:68], v183 offset:25840                   // 0000001E77D0: DBFC64F0 410000B7
	v_fma_mixhi_f16 v151, v196, s39, 0                         // 0000001E77D8: CC220097 02004FC4
	v_fma_mixlo_f16 v157, v83, s39, 0                          // 0000001E77E0: CC21009D 02004F53
	v_fma_mixhi_f16 v157, v84, s39, 0                          // 0000001E77E8: CC22009D 02004F54
	v_fma_mixlo_f16 v158, v85, s39, 0                          // 0000001E77F0: CC21009E 02004F55
	v_fma_mixhi_f16 v158, v86, s39, 0                          // 0000001E77F8: CC22009E 02004F56
	ds_load_b128 v[83:86], v183 offset:17392                   // 0000001E7800: DBFC43F0 530000B7
	v_fma_mixlo_f16 v187, v91, s39, 0                          // 0000001E7808: CC2100BB 02004F5B
	v_fma_mixhi_f16 v187, v92, s39, 0                          // 0000001E7810: CC2200BB 02004F5C
	v_fma_mixlo_f16 v188, v93, s39, 0                          // 0000001E7818: CC2100BC 02004F5D
	v_fma_mixhi_f16 v188, v94, s39, 0                          // 0000001E7820: CC2200BC 02004F5E
	s_waitcnt lgkmcnt(4)                                       // 0000001E7828: BF89FC47
	v_fma_mixlo_f16 v191, v69, s39, 0                          // 0000001E782C: CC2100BF 02004F45
	v_fma_mixhi_f16 v191, v70, s39, 0                          // 0000001E7834: CC2200BF 02004F46
	v_fma_mixlo_f16 v192, v71, s39, 0                          // 0000001E783C: CC2100C0 02004F47
	v_fma_mixhi_f16 v192, v72, s39, 0                          // 0000001E7844: CC2200C0 02004F48
	s_waitcnt vmcnt(1)                                         // 0000001E784C: BF8907F7
	.long 0xd7006a51                                           // 0000001E7850: D7006A51
	v_cndmask_b32_e32 v0, v81, v0, vcc_lo                      // 0000001E7854: 02000151
	s_waitcnt lgkmcnt(3)                                       // 0000001E7858: BF89FC37
	v_fma_mixlo_f16 v196, v89, s39, 0                          // 0000001E785C: CC2100C4 02004F59
	v_fma_mixhi_f16 v196, v90, s39, 0                          // 0000001E7864: CC2200C4 02004F5A
	s_waitcnt lgkmcnt(2)                                       // 0000001E786C: BF89FC27
	v_fma_mixlo_f16 v197, v197, s39, 0                         // 0000001E7870: CC2100C5 02004FC5
	v_fma_mixhi_f16 v197, v198, s39, 0                         // 0000001E7878: CC2200C5 02004FC6
	v_fma_mixlo_f16 v198, v199, s39, 0                         // 0000001E7880: CC2100C6 02004FC7
	v_fma_mixlo_f16 v199, v201, s39, 0                         // 0000001E7888: CC2100C7 02004FC9
	v_fma_mixhi_f16 v199, v202, s39, 0                         // 0000001E7890: CC2200C7 02004FCA
	s_waitcnt lgkmcnt(1)                                       // 0000001E7898: BF89FC17
	v_fma_mixlo_f16 v201, v65, s39, 0                          // 0000001E789C: CC2100C9 02004F41
	v_fma_mixhi_f16 v201, v66, s39, 0                          // 0000001E78A4: CC2200C9 02004F42
	v_fma_mixlo_f16 v202, v67, s39, 0                          // 0000001E78AC: CC2100CA 02004F43
	v_fma_mixhi_f16 v202, v68, s39, 0                          // 0000001E78B4: CC2200CA 02004F44
	v_fma_mixlo_f16 v150, v193, s39, 0                         // 0000001E78BC: CC210096 02004FC1
	v_fma_mixhi_f16 v150, v194, s39, 0                         // 0000001E78C4: CC220096 02004FC2
	v_fma_mixlo_f16 v151, v195, s39, 0                         // 0000001E78CC: CC210097 02004FC3
	s_waitcnt lgkmcnt(0)                                       // 0000001E78D4: BF89FC07
	v_fma_mixlo_f16 v193, v83, s39, 0                          // 0000001E78D8: CC2100C1 02004F53
	v_fma_mixhi_f16 v193, v84, s39, 0                          // 0000001E78E0: CC2200C1 02004F54
	v_fma_mixlo_f16 v194, v85, s39, 0                          // 0000001E78E8: CC2100C2 02004F55
	v_fma_mixhi_f16 v194, v86, s39, 0                          // 0000001E78F0: CC2200C2 02004F56
	v_fma_mixlo_f16 v195, v87, s39, 0                          // 0000001E78F8: CC2100C3 02004F57
	s_waitcnt vmcnt(0)                                         // 0000001E7900: BF8903F7
	v_add_co_ci_u32_e64 v82, null, s1, v82, vcc_lo             // 0000001E7904: D5207C52 01AAA401
	s_clause 0x7                                               // 0000001E790C: BF850007
	global_load_b128 v[93:96], v[81:82], off offset:80         // 0000001E7910: DC5E0050 5D7C0051
	global_load_b128 v[89:92], v[81:82], off offset:64         // 0000001E7918: DC5E0040 597C0051
	global_load_b128 v[61:64], v[81:82], off offset:16         // 0000001E7920: DC5E0010 3D7C0051
	global_load_b128 v[57:60], v[81:82], off                   // 0000001E7928: DC5E0000 397C0051
	global_load_b128 v[77:80], v[81:82], off offset:48         // 0000001E7930: DC5E0030 4D7C0051
	global_load_b128 v[73:76], v[81:82], off offset:32         // 0000001E7938: DC5E0020 497C0051
	global_load_b128 v[69:72], v[81:82], off offset:112        // 0000001E7940: DC5E0070 457C0051
	global_load_b128 v[65:68], v[81:82], off offset:96         // 0000001E7948: DC5E0060 417C0051
	v_fma_mixhi_f16 v195, v88, s39, 0                          // 0000001E7950: CC2200C3 02004F58
	v_fma_mixhi_f16 v198, v200, s39, 0                         // 0000001E7958: CC2200C6 02004FC8
	v_fma_mixlo_f16 v200, v203, s39, 0                         // 0000001E7960: CC2100C8 02004FCB
	v_fma_mixhi_f16 v200, v204, s39, 0                         // 0000001E7968: CC2200C8 02004FCC
	v_wmma_f32_16x16x16_f16 v[137:144], v[49:56], v[145:152], v[137:144]// 0000001E7970: CC404089 1E272331
	v_wmma_f32_16x16x16_f16 v[129:136], v[49:56], v[153:160], v[129:136]// 0000001E7978: CC404081 1E073331
	v_wmma_f32_16x16x16_f16 v[113:120], v[49:56], v[187:194], v[113:120]// 0000001E7980: CC404071 1DC77731
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001E7988: BF8700C4
	v_wmma_f32_16x16x16_f16 v[97:104], v[49:56], v[195:202], v[97:104]// 0000001E798C: CC404061 1D878731
	scratch_load_b32 v49, off, off offset:64                   // 0000001E7994: DC510040 317C0000
	s_waitcnt vmcnt(0)                                         // 0000001E799C: BF8903F7
	v_add_nc_u32_e32 v145, s42, v49                            // 0000001E79A0: 4B22622A
	v_or_b32_e32 v49, 2, v145                                  // 0000001E79A4: 38632282
	v_or_b32_e32 v51, 4, v145                                  // 0000001E79A8: 38672284
	v_or_b32_e32 v52, 6, v145                                  // 0000001E79AC: 38692286
	v_or_b32_e32 v53, 8, v145                                  // 0000001E79B0: 386B2288
	v_or_b32_e32 v55, 10, v145                                 // 0000001E79B4: 386F228A
	v_min_i32_e32 v54, s49, v49                                // 0000001E79B8: 226C6231
	v_min_i32_e32 v56, s49, v51                                // 0000001E79BC: 22706631
	v_min_i32_e32 v82, s49, v52                                // 0000001E79C0: 22A46831
	v_min_i32_e32 v83, s49, v53                                // 0000001E79C4: 22A66A31
	v_min_i32_e32 v84, s49, v55                                // 0000001E79C8: 22A86E31
	v_mad_i64_i32 v[51:52], null, v54, 48, s[2:3]              // 0000001E79CC: D6FF7C33 00096136
	v_mad_i64_i32 v[53:54], null, v56, 48, s[2:3]              // 0000001E79D4: D6FF7C35 00096138
	v_mad_i64_i32 v[55:56], null, v82, 48, s[2:3]              // 0000001E79DC: D6FF7C37 00096152
	v_or_b32_e32 v81, 12, v145                                 // 0000001E79E4: 38A3228C
	v_or_b32_e32 v146, 14, v145                                // 0000001E79E8: 3925228E
	v_min_i32_e32 v50, s49, v145                               // 0000001E79EC: 22652231
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001E79F0: BF870003
	v_min_i32_e32 v85, s49, v81                                // 0000001E79F4: 22AAA231
	.long 0xd73c0033                                           // 0000001E79F8: D73C0033
	v_cndmask_b32_e32 v1, 9, v51, vcc_lo                       // 0000001E79FC: 02026689
	v_mad_i64_i32 v[81:82], null, v83, 48, s[2:3]              // 0000001E7A00: D6FF7C51 00096153
	v_mad_i64_i32 v[83:84], null, v84, 48, s[2:3]              // 0000001E7A08: D6FF7C53 00096154
	.long 0xd73c0037                                           // 0000001E7A10: D73C0037
	v_cndmask_b32_e32 v1, 9, v55, vcc_lo                       // 0000001E7A14: 02026E89
	v_mad_i64_i32 v[85:86], null, v85, 48, s[2:3]              // 0000001E7A18: D6FF7C55 00096155
	v_mad_i64_i32 v[49:50], null, v50, 48, s[2:3]              // 0000001E7A20: D6FF7C31 00096132
	.long 0xd7006a33                                           // 0000001E7A28: D7006A33
	v_cndmask_b32_e32 v1, v229, v51, vcc_lo                    // 0000001E7A2C: 020267E5
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E7A30: BF870001
	v_add_co_ci_u32_e64 v52, null, v230, v52, vcc_lo           // 0000001E7A34: D5207C34 01AA69E6
	.long 0xd7006a57                                           // 0000001E7A3C: D7006A57
	v_cndmask_b32_e32 v1, v229, v55, vcc_lo                    // 0000001E7A40: 02026FE5
	.long 0xd73c0051                                           // 0000001E7A44: D73C0051
	v_cndmask_b32_e32 v1, 9, v81, vcc_lo                       // 0000001E7A48: 0202A289
	v_add_co_ci_u32_e64 v88, null, v230, v56, vcc_lo           // 0000001E7A4C: D5207C58 01AA71E6
	.long 0xd73c0037                                           // 0000001E7A54: D73C0037
	v_cndmask_b32_e32 v1, 9, v83, vcc_lo                       // 0000001E7A58: 0202A689
	v_min_i32_e32 v83, s49, v146                               // 0000001E7A5C: 22A72431
	.long 0xd73c0035                                           // 0000001E7A60: D73C0035
	v_cndmask_b32_e32 v1, 9, v53, vcc_lo                       // 0000001E7A64: 02026A89
	.long 0xd7006a93                                           // 0000001E7A68: D7006A93
	v_cndmask_b32_e32 v1, v229, v81, vcc_lo                    // 0000001E7A6C: 0202A3E5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001E7A70: BF870211
	v_add_co_ci_u32_e64 v148, null, v230, v82, vcc_lo          // 0000001E7A74: D5207C94 01AAA5E6
	v_mad_i64_i32 v[83:84], null, v83, 48, s[2:3]              // 0000001E7A7C: D6FF7C53 00096153
	.long 0xd73c0051                                           // 0000001E7A84: D73C0051
	v_cndmask_b32_e32 v1, 9, v85, vcc_lo                       // 0000001E7A88: 0202AA89
	.long 0xd73c0031                                           // 0000001E7A8C: D73C0031
	v_cndmask_b32_e32 v1, 9, v49, vcc_lo                       // 0000001E7A90: 02026289
	.long 0xd7006a99                                           // 0000001E7A94: D7006A99
	v_cndmask_b32_e32 v1, v229, v55, vcc_lo                    // 0000001E7A98: 02026FE5
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001E7A9C: BF870211
	v_add_co_ci_u32_e64 v154, null, v230, v56, vcc_lo          // 0000001E7AA0: D5207C9A 01AA71E6
	.long 0xd7006abb                                           // 0000001E7AA8: D7006ABB
	v_cndmask_b32_e32 v1, v229, v81, vcc_lo                    // 0000001E7AAC: 0202A3E5
	.long 0xd73c0037                                           // 0000001E7AB0: D73C0037
	v_cndmask_b32_e32 v1, 9, v83, vcc_lo                       // 0000001E7AB4: 0202A689
	.long 0xd7000035                                           // 0000001E7AB8: D7000035
	v_cndmask_b32_e32 v1, v229, v53, vcc_lo                    // 0000001E7ABC: 02026BE5
	v_add_co_ci_u32_e64 v188, null, v230, v82, vcc_lo          // 0000001E7AC0: D5207CBC 01AAA5E6
	.long 0xd7006a31                                           // 0000001E7AC8: D7006A31
	v_cndmask_b32_e32 v1, v229, v49, vcc_lo                    // 0000001E7ACC: 020263E5
	v_add_co_ci_u32_e64 v54, null, v230, v54, s0               // 0000001E7AD0: D5207C36 00026DE6
	v_add_co_ci_u32_e64 v50, null, v230, v50, vcc_lo           // 0000001E7AD8: D5207C32 01AA65E6
	.long 0xd7006abd                                           // 0000001E7AE0: D7006ABD
	v_cndmask_b32_e32 v1, v229, v55, vcc_lo                    // 0000001E7AE4: 02026FE5
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E7AE8: BF870001
	v_add_co_ci_u32_e64 v190, null, v230, v56, vcc_lo          // 0000001E7AEC: D5207CBE 01AA71E6
	s_clause 0x1e                                              // 0000001E7AF4: BF85001E
	global_load_b32 v146, v[51:52], off                        // 0000001E7AF8: DC520000 927C0033
	global_load_b32 v159, v[53:54], off                        // 0000001E7B00: DC520000 9F7C0035
	global_load_b32 v155, v[49:50], off offset:64              // 0000001E7B08: DC520040 9B7C0031
	global_load_b32 v156, v[51:52], off offset:64              // 0000001E7B10: DC520040 9C7C0033
	global_load_b32 v150, v[49:50], off offset:128             // 0000001E7B18: DC520080 967C0031
	global_load_b32 v86, v[51:52], off offset:128              // 0000001E7B20: DC520080 567C0033
	global_load_b32 v56, v[51:52], off offset:192              // 0000001E7B28: DC5200C0 387C0033
	global_load_b32 v81, v[49:50], off offset:192              // 0000001E7B30: DC5200C0 517C0031
	global_load_b32 v167, v[87:88], off                        // 0000001E7B38: DC520000 A77C0057
	global_load_b32 v166, v[147:148], off                      // 0000001E7B40: DC520000 A67C0093
	global_load_b32 v158, v[53:54], off offset:64              // 0000001E7B48: DC520040 9E7C0035
	global_load_b32 v157, v[87:88], off offset:64              // 0000001E7B50: DC520040 9D7C0057
	global_load_b32 v149, v[53:54], off offset:128             // 0000001E7B58: DC520080 957C0035
	global_load_b32 v83, v[87:88], off offset:128              // 0000001E7B60: DC520080 537C0057
	global_load_b32 v51, v[87:88], off offset:192              // 0000001E7B68: DC5200C0 337C0057
	global_load_b32 v82, v[53:54], off offset:192              // 0000001E7B70: DC5200C0 527C0035
	global_load_b32 v180, v[153:154], off                      // 0000001E7B78: DC520000 B47C0099
	global_load_b32 v160, v[187:188], off                      // 0000001E7B80: DC520000 A07C00BB
	global_load_b32 v151, v[147:148], off offset:64            // 0000001E7B88: DC520040 977C0093
	global_load_b32 v152, v[153:154], off offset:64            // 0000001E7B90: DC520040 987C0099
	global_load_b32 v87, v[147:148], off offset:128            // 0000001E7B98: DC520080 577C0093
	global_load_b32 v88, v[153:154], off offset:128            // 0000001E7BA0: DC520080 587C0099
	global_load_b32 v52, v[153:154], off offset:192            // 0000001E7BA8: DC5200C0 347C0099
	global_load_b32 v53, v[147:148], off offset:192            // 0000001E7BB0: DC5200C0 357C0093
	global_load_b32 v179, v[189:190], off                      // 0000001E7BB8: DC520000 B37C00BD
	global_load_b32 v153, v[187:188], off offset:64            // 0000001E7BC0: DC520040 997C00BB
	global_load_b32 v154, v[189:190], off offset:64            // 0000001E7BC8: DC520040 9A7C00BD
	global_load_b32 v84, v[187:188], off offset:128            // 0000001E7BD0: DC520080 547C00BB
	global_load_b32 v85, v[189:190], off offset:128            // 0000001E7BD8: DC520080 557C00BD
	global_load_b32 v54, v[189:190], off offset:192            // 0000001E7BE0: DC5200C0 367C00BD
	global_load_b32 v55, v[187:188], off offset:192            // 0000001E7BE8: DC5200C0 377C00BB
	.long 0xd4440000                                           // 0000001E7BF0: D4440000
	v_cndmask_b32_e32 v1, s47, v145, vcc_lo                    // 0000001E7BF4: 0203222F
	s_and_saveexec_b32 s1, s0                                  // 0000001E7BF8: BE812000
	s_cbranch_execz 8                                          // 0000001E7BFC: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3a20>
	global_load_b32 v49, v[49:50], off                         // 0000001E7C00: DC520000 317C0031
	s_waitcnt vmcnt(0)                                         // 0000001E7C08: BF8903F7
	v_fmac_f32_e32 v49, 0xbb800000, v137                       // 0000001E7C0C: 566312FF BB800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E7C14: BF870001
	v_fma_mixlo_f16 v161, v49, s39, 0                          // 0000001E7C18: CC2100A1 02004F31
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001E7C20: 8C7E017E
	s_waitcnt vmcnt(30)                                        // 0000001E7C24: BF897BF7
	v_dual_fmac_f32 v146, 0xbb800000, v138 :: v_dual_add_nc_u32 v147, 4, v145// 0000001E7C28: C82114FF 92932284 BB800000
	s_waitcnt vmcnt(29)                                        // 0000001E7C34: BF8977F7
	v_dual_fmac_f32 v159, 0xbb800000, v139 :: v_dual_add_nc_u32 v148, 2, v145// 0000001E7C38: C82116FF 9F952282 BB800000
	s_waitcnt vmcnt(19)                                        // 0000001E7C44: BF894FF7
	v_dual_fmac_f32 v166, 0xbb800000, v141 :: v_dual_fmac_f32 v157, 0xbb800000, v132// 0000001E7C48: C8011AFF A69D08FF BB800000
	v_fma_mixlo_f16 v49, v146, s39, 0                          // 0000001E7C54: CC210031 02004F92
	v_dual_fmac_f32 v167, 0xbb800000, v140 :: v_dual_add_nc_u32 v146, 6, v145// 0000001E7C5C: C82118FF A7932286 BB800000
	s_waitcnt vmcnt(6)                                         // 0000001E7C68: BF891BF7
	v_dual_fmac_f32 v179, 0xbb800000, v144 :: v_dual_add_nc_u32 v140, 8, v145// 0000001E7C6C: C82120FF B38D2288 BB800000
	v_dual_fmac_f32 v180, 0xbb800000, v142 :: v_dual_add_nc_u32 v139, 10, v145// 0000001E7C78: C8211CFF B48B228A BB800000
	s_waitcnt vmcnt(5)                                         // 0000001E7C84: BF8917F7
	v_dual_fmac_f32 v153, 0xbb800000, v135 :: v_dual_add_nc_u32 v138, 12, v145// 0000001E7C88: C8210EFF 998B228C BB800000
	v_dual_fmac_f32 v160, 0xbb800000, v143 :: v_dual_add_nc_u32 v137, 14, v145// 0000001E7C94: C8211EFF A089228E BB800000
	.long 0xd444000d                                           // 0000001E7CA0: D444000D
	v_cndmask_b32_e32 v1, s47, v148, vcc_lo                    // 0000001E7CA4: 0203282F
	v_dual_fmac_f32 v155, 0xbb800000, v129 :: v_dual_fmac_f32 v156, 0xbb800000, v130// 0000001E7CA8: C80102FF 9B9D04FF BB800000
	.long 0xd444000c                                           // 0000001E7CB4: D444000C
	v_cndmask_b32_e32 v1, s47, v147, vcc_lo                    // 0000001E7CB8: 0203262F
	v_fma_mixhi_f16 v49, v159, s39, 0                          // 0000001E7CBC: CC220031 02004F9F
	.long 0xd444000b                                           // 0000001E7CC4: D444000B
	v_cndmask_b32_e32 v1, s47, v146, vcc_lo                    // 0000001E7CC8: 0203242F
	v_fma_mixlo_f16 v50, v167, s39, 0                          // 0000001E7CCC: CC210032 02004FA7
	.long 0xd444000a                                           // 0000001E7CD4: D444000A
	v_cndmask_b32_e32 v1, s47, v140, vcc_lo                    // 0000001E7CD8: 0203182F
	v_fma_mixhi_f16 v50, v166, s39, 0                          // 0000001E7CDC: CC220032 02004FA6
	v_dual_fmac_f32 v158, 0xbb800000, v131 :: v_dual_fmac_f32 v151, 0xbb800000, v133// 0000001E7CE4: C80106FF 9E970AFF BB800000
	.long 0xd4440008                                           // 0000001E7CF0: D4440008
	v_cndmask_b32_e32 v1, s47, v139, vcc_lo                    // 0000001E7CF4: 0203162F
	v_fma_mixlo_f16 v141, v180, s39, 0                         // 0000001E7CF8: CC21008D 02004FB4
	.long 0xd4440009                                           // 0000001E7D00: D4440009
	v_cndmask_b32_e32 v1, s47, v138, vcc_lo                    // 0000001E7D04: 0203142F
	v_fma_mixhi_f16 v141, v160, s39, 0                         // 0000001E7D08: CC22008D 02004FA0
	.long 0xd4440001                                           // 0000001E7D10: D4440001
	v_cndmask_b32_e32 v1, s47, v137, vcc_lo                    // 0000001E7D14: 0203122F
	v_fma_mixlo_f16 v142, v179, s39, 0                         // 0000001E7D18: CC21008E 02004FB3
	v_cndmask_b16 v49, 0, v49, s13                             // 0000001E7D20: D65D0031 00366280
	v_fma_mixlo_f16 v130, v155, s39, 0                         // 0000001E7D28: CC210082 02004F9B
	v_cndmask_b16 v49, 0, v49, s12                             // 0000001E7D30: D65D5031 00326280
	v_fma_mixhi_f16 v130, v156, s39, 0                         // 0000001E7D38: CC220082 02004F9C
	v_dual_fmac_f32 v152, 0xbb800000, v134 :: v_dual_fmac_f32 v149, 0xbb800000, v115// 0000001E7D40: C8010CFF 9894E6FF BB800000
	s_waitcnt vmcnt(4)                                         // 0000001E7D4C: BF8913F7
	v_dual_fmac_f32 v154, 0xbb800000, v136 :: v_dual_fmac_f32 v87, 0xbb800000, v117// 0000001E7D50: C80110FF 9A56EAFF BB800000
	v_cndmask_b16 v50, 0, v50, s11                             // 0000001E7D5C: D65D0032 002E6480
	v_cndmask_b16 v50, 0, v50, s10                             // 0000001E7D64: D65D5032 002A6480
	v_fma_mixlo_f16 v131, v158, s39, 0                         // 0000001E7D6C: CC210083 02004F9E
	v_cndmask_b16 v141, 0, v141, s8                            // 0000001E7D74: D65D008D 00231A80
	v_cndmask_b16 v129, 0, v141, s9                            // 0000001E7D7C: D65D1081 00271A80
	v_cndmask_b16 v129, 0, v142, s1                            // 0000001E7D84: D65D4081 00071C80
	ds_store_b16 v231, v161                                    // 0000001E7D8C: D87C0000 0000A1E7
	ds_store_b16 v231, v49 offset:4                            // 0000001E7D94: D87C0004 000031E7
	ds_store_b16_d16_hi v231, v49 offset:8                     // 0000001E7D9C: DA840008 000031E7
	ds_store_b16 v231, v50 offset:12                           // 0000001E7DA4: D87C000C 000032E7
	ds_store_b16_d16_hi v231, v50 offset:16                    // 0000001E7DAC: DA840010 000032E7
	ds_store_b16 v231, v141 offset:20                          // 0000001E7DB4: D87C0014 00008DE7
	ds_store_b16 v231, v129 offset:24                          // 0000001E7DBC: D87C0018 000081E7
	ds_store_b16_d16_hi v231, v129 offset:28                   // 0000001E7DC4: DA84001C 000081E7
	v_fma_mixhi_f16 v50, v157, s39, 0                          // 0000001E7DCC: CC220032 02004F9D
	v_cndmask_b16 v49, 0, v130, s0                             // 0000001E7DD4: D65D0031 00030480
	v_fma_mixlo_f16 v129, v151, s39, 0                         // 0000001E7DDC: CC210081 02004F97
	v_fma_mixlo_f16 v130, v153, s39, 0                         // 0000001E7DE4: CC210082 02004F99
	v_dual_fmac_f32 v150, 0xbb800000, v113 :: v_dual_fmac_f32 v83, 0xbb800000, v116// 0000001E7DEC: C800E2FF 9652E8FF BB800000
	v_cndmask_b16 v49, 0, v130, s13                            // 0000001E7DF8: D65D5031 00370480
	v_fma_mixhi_f16 v129, v152, s39, 0                         // 0000001E7E00: CC220081 02004F98
	v_fma_mixhi_f16 v130, v154, s39, 0                         // 0000001E7E08: CC220082 02004F9A
	s_waitcnt vmcnt(2)                                         // 0000001E7E10: BF890BF7
	v_dual_fmac_f32 v86, 0xbb800000, v114 :: v_dual_fmac_f32 v85, 0xbb800000, v120// 0000001E7E14: C800E4FF 5654F0FF BB800000
	v_cndmask_b16 v50, 0, v131, s12                            // 0000001E7E20: D65D0032 00330680
	v_cndmask_b16 v50, 0, v50, s11                             // 0000001E7E28: D65D5032 002E6480
	v_cndmask_b16 v113, 0, v129, s10                           // 0000001E7E30: D65D0071 002B0280
	v_cndmask_b16 v129, 0, v130, s9                            // 0000001E7E38: D65D0081 00270480
	v_fma_mixlo_f16 v130, v150, s39, 0                         // 0000001E7E40: CC210082 02004F96
	v_dual_fmac_f32 v88, 0xbb800000, v118 :: v_dual_fmac_f32 v81, 0xbb800000, v97// 0000001E7E48: C800ECFF 5850C2FF BB800000
	v_dual_fmac_f32 v84, 0xbb800000, v119 :: v_dual_fmac_f32 v51, 0xbb800000, v100// 0000001E7E54: C800EEFF 5432C8FF BB800000
	v_cndmask_b16 v113, 0, v129, s8                            // 0000001E7E60: D65D5071 00230280
	v_cndmask_b16 v129, 0, v130, s1                            // 0000001E7E68: D65D5081 00070480
	ds_store_b16 v231, v49 offset:2304                         // 0000001E7E70: D87C0900 000031E7
	ds_store_b16_d16_hi v231, v49 offset:2308                  // 0000001E7E78: DA840904 000031E7
	ds_store_b16 v231, v50 offset:2312                         // 0000001E7E80: D87C0908 000032E7
	ds_store_b16_d16_hi v231, v50 offset:2316                  // 0000001E7E88: DA84090C 000032E7
	ds_store_b16 v231, v113 offset:2320                        // 0000001E7E90: D87C0910 000071E7
	ds_store_b16_d16_hi v231, v113 offset:2324                 // 0000001E7E98: DA840914 000071E7
	ds_store_b16 v231, v129 offset:2328                        // 0000001E7EA0: D87C0918 000081E7
	ds_store_b16_d16_hi v231, v129 offset:2332                 // 0000001E7EA8: DA84091C 000081E7
	v_fma_mixhi_f16 v49, v86, s39, 0                           // 0000001E7EB0: CC220031 02004F56
	v_fma_mixlo_f16 v50, v149, s39, 0                          // 0000001E7EB8: CC210032 02004F95
	v_fma_mixhi_f16 v50, v83, s39, 0                           // 0000001E7EC0: CC220032 02004F53
	v_fma_mixlo_f16 v83, v87, s39, 0                           // 0000001E7EC8: CC210053 02004F57
	v_cndmask_b16 v49, 0, v130, s0                             // 0000001E7ED0: D65D0031 00030480
	v_fma_mixhi_f16 v83, v88, s39, 0                           // 0000001E7ED8: CC220053 02004F58
	v_fma_mixlo_f16 v84, v84, s39, 0                           // 0000001E7EE0: CC210054 02004F54
	v_fma_mixhi_f16 v84, v85, s39, 0                           // 0000001E7EE8: CC220054 02004F55
	v_dual_fmac_f32 v56, 0xbb800000, v98 :: v_dual_fmac_f32 v53, 0xbb800000, v101// 0000001E7EF0: C800C4FF 3834CAFF BB800000
	v_fmac_f32_e32 v82, 0xbb800000, v99                        // 0000001E7EFC: 56A4C6FF BB800000
	s_waitcnt vmcnt(0)                                         // 0000001E7F04: BF8903F7
	v_dual_fmac_f32 v52, 0xbb800000, v102 :: v_dual_fmac_f32 v55, 0xbb800000, v103// 0000001E7F08: C800CCFF 3436CEFF BB800000
	v_fmac_f32_e32 v54, 0xbb800000, v104                       // 0000001E7F14: 566CD0FF BB800000
	v_cndmask_b16 v49, 0, v49, s13                             // 0000001E7F1C: D65D5031 00366280
	v_cndmask_b16 v50, 0, v50, s12                             // 0000001E7F24: D65D0032 00326480
	v_cndmask_b16 v50, 0, v50, s11                             // 0000001E7F2C: D65D5032 002E6480
	v_cndmask_b16 v83, 0, v83, s10                             // 0000001E7F34: D65D0053 002AA680
	v_cndmask_b16 v83, 0, v83, s8                              // 0000001E7F3C: D65D5053 0022A680
	v_cndmask_b16 v84, 0, v84, s9                              // 0000001E7F44: D65D0054 0026A880
	v_cndmask_b16 v84, 0, v84, s1                              // 0000001E7F4C: D65D5054 0006A880
	v_fma_mixlo_f16 v81, v81, s39, 0                           // 0000001E7F54: CC210051 02004F51
	v_fma_mixlo_f16 v56, v56, s39, 0                           // 0000001E7F5C: CC210038 02004F38
	v_fma_mixhi_f16 v56, v82, s39, 0                           // 0000001E7F64: CC220038 02004F52
	ds_store_b16 v231, v49 offset:4608                         // 0000001E7F6C: D87C1200 000031E7
	ds_store_b16_d16_hi v231, v49 offset:4612                  // 0000001E7F74: DA841204 000031E7
	ds_store_b16 v231, v50 offset:4616                         // 0000001E7F7C: D87C1208 000032E7
	ds_store_b16_d16_hi v231, v50 offset:4620                  // 0000001E7F84: DA84120C 000032E7
	ds_store_b16 v231, v83 offset:4624                         // 0000001E7F8C: D87C1210 000053E7
	ds_store_b16_d16_hi v231, v83 offset:4628                  // 0000001E7F94: DA841214 000053E7
	ds_store_b16 v231, v84 offset:4632                         // 0000001E7F9C: D87C1218 000054E7
	ds_store_b16_d16_hi v231, v84 offset:4636                  // 0000001E7FA4: DA84121C 000054E7
	v_fma_mixhi_f16 v50, v51, s39, 0                           // 0000001E7FAC: CC220032 02004F33
	v_fma_mixlo_f16 v51, v53, s39, 0                           // 0000001E7FB4: CC210033 02004F35
	v_fma_mixhi_f16 v51, v52, s39, 0                           // 0000001E7FBC: CC220033 02004F34
	v_fma_mixlo_f16 v52, v55, s39, 0                           // 0000001E7FC4: CC210034 02004F37
	v_fma_mixhi_f16 v52, v54, s39, 0                           // 0000001E7FCC: CC220034 02004F36
	v_cndmask_b16 v49, 0, v81, s0                              // 0000001E7FD4: D65D0031 0002A280
	v_cndmask_b16 v49, 0, v56, s13                             // 0000001E7FDC: D65D4031 00367080
	v_cndmask_b16 v50, 0, v56, s12                             // 0000001E7FE4: D65D1032 00327080
	v_cndmask_b16 v50, 0, v50, s11                             // 0000001E7FEC: D65D5032 002E6480
	v_cndmask_b16 v51, 0, v51, s10                             // 0000001E7FF4: D65D0033 002A6680
	v_cndmask_b16 v51, 0, v51, s8                              // 0000001E7FFC: D65D5033 00226680
	v_cndmask_b16 v52, 0, v52, s9                              // 0000001E8004: D65D0034 00266880
	v_cndmask_b16 v52, 0, v52, s1                              // 0000001E800C: D65D5034 00066880
	ds_store_b16 v231, v49 offset:6912                         // 0000001E8014: D87C1B00 000031E7
	ds_store_b16_d16_hi v231, v49 offset:6916                  // 0000001E801C: DA841B04 000031E7
	ds_store_b16 v231, v50 offset:6920                         // 0000001E8024: D87C1B08 000032E7
	ds_store_b16_d16_hi v231, v50 offset:6924                  // 0000001E802C: DA841B0C 000032E7
	ds_store_b16 v231, v51 offset:6928                         // 0000001E8034: D87C1B10 000033E7
	ds_store_b16_d16_hi v231, v51 offset:6932                  // 0000001E803C: DA841B14 000033E7
	ds_store_b16 v231, v52 offset:6936                         // 0000001E8044: D87C1B18 000034E7
	ds_store_b16_d16_hi v231, v52 offset:6940                  // 0000001E804C: DA841B1C 000034E7
	s_waitcnt lgkmcnt(0)                                       // 0000001E8054: BF89FC07
	s_barrier                                                  // 0000001E8058: BFBD0000
	buffer_gl0_inv                                             // 0000001E805C: E0AC0000 00000000
	ds_load_b128 v[49:52], v183                                // 0000001E8064: DBFC0000 310000B7
	ds_load_b128 v[53:56], v183 offset:16                      // 0000001E806C: DBFC0010 350000B7
	ds_load_b128 v[81:84], v183 offset:32                      // 0000001E8074: DBFC0020 510000B7
	ds_load_b128 v[85:88], v183 offset:48                      // 0000001E807C: DBFC0030 550000B7
	ds_load_b128 v[97:100], v183 offset:8448                   // 0000001E8084: DBFC2100 610000B7
	ds_load_b128 v[101:104], v183 offset:8464                  // 0000001E808C: DBFC2110 650000B7
	ds_load_b128 v[113:116], v183 offset:8480                  // 0000001E8094: DBFC2120 710000B7
	ds_load_b128 v[117:120], v183 offset:8496                  // 0000001E809C: DBFC2130 750000B7
	v_dual_mov_b32 v136, s27 :: v_dual_mov_b32 v135, s26       // 0000001E80A4: CA10001B 8886001A
	v_dual_mov_b32 v134, s25 :: v_dual_mov_b32 v133, s24       // 0000001E80AC: CA100019 86840018
	v_dual_mov_b32 v132, s23 :: v_dual_mov_b32 v131, s22       // 0000001E80B4: CA100017 84820016
	v_dual_mov_b32 v130, s21 :: v_dual_mov_b32 v129, s20       // 0000001E80BC: CA100015 82800014
	ds_load_b128 v[141:144], v183 offset:112                   // 0000001E80C4: DBFC0070 8D0000B7
	s_waitcnt lgkmcnt(8)                                       // 0000001E80CC: BF89FC87
	v_fma_mixlo_f16 v49, v49, s39, 0                           // 0000001E80D0: CC210031 02004F31
	v_fma_mixhi_f16 v49, v50, s39, 0                           // 0000001E80D8: CC220031 02004F32
	v_fma_mixlo_f16 v50, v51, s39, 0                           // 0000001E80E0: CC210032 02004F33
	s_waitcnt lgkmcnt(7)                                       // 0000001E80E8: BF89FC77
	v_fma_mixlo_f16 v51, v53, s39, 0                           // 0000001E80EC: CC210033 02004F35
	s_waitcnt lgkmcnt(6)                                       // 0000001E80F4: BF89FC67
	v_fma_mixlo_f16 v53, v81, s39, 0                           // 0000001E80F8: CC210035 02004F51
	v_fma_mixhi_f16 v53, v82, s39, 0                           // 0000001E8100: CC220035 02004F52
	s_waitcnt lgkmcnt(4)                                       // 0000001E8108: BF89FC47
	v_fma_mixlo_f16 v81, v97, s39, 0                           // 0000001E810C: CC210051 02004F61
	v_fma_mixhi_f16 v81, v98, s39, 0                           // 0000001E8114: CC220051 02004F62
	v_fma_mixlo_f16 v82, v99, s39, 0                           // 0000001E811C: CC210052 02004F63
	v_fma_mixhi_f16 v82, v100, s39, 0                          // 0000001E8124: CC220052 02004F64
	ds_load_b128 v[97:100], v183 offset:16896                  // 0000001E812C: DBFC4200 610000B7
	v_fma_mixhi_f16 v51, v54, s39, 0                           // 0000001E8134: CC220033 02004F36
	v_fma_mixlo_f16 v54, v83, s39, 0                           // 0000001E813C: CC210036 02004F53
	v_fma_mixhi_f16 v54, v84, s39, 0                           // 0000001E8144: CC220036 02004F54
	s_waitcnt lgkmcnt(4)                                       // 0000001E814C: BF89FC47
	v_fma_mixlo_f16 v83, v101, s39, 0                          // 0000001E8150: CC210053 02004F65
	v_fma_mixhi_f16 v83, v102, s39, 0                          // 0000001E8158: CC220053 02004F66
	v_fma_mixlo_f16 v84, v103, s39, 0                          // 0000001E8160: CC210054 02004F67
	v_fma_mixhi_f16 v84, v104, s39, 0                          // 0000001E8168: CC220054 02004F68
	ds_load_b128 v[101:104], v183 offset:16912                 // 0000001E8170: DBFC4210 650000B7
	v_fma_mixhi_f16 v50, v52, s39, 0                           // 0000001E8178: CC220032 02004F34
	v_fma_mixlo_f16 v52, v55, s39, 0                           // 0000001E8180: CC210034 02004F37
	v_fma_mixhi_f16 v52, v56, s39, 0                           // 0000001E8188: CC220034 02004F38
	v_fma_mixlo_f16 v55, v85, s39, 0                           // 0000001E8190: CC210037 02004F55
	v_fma_mixhi_f16 v55, v86, s39, 0                           // 0000001E8198: CC220037 02004F56
	v_fma_mixlo_f16 v56, v87, s39, 0                           // 0000001E81A0: CC210038 02004F57
	v_fma_mixhi_f16 v56, v88, s39, 0                           // 0000001E81A8: CC220038 02004F58
	s_waitcnt lgkmcnt(4)                                       // 0000001E81B0: BF89FC47
	v_fma_mixlo_f16 v85, v113, s39, 0                          // 0000001E81B4: CC210055 02004F71
	v_fma_mixhi_f16 v85, v114, s39, 0                          // 0000001E81BC: CC220055 02004F72
	v_fma_mixlo_f16 v86, v115, s39, 0                          // 0000001E81C4: CC210056 02004F73
	v_fma_mixhi_f16 v86, v116, s39, 0                          // 0000001E81CC: CC220056 02004F74
	s_waitcnt lgkmcnt(1)                                       // 0000001E81D4: BF89FC17
	v_fma_mixlo_f16 v149, v97, s39, 0                          // 0000001E81D8: CC210095 02004F61
	v_fma_mixhi_f16 v149, v98, s39, 0                          // 0000001E81E0: CC220095 02004F62
	v_fma_mixlo_f16 v150, v99, s39, 0                          // 0000001E81E8: CC210096 02004F63
	v_fma_mixhi_f16 v150, v100, s39, 0                         // 0000001E81F0: CC220096 02004F64
	ds_load_b128 v[97:100], v183 offset:16928                  // 0000001E81F8: DBFC4220 610000B7
	v_fma_mixlo_f16 v87, v117, s39, 0                          // 0000001E8200: CC210057 02004F75
	v_fma_mixhi_f16 v87, v118, s39, 0                          // 0000001E8208: CC220057 02004F76
	v_fma_mixlo_f16 v88, v119, s39, 0                          // 0000001E8210: CC210058 02004F77
	s_waitcnt lgkmcnt(1)                                       // 0000001E8218: BF89FC17
	v_fma_mixlo_f16 v151, v101, s39, 0                         // 0000001E821C: CC210097 02004F65
	v_fma_mixhi_f16 v151, v102, s39, 0                         // 0000001E8224: CC220097 02004F66
	v_fma_mixlo_f16 v152, v103, s39, 0                         // 0000001E822C: CC210098 02004F67
	v_fma_mixhi_f16 v152, v104, s39, 0                         // 0000001E8234: CC220098 02004F68
	ds_load_b128 v[101:104], v183 offset:16944                 // 0000001E823C: DBFC4230 650000B7
	v_fma_mixhi_f16 v88, v120, s39, 0                          // 0000001E8244: CC220058 02004F78
	v_wmma_f32_16x16x16_f16 v[113:120], v[121:128], v[49:56], v[129:136]// 0000001E824C: CC404071 1E066379
	s_waitcnt lgkmcnt(1)                                       // 0000001E8254: BF89FC17
	v_fma_mixlo_f16 v153, v97, s39, 0                          // 0000001E8258: CC210099 02004F61
	v_fma_mixhi_f16 v153, v98, s39, 0                          // 0000001E8260: CC220099 02004F62
	v_fma_mixlo_f16 v154, v99, s39, 0                          // 0000001E8268: CC21009A 02004F63
	v_fma_mixhi_f16 v154, v100, s39, 0                         // 0000001E8270: CC22009A 02004F64
	ds_load_b128 v[97:100], v183 offset:25344                  // 0000001E8278: DBFC6300 610000B7
	s_waitcnt lgkmcnt(1)                                       // 0000001E8280: BF89FC17
	v_fma_mixlo_f16 v155, v101, s39, 0                         // 0000001E8284: CC21009B 02004F65
	v_fma_mixhi_f16 v155, v102, s39, 0                         // 0000001E828C: CC22009B 02004F66
	v_fma_mixlo_f16 v156, v103, s39, 0                         // 0000001E8294: CC21009C 02004F67
	v_fma_mixhi_f16 v156, v104, s39, 0                         // 0000001E829C: CC22009C 02004F68
	s_waitcnt lgkmcnt(0)                                       // 0000001E82A4: BF89FC07
	v_fma_mixlo_f16 v187, v97, s39, 0                          // 0000001E82A8: CC2100BB 02004F61
	v_fma_mixhi_f16 v187, v98, s39, 0                          // 0000001E82B0: CC2200BB 02004F62
	v_fma_mixlo_f16 v188, v99, s39, 0                          // 0000001E82B8: CC2100BC 02004F63
	v_fma_mixhi_f16 v188, v100, s39, 0                         // 0000001E82C0: CC2200BC 02004F64
	ds_load_b128 v[97:100], v183 offset:25360                  // 0000001E82C8: DBFC6310 610000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E82D0: BF89FC07
	v_fma_mixlo_f16 v189, v97, s39, 0                          // 0000001E82D4: CC2100BD 02004F61
	v_fma_mixhi_f16 v189, v98, s39, 0                          // 0000001E82DC: CC2200BD 02004F62
	v_fma_mixlo_f16 v190, v99, s39, 0                          // 0000001E82E4: CC2100BE 02004F63
	v_fma_mixhi_f16 v190, v100, s39, 0                         // 0000001E82EC: CC2200BE 02004F64
	ds_load_b128 v[97:100], v183 offset:25376                  // 0000001E82F4: DBFC6320 610000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E82FC: BF89FC07
	v_fma_mixlo_f16 v191, v97, s39, 0                          // 0000001E8300: CC2100BF 02004F61
	v_fma_mixhi_f16 v191, v98, s39, 0                          // 0000001E8308: CC2200BF 02004F62
	v_fma_mixlo_f16 v192, v99, s39, 0                          // 0000001E8310: CC2100C0 02004F63
	v_fma_mixhi_f16 v192, v100, s39, 0                         // 0000001E8318: CC2200C0 02004F64
	ds_load_b128 v[97:100], v183 offset:25392                  // 0000001E8320: DBFC6330 610000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E8328: BF89FC07
	v_fma_mixlo_f16 v193, v97, s39, 0                          // 0000001E832C: CC2100C1 02004F61
	v_fma_mixhi_f16 v193, v98, s39, 0                          // 0000001E8334: CC2200C1 02004F62
	v_fma_mixlo_f16 v194, v99, s39, 0                          // 0000001E833C: CC2100C2 02004F63
	v_fma_mixhi_f16 v194, v100, s39, 0                         // 0000001E8344: CC2200C2 02004F64
	v_wmma_f32_16x16x16_f16 v[97:104], v[121:128], v[81:88], v[129:136]// 0000001E834C: CC404061 1E06A379
	v_wmma_f32_16x16x16_f16 v[81:88], v[121:128], v[149:156], v[129:136]// 0000001E8354: CC404051 1E072B79
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001E835C: BF870003
	v_wmma_f32_16x16x16_f16 v[49:56], v[121:128], v[187:194], v[129:136]// 0000001E8360: CC404031 1E077779
	ds_load_b128 v[121:124], v183 offset:64                    // 0000001E8368: DBFC0040 790000B7
	ds_load_b128 v[153:156], v185 offset:6928                  // 0000001E8370: DBFC1B10 990000B9
	ds_load_b128 v[149:152], v185 offset:6912                  // 0000001E8378: DBFC1B00 950000B9
	s_waitcnt lgkmcnt(2)                                       // 0000001E8380: BF89FC27
	v_fma_mixlo_f16 v121, v121, s39, 0                         // 0000001E8384: CC210079 02004F79
	v_fma_mixhi_f16 v121, v122, s39, 0                         // 0000001E838C: CC220079 02004F7A
	v_fma_mixlo_f16 v122, v123, s39, 0                         // 0000001E8394: CC21007A 02004F7B
	v_fma_mixhi_f16 v122, v124, s39, 0                         // 0000001E839C: CC22007A 02004F7C
	ds_load_b128 v[123:126], v183 offset:80                    // 0000001E83A4: DBFC0050 7B0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E83AC: BF89FC07
	v_fma_mixlo_f16 v123, v123, s39, 0                         // 0000001E83B0: CC21007B 02004F7B
	v_fma_mixhi_f16 v123, v124, s39, 0                         // 0000001E83B8: CC22007B 02004F7C
	v_fma_mixlo_f16 v124, v125, s39, 0                         // 0000001E83C0: CC21007C 02004F7D
	v_fma_mixhi_f16 v124, v126, s39, 0                         // 0000001E83C8: CC22007C 02004F7E
	ds_load_b128 v[125:128], v183 offset:96                    // 0000001E83D0: DBFC0060 7D0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E83D8: BF89FC07
	v_fma_mixlo_f16 v125, v125, s39, 0                         // 0000001E83DC: CC21007D 02004F7D
	v_fma_mixhi_f16 v125, v126, s39, 0                         // 0000001E83E4: CC22007D 02004F7E
	v_fma_mixlo_f16 v126, v127, s39, 0                         // 0000001E83EC: CC21007E 02004F7F
	v_fma_mixhi_f16 v126, v128, s39, 0                         // 0000001E83F4: CC22007E 02004F80
	v_fma_mixlo_f16 v127, v141, s39, 0                         // 0000001E83FC: CC21007F 02004F8D
	v_fma_mixhi_f16 v127, v142, s39, 0                         // 0000001E8404: CC22007F 02004F8E
	v_fma_mixlo_f16 v128, v143, s39, 0                         // 0000001E840C: CC210080 02004F8F
	v_fma_mixhi_f16 v128, v144, s39, 0                         // 0000001E8414: CC220080 02004F90
	ds_load_b128 v[141:144], v183 offset:8560                  // 0000001E841C: DBFC2170 8D0000B7
	v_wmma_f32_16x16x16_f16 v[113:120], v[105:112], v[121:128], v[113:120]// 0000001E8424: CC404071 1DC6F369
	ds_load_b128 v[121:124], v183 offset:8512                  // 0000001E842C: DBFC2140 790000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E8434: BF89FC07
	v_fma_mixlo_f16 v121, v121, s39, 0                         // 0000001E8438: CC210079 02004F79
	v_fma_mixhi_f16 v121, v122, s39, 0                         // 0000001E8440: CC220079 02004F7A
	v_fma_mixlo_f16 v122, v123, s39, 0                         // 0000001E8448: CC21007A 02004F7B
	v_fma_mixhi_f16 v122, v124, s39, 0                         // 0000001E8450: CC22007A 02004F7C
	ds_load_b128 v[123:126], v183 offset:8528                  // 0000001E8458: DBFC2150 7B0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E8460: BF89FC07
	v_fma_mixlo_f16 v123, v123, s39, 0                         // 0000001E8464: CC21007B 02004F7B
	v_fma_mixhi_f16 v123, v124, s39, 0                         // 0000001E846C: CC22007B 02004F7C
	v_fma_mixlo_f16 v124, v125, s39, 0                         // 0000001E8474: CC21007C 02004F7D
	v_fma_mixhi_f16 v124, v126, s39, 0                         // 0000001E847C: CC22007C 02004F7E
	ds_load_b128 v[125:128], v183 offset:8544                  // 0000001E8484: DBFC2160 7D0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E848C: BF89FC07
	v_fma_mixlo_f16 v125, v125, s39, 0                         // 0000001E8490: CC21007D 02004F7D
	v_fma_mixhi_f16 v125, v126, s39, 0                         // 0000001E8498: CC22007D 02004F7E
	v_fma_mixlo_f16 v126, v127, s39, 0                         // 0000001E84A0: CC21007E 02004F7F
	v_fma_mixhi_f16 v126, v128, s39, 0                         // 0000001E84A8: CC22007E 02004F80
	v_fma_mixlo_f16 v127, v141, s39, 0                         // 0000001E84B0: CC21007F 02004F8D
	v_fma_mixhi_f16 v127, v142, s39, 0                         // 0000001E84B8: CC22007F 02004F8E
	v_fma_mixlo_f16 v128, v143, s39, 0                         // 0000001E84C0: CC210080 02004F8F
	v_fma_mixhi_f16 v128, v144, s39, 0                         // 0000001E84C8: CC220080 02004F90
	ds_load_b128 v[141:144], v183 offset:17008                 // 0000001E84D0: DBFC4270 8D0000B7
	v_wmma_f32_16x16x16_f16 v[97:104], v[105:112], v[121:128], v[97:104]// 0000001E84D8: CC404061 1D86F369
	ds_load_b128 v[121:124], v183 offset:16960                 // 0000001E84E0: DBFC4240 790000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E84E8: BF89FC07
	v_fma_mixlo_f16 v121, v121, s39, 0                         // 0000001E84EC: CC210079 02004F79
	v_fma_mixhi_f16 v121, v122, s39, 0                         // 0000001E84F4: CC220079 02004F7A
	v_fma_mixlo_f16 v122, v123, s39, 0                         // 0000001E84FC: CC21007A 02004F7B
	v_fma_mixhi_f16 v122, v124, s39, 0                         // 0000001E8504: CC22007A 02004F7C
	ds_load_b128 v[123:126], v183 offset:16976                 // 0000001E850C: DBFC4250 7B0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E8514: BF89FC07
	v_fma_mixlo_f16 v123, v123, s39, 0                         // 0000001E8518: CC21007B 02004F7B
	v_fma_mixhi_f16 v123, v124, s39, 0                         // 0000001E8520: CC22007B 02004F7C
	v_fma_mixlo_f16 v124, v125, s39, 0                         // 0000001E8528: CC21007C 02004F7D
	v_fma_mixhi_f16 v124, v126, s39, 0                         // 0000001E8530: CC22007C 02004F7E
	ds_load_b128 v[125:128], v183 offset:16992                 // 0000001E8538: DBFC4260 7D0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E8540: BF89FC07
	v_fma_mixlo_f16 v125, v125, s39, 0                         // 0000001E8544: CC21007D 02004F7D
	v_fma_mixhi_f16 v125, v126, s39, 0                         // 0000001E854C: CC22007D 02004F7E
	v_fma_mixlo_f16 v126, v127, s39, 0                         // 0000001E8554: CC21007E 02004F7F
	v_fma_mixhi_f16 v126, v128, s39, 0                         // 0000001E855C: CC22007E 02004F80
	v_fma_mixlo_f16 v127, v141, s39, 0                         // 0000001E8564: CC21007F 02004F8D
	v_fma_mixhi_f16 v127, v142, s39, 0                         // 0000001E856C: CC22007F 02004F8E
	v_fma_mixlo_f16 v128, v143, s39, 0                         // 0000001E8574: CC210080 02004F8F
	v_fma_mixhi_f16 v128, v144, s39, 0                         // 0000001E857C: CC220080 02004F90
	ds_load_b128 v[141:144], v183 offset:25456                 // 0000001E8584: DBFC6370 8D0000B7
	v_wmma_f32_16x16x16_f16 v[81:88], v[105:112], v[121:128], v[81:88]// 0000001E858C: CC404051 1D46F369
	ds_load_b128 v[121:124], v183 offset:25408                 // 0000001E8594: DBFC6340 790000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E859C: BF89FC07
	v_fma_mixlo_f16 v121, v121, s39, 0                         // 0000001E85A0: CC210079 02004F79
	v_fma_mixhi_f16 v121, v122, s39, 0                         // 0000001E85A8: CC220079 02004F7A
	v_fma_mixlo_f16 v122, v123, s39, 0                         // 0000001E85B0: CC21007A 02004F7B
	v_fma_mixhi_f16 v122, v124, s39, 0                         // 0000001E85B8: CC22007A 02004F7C
	ds_load_b128 v[123:126], v183 offset:25424                 // 0000001E85C0: DBFC6350 7B0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E85C8: BF89FC07
	v_fma_mixlo_f16 v123, v123, s39, 0                         // 0000001E85CC: CC21007B 02004F7B
	v_fma_mixhi_f16 v123, v124, s39, 0                         // 0000001E85D4: CC22007B 02004F7C
	v_fma_mixlo_f16 v124, v125, s39, 0                         // 0000001E85DC: CC21007C 02004F7D
	v_fma_mixhi_f16 v124, v126, s39, 0                         // 0000001E85E4: CC22007C 02004F7E
	ds_load_b128 v[125:128], v183 offset:25440                 // 0000001E85EC: DBFC6360 7D0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E85F4: BF89FC07
	v_fma_mixlo_f16 v125, v125, s39, 0                         // 0000001E85F8: CC21007D 02004F7D
	v_fma_mixhi_f16 v125, v126, s39, 0                         // 0000001E8600: CC22007D 02004F7E
	v_fma_mixlo_f16 v126, v127, s39, 0                         // 0000001E8608: CC21007E 02004F7F
	v_fma_mixhi_f16 v126, v128, s39, 0                         // 0000001E8610: CC22007E 02004F80
	v_fma_mixlo_f16 v127, v141, s39, 0                         // 0000001E8618: CC21007F 02004F8D
	v_fma_mixhi_f16 v127, v142, s39, 0                         // 0000001E8620: CC22007F 02004F8E
	v_fma_mixlo_f16 v128, v143, s39, 0                         // 0000001E8628: CC210080 02004F8F
	v_fma_mixhi_f16 v128, v144, s39, 0                         // 0000001E8630: CC220080 02004F90
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E8638: BF870001
	v_wmma_f32_16x16x16_f16 v[49:56], v[105:112], v[121:128], v[49:56]// 0000001E863C: CC404031 1CC6F369
	ds_load_b128 v[105:108], v183 offset:128                   // 0000001E8644: DBFC0080 690000B7
	ds_load_b128 v[121:124], v183 offset:176                   // 0000001E864C: DBFC00B0 790000B7
	ds_load_b128 v[125:128], v183 offset:25840                 // 0000001E8654: DBFC64F0 7D0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E865C: BF89FC27
	v_fma_mixlo_f16 v105, v105, s39, 0                         // 0000001E8660: CC210069 02004F69
	v_fma_mixhi_f16 v105, v106, s39, 0                         // 0000001E8668: CC220069 02004F6A
	v_fma_mixlo_f16 v106, v107, s39, 0                         // 0000001E8670: CC21006A 02004F6B
	v_fma_mixhi_f16 v106, v108, s39, 0                         // 0000001E8678: CC22006A 02004F6C
	ds_load_b128 v[107:110], v183 offset:144                   // 0000001E8680: DBFC0090 6B0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E8688: BF89FC07
	v_fma_mixlo_f16 v107, v107, s39, 0                         // 0000001E868C: CC21006B 02004F6B
	v_fma_mixhi_f16 v107, v108, s39, 0                         // 0000001E8694: CC22006B 02004F6C
	v_fma_mixlo_f16 v108, v109, s39, 0                         // 0000001E869C: CC21006C 02004F6D
	v_fma_mixhi_f16 v108, v110, s39, 0                         // 0000001E86A4: CC22006C 02004F6E
	ds_load_b128 v[109:112], v183 offset:160                   // 0000001E86AC: DBFC00A0 6D0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E86B4: BF89FC07
	v_fma_mixlo_f16 v109, v109, s39, 0                         // 0000001E86B8: CC21006D 02004F6D
	v_fma_mixhi_f16 v109, v110, s39, 0                         // 0000001E86C0: CC22006D 02004F6E
	v_fma_mixlo_f16 v110, v111, s39, 0                         // 0000001E86C8: CC21006E 02004F6F
	v_fma_mixhi_f16 v110, v112, s39, 0                         // 0000001E86D0: CC22006E 02004F70
	v_fma_mixlo_f16 v111, v121, s39, 0                         // 0000001E86D8: CC21006F 02004F79
	v_fma_mixhi_f16 v111, v122, s39, 0                         // 0000001E86E0: CC22006F 02004F7A
	v_fma_mixlo_f16 v112, v123, s39, 0                         // 0000001E86E8: CC210070 02004F7B
	v_fma_mixhi_f16 v112, v124, s39, 0                         // 0000001E86F0: CC220070 02004F7C
	ds_load_b128 v[121:124], v183 offset:8624                  // 0000001E86F8: DBFC21B0 790000B7
	v_wmma_f32_16x16x16_f16 v[113:120], v[41:48], v[105:112], v[113:120]// 0000001E8700: CC404071 1DC6D329
	ds_load_b128 v[105:108], v183 offset:8576                  // 0000001E8708: DBFC2180 690000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E8710: BF89FC07
	v_fma_mixlo_f16 v105, v105, s39, 0                         // 0000001E8714: CC210069 02004F69
	v_fma_mixhi_f16 v105, v106, s39, 0                         // 0000001E871C: CC220069 02004F6A
	v_fma_mixlo_f16 v106, v107, s39, 0                         // 0000001E8724: CC21006A 02004F6B
	v_fma_mixhi_f16 v106, v108, s39, 0                         // 0000001E872C: CC22006A 02004F6C
	ds_load_b128 v[107:110], v183 offset:8592                  // 0000001E8734: DBFC2190 6B0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E873C: BF89FC07
	v_fma_mixlo_f16 v107, v107, s39, 0                         // 0000001E8740: CC21006B 02004F6B
	v_fma_mixhi_f16 v107, v108, s39, 0                         // 0000001E8748: CC22006B 02004F6C
	v_fma_mixlo_f16 v108, v109, s39, 0                         // 0000001E8750: CC21006C 02004F6D
	v_fma_mixhi_f16 v108, v110, s39, 0                         // 0000001E8758: CC22006C 02004F6E
	ds_load_b128 v[109:112], v183 offset:8608                  // 0000001E8760: DBFC21A0 6D0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E8768: BF89FC07
	v_fma_mixlo_f16 v109, v109, s39, 0                         // 0000001E876C: CC21006D 02004F6D
	v_fma_mixhi_f16 v109, v110, s39, 0                         // 0000001E8774: CC22006D 02004F6E
	v_fma_mixlo_f16 v110, v111, s39, 0                         // 0000001E877C: CC21006E 02004F6F
	v_fma_mixhi_f16 v110, v112, s39, 0                         // 0000001E8784: CC22006E 02004F70
	v_fma_mixlo_f16 v111, v121, s39, 0                         // 0000001E878C: CC21006F 02004F79
	v_fma_mixhi_f16 v111, v122, s39, 0                         // 0000001E8794: CC22006F 02004F7A
	v_fma_mixlo_f16 v112, v123, s39, 0                         // 0000001E879C: CC210070 02004F7B
	v_fma_mixhi_f16 v112, v124, s39, 0                         // 0000001E87A4: CC220070 02004F7C
	ds_load_b128 v[121:124], v183 offset:17072                 // 0000001E87AC: DBFC42B0 790000B7
	v_wmma_f32_16x16x16_f16 v[97:104], v[41:48], v[105:112], v[97:104]// 0000001E87B4: CC404061 1D86D329
	ds_load_b128 v[105:108], v183 offset:17024                 // 0000001E87BC: DBFC4280 690000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E87C4: BF89FC07
	v_fma_mixlo_f16 v105, v105, s39, 0                         // 0000001E87C8: CC210069 02004F69
	v_fma_mixhi_f16 v105, v106, s39, 0                         // 0000001E87D0: CC220069 02004F6A
	v_fma_mixlo_f16 v106, v107, s39, 0                         // 0000001E87D8: CC21006A 02004F6B
	v_fma_mixhi_f16 v106, v108, s39, 0                         // 0000001E87E0: CC22006A 02004F6C
	ds_load_b128 v[107:110], v183 offset:17040                 // 0000001E87E8: DBFC4290 6B0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E87F0: BF89FC07
	v_fma_mixlo_f16 v107, v107, s39, 0                         // 0000001E87F4: CC21006B 02004F6B
	v_fma_mixhi_f16 v107, v108, s39, 0                         // 0000001E87FC: CC22006B 02004F6C
	v_fma_mixlo_f16 v108, v109, s39, 0                         // 0000001E8804: CC21006C 02004F6D
	v_fma_mixhi_f16 v108, v110, s39, 0                         // 0000001E880C: CC22006C 02004F6E
	ds_load_b128 v[109:112], v183 offset:17056                 // 0000001E8814: DBFC42A0 6D0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E881C: BF89FC07
	v_fma_mixlo_f16 v109, v109, s39, 0                         // 0000001E8820: CC21006D 02004F6D
	v_fma_mixhi_f16 v109, v110, s39, 0                         // 0000001E8828: CC22006D 02004F6E
	v_fma_mixlo_f16 v110, v111, s39, 0                         // 0000001E8830: CC21006E 02004F6F
	v_fma_mixhi_f16 v110, v112, s39, 0                         // 0000001E8838: CC22006E 02004F70
	v_fma_mixlo_f16 v111, v121, s39, 0                         // 0000001E8840: CC21006F 02004F79
	v_fma_mixhi_f16 v111, v122, s39, 0                         // 0000001E8848: CC22006F 02004F7A
	v_fma_mixlo_f16 v112, v123, s39, 0                         // 0000001E8850: CC210070 02004F7B
	v_fma_mixhi_f16 v112, v124, s39, 0                         // 0000001E8858: CC220070 02004F7C
	ds_load_b128 v[121:124], v183 offset:25520                 // 0000001E8860: DBFC63B0 790000B7
	v_wmma_f32_16x16x16_f16 v[81:88], v[41:48], v[105:112], v[81:88]// 0000001E8868: CC404051 1D46D329
	ds_load_b128 v[105:108], v183 offset:25472                 // 0000001E8870: DBFC6380 690000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E8878: BF89FC07
	v_fma_mixlo_f16 v105, v105, s39, 0                         // 0000001E887C: CC210069 02004F69
	v_fma_mixhi_f16 v105, v106, s39, 0                         // 0000001E8884: CC220069 02004F6A
	v_fma_mixlo_f16 v106, v107, s39, 0                         // 0000001E888C: CC21006A 02004F6B
	v_fma_mixhi_f16 v106, v108, s39, 0                         // 0000001E8894: CC22006A 02004F6C
	ds_load_b128 v[107:110], v183 offset:25488                 // 0000001E889C: DBFC6390 6B0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E88A4: BF89FC07
	v_fma_mixlo_f16 v107, v107, s39, 0                         // 0000001E88A8: CC21006B 02004F6B
	v_fma_mixhi_f16 v107, v108, s39, 0                         // 0000001E88B0: CC22006B 02004F6C
	v_fma_mixlo_f16 v108, v109, s39, 0                         // 0000001E88B8: CC21006C 02004F6D
	v_fma_mixhi_f16 v108, v110, s39, 0                         // 0000001E88C0: CC22006C 02004F6E
	ds_load_b128 v[109:112], v183 offset:25504                 // 0000001E88C8: DBFC63A0 6D0000B7
	s_waitcnt lgkmcnt(0)                                       // 0000001E88D0: BF89FC07
	v_fma_mixlo_f16 v109, v109, s39, 0                         // 0000001E88D4: CC21006D 02004F6D
	v_fma_mixhi_f16 v109, v110, s39, 0                         // 0000001E88DC: CC22006D 02004F6E
	v_fma_mixlo_f16 v110, v111, s39, 0                         // 0000001E88E4: CC21006E 02004F6F
	v_fma_mixhi_f16 v110, v112, s39, 0                         // 0000001E88EC: CC22006E 02004F70
	v_fma_mixlo_f16 v111, v121, s39, 0                         // 0000001E88F4: CC21006F 02004F79
	v_fma_mixhi_f16 v111, v122, s39, 0                         // 0000001E88FC: CC22006F 02004F7A
	v_fma_mixlo_f16 v112, v123, s39, 0                         // 0000001E8904: CC210070 02004F7B
	v_fma_mixhi_f16 v112, v124, s39, 0                         // 0000001E890C: CC220070 02004F7C
	ds_load_b128 v[121:124], v183 offset:25824                 // 0000001E8914: DBFC64E0 790000B7
	v_wmma_f32_16x16x16_f16 v[49:56], v[41:48], v[105:112], v[49:56]// 0000001E891C: CC404031 1CC6D329
	ds_load_b128 v[41:44], v183 offset:192                     // 0000001E8924: DBFC00C0 290000B7
	ds_load_b128 v[45:48], v183 offset:208                     // 0000001E892C: DBFC00D0 2D0000B7
	ds_load_b128 v[105:108], v183 offset:224                   // 0000001E8934: DBFC00E0 690000B7
	ds_load_b128 v[109:112], v183 offset:240                   // 0000001E893C: DBFC00F0 6D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E8944: BF89FC37
	v_fma_mixlo_f16 v41, v41, s39, 0                           // 0000001E8948: CC210029 02004F29
	v_fma_mixhi_f16 v41, v42, s39, 0                           // 0000001E8950: CC220029 02004F2A
	v_fma_mixlo_f16 v42, v43, s39, 0                           // 0000001E8958: CC21002A 02004F2B
	s_waitcnt lgkmcnt(2)                                       // 0000001E8960: BF89FC27
	v_fma_mixlo_f16 v43, v45, s39, 0                           // 0000001E8964: CC21002B 02004F2D
	v_fma_mixhi_f16 v43, v46, s39, 0                           // 0000001E896C: CC22002B 02004F2E
	s_waitcnt lgkmcnt(1)                                       // 0000001E8974: BF89FC17
	v_fma_mixlo_f16 v45, v105, s39, 0                          // 0000001E8978: CC21002D 02004F69
	v_fma_mixhi_f16 v45, v106, s39, 0                          // 0000001E8980: CC22002D 02004F6A
	v_fma_mixlo_f16 v46, v107, s39, 0                          // 0000001E8988: CC21002E 02004F6B
	v_fma_mixhi_f16 v46, v108, s39, 0                          // 0000001E8990: CC22002E 02004F6C
	ds_load_b128 v[105:108], v183 offset:8640                  // 0000001E8998: DBFC21C0 690000B7
	v_fma_mixhi_f16 v42, v44, s39, 0                           // 0000001E89A0: CC22002A 02004F2C
	v_fma_mixlo_f16 v44, v47, s39, 0                           // 0000001E89A8: CC21002C 02004F2F
	v_fma_mixhi_f16 v44, v48, s39, 0                           // 0000001E89B0: CC22002C 02004F30
	s_waitcnt lgkmcnt(1)                                       // 0000001E89B8: BF89FC17
	v_fma_mixlo_f16 v47, v109, s39, 0                          // 0000001E89BC: CC21002F 02004F6D
	v_fma_mixhi_f16 v47, v110, s39, 0                          // 0000001E89C4: CC22002F 02004F6E
	v_fma_mixlo_f16 v48, v111, s39, 0                          // 0000001E89CC: CC210030 02004F6F
	v_fma_mixhi_f16 v48, v112, s39, 0                          // 0000001E89D4: CC220030 02004F70
	ds_load_b128 v[109:112], v183 offset:8656                  // 0000001E89DC: DBFC21D0 6D0000B7
	v_wmma_f32_16x16x16_f16 v[113:120], v[33:40], v[41:48], v[113:120]// 0000001E89E4: CC404071 1DC65321
	ds_load_b128 v[45:48], v183 offset:8672                    // 0000001E89EC: DBFC21E0 2D0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E89F4: BF89FC27
	v_fma_mixlo_f16 v41, v105, s39, 0                          // 0000001E89F8: CC210029 02004F69
	v_fma_mixhi_f16 v41, v106, s39, 0                          // 0000001E8A00: CC220029 02004F6A
	v_fma_mixlo_f16 v42, v107, s39, 0                          // 0000001E8A08: CC21002A 02004F6B
	v_fma_mixhi_f16 v42, v108, s39, 0                          // 0000001E8A10: CC22002A 02004F6C
	ds_load_b128 v[105:108], v183 offset:8688                  // 0000001E8A18: DBFC21F0 690000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E8A20: BF89FC27
	v_fma_mixlo_f16 v43, v109, s39, 0                          // 0000001E8A24: CC21002B 02004F6D
	v_fma_mixhi_f16 v43, v110, s39, 0                          // 0000001E8A2C: CC22002B 02004F6E
	v_fma_mixlo_f16 v44, v111, s39, 0                          // 0000001E8A34: CC21002C 02004F6F
	v_fma_mixhi_f16 v44, v112, s39, 0                          // 0000001E8A3C: CC22002C 02004F70
	ds_load_b128 v[109:112], v183 offset:17088                 // 0000001E8A44: DBFC42C0 6D0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E8A4C: BF89FC27
	v_fma_mixlo_f16 v45, v45, s39, 0                           // 0000001E8A50: CC21002D 02004F2D
	v_fma_mixhi_f16 v45, v46, s39, 0                           // 0000001E8A58: CC22002D 02004F2E
	v_fma_mixlo_f16 v46, v47, s39, 0                           // 0000001E8A60: CC21002E 02004F2F
	v_fma_mixhi_f16 v46, v48, s39, 0                           // 0000001E8A68: CC22002E 02004F30
	s_waitcnt lgkmcnt(1)                                       // 0000001E8A70: BF89FC17
	v_fma_mixlo_f16 v47, v105, s39, 0                          // 0000001E8A74: CC21002F 02004F69
	v_fma_mixhi_f16 v47, v106, s39, 0                          // 0000001E8A7C: CC22002F 02004F6A
	v_fma_mixlo_f16 v48, v107, s39, 0                          // 0000001E8A84: CC210030 02004F6B
	v_fma_mixhi_f16 v48, v108, s39, 0                          // 0000001E8A8C: CC220030 02004F6C
	ds_load_b128 v[105:108], v183 offset:17104                 // 0000001E8A94: DBFC42D0 690000B7
	v_wmma_f32_16x16x16_f16 v[97:104], v[33:40], v[41:48], v[97:104]// 0000001E8A9C: CC404061 1D865321
	ds_load_b128 v[45:48], v183 offset:17120                   // 0000001E8AA4: DBFC42E0 2D0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E8AAC: BF89FC27
	v_fma_mixlo_f16 v41, v109, s39, 0                          // 0000001E8AB0: CC210029 02004F6D
	v_fma_mixhi_f16 v41, v110, s39, 0                          // 0000001E8AB8: CC220029 02004F6E
	v_fma_mixlo_f16 v42, v111, s39, 0                          // 0000001E8AC0: CC21002A 02004F6F
	v_fma_mixhi_f16 v42, v112, s39, 0                          // 0000001E8AC8: CC22002A 02004F70
	ds_load_b128 v[109:112], v183 offset:25536                 // 0000001E8AD0: DBFC63C0 6D0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E8AD8: BF89FC27
	v_fma_mixlo_f16 v43, v105, s39, 0                          // 0000001E8ADC: CC21002B 02004F69
	v_fma_mixhi_f16 v43, v106, s39, 0                          // 0000001E8AE4: CC22002B 02004F6A
	v_fma_mixlo_f16 v44, v107, s39, 0                          // 0000001E8AEC: CC21002C 02004F6B
	v_fma_mixhi_f16 v44, v108, s39, 0                          // 0000001E8AF4: CC22002C 02004F6C
	ds_load_b128 v[105:108], v183 offset:17136                 // 0000001E8AFC: DBFC42F0 690000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E8B04: BF89FC27
	v_fma_mixlo_f16 v45, v45, s39, 0                           // 0000001E8B08: CC21002D 02004F2D
	v_fma_mixhi_f16 v45, v46, s39, 0                           // 0000001E8B10: CC22002D 02004F2E
	v_fma_mixlo_f16 v46, v47, s39, 0                           // 0000001E8B18: CC21002E 02004F2F
	v_fma_mixhi_f16 v46, v48, s39, 0                           // 0000001E8B20: CC22002E 02004F30
	s_waitcnt lgkmcnt(0)                                       // 0000001E8B28: BF89FC07
	v_fma_mixlo_f16 v47, v105, s39, 0                          // 0000001E8B2C: CC21002F 02004F69
	v_fma_mixhi_f16 v47, v106, s39, 0                          // 0000001E8B34: CC22002F 02004F6A
	v_fma_mixlo_f16 v48, v107, s39, 0                          // 0000001E8B3C: CC210030 02004F6B
	v_fma_mixhi_f16 v48, v108, s39, 0                          // 0000001E8B44: CC220030 02004F6C
	ds_load_b128 v[105:108], v183 offset:25552                 // 0000001E8B4C: DBFC63D0 690000B7
	v_wmma_f32_16x16x16_f16 v[81:88], v[33:40], v[41:48], v[81:88]// 0000001E8B54: CC404051 1D465321
	ds_load_b128 v[45:48], v183 offset:25568                   // 0000001E8B5C: DBFC63E0 2D0000B7
	v_fma_mixlo_f16 v41, v109, s39, 0                          // 0000001E8B64: CC210029 02004F6D
	v_fma_mixhi_f16 v41, v110, s39, 0                          // 0000001E8B6C: CC220029 02004F6E
	v_fma_mixlo_f16 v42, v111, s39, 0                          // 0000001E8B74: CC21002A 02004F6F
	v_fma_mixhi_f16 v42, v112, s39, 0                          // 0000001E8B7C: CC22002A 02004F70
	ds_load_b128 v[109:112], v183 offset:256                   // 0000001E8B84: DBFC0100 6D0000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E8B8C: BF89FC27
	v_fma_mixlo_f16 v43, v105, s39, 0                          // 0000001E8B90: CC21002B 02004F69
	v_fma_mixhi_f16 v43, v106, s39, 0                          // 0000001E8B98: CC22002B 02004F6A
	v_fma_mixlo_f16 v44, v107, s39, 0                          // 0000001E8BA0: CC21002C 02004F6B
	v_fma_mixhi_f16 v44, v108, s39, 0                          // 0000001E8BA8: CC22002C 02004F6C
	ds_load_b128 v[105:108], v183 offset:25584                 // 0000001E8BB0: DBFC63F0 690000B7
	s_waitcnt lgkmcnt(2)                                       // 0000001E8BB8: BF89FC27
	v_fma_mixlo_f16 v45, v45, s39, 0                           // 0000001E8BBC: CC21002D 02004F2D
	v_fma_mixhi_f16 v45, v46, s39, 0                           // 0000001E8BC4: CC22002D 02004F2E
	v_fma_mixlo_f16 v46, v47, s39, 0                           // 0000001E8BCC: CC21002E 02004F2F
	v_fma_mixhi_f16 v46, v48, s39, 0                           // 0000001E8BD4: CC22002E 02004F30
	s_waitcnt lgkmcnt(0)                                       // 0000001E8BDC: BF89FC07
	v_fma_mixlo_f16 v47, v105, s39, 0                          // 0000001E8BE0: CC21002F 02004F69
	v_fma_mixhi_f16 v47, v106, s39, 0                          // 0000001E8BE8: CC22002F 02004F6A
	v_fma_mixlo_f16 v48, v107, s39, 0                          // 0000001E8BF0: CC210030 02004F6B
	v_fma_mixhi_f16 v48, v108, s39, 0                          // 0000001E8BF8: CC220030 02004F6C
	ds_load_b128 v[105:108], v183 offset:272                   // 0000001E8C00: DBFC0110 690000B7
	v_wmma_f32_16x16x16_f16 v[49:56], v[33:40], v[41:48], v[49:56]// 0000001E8C08: CC404031 1CC65321
	ds_load_b128 v[37:40], v183 offset:288                     // 0000001E8C10: DBFC0120 250000B7
	ds_load_b128 v[41:44], v183 offset:304                     // 0000001E8C18: DBFC0130 290000B7
	ds_load_b128 v[45:48], v183 offset:8704                    // 0000001E8C20: DBFC2200 2D0000B7
	v_fma_mixlo_f16 v33, v109, s39, 0                          // 0000001E8C28: CC210021 02004F6D
	v_fma_mixhi_f16 v33, v110, s39, 0                          // 0000001E8C30: CC220021 02004F6E
	v_fma_mixlo_f16 v34, v111, s39, 0                          // 0000001E8C38: CC210022 02004F6F
	v_fma_mixhi_f16 v34, v112, s39, 0                          // 0000001E8C40: CC220022 02004F70
	ds_load_b128 v[109:112], v183 offset:8736                  // 0000001E8C48: DBFC2220 6D0000B7
	s_waitcnt lgkmcnt(4)                                       // 0000001E8C50: BF89FC47
	v_fma_mixlo_f16 v35, v105, s39, 0                          // 0000001E8C54: CC210023 02004F69
	v_fma_mixhi_f16 v35, v106, s39, 0                          // 0000001E8C5C: CC220023 02004F6A
	v_fma_mixlo_f16 v36, v107, s39, 0                          // 0000001E8C64: CC210024 02004F6B
	v_fma_mixhi_f16 v36, v108, s39, 0                          // 0000001E8C6C: CC220024 02004F6C
	ds_load_b128 v[105:108], v183 offset:8720                  // 0000001E8C74: DBFC2210 690000B7
	s_waitcnt lgkmcnt(4)                                       // 0000001E8C7C: BF89FC47
	v_fma_mixlo_f16 v37, v37, s39, 0                           // 0000001E8C80: CC210025 02004F25
	v_fma_mixhi_f16 v37, v38, s39, 0                           // 0000001E8C88: CC220025 02004F26
	v_fma_mixlo_f16 v38, v39, s39, 0                           // 0000001E8C90: CC210026 02004F27
	v_fma_mixhi_f16 v38, v40, s39, 0                           // 0000001E8C98: CC220026 02004F28
	s_waitcnt lgkmcnt(3)                                       // 0000001E8CA0: BF89FC37
	v_fma_mixlo_f16 v39, v41, s39, 0                           // 0000001E8CA4: CC210027 02004F29
	v_fma_mixhi_f16 v39, v42, s39, 0                           // 0000001E8CAC: CC220027 02004F2A
	v_fma_mixlo_f16 v40, v43, s39, 0                           // 0000001E8CB4: CC210028 02004F2B
	v_fma_mixhi_f16 v40, v44, s39, 0                           // 0000001E8CBC: CC220028 02004F2C
	ds_load_b128 v[41:44], v183 offset:8752                    // 0000001E8CC4: DBFC2230 290000B7
	v_wmma_f32_16x16x16_f16 v[113:120], v[25:32], v[33:40], v[113:120]// 0000001E8CCC: CC404071 1DC64319
	s_waitcnt lgkmcnt(3)                                       // 0000001E8CD4: BF89FC37
	v_fma_mixlo_f16 v33, v45, s39, 0                           // 0000001E8CD8: CC210021 02004F2D
	v_fma_mixhi_f16 v33, v46, s39, 0                           // 0000001E8CE0: CC220021 02004F2E
	v_fma_mixlo_f16 v34, v47, s39, 0                           // 0000001E8CE8: CC210022 02004F2F
	v_fma_mixhi_f16 v34, v48, s39, 0                           // 0000001E8CF0: CC220022 02004F30
	ds_load_b128 v[45:48], v183 offset:17152                   // 0000001E8CF8: DBFC4300 2D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E8D00: BF89FC37
	v_fma_mixlo_f16 v37, v109, s39, 0                          // 0000001E8D04: CC210025 02004F6D
	s_waitcnt lgkmcnt(2)                                       // 0000001E8D0C: BF89FC27
	v_fma_mixlo_f16 v35, v105, s39, 0                          // 0000001E8D10: CC210023 02004F69
	v_fma_mixhi_f16 v35, v106, s39, 0                          // 0000001E8D18: CC220023 02004F6A
	v_fma_mixlo_f16 v36, v107, s39, 0                          // 0000001E8D20: CC210024 02004F6B
	v_fma_mixhi_f16 v36, v108, s39, 0                          // 0000001E8D28: CC220024 02004F6C
	ds_load_b128 v[105:108], v183 offset:17168                 // 0000001E8D30: DBFC4310 690000B7
	v_fma_mixhi_f16 v37, v110, s39, 0                          // 0000001E8D38: CC220025 02004F6E
	v_fma_mixlo_f16 v38, v111, s39, 0                          // 0000001E8D40: CC210026 02004F6F
	v_fma_mixhi_f16 v38, v112, s39, 0                          // 0000001E8D48: CC220026 02004F70
	ds_load_b128 v[109:112], v183 offset:17184                 // 0000001E8D50: DBFC4320 6D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E8D58: BF89FC37
	v_fma_mixlo_f16 v39, v41, s39, 0                           // 0000001E8D5C: CC210027 02004F29
	v_fma_mixhi_f16 v39, v42, s39, 0                           // 0000001E8D64: CC220027 02004F2A
	v_fma_mixlo_f16 v40, v43, s39, 0                           // 0000001E8D6C: CC210028 02004F2B
	v_fma_mixhi_f16 v40, v44, s39, 0                           // 0000001E8D74: CC220028 02004F2C
	ds_load_b128 v[41:44], v183 offset:17200                   // 0000001E8D7C: DBFC4330 290000B7
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[33:40], v[97:104]// 0000001E8D84: CC404061 1D864319
	s_waitcnt lgkmcnt(3)                                       // 0000001E8D8C: BF89FC37
	v_fma_mixlo_f16 v33, v45, s39, 0                           // 0000001E8D90: CC210021 02004F2D
	v_fma_mixhi_f16 v33, v46, s39, 0                           // 0000001E8D98: CC220021 02004F2E
	v_fma_mixlo_f16 v34, v47, s39, 0                           // 0000001E8DA0: CC210022 02004F2F
	v_fma_mixhi_f16 v34, v48, s39, 0                           // 0000001E8DA8: CC220022 02004F30
	ds_load_b128 v[45:48], v183 offset:25600                   // 0000001E8DB0: DBFC6400 2D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E8DB8: BF89FC37
	v_fma_mixlo_f16 v35, v105, s39, 0                          // 0000001E8DBC: CC210023 02004F69
	v_fma_mixhi_f16 v35, v106, s39, 0                          // 0000001E8DC4: CC220023 02004F6A
	v_fma_mixlo_f16 v36, v107, s39, 0                          // 0000001E8DCC: CC210024 02004F6B
	v_fma_mixhi_f16 v36, v108, s39, 0                          // 0000001E8DD4: CC220024 02004F6C
	ds_load_b128 v[105:108], v183 offset:25616                 // 0000001E8DDC: DBFC6410 690000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E8DE4: BF89FC37
	v_fma_mixlo_f16 v37, v109, s39, 0                          // 0000001E8DE8: CC210025 02004F6D
	v_fma_mixhi_f16 v37, v110, s39, 0                          // 0000001E8DF0: CC220025 02004F6E
	v_fma_mixlo_f16 v38, v111, s39, 0                          // 0000001E8DF8: CC210026 02004F6F
	v_fma_mixhi_f16 v38, v112, s39, 0                          // 0000001E8E00: CC220026 02004F70
	ds_load_b128 v[109:112], v183 offset:25632                 // 0000001E8E08: DBFC6420 6D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E8E10: BF89FC37
	v_fma_mixlo_f16 v39, v41, s39, 0                           // 0000001E8E14: CC210027 02004F29
	v_fma_mixhi_f16 v39, v42, s39, 0                           // 0000001E8E1C: CC220027 02004F2A
	v_fma_mixlo_f16 v40, v43, s39, 0                           // 0000001E8E24: CC210028 02004F2B
	v_fma_mixhi_f16 v40, v44, s39, 0                           // 0000001E8E2C: CC220028 02004F2C
	ds_load_b128 v[41:44], v183 offset:25648                   // 0000001E8E34: DBFC6430 290000B7
	v_wmma_f32_16x16x16_f16 v[81:88], v[25:32], v[33:40], v[81:88]// 0000001E8E3C: CC404051 1D464319
	s_waitcnt lgkmcnt(3)                                       // 0000001E8E44: BF89FC37
	v_fma_mixlo_f16 v33, v45, s39, 0                           // 0000001E8E48: CC210021 02004F2D
	v_fma_mixhi_f16 v33, v46, s39, 0                           // 0000001E8E50: CC220021 02004F2E
	v_fma_mixlo_f16 v34, v47, s39, 0                           // 0000001E8E58: CC210022 02004F2F
	v_fma_mixhi_f16 v34, v48, s39, 0                           // 0000001E8E60: CC220022 02004F30
	ds_load_b128 v[45:48], v183 offset:320                     // 0000001E8E68: DBFC0140 2D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E8E70: BF89FC37
	v_fma_mixlo_f16 v35, v105, s39, 0                          // 0000001E8E74: CC210023 02004F69
	v_fma_mixhi_f16 v35, v106, s39, 0                          // 0000001E8E7C: CC220023 02004F6A
	v_fma_mixlo_f16 v36, v107, s39, 0                          // 0000001E8E84: CC210024 02004F6B
	v_fma_mixhi_f16 v36, v108, s39, 0                          // 0000001E8E8C: CC220024 02004F6C
	ds_load_b128 v[105:108], v183 offset:336                   // 0000001E8E94: DBFC0150 690000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E8E9C: BF89FC37
	v_fma_mixlo_f16 v37, v109, s39, 0                          // 0000001E8EA0: CC210025 02004F6D
	v_fma_mixhi_f16 v37, v110, s39, 0                          // 0000001E8EA8: CC220025 02004F6E
	v_fma_mixlo_f16 v38, v111, s39, 0                          // 0000001E8EB0: CC210026 02004F6F
	v_fma_mixhi_f16 v38, v112, s39, 0                          // 0000001E8EB8: CC220026 02004F70
	ds_load_b128 v[109:112], v183 offset:352                   // 0000001E8EC0: DBFC0160 6D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E8EC8: BF89FC37
	v_fma_mixlo_f16 v39, v41, s39, 0                           // 0000001E8ECC: CC210027 02004F29
	v_fma_mixhi_f16 v39, v42, s39, 0                           // 0000001E8ED4: CC220027 02004F2A
	v_fma_mixlo_f16 v40, v43, s39, 0                           // 0000001E8EDC: CC210028 02004F2B
	v_fma_mixhi_f16 v40, v44, s39, 0                           // 0000001E8EE4: CC220028 02004F2C
	ds_load_b128 v[41:44], v183 offset:368                     // 0000001E8EEC: DBFC0170 290000B7
	v_wmma_f32_16x16x16_f16 v[49:56], v[25:32], v[33:40], v[49:56]// 0000001E8EF4: CC404031 1CC64319
	ds_load_b128 v[33:36], v183 offset:8768                    // 0000001E8EFC: DBFC2240 210000B7
	ds_load_b128 v[37:40], v183 offset:8784                    // 0000001E8F04: DBFC2250 250000B7
	s_waitcnt lgkmcnt(5)                                       // 0000001E8F0C: BF89FC57
	v_fma_mixlo_f16 v25, v45, s39, 0                           // 0000001E8F10: CC210019 02004F2D
	v_fma_mixhi_f16 v25, v46, s39, 0                           // 0000001E8F18: CC220019 02004F2E
	v_fma_mixlo_f16 v26, v47, s39, 0                           // 0000001E8F20: CC21001A 02004F2F
	v_fma_mixhi_f16 v26, v48, s39, 0                           // 0000001E8F28: CC22001A 02004F30
	s_waitcnt lgkmcnt(4)                                       // 0000001E8F30: BF89FC47
	v_fma_mixlo_f16 v27, v105, s39, 0                          // 0000001E8F34: CC21001B 02004F69
	v_fma_mixhi_f16 v27, v106, s39, 0                          // 0000001E8F3C: CC22001B 02004F6A
	v_fma_mixlo_f16 v28, v107, s39, 0                          // 0000001E8F44: CC21001C 02004F6B
	v_fma_mixhi_f16 v28, v108, s39, 0                          // 0000001E8F4C: CC22001C 02004F6C
	ds_load_b128 v[45:48], v183 offset:8800                    // 0000001E8F54: DBFC2260 2D0000B7
	ds_load_b128 v[105:108], v183 offset:8816                  // 0000001E8F5C: DBFC2270 690000B7
	s_waitcnt lgkmcnt(5)                                       // 0000001E8F64: BF89FC57
	v_fma_mixlo_f16 v29, v109, s39, 0                          // 0000001E8F68: CC21001D 02004F6D
	v_fma_mixhi_f16 v29, v110, s39, 0                          // 0000001E8F70: CC22001D 02004F6E
	v_fma_mixlo_f16 v30, v111, s39, 0                          // 0000001E8F78: CC21001E 02004F6F
	v_fma_mixhi_f16 v30, v112, s39, 0                          // 0000001E8F80: CC22001E 02004F70
	s_waitcnt lgkmcnt(4)                                       // 0000001E8F88: BF89FC47
	v_fma_mixlo_f16 v31, v41, s39, 0                           // 0000001E8F8C: CC21001F 02004F29
	v_fma_mixhi_f16 v31, v42, s39, 0                           // 0000001E8F94: CC22001F 02004F2A
	v_fma_mixlo_f16 v32, v43, s39, 0                           // 0000001E8F9C: CC210020 02004F2B
	v_fma_mixhi_f16 v32, v44, s39, 0                           // 0000001E8FA4: CC220020 02004F2C
	s_waitcnt lgkmcnt(3)                                       // 0000001E8FAC: BF89FC37
	v_fma_mixlo_f16 v33, v33, s39, 0                           // 0000001E8FB0: CC210021 02004F21
	v_fma_mixhi_f16 v33, v34, s39, 0                           // 0000001E8FB8: CC220021 02004F22
	v_fma_mixlo_f16 v34, v35, s39, 0                           // 0000001E8FC0: CC210022 02004F23
	v_fma_mixhi_f16 v34, v36, s39, 0                           // 0000001E8FC8: CC220022 02004F24
	ds_load_b128 v[41:44], v183 offset:17216                   // 0000001E8FD0: DBFC4340 290000B7
	ds_load_b128 v[109:112], v183 offset:17232                 // 0000001E8FD8: DBFC4350 6D0000B7
	s_waitcnt lgkmcnt(4)                                       // 0000001E8FE0: BF89FC47
	v_fma_mixlo_f16 v35, v37, s39, 0                           // 0000001E8FE4: CC210023 02004F25
	v_fma_mixhi_f16 v35, v38, s39, 0                           // 0000001E8FEC: CC220023 02004F26
	v_fma_mixlo_f16 v36, v39, s39, 0                           // 0000001E8FF4: CC210024 02004F27
	v_fma_mixhi_f16 v36, v40, s39, 0                           // 0000001E8FFC: CC220024 02004F28
	s_waitcnt lgkmcnt(3)                                       // 0000001E9004: BF89FC37
	v_fma_mixlo_f16 v37, v45, s39, 0                           // 0000001E9008: CC210025 02004F2D
	v_fma_mixhi_f16 v37, v46, s39, 0                           // 0000001E9010: CC220025 02004F2E
	v_fma_mixlo_f16 v38, v47, s39, 0                           // 0000001E9018: CC210026 02004F2F
	v_fma_mixhi_f16 v38, v48, s39, 0                           // 0000001E9020: CC220026 02004F30
	ds_load_b128 v[45:48], v183 offset:17248                   // 0000001E9028: DBFC4360 2D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E9030: BF89FC37
	v_fma_mixlo_f16 v39, v105, s39, 0                          // 0000001E9034: CC210027 02004F69
	v_fma_mixhi_f16 v39, v106, s39, 0                          // 0000001E903C: CC220027 02004F6A
	v_fma_mixlo_f16 v40, v107, s39, 0                          // 0000001E9044: CC210028 02004F6B
	v_fma_mixhi_f16 v40, v108, s39, 0                          // 0000001E904C: CC220028 02004F6C
	ds_load_b128 v[105:108], v183 offset:17264                 // 0000001E9054: DBFC4370 690000B7
	v_wmma_f32_16x16x16_f16 v[113:120], v[17:24], v[25:32], v[113:120]// 0000001E905C: CC404071 1DC63311
	v_wmma_f32_16x16x16_f16 v[97:104], v[17:24], v[33:40], v[97:104]// 0000001E9064: CC404061 1D864311
	s_waitcnt lgkmcnt(3)                                       // 0000001E906C: BF89FC37
	v_fma_mixlo_f16 v25, v41, s39, 0                           // 0000001E9070: CC210019 02004F29
	v_fma_mixhi_f16 v25, v42, s39, 0                           // 0000001E9078: CC220019 02004F2A
	v_fma_mixlo_f16 v26, v43, s39, 0                           // 0000001E9080: CC21001A 02004F2B
	v_fma_mixhi_f16 v26, v44, s39, 0                           // 0000001E9088: CC22001A 02004F2C
	ds_load_b128 v[41:44], v183 offset:25664                   // 0000001E9090: DBFC6440 290000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E9098: BF89FC37
	v_fma_mixlo_f16 v27, v109, s39, 0                          // 0000001E909C: CC21001B 02004F6D
	v_fma_mixhi_f16 v27, v110, s39, 0                          // 0000001E90A4: CC22001B 02004F6E
	v_fma_mixlo_f16 v28, v111, s39, 0                          // 0000001E90AC: CC21001C 02004F6F
	v_fma_mixhi_f16 v28, v112, s39, 0                          // 0000001E90B4: CC22001C 02004F70
	ds_load_b128 v[109:112], v183 offset:25680                 // 0000001E90BC: DBFC6450 6D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E90C4: BF89FC37
	v_fma_mixlo_f16 v29, v45, s39, 0                           // 0000001E90C8: CC21001D 02004F2D
	v_fma_mixhi_f16 v29, v46, s39, 0                           // 0000001E90D0: CC22001D 02004F2E
	v_fma_mixlo_f16 v30, v47, s39, 0                           // 0000001E90D8: CC21001E 02004F2F
	v_fma_mixhi_f16 v30, v48, s39, 0                           // 0000001E90E0: CC22001E 02004F30
	ds_load_b128 v[45:48], v183 offset:25696                   // 0000001E90E8: DBFC6460 2D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E90F0: BF89FC37
	v_fma_mixlo_f16 v31, v105, s39, 0                          // 0000001E90F4: CC21001F 02004F69
	v_fma_mixhi_f16 v31, v106, s39, 0                          // 0000001E90FC: CC22001F 02004F6A
	v_fma_mixlo_f16 v32, v107, s39, 0                          // 0000001E9104: CC210020 02004F6B
	v_fma_mixhi_f16 v32, v108, s39, 0                          // 0000001E910C: CC220020 02004F6C
	ds_load_b128 v[105:108], v183 offset:25712                 // 0000001E9114: DBFC6470 690000B7
	v_wmma_f32_16x16x16_f16 v[81:88], v[17:24], v[25:32], v[81:88]// 0000001E911C: CC404051 1D463311
	s_waitcnt lgkmcnt(3)                                       // 0000001E9124: BF89FC37
	v_fma_mixlo_f16 v33, v41, s39, 0                           // 0000001E9128: CC210021 02004F29
	v_fma_mixhi_f16 v33, v42, s39, 0                           // 0000001E9130: CC220021 02004F2A
	v_fma_mixlo_f16 v34, v43, s39, 0                           // 0000001E9138: CC210022 02004F2B
	v_fma_mixhi_f16 v34, v44, s39, 0                           // 0000001E9140: CC220022 02004F2C
	ds_load_b128 v[41:44], v183 offset:384                     // 0000001E9148: DBFC0180 290000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E9150: BF89FC37
	v_fma_mixlo_f16 v35, v109, s39, 0                          // 0000001E9154: CC210023 02004F6D
	v_fma_mixhi_f16 v35, v110, s39, 0                          // 0000001E915C: CC220023 02004F6E
	v_fma_mixlo_f16 v36, v111, s39, 0                          // 0000001E9164: CC210024 02004F6F
	v_fma_mixhi_f16 v36, v112, s39, 0                          // 0000001E916C: CC220024 02004F70
	ds_load_b128 v[109:112], v183 offset:400                   // 0000001E9174: DBFC0190 6D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E917C: BF89FC37
	v_fma_mixlo_f16 v37, v45, s39, 0                           // 0000001E9180: CC210025 02004F2D
	v_fma_mixhi_f16 v37, v46, s39, 0                           // 0000001E9188: CC220025 02004F2E
	v_fma_mixlo_f16 v38, v47, s39, 0                           // 0000001E9190: CC210026 02004F2F
	v_fma_mixhi_f16 v38, v48, s39, 0                           // 0000001E9198: CC220026 02004F30
	ds_load_b128 v[45:48], v183 offset:416                     // 0000001E91A0: DBFC01A0 2D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E91A8: BF89FC37
	v_fma_mixlo_f16 v39, v105, s39, 0                          // 0000001E91AC: CC210027 02004F69
	v_fma_mixhi_f16 v39, v106, s39, 0                          // 0000001E91B4: CC220027 02004F6A
	v_fma_mixlo_f16 v40, v107, s39, 0                          // 0000001E91BC: CC210028 02004F6B
	v_fma_mixhi_f16 v40, v108, s39, 0                          // 0000001E91C4: CC220028 02004F6C
	ds_load_b128 v[105:108], v183 offset:432                   // 0000001E91CC: DBFC01B0 690000B7
	ds_load_b128 v[25:28], v183 offset:8832                    // 0000001E91D4: DBFC2280 190000B7
	ds_load_b128 v[29:32], v183 offset:8848                    // 0000001E91DC: DBFC2290 1D0000B7
	v_wmma_f32_16x16x16_f16 v[49:56], v[17:24], v[33:40], v[49:56]// 0000001E91E4: CC404031 1CC64311
	s_waitcnt lgkmcnt(5)                                       // 0000001E91EC: BF89FC57
	v_fma_mixlo_f16 v17, v41, s39, 0                           // 0000001E91F0: CC210011 02004F29
	v_fma_mixhi_f16 v17, v42, s39, 0                           // 0000001E91F8: CC220011 02004F2A
	v_fma_mixlo_f16 v18, v43, s39, 0                           // 0000001E9200: CC210012 02004F2B
	v_fma_mixhi_f16 v18, v44, s39, 0                           // 0000001E9208: CC220012 02004F2C
	ds_load_b128 v[33:36], v183 offset:8864                    // 0000001E9210: DBFC22A0 210000B7
	ds_load_b128 v[37:40], v183 offset:8880                    // 0000001E9218: DBFC22B0 250000B7
	s_waitcnt lgkmcnt(6)                                       // 0000001E9220: BF89FC67
	v_fma_mixlo_f16 v19, v109, s39, 0                          // 0000001E9224: CC210013 02004F6D
	v_fma_mixhi_f16 v19, v110, s39, 0                          // 0000001E922C: CC220013 02004F6E
	v_fma_mixlo_f16 v20, v111, s39, 0                          // 0000001E9234: CC210014 02004F6F
	v_fma_mixhi_f16 v20, v112, s39, 0                          // 0000001E923C: CC220014 02004F70
	s_waitcnt lgkmcnt(5)                                       // 0000001E9244: BF89FC57
	v_fma_mixlo_f16 v21, v45, s39, 0                           // 0000001E9248: CC210015 02004F2D
	v_fma_mixhi_f16 v21, v46, s39, 0                           // 0000001E9250: CC220015 02004F2E
	v_fma_mixlo_f16 v22, v47, s39, 0                           // 0000001E9258: CC210016 02004F2F
	v_fma_mixhi_f16 v22, v48, s39, 0                           // 0000001E9260: CC220016 02004F30
	ds_load_b128 v[41:44], v183 offset:17280                   // 0000001E9268: DBFC4380 290000B7
	ds_load_b128 v[45:48], v183 offset:17296                   // 0000001E9270: DBFC4390 2D0000B7
	s_waitcnt lgkmcnt(6)                                       // 0000001E9278: BF89FC67
	v_fma_mixlo_f16 v23, v105, s39, 0                          // 0000001E927C: CC210017 02004F69
	v_fma_mixhi_f16 v23, v106, s39, 0                          // 0000001E9284: CC220017 02004F6A
	v_fma_mixlo_f16 v24, v107, s39, 0                          // 0000001E928C: CC210018 02004F6B
	v_fma_mixhi_f16 v24, v108, s39, 0                          // 0000001E9294: CC220018 02004F6C
	ds_load_b128 v[105:108], v183 offset:17312                 // 0000001E929C: DBFC43A0 690000B7
	ds_load_b128 v[109:112], v183 offset:17328                 // 0000001E92A4: DBFC43B0 6D0000B7
	s_waitcnt lgkmcnt(7)                                       // 0000001E92AC: BF89FC77
	v_fma_mixlo_f16 v25, v25, s39, 0                           // 0000001E92B0: CC210019 02004F19
	v_fma_mixhi_f16 v25, v26, s39, 0                           // 0000001E92B8: CC220019 02004F1A
	v_fma_mixlo_f16 v26, v27, s39, 0                           // 0000001E92C0: CC21001A 02004F1B
	v_fma_mixhi_f16 v26, v28, s39, 0                           // 0000001E92C8: CC22001A 02004F1C
	s_waitcnt lgkmcnt(6)                                       // 0000001E92D0: BF89FC67
	v_fma_mixlo_f16 v27, v29, s39, 0                           // 0000001E92D4: CC21001B 02004F1D
	v_fma_mixhi_f16 v27, v30, s39, 0                           // 0000001E92DC: CC22001B 02004F1E
	v_fma_mixlo_f16 v28, v31, s39, 0                           // 0000001E92E4: CC21001C 02004F1F
	v_fma_mixhi_f16 v28, v32, s39, 0                           // 0000001E92EC: CC22001C 02004F20
	s_waitcnt lgkmcnt(5)                                       // 0000001E92F4: BF89FC57
	v_fma_mixlo_f16 v29, v33, s39, 0                           // 0000001E92F8: CC21001D 02004F21
	v_fma_mixhi_f16 v29, v34, s39, 0                           // 0000001E9300: CC22001D 02004F22
	v_fma_mixlo_f16 v30, v35, s39, 0                           // 0000001E9308: CC21001E 02004F23
	v_fma_mixhi_f16 v30, v36, s39, 0                           // 0000001E9310: CC22001E 02004F24
	s_waitcnt lgkmcnt(4)                                       // 0000001E9318: BF89FC47
	v_fma_mixlo_f16 v31, v37, s39, 0                           // 0000001E931C: CC21001F 02004F25
	v_fma_mixhi_f16 v31, v38, s39, 0                           // 0000001E9324: CC22001F 02004F26
	v_fma_mixlo_f16 v32, v39, s39, 0                           // 0000001E932C: CC210020 02004F27
	v_fma_mixhi_f16 v32, v40, s39, 0                           // 0000001E9334: CC220020 02004F28
	s_waitcnt lgkmcnt(3)                                       // 0000001E933C: BF89FC37
	v_fma_mixlo_f16 v33, v41, s39, 0                           // 0000001E9340: CC210021 02004F29
	v_fma_mixhi_f16 v33, v42, s39, 0                           // 0000001E9348: CC220021 02004F2A
	v_fma_mixlo_f16 v34, v43, s39, 0                           // 0000001E9350: CC210022 02004F2B
	v_fma_mixhi_f16 v34, v44, s39, 0                           // 0000001E9358: CC220022 02004F2C
	ds_load_b128 v[41:44], v183 offset:25728                   // 0000001E9360: DBFC6480 290000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E9368: BF89FC37
	v_fma_mixlo_f16 v35, v45, s39, 0                           // 0000001E936C: CC210023 02004F2D
	v_fma_mixhi_f16 v35, v46, s39, 0                           // 0000001E9374: CC220023 02004F2E
	v_fma_mixlo_f16 v36, v47, s39, 0                           // 0000001E937C: CC210024 02004F2F
	v_fma_mixhi_f16 v36, v48, s39, 0                           // 0000001E9384: CC220024 02004F30
	ds_load_b128 v[45:48], v183 offset:25744                   // 0000001E938C: DBFC6490 2D0000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E9394: BF89FC37
	v_fma_mixlo_f16 v37, v105, s39, 0                          // 0000001E9398: CC210025 02004F69
	v_fma_mixhi_f16 v37, v106, s39, 0                          // 0000001E93A0: CC220025 02004F6A
	v_fma_mixlo_f16 v38, v107, s39, 0                          // 0000001E93A8: CC210026 02004F6B
	v_fma_mixhi_f16 v38, v108, s39, 0                          // 0000001E93B0: CC220026 02004F6C
	ds_load_b128 v[105:108], v183 offset:25760                 // 0000001E93B8: DBFC64A0 690000B7
	s_waitcnt lgkmcnt(3)                                       // 0000001E93C0: BF89FC37
	v_fma_mixlo_f16 v39, v109, s39, 0                          // 0000001E93C4: CC210027 02004F6D
	v_fma_mixhi_f16 v39, v110, s39, 0                          // 0000001E93CC: CC220027 02004F6E
	v_fma_mixlo_f16 v40, v111, s39, 0                          // 0000001E93D4: CC210028 02004F6F
	v_fma_mixhi_f16 v40, v112, s39, 0                          // 0000001E93DC: CC220028 02004F70
	ds_load_b128 v[109:112], v183 offset:25776                 // 0000001E93E4: DBFC64B0 6D0000B7
	v_wmma_f32_16x16x16_f16 v[113:120], v[9:16], v[17:24], v[113:120]// 0000001E93EC: CC404071 1DC62309
	v_wmma_f32_16x16x16_f16 v[97:104], v[9:16], v[25:32], v[97:104]// 0000001E93F4: CC404061 1D863309
	ds_load_b128 v[25:28], v183 offset:8928                    // 0000001E93FC: DBFC22E0 190000B7
	ds_load_b128 v[29:32], v183 offset:8944                    // 0000001E9404: DBFC22F0 1D0000B7
	s_waitcnt lgkmcnt(5)                                       // 0000001E940C: BF89FC57
	v_fma_mixlo_f16 v17, v41, s39, 0                           // 0000001E9410: CC210011 02004F29
	v_fma_mixhi_f16 v17, v42, s39, 0                           // 0000001E9418: CC220011 02004F2A
	v_fma_mixlo_f16 v18, v43, s39, 0                           // 0000001E9420: CC210012 02004F2B
	v_fma_mixhi_f16 v18, v44, s39, 0                           // 0000001E9428: CC220012 02004F2C
	ds_load_b128 v[41:44], v183 offset:448                     // 0000001E9430: DBFC01C0 290000B7
	s_waitcnt lgkmcnt(5)                                       // 0000001E9438: BF89FC57
	v_fma_mixlo_f16 v19, v45, s39, 0                           // 0000001E943C: CC210013 02004F2D
	v_fma_mixhi_f16 v19, v46, s39, 0                           // 0000001E9444: CC220013 02004F2E
	v_fma_mixlo_f16 v20, v47, s39, 0                           // 0000001E944C: CC210014 02004F2F
	v_fma_mixhi_f16 v20, v48, s39, 0                           // 0000001E9454: CC220014 02004F30
	ds_load_b128 v[45:48], v183 offset:464                     // 0000001E945C: DBFC01D0 2D0000B7
	s_waitcnt lgkmcnt(5)                                       // 0000001E9464: BF89FC57
	v_fma_mixlo_f16 v21, v105, s39, 0                          // 0000001E9468: CC210015 02004F69
	v_fma_mixhi_f16 v21, v106, s39, 0                          // 0000001E9470: CC220015 02004F6A
	v_fma_mixlo_f16 v22, v107, s39, 0                          // 0000001E9478: CC210016 02004F6B
	v_fma_mixhi_f16 v22, v108, s39, 0                          // 0000001E9480: CC220016 02004F6C
	ds_load_b128 v[105:108], v183 offset:480                   // 0000001E9488: DBFC01E0 690000B7
	s_waitcnt lgkmcnt(5)                                       // 0000001E9490: BF89FC57
	v_fma_mixlo_f16 v23, v109, s39, 0                          // 0000001E9494: CC210017 02004F6D
	v_fma_mixhi_f16 v23, v110, s39, 0                          // 0000001E949C: CC220017 02004F6E
	v_fma_mixlo_f16 v24, v111, s39, 0                          // 0000001E94A4: CC210018 02004F6F
	v_fma_mixhi_f16 v24, v112, s39, 0                          // 0000001E94AC: CC220018 02004F70
	ds_load_b128 v[109:112], v183 offset:496                   // 0000001E94B4: DBFC01F0 6D0000B7
	v_wmma_f32_16x16x16_f16 v[81:88], v[9:16], v[33:40], v[81:88]// 0000001E94BC: CC404051 1D464309
	ds_load_b128 v[33:36], v183 offset:17344                   // 0000001E94C4: DBFC43C0 210000B7
	ds_load_b128 v[37:40], v183 offset:17360                   // 0000001E94CC: DBFC43D0 250000B7
	v_wmma_f32_16x16x16_f16 v[49:56], v[9:16], v[17:24], v[49:56]// 0000001E94D4: CC404031 1CC62309
	ds_load_b128 v[17:20], v183 offset:8896                    // 0000001E94DC: DBFC22C0 110000B7
	ds_load_b128 v[21:24], v183 offset:8912                    // 0000001E94E4: DBFC22D0 150000B7
	s_waitcnt lgkmcnt(7)                                       // 0000001E94EC: BF89FC77
	v_fma_mixlo_f16 v9, v41, s39, 0                            // 0000001E94F0: CC210009 02004F29
	v_fma_mixhi_f16 v9, v42, s39, 0                            // 0000001E94F8: CC220009 02004F2A
	v_fma_mixlo_f16 v10, v43, s39, 0                           // 0000001E9500: CC21000A 02004F2B
	v_fma_mixhi_f16 v10, v44, s39, 0                           // 0000001E9508: CC22000A 02004F2C
	s_waitcnt lgkmcnt(6)                                       // 0000001E9510: BF89FC67
	v_fma_mixlo_f16 v11, v45, s39, 0                           // 0000001E9514: CC21000B 02004F2D
	v_fma_mixhi_f16 v11, v46, s39, 0                           // 0000001E951C: CC22000B 02004F2E
	v_fma_mixlo_f16 v12, v47, s39, 0                           // 0000001E9524: CC21000C 02004F2F
	v_fma_mixhi_f16 v12, v48, s39, 0                           // 0000001E952C: CC22000C 02004F30
	s_waitcnt lgkmcnt(5)                                       // 0000001E9534: BF89FC57
	v_fma_mixlo_f16 v13, v105, s39, 0                          // 0000001E9538: CC21000D 02004F69
	v_fma_mixhi_f16 v13, v106, s39, 0                          // 0000001E9540: CC22000D 02004F6A
	v_fma_mixlo_f16 v14, v107, s39, 0                          // 0000001E9548: CC21000E 02004F6B
	v_fma_mixhi_f16 v14, v108, s39, 0                          // 0000001E9550: CC22000E 02004F6C
	ds_load_b128 v[41:44], v183 offset:17376                   // 0000001E9558: DBFC43E0 290000B7
	ds_load_b128 v[45:48], v183 offset:17392                   // 0000001E9560: DBFC43F0 2D0000B7
	s_waitcnt lgkmcnt(6)                                       // 0000001E9568: BF89FC67
	v_fma_mixlo_f16 v15, v109, s39, 0                          // 0000001E956C: CC21000F 02004F6D
	v_fma_mixhi_f16 v15, v110, s39, 0                          // 0000001E9574: CC22000F 02004F6E
	v_fma_mixlo_f16 v16, v111, s39, 0                          // 0000001E957C: CC210010 02004F6F
	v_fma_mixhi_f16 v16, v112, s39, 0                          // 0000001E9584: CC220010 02004F70
	ds_load_b128 v[105:108], v183 offset:25792                 // 0000001E958C: DBFC64C0 690000B7
	ds_load_b128 v[109:112], v183 offset:25808                 // 0000001E9594: DBFC64D0 6D0000B7
	s_waitcnt lgkmcnt(5)                                       // 0000001E959C: BF89FC57
	v_fma_mixlo_f16 v17, v17, s39, 0                           // 0000001E95A0: CC210011 02004F11
	v_fma_mixhi_f16 v17, v18, s39, 0                           // 0000001E95A8: CC220011 02004F12
	v_fma_mixlo_f16 v18, v19, s39, 0                           // 0000001E95B0: CC210012 02004F13
	v_fma_mixhi_f16 v18, v20, s39, 0                           // 0000001E95B8: CC220012 02004F14
	s_waitcnt lgkmcnt(4)                                       // 0000001E95C0: BF89FC47
	v_fma_mixlo_f16 v19, v21, s39, 0                           // 0000001E95C4: CC210013 02004F15
	v_fma_mixhi_f16 v19, v22, s39, 0                           // 0000001E95CC: CC220013 02004F16
	v_fma_mixlo_f16 v20, v23, s39, 0                           // 0000001E95D4: CC210014 02004F17
	v_fma_mixhi_f16 v20, v24, s39, 0                           // 0000001E95DC: CC220014 02004F18
	v_fma_mixlo_f16 v21, v25, s39, 0                           // 0000001E95E4: CC210015 02004F19
	v_fma_mixhi_f16 v21, v26, s39, 0                           // 0000001E95EC: CC220015 02004F1A
	v_fma_mixlo_f16 v22, v27, s39, 0                           // 0000001E95F4: CC210016 02004F1B
	v_fma_mixhi_f16 v22, v28, s39, 0                           // 0000001E95FC: CC220016 02004F1C
	v_fma_mixlo_f16 v23, v29, s39, 0                           // 0000001E9604: CC210017 02004F1D
	v_fma_mixhi_f16 v23, v30, s39, 0                           // 0000001E960C: CC220017 02004F1E
	v_fma_mixlo_f16 v24, v31, s39, 0                           // 0000001E9614: CC210018 02004F1F
	v_fma_mixhi_f16 v24, v32, s39, 0                           // 0000001E961C: CC220018 02004F20
	v_fma_mixlo_f16 v25, v33, s39, 0                           // 0000001E9624: CC210019 02004F21
	v_fma_mixhi_f16 v25, v34, s39, 0                           // 0000001E962C: CC220019 02004F22
	v_fma_mixlo_f16 v26, v35, s39, 0                           // 0000001E9634: CC21001A 02004F23
	v_fma_mixhi_f16 v26, v36, s39, 0                           // 0000001E963C: CC22001A 02004F24
	v_fma_mixlo_f16 v27, v37, s39, 0                           // 0000001E9644: CC21001B 02004F25
	v_fma_mixhi_f16 v27, v38, s39, 0                           // 0000001E964C: CC22001B 02004F26
	v_fma_mixlo_f16 v28, v39, s39, 0                           // 0000001E9654: CC21001C 02004F27
	v_fma_mixhi_f16 v28, v40, s39, 0                           // 0000001E965C: CC22001C 02004F28
	s_waitcnt lgkmcnt(3)                                       // 0000001E9664: BF89FC37
	v_fma_mixlo_f16 v29, v41, s39, 0                           // 0000001E9668: CC21001D 02004F29
	v_fma_mixhi_f16 v29, v42, s39, 0                           // 0000001E9670: CC22001D 02004F2A
	v_fma_mixlo_f16 v30, v43, s39, 0                           // 0000001E9678: CC21001E 02004F2B
	v_fma_mixhi_f16 v30, v44, s39, 0                           // 0000001E9680: CC22001E 02004F2C
	s_waitcnt lgkmcnt(2)                                       // 0000001E9688: BF89FC27
	v_fma_mixlo_f16 v31, v45, s39, 0                           // 0000001E968C: CC21001F 02004F2D
	v_fma_mixhi_f16 v31, v46, s39, 0                           // 0000001E9694: CC22001F 02004F2E
	v_fma_mixlo_f16 v32, v47, s39, 0                           // 0000001E969C: CC210020 02004F2F
	v_fma_mixhi_f16 v32, v48, s39, 0                           // 0000001E96A4: CC220020 02004F30
	s_waitcnt lgkmcnt(1)                                       // 0000001E96AC: BF89FC17
	v_fma_mixlo_f16 v33, v105, s39, 0                          // 0000001E96B0: CC210021 02004F69
	v_fma_mixhi_f16 v33, v106, s39, 0                          // 0000001E96B8: CC220021 02004F6A
	v_fma_mixlo_f16 v34, v107, s39, 0                          // 0000001E96C0: CC210022 02004F6B
	v_fma_mixhi_f16 v34, v108, s39, 0                          // 0000001E96C8: CC220022 02004F6C
	s_waitcnt lgkmcnt(0)                                       // 0000001E96D0: BF89FC07
	v_fma_mixlo_f16 v35, v109, s39, 0                          // 0000001E96D4: CC210023 02004F6D
	v_fma_mixhi_f16 v35, v110, s39, 0                          // 0000001E96DC: CC220023 02004F6E
	v_fma_mixlo_f16 v36, v111, s39, 0                          // 0000001E96E4: CC210024 02004F6F
	v_fma_mixhi_f16 v36, v112, s39, 0                          // 0000001E96EC: CC220024 02004F70
	v_fma_mixlo_f16 v37, v121, s39, 0                          // 0000001E96F4: CC210025 02004F79
	ds_load_b128 v[41:44], v185                                // 0000001E96FC: DBFC0000 290000B9
	ds_load_b128 v[45:48], v185 offset:16                      // 0000001E9704: DBFC0010 2D0000B9
	v_fma_mixhi_f16 v37, v122, s39, 0                          // 0000001E970C: CC220025 02004F7A
	v_fma_mixlo_f16 v38, v123, s39, 0                          // 0000001E9714: CC210026 02004F7B
	v_fma_mixhi_f16 v38, v124, s39, 0                          // 0000001E971C: CC220026 02004F7C
	v_fma_mixlo_f16 v39, v125, s39, 0                          // 0000001E9724: CC210027 02004F7D
	v_fma_mixhi_f16 v39, v126, s39, 0                          // 0000001E972C: CC220027 02004F7E
	v_fma_mixlo_f16 v40, v127, s39, 0                          // 0000001E9734: CC210028 02004F7F
	v_fma_mixhi_f16 v40, v128, s39, 0                          // 0000001E973C: CC220028 02004F80
	ds_load_b128 v[109:112], v185 offset:2320                  // 0000001E9744: DBFC0910 6D0000B9
	ds_load_b128 v[105:108], v185 offset:2304                  // 0000001E974C: DBFC0900 690000B9
	ds_load_b128 v[125:128], v185 offset:4624                  // 0000001E9754: DBFC1210 7D0000B9
	ds_load_b128 v[121:124], v185 offset:4608                  // 0000001E975C: DBFC1200 790000B9
	v_wmma_f32_16x16x16_f16 v[113:120], v[1:8], v[9:16], v[113:120]// 0000001E9764: CC404071 1DC61301
	v_wmma_f32_16x16x16_f16 v[97:104], v[1:8], v[17:24], v[97:104]// 0000001E976C: CC404061 1D862301
	v_wmma_f32_16x16x16_f16 v[81:88], v[1:8], v[25:32], v[81:88]// 0000001E9774: CC404051 1D463301
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[33:40], v[49:56]// 0000001E977C: CC404031 1CC64301
	v_wmma_f32_16x16x16_f16 v[1:8], v[57:64], v[149:156], v[129:136]// 0000001E9784: CC404001 1E072B39
	s_waitcnt lgkmcnt(4)                                       // 0000001E978C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[41:48], v[129:136]// 0000001E9790: CC404019 1E065339
	s_waitcnt lgkmcnt(2)                                       // 0000001E9798: BF89FC27
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[105:112], v[129:136]// 0000001E979C: CC404011 1E06D339
	s_waitcnt lgkmcnt(0)                                       // 0000001E97A4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[9:16], v[57:64], v[121:128], v[129:136]// 0000001E97A8: CC404009 1E06F339
	s_and_saveexec_b32 s43, s6                                 // 0000001E97B0: BEAB2006
	s_cbranch_execnz 1503                                      // 0000001E97B4: BFA605DF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6d34>
	s_or_b32 exec_lo, exec_lo, s43                             // 0000001E97B8: 8C7E2B7E
	s_and_saveexec_b32 s43, s5                                 // 0000001E97BC: BEAB2005
	s_cbranch_execnz 1531                                      // 0000001E97C0: BFA605FB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6db0>
	s_or_b32 exec_lo, exec_lo, s43                             // 0000001E97C4: 8C7E2B7E
	s_and_saveexec_b32 s43, s7                                 // 0000001E97C8: BEAB2007
	s_cbranch_execz 28                                         // 0000001E97CC: BFA5001C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5640>
	ds_load_b128 v[33:36], v185 offset:96                      // 0000001E97D0: DBFC0060 210000B9
	ds_load_b128 v[37:40], v185 offset:112                     // 0000001E97D8: DBFC0070 250000B9
	ds_load_b128 v[45:48], v185 offset:2416                    // 0000001E97E0: DBFC0970 2D0000B9
	ds_load_b128 v[41:44], v185 offset:2400                    // 0000001E97E8: DBFC0960 290000B9
	ds_load_b128 v[61:64], v185 offset:4720                    // 0000001E97F0: DBFC1270 3D0000B9
	ds_load_b128 v[57:60], v185 offset:4704                    // 0000001E97F8: DBFC1260 390000B9
	ds_load_b128 v[77:80], v185 offset:7024                    // 0000001E9800: DBFC1B70 4D0000B9
	ds_load_b128 v[73:76], v185 offset:7008                    // 0000001E9808: DBFC1B60 490000B9
	s_waitcnt lgkmcnt(6)                                       // 0000001E9810: BF89FC67
	v_wmma_f32_16x16x16_f16 v[25:32], v[65:72], v[33:40], v[25:32]// 0000001E9814: CC404019 1C664341
	s_waitcnt lgkmcnt(4)                                       // 0000001E981C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[17:24], v[65:72], v[41:48], v[17:24]// 0000001E9820: CC404011 1C465341
	s_waitcnt lgkmcnt(2)                                       // 0000001E9828: BF89FC27
	v_wmma_f32_16x16x16_f16 v[9:16], v[65:72], v[57:64], v[9:16]// 0000001E982C: CC404009 1C267341
	s_waitcnt lgkmcnt(0)                                       // 0000001E9834: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[65:72], v[73:80], v[1:8] // 0000001E9838: CC404001 1C069341
	s_or_b32 exec_lo, exec_lo, s43                             // 0000001E9840: 8C7E2B7E
	s_add_i32 s42, s42, 64                                     // 0000001E9844: 812AC02A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001E9848: BF870009
	s_cmp_le_i32 s42, s47                                      // 0000001E984C: BF052F2A
	s_mov_b32 s42, -1                                          // 0000001E9850: BEAA00C1
	s_cbranch_scc1 1526                                        // 0000001E9854: BFA205F6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6e30>
	s_and_not1_b32 vcc_lo, exec_lo, s42                        // 0000001E9858: 916A2A7E
	s_cbranch_vccz 1915                                        // 0000001E985C: BFA3077B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x744c>
	s_add_i32 s1, s40, 1                                       // 0000001E9860: 81018128
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001E9864: BF870009
	s_cmp_ge_i32 s1, s48                                       // 0000001E9868: BF033001
	s_cbranch_scc1 797                                         // 0000001E986C: BFA2031D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x62e4>
	scratch_load_b32 v0, off, off offset:80                    // 0000001E9870: DC510050 007C0000
	s_lshl_b32 s0, s1, 6                                       // 0000001E9878: 84008601
	s_mul_i32 s8, s1, 0xc00                                    // 0000001E987C: 9608FF01 00000C00
	s_sub_i32 s0, s47, s0                                      // 0000001E9884: 8180002F
	s_mul_hi_u32 s9, s1, 0xc00                                 // 0000001E9888: 9689FF01 00000C00
	s_add_u32 s8, s8, s2                                       // 0000001E9890: 80080208
	s_addc_u32 s9, s9, s3                                      // 0000001E9894: 82090309
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001E9898: BF870009
	s_lshl_b64 s[8:9], s[8:9], 9                               // 0000001E989C: 84888908
	s_cmp_gt_i32 s0, 0                                         // 0000001E98A0: BF028000
	s_waitcnt vmcnt(0)                                         // 0000001E98A4: BF8903F7
	.long 0xd7006a01                                           // 0000001E98A8: D7006A01
	v_cndmask_b32_e32 v0, v0, v8, vcc_lo                       // 0000001E98AC: 02001100
	scratch_load_b32 v0, off, off offset:84                    // 0000001E98B0: DC510054 007C0000
	s_waitcnt vmcnt(0)                                         // 0000001E98B8: BF8903F7
	v_add_co_ci_u32_e64 v2, null, s9, v0, vcc_lo               // 0000001E98BC: D5207C02 01AA0009
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E98C4: 986A80C1
	s_cmp_gt_i32 s0, 1                                         // 0000001E98C8: BF028100
	v_dual_cndmask_b32 v3, v174, v1 :: v_dual_cndmask_b32 v4, v175, v2// 0000001E98CC: CA5203AE 030405AF
	global_load_b32 v0, v[3:4], off                            // 0000001E98D4: DC520000 007C0003
	s_waitcnt vmcnt(0)                                         // 0000001E98DC: BF8903F7
	scratch_store_b32 off, v0, off offset:4                    // 0000001E98E0: DC690004 007C0000
	.long 0xd7006a00                                           // 0000001E98E8: D7006A00
	v_cndmask_b32_e32 v1, 0x6000, v1, vcc_lo                   // 0000001E98EC: 020202FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E98F4: BF8700A1
	v_add_co_ci_u32_e64 v3, null, 0, v2, vcc_lo                // 0000001E98F8: D5207C03 01AA0480
	.long 0xd7006a05                                           // 0000001E9900: D7006A05
	v_cndmask_b32_e32 v1, 0xc000, v1, vcc_lo                   // 0000001E9904: 020202FF 0000C000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001E990C: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9914: 986A80C1
	s_cmp_gt_i32 s0, 2                                         // 0000001E9918: BF028200
	v_dual_cndmask_b32 v4, v175, v3 :: v_dual_cndmask_b32 v3, v174, v0// 0000001E991C: CA5207AF 040201AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9924: 986A80C1
	s_cmp_gt_i32 s0, 3                                         // 0000001E9928: BF028300
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001E992C: CA520DAF 06040BAE
	global_load_b32 v0, v[3:4], off                            // 0000001E9934: DC520000 007C0003
	.long 0xd7006a07                                           // 0000001E993C: D7006A07
	v_cndmask_b32_e32 v1, 0x12000, v1, vcc_lo                  // 0000001E9940: 020202FF 00012000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E9948: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001E994C: D5207C08 01AA0480
	global_load_b32 v3, v[5:6], off                            // 0000001E9954: DC520000 037C0005
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E995C: 986A80C1
	s_cmp_gt_i32 s0, 4                                         // 0000001E9960: BF028400
	v_cndmask_b32_e32 v4, v175, v8, vcc_lo                     // 0000001E9964: 020811AF
	s_waitcnt vmcnt(0)                                         // 0000001E9968: BF8903F7
	scratch_store_b32 off, v3, off offset:8                    // 0000001E996C: DC690008 007C0300
	v_cndmask_b32_e32 v3, v174, v7, vcc_lo                     // 0000001E9974: 02060FAE
	.long 0xd7006a05                                           // 0000001E9978: D7006A05
	v_cndmask_b32_e32 v1, 0x18000, v1, vcc_lo                  // 0000001E997C: 020202FF 00018000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E9984: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001E9988: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001E9990: D7006A07
	v_cndmask_b32_e32 v1, 0x1e000, v1, vcc_lo                  // 0000001E9994: 020202FF 0001E000
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001E999C: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E99A4: 986A80C1
	s_cmp_gt_i32 s0, 5                                         // 0000001E99A8: BF028500
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001E99AC: CA520DAF 06040BAE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E99B4: 986A80C1
	s_cmp_gt_i32 s0, 6                                         // 0000001E99B8: BF028600
	v_dual_cndmask_b32 v8, v175, v8 :: v_dual_cndmask_b32 v7, v174, v7// 0000001E99BC: CA5211AF 08060FAE
	.long 0xd7006a09                                           // 0000001E99C4: D7006A09
	v_cndmask_b32_e32 v1, 0x24000, v1, vcc_lo                  // 0000001E99C8: 020202FF 00024000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E99D0: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001E99D4: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001E99DC: D7006A0B
	v_cndmask_b32_e32 v1, 0x2a000, v1, vcc_lo                  // 0000001E99E0: 020202FF 0002A000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001E99E8: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E99F0: 986A80C1
	s_cmp_gt_i32 s0, 7                                         // 0000001E99F4: BF028700
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001E99F8: CA5215AF 0A0813AE
	global_load_b32 v233, v[3:4], off                          // 0000001E9A00: DC520000 E97C0003
	global_load_b32 v234, v[5:6], off                          // 0000001E9A08: DC520000 EA7C0005
	global_load_b32 v235, v[7:8], off                          // 0000001E9A10: DC520000 EB7C0007
	global_load_b32 v3, v[9:10], off                           // 0000001E9A18: DC520000 037C0009
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9A20: 986A80C1
	s_cmp_gt_i32 s0, 8                                         // 0000001E9A24: BF028800
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001E9A28: CA5219AF 0C0A17AE
	global_load_b32 v168, v[11:12], off                        // 0000001E9A30: DC520000 A87C000B
	s_waitcnt vmcnt(1)                                         // 0000001E9A38: BF8907F7
	scratch_store_b32 off, v3, off offset:12                   // 0000001E9A3C: DC69000C 007C0300
	.long 0xd7006a03                                           // 0000001E9A44: D7006A03
	v_cndmask_b32_e32 v1, 0x30000, v1, vcc_lo                  // 0000001E9A48: 020202FF 00030000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E9A50: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001E9A54: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001E9A5C: D7006A05
	v_cndmask_b32_e32 v1, 0x36000, v1, vcc_lo                  // 0000001E9A60: 020202FF 00036000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001E9A68: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9A70: 986A80C1
	s_cmp_gt_i32 s0, 9                                         // 0000001E9A74: BF028900
	v_dual_cndmask_b32 v4, v175, v4 :: v_dual_cndmask_b32 v3, v174, v3// 0000001E9A78: CA5209AF 040207AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9A80: 986A80C1
	s_cmp_gt_i32 s0, 10                                        // 0000001E9A84: BF028A00
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001E9A88: CA520DAF 06040BAE
	global_load_b32 v169, v[3:4], off                          // 0000001E9A90: DC520000 A97C0003
	.long 0xd7006a07                                           // 0000001E9A98: D7006A07
	v_cndmask_b32_e32 v1, 0x3c000, v1, vcc_lo                  // 0000001E9A9C: 020202FF 0003C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E9AA4: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001E9AA8: D5207C08 01AA0480
	global_load_b32 v3, v[5:6], off                            // 0000001E9AB0: DC520000 037C0005
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9AB8: 986A80C1
	s_cmp_gt_i32 s0, 11                                        // 0000001E9ABC: BF028B00
	v_cndmask_b32_e32 v4, v175, v8, vcc_lo                     // 0000001E9AC0: 020811AF
	s_waitcnt vmcnt(0)                                         // 0000001E9AC4: BF8903F7
	scratch_store_b32 off, v3, off offset:16                   // 0000001E9AC8: DC690010 007C0300
	v_cndmask_b32_e32 v3, v174, v7, vcc_lo                     // 0000001E9AD0: 02060FAE
	.long 0xd7006a05                                           // 0000001E9AD4: D7006A05
	v_cndmask_b32_e32 v1, 0x42000, v1, vcc_lo                  // 0000001E9AD8: 020202FF 00042000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E9AE0: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001E9AE4: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001E9AEC: D7006A07
	v_cndmask_b32_e32 v1, 0x48000, v1, vcc_lo                  // 0000001E9AF0: 020202FF 00048000
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001E9AF8: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9B00: 986A80C1
	s_cmp_gt_i32 s0, 12                                        // 0000001E9B04: BF028C00
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001E9B08: CA520DAF 06040BAE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9B10: 986A80C1
	s_cmp_gt_i32 s0, 13                                        // 0000001E9B14: BF028D00
	v_dual_cndmask_b32 v8, v175, v8 :: v_dual_cndmask_b32 v7, v174, v7// 0000001E9B18: CA5211AF 08060FAE
	.long 0xd7006a09                                           // 0000001E9B20: D7006A09
	v_cndmask_b32_e32 v1, 0x4e000, v1, vcc_lo                  // 0000001E9B24: 020202FF 0004E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E9B2C: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001E9B30: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001E9B38: D7006A0B
	v_cndmask_b32_e32 v1, 0x54000, v1, vcc_lo                  // 0000001E9B3C: 020202FF 00054000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001E9B44: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9B4C: 986A80C1
	s_cmp_gt_i32 s0, 14                                        // 0000001E9B50: BF028E00
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001E9B54: CA5215AF 0A0813AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9B5C: 986A80C1
	s_cmp_gt_i32 s0, 15                                        // 0000001E9B60: BF028F00
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001E9B64: CA5219AF 0C0A17AE
	global_load_b32 v236, v[3:4], off                          // 0000001E9B6C: DC520000 EC7C0003
	global_load_b32 v237, v[5:6], off                          // 0000001E9B74: DC520000 ED7C0005
	global_load_b32 v238, v[7:8], off                          // 0000001E9B7C: DC520000 EE7C0007
	global_load_b32 v227, v[9:10], off                         // 0000001E9B84: DC520000 E37C0009
	global_load_b32 v170, v[11:12], off                        // 0000001E9B8C: DC520000 AA7C000B
	.long 0xd7006a03                                           // 0000001E9B94: D7006A03
	v_cndmask_b32_e32 v1, 0x5a000, v1, vcc_lo                  // 0000001E9B98: 020202FF 0005A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E9BA0: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001E9BA4: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001E9BAC: D7006A05
	v_cndmask_b32_e32 v1, 0x60000, v1, vcc_lo                  // 0000001E9BB0: 020202FF 00060000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001E9BB8: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9BC0: 986A80C1
	s_cmp_gt_i32 s0, 16                                        // 0000001E9BC4: BF029000
	v_dual_cndmask_b32 v4, v175, v4 :: v_dual_cndmask_b32 v3, v174, v3// 0000001E9BC8: CA5209AF 040207AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9BD0: 986A80C1
	s_cmp_gt_i32 s0, 17                                        // 0000001E9BD4: BF029100
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001E9BD8: CA520DAF 06040BAE
	.long 0xd7006a07                                           // 0000001E9BE0: D7006A07
	v_cndmask_b32_e32 v1, 0x66000, v1, vcc_lo                  // 0000001E9BE4: 020202FF 00066000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E9BEC: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001E9BF0: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9BF8: 986A80C1
	global_load_b32 v171, v[3:4], off                          // 0000001E9BFC: DC520000 AB7C0003
	global_load_b32 v228, v[5:6], off                          // 0000001E9C04: DC520000 E47C0005
	v_dual_cndmask_b32 v4, v175, v8 :: v_dual_cndmask_b32 v3, v174, v7// 0000001E9C0C: CA5211AF 04020FAE
	.long 0xd7006a05                                           // 0000001E9C14: D7006A05
	v_cndmask_b32_e32 v1, 0x6c000, v1, vcc_lo                  // 0000001E9C18: 020202FF 0006C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E9C20: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001E9C24: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001E9C2C: D7006A07
	v_cndmask_b32_e32 v1, 0x72000, v1, vcc_lo                  // 0000001E9C30: 020202FF 00072000
	s_cmp_gt_i32 s0, 18                                        // 0000001E9C38: BF029200
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001E9C3C: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9C44: 986A80C1
	s_cmp_gt_i32 s0, 19                                        // 0000001E9C48: BF029300
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001E9C4C: CA520DAF 06040BAE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9C54: 986A80C1
	s_cmp_gt_i32 s0, 20                                        // 0000001E9C58: BF029400
	v_dual_cndmask_b32 v8, v175, v8 :: v_dual_cndmask_b32 v7, v174, v7// 0000001E9C5C: CA5211AF 08060FAE
	.long 0xd7006a09                                           // 0000001E9C64: D7006A09
	v_cndmask_b32_e32 v1, 0x78000, v1, vcc_lo                  // 0000001E9C68: 020202FF 00078000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E9C70: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001E9C74: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001E9C7C: D7006A0B
	v_cndmask_b32_e32 v1, 0x7e000, v1, vcc_lo                  // 0000001E9C80: 020202FF 0007E000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001E9C88: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9C90: 986A80C1
	s_cmp_gt_i32 s0, 21                                        // 0000001E9C94: BF029500
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001E9C98: CA5215AF 0A0813AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9CA0: 986A80C1
	s_cmp_gt_i32 s0, 22                                        // 0000001E9CA4: BF029600
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001E9CA8: CA5219AF 0C0A17AE
	global_load_b32 v239, v[3:4], off                          // 0000001E9CB0: DC520000 EF7C0003
	global_load_b32 v240, v[5:6], off                          // 0000001E9CB8: DC520000 F07C0005
	global_load_b32 v241, v[7:8], off                          // 0000001E9CC0: DC520000 F17C0007
	global_load_b32 v181, v[9:10], off                         // 0000001E9CC8: DC520000 B57C0009
	global_load_b32 v211, v[11:12], off                        // 0000001E9CD0: DC520000 D37C000B
	.long 0xd7006a03                                           // 0000001E9CD8: D7006A03
	v_cndmask_b32_e32 v1, 0x84000, v1, vcc_lo                  // 0000001E9CDC: 020202FF 00084000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E9CE4: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001E9CE8: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001E9CF0: D7006A05
	v_cndmask_b32_e32 v1, 0x8a000, v1, vcc_lo                  // 0000001E9CF4: 020202FF 0008A000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001E9CFC: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9D04: 986A80C1
	s_cmp_gt_i32 s0, 23                                        // 0000001E9D08: BF029700
	v_dual_cndmask_b32 v4, v175, v4 :: v_dual_cndmask_b32 v3, v174, v3// 0000001E9D0C: CA5209AF 040207AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9D14: 986A80C1
	s_cmp_gt_i32 s0, 24                                        // 0000001E9D18: BF029800
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001E9D1C: CA520DAF 06040BAE
	.long 0xd7006a07                                           // 0000001E9D24: D7006A07
	v_cndmask_b32_e32 v1, 0x90000, v1, vcc_lo                  // 0000001E9D28: 020202FF 00090000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E9D30: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001E9D34: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9D3C: 986A80C1
	global_load_b32 v212, v[3:4], off                          // 0000001E9D40: DC520000 D47C0003
	global_load_b32 v173, v[5:6], off                          // 0000001E9D48: DC520000 AD7C0005
	v_dual_cndmask_b32 v4, v175, v8 :: v_dual_cndmask_b32 v3, v174, v7// 0000001E9D50: CA5211AF 04020FAE
	.long 0xd7006a05                                           // 0000001E9D58: D7006A05
	v_cndmask_b32_e32 v1, 0x96000, v1, vcc_lo                  // 0000001E9D5C: 020202FF 00096000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E9D64: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001E9D68: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001E9D70: D7006A07
	v_cndmask_b32_e32 v1, 0x9c000, v1, vcc_lo                  // 0000001E9D74: 020202FF 0009C000
	s_cmp_gt_i32 s0, 25                                        // 0000001E9D7C: BF029900
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001E9D80: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9D88: 986A80C1
	s_cmp_gt_i32 s0, 26                                        // 0000001E9D8C: BF029A00
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001E9D90: CA520DAF 06040BAE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9D98: 986A80C1
	s_cmp_gt_i32 s0, 27                                        // 0000001E9D9C: BF029B00
	v_dual_cndmask_b32 v8, v175, v8 :: v_dual_cndmask_b32 v7, v174, v7// 0000001E9DA0: CA5211AF 08060FAE
	.long 0xd7006a09                                           // 0000001E9DA8: D7006A09
	v_cndmask_b32_e32 v1, 0xa2000, v1, vcc_lo                  // 0000001E9DAC: 020202FF 000A2000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E9DB4: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001E9DB8: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001E9DC0: D7006A0B
	v_cndmask_b32_e32 v1, 0xa8000, v1, vcc_lo                  // 0000001E9DC4: 020202FF 000A8000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001E9DCC: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9DD4: 986A80C1
	s_cmp_gt_i32 s0, 28                                        // 0000001E9DD8: BF029C00
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001E9DDC: CA5215AF 0A0813AE
	global_load_b32 v242, v[3:4], off                          // 0000001E9DE4: DC520000 F27C0003
	global_load_b32 v243, v[5:6], off                          // 0000001E9DEC: DC520000 F37C0005
	global_load_b32 v244, v[7:8], off                          // 0000001E9DF4: DC520000 F47C0007
	global_load_b32 v3, v[9:10], off                           // 0000001E9DFC: DC520000 037C0009
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9E04: 986A80C1
	s_cmp_gt_i32 s0, 29                                        // 0000001E9E08: BF029D00
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001E9E0C: CA5219AF 0C0A17AE
	global_load_b32 v213, v[11:12], off                        // 0000001E9E14: DC520000 D57C000B
	s_waitcnt vmcnt(1)                                         // 0000001E9E1C: BF8907F7
	scratch_store_b32 off, v3, off offset:20                   // 0000001E9E20: DC690014 007C0300
	.long 0xd7006a03                                           // 0000001E9E28: D7006A03
	v_cndmask_b32_e32 v1, 0xae000, v1, vcc_lo                  // 0000001E9E2C: 020202FF 000AE000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E9E34: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001E9E38: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001E9E40: D7006A05
	v_cndmask_b32_e32 v1, 0xb4000, v1, vcc_lo                  // 0000001E9E44: 020202FF 000B4000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001E9E4C: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9E54: 986A80C1
	s_cmp_gt_i32 s0, 30                                        // 0000001E9E58: BF029E00
	v_dual_cndmask_b32 v4, v175, v4 :: v_dual_cndmask_b32 v3, v174, v3// 0000001E9E5C: CA5209AF 040207AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9E64: 986A80C1
	s_cmp_gt_i32 s0, 31                                        // 0000001E9E68: BF029F00
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001E9E6C: CA520DAF 06040BAE
	global_load_b32 v214, v[3:4], off                          // 0000001E9E74: DC520000 D67C0003
	.long 0xd7006a07                                           // 0000001E9E7C: D7006A07
	v_cndmask_b32_e32 v1, 0xba000, v1, vcc_lo                  // 0000001E9E80: 020202FF 000BA000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E9E88: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001E9E8C: D5207C08 01AA0480
	global_load_b32 v3, v[5:6], off                            // 0000001E9E94: DC520000 037C0005
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9E9C: 986A80C1
	s_cmp_gt_i32 s0, 32                                        // 0000001E9EA0: BF02A000
	v_cndmask_b32_e32 v4, v175, v8, vcc_lo                     // 0000001E9EA4: 020811AF
	s_waitcnt vmcnt(0)                                         // 0000001E9EA8: BF8903F7
	scratch_store_b32 off, v3, off offset:24                   // 0000001E9EAC: DC690018 007C0300
	v_cndmask_b32_e32 v3, v174, v7, vcc_lo                     // 0000001E9EB4: 02060FAE
	.long 0xd7006a05                                           // 0000001E9EB8: D7006A05
	v_cndmask_b32_e32 v1, 0xc0000, v1, vcc_lo                  // 0000001E9EBC: 020202FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E9EC4: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001E9EC8: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001E9ED0: D7006A07
	v_cndmask_b32_e32 v1, 0xc6000, v1, vcc_lo                  // 0000001E9ED4: 020202FF 000C6000
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001E9EDC: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9EE4: 986A80C1
	s_cmp_gt_i32 s0, 33                                        // 0000001E9EE8: BF02A100
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001E9EEC: CA520DAF 06040BAE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9EF4: 986A80C1
	s_cmp_gt_i32 s0, 34                                        // 0000001E9EF8: BF02A200
	v_dual_cndmask_b32 v8, v175, v8 :: v_dual_cndmask_b32 v7, v174, v7// 0000001E9EFC: CA5211AF 08060FAE
	.long 0xd7006a09                                           // 0000001E9F04: D7006A09
	v_cndmask_b32_e32 v1, 0xcc000, v1, vcc_lo                  // 0000001E9F08: 020202FF 000CC000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E9F10: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001E9F14: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001E9F1C: D7006A0B
	v_cndmask_b32_e32 v1, 0xd2000, v1, vcc_lo                  // 0000001E9F20: 020202FF 000D2000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001E9F28: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9F30: 986A80C1
	s_cmp_gt_i32 s0, 35                                        // 0000001E9F34: BF02A300
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001E9F38: CA5215AF 0A0813AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9F40: 986A80C1
	s_cmp_gt_i32 s0, 36                                        // 0000001E9F44: BF02A400
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001E9F48: CA5219AF 0C0A17AE
	global_load_b32 v245, v[3:4], off                          // 0000001E9F50: DC520000 F57C0003
	global_load_b32 v246, v[5:6], off                          // 0000001E9F58: DC520000 F67C0005
	global_load_b32 v247, v[7:8], off                          // 0000001E9F60: DC520000 F77C0007
	global_load_b32 v184, v[9:10], off                         // 0000001E9F68: DC520000 B87C0009
	global_load_b32 v215, v[11:12], off                        // 0000001E9F70: DC520000 D77C000B
	.long 0xd7006a03                                           // 0000001E9F78: D7006A03
	v_cndmask_b32_e32 v1, 0xd8000, v1, vcc_lo                  // 0000001E9F7C: 020202FF 000D8000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001E9F84: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001E9F88: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001E9F90: D7006A05
	v_cndmask_b32_e32 v1, 0xde000, v1, vcc_lo                  // 0000001E9F94: 020202FF 000DE000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001E9F9C: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9FA4: 986A80C1
	s_cmp_gt_i32 s0, 37                                        // 0000001E9FA8: BF02A500
	v_dual_cndmask_b32 v4, v175, v4 :: v_dual_cndmask_b32 v3, v174, v3// 0000001E9FAC: CA5209AF 040207AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9FB4: 986A80C1
	s_cmp_gt_i32 s0, 38                                        // 0000001E9FB8: BF02A600
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001E9FBC: CA520DAF 06040BAE
	global_load_b32 v216, v[3:4], off                          // 0000001E9FC4: DC520000 D87C0003
	.long 0xd7006a07                                           // 0000001E9FCC: D7006A07
	v_cndmask_b32_e32 v1, 0xe4000, v1, vcc_lo                  // 0000001E9FD0: 020202FF 000E4000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001E9FD8: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001E9FDC: D5207C08 01AA0480
	global_load_b32 v3, v[5:6], off                            // 0000001E9FE4: DC520000 037C0005
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001E9FEC: 986A80C1
	s_cmp_gt_i32 s0, 39                                        // 0000001E9FF0: BF02A700
	v_cndmask_b32_e32 v4, v175, v8, vcc_lo                     // 0000001E9FF4: 020811AF
	s_waitcnt vmcnt(0)                                         // 0000001E9FF8: BF8903F7
	scratch_store_b32 off, v3, off offset:28                   // 0000001E9FFC: DC69001C 007C0300
	v_cndmask_b32_e32 v3, v174, v7, vcc_lo                     // 0000001EA004: 02060FAE
	.long 0xd7006a05                                           // 0000001EA008: D7006A05
	v_cndmask_b32_e32 v1, 0xea000, v1, vcc_lo                  // 0000001EA00C: 020202FF 000EA000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EA014: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001EA018: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001EA020: D7006A07
	v_cndmask_b32_e32 v1, 0xf0000, v1, vcc_lo                  // 0000001EA024: 020202FF 000F0000
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001EA02C: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA034: 986A80C1
	s_cmp_gt_i32 s0, 40                                        // 0000001EA038: BF02A800
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001EA03C: CA520DAF 06040BAE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA044: 986A80C1
	s_cmp_gt_i32 s0, 41                                        // 0000001EA048: BF02A900
	v_dual_cndmask_b32 v8, v175, v8 :: v_dual_cndmask_b32 v7, v174, v7// 0000001EA04C: CA5211AF 08060FAE
	.long 0xd7006a09                                           // 0000001EA054: D7006A09
	v_cndmask_b32_e32 v1, 0xf6000, v1, vcc_lo                  // 0000001EA058: 020202FF 000F6000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EA060: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001EA064: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001EA06C: D7006A0B
	v_cndmask_b32_e32 v1, 0xfc000, v1, vcc_lo                  // 0000001EA070: 020202FF 000FC000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001EA078: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA080: 986A80C1
	s_cmp_gt_i32 s0, 42                                        // 0000001EA084: BF02AA00
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001EA088: CA5215AF 0A0813AE
	global_load_b32 v248, v[3:4], off                          // 0000001EA090: DC520000 F87C0003
	global_load_b32 v249, v[5:6], off                          // 0000001EA098: DC520000 F97C0005
	global_load_b32 v250, v[7:8], off                          // 0000001EA0A0: DC520000 FA7C0007
	global_load_b32 v3, v[9:10], off                           // 0000001EA0A8: DC520000 037C0009
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA0B0: 986A80C1
	s_cmp_gt_i32 s0, 43                                        // 0000001EA0B4: BF02AB00
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001EA0B8: CA5219AF 0C0A17AE
	global_load_b32 v217, v[11:12], off                        // 0000001EA0C0: DC520000 D97C000B
	s_waitcnt vmcnt(1)                                         // 0000001EA0C8: BF8907F7
	scratch_store_b32 off, v3, off offset:32                   // 0000001EA0CC: DC690020 007C0300
	.long 0xd7006a03                                           // 0000001EA0D4: D7006A03
	v_cndmask_b32_e32 v1, 0x102000, v1, vcc_lo                 // 0000001EA0D8: 020202FF 00102000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EA0E0: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001EA0E4: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001EA0EC: D7006A05
	v_cndmask_b32_e32 v1, 0x108000, v1, vcc_lo                 // 0000001EA0F0: 020202FF 00108000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001EA0F8: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA100: 986A80C1
	s_cmp_gt_i32 s0, 44                                        // 0000001EA104: BF02AC00
	v_dual_cndmask_b32 v4, v175, v4 :: v_dual_cndmask_b32 v3, v174, v3// 0000001EA108: CA5209AF 040207AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA110: 986A80C1
	s_cmp_gt_i32 s0, 45                                        // 0000001EA114: BF02AD00
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001EA118: CA520DAF 06040BAE
	global_load_b32 v218, v[3:4], off                          // 0000001EA120: DC520000 DA7C0003
	.long 0xd7006a07                                           // 0000001EA128: D7006A07
	v_cndmask_b32_e32 v1, 0x10e000, v1, vcc_lo                 // 0000001EA12C: 020202FF 0010E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EA134: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001EA138: D5207C08 01AA0480
	global_load_b32 v3, v[5:6], off                            // 0000001EA140: DC520000 037C0005
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA148: 986A80C1
	s_cmp_gt_i32 s0, 46                                        // 0000001EA14C: BF02AE00
	v_cndmask_b32_e32 v4, v175, v8, vcc_lo                     // 0000001EA150: 020811AF
	s_waitcnt vmcnt(0)                                         // 0000001EA154: BF8903F7
	scratch_store_b32 off, v3, off offset:36                   // 0000001EA158: DC690024 007C0300
	v_cndmask_b32_e32 v3, v174, v7, vcc_lo                     // 0000001EA160: 02060FAE
	.long 0xd7006a05                                           // 0000001EA164: D7006A05
	v_cndmask_b32_e32 v1, 0x114000, v1, vcc_lo                 // 0000001EA168: 020202FF 00114000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EA170: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001EA174: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001EA17C: D7006A07
	v_cndmask_b32_e32 v1, 0x11a000, v1, vcc_lo                 // 0000001EA180: 020202FF 0011A000
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001EA188: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA190: 986A80C1
	s_cmp_gt_i32 s0, 47                                        // 0000001EA194: BF02AF00
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001EA198: CA520DAF 06040BAE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA1A0: 986A80C1
	s_cmp_gt_i32 s0, 48                                        // 0000001EA1A4: BF02B000
	v_dual_cndmask_b32 v8, v175, v8 :: v_dual_cndmask_b32 v7, v174, v7// 0000001EA1A8: CA5211AF 08060FAE
	.long 0xd7006a09                                           // 0000001EA1B0: D7006A09
	v_cndmask_b32_e32 v1, 0x120000, v1, vcc_lo                 // 0000001EA1B4: 020202FF 00120000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EA1BC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001EA1C0: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001EA1C8: D7006A0B
	v_cndmask_b32_e32 v1, 0x126000, v1, vcc_lo                 // 0000001EA1CC: 020202FF 00126000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001EA1D4: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA1DC: 986A80C1
	s_cmp_gt_i32 s0, 49                                        // 0000001EA1E0: BF02B100
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001EA1E4: CA5215AF 0A0813AE
	global_load_b32 v251, v[3:4], off                          // 0000001EA1EC: DC520000 FB7C0003
	global_load_b32 v252, v[5:6], off                          // 0000001EA1F4: DC520000 FC7C0005
	global_load_b32 v253, v[7:8], off                          // 0000001EA1FC: DC520000 FD7C0007
	global_load_b32 v3, v[9:10], off                           // 0000001EA204: DC520000 037C0009
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA20C: 986A80C1
	s_cmp_gt_i32 s0, 50                                        // 0000001EA210: BF02B200
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001EA214: CA5219AF 0C0A17AE
	global_load_b32 v219, v[11:12], off                        // 0000001EA21C: DC520000 DB7C000B
	s_waitcnt vmcnt(1)                                         // 0000001EA224: BF8907F7
	scratch_store_b32 off, v3, off offset:40                   // 0000001EA228: DC690028 007C0300
	.long 0xd7006a03                                           // 0000001EA230: D7006A03
	v_cndmask_b32_e32 v1, 0x12c000, v1, vcc_lo                 // 0000001EA234: 020202FF 0012C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EA23C: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001EA240: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001EA248: D7006A05
	v_cndmask_b32_e32 v1, 0x132000, v1, vcc_lo                 // 0000001EA24C: 020202FF 00132000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001EA254: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA25C: 986A80C1
	s_cmp_gt_i32 s0, 51                                        // 0000001EA260: BF02B300
	v_dual_cndmask_b32 v4, v175, v4 :: v_dual_cndmask_b32 v3, v174, v3// 0000001EA264: CA5209AF 040207AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA26C: 986A80C1
	s_cmp_gt_i32 s0, 52                                        // 0000001EA270: BF02B400
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001EA274: CA520DAF 06040BAE
	global_load_b32 v220, v[3:4], off                          // 0000001EA27C: DC520000 DC7C0003
	.long 0xd7006a07                                           // 0000001EA284: D7006A07
	v_cndmask_b32_e32 v1, 0x138000, v1, vcc_lo                 // 0000001EA288: 020202FF 00138000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EA290: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001EA294: D5207C08 01AA0480
	global_load_b32 v3, v[5:6], off                            // 0000001EA29C: DC520000 037C0005
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA2A4: 986A80C1
	s_cmp_gt_i32 s0, 53                                        // 0000001EA2A8: BF02B500
	v_cndmask_b32_e32 v4, v175, v8, vcc_lo                     // 0000001EA2AC: 020811AF
	s_waitcnt vmcnt(0)                                         // 0000001EA2B0: BF8903F7
	scratch_store_b32 off, v3, off offset:44                   // 0000001EA2B4: DC69002C 007C0300
	v_cndmask_b32_e32 v3, v174, v7, vcc_lo                     // 0000001EA2BC: 02060FAE
	.long 0xd7006a05                                           // 0000001EA2C0: D7006A05
	v_cndmask_b32_e32 v1, 0x13e000, v1, vcc_lo                 // 0000001EA2C4: 020202FF 0013E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EA2CC: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001EA2D0: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001EA2D8: D7006A07
	v_cndmask_b32_e32 v1, 0x144000, v1, vcc_lo                 // 0000001EA2DC: 020202FF 00144000
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001EA2E4: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA2EC: 986A80C1
	s_cmp_gt_i32 s0, 54                                        // 0000001EA2F0: BF02B600
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001EA2F4: CA520DAF 06040BAE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA2FC: 986A80C1
	s_cmp_gt_i32 s0, 55                                        // 0000001EA300: BF02B700
	v_dual_cndmask_b32 v8, v175, v8 :: v_dual_cndmask_b32 v7, v174, v7// 0000001EA304: CA5211AF 08060FAE
	.long 0xd7006a09                                           // 0000001EA30C: D7006A09
	v_cndmask_b32_e32 v1, 0x14a000, v1, vcc_lo                 // 0000001EA310: 020202FF 0014A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EA318: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001EA31C: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001EA324: D7006A0B
	v_cndmask_b32_e32 v1, 0x150000, v1, vcc_lo                 // 0000001EA328: 020202FF 00150000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001EA330: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA338: 986A80C1
	s_cmp_gt_i32 s0, 56                                        // 0000001EA33C: BF02B800
	v_dual_cndmask_b32 v10, v175, v10 :: v_dual_cndmask_b32 v9, v174, v9// 0000001EA340: CA5215AF 0A0813AE
	global_load_b32 v254, v[3:4], off                          // 0000001EA348: DC520000 FE7C0003
	global_load_b32 v255, v[5:6], off                          // 0000001EA350: DC520000 FF7C0005
	global_load_b32 v186, v[7:8], off                          // 0000001EA358: DC520000 BA7C0007
	global_load_b32 v3, v[9:10], off                           // 0000001EA360: DC520000 037C0009
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA368: 986A80C1
	s_cmp_gt_i32 s0, 57                                        // 0000001EA36C: BF02B900
	v_dual_cndmask_b32 v12, v175, v12 :: v_dual_cndmask_b32 v11, v174, v11// 0000001EA370: CA5219AF 0C0A17AE
	global_load_b32 v221, v[11:12], off                        // 0000001EA378: DC520000 DD7C000B
	s_waitcnt vmcnt(1)                                         // 0000001EA380: BF8907F7
	scratch_store_b32 off, v3, off offset:48                   // 0000001EA384: DC690030 007C0300
	.long 0xd7006a03                                           // 0000001EA38C: D7006A03
	v_cndmask_b32_e32 v1, 0x156000, v1, vcc_lo                 // 0000001EA390: 020202FF 00156000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EA398: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001EA39C: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001EA3A4: D7006A05
	v_cndmask_b32_e32 v1, 0x15c000, v1, vcc_lo                 // 0000001EA3A8: 020202FF 0015C000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001EA3B0: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA3B8: 986A80C1
	s_cmp_gt_i32 s0, 58                                        // 0000001EA3BC: BF02BA00
	v_dual_cndmask_b32 v4, v175, v4 :: v_dual_cndmask_b32 v3, v174, v3// 0000001EA3C0: CA5209AF 040207AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA3C8: 986A80C1
	s_cmp_gt_i32 s0, 59                                        // 0000001EA3CC: BF02BB00
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001EA3D0: CA520DAF 06040BAE
	global_load_b32 v222, v[3:4], off                          // 0000001EA3D8: DC520000 DE7C0003
	.long 0xd7006a07                                           // 0000001EA3E0: D7006A07
	v_cndmask_b32_e32 v1, 0x162000, v1, vcc_lo                 // 0000001EA3E4: 020202FF 00162000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EA3EC: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001EA3F0: D5207C08 01AA0480
	global_load_b32 v3, v[5:6], off                            // 0000001EA3F8: DC520000 037C0005
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA400: 986A80C1
	s_cmp_gt_i32 s0, 60                                        // 0000001EA404: BF02BC00
	v_cndmask_b32_e32 v4, v175, v8, vcc_lo                     // 0000001EA408: 020811AF
	s_waitcnt vmcnt(0)                                         // 0000001EA40C: BF8903F7
	scratch_store_b32 off, v3, off offset:52                   // 0000001EA410: DC690034 007C0300
	v_cndmask_b32_e32 v3, v174, v7, vcc_lo                     // 0000001EA418: 02060FAE
	.long 0xd7006a05                                           // 0000001EA41C: D7006A05
	v_cndmask_b32_e32 v1, 0x168000, v1, vcc_lo                 // 0000001EA420: 020202FF 00168000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EA428: BF8700A1
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001EA42C: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001EA434: D7006A07
	v_cndmask_b32_e32 v1, 0x16e000, v1, vcc_lo                 // 0000001EA438: 020202FF 0016E000
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001EA440: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA448: 986A80C1
	s_cmp_gt_i32 s0, 61                                        // 0000001EA44C: BF02BD00
	v_dual_cndmask_b32 v6, v175, v6 :: v_dual_cndmask_b32 v5, v174, v5// 0000001EA450: CA520DAF 06040BAE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA458: 986A80C1
	s_cmp_gt_i32 s0, 62                                        // 0000001EA45C: BF02BE00
	v_dual_cndmask_b32 v8, v175, v8 :: v_dual_cndmask_b32 v7, v174, v7// 0000001EA460: CA5211AF 08060FAE
	.long 0xd7006a09                                           // 0000001EA468: D7006A09
	v_cndmask_b32_e32 v1, 0x174000, v1, vcc_lo                 // 0000001EA46C: 020202FF 00174000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EA474: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001EA478: D5207C0A 01AA0480
	.long 0xd7006a0b                                           // 0000001EA480: D7006A0B
	v_cndmask_b32_e32 v1, 0x17a000, v1, vcc_lo                 // 0000001EA484: 020202FF 0017A000
	v_add_co_ci_u32_e64 v12, null, 0, v2, vcc_lo               // 0000001EA48C: D5207C0C 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA494: 986A80C1
	s_cmp_gt_i32 s0, 63                                        // 0000001EA498: BF02BF00
	v_dual_cndmask_b32 v2, v175, v10 :: v_dual_cndmask_b32 v1, v174, v9// 0000001EA49C: CA5215AF 020013AE
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA4A4: 986A80C1
	global_load_b32 v172, v[3:4], off                          // 0000001EA4A8: DC520000 AC7C0003
	global_load_b32 v176, v[5:6], off                          // 0000001EA4B0: DC520000 B07C0005
	global_load_b32 v177, v[7:8], off                          // 0000001EA4B8: DC520000 B17C0007
	global_load_b32 v1, v[1:2], off                            // 0000001EA4C0: DC520000 017C0001
	v_dual_cndmask_b32 v10, v175, v12 :: v_dual_cndmask_b32 v9, v174, v11// 0000001EA4C8: CA5219AF 0A0817AE
	global_load_b32 v223, v[9:10], off                         // 0000001EA4D0: DC520000 DF7C0009
	s_waitcnt vmcnt(1)                                         // 0000001EA4D8: BF8907F7
	scratch_store_b32 off, v1, off offset:56                   // 0000001EA4DC: DC690038 007C0100
	s_waitcnt vmcnt(0)                                         // 0000001EA4E4: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 0000001EA4E8: BC7C0000
	s_barrier                                                  // 0000001EA4EC: BFBD0000
	buffer_gl0_inv                                             // 0000001EA4F0: E0AC0000 00000000
	ds_load_b128 v[1:4], v224                                  // 0000001EA4F8: DBFC0000 010000E0
	ds_load_b128 v[5:8], v224 offset:16                        // 0000001EA500: DBFC0010 050000E0
	ds_load_b128 v[25:28], v225                                // 0000001EA508: DBFC0000 190000E1
	ds_load_b128 v[29:32], v225 offset:16                      // 0000001EA510: DBFC0010 1D0000E1
	ds_load_b128 v[9:12], v224 offset:32                       // 0000001EA518: DBFC0020 090000E0
	ds_load_b128 v[13:16], v224 offset:48                      // 0000001EA520: DBFC0030 0D0000E0
	ds_load_b128 v[33:36], v225 offset:2304                    // 0000001EA528: DBFC0900 210000E1
	ds_load_b128 v[37:40], v225 offset:2320                    // 0000001EA530: DBFC0910 250000E1
	ds_load_b128 v[41:44], v225 offset:4608                    // 0000001EA538: DBFC1200 290000E1
	ds_load_b128 v[45:48], v225 offset:4624                    // 0000001EA540: DBFC1210 2D0000E1
	ds_load_b128 v[49:52], v225 offset:6912                    // 0000001EA548: DBFC1B00 310000E1
	ds_load_b128 v[53:56], v225 offset:6928                    // 0000001EA550: DBFC1B10 350000E1
	ds_load_b128 v[57:60], v225 offset:9216                    // 0000001EA558: DBFC2400 390000E1
	ds_load_b128 v[61:64], v225 offset:9232                    // 0000001EA560: DBFC2410 3D0000E1
	ds_load_b128 v[65:68], v225 offset:11520                   // 0000001EA568: DBFC2D00 410000E1
	ds_load_b128 v[69:72], v225 offset:11536                   // 0000001EA570: DBFC2D10 450000E1
	ds_load_b128 v[73:76], v225 offset:13824                   // 0000001EA578: DBFC3600 490000E1
	ds_load_b128 v[77:80], v225 offset:13840                   // 0000001EA580: DBFC3610 4D0000E1
	ds_load_b128 v[81:84], v225 offset:16128                   // 0000001EA588: DBFC3F00 510000E1
	ds_load_b128 v[85:88], v225 offset:16144                   // 0000001EA590: DBFC3F10 550000E1
	ds_load_b128 v[89:92], v225 offset:32                      // 0000001EA598: DBFC0020 590000E1
	ds_load_b128 v[93:96], v225 offset:48                      // 0000001EA5A0: DBFC0030 5D0000E1
	v_dual_mov_b32 v17, s20 :: v_dual_mov_b32 v18, s21         // 0000001EA5A8: CA100014 11120015
	v_dual_mov_b32 v19, s22 :: v_dual_mov_b32 v20, s23         // 0000001EA5B0: CA100016 13140017
	v_dual_mov_b32 v21, s24 :: v_dual_mov_b32 v22, s25         // 0000001EA5B8: CA100018 15160019
	v_dual_mov_b32 v23, s26 :: v_dual_mov_b32 v24, s27         // 0000001EA5C0: CA10001A 1718001B
	s_mul_f32 s0, s41, 0x3fb8aa3b                              // 0000001EA5C8: A200FF29 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000001EA5D0: BF87000B
	s_xor_b32 s8, s0, 0x80000000                               // 0000001EA5D4: 8D08FF00 80000000
	s_rndne_f32 s9, s0                                         // 0000001EA5DC: BE896300
	s_waitcnt lgkmcnt(14)                                      // 0000001EA5E0: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[105:112], v[33:40], v[1:8], v[17:24]// 0000001EA5E4: CC404069 1C460321
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[1:8], v[17:24]// 0000001EA5EC: CC404061 1C460319
	ds_load_b128 v[25:28], v225 offset:2336                    // 0000001EA5F4: DBFC0920 190000E1
	ds_load_b128 v[29:32], v225 offset:2352                    // 0000001EA5FC: DBFC0930 1D0000E1
	s_waitcnt lgkmcnt(14)                                      // 0000001EA604: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[1:8], v[17:24]// 0000001EA608: CC404021 1C460329
	s_waitcnt lgkmcnt(12)                                      // 0000001EA610: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[41:48], v[49:56], v[1:8], v[17:24]// 0000001EA614: CC404029 1C460331
	s_waitcnt lgkmcnt(10)                                      // 0000001EA61C: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[49:56], v[57:64], v[1:8], v[17:24]// 0000001EA620: CC404031 1C460339
	s_waitcnt lgkmcnt(8)                                       // 0000001EA628: BF89FC87
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[1:8], v[17:24]// 0000001EA62C: CC404039 1C460341
	s_waitcnt lgkmcnt(6)                                       // 0000001EA634: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[73:80], v[1:8], v[17:24]// 0000001EA638: CC404041 1C460349
	s_waitcnt lgkmcnt(4)                                       // 0000001EA640: BF89FC47
	v_wmma_f32_16x16x16_f16 v[73:80], v[81:88], v[1:8], v[17:24]// 0000001EA644: CC404049 1C460351
	ds_load_b128 v[1:4], v225 offset:4640                      // 0000001EA64C: DBFC1220 010000E1
	ds_load_b128 v[5:8], v225 offset:4656                      // 0000001EA654: DBFC1230 050000E1
	ds_load_b128 v[17:20], v225 offset:6944                    // 0000001EA65C: DBFC1B20 110000E1
	ds_load_b128 v[21:24], v225 offset:6960                    // 0000001EA664: DBFC1B30 150000E1
	ds_load_b128 v[81:84], v225 offset:9248                    // 0000001EA66C: DBFC2420 510000E1
	ds_load_b128 v[85:88], v225 offset:9264                    // 0000001EA674: DBFC2430 550000E1
	s_waitcnt lgkmcnt(8)                                       // 0000001EA67C: BF89FC87
	v_wmma_f32_16x16x16_f16 v[97:104], v[89:96], v[9:16], v[97:104]// 0000001EA680: CC404061 1D861359
	s_fmamk_f32 s8, s41, 0x3fb8aa3b, s8                        // 0000001EA688: A3080829 3FB8AA3B
	s_sub_f32 s0, s0, s9                                       // 0000001EA690: A0800900
	s_cmp_nlt_f32 s41, 0xc2ce8ed0                              // 0000001EA694: BF4EFF29 C2CE8ED0
	s_waitcnt lgkmcnt(6)                                       // 0000001EA69C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[105:112], v[25:32], v[9:16], v[105:112]// 0000001EA6A0: CC404069 1DA61319
	ds_load_b128 v[25:28], v225 offset:11552                   // 0000001EA6A8: DBFC2D20 190000E1
	ds_load_b128 v[29:32], v225 offset:11568                   // 0000001EA6B0: DBFC2D30 1D0000E1
	s_fmamk_f32 s8, s41, 0x32a5705f, s8                        // 0000001EA6B8: A3080829 32A5705F
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA6C0: 986A80C1
	s_cmp_ngt_f32 s41, 0x42b17218                              // 0000001EA6C4: BF4BFF29 42B17218
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000001EA6CC: BF870599
	s_add_f32 s0, s0, s8                                       // 0000001EA6D0: A0000800
	v_exp_f32_e32 v91, s0                                      // 0000001EA6D4: 7EB64A00
	s_waitcnt lgkmcnt(6)                                       // 0000001EA6D8: BF89FC67
	v_wmma_f32_16x16x16_f16 v[33:40], v[1:8], v[9:16], v[33:40]// 0000001EA6DC: CC404021 1C861301
	ds_load_b128 v[1:4], v225 offset:13856                     // 0000001EA6E4: DBFC3620 010000E1
	ds_load_b128 v[5:8], v225 offset:13872                     // 0000001EA6EC: DBFC3630 050000E1
	s_waitcnt lgkmcnt(6)                                       // 0000001EA6F4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[9:16], v[41:48]// 0000001EA6F8: CC404029 1CA61311
	ds_load_b128 v[17:20], v225 offset:16160                   // 0000001EA700: DBFC3F20 110000E1
	ds_load_b128 v[21:24], v225 offset:16176                   // 0000001EA708: DBFC3F30 150000E1
	s_waitcnt lgkmcnt(6)                                       // 0000001EA710: BF89FC67
	v_wmma_f32_16x16x16_f16 v[49:56], v[81:88], v[9:16], v[49:56]// 0000001EA714: CC404031 1CC61351
	ds_load_b128 v[85:88], v224 offset:80                      // 0000001EA71C: DBFC0050 550000E0
	ds_load_b128 v[81:84], v224 offset:64                      // 0000001EA724: DBFC0040 510000E0
	s_cvt_i32_f32 s0, s9                                       // 0000001EA72C: BE806609
	s_waitcnt lgkmcnt(6)                                       // 0000001EA730: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[25:32], v[9:16], v[57:64]// 0000001EA734: CC404039 1CE61319
	ds_load_b128 v[29:32], v225 offset:80                      // 0000001EA73C: DBFC0050 1D0000E1
	ds_load_b128 v[25:28], v225 offset:64                      // 0000001EA744: DBFC0040 190000E1
	.long 0xd71c005b                                           // 0000001EA74C: D71C005B
	v_cndmask_b32_e32 v0, v91, v0, vcc_lo                      // 0000001EA750: 0200015B
	s_waitcnt lgkmcnt(6)                                       // 0000001EA754: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[1:8], v[9:16], v[65:72]// 0000001EA758: CC404041 1D061301
	ds_load_b128 v[5:8], v225 offset:2384                      // 0000001EA760: DBFC0950 050000E1
	ds_load_b128 v[1:4], v225 offset:2368                      // 0000001EA768: DBFC0940 010000E1
	s_waitcnt lgkmcnt(6)                                       // 0000001EA770: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[9:16], v[73:80]// 0000001EA774: CC404049 1D261311
	ds_load_b128 v[13:16], v225 offset:4688                    // 0000001EA77C: DBFC1250 0D0000E1
	ds_load_b128 v[9:12], v225 offset:4672                     // 0000001EA784: DBFC1240 090000E1
	ds_load_b128 v[21:24], v225 offset:6992                    // 0000001EA78C: DBFC1B50 150000E1
	ds_load_b128 v[17:20], v225 offset:6976                    // 0000001EA794: DBFC1B40 110000E1
	s_waitcnt lgkmcnt(6)                                       // 0000001EA79C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[81:88], v[97:104]// 0000001EA7A0: CC404061 1D86A319
	ds_load_b128 v[29:32], v225 offset:9296                    // 0000001EA7A8: DBFC2450 1D0000E1
	ds_load_b128 v[25:28], v225 offset:9280                    // 0000001EA7B0: DBFC2440 190000E1
	s_waitcnt lgkmcnt(6)                                       // 0000001EA7B8: BF89FC67
	v_wmma_f32_16x16x16_f16 v[105:112], v[1:8], v[81:88], v[105:112]// 0000001EA7BC: CC404069 1DA6A301
	ds_load_b128 v[5:8], v225 offset:11600                     // 0000001EA7C4: DBFC2D50 050000E1
	ds_load_b128 v[1:4], v225 offset:11584                     // 0000001EA7CC: DBFC2D40 010000E1
	s_waitcnt lgkmcnt(6)                                       // 0000001EA7D4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[33:40], v[9:16], v[81:88], v[33:40]// 0000001EA7D8: CC404021 1C86A309
	ds_load_b128 v[13:16], v225 offset:13904                   // 0000001EA7E0: DBFC3650 0D0000E1
	ds_load_b128 v[9:12], v225 offset:13888                    // 0000001EA7E8: DBFC3640 090000E1
	s_waitcnt lgkmcnt(6)                                       // 0000001EA7F0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[81:88], v[41:48]// 0000001EA7F4: CC404029 1CA6A311
	ds_load_b128 v[21:24], v225 offset:16208                   // 0000001EA7FC: DBFC3F50 150000E1
	ds_load_b128 v[17:20], v225 offset:16192                   // 0000001EA804: DBFC3F40 110000E1
	s_waitcnt lgkmcnt(6)                                       // 0000001EA80C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[49:56], v[25:32], v[81:88], v[49:56]// 0000001EA810: CC404031 1CC6A319
	ds_load_b128 v[29:32], v224 offset:112                     // 0000001EA818: DBFC0070 1D0000E0
	ds_load_b128 v[25:28], v224 offset:96                      // 0000001EA820: DBFC0060 190000E0
	s_waitcnt lgkmcnt(6)                                       // 0000001EA828: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[1:8], v[81:88], v[57:64]// 0000001EA82C: CC404039 1CE6A301
	ds_load_b128 v[5:8], v225 offset:112                       // 0000001EA834: DBFC0070 050000E1
	ds_load_b128 v[1:4], v225 offset:96                        // 0000001EA83C: DBFC0060 010000E1
	s_waitcnt lgkmcnt(6)                                       // 0000001EA844: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[9:16], v[81:88], v[65:72]// 0000001EA848: CC404041 1D06A309
	ds_load_b128 v[13:16], v225 offset:2416                    // 0000001EA850: DBFC0970 0D0000E1
	ds_load_b128 v[9:12], v225 offset:2400                     // 0000001EA858: DBFC0960 090000E1
	s_waitcnt lgkmcnt(6)                                       // 0000001EA860: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[81:88], v[73:80]// 0000001EA864: CC404049 1D26A311
	ds_load_b128 v[21:24], v225 offset:4720                    // 0000001EA86C: DBFC1270 150000E1
	ds_load_b128 v[17:20], v225 offset:4704                    // 0000001EA874: DBFC1260 110000E1
	ds_load_b128 v[85:88], v225 offset:7024                    // 0000001EA87C: DBFC1B70 550000E1
	ds_load_b128 v[81:84], v225 offset:7008                    // 0000001EA884: DBFC1B60 510000E1
	s_waitcnt lgkmcnt(6)                                       // 0000001EA88C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[97:104], v[1:8], v[25:32], v[97:104]// 0000001EA890: CC404061 1D863301
	ds_load_b128 v[5:8], v225 offset:9328                      // 0000001EA898: DBFC2470 050000E1
	ds_load_b128 v[1:4], v225 offset:9312                      // 0000001EA8A0: DBFC2460 010000E1
	s_waitcnt lgkmcnt(4)                                       // 0000001EA8A8: BF89FC47
	v_wmma_f32_16x16x16_f16 v[33:40], v[17:24], v[25:32], v[33:40]// 0000001EA8AC: CC404021 1C863311
	ds_load_b128 v[21:24], v225 offset:13936                   // 0000001EA8B4: DBFC3670 150000E1
	ds_load_b128 v[17:20], v225 offset:13920                   // 0000001EA8BC: DBFC3660 110000E1
	s_waitcnt lgkmcnt(4)                                       // 0000001EA8C4: BF89FC47
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[25:32], v[41:48]// 0000001EA8C8: CC404029 1CA63351
	ds_load_b128 v[85:88], v225 offset:16240                   // 0000001EA8D0: DBFC3F70 550000E1
	ds_load_b128 v[81:84], v225 offset:16224                   // 0000001EA8D8: DBFC3F60 510000E1
	v_wmma_f32_16x16x16_f16 v[105:112], v[9:16], v[25:32], v[105:112]// 0000001EA8E0: CC404069 1DA63309
	ds_load_b128 v[13:16], v225 offset:11632                   // 0000001EA8E8: DBFC2D70 0D0000E1
	ds_load_b128 v[9:12], v225 offset:11616                    // 0000001EA8F0: DBFC2D60 090000E1
	ds_load_2addr_b32 v[89:90], v226 offset1:2                 // 0000001EA8F8: D8DC0200 590000E2
	s_waitcnt lgkmcnt(7)                                       // 0000001EA900: BF89FC77
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[25:32], v[49:56]// 0000001EA904: CC404031 1CC63301
	ds_load_2addr_b32 v[1:2], v226 offset0:4 offset1:6         // 0000001EA90C: D8DC0604 010000E2
	ds_load_2addr_b32 v[3:4], v226 offset0:8 offset1:10        // 0000001EA914: D8DC0A08 030000E2
	ds_load_2addr_b32 v[5:6], v226 offset0:12 offset1:14       // 0000001EA91C: D8DC0E0C 050000E2
	s_waitcnt lgkmcnt(8)                                       // 0000001EA924: BF89FC87
	v_wmma_f32_16x16x16_f16 v[65:72], v[17:24], v[25:32], v[65:72]// 0000001EA928: CC404041 1D063311
	ds_load_2addr_b32 v[7:8], v226 offset0:16 offset1:18       // 0000001EA930: D8DC1210 070000E2
	s_waitcnt lgkmcnt(7)                                       // 0000001EA938: BF89FC77
	v_wmma_f32_16x16x16_f16 v[73:80], v[81:88], v[25:32], v[73:80]// 0000001EA93C: CC404049 1D263351
	s_waitcnt lgkmcnt(5)                                       // 0000001EA944: BF89FC57
	v_wmma_f32_16x16x16_f16 v[57:64], v[9:16], v[25:32], v[57:64]// 0000001EA948: CC404039 1CE63309
	v_cndmask_b32_e32 v31, 0, v91, vcc_lo                      // 0000001EA950: 023EB680
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001EA954: 986A80C1
	ds_load_2addr_b32 v[9:10], v226 offset0:20 offset1:22      // 0000001EA958: D8DC1614 090000E2
	ds_load_2addr_b32 v[11:12], v226 offset0:24 offset1:26     // 0000001EA960: D8DC1A18 0B0000E2
	ds_load_2addr_b32 v[13:14], v226 offset0:28 offset1:30     // 0000001EA968: D8DC1E1C 0D0000E2
	ds_load_2addr_b32 v[15:16], v226 offset0:32 offset1:34     // 0000001EA970: D8DC2220 0F0000E2
	ds_load_2addr_b32 v[17:18], v226 offset0:36 offset1:38     // 0000001EA978: D8DC2624 110000E2
	v_cndmask_b32_e32 v91, 0x7f800000, v31, vcc_lo             // 0000001EA980: 02B63EFF 7F800000
	ds_load_2addr_b32 v[19:20], v226 offset0:40 offset1:42     // 0000001EA988: D8DC2A28 130000E2
	ds_load_2addr_b32 v[21:22], v226 offset0:44 offset1:46     // 0000001EA990: D8DC2E2C 150000E2
	ds_load_2addr_b32 v[23:24], v226 offset0:48 offset1:50     // 0000001EA998: D8DC3230 170000E2
	ds_load_2addr_b32 v[25:26], v226 offset0:52 offset1:54     // 0000001EA9A0: D8DC3634 190000E2
	ds_load_2addr_b32 v[27:28], v226 offset0:56 offset1:58     // 0000001EA9A8: D8DC3A38 1B0000E2
	ds_load_2addr_b32 v[29:30], v226 offset0:60 offset1:62     // 0000001EA9B0: D8DC3E3C 1D0000E2
	s_waitcnt lgkmcnt(15)                                      // 0000001EA9B8: BF89FCF7
	v_mul_f32_e32 v90, v91, v90                                // 0000001EA9BC: 10B4B55B
	v_mul_f32_e32 v89, v91, v89                                // 0000001EA9C0: 10B2B35B
	ds_load_2addr_b32 v[31:32], v226 offset0:64 offset1:66     // 0000001EA9C4: D8DC4240 1F0000E2
	ds_load_2addr_b32 v[81:82], v226 offset0:68 offset1:70     // 0000001EA9CC: D8DC4644 510000E2
	ds_load_2addr_b32 v[83:84], v226 offset0:72 offset1:74     // 0000001EA9D4: D8DC4A48 530000E2
	ds_load_2addr_b32 v[85:86], v226 offset0:76 offset1:78     // 0000001EA9DC: D8DC4E4C 550000E2
	s_waitcnt lgkmcnt(18)                                      // 0000001EA9E4: BF89FD27
	v_mul_f32_e32 v93, v91, v2                                 // 0000001EA9E8: 10BA055B
	v_mul_f32_e32 v92, v91, v1                                 // 0000001EA9EC: 10B8035B
	v_fmac_f32_e32 v90, 0x3b800000, v98                        // 0000001EA9F0: 56B4C4FF 3B800000
	s_waitcnt lgkmcnt(17)                                      // 0000001EA9F8: BF89FD17
	v_dual_mul_f32 v94, v91, v3 :: v_dual_fmac_f32 v89, 0x3b800000, v97// 0000001EA9FC: C8C0075B 5E58C2FF 3B800000
	v_mul_f32_e32 v95, v91, v4                                 // 0000001EAA08: 10BE095B
	v_dual_fmac_f32 v93, 0x3b800000, v100 :: v_dual_fmac_f32 v92, 0x3b800000, v99// 0000001EAA0C: C800C8FF 5D5CC6FF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001EAA18: BF8701A3
	v_fmac_f32_e32 v94, 0x3b800000, v101                       // 0000001EAA1C: 56BCCAFF 3B800000
	s_waitcnt lgkmcnt(16)                                      // 0000001EAA24: BF89FD07
	v_dual_mul_f32 v96, v91, v5 :: v_dual_fmac_f32 v95, 0x3b800000, v102// 0000001EAA28: C8C00B5B 605ECCFF 3B800000
	v_mul_f32_e32 v113, v91, v6                                // 0000001EAA34: 10E20D5B
	s_waitcnt lgkmcnt(14)                                      // 0000001EAA38: BF89FCE7
	v_mul_f32_e32 v100, v91, v10                               // 0000001EAA3C: 10C8155B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001EAA40: BF870233
	v_dual_mul_f32 v99, v91, v9 :: v_dual_fmac_f32 v96, 0x3b800000, v103// 0000001EAA44: C8C0135B 6360CEFF 3B800000
	v_mul_f32_e32 v98, v91, v8                                 // 0000001EAA50: 10C4115B
	v_fmac_f32_e32 v113, 0x3b800000, v104                      // 0000001EAA54: 56E2D0FF 3B800000
	v_fmac_f32_e32 v100, 0x3b800000, v108                      // 0000001EAA5C: 56C8D8FF 3B800000
	s_waitcnt lgkmcnt(13)                                      // 0000001EAA64: BF89FCD7
	v_dual_mul_f32 v102, v91, v12 :: v_dual_fmac_f32 v99, 0x3b800000, v107// 0000001EAA68: C8C0195B 6662D6FF 3B800000
	v_mul_f32_e32 v101, v91, v11                               // 0000001EAA74: 10CA175B
	v_dual_mul_f32 v97, v91, v7 :: v_dual_fmac_f32 v98, 0x3b800000, v106// 0000001EAA78: C8C00F5B 6162D4FF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001EAA84: BF8701A3
	v_fmac_f32_e32 v102, 0x3b800000, v110                      // 0000001EAA88: 56CCDCFF 3B800000
	s_waitcnt lgkmcnt(12)                                      // 0000001EAA90: BF89FCC7
	v_dual_mul_f32 v104, v91, v14 :: v_dual_fmac_f32 v101, 0x3b800000, v109// 0000001EAA94: C8C01D5B 6864DAFF 3B800000
	v_mul_f32_e32 v103, v91, v13                               // 0000001EAAA0: 10CE1B5B
	s_waitcnt lgkmcnt(11)                                      // 0000001EAAA4: BF89FCB7
	v_dual_fmac_f32 v97, 0x3b800000, v105 :: v_dual_mul_f32 v106, v91, v16// 0000001EAAA8: C806D2FF 616A215B 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001EAAB4: BF870193
	v_dual_fmac_f32 v104, 0x3b800000, v112 :: v_dual_mul_f32 v105, v91, v15// 0000001EAAB8: C806E0FF 68681F5B 3B800000
	v_fmac_f32_e32 v103, 0x3b800000, v111                      // 0000001EAAC4: 56CEDEFF 3B800000
	ds_load_2addr_b32 v[1:2], v226 offset0:80 offset1:82       // 0000001EAACC: D8DC5250 010000E2
	ds_load_2addr_b32 v[3:4], v226 offset0:84 offset1:86       // 0000001EAAD4: D8DC5654 030000E2
	ds_load_2addr_b32 v[5:6], v226 offset0:88 offset1:90       // 0000001EAADC: D8DC5A58 050000E2
	ds_load_2addr_b32 v[87:88], v226 offset0:92 offset1:94     // 0000001EAAE4: D8DC5E5C 570000E2
	v_fmac_f32_e32 v106, 0x3b800000, v34                       // 0000001EAAEC: 56D444FF 3B800000
	s_waitcnt lgkmcnt(14)                                      // 0000001EAAF4: BF89FCE7
	v_dual_mul_f32 v108, v91, v18 :: v_dual_fmac_f32 v105, 0x3b800000, v33// 0000001EAAF8: C8C0255B 6C6842FF 3B800000
	v_mul_f32_e32 v107, v91, v17                               // 0000001EAB04: 10D6235B
	ds_load_2addr_b32 v[7:8], v226 offset0:96 offset1:98       // 0000001EAB08: D8DC6260 070000E2
	ds_load_2addr_b32 v[9:10], v226 offset0:100 offset1:102    // 0000001EAB10: D8DC6664 090000E2
	ds_load_2addr_b32 v[11:12], v226 offset0:104 offset1:106   // 0000001EAB18: D8DC6A68 0B0000E2
	ds_load_2addr_b32 v[13:14], v226 offset0:108 offset1:110   // 0000001EAB20: D8DC6E6C 0D0000E2
	s_waitcnt lgkmcnt(15)                                      // 0000001EAB28: BF89FCF7
	v_mul_f32_e32 v24, v91, v24                                // 0000001EAB2C: 1030315B
	v_fmac_f32_e32 v108, 0x3b800000, v36                       // 0000001EAB30: 56D848FF 3B800000
	v_dual_mul_f32 v110, v91, v20 :: v_dual_fmac_f32 v107, 0x3b800000, v35// 0000001EAB38: C8C0295B 6E6A46FF 3B800000
	v_mul_f32_e32 v109, v91, v19                               // 0000001EAB44: 10DA275B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001EAB48: BF870194
	v_dual_mul_f32 v23, v91, v23 :: v_dual_fmac_f32 v24, 0x3b800000, v42// 0000001EAB4C: C8C02F5B 171854FF 3B800000
	v_fmac_f32_e32 v110, 0x3b800000, v38                       // 0000001EAB58: 56DC4CFF 3B800000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001EAB60: BF870003
	v_dual_mul_f32 v112, v91, v22 :: v_dual_fmac_f32 v109, 0x3b800000, v37// 0000001EAB64: C8C02D5B 706C4AFF 3B800000
	v_mul_f32_e32 v111, v91, v21                               // 0000001EAB70: 10DE2B5B
	ds_load_2addr_b32 v[15:16], v226 offset0:112 offset1:114   // 0000001EAB74: D8DC7270 0F0000E2
	ds_load_2addr_b32 v[17:18], v226 offset0:116 offset1:118   // 0000001EAB7C: D8DC7674 110000E2
	ds_load_2addr_b32 v[19:20], v226 offset0:120 offset1:122   // 0000001EAB84: D8DC7A78 130000E2
	ds_load_2addr_b32 v[21:22], v226 offset0:124 offset1:126   // 0000001EAB8C: D8DC7E7C 150000E2
	s_waitcnt lgkmcnt(18)                                      // 0000001EAB94: BF89FD27
	v_dual_mul_f32 v26, v91, v26 :: v_dual_fmac_f32 v23, 0x3b800000, v41// 0000001EAB98: C8C0355B 1A1652FF 3B800000
	v_dual_fmac_f32 v112, 0x3b800000, v40 :: v_dual_fmac_f32 v111, 0x3b800000, v39// 0000001EABA4: C80050FF 706E4EFF 3B800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000001EABB0: BF870142
	v_dual_mul_f32 v25, v91, v25 :: v_dual_fmac_f32 v26, 0x3b800000, v44// 0000001EABB4: C8C0335B 191A58FF 3B800000
	s_waitcnt lgkmcnt(17)                                      // 0000001EABC0: BF89FD17
	v_mul_f32_e32 v28, v91, v28                                // 0000001EABC4: 1038395B
	s_cmp_lg_u32 s40, s36                                      // 0000001EABC8: BF072428
	v_fmac_f32_e32 v25, 0x3b800000, v43                        // 0000001EABCC: 563256FF 3B800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EABD4: BF8700A2
	v_dual_mul_f32 v27, v91, v27 :: v_dual_fmac_f32 v28, 0x3b800000, v46// 0000001EABD8: C8C0375B 1B1C5CFF 3B800000
	s_waitcnt lgkmcnt(16)                                      // 0000001EABE4: BF89FD07
	v_dual_mul_f32 v30, v91, v30 :: v_dual_fmac_f32 v27, 0x3b800000, v45// 0000001EABE8: C8C03D5B 1E1A5AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EABF4: BF8700A1
	v_dual_mul_f32 v29, v91, v29 :: v_dual_fmac_f32 v30, 0x3b800000, v48// 0000001EABF8: C8C03B5B 1D1E60FF 3B800000
	s_waitcnt lgkmcnt(15)                                      // 0000001EAC04: BF89FCF7
	v_dual_mul_f32 v32, v91, v32 :: v_dual_fmac_f32 v29, 0x3b800000, v47// 0000001EAC08: C8C0415B 201C5EFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EAC14: BF8700A1
	v_dual_mul_f32 v31, v91, v31 :: v_dual_fmac_f32 v32, 0x3b800000, v50// 0000001EAC18: C8C03F5B 1F2064FF 3B800000
	s_waitcnt lgkmcnt(14)                                      // 0000001EAC24: BF89FCE7
	v_dual_mul_f32 v34, v91, v82 :: v_dual_fmac_f32 v31, 0x3b800000, v49// 0000001EAC28: C8C0A55B 221E62FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EAC34: BF8700A1
	v_dual_mul_f32 v33, v91, v81 :: v_dual_fmac_f32 v34, 0x3b800000, v52// 0000001EAC38: C8C0A35B 212268FF 3B800000
	s_waitcnt lgkmcnt(13)                                      // 0000001EAC44: BF89FCD7
	v_dual_mul_f32 v36, v91, v84 :: v_dual_fmac_f32 v33, 0x3b800000, v51// 0000001EAC48: C8C0A95B 242066FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EAC54: BF8700A1
	v_dual_mul_f32 v35, v91, v83 :: v_dual_fmac_f32 v36, 0x3b800000, v54// 0000001EAC58: C8C0A75B 23246CFF 3B800000
	s_waitcnt lgkmcnt(12)                                      // 0000001EAC64: BF89FCC7
	v_dual_mul_f32 v38, v91, v86 :: v_dual_fmac_f32 v35, 0x3b800000, v53// 0000001EAC68: C8C0AD5B 26226AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EAC74: BF8700A1
	v_dual_mul_f32 v37, v91, v85 :: v_dual_fmac_f32 v38, 0x3b800000, v56// 0000001EAC78: C8C0AB5B 252670FF 3B800000
	s_waitcnt lgkmcnt(11)                                      // 0000001EAC84: BF89FCB7
	v_dual_mul_f32 v2, v91, v2 :: v_dual_fmac_f32 v37, 0x3b800000, v55// 0000001EAC88: C8C0055B 02246EFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EAC94: BF8700A1
	v_dual_mul_f32 v1, v91, v1 :: v_dual_fmac_f32 v2, 0x3b800000, v58// 0000001EAC98: C8C0035B 010274FF 3B800000
	s_waitcnt lgkmcnt(10)                                      // 0000001EACA4: BF89FCA7
	v_dual_mul_f32 v4, v91, v4 :: v_dual_fmac_f32 v1, 0x3b800000, v57// 0000001EACA8: C8C0095B 040072FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EACB4: BF8700A1
	v_dual_mul_f32 v3, v91, v3 :: v_dual_fmac_f32 v4, 0x3b800000, v60// 0000001EACB8: C8C0075B 030478FF 3B800000
	s_waitcnt lgkmcnt(9)                                       // 0000001EACC4: BF89FC97
	v_dual_mul_f32 v6, v91, v6 :: v_dual_fmac_f32 v3, 0x3b800000, v59// 0000001EACC8: C8C00D5B 060276FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EACD4: BF8700A1
	v_dual_mul_f32 v5, v91, v5 :: v_dual_fmac_f32 v6, 0x3b800000, v62// 0000001EACD8: C8C00B5B 05067CFF 3B800000
	s_waitcnt lgkmcnt(8)                                       // 0000001EACE4: BF89FC87
	v_dual_mul_f32 v40, v91, v88 :: v_dual_fmac_f32 v5, 0x3b800000, v61// 0000001EACE8: C8C0B15B 28047AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EACF4: BF8700A1
	v_dual_mul_f32 v39, v91, v87 :: v_dual_fmac_f32 v40, 0x3b800000, v64// 0000001EACF8: C8C0AF5B 272880FF 3B800000
	s_waitcnt lgkmcnt(7)                                       // 0000001EAD04: BF89FC77
	v_dual_mul_f32 v8, v91, v8 :: v_dual_fmac_f32 v39, 0x3b800000, v63// 0000001EAD08: C8C0115B 08267EFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EAD14: BF8700A1
	v_dual_mul_f32 v7, v91, v7 :: v_dual_fmac_f32 v8, 0x3b800000, v66// 0000001EAD18: C8C00F5B 070884FF 3B800000
	s_waitcnt lgkmcnt(6)                                       // 0000001EAD24: BF89FC67
	v_dual_mul_f32 v10, v91, v10 :: v_dual_fmac_f32 v7, 0x3b800000, v65// 0000001EAD28: C8C0155B 0A0682FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EAD34: BF8700A1
	v_dual_mul_f32 v9, v91, v9 :: v_dual_fmac_f32 v10, 0x3b800000, v68// 0000001EAD38: C8C0135B 090A88FF 3B800000
	s_waitcnt lgkmcnt(5)                                       // 0000001EAD44: BF89FC57
	v_dual_mul_f32 v12, v91, v12 :: v_dual_fmac_f32 v9, 0x3b800000, v67// 0000001EAD48: C8C0195B 0C0886FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EAD54: BF8700A1
	v_dual_mul_f32 v11, v91, v11 :: v_dual_fmac_f32 v12, 0x3b800000, v70// 0000001EAD58: C8C0175B 0B0C8CFF 3B800000
	s_waitcnt lgkmcnt(4)                                       // 0000001EAD64: BF89FC47
	v_dual_mul_f32 v14, v91, v14 :: v_dual_fmac_f32 v11, 0x3b800000, v69// 0000001EAD68: C8C01D5B 0E0A8AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EAD74: BF8700A1
	v_dual_mul_f32 v13, v91, v13 :: v_dual_fmac_f32 v14, 0x3b800000, v72// 0000001EAD78: C8C01B5B 0D0E90FF 3B800000
	s_waitcnt lgkmcnt(3)                                       // 0000001EAD84: BF89FC37
	v_dual_mul_f32 v16, v91, v16 :: v_dual_fmac_f32 v13, 0x3b800000, v71// 0000001EAD88: C8C0215B 100C8EFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EAD94: BF8700A1
	v_dual_mul_f32 v15, v91, v15 :: v_dual_fmac_f32 v16, 0x3b800000, v74// 0000001EAD98: C8C01F5B 0F1094FF 3B800000
	s_waitcnt lgkmcnt(2)                                       // 0000001EADA4: BF89FC27
	v_dual_mul_f32 v18, v91, v18 :: v_dual_fmac_f32 v15, 0x3b800000, v73// 0000001EADA8: C8C0255B 120E92FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EADB4: BF8700A1
	v_dual_mul_f32 v17, v91, v17 :: v_dual_fmac_f32 v18, 0x3b800000, v76// 0000001EADB8: C8C0235B 111298FF 3B800000
	s_waitcnt lgkmcnt(1)                                       // 0000001EADC4: BF89FC17
	v_dual_mul_f32 v20, v91, v20 :: v_dual_fmac_f32 v17, 0x3b800000, v75// 0000001EADC8: C8C0295B 141096FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001EADD4: BF8700A1
	v_dual_mul_f32 v19, v91, v19 :: v_dual_fmac_f32 v20, 0x3b800000, v78// 0000001EADD8: C8C0275B 13149CFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 0000001EADE4: BF89FC07
	v_dual_mul_f32 v22, v91, v22 :: v_dual_fmac_f32 v19, 0x3b800000, v77// 0000001EADE8: C8C02D5B 16129AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001EADF4: BF870091
	v_dual_mul_f32 v21, v91, v21 :: v_dual_fmac_f32 v22, 0x3b800000, v80// 0000001EADF8: C8C02B5B 1516A0FF 3B800000
	v_fmac_f32_e32 v21, 0x3b800000, v79                        // 0000001EAE04: 562A9EFF 3B800000
	ds_store_2addr_b32 v226, v89, v90 offset1:2                // 0000001EAE0C: D8380200 005A59E2
	ds_store_2addr_b32 v226, v92, v93 offset0:4 offset1:6      // 0000001EAE14: D8380604 005D5CE2
	ds_store_2addr_b32 v226, v94, v95 offset0:8 offset1:10     // 0000001EAE1C: D8380A08 005F5EE2
	ds_store_2addr_b32 v226, v96, v113 offset0:12 offset1:14   // 0000001EAE24: D8380E0C 007160E2
	ds_store_2addr_b32 v226, v97, v98 offset0:16 offset1:18    // 0000001EAE2C: D8381210 006261E2
	ds_store_2addr_b32 v226, v99, v100 offset0:20 offset1:22   // 0000001EAE34: D8381614 006463E2
	ds_store_2addr_b32 v226, v101, v102 offset0:24 offset1:26  // 0000001EAE3C: D8381A18 006665E2
	ds_store_2addr_b32 v226, v103, v104 offset0:28 offset1:30  // 0000001EAE44: D8381E1C 006867E2
	ds_store_2addr_b32 v226, v105, v106 offset0:32 offset1:34  // 0000001EAE4C: D8382220 006A69E2
	ds_store_2addr_b32 v226, v107, v108 offset0:36 offset1:38  // 0000001EAE54: D8382624 006C6BE2
	ds_store_2addr_b32 v226, v109, v110 offset0:40 offset1:42  // 0000001EAE5C: D8382A28 006E6DE2
	ds_store_2addr_b32 v226, v111, v112 offset0:44 offset1:46  // 0000001EAE64: D8382E2C 00706FE2
	ds_store_2addr_b32 v226, v23, v24 offset0:48 offset1:50    // 0000001EAE6C: D8383230 001817E2
	ds_store_2addr_b32 v226, v25, v26 offset0:52 offset1:54    // 0000001EAE74: D8383634 001A19E2
	ds_store_2addr_b32 v226, v27, v28 offset0:56 offset1:58    // 0000001EAE7C: D8383A38 001C1BE2
	ds_store_2addr_b32 v226, v29, v30 offset0:60 offset1:62    // 0000001EAE84: D8383E3C 001E1DE2
	ds_store_2addr_b32 v226, v31, v32 offset0:64 offset1:66    // 0000001EAE8C: D8384240 00201FE2
	ds_store_2addr_b32 v226, v33, v34 offset0:68 offset1:70    // 0000001EAE94: D8384644 002221E2
	ds_store_2addr_b32 v226, v35, v36 offset0:72 offset1:74    // 0000001EAE9C: D8384A48 002423E2
	ds_store_2addr_b32 v226, v37, v38 offset0:76 offset1:78    // 0000001EAEA4: D8384E4C 002625E2
	ds_store_2addr_b32 v226, v1, v2 offset0:80 offset1:82      // 0000001EAEAC: D8385250 000201E2
	ds_store_2addr_b32 v226, v3, v4 offset0:84 offset1:86      // 0000001EAEB4: D8385654 000403E2
	ds_store_2addr_b32 v226, v5, v6 offset0:88 offset1:90      // 0000001EAEBC: D8385A58 000605E2
	ds_store_2addr_b32 v226, v39, v40 offset0:92 offset1:94    // 0000001EAEC4: D8385E5C 002827E2
	ds_store_2addr_b32 v226, v7, v8 offset0:96 offset1:98      // 0000001EAECC: D8386260 000807E2
	ds_store_2addr_b32 v226, v9, v10 offset0:100 offset1:102   // 0000001EAED4: D8386664 000A09E2
	ds_store_2addr_b32 v226, v11, v12 offset0:104 offset1:106  // 0000001EAEDC: D8386A68 000C0BE2
	ds_store_2addr_b32 v226, v13, v14 offset0:108 offset1:110  // 0000001EAEE4: D8386E6C 000E0DE2
	ds_store_2addr_b32 v226, v15, v16 offset0:112 offset1:114  // 0000001EAEEC: D8387270 00100FE2
	ds_store_2addr_b32 v226, v17, v18 offset0:116 offset1:118  // 0000001EAEF4: D8387674 001211E2
	ds_store_2addr_b32 v226, v19, v20 offset0:120 offset1:122  // 0000001EAEFC: D8387A78 001413E2
	ds_store_2addr_b32 v226, v21, v22 offset0:124 offset1:126  // 0000001EAF04: D8387E7C 001615E2
	s_waitcnt lgkmcnt(0)                                       // 0000001EAF0C: BF89FC07
	s_barrier                                                  // 0000001EAF10: BFBD0000
	buffer_gl0_inv                                             // 0000001EAF14: E0AC0000 00000000
	s_cbranch_scc0 578                                         // 0000001EAF1C: BFA10242 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7628>
	s_cmp_lg_u32 s40, s37                                      // 0000001EAF20: BF072528
	s_cbranch_scc0 621                                         // 0000001EAF24: BFA1026D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x76dc>
	s_cmp_lg_u32 s40, s38                                      // 0000001EAF28: BF072628
	s_cbranch_scc1 59619                                       // 0000001EAF2C: BFA2E8E3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x10bc>
	s_branch 650                                               // 0000001EAF30: BFA0028A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x775c>
	ds_load_b128 v[33:36], v185 offset:32                      // 0000001EAF34: DBFC0020 210000B9
	ds_load_b128 v[37:40], v185 offset:48                      // 0000001EAF3C: DBFC0030 250000B9
	ds_load_b128 v[45:48], v185 offset:2352                    // 0000001EAF44: DBFC0930 2D0000B9
	ds_load_b128 v[41:44], v185 offset:2336                    // 0000001EAF4C: DBFC0920 290000B9
	ds_load_b128 v[61:64], v185 offset:4656                    // 0000001EAF54: DBFC1230 3D0000B9
	ds_load_b128 v[57:60], v185 offset:4640                    // 0000001EAF5C: DBFC1220 390000B9
	ds_load_b128 v[109:112], v185 offset:6960                  // 0000001EAF64: DBFC1B30 6D0000B9
	ds_load_b128 v[105:108], v185 offset:6944                  // 0000001EAF6C: DBFC1B20 690000B9
	s_waitcnt lgkmcnt(6)                                       // 0000001EAF74: BF89FC67
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[33:40], v[25:32]// 0000001EAF78: CC404019 1C664349
	s_waitcnt lgkmcnt(4)                                       // 0000001EAF80: BF89FC47
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[41:48], v[17:24]// 0000001EAF84: CC404011 1C465349
	s_waitcnt lgkmcnt(2)                                       // 0000001EAF8C: BF89FC27
	v_wmma_f32_16x16x16_f16 v[9:16], v[73:80], v[57:64], v[9:16]// 0000001EAF90: CC404009 1C267349
	s_waitcnt lgkmcnt(0)                                       // 0000001EAF98: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[73:80], v[105:112], v[1:8]// 0000001EAF9C: CC404001 1C06D349
	s_or_b32 exec_lo, exec_lo, s43                             // 0000001EAFA4: 8C7E2B7E
	s_and_saveexec_b32 s43, s5                                 // 0000001EAFA8: BEAB2005
	s_cbranch_execz 64005                                      // 0000001EAFAC: BFA5FA05 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x55c4>
	ds_load_b128 v[33:36], v185 offset:64                      // 0000001EAFB0: DBFC0040 210000B9
	ds_load_b128 v[37:40], v185 offset:80                      // 0000001EAFB8: DBFC0050 250000B9
	ds_load_b128 v[45:48], v185 offset:2384                    // 0000001EAFC0: DBFC0950 2D0000B9
	ds_load_b128 v[41:44], v185 offset:2368                    // 0000001EAFC8: DBFC0940 290000B9
	ds_load_b128 v[61:64], v185 offset:4688                    // 0000001EAFD0: DBFC1250 3D0000B9
	ds_load_b128 v[57:60], v185 offset:4672                    // 0000001EAFD8: DBFC1240 390000B9
	ds_load_b128 v[77:80], v185 offset:6992                    // 0000001EAFE0: DBFC1B50 4D0000B9
	ds_load_b128 v[73:76], v185 offset:6976                    // 0000001EAFE8: DBFC1B40 490000B9
	s_waitcnt lgkmcnt(6)                                       // 0000001EAFF0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[33:40], v[25:32]// 0000001EAFF4: CC404019 1C664359
	s_waitcnt lgkmcnt(4)                                       // 0000001EAFFC: BF89FC47
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[41:48], v[17:24]// 0000001EB000: CC404011 1C465359
	s_waitcnt lgkmcnt(2)                                       // 0000001EB008: BF89FC27
	v_wmma_f32_16x16x16_f16 v[9:16], v[89:96], v[57:64], v[9:16]// 0000001EB00C: CC404009 1C267359
	s_waitcnt lgkmcnt(0)                                       // 0000001EB014: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[89:96], v[73:80], v[1:8] // 0000001EB018: CC404001 1C069359
	s_or_b32 exec_lo, exec_lo, s43                             // 0000001EB020: 8C7E2B7E
	s_and_saveexec_b32 s43, s7                                 // 0000001EB024: BEAB2007
	s_cbranch_execnz 63977                                     // 0000001EB028: BFA6F9E9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x55d0>
	s_branch 64004                                             // 0000001EB02C: BFA0FA04 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5640>
	ds_load_2addr_b32 v[33:34], v232 offset1:2                 // 0000001EB030: D8DC0200 210000E8
	ds_load_2addr_b32 v[35:36], v232 offset0:4 offset1:6       // 0000001EB038: D8DC0604 230000E8
	ds_load_2addr_b32 v[37:38], v232 offset0:8 offset1:10      // 0000001EB040: D8DC0A08 250000E8
	ds_load_2addr_b32 v[39:40], v232 offset0:12 offset1:14     // 0000001EB048: D8DC0E0C 270000E8
	v_mad_u64_u32 v[41:42], null, 0x3000, v145, v[164:165]     // 0000001EB050: D6FE7C29 069322FF 00003000
	v_mad_u64_u32 v[43:44], null, 0x3000, v148, v[164:165]     // 0000001EB05C: D6FE7C2B 069328FF 00003000
	v_mad_u64_u32 v[45:46], null, 0x3000, v147, v[164:165]     // 0000001EB068: D6FE7C2D 069326FF 00003000
	v_mad_u64_u32 v[47:48], null, 0x3000, v146, v[164:165]     // 0000001EB074: D6FE7C2F 069324FF 00003000
	s_waitcnt lgkmcnt(3)                                       // 0000001EB080: BF89FC37
	v_fma_f32 v72, v97, v33, v17                               // 0000001EB084: D6130048 04464361
	v_fma_f32 v73, v98, v34, v18                               // 0000001EB08C: D6130049 044A4562
	s_waitcnt lgkmcnt(2)                                       // 0000001EB094: BF89FC27
	v_fma_f32 v74, v99, v35, v19                               // 0000001EB098: D613004A 044E4763
	v_fma_f32 v76, v100, v36, v20                              // 0000001EB0A0: D613004C 04524964
	s_waitcnt lgkmcnt(1)                                       // 0000001EB0A8: BF89FC17
	v_fma_f32 v80, v101, v37, v21                              // 0000001EB0AC: D6130050 04564B65
	v_dual_mul_f32 v72, 0x3b800000, v72 :: v_dual_mul_f32 v73, 0x3b800000, v73// 0000001EB0B4: C8C690FF 484892FF 3B800000
	v_mul_f32_e32 v74, 0x3b800000, v74                         // 0000001EB0C0: 109494FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 0000001EB0C8: BF89FC07
	v_fma_f32 v89, v104, v40, v24                              // 0000001EB0CC: D6130059 04625168
	v_mul_f32_e32 v76, 0x3b800000, v76                         // 0000001EB0D4: 109898FF 3B800000
	v_bfe_u32 v77, v72, 16, 1                                  // 0000001EB0DC: D610004D 02052148
	v_bfe_u32 v78, v73, 16, 1                                  // 0000001EB0E4: D610004E 02052149
	v_bfe_u32 v79, v74, 16, 1                                  // 0000001EB0EC: D610004F 0205214A
	v_mul_f32_e32 v89, 0x3b800000, v89                         // 0000001EB0F4: 10B2B2FF 3B800000
	v_fma_f32 v93, v82, v34, v10                               // 0000001EB0FC: D613005D 042A4552
	v_add3_u32 v72, v72, v77, 0x7fff                           // 0000001EB104: D6550048 03FE9B48 00007FFF
	v_add3_u32 v73, v73, v78, 0x7fff                           // 0000001EB110: D6550049 03FE9D49 00007FFF
	v_add3_u32 v74, v74, v79, 0x7fff                           // 0000001EB11C: D655004A 03FE9F4A 00007FFF
	v_bfe_u32 v77, v76, 16, 1                                  // 0000001EB128: D610004D 0205214C
	v_mul_f32_e32 v78, 0x3b800000, v80                         // 0000001EB130: 109CA0FF 3B800000
	v_fma_f32 v79, v102, v38, v22                              // 0000001EB138: D613004F 045A4D66
	v_fma_f32 v80, v103, v39, v23                              // 0000001EB140: D6130050 045E4F67
	v_fma_f32 v90, v81, v33, v9                                // 0000001EB148: D613005A 04264351
	v_add3_u32 v76, v76, v77, 0x7fff                           // 0000001EB150: D655004C 03FE9B4C 00007FFF
	v_bfe_u32 v77, v78, 16, 1                                  // 0000001EB15C: D610004D 0205214E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001EB164: BF870234
	v_dual_mul_f32 v79, 0x3b800000, v79 :: v_dual_mul_f32 v80, 0x3b800000, v80// 0000001EB168: C8C69EFF 4F50A0FF 3B800000
	v_bfe_u32 v92, v89, 16, 1                                  // 0000001EB174: D610005C 02052159
	v_fma_f32 v95, v86, v38, v14                               // 0000001EB17C: D613005F 043A4D56
	v_add3_u32 v77, v78, v77, 0x7fff                           // 0000001EB184: D655004D 03FE9B4E 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001EB190: BF870224
	v_bfe_u32 v78, v79, 16, 1                                  // 0000001EB194: D610004E 0205214F
	v_bfe_u32 v91, v80, 16, 1                                  // 0000001EB19C: D610005B 02052150
	v_dual_mul_f32 v90, 0x3b800000, v90 :: v_dual_mul_f32 v95, 0x3b800000, v95// 0000001EB1A4: C8C6B4FF 5A5EBEFF 3B800000
	v_fma_f32 v94, v85, v37, v13                               // 0000001EB1B0: D613005E 04364B55
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001EB1B8: BF870214
	v_add3_u32 v78, v79, v78, 0x7fff                           // 0000001EB1BC: D655004E 03FE9D4F 00007FFF
	v_add3_u32 v79, v80, v91, 0x7fff                           // 0000001EB1C8: D655004F 03FEB750 00007FFF
	v_add3_u32 v80, v89, v92, 0x7fff                           // 0000001EB1D4: D6550050 03FEB959 00007FFF
	v_bfe_u32 v89, v90, 16, 1                                  // 0000001EB1E0: D6100059 0205215A
	v_mul_f32_e32 v91, 0x3b800000, v93                         // 0000001EB1E8: 10B6BAFF 3B800000
	v_fma_f32 v92, v83, v35, v11                               // 0000001EB1F0: D613005C 042E4753
	v_fma_f32 v93, v84, v36, v12                               // 0000001EB1F8: D613005D 04324954
	v_fma_f32 v57, v113, v33, v25                              // 0000001EB200: D6130039 04664371
	v_add3_u32 v89, v90, v89, 0x7fff                           // 0000001EB208: D6550059 03FEB35A 00007FFF
	v_bfe_u32 v90, v91, 16, 1                                  // 0000001EB214: D610005A 0205215B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001EB21C: BF870234
	v_dual_mul_f32 v92, 0x3b800000, v92 :: v_dual_mul_f32 v93, 0x3b800000, v93// 0000001EB220: C8C6B8FF 5C5CBAFF 3B800000
	v_fma_f32 v33, v49, v33, v1                                // 0000001EB22C: D6130021 04064331
	v_mul_f32_e32 v94, 0x3b800000, v94                         // 0000001EB234: 10BCBCFF 3B800000
	v_add3_u32 v90, v91, v90, 0x7fff                           // 0000001EB23C: D655005A 03FEB55B 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001EB248: BF870004
	v_bfe_u32 v91, v92, 16, 1                                  // 0000001EB24C: D610005B 0205215C
	v_bfe_u32 v96, v93, 16, 1                                  // 0000001EB254: D6100060 0205215D
	v_fma_f32 v106, v87, v39, v15                              // 0000001EB25C: D613006A 043E4F57
	v_mul_f32_e32 v33, 0x3b800000, v33                         // 0000001EB264: 104242FF 3B800000
	v_bfe_u32 v105, v94, 16, 1                                 // 0000001EB26C: D6100069 0205215E
	v_fma_f32 v59, v115, v35, v27                              // 0000001EB274: D613003B 046E4773
	v_add3_u32 v91, v92, v91, 0x7fff                           // 0000001EB27C: D655005B 03FEB75C 00007FFF
	v_add3_u32 v92, v93, v96, 0x7fff                           // 0000001EB288: D655005C 03FEC15D 00007FFF
	v_fma_f32 v35, v51, v35, v3                                // 0000001EB294: D6130023 040E4733
	v_add3_u32 v93, v94, v105, 0x7fff                          // 0000001EB29C: D655005D 03FED35E 00007FFF
	v_bfe_u32 v94, v95, 16, 1                                  // 0000001EB2A8: D610005E 0205215F
	v_mul_f32_e32 v96, 0x3b800000, v106                        // 0000001EB2B0: 10C0D4FF 3B800000
	v_fma_f32 v105, v88, v40, v16                              // 0000001EB2B8: D6130069 04425158
	v_fma_f32 v58, v114, v34, v26                              // 0000001EB2C0: D613003A 046A4572
	v_fma_f32 v34, v50, v34, v2                                // 0000001EB2C8: D6130022 040A4532
	v_mul_f32_e32 v57, 0x3b800000, v57                         // 0000001EB2D0: 107272FF 3B800000
	v_add3_u32 v94, v95, v94, 0x7fff                           // 0000001EB2D8: D655005E 03FEBD5F 00007FFF
	v_mul_f32_e32 v105, 0x3b800000, v105                       // 0000001EB2E4: 10D2D2FF 3B800000
	v_mul_f32_e32 v35, 0x3b800000, v35                         // 0000001EB2EC: 104646FF 3B800000
	v_bfe_u32 v95, v96, 16, 1                                  // 0000001EB2F4: D610005F 02052160
	v_mul_f32_e32 v58, 0x3b800000, v58                         // 0000001EB2FC: 107474FF 3B800000
	v_fma_f32 v61, v117, v37, v29                              // 0000001EB304: D613003D 04764B75
	v_fma_f32 v37, v53, v37, v5                                // 0000001EB30C: D6130025 04164B35
	v_mul_f32_e32 v34, 0x3b800000, v34                         // 0000001EB314: 104444FF 3B800000
	v_fma_f32 v60, v116, v36, v28                              // 0000001EB31C: D613003C 04724974
	v_fma_f32 v63, v119, v39, v31                              // 0000001EB324: D613003F 047E4F77
	v_bfe_u32 v65, v57, 16, 1                                  // 0000001EB32C: D6100041 02052139
	v_add3_u32 v95, v96, v95, 0x7fff                           // 0000001EB334: D655005F 03FEBF60 00007FFF
	v_bfe_u32 v96, v105, 16, 1                                 // 0000001EB340: D6100060 02052169
	v_fma_f32 v36, v52, v36, v4                                // 0000001EB348: D6130024 04124934
	v_fma_f32 v62, v118, v38, v30                              // 0000001EB350: D613003E 047A4D76
	v_bfe_u32 v66, v58, 16, 1                                  // 0000001EB358: D6100042 0205213A
	v_bfe_u32 v106, v33, 16, 1                                 // 0000001EB360: D610006A 02052121
	v_bfe_u32 v107, v34, 16, 1                                 // 0000001EB368: D610006B 02052122
	v_fma_f32 v64, v120, v40, v32                              // 0000001EB370: D6130040 04825178
	v_dual_mul_f32 v59, 0x3b800000, v59 :: v_dual_mul_f32 v60, 0x3b800000, v60// 0000001EB378: C8C676FF 3B3C78FF 3B800000
	v_mul_f32_e32 v63, 0x3b800000, v63                         // 0000001EB384: 107E7EFF 3B800000
	v_add3_u32 v65, v57, v65, 0x7fff                           // 0000001EB38C: D6550041 03FE8339 00007FFF
	v_add3_u32 v96, v105, v96, 0x7fff                          // 0000001EB398: D6550060 03FEC169 00007FFF
	v_bfe_u32 v105, v35, 16, 1                                 // 0000001EB3A4: D6100069 02052123
	v_fma_f32 v38, v54, v38, v6                                // 0000001EB3AC: D6130026 041A4D36
	v_dual_mul_f32 v36, 0x3b800000, v36 :: v_dual_mul_f32 v61, 0x3b800000, v61// 0000001EB3B4: C8C648FF 243C7AFF 3B800000
	v_mul_f32_e32 v62, 0x3b800000, v62                         // 0000001EB3C0: 107C7CFF 3B800000
	v_add3_u32 v66, v58, v66, 0x7fff                           // 0000001EB3C8: D6550042 03FE853A 00007FFF
	v_add3_u32 v33, v33, v106, 0x7fff                          // 0000001EB3D4: D6550021 03FED521 00007FFF
	v_add3_u32 v34, v34, v107, 0x7fff                          // 0000001EB3E0: D6550022 03FED722 00007FFF
	v_mul_f32_e32 v64, 0x3b800000, v64                         // 0000001EB3EC: 108080FF 3B800000
	v_bfe_u32 v67, v59, 16, 1                                  // 0000001EB3F4: D6100043 0205213B
	v_bfe_u32 v71, v63, 16, 1                                  // 0000001EB3FC: D6100047 0205213F
	s_clause 0x7                                               // 0000001EB404: BF850007
	global_store_d16_hi_b16 v[41:42], v65, off                 // 0000001EB408: DC960000 007C4129
	global_store_d16_hi_b16 v[41:42], v72, off offset:32       // 0000001EB410: DC960020 007C4829
	global_store_d16_hi_b16 v[41:42], v89, off offset:64       // 0000001EB418: DC960040 007C5929
	global_store_d16_hi_b16 v[43:44], v66, off                 // 0000001EB420: DC960000 007C422B
	global_store_d16_hi_b16 v[43:44], v73, off offset:32       // 0000001EB428: DC960020 007C492B
	global_store_d16_hi_b16 v[43:44], v90, off offset:64       // 0000001EB430: DC960040 007C5A2B
	global_store_d16_hi_b16 v[41:42], v33, off offset:96       // 0000001EB438: DC960060 007C2129
	global_store_d16_hi_b16 v[43:44], v34, off offset:96       // 0000001EB440: DC960060 007C222B
	v_add3_u32 v33, v35, v105, 0x7fff                          // 0000001EB448: D6550021 03FED323 00007FFF
	v_mul_f32_e32 v35, 0x3b800000, v37                         // 0000001EB454: 10464AFF 3B800000
	v_mul_f32_e32 v37, 0x3b800000, v38                         // 0000001EB45C: 104A4CFF 3B800000
	v_bfe_u32 v34, v36, 16, 1                                  // 0000001EB464: D6100022 02052124
	v_fma_f32 v38, v55, v39, v7                                // 0000001EB46C: D6130026 041E4F37
	v_fma_f32 v39, v56, v40, v8                                // 0000001EB474: D6130027 04225138
	v_bfe_u32 v69, v61, 16, 1                                  // 0000001EB47C: D6100045 0205213D
	v_bfe_u32 v70, v62, 16, 1                                  // 0000001EB484: D6100046 0205213E
	v_bfe_u32 v68, v60, 16, 1                                  // 0000001EB48C: D6100044 0205213C
	v_add3_u32 v67, v59, v67, 0x7fff                           // 0000001EB494: D6550043 03FE873B 00007FFF
	v_add3_u32 v71, v63, v71, 0x7fff                           // 0000001EB4A0: D6550047 03FE8F3F 00007FFF
	v_bfe_u32 v63, v64, 16, 1                                  // 0000001EB4AC: D610003F 02052140
	v_add3_u32 v34, v36, v34, 0x7fff                           // 0000001EB4B4: D6550022 03FE4524 00007FFF
	v_bfe_u32 v36, v35, 16, 1                                  // 0000001EB4C0: D6100024 02052123
	v_dual_mul_f32 v38, 0x3b800000, v38 :: v_dual_mul_f32 v39, 0x3b800000, v39// 0000001EB4C8: C8C64CFF 26264EFF 3B800000
	v_add3_u32 v69, v61, v69, 0x7fff                           // 0000001EB4D4: D6550045 03FE8B3D 00007FFF
	v_mad_u64_u32 v[57:58], null, 0x3000, v140, v[164:165]     // 0000001EB4E0: D6FE7C39 069318FF 00003000
	v_add3_u32 v70, v62, v70, 0x7fff                           // 0000001EB4EC: D6550046 03FE8D3E 00007FFF
	v_mad_u64_u32 v[61:62], null, 0x3000, v138, v[164:165]     // 0000001EB4F8: D6FE7C3D 069314FF 00003000
	v_add3_u32 v68, v60, v68, 0x7fff                           // 0000001EB504: D6550044 03FE893C 00007FFF
	v_bfe_u32 v40, v37, 16, 1                                  // 0000001EB510: D6100028 02052125
	v_mad_u64_u32 v[59:60], null, 0x3000, v139, v[164:165]     // 0000001EB518: D6FE7C3B 069316FF 00003000
	v_add3_u32 v75, v64, v63, 0x7fff                           // 0000001EB524: D655004B 03FE7F40 00007FFF
	v_mad_u64_u32 v[63:64], null, 0x3000, v137, v[164:165]     // 0000001EB530: D6FE7C3F 069312FF 00003000
	s_clause 0x7                                               // 0000001EB53C: BF850007
	global_store_d16_hi_b16 v[45:46], v67, off                 // 0000001EB540: DC960000 007C432D
	global_store_d16_hi_b16 v[45:46], v74, off offset:32       // 0000001EB548: DC960020 007C4A2D
	global_store_d16_hi_b16 v[45:46], v91, off offset:64       // 0000001EB550: DC960040 007C5B2D
	global_store_d16_hi_b16 v[47:48], v68, off                 // 0000001EB558: DC960000 007C442F
	global_store_d16_hi_b16 v[47:48], v76, off offset:32       // 0000001EB560: DC960020 007C4C2F
	global_store_d16_hi_b16 v[47:48], v92, off offset:64       // 0000001EB568: DC960040 007C5C2F
	global_store_d16_hi_b16 v[45:46], v33, off offset:96       // 0000001EB570: DC960060 007C212D
	global_store_d16_hi_b16 v[47:48], v34, off offset:96       // 0000001EB578: DC960060 007C222F
	v_add3_u32 v33, v35, v36, 0x7fff                           // 0000001EB580: D6550021 03FE4923 00007FFF
	v_bfe_u32 v35, v38, 16, 1                                  // 0000001EB58C: D6100023 02052126
	v_bfe_u32 v36, v39, 16, 1                                  // 0000001EB594: D6100024 02052127
	v_add3_u32 v34, v37, v40, 0x7fff                           // 0000001EB59C: D6550022 03FE5125 00007FFF
	s_clause 0x7                                               // 0000001EB5A8: BF850007
	global_store_d16_hi_b16 v[57:58], v69, off                 // 0000001EB5AC: DC960000 007C4539
	global_store_d16_hi_b16 v[57:58], v77, off offset:32       // 0000001EB5B4: DC960020 007C4D39
	global_store_d16_hi_b16 v[57:58], v93, off offset:64       // 0000001EB5BC: DC960040 007C5D39
	global_store_d16_hi_b16 v[59:60], v70, off                 // 0000001EB5C4: DC960000 007C463B
	global_store_d16_hi_b16 v[59:60], v78, off offset:32       // 0000001EB5CC: DC960020 007C4E3B
	global_store_d16_hi_b16 v[59:60], v94, off offset:64       // 0000001EB5D4: DC960040 007C5E3B
	global_store_d16_hi_b16 v[57:58], v33, off offset:96       // 0000001EB5DC: DC960060 007C2139
	global_store_d16_hi_b16 v[59:60], v34, off offset:96       // 0000001EB5E4: DC960060 007C223B
	v_add3_u32 v33, v38, v35, 0x7fff                           // 0000001EB5EC: D6550021 03FE4726 00007FFF
	v_add3_u32 v34, v39, v36, 0x7fff                           // 0000001EB5F8: D6550022 03FE4927 00007FFF
	s_clause 0x7                                               // 0000001EB604: BF850007
	global_store_d16_hi_b16 v[61:62], v71, off                 // 0000001EB608: DC960000 007C473D
	global_store_d16_hi_b16 v[61:62], v79, off offset:32       // 0000001EB610: DC960020 007C4F3D
	global_store_d16_hi_b16 v[61:62], v95, off offset:64       // 0000001EB618: DC960040 007C5F3D
	global_store_d16_hi_b16 v[63:64], v75, off                 // 0000001EB620: DC960000 007C4B3F
	global_store_d16_hi_b16 v[63:64], v80, off offset:32       // 0000001EB628: DC960020 007C503F
	global_store_d16_hi_b16 v[63:64], v96, off offset:64       // 0000001EB630: DC960040 007C603F
	global_store_d16_hi_b16 v[61:62], v33, off offset:96       // 0000001EB638: DC960060 007C213D
	global_store_d16_hi_b16 v[63:64], v34, off offset:96       // 0000001EB640: DC960060 007C223F
	s_cbranch_execnz 63621                                     // 0000001EB648: BFA6F885 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5660>
	s_and_saveexec_b32 s42, s0                                 // 0000001EB64C: BEAA2000
	s_cbranch_execnz 225                                       // 0000001EB650: BFA600E1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x77d8>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB654: 8C7E2A7E
	s_and_saveexec_b32 s42, s13                                // 0000001EB658: BEAA200D
	s_cbranch_execnz 244                                       // 0000001EB65C: BFA600F4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7830>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB660: 8C7E2A7E
	s_and_saveexec_b32 s42, s12                                // 0000001EB664: BEAA200C
	s_cbranch_execnz 263                                       // 0000001EB668: BFA60107 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7888>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB66C: 8C7E2A7E
	s_and_saveexec_b32 s42, s11                                // 0000001EB670: BEAA200B
	s_cbranch_execnz 282                                       // 0000001EB674: BFA6011A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x78e0>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB678: 8C7E2A7E
	s_and_saveexec_b32 s42, s10                                // 0000001EB67C: BEAA200A
	s_cbranch_execnz 301                                       // 0000001EB680: BFA6012D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7938>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB684: 8C7E2A7E
	s_and_saveexec_b32 s42, s8                                 // 0000001EB688: BEAA2008
	s_cbranch_execnz 320                                       // 0000001EB68C: BFA60140 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7990>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB690: 8C7E2A7E
	s_and_saveexec_b32 s42, s9                                 // 0000001EB694: BEAA2009
	s_cbranch_execnz 339                                       // 0000001EB698: BFA60153 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x79e8>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB69C: 8C7E2A7E
	s_and_saveexec_b32 s42, s1                                 // 0000001EB6A0: BEAA2001
	s_cbranch_execnz 358                                       // 0000001EB6A4: BFA60166 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7a40>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB6A8: 8C7E2A7E
	s_and_saveexec_b32 s42, s0                                 // 0000001EB6AC: BEAA2000
	s_cbranch_execnz 377                                       // 0000001EB6B0: BFA60179 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7a98>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB6B4: 8C7E2A7E
	s_and_saveexec_b32 s42, s13                                // 0000001EB6B8: BEAA200D
	s_cbranch_execnz 396                                       // 0000001EB6BC: BFA6018C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7af0>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB6C0: 8C7E2A7E
	s_and_saveexec_b32 s42, s12                                // 0000001EB6C4: BEAA200C
	s_cbranch_execnz 415                                       // 0000001EB6C8: BFA6019F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7b48>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB6CC: 8C7E2A7E
	s_and_saveexec_b32 s42, s11                                // 0000001EB6D0: BEAA200B
	s_cbranch_execnz 434                                       // 0000001EB6D4: BFA601B2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7ba0>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB6D8: 8C7E2A7E
	s_and_saveexec_b32 s42, s10                                // 0000001EB6DC: BEAA200A
	s_cbranch_execnz 453                                       // 0000001EB6E0: BFA601C5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7bf8>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB6E4: 8C7E2A7E
	s_and_saveexec_b32 s42, s8                                 // 0000001EB6E8: BEAA2008
	s_cbranch_execnz 472                                       // 0000001EB6EC: BFA601D8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7c50>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB6F0: 8C7E2A7E
	s_and_saveexec_b32 s42, s9                                 // 0000001EB6F4: BEAA2009
	s_cbranch_execnz 491                                       // 0000001EB6F8: BFA601EB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7ca8>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB6FC: 8C7E2A7E
	s_and_saveexec_b32 s42, s1                                 // 0000001EB700: BEAA2001
	s_cbranch_execnz 510                                       // 0000001EB704: BFA601FE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7d00>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB708: 8C7E2A7E
	s_and_saveexec_b32 s42, s0                                 // 0000001EB70C: BEAA2000
	s_cbranch_execnz 529                                       // 0000001EB710: BFA60211 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7d58>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB714: 8C7E2A7E
	s_and_saveexec_b32 s42, s13                                // 0000001EB718: BEAA200D
	s_cbranch_execnz 548                                       // 0000001EB71C: BFA60224 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7db0>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB720: 8C7E2A7E
	s_and_saveexec_b32 s42, s12                                // 0000001EB724: BEAA200C
	s_cbranch_execnz 567                                       // 0000001EB728: BFA60237 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7e08>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB72C: 8C7E2A7E
	s_and_saveexec_b32 s42, s11                                // 0000001EB730: BEAA200B
	s_cbranch_execnz 586                                       // 0000001EB734: BFA6024A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7e60>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB738: 8C7E2A7E
	s_and_saveexec_b32 s42, s10                                // 0000001EB73C: BEAA200A
	s_cbranch_execnz 605                                       // 0000001EB740: BFA6025D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7eb8>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB744: 8C7E2A7E
	s_and_saveexec_b32 s42, s8                                 // 0000001EB748: BEAA2008
	s_cbranch_execnz 624                                       // 0000001EB74C: BFA60270 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7f10>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB750: 8C7E2A7E
	s_and_saveexec_b32 s42, s9                                 // 0000001EB754: BEAA2009
	s_cbranch_execnz 643                                       // 0000001EB758: BFA60283 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7f68>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB75C: 8C7E2A7E
	s_and_saveexec_b32 s42, s1                                 // 0000001EB760: BEAA2001
	s_cbranch_execnz 662                                       // 0000001EB764: BFA60296 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7fc0>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB768: 8C7E2A7E
	s_and_saveexec_b32 s42, s0                                 // 0000001EB76C: BEAA2000
	s_cbranch_execnz 681                                       // 0000001EB770: BFA602A9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8018>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EB774: 8C7E2A7E
	s_and_saveexec_b32 s0, s13                                 // 0000001EB778: BE80200D
	s_cbranch_execnz 700                                       // 0000001EB77C: BFA602BC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8070>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001EB780: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001EB784: BE80200C
	s_cbranch_execnz 719                                       // 0000001EB788: BFA602CF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x80c8>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001EB78C: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001EB790: BE80200B
	s_cbranch_execnz 738                                       // 0000001EB794: BFA602E2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8120>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001EB798: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001EB79C: BE80200A
	s_cbranch_execnz 757                                       // 0000001EB7A0: BFA602F5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8178>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001EB7A4: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001EB7A8: BE802008
	s_cbranch_execnz 776                                       // 0000001EB7AC: BFA60308 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x81d0>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001EB7B0: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001EB7B4: BE802009
	s_cbranch_execnz 795                                       // 0000001EB7B8: BFA6031B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8228>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001EB7BC: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001EB7C0: BE802001
	s_cbranch_execz 18                                         // 0000001EB7C4: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7610>
	ds_load_b32 v1, v232 offset:56                             // 0000001EB7C8: D8D80038 010000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EB7D0: BF89FC07
	v_fmac_f32_e32 v8, v56, v1                                 // 0000001EB7D4: 56100338
	v_mad_u64_u32 v[1:2], null, 0x3000, v137, v[164:165]       // 0000001EB7D8: D6FE7C01 069312FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001EB7E4: BF870092
	v_mul_f32_e32 v3, 0x3b800000, v8                           // 0000001EB7E8: 100610FF 3B800000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001EB7F0: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EB7F8: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001EB7FC: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001EB808: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001EB810: 8C7E007E
	s_add_i32 s1, s40, 1                                       // 0000001EB814: 81018128
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001EB818: BF870009
	s_cmp_ge_i32 s1, s48                                       // 0000001EB81C: BF033001
	s_cbranch_scc0 63507                                       // 0000001EB820: BFA1F813 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5670>
	s_branch 64303                                             // 0000001EB824: BFA0FB2F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x62e4>
	s_clause 0x1                                               // 0000001EB828: BF850001
	scratch_load_b64 v[1:2], off, off offset:96                // 0000001EB82C: DC550060 017C0000
	scratch_load_b32 v4, off, off                              // 0000001EB834: DC510000 047C0000
	v_mov_b32_e32 v3, v178                                     // 0000001EB83C: 7E0603B2
	s_mov_b32 s8, 0                                            // 0000001EB840: BE880080
	s_nop 0                                                    // 0000001EB844: BF800000
	s_nop 0                                                    // 0000001EB848: BF800000
	s_nop 0                                                    // 0000001EB84C: BF800000
	s_nop 0                                                    // 0000001EB850: BF800000
	s_nop 0                                                    // 0000001EB854: BF800000
	s_nop 0                                                    // 0000001EB858: BF800000
	s_nop 0                                                    // 0000001EB85C: BF800000
	s_nop 0                                                    // 0000001EB860: BF800000
	s_nop 0                                                    // 0000001EB864: BF800000
	s_nop 0                                                    // 0000001EB868: BF800000
	s_nop 0                                                    // 0000001EB86C: BF800000
	s_nop 0                                                    // 0000001EB870: BF800000
	s_nop 0                                                    // 0000001EB874: BF800000
	s_nop 0                                                    // 0000001EB878: BF800000
	s_nop 0                                                    // 0000001EB87C: BF800000
	ds_load_b32 v5, v3                                         // 0000001EB880: D8D80000 05000003
	s_waitcnt vmcnt(0)                                         // 0000001EB888: BF8903F7
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001EB88C: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001EB894: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001EB898: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001EB89C: 7C9208FF 00001F7F
	s_or_b32 s8, vcc_lo, s8                                    // 0000001EB8A4: 8C08086A
	s_waitcnt lgkmcnt(0)                                       // 0000001EB8A8: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001EB8AC: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001EB8B4: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001EB8B8: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001EB8C0: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000001EB8C8: 917E087E
	s_cbranch_execnz 65516                                     // 0000001EB8CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7680>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001EB8D0: 8C7E087E
	s_cmp_lg_u32 s40, s37                                      // 0000001EB8D4: BF072528
	s_cbranch_scc1 64915                                       // 0000001EB8D8: BFA2FD93 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6d28>
	s_clause 0x1                                               // 0000001EB8DC: BF850001
	scratch_load_b64 v[1:2], off, off offset:104               // 0000001EB8E0: DC550068 017C0000
	scratch_load_b32 v4, off, off                              // 0000001EB8E8: DC510000 047C0000
	v_mov_b32_e32 v3, v178                                     // 0000001EB8F0: 7E0603B2
	s_mov_b32 s8, 0                                            // 0000001EB8F4: BE880080
	s_nop 0                                                    // 0000001EB8F8: BF800000
	s_nop 0                                                    // 0000001EB8FC: BF800000
	ds_load_b32 v5, v3                                         // 0000001EB900: D8D80000 05000003
	s_waitcnt vmcnt(0)                                         // 0000001EB908: BF8903F7
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001EB90C: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001EB914: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001EB918: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001EB91C: 7C9208FF 00001F7F
	s_or_b32 s8, vcc_lo, s8                                    // 0000001EB924: 8C08086A
	s_waitcnt lgkmcnt(0)                                       // 0000001EB928: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001EB92C: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001EB934: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001EB938: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001EB940: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000001EB948: 917E087E
	s_cbranch_execnz 65516                                     // 0000001EB94C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7700>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001EB950: 8C7E087E
	s_cmp_lg_u32 s40, s38                                      // 0000001EB954: BF072628
	s_cbranch_scc1 58968                                       // 0000001EB958: BFA2E658 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x10bc>
	s_clause 0x1                                               // 0000001EB95C: BF850001
	scratch_load_b64 v[1:2], off, off offset:112               // 0000001EB960: DC550070 017C0000
	scratch_load_b32 v4, off, off                              // 0000001EB968: DC510000 047C0000
	v_mov_b32_e32 v3, v178                                     // 0000001EB970: 7E0603B2
	s_mov_b32 s8, 0                                            // 0000001EB974: BE880080
	s_nop 0                                                    // 0000001EB978: BF800000
	s_nop 0                                                    // 0000001EB97C: BF800000
	ds_load_b32 v5, v3                                         // 0000001EB980: D8D80000 05000003
	s_waitcnt vmcnt(0)                                         // 0000001EB988: BF8903F7
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001EB98C: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001EB994: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001EB998: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001EB99C: 7C9208FF 00001F7F
	s_or_b32 s8, vcc_lo, s8                                    // 0000001EB9A4: 8C08086A
	s_waitcnt lgkmcnt(0)                                       // 0000001EB9A8: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001EB9AC: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001EB9B4: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001EB9B8: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001EB9C0: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s8                        // 0000001EB9C8: 917E087E
	s_cbranch_execnz 65516                                     // 0000001EB9CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7780>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001EB9D0: 8C7E087E
	s_branch 58937                                             // 0000001EB9D4: BFA0E639 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x10bc>
	ds_load_b32 v33, v232                                      // 0000001EB9D8: D8D80000 210000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EB9E0: BF89FC07
	v_fma_f32 v25, v113, v33, v25                              // 0000001EB9E4: D6130019 04664371
	v_mad_u64_u32 v[33:34], null, 0x3000, v145, v[164:165]     // 0000001EB9EC: D6FE7C21 069322FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001EB9F8: BF870092
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 0000001EB9FC: 103232FF 3B800000
	v_bfe_u32 v35, v25, 16, 1                                  // 0000001EBA04: D6100023 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBA0C: BF870001
	v_add3_u32 v25, v25, v35, 0x7fff                           // 0000001EBA10: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off                 // 0000001EBA1C: DC960000 007C1921
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBA24: 8C7E2A7E
	s_and_saveexec_b32 s42, s13                                // 0000001EBA28: BEAA200D
	s_cbranch_execz 65292                                      // 0000001EBA2C: BFA5FF0C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7460>
	ds_load_b32 v25, v232 offset:8                             // 0000001EBA30: D8D80008 190000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBA38: BF89FC07
	v_fma_f32 v25, v114, v25, v26                              // 0000001EBA3C: D6130019 046A3372
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBA44: BF870121
	v_mul_f32_e32 v33, 0x3b800000, v25                         // 0000001EBA48: 104232FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v148, v[164:165]     // 0000001EBA50: D6FE7C19 069328FF 00003000
	v_bfe_u32 v34, v33, 16, 1                                  // 0000001EBA5C: D6100022 02052121
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBA64: BF870001
	v_add3_u32 v33, v33, v34, 0x7fff                           // 0000001EBA68: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off                 // 0000001EBA74: DC960000 007C2119
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBA7C: 8C7E2A7E
	s_and_saveexec_b32 s42, s12                                // 0000001EBA80: BEAA200C
	s_cbranch_execz 65273                                      // 0000001EBA84: BFA5FEF9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x746c>
	ds_load_b32 v25, v232 offset:16                            // 0000001EBA88: D8D80010 190000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBA90: BF89FC07
	v_fma_f32 v25, v115, v25, v27                              // 0000001EBA94: D6130019 046E3373
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBA9C: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001EBAA0: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v147, v[164:165]     // 0000001EBAA8: D6FE7C19 069326FF 00003000
	v_bfe_u32 v33, v27, 16, 1                                  // 0000001EBAB4: D6100021 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBABC: BF870001
	v_add3_u32 v27, v27, v33, 0x7fff                           // 0000001EBAC0: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001EBACC: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBAD4: 8C7E2A7E
	s_and_saveexec_b32 s42, s11                                // 0000001EBAD8: BEAA200B
	s_cbranch_execz 65254                                      // 0000001EBADC: BFA5FEE6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7478>
	ds_load_b32 v25, v232 offset:24                            // 0000001EBAE0: D8D80018 190000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBAE8: BF89FC07
	v_fma_f32 v25, v116, v25, v28                              // 0000001EBAEC: D6130019 04723374
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBAF4: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001EBAF8: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v146, v[164:165]     // 0000001EBB00: D6FE7C19 069324FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001EBB0C: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBB14: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001EBB18: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001EBB24: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBB2C: 8C7E2A7E
	s_and_saveexec_b32 s42, s10                                // 0000001EBB30: BEAA200A
	s_cbranch_execz 65235                                      // 0000001EBB34: BFA5FED3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7484>
	ds_load_b32 v25, v232 offset:32                            // 0000001EBB38: D8D80020 190000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBB40: BF89FC07
	v_fma_f32 v25, v117, v25, v29                              // 0000001EBB44: D6130019 04763375
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBB4C: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001EBB50: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v140, v[164:165]     // 0000001EBB58: D6FE7C19 069318FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001EBB64: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBB6C: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001EBB70: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001EBB7C: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBB84: 8C7E2A7E
	s_and_saveexec_b32 s42, s8                                 // 0000001EBB88: BEAA2008
	s_cbranch_execz 65216                                      // 0000001EBB8C: BFA5FEC0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7490>
	ds_load_b32 v25, v232 offset:40                            // 0000001EBB90: D8D80028 190000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBB98: BF89FC07
	v_fma_f32 v25, v118, v25, v30                              // 0000001EBB9C: D6130019 047A3376
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBBA4: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001EBBA8: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v139, v[164:165]     // 0000001EBBB0: D6FE7C19 069316FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001EBBBC: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBBC4: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001EBBC8: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001EBBD4: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBBDC: 8C7E2A7E
	s_and_saveexec_b32 s42, s9                                 // 0000001EBBE0: BEAA2009
	s_cbranch_execz 65197                                      // 0000001EBBE4: BFA5FEAD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x749c>
	ds_load_b32 v25, v232 offset:48                            // 0000001EBBE8: D8D80030 190000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBBF0: BF89FC07
	v_fma_f32 v25, v119, v25, v31                              // 0000001EBBF4: D6130019 047E3377
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBBFC: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001EBC00: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v138, v[164:165]     // 0000001EBC08: D6FE7C19 069314FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001EBC14: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBC1C: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001EBC20: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001EBC2C: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBC34: 8C7E2A7E
	s_and_saveexec_b32 s42, s1                                 // 0000001EBC38: BEAA2001
	s_cbranch_execz 65178                                      // 0000001EBC3C: BFA5FE9A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x74a8>
	ds_load_b32 v25, v232 offset:56                            // 0000001EBC40: D8D80038 190000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBC48: BF89FC07
	v_fma_f32 v25, v120, v25, v32                              // 0000001EBC4C: D6130019 04823378
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBC54: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001EBC58: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v137, v[164:165]     // 0000001EBC60: D6FE7C19 069312FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001EBC6C: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBC74: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001EBC78: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001EBC84: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBC8C: 8C7E2A7E
	s_and_saveexec_b32 s42, s0                                 // 0000001EBC90: BEAA2000
	s_cbranch_execz 65159                                      // 0000001EBC94: BFA5FE87 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x74b4>
	ds_load_b32 v25, v232                                      // 0000001EBC98: D8D80000 190000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBCA0: BF89FC07
	v_fma_f32 v17, v97, v25, v17                               // 0000001EBCA4: D6130011 04463361
	v_mad_u64_u32 v[25:26], null, 0x3000, v145, v[164:165]     // 0000001EBCAC: D6FE7C19 069322FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001EBCB8: BF870092
	v_mul_f32_e32 v17, 0x3b800000, v17                         // 0000001EBCBC: 102222FF 3B800000
	v_bfe_u32 v27, v17, 16, 1                                  // 0000001EBCC4: D610001B 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBCCC: BF870001
	v_add3_u32 v17, v17, v27, 0x7fff                           // 0000001EBCD0: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:32       // 0000001EBCDC: DC960020 007C1119
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBCE4: 8C7E2A7E
	s_and_saveexec_b32 s42, s13                                // 0000001EBCE8: BEAA200D
	s_cbranch_execz 65140                                      // 0000001EBCEC: BFA5FE74 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x74c0>
	ds_load_b32 v17, v232 offset:8                             // 0000001EBCF0: D8D80008 110000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBCF8: BF89FC07
	v_fma_f32 v17, v98, v17, v18                               // 0000001EBCFC: D6130011 044A2362
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBD04: BF870121
	v_mul_f32_e32 v25, 0x3b800000, v17                         // 0000001EBD08: 103222FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v148, v[164:165]     // 0000001EBD10: D6FE7C11 069328FF 00003000
	v_bfe_u32 v26, v25, 16, 1                                  // 0000001EBD1C: D610001A 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBD24: BF870001
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000001EBD28: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:32       // 0000001EBD34: DC960020 007C1911
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBD3C: 8C7E2A7E
	s_and_saveexec_b32 s42, s12                                // 0000001EBD40: BEAA200C
	s_cbranch_execz 65121                                      // 0000001EBD44: BFA5FE61 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x74cc>
	ds_load_b32 v17, v232 offset:16                            // 0000001EBD48: D8D80010 110000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBD50: BF89FC07
	v_fma_f32 v17, v99, v17, v19                               // 0000001EBD54: D6130011 044E2363
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBD5C: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 0000001EBD60: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v147, v[164:165]     // 0000001EBD68: D6FE7C11 069326FF 00003000
	v_bfe_u32 v25, v19, 16, 1                                  // 0000001EBD74: D6100019 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBD7C: BF870001
	v_add3_u32 v19, v19, v25, 0x7fff                           // 0000001EBD80: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:32       // 0000001EBD8C: DC960020 007C1311
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBD94: 8C7E2A7E
	s_and_saveexec_b32 s42, s11                                // 0000001EBD98: BEAA200B
	s_cbranch_execz 65102                                      // 0000001EBD9C: BFA5FE4E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x74d8>
	ds_load_b32 v17, v232 offset:24                            // 0000001EBDA0: D8D80018 110000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBDA8: BF89FC07
	v_fma_f32 v17, v100, v17, v20                              // 0000001EBDAC: D6130011 04522364
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBDB4: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 0000001EBDB8: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v146, v[164:165]     // 0000001EBDC0: D6FE7C11 069324FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 0000001EBDCC: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBDD4: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000001EBDD8: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:32       // 0000001EBDE4: DC960020 007C1311
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBDEC: 8C7E2A7E
	s_and_saveexec_b32 s42, s10                                // 0000001EBDF0: BEAA200A
	s_cbranch_execz 65083                                      // 0000001EBDF4: BFA5FE3B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x74e4>
	ds_load_b32 v17, v232 offset:32                            // 0000001EBDF8: D8D80020 110000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBE00: BF89FC07
	v_fma_f32 v17, v101, v17, v21                              // 0000001EBE04: D6130011 04562365
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBE0C: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 0000001EBE10: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v140, v[164:165]     // 0000001EBE18: D6FE7C11 069318FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 0000001EBE24: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBE2C: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000001EBE30: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:32       // 0000001EBE3C: DC960020 007C1311
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBE44: 8C7E2A7E
	s_and_saveexec_b32 s42, s8                                 // 0000001EBE48: BEAA2008
	s_cbranch_execz 65064                                      // 0000001EBE4C: BFA5FE28 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x74f0>
	ds_load_b32 v17, v232 offset:40                            // 0000001EBE50: D8D80028 110000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBE58: BF89FC07
	v_fma_f32 v17, v102, v17, v22                              // 0000001EBE5C: D6130011 045A2366
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBE64: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 0000001EBE68: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v139, v[164:165]     // 0000001EBE70: D6FE7C11 069316FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 0000001EBE7C: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBE84: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000001EBE88: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:32       // 0000001EBE94: DC960020 007C1311
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBE9C: 8C7E2A7E
	s_and_saveexec_b32 s42, s9                                 // 0000001EBEA0: BEAA2009
	s_cbranch_execz 65045                                      // 0000001EBEA4: BFA5FE15 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x74fc>
	ds_load_b32 v17, v232 offset:48                            // 0000001EBEA8: D8D80030 110000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBEB0: BF89FC07
	v_fma_f32 v17, v103, v17, v23                              // 0000001EBEB4: D6130011 045E2367
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBEBC: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 0000001EBEC0: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v138, v[164:165]     // 0000001EBEC8: D6FE7C11 069314FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 0000001EBED4: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBEDC: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000001EBEE0: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:32       // 0000001EBEEC: DC960020 007C1311
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBEF4: 8C7E2A7E
	s_and_saveexec_b32 s42, s1                                 // 0000001EBEF8: BEAA2001
	s_cbranch_execz 65026                                      // 0000001EBEFC: BFA5FE02 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7508>
	ds_load_b32 v17, v232 offset:56                            // 0000001EBF00: D8D80038 110000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBF08: BF89FC07
	v_fma_f32 v17, v104, v17, v24                              // 0000001EBF0C: D6130011 04622368
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBF14: BF870121
	v_mul_f32_e32 v19, 0x3b800000, v17                         // 0000001EBF18: 102622FF 3B800000
	v_mad_u64_u32 v[17:18], null, 0x3000, v137, v[164:165]     // 0000001EBF20: D6FE7C11 069312FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 0000001EBF2C: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBF34: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000001EBF38: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:32       // 0000001EBF44: DC960020 007C1311
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBF4C: 8C7E2A7E
	s_and_saveexec_b32 s42, s0                                 // 0000001EBF50: BEAA2000
	s_cbranch_execz 65007                                      // 0000001EBF54: BFA5FDEF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7514>
	ds_load_b32 v17, v232                                      // 0000001EBF58: D8D80000 110000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBF60: BF89FC07
	v_fma_f32 v9, v81, v17, v9                                 // 0000001EBF64: D6130009 04262351
	v_mad_u64_u32 v[17:18], null, 0x3000, v145, v[164:165]     // 0000001EBF6C: D6FE7C11 069322FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001EBF78: BF870092
	v_mul_f32_e32 v9, 0x3b800000, v9                           // 0000001EBF7C: 101212FF 3B800000
	v_bfe_u32 v19, v9, 16, 1                                   // 0000001EBF84: D6100013 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBF8C: BF870001
	v_add3_u32 v9, v9, v19, 0x7fff                             // 0000001EBF90: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:64        // 0000001EBF9C: DC960040 007C0911
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBFA4: 8C7E2A7E
	s_and_saveexec_b32 s42, s13                                // 0000001EBFA8: BEAA200D
	s_cbranch_execz 64988                                      // 0000001EBFAC: BFA5FDDC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7520>
	ds_load_b32 v9, v232 offset:8                              // 0000001EBFB0: D8D80008 090000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EBFB8: BF89FC07
	v_fma_f32 v9, v82, v9, v10                                 // 0000001EBFBC: D6130009 042A1352
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EBFC4: BF870121
	v_mul_f32_e32 v17, 0x3b800000, v9                          // 0000001EBFC8: 102212FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v148, v[164:165]      // 0000001EBFD0: D6FE7C09 069328FF 00003000
	v_bfe_u32 v18, v17, 16, 1                                  // 0000001EBFDC: D6100012 02052111
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EBFE4: BF870001
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000001EBFE8: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:64        // 0000001EBFF4: DC960040 007C1109
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EBFFC: 8C7E2A7E
	s_and_saveexec_b32 s42, s12                                // 0000001EC000: BEAA200C
	s_cbranch_execz 64969                                      // 0000001EC004: BFA5FDC9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x752c>
	ds_load_b32 v9, v232 offset:16                             // 0000001EC008: D8D80010 090000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EC010: BF89FC07
	v_fma_f32 v9, v83, v9, v11                                 // 0000001EC014: D6130009 042E1353
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EC01C: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001EC020: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v147, v[164:165]      // 0000001EC028: D6FE7C09 069326FF 00003000
	v_bfe_u32 v17, v11, 16, 1                                  // 0000001EC034: D6100011 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EC03C: BF870001
	v_add3_u32 v11, v11, v17, 0x7fff                           // 0000001EC040: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001EC04C: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EC054: 8C7E2A7E
	s_and_saveexec_b32 s42, s11                                // 0000001EC058: BEAA200B
	s_cbranch_execz 64950                                      // 0000001EC05C: BFA5FDB6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7538>
	ds_load_b32 v9, v232 offset:24                             // 0000001EC060: D8D80018 090000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EC068: BF89FC07
	v_fma_f32 v9, v84, v9, v12                                 // 0000001EC06C: D6130009 04321354
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EC074: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001EC078: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v146, v[164:165]      // 0000001EC080: D6FE7C09 069324FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001EC08C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EC094: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001EC098: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001EC0A4: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EC0AC: 8C7E2A7E
	s_and_saveexec_b32 s42, s10                                // 0000001EC0B0: BEAA200A
	s_cbranch_execz 64931                                      // 0000001EC0B4: BFA5FDA3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7544>
	ds_load_b32 v9, v232 offset:32                             // 0000001EC0B8: D8D80020 090000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EC0C0: BF89FC07
	v_fma_f32 v9, v85, v9, v13                                 // 0000001EC0C4: D6130009 04361355
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EC0CC: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001EC0D0: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v140, v[164:165]      // 0000001EC0D8: D6FE7C09 069318FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001EC0E4: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EC0EC: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001EC0F0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001EC0FC: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EC104: 8C7E2A7E
	s_and_saveexec_b32 s42, s8                                 // 0000001EC108: BEAA2008
	s_cbranch_execz 64912                                      // 0000001EC10C: BFA5FD90 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7550>
	ds_load_b32 v9, v232 offset:40                             // 0000001EC110: D8D80028 090000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EC118: BF89FC07
	v_fma_f32 v9, v86, v9, v14                                 // 0000001EC11C: D6130009 043A1356
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EC124: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001EC128: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v139, v[164:165]      // 0000001EC130: D6FE7C09 069316FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001EC13C: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EC144: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001EC148: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001EC154: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EC15C: 8C7E2A7E
	s_and_saveexec_b32 s42, s9                                 // 0000001EC160: BEAA2009
	s_cbranch_execz 64893                                      // 0000001EC164: BFA5FD7D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x755c>
	ds_load_b32 v9, v232 offset:48                             // 0000001EC168: D8D80030 090000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EC170: BF89FC07
	v_fma_f32 v9, v87, v9, v15                                 // 0000001EC174: D6130009 043E1357
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EC17C: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001EC180: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v138, v[164:165]      // 0000001EC188: D6FE7C09 069314FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001EC194: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EC19C: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001EC1A0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001EC1AC: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EC1B4: 8C7E2A7E
	s_and_saveexec_b32 s42, s1                                 // 0000001EC1B8: BEAA2001
	s_cbranch_execz 64874                                      // 0000001EC1BC: BFA5FD6A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7568>
	ds_load_b32 v9, v232 offset:56                             // 0000001EC1C0: D8D80038 090000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EC1C8: BF89FC07
	v_fma_f32 v9, v88, v9, v16                                 // 0000001EC1CC: D6130009 04421358
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EC1D4: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001EC1D8: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v137, v[164:165]      // 0000001EC1E0: D6FE7C09 069312FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001EC1EC: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EC1F4: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001EC1F8: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001EC204: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EC20C: 8C7E2A7E
	s_and_saveexec_b32 s42, s0                                 // 0000001EC210: BEAA2000
	s_cbranch_execz 64855                                      // 0000001EC214: BFA5FD57 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7574>
	ds_load_b32 v9, v232                                       // 0000001EC218: D8D80000 090000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EC220: BF89FC07
	v_fma_f32 v1, v49, v9, v1                                  // 0000001EC224: D6130001 04061331
	v_mad_u64_u32 v[9:10], null, 0x3000, v145, v[164:165]      // 0000001EC22C: D6FE7C09 069322FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001EC238: BF870092
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 0000001EC23C: 100202FF 3B800000
	v_bfe_u32 v11, v1, 16, 1                                   // 0000001EC244: D610000B 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EC24C: BF870001
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001EC250: D6550001 03FE1701 00007FFF
	global_store_d16_hi_b16 v[9:10], v1, off offset:96         // 0000001EC25C: DC960060 007C0109
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001EC264: 8C7E2A7E
	s_and_saveexec_b32 s0, s13                                 // 0000001EC268: BE80200D
	s_cbranch_execz 64836                                      // 0000001EC26C: BFA5FD44 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7580>
	ds_load_b32 v1, v232 offset:8                              // 0000001EC270: D8D80008 010000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EC278: BF89FC07
	v_fma_f32 v1, v50, v1, v2                                  // 0000001EC27C: D6130001 040A0332
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EC284: BF870121
	v_mul_f32_e32 v9, 0x3b800000, v1                           // 0000001EC288: 101202FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v148, v[164:165]       // 0000001EC290: D6FE7C01 069328FF 00003000
	v_bfe_u32 v10, v9, 16, 1                                   // 0000001EC29C: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EC2A4: BF870001
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000001EC2A8: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[1:2], v9, off offset:96          // 0000001EC2B4: DC960060 007C0901
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001EC2BC: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001EC2C0: BE80200C
	s_cbranch_execz 64817                                      // 0000001EC2C4: BFA5FD31 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x758c>
	ds_load_b32 v1, v232 offset:16                             // 0000001EC2C8: D8D80010 010000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EC2D0: BF89FC07
	v_fma_f32 v1, v51, v1, v3                                  // 0000001EC2D4: D6130001 040E0333
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EC2DC: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001EC2E0: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v147, v[164:165]       // 0000001EC2E8: D6FE7C01 069326FF 00003000
	v_bfe_u32 v9, v3, 16, 1                                    // 0000001EC2F4: D6100009 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EC2FC: BF870001
	v_add3_u32 v3, v3, v9, 0x7fff                              // 0000001EC300: D6550003 03FE1303 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001EC30C: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001EC314: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001EC318: BE80200B
	s_cbranch_execz 64798                                      // 0000001EC31C: BFA5FD1E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7598>
	ds_load_b32 v1, v232 offset:24                             // 0000001EC320: D8D80018 010000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EC328: BF89FC07
	v_fma_f32 v1, v52, v1, v4                                  // 0000001EC32C: D6130001 04120334
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EC334: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001EC338: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v146, v[164:165]       // 0000001EC340: D6FE7C01 069324FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001EC34C: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EC354: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001EC358: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001EC364: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001EC36C: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001EC370: BE80200A
	s_cbranch_execz 64779                                      // 0000001EC374: BFA5FD0B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x75a4>
	ds_load_b32 v1, v232 offset:32                             // 0000001EC378: D8D80020 010000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EC380: BF89FC07
	v_fma_f32 v1, v53, v1, v5                                  // 0000001EC384: D6130001 04160335
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EC38C: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001EC390: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v140, v[164:165]       // 0000001EC398: D6FE7C01 069318FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001EC3A4: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EC3AC: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001EC3B0: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001EC3BC: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001EC3C4: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001EC3C8: BE802008
	s_cbranch_execz 64760                                      // 0000001EC3CC: BFA5FCF8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x75b0>
	ds_load_b32 v1, v232 offset:40                             // 0000001EC3D0: D8D80028 010000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EC3D8: BF89FC07
	v_fma_f32 v1, v54, v1, v6                                  // 0000001EC3DC: D6130001 041A0336
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EC3E4: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001EC3E8: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v139, v[164:165]       // 0000001EC3F0: D6FE7C01 069316FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001EC3FC: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EC404: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001EC408: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001EC414: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001EC41C: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001EC420: BE802009
	s_cbranch_execz 64741                                      // 0000001EC424: BFA5FCE5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x75bc>
	ds_load_b32 v1, v232 offset:48                             // 0000001EC428: D8D80030 010000E8
	s_waitcnt lgkmcnt(0)                                       // 0000001EC430: BF89FC07
	v_fma_f32 v1, v55, v1, v7                                  // 0000001EC434: D6130001 041E0337
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EC43C: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001EC440: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v138, v[164:165]       // 0000001EC448: D6FE7C01 069314FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001EC454: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001EC45C: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001EC460: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001EC46C: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001EC474: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001EC478: BE802001
	s_cbranch_execnz 64722                                     // 0000001EC47C: BFA6FCD2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x75c8>
	s_branch 64739                                             // 0000001EC480: BFA0FCE3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7610>
	s_clause 0x2                                               // 0000001EC484: BF850002
	scratch_load_b32 v6, off, off                              // 0000001EC488: DC510000 067C0000
	scratch_load_b32 v18, off, off offset:120                  // 0000001EC490: DC510078 127C0000
	scratch_load_b32 v7, off, off offset:124                   // 0000001EC498: DC51007C 077C0000
	v_dual_mov_b32 v1, s44 :: v_dual_mov_b32 v2, s45           // 0000001EC4A0: CA10002C 0102002D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001EC4A8: BF870091
	.long 0xd7006a00                                           // 0000001EC4AC: D7006A00
	v_cndmask_b32_e32 v0, v1, v18, vcc_lo                      // 0000001EC4B0: 02002501
	v_add_co_ci_u32_e64 v1, null, s19, v2, vcc_lo              // 0000001EC4B4: D5207C01 01AA0413
	s_add_u32 s0, s46, s34                                     // 0000001EC4BC: 8000222E
	s_addc_u32 s1, s33, s35                                    // 0000001EC4C0: 82012321
	.long 0xd7006a00                                           // 0000001EC4C4: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000001EC4C8: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001EC4CC: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000001EC4D0: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000001EC4D8: BE810080
	.long 0xd7006a00                                           // 0000001EC4DC: D7006A00
	v_cndmask_b32_e32 v1, v0, v162, vcc_lo                     // 0000001EC4E0: 02034500
	v_add_co_ci_u32_e64 v1, null, v1, v163, vcc_lo             // 0000001EC4E4: D5207C01 01AB4701
	s_waitcnt vmcnt(1)                                         // 0000001EC4EC: BF8907F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001EC4F0: BF870122
	.long 0xd7006a00                                           // 0000001EC4F4: D7006A00
	v_cndmask_b32_e32 v1, v0, v18, vcc_lo                      // 0000001EC4F8: 02022500
	s_waitcnt vmcnt(0)                                         // 0000001EC4FC: BF8903F7
	v_add_co_ci_u32_e64 v1, null, v1, v7, vcc_lo               // 0000001EC500: D5207C01 01AA0F01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001EC508: BF870092
	.long 0xd7006a00                                           // 0000001EC50C: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000001EC510: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000001EC514: D5207C01 01AA0211
	s_nop 0                                                    // 0000001EC51C: BF800000
	s_nop 0                                                    // 0000001EC520: BF800000
	s_nop 0                                                    // 0000001EC524: BF800000
	s_nop 0                                                    // 0000001EC528: BF800000
	s_nop 0                                                    // 0000001EC52C: BF800000
	s_nop 0                                                    // 0000001EC530: BF800000
	s_nop 0                                                    // 0000001EC534: BF800000
	s_nop 0                                                    // 0000001EC538: BF800000
	s_nop 0                                                    // 0000001EC53C: BF800000
	ds_load_b32 v2, v178                                       // 0000001EC540: D8D80000 020000B2
	v_add_nc_u32_e32 v6, 0x80, v6                              // 0000001EC548: 4A0C0CFF 00000080
	v_add_nc_u32_e32 v178, 8, v178                             // 0000001EC550: 4B656488
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001EC554: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v6                        // 0000001EC558: 7C920CFF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001EC560: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001EC564: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000001EC568: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000001EC570: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 0000001EC574: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000001EC57C: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001EC584: 917E017E
	s_cbranch_execnz 65517                                     // 0000001EC588: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb1ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8340>
	s_nop 0                                                    // 0000001EC58C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001EC590: BFB60003
	s_endpgm                                                   // 0000001EC594: BFB00000
		...

