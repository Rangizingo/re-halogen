0000000000217f00 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_():
	.long 0xd44a0007                                           // 000000217F00: D44A0007
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000217F04: 02020080
	s_mov_b32 s4, s3                                           // 000000217F08: BE840003
	s_and_saveexec_b32 s3, s7                                  // 000000217F0C: BE832007
	v_mov_b32_e32 v1, 0                                        // 000000217F10: 7E020280
	ds_store_b32 v1, v1 offset:512                             // 000000217F14: D8340200 00000101
	s_or_b32 exec_lo, exec_lo, s3                              // 000000217F1C: 8C7E037E
	s_clause 0x3                                               // 000000217F20: BF850003
	s_load_b64 s[24:25], s[0:1], 0x30                          // 000000217F24: F4040600 F8000030
	s_load_b64 s[16:17], s[0:1], 0x20                          // 000000217F2C: F4040400 F8000020
	s_load_b32 s20, s[0:1], 0x28                               // 000000217F34: F4000500 F8000028
	s_load_b256 s[8:15], s[0:1], null                          // 000000217F3C: F40C0200 F8000000
	s_mul_hi_i32 s0, s4, 0x55555556                            // 000000217F44: 9700FF04 55555556
	s_lshl_b32 s21, s2, 6                                      // 000000217F4C: 84158602
	s_lshr_b32 s3, s0, 31                                      // 000000217F50: 85039F00
	s_ashr_i32 s5, s4, 31                                      // 000000217F54: 86059F04
	s_add_i32 s0, s0, s3                                       // 000000217F58: 81000300
	s_mul_i32 s1, s2, 0xc00                                    // 000000217F5C: 9601FF02 00000C00
	s_mul_i32 s6, s2, 0x60000                                  // 000000217F64: 9606FF02 00060000
	s_mul_hi_i32 s3, s21, 0x1800                               // 000000217F6C: 9703FF15 00001800
	s_mul_i32 s2, s2, 0x140000                                 // 000000217F74: 9602FF02 00140000
	v_dual_mov_b32 v5, 0 :: v_dual_lshlrev_b32 v6, 2, v0       // 000000217F7C: CA220080 05060082
	s_mul_hi_i32 s19, s21, 0x5000                              // 000000217F84: 9713FF15 00005000
	v_rsq_f32_e32 v7, 0x43000000                               // 000000217F8C: 7E0E5CFF 43000000
	s_waitcnt lgkmcnt(0)                                       // 000000217F94: BF89FC07
	s_barrier                                                  // 000000217F98: BFBD0000
	buffer_gl0_inv                                             // 000000217F9C: E0AC0000 00000000
	s_cmp_lg_u64 s[24:25], 0                                   // 000000217FA4: BF118018
	s_cselect_b32 s22, -1, 0                                   // 000000217FA8: 981680C1
	s_lshl_b32 s26, s0, 7                                      // 000000217FAC: 841A8700
	s_add_i32 s18, s4, s1                                      // 000000217FB0: 81120104
	s_lshl_b64 s[0:1], s[4:5], 7                               // 000000217FB4: 84808704
	s_ashr_i32 s27, s26, 31                                    // 000000217FB8: 861B9F1A
	s_add_u32 s0, s6, s0                                       // 000000217FBC: 80000006
	s_addc_u32 s1, s3, s1                                      // 000000217FC0: 82010103
	.long 0xd7000001                                           // 000000217FC4: D7000001
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000217FC8: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000217FCC: BF870241
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 000000217FD0: D5207C02 00010001
	.long 0xd44c0000                                           // 000000217FD8: D44C0000
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 000000217FDC: 020200C0
	.long 0xd44c0001                                           // 000000217FE0: D44C0001
	v_cndmask_b32_e32 v1, 32, v0, vcc_lo                       // 000000217FE4: 020200A0
	.long 0xd44c0003                                           // 000000217FE8: D44C0003
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 000000217FEC: 02020090
	.long 0xd73c0003                                           // 000000217FF0: D73C0003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000217FF4: 02020282
	.long 0xd44c0004                                           // 000000217FF8: D44C0004
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 000000217FFC: 02020088
	.long 0xd44c0005                                           // 000000218000: D44C0005
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 000000218004: 02020084
	.long 0xd44c0006                                           // 000000218008: D44C0006
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021800C: 02020082
	.long 0xd73c0001                                           // 000000218010: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000218014: 02020281
	v_lshlrev_b32_e32 v0, 1, v0                                // 000000218018: 30000081
	.long 0xd7006a08                                           // 00000021801C: D7006A08
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                      // 000000218020: 0202060C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000218024: BF870001
	v_add_co_ci_u32_e64 v9, null, s13, v4, vcc_lo              // 000000218028: D5207C09 01AA080D
	s_lshl_b64 s[12:13], s[26:27], 1                           // 000000218030: 848C811A
	.long 0xd7006a01                                           // 000000218034: D7006A01
	v_cndmask_b32_e32 v1, s24, v1, vcc_lo                      // 000000218038: 02020218
	s_add_u32 s2, s2, s12                                      // 00000021803C: 80020C02
	s_addc_u32 s12, s19, s13                                   // 000000218040: 820C0D13
	s_add_u32 s2, s8, s2                                       // 000000218044: 80020208
	s_addc_u32 s8, s9, s12                                     // 000000218048: 82080C09
	.long 0xd700020b                                           // 00000021804C: D700020B
	v_cndmask_b32_e32 v1, s2, v0, vcc_lo                       // 000000218050: 02020002
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000218054: BF8700B1
	v_add_co_ci_u32_e64 v12, null, s8, 0, s2                   // 000000218058: D5207C0C 00090008
	v_add_co_ci_u32_e64 v2, null, s25, v2, vcc_lo              // 000000218060: D5207C02 01AA0419
	.long 0xd7006a00                                           // 000000218068: D7006A00
	v_cndmask_b32_e32 v1, s14, v3, vcc_lo                      // 00000021806C: 0202060E
	v_add_co_ci_u32_e64 v10, null, s15, v4, vcc_lo             // 000000218070: D5207C0A 01AA080F
	.long 0xd7006a03                                           // 000000218078: D7006A03
	v_cndmask_b32_e32 v1, 0x1000, v11, vcc_lo                  // 00000021807C: 020216FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000218084: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v12, vcc_lo               // 000000218088: D5207C04 01AA1880
	s_mov_b64 s[8:9], 0                                        // 000000218090: BE880180
	s_mov_b32 s2, 0x41800000                                   // 000000218094: BE8200FF 41800000
	s_branch 37                                                // 00000021809C: BFA00025 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x234>
	ds_load_b32 v11, v5 offset:512                             // 0000002180A0: D8D80200 0B000005
	s_lshl_b64 s[14:15], s[18:19], 2                           // 0000002180A8: 848E8212
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002180AC: BF870009
	s_add_u32 s14, s16, s14                                    // 0000002180B0: 800E0E10
	s_addc_u32 s15, s17, s15                                   // 0000002180B4: 820F0F11
	s_waitcnt lgkmcnt(0)                                       // 0000002180B8: BF89FC07
	v_add_f32_e32 v11, s13, v11                                // 0000002180BC: 0616160D
	ds_store_b32 v5, v11 offset:512                            // 0000002180C0: D8340200 00000B05
	global_store_b32 v5, v11, s[14:15]                         // 0000002180C8: DC6A0000 000E0B05
	s_or_b32 exec_lo, exec_lo, s12                             // 0000002180D0: 8C7E0C7E
	.long 0xd7006a01                                           // 0000002180D4: D7006A01
	v_cndmask_b32_e32 v1, 0x3000, v1, vcc_lo                   // 0000002180D8: 020202FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002180E0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000002180E4: D5207C02 01AA0480
	.long 0xd7006a03                                           // 0000002180EC: D7006A03
	v_cndmask_b32_e32 v1, 0x5000, v3, vcc_lo                   // 0000002180F0: 020206FF 00005000
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 0000002180F8: D5207C04 01AA0880
	s_add_u32 s8, s8, 0x6000                                   // 000000218100: 8008FF08 00006000
	s_addc_u32 s9, s9, 0                                       // 000000218108: 82098009
	s_add_i32 s18, s18, 48                                     // 00000021810C: 8112B012
	s_add_i32 s21, s21, 1                                      // 000000218110: 81158115
	s_cmp_eq_u32 s8, 0x180000                                  // 000000218114: BF06FF08 00180000
	s_waitcnt lgkmcnt(0)                                       // 00000021811C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000218120: BC7C0000
	s_barrier                                                  // 000000218124: BFBD0000
	buffer_gl0_inv                                             // 000000218128: E0AC0000 00000000
	s_cbranch_scc1 294                                         // 000000218130: BFA20126 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x6cc>
	v_mov_b32_e32 v13, 0                                       // 000000218134: 7E1A0280
	s_cmp_lt_i32 s21, s20                                      // 000000218138: BF041415
	s_cselect_b32 s12, -1, 0                                   // 00000021813C: 980C80C1
	s_cmp_ge_i32 s21, s20                                      // 000000218140: BF031415
	s_cbranch_scc1 4                                           // 000000218144: BFA20004 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x258>
	global_load_u16 v11, v[3:4], off offset:-4096              // 000000218148: DC4A1000 0B7C0003
	s_waitcnt vmcnt(0)                                         // 000000218150: BF8903F7
	v_lshlrev_b32_e32 v13, 16, v11                             // 000000218154: 301A1690
	v_cndmask_b32_e64 v11, 0, 1, s12                           // 000000218158: D501000B 00310280
	v_mov_b32_e32 v12, 0                                       // 000000218160: 7E180280
	s_and_not1_b32 vcc_lo, exec_lo, s12                        // 000000218164: 916A0C7E
	s_cbranch_vccnz 4                                          // 000000218168: BFA40004 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x27c>
	global_load_u16 v12, v[3:4], off                           // 00000021816C: DC4A0000 0C7C0003
	s_waitcnt vmcnt(0)                                         // 000000218174: BF8903F7
	v_lshlrev_b32_e32 v12, 16, v12                             // 000000218178: 30181890
	v_mul_f32_e32 v14, v13, v13                                // 00000021817C: 101C1B0D
	s_barrier                                                  // 000000218180: BFBD0000
	buffer_gl0_inv                                             // 000000218184: E0AC0000 00000000
	ds_store_b32 v6, v14                                       // 00000021818C: D8340000 00000E06
	s_waitcnt lgkmcnt(0)                                       // 000000218194: BF89FC07
	s_barrier                                                  // 000000218198: BFBD0000
	buffer_gl0_inv                                             // 00000021819C: E0AC0000 00000000
	s_and_saveexec_b32 s12, s0                                 // 0000002181A4: BE8C2000
	s_cbranch_execz 6                                          // 0000002181A8: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x2c4>
	ds_load_2addr_stride64_b32 v[14:15], v6 offset1:1          // 0000002181AC: D8E00100 0E000006
	s_waitcnt lgkmcnt(0)                                       // 0000002181B4: BF89FC07
	v_add_f32_e32 v14, v15, v14                                // 0000002181B8: 061C1D0F
	ds_store_b32 v6, v14                                       // 0000002181BC: D8340000 00000E06
	s_or_b32 exec_lo, exec_lo, s12                             // 0000002181C4: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 0000002181C8: BF89FC07
	s_barrier                                                  // 0000002181CC: BFBD0000
	buffer_gl0_inv                                             // 0000002181D0: E0AC0000 00000000
	s_and_saveexec_b32 s12, s1                                 // 0000002181D8: BE8C2001
	s_cbranch_execz 6                                          // 0000002181DC: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x2f8>
	ds_load_2addr_b32 v[14:15], v6 offset1:32                  // 0000002181E0: D8DC2000 0E000006
	s_waitcnt lgkmcnt(0)                                       // 0000002181E8: BF89FC07
	v_add_f32_e32 v14, v15, v14                                // 0000002181EC: 061C1D0F
	ds_store_b32 v6, v14                                       // 0000002181F0: D8340000 00000E06
	s_or_b32 exec_lo, exec_lo, s12                             // 0000002181F8: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 0000002181FC: BF89FC07
	s_barrier                                                  // 000000218200: BFBD0000
	buffer_gl0_inv                                             // 000000218204: E0AC0000 00000000
	s_and_saveexec_b32 s12, s3                                 // 00000021820C: BE8C2003
	s_cbranch_execz 6                                          // 000000218210: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x32c>
	ds_load_2addr_b32 v[14:15], v6 offset1:16                  // 000000218214: D8DC1000 0E000006
	s_waitcnt lgkmcnt(0)                                       // 00000021821C: BF89FC07
	v_add_f32_e32 v14, v15, v14                                // 000000218220: 061C1D0F
	ds_store_b32 v6, v14                                       // 000000218224: D8340000 00000E06
	s_or_b32 exec_lo, exec_lo, s12                             // 00000021822C: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000218230: BF89FC07
	s_barrier                                                  // 000000218234: BFBD0000
	buffer_gl0_inv                                             // 000000218238: E0AC0000 00000000
	s_and_saveexec_b32 s12, s4                                 // 000000218240: BE8C2004
	s_cbranch_execz 6                                          // 000000218244: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x360>
	ds_load_2addr_b32 v[14:15], v6 offset1:8                   // 000000218248: D8DC0800 0E000006
	s_waitcnt lgkmcnt(0)                                       // 000000218250: BF89FC07
	v_add_f32_e32 v14, v15, v14                                // 000000218254: 061C1D0F
	ds_store_b32 v6, v14                                       // 000000218258: D8340000 00000E06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000218260: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000218264: BF89FC07
	s_barrier                                                  // 000000218268: BFBD0000
	buffer_gl0_inv                                             // 00000021826C: E0AC0000 00000000
	s_and_saveexec_b32 s12, s5                                 // 000000218274: BE8C2005
	s_cbranch_execz 6                                          // 000000218278: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x394>
	ds_load_2addr_b32 v[14:15], v6 offset1:4                   // 00000021827C: D8DC0400 0E000006
	s_waitcnt lgkmcnt(0)                                       // 000000218284: BF89FC07
	v_add_f32_e32 v14, v15, v14                                // 000000218288: 061C1D0F
	ds_store_b32 v6, v14                                       // 00000021828C: D8340000 00000E06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000218294: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000218298: BF89FC07
	s_barrier                                                  // 00000021829C: BFBD0000
	buffer_gl0_inv                                             // 0000002182A0: E0AC0000 00000000
	s_and_saveexec_b32 s12, s6                                 // 0000002182A8: BE8C2006
	s_cbranch_execz 6                                          // 0000002182AC: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x3c8>
	ds_load_2addr_b32 v[14:15], v6 offset1:2                   // 0000002182B0: D8DC0200 0E000006
	s_waitcnt lgkmcnt(0)                                       // 0000002182B8: BF89FC07
	v_add_f32_e32 v14, v15, v14                                // 0000002182BC: 061C1D0F
	ds_store_b32 v6, v14                                       // 0000002182C0: D8340000 00000E06
	s_or_b32 exec_lo, exec_lo, s12                             // 0000002182C8: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 0000002182CC: BF89FC07
	s_barrier                                                  // 0000002182D0: BFBD0000
	buffer_gl0_inv                                             // 0000002182D4: E0AC0000 00000000
	s_and_saveexec_b32 s12, s7                                 // 0000002182DC: BE8C2007
	s_cbranch_execz 8                                          // 0000002182E0: BFA50008 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x404>
	ds_load_b32 v14, v5 offset:4                               // 0000002182E4: D8D80004 0E000005
	ds_load_b32 v15, v6                                        // 0000002182EC: D8D80000 0F000006
	s_waitcnt lgkmcnt(0)                                       // 0000002182F4: BF89FC07
	v_add_f32_e32 v14, v14, v15                                // 0000002182F8: 061C1F0E
	ds_store_b32 v6, v14                                       // 0000002182FC: D8340000 00000E06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000218304: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000218308: BF89FC07
	s_barrier                                                  // 00000021830C: BFBD0000
	buffer_gl0_inv                                             // 000000218310: E0AC0000 00000000
	ds_load_b32 v14, v5                                        // 000000218318: D8D80000 0E000005
	s_waitcnt lgkmcnt(0)                                       // 000000218320: BF89FC07
	v_dual_mul_f32 v15, v12, v12 :: v_dual_add_f32 v14, 0x358637bd, v14// 000000218324: C8C8190C 0F0E1CFF 358637BD
	s_delay_alu instid0(VALU_DEP_1)                            // 000000218330: BF870001
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v14                     // 000000218334: 7C281CFF 00800000
	s_barrier                                                  // 00000021833C: BFBD0000
	buffer_gl0_inv                                             // 000000218340: E0AC0000 00000000
	ds_store_b32 v6, v15                                       // 000000218348: D8340000 00000F06
	s_waitcnt lgkmcnt(0)                                       // 000000218350: BF89FC07
	s_barrier                                                  // 000000218354: BFBD0000
	buffer_gl0_inv                                             // 000000218358: E0AC0000 00000000
	s_and_saveexec_b32 s12, s0                                 // 000000218360: BE8C2000
	s_cbranch_execz 6                                          // 000000218364: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x480>
	ds_load_2addr_stride64_b32 v[15:16], v6 offset1:1          // 000000218368: D8E00100 0F000006
	s_waitcnt lgkmcnt(0)                                       // 000000218370: BF89FC07
	v_add_f32_e32 v15, v16, v15                                // 000000218374: 061E1F10
	ds_store_b32 v6, v15                                       // 000000218378: D8340000 00000F06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000218380: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000218384: BF89FC07
	s_barrier                                                  // 000000218388: BFBD0000
	buffer_gl0_inv                                             // 00000021838C: E0AC0000 00000000
	s_and_saveexec_b32 s12, s1                                 // 000000218394: BE8C2001
	s_cbranch_execz 6                                          // 000000218398: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x4b4>
	ds_load_2addr_b32 v[15:16], v6 offset1:32                  // 00000021839C: D8DC2000 0F000006
	s_waitcnt lgkmcnt(0)                                       // 0000002183A4: BF89FC07
	v_add_f32_e32 v15, v16, v15                                // 0000002183A8: 061E1F10
	ds_store_b32 v6, v15                                       // 0000002183AC: D8340000 00000F06
	s_or_b32 exec_lo, exec_lo, s12                             // 0000002183B4: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 0000002183B8: BF89FC07
	s_barrier                                                  // 0000002183BC: BFBD0000
	buffer_gl0_inv                                             // 0000002183C0: E0AC0000 00000000
	s_and_saveexec_b32 s12, s3                                 // 0000002183C8: BE8C2003
	s_cbranch_execz 6                                          // 0000002183CC: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x4e8>
	ds_load_2addr_b32 v[15:16], v6 offset1:16                  // 0000002183D0: D8DC1000 0F000006
	s_waitcnt lgkmcnt(0)                                       // 0000002183D8: BF89FC07
	v_add_f32_e32 v15, v16, v15                                // 0000002183DC: 061E1F10
	ds_store_b32 v6, v15                                       // 0000002183E0: D8340000 00000F06
	s_or_b32 exec_lo, exec_lo, s12                             // 0000002183E8: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 0000002183EC: BF89FC07
	s_barrier                                                  // 0000002183F0: BFBD0000
	buffer_gl0_inv                                             // 0000002183F4: E0AC0000 00000000
	s_and_saveexec_b32 s12, s4                                 // 0000002183FC: BE8C2004
	s_cbranch_execz 6                                          // 000000218400: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x51c>
	ds_load_2addr_b32 v[15:16], v6 offset1:8                   // 000000218404: D8DC0800 0F000006
	s_waitcnt lgkmcnt(0)                                       // 00000021840C: BF89FC07
	v_add_f32_e32 v15, v16, v15                                // 000000218410: 061E1F10
	ds_store_b32 v6, v15                                       // 000000218414: D8340000 00000F06
	s_or_b32 exec_lo, exec_lo, s12                             // 00000021841C: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000218420: BF89FC07
	s_barrier                                                  // 000000218424: BFBD0000
	buffer_gl0_inv                                             // 000000218428: E0AC0000 00000000
	s_and_saveexec_b32 s12, s5                                 // 000000218430: BE8C2005
	s_cbranch_execz 6                                          // 000000218434: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x550>
	ds_load_2addr_b32 v[15:16], v6 offset1:4                   // 000000218438: D8DC0400 0F000006
	s_waitcnt lgkmcnt(0)                                       // 000000218440: BF89FC07
	v_add_f32_e32 v15, v16, v15                                // 000000218444: 061E1F10
	ds_store_b32 v6, v15                                       // 000000218448: D8340000 00000F06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000218450: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000218454: BF89FC07
	s_barrier                                                  // 000000218458: BFBD0000
	buffer_gl0_inv                                             // 00000021845C: E0AC0000 00000000
	s_and_saveexec_b32 s12, s6                                 // 000000218464: BE8C2006
	s_cbranch_execz 6                                          // 000000218468: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x584>
	ds_load_2addr_b32 v[15:16], v6 offset1:2                   // 00000021846C: D8DC0200 0F000006
	s_waitcnt lgkmcnt(0)                                       // 000000218474: BF89FC07
	v_add_f32_e32 v15, v16, v15                                // 000000218478: 061E1F10
	ds_store_b32 v6, v15                                       // 00000021847C: D8340000 00000F06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000218484: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000218488: BF89FC07
	s_barrier                                                  // 00000021848C: BFBD0000
	buffer_gl0_inv                                             // 000000218490: E0AC0000 00000000
	s_and_saveexec_b32 s12, s7                                 // 000000218498: BE8C2007
	s_cbranch_execz 8                                          // 00000021849C: BFA50008 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x5c0>
	ds_load_b32 v15, v5 offset:4                               // 0000002184A0: D8D80004 0F000005
	ds_load_b32 v16, v6                                        // 0000002184A8: D8D80000 10000006
	s_waitcnt lgkmcnt(0)                                       // 0000002184B0: BF89FC07
	v_add_f32_e32 v15, v15, v16                                // 0000002184B4: 061E210F
	ds_store_b32 v6, v15                                       // 0000002184B8: D8340000 00000F06
	s_or_b32 exec_lo, exec_lo, s12                             // 0000002184C0: 8C7E0C7E
	v_mul_f32_e32 v15, 0x4b800000, v14                         // 0000002184C4: 101E1CFF 4B800000
	s_waitcnt lgkmcnt(0)                                       // 0000002184CC: BF89FC07
	s_barrier                                                  // 0000002184D0: BFBD0000
	buffer_gl0_inv                                             // 0000002184D4: E0AC0000 00000000
	v_cndmask_b32_e32 v14, v14, v15, vcc_lo                    // 0000002184DC: 021C1F0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000002184E0: BF8700B1
	v_rsq_f32_e32 v15, v14                                     // 0000002184E4: 7E1E5D0E
	ds_load_b32 v14, v5                                        // 0000002184E8: D8D80000 0E000005
	v_mul_f32_e32 v16, 0x45800000, v15                         // 0000002184F0: 10201EFF 45800000
	v_cndmask_b32_e32 v15, v15, v16, vcc_lo                    // 0000002184F8: 021E210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000002184FC: BF870091
	v_mul_f32_e32 v15, v7, v15                                 // 000000218500: 101E1F07
	v_mul_f32_e32 v13, v13, v15                                // 000000218504: 101A1F0D
	.long 0xd7006a0f                                           // 000000218508: D7006A0F
	v_cndmask_b32_e32 v0, v8, v8, vcc_lo                       // 00000021850C: 02001108
	s_delay_alu instid0(VALU_DEP_1)                            // 000000218510: BF870001
	v_add_co_ci_u32_e64 v16, null, s9, v9, vcc_lo              // 000000218514: D5207C10 01AA1209
	s_and_not1_b32 vcc_lo, exec_lo, s22                        // 00000021851C: 916A167E
	global_store_b32 v[15:16], v13, off                        // 000000218520: DC6A0000 007C0D0F
	s_cbranch_vccnz 4                                          // 000000218528: BFA40004 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x63c>
	v_fma_mixlo_f16 v13, v13, s2, 0                            // 00000021852C: CC21000D 0200050D
	global_store_b16 v[1:2], v13, off                          // 000000218534: DC660000 007C0D01
	s_waitcnt lgkmcnt(0)                                       // 00000021853C: BF89FC07
	v_add_f32_e32 v13, 0x358637bd, v14                         // 000000218540: 061A1CFF 358637BD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000218548: BF870121
	v_mul_f32_e32 v14, 0x4b800000, v13                         // 00000021854C: 101C1AFF 4B800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v13                     // 000000218554: 7C281AFF 00800000
	v_cndmask_b32_e32 v13, v13, v14, vcc_lo                    // 00000021855C: 021A1D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000218560: BF870291
	v_rsq_f32_e32 v13, v13                                     // 000000218564: 7E1A5D0D
	v_mul_f32_e32 v14, 0x45800000, v13                         // 000000218568: 101C1AFF 45800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000218570: BF870091
	v_cndmask_b32_e32 v13, v13, v14, vcc_lo                    // 000000218574: 021A1D0D
	v_mul_f32_e32 v14, v12, v13                                // 000000218578: 101C1B0C
	.long 0xd7006a0c                                           // 00000021857C: D7006A0C
	v_cndmask_b32_e32 v0, v0, v8, vcc_lo                       // 000000218580: 02001100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000218584: BF870001
	v_add_co_ci_u32_e64 v13, null, s9, v10, vcc_lo             // 000000218588: D5207C0D 01AA1409
	global_store_b32 v[12:13], v14, off                        // 000000218590: DC6A0000 007C0E0C
	s_and_saveexec_b32 s12, s7                                 // 000000218598: BE8C2007
	s_cbranch_execz 65228                                      // 00000021859C: BFA5FECC <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x1d0>
	v_cmp_ne_u32_e32 vcc_lo, 1, v11                            // 0000002185A0: 7C9A1681
	s_ashr_i32 s19, s18, 31                                    // 0000002185A4: 86139F12
	s_mov_b32 s13, 0                                           // 0000002185A8: BE8D0080
	s_cbranch_vccnz 65212                                      // 0000002185AC: BFA4FEBC <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x1a0>
	s_lshl_b64 s[14:15], s[18:19], 2                           // 0000002185B0: 848E8212
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002185B4: BF870009
	s_add_u32 s14, s10, s14                                    // 0000002185B8: 800E0E0A
	s_addc_u32 s15, s11, s15                                   // 0000002185BC: 820F0F0B
	s_load_b32 s13, s[14:15], null                             // 0000002185C0: F4000347 F8000000
	s_branch 65205                                             // 0000002185C8: BFA0FEB5 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb0ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x1a0>
	s_endpgm                                                   // 0000002185CC: BFB00000
		...

