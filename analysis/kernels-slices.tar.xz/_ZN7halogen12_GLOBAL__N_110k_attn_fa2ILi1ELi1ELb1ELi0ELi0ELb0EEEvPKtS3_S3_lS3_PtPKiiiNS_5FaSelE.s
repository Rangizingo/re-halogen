000000000009ff00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 00000009FF00: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 00000009FF04: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 00000009FF0C: F4080500 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 00000009FF14: 3706009F
	v_lshrrev_b32_e32 v156, 5, v0                              // 00000009FF18: 33380085
	s_mov_b32 s24, s3                                          // 00000009FF1C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000009FF20: BF870112
	.long 0xd44c0003                                           // 00000009FF24: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 00000009FF28: 02030690
	v_lshlrev_b32_e32 v132, 6, v156                            // 00000009FF2C: 31093886
	s_waitcnt lgkmcnt(0)                                       // 00000009FF30: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 00000009FF34: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 00000009FF3C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 00000009FF40: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 00000009FF44: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 00000009FF4C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:156 offset1:162// 00000009FF58: D83CA29C 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 00000009FF60: 8C7E047E
	v_mul_u32_u24_e32 v1, 0xab, v0                             // 00000009FF64: 160200FF 000000AB
	.long 0x7f043880                                           // 00000009FF6C: 7F043880
	v_dual_mov_b32 v141, 0 :: v_dual_and_b32 v154, 15, v0      // 00000009FF70: CA240080 8D9A008F
	s_cmp_eq_u64 s[14:15], 0                                   // 00000009FF78: BF10800E
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000009FF7C: BF8704B3
	.long 0x7e043981                                           // 00000009FF80: 7E043981
	v_mov_b32_e32 v142, 0                                      // 00000009FF84: 7F1C0280
	s_cselect_b32 s25, -1, 0                                   // 00000009FF88: 981980C1
	s_and_b32 vcc_lo, exec_lo, s25                             // 00000009FF8C: 8B6A197E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009FF90: BF870092
	v_add_lshl_u32 v155, s2, v2, 4                             // 00000009FF94: D647009B 02120402
	v_or_b32_e32 v129, v155, v154                              // 00000009FF9C: 3903359B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000009FFA0: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 00000009FFA4: 3505029F
	s_cbranch_vccnz 10                                         // 00000009FFA8: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xd4>
	v_mad_i64_i32 v[1:2], null, s23, v129, 0                   // 00000009FFAC: D6FF7C01 02030217
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009FFB4: BF870091
	.long 0xd73c0001                                           // 00000009FFB8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000009FFBC: 02020282
	.long 0xd7006a8d                                           // 00000009FFC0: D7006A8D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000009FFC4: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000009FFC8: BF870001
	v_add_co_ci_u32_e64 v142, null, s15, v2, vcc_lo            // 00000009FFCC: D5207C8E 01AA040F
	s_clause 0x2                                               // 00000009FFD4: BF850002
	s_load_b64 s[14:15], s[0:1], 0x38                          // 00000009FFD8: F4040380 F8000038
	s_load_b128 s[16:19], s[0:1], 0x20                         // 00000009FFE0: F4080400 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 00000009FFE8: F40C0100 F8000000
	v_mov_b32_e32 v158, 0                                      // 00000009FFF0: 7F3C0280
	s_xor_b32 s0, s25, -1                                      // 00000009FFF4: 8D00C119
	s_waitcnt lgkmcnt(0)                                       // 00000009FFF8: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v129                         // 00000009FFFC: 7C89020E
	s_and_b32 s23, s0, vcc_lo                                  // 0000000A0000: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A0004: BF870009
	s_and_saveexec_b32 s0, s23                                 // 0000000A0008: BE802017
	s_cbranch_execz 9                                          // 0000000A000C: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x134>
	.long 0xd73c0001                                           // 0000000A0010: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 0000000A0014: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0018: BF870091
	.long 0xd7006a01                                           // 0000000A001C: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 0000000A0020: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 0000000A0024: D5207C02 01AA0415
	global_load_b32 v158, v[1:2], off                          // 0000000A002C: DC520000 9E7C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000A0034: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 0000000A0038: BF10800C
	s_mov_b64 s[20:21], 0                                      // 0000000A003C: BE940180
	s_cbranch_scc1 10                                          // 0000000A0040: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16c>
	s_ashr_i32 s0, s22, 31                                     // 0000000A0044: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 0000000A0048: 96810216
	s_mul_i32 s0, s0, s2                                       // 0000000A004C: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000A0050: BF8704A9
	s_add_i32 s1, s1, s0                                       // 0000000A0054: 81010001
	s_mul_i32 s0, s22, s2                                      // 0000000A0058: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000000A005C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A0060: BF870009
	s_add_u32 s20, s12, s0                                     // 0000000A0064: 8014000C
	s_addc_u32 s21, s13, s1                                    // 0000000A0068: 8215010D
	.long 0xd7050001                                           // 0000000A006C: D7050001
	v_cndmask_b32_e32 v0, v156, v150, vcc_lo                   // 0000000A0070: 02012D9C
	s_lshl_b32 s0, s2, 4                                       // 0000000A0074: 84008402
	s_add_i32 s1, s14, -1                                      // 0000000A0078: 8101C10E
	s_or_b32 s0, s0, 15                                        // 0000000A007C: 8C008F00
	v_lshrrev_b32_e32 v157, 4, v131                            // 0000000A0080: 333B0684
	.long 0xd7390001                                           // 0000000A0084: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000000A0088: 02020288
	s_min_i32 s0, s0, s1                                       // 0000000A008C: 89000100
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000A0090: BF870499
	s_add_i32 s0, s26, s0                                      // 0000000A0094: 8100001A
	s_cmp_lt_i32 s0, -15                                       // 0000000A0098: BF04CF00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A009C: BF870091
	.long 0xd7050001                                           // 0000000A00A0: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 0000000A00A4: 02011901
	.long 0xd7040001                                           // 0000000A00A8: D7040001
	v_cndmask_b32_e32 v1, v156, v1, vcc_lo                     // 0000000A00AC: 0202039C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A00B0: BF870091
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 0000000A00B4: CA240080 480002FF 000000FF
	v_mov_b32_e32 v71, v72                                     // 0000000A00C0: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 0000000A00C4: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 0000000A00C8: 7E880348
	v_mov_b32_e32 v67, v72                                     // 0000000A00CC: 7E860348
	v_mad_u64_u32 v[138:139], null, s24, 12, v[1:2]            // 0000000A00D0: D6FE7C8A 04051818
	v_mov_b32_e32 v70, v72                                     // 0000000A00D8: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 0000000A00DC: 7E840348
	v_mov_b32_e32 v65, v72                                     // 0000000A00E0: 7E820348
	v_mov_b32_e32 v80, v72                                     // 0000000A00E4: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 0000000A00E8: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 0000000A00EC: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 0000000A00F0: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 0000000A00F4: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 0000000A00FC: 7E960348
	v_mov_b32_e32 v74, v72                                     // 0000000A0100: 7E940348
	v_mov_b32_e32 v73, v72                                     // 0000000A0104: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A0108: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000000A010C: 3404029F
	v_mov_b32_e32 v88, v72                                     // 0000000A0110: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 0000000A0114: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 0000000A0118: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 0000000A011C: 7EAA0348
	.long 0xd73c008b                                           // 0000000A0120: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000000A0124: 02020281
	v_mov_b32_e32 v84, v72                                     // 0000000A0128: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 0000000A012C: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 0000000A0130: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 0000000A0134: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 0000000A0138: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 0000000A013C: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 0000000A0140: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 0000000A0144: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 0000000A0148: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 0000000A014C: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 0000000A0150: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 0000000A0154: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 0000000A0158: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 0000000A015C: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 0000000A0160: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 0000000A0164: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 0000000A0168: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 0000000A016C: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 0000000A0170: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 0000000A0174: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 0000000A0178: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 0000000A017C: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 0000000A0180: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 0000000A0184: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 0000000A0188: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 0000000A018C: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 0000000A0190: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 0000000A0194: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 0000000A0198: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 0000000A019C: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 0000000A01A0: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 0000000A01A4: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 0000000A01A8: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 0000000A01AC: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 0000000A01B0: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 0000000A01B4: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 0000000A01B8: 7F000348
	v_mov_b32_e32 v127, v72                                    // 0000000A01BC: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 0000000A01C0: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 0000000A01C4: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 0000000A01C8: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 0000000A01CC: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 0000000A01D0: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 0000000A01D4: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 0000000A01D8: 7E800348
	v_mov_b32_e32 v63, v72                                     // 0000000A01DC: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 0000000A01E0: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 0000000A01E4: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 0000000A01E8: 7E780348
	v_mov_b32_e32 v59, v72                                     // 0000000A01EC: 7E760348
	v_mov_b32_e32 v58, v72                                     // 0000000A01F0: 7E740348
	v_mov_b32_e32 v57, v72                                     // 0000000A01F4: 7E720348
	v_mov_b32_e32 v56, v72                                     // 0000000A01F8: 7E700348
	v_mov_b32_e32 v55, v72                                     // 0000000A01FC: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 0000000A0200: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 0000000A0204: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 0000000A0208: 7E680348
	v_mov_b32_e32 v51, v72                                     // 0000000A020C: 7E660348
	v_mov_b32_e32 v50, v72                                     // 0000000A0210: 7E640348
	v_mov_b32_e32 v49, v72                                     // 0000000A0214: 7E620348
	v_mov_b32_e32 v48, v72                                     // 0000000A0218: 7E600348
	v_mov_b32_e32 v47, v72                                     // 0000000A021C: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 0000000A0220: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 0000000A0224: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 0000000A0228: 7E580348
	v_mov_b32_e32 v43, v72                                     // 0000000A022C: 7E560348
	v_mov_b32_e32 v42, v72                                     // 0000000A0230: 7E540348
	v_mov_b32_e32 v41, v72                                     // 0000000A0234: 7E520348
	v_mov_b32_e32 v40, v72                                     // 0000000A0238: 7E500348
	v_mov_b32_e32 v39, v72                                     // 0000000A023C: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 0000000A0240: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 0000000A0244: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 0000000A0248: 7E480348
	v_mov_b32_e32 v35, v72                                     // 0000000A024C: 7E460348
	v_mov_b32_e32 v34, v72                                     // 0000000A0250: 7E440348
	v_mov_b32_e32 v33, v72                                     // 0000000A0254: 7E420348
	v_mov_b32_e32 v32, v72                                     // 0000000A0258: 7E400348
	v_mov_b32_e32 v31, v72                                     // 0000000A025C: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 0000000A0260: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 0000000A0264: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 0000000A0268: 7E380348
	v_mov_b32_e32 v27, v72                                     // 0000000A026C: 7E360348
	v_mov_b32_e32 v26, v72                                     // 0000000A0270: 7E340348
	v_mov_b32_e32 v25, v72                                     // 0000000A0274: 7E320348
	v_mov_b32_e32 v24, v72                                     // 0000000A0278: 7E300348
	v_mov_b32_e32 v23, v72                                     // 0000000A027C: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 0000000A0280: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 0000000A0284: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 0000000A0288: 7E280348
	v_mov_b32_e32 v19, v72                                     // 0000000A028C: 7E260348
	v_mov_b32_e32 v18, v72                                     // 0000000A0290: 7E240348
	v_mov_b32_e32 v17, v72                                     // 0000000A0294: 7E220348
	v_mov_b32_e32 v16, v72                                     // 0000000A0298: 7E200348
	v_mov_b32_e32 v15, v72                                     // 0000000A029C: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 0000000A02A0: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 0000000A02A4: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 0000000A02A8: 7E180348
	v_mov_b32_e32 v11, v72                                     // 0000000A02AC: 7E160348
	v_mov_b32_e32 v10, v72                                     // 0000000A02B0: 7E140348
	v_mov_b32_e32 v9, v72                                      // 0000000A02B4: 7E120348
	v_mov_b32_e32 v8, v72                                      // 0000000A02B8: 7E100348
	v_mov_b32_e32 v7, v72                                      // 0000000A02BC: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 0000000A02C0: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 0000000A02C4: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 0000000A02C8: 7E080348
	v_mov_b32_e32 v3, v72                                      // 0000000A02CC: 7E060348
	v_mov_b32_e32 v2, v72                                      // 0000000A02D0: 7E040348
	v_mov_b32_e32 v1, v72                                      // 0000000A02D4: 7E020348
	s_cbranch_scc1 2304                                        // 0000000A02D8: BFA20900 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x27dc>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[4:5]           // 0000000A02DC: D6FF7C01 001302FF 00003000
	v_add3_u32 v3, v129, s26, 1                                // 0000000A02E8: D6550003 02043581
	s_ashr_i32 s1, s0, 31                                      // 0000000A02F0: 86019F00
	v_dual_mov_b32 v129, 0 :: v_dual_lshlrev_b32 v4, 2, v131   // 0000000A02F4: CA220080 81050682
	s_lshr_b32 s1, s1, 28                                      // 0000000A02FC: 85019C01
	s_movk_i32 s2, 0x210                                       // 0000000A0300: B0020210
	s_add_i32 s0, s0, s1                                       // 0000000A0304: 81000100
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 0000000A0308: BF8701D3
	.long 0xd7006a8f                                           // 0000000A030C: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 0000000A0310: 02031701
	v_ashrrev_i32_e32 v1, 31, v3                               // 0000000A0314: 3402069F
	s_movk_i32 s1, 0x440                                       // 0000000A0318: B0010440
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 0000000A031C: D5207C90 01AB1902
	v_mad_u32_u24 v2, v156, s1, 0x1800                         // 0000000A0324: D60B0002 03FC039C 00001800
	v_lshrrev_b32_e32 v1, 30, v1                               // 0000000A0330: 3202029E
	s_ashr_i32 s12, s0, 4                                      // 0000000A0334: 860C8400
	s_cmp_eq_u64 s[20:21], 0                                   // 0000000A0338: BF108014
	v_mov_b32_e32 v176, v156                                   // 0000000A033C: 7F60039C
	v_mad_u32_u24 v5, 0x44, v157, v2                           // 0000000A0340: D60B0005 040B3AFF 00000044
	v_add_nc_u32_e32 v1, v3, v1                                // 0000000A034C: 4A020303
	v_mad_u32_u24 v164, 0x44, v131, v2                         // 0000000A0350: D60B00A4 040B06FF 00000044
	v_lshlrev_b32_e32 v2, 4, v0                                // 0000000A035C: 30040084
	s_cselect_b32 s13, -1, 0                                   // 0000000A0360: 980D80C1
	v_lshl_add_u32 v160, v154, 2, v5                           // 0000000A0364: D64600A0 0415059A
	v_ashrrev_i32_e32 v161, 2, v1                              // 0000000A036C: 35420282
	v_lshlrev_b32_e32 v1, 9, v156                              // 0000000A0370: 30033889
	v_dual_mov_b32 v8, v129 :: v_dual_add_nc_u32 v5, 0x9f00, v132// 0000000A0374: CA200181 080508FF 00009F00
	s_cmp_lg_u64 s[20:21], 0                                   // 0000000A0380: BF118014
	v_add_nc_u32_e32 v3, v4, v132                              // 0000000A0384: 4A070904
	s_cselect_b32 s22, -1, 0                                   // 0000000A0388: 981680C1
	s_ashr_i32 s25, s24, 31                                    // 0000000A038C: 86199F18
	v_add_nc_u32_e32 v167, v5, v4                              // 0000000A0390: 4B4E0905
	v_mov_b32_e32 v4, v129                                     // 0000000A0394: 7E080381
	v_lshl_add_u32 v165, v131, 5, v1                           // 0000000A0398: D64600A5 04050B83
	v_lshl_or_b32 v169, v154, 5, v1                            // 0000000A03A0: D65600A9 04050B9A
	v_dual_mov_b32 v10, v129 :: v_dual_and_b32 v1, 0x1f0, v2   // 0000000A03A8: CA240181 0A0004FF 000001F0
	s_lshl_b64 s[4:5], s[24:25], 9                             // 0000000A03B4: 84848918
	s_add_i32 s15, s15, -1                                     // 0000000A03B8: 810FC10F
	v_mul_u32_u24_e32 v2, 0x210, v156                          // 0000000A03BC: 160538FF 00000210
	s_add_u32 s1, s6, s4                                       // 0000000A03C4: 80010406
	s_addc_u32 s6, s7, s5                                      // 0000000A03C8: 82060507
	.long 0xd70001ab                                           // 0000000A03CC: D70001AB
	v_cndmask_b32_e32 v1, s1, v1, vcc_lo                       // 0000000A03D0: 02020201
	.long 0xd44c0000                                           // 0000000A03D4: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 0000000A03D8: 020200FF 00000200
	v_mad_u32_u24 v159, v154, s2, 0x7b00                       // 0000000A03E0: D60B009F 03FC059A 00007B00
	v_add3_u32 v162, v155, v131, s26                           // 0000000A03EC: D65500A2 006B079B
	v_lshl_or_b32 v168, v157, 2, v5                            // 0000000A03F4: D65600A8 0415059D
	v_mad_u32_u24 v170, v154, 48, 0x4b00                       // 0000000A03FC: D60B00AA 03FD619A 00004B00
	v_add_co_ci_u32_e64 v172, null, s6, 0, s1                  // 0000000A0408: D5207CAC 00050006
	v_lshl_or_b32 v173, v154, 1, 0x4b00                        // 0000000A0410: D65600AD 03FD039A 00004B00
	v_dual_mov_b32 v5, v129 :: v_dual_add_nc_u32 v174, 0xfffffe80, v0// 0000000A041C: CA200181 05AE00FF FFFFFE80
	v_lshl_add_u32 v175, v131, 4, v2                           // 0000000A0428: D64600AF 04090983
	v_lshrrev_b32_e32 v0, 1, v0                                // 0000000A0430: 32000081
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, v129            // 0000000A0434: CA100080 01020181
	v_dual_mov_b32 v6, v129 :: v_dual_add_nc_u32 v163, 0x9c00, v3// 0000000A043C: CA200181 06A206FF 00009C00
	v_dual_mov_b32 v3, v129 :: v_dual_add_nc_u32 v166, 0xa200, v3// 0000000A0448: CA200181 03A606FF 0000A200
	v_mov_b32_e32 v7, v129                                     // 0000000A0454: 7E0E0381
	v_dual_mov_b32 v9, 0 :: v_dual_mov_b32 v12, v129           // 0000000A0458: CA100080 090C0181
	v_mov_b32_e32 v11, v129                                    // 0000000A0460: 7E160381
	v_mov_b32_e32 v13, v129                                    // 0000000A0464: 7E1A0381
	v_dual_mov_b32 v14, v129 :: v_dual_mov_b32 v17, 0          // 0000000A0468: CA100181 0E100080
	v_mov_b32_e32 v15, v129                                    // 0000000A0470: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v25, 0          // 0000000A0474: CA100181 10180080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v33, 0          // 0000000A047C: CA100181 12200080
	v_mov_b32_e32 v19, v129                                    // 0000000A0484: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v41, 0          // 0000000A0488: CA100181 14280080
	v_mov_b32_e32 v21, v129                                    // 0000000A0490: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v49, 0          // 0000000A0494: CA100181 16300080
	v_mov_b32_e32 v23, v129                                    // 0000000A049C: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v57, 0          // 0000000A04A0: CA100181 18380080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v121, 0         // 0000000A04A8: CA100181 1A780080
	v_mov_b32_e32 v27, v129                                    // 0000000A04B0: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v113, 0         // 0000000A04B4: CA100181 1C700080
	v_mov_b32_e32 v29, v129                                    // 0000000A04BC: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v105, 0         // 0000000A04C0: CA100181 1E680080
	v_mov_b32_e32 v31, v129                                    // 0000000A04C8: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v97, 0          // 0000000A04CC: CA100181 20600080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v89, 0          // 0000000A04D4: CA100181 22580080
	v_mov_b32_e32 v35, v129                                    // 0000000A04DC: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v81, 0          // 0000000A04E0: CA100181 24500080
	v_mov_b32_e32 v37, v129                                    // 0000000A04E8: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v73, 0          // 0000000A04EC: CA100181 26480080
	v_mov_b32_e32 v39, v129                                    // 0000000A04F4: 7E4E0381
	v_dual_mov_b32 v40, v129 :: v_dual_mov_b32 v65, 0          // 0000000A04F8: CA100181 28400080
	v_dual_mov_b32 v42, v129 :: v_dual_mov_b32 v145, 0         // 0000000A0500: CA100181 2A900080
	v_mov_b32_e32 v43, v129                                    // 0000000A0508: 7E560381
	v_mov_b32_e32 v44, v129                                    // 0000000A050C: 7E580381
	v_mov_b32_e32 v45, v129                                    // 0000000A0510: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 0000000A0514: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 0000000A0518: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 0000000A051C: 7E600381
	v_mov_b32_e32 v50, v129                                    // 0000000A0520: 7E640381
	v_mov_b32_e32 v51, v129                                    // 0000000A0524: 7E660381
	v_mov_b32_e32 v52, v129                                    // 0000000A0528: 7E680381
	v_mov_b32_e32 v53, v129                                    // 0000000A052C: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 0000000A0530: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 0000000A0534: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 0000000A0538: 7E700381
	v_mov_b32_e32 v58, v129                                    // 0000000A053C: 7E740381
	v_mov_b32_e32 v59, v129                                    // 0000000A0540: 7E760381
	v_mov_b32_e32 v60, v129                                    // 0000000A0544: 7E780381
	v_mov_b32_e32 v61, v129                                    // 0000000A0548: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 0000000A054C: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 0000000A0550: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 0000000A0554: 7E800381
	v_mov_b32_e32 v122, v129                                   // 0000000A0558: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 0000000A055C: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 0000000A0560: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 0000000A0564: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 0000000A0568: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 0000000A056C: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 0000000A0570: 7F000381
	v_mov_b32_e32 v114, v129                                   // 0000000A0574: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 0000000A0578: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 0000000A057C: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 0000000A0580: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 0000000A0584: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 0000000A0588: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 0000000A058C: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 0000000A0590: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 0000000A0594: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 0000000A0598: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 0000000A059C: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 0000000A05A0: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 0000000A05A4: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 0000000A05A8: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 0000000A05AC: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 0000000A05B0: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 0000000A05B4: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 0000000A05B8: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 0000000A05BC: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 0000000A05C0: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 0000000A05C4: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 0000000A05C8: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 0000000A05CC: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 0000000A05D0: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 0000000A05D4: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 0000000A05D8: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 0000000A05DC: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 0000000A05E0: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 0000000A05E4: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 0000000A05E8: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 0000000A05EC: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 0000000A05F0: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 0000000A05F4: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 0000000A05F8: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 0000000A05FC: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 0000000A0600: 7E940381
	v_mov_b32_e32 v75, v129                                    // 0000000A0604: 7E960381
	v_mov_b32_e32 v76, v129                                    // 0000000A0608: 7E980381
	v_mov_b32_e32 v77, v129                                    // 0000000A060C: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 0000000A0610: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 0000000A0614: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 0000000A0618: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 0000000A061C: 7E840381
	v_mov_b32_e32 v67, v129                                    // 0000000A0620: 7E860381
	v_mov_b32_e32 v68, v129                                    // 0000000A0624: 7E880381
	v_mov_b32_e32 v69, v129                                    // 0000000A0628: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 0000000A062C: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 0000000A0630: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 0000000A0634: 7E900381
	s_add_u32 s6, s8, s4                                       // 0000000A0638: 80060408
	s_addc_u32 s5, s9, s5                                      // 0000000A063C: 82050509
	s_mov_b32 s7, 0                                            // 0000000A0640: BE870080
	s_branch 117                                               // 0000000A0644: BFA00075 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x91c>
	ds_load_b128 v[146:149], v170                              // 0000000A0648: DBFC0000 920000AA
	ds_load_b128 v[150:153], v170 offset:16                    // 0000000A0650: DBFC0010 960000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A0658: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[146:153], v[121:128]// 0000000A065C: CC414079 1DE72582
	ds_load_b128 v[150:153], v170 offset:784                   // 0000000A0664: DBFC0310 960000AA
	ds_load_b128 v[146:149], v170 offset:768                   // 0000000A066C: DBFC0300 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A0674: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[146:153], v[113:120]// 0000000A0678: CC414071 1DC72582
	ds_load_b128 v[150:153], v170 offset:1552                  // 0000000A0680: DBFC0610 960000AA
	ds_load_b128 v[146:149], v170 offset:1536                  // 0000000A0688: DBFC0600 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A0690: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[146:153], v[105:112]// 0000000A0694: CC414069 1DA72582
	ds_load_b128 v[150:153], v170 offset:2320                  // 0000000A069C: DBFC0910 960000AA
	ds_load_b128 v[146:149], v170 offset:2304                  // 0000000A06A4: DBFC0900 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A06AC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[146:153], v[97:104]// 0000000A06B0: CC414061 1D872582
	ds_load_b128 v[150:153], v170 offset:3088                  // 0000000A06B8: DBFC0C10 960000AA
	ds_load_b128 v[146:149], v170 offset:3072                  // 0000000A06C0: DBFC0C00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A06C8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[146:153], v[89:96]// 0000000A06CC: CC414059 1D672582
	ds_load_b128 v[150:153], v170 offset:3856                  // 0000000A06D4: DBFC0F10 960000AA
	ds_load_b128 v[146:149], v170 offset:3840                  // 0000000A06DC: DBFC0F00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A06E4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[146:153], v[81:88]// 0000000A06E8: CC414051 1D472582
	ds_load_b128 v[150:153], v170 offset:4624                  // 0000000A06F0: DBFC1210 960000AA
	ds_load_b128 v[146:149], v170 offset:4608                  // 0000000A06F8: DBFC1200 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A0700: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[146:153], v[73:80]// 0000000A0704: CC414049 1D272582
	ds_load_b128 v[150:153], v170 offset:5392                  // 0000000A070C: DBFC1510 960000AA
	ds_load_b128 v[146:149], v170 offset:5376                  // 0000000A0714: DBFC1500 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A071C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[146:153], v[65:72]// 0000000A0720: CC414041 1D072582
	ds_load_b128 v[150:153], v170 offset:6160                  // 0000000A0728: DBFC1810 960000AA
	ds_load_b128 v[146:149], v170 offset:6144                  // 0000000A0730: DBFC1800 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A0738: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[146:153], v[57:64]// 0000000A073C: CC414039 1CE72582
	ds_load_b128 v[150:153], v170 offset:6928                  // 0000000A0744: DBFC1B10 960000AA
	ds_load_b128 v[146:149], v170 offset:6912                  // 0000000A074C: DBFC1B00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A0754: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[146:153], v[49:56]// 0000000A0758: CC414031 1CC72582
	ds_load_b128 v[150:153], v170 offset:7696                  // 0000000A0760: DBFC1E10 960000AA
	ds_load_b128 v[146:149], v170 offset:7680                  // 0000000A0768: DBFC1E00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A0770: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[146:153], v[41:48]// 0000000A0774: CC414029 1CA72582
	ds_load_b128 v[150:153], v170 offset:8464                  // 0000000A077C: DBFC2110 960000AA
	ds_load_b128 v[146:149], v170 offset:8448                  // 0000000A0784: DBFC2100 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A078C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[146:153], v[33:40]// 0000000A0790: CC414021 1C872582
	ds_load_b128 v[150:153], v170 offset:9232                  // 0000000A0798: DBFC2410 960000AA
	ds_load_b128 v[146:149], v170 offset:9216                  // 0000000A07A0: DBFC2400 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A07A8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[146:153], v[25:32]// 0000000A07AC: CC414019 1C672582
	ds_load_b128 v[150:153], v170 offset:10000                 // 0000000A07B4: DBFC2710 960000AA
	ds_load_b128 v[146:149], v170 offset:9984                  // 0000000A07BC: DBFC2700 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A07C4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[146:153], v[17:24]// 0000000A07C8: CC414011 1C472582
	ds_load_b128 v[150:153], v170 offset:10768                 // 0000000A07D0: DBFC2A10 960000AA
	ds_load_b128 v[146:149], v170 offset:10752                 // 0000000A07D8: DBFC2A00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A07E0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[146:153], v[9:16]// 0000000A07E4: CC414009 1C272582
	ds_load_b128 v[150:153], v170 offset:11536                 // 0000000A07EC: DBFC2D10 960000AA
	ds_load_b128 v[146:149], v170 offset:11520                 // 0000000A07F4: DBFC2D00 920000AA
	s_waitcnt lgkmcnt(0)                                       // 0000000A07FC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[146:153], v[1:8]// 0000000A0800: CC414001 1C072582
	v_add_nc_u32_e32 v176, 16, v176                            // 0000000A0808: 4B616090
	s_add_i32 s1, s7, 1                                        // 0000000A080C: 81018107
	s_cmp_eq_u32 s7, s12                                       // 0000000A0810: BF060C07
	s_mov_b32 s7, s1                                           // 0000000A0814: BE870001
	s_cbranch_scc1 1968                                        // 0000000A0818: BFA207B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x27dc>
	s_and_not1_b32 vcc_lo, exec_lo, s22                        // 0000000A081C: 916A167E
	s_mov_b32 s1, s13                                          // 0000000A0820: BE81000D
	s_cbranch_vccnz 13                                         // 0000000A0824: BFA4000D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x95c>
	s_lshr_b32 s1, s7, 3                                       // 0000000A0828: 85018307
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000A082C: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 0000000A0830: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 0000000A0838: 7F040201
	global_load_b32 v130, v130, s[20:21]                       // 0000000A083C: DC520000 82140082
	s_waitcnt vmcnt(0)                                         // 0000000A0844: BF8903F7
	v_lshrrev_b32_e32 v130, s7, v130                           // 0000000A0848: 33050407
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A084C: BF870091
	v_and_b32_e32 v130, 1, v130                                // 0000000A0850: 37050481
	.long 0xd44a0001                                           // 0000000A0854: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000A0858: 02030481
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A085C: BF870001
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000000A0860: 916A017E
	s_cbranch_vccnz 65512                                      // 0000000A0864: BFA4FFE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x908>
	s_lshl_b32 s2, s7, 4                                       // 0000000A0868: 84028407
	s_waitcnt vmcnt(0)                                         // 0000000A086C: BF8903F7
	s_barrier                                                  // 0000000A0870: BFBD0000
	buffer_gl0_inv                                             // 0000000A0874: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000000A087C: BE812000
	s_cbranch_execz 119                                        // 0000000A0880: BFA50077 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb60>
	v_dual_mov_b32 v130, v176 :: v_dual_mov_b32 v131, v175     // 0000000A0884: CA1001B0 828201AF
	v_mov_b32_e32 v132, v174                                   // 0000000A088C: 7F0803AE
	s_mov_b32 s4, 0                                            // 0000000A0890: BE840080
	s_nop 0                                                    // 0000000A0894: BF800000
	s_nop 0                                                    // 0000000A0898: BF800000
	s_nop 0                                                    // 0000000A089C: BF800000
	s_nop 0                                                    // 0000000A08A0: BF800000
	s_nop 0                                                    // 0000000A08A4: BF800000
	s_nop 0                                                    // 0000000A08A8: BF800000
	s_nop 0                                                    // 0000000A08AC: BF800000
	s_nop 0                                                    // 0000000A08B0: BF800000
	s_nop 0                                                    // 0000000A08B4: BF800000
	s_nop 0                                                    // 0000000A08B8: BF800000
	s_nop 0                                                    // 0000000A08BC: BF800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A08C0: BF870112
	v_min_i32_e32 v133, s15, v130                              // 0000000A08C4: 230B040F
	v_add_nc_u32_e32 v132, 0x180, v132                         // 0000000A08C8: 4B0908FF 00000180
	v_add_nc_u32_e32 v130, 12, v130                            // 0000000A08D0: 4B05048C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000A08D4: BF8701B3
	v_ashrrev_i32_e32 v135, 31, v133                           // 0000000A08D8: 350F0A9F
	.long 0xd72c0088                                           // 0000000A08DC: D72C0088
	v_cndmask_b32_e32 v1, s11, v133, vcc_lo                    // 0000000A08E0: 02030A0B
	v_mad_u64_u32 v[133:134], null, s10, v133, 0               // 0000000A08E4: D6FE7C85 02030A0A
	.long 0xd72c0087                                           // 0000000A08EC: D72C0087
	v_cndmask_b32_e32 v1, s10, v135, vcc_lo                    // 0000000A08F0: 02030E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A08F4: BF870091
	v_add3_u32 v134, v134, v135, v136                          // 0000000A08F8: D6550086 06230F86
	.long 0xd73c0085                                           // 0000000A0900: D73C0085
	v_cndmask_b32_e32 v1, 1, v133, vcc_lo                      // 0000000A0904: 02030A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0908: BF870091
	.long 0xd7006a85                                           // 0000000A090C: D7006A85
	v_cndmask_b32_e32 v1, v171, v133, vcc_lo                   // 0000000A0910: 02030BAB
	v_add_co_ci_u32_e64 v134, null, v172, v134, vcc_lo         // 0000000A0914: D5207C86 01AB0DAC
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v132                        // 0000000A091C: 7C9308FF 0000007F
	global_load_b128 v[133:136], v[133:134], off               // 0000000A0924: DC5E0000 857C0085
	s_or_b32 s4, vcc_lo, s4                                    // 0000000A092C: 8C04046A
	s_waitcnt vmcnt(0)                                         // 0000000A0930: BF8903F7
	ds_store_b128 v131, v[133:136] offset:31488                // 0000000A0934: DB7C7B00 00008583
	v_add_nc_u32_e32 v131, 0x18c0, v131                        // 0000000A093C: 4B0706FF 000018C0
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A0944: 917E047E
	s_cbranch_execnz 65501                                     // 0000000A0948: BFA6FFDD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A094C: 8C7E047E
	v_or_b32_e32 v130, s2, v154                                // 0000000A0950: 39053402
	s_mov_b32 s4, 0                                            // 0000000A0954: BE840080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0958: BF870091
	v_min_i32_e32 v130, s15, v130                              // 0000000A095C: 2305040F
	v_ashrrev_i32_e32 v132, 31, v130                           // 0000000A0960: 3509049F
	.long 0xd72c0085                                           // 0000000A0964: D72C0085
	v_cndmask_b32_e32 v1, s11, v130, vcc_lo                    // 0000000A0968: 0203040B
	v_mad_u64_u32 v[130:131], null, s10, v130, 0               // 0000000A096C: D6FE7C82 0203040A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0974: BF870093
	.long 0xd72c0084                                           // 0000000A0978: D72C0084
	v_cndmask_b32_e32 v1, s10, v132, vcc_lo                    // 0000000A097C: 0203080A
	v_add3_u32 v131, v131, v132, v133                          // 0000000A0980: D6550083 06170983
	v_mov_b32_e32 v133, v174                                   // 0000000A0988: 7F0A03AE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A098C: BF870122
	.long 0xd73c0083                                           // 0000000A0990: D73C0083
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000A0994: 02030481
	v_mov_b32_e32 v130, v0                                     // 0000000A0998: 7F040300
	.long 0xd7006a83                                           // 0000000A099C: D7006A83
	v_cndmask_b32_e32 v1, s6, v131, vcc_lo                     // 0000000A09A0: 02030606
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A09A4: BF870001
	v_add_co_ci_u32_e64 v132, null, s5, v132, vcc_lo           // 0000000A09A8: D5207C84 01AB0805
	s_set_inst_prefetch_distance 0x1                           // 0000000A09B0: BF840001
	s_nop 0                                                    // 0000000A09B4: BF800000
	s_nop 0                                                    // 0000000A09B8: BF800000
	s_nop 0                                                    // 0000000A09BC: BF800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000A09C0: BF8701B3
	v_and_b32_e32 v146, 0xf8, v130                             // 0000000A09C4: 372504FF 000000F8
	v_add_nc_u32_e32 v133, 0x180, v133                         // 0000000A09CC: 4B0B0AFF 00000180
	v_add_nc_u32_e32 v130, 0xc0, v130                          // 0000000A09D4: 4B0504FF 000000C0
	v_lshlrev_b32_e32 v134, 1, v146                            // 0000000A09DC: 310D2481
	v_mad_u32_u24 v146, v146, 48, v173                         // 0000000A09E0: D60B0092 06B56192
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A09E8: BF870092
	.long 0xd7006a86                                           // 0000000A09EC: D7006A86
	v_cndmask_b32_e32 v1, v131, v134, vcc_lo                   // 0000000A09F0: 02030D83
	v_add_co_ci_u32_e64 v135, null, 0, v132, vcc_lo            // 0000000A09F4: D5207C87 01AB0880
	v_cmp_lt_u32_e32 vcc_lo, 0x7f, v133                        // 0000000A09FC: 7C930AFF 0000007F
	global_load_b128 v[134:137], v[134:135], off               // 0000000A0A04: DC5E0000 867C0086
	s_waitcnt vmcnt(0)                                         // 0000000A0A0C: BF8903F7
	ds_store_b16 v146, v134                                    // 0000000A0A10: D87C0000 00008692
	ds_store_b16_d16_hi v146, v134 offset:48                   // 0000000A0A18: DA840030 00008692
	ds_store_b16 v146, v135 offset:96                          // 0000000A0A20: D87C0060 00008792
	ds_store_b16_d16_hi v146, v135 offset:144                  // 0000000A0A28: DA840090 00008792
	ds_store_b16 v146, v136 offset:192                         // 0000000A0A30: D87C00C0 00008892
	ds_store_b16_d16_hi v146, v136 offset:240                  // 0000000A0A38: DA8400F0 00008892
	ds_store_b16 v146, v137 offset:288                         // 0000000A0A40: D87C0120 00008992
	ds_store_b16_d16_hi v146, v137 offset:336                  // 0000000A0A48: DA840150 00008992
	s_or_b32 s4, vcc_lo, s4                                    // 0000000A0A50: 8C04046A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A0A54: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A0A58: 917E047E
	s_cbranch_execnz 65496                                     // 0000000A0A5C: BFA6FFD8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac0>
	s_set_inst_prefetch_distance 0x2                           // 0000000A0A60: BF840002
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A0A64: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 0000000A0A68: BF89FC07
	s_barrier                                                  // 0000000A0A6C: BFBD0000
	buffer_gl0_inv                                             // 0000000A0A70: E0AC0000 00000000
	s_clause 0x3                                               // 0000000A0A78: BF850003
	global_load_b128 v[150:153], v[143:144], off offset:16     // 0000000A0A7C: DC5E0010 967C008F
	global_load_b128 v[146:149], v[143:144], off               // 0000000A0A84: DC5E0000 927C008F
	global_load_b128 v[181:184], v[143:144], off offset:48     // 0000000A0A8C: DC5E0030 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:32     // 0000000A0A94: DC5E0020 B17C008F
	ds_load_b128 v[185:188], v159                              // 0000000A0A9C: DBFC0000 B900009F
	ds_load_b128 v[189:192], v159 offset:16                    // 0000000A0AA4: DBFC0010 BD00009F
	v_mov_b32_e32 v136, v129                                   // 0000000A0AAC: 7F100381
	v_mov_b32_e32 v130, v129                                   // 0000000A0AB0: 7F040381
	v_mov_b32_e32 v131, v129                                   // 0000000A0AB4: 7F060381
	v_mov_b32_e32 v132, v129                                   // 0000000A0AB8: 7F080381
	v_mov_b32_e32 v133, v129                                   // 0000000A0ABC: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 0000000A0AC0: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 0000000A0AC4: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 0000000A0AC8: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000A0ACC: BF870212
	v_mov_b32_e32 v136, v135                                   // 0000000A0AD0: 7F100387
	v_mov_b32_e32 v135, v134                                   // 0000000A0AD4: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 0000000A0AD8: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 0000000A0ADC: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 0000000A0AE0: 7F080383
	v_mov_b32_e32 v131, v130                                   // 0000000A0AE4: 7F060382
	v_mov_b32_e32 v130, v129                                   // 0000000A0AE8: 7F040381
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0AEC: BF890807
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A0AF0: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 0000000A0AF4: CC414082 1E0B7392
	s_clause 0x1                                               // 0000000A0AFC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:80     // 0000000A0B00: DC5E0050 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:64     // 0000000A0B08: DC5E0040 927C008F
	ds_load_b128 v[185:188], v159 offset:32                    // 0000000A0B10: DBFC0020 B900009F
	ds_load_b128 v[189:192], v159 offset:48                    // 0000000A0B18: DBFC0030 BD00009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0B20: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000A0B24: CC414082 1E0B73B1
	s_clause 0x1                                               // 0000000A0B2C: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:112    // 0000000A0B30: DC5E0070 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:96     // 0000000A0B38: DC5E0060 B17C008F
	ds_load_b128 v[189:192], v159 offset:80                    // 0000000A0B40: DBFC0050 BD00009F
	ds_load_b128 v[185:188], v159 offset:64                    // 0000000A0B48: DBFC0040 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0B50: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 0000000A0B54: CC414082 1E0B7392
	s_clause 0x1                                               // 0000000A0B5C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:144    // 0000000A0B60: DC5E0090 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:128    // 0000000A0B68: DC5E0080 927C008F
	ds_load_b128 v[189:192], v159 offset:112                   // 0000000A0B70: DBFC0070 BD00009F
	ds_load_b128 v[185:188], v159 offset:96                    // 0000000A0B78: DBFC0060 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0B80: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000A0B84: CC414082 1E0B73B1
	s_clause 0x1                                               // 0000000A0B8C: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:176    // 0000000A0B90: DC5E00B0 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:160    // 0000000A0B98: DC5E00A0 B17C008F
	ds_load_b128 v[189:192], v159 offset:144                   // 0000000A0BA0: DBFC0090 BD00009F
	ds_load_b128 v[185:188], v159 offset:128                   // 0000000A0BA8: DBFC0080 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0BB0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 0000000A0BB4: CC414082 1E0B7392
	s_clause 0x1                                               // 0000000A0BBC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:208    // 0000000A0BC0: DC5E00D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:192    // 0000000A0BC8: DC5E00C0 927C008F
	ds_load_b128 v[189:192], v159 offset:176                   // 0000000A0BD0: DBFC00B0 BD00009F
	ds_load_b128 v[185:188], v159 offset:160                   // 0000000A0BD8: DBFC00A0 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0BE0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000A0BE4: CC414082 1E0B73B1
	s_clause 0x1                                               // 0000000A0BEC: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:240    // 0000000A0BF0: DC5E00F0 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:224    // 0000000A0BF8: DC5E00E0 B17C008F
	ds_load_b128 v[189:192], v159 offset:208                   // 0000000A0C00: DBFC00D0 BD00009F
	ds_load_b128 v[185:188], v159 offset:192                   // 0000000A0C08: DBFC00C0 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0C10: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 0000000A0C14: CC414082 1E0B7392
	s_clause 0x1                                               // 0000000A0C1C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:272    // 0000000A0C20: DC5E0110 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:256    // 0000000A0C28: DC5E0100 927C008F
	ds_load_b128 v[189:192], v159 offset:240                   // 0000000A0C30: DBFC00F0 BD00009F
	ds_load_b128 v[185:188], v159 offset:224                   // 0000000A0C38: DBFC00E0 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0C40: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000A0C44: CC414082 1E0B73B1
	s_clause 0x1                                               // 0000000A0C4C: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:304    // 0000000A0C50: DC5E0130 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:288    // 0000000A0C58: DC5E0120 B17C008F
	ds_load_b128 v[189:192], v159 offset:272                   // 0000000A0C60: DBFC0110 BD00009F
	ds_load_b128 v[185:188], v159 offset:256                   // 0000000A0C68: DBFC0100 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0C70: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 0000000A0C74: CC414082 1E0B7392
	s_clause 0x1                                               // 0000000A0C7C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:336    // 0000000A0C80: DC5E0150 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:320    // 0000000A0C88: DC5E0140 927C008F
	ds_load_b128 v[189:192], v159 offset:304                   // 0000000A0C90: DBFC0130 BD00009F
	ds_load_b128 v[185:188], v159 offset:288                   // 0000000A0C98: DBFC0120 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0CA0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000A0CA4: CC414082 1E0B73B1
	s_clause 0x1                                               // 0000000A0CAC: BF850001
	global_load_b128 v[181:184], v[143:144], off offset:368    // 0000000A0CB0: DC5E0170 B57C008F
	global_load_b128 v[177:180], v[143:144], off offset:352    // 0000000A0CB8: DC5E0160 B17C008F
	ds_load_b128 v[189:192], v159 offset:336                   // 0000000A0CC0: DBFC0150 BD00009F
	ds_load_b128 v[185:188], v159 offset:320                   // 0000000A0CC8: DBFC0140 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0CD0: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[185:192], v[130:137]// 0000000A0CD4: CC414082 1E0B7392
	s_clause 0x1                                               // 0000000A0CDC: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:400    // 0000000A0CE0: DC5E0190 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:384    // 0000000A0CE8: DC5E0180 927C008F
	ds_load_b128 v[189:192], v159 offset:368                   // 0000000A0CF0: DBFC0170 BD00009F
	ds_load_b128 v[185:188], v159 offset:352                   // 0000000A0CF8: DBFC0160 B900009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0D00: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[177:184], v[185:192], v[130:137]// 0000000A0D04: CC414082 1E0B73B1
	ds_load_b128 v[181:184], v159 offset:400                   // 0000000A0D0C: DBFC0190 B500009F
	ds_load_b128 v[177:180], v159 offset:384                   // 0000000A0D14: DBFC0180 B100009F
	s_clause 0x1                                               // 0000000A0D1C: BF850001
	global_load_b128 v[189:192], v[143:144], off offset:432    // 0000000A0D20: DC5E01B0 BD7C008F
	global_load_b128 v[185:188], v[143:144], off offset:416    // 0000000A0D28: DC5E01A0 B97C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0D30: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000A0D34: CC414082 1E0B6392
	s_clause 0x1                                               // 0000000A0D3C: BF850001
	global_load_b128 v[150:153], v[143:144], off offset:464    // 0000000A0D40: DC5E01D0 967C008F
	global_load_b128 v[146:149], v[143:144], off offset:448    // 0000000A0D48: DC5E01C0 927C008F
	ds_load_b128 v[181:184], v159 offset:432                   // 0000000A0D50: DBFC01B0 B500009F
	ds_load_b128 v[177:180], v159 offset:416                   // 0000000A0D58: DBFC01A0 B100009F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0D60: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[185:192], v[177:184], v[130:137]// 0000000A0D64: CC414082 1E0B63B9
	ds_load_b128 v[181:184], v159 offset:464                   // 0000000A0D6C: DBFC01D0 B500009F
	ds_load_b128 v[177:180], v159 offset:448                   // 0000000A0D74: DBFC01C0 B100009F
	s_clause 0x1                                               // 0000000A0D7C: BF850001
	global_load_b128 v[189:192], v[143:144], off offset:496    // 0000000A0D80: DC5E01F0 BD7C008F
	global_load_b128 v[185:188], v[143:144], off offset:480    // 0000000A0D88: DC5E01E0 B97C008F
	s_waitcnt vmcnt(2) lgkmcnt(0)                              // 0000000A0D90: BF890807
	v_wmma_f32_16x16x16_bf16 v[130:137], v[146:153], v[177:184], v[130:137]// 0000000A0D94: CC414082 1E0B6392
	ds_load_b128 v[150:153], v159 offset:496                   // 0000000A0D9C: DBFC01F0 9600009F
	ds_load_b128 v[146:149], v159 offset:480                   // 0000000A0DA4: DBFC01E0 9200009F
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A0DAC: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[185:192], v[146:153], v[130:137]// 0000000A0DB0: CC414082 1E0B25B9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A0DB8: BF870111
	v_dual_mul_f32 v130, 0x3d800000, v130 :: v_dual_mul_f32 v131, 0x3d800000, v131// 0000000A0DBC: C8C704FF 828306FF 3D800000
	v_mul_f32_e32 v146, 0x3d800000, v133                       // 0000000A0DC8: 11250AFF 3D800000
	v_mov_b32_e32 v133, 0xffff                                 // 0000000A0DD0: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A0DD8: BF870004
	v_mul_f32_e32 v132, 0x3d800000, v132                       // 0000000A0DDC: 110908FF 3D800000
	v_dual_mul_f32 v134, 0x3d800000, v134 :: v_dual_mul_f32 v135, 0x3d800000, v135// 0000000A0DE4: C8C70CFF 86870EFF 3D800000
	v_dual_mul_f32 v136, 0x3d800000, v136 :: v_dual_mul_f32 v137, 0x3d800000, v137// 0000000A0DF0: C8C710FF 888912FF 3D800000
	ds_store_2addr_b32 v160, v130, v131 offset1:34             // 0000000A0DFC: D8382200 008382A0
	ds_store_2addr_b32 v160, v132, v146 offset0:68 offset1:102 // 0000000A0E04: D8386644 009284A0
	ds_store_2addr_b32 v160, v134, v135 offset0:136 offset1:170// 0000000A0E0C: D838AA88 008786A0
	ds_store_2addr_b32 v160, v136, v137 offset0:204 offset1:238// 0000000A0E14: D838EECC 008988A0
	s_waitcnt lgkmcnt(0)                                       // 0000000A0E1C: BF89FC07
	s_barrier                                                  // 0000000A0E20: BFBD0000
	buffer_gl0_inv                                             // 0000000A0E24: E0AC0000 00000000
	s_and_saveexec_b32 s4, s23                                 // 0000000A0E2C: BE842017
	s_cbranch_execz 359                                        // 0000000A0E30: BFA50167 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14d0>
	s_lshl_b32 s8, s7, 2                                       // 0000000A0E34: 84088207
	s_mov_b32 s9, exec_lo                                      // 0000000A0E38: BE89007E
	.long 0xd4c1007e                                           // 0000000A0E3C: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 0000000A0E40: 02033D91
	s_cbranch_execz 44                                         // 0000000A0E44: BFA5002C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff8>
	v_ashrrev_i32_e32 v146, 31, v145                           // 0000000A0E48: 3525229F
	s_mov_b32 s24, 0                                           // 0000000A0E4C: BE980080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0E50: BF870091
	.long 0xd73c0082                                           // 0000000A0E54: D73C0082
	v_cndmask_b32_e32 v1, 2, v145, vcc_lo                      // 0000000A0E58: 02032282
	.long 0xd7006a82                                           // 0000000A0E5C: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 0000000A0E60: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A0E64: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 0000000A0E68: D5207C83 01AB078E
	s_branch 11                                                // 0000000A0E70: BFA0000B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xfa0>
	s_nop 0                                                    // 0000000A0E74: BF800000
	s_nop 0                                                    // 0000000A0E78: BF800000
	s_nop 0                                                    // 0000000A0E7C: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 0000000A0E80: 8C7E1A7E
	v_mov_b32_e32 v133, v145                                   // 0000000A0E84: 7F0A0391
	v_mov_b32_e32 v145, v132                                   // 0000000A0E88: 7F220384
	s_and_b32 s1, exec_lo, s25                                 // 0000000A0E8C: 8B01197E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000A0E90: BF870499
	s_or_b32 s24, s1, s24                                      // 0000000A0E94: 8C181801
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 0000000A0E98: 917E187E
	s_cbranch_execz 20                                         // 0000000A0E9C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xff0>
	global_load_b32 v132, v[130:131], off                      // 0000000A0EA0: DC520000 847C0082
	s_or_b32 s25, s25, exec_lo                                 // 0000000A0EA8: 8C197E19
	s_waitcnt vmcnt(0)                                         // 0000000A0EAC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s8, v132                          // 0000000A0EB0: 7C890808
	s_and_saveexec_b32 s26, vcc_lo                             // 0000000A0EB4: BE9A206A
	s_cbranch_execz 65521                                      // 0000000A0EB8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	v_dual_mov_b32 v145, v158 :: v_dual_add_nc_u32 v132, 1, v145// 0000000A0EBC: CA20019E 91852281
	.long 0xd7000182                                           // 0000000A0EC4: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 0000000A0EC8: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A0ECC: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 0000000A0ED0: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v158, v132                        // 0000000A0ED8: 7C95099E
	s_and_not1_b32 s1, s25, exec_lo                            // 0000000A0EDC: 91017E19
	s_and_b32 s25, vcc_lo, exec_lo                             // 0000000A0EE0: 8B197E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A0EE4: BF870009
	s_or_b32 s25, s1, s25                                      // 0000000A0EE8: 8C191901
	s_branch 65508                                             // 0000000A0EEC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf80>
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000A0EF0: 8C7E187E
	v_mov_b32_e32 v145, v133                                   // 0000000A0EF4: 7F220385
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000A0EF8: 8C7E097E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A0EFC: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v145       // 0000000A0F00: CA10008F 85820191
	s_mov_b32 s1, exec_lo                                      // 0000000A0F08: BE81007E
	.long 0xd4c1007e                                           // 0000000A0F0C: D4C1007E
	v_cndmask_b32_e32 v1, s8, v161, vcc_lo                     // 0000000A0F10: 02034208
	s_cbranch_execz 62                                         // 0000000A0F14: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1110>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v145        // 0000000A0F18: CA100080 85820191
	s_mov_b32 s9, exec_lo                                      // 0000000A0F20: BE89007E
	.long 0xd4c1007e                                           // 0000000A0F24: D4C1007E
	v_cndmask_b32_e32 v1, v145, v158, vcc_lo                   // 0000000A0F28: 02033D91
	s_cbranch_execz 54                                         // 0000000A0F2C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1108>
	v_mov_b32_e32 v130, v145                                   // 0000000A0F30: 7F040391
	s_mov_b32 s25, 0                                           // 0000000A0F34: BE990080
	s_set_inst_prefetch_distance 0x1                           // 0000000A0F38: BF840001
	s_branch 10                                                // 0000000A0F3C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1068>
	s_or_b32 exec_lo, exec_lo, s28                             // 0000000A0F40: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000A0F44: BF870499
	s_and_b32 s28, exec_lo, s27                                // 0000000A0F48: 8B1C1B7E
	s_or_b32 s25, s28, s25                                     // 0000000A0F4C: 8C19191C
	s_and_not1_b32 s24, s24, exec_lo                           // 0000000A0F50: 91187E18
	s_and_b32 s28, s26, exec_lo                                // 0000000A0F54: 8B1C7E1A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A0F58: BF870009
	s_or_b32 s24, s24, s28                                     // 0000000A0F5C: 8C181C18
	s_and_not1_b32 exec_lo, exec_lo, s25                       // 0000000A0F60: 917E197E
	s_cbranch_execz 28                                         // 0000000A0F64: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10d8>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A0F68: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 0000000A0F6C: 7F060382
	s_or_b32 s26, s26, exec_lo                                 // 0000000A0F70: 8C1A7E1A
	s_or_b32 s27, s27, exec_lo                                 // 0000000A0F74: 8C1B7E1B
	s_mov_b32 s28, exec_lo                                     // 0000000A0F78: BE9C007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000A0F7C: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0F80: BF870091
	.long 0xd73c0084                                           // 0000000A0F84: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000A0F88: 02030682
	.long 0xd7006a84                                           // 0000000A0F8C: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 0000000A0F90: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A0F94: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 0000000A0F98: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 0000000A0FA0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 0000000A0FA8: BF8903F7
	.long 0xd4c4007e                                           // 0000000A0FAC: D4C4007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 0000000A0FB0: 02030808
	s_cbranch_execz 65506                                      // 0000000A0FB4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000A0FB8: 4B050681
	s_and_not1_b32 s27, s27, exec_lo                           // 0000000A0FBC: 911B7E1B
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000A0FC0: 911A7E1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000A0FC4: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000A0FC8: 7C95059E
	s_and_b32 s29, vcc_lo, exec_lo                             // 0000000A0FCC: 8B1D7E6A
	s_or_b32 s27, s27, s29                                     // 0000000A0FD0: 8C1B1D1B
	s_branch 65498                                             // 0000000A0FD4: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	s_set_inst_prefetch_distance 0x2                           // 0000000A0FD8: BF840002
	s_or_b32 exec_lo, exec_lo, s25                             // 0000000A0FDC: 8C7E197E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v158        // 0000000A0FE0: CA100080 8582019E
	s_and_saveexec_b32 s25, s24                                // 0000000A0FE8: BE992018
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A0FEC: BF870009
	s_xor_b32 s24, exec_lo, s25                                // 0000000A0FF0: 8D18197E
	v_cmp_eq_u32_e32 vcc_lo, s8, v132                          // 0000000A0FF4: 7C950808
	v_mov_b32_e32 v130, v131                                   // 0000000A0FF8: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 0000000A0FFC: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000A1004: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1008: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000A100C: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1010: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A1014: 8C7E017E
	s_or_b32 s9, s8, 1                                         // 0000000A1018: 8C098108
	s_mov_b32 s1, exec_lo                                      // 0000000A101C: BE81007E
	.long 0xd4c6007e                                           // 0000000A1020: D4C6007E
	v_cndmask_b32_e32 v1, s9, v161, vcc_lo                     // 0000000A1024: 02034209
	s_xor_b32 s1, exec_lo, s1                                  // 0000000A1028: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 0000000A102C: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 0000000A1034: BE813001
	s_cbranch_execz 70                                         // 0000000A1038: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1254>
	s_mov_b32 s24, exec_lo                                     // 0000000A103C: BE98007E
	.long 0xd4c1007e                                           // 0000000A1040: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 0000000A1044: 02033D82
	s_cbranch_execz 64                                         // 0000000A1048: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x124c>
	s_mov_b32 s26, 0                                           // 0000000A104C: BE9A0080
	s_set_inst_prefetch_distance 0x1                           // 0000000A1050: BF840001
	s_branch 20                                                // 0000000A1054: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11a8>
	s_nop 0                                                    // 0000000A1058: BF800000
	s_nop 0                                                    // 0000000A105C: BF800000
	s_nop 0                                                    // 0000000A1060: BF800000
	s_nop 0                                                    // 0000000A1064: BF800000
	s_nop 0                                                    // 0000000A1068: BF800000
	s_nop 0                                                    // 0000000A106C: BF800000
	s_nop 0                                                    // 0000000A1070: BF800000
	s_nop 0                                                    // 0000000A1074: BF800000
	s_nop 0                                                    // 0000000A1078: BF800000
	s_nop 0                                                    // 0000000A107C: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 0000000A1080: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000A1084: BF870499
	s_and_b32 s29, exec_lo, s28                                // 0000000A1088: 8B1D1C7E
	s_or_b32 s26, s29, s26                                     // 0000000A108C: 8C1A1A1D
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000A1090: 91197E19
	s_and_b32 s29, s27, exec_lo                                // 0000000A1094: 8B1D7E1B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1098: BF870009
	s_or_b32 s25, s25, s29                                     // 0000000A109C: 8C191D19
	s_and_not1_b32 exec_lo, exec_lo, s26                       // 0000000A10A0: 917E1A7E
	s_cbranch_execz 27                                         // 0000000A10A4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1214>
	v_mov_b32_e32 v131, v130                                   // 0000000A10A8: 7F060382
	s_or_b32 s27, s27, exec_lo                                 // 0000000A10AC: 8C1B7E1B
	s_or_b32 s28, s28, exec_lo                                 // 0000000A10B0: 8C1C7E1C
	s_mov_b32 s29, exec_lo                                     // 0000000A10B4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A10B8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000A10BC: 3509069F
	.long 0xd73c0086                                           // 0000000A10C0: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000A10C4: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A10C8: BF870091
	.long 0xd7006a86                                           // 0000000A10CC: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 0000000A10D0: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 0000000A10D4: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 0000000A10DC: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 0000000A10E4: BF8903F7
	.long 0xd4c6007e                                           // 0000000A10E8: D4C6007E
	v_cndmask_b32_e32 v1, s8, v132, vcc_lo                     // 0000000A10EC: 02030808
	s_cbranch_execz 65507                                      // 0000000A10F0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000A10F4: 4B050681
	s_and_not1_b32 s28, s28, exec_lo                           // 0000000A10F8: 911C7E1C
	s_and_not1_b32 s27, s27, exec_lo                           // 0000000A10FC: 911B7E1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000A1100: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000A1104: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 0000000A1108: 8B1E7E6A
	s_or_b32 s28, s28, s30                                     // 0000000A110C: 8C1C1E1C
	s_branch 65499                                             // 0000000A1110: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1180>
	s_set_inst_prefetch_distance 0x2                           // 0000000A1114: BF840002
	s_or_b32 exec_lo, exec_lo, s26                             // 0000000A1118: 8C7E1A7E
	v_mov_b32_e32 v130, v158                                   // 0000000A111C: 7F04039E
	s_and_saveexec_b32 s26, s25                                // 0000000A1120: BE9A2019
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1124: BF870009
	s_xor_b32 s25, exec_lo, s26                                // 0000000A1128: 8D191A7E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 0000000A112C: 7C950809
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 0000000A1130: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A113C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000A1140: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 0000000A1144: 7F040383
	s_or_b32 exec_lo, exec_lo, s25                             // 0000000A1148: 8C7E197E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A114C: BF870009
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000A1150: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1154: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A1158: 8C7E017E
	s_or_b32 s9, s8, 2                                         // 0000000A115C: 8C098208
	s_mov_b32 s1, exec_lo                                      // 0000000A1160: BE81007E
	.long 0xd4c6007e                                           // 0000000A1164: D4C6007E
	v_cndmask_b32_e32 v1, s9, v161, vcc_lo                     // 0000000A1168: 02034209
	s_xor_b32 s1, exec_lo, s1                                  // 0000000A116C: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 0000000A1170: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 0000000A1178: BE813001
	s_cbranch_execz 69                                         // 0000000A117C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1394>
	s_mov_b32 s24, exec_lo                                     // 0000000A1180: BE98007E
	.long 0xd4c1007e                                           // 0000000A1184: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 0000000A1188: 02033D82
	s_cbranch_execz 63                                         // 0000000A118C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x138c>
	s_mov_b32 s26, 0                                           // 0000000A1190: BE9A0080
	s_set_inst_prefetch_distance 0x1                           // 0000000A1194: BF840001
	s_branch 19                                                // 0000000A1198: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12e8>
	s_nop 0                                                    // 0000000A119C: BF800000
	s_nop 0                                                    // 0000000A11A0: BF800000
	s_nop 0                                                    // 0000000A11A4: BF800000
	s_nop 0                                                    // 0000000A11A8: BF800000
	s_nop 0                                                    // 0000000A11AC: BF800000
	s_nop 0                                                    // 0000000A11B0: BF800000
	s_nop 0                                                    // 0000000A11B4: BF800000
	s_nop 0                                                    // 0000000A11B8: BF800000
	s_nop 0                                                    // 0000000A11BC: BF800000
	s_or_b32 exec_lo, exec_lo, s29                             // 0000000A11C0: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000A11C4: BF870499
	s_and_b32 s29, exec_lo, s28                                // 0000000A11C8: 8B1D1C7E
	s_or_b32 s26, s29, s26                                     // 0000000A11CC: 8C1A1A1D
	s_and_not1_b32 s25, s25, exec_lo                           // 0000000A11D0: 91197E19
	s_and_b32 s29, s27, exec_lo                                // 0000000A11D4: 8B1D7E1B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A11D8: BF870009
	s_or_b32 s25, s25, s29                                     // 0000000A11DC: 8C191D19
	s_and_not1_b32 exec_lo, exec_lo, s26                       // 0000000A11E0: 917E1A7E
	s_cbranch_execz 27                                         // 0000000A11E4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1354>
	v_mov_b32_e32 v131, v130                                   // 0000000A11E8: 7F060382
	s_or_b32 s27, s27, exec_lo                                 // 0000000A11EC: 8C1B7E1B
	s_or_b32 s28, s28, exec_lo                                 // 0000000A11F0: 8C1C7E1C
	s_mov_b32 s29, exec_lo                                     // 0000000A11F4: BE9D007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A11F8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 0000000A11FC: 3509069F
	.long 0xd73c0086                                           // 0000000A1200: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 0000000A1204: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1208: BF870091
	.long 0xd7006a86                                           // 0000000A120C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 0000000A1210: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 0000000A1214: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 0000000A121C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 0000000A1224: BF8903F7
	.long 0xd4c4007e                                           // 0000000A1228: D4C4007E
	v_cndmask_b32_e32 v1, s9, v132, vcc_lo                     // 0000000A122C: 02030809
	s_cbranch_execz 65507                                      // 0000000A1230: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 0000000A1234: 4B050681
	s_and_not1_b32 s28, s28, exec_lo                           // 0000000A1238: 911C7E1C
	s_and_not1_b32 s27, s27, exec_lo                           // 0000000A123C: 911B7E1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000A1240: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000A1244: 7C95059E
	s_and_b32 s30, vcc_lo, exec_lo                             // 0000000A1248: 8B1E7E6A
	s_or_b32 s28, s28, s30                                     // 0000000A124C: 8C1C1E1C
	s_branch 65499                                             // 0000000A1250: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000A1254: BF840002
	s_or_b32 exec_lo, exec_lo, s26                             // 0000000A1258: 8C7E1A7E
	v_mov_b32_e32 v130, v158                                   // 0000000A125C: 7F04039E
	s_and_saveexec_b32 s26, s25                                // 0000000A1260: BE9A2019
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1264: BF870009
	s_xor_b32 s25, exec_lo, s26                                // 0000000A1268: 8D191A7E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 0000000A126C: 7C950809
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 0000000A1270: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A127C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000A1280: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 0000000A1284: 7F040383
	s_or_b32 exec_lo, exec_lo, s25                             // 0000000A1288: 8C7E197E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A128C: BF870009
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000A1290: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1294: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A1298: 8C7E017E
	s_or_b32 s8, s8, 3                                         // 0000000A129C: 8C088308
	s_mov_b32 s1, exec_lo                                      // 0000000A12A0: BE81007E
	.long 0xd4c6007e                                           // 0000000A12A4: D4C6007E
	v_cndmask_b32_e32 v1, s8, v161, vcc_lo                     // 0000000A12A8: 02034208
	s_xor_b32 s1, exec_lo, s1                                  // 0000000A12AC: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 0000000A12B0: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 0000000A12B8: BE813001
	s_cbranch_execz 66                                         // 0000000A12BC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c8>
	s_mov_b32 s9, exec_lo                                      // 0000000A12C0: BE89007E
	.long 0xd4c1007e                                           // 0000000A12C4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v158, vcc_lo                   // 0000000A12C8: 02033D82
	s_cbranch_execz 60                                         // 0000000A12CC: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	s_mov_b32 s25, 0                                           // 0000000A12D0: BE990080
	s_set_inst_prefetch_distance 0x1                           // 0000000A12D4: BF840001
	s_branch 19                                                // 0000000A12D8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1428>
	s_nop 0                                                    // 0000000A12DC: BF800000
	s_nop 0                                                    // 0000000A12E0: BF800000
	s_nop 0                                                    // 0000000A12E4: BF800000
	s_nop 0                                                    // 0000000A12E8: BF800000
	s_nop 0                                                    // 0000000A12EC: BF800000
	s_nop 0                                                    // 0000000A12F0: BF800000
	s_nop 0                                                    // 0000000A12F4: BF800000
	s_nop 0                                                    // 0000000A12F8: BF800000
	s_nop 0                                                    // 0000000A12FC: BF800000
	s_or_b32 exec_lo, exec_lo, s28                             // 0000000A1300: 8C7E1C7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000A1304: BF870499
	s_and_b32 s28, exec_lo, s27                                // 0000000A1308: 8B1C1B7E
	s_or_b32 s25, s28, s25                                     // 0000000A130C: 8C19191C
	s_and_not1_b32 s24, s24, exec_lo                           // 0000000A1310: 91187E18
	s_and_b32 s28, s26, exec_lo                                // 0000000A1314: 8B1C7E1A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1318: BF870009
	s_or_b32 s24, s24, s28                                     // 0000000A131C: 8C181C18
	s_and_not1_b32 exec_lo, exec_lo, s25                       // 0000000A1320: 917E197E
	s_cbranch_execz 26                                         // 0000000A1324: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1490>
	v_ashrrev_i32_e32 v131, 31, v130                           // 0000000A1328: 3507049F
	s_or_b32 s26, s26, exec_lo                                 // 0000000A132C: 8C1A7E1A
	s_or_b32 s27, s27, exec_lo                                 // 0000000A1330: 8C1B7E1B
	s_mov_b32 s28, exec_lo                                     // 0000000A1334: BE9C007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1338: BF870091
	.long 0xd73c0083                                           // 0000000A133C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 0000000A1340: 02030482
	.long 0xd7006a83                                           // 0000000A1344: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 0000000A1348: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A134C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 0000000A1350: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 0000000A1358: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 0000000A1360: BF8903F7
	.long 0xd4c4007e                                           // 0000000A1364: D4C4007E
	v_cndmask_b32_e32 v1, s8, v131, vcc_lo                     // 0000000A1368: 02030608
	s_cbranch_execz 65508                                      // 0000000A136C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	v_add_nc_u32_e32 v130, 1, v130                             // 0000000A1370: 4B050481
	s_and_not1_b32 s27, s27, exec_lo                           // 0000000A1374: 911B7E1B
	s_and_not1_b32 s26, s26, exec_lo                           // 0000000A1378: 911A7E1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000A137C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v158, v130                        // 0000000A1380: 7C95059E
	s_and_b32 s29, vcc_lo, exec_lo                             // 0000000A1384: 8B1D7E6A
	s_or_b32 s27, s27, s29                                     // 0000000A1388: 8C1B1D1B
	s_branch 65500                                             // 0000000A138C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1400>
	s_set_inst_prefetch_distance 0x2                           // 0000000A1390: BF840002
	s_or_b32 exec_lo, exec_lo, s25                             // 0000000A1394: 8C7E197E
	s_and_saveexec_b32 s25, s24                                // 0000000A1398: BE992018
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A139C: BF870009
	s_xor_b32 s24, exec_lo, s25                                // 0000000A13A0: 8D18197E
	v_cmp_eq_u32_e32 vcc_lo, s8, v131                          // 0000000A13A4: 7C950608
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 0000000A13A8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A13B4: BF870001
	v_or_b32_e32 v133, v130, v133                              // 0000000A13B8: 390B0B82
	s_or_b32 exec_lo, exec_lo, s24                             // 0000000A13BC: 8C7E187E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A13C0: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 0000000A13C4: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A13C8: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A13CC: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A13D0: BF870009
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A13D4: 8C7E047E
	s_and_saveexec_b32 s4, s3                                  // 0000000A13D8: BE842003
	s_cbranch_execz 1029                                       // 0000000A13DC: BFA50405 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x24f4>
	ds_load_b32 v131, v163                                     // 0000000A13E0: D8D80000 830000A3
	v_and_b32_e32 v130, 1, v133                                // 0000000A13E8: 37050A81
	v_cmp_le_i32_e32 vcc_lo, s2, v162                          // 0000000A13EC: 7C874402
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A13F0: BF870002
	.long 0xd44a0001                                           // 0000000A13F4: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 0000000A13F8: 02030481
	s_and_b32 s37, vcc_lo, s1                                  // 0000000A13FC: 8B25016A
	s_waitcnt lgkmcnt(0)                                       // 0000000A1400: BF89FC07
	v_mov_b32_e32 v130, v131                                   // 0000000A1404: 7F040383
	s_and_saveexec_b32 s1, s37                                 // 0000000A1408: BE812025
	s_cbranch_execz 7                                          // 0000000A140C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x152c>
	ds_load_b32 v130, v164                                     // 0000000A1410: D8D80000 820000A4
	v_max_f32_e32 v132, v131, v131                             // 0000000A1418: 21090783
	s_waitcnt lgkmcnt(0)                                       // 0000000A141C: BF89FC07
	v_max_f32_e32 v130, v130, v130                             // 0000000A1420: 21050582
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A1424: BF870001
	v_max_f32_e32 v130, v132, v130                             // 0000000A1428: 21050584
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A142C: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 0000000A1430: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s2, v162                          // 0000000A1434: 7C834402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000A1438: BF8704A2
	.long 0xd44d0001                                           // 0000000A143C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A1440: 02030880
	s_and_b32 s36, vcc_lo, s1                                  // 0000000A1444: 8B24016A
	s_and_saveexec_b32 s1, s36                                 // 0000000A1448: BE812024
	s_cbranch_execz 7                                          // 0000000A144C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x156c>
	ds_load_b32 v132, v164 offset:4                            // 0000000A1450: D8D80004 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A1458: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A145C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A1460: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A1464: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A1468: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A146C: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 0000000A1470: 37090A84
	s_or_b32 s1, s2, 2                                         // 0000000A1474: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A1478: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000A147C: 7C874401
	.long 0xd44d0001                                           // 0000000A1480: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A1484: 02030880
	s_and_b32 s35, vcc_lo, s1                                  // 0000000A1488: 8B23016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A148C: BF870009
	s_and_saveexec_b32 s1, s35                                 // 0000000A1490: BE812023
	s_cbranch_execz 7                                          // 0000000A1494: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15b4>
	ds_load_b32 v132, v164 offset:8                            // 0000000A1498: D8D80008 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A14A0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A14A4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A14A8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A14AC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A14B0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A14B4: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 0000000A14B8: 37090A88
	s_or_b32 s1, s2, 3                                         // 0000000A14BC: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A14C0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000A14C4: 7C874401
	.long 0xd44d0001                                           // 0000000A14C8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A14CC: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 0000000A14D0: 8B22016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A14D4: BF870009
	s_and_saveexec_b32 s1, s34                                 // 0000000A14D8: BE812022
	s_cbranch_execz 7                                          // 0000000A14DC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15fc>
	ds_load_b32 v132, v164 offset:12                           // 0000000A14E0: D8D8000C 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A14E8: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A14EC: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A14F0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A14F4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A14F8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A14FC: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 0000000A1500: 37090A90
	s_or_b32 s1, s2, 4                                         // 0000000A1504: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A1508: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000A150C: 7C874401
	.long 0xd44d0001                                           // 0000000A1510: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A1514: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 0000000A1518: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A151C: BF870009
	s_and_saveexec_b32 s1, s33                                 // 0000000A1520: BE812021
	s_cbranch_execz 7                                          // 0000000A1524: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1644>
	ds_load_b32 v132, v164 offset:16                           // 0000000A1528: D8D80010 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A1530: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A1534: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A1538: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A153C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A1540: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A1544: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 0000000A1548: 37090AA0
	s_or_b32 s1, s2, 5                                         // 0000000A154C: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A1550: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000A1554: 7C874401
	.long 0xd44d0001                                           // 0000000A1558: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A155C: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 0000000A1560: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1564: BF870009
	s_and_saveexec_b32 s1, s31                                 // 0000000A1568: BE81201F
	s_cbranch_execz 7                                          // 0000000A156C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x168c>
	ds_load_b32 v132, v164 offset:20                           // 0000000A1570: D8D80014 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A1578: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A157C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A1580: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A1584: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A1588: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A158C: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 0000000A1590: 37090AC0
	s_or_b32 s1, s2, 6                                         // 0000000A1594: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A1598: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000A159C: 7C874401
	.long 0xd44d0001                                           // 0000000A15A0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A15A4: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 0000000A15A8: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A15AC: BF870009
	s_and_saveexec_b32 s1, s30                                 // 0000000A15B0: BE81201E
	s_cbranch_execz 7                                          // 0000000A15B4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16d4>
	ds_load_b32 v132, v164 offset:24                           // 0000000A15B8: D8D80018 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A15C0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A15C4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A15C8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A15CC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A15D0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A15D4: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 0000000A15D8: 37090AFF 00000080
	s_or_b32 s1, s2, 7                                         // 0000000A15E0: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A15E4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000A15E8: 7C874401
	.long 0xd44d0001                                           // 0000000A15EC: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A15F0: 02030880
	s_and_b32 s29, vcc_lo, s1                                  // 0000000A15F4: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A15F8: BF870009
	s_and_saveexec_b32 s1, s29                                 // 0000000A15FC: BE81201D
	s_cbranch_execz 7                                          // 0000000A1600: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1720>
	ds_load_b32 v132, v164 offset:28                           // 0000000A1604: D8D8001C 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A160C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A1610: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A1614: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A1618: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A161C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A1620: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 0000000A1624: 37090AFF 00000100
	s_or_b32 s1, s2, 8                                         // 0000000A162C: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A1630: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000A1634: 7C874401
	.long 0xd44d0001                                           // 0000000A1638: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A163C: 02030880
	s_and_b32 s28, vcc_lo, s1                                  // 0000000A1640: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1644: BF870009
	s_and_saveexec_b32 s1, s28                                 // 0000000A1648: BE81201C
	s_cbranch_execz 7                                          // 0000000A164C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x176c>
	ds_load_b32 v132, v164 offset:32                           // 0000000A1650: D8D80020 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A1658: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A165C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A1660: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A1664: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A1668: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A166C: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 0000000A1670: 37090AFF 00000200
	s_or_b32 s1, s2, 9                                         // 0000000A1678: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A167C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000A1680: 7C874401
	.long 0xd44d0001                                           // 0000000A1684: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A1688: 02030880
	s_and_b32 s27, vcc_lo, s1                                  // 0000000A168C: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1690: BF870009
	s_and_saveexec_b32 s1, s27                                 // 0000000A1694: BE81201B
	s_cbranch_execz 7                                          // 0000000A1698: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17b8>
	ds_load_b32 v132, v164 offset:36                           // 0000000A169C: D8D80024 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A16A4: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A16A8: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A16AC: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A16B0: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A16B4: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A16B8: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 0000000A16BC: 37090AFF 00000400
	s_or_b32 s1, s2, 10                                        // 0000000A16C4: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A16C8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000A16CC: 7C874401
	.long 0xd44d0001                                           // 0000000A16D0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A16D4: 02030880
	s_and_b32 s26, vcc_lo, s1                                  // 0000000A16D8: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A16DC: BF870009
	s_and_saveexec_b32 s1, s26                                 // 0000000A16E0: BE81201A
	s_cbranch_execz 7                                          // 0000000A16E4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1804>
	ds_load_b32 v132, v164 offset:40                           // 0000000A16E8: D8D80028 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A16F0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A16F4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A16F8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A16FC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A1700: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A1704: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 0000000A1708: 37090AFF 00000800
	s_or_b32 s1, s2, 11                                        // 0000000A1710: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A1714: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000A1718: 7C874401
	.long 0xd44d0001                                           // 0000000A171C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A1720: 02030880
	s_and_b32 s25, vcc_lo, s1                                  // 0000000A1724: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1728: BF870009
	s_and_saveexec_b32 s1, s25                                 // 0000000A172C: BE812019
	s_cbranch_execz 7                                          // 0000000A1730: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1850>
	ds_load_b32 v132, v164 offset:44                           // 0000000A1734: D8D8002C 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A173C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A1740: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A1744: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A1748: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A174C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A1750: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 0000000A1754: 37090AFF 00001000
	s_or_b32 s1, s2, 12                                        // 0000000A175C: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A1760: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000A1764: 7C874401
	.long 0xd44d0001                                           // 0000000A1768: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A176C: 02030880
	s_and_b32 s24, vcc_lo, s1                                  // 0000000A1770: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1774: BF870009
	s_and_saveexec_b32 s1, s24                                 // 0000000A1778: BE812018
	s_cbranch_execz 7                                          // 0000000A177C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x189c>
	ds_load_b32 v132, v164 offset:48                           // 0000000A1780: D8D80030 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A1788: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A178C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A1790: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A1794: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A1798: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A179C: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 0000000A17A0: 37090AFF 00002000
	s_or_b32 s1, s2, 13                                        // 0000000A17A8: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A17AC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000A17B0: 7C874401
	.long 0xd44d0001                                           // 0000000A17B4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A17B8: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 0000000A17BC: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A17C0: BF870009
	s_and_saveexec_b32 s1, s9                                  // 0000000A17C4: BE812009
	s_cbranch_execz 7                                          // 0000000A17C8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18e8>
	ds_load_b32 v132, v164 offset:52                           // 0000000A17CC: D8D80034 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A17D4: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A17D8: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A17DC: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A17E0: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A17E4: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A17E8: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 0000000A17EC: 37090AFF 00004000
	s_or_b32 s1, s2, 14                                        // 0000000A17F4: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A17F8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v162                          // 0000000A17FC: 7C874401
	.long 0xd44d0001                                           // 0000000A1800: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A1804: 02030880
	s_and_b32 s8, vcc_lo, s1                                   // 0000000A1808: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A180C: BF870009
	s_and_saveexec_b32 s1, s8                                  // 0000000A1810: BE812008
	s_cbranch_execz 7                                          // 0000000A1814: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1934>
	ds_load_b32 v132, v164 offset:56                           // 0000000A1818: D8D80038 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A1820: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A1824: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A1828: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A182C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A1830: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A1834: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 0000000A1838: 37090AFF 00008000
	s_or_b32 s2, s2, 15                                        // 0000000A1840: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A1844: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v162                          // 0000000A1848: 7C874402
	.long 0xd44d0001                                           // 0000000A184C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 0000000A1850: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 0000000A1854: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1858: BF870009
	s_and_saveexec_b32 s2, s1                                  // 0000000A185C: BE822001
	s_cbranch_execz 7                                          // 0000000A1860: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1980>
	ds_load_b32 v132, v164 offset:60                           // 0000000A1864: D8D8003C 840000A4
	v_max_f32_e32 v130, v130, v130                             // 0000000A186C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 0000000A1870: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 0000000A1874: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A1878: BF870001
	v_max_f32_e32 v130, v130, v132                             // 0000000A187C: 21050982
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A1880: 8C7E027E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 0000000A1884: CA100080 84840080
	s_and_saveexec_b32 s2, s37                                 // 0000000A188C: BE822025
	s_cbranch_execz 30                                         // 0000000A1890: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a0c>
	ds_load_b32 v133, v164                                     // 0000000A1894: D8D80000 850000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A189C: BF89FC07
	v_sub_f32_e32 v133, v133, v130                             // 0000000A18A0: 090B0585
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A18A4: BF870091
	v_mul_f32_e32 v134, 0x3fb8aa3b, v133                       // 0000000A18A8: 110D0AFF 3FB8AA3B
	v_fma_f32 v135, 0x3fb8aa3b, v133, -v134                    // 0000000A18B0: D6130087 861B0AFF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 0000000A18BC: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A18C0: BF870221
	v_sub_f32_e32 v134, v134, v136                             // 0000000A18C4: 090D1186
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 0000000A18C8: 7C370AFF C2CE8ED0
	v_fmac_f32_e32 v135, 0x32a5705f, v133                      // 0000000A18D0: 570F0AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A18D8: BF870121
	v_add_f32_e32 v134, v134, v135                             // 0000000A18DC: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 0000000A18E0: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 0000000A18E4: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A18E8: BF870095
	.long 0xd71c0086                                           // 0000000A18EC: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 0000000A18F0: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000000A18F4: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 0000000A18F8: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A1900: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v134, vcc_lo           // 0000000A1904: 030B0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A190C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1910: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 0000000A1914: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 0000000A191C: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v165, v134                             // 0000000A1928: DA840000 000086A5
	s_and_saveexec_b32 s2, s36                                 // 0000000A1930: BE822024
	s_cbranch_execz 30                                         // 0000000A1934: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ab0>
	ds_load_b32 v132, v164 offset:4                            // 0000000A1938: D8D80004 840000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A1940: BF89FC07
	v_sub_f32_e32 v132, v132, v130                             // 0000000A1944: 09090584
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1948: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v132                       // 0000000A194C: 110D08FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v132                 // 0000000A1954: 7C3708FF C2CE8ED0
	v_fma_f32 v135, 0x3fb8aa3b, v132, -v134                    // 0000000A195C: D6130087 861B08FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 0000000A1968: 7F104786
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A196C: BF870112
	v_fmac_f32_e32 v135, 0x32a5705f, v132                      // 0000000A1970: 570F08FF 32A5705F
	v_sub_f32_e32 v134, v134, v136                             // 0000000A1978: 090D1186
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A197C: BF870121
	v_add_f32_e32 v134, v134, v135                             // 0000000A1980: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 0000000A1984: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 0000000A1988: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A198C: BF870095
	.long 0xd71c0086                                           // 0000000A1990: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 0000000A1994: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000000A1998: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v132                 // 0000000A199C: 7C3D08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A19A4: BF870002
	v_cndmask_b32_e32 v132, 0x7f800000, v134, vcc_lo           // 0000000A19A8: 03090CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A19B0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A19B4: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 0000000A19B8: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 0000000A19C0: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 0000000A19C4: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 0000000A19D0: 7F0C0280
	ds_store_b16_d16_hi v165, v136 offset:2                    // 0000000A19D4: DA840002 000088A5
	s_and_saveexec_b32 s2, s35                                 // 0000000A19DC: BE822023
	s_cbranch_execz 29                                         // 0000000A19E0: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b58>
	ds_load_b32 v135, v164 offset:8                            // 0000000A19E4: D8D80008 870000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A19EC: BF89FC07
	v_sub_f32_e32 v135, v135, v130                             // 0000000A19F0: 090F0587
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A19F4: BF870091
	v_mul_f32_e32 v136, 0x3fb8aa3b, v135                       // 0000000A19F8: 11110EFF 3FB8AA3B
	v_fma_f32 v137, 0x3fb8aa3b, v135, -v136                    // 0000000A1A00: D6130089 86230EFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 0000000A1A0C: 7F244788
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1A10: BF870091
	v_dual_fmac_f32 v137, 0x32a5705f, v135 :: v_dual_sub_f32 v136, v136, v146// 0000000A1A14: C80B0EFF 89892588 32A5705F
	v_add_f32_e32 v136, v136, v137                             // 0000000A1A20: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 0000000A1A24: 7F121192
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 0000000A1A28: 7C370EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A1A30: BF870293
	v_exp_f32_e32 v136, v136                                   // 0000000A1A34: 7F104B88
	.long 0xd71c0088                                           // 0000000A1A38: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 0000000A1A3C: 02031388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1A40: BF870121
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000000A1A44: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 0000000A1A48: 7C3D0EFF 42B17218
	v_cndmask_b32_e32 v135, 0x7f800000, v136, vcc_lo           // 0000000A1A50: 030F10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A1A58: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1A5C: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 0000000A1A60: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 0000000A1A68: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v165, v136 offset:4                    // 0000000A1A74: DA840004 000088A5
	s_and_saveexec_b32 s2, s34                                 // 0000000A1A7C: BE822022
	s_cbranch_execz 30                                         // 0000000A1A80: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1bfc>
	ds_load_b32 v134, v164 offset:12                           // 0000000A1A84: D8D8000C 860000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A1A8C: BF89FC07
	v_sub_f32_e32 v134, v134, v130                             // 0000000A1A90: 090D0586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1A94: BF870121
	v_mul_f32_e32 v136, 0x3fb8aa3b, v134                       // 0000000A1A98: 11110CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 0000000A1AA0: 7C370CFF C2CE8ED0
	v_fma_f32 v137, 0x3fb8aa3b, v134, -v136                    // 0000000A1AA8: D6130089 86230CFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 0000000A1AB4: 7F244788
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A1AB8: BF870112
	v_fmac_f32_e32 v137, 0x32a5705f, v134                      // 0000000A1ABC: 57130CFF 32A5705F
	v_sub_f32_e32 v136, v136, v146                             // 0000000A1AC4: 09112588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1AC8: BF870121
	v_add_f32_e32 v136, v136, v137                             // 0000000A1ACC: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 0000000A1AD0: 7F121192
	v_exp_f32_e32 v136, v136                                   // 0000000A1AD4: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1AD8: BF870095
	.long 0xd71c0088                                           // 0000000A1ADC: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 0000000A1AE0: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000000A1AE4: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 0000000A1AE8: 7C3D0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A1AF0: BF870002
	v_cndmask_b32_e32 v134, 0x7f800000, v136, vcc_lo           // 0000000A1AF4: 030D10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A1AFC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1B00: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 0000000A1B04: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 0000000A1B0C: 7F120280
	v_add3_u32 v146, v134, v136, 0x7fff                        // 0000000A1B10: D6550092 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 0000000A1B1C: 7F100280
	ds_store_b16_d16_hi v165, v146 offset:6                    // 0000000A1B20: DA840006 000092A5
	s_and_saveexec_b32 s2, s33                                 // 0000000A1B28: BE822021
	s_cbranch_execz 30                                         // 0000000A1B2C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ca8>
	ds_load_b32 v137, v164 offset:16                           // 0000000A1B30: D8D80010 890000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A1B38: BF89FC07
	v_sub_f32_e32 v137, v137, v130                             // 0000000A1B3C: 09130589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1B40: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 0000000A1B44: 112512FF 3FB8AA3B
	v_fma_f32 v147, 0x3fb8aa3b, v137, -v146                    // 0000000A1B4C: D6130093 864B12FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 0000000A1B58: 7F284792
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A1B5C: BF870221
	v_sub_f32_e32 v146, v146, v148                             // 0000000A1B60: 09252992
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v137                 // 0000000A1B64: 7C3712FF C2CE8ED0
	v_fmac_f32_e32 v147, 0x32a5705f, v137                      // 0000000A1B6C: 572712FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1B74: BF870121
	v_add_f32_e32 v146, v146, v147                             // 0000000A1B78: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 0000000A1B7C: 7F261194
	v_exp_f32_e32 v146, v146                                   // 0000000A1B80: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1B84: BF870095
	.long 0xd71c0092                                           // 0000000A1B88: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 0000000A1B8C: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 0000000A1B90: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v137                 // 0000000A1B94: 7C3D12FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A1B9C: BF870002
	v_cndmask_b32_e32 v137, 0x7f800000, v146, vcc_lo           // 0000000A1BA0: 031324FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A1BA8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1BAC: BF870091
	v_bfe_u32 v146, v137, 16, 1                                // 0000000A1BB0: D6100092 02052189
	v_add3_u32 v146, v137, v146, 0x7fff                        // 0000000A1BB8: D6550092 03FF2589 00007FFF
	ds_store_b16_d16_hi v165, v146 offset:8                    // 0000000A1BC4: DA840008 000092A5
	s_and_saveexec_b32 s2, s31                                 // 0000000A1BCC: BE82201F
	s_cbranch_execz 30                                         // 0000000A1BD0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d4c>
	ds_load_b32 v136, v164 offset:20                           // 0000000A1BD4: D8D80014 880000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A1BDC: BF89FC07
	v_sub_f32_e32 v136, v136, v130                             // 0000000A1BE0: 09110588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1BE4: BF870121
	v_mul_f32_e32 v146, 0x3fb8aa3b, v136                       // 0000000A1BE8: 112510FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 0000000A1BF0: 7C3710FF C2CE8ED0
	v_fma_f32 v147, 0x3fb8aa3b, v136, -v146                    // 0000000A1BF8: D6130093 864B10FF 3FB8AA3B
	v_rndne_f32_e32 v148, v146                                 // 0000000A1C04: 7F284792
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A1C08: BF870112
	v_fmac_f32_e32 v147, 0x32a5705f, v136                      // 0000000A1C0C: 572710FF 32A5705F
	v_sub_f32_e32 v146, v146, v148                             // 0000000A1C14: 09252992
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1C18: BF870121
	v_add_f32_e32 v146, v146, v147                             // 0000000A1C1C: 07252792
	v_cvt_i32_f32_e32 v147, v148                               // 0000000A1C20: 7F261194
	v_exp_f32_e32 v146, v146                                   // 0000000A1C24: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1C28: BF870095
	.long 0xd71c0092                                           // 0000000A1C2C: D71C0092
	v_cndmask_b32_e32 v1, v146, v147, vcc_lo                   // 0000000A1C30: 02032792
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 0000000A1C34: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 0000000A1C38: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A1C40: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v146, vcc_lo           // 0000000A1C44: 031124FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A1C4C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1C50: BF870121
	v_bfe_u32 v146, v136, 16, 1                                // 0000000A1C54: D6100092 02052188
	v_mov_b32_e32 v147, 0                                      // 0000000A1C5C: 7F260280
	v_add3_u32 v148, v136, v146, 0x7fff                        // 0000000A1C60: D6550094 03FF2588 00007FFF
	v_mov_b32_e32 v146, 0                                      // 0000000A1C6C: 7F240280
	ds_store_b16_d16_hi v165, v148 offset:10                   // 0000000A1C70: DA84000A 000094A5
	s_and_saveexec_b32 s2, s30                                 // 0000000A1C78: BE82201E
	s_cbranch_execz 29                                         // 0000000A1C7C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1df4>
	ds_load_b32 v147, v164 offset:24                           // 0000000A1C80: D8D80018 930000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A1C88: BF89FC07
	v_sub_f32_e32 v147, v147, v130                             // 0000000A1C8C: 09270593
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1C90: BF870091
	v_mul_f32_e32 v148, 0x3fb8aa3b, v147                       // 0000000A1C94: 112926FF 3FB8AA3B
	v_fma_f32 v149, 0x3fb8aa3b, v147, -v148                    // 0000000A1C9C: D6130095 865326FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 0000000A1CA8: 7F2C4794
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1CAC: BF870091
	v_dual_fmac_f32 v149, 0x32a5705f, v147 :: v_dual_sub_f32 v148, v148, v150// 0000000A1CB0: C80B26FF 95952D94 32A5705F
	v_add_f32_e32 v148, v148, v149                             // 0000000A1CBC: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 0000000A1CC0: 7F2A1196
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v147                 // 0000000A1CC4: 7C3726FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A1CCC: BF870293
	v_exp_f32_e32 v148, v148                                   // 0000000A1CD0: 7F284B94
	.long 0xd71c0094                                           // 0000000A1CD4: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 0000000A1CD8: 02032B94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1CDC: BF870121
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 0000000A1CE0: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v147                 // 0000000A1CE4: 7C3D26FF 42B17218
	v_cndmask_b32_e32 v147, 0x7f800000, v148, vcc_lo           // 0000000A1CEC: 032728FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A1CF4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1CF8: BF870091
	v_bfe_u32 v148, v147, 16, 1                                // 0000000A1CFC: D6100094 02052193
	v_add3_u32 v148, v147, v148, 0x7fff                        // 0000000A1D04: D6550094 03FF2993 00007FFF
	ds_store_b16_d16_hi v165, v148 offset:12                   // 0000000A1D10: DA84000C 000094A5
	s_and_saveexec_b32 s2, s29                                 // 0000000A1D18: BE82201D
	s_cbranch_execz 30                                         // 0000000A1D1C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e98>
	ds_load_b32 v146, v164 offset:28                           // 0000000A1D20: D8D8001C 920000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A1D28: BF89FC07
	v_sub_f32_e32 v146, v146, v130                             // 0000000A1D2C: 09250592
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1D30: BF870121
	v_mul_f32_e32 v148, 0x3fb8aa3b, v146                       // 0000000A1D34: 112924FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 0000000A1D3C: 7C3724FF C2CE8ED0
	v_fma_f32 v149, 0x3fb8aa3b, v146, -v148                    // 0000000A1D44: D6130095 865324FF 3FB8AA3B
	v_rndne_f32_e32 v150, v148                                 // 0000000A1D50: 7F2C4794
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A1D54: BF870112
	v_fmac_f32_e32 v149, 0x32a5705f, v146                      // 0000000A1D58: 572B24FF 32A5705F
	v_sub_f32_e32 v148, v148, v150                             // 0000000A1D60: 09292D94
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1D64: BF870121
	v_add_f32_e32 v148, v148, v149                             // 0000000A1D68: 07292B94
	v_cvt_i32_f32_e32 v149, v150                               // 0000000A1D6C: 7F2A1196
	v_exp_f32_e32 v148, v148                                   // 0000000A1D70: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1D74: BF870095
	.long 0xd71c0094                                           // 0000000A1D78: D71C0094
	v_cndmask_b32_e32 v1, v148, v149, vcc_lo                   // 0000000A1D7C: 02032B94
	v_cndmask_b32_e32 v148, 0, v148, vcc_lo                    // 0000000A1D80: 03292880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 0000000A1D84: 7C3D24FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A1D8C: BF870002
	v_cndmask_b32_e32 v146, 0x7f800000, v148, vcc_lo           // 0000000A1D90: 032528FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A1D98: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1D9C: BF870121
	v_bfe_u32 v148, v146, 16, 1                                // 0000000A1DA0: D6100094 02052192
	v_mov_b32_e32 v149, 0                                      // 0000000A1DA8: 7F2A0280
	v_add3_u32 v150, v146, v148, 0x7fff                        // 0000000A1DAC: D6550096 03FF2992 00007FFF
	v_mov_b32_e32 v148, 0                                      // 0000000A1DB8: 7F280280
	ds_store_b16_d16_hi v165, v150 offset:14                   // 0000000A1DBC: DA84000E 000096A5
	s_and_saveexec_b32 s2, s28                                 // 0000000A1DC4: BE82201C
	s_cbranch_execz 30                                         // 0000000A1DC8: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f44>
	ds_load_b32 v149, v164 offset:32                           // 0000000A1DCC: D8D80020 950000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A1DD4: BF89FC07
	v_sub_f32_e32 v149, v149, v130                             // 0000000A1DD8: 092B0595
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1DDC: BF870091
	v_mul_f32_e32 v150, 0x3fb8aa3b, v149                       // 0000000A1DE0: 112D2AFF 3FB8AA3B
	v_fma_f32 v151, 0x3fb8aa3b, v149, -v150                    // 0000000A1DE8: D6130097 865B2AFF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 0000000A1DF4: 7F304796
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A1DF8: BF870221
	v_sub_f32_e32 v150, v150, v152                             // 0000000A1DFC: 092D3196
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 0000000A1E00: 7C372AFF C2CE8ED0
	v_fmac_f32_e32 v151, 0x32a5705f, v149                      // 0000000A1E08: 572F2AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1E10: BF870121
	v_add_f32_e32 v150, v150, v151                             // 0000000A1E14: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 0000000A1E18: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 0000000A1E1C: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1E20: BF870095
	.long 0xd71c0096                                           // 0000000A1E24: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 0000000A1E28: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 0000000A1E2C: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 0000000A1E30: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A1E38: BF870002
	v_cndmask_b32_e32 v149, 0x7f800000, v150, vcc_lo           // 0000000A1E3C: 032B2CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A1E44: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1E48: BF870091
	v_bfe_u32 v150, v149, 16, 1                                // 0000000A1E4C: D6100096 02052195
	v_add3_u32 v150, v149, v150, 0x7fff                        // 0000000A1E54: D6550096 03FF2D95 00007FFF
	ds_store_b16_d16_hi v165, v150 offset:16                   // 0000000A1E60: DA840010 000096A5
	s_and_saveexec_b32 s2, s27                                 // 0000000A1E68: BE82201B
	s_cbranch_execz 30                                         // 0000000A1E6C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1fe8>
	ds_load_b32 v148, v164 offset:36                           // 0000000A1E70: D8D80024 940000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A1E78: BF89FC07
	v_sub_f32_e32 v148, v148, v130                             // 0000000A1E7C: 09290594
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1E80: BF870121
	v_mul_f32_e32 v150, 0x3fb8aa3b, v148                       // 0000000A1E84: 112D28FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v148                 // 0000000A1E8C: 7C3728FF C2CE8ED0
	v_fma_f32 v151, 0x3fb8aa3b, v148, -v150                    // 0000000A1E94: D6130097 865B28FF 3FB8AA3B
	v_rndne_f32_e32 v152, v150                                 // 0000000A1EA0: 7F304796
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A1EA4: BF870112
	v_fmac_f32_e32 v151, 0x32a5705f, v148                      // 0000000A1EA8: 572F28FF 32A5705F
	v_sub_f32_e32 v150, v150, v152                             // 0000000A1EB0: 092D3196
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1EB4: BF870121
	v_add_f32_e32 v150, v150, v151                             // 0000000A1EB8: 072D2F96
	v_cvt_i32_f32_e32 v151, v152                               // 0000000A1EBC: 7F2E1198
	v_exp_f32_e32 v150, v150                                   // 0000000A1EC0: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1EC4: BF870095
	.long 0xd71c0096                                           // 0000000A1EC8: D71C0096
	v_cndmask_b32_e32 v1, v150, v151, vcc_lo                   // 0000000A1ECC: 02032F96
	v_cndmask_b32_e32 v150, 0, v150, vcc_lo                    // 0000000A1ED0: 032D2C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v148                 // 0000000A1ED4: 7C3D28FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A1EDC: BF870002
	v_cndmask_b32_e32 v148, 0x7f800000, v150, vcc_lo           // 0000000A1EE0: 03292CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A1EE8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1EEC: BF870121
	v_bfe_u32 v150, v148, 16, 1                                // 0000000A1EF0: D6100096 02052194
	v_mov_b32_e32 v151, 0                                      // 0000000A1EF8: 7F2E0280
	v_add3_u32 v152, v148, v150, 0x7fff                        // 0000000A1EFC: D6550098 03FF2D94 00007FFF
	v_mov_b32_e32 v150, 0                                      // 0000000A1F08: 7F2C0280
	ds_store_b16_d16_hi v165, v152 offset:18                   // 0000000A1F0C: DA840012 000098A5
	s_and_saveexec_b32 s2, s26                                 // 0000000A1F14: BE82201A
	s_cbranch_execz 30                                         // 0000000A1F18: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2094>
	ds_load_b32 v151, v164 offset:40                           // 0000000A1F1C: D8D80028 970000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A1F24: BF89FC07
	v_sub_f32_e32 v151, v151, v130                             // 0000000A1F28: 092F0597
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1F2C: BF870091
	v_mul_f32_e32 v152, 0x3fb8aa3b, v151                       // 0000000A1F30: 11312EFF 3FB8AA3B
	v_fma_f32 v153, 0x3fb8aa3b, v151, -v152                    // 0000000A1F38: D6130099 86632EFF 3FB8AA3B
	v_rndne_f32_e32 v177, v152                                 // 0000000A1F44: 7F624798
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A1F48: BF870221
	v_sub_f32_e32 v152, v152, v177                             // 0000000A1F4C: 09316398
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 0000000A1F50: 7C372EFF C2CE8ED0
	v_fmac_f32_e32 v153, 0x32a5705f, v151                      // 0000000A1F58: 57332EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1F60: BF870121
	v_add_f32_e32 v152, v152, v153                             // 0000000A1F64: 07313398
	v_cvt_i32_f32_e32 v153, v177                               // 0000000A1F68: 7F3211B1
	v_exp_f32_e32 v152, v152                                   // 0000000A1F6C: 7F304B98
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1F70: BF870095
	.long 0xd71c0098                                           // 0000000A1F74: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 0000000A1F78: 02033398
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 0000000A1F7C: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 0000000A1F80: 7C3D2EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A1F88: BF870002
	v_cndmask_b32_e32 v151, 0x7f800000, v152, vcc_lo           // 0000000A1F8C: 032F30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A1F94: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1F98: BF870091
	v_bfe_u32 v152, v151, 16, 1                                // 0000000A1F9C: D6100098 02052197
	v_add3_u32 v152, v151, v152, 0x7fff                        // 0000000A1FA4: D6550098 03FF3197 00007FFF
	ds_store_b16_d16_hi v165, v152 offset:20                   // 0000000A1FB0: DA840014 000098A5
	s_and_saveexec_b32 s2, s25                                 // 0000000A1FB8: BE822019
	s_cbranch_execz 29                                         // 0000000A1FBC: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2134>
	ds_load_b32 v150, v164 offset:44                           // 0000000A1FC0: D8D8002C 960000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A1FC8: BF89FC07
	v_sub_f32_e32 v150, v150, v130                             // 0000000A1FCC: 092D0596
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1FD0: BF870121
	v_mul_f32_e32 v152, 0x3fb8aa3b, v150                       // 0000000A1FD4: 11312CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 0000000A1FDC: 7C372CFF C2CE8ED0
	v_fma_f32 v153, 0x3fb8aa3b, v150, -v152                    // 0000000A1FE4: D6130099 86632CFF 3FB8AA3B
	v_rndne_f32_e32 v177, v152                                 // 0000000A1FF0: 7F624798
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1FF4: BF870091
	v_dual_fmac_f32 v153, 0x32a5705f, v150 :: v_dual_sub_f32 v152, v152, v177// 0000000A1FF8: C80B2CFF 99996398 32A5705F
	v_add_f32_e32 v152, v152, v153                             // 0000000A2004: 07313398
	v_cvt_i32_f32_e32 v153, v177                               // 0000000A2008: 7F3211B1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A200C: BF870292
	v_exp_f32_e32 v152, v152                                   // 0000000A2010: 7F304B98
	.long 0xd71c0098                                           // 0000000A2014: D71C0098
	v_cndmask_b32_e32 v1, v152, v153, vcc_lo                   // 0000000A2018: 02033398
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A201C: BF870121
	v_cndmask_b32_e32 v152, 0, v152, vcc_lo                    // 0000000A2020: 03313080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 0000000A2024: 7C3D2CFF 42B17218
	v_cndmask_b32_e32 v150, 0x7f800000, v152, vcc_lo           // 0000000A202C: 032D30FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A2034: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A2038: BF870121
	v_bfe_u32 v152, v150, 16, 1                                // 0000000A203C: D6100098 02052196
	v_mov_b32_e32 v153, 0                                      // 0000000A2044: 7F320280
	v_add3_u32 v177, v150, v152, 0x7fff                        // 0000000A2048: D65500B1 03FF3196 00007FFF
	v_mov_b32_e32 v152, 0                                      // 0000000A2054: 7F300280
	ds_store_b16_d16_hi v165, v177 offset:22                   // 0000000A2058: DA840016 0000B1A5
	s_and_saveexec_b32 s2, s24                                 // 0000000A2060: BE822018
	s_cbranch_execz 29                                         // 0000000A2064: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21dc>
	ds_load_b32 v153, v164 offset:48                           // 0000000A2068: D8D80030 990000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A2070: BF89FC07
	v_sub_f32_e32 v153, v153, v130                             // 0000000A2074: 09330599
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A2078: BF870121
	v_mul_f32_e32 v177, 0x3fb8aa3b, v153                       // 0000000A207C: 116332FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 0000000A2084: 7C3732FF C2CE8ED0
	v_fma_f32 v178, 0x3fb8aa3b, v153, -v177                    // 0000000A208C: D61300B2 86C732FF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 0000000A2098: 7F6647B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A209C: BF870091
	v_dual_fmac_f32 v178, 0x32a5705f, v153 :: v_dual_sub_f32 v177, v177, v179// 0000000A20A0: C80B32FF B2B167B1 32A5705F
	v_add_f32_e32 v177, v177, v178                             // 0000000A20AC: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 0000000A20B0: 7F6411B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A20B4: BF870292
	v_exp_f32_e32 v177, v177                                   // 0000000A20B8: 7F624BB1
	.long 0xd71c00b1                                           // 0000000A20BC: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 0000000A20C0: 020365B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A20C4: BF870121
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 0000000A20C8: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 0000000A20CC: 7C3D32FF 42B17218
	v_cndmask_b32_e32 v153, 0x7f800000, v177, vcc_lo           // 0000000A20D4: 033362FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A20DC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A20E0: BF870091
	v_bfe_u32 v177, v153, 16, 1                                // 0000000A20E4: D61000B1 02052199
	v_add3_u32 v177, v153, v177, 0x7fff                        // 0000000A20EC: D65500B1 03FF6399 00007FFF
	ds_store_b16_d16_hi v165, v177 offset:24                   // 0000000A20F8: DA840018 0000B1A5
	s_and_saveexec_b32 s2, s9                                  // 0000000A2100: BE822009
	s_cbranch_execz 30                                         // 0000000A2104: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2280>
	ds_load_b32 v152, v164 offset:52                           // 0000000A2108: D8D80034 980000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A2110: BF89FC07
	v_sub_f32_e32 v152, v152, v130                             // 0000000A2114: 09310598
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2118: BF870091
	v_mul_f32_e32 v177, 0x3fb8aa3b, v152                       // 0000000A211C: 116330FF 3FB8AA3B
	v_fma_f32 v178, 0x3fb8aa3b, v152, -v177                    // 0000000A2124: D61300B2 86C730FF 3FB8AA3B
	v_rndne_f32_e32 v179, v177                                 // 0000000A2130: 7F6647B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A2134: BF870221
	v_sub_f32_e32 v177, v177, v179                             // 0000000A2138: 096367B1
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 0000000A213C: 7C3730FF C2CE8ED0
	v_fmac_f32_e32 v178, 0x32a5705f, v152                      // 0000000A2144: 576530FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A214C: BF870121
	v_add_f32_e32 v177, v177, v178                             // 0000000A2150: 076365B1
	v_cvt_i32_f32_e32 v178, v179                               // 0000000A2154: 7F6411B3
	v_exp_f32_e32 v177, v177                                   // 0000000A2158: 7F624BB1
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A215C: BF870095
	.long 0xd71c00b1                                           // 0000000A2160: D71C00B1
	v_cndmask_b32_e32 v1, v177, v178, vcc_lo                   // 0000000A2164: 020365B1
	v_cndmask_b32_e32 v177, 0, v177, vcc_lo                    // 0000000A2168: 03636280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 0000000A216C: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A2174: BF870002
	v_cndmask_b32_e32 v152, 0x7f800000, v177, vcc_lo           // 0000000A2178: 033162FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A2180: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A2184: BF870121
	v_bfe_u32 v177, v152, 16, 1                                // 0000000A2188: D61000B1 02052198
	v_mov_b32_e32 v178, 0                                      // 0000000A2190: 7F640280
	v_add3_u32 v179, v152, v177, 0x7fff                        // 0000000A2194: D65500B3 03FF6398 00007FFF
	v_mov_b32_e32 v177, 0                                      // 0000000A21A0: 7F620280
	ds_store_b16_d16_hi v165, v179 offset:26                   // 0000000A21A4: DA84001A 0000B3A5
	s_and_saveexec_b32 s2, s8                                  // 0000000A21AC: BE822008
	s_cbranch_execz 30                                         // 0000000A21B0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x232c>
	ds_load_b32 v178, v164 offset:56                           // 0000000A21B4: D8D80038 B20000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A21BC: BF89FC07
	v_sub_f32_e32 v178, v178, v130                             // 0000000A21C0: 096505B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A21C4: BF870091
	v_mul_f32_e32 v179, 0x3fb8aa3b, v178                       // 0000000A21C8: 116764FF 3FB8AA3B
	v_fma_f32 v180, 0x3fb8aa3b, v178, -v179                    // 0000000A21D0: D61300B4 86CF64FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000A21DC: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A21E0: BF870221
	v_sub_f32_e32 v179, v179, v181                             // 0000000A21E4: 09676BB3
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v178                 // 0000000A21E8: 7C3764FF C2CE8ED0
	v_fmac_f32_e32 v180, 0x32a5705f, v178                      // 0000000A21F0: 576964FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A21F8: BF870121
	v_add_f32_e32 v179, v179, v180                             // 0000000A21FC: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000A2200: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 0000000A2204: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2208: BF870095
	.long 0xd71c00b3                                           // 0000000A220C: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000A2210: 020369B3
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000A2214: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v178                 // 0000000A2218: 7C3D64FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A2220: BF870002
	v_cndmask_b32_e32 v178, 0x7f800000, v179, vcc_lo           // 0000000A2224: 036566FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A222C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2230: BF870091
	v_bfe_u32 v179, v178, 16, 1                                // 0000000A2234: D61000B3 020521B2
	v_add3_u32 v179, v178, v179, 0x7fff                        // 0000000A223C: D65500B3 03FF67B2 00007FFF
	ds_store_b16_d16_hi v165, v179 offset:28                   // 0000000A2248: DA84001C 0000B3A5
	s_and_saveexec_b32 s2, s1                                  // 0000000A2250: BE822001
	s_cbranch_execz 30                                         // 0000000A2254: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x23d0>
	ds_load_b32 v177, v164 offset:60                           // 0000000A2258: D8D8003C B10000A4
	s_waitcnt lgkmcnt(0)                                       // 0000000A2260: BF89FC07
	v_sub_f32_e32 v177, v177, v130                             // 0000000A2264: 096305B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A2268: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v177                       // 0000000A226C: 116762FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v177                 // 0000000A2274: 7C3762FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v177, -v179                    // 0000000A227C: D61300B4 86CF62FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000A2288: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A228C: BF870112
	v_fmac_f32_e32 v180, 0x32a5705f, v177                      // 0000000A2290: 576962FF 32A5705F
	v_sub_f32_e32 v179, v179, v181                             // 0000000A2298: 09676BB3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A229C: BF870121
	v_add_f32_e32 v179, v179, v180                             // 0000000A22A0: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000A22A4: 7F6811B5
	v_exp_f32_e32 v179, v179                                   // 0000000A22A8: 7F664BB3
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A22AC: BF870095
	.long 0xd71c00b3                                           // 0000000A22B0: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000A22B4: 020369B3
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000A22B8: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v177                 // 0000000A22BC: 7C3D62FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A22C4: BF870002
	v_cndmask_b32_e32 v177, 0x7f800000, v179, vcc_lo           // 0000000A22C8: 036366FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A22D0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A22D4: BF8700A1
	v_bfe_u32 v179, v177, 16, 1                                // 0000000A22D8: D61000B3 020521B1
	s_mov_b32 s1, exec_lo                                      // 0000000A22E0: BE81007E
	v_add3_u32 v180, v177, v179, 0x7fff                        // 0000000A22E4: D65500B4 03FF67B1 00007FFF
	v_mov_b32_e32 v179, 0                                      // 0000000A22F0: 7F660280
	ds_store_b16_d16_hi v165, v180 offset:30                   // 0000000A22F4: DA84001E 0000B4A5
	v_cmpx_lt_f32_e32 0xefa18f08, v131                         // 0000000A22FC: 7D2306FF EFA18F08
	s_cbranch_execz 26                                         // 0000000A2304: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2470>
	v_sub_f32_e32 v131, v131, v130                             // 0000000A2308: 09070583
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A230C: BF870121
	v_mul_f32_e32 v179, 0x3fb8aa3b, v131                       // 0000000A2310: 116706FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 0000000A2318: 7C3706FF C2CE8ED0
	v_fma_f32 v180, 0x3fb8aa3b, v131, -v179                    // 0000000A2320: D61300B4 86CF06FF 3FB8AA3B
	v_rndne_f32_e32 v181, v179                                 // 0000000A232C: 7F6A47B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2330: BF870091
	v_dual_fmac_f32 v180, 0x32a5705f, v131 :: v_dual_sub_f32 v179, v179, v181// 0000000A2334: C80B06FF B4B36BB3 32A5705F
	v_add_f32_e32 v179, v179, v180                             // 0000000A2340: 076769B3
	v_cvt_i32_f32_e32 v180, v181                               // 0000000A2344: 7F6811B5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A2348: BF870292
	v_exp_f32_e32 v179, v179                                   // 0000000A234C: 7F664BB3
	.long 0xd71c00b3                                           // 0000000A2350: D71C00B3
	v_cndmask_b32_e32 v1, v179, v180, vcc_lo                   // 0000000A2354: 020369B3
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A2358: BF870121
	v_cndmask_b32_e32 v179, 0, v179, vcc_lo                    // 0000000A235C: 03676680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 0000000A2360: 7C3D06FF 42B17218
	v_cndmask_b32_e32 v179, 0x7f800000, v179, vcc_lo           // 0000000A2368: 036766FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A2370: 8C7E017E
	v_add_f32_e32 v131, v133, v132                             // 0000000A2374: 07070985
	ds_load_b32 v132, v166                                     // 0000000A2378: D8D80000 840000A6
	v_add_f32_e32 v131, v131, v135                             // 0000000A2380: 07070F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2384: BF870091
	v_add_f32_e32 v131, v131, v134                             // 0000000A2388: 07070D83
	v_add_f32_e32 v131, v131, v137                             // 0000000A238C: 07071383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2390: BF870091
	v_add_f32_e32 v131, v131, v136                             // 0000000A2394: 07071183
	v_add_f32_e32 v131, v131, v147                             // 0000000A2398: 07072783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A239C: BF870091
	v_add_f32_e32 v131, v131, v146                             // 0000000A23A0: 07072583
	v_add_f32_e32 v131, v131, v149                             // 0000000A23A4: 07072B83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A23A8: BF870091
	v_add_f32_e32 v131, v131, v148                             // 0000000A23AC: 07072983
	v_add_f32_e32 v131, v131, v151                             // 0000000A23B0: 07072F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A23B4: BF870091
	v_add_f32_e32 v131, v131, v150                             // 0000000A23B8: 07072D83
	v_add_f32_e32 v131, v131, v153                             // 0000000A23BC: 07073383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A23C0: BF870091
	v_add_f32_e32 v131, v131, v152                             // 0000000A23C4: 07073183
	v_add_f32_e32 v131, v131, v178                             // 0000000A23C8: 07076583
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A23CC: BF8700A1
	v_add_f32_e32 v131, v131, v177                             // 0000000A23D0: 07076383
	s_waitcnt lgkmcnt(0)                                       // 0000000A23D4: BF89FC07
	v_fmac_f32_e32 v131, v179, v132                            // 0000000A23D8: 570709B3
	ds_store_b32 v163, v130                                    // 0000000A23DC: D8340000 000082A3
	ds_store_b32 v166, v131                                    // 0000000A23E4: D8340000 000083A6
	ds_store_b32 v167, v179                                    // 0000000A23EC: D8340000 0000B3A7
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A23F4: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 0000000A23F8: BF89FC07
	s_barrier                                                  // 0000000A23FC: BFBD0000
	buffer_gl0_inv                                             // 0000000A2400: E0AC0000 00000000
	ds_load_2addr_b32 v[152:153], v168 offset1:2               // 0000000A2408: D8DC0200 980000A8
	ds_load_2addr_b32 v[150:151], v168 offset0:4 offset1:6     // 0000000A2410: D8DC0604 960000A8
	ds_load_2addr_b32 v[148:149], v168 offset0:8 offset1:10    // 0000000A2418: D8DC0A08 940000A8
	ds_load_2addr_b32 v[146:147], v168 offset0:12 offset1:14   // 0000000A2420: D8DC0E0C 920000A8
	s_waitcnt lgkmcnt(3)                                       // 0000000A2428: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v152                         // 0000000A242C: 7C2530F2
	.long 0xd4120001                                           // 0000000A2430: D4120001
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 0000000A2434: 020332F2
	s_waitcnt lgkmcnt(2)                                       // 0000000A2438: BF89FC27
	.long 0xd4120002                                           // 0000000A243C: D4120002
	v_cndmask_b32_e32 v1, 1.0, v150, vcc_lo                    // 0000000A2440: 02032CF2
	.long 0xd4120004                                           // 0000000A2444: D4120004
	v_cndmask_b32_e32 v1, 1.0, v151, vcc_lo                    // 0000000A2448: 02032EF2
	s_and_b32 s1, vcc_lo, s1                                   // 0000000A244C: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 0000000A2450: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v148                         // 0000000A2454: 7C2528F2
	s_and_b32 s2, s1, s2                                       // 0000000A2458: 8B020201
	.long 0xd4120001                                           // 0000000A245C: D4120001
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 0000000A2460: 02032AF2
	s_and_b32 s4, s2, s4                                       // 0000000A2464: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 0000000A2468: BF89FC07
	.long 0xd4120002                                           // 0000000A246C: D4120002
	v_cndmask_b32_e32 v1, 1.0, v146, vcc_lo                    // 0000000A2470: 020324F2
	s_and_b32 s4, s4, vcc_lo                                   // 0000000A2474: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v147                         // 0000000A2478: 7C2526F2
	s_and_b32 s1, s4, s1                                       // 0000000A247C: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000A2480: BF870499
	s_and_b32 s1, s1, s2                                       // 0000000A2484: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 0000000A2488: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A248C: BF870099
	v_cndmask_b32_e64 v130, 0, 1, s1                           // 0000000A2490: D5010082 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v130                           // 0000000A2498: 7C9B0480
	ds_load_b128 v[130:133], v169                              // 0000000A249C: DBFC0000 820000A9
	ds_load_b128 v[134:137], v169 offset:16                    // 0000000A24A4: DBFC0010 860000A9
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 0000000A24AC: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 0000000A24B0: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A24B4: BF870099
	v_cndmask_b32_e64 v177, 0, 1, s1                           // 0000000A24B8: D50100B1 00050280
	v_readfirstlane_b32 s1, v177                               // 0000000A24C0: 7E0205B1
	s_bitcmp1_b32 s1, 0                                        // 0000000A24C4: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 0000000A24C8: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A24CC: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 0000000A24D0: 8B6A017E
	s_cbranch_vccnz 63580                                      // 0000000A24D4: BFA4F85C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x748>
	v_dual_mul_f32 v121, v152, v121 :: v_dual_mul_f32 v122, v153, v122// 0000000A24D8: C8C6F398 797AF599
	v_dual_mul_f32 v123, v150, v123 :: v_dual_mul_f32 v124, v151, v124// 0000000A24E0: C8C6F796 7B7CF997
	v_dual_mul_f32 v125, v148, v125 :: v_dual_mul_f32 v126, v149, v126// 0000000A24E8: C8C6FB94 7D7EFD95
	v_dual_mul_f32 v127, v146, v127 :: v_dual_mul_f32 v128, v147, v128// 0000000A24F0: C8C6FF92 7F810193
	v_dual_mul_f32 v113, v152, v113 :: v_dual_mul_f32 v114, v153, v114// 0000000A24F8: C8C6E398 7172E599
	v_dual_mul_f32 v115, v150, v115 :: v_dual_mul_f32 v116, v151, v116// 0000000A2500: C8C6E796 7374E997
	v_dual_mul_f32 v117, v148, v117 :: v_dual_mul_f32 v118, v149, v118// 0000000A2508: C8C6EB94 7576ED95
	v_dual_mul_f32 v119, v146, v119 :: v_dual_mul_f32 v120, v147, v120// 0000000A2510: C8C6EF92 7778F193
	v_dual_mul_f32 v105, v152, v105 :: v_dual_mul_f32 v106, v153, v106// 0000000A2518: C8C6D398 696AD599
	v_dual_mul_f32 v107, v150, v107 :: v_dual_mul_f32 v108, v151, v108// 0000000A2520: C8C6D796 6B6CD997
	v_dual_mul_f32 v109, v148, v109 :: v_dual_mul_f32 v110, v149, v110// 0000000A2528: C8C6DB94 6D6EDD95
	v_dual_mul_f32 v111, v146, v111 :: v_dual_mul_f32 v112, v147, v112// 0000000A2530: C8C6DF92 6F70E193
	v_dual_mul_f32 v97, v152, v97 :: v_dual_mul_f32 v98, v153, v98// 0000000A2538: C8C6C398 6162C599
	v_dual_mul_f32 v99, v150, v99 :: v_dual_mul_f32 v100, v151, v100// 0000000A2540: C8C6C796 6364C997
	v_dual_mul_f32 v101, v148, v101 :: v_dual_mul_f32 v102, v149, v102// 0000000A2548: C8C6CB94 6566CD95
	v_dual_mul_f32 v103, v146, v103 :: v_dual_mul_f32 v104, v147, v104// 0000000A2550: C8C6CF92 6768D193
	v_dual_mul_f32 v89, v152, v89 :: v_dual_mul_f32 v90, v153, v90// 0000000A2558: C8C6B398 595AB599
	v_dual_mul_f32 v91, v150, v91 :: v_dual_mul_f32 v92, v151, v92// 0000000A2560: C8C6B796 5B5CB997
	v_dual_mul_f32 v93, v148, v93 :: v_dual_mul_f32 v94, v149, v94// 0000000A2568: C8C6BB94 5D5EBD95
	v_dual_mul_f32 v95, v146, v95 :: v_dual_mul_f32 v96, v147, v96// 0000000A2570: C8C6BF92 5F60C193
	v_dual_mul_f32 v81, v152, v81 :: v_dual_mul_f32 v82, v153, v82// 0000000A2578: C8C6A398 5152A599
	v_dual_mul_f32 v83, v150, v83 :: v_dual_mul_f32 v84, v151, v84// 0000000A2580: C8C6A796 5354A997
	v_dual_mul_f32 v85, v148, v85 :: v_dual_mul_f32 v86, v149, v86// 0000000A2588: C8C6AB94 5556AD95
	v_dual_mul_f32 v87, v146, v87 :: v_dual_mul_f32 v88, v147, v88// 0000000A2590: C8C6AF92 5758B193
	v_dual_mul_f32 v73, v152, v73 :: v_dual_mul_f32 v74, v153, v74// 0000000A2598: C8C69398 494A9599
	v_dual_mul_f32 v75, v150, v75 :: v_dual_mul_f32 v76, v151, v76// 0000000A25A0: C8C69796 4B4C9997
	v_dual_mul_f32 v77, v148, v77 :: v_dual_mul_f32 v78, v149, v78// 0000000A25A8: C8C69B94 4D4E9D95
	v_dual_mul_f32 v79, v146, v79 :: v_dual_mul_f32 v80, v147, v80// 0000000A25B0: C8C69F92 4F50A193
	v_dual_mul_f32 v65, v152, v65 :: v_dual_mul_f32 v66, v153, v66// 0000000A25B8: C8C68398 41428599
	v_dual_mul_f32 v67, v150, v67 :: v_dual_mul_f32 v68, v151, v68// 0000000A25C0: C8C68796 43448997
	v_dual_mul_f32 v69, v148, v69 :: v_dual_mul_f32 v70, v149, v70// 0000000A25C8: C8C68B94 45468D95
	v_dual_mul_f32 v71, v146, v71 :: v_dual_mul_f32 v72, v147, v72// 0000000A25D0: C8C68F92 47489193
	v_dual_mul_f32 v57, v152, v57 :: v_dual_mul_f32 v58, v153, v58// 0000000A25D8: C8C67398 393A7599
	v_dual_mul_f32 v59, v150, v59 :: v_dual_mul_f32 v60, v151, v60// 0000000A25E0: C8C67796 3B3C7997
	v_dual_mul_f32 v61, v148, v61 :: v_dual_mul_f32 v62, v149, v62// 0000000A25E8: C8C67B94 3D3E7D95
	v_dual_mul_f32 v63, v146, v63 :: v_dual_mul_f32 v64, v147, v64// 0000000A25F0: C8C67F92 3F408193
	v_dual_mul_f32 v49, v152, v49 :: v_dual_mul_f32 v50, v153, v50// 0000000A25F8: C8C66398 31326599
	v_dual_mul_f32 v51, v150, v51 :: v_dual_mul_f32 v52, v151, v52// 0000000A2600: C8C66796 33346997
	v_dual_mul_f32 v53, v148, v53 :: v_dual_mul_f32 v54, v149, v54// 0000000A2608: C8C66B94 35366D95
	v_dual_mul_f32 v55, v146, v55 :: v_dual_mul_f32 v56, v147, v56// 0000000A2610: C8C66F92 37387193
	v_dual_mul_f32 v41, v152, v41 :: v_dual_mul_f32 v42, v153, v42// 0000000A2618: C8C65398 292A5599
	v_dual_mul_f32 v43, v150, v43 :: v_dual_mul_f32 v44, v151, v44// 0000000A2620: C8C65796 2B2C5997
	v_dual_mul_f32 v45, v148, v45 :: v_dual_mul_f32 v46, v149, v46// 0000000A2628: C8C65B94 2D2E5D95
	v_dual_mul_f32 v47, v146, v47 :: v_dual_mul_f32 v48, v147, v48// 0000000A2630: C8C65F92 2F306193
	v_dual_mul_f32 v33, v152, v33 :: v_dual_mul_f32 v34, v153, v34// 0000000A2638: C8C64398 21224599
	v_dual_mul_f32 v35, v150, v35 :: v_dual_mul_f32 v36, v151, v36// 0000000A2640: C8C64796 23244997
	v_dual_mul_f32 v37, v148, v37 :: v_dual_mul_f32 v38, v149, v38// 0000000A2648: C8C64B94 25264D95
	v_dual_mul_f32 v39, v146, v39 :: v_dual_mul_f32 v40, v147, v40// 0000000A2650: C8C64F92 27285193
	v_dual_mul_f32 v25, v152, v25 :: v_dual_mul_f32 v26, v153, v26// 0000000A2658: C8C63398 191A3599
	v_dual_mul_f32 v27, v150, v27 :: v_dual_mul_f32 v28, v151, v28// 0000000A2660: C8C63796 1B1C3997
	v_dual_mul_f32 v29, v148, v29 :: v_dual_mul_f32 v30, v149, v30// 0000000A2668: C8C63B94 1D1E3D95
	v_dual_mul_f32 v31, v146, v31 :: v_dual_mul_f32 v32, v147, v32// 0000000A2670: C8C63F92 1F204193
	v_dual_mul_f32 v17, v152, v17 :: v_dual_mul_f32 v18, v153, v18// 0000000A2678: C8C62398 11122599
	v_dual_mul_f32 v19, v150, v19 :: v_dual_mul_f32 v20, v151, v20// 0000000A2680: C8C62796 13142997
	v_dual_mul_f32 v21, v148, v21 :: v_dual_mul_f32 v22, v149, v22// 0000000A2688: C8C62B94 15162D95
	v_dual_mul_f32 v23, v146, v23 :: v_dual_mul_f32 v24, v147, v24// 0000000A2690: C8C62F92 17183193
	v_dual_mul_f32 v9, v152, v9 :: v_dual_mul_f32 v10, v153, v10// 0000000A2698: C8C61398 090A1599
	v_dual_mul_f32 v11, v150, v11 :: v_dual_mul_f32 v12, v151, v12// 0000000A26A0: C8C61796 0B0C1997
	v_dual_mul_f32 v13, v148, v13 :: v_dual_mul_f32 v14, v149, v14// 0000000A26A8: C8C61B94 0D0E1D95
	v_dual_mul_f32 v15, v146, v15 :: v_dual_mul_f32 v16, v147, v16// 0000000A26B0: C8C61F92 0F102193
	v_dual_mul_f32 v1, v152, v1 :: v_dual_mul_f32 v2, v153, v2 // 0000000A26B8: C8C60398 01020599
	v_dual_mul_f32 v3, v150, v3 :: v_dual_mul_f32 v4, v151, v4 // 0000000A26C0: C8C60796 03040997
	v_dual_mul_f32 v5, v148, v5 :: v_dual_mul_f32 v6, v149, v6 // 0000000A26C8: C8C60B94 05060D95
	v_dual_mul_f32 v7, v146, v7 :: v_dual_mul_f32 v8, v147, v8 // 0000000A26D0: C8C60F92 07081193
	s_branch 63451                                             // 0000000A26D8: BFA0F7DB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x748>
	v_lshlrev_b32_e32 v0, 2, v157                              // 0000000A26DC: 30013A82
	.long 0xd700008b                                           // 0000000A26E0: D700008B
	v_cndmask_b32_e32 v1, s18, v139, vcc_lo                    // 0000000A26E4: 02031612
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A26E8: BF870191
	v_add_co_ci_u32_e64 v140, null, s19, v140, s0              // 0000000A26EC: D5207C8C 00031813
	v_lshl_or_b32 v0, v156, 6, v0                              // 0000000A26F4: D6560000 04010D9C
	v_lshlrev_b32_e32 v147, 1, v154                            // 0000000A26FC: 31273481
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000000A2700: BF870152
	v_add_nc_u32_e32 v133, 0xa000, v0                          // 0000000A2704: 4B0A00FF 0000A000
	ds_load_2addr_b32 v[141:142], v133 offset0:128 offset1:130 // 0000000A270C: D8DC8280 8D000085
	s_waitcnt lgkmcnt(0)                                       // 0000000A2714: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 0000000A2718: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 0000000A2720: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 0000000A2728: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000000A272C: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 0000000A2730: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 0000000A2738: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:132 offset1:134 // 0000000A273C: D8DC8684 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:136 offset1:138 // 0000000A2744: D8DC8A88 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:140 offset1:142 // 0000000A274C: D8DC8E8C 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 0000000A2754: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000000A2758: 3505029F
	v_or_b32_e32 v0, v155, v157                                // 0000000A275C: 38013B9B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A2760: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 0000000A2764: 11252191
	.long 0xd73c0083                                           // 0000000A2768: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000000A276C: 02030281
	.long 0xd7000081                                           // 0000000A2770: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 0000000A2774: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000A2778: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 0000000A277C: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 0000000A2784: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A278C: BF870094
	.long 0xd7000083                                           // 0000000A2790: D7000083
	v_cndmask_b32_e32 v1, s16, v131, vcc_lo                    // 0000000A2794: 02030610
	v_add_co_ci_u32_e64 v132, null, s17, v132, s0              // 0000000A2798: D5207C84 00030811
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A27A0: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 0000000A27A4: 57252194
	.long 0xd4440000                                           // 0000000A27A8: D4440000
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 0000000A27AC: 0202000E
	v_fma_f32 v139, -v143, v146, v145                          // 0000000A27B0: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A27B8: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 0000000A27BC: D637008B 064B218B
	.long 0xd7006a83                                           // 0000000A27C4: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 0000000A27C8: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 0000000A27CC: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000A27D4: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 0000000A27D8: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 0000000A27E0: BE812000
	s_cbranch_execz 70                                         // 0000000A27E4: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2a00>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A27E8: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 0000000A27EC: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 0000000A27F8: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 0000000A27FC: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 0000000A2804: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 0000000A2808: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A280C: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 0000000A2810: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 0000000A2818: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 0000000A2824: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A2828: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 0000000A282C: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 0000000A2834: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000A2838: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 0000000A283C: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 0000000A2840: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 0000000A2844: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 0000000A284C: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2850: BF870095
	.long 0xd71c008d                                           // 0000000A2854: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 0000000A2858: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000A285C: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 0000000A2860: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2868: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 0000000A286C: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 0000000A2874: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2878: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 0000000A287C: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 0000000A2884: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2888: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 0000000A288C: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 0000000A2894: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 0000000A2898: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A28A0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000A28A4: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 0000000A28A8: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A28B0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000A28B4: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 0000000A28B8: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A28C0: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 0000000A28C4: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 0000000A28CC: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 0000000A28D4: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A28E0: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 0000000A28E4: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 0000000A28EC: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 0000000A28F8: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000A2900: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 0000000A2904: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 0000000A290C: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A2914: BF870292
	v_rcp_f32_e32 v140, v121                                   // 0000000A2918: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 0000000A291C: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2924: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 0000000A2928: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 0000000A292C: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2930: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 0000000A2934: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 0000000A293C: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2940: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 0000000A2944: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 0000000A294C: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 0000000A2954: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A2958: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 0000000A295C: D627008C 03CB1D8C
	.long 0xd4440001                                           // 0000000A2964: D4440001
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 0000000A2968: 0202F20E
	s_and_saveexec_b32 s2, s1                                  // 0000000A296C: BE822001
	s_cbranch_execz 69                                         // 0000000A2970: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2b88>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000000A2974: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 0000000A2980: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 0000000A2984: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000A298C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000A2990: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2994: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000A2998: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000A29A0: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000A29AC: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A29B0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000A29B4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000A29B8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000A29C0: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A29C8: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000A29CC: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000A29D0: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000A29D4: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A29D8: BF870095
	.long 0xd71c008e                                           // 0000000A29DC: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000A29E0: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000A29E4: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000A29E8: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A29F0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000A29F4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000A29FC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2A00: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 0000000A2A04: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000A2A0C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2A10: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000A2A14: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000A2A1C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 0000000A2A20: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2A28: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000A2A2C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000A2A30: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2A38: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000A2A3C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000A2A40: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2A48: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000A2A4C: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 0000000A2A54: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 0000000A2A5C: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2A68: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 0000000A2A6C: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 0000000A2A74: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 0000000A2A80: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 0000000A2A88: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 0000000A2A8C: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 0000000A2A90: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 0000000A2A98: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A2AA0: BF870292
	v_rcp_f32_e32 v141, v122                                   // 0000000A2AA4: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 0000000A2AA8: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2AB0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000A2AB4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000A2AB8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2ABC: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 0000000A2AC0: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 0000000A2AC8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2ACC: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 0000000A2AD0: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 0000000A2AD8: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 0000000A2AE0: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A2AE4: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 0000000A2AE8: D6270089 03CB138D
	.long 0xd4440002                                           // 0000000A2AF0: D4440002
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 0000000A2AF4: 0202F40E
	s_and_saveexec_b32 s3, s2                                  // 0000000A2AF8: BE832002
	s_cbranch_execz 69                                         // 0000000A2AFC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2d14>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 0000000A2B00: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 0000000A2B0C: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 0000000A2B10: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000A2B18: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000A2B1C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2B20: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000A2B24: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000A2B2C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000A2B38: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A2B3C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000A2B40: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000A2B44: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000A2B4C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A2B54: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000A2B58: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000A2B5C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000A2B60: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2B64: BF870095
	.long 0xd71c008e                                           // 0000000A2B68: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000A2B6C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000A2B70: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000A2B74: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2B7C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000A2B80: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000A2B88: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2B8C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 0000000A2B90: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000A2B98: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2B9C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000A2BA0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000A2BA8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 0000000A2BAC: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2BB4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000A2BB8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000A2BBC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2BC4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000A2BC8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000A2BCC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2BD4: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000A2BD8: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 0000000A2BE0: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 0000000A2BE8: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2BF4: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 0000000A2BF8: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 0000000A2C00: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 0000000A2C0C: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 0000000A2C14: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 0000000A2C18: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 0000000A2C20: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A2C28: BF870292
	v_rcp_f32_e32 v141, v123                                   // 0000000A2C2C: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 0000000A2C30: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2C38: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000A2C3C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000A2C40: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2C44: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 0000000A2C48: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 0000000A2C50: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2C54: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 0000000A2C58: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 0000000A2C60: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 0000000A2C68: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A2C6C: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 0000000A2C70: D627008A 03CB158D
	.long 0xd4440003                                           // 0000000A2C78: D4440003
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 0000000A2C7C: 0202F60E
	s_and_saveexec_b32 s4, s3                                  // 0000000A2C80: BE842003
	s_cbranch_execz 69                                         // 0000000A2C84: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2e9c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 0000000A2C88: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 0000000A2C94: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 0000000A2C98: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000A2CA0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000A2CA4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2CA8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000A2CAC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000A2CB4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000A2CC0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A2CC4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000A2CC8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000A2CCC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000A2CD4: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A2CDC: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000A2CE0: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000A2CE4: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000A2CE8: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2CEC: BF870095
	.long 0xd71c008e                                           // 0000000A2CF0: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000A2CF4: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000A2CF8: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000A2CFC: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2D04: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000A2D08: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000A2D10: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2D14: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 0000000A2D18: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000A2D20: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2D24: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000A2D28: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000A2D30: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 0000000A2D34: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2D3C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000A2D40: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000A2D44: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2D4C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000A2D50: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000A2D54: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2D5C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000A2D60: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 0000000A2D68: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 0000000A2D70: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2D7C: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 0000000A2D80: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 0000000A2D88: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 0000000A2D94: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A2D9C: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 0000000A2DA0: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 0000000A2DA4: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 0000000A2DAC: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A2DB4: BF870292
	v_rcp_f32_e32 v141, v124                                   // 0000000A2DB8: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 0000000A2DBC: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2DC4: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000A2DC8: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000A2DCC: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2DD0: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 0000000A2DD4: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 0000000A2DDC: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2DE0: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 0000000A2DE4: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 0000000A2DEC: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 0000000A2DF4: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A2DF8: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 0000000A2DFC: D6270087 03CB0F8D
	.long 0xd4440004                                           // 0000000A2E04: D4440004
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 0000000A2E08: 0202F80E
	s_and_saveexec_b32 s5, s4                                  // 0000000A2E0C: BE852004
	s_cbranch_execz 69                                         // 0000000A2E10: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3028>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 0000000A2E14: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 0000000A2E20: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 0000000A2E24: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000A2E2C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000A2E30: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2E34: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000A2E38: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000A2E40: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000A2E4C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A2E50: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000A2E54: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000A2E58: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000A2E60: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A2E68: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000A2E6C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000A2E70: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000A2E74: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2E78: BF870095
	.long 0xd71c008e                                           // 0000000A2E7C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000A2E80: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000A2E84: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000A2E88: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2E90: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000A2E94: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000A2E9C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2EA0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 0000000A2EA4: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000A2EAC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2EB0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000A2EB4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000A2EBC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 0000000A2EC0: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2EC8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000A2ECC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000A2ED0: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2ED8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000A2EDC: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000A2EE0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2EE8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000A2EEC: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 0000000A2EF4: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 0000000A2EFC: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2F08: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 0000000A2F0C: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 0000000A2F14: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 0000000A2F20: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000A2F28: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 0000000A2F2C: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 0000000A2F34: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A2F3C: BF870292
	v_rcp_f32_e32 v141, v125                                   // 0000000A2F40: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 0000000A2F44: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2F4C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000A2F50: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000A2F54: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2F58: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 0000000A2F5C: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 0000000A2F64: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2F68: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 0000000A2F6C: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 0000000A2F74: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 0000000A2F7C: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A2F80: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 0000000A2F84: D6270088 03CB118D
	.long 0xd4440005                                           // 0000000A2F8C: D4440005
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 0000000A2F90: 0202FA0E
	s_and_saveexec_b32 s6, s5                                  // 0000000A2F94: BE862005
	s_cbranch_execz 69                                         // 0000000A2F98: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x31b0>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 0000000A2F9C: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 0000000A2FA8: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 0000000A2FAC: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000A2FB4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000A2FB8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2FBC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000A2FC0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000A2FC8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000A2FD4: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A2FD8: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000A2FDC: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000A2FE0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000A2FE8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A2FF0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000A2FF4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000A2FF8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000A2FFC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3000: BF870095
	.long 0xd71c008e                                           // 0000000A3004: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000A3008: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000A300C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000A3010: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3018: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000A301C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000A3024: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3028: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 0000000A302C: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000A3034: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3038: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000A303C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000A3044: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 0000000A3048: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3050: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000A3054: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000A3058: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3060: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000A3064: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000A3068: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3070: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000A3074: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 0000000A307C: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 0000000A3084: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3090: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 0000000A3094: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 0000000A309C: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 0000000A30A8: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000A30B0: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000A30B4: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 0000000A30B8: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 0000000A30C0: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A30C8: BF870292
	v_rcp_f32_e32 v141, v126                                   // 0000000A30CC: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 0000000A30D0: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A30D8: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000A30DC: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000A30E0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A30E4: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 0000000A30E8: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 0000000A30F0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A30F4: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 0000000A30F8: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 0000000A3100: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 0000000A3108: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A310C: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 0000000A3110: D6270085 03CB0B8D
	.long 0xd4440006                                           // 0000000A3118: D4440006
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 0000000A311C: 0202FC0E
	s_and_saveexec_b32 s7, s6                                  // 0000000A3120: BE872006
	s_cbranch_execz 69                                         // 0000000A3124: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x333c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 0000000A3128: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 0000000A3134: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 0000000A3138: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000A3140: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000A3144: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3148: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000A314C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000A3154: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000A3160: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A3164: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000A3168: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000A316C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000A3174: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A317C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000A3180: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000A3184: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000A3188: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A318C: BF870095
	.long 0xd71c008e                                           // 0000000A3190: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000A3194: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000A3198: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000A319C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A31A4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000A31A8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000A31B0: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A31B4: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 0000000A31B8: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000A31C0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A31C4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000A31C8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000A31D0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 0000000A31D4: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A31DC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000A31E0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000A31E4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A31EC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000A31F0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000A31F4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A31FC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000A3200: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 0000000A3208: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 0000000A3210: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A321C: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 0000000A3220: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 0000000A3228: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 0000000A3234: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 0000000A323C: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 0000000A3240: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 0000000A3248: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A3250: BF870292
	v_rcp_f32_e32 v141, v127                                   // 0000000A3254: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 0000000A3258: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3260: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000000A3264: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000000A3268: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A326C: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 0000000A3270: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 0000000A3278: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A327C: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 0000000A3280: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 0000000A3288: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 0000000A3290: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A3294: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 0000000A3298: D6270086 03CB0D8D
	.long 0xd4440007                                           // 0000000A32A0: D4440007
	v_cndmask_b32_e32 v1, s14, v127, vcc_lo                    // 0000000A32A4: 0202FE0E
	s_and_saveexec_b32 s8, s7                                  // 0000000A32A8: BE882007
	s_cbranch_execnz 363                                       // 0000000A32AC: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x395c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A32B0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A32B4: BE882000
	s_cbranch_execnz 432                                       // 0000000A32B8: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A32BC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A32C0: BE882001
	s_cbranch_execnz 501                                       // 0000000A32C4: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A32C8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A32CC: BE882002
	s_cbranch_execnz 570                                       // 0000000A32D0: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A32D4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A32D8: BE882003
	s_cbranch_execnz 639                                       // 0000000A32DC: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ddc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A32E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A32E4: BE882004
	s_cbranch_execnz 708                                       // 0000000A32E8: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3efc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A32EC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A32F0: BE882005
	s_cbranch_execnz 777                                       // 0000000A32F4: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x401c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A32F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A32FC: BE882006
	s_cbranch_execnz 846                                       // 0000000A3300: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x413c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3304: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A3308: BE882007
	s_cbranch_execnz 915                                       // 0000000A330C: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x425c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3310: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A3314: BE882000
	s_cbranch_execnz 984                                       // 0000000A3318: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x437c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A331C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A3320: BE882001
	s_cbranch_execnz 1053                                      // 0000000A3324: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x449c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3328: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A332C: BE882002
	s_cbranch_execnz 1122                                      // 0000000A3330: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x45bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3334: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A3338: BE882003
	s_cbranch_execnz 1191                                      // 0000000A333C: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x46dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3340: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A3344: BE882004
	s_cbranch_execnz 1260                                      // 0000000A3348: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x47fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A334C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A3350: BE882005
	s_cbranch_execnz 1329                                      // 0000000A3354: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x491c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3358: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A335C: BE882006
	s_cbranch_execnz 1398                                      // 0000000A3360: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4a3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3364: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A3368: BE882007
	s_cbranch_execnz 1467                                      // 0000000A336C: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4b5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3370: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A3374: BE882000
	s_cbranch_execnz 1536                                      // 0000000A3378: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4c7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A337C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A3380: BE882001
	s_cbranch_execnz 1605                                      // 0000000A3384: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4d9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3388: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A338C: BE882002
	s_cbranch_execnz 1674                                      // 0000000A3390: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4ebc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3394: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A3398: BE882003
	s_cbranch_execnz 1743                                      // 0000000A339C: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4fdc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A33A0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A33A4: BE882004
	s_cbranch_execnz 1812                                      // 0000000A33A8: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x50fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A33AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A33B0: BE882005
	s_cbranch_execnz 1881                                      // 0000000A33B4: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x521c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A33B8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A33BC: BE882006
	s_cbranch_execnz 1950                                      // 0000000A33C0: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x533c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A33C4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A33C8: BE882007
	s_cbranch_execnz 2019                                      // 0000000A33CC: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x545c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A33D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A33D4: BE882000
	s_cbranch_execnz 2088                                      // 0000000A33D8: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x557c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A33DC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A33E0: BE882001
	s_cbranch_execnz 2157                                      // 0000000A33E4: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x569c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A33E8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A33EC: BE882002
	s_cbranch_execnz 2226                                      // 0000000A33F0: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x57bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A33F4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A33F8: BE882003
	s_cbranch_execnz 2295                                      // 0000000A33FC: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x58dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3400: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A3404: BE882004
	s_cbranch_execnz 2364                                      // 0000000A3408: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x59fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A340C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A3410: BE882005
	s_cbranch_execnz 2433                                      // 0000000A3414: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5b1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3418: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A341C: BE882006
	s_cbranch_execnz 2502                                      // 0000000A3420: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5c3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3424: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A3428: BE882007
	s_cbranch_execnz 2571                                      // 0000000A342C: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5d5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3430: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A3434: BE882000
	s_cbranch_execnz 2640                                      // 0000000A3438: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5e7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A343C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A3440: BE882001
	s_cbranch_execnz 2709                                      // 0000000A3444: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5f9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3448: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A344C: BE882002
	s_cbranch_execnz 2778                                      // 0000000A3450: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x60bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3454: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A3458: BE882003
	s_cbranch_execnz 2847                                      // 0000000A345C: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x61dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3460: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A3464: BE882004
	s_cbranch_execnz 2916                                      // 0000000A3468: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x62fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A346C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A3470: BE882005
	s_cbranch_execnz 2985                                      // 0000000A3474: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x641c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3478: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A347C: BE882006
	s_cbranch_execnz 3054                                      // 0000000A3480: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x653c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3484: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A3488: BE882007
	s_cbranch_execnz 3123                                      // 0000000A348C: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x665c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3490: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A3494: BE882000
	s_cbranch_execnz 3192                                      // 0000000A3498: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x677c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A349C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A34A0: BE882001
	s_cbranch_execnz 3261                                      // 0000000A34A4: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x689c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A34A8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A34AC: BE882002
	s_cbranch_execnz 3330                                      // 0000000A34B0: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x69bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A34B4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A34B8: BE882003
	s_cbranch_execnz 3399                                      // 0000000A34BC: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6adc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A34C0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A34C4: BE882004
	s_cbranch_execnz 3468                                      // 0000000A34C8: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6bfc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A34CC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A34D0: BE882005
	s_cbranch_execnz 3537                                      // 0000000A34D4: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6d1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A34D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A34DC: BE882006
	s_cbranch_execnz 3606                                      // 0000000A34E0: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6e3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A34E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A34E8: BE882007
	s_cbranch_execnz 3675                                      // 0000000A34EC: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6f5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A34F0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A34F4: BE882000
	s_cbranch_execnz 3744                                      // 0000000A34F8: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x707c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A34FC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A3500: BE882001
	s_cbranch_execnz 3813                                      // 0000000A3504: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x719c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3508: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A350C: BE882002
	s_cbranch_execnz 3882                                      // 0000000A3510: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x72bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3514: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A3518: BE882003
	s_cbranch_execnz 3951                                      // 0000000A351C: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x73dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3520: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A3524: BE882004
	s_cbranch_execnz 4020                                      // 0000000A3528: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x74fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A352C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A3530: BE882005
	s_cbranch_execnz 4089                                      // 0000000A3534: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x761c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3538: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A353C: BE882006
	s_cbranch_execnz 4158                                      // 0000000A3540: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x773c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3544: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A3548: BE882007
	s_cbranch_execnz 4227                                      // 0000000A354C: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x785c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3550: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A3554: BE882000
	s_cbranch_execnz 4296                                      // 0000000A3558: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x797c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A355C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A3560: BE882001
	s_cbranch_execnz 4365                                      // 0000000A3564: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7a9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3568: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A356C: BE882002
	s_cbranch_execnz 4434                                      // 0000000A3570: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7bbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3574: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A3578: BE882003
	s_cbranch_execnz 4503                                      // 0000000A357C: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7cdc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3580: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A3584: BE882004
	s_cbranch_execnz 4572                                      // 0000000A3588: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7dfc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A358C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A3590: BE882005
	s_cbranch_execnz 4641                                      // 0000000A3594: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7f1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3598: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A359C: BE882006
	s_cbranch_execnz 4710                                      // 0000000A35A0: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x803c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A35A4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A35A8: BE882007
	s_cbranch_execnz 4779                                      // 0000000A35AC: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x815c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A35B0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A35B4: BE882000
	s_cbranch_execnz 4848                                      // 0000000A35B8: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x827c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A35BC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A35C0: BE882001
	s_cbranch_execnz 4917                                      // 0000000A35C4: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x839c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A35C8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A35CC: BE882002
	s_cbranch_execnz 4986                                      // 0000000A35D0: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x84bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A35D4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A35D8: BE882003
	s_cbranch_execnz 5055                                      // 0000000A35DC: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x85dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A35E0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A35E4: BE882004
	s_cbranch_execnz 5124                                      // 0000000A35E8: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x86fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A35EC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A35F0: BE882005
	s_cbranch_execnz 5193                                      // 0000000A35F4: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x881c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A35F8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A35FC: BE882006
	s_cbranch_execnz 5262                                      // 0000000A3600: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x893c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3604: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A3608: BE882007
	s_cbranch_execnz 5331                                      // 0000000A360C: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8a5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3610: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A3614: BE882000
	s_cbranch_execnz 5400                                      // 0000000A3618: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A361C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A3620: BE882001
	s_cbranch_execnz 5469                                      // 0000000A3624: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8c9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3628: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A362C: BE882002
	s_cbranch_execnz 5538                                      // 0000000A3630: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8dbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3634: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A3638: BE882003
	s_cbranch_execnz 5607                                      // 0000000A363C: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8edc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3640: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A3644: BE882004
	s_cbranch_execnz 5676                                      // 0000000A3648: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8ffc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A364C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A3650: BE882005
	s_cbranch_execnz 5745                                      // 0000000A3654: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x911c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3658: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A365C: BE882006
	s_cbranch_execnz 5814                                      // 0000000A3660: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x923c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3664: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A3668: BE882007
	s_cbranch_execnz 5883                                      // 0000000A366C: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x935c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3670: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A3674: BE882000
	s_cbranch_execnz 5952                                      // 0000000A3678: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x947c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A367C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A3680: BE882001
	s_cbranch_execnz 6021                                      // 0000000A3684: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x959c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3688: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A368C: BE882002
	s_cbranch_execnz 6090                                      // 0000000A3690: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x96bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3694: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A3698: BE882003
	s_cbranch_execnz 6159                                      // 0000000A369C: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x97dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A36A0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A36A4: BE882004
	s_cbranch_execnz 6228                                      // 0000000A36A8: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x98fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A36AC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A36B0: BE882005
	s_cbranch_execnz 6297                                      // 0000000A36B4: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9a1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A36B8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A36BC: BE882006
	s_cbranch_execnz 6366                                      // 0000000A36C0: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9b3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A36C4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A36C8: BE882007
	s_cbranch_execnz 6435                                      // 0000000A36CC: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A36D0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A36D4: BE882000
	s_cbranch_execnz 6504                                      // 0000000A36D8: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9d7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A36DC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A36E0: BE882001
	s_cbranch_execnz 6573                                      // 0000000A36E4: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9e9c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A36E8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A36EC: BE882002
	s_cbranch_execnz 6642                                      // 0000000A36F0: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9fbc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A36F4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A36F8: BE882003
	s_cbranch_execnz 6711                                      // 0000000A36FC: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa0dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3700: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A3704: BE882004
	s_cbranch_execnz 6780                                      // 0000000A3708: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa1fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A370C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A3710: BE882005
	s_cbranch_execnz 6849                                      // 0000000A3714: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa31c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3718: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A371C: BE882006
	s_cbranch_execnz 6918                                      // 0000000A3720: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa43c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3724: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A3728: BE882007
	s_cbranch_execnz 6987                                      // 0000000A372C: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa55c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3730: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A3734: BE882000
	s_cbranch_execnz 7056                                      // 0000000A3738: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa67c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A373C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A3740: BE882001
	s_cbranch_execnz 7125                                      // 0000000A3744: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa79c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3748: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A374C: BE882002
	s_cbranch_execnz 7194                                      // 0000000A3750: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa8bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3754: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A3758: BE882003
	s_cbranch_execnz 7263                                      // 0000000A375C: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa9dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3760: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A3764: BE882004
	s_cbranch_execnz 7332                                      // 0000000A3768: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaafc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A376C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A3770: BE882005
	s_cbranch_execnz 7401                                      // 0000000A3774: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac1c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3778: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A377C: BE882006
	s_cbranch_execnz 7470                                      // 0000000A3780: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xad3c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3784: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A3788: BE882007
	s_cbranch_execnz 7539                                      // 0000000A378C: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xae5c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3790: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A3794: BE882000
	s_cbranch_execnz 7608                                      // 0000000A3798: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaf7c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A379C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A37A0: BE882001
	s_cbranch_execnz 7677                                      // 0000000A37A4: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb09c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A37A8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A37AC: BE882002
	s_cbranch_execnz 7746                                      // 0000000A37B0: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb1bc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A37B4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A37B8: BE882003
	s_cbranch_execnz 7815                                      // 0000000A37BC: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb2dc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A37C0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A37C4: BE882004
	s_cbranch_execnz 7884                                      // 0000000A37C8: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb3fc>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A37CC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A37D0: BE882005
	s_cbranch_execnz 7953                                      // 0000000A37D4: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb51c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A37D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A37DC: BE882006
	s_cbranch_execnz 8022                                      // 0000000A37E0: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb63c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A37E4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A37E8: BE882007
	s_cbranch_execnz 8091                                      // 0000000A37EC: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb75c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A37F0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A37F4: BE882000
	s_cbranch_execnz 8160                                      // 0000000A37F8: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb87c>
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A37FC: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 0000000A3800: BE802001
	s_cbranch_execnz 8229                                      // 0000000A3804: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb99c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000A3808: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000A380C: BE802002
	s_cbranch_execnz 8298                                      // 0000000A3810: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbabc>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000A3814: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000A3818: BE802003
	s_cbranch_execnz 8367                                      // 0000000A381C: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbbdc>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000A3820: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000A3824: BE802004
	s_cbranch_execnz 8436                                      // 0000000A3828: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbcfc>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000A382C: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000A3830: BE802005
	s_cbranch_execnz 8505                                      // 0000000A3834: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbe1c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000A3838: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000A383C: BE802006
	s_cbranch_execnz 8574                                      // 0000000A3840: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbf3c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000A3844: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000A3848: BE802007
	s_cbranch_execnz 8643                                      // 0000000A384C: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc05c>
	s_nop 0                                                    // 0000000A3850: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000000A3854: BFB60003
	s_endpgm                                                   // 0000000A3858: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 0000000A385C: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 0000000A3868: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 0000000A386C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000000A3874: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000000A3878: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A387C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000000A3880: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000000A3888: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000000A3894: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A3898: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000000A389C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000000A38A0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000000A38A8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A38B0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000000A38B4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000000A38B8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000000A38BC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A38C0: BF870095
	.long 0xd71c008e                                           // 0000000A38C4: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000000A38C8: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000000A38CC: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000000A38D0: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A38D8: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000000A38DC: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000000A38E4: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A38E8: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 0000000A38EC: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 0000000A38F4: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A38F8: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000000A38FC: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000000A3904: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 0000000A3908: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3910: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000000A3914: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000000A3918: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3920: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000000A3924: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000000A3928: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3930: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000000A3934: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 0000000A393C: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 0000000A3944: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3950: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 0000000A3954: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 0000000A395C: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 0000000A3968: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3970: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A3974: BE882000
	s_cbranch_execz 65104                                      // 0000000A3978: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33bc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 0000000A397C: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 0000000A3988: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 0000000A398C: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 0000000A3994: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 0000000A3998: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A399C: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 0000000A39A0: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 0000000A39A8: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 0000000A39B4: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A39B8: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 0000000A39BC: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 0000000A39C0: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 0000000A39C8: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A39D0: BF870121
	v_add_f32_e32 v141, v141, v142                             // 0000000A39D4: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 0000000A39D8: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 0000000A39DC: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A39E0: BF870095
	.long 0xd71c008d                                           // 0000000A39E4: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 0000000A39E8: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 0000000A39EC: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 0000000A39F0: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A39F8: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 0000000A39FC: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 0000000A3A04: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3A08: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 0000000A3A0C: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 0000000A3A14: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3A18: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 0000000A3A1C: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 0000000A3A24: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 0000000A3A28: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3A30: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 0000000A3A34: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 0000000A3A38: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3A40: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 0000000A3A44: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 0000000A3A48: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3A50: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 0000000A3A54: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 0000000A3A5C: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 0000000A3A64: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3A70: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 0000000A3A74: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 0000000A3A7C: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 0000000A3A88: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3A90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A3A94: BE882001
	s_cbranch_execz 65035                                      // 0000000A3A98: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33c8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 0000000A3A9C: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 0000000A3AA8: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 0000000A3AAC: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 0000000A3AB4: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000A3AB8: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3ABC: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 0000000A3AC0: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 0000000A3AC8: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 0000000A3AD4: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A3AD8: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 0000000A3ADC: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000A3AE0: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 0000000A3AE8: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A3AF0: BF870121
	v_add_f32_e32 v128, v128, v141                             // 0000000A3AF4: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 0000000A3AF8: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 0000000A3AFC: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3B00: BF870095
	.long 0xd71c0080                                           // 0000000A3B04: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 0000000A3B08: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 0000000A3B0C: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000A3B10: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3B18: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 0000000A3B1C: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000A3B24: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3B28: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 0000000A3B2C: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 0000000A3B34: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3B38: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 0000000A3B3C: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 0000000A3B44: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 0000000A3B48: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3B50: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 0000000A3B54: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 0000000A3B58: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3B60: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 0000000A3B64: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 0000000A3B68: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3B70: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 0000000A3B74: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 0000000A3B7C: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 0000000A3B84: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3B90: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 0000000A3B94: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 0000000A3B9C: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 0000000A3BA8: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3BB0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A3BB4: BE882002
	s_cbranch_execz 64966                                      // 0000000A3BB8: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33d4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 0000000A3BBC: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000A3BC8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000A3BD0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000A3BD4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3BD8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000A3BDC: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 0000000A3BE4: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 0000000A3BF0: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A3BF4: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 0000000A3BF8: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 0000000A3C00: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000A3C04: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 0000000A3C08: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 0000000A3C0C: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000A3C10: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 0000000A3C18: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3C1C: BF870095
	.long 0xd71c0072                                           // 0000000A3C20: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 0000000A3C24: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000A3C28: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000A3C2C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3C34: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 0000000A3C38: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000A3C44: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3C48: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000A3C4C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 0000000A3C54: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3C58: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 0000000A3C5C: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 0000000A3C64: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 0000000A3C68: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3C70: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 0000000A3C74: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 0000000A3C78: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3C80: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 0000000A3C84: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 0000000A3C88: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3C90: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 0000000A3C94: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000A3C9C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 0000000A3CA4: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3CB0: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 0000000A3CB4: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 0000000A3CBC: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000A3CC8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3CD0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A3CD4: BE882003
	s_cbranch_execz 64897                                      // 0000000A3CD8: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33e0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 0000000A3CDC: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000A3CE8: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000A3CF0: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000A3CF4: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3CF8: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000A3CFC: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000A3D04: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 0000000A3D10: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A3D14: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 0000000A3D18: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000A3D1C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000A3D24: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A3D2C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000A3D30: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 0000000A3D34: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 0000000A3D38: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3D3C: BF870095
	.long 0xd71c0072                                           // 0000000A3D40: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000A3D44: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000A3D48: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000A3D4C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3D54: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 0000000A3D58: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000A3D64: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3D68: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000A3D6C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000A3D74: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3D78: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 0000000A3D7C: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 0000000A3D84: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 0000000A3D88: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3D90: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 0000000A3D94: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 0000000A3D98: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3DA0: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 0000000A3DA4: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 0000000A3DA8: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3DB0: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 0000000A3DB4: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000A3DBC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 0000000A3DC4: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3DD0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000A3DD4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000A3DDC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000A3DE8: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3DF0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A3DF4: BE882004
	s_cbranch_execz 64828                                      // 0000000A3DF8: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33ec>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 0000000A3DFC: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000A3E08: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000A3E10: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000A3E14: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3E18: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000A3E1C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000A3E24: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000A3E30: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A3E34: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000A3E38: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000A3E3C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000A3E44: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A3E4C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000A3E50: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000A3E54: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000A3E58: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3E5C: BF870095
	.long 0xd71c0072                                           // 0000000A3E60: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000A3E64: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000A3E68: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000A3E6C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3E74: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 0000000A3E78: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000A3E84: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3E88: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000A3E8C: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000A3E94: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3E98: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000A3E9C: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000A3EA4: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000A3EA8: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3EB0: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 0000000A3EB4: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 0000000A3EB8: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3EC0: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 0000000A3EC4: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 0000000A3EC8: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3ED0: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 0000000A3ED4: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000A3EDC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 0000000A3EE4: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3EF0: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000A3EF4: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000A3EFC: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000A3F08: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A3F10: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A3F14: BE882005
	s_cbranch_execz 64759                                      // 0000000A3F18: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33f8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 0000000A3F1C: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000A3F28: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000A3F30: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000A3F34: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3F38: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000A3F3C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000A3F44: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000A3F50: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A3F54: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000A3F58: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000A3F5C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000A3F64: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A3F6C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000A3F70: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000A3F74: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000A3F78: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3F7C: BF870095
	.long 0xd71c0072                                           // 0000000A3F80: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000A3F84: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000A3F88: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000A3F8C: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3F94: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000A3F98: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 0000000A3FA0: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3FA8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000A3FAC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000A3FB4: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3FB8: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000A3FBC: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000A3FC4: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000A3FC8: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3FD0: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000A3FD4: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 0000000A3FD8: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3FE0: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 0000000A3FE4: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 0000000A3FE8: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3FF0: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000A3FF4: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000A3FFC: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 0000000A4004: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4010: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000A4014: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000A401C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000A4028: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A4030: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A4034: BE882006
	s_cbranch_execz 64690                                      // 0000000A4038: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3404>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 0000000A403C: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000A4048: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000A4050: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000A4054: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4058: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000A405C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000A4064: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000A4070: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A4074: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000A4078: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000A407C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000A4084: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A408C: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000A4090: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000A4094: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000A4098: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A409C: BF870095
	.long 0xd71c0072                                           // 0000000A40A0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000A40A4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000A40A8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000A40AC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A40B4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 0000000A40B8: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000A40C4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A40C8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000A40CC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000A40D4: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A40D8: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000A40DC: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000A40E4: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000A40E8: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A40F0: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000A40F4: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000A40F8: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4100: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000A4104: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000A4108: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4110: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000A4114: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000A411C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 0000000A4124: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4130: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000A4134: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000A413C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000A4148: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A4150: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A4154: BE882007
	s_cbranch_execz 64621                                      // 0000000A4158: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3410>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 0000000A415C: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000000A4168: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000A4170: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000A4174: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4178: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000A417C: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000A4184: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000A4190: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A4194: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000A4198: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000A419C: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000A41A4: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A41AC: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000A41B0: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000A41B4: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000A41B8: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A41BC: BF870095
	.long 0xd71c0072                                           // 0000000A41C0: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000A41C4: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000A41C8: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000A41CC: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A41D4: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 0000000A41D8: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000A41E4: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A41E8: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000000A41EC: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000000A41F4: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A41F8: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000000A41FC: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000000A4204: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000000A4208: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4210: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000000A4214: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000000A4218: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4220: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000000A4224: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000000A4228: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4230: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000000A4234: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000000A423C: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 0000000A4244: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4250: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000000A4254: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000000A425C: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000000A4268: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A4270: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A4274: BE882000
	s_cbranch_execz 64552                                      // 0000000A4278: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x341c>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 0000000A427C: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 0000000A4288: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 0000000A428C: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 0000000A4294: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000000A4298: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A429C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000000A42A0: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000000A42A8: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 0000000A42B4: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A42B8: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 0000000A42BC: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000000A42C0: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000000A42C8: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A42D0: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000000A42D4: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000000A42D8: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000000A42DC: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A42E0: BF870095
	.long 0xd71c0072                                           // 0000000A42E4: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000000A42E8: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000000A42EC: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000000A42F0: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A42F8: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000000A42FC: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000000A4304: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4308: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 0000000A430C: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 0000000A4314: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4318: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 0000000A431C: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 0000000A4324: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 0000000A4328: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4330: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 0000000A4334: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 0000000A4338: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4340: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 0000000A4344: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 0000000A4348: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4350: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 0000000A4354: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 0000000A435C: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 0000000A4364: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4370: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 0000000A4374: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 0000000A437C: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 0000000A4388: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A4390: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A4394: BE882001
	s_cbranch_execz 64483                                      // 0000000A4398: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3428>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 0000000A439C: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 0000000A43A8: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 0000000A43AC: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 0000000A43B4: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000A43B8: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A43BC: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 0000000A43C0: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000A43C8: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 0000000A43D0: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000000A43DC: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A43E0: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 0000000A43E4: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 0000000A43EC: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A43F0: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000000A43F4: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000000A43F8: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000000A43FC: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4400: BF870095
	.long 0xd71c0071                                           // 0000000A4404: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000000A4408: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000000A440C: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000A4410: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4418: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 0000000A441C: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000A4424: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4428: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 0000000A442C: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 0000000A4434: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4438: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 0000000A443C: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 0000000A4444: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 0000000A4448: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4450: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 0000000A4454: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 0000000A4458: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4460: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 0000000A4464: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 0000000A4468: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4470: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 0000000A4474: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 0000000A447C: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 0000000A4484: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4490: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 0000000A4494: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 0000000A449C: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 0000000A44A8: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A44B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A44B4: BE882002
	s_cbranch_execz 64414                                      // 0000000A44B8: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3434>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 0000000A44BC: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000A44C8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000A44D0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000A44D4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A44D8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000A44DC: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 0000000A44E4: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 0000000A44F0: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A44F4: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 0000000A44F8: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000A44FC: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 0000000A4504: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A450C: BF870121
	v_add_f32_e32 v106, v106, v113                             // 0000000A4510: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 0000000A4514: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 0000000A4518: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A451C: BF870095
	.long 0xd71c006a                                           // 0000000A4520: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 0000000A4524: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000A4528: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000A452C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4534: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 0000000A4538: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000A4544: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4548: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000A454C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 0000000A4554: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4558: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 0000000A455C: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 0000000A4564: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 0000000A4568: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4570: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 0000000A4574: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 0000000A4578: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4580: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 0000000A4584: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 0000000A4588: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4590: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 0000000A4594: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000A459C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 0000000A45A4: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A45B0: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 0000000A45B4: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 0000000A45BC: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000A45C8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A45D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A45D4: BE882003
	s_cbranch_execz 64345                                      // 0000000A45D8: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3440>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 0000000A45DC: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000A45E8: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000A45F0: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000A45F4: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A45F8: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000A45FC: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000A4604: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 0000000A4610: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4614: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 0000000A4618: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 0000000A4624: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 0000000A4628: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000A462C: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A4634: BF870293
	v_exp_f32_e32 v106, v106                                   // 0000000A4638: 7ED44B6A
	.long 0xd71c006a                                           // 0000000A463C: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000A4640: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A4644: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000A4648: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000A464C: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 0000000A4654: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4660: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 0000000A4664: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000A4668: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A4670: BF870291
	v_rcp_f32_e32 v108, v107                                   // 0000000A4674: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 0000000A4678: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A4680: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 0000000A4684: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 0000000A4688: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 0000000A4690: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4694: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 0000000A4698: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 0000000A46A0: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A46A4: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 0000000A46A8: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 0000000A46B0: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A46B8: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000A46BC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 0000000A46C4: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 0000000A46D0: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A46D8: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000A46DC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000A46E8: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A46F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A46F4: BE882004
	s_cbranch_execz 64276                                      // 0000000A46F8: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x344c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 0000000A46FC: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000A4708: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000A4710: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000A4714: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4718: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000A471C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000A4724: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000A4730: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A4734: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000A4738: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000A473C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000A4744: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A474C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000A4750: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000A4754: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000A4758: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A475C: BF870095
	.long 0xd71c006a                                           // 0000000A4760: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000A4764: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000A4768: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000A476C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4774: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 0000000A4778: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000A4784: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4788: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000A478C: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000A4794: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4798: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000A479C: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000A47A4: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000A47A8: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A47B0: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 0000000A47B4: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 0000000A47B8: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A47C0: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 0000000A47C4: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 0000000A47C8: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A47D0: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 0000000A47D4: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000A47DC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 0000000A47E4: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A47F0: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000A47F4: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000A47FC: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000A4808: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A4810: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A4814: BE882005
	s_cbranch_execz 64207                                      // 0000000A4818: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3458>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 0000000A481C: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000A4828: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000A4830: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000A4834: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4838: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000A483C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000A4844: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000A4850: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A4854: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000A4858: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000A485C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000A4864: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A486C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000A4870: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000A4874: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000A4878: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A487C: BF870095
	.long 0xd71c006a                                           // 0000000A4880: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000A4884: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000A4888: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000A488C: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4894: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000000A4898: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 0000000A48A0: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A48A8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000A48AC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000A48B4: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A48B8: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000A48BC: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000A48C4: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000A48C8: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A48D0: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000A48D4: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 0000000A48D8: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A48E0: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 0000000A48E4: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 0000000A48E8: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A48F0: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000A48F4: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000A48FC: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 0000000A4904: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4910: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000A4914: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000A491C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000A4928: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A4930: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A4934: BE882006
	s_cbranch_execz 64138                                      // 0000000A4938: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3464>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 0000000A493C: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000A4948: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000A4950: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000A4954: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4958: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000A495C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000A4964: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000A4970: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A4974: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000A4978: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000A497C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000A4984: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A498C: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000A4990: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000A4994: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000A4998: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A499C: BF870095
	.long 0xd71c006a                                           // 0000000A49A0: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000A49A4: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000A49A8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000A49AC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A49B4: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 0000000A49B8: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000A49C4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A49C8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000A49CC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000A49D4: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A49D8: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000A49DC: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000A49E4: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000A49E8: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A49F0: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000A49F4: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 0000000A49F8: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4A00: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 0000000A4A04: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 0000000A4A08: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4A10: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000A4A14: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000A4A1C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 0000000A4A24: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4A30: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000A4A34: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000A4A3C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000A4A48: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A4A50: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A4A54: BE882007
	s_cbranch_execz 64069                                      // 0000000A4A58: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3470>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 0000000A4A5C: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 0000000A4A68: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000A4A70: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000A4A74: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4A78: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000A4A7C: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000A4A84: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000A4A90: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A4A94: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000A4A98: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000A4A9C: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000A4AA4: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A4AAC: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000A4AB0: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000A4AB4: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000A4AB8: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4ABC: BF870095
	.long 0xd71c006a                                           // 0000000A4AC0: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000A4AC4: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000A4AC8: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000A4ACC: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4AD4: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 0000000A4AD8: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000A4AE4: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4AE8: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 0000000A4AEC: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 0000000A4AF4: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4AF8: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 0000000A4AFC: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 0000000A4B04: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 0000000A4B08: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4B10: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 0000000A4B14: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 0000000A4B18: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4B20: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 0000000A4B24: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 0000000A4B28: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4B30: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 0000000A4B34: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 0000000A4B3C: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 0000000A4B44: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4B50: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 0000000A4B54: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 0000000A4B5C: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 0000000A4B68: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A4B70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A4B74: BE882000
	s_cbranch_execz 64000                                      // 0000000A4B78: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x347c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 0000000A4B7C: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 0000000A4B88: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 0000000A4B8C: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 0000000A4B94: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000000A4B98: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4B9C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000000A4BA0: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 0000000A4BA8: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 0000000A4BB4: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A4BB8: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 0000000A4BBC: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000000A4BC0: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 0000000A4BC8: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A4BD0: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000000A4BD4: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000000A4BD8: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000000A4BDC: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4BE0: BF870095
	.long 0xd71c006a                                           // 0000000A4BE4: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000000A4BE8: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000000A4BEC: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000000A4BF0: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4BF8: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000000A4BFC: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000000A4C04: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4C08: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 0000000A4C0C: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 0000000A4C14: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4C18: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 0000000A4C1C: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 0000000A4C24: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 0000000A4C28: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4C30: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 0000000A4C34: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 0000000A4C38: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4C40: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 0000000A4C44: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 0000000A4C48: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4C50: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 0000000A4C54: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 0000000A4C5C: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 0000000A4C64: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4C70: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 0000000A4C74: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 0000000A4C7C: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 0000000A4C88: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A4C90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A4C94: BE882001
	s_cbranch_execz 63931                                      // 0000000A4C98: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3488>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 0000000A4C9C: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 0000000A4CA8: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 0000000A4CAC: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 0000000A4CB4: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000A4CB8: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A4CBC: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 0000000A4CC0: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000A4CC8: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 0000000A4CD0: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000000A4CDC: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A4CE0: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 0000000A4CE4: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 0000000A4CEC: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A4CF0: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000000A4CF4: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000000A4CF8: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000000A4CFC: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4D00: BF870095
	.long 0xd71c0069                                           // 0000000A4D04: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000000A4D08: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000000A4D0C: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000A4D10: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4D18: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 0000000A4D1C: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000A4D24: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4D28: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 0000000A4D2C: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 0000000A4D34: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4D38: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 0000000A4D3C: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 0000000A4D44: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 0000000A4D48: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4D50: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 0000000A4D54: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 0000000A4D58: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4D60: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 0000000A4D64: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 0000000A4D68: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4D70: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 0000000A4D74: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 0000000A4D7C: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 0000000A4D84: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4D90: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 0000000A4D94: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 0000000A4D9C: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 0000000A4DA8: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A4DB0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A4DB4: BE882002
	s_cbranch_execz 63862                                      // 0000000A4DB8: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3494>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 0000000A4DBC: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000A4DC8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000A4DD0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000A4DD4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4DD8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000A4DDC: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 0000000A4DE4: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 0000000A4DF0: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A4DF4: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 0000000A4DF8: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000A4DFC: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 0000000A4E04: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A4E0C: BF870121
	v_add_f32_e32 v98, v98, v105                               // 0000000A4E10: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 0000000A4E14: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 0000000A4E18: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4E1C: BF870095
	.long 0xd71c0062                                           // 0000000A4E20: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 0000000A4E24: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000A4E28: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000A4E2C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4E34: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 0000000A4E38: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000A4E44: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4E48: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000A4E4C: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 0000000A4E54: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4E58: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 0000000A4E5C: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 0000000A4E64: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 0000000A4E68: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4E70: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 0000000A4E74: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 0000000A4E78: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4E80: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 0000000A4E84: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 0000000A4E88: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4E90: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 0000000A4E94: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000A4E9C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 0000000A4EA4: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4EB0: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 0000000A4EB4: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 0000000A4EBC: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000A4EC8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A4ED0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A4ED4: BE882003
	s_cbranch_execz 63793                                      // 0000000A4ED8: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34a0>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 0000000A4EDC: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000A4EE8: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000A4EF0: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000A4EF4: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4EF8: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000A4EFC: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000A4F04: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 0000000A4F10: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4F14: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 0000000A4F18: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 0000000A4F24: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 0000000A4F28: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000A4F2C: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A4F34: BF870293
	v_exp_f32_e32 v98, v98                                     // 0000000A4F38: 7EC44B62
	.long 0xd71c0062                                           // 0000000A4F3C: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000A4F40: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A4F44: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000A4F48: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000A4F4C: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 0000000A4F54: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4F60: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 0000000A4F64: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000A4F68: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A4F70: BF870291
	v_rcp_f32_e32 v100, v99                                    // 0000000A4F74: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 0000000A4F78: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A4F80: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 0000000A4F84: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 0000000A4F88: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 0000000A4F90: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4F94: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 0000000A4F98: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 0000000A4FA0: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A4FA4: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 0000000A4FA8: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 0000000A4FB0: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A4FB8: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000A4FBC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 0000000A4FC4: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000A4FD0: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A4FD8: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000A4FDC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000A4FE8: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A4FF0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A4FF4: BE882004
	s_cbranch_execz 63724                                      // 0000000A4FF8: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34ac>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 0000000A4FFC: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000A5008: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000A5010: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000A5014: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5018: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000A501C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000A5024: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000A5030: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A5034: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000A5038: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000A503C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000A5044: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A504C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000A5050: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000A5054: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000A5058: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A505C: BF870095
	.long 0xd71c0062                                           // 0000000A5060: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000A5064: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000A5068: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000A506C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5074: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 0000000A5078: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000A5084: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5088: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000A508C: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000A5094: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5098: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000A509C: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000A50A4: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000A50A8: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A50B0: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 0000000A50B4: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 0000000A50B8: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A50C0: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 0000000A50C4: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 0000000A50C8: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A50D0: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 0000000A50D4: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000A50DC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 0000000A50E4: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A50F0: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000A50F4: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000A50FC: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000A5108: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A5110: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A5114: BE882005
	s_cbranch_execz 63655                                      // 0000000A5118: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34b8>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 0000000A511C: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000A5128: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000A5130: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000A5134: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5138: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000A513C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000A5144: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000A5150: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A5154: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000A5158: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000A515C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000A5164: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A516C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000A5170: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000A5174: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000A5178: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A517C: BF870095
	.long 0xd71c0062                                           // 0000000A5180: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000A5184: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000A5188: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000A518C: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5194: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000A5198: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 0000000A51A0: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A51A8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000A51AC: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000A51B4: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A51B8: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000A51BC: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000A51C4: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000A51C8: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A51D0: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000A51D4: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 0000000A51D8: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A51E0: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 0000000A51E4: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 0000000A51E8: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A51F0: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000A51F4: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000A51FC: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 0000000A5204: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5210: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000A5214: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000A521C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000A5228: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A5230: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A5234: BE882006
	s_cbranch_execz 63586                                      // 0000000A5238: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34c4>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 0000000A523C: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000A5248: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000A5250: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000A5254: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5258: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000A525C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000A5264: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000A5270: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A5274: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000A5278: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000A527C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000A5284: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A528C: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000A5290: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000A5294: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000A5298: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A529C: BF870095
	.long 0xd71c0062                                           // 0000000A52A0: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000A52A4: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000A52A8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000A52AC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A52B4: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 0000000A52B8: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000A52C4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A52C8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000A52CC: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000A52D4: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A52D8: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000A52DC: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000A52E4: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000A52E8: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A52F0: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000A52F4: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000A52F8: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5300: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000A5304: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000A5308: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5310: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000A5314: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000A531C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 0000000A5324: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5330: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000A5334: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000A533C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000A5348: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A5350: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A5354: BE882007
	s_cbranch_execz 63517                                      // 0000000A5358: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34d0>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 0000000A535C: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000000A5368: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000A5370: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000A5374: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5378: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000A537C: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000A5384: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000A5390: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A5394: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000A5398: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000A539C: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000A53A4: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A53AC: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000A53B0: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000A53B4: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000A53B8: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A53BC: BF870095
	.long 0xd71c0062                                           // 0000000A53C0: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000A53C4: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000A53C8: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000A53CC: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A53D4: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 0000000A53D8: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000A53E4: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A53E8: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000000A53EC: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000000A53F4: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A53F8: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000000A53FC: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000000A5404: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000000A5408: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5410: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000000A5414: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000000A5418: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5420: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000000A5424: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000000A5428: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5430: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000000A5434: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000000A543C: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 0000000A5444: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5450: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000000A5454: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000000A545C: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000000A5468: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A5470: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A5474: BE882000
	s_cbranch_execz 63448                                      // 0000000A5478: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34dc>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 0000000A547C: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 0000000A5488: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 0000000A548C: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 0000000A5494: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000000A5498: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A549C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000000A54A0: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000000A54A8: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 0000000A54B4: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A54B8: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 0000000A54BC: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000000A54C0: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 0000000A54C8: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A54D0: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000000A54D4: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000000A54D8: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000000A54DC: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A54E0: BF870095
	.long 0xd71c0062                                           // 0000000A54E4: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000000A54E8: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000000A54EC: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000000A54F0: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A54F8: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000000A54FC: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000000A5504: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5508: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 0000000A550C: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 0000000A5514: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5518: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000000A551C: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 0000000A5524: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 0000000A5528: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5530: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 0000000A5534: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 0000000A5538: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5540: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 0000000A5544: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 0000000A5548: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5550: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 0000000A5554: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 0000000A555C: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 0000000A5564: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5570: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 0000000A5574: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 0000000A557C: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 0000000A5588: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A5590: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A5594: BE882001
	s_cbranch_execz 63379                                      // 0000000A5598: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34e8>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 0000000A559C: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 0000000A55A8: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 0000000A55AC: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 0000000A55B4: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000A55B8: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A55BC: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 0000000A55C0: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000A55C8: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 0000000A55D0: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000000A55DC: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A55E0: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 0000000A55E4: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 0000000A55EC: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A55F0: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000000A55F4: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000000A55F8: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000000A55FC: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5600: BF870095
	.long 0xd71c0061                                           // 0000000A5604: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000000A5608: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000000A560C: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000A5610: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5618: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 0000000A561C: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000A5624: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5628: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 0000000A562C: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 0000000A5634: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5638: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 0000000A563C: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 0000000A5644: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 0000000A5648: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5650: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 0000000A5654: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 0000000A5658: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5660: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 0000000A5664: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 0000000A5668: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5670: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 0000000A5674: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 0000000A567C: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 0000000A5684: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5690: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 0000000A5694: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 0000000A569C: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 0000000A56A8: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A56B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A56B4: BE882002
	s_cbranch_execz 63310                                      // 0000000A56B8: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34f4>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 0000000A56BC: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000A56C8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000A56D0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000A56D4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A56D8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000A56DC: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 0000000A56E4: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 0000000A56F0: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A56F4: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 0000000A56F8: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000A56FC: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 0000000A5704: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A570C: BF870121
	v_add_f32_e32 v90, v90, v97                                // 0000000A5710: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 0000000A5714: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 0000000A5718: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A571C: BF870095
	.long 0xd71c005a                                           // 0000000A5720: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 0000000A5724: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000A5728: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000A572C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5734: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 0000000A5738: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000A5744: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5748: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000A574C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 0000000A5754: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5758: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 0000000A575C: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 0000000A5764: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 0000000A5768: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5770: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 0000000A5774: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 0000000A5778: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5780: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 0000000A5784: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 0000000A5788: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5790: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 0000000A5794: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000A579C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 0000000A57A4: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A57B0: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 0000000A57B4: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 0000000A57BC: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000A57C8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A57D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A57D4: BE882003
	s_cbranch_execz 63241                                      // 0000000A57D8: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3500>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 0000000A57DC: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000A57E8: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000A57F0: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000A57F4: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A57F8: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000A57FC: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000A5804: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 0000000A5810: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5814: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 0000000A5818: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 0000000A5824: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 0000000A5828: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000A582C: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A5834: BF870293
	v_exp_f32_e32 v90, v90                                     // 0000000A5838: 7EB44B5A
	.long 0xd71c005a                                           // 0000000A583C: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000A5840: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A5844: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000A5848: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000A584C: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 0000000A5854: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5860: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 0000000A5864: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000A5868: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A5870: BF870291
	v_rcp_f32_e32 v92, v91                                     // 0000000A5874: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 0000000A5878: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A5880: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 0000000A5884: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 0000000A5888: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 0000000A5890: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5894: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 0000000A5898: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 0000000A58A0: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A58A4: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 0000000A58A8: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 0000000A58B0: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A58B8: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000A58BC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 0000000A58C4: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000A58D0: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A58D8: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000A58DC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000A58E8: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A58F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A58F4: BE882004
	s_cbranch_execz 63172                                      // 0000000A58F8: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x350c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 0000000A58FC: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000A5908: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000A5910: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000A5914: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5918: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000A591C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000A5924: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000A5930: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A5934: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000A5938: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000A593C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000A5944: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A594C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000A5950: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000A5954: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000A5958: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A595C: BF870095
	.long 0xd71c005a                                           // 0000000A5960: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000A5964: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000A5968: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000A596C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5974: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 0000000A5978: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000A5984: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5988: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000A598C: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000A5994: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5998: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000A599C: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000A59A4: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000A59A8: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A59B0: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 0000000A59B4: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 0000000A59B8: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A59C0: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 0000000A59C4: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 0000000A59C8: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A59D0: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 0000000A59D4: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000A59DC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 0000000A59E4: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A59F0: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000A59F4: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000A59FC: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000A5A08: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A5A10: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A5A14: BE882005
	s_cbranch_execz 63103                                      // 0000000A5A18: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3518>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 0000000A5A1C: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000A5A28: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000A5A30: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000A5A34: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5A38: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000A5A3C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000A5A44: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000A5A50: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A5A54: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000A5A58: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000A5A5C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000A5A64: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A5A6C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000A5A70: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000A5A74: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000A5A78: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5A7C: BF870095
	.long 0xd71c005a                                           // 0000000A5A80: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000A5A84: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000A5A88: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000A5A8C: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5A94: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000000A5A98: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 0000000A5AA0: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5AA8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000A5AAC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000A5AB4: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5AB8: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000A5ABC: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000A5AC4: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000A5AC8: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5AD0: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000A5AD4: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 0000000A5AD8: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5AE0: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 0000000A5AE4: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 0000000A5AE8: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5AF0: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000A5AF4: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000A5AFC: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 0000000A5B04: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5B10: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000A5B14: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000A5B1C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000A5B28: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A5B30: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A5B34: BE882006
	s_cbranch_execz 63034                                      // 0000000A5B38: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3524>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 0000000A5B3C: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000A5B48: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000A5B50: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000A5B54: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5B58: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000A5B5C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000A5B64: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000A5B70: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A5B74: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000A5B78: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000A5B7C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000A5B84: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A5B8C: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000A5B90: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000A5B94: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000A5B98: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5B9C: BF870095
	.long 0xd71c005a                                           // 0000000A5BA0: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000A5BA4: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000A5BA8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000A5BAC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5BB4: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 0000000A5BB8: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000A5BC4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5BC8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000A5BCC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000A5BD4: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5BD8: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000A5BDC: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000A5BE4: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000A5BE8: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5BF0: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000A5BF4: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000000A5BF8: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5C00: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000000A5C04: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000000A5C08: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5C10: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000A5C14: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000A5C1C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 0000000A5C24: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5C30: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000A5C34: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000A5C3C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000A5C48: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A5C50: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A5C54: BE882007
	s_cbranch_execz 62965                                      // 0000000A5C58: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3530>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 0000000A5C5C: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 0000000A5C68: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000A5C70: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000A5C74: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5C78: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000A5C7C: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000A5C84: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000A5C90: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A5C94: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000A5C98: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000A5C9C: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000A5CA4: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A5CAC: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000A5CB0: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000A5CB4: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000A5CB8: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5CBC: BF870095
	.long 0xd71c005a                                           // 0000000A5CC0: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000A5CC4: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000A5CC8: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000A5CCC: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5CD4: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 0000000A5CD8: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000A5CE4: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5CE8: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000000A5CEC: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000000A5CF4: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5CF8: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000000A5CFC: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000000A5D04: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000000A5D08: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5D10: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000000A5D14: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000000A5D18: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5D20: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000000A5D24: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000000A5D28: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5D30: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000000A5D34: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000000A5D3C: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 0000000A5D44: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5D50: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 0000000A5D54: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 0000000A5D5C: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 0000000A5D68: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A5D70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A5D74: BE882000
	s_cbranch_execz 62896                                      // 0000000A5D78: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x353c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 0000000A5D7C: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 0000000A5D88: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 0000000A5D8C: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 0000000A5D94: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 0000000A5D98: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5D9C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 0000000A5DA0: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 0000000A5DA8: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 0000000A5DB4: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A5DB8: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 0000000A5DBC: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 0000000A5DC0: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 0000000A5DC8: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A5DD0: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000000A5DD4: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000000A5DD8: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000000A5DDC: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5DE0: BF870095
	.long 0xd71c005a                                           // 0000000A5DE4: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000000A5DE8: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000000A5DEC: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000000A5DF0: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5DF8: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000000A5DFC: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000000A5E04: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5E08: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 0000000A5E0C: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 0000000A5E14: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5E18: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 0000000A5E1C: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 0000000A5E24: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 0000000A5E28: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5E30: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 0000000A5E34: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 0000000A5E38: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5E40: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 0000000A5E44: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 0000000A5E48: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5E50: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 0000000A5E54: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 0000000A5E5C: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 0000000A5E64: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5E70: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 0000000A5E74: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 0000000A5E7C: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 0000000A5E88: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A5E90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A5E94: BE882001
	s_cbranch_execz 62827                                      // 0000000A5E98: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3548>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 0000000A5E9C: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 0000000A5EA8: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 0000000A5EAC: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 0000000A5EB4: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000A5EB8: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A5EBC: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 0000000A5EC0: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000A5EC8: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 0000000A5ED0: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000000A5EDC: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A5EE0: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 0000000A5EE4: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 0000000A5EEC: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A5EF0: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000000A5EF4: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000000A5EF8: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000000A5EFC: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5F00: BF870095
	.long 0xd71c0059                                           // 0000000A5F04: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000000A5F08: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000000A5F0C: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000A5F10: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5F18: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 0000000A5F1C: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000A5F24: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5F28: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 0000000A5F2C: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 0000000A5F34: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5F38: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 0000000A5F3C: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 0000000A5F44: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 0000000A5F48: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5F50: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 0000000A5F54: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 0000000A5F58: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5F60: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 0000000A5F64: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 0000000A5F68: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5F70: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 0000000A5F74: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 0000000A5F7C: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 0000000A5F84: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5F90: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 0000000A5F94: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 0000000A5F9C: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 0000000A5FA8: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A5FB0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A5FB4: BE882002
	s_cbranch_execz 62758                                      // 0000000A5FB8: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3554>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 0000000A5FBC: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000A5FC8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000A5FD0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000A5FD4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A5FD8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000A5FDC: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 0000000A5FE4: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 0000000A5FF0: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A5FF4: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 0000000A5FF8: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000A5FFC: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 0000000A6004: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A600C: BF870121
	v_add_f32_e32 v82, v82, v89                                // 0000000A6010: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 0000000A6014: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 0000000A6018: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A601C: BF870095
	.long 0xd71c0052                                           // 0000000A6020: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 0000000A6024: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000A6028: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000A602C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6034: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 0000000A6038: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000A6044: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6048: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000A604C: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 0000000A6054: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6058: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 0000000A605C: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 0000000A6064: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 0000000A6068: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6070: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 0000000A6074: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 0000000A6078: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6080: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 0000000A6084: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 0000000A6088: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6090: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 0000000A6094: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000A609C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 0000000A60A4: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A60B0: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 0000000A60B4: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 0000000A60BC: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000A60C8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A60D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A60D4: BE882003
	s_cbranch_execz 62689                                      // 0000000A60D8: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3560>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 0000000A60DC: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000A60E8: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000A60F0: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000A60F4: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A60F8: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000A60FC: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000A6104: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 0000000A6110: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6114: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 0000000A6118: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 0000000A6124: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 0000000A6128: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000A612C: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A6134: BF870293
	v_exp_f32_e32 v82, v82                                     // 0000000A6138: 7EA44B52
	.long 0xd71c0052                                           // 0000000A613C: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000A6140: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A6144: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000A6148: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000A614C: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 0000000A6154: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6160: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 0000000A6164: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000A6168: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A6170: BF870291
	v_rcp_f32_e32 v84, v83                                     // 0000000A6174: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 0000000A6178: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A6180: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 0000000A6184: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 0000000A6188: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 0000000A6190: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6194: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 0000000A6198: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 0000000A61A0: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A61A4: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 0000000A61A8: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 0000000A61B0: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A61B8: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000A61BC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 0000000A61C4: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000A61D0: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A61D8: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000A61DC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000A61E8: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A61F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A61F4: BE882004
	s_cbranch_execz 62620                                      // 0000000A61F8: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x356c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 0000000A61FC: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000A6208: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000A6210: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000A6214: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6218: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000A621C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000A6224: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000A6230: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A6234: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000A6238: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000A623C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000A6244: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A624C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000A6250: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000A6254: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000A6258: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A625C: BF870095
	.long 0xd71c0052                                           // 0000000A6260: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000A6264: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000A6268: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000A626C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6274: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 0000000A6278: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000A6284: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6288: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000A628C: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000A6294: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6298: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000A629C: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000A62A4: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000A62A8: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A62B0: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 0000000A62B4: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 0000000A62B8: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A62C0: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 0000000A62C4: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 0000000A62C8: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A62D0: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 0000000A62D4: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000A62DC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 0000000A62E4: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A62F0: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000A62F4: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000A62FC: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000A6308: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A6310: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A6314: BE882005
	s_cbranch_execz 62551                                      // 0000000A6318: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3578>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 0000000A631C: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000A6328: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000A6330: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000A6334: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6338: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000A633C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000A6344: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000A6350: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A6354: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000A6358: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000A635C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000A6364: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A636C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000A6370: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000A6374: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000A6378: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A637C: BF870095
	.long 0xd71c0052                                           // 0000000A6380: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000A6384: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000A6388: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000A638C: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6394: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 0000000A6398: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 0000000A63A0: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A63A8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000A63AC: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000A63B4: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A63B8: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000A63BC: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000A63C4: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000A63C8: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A63D0: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000A63D4: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 0000000A63D8: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A63E0: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 0000000A63E4: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 0000000A63E8: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A63F0: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000A63F4: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000A63FC: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 0000000A6404: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6410: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000A6414: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000A641C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000A6428: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A6430: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A6434: BE882006
	s_cbranch_execz 62482                                      // 0000000A6438: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3584>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 0000000A643C: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000A6448: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000A6450: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000A6454: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6458: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000A645C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000A6464: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000A6470: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A6474: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000A6478: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000A647C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000A6484: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A648C: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000A6490: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000A6494: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000A6498: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A649C: BF870095
	.long 0xd71c0052                                           // 0000000A64A0: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000A64A4: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000A64A8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000A64AC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A64B4: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 0000000A64B8: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000A64C4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A64C8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000A64CC: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000A64D4: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A64D8: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000A64DC: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000A64E4: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000A64E8: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A64F0: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000A64F4: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000A64F8: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6500: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000A6504: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000A6508: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6510: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000A6514: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000A651C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 0000000A6524: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6530: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000A6534: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000A653C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000A6548: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A6550: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A6554: BE882007
	s_cbranch_execz 62413                                      // 0000000A6558: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3590>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 0000000A655C: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000000A6568: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000A6570: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000A6574: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6578: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000A657C: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000A6584: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000A6590: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A6594: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000A6598: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000A659C: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000A65A4: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A65AC: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000A65B0: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000A65B4: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000A65B8: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A65BC: BF870095
	.long 0xd71c0052                                           // 0000000A65C0: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000A65C4: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000A65C8: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000A65CC: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A65D4: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 0000000A65D8: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000A65E4: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A65E8: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000000A65EC: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000000A65F4: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A65F8: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000000A65FC: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000000A6604: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000000A6608: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6610: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000000A6614: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000000A6618: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6620: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000000A6624: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000000A6628: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6630: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000000A6634: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000000A663C: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 0000000A6644: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6650: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000000A6654: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000000A665C: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000000A6668: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A6670: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A6674: BE882000
	s_cbranch_execz 62344                                      // 0000000A6678: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x359c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 0000000A667C: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 0000000A6688: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 0000000A668C: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000000A6694: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000000A6698: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A669C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000000A66A0: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000000A66A8: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 0000000A66B4: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A66B8: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 0000000A66BC: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000000A66C0: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 0000000A66C8: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A66D0: BF870121
	v_add_f32_e32 v82, v82, v83                                // 0000000A66D4: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 0000000A66D8: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 0000000A66DC: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A66E0: BF870095
	.long 0xd71c0052                                           // 0000000A66E4: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 0000000A66E8: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000000A66EC: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000000A66F0: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A66F8: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 0000000A66FC: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000000A6704: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6708: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 0000000A670C: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 0000000A6714: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6718: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 0000000A671C: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 0000000A6724: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 0000000A6728: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6730: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 0000000A6734: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 0000000A6738: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6740: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 0000000A6744: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 0000000A6748: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6750: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 0000000A6754: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 0000000A675C: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 0000000A6764: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6770: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 0000000A6774: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 0000000A677C: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 0000000A6788: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A6790: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A6794: BE882001
	s_cbranch_execz 62275                                      // 0000000A6798: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35a8>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 0000000A679C: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 0000000A67A8: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 0000000A67AC: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 0000000A67B4: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000A67B8: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A67BC: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 0000000A67C0: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000A67C8: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 0000000A67D0: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 0000000A67DC: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A67E0: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 0000000A67E4: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 0000000A67EC: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A67F0: BF870121
	v_add_f32_e32 v81, v81, v82                                // 0000000A67F4: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 0000000A67F8: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 0000000A67FC: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6800: BF870095
	.long 0xd71c0051                                           // 0000000A6804: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000000A6808: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000000A680C: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000A6810: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6818: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 0000000A681C: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000A6824: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6828: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 0000000A682C: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 0000000A6834: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6838: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 0000000A683C: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 0000000A6844: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 0000000A6848: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6850: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 0000000A6854: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 0000000A6858: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6860: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 0000000A6864: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 0000000A6868: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6870: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 0000000A6874: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 0000000A687C: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 0000000A6884: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6890: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 0000000A6894: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 0000000A689C: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 0000000A68A8: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A68B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A68B4: BE882002
	s_cbranch_execz 62206                                      // 0000000A68B8: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35b4>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 0000000A68BC: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000A68C8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000A68D0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000A68D4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A68D8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000A68DC: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 0000000A68E4: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 0000000A68F0: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A68F4: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 0000000A68F8: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000A68FC: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 0000000A6904: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A690C: BF870121
	v_add_f32_e32 v74, v74, v81                                // 0000000A6910: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 0000000A6914: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 0000000A6918: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A691C: BF870095
	.long 0xd71c004a                                           // 0000000A6920: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 0000000A6924: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000A6928: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000A692C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6934: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 0000000A6938: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000A6944: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6948: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000A694C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 0000000A6954: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6958: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 0000000A695C: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 0000000A6964: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 0000000A6968: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6970: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 0000000A6974: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 0000000A6978: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6980: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 0000000A6984: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 0000000A6988: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6990: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 0000000A6994: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000A699C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 0000000A69A4: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A69B0: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 0000000A69B4: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 0000000A69BC: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000A69C8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A69D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A69D4: BE882003
	s_cbranch_execz 62137                                      // 0000000A69D8: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35c0>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 0000000A69DC: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000A69E8: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000A69F0: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000A69F4: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A69F8: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000A69FC: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000A6A04: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 0000000A6A10: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6A14: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 0000000A6A18: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 0000000A6A24: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 0000000A6A28: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000A6A2C: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A6A34: BF870293
	v_exp_f32_e32 v74, v74                                     // 0000000A6A38: 7E944B4A
	.long 0xd71c004a                                           // 0000000A6A3C: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000A6A40: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A6A44: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000A6A48: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000A6A4C: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 0000000A6A54: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6A60: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 0000000A6A64: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000A6A68: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A6A70: BF870291
	v_rcp_f32_e32 v76, v75                                     // 0000000A6A74: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 0000000A6A78: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A6A80: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 0000000A6A84: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 0000000A6A88: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 0000000A6A90: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6A94: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 0000000A6A98: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 0000000A6AA0: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6AA4: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 0000000A6AA8: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 0000000A6AB0: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A6AB8: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000A6ABC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 0000000A6AC4: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000A6AD0: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A6AD8: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000A6ADC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000A6AE8: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A6AF0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A6AF4: BE882004
	s_cbranch_execz 62068                                      // 0000000A6AF8: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35cc>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 0000000A6AFC: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000A6B08: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000A6B10: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000A6B14: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6B18: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000A6B1C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000A6B24: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000A6B30: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A6B34: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000A6B38: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000A6B3C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000A6B44: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A6B4C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000A6B50: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000A6B54: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000A6B58: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6B5C: BF870095
	.long 0xd71c004a                                           // 0000000A6B60: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000A6B64: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000A6B68: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000A6B6C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6B74: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 0000000A6B78: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000A6B84: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6B88: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000A6B8C: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000A6B94: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6B98: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000A6B9C: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000A6BA4: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000A6BA8: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6BB0: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 0000000A6BB4: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 0000000A6BB8: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6BC0: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 0000000A6BC4: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 0000000A6BC8: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6BD0: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 0000000A6BD4: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000A6BDC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 0000000A6BE4: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6BF0: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000A6BF4: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000A6BFC: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000A6C08: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A6C10: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A6C14: BE882005
	s_cbranch_execz 61999                                      // 0000000A6C18: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35d8>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 0000000A6C1C: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000A6C28: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000A6C30: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000A6C34: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6C38: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000A6C3C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000A6C44: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000A6C50: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A6C54: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000A6C58: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000A6C5C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000A6C64: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A6C6C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000A6C70: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000A6C74: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000A6C78: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6C7C: BF870095
	.long 0xd71c004a                                           // 0000000A6C80: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000A6C84: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000A6C88: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000A6C8C: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6C94: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000000A6C98: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 0000000A6CA0: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6CA8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000A6CAC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000A6CB4: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6CB8: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000A6CBC: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000A6CC4: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000A6CC8: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6CD0: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000A6CD4: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 0000000A6CD8: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6CE0: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 0000000A6CE4: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 0000000A6CE8: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6CF0: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000A6CF4: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000A6CFC: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 0000000A6D04: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6D10: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000A6D14: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000A6D1C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000A6D28: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A6D30: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A6D34: BE882006
	s_cbranch_execz 61930                                      // 0000000A6D38: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35e4>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 0000000A6D3C: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000A6D48: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000A6D50: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000A6D54: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6D58: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000A6D5C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000A6D64: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000A6D70: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A6D74: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000A6D78: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000A6D7C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000A6D84: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A6D8C: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000A6D90: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000A6D94: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000A6D98: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6D9C: BF870095
	.long 0xd71c004a                                           // 0000000A6DA0: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000A6DA4: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000A6DA8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000A6DAC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6DB4: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 0000000A6DB8: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000A6DC4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6DC8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000A6DCC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000A6DD4: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6DD8: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000A6DDC: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000A6DE4: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000A6DE8: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6DF0: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000A6DF4: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000A6DF8: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6E00: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000A6E04: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000A6E08: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6E10: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000A6E14: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000A6E1C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 0000000A6E24: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6E30: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000A6E34: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000A6E3C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000A6E48: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A6E50: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A6E54: BE882007
	s_cbranch_execz 61861                                      // 0000000A6E58: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35f0>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 0000000A6E5C: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000000A6E68: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000A6E70: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000A6E74: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6E78: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000A6E7C: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000A6E84: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000A6E90: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A6E94: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000A6E98: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000A6E9C: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000A6EA4: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A6EAC: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000A6EB0: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000A6EB4: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000A6EB8: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6EBC: BF870095
	.long 0xd71c004a                                           // 0000000A6EC0: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000A6EC4: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000A6EC8: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000A6ECC: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6ED4: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 0000000A6ED8: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000A6EE4: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6EE8: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000000A6EEC: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000000A6EF4: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6EF8: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000000A6EFC: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000000A6F04: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000000A6F08: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6F10: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000000A6F14: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000000A6F18: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6F20: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000000A6F24: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000000A6F28: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6F30: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000000A6F34: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000000A6F3C: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 0000000A6F44: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6F50: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000000A6F54: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000000A6F5C: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000000A6F68: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A6F70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A6F74: BE882000
	s_cbranch_execz 61792                                      // 0000000A6F78: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35fc>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 0000000A6F7C: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 0000000A6F88: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 0000000A6F8C: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 0000000A6F94: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000000A6F98: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6F9C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 0000000A6FA0: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 0000000A6FA8: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 0000000A6FB4: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A6FB8: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 0000000A6FBC: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000000A6FC0: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 0000000A6FC8: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A6FD0: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000000A6FD4: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000000A6FD8: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000000A6FDC: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6FE0: BF870095
	.long 0xd71c004a                                           // 0000000A6FE4: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000000A6FE8: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000000A6FEC: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000000A6FF0: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A6FF8: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000000A6FFC: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000000A7004: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7008: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 0000000A700C: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 0000000A7014: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7018: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000000A701C: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000000A7024: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 0000000A7028: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7030: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 0000000A7034: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 0000000A7038: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7040: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 0000000A7044: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 0000000A7048: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7050: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 0000000A7054: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 0000000A705C: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 0000000A7064: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7070: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 0000000A7074: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 0000000A707C: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 0000000A7088: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A7090: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A7094: BE882001
	s_cbranch_execz 61723                                      // 0000000A7098: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3608>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 0000000A709C: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 0000000A70A8: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 0000000A70AC: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 0000000A70B4: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000A70B8: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A70BC: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 0000000A70C0: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000A70C8: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 0000000A70D0: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000000A70DC: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A70E0: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 0000000A70E4: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 0000000A70EC: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A70F0: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000000A70F4: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000000A70F8: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000000A70FC: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7100: BF870095
	.long 0xd71c0049                                           // 0000000A7104: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000000A7108: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000000A710C: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000A7110: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7118: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 0000000A711C: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000A7124: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7128: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 0000000A712C: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 0000000A7134: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7138: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 0000000A713C: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 0000000A7144: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 0000000A7148: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7150: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 0000000A7154: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 0000000A7158: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7160: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 0000000A7164: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 0000000A7168: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7170: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 0000000A7174: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 0000000A717C: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 0000000A7184: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7190: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 0000000A7194: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 0000000A719C: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 0000000A71A8: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A71B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A71B4: BE882002
	s_cbranch_execz 61654                                      // 0000000A71B8: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3614>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 0000000A71BC: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000A71C8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000A71D0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000A71D4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A71D8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000A71DC: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 0000000A71E4: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 0000000A71F0: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A71F4: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 0000000A71F8: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000A71FC: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 0000000A7204: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A720C: BF870121
	v_add_f32_e32 v66, v66, v73                                // 0000000A7210: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 0000000A7214: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 0000000A7218: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A721C: BF870095
	.long 0xd71c0042                                           // 0000000A7220: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 0000000A7224: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000A7228: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000A722C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7234: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 0000000A7238: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000A7244: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7248: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000A724C: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 0000000A7254: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7258: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 0000000A725C: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 0000000A7264: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 0000000A7268: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7270: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 0000000A7274: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 0000000A7278: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7280: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 0000000A7284: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 0000000A7288: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7290: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 0000000A7294: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000A729C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 0000000A72A4: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A72B0: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 0000000A72B4: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 0000000A72BC: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000A72C8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A72D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A72D4: BE882003
	s_cbranch_execz 61585                                      // 0000000A72D8: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3620>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 0000000A72DC: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000A72E8: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000A72F0: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000A72F4: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A72F8: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000A72FC: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000A7304: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 0000000A7310: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7314: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 0000000A7318: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 0000000A7324: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 0000000A7328: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000A732C: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A7334: BF870293
	v_exp_f32_e32 v66, v66                                     // 0000000A7338: 7E844B42
	.long 0xd71c0042                                           // 0000000A733C: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000A7340: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A7344: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000A7348: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000A734C: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 0000000A7354: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7360: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 0000000A7364: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000A7368: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A7370: BF870291
	v_rcp_f32_e32 v68, v67                                     // 0000000A7374: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 0000000A7378: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A7380: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 0000000A7384: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 0000000A7388: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 0000000A7390: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7394: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 0000000A7398: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 0000000A73A0: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A73A4: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 0000000A73A8: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 0000000A73B0: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A73B8: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000A73BC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 0000000A73C4: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000A73D0: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A73D8: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000A73DC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000A73E8: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A73F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A73F4: BE882004
	s_cbranch_execz 61516                                      // 0000000A73F8: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x362c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 0000000A73FC: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000A7408: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000A7410: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000A7414: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7418: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000A741C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000A7424: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000A7430: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A7434: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000A7438: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000A743C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000A7444: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A744C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000A7450: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000A7454: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000A7458: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A745C: BF870095
	.long 0xd71c0042                                           // 0000000A7460: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000A7464: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000A7468: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000A746C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7474: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 0000000A7478: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000A7484: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7488: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000A748C: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000A7494: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7498: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000A749C: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000A74A4: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000A74A8: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A74B0: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 0000000A74B4: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 0000000A74B8: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A74C0: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 0000000A74C4: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 0000000A74C8: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A74D0: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 0000000A74D4: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000A74DC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 0000000A74E4: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A74F0: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000A74F4: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000A74FC: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000A7508: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A7510: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A7514: BE882005
	s_cbranch_execz 61447                                      // 0000000A7518: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3638>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 0000000A751C: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000A7528: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000A7530: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000A7534: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7538: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000A753C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000A7544: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000A7550: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A7554: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000A7558: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000A755C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000A7564: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A756C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000A7570: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000A7574: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000A7578: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A757C: BF870095
	.long 0xd71c0042                                           // 0000000A7580: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000A7584: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000A7588: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000A758C: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7594: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 0000000A7598: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 0000000A75A0: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A75A8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000A75AC: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000A75B4: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A75B8: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000A75BC: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000A75C4: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000A75C8: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A75D0: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000A75D4: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 0000000A75D8: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A75E0: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 0000000A75E4: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 0000000A75E8: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A75F0: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000A75F4: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000A75FC: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 0000000A7604: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7610: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000A7614: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000A761C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000A7628: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A7630: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A7634: BE882006
	s_cbranch_execz 61378                                      // 0000000A7638: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3644>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 0000000A763C: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000A7648: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000A7650: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000A7654: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7658: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000A765C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000A7664: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000A7670: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A7674: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000A7678: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000A767C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000A7684: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A768C: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000A7690: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000A7694: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000A7698: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A769C: BF870095
	.long 0xd71c0042                                           // 0000000A76A0: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000A76A4: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000A76A8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000A76AC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A76B4: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 0000000A76B8: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000A76C4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A76C8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000A76CC: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000A76D4: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A76D8: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000A76DC: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000A76E4: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000A76E8: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A76F0: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000A76F4: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000A76F8: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7700: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000A7704: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000A7708: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7710: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000A7714: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000A771C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 0000000A7724: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7730: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000A7734: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000A773C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000A7748: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A7750: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A7754: BE882007
	s_cbranch_execz 61309                                      // 0000000A7758: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3650>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 0000000A775C: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000000A7768: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000A7770: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000A7774: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7778: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000A777C: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000A7784: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000A7790: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A7794: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000A7798: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000A779C: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000A77A4: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A77AC: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000A77B0: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000A77B4: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000A77B8: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A77BC: BF870095
	.long 0xd71c0042                                           // 0000000A77C0: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000A77C4: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000A77C8: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000A77CC: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A77D4: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 0000000A77D8: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000A77E4: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A77E8: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 0000000A77EC: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 0000000A77F4: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A77F8: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 0000000A77FC: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 0000000A7804: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 0000000A7808: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7810: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 0000000A7814: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 0000000A7818: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7820: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 0000000A7824: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 0000000A7828: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7830: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 0000000A7834: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000000A783C: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 0000000A7844: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7850: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000000A7854: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000000A785C: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000000A7868: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A7870: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A7874: BE882000
	s_cbranch_execz 61240                                      // 0000000A7878: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x365c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 0000000A787C: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 0000000A7888: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 0000000A788C: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 0000000A7894: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000000A7898: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A789C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000000A78A0: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000000A78A8: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 0000000A78B4: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A78B8: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 0000000A78BC: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000000A78C0: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 0000000A78C8: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A78D0: BF870121
	v_add_f32_e32 v66, v66, v67                                // 0000000A78D4: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 0000000A78D8: 7E861144
	v_exp_f32_e32 v66, v66                                     // 0000000A78DC: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A78E0: BF870095
	.long 0xd71c0042                                           // 0000000A78E4: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 0000000A78E8: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000000A78EC: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000000A78F0: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A78F8: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 0000000A78FC: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000000A7904: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7908: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 0000000A790C: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 0000000A7914: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7918: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 0000000A791C: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 0000000A7924: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 0000000A7928: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7930: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 0000000A7934: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 0000000A7938: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7940: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 0000000A7944: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 0000000A7948: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7950: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 0000000A7954: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 0000000A795C: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 0000000A7964: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7970: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 0000000A7974: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 0000000A797C: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 0000000A7988: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A7990: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A7994: BE882001
	s_cbranch_execz 61171                                      // 0000000A7998: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3668>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 0000000A799C: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 0000000A79A8: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 0000000A79AC: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 0000000A79B4: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000A79B8: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A79BC: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 0000000A79C0: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000A79C8: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 0000000A79D0: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 0000000A79DC: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A79E0: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 0000000A79E4: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 0000000A79EC: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A79F0: BF870121
	v_add_f32_e32 v65, v65, v66                                // 0000000A79F4: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 0000000A79F8: 7E841143
	v_exp_f32_e32 v65, v65                                     // 0000000A79FC: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7A00: BF870095
	.long 0xd71c0041                                           // 0000000A7A04: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 0000000A7A08: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 0000000A7A0C: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000A7A10: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7A18: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 0000000A7A1C: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000A7A24: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7A28: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 0000000A7A2C: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 0000000A7A34: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7A38: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 0000000A7A3C: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 0000000A7A44: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 0000000A7A48: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7A50: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 0000000A7A54: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 0000000A7A58: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7A60: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 0000000A7A64: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 0000000A7A68: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7A70: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 0000000A7A74: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 0000000A7A7C: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 0000000A7A84: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7A90: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 0000000A7A94: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 0000000A7A9C: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 0000000A7AA8: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A7AB0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A7AB4: BE882002
	s_cbranch_execz 61102                                      // 0000000A7AB8: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3674>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 0000000A7ABC: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000A7AC8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000A7AD0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000A7AD4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7AD8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000A7ADC: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 0000000A7AE4: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 0000000A7AF0: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A7AF4: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 0000000A7AF8: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000A7AFC: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 0000000A7B04: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A7B0C: BF870121
	v_add_f32_e32 v58, v58, v65                                // 0000000A7B10: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 0000000A7B14: 7E821142
	v_exp_f32_e32 v58, v58                                     // 0000000A7B18: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7B1C: BF870095
	.long 0xd71c003a                                           // 0000000A7B20: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 0000000A7B24: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000A7B28: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000A7B2C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7B34: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 0000000A7B38: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000A7B44: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7B48: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000A7B4C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 0000000A7B54: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7B58: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 0000000A7B5C: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 0000000A7B64: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 0000000A7B68: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7B70: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 0000000A7B74: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 0000000A7B78: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7B80: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 0000000A7B84: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 0000000A7B88: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7B90: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 0000000A7B94: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000A7B9C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 0000000A7BA4: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7BB0: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 0000000A7BB4: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 0000000A7BBC: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000A7BC8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A7BD0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A7BD4: BE882003
	s_cbranch_execz 61033                                      // 0000000A7BD8: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3680>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 0000000A7BDC: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000A7BE8: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000A7BF0: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000A7BF4: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7BF8: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000A7BFC: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000A7C04: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 0000000A7C10: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7C14: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 0000000A7C18: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 0000000A7C24: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 0000000A7C28: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000A7C2C: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A7C34: BF870293
	v_exp_f32_e32 v58, v58                                     // 0000000A7C38: 7E744B3A
	.long 0xd71c003a                                           // 0000000A7C3C: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000A7C40: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A7C44: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000A7C48: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000A7C4C: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 0000000A7C54: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7C60: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 0000000A7C64: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000A7C68: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A7C70: BF870291
	v_rcp_f32_e32 v60, v59                                     // 0000000A7C74: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 0000000A7C78: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A7C80: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 0000000A7C84: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 0000000A7C88: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 0000000A7C90: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7C94: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 0000000A7C98: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 0000000A7CA0: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7CA4: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 0000000A7CA8: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 0000000A7CB0: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A7CB8: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000A7CBC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 0000000A7CC4: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000A7CD0: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A7CD8: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000A7CDC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000A7CE8: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A7CF0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A7CF4: BE882004
	s_cbranch_execz 60964                                      // 0000000A7CF8: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x368c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 0000000A7CFC: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000A7D08: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000A7D10: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000A7D14: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7D18: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000A7D1C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000A7D24: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000A7D30: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A7D34: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000A7D38: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000A7D3C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000A7D44: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A7D4C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000A7D50: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000A7D54: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000A7D58: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7D5C: BF870095
	.long 0xd71c003a                                           // 0000000A7D60: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000A7D64: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000A7D68: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000A7D6C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7D74: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 0000000A7D78: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000A7D84: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7D88: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000A7D8C: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000A7D94: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7D98: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000A7D9C: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000A7DA4: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000A7DA8: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7DB0: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 0000000A7DB4: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 0000000A7DB8: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7DC0: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 0000000A7DC4: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 0000000A7DC8: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7DD0: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 0000000A7DD4: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000A7DDC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 0000000A7DE4: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7DF0: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000A7DF4: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000A7DFC: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000A7E08: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A7E10: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A7E14: BE882005
	s_cbranch_execz 60895                                      // 0000000A7E18: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3698>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 0000000A7E1C: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000A7E28: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000A7E30: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000A7E34: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7E38: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000A7E3C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000A7E44: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000A7E50: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A7E54: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000A7E58: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000A7E5C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000A7E64: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A7E6C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000A7E70: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000A7E74: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000A7E78: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7E7C: BF870095
	.long 0xd71c003a                                           // 0000000A7E80: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000A7E84: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000A7E88: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000A7E8C: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7E94: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000A7E98: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 0000000A7EA0: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7EA8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000A7EAC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000A7EB4: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7EB8: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000A7EBC: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000A7EC4: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000A7EC8: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7ED0: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000A7ED4: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 0000000A7ED8: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7EE0: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 0000000A7EE4: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 0000000A7EE8: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7EF0: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000A7EF4: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000A7EFC: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 0000000A7F04: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7F10: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000A7F14: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000A7F1C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000A7F28: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A7F30: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A7F34: BE882006
	s_cbranch_execz 60826                                      // 0000000A7F38: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36a4>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 0000000A7F3C: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000A7F48: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000A7F50: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000A7F54: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7F58: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000A7F5C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000A7F64: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000A7F70: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A7F74: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000A7F78: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000A7F7C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000A7F84: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A7F8C: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000A7F90: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000A7F94: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000A7F98: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7F9C: BF870095
	.long 0xd71c003a                                           // 0000000A7FA0: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000A7FA4: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000A7FA8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000A7FAC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7FB4: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 0000000A7FB8: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000A7FC4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7FC8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000A7FCC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000A7FD4: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7FD8: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000A7FDC: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000A7FE4: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000A7FE8: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A7FF0: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000A7FF4: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000A7FF8: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8000: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000A8004: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000A8008: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8010: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000A8014: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000A801C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 0000000A8024: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8030: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000A8034: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000A803C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000A8048: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A8050: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A8054: BE882007
	s_cbranch_execz 60757                                      // 0000000A8058: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36b0>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 0000000A805C: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000000A8068: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000A8070: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000A8074: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8078: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000A807C: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000A8084: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000A8090: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A8094: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000A8098: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000A809C: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000A80A4: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A80AC: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000A80B0: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000A80B4: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000A80B8: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A80BC: BF870095
	.long 0xd71c003a                                           // 0000000A80C0: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000A80C4: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000A80C8: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000A80CC: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A80D4: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 0000000A80D8: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000A80E4: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A80E8: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000000A80EC: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000000A80F4: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A80F8: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000000A80FC: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000000A8104: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000000A8108: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8110: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000000A8114: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000000A8118: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8120: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000000A8124: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000000A8128: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8130: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000000A8134: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000000A813C: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 0000000A8144: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8150: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000000A8154: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000000A815C: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000000A8168: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A8170: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A8174: BE882000
	s_cbranch_execz 60688                                      // 0000000A8178: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36bc>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 0000000A817C: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 0000000A8188: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 0000000A818C: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 0000000A8194: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000000A8198: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A819C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000000A81A0: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000000A81A8: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 0000000A81B4: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A81B8: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 0000000A81BC: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 0000000A81C0: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 0000000A81C8: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A81D0: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000000A81D4: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000000A81D8: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000000A81DC: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A81E0: BF870095
	.long 0xd71c003a                                           // 0000000A81E4: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000000A81E8: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000000A81EC: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000000A81F0: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A81F8: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000000A81FC: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000000A8204: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8208: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 0000000A820C: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 0000000A8214: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8218: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 0000000A821C: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 0000000A8224: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 0000000A8228: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8230: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 0000000A8234: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 0000000A8238: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8240: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 0000000A8244: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 0000000A8248: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8250: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 0000000A8254: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 0000000A825C: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 0000000A8264: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8270: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 0000000A8274: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 0000000A827C: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 0000000A8288: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A8290: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A8294: BE882001
	s_cbranch_execz 60619                                      // 0000000A8298: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36c8>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 0000000A829C: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 0000000A82A8: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 0000000A82AC: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 0000000A82B4: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000A82B8: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A82BC: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 0000000A82C0: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000A82C8: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 0000000A82D0: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 0000000A82DC: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A82E0: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 0000000A82E4: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 0000000A82EC: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A82F0: BF870121
	v_add_f32_e32 v57, v57, v58                                // 0000000A82F4: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 0000000A82F8: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 0000000A82FC: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8300: BF870095
	.long 0xd71c0039                                           // 0000000A8304: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000000A8308: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000000A830C: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000A8310: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8318: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 0000000A831C: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000A8324: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8328: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 0000000A832C: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 0000000A8334: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8338: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 0000000A833C: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 0000000A8344: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 0000000A8348: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8350: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 0000000A8354: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 0000000A8358: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8360: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 0000000A8364: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 0000000A8368: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8370: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 0000000A8374: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 0000000A837C: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 0000000A8384: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8390: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 0000000A8394: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000000A839C: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 0000000A83A8: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A83B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A83B4: BE882002
	s_cbranch_execz 60550                                      // 0000000A83B8: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36d4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 0000000A83BC: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000A83C8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000A83D0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000A83D4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A83D8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000A83DC: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 0000000A83E4: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 0000000A83F0: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A83F4: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 0000000A83F8: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000A83FC: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 0000000A8404: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A840C: BF870121
	v_add_f32_e32 v50, v50, v57                                // 0000000A8410: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 0000000A8414: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 0000000A8418: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A841C: BF870095
	.long 0xd71c0032                                           // 0000000A8420: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 0000000A8424: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000A8428: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000A842C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8434: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 0000000A8438: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000A8444: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8448: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000A844C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 0000000A8454: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8458: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 0000000A845C: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 0000000A8464: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 0000000A8468: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8470: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 0000000A8474: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 0000000A8478: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8480: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 0000000A8484: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 0000000A8488: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8490: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 0000000A8494: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000A849C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 0000000A84A4: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A84B0: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 0000000A84B4: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 0000000A84BC: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000A84C8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A84D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A84D4: BE882003
	s_cbranch_execz 60481                                      // 0000000A84D8: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36e0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 0000000A84DC: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000A84E8: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000A84F0: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000A84F4: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A84F8: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000A84FC: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000A8504: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 0000000A8510: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8514: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 0000000A8518: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 0000000A8524: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 0000000A8528: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000A852C: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A8534: BF870293
	v_exp_f32_e32 v50, v50                                     // 0000000A8538: 7E644B32
	.long 0xd71c0032                                           // 0000000A853C: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000A8540: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A8544: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000A8548: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000A854C: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 0000000A8554: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8560: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 0000000A8564: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000A8568: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A8570: BF870291
	v_rcp_f32_e32 v52, v51                                     // 0000000A8574: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 0000000A8578: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A8580: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 0000000A8584: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 0000000A8588: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 0000000A8590: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8594: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 0000000A8598: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 0000000A85A0: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A85A4: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 0000000A85A8: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 0000000A85B0: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A85B8: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000A85BC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 0000000A85C4: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000A85D0: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A85D8: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000A85DC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000A85E8: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A85F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A85F4: BE882004
	s_cbranch_execz 60412                                      // 0000000A85F8: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36ec>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 0000000A85FC: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000A8608: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000A8610: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000A8614: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8618: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000A861C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000A8624: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000A8630: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A8634: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000A8638: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000A863C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000A8644: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A864C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000A8650: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000A8654: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000A8658: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A865C: BF870095
	.long 0xd71c0032                                           // 0000000A8660: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000A8664: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000A8668: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000A866C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8674: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 0000000A8678: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000A8684: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8688: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000A868C: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000A8694: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8698: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000A869C: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000A86A4: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000A86A8: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A86B0: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 0000000A86B4: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 0000000A86B8: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A86C0: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 0000000A86C4: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 0000000A86C8: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A86D0: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 0000000A86D4: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000A86DC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 0000000A86E4: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A86F0: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000A86F4: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000A86FC: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000A8708: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A8710: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A8714: BE882005
	s_cbranch_execz 60343                                      // 0000000A8718: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36f8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 0000000A871C: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000A8728: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000A8730: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000A8734: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8738: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000A873C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000A8744: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000A8750: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A8754: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000A8758: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000A875C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000A8764: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A876C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000A8770: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000A8774: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000A8778: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A877C: BF870095
	.long 0xd71c0032                                           // 0000000A8780: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000A8784: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000A8788: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000A878C: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8794: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 0000000A8798: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 0000000A87A0: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A87A8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000A87AC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000A87B4: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A87B8: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000A87BC: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000A87C4: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000A87C8: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A87D0: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000A87D4: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 0000000A87D8: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A87E0: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 0000000A87E4: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 0000000A87E8: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A87F0: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000A87F4: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000A87FC: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 0000000A8804: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8810: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000A8814: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000A881C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000A8828: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A8830: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A8834: BE882006
	s_cbranch_execz 60274                                      // 0000000A8838: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3704>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 0000000A883C: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000A8848: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000A8850: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000A8854: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8858: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000A885C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000A8864: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000A8870: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A8874: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000A8878: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000A887C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000A8884: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A888C: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000A8890: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000A8894: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000A8898: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A889C: BF870095
	.long 0xd71c0032                                           // 0000000A88A0: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000A88A4: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000A88A8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000A88AC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A88B4: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 0000000A88B8: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000A88C4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A88C8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000A88CC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000A88D4: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A88D8: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000A88DC: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000A88E4: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000A88E8: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A88F0: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000A88F4: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 0000000A88F8: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8900: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 0000000A8904: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000A8908: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8910: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000A8914: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000A891C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 0000000A8924: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8930: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000A8934: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000A893C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000A8948: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A8950: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A8954: BE882007
	s_cbranch_execz 60205                                      // 0000000A8958: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3710>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 0000000A895C: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000000A8968: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000A8970: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000A8974: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8978: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000A897C: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000A8984: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000A8990: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A8994: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000A8998: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000A899C: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000A89A4: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A89AC: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000A89B0: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000A89B4: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000A89B8: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A89BC: BF870095
	.long 0xd71c0032                                           // 0000000A89C0: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000A89C4: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000A89C8: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000A89CC: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A89D4: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 0000000A89D8: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000A89E4: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A89E8: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 0000000A89EC: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 0000000A89F4: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A89F8: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 0000000A89FC: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 0000000A8A04: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 0000000A8A08: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8A10: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 0000000A8A14: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 0000000A8A18: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8A20: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 0000000A8A24: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 0000000A8A28: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8A30: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 0000000A8A34: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 0000000A8A3C: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 0000000A8A44: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8A50: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000A8A54: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 0000000A8A5C: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 0000000A8A68: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A8A70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A8A74: BE882000
	s_cbranch_execz 60136                                      // 0000000A8A78: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x371c>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 0000000A8A7C: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 0000000A8A88: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 0000000A8A8C: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 0000000A8A94: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000000A8A98: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8A9C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000000A8AA0: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000000A8AA8: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 0000000A8AB4: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A8AB8: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 0000000A8ABC: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000000A8AC0: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 0000000A8AC8: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A8AD0: BF870121
	v_add_f32_e32 v50, v50, v51                                // 0000000A8AD4: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 0000000A8AD8: 7E661134
	v_exp_f32_e32 v50, v50                                     // 0000000A8ADC: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8AE0: BF870095
	.long 0xd71c0032                                           // 0000000A8AE4: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 0000000A8AE8: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000000A8AEC: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000000A8AF0: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8AF8: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 0000000A8AFC: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000000A8B04: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8B08: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 0000000A8B0C: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 0000000A8B14: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8B18: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 0000000A8B1C: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 0000000A8B24: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 0000000A8B28: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8B30: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 0000000A8B34: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 0000000A8B38: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8B40: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 0000000A8B44: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 0000000A8B48: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8B50: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 0000000A8B54: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 0000000A8B5C: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 0000000A8B64: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8B70: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 0000000A8B74: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 0000000A8B7C: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 0000000A8B88: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A8B90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A8B94: BE882001
	s_cbranch_execz 60067                                      // 0000000A8B98: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3728>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 0000000A8B9C: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 0000000A8BA8: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 0000000A8BAC: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 0000000A8BB4: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000A8BB8: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A8BBC: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 0000000A8BC0: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000A8BC8: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 0000000A8BD0: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 0000000A8BDC: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A8BE0: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 0000000A8BE4: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 0000000A8BEC: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A8BF0: BF870121
	v_add_f32_e32 v49, v49, v50                                // 0000000A8BF4: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 0000000A8BF8: 7E641133
	v_exp_f32_e32 v49, v49                                     // 0000000A8BFC: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8C00: BF870095
	.long 0xd71c0031                                           // 0000000A8C04: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 0000000A8C08: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000000A8C0C: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000A8C10: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8C18: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 0000000A8C1C: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000A8C24: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8C28: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 0000000A8C2C: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 0000000A8C34: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8C38: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 0000000A8C3C: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 0000000A8C44: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 0000000A8C48: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8C50: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 0000000A8C54: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 0000000A8C58: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8C60: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 0000000A8C64: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 0000000A8C68: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8C70: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 0000000A8C74: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 0000000A8C7C: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 0000000A8C84: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8C90: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 0000000A8C94: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 0000000A8C9C: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 0000000A8CA8: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A8CB0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A8CB4: BE882002
	s_cbranch_execz 59998                                      // 0000000A8CB8: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3734>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 0000000A8CBC: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000A8CC8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000A8CD0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000A8CD4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8CD8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000A8CDC: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 0000000A8CE4: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 0000000A8CF0: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A8CF4: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 0000000A8CF8: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000A8CFC: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 0000000A8D04: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A8D0C: BF870121
	v_add_f32_e32 v42, v42, v49                                // 0000000A8D10: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 0000000A8D14: 7E621132
	v_exp_f32_e32 v42, v42                                     // 0000000A8D18: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8D1C: BF870095
	.long 0xd71c002a                                           // 0000000A8D20: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 0000000A8D24: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000A8D28: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000A8D2C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8D34: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 0000000A8D38: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000A8D44: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8D48: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000A8D4C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 0000000A8D54: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8D58: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 0000000A8D5C: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 0000000A8D64: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 0000000A8D68: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8D70: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 0000000A8D74: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 0000000A8D78: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8D80: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 0000000A8D84: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 0000000A8D88: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8D90: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 0000000A8D94: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000A8D9C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 0000000A8DA4: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8DB0: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 0000000A8DB4: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 0000000A8DBC: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000A8DC8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A8DD0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A8DD4: BE882003
	s_cbranch_execz 59929                                      // 0000000A8DD8: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3740>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 0000000A8DDC: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000A8DE8: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000A8DF0: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000A8DF4: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8DF8: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000A8DFC: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000A8E04: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 0000000A8E10: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8E14: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 0000000A8E18: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 0000000A8E24: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 0000000A8E28: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000A8E2C: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A8E34: BF870293
	v_exp_f32_e32 v42, v42                                     // 0000000A8E38: 7E544B2A
	.long 0xd71c002a                                           // 0000000A8E3C: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000A8E40: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A8E44: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000A8E48: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000A8E4C: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 0000000A8E54: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8E60: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 0000000A8E64: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000A8E68: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A8E70: BF870291
	v_rcp_f32_e32 v44, v43                                     // 0000000A8E74: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 0000000A8E78: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A8E80: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 0000000A8E84: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 0000000A8E88: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 0000000A8E90: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8E94: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 0000000A8E98: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 0000000A8EA0: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8EA4: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 0000000A8EA8: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 0000000A8EB0: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A8EB8: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000A8EBC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 0000000A8EC4: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000A8ED0: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A8ED8: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000A8EDC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000A8EE8: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A8EF0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A8EF4: BE882004
	s_cbranch_execz 59860                                      // 0000000A8EF8: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x374c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 0000000A8EFC: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000A8F08: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000A8F10: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000A8F14: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8F18: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000A8F1C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000A8F24: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000A8F30: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A8F34: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000A8F38: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000A8F3C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000A8F44: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A8F4C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000A8F50: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000A8F54: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000A8F58: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8F5C: BF870095
	.long 0xd71c002a                                           // 0000000A8F60: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000A8F64: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000A8F68: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000A8F6C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8F74: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 0000000A8F78: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000A8F84: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8F88: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000A8F8C: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000A8F94: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8F98: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000A8F9C: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000A8FA4: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000A8FA8: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8FB0: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 0000000A8FB4: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 0000000A8FB8: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8FC0: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 0000000A8FC4: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 0000000A8FC8: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8FD0: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 0000000A8FD4: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000A8FDC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 0000000A8FE4: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A8FF0: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000A8FF4: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000A8FFC: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000A9008: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A9010: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A9014: BE882005
	s_cbranch_execz 59791                                      // 0000000A9018: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3758>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 0000000A901C: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000A9028: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000A9030: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000A9034: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9038: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000A903C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000A9044: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000A9050: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A9054: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000A9058: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000A905C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000A9064: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A906C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000A9070: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000A9074: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000A9078: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A907C: BF870095
	.long 0xd71c002a                                           // 0000000A9080: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000A9084: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000A9088: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000A908C: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9094: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000A9098: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 0000000A90A0: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A90A8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000A90AC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000A90B4: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A90B8: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000A90BC: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000A90C4: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000A90C8: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A90D0: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000A90D4: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 0000000A90D8: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A90E0: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 0000000A90E4: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 0000000A90E8: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A90F0: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000A90F4: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000A90FC: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 0000000A9104: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9110: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000A9114: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000A911C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000A9128: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A9130: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A9134: BE882006
	s_cbranch_execz 59722                                      // 0000000A9138: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3764>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 0000000A913C: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000A9148: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000A9150: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000A9154: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9158: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000A915C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000A9164: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000A9170: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A9174: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000A9178: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000A917C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000A9184: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A918C: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000A9190: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000A9194: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000A9198: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A919C: BF870095
	.long 0xd71c002a                                           // 0000000A91A0: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000A91A4: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000A91A8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000A91AC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A91B4: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 0000000A91B8: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000A91C4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A91C8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000A91CC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000A91D4: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A91D8: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000A91DC: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000A91E4: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000A91E8: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A91F0: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000A91F4: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000A91F8: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9200: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000A9204: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000A9208: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9210: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000A9214: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000A921C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 0000000A9224: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9230: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000A9234: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000A923C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000A9248: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A9250: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A9254: BE882007
	s_cbranch_execz 59653                                      // 0000000A9258: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3770>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 0000000A925C: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000000A9268: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000A9270: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000A9274: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9278: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000A927C: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000A9284: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000A9290: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A9294: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000A9298: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000A929C: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000A92A4: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A92AC: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000A92B0: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000A92B4: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000A92B8: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A92BC: BF870095
	.long 0xd71c002a                                           // 0000000A92C0: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000A92C4: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000A92C8: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000A92CC: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A92D4: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 0000000A92D8: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000A92E4: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A92E8: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000000A92EC: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000000A92F4: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A92F8: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000000A92FC: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000000A9304: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000000A9308: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9310: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000000A9314: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000000A9318: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9320: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000000A9324: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000000A9328: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9330: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000000A9334: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000000A933C: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 0000000A9344: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9350: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000000A9354: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000000A935C: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000000A9368: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A9370: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A9374: BE882000
	s_cbranch_execz 59584                                      // 0000000A9378: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x377c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 0000000A937C: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 0000000A9388: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 0000000A938C: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 0000000A9394: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000000A9398: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A939C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000000A93A0: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000000A93A8: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 0000000A93B4: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A93B8: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 0000000A93BC: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000000A93C0: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 0000000A93C8: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A93D0: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000000A93D4: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000000A93D8: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000000A93DC: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A93E0: BF870095
	.long 0xd71c002a                                           // 0000000A93E4: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000000A93E8: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000000A93EC: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000000A93F0: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A93F8: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000000A93FC: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000000A9404: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9408: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 0000000A940C: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 0000000A9414: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9418: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000000A941C: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000000A9424: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 0000000A9428: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9430: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 0000000A9434: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 0000000A9438: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9440: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 0000000A9444: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 0000000A9448: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9450: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 0000000A9454: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 0000000A945C: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 0000000A9464: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9470: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 0000000A9474: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 0000000A947C: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 0000000A9488: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A9490: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A9494: BE882001
	s_cbranch_execz 59515                                      // 0000000A9498: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3788>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 0000000A949C: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 0000000A94A8: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 0000000A94AC: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 0000000A94B4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000A94B8: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A94BC: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 0000000A94C0: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000A94C8: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 0000000A94D0: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000000A94DC: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A94E0: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 0000000A94E4: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 0000000A94EC: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A94F0: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000000A94F4: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000000A94F8: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 0000000A94FC: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9500: BF870095
	.long 0xd71c0029                                           // 0000000A9504: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000000A9508: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000000A950C: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000A9510: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9518: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 0000000A951C: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000A9524: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9528: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 0000000A952C: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 0000000A9534: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9538: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 0000000A953C: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 0000000A9544: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 0000000A9548: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9550: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 0000000A9554: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 0000000A9558: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9560: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 0000000A9564: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 0000000A9568: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9570: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 0000000A9574: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 0000000A957C: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 0000000A9584: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9590: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 0000000A9594: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 0000000A959C: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 0000000A95A8: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A95B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A95B4: BE882002
	s_cbranch_execz 59446                                      // 0000000A95B8: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3794>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 0000000A95BC: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000A95C8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000A95D0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000A95D4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A95D8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000A95DC: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 0000000A95E4: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 0000000A95F0: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A95F4: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 0000000A95F8: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000A95FC: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 0000000A9604: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A960C: BF870121
	v_add_f32_e32 v34, v34, v41                                // 0000000A9610: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 0000000A9614: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 0000000A9618: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A961C: BF870095
	.long 0xd71c0022                                           // 0000000A9620: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 0000000A9624: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000A9628: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000A962C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9634: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 0000000A9638: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000A9644: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9648: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000A964C: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 0000000A9654: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9658: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 0000000A965C: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 0000000A9664: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 0000000A9668: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9670: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 0000000A9674: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 0000000A9678: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9680: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 0000000A9684: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 0000000A9688: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9690: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 0000000A9694: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000A969C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 0000000A96A4: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A96B0: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 0000000A96B4: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 0000000A96BC: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000A96C8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A96D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A96D4: BE882003
	s_cbranch_execz 59377                                      // 0000000A96D8: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37a0>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 0000000A96DC: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000A96E8: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000A96F0: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000A96F4: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A96F8: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000A96FC: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000A9704: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 0000000A9710: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9714: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 0000000A9718: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 0000000A9724: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 0000000A9728: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000A972C: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A9734: BF870293
	v_exp_f32_e32 v34, v34                                     // 0000000A9738: 7E444B22
	.long 0xd71c0022                                           // 0000000A973C: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000A9740: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A9744: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000A9748: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000A974C: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 0000000A9754: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9760: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 0000000A9764: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000A9768: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A9770: BF870291
	v_rcp_f32_e32 v36, v35                                     // 0000000A9774: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 0000000A9778: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A9780: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 0000000A9784: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 0000000A9788: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 0000000A9790: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9794: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 0000000A9798: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 0000000A97A0: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A97A4: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 0000000A97A8: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 0000000A97B0: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A97B8: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000A97BC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 0000000A97C4: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000A97D0: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A97D8: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000A97DC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000A97E8: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A97F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000A97F4: BE882004
	s_cbranch_execz 59308                                      // 0000000A97F8: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37ac>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 0000000A97FC: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000A9808: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000A9810: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000A9814: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9818: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000A981C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000A9824: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000A9830: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A9834: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000A9838: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000A983C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000A9844: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A984C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000A9850: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000A9854: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000A9858: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A985C: BF870095
	.long 0xd71c0022                                           // 0000000A9860: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000A9864: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000A9868: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000A986C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9874: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 0000000A9878: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000A9884: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9888: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000A988C: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000A9894: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9898: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000A989C: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000A98A4: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000A98A8: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A98B0: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 0000000A98B4: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 0000000A98B8: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A98C0: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 0000000A98C4: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 0000000A98C8: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A98D0: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 0000000A98D4: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000A98DC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 0000000A98E4: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A98F0: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000A98F4: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000A98FC: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000A9908: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A9910: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000A9914: BE882005
	s_cbranch_execz 59239                                      // 0000000A9918: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37b8>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 0000000A991C: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000A9928: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000A9930: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000A9934: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9938: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000A993C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000A9944: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000A9950: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A9954: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000A9958: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000A995C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000A9964: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A996C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000A9970: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000A9974: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000A9978: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A997C: BF870095
	.long 0xd71c0022                                           // 0000000A9980: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000A9984: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000A9988: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000A998C: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9994: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000000A9998: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 0000000A99A0: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A99A8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000A99AC: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000A99B4: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A99B8: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000A99BC: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000A99C4: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000A99C8: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A99D0: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000A99D4: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 0000000A99D8: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A99E0: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 0000000A99E4: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 0000000A99E8: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A99F0: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000A99F4: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000A99FC: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 0000000A9A04: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9A10: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000A9A14: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000A9A1C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000A9A28: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A9A30: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000A9A34: BE882006
	s_cbranch_execz 59170                                      // 0000000A9A38: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37c4>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 0000000A9A3C: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000A9A48: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000A9A50: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000A9A54: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9A58: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000A9A5C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000A9A64: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000A9A70: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A9A74: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000A9A78: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000A9A7C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000A9A84: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A9A8C: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000A9A90: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000A9A94: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000A9A98: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9A9C: BF870095
	.long 0xd71c0022                                           // 0000000A9AA0: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000A9AA4: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000A9AA8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000A9AAC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9AB4: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 0000000A9AB8: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000A9AC4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9AC8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000A9ACC: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000A9AD4: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9AD8: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000A9ADC: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000A9AE4: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000A9AE8: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9AF0: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000A9AF4: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 0000000A9AF8: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9B00: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 0000000A9B04: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000000A9B08: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9B10: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000A9B14: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000A9B1C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 0000000A9B24: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9B30: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000A9B34: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000A9B3C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000A9B48: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A9B50: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000A9B54: BE882007
	s_cbranch_execz 59101                                      // 0000000A9B58: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37d0>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 0000000A9B5C: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 0000000A9B68: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000A9B70: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000A9B74: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9B78: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000A9B7C: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000A9B84: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000A9B90: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A9B94: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000A9B98: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000A9B9C: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000A9BA4: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A9BAC: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000A9BB0: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000A9BB4: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000A9BB8: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9BBC: BF870095
	.long 0xd71c0022                                           // 0000000A9BC0: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000A9BC4: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000A9BC8: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000A9BCC: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9BD4: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 0000000A9BD8: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000A9BE4: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9BE8: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000000A9BEC: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000000A9BF4: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9BF8: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000000A9BFC: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000000A9C04: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000000A9C08: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9C10: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000000A9C14: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 0000000A9C18: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9C20: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 0000000A9C24: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000000A9C28: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9C30: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 0000000A9C34: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 0000000A9C3C: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 0000000A9C44: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9C50: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 0000000A9C54: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 0000000A9C5C: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 0000000A9C68: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A9C70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000A9C74: BE882000
	s_cbranch_execz 59032                                      // 0000000A9C78: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37dc>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 0000000A9C7C: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 0000000A9C88: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 0000000A9C8C: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 0000000A9C94: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000000A9C98: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9C9C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 0000000A9CA0: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 0000000A9CA8: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 0000000A9CB4: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A9CB8: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 0000000A9CBC: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 0000000A9CC0: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 0000000A9CC8: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A9CD0: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000000A9CD4: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000000A9CD8: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000000A9CDC: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9CE0: BF870095
	.long 0xd71c0022                                           // 0000000A9CE4: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000000A9CE8: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000000A9CEC: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000000A9CF0: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9CF8: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000000A9CFC: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000000A9D04: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9D08: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 0000000A9D0C: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 0000000A9D14: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9D18: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000000A9D1C: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000000A9D24: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 0000000A9D28: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9D30: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 0000000A9D34: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 0000000A9D38: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9D40: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 0000000A9D44: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 0000000A9D48: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9D50: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 0000000A9D54: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 0000000A9D5C: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 0000000A9D64: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9D70: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 0000000A9D74: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 0000000A9D7C: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 0000000A9D88: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A9D90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000A9D94: BE882001
	s_cbranch_execz 58963                                      // 0000000A9D98: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37e8>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 0000000A9D9C: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 0000000A9DA8: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 0000000A9DAC: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 0000000A9DB4: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000A9DB8: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A9DBC: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 0000000A9DC0: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000A9DC8: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 0000000A9DD0: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000000A9DDC: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A9DE0: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 0000000A9DE4: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 0000000A9DEC: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A9DF0: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000000A9DF4: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 0000000A9DF8: 7E441123
	v_exp_f32_e32 v33, v33                                     // 0000000A9DFC: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9E00: BF870095
	.long 0xd71c0021                                           // 0000000A9E04: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000000A9E08: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000000A9E0C: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000A9E10: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9E18: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 0000000A9E1C: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000A9E24: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9E28: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 0000000A9E2C: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 0000000A9E34: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9E38: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 0000000A9E3C: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 0000000A9E44: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 0000000A9E48: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9E50: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 0000000A9E54: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 0000000A9E58: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9E60: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 0000000A9E64: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 0000000A9E68: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9E70: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 0000000A9E74: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 0000000A9E7C: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 0000000A9E84: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9E90: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 0000000A9E94: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 0000000A9E9C: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 0000000A9EA8: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A9EB0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000A9EB4: BE882002
	s_cbranch_execz 58894                                      // 0000000A9EB8: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37f4>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 0000000A9EBC: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000A9EC8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000A9ED0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000A9ED4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9ED8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000A9EDC: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 0000000A9EE4: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 0000000A9EF0: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000A9EF4: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 0000000A9EF8: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000A9EFC: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 0000000A9F04: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A9F0C: BF870121
	v_add_f32_e32 v26, v26, v33                                // 0000000A9F10: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000A9F14: 7E421122
	v_exp_f32_e32 v26, v26                                     // 0000000A9F18: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9F1C: BF870095
	.long 0xd71c001a                                           // 0000000A9F20: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 0000000A9F24: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000A9F28: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000A9F2C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9F34: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 0000000A9F38: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000A9F44: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9F48: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000A9F4C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 0000000A9F54: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9F58: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 0000000A9F5C: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 0000000A9F64: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 0000000A9F68: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9F70: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 0000000A9F74: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 0000000A9F78: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9F80: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 0000000A9F84: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 0000000A9F88: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9F90: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 0000000A9F94: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000A9F9C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 0000000A9FA4: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9FB0: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 0000000A9FB4: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 0000000A9FBC: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000A9FC8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000A9FD0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000A9FD4: BE882003
	s_cbranch_execz 58825                                      // 0000000A9FD8: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3800>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 0000000A9FDC: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000A9FE8: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000A9FF0: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000A9FF4: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A9FF8: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000A9FFC: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000AA004: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 0000000AA010: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA014: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 0000000AA018: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 0000000AA024: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 0000000AA028: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000AA02C: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AA034: BF870293
	v_exp_f32_e32 v26, v26                                     // 0000000AA038: 7E344B1A
	.long 0xd71c001a                                           // 0000000AA03C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000AA040: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AA044: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000AA048: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000AA04C: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 0000000AA054: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA060: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 0000000AA064: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000AA068: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AA070: BF870291
	v_rcp_f32_e32 v28, v27                                     // 0000000AA074: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 0000000AA078: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000AA080: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 0000000AA084: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 0000000AA088: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 0000000AA090: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA094: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 0000000AA098: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 0000000AA0A0: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA0A4: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 0000000AA0A8: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 0000000AA0B0: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AA0B8: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000AA0BC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 0000000AA0C4: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000AA0D0: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AA0D8: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000AA0DC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000AA0E8: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AA0F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AA0F4: BE882004
	s_cbranch_execz 58756                                      // 0000000AA0F8: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x380c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 0000000AA0FC: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000AA108: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000AA110: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000AA114: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA118: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000AA11C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000AA124: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000AA130: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AA134: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000AA138: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000AA13C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000AA144: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AA14C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000AA150: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000AA154: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000AA158: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA15C: BF870095
	.long 0xd71c001a                                           // 0000000AA160: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000AA164: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000AA168: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000AA16C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA174: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 0000000AA178: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000AA184: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA188: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000AA18C: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000AA194: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA198: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000AA19C: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000AA1A4: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000AA1A8: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA1B0: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 0000000AA1B4: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 0000000AA1B8: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA1C0: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 0000000AA1C4: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 0000000AA1C8: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA1D0: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 0000000AA1D4: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000AA1DC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 0000000AA1E4: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA1F0: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000AA1F4: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000AA1FC: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000AA208: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AA210: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AA214: BE882005
	s_cbranch_execz 58687                                      // 0000000AA218: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3818>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 0000000AA21C: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000AA228: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000AA230: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000AA234: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA238: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000AA23C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000AA244: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000AA250: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AA254: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000AA258: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000AA25C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000AA264: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AA26C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000AA270: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000AA274: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000AA278: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA27C: BF870095
	.long 0xd71c001a                                           // 0000000AA280: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000AA284: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000AA288: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000AA28C: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA294: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 0000000AA298: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 0000000AA2A0: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA2A8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000AA2AC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000AA2B4: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA2B8: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000AA2BC: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000AA2C4: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000AA2C8: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA2D0: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000AA2D4: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 0000000AA2D8: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA2E0: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 0000000AA2E4: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 0000000AA2E8: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA2F0: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000AA2F4: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000AA2FC: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 0000000AA304: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA310: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000AA314: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000AA31C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000AA328: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AA330: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AA334: BE882006
	s_cbranch_execz 58618                                      // 0000000AA338: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3824>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 0000000AA33C: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000AA348: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000AA350: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000AA354: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA358: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000AA35C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000AA364: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000AA370: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AA374: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000AA378: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000AA37C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000AA384: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AA38C: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000AA390: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000AA394: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000AA398: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA39C: BF870095
	.long 0xd71c001a                                           // 0000000AA3A0: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000AA3A4: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000AA3A8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000AA3AC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA3B4: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 0000000AA3B8: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000AA3C4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA3C8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000AA3CC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000AA3D4: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA3D8: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000AA3DC: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000AA3E4: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000AA3E8: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA3F0: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000AA3F4: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000AA3F8: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA400: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000AA404: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000AA408: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA410: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000AA414: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000AA41C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 0000000AA424: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA430: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000AA434: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000AA43C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000AA448: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AA450: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AA454: BE882007
	s_cbranch_execz 58549                                      // 0000000AA458: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3830>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 0000000AA45C: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000000AA468: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000AA470: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000AA474: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA478: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000AA47C: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000AA484: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000AA490: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AA494: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000AA498: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000AA49C: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000AA4A4: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AA4AC: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000AA4B0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000AA4B4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000AA4B8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA4BC: BF870095
	.long 0xd71c001a                                           // 0000000AA4C0: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000AA4C4: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000AA4C8: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000AA4CC: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA4D4: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 0000000AA4D8: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000AA4E4: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA4E8: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000000AA4EC: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000000AA4F4: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA4F8: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000000AA4FC: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000000AA504: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000000AA508: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA510: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000000AA514: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000000AA518: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA520: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000000AA524: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000000AA528: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA530: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000000AA534: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000000AA53C: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 0000000AA544: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA550: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000000AA554: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000000AA55C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000000AA568: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AA570: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AA574: BE882000
	s_cbranch_execz 58480                                      // 0000000AA578: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x383c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 0000000AA57C: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 0000000AA588: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 0000000AA58C: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 0000000AA594: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000000AA598: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA59C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000000AA5A0: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000000AA5A8: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 0000000AA5B4: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AA5B8: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 0000000AA5BC: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000000AA5C0: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 0000000AA5C8: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AA5D0: BF870121
	v_add_f32_e32 v26, v26, v27                                // 0000000AA5D4: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 0000000AA5D8: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 0000000AA5DC: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA5E0: BF870095
	.long 0xd71c001a                                           // 0000000AA5E4: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000AA5E8: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000000AA5EC: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000000AA5F0: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA5F8: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 0000000AA5FC: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000000AA604: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA608: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 0000000AA60C: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 0000000AA614: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA618: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 0000000AA61C: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 0000000AA624: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 0000000AA628: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA630: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 0000000AA634: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 0000000AA638: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA640: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 0000000AA644: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 0000000AA648: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA650: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 0000000AA654: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 0000000AA65C: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 0000000AA664: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA670: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 0000000AA674: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 0000000AA67C: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 0000000AA688: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AA690: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AA694: BE882001
	s_cbranch_execz 58411                                      // 0000000AA698: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3848>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 0000000AA69C: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 0000000AA6A8: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 0000000AA6AC: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 0000000AA6B4: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000AA6B8: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AA6BC: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 0000000AA6C0: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000AA6C8: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 0000000AA6D0: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 0000000AA6DC: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AA6E0: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 0000000AA6E4: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 0000000AA6EC: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AA6F0: BF870121
	v_add_f32_e32 v25, v25, v26                                // 0000000AA6F4: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 0000000AA6F8: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 0000000AA6FC: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA700: BF870095
	.long 0xd71c0019                                           // 0000000AA704: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000000AA708: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000000AA70C: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000AA710: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA718: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 0000000AA71C: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000AA724: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA728: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 0000000AA72C: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 0000000AA734: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA738: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 0000000AA73C: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 0000000AA744: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 0000000AA748: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA750: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 0000000AA754: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 0000000AA758: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA760: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 0000000AA764: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 0000000AA768: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA770: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 0000000AA774: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 0000000AA77C: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 0000000AA784: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA790: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 0000000AA794: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000000AA79C: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 0000000AA7A8: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AA7B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AA7B4: BE882002
	s_cbranch_execz 58342                                      // 0000000AA7B8: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3854>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 0000000AA7BC: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000AA7C8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000AA7D0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000AA7D4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA7D8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000AA7DC: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 0000000AA7E4: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 0000000AA7F0: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AA7F4: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 0000000AA7F8: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000AA7FC: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 0000000AA804: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AA80C: BF870121
	v_add_f32_e32 v18, v18, v25                                // 0000000AA810: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 0000000AA814: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 0000000AA818: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA81C: BF870095
	.long 0xd71c0012                                           // 0000000AA820: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 0000000AA824: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000AA828: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000AA82C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA834: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 0000000AA838: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000AA844: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA848: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000AA84C: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 0000000AA854: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA858: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 0000000AA85C: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 0000000AA864: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 0000000AA868: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA870: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 0000000AA874: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 0000000AA878: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA880: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 0000000AA884: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 0000000AA888: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA890: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 0000000AA894: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000AA89C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 0000000AA8A4: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA8B0: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 0000000AA8B4: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 0000000AA8BC: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000AA8C8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AA8D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AA8D4: BE882003
	s_cbranch_execz 58273                                      // 0000000AA8D8: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3860>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 0000000AA8DC: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000AA8E8: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000AA8F0: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000AA8F4: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA8F8: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000AA8FC: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000AA904: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 0000000AA910: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA914: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 0000000AA918: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 0000000AA924: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 0000000AA928: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000AA92C: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AA934: BF870293
	v_exp_f32_e32 v18, v18                                     // 0000000AA938: 7E244B12
	.long 0xd71c0012                                           // 0000000AA93C: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000AA940: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AA944: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000AA948: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000AA94C: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 0000000AA954: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA960: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 0000000AA964: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000AA968: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AA970: BF870291
	v_rcp_f32_e32 v20, v19                                     // 0000000AA974: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 0000000AA978: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000AA980: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 0000000AA984: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 0000000AA988: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 0000000AA990: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA994: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 0000000AA998: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 0000000AA9A0: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AA9A4: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 0000000AA9A8: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 0000000AA9B0: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AA9B8: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000AA9BC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 0000000AA9C4: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000AA9D0: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AA9D8: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000AA9DC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000AA9E8: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AA9F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AA9F4: BE882004
	s_cbranch_execz 58204                                      // 0000000AA9F8: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x386c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 0000000AA9FC: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000AAA08: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000AAA10: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000AAA14: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAA18: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000AAA1C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000AAA24: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000AAA30: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AAA34: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000AAA38: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000AAA3C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000AAA44: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AAA4C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000AAA50: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000AAA54: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000AAA58: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAA5C: BF870095
	.long 0xd71c0012                                           // 0000000AAA60: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000AAA64: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000AAA68: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000AAA6C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAA74: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 0000000AAA78: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000AAA84: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAA88: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000AAA8C: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000AAA94: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAA98: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000AAA9C: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000AAAA4: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000AAAA8: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAAB0: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 0000000AAAB4: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 0000000AAAB8: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAAC0: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 0000000AAAC4: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 0000000AAAC8: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAAD0: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 0000000AAAD4: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000AAADC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 0000000AAAE4: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAAF0: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000AAAF4: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000AAAFC: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000AAB08: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AAB10: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AAB14: BE882005
	s_cbranch_execz 58135                                      // 0000000AAB18: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3878>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 0000000AAB1C: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000AAB28: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000AAB30: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000AAB34: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAB38: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000AAB3C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000AAB44: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000AAB50: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AAB54: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000AAB58: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000AAB5C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000AAB64: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AAB6C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000AAB70: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000AAB74: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000AAB78: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAB7C: BF870095
	.long 0xd71c0012                                           // 0000000AAB80: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000AAB84: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000AAB88: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000AAB8C: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAB94: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000AAB98: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 0000000AABA0: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AABA8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000AABAC: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000AABB4: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AABB8: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000AABBC: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000AABC4: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000AABC8: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AABD0: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000AABD4: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 0000000AABD8: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AABE0: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 0000000AABE4: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 0000000AABE8: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AABF0: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000AABF4: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000AABFC: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 0000000AAC04: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAC10: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000AAC14: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000AAC1C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000AAC28: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AAC30: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AAC34: BE882006
	s_cbranch_execz 58066                                      // 0000000AAC38: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3884>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 0000000AAC3C: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000AAC48: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000AAC50: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000AAC54: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAC58: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000AAC5C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000AAC64: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000AAC70: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AAC74: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000AAC78: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000AAC7C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000AAC84: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AAC8C: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000AAC90: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000AAC94: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000AAC98: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAC9C: BF870095
	.long 0xd71c0012                                           // 0000000AACA0: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000AACA4: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000AACA8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000AACAC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AACB4: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 0000000AACB8: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000AACC4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AACC8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000AACCC: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000AACD4: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AACD8: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000AACDC: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000AACE4: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000AACE8: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AACF0: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000AACF4: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000AACF8: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAD00: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000AAD04: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000AAD08: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAD10: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000AAD14: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000AAD1C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 0000000AAD24: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAD30: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000AAD34: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000AAD3C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000AAD48: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AAD50: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AAD54: BE882007
	s_cbranch_execz 57997                                      // 0000000AAD58: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3890>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 0000000AAD5C: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 0000000AAD68: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000AAD70: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000AAD74: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAD78: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000AAD7C: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000AAD84: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000AAD90: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AAD94: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000AAD98: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000AAD9C: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000AADA4: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AADAC: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000AADB0: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000AADB4: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000AADB8: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AADBC: BF870095
	.long 0xd71c0012                                           // 0000000AADC0: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000AADC4: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000AADC8: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000AADCC: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AADD4: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 0000000AADD8: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000AADE4: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AADE8: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000000AADEC: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000000AADF4: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AADF8: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000000AADFC: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000000AAE04: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000000AAE08: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAE10: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000000AAE14: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000000AAE18: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAE20: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000000AAE24: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000000AAE28: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAE30: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000000AAE34: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000000AAE3C: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 0000000AAE44: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAE50: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000000AAE54: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000000AAE5C: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000000AAE68: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AAE70: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AAE74: BE882000
	s_cbranch_execz 57928                                      // 0000000AAE78: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x389c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 0000000AAE7C: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 0000000AAE88: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 0000000AAE8C: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 0000000AAE94: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 0000000AAE98: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAE9C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 0000000AAEA0: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 0000000AAEA8: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 0000000AAEB4: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AAEB8: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 0000000AAEBC: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 0000000AAEC0: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 0000000AAEC8: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AAED0: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000000AAED4: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000000AAED8: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000000AAEDC: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAEE0: BF870095
	.long 0xd71c0012                                           // 0000000AAEE4: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000000AAEE8: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000000AAEEC: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000000AAEF0: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAEF8: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000000AAEFC: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000000AAF04: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAF08: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 0000000AAF0C: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 0000000AAF14: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAF18: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000000AAF1C: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 0000000AAF24: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 0000000AAF28: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAF30: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 0000000AAF34: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 0000000AAF38: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAF40: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 0000000AAF44: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 0000000AAF48: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAF50: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 0000000AAF54: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 0000000AAF5C: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 0000000AAF64: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AAF70: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 0000000AAF74: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 0000000AAF7C: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 0000000AAF88: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AAF90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 0000000AAF94: BE882001
	s_cbranch_execz 57859                                      // 0000000AAF98: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38a8>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 0000000AAF9C: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 0000000AAFA8: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 0000000AAFAC: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 0000000AAFB4: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000AAFB8: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AAFBC: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 0000000AAFC0: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000AAFC8: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 0000000AAFD0: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 0000000AAFDC: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000AAFE0: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 0000000AAFE4: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 0000000AAFEC: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AAFF0: BF870121
	v_add_f32_e32 v17, v17, v18                                // 0000000AAFF4: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 0000000AAFF8: 7E241113
	v_exp_f32_e32 v17, v17                                     // 0000000AAFFC: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB000: BF870095
	.long 0xd71c0011                                           // 0000000AB004: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000000AB008: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000000AB00C: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000AB010: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB018: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 0000000AB01C: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000AB024: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB028: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 0000000AB02C: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 0000000AB034: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB038: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 0000000AB03C: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 0000000AB044: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 0000000AB048: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB050: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 0000000AB054: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 0000000AB058: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB060: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 0000000AB064: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 0000000AB068: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB070: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 0000000AB074: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 0000000AB07C: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 0000000AB084: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB090: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 0000000AB094: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 0000000AB09C: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 0000000AB0A8: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AB0B0: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 0000000AB0B4: BE882002
	s_cbranch_execz 57790                                      // 0000000AB0B8: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38b4>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 0000000AB0BC: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000AB0C8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000AB0D0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000AB0D4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB0D8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000AB0DC: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 0000000AB0E4: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 0000000AB0F0: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AB0F4: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 0000000AB0F8: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000AB0FC: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 0000000AB104: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AB10C: BF870121
	v_add_f32_e32 v10, v10, v17                                // 0000000AB110: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 0000000AB114: 7E221112
	v_exp_f32_e32 v10, v10                                     // 0000000AB118: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB11C: BF870095
	.long 0xd71c000a                                           // 0000000AB120: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 0000000AB124: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000AB128: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000AB12C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB134: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 0000000AB138: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000AB144: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB148: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000AB14C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 0000000AB154: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB158: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 0000000AB15C: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 0000000AB164: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 0000000AB168: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB170: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 0000000AB174: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 0000000AB178: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB180: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 0000000AB184: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 0000000AB188: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB190: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 0000000AB194: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000AB19C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 0000000AB1A4: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB1B0: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 0000000AB1B4: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 0000000AB1BC: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000AB1C8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AB1D0: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000000AB1D4: BE882003
	s_cbranch_execz 57721                                      // 0000000AB1D8: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38c0>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 0000000AB1DC: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000AB1E8: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000AB1F0: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000AB1F4: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB1F8: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000AB1FC: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000AB204: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 0000000AB210: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB214: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 0000000AB218: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 0000000AB224: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 0000000AB228: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000AB22C: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AB234: BF870293
	v_exp_f32_e32 v10, v10                                     // 0000000AB238: 7E144B0A
	.long 0xd71c000a                                           // 0000000AB23C: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000AB240: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AB244: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000AB248: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000AB24C: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 0000000AB254: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB260: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000AB264: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000AB268: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000AB270: BF870291
	v_rcp_f32_e32 v12, v11                                     // 0000000AB274: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 0000000AB278: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000AB280: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 0000000AB284: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 0000000AB288: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 0000000AB290: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB294: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 0000000AB298: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 0000000AB2A0: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB2A4: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 0000000AB2A8: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 0000000AB2B0: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AB2B8: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000AB2BC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 0000000AB2C4: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000AB2D0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000AB2D8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000AB2DC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000AB2E8: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AB2F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000000AB2F4: BE882004
	s_cbranch_execz 57652                                      // 0000000AB2F8: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38cc>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 0000000AB2FC: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000AB308: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000AB310: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000AB314: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB318: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000AB31C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000AB324: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000AB330: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AB334: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000AB338: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000AB33C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000AB344: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AB34C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000AB350: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000AB354: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000AB358: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB35C: BF870095
	.long 0xd71c000a                                           // 0000000AB360: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000AB364: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000AB368: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000AB36C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB374: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 0000000AB378: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000AB384: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB388: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000AB38C: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000AB394: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB398: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000AB39C: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000AB3A4: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000AB3A8: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB3B0: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 0000000AB3B4: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 0000000AB3B8: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB3C0: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 0000000AB3C4: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 0000000AB3C8: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB3D0: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 0000000AB3D4: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000AB3DC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 0000000AB3E4: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB3F0: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000AB3F4: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000AB3FC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000AB408: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AB410: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000000AB414: BE882005
	s_cbranch_execz 57583                                      // 0000000AB418: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38d8>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 0000000AB41C: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000AB428: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000AB430: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000AB434: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB438: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000AB43C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000AB444: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000AB450: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AB454: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000AB458: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000AB45C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000AB464: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AB46C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000AB470: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000AB474: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000AB478: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB47C: BF870095
	.long 0xd71c000a                                           // 0000000AB480: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000AB484: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000AB488: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000AB48C: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB494: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 0000000AB498: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 0000000AB4A0: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB4A8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000AB4AC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000AB4B4: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB4B8: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000AB4BC: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000AB4C4: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000AB4C8: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB4D0: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000AB4D4: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 0000000AB4D8: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB4E0: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 0000000AB4E4: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 0000000AB4E8: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB4F0: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000AB4F4: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000AB4FC: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 0000000AB504: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB510: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000AB514: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000AB51C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000AB528: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AB530: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000000AB534: BE882006
	s_cbranch_execz 57514                                      // 0000000AB538: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38e4>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 0000000AB53C: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000AB548: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000AB550: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000AB554: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB558: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000AB55C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000AB564: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000AB570: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AB574: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000AB578: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000AB57C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000AB584: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AB58C: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000AB590: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000AB594: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000AB598: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB59C: BF870095
	.long 0xd71c000a                                           // 0000000AB5A0: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000AB5A4: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000AB5A8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000AB5AC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB5B4: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 0000000AB5B8: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000AB5C4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB5C8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000AB5CC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000AB5D4: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB5D8: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000AB5DC: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000AB5E4: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000AB5E8: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB5F0: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000AB5F4: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000000AB5F8: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB600: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000AB604: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000AB608: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB610: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000AB614: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000AB61C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 0000000AB624: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB630: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000AB634: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000AB63C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000AB648: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AB650: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000000AB654: BE882007
	s_cbranch_execz 57445                                      // 0000000AB658: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38f0>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 0000000AB65C: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000000AB668: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000AB670: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000AB674: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB678: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000AB67C: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000AB684: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000AB690: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AB694: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000AB698: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000AB69C: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000AB6A4: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AB6AC: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000AB6B0: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000AB6B4: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000AB6B8: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB6BC: BF870095
	.long 0xd71c000a                                           // 0000000AB6C0: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000AB6C4: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000AB6C8: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000AB6CC: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB6D4: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 0000000AB6D8: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000AB6E4: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB6E8: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 0000000AB6EC: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 0000000AB6F4: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB6F8: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 0000000AB6FC: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 0000000AB704: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 0000000AB708: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB710: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000000AB714: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 0000000AB718: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB720: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 0000000AB724: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 0000000AB728: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB730: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000000AB734: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000000AB73C: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 0000000AB744: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB750: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000000AB754: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000000AB75C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000000AB768: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AB770: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000000AB774: BE882000
	s_cbranch_execz 57376                                      // 0000000AB778: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38fc>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 0000000AB77C: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 0000000AB788: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 0000000AB78C: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000000AB794: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000000AB798: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB79C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000000AB7A0: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000000AB7A8: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 0000000AB7B4: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AB7B8: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 0000000AB7BC: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000000AB7C0: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 0000000AB7C8: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AB7D0: BF870121
	v_add_f32_e32 v10, v10, v11                                // 0000000AB7D4: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 0000000AB7D8: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 0000000AB7DC: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB7E0: BF870095
	.long 0xd71c000a                                           // 0000000AB7E4: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 0000000AB7E8: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000000AB7EC: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000000AB7F0: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB7F8: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 0000000AB7FC: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000000AB804: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB808: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 0000000AB80C: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 0000000AB814: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB818: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 0000000AB81C: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 0000000AB824: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 0000000AB828: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB830: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 0000000AB834: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 0000000AB838: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB840: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 0000000AB844: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 0000000AB848: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB850: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 0000000AB854: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 0000000AB85C: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 0000000AB864: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB870: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 0000000AB874: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000000AB87C: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 0000000AB888: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 0000000AB890: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 0000000AB894: BE802001
	s_cbranch_execz 57307                                      // 0000000AB898: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3908>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 0000000AB89C: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000AB8A8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000AB8B0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000AB8B4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB8B8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000AB8BC: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 0000000AB8C4: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 0000000AB8D0: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000AB8D4: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 0000000AB8D8: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 0000000AB8DC: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000AB8E4: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000AB8EC: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 0000000AB8F0: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 0000000AB8F4: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 0000000AB8F8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB8FC: BF870095
	.long 0xd71c0001                                           // 0000000AB900: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 0000000AB904: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000AB908: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000AB90C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB914: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 0000000AB918: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000AB924: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB928: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000AB92C: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 0000000AB934: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB938: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 0000000AB93C: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 0000000AB944: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 0000000AB948: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB950: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 0000000AB954: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 0000000AB958: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB960: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 0000000AB964: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 0000000AB968: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB970: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 0000000AB974: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000AB97C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 0000000AB984: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB990: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 0000000AB994: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 0000000AB99C: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000AB9A8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000AB9B0: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 0000000AB9B4: BE802002
	s_cbranch_execz 57238                                      // 0000000AB9B8: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3914>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 0000000AB9BC: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000AB9C8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000AB9D0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000AB9D4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AB9D8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000AB9DC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000AB9E4: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 0000000AB9F0: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000AB9F4: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 0000000AB9F8: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000AB9FC: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000ABA04: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ABA0C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000ABA10: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 0000000ABA14: 7E041109
	v_exp_f32_e32 v1, v1                                       // 0000000ABA18: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABA1C: BF870095
	.long 0xd71c0001                                           // 0000000ABA20: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000ABA24: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000ABA28: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000ABA2C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABA34: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 0000000ABA38: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000ABA44: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABA48: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000ABA4C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000ABA54: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABA58: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 0000000ABA5C: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 0000000ABA64: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 0000000ABA68: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABA70: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 0000000ABA74: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 0000000ABA78: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABA80: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 0000000ABA84: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 0000000ABA88: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABA90: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 0000000ABA94: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000ABA9C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 0000000ABAA4: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABAB0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000ABAB4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000ABABC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000ABAC8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000ABAD0: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 0000000ABAD4: BE802003
	s_cbranch_execz 57169                                      // 0000000ABAD8: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3920>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 0000000ABADC: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000ABAE8: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000ABAF0: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000ABAF4: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABAF8: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000ABAFC: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000ABB04: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000ABB10: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ABB14: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000ABB18: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000ABB1C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000ABB24: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ABB2C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000ABB30: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000ABB34: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000ABB38: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABB3C: BF870095
	.long 0xd71c0001                                           // 0000000ABB40: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000ABB44: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000ABB48: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000ABB4C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABB54: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 0000000ABB58: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000ABB64: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABB68: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000ABB6C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000ABB74: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABB78: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000ABB7C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000ABB84: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000ABB88: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABB90: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 0000000ABB94: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 0000000ABB98: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABBA0: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 0000000ABBA4: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 0000000ABBA8: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABBB0: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 0000000ABBB4: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000ABBBC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 0000000ABBC4: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABBD0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000ABBD4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000ABBDC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000ABBE8: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000ABBF0: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000000ABBF4: BE802004
	s_cbranch_execz 57100                                      // 0000000ABBF8: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x392c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 0000000ABBFC: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000ABC08: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000ABC10: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000ABC14: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABC18: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000ABC1C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000ABC24: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000ABC30: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ABC34: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000ABC38: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000ABC3C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000ABC44: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ABC4C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000ABC50: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000ABC54: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000ABC58: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABC5C: BF870095
	.long 0xd71c0001                                           // 0000000ABC60: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000ABC64: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000ABC68: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000ABC6C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABC74: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 0000000ABC78: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 0000000ABC80: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABC88: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000ABC8C: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000ABC94: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABC98: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000ABC9C: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000ABCA4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000ABCA8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABCB0: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000ABCB4: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 0000000ABCB8: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABCC0: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 0000000ABCC4: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000ABCC8: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABCD0: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000ABCD4: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000ABCDC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 0000000ABCE4: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABCF0: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000ABCF4: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000ABCFC: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000ABD08: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000ABD10: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000000ABD14: BE802005
	s_cbranch_execz 57031                                      // 0000000ABD18: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3938>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 0000000ABD1C: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000ABD28: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000ABD30: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000ABD34: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABD38: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000ABD3C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000ABD44: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000ABD50: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ABD54: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000ABD58: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000ABD5C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000ABD64: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ABD6C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000ABD70: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000ABD74: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000ABD78: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABD7C: BF870095
	.long 0xd71c0001                                           // 0000000ABD80: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000ABD84: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000ABD88: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000ABD8C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABD94: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 0000000ABD98: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000ABDA4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABDA8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000ABDAC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000ABDB4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABDB8: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000ABDBC: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000ABDC4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000ABDC8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABDD0: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000ABDD4: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000ABDD8: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABDE0: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000ABDE4: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000ABDE8: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABDF0: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000ABDF4: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000ABDFC: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 0000000ABE04: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABE10: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000ABE14: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000ABE1C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000ABE28: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000ABE30: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000000ABE34: BE802006
	s_cbranch_execz 56962                                      // 0000000ABE38: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3944>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 0000000ABE3C: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000ABE48: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000ABE50: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000ABE54: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABE58: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000ABE5C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000ABE64: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000ABE70: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ABE74: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000ABE78: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000ABE7C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000ABE84: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ABE8C: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000ABE90: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000ABE94: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000ABE98: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABE9C: BF870095
	.long 0xd71c0001                                           // 0000000ABEA0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000ABEA4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000ABEA8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000ABEAC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABEB4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 0000000ABEB8: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000ABEC4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABEC8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000ABECC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000ABED4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABED8: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000ABEDC: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000ABEE4: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000ABEE8: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABEF0: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000ABEF4: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000ABEF8: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABF00: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000ABF04: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000ABF08: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABF10: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000ABF14: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000ABF1C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 0000000ABF24: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABF30: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000ABF34: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000ABF3C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000ABF48: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000ABF50: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000000ABF54: BE802007
	s_cbranch_execz 56893                                      // 0000000ABF58: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi1ELi1ELb1ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3950>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 0000000ABF5C: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000000ABF68: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000000ABF70: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000000ABF74: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABF78: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000000ABF7C: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000000ABF84: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000000ABF90: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000ABF94: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000000ABF98: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000000ABF9C: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000000ABFA4: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000ABFAC: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000000ABFB0: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000000ABFB4: 7E041103
	v_exp_f32_e32 v1, v1                                       // 0000000ABFB8: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABFBC: BF870095
	.long 0xd71c0001                                           // 0000000ABFC0: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000000ABFC4: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000000ABFC8: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000000ABFCC: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABFD4: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 0000000ABFD8: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000000ABFE4: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABFE8: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000000ABFEC: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000000ABFF4: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000ABFF8: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000000ABFFC: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000000AC004: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000000AC008: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC010: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000000AC014: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000000AC018: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC020: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000000AC024: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000000AC028: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC030: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000000AC034: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000000AC03C: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 0000000AC044: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000AC050: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000000AC054: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000000AC05C: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000000AC068: DC9601E0 007C0200
	s_nop 0                                                    // 0000000AC070: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000000AC074: BFB60003
	s_endpgm                                                   // 0000000AC078: BFB00000
		...

