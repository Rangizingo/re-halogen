000000000007f900 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 00000007F900: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 00000007F904: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000007F90C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 00000007F914: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 00000007F918: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000007F91C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 00000007F920: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000007F928: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000007F92C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 00000007F930: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 00000007F934: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000007F93C: 84928214
	s_add_u32 s25, s16, s18                                    // 00000007F940: 80191210
	s_addc_u32 s28, s17, s19                                   // 00000007F944: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 00000007F948: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007F94C: BF870009
	s_add_u32 s25, s25, s20                                    // 00000007F950: 80191419
	s_addc_u32 s30, s28, s21                                   // 00000007F954: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 00000007F958: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000007F95C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 00000007F964: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000007F96C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 00000007F970: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 00000007F974: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000007F978: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000007F97C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 00000007F980: 821E191E
	.long 0xd7001f02                                           // 00000007F984: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 00000007F988: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000007F98C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 00000007F994: BE9E0080
	s_nop 0                                                    // 00000007F998: BF800000
	s_nop 0                                                    // 00000007F99C: BF800000
	s_nop 0                                                    // 00000007F9A0: BF800000
	s_nop 0                                                    // 00000007F9A4: BF800000
	s_nop 0                                                    // 00000007F9A8: BF800000
	s_nop 0                                                    // 00000007F9AC: BF800000
	s_nop 0                                                    // 00000007F9B0: BF800000
	s_nop 0                                                    // 00000007F9B4: BF800000
	s_nop 0                                                    // 00000007F9B8: BF800000
	s_nop 0                                                    // 00000007F9BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 00000007F9C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 00000007F9C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007F9CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 00000007F9D0: 300C1089
	.long 0xd7006a06                                           // 00000007F9D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000007F9D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007F9DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 00000007F9E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000007F9E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 00000007F9F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 00000007F9F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 00000007F9FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 00000007FA08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000007FA0C: BF8903F7
	ds_store_b32 v6, v9                                        // 00000007FA10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 00000007FA18: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000007FA1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 00000007FA20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 00000007FA24: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 00000007FA2C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 00000007FA34: 32040084
	s_mov_b32 s0, 0                                            // 00000007FA38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000007FA3C: BF89FC07
	s_barrier                                                  // 00000007FA40: BFBD0000
	buffer_gl0_inv                                             // 00000007FA44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000007FA4C: BF02801E
	s_cbranch_scc1 12                                          // 00000007FA50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 00000007FA54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000007FA5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000007FA64: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 00000007FA68: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 00000007FA70: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000007FA74: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000007FA78: 916A007E
	s_cbranch_vccz 2                                           // 00000007FA7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2616                                              // 00000007FA80: BFA00A38 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a64>
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000007FA84: 304E0A82
	s_add_i32 s0, s30, 63                                      // 00000007FA88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000007FA8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 00000007FA94: 85218600
	s_add_u32 s34, s10, s24                                    // 00000007FA98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000007FA9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 00000007FAA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 00000007FAA4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 00000007FAAC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 00000007FAB0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000007FAB4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 00000007FAB8: 301A0488
	s_add_u32 s22, s22, s0                                     // 00000007FABC: 80160016
	s_addc_u32 s1, s23, s1                                     // 00000007FAC0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 00000007FAC4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 00000007FAC8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 00000007FAD4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 00000007FAD8: 82010B01
	s_movk_i32 s10, 0x204                                      // 00000007FADC: B00A0204
	.long 0xd7000b2c                                           // 00000007FAE0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 00000007FAE4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000007FAE8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 00000007FAEC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 00000007FAF4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 00000007FB00: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 00000007FB04: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 00000007FB10: 3816500A
	.long 0xd7000a05                                           // 00000007FB14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 00000007FB18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007FB1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 00000007FB20: D5207C06 00290001
	.long 0xd7000107                                           // 00000007FB28: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 00000007FB2C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007FB30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 00000007FB34: D5207C08 0006180D
	.long 0xd7000109                                           // 00000007FB3C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 00000007FB40: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 00000007FB44: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 00000007FB4C: 84848E02
	.long 0xd700010b                                           // 00000007FB50: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 00000007FB54: 02021606
	s_add_u32 s4, s14, s4                                      // 00000007FB58: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 00000007FB5C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 00000007FB64: 8205050F
	.long 0xd700010d                                           // 00000007FB68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 00000007FB6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007FB70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 00000007FB74: D5207C0E 00050005
	.long 0xd700010f                                           // 00000007FB7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 00000007FB80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 00000007FB88: D5207C10 00061880
	.long 0xd7000111                                           // 00000007FB90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 00000007FB94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007FB9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 00000007FBA0: D5207C12 00061880
	.long 0xd7000113                                           // 00000007FBA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 00000007FBAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 00000007FBB4: D5207C14 00061880
	.long 0xd7000115                                           // 00000007FBBC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 00000007FBC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007FBC8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 00000007FBCC: D5207C16 00061880
	.long 0xd7000117                                           // 00000007FBD4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 00000007FBD8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 00000007FBE0: D5207C18 00061880
	.long 0xd7000119                                           // 00000007FBE8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 00000007FBEC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007FBF4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 00000007FBF8: D5207C1A 00061880
	.long 0xd700011b                                           // 00000007FC00: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 00000007FC04: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 00000007FC0C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 00000007FC14: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000007FC18: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 00000007FC20: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 00000007FC24: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 00000007FC2C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 00000007FC34: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 00000007FC3C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 00000007FC44: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 00000007FC4C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 00000007FC54: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 00000007FC5C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 00000007FC64: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 00000007FC6C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 00000007FC74: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 00000007FC7C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 00000007FC84: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 00000007FC8C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 00000007FC94: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 00000007FC9C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000007FCA0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 00000007FCA4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000007FCAC: BF870499
	s_add_i32 s6, s31, s1                                      // 00000007FCB0: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 00000007FCB4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000007FCB8: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 00000007FCBC: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 00000007FCC0: 84078605
	s_add_u32 s10, s8, s10                                     // 00000007FCC4: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 00000007FCC8: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 00000007FCCC: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 00000007FCD4: BE84206A
	s_cbranch_execz 77                                         // 00000007FCD8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s7, v0                                   // 00000007FCDC: 383A0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FCE0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 00000007FCE4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 00000007FCEC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FCF0: BF870091
	.long 0xd73c001d                                           // 00000007FCF4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 00000007FCF8: 02023A82
	.long 0xd700011d                                           // 00000007FCFC: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 00000007FD00: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000007FD04: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 00000007FD08: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 00000007FD10: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000007FD18: BF890007
	v_sub_f32_e32 v30, s6, v29                                 // 00000007FD1C: 083C3A06
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 00000007FD20: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000007FD2C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 00000007FD30: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 00000007FD3C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 00000007FD40: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 00000007FD4C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000007FD50: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 00000007FD54: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 00000007FD60: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000007FD64: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 00000007FD68: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 00000007FD70: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 00000007FD74: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 00000007FD7C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 00000007FD84: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 00000007FD88: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007FD8C: BF870193
	v_exp_f32_e32 v32, v32                                     // 00000007FD90: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 00000007FD94: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000007FD98: BF870296
	.long 0xd71c0020                                           // 00000007FD9C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 00000007FDA0: 02024520
	.long 0xd71c001f                                           // 00000007FDA4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 00000007FDA8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007FDAC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 00000007FDB0: D501001F 00063E80
	.long 0xd41b0001                                           // 00000007FDB8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 00000007FDBC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 00000007FDC4: D5010020 00064080
	.long 0xd41e0001                                           // 00000007FDCC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 00000007FDD0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007FDD8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 00000007FDDC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 00000007FDE8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 00000007FDEC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 00000007FDF4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 00000007FE00: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 00000007FE08: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007FE10: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 00000007FE14: CA100108 1E1C0107
	s_mov_b32 s10, 0                                           // 00000007FE1C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000007FE20: BF89FC07
	s_barrier                                                  // 00000007FE24: BFBD0000
	buffer_gl0_inv                                             // 00000007FE28: E0AC0000 00000000
	s_branch 15                                                // 00000007FE30: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000007FE34: 8C7E047E
	.long 0xd700011d                                           // 00000007FE38: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 00000007FE3C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000007FE44: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000007FE48: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000007FE50: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000007FE54: BF08B70A
	s_mov_b32 s10, s1                                          // 00000007FE58: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 00000007FE5C: BF89FC07
	s_barrier                                                  // 00000007FE60: BFBD0000
	buffer_gl0_inv                                             // 00000007FE64: E0AC0000 00000000
	s_cbranch_scc1 706                                         // 00000007FE6C: BFA202C2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 00000007FE70: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 00000007FE78: CA100128 21220126
	s_mov_b32 s11, 0                                           // 00000007FE80: BE8B0080
	s_nop 0                                                    // 00000007FE84: BF800000
	s_nop 0                                                    // 00000007FE88: BF800000
	s_nop 0                                                    // 00000007FE8C: BF800000
	s_nop 0                                                    // 00000007FE90: BF800000
	s_nop 0                                                    // 00000007FE94: BF800000
	s_nop 0                                                    // 00000007FE98: BF800000
	s_nop 0                                                    // 00000007FE9C: BF800000
	s_nop 0                                                    // 00000007FEA0: BF800000
	s_nop 0                                                    // 00000007FEA4: BF800000
	s_nop 0                                                    // 00000007FEA8: BF800000
	s_nop 0                                                    // 00000007FEAC: BF800000
	s_nop 0                                                    // 00000007FEB0: BF800000
	s_nop 0                                                    // 00000007FEB4: BF800000
	s_nop 0                                                    // 00000007FEB8: BF800000
	s_nop 0                                                    // 00000007FEBC: BF800000
	global_load_b32 v35, v[31:32], off                         // 00000007FEC0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 00000007FEC8: 4A4444FF 00000080
	.long 0xd700011f                                           // 00000007FED0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 00000007FED4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000007FEDC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000007FEE0: D5207C20 00064080
	.long 0xd4490004                                           // 00000007FEE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 00000007FEEC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000007FEF4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000007FEF8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 00000007FEFC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 00000007FF04: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000007FF0C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000007FF10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000007FF14: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000007FF18: BF89FC07
	s_barrier                                                  // 00000007FF1C: BFBD0000
	buffer_gl0_inv                                             // 00000007FF20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000007FF28: BE842000
	s_cbranch_execz 65473                                      // 00000007FF2C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 00000007FF30: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 00000007FF38: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 00000007FF40: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 00000007FF48: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 00000007FF50: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 00000007FF58: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 00000007FF60: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 00000007FF68: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 00000007FF70: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 00000007FF78: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 00000007FF80: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 00000007FF88: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 00000007FF90: D8DCFFEE 50000001
	v_or3_b32 v70, s10, s7, v2                                 // 00000007FF98: D6580046 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FFA0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 00000007FFA4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 00000007FFAC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 00000007FFB0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000007FFB4: BF870091
	.long 0xd7000146                                           // 00000007FFB8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 00000007FFBC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 00000007FFC0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 00000007FFC8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 00000007FFD0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 00000007FFD4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000007FFDC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 00000007FFE0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 00000007FFE8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 00000007FFEC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 00000007FFF4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 00000007FFFC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 000000080004: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 00000008000C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 000000080014: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080018: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 00000008001C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 000000080024: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 00000008002C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080030: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 000000080034: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 00000008003C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 000000080044: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080048: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 00000008004C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 000000080054: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 00000008005C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000080060: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000080064: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 00000008006C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 000000080074: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 00000008007C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 000000080084: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 00000008008C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 000000080094: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 00000008009C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000800A4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 0000000800AC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 0000000800B4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000800B8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 0000000800BC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 0000000800C4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000800CC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 0000000800D0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 0000000800D8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 0000000800E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000800E4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 0000000800E8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 0000000800F0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 0000000800F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000800FC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 000000080100: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 000000080108: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 000000080110: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 000000080118: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 000000080120: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 000000080128: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 000000080130: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 000000080138: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 000000080140: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 000000080148: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 000000080150: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080154: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 000000080158: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 000000080160: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 000000080168: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008016C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000080170: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000080178: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000080180: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080184: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 000000080188: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 000000080190: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 000000080198: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008019C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000801A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 0000000801A8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 0000000801B0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 0000000801B8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 0000000801C0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 0000000801C8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 0000000801D0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000801D8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000801E0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 0000000801E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000801F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000801F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000801F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000080200: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000080208: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008020C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 000000080210: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 000000080218: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 000000080220: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080224: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 000000080228: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000080230: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 000000080238: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008023C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 000000080240: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 000000080248: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 000000080250: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 000000080258: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 000000080260: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 000000080268: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 000000080270: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 000000080278: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 000000080280: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 000000080288: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 000000080290: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080294: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000080298: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000802A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000802A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000802AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000802B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000802B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000802C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000802C4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 0000000802C8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 0000000802D0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 0000000802D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000802DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000802E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 0000000802E8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 0000000802F0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 0000000802F8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 000000080300: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 000000080308: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 000000080310: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 000000080318: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 000000080320: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 000000080328: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000080330: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080334: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000080338: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000080340: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000080348: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008034C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000080350: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000080358: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000080360: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080364: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000080368: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000080370: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000080378: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008037C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000080380: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 000000080388: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 000000080390: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 000000080398: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 0000000803A0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 0000000803A8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 0000000803B0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 0000000803B8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 0000000803C0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 0000000803C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000803D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000803D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000803D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000803E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000803E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000803EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000803F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000803F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000080400: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080404: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000080408: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000080410: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000080418: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008041C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000080420: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 000000080428: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 000000080430: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 000000080438: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 000000080440: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 000000080448: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 000000080450: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 000000080458: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 000000080460: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 000000080468: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000080470: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080474: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000080478: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000080480: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000080488: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008048C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000080490: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000080498: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000804A0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000804A4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000804A8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000804B0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000804B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000804BC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000804C0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 0000000804C8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 0000000804D0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 0000000804D8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 0000000804E0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 0000000804E8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 0000000804F0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 0000000804F8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 000000080500: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 000000080508: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000080510: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080514: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000080518: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 000000080520: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 000000080528: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008052C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000080530: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000080538: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000080540: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080544: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000080548: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000080550: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000080558: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008055C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000080560: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 000000080568: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 000000080570: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 000000080578: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 000000080580: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 000000080588: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 000000080590: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 000000080598: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000805A0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 0000000805A8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000805B0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000805B4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000805B8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000805C0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000805C8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000805CC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000805D0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000805D8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000805E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000805E4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000805E8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000805F0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000805F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000805FC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000080600: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 000000080608: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 000000080610: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 000000080618: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 000000080620: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 000000080628: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 000000080630: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 000000080638: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 000000080640: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 000000080648: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000080650: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080654: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000080658: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 000000080660: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 000000080668: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008066C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000080670: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000080678: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000080680: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080684: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000080688: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000080690: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000080698: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008069C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000806A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 0000000806A8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 0000000806B0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 0000000806B8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 0000000806C0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 0000000806C8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 0000000806D0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000806D8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000806E0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 0000000806E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000806F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000806F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000806F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000080700: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000080708: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008070C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000080710: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000080718: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000080720: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080724: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000080728: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000080730: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000080738: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008073C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000080740: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 000000080748: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 000000080750: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 000000080758: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 000000080760: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 000000080768: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 000000080770: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 000000080778: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 000000080780: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 000000080788: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000080790: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080794: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000080798: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000807A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000807A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000807AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000807B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000807B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000807C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000807C4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000807C8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000807D0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000807D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000807DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000807E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 0000000807E8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 0000000807F0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 0000000807F8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 000000080800: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 000000080808: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 000000080810: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 000000080818: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 000000080820: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 000000080828: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000080830: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080834: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000080838: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000080840: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000080848: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008084C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000080850: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000080858: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000080860: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080864: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000080868: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000080870: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000080878: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008087C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000080880: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 000000080888: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 000000080890: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 000000080898: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 0000000808A0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 0000000808A8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 0000000808B0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 0000000808B8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 0000000808C0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 0000000808C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000808D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000808D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000808D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000808E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000808E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000808EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000808F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000808F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000080900: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080904: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000080908: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000080910: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000080918: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008091C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 000000080920: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 000000080928: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 000000080930: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080934: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 000000080938: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 000000080940: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 000000080948: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008094C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 000000080950: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s10, v[4:5]            // 000000080958: D6FE7C1F 041014FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 000000080964: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 00000008096C: D8340000 0000201F
	s_branch 64815                                             // 000000080974: BFA0FD2F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_mov_b32_e32 v30, v14                                     // 000000080978: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 00000008097C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 000000080984: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 000000080988: 7E46032B
	s_mov_b32 s10, 0                                           // 00000008098C: BE8A0080
	s_branch 21                                                // 000000080990: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000080994: 8C7E0B7E
	.long 0xd700011f                                           // 000000080998: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 00000008099C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000809A4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000809A8: D5207C20 00064080
	.long 0xd700011d                                           // 0000000809B0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000809B4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000809BC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000809C0: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 0000000809C8: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 0000000809CC: BF08B70A
	s_mov_b32 s10, s1                                          // 0000000809D0: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000809D4: BC7C0000
	s_barrier                                                  // 0000000809D8: BFBD0000
	buffer_gl0_inv                                             // 0000000809DC: E0AC0000 00000000
	s_cbranch_scc1 616                                         // 0000000809E4: BFA20268 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a88>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000809E8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000809EC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000809F4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000809F8: 7E780326
	s_mov_b32 s11, 0                                           // 0000000809FC: BE8B0080
	global_load_b32 v61, v[33:34], off                         // 000000080A00: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 000000080A08: 4A7878FF 00000080
	.long 0xd7000121                                           // 000000080A10: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 000000080A14: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000080A1C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 000000080A20: D5207C22 00064480
	.long 0xd4490004                                           // 000000080A28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 000000080A2C: 020278FF 0000037F
	s_or_b32 s11, s4, s11                                      // 000000080A34: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 000000080A38: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 000000080A3C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 000000080A44: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 000000080A4C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000080A50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000080A54: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000080A58: BF89FC07
	s_barrier                                                  // 000000080A5C: BFBD0000
	buffer_gl0_inv                                             // 000000080A60: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 000000080A68: BE8B2000
	s_cbranch_execz 65481                                      // 000000080A6C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s10, v2                                  // 000000080A70: 3842040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000080A74: BF870091
	v_or_b32_e32 v36, s7, v33                                  // 000000080A78: 38484207
	.long 0xd4440001                                           // 000000080A7C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 000000080A80: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 000000080A84: 8B7E017E
	s_cbranch_execz 65474                                      // 000000080A88: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 000000080A8C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 000000080A94: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 000000080A9C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 000000080AA4: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 000000080AAC: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 000000080AB4: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 000000080ABC: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 000000080AC4: D8DC7766 4A000001
	s_mov_b32 s12, 0                                           // 000000080ACC: BE8C0080
	s_waitcnt lgkmcnt(6)                                       // 000000080AD0: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 000000080AD4: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080ADC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000080AE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000080AE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000080AE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080AEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000080AF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000080AF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000080AF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080AFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000080B00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000080B04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000080B08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000080B0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000080B10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:8 offset1:9        // 000000080B14: D8DC0908 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 000000080B1C: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 000000080B24: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 000000080B2C: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:12 offset1:13      // 000000080B34: D8DC0D0C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 000000080B3C: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 000000080B44: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 000000080B4C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 000000080B54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000080B58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080B5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000080B60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000080B64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000080B68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080B6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000080B70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000080B74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000080B78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080B7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000080B80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000080B84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000080B88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000080B8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000080B90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 000000080B94: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 000000080B9C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 000000080BA4: D8DC1312 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 000000080BAC: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:20 offset1:21      // 000000080BB4: D8DC1514 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 000000080BBC: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 000000080BC4: D8DC6554 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 000000080BCC: D8DC8776 4A000030
	s_waitcnt lgkmcnt(6)                                       // 000000080BD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000080BD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080BDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000080BE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000080BE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000080BE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080BEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000080BF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000080BF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000080BF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080BFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000080C00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000080C04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000080C08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000080C0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000080C10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 000000080C14: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 000000080C1C: D8DCA998 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 000000080C24: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 000000080C2C: D8DCCBBA 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:28 offset1:29      // 000000080C34: D8DC1D1C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 000000080C3C: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 000000080C44: D8DCEDDC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:126 offset1:143    // 000000080C4C: D8DC8F7E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 000000080C54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000080C58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080C5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000080C60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000080C64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000080C68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080C6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000080C70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000080C74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000080C78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080C7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000080C80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000080C84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000080C88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000080C8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000080C90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 000000080C94: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 000000080C9C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 000000080CA4: D8DC2322 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:66 offset1:83      // 000000080CAC: D8DC5342 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:36 offset1:37      // 000000080CB4: D8DC2524 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 000000080CBC: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 000000080CC4: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 000000080CCC: D8DC9786 4A000032
	s_waitcnt lgkmcnt(6)                                       // 000000080CD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000080CD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080CDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000080CE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000080CE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000080CE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080CEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000080CF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000080CF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000080CF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080CFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000080D00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000080D04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000080D08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000080D0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000080D10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:40 offset1:41      // 000000080D14: D8DC2928 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:168 offset1:185    // 000000080D1C: D8DCB9A8 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 000000080D24: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:202 offset1:219    // 000000080D2C: D8DCDBCA 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:44 offset1:45      // 000000080D34: D8DC2D2C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 000000080D3C: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 000000080D44: D8DCFDEC 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:14 offset1:31      // 000000080D4C: D8DC1F0E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 000000080D54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000080D58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080D5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000080D60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000080D64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000080D68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080D6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000080D70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000080D74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000080D78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080D7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000080D80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000080D84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000080D88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000080D8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000080D90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 000000080D94: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 000000080D9C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 000000080DA4: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 000000080DAC: D8DC6352 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:52 offset1:53      // 000000080DB4: D8DC3534 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 000000080DBC: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 000000080DC4: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 000000080DCC: D8DCA796 4A000033
	s_waitcnt lgkmcnt(6)                                       // 000000080DD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000080DD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080DDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000080DE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000080DE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000080DE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080DEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000080DF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000080DF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000080DF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080DFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000080E00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000080E04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000080E08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000080E0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000080E10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:56 offset1:57      // 000000080E14: D8DC3938 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:184 offset1:201    // 000000080E1C: D8DCC9B8 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 000000080E24: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:218 offset1:235    // 000000080E2C: D8DCEBDA 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:60 offset1:61      // 000000080E34: D8DC3D3C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 000000080E3C: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 000000080E44: D8DC8D7C 48000034
	ds_load_2addr_b32 v[74:75], v53 offset0:30 offset1:47      // 000000080E4C: D8DC2F1E 4A000035
	s_waitcnt lgkmcnt(6)                                       // 000000080E54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000080E58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080E5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000080E60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000080E64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000080E68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080E6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000080E70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000080E74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000080E78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080E7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000080E80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000080E84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000080E88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000080E8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000080E90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 000000080E94: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 000000080E9C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 000000080EA4: D8DC4342 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:98 offset1:115     // 000000080EAC: D8DC7362 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:68 offset1:69      // 000000080EB4: D8DC4544 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 000000080EBC: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 000000080EC4: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 000000080ECC: D8DCB7A6 4A000035
	s_waitcnt lgkmcnt(6)                                       // 000000080ED4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000080ED8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080EDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000080EE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000080EE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000080EE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080EEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000080EF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000080EF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000080EF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080EFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000080F00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000080F04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000080F08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000080F0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000080F10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 000000080F14: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 000000080F1C: D8DCD9C8 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 000000080F24: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 000000080F2C: D8DCFBEA 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:76 offset1:77      // 000000080F34: D8DC4D4C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 000000080F3C: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 000000080F44: D8DC1D0C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:46 offset1:63      // 000000080F4C: D8DC3F2E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 000000080F54: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000080F58: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080F5C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000080F60: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000080F64: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000080F68: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080F6C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000080F70: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000080F74: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000080F78: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080F7C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000080F80: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000080F84: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000080F88: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 000000080F8C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000080F90: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 000000080F94: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 000000080F9C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 000000080FA4: D8DC5352 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:114 offset1:131    // 000000080FAC: D8DC8372 42000036
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:85      // 000000080FB4: D8DC5554 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 000000080FBC: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 000000080FC4: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 000000080FCC: D8DCC7B6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 000000080FD4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000080FD8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080FDC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000080FE0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000080FE4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000080FE8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080FEC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000080FF0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000080FF4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000080FF8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000080FFC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000081000: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000081004: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000081008: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008100C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000081010: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:88 offset1:89      // 000000081014: D8DC5958 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:216 offset1:233    // 00000008101C: D8DCE9D8 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:90 offset1:91      // 000000081024: D8DC5B5A 4000002E
	ds_load_2addr_b32 v[66:67], v55 offset0:122 offset1:139    // 00000008102C: D8DC8B7A 42000037
	ds_load_2addr_b32 v[68:69], v46 offset0:92 offset1:93      // 000000081034: D8DC5D5C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 00000008103C: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 000000081044: D8DC2D1C 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:62 offset1:79      // 00000008104C: D8DC4F3E 4A000038
	s_waitcnt lgkmcnt(6)                                       // 000000081054: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000081058: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008105C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000081060: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000081064: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000081068: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008106C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000081070: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000081074: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000081078: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008107C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000081080: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000081084: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000081088: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008108C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000081090: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 000000081094: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 00000008109C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 0000000810A4: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 0000000810AC: D8DC9382 42000038
	ds_load_2addr_b32 v[68:69], v46 offset0:100 offset1:101    // 0000000810B4: D8DC6564 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 0000000810BC: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000810C4: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000810CC: D8DCD7C6 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000810D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000810D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000810DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000810E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000810E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000810E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000810EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000810F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000810F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000810F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000810FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000081100: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000081104: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000081108: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008110C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000081110: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:104 offset1:105    // 000000081114: D8DC6968 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:232 offset1:249    // 00000008111C: D8DCF9E8 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 000000081124: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:10 offset1:27      // 00000008112C: D8DC1B0A 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:108 offset1:109    // 000000081134: D8DC6D6C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 00000008113C: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 000000081144: D8DC3D2C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:78 offset1:95      // 00000008114C: D8DC5F4E 4A000039
	s_waitcnt lgkmcnt(6)                                       // 000000081154: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 000000081158: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008115C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 000000081160: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 000000081164: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000081168: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008116C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 000000081170: 56988741
	s_waitcnt lgkmcnt(1)                                       // 000000081174: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 000000081178: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008117C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000081180: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000081184: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000081188: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008118C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000081190: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 000000081194: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 00000008119C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 0000000811A4: D8DC7372 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:146 offset1:163    // 0000000811AC: D8DCA392 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:116 offset1:117    // 0000000811B4: D8DC7574 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 0000000811BC: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000811C4: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000811CC: D8DCE7D6 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000811D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000811D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000811DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000811E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000811E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000811E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000811EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000811F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000811F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000811F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000811FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 000000081200: 56989345
	s_waitcnt lgkmcnt(0)                                       // 000000081204: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 000000081208: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008120C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 000000081210: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 000000081214: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 00000008121C: D8DC8978 3E00003A
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 000000081224: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:26 offset1:43      // 00000008122C: D8DC2B1A 4200003B
	ds_load_2addr_b32 v[68:69], v46 offset0:124 offset1:125    // 000000081234: D8DC7D7C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 00000008123C: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 000000081244: D8DC4D3C 4800003B
	ds_load_2addr_b32 v[74:75], v59 offset0:94 offset1:111     // 00000008124C: D8DC6F5E 4A00003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 000000081254: 30424282
	s_waitcnt lgkmcnt(6)                                       // 000000081258: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 00000008125C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 000000081260: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 000000081268: CA10011E 2220011D
	v_mov_b32_e32 v62, v35                                     // 000000081270: 7E7C0323
	v_fmac_f32_e32 v76, v61, v63                               // 000000081274: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 000000081278: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 00000008127C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081280: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 000000081284: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 000000081288: 56988741
	s_waitcnt lgkmcnt(2)                                       // 00000008128C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081290: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 000000081294: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 000000081298: 56989345
	s_waitcnt lgkmcnt(1)                                       // 00000008129C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000812A0: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 0000000812A4: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 0000000812A8: 56989747
	s_waitcnt lgkmcnt(0)                                       // 0000000812AC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000812B0: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 0000000812B4: 1078794C
	s_nop 0                                                    // 0000000812B8: BF800000
	s_nop 0                                                    // 0000000812BC: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000812C0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000812C8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000812D0: 4A7C7CC1
	.long 0xd7000121                                           // 0000000812D4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000812D8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000812DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000812E0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000812E8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000812EC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000812F0: 4A7A7AFF 00000044
	s_or_b32 s12, s4, s12                                      // 0000000812F8: 8C0C0C04
	s_waitcnt lgkmcnt(0)                                       // 0000000812FC: BF89FC07
	v_bfe_u32 v65, v64, 16, 1                                  // 000000081300: D6100041 02052140
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081308: BF870091
	v_add3_u32 v64, v64, v65, 0x7fff                           // 00000008130C: D6550040 03FE8340 00007FFF
	v_and_b32_e32 v64, 0xffff0000, v64                         // 000000081318: 368080FF FFFF0000
	s_waitcnt vmcnt(0)                                         // 000000081320: BF8903F7
	v_bfe_u32 v66, v63, 16, 1                                  // 000000081324: D6100042 0205213F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008132C: BF870091
	v_add3_u32 v63, v63, v66, 0x7fff                           // 000000081330: D655003F 03FE853F 00007FFF
	v_and_b32_e32 v63, 0xffff0000, v63                         // 00000008133C: 367E7EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000081344: BF870001
	v_fmac_f32_e32 v60, v63, v64                               // 000000081348: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 00000008134C: 917E0C7E
	s_cbranch_execnz 65499                                     // 000000081350: BFA6FFDB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19c0>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000081354: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081358: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 00000008135C: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 000000081364: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 000000081370: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 00000008137C: DC960000 007C2421
	s_branch 64899                                             // 000000081384: BFA0FD83 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 000000081388: A201FF06 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 000000081390: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000081394: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 000000081398: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 0000000813A0: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 0000000813A4: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 0000000813AC: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 0000000813B4: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000813B8: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 0000000813BC: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000813C4: A0010401
	s_mov_b32 s4, 0                                            // 0000000813C8: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000813CC: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000813D0: 7E3A4A01
	s_cvt_i32_f32 s1, s7                                       // 0000000813D4: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000813D8: BF870585
	.long 0xd71c001d                                           // 0000000813DC: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000813E0: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000813E4: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 0000000813E8: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000813F0: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000813F4: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000813FC: 980180C1
	v_mov_b32_e32 v29, v37                                     // 000000081400: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 000000081404: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 000000081410: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 000000081418: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000081420: BF870001
	.long 0xd4490001                                           // 000000081424: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 000000081428: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 000000081430: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 000000081434: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 000000081438: 1040411E
	ds_store_b32 v29, v32                                      // 00000008143C: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 000000081444: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000008144C: 917E047E
	s_cbranch_execnz 65519                                     // 000000081450: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b10>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000081454: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 000000081458: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 000000081460: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 000000081468: 7E420326
	s_mov_b32 s6, 0                                            // 00000008146C: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000081470: BF89FC07
	s_barrier                                                  // 000000081474: BFBD0000
	buffer_gl0_inv                                             // 000000081478: E0AC0000 00000000
	global_load_b32 v34, v[29:30], off                         // 000000081480: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 000000081488: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000081490: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000081498: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008149C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000814A4: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000814A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000814B0: BF870004
	.long 0xd4490004                                           // 0000000814B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000814B8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 0000000814C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000814C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000814C8: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 0000000814CC: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000814D4: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000814DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000000814E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b80>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000814E4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000814E8: BF89FC07
	s_barrier                                                  // 0000000814EC: BFBD0000
	buffer_gl0_inv                                             // 0000000814F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000814F8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 000000081500: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 000000081508: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 000000081510: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 000000081518: 7E780300
	s_mov_b32 s4, 0                                            // 00000008151C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000081520: BF840001
	s_nop 0                                                    // 000000081524: BF800000
	s_nop 0                                                    // 000000081528: BF800000
	s_nop 0                                                    // 00000008152C: BF800000
	s_nop 0                                                    // 000000081530: BF800000
	s_nop 0                                                    // 000000081534: BF800000
	s_nop 0                                                    // 000000081538: BF800000
	s_nop 0                                                    // 00000008153C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081540: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000081544: 327A7884
	.long 0xd4490001                                           // 000000081548: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000008154C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000081554: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000081558: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000081564: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000081568: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000081570: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000081578: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000081580: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000081588: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000081590: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000081598: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000815A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000815A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000815B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000815B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000815B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000815C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000815C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000815C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000815CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000815D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000815D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000815D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000815DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000815E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000815E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000815F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000815F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000081600: 917E047E
	s_cbranch_execnz 65486                                     // 000000081604: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_set_inst_prefetch_distance 0x2                           // 000000081608: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008160C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 000000081610: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000081618: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000081620: 7E420326
	s_mov_b32 s6, 0                                            // 000000081624: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000081628: BF89FC07
	s_barrier                                                  // 00000008162C: BFBD0000
	buffer_gl0_inv                                             // 000000081630: E0AC0000 00000000
	s_nop 0                                                    // 000000081638: BF800000
	s_nop 0                                                    // 00000008163C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000081640: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 000000081648: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000081650: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000081658: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008165C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000081664: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000081668: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000081670: BF870004
	.long 0xd4490004                                           // 000000081674: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000081678: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000081680: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000081684: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000081688: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008168C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000081694: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000008169C: 917E067E
	s_cbranch_execnz 65511                                     // 0000000816A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d40>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000816A4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000816A8: BF89FC07
	s_barrier                                                  // 0000000816AC: BFBD0000
	buffer_gl0_inv                                             // 0000000816B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000816B8: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000000816C0: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000000816C8: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000000816D0: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000816D8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000816DC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000816E0: BF840001
	s_nop 0                                                    // 0000000816E4: BF800000
	s_nop 0                                                    // 0000000816E8: BF800000
	s_nop 0                                                    // 0000000816EC: BF800000
	s_nop 0                                                    // 0000000816F0: BF800000
	s_nop 0                                                    // 0000000816F4: BF800000
	s_nop 0                                                    // 0000000816F8: BF800000
	s_nop 0                                                    // 0000000816FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081700: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000081704: 327A7884
	.long 0xd4490001                                           // 000000081708: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000008170C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000081714: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000081718: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000081724: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000081728: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000081730: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000081738: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000081740: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000081748: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000081750: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000081758: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000081760: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000081764: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000081770: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000081774: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000081778: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000081780: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000081784: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000081788: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000008178C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081790: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000081794: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000081798: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000008179C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000817A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000817A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000817B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000817B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000817C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000817C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e00>
	s_set_inst_prefetch_distance 0x2                           // 0000000817C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000817CC: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000000817D0: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000817D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000817E0: 7E420326
	s_mov_b32 s6, 0                                            // 0000000817E4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000817E8: BF89FC07
	s_barrier                                                  // 0000000817EC: BFBD0000
	buffer_gl0_inv                                             // 0000000817F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000817F8: BF800000
	s_nop 0                                                    // 0000000817FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000081800: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 000000081808: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000081810: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000081818: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008181C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000081824: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000081828: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000081830: BF870004
	.long 0xd4490004                                           // 000000081834: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000081838: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000081840: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000081844: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000081848: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008184C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000081854: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000008185C: 917E067E
	s_cbranch_execnz 65511                                     // 000000081860: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f00>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000081864: 8C7E067E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 000000081868: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000081870: BF89FC07
	s_barrier                                                  // 000000081874: BFBD0000
	buffer_gl0_inv                                             // 000000081878: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 000000081880: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 000000081884: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 00000008188C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 000000081894: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 00000008189C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000818A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000818A8: BF840001
	s_nop 0                                                    // 0000000818AC: BF800000
	s_nop 0                                                    // 0000000818B0: BF800000
	s_nop 0                                                    // 0000000818B4: BF800000
	s_nop 0                                                    // 0000000818B8: BF800000
	s_nop 0                                                    // 0000000818BC: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000818C0: 327C7A84
	.long 0xd4490001                                           // 0000000818C4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000818C8: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000818D0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000818D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000818D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000818E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000818E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000818F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000818F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000081900: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000081908: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000081910: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000081918: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000081920: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000081924: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000081928: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000008192C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000081938: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000081940: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000081944: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000081948: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000008194C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081950: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000081954: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000081958: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000008195C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081960: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000081964: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000081970: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000081978: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000081980: 917E047E
	s_cbranch_execnz 65486                                     // 000000081984: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fc0>
	s_set_inst_prefetch_distance 0x2                           // 000000081988: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008198C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 000000081990: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000081998: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000819A0: 7E420326
	s_mov_b32 s6, 0                                            // 0000000819A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000819A8: BF89FC07
	s_barrier                                                  // 0000000819AC: BFBD0000
	buffer_gl0_inv                                             // 0000000819B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000819B8: BF800000
	s_nop 0                                                    // 0000000819BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000819C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000000819C8: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000819D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000819D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000819DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000819E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000819E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000819F0: BF870004
	.long 0xd4490004                                           // 0000000819F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000819F8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000081A00: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000081A04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000081A08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000081A0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000081A14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000081A1C: 917E067E
	s_cbranch_execnz 65511                                     // 000000081A20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x20c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000081A24: 8C7E067E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 000000081A28: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 000000081A30: BF89FC07
	s_barrier                                                  // 000000081A34: BFBD0000
	buffer_gl0_inv                                             // 000000081A38: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 000000081A40: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 000000081A48: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 000000081A50: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 000000081A58: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000081A60: 7E780300
	s_mov_b32 s4, 0                                            // 000000081A64: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000081A68: BF840001
	s_nop 0                                                    // 000000081A6C: BF800000
	s_nop 0                                                    // 000000081A70: BF800000
	s_nop 0                                                    // 000000081A74: BF800000
	s_nop 0                                                    // 000000081A78: BF800000
	s_nop 0                                                    // 000000081A7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081A80: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000081A84: 327A7884
	.long 0xd4490001                                           // 000000081A88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000081A8C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000081A94: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000081A98: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000081AA4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000081AA8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000081AB0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000081AB8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000081AC0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000081AC8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000081AD0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000081AD8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000081AE0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000081AE4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000081AF0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000081AF4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000081AF8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000081B00: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000081B04: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000081B08: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 000000081B0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081B10: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000081B14: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000081B18: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 000000081B1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081B20: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000081B24: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000081B30: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000081B38: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000081B40: 917E047E
	s_cbranch_execnz 65486                                     // 000000081B44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_set_inst_prefetch_distance 0x2                           // 000000081B48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000081B4C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 000000081B50: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000081B58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000081B60: 7E420326
	s_mov_b32 s6, 0                                            // 000000081B64: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000081B68: BF89FC07
	s_barrier                                                  // 000000081B6C: BFBD0000
	buffer_gl0_inv                                             // 000000081B70: E0AC0000 00000000
	s_nop 0                                                    // 000000081B78: BF800000
	s_nop 0                                                    // 000000081B7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000081B80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 000000081B88: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000081B90: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000081B98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000081B9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000081BA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000081BA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000081BB0: BF870004
	.long 0xd4490004                                           // 000000081BB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000081BB8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000081BC0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000081BC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000081BC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000081BCC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000081BD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000081BDC: 917E067E
	s_cbranch_execnz 65511                                     // 000000081BE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2280>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000081BE4: 8C7E067E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 000000081BE8: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 000000081BF0: BF89FC07
	s_barrier                                                  // 000000081BF4: BFBD0000
	buffer_gl0_inv                                             // 000000081BF8: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 000000081C00: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 000000081C04: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 000000081C0C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 000000081C14: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 000000081C1C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 000000081C24: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000081C28: BF840001
	s_nop 0                                                    // 000000081C2C: BF800000
	s_nop 0                                                    // 000000081C30: BF800000
	s_nop 0                                                    // 000000081C34: BF800000
	s_nop 0                                                    // 000000081C38: BF800000
	s_nop 0                                                    // 000000081C3C: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 000000081C40: 327C7884
	.long 0xd4490001                                           // 000000081C44: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000081C48: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000081C50: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000081C54: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000081C58: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000081C64: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000081C68: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000081C70: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000081C78: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000081C80: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000081C88: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000081C90: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000081C98: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000081CA0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000081CA4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000081CA8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000081CAC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000081CB8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000081CC0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000081CC4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000081CC8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 000000081CCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081CD0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000081CD4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000081CD8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 000000081CDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081CE0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 000000081CE4: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 000000081CF0: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 000000081CF4: BF870002
	v_mov_b32_e32 v60, v63                                     // 000000081CF8: 7E78033F
	ds_store_b32 v62, v70                                      // 000000081CFC: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000081D04: 917E047E
	s_cbranch_execnz 65485                                     // 000000081D08: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2340>
	s_set_inst_prefetch_distance 0x2                           // 000000081D0C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000081D10: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 000000081D14: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000081D1C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000081D24: 7E420326
	s_mov_b32 s6, 0                                            // 000000081D28: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000081D2C: BF89FC07
	s_barrier                                                  // 000000081D30: BFBD0000
	buffer_gl0_inv                                             // 000000081D34: E0AC0000 00000000
	s_nop 0                                                    // 000000081D3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000081D40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 000000081D48: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000081D50: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000081D58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000081D5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000081D64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000081D68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000081D70: BF870004
	.long 0xd4490004                                           // 000000081D74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000081D78: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000081D80: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000081D84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000081D88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000081D8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000081D94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000081D9C: 917E067E
	s_cbranch_execnz 65511                                     // 000000081DA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000081DA4: 8C7E067E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 000000081DA8: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 000000081DB0: BF89FC07
	s_barrier                                                  // 000000081DB4: BFBD0000
	buffer_gl0_inv                                             // 000000081DB8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 000000081DC0: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 000000081DC8: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 000000081DD0: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 000000081DD8: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000081DE0: 7E7A0300
	s_mov_b32 s4, 0                                            // 000000081DE4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000081DE8: BF840001
	s_nop 0                                                    // 000000081DEC: BF800000
	s_nop 0                                                    // 000000081DF0: BF800000
	s_nop 0                                                    // 000000081DF4: BF800000
	s_nop 0                                                    // 000000081DF8: BF800000
	s_nop 0                                                    // 000000081DFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081E00: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000081E04: 327C7A84
	.long 0xd4490001                                           // 000000081E08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000081E0C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000081E14: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000081E18: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000081E24: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000081E28: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000081E30: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000081E38: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000081E40: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000081E48: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000081E50: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000081E58: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000081E60: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000081E64: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000081E68: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000081E6C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000081E78: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000081E80: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000081E84: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000081E88: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 000000081E8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081E90: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000081E94: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000081E98: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 000000081E9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000081EA0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000081EA4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000081EB0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000081EB8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000081EC0: 917E047E
	s_cbranch_execnz 65486                                     // 000000081EC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2500>
	s_set_inst_prefetch_distance 0x2                           // 000000081EC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000081ECC: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 000000081ED0: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000081ED8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000081EE0: 7E420326
	s_mov_b32 s6, 0                                            // 000000081EE4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000081EE8: BF89FC07
	s_barrier                                                  // 000000081EEC: BFBD0000
	buffer_gl0_inv                                             // 000000081EF0: E0AC0000 00000000
	s_nop 0                                                    // 000000081EF8: BF800000
	s_nop 0                                                    // 000000081EFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000081F00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 000000081F08: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000081F10: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000081F18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000081F1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000081F24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000081F28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000081F30: BF870004
	.long 0xd4490004                                           // 000000081F34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000081F38: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000081F40: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000081F44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000081F48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000081F4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000081F54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000081F5C: 917E067E
	s_cbranch_execnz 65511                                     // 000000081F60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2600>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000081F64: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000081F68: BF89FC07
	s_barrier                                                  // 000000081F6C: BFBD0000
	buffer_gl0_inv                                             // 000000081F70: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 000000081F78: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 000000081F80: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 000000081F88: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 000000081F90: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000081F98: 7E7A0300
	s_mov_b32 s4, 0                                            // 000000081F9C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000081FA0: BF840001
	s_nop 0                                                    // 000000081FA4: BF800000
	s_nop 0                                                    // 000000081FA8: BF800000
	s_nop 0                                                    // 000000081FAC: BF800000
	s_nop 0                                                    // 000000081FB0: BF800000
	s_nop 0                                                    // 000000081FB4: BF800000
	s_nop 0                                                    // 000000081FB8: BF800000
	s_nop 0                                                    // 000000081FBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000081FC0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000081FC4: 327C7A84
	.long 0xd4490001                                           // 000000081FC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000081FCC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000081FD4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000081FD8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000081FE4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000081FE8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000081FF0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000081FF8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000082000: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000082008: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000082010: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000082018: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000082020: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000082024: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000082028: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000008202C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000082038: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000082040: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000082044: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000082048: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000008204C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082050: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000082054: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000082058: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000008205C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082060: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000082064: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000082070: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000082078: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000082080: 917E047E
	s_cbranch_execnz 65486                                     // 000000082084: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26c0>
	s_set_inst_prefetch_distance 0x2                           // 000000082088: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008208C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 000000082090: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000082098: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000820A0: 7E420326
	s_mov_b32 s6, 0                                            // 0000000820A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000820A8: BF89FC07
	s_barrier                                                  // 0000000820AC: BFBD0000
	buffer_gl0_inv                                             // 0000000820B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000820B8: BF800000
	s_nop 0                                                    // 0000000820BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000820C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000000820C8: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000820D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000820D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000820DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000820E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000820E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000820F0: BF870004
	.long 0xd4490004                                           // 0000000820F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000820F8: 020242FF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000082100: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000082104: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000082108: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008210C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000082114: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000008211C: 917E067E
	s_cbranch_execnz 65511                                     // 000000082120: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000082124: 8C7E067E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 000000082128: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 000000082130: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 000000082138: BF89FC07
	s_barrier                                                  // 00000008213C: BFBD0000
	buffer_gl0_inv                                             // 000000082140: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 000000082148: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 000000082150: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 000000082158: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 000000082160: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000082168: 7E780300
	s_mov_b32 s4, 0                                            // 00000008216C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000082170: BF840001
	s_nop 0                                                    // 000000082174: BF800000
	s_nop 0                                                    // 000000082178: BF800000
	s_nop 0                                                    // 00000008217C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000082180: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000082184: 327A7884
	.long 0xd4490001                                           // 000000082188: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000008218C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000082194: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000082198: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000821A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000821A8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000821B0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000821B8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000821C0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000821C8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000821D0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000821D8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000821E0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000821E4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000821F0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000821F4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000821F8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000082200: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000082204: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000082208: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000008220C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082210: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000082214: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000082218: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000008221C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000082220: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000082224: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000082230: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000082238: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000082240: 917E047E
	s_cbranch_execnz 65486                                     // 000000082244: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2880>
	s_set_inst_prefetch_distance 0x2                           // 000000082248: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008224C: 8C7E047E
	.long 0xd7000107                                           // 000000082250: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 000000082254: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008225C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 000000082260: D5207C08 00061080
	.long 0xd7000109                                           // 000000082268: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 00000008226C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 000000082274: D5207C0A 00061480
	.long 0xd700010d                                           // 00000008227C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 000000082280: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000082288: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 00000008228C: D5207C0E 00061C80
	.long 0xd700010b                                           // 000000082294: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 000000082298: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000822A0: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000822A8: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000822AC: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000822B4: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000822B8: D5207C10 00062080
	.long 0xd7000111                                           // 0000000822C0: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000822C4: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000822CC: D5207C12 00062480
	.long 0xd7000113                                           // 0000000822D4: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000822D8: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000822E0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000822E4: D5207C14 00062880
	.long 0xd7000115                                           // 0000000822EC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000822F0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000822F8: D5207C16 00062C80
	.long 0xd7000117                                           // 000000082300: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 000000082304: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008230C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 000000082310: D5207C18 00063080
	.long 0xd7000119                                           // 000000082318: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 00000008231C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 000000082324: D5207C1A 00063480
	.long 0xd700011b                                           // 00000008232C: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 000000082330: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000082338: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 00000008233C: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 000000082344: 81058105
	s_waitcnt lgkmcnt(0)                                       // 000000082348: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 00000008234C: BF062105
	s_barrier                                                  // 000000082350: BFBD0000
	buffer_gl0_inv                                             // 000000082354: E0AC0000 00000000
	s_cbranch_scc0 63057                                       // 00000008235C: BFA1F651 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 000000082360: 7E080326
	s_add_u32 s0, s28, s20                                     // 000000082364: 8000141C
	.long 0xd73c0000                                           // 000000082368: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000008236C: 02020489
	s_addc_u32 s1, s29, s21                                    // 000000082370: 8201151D
	s_add_u32 s2, s24, s18                                     // 000000082374: 80021218
	s_addc_u32 s3, s25, s19                                    // 000000082378: 82031319
	s_add_u32 s0, s2, s0                                       // 00000008237C: 80000002
	s_addc_u32 s1, s3, s1                                      // 000000082380: 82010103
	.long 0xd7006a00                                           // 000000082384: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000082388: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000008238C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000082390: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000082398: BE810080
	.long 0xd7006a00                                           // 00000008239C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 0000000823A0: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000823A4: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000823AC: BF870092
	.long 0xd7006a00                                           // 0000000823B0: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000823B4: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000823B8: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 0000000823C0: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000823C8: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000000823D0: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000823D8: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000823DC: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000823E4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000823E8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000823EC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000823F4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000823F8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 000000082400: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000082408: 917E017E
	s_cbranch_execnz 65516                                     // 00000008240C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi2ELi4ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ac0>
	s_endpgm                                                   // 000000082410: BFB00000
		...

