000000000014c500 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 00000014C500: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 00000014C504: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 00000014C50C: F4080500 F8000050
	v_and_b32_e32 v131, 31, v0                                 // 00000014C514: 3706009F
	v_lshrrev_b32_e32 v148, 5, v0                              // 00000014C518: 33280085
	s_mov_b32 s24, s3                                          // 00000014C51C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014C520: BF870112
	.long 0xd44c0003                                           // 00000014C524: D44C0003
	v_cndmask_b32_e32 v1, 16, v131, vcc_lo                     // 00000014C528: 02030690
	v_lshlrev_b32_e32 v132, 6, v148                            // 00000014C52C: 31092886
	s_waitcnt lgkmcnt(0)                                       // 00000014C530: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 00000014C534: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 00000014C53C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C540: BF870001
	v_lshl_add_u32 v1, v131, 2, v132                           // 00000014C544: D6460001 06110583
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 00000014C54C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:231 offset1:243// 00000014C558: D83CF3E7 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 00000014C560: 8C7E047E
	v_mul_u32_u24_e32 v1, 0x2ab, v0                            // 00000014C564: 160200FF 000002AB
	s_lshl_b32 s25, s2, 5                                      // 00000014C56C: 84198502
	v_dual_mov_b32 v142, 0 :: v_dual_and_b32 v147, 15, v0      // 00000014C570: CA240080 8E92008F
	s_cmp_eq_u64 s[14:15], 0                                   // 00000014C578: BF10800E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000014C57C: BF8704C2
	.long 0xd7381001                                           // 00000014C580: D7381001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000014C584: 02020282
	.long 0x7f023880                                           // 00000014C588: 7F023880
	v_mov_b32_e32 v141, 0                                      // 00000014C58C: 7F1A0280
	s_cselect_b32 s27, -1, 0                                   // 00000014C590: 981B80C1
	s_and_b32 vcc_lo, exec_lo, s27                             // 00000014C594: 8B6A1B7E
	.long 0xd7620001                                           // 00000014C598: D7620001
	v_cndmask_b32_e32 v0, v1, v176, vcc_lo                     // 00000014C59C: 02016101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014C5A0: BF870091
	v_add_nc_u32_e32 v149, s25, v1                             // 00000014C5A4: 4B2A0219
	v_or_b32_e32 v129, v149, v147                              // 00000014C5A8: 39032795
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C5AC: BF870001
	v_ashrrev_i32_e32 v130, 31, v129                           // 00000014C5B0: 3505029F
	s_cbranch_vccnz 10                                         // 00000014C5B4: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xe0>
	v_mad_i64_i32 v[1:2], null, s23, v129, 0                   // 00000014C5B8: D6FF7C01 02030217
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014C5C0: BF870091
	.long 0xd73c0001                                           // 00000014C5C4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000014C5C8: 02020282
	.long 0xd7006a8d                                           // 00000014C5CC: D7006A8D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000014C5D0: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C5D4: BF870001
	v_add_co_ci_u32_e64 v142, null, s15, v2, vcc_lo            // 00000014C5D8: D5207C8E 01AA040F
	s_clause 0x2                                               // 00000014C5E0: BF850002
	s_load_b64 s[14:15], s[0:1], 0x38                          // 00000014C5E4: F4040380 F8000038
	s_load_b128 s[16:19], s[0:1], 0x20                         // 00000014C5EC: F4080400 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 00000014C5F4: F40C0100 F8000000
	v_mov_b32_e32 v151, 0                                      // 00000014C5FC: 7F2E0280
	s_xor_b32 s0, s27, -1                                      // 00000014C600: 8D00C11B
	s_waitcnt lgkmcnt(0)                                       // 00000014C604: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v129                         // 00000014C608: 7C89020E
	s_and_b32 s23, s0, vcc_lo                                  // 00000014C60C: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014C610: BF870009
	s_and_saveexec_b32 s0, s23                                 // 00000014C614: BE802017
	s_cbranch_execz 9                                          // 00000014C618: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x140>
	.long 0xd73c0001                                           // 00000014C61C: D73C0001
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 00000014C620: 02030282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014C624: BF870091
	.long 0xd7006a01                                           // 00000014C628: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 00000014C62C: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 00000014C630: D5207C02 01AA0415
	global_load_b32 v151, v[1:2], off                          // 00000014C638: DC520000 977C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014C640: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 00000014C644: BF10800C
	s_mov_b64 s[20:21], 0                                      // 00000014C648: BE940180
	s_cbranch_scc1 10                                          // 00000014C64C: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x178>
	s_ashr_i32 s0, s22, 31                                     // 00000014C650: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 00000014C654: 96810216
	s_mul_i32 s0, s0, s2                                       // 00000014C658: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000014C65C: BF8704A9
	s_add_i32 s1, s1, s0                                       // 00000014C660: 81010001
	s_mul_i32 s0, s22, s2                                      // 00000014C664: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000014C668: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014C66C: BF870009
	s_add_u32 s20, s12, s0                                     // 00000014C670: 8014000C
	s_addc_u32 s21, s13, s1                                    // 00000014C674: 8215010D
	.long 0xd7050001                                           // 00000014C678: D7050001
	v_cndmask_b32_e32 v0, v148, v150, vcc_lo                   // 00000014C67C: 02012D94
	s_or_b32 s25, s25, 31                                      // 00000014C680: 8C199F19
	s_add_i32 s0, s14, -1                                      // 00000014C684: 8100C10E
	v_lshrrev_b32_e32 v150, 4, v131                            // 00000014C688: 332D0684
	s_min_i32 s0, s25, s0                                      // 00000014C68C: 89000019
	.long 0xd7390001                                           // 00000014C690: D7390001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 00000014C694: 02020288
	s_add_i32 s0, s26, s0                                      // 00000014C698: 8100001A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014C69C: BF870099
	s_cmp_lt_i32 s0, -15                                       // 00000014C6A0: BF04CF00
	.long 0xd7050001                                           // 00000014C6A4: D7050001
	v_cndmask_b32_e32 v0, v1, v140, vcc_lo                     // 00000014C6A8: 02011901
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014C6AC: BF870091
	.long 0xd7040001                                           // 00000014C6B0: D7040001
	v_cndmask_b32_e32 v1, v148, v1, vcc_lo                     // 00000014C6B4: 02020394
	v_dual_mov_b32 v72, 0 :: v_dual_and_b32 v1, 0xff, v1       // 00000014C6B8: CA240080 480002FF 000000FF
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014C6C4: BF870001
	v_mov_b32_e32 v71, v72                                     // 00000014C6C8: 7E8E0348
	v_mov_b32_e32 v69, v72                                     // 00000014C6CC: 7E8A0348
	v_mov_b32_e32 v68, v72                                     // 00000014C6D0: 7E880348
	v_mov_b32_e32 v67, v72                                     // 00000014C6D4: 7E860348
	v_mad_u64_u32 v[138:139], null, s24, 12, v[1:2]            // 00000014C6D8: D6FE7C8A 04051818
	v_mov_b32_e32 v70, v72                                     // 00000014C6E0: 7E8C0348
	v_mov_b32_e32 v66, v72                                     // 00000014C6E4: 7E840348
	v_mov_b32_e32 v65, v72                                     // 00000014C6E8: 7E820348
	v_mov_b32_e32 v80, v72                                     // 00000014C6EC: 7EA00348
	v_mov_b32_e32 v79, v72                                     // 00000014C6F0: 7E9E0348
	v_mov_b32_e32 v78, v72                                     // 00000014C6F4: 7E9C0348
	v_mov_b32_e32 v77, v72                                     // 00000014C6F8: 7E9A0348
	v_dual_mov_b32 v76, v72 :: v_dual_lshlrev_b32 v1, 8, v138  // 00000014C6FC: CA220148 4C011488
	v_mov_b32_e32 v75, v72                                     // 00000014C704: 7E960348
	v_mov_b32_e32 v74, v72                                     // 00000014C708: 7E940348
	v_mov_b32_e32 v73, v72                                     // 00000014C70C: 7E920348
	s_delay_alu instid0(VALU_DEP_4)                            // 00000014C710: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000014C714: 3404029F
	v_mov_b32_e32 v88, v72                                     // 00000014C718: 7EB00348
	v_mov_b32_e32 v87, v72                                     // 00000014C71C: 7EAE0348
	v_mov_b32_e32 v86, v72                                     // 00000014C720: 7EAC0348
	v_mov_b32_e32 v85, v72                                     // 00000014C724: 7EAA0348
	.long 0xd73c008b                                           // 00000014C728: D73C008B
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000014C72C: 02020281
	v_mov_b32_e32 v84, v72                                     // 00000014C730: 7EA80348
	v_mov_b32_e32 v83, v72                                     // 00000014C734: 7EA60348
	v_mov_b32_e32 v82, v72                                     // 00000014C738: 7EA40348
	v_mov_b32_e32 v81, v72                                     // 00000014C73C: 7EA20348
	v_mov_b32_e32 v96, v72                                     // 00000014C740: 7EC00348
	v_mov_b32_e32 v95, v72                                     // 00000014C744: 7EBE0348
	v_mov_b32_e32 v94, v72                                     // 00000014C748: 7EBC0348
	v_mov_b32_e32 v93, v72                                     // 00000014C74C: 7EBA0348
	v_mov_b32_e32 v92, v72                                     // 00000014C750: 7EB80348
	v_mov_b32_e32 v91, v72                                     // 00000014C754: 7EB60348
	v_mov_b32_e32 v90, v72                                     // 00000014C758: 7EB40348
	v_mov_b32_e32 v89, v72                                     // 00000014C75C: 7EB20348
	v_mov_b32_e32 v104, v72                                    // 00000014C760: 7ED00348
	v_mov_b32_e32 v103, v72                                    // 00000014C764: 7ECE0348
	v_mov_b32_e32 v102, v72                                    // 00000014C768: 7ECC0348
	v_mov_b32_e32 v101, v72                                    // 00000014C76C: 7ECA0348
	v_mov_b32_e32 v100, v72                                    // 00000014C770: 7EC80348
	v_mov_b32_e32 v99, v72                                     // 00000014C774: 7EC60348
	v_mov_b32_e32 v98, v72                                     // 00000014C778: 7EC40348
	v_mov_b32_e32 v97, v72                                     // 00000014C77C: 7EC20348
	v_mov_b32_e32 v112, v72                                    // 00000014C780: 7EE00348
	v_mov_b32_e32 v111, v72                                    // 00000014C784: 7EDE0348
	v_mov_b32_e32 v110, v72                                    // 00000014C788: 7EDC0348
	v_mov_b32_e32 v109, v72                                    // 00000014C78C: 7EDA0348
	v_mov_b32_e32 v108, v72                                    // 00000014C790: 7ED80348
	v_mov_b32_e32 v107, v72                                    // 00000014C794: 7ED60348
	v_mov_b32_e32 v106, v72                                    // 00000014C798: 7ED40348
	v_mov_b32_e32 v105, v72                                    // 00000014C79C: 7ED20348
	v_mov_b32_e32 v120, v72                                    // 00000014C7A0: 7EF00348
	v_mov_b32_e32 v119, v72                                    // 00000014C7A4: 7EEE0348
	v_mov_b32_e32 v118, v72                                    // 00000014C7A8: 7EEC0348
	v_mov_b32_e32 v117, v72                                    // 00000014C7AC: 7EEA0348
	v_mov_b32_e32 v116, v72                                    // 00000014C7B0: 7EE80348
	v_mov_b32_e32 v115, v72                                    // 00000014C7B4: 7EE60348
	v_mov_b32_e32 v114, v72                                    // 00000014C7B8: 7EE40348
	v_mov_b32_e32 v113, v72                                    // 00000014C7BC: 7EE20348
	v_mov_b32_e32 v128, v72                                    // 00000014C7C0: 7F000348
	v_mov_b32_e32 v127, v72                                    // 00000014C7C4: 7EFE0348
	v_mov_b32_e32 v126, v72                                    // 00000014C7C8: 7EFC0348
	v_mov_b32_e32 v125, v72                                    // 00000014C7CC: 7EFA0348
	v_mov_b32_e32 v124, v72                                    // 00000014C7D0: 7EF80348
	v_mov_b32_e32 v123, v72                                    // 00000014C7D4: 7EF60348
	v_mov_b32_e32 v122, v72                                    // 00000014C7D8: 7EF40348
	v_mov_b32_e32 v121, v72                                    // 00000014C7DC: 7EF20348
	v_mov_b32_e32 v64, v72                                     // 00000014C7E0: 7E800348
	v_mov_b32_e32 v63, v72                                     // 00000014C7E4: 7E7E0348
	v_mov_b32_e32 v62, v72                                     // 00000014C7E8: 7E7C0348
	v_mov_b32_e32 v61, v72                                     // 00000014C7EC: 7E7A0348
	v_mov_b32_e32 v60, v72                                     // 00000014C7F0: 7E780348
	v_mov_b32_e32 v59, v72                                     // 00000014C7F4: 7E760348
	v_mov_b32_e32 v58, v72                                     // 00000014C7F8: 7E740348
	v_mov_b32_e32 v57, v72                                     // 00000014C7FC: 7E720348
	v_mov_b32_e32 v56, v72                                     // 00000014C800: 7E700348
	v_mov_b32_e32 v55, v72                                     // 00000014C804: 7E6E0348
	v_mov_b32_e32 v54, v72                                     // 00000014C808: 7E6C0348
	v_mov_b32_e32 v53, v72                                     // 00000014C80C: 7E6A0348
	v_mov_b32_e32 v52, v72                                     // 00000014C810: 7E680348
	v_mov_b32_e32 v51, v72                                     // 00000014C814: 7E660348
	v_mov_b32_e32 v50, v72                                     // 00000014C818: 7E640348
	v_mov_b32_e32 v49, v72                                     // 00000014C81C: 7E620348
	v_mov_b32_e32 v48, v72                                     // 00000014C820: 7E600348
	v_mov_b32_e32 v47, v72                                     // 00000014C824: 7E5E0348
	v_mov_b32_e32 v46, v72                                     // 00000014C828: 7E5C0348
	v_mov_b32_e32 v45, v72                                     // 00000014C82C: 7E5A0348
	v_mov_b32_e32 v44, v72                                     // 00000014C830: 7E580348
	v_mov_b32_e32 v43, v72                                     // 00000014C834: 7E560348
	v_mov_b32_e32 v42, v72                                     // 00000014C838: 7E540348
	v_mov_b32_e32 v41, v72                                     // 00000014C83C: 7E520348
	v_mov_b32_e32 v40, v72                                     // 00000014C840: 7E500348
	v_mov_b32_e32 v39, v72                                     // 00000014C844: 7E4E0348
	v_mov_b32_e32 v38, v72                                     // 00000014C848: 7E4C0348
	v_mov_b32_e32 v37, v72                                     // 00000014C84C: 7E4A0348
	v_mov_b32_e32 v36, v72                                     // 00000014C850: 7E480348
	v_mov_b32_e32 v35, v72                                     // 00000014C854: 7E460348
	v_mov_b32_e32 v34, v72                                     // 00000014C858: 7E440348
	v_mov_b32_e32 v33, v72                                     // 00000014C85C: 7E420348
	v_mov_b32_e32 v32, v72                                     // 00000014C860: 7E400348
	v_mov_b32_e32 v31, v72                                     // 00000014C864: 7E3E0348
	v_mov_b32_e32 v30, v72                                     // 00000014C868: 7E3C0348
	v_mov_b32_e32 v29, v72                                     // 00000014C86C: 7E3A0348
	v_mov_b32_e32 v28, v72                                     // 00000014C870: 7E380348
	v_mov_b32_e32 v27, v72                                     // 00000014C874: 7E360348
	v_mov_b32_e32 v26, v72                                     // 00000014C878: 7E340348
	v_mov_b32_e32 v25, v72                                     // 00000014C87C: 7E320348
	v_mov_b32_e32 v24, v72                                     // 00000014C880: 7E300348
	v_mov_b32_e32 v23, v72                                     // 00000014C884: 7E2E0348
	v_mov_b32_e32 v22, v72                                     // 00000014C888: 7E2C0348
	v_mov_b32_e32 v21, v72                                     // 00000014C88C: 7E2A0348
	v_mov_b32_e32 v20, v72                                     // 00000014C890: 7E280348
	v_mov_b32_e32 v19, v72                                     // 00000014C894: 7E260348
	v_mov_b32_e32 v18, v72                                     // 00000014C898: 7E240348
	v_mov_b32_e32 v17, v72                                     // 00000014C89C: 7E220348
	v_mov_b32_e32 v16, v72                                     // 00000014C8A0: 7E200348
	v_mov_b32_e32 v15, v72                                     // 00000014C8A4: 7E1E0348
	v_mov_b32_e32 v14, v72                                     // 00000014C8A8: 7E1C0348
	v_mov_b32_e32 v13, v72                                     // 00000014C8AC: 7E1A0348
	v_mov_b32_e32 v12, v72                                     // 00000014C8B0: 7E180348
	v_mov_b32_e32 v11, v72                                     // 00000014C8B4: 7E160348
	v_mov_b32_e32 v10, v72                                     // 00000014C8B8: 7E140348
	v_mov_b32_e32 v9, v72                                      // 00000014C8BC: 7E120348
	v_mov_b32_e32 v8, v72                                      // 00000014C8C0: 7E100348
	v_mov_b32_e32 v7, v72                                      // 00000014C8C4: 7E0E0348
	v_mov_b32_e32 v6, v72                                      // 00000014C8C8: 7E0C0348
	v_mov_b32_e32 v5, v72                                      // 00000014C8CC: 7E0A0348
	v_mov_b32_e32 v4, v72                                      // 00000014C8D0: 7E080348
	v_mov_b32_e32 v3, v72                                      // 00000014C8D4: 7E060348
	v_mov_b32_e32 v2, v72                                      // 00000014C8D8: 7E040348
	v_mov_b32_e32 v1, v72                                      // 00000014C8DC: 7E020348
	s_cbranch_scc1 2227                                        // 00000014C8E0: BFA208B3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x26b0>
	v_mad_i64_i32 v[1:2], null, 0x3000, v129, s[4:5]           // 00000014C8E4: D6FF7C01 001302FF 00003000
	s_ashr_i32 s1, s0, 31                                      // 00000014C8F0: 86019F00
	v_lshlrev_b32_e32 v4, 2, v131                              // 00000014C8F4: 30090682
	s_lshr_b32 s1, s1, 28                                      // 00000014C8F8: 85019C01
	v_add3_u32 v154, v149, v131, s26                           // 00000014C8FC: D655009A 006B0795
	s_add_i32 s0, s0, s1                                       // 00000014C904: 81000100
	s_movk_i32 s1, 0x440                                       // 00000014C908: B0010440
	s_ashr_i32 s2, s0, 4                                       // 00000014C90C: 86028400
	.long 0xd7006a8f                                           // 00000014C910: D7006A8F
	v_cndmask_b32_e32 v1, v1, v139, vcc_lo                     // 00000014C914: 02031701
	v_add3_u32 v1, v129, s26, 1                                // 00000014C918: D6550001 02043581
	v_add_co_ci_u32_e64 v144, null, v2, v140, vcc_lo           // 00000014C920: D5207C90 01AB1902
	v_mad_u32_u24 v3, v148, s1, 0x3000                         // 00000014C928: D60B0003 03FC0394 00003000
	v_mov_b32_e32 v129, 0                                      // 00000014C934: 7F020280
	s_delay_alu instid0(VALU_DEP_4)                            // 00000014C938: BF870004
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000014C93C: 3404029F
	v_add_nc_u32_e32 v6, 0xed00, v132                          // 00000014C940: 4A0D08FF 0000ED00
	.long 0xd44c0000                                           // 00000014C948: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 00000014C94C: 020200FF 00000200
	v_mad_u32_u24 v5, 0x44, v150, v3                           // 00000014C954: D60B0005 040F2CFF 00000044
	v_mad_u32_u24 v156, 0x44, v131, v3                         // 00000014C960: D60B009C 040F06FF 00000044
	v_lshrrev_b32_e32 v2, 30, v2                               // 00000014C96C: 3204049E
	v_dual_mov_b32 v8, v129 :: v_dual_lshlrev_b32 v3, 4, v0    // 00000014C970: CA220181 08020084
	v_mov_b32_e32 v9, 0                                        // 00000014C978: 7E120280
	s_cmp_eq_u64 s[20:21], 0                                   // 00000014C97C: BF108014
	s_delay_alu instid0(VALU_DEP_3)                            // 00000014C980: BF870003
	v_add_nc_u32_e32 v1, v1, v2                                // 00000014C984: 4A020501
	v_add_nc_u32_e32 v2, v132, v4                              // 00000014C988: 4A040984
	v_and_b32_e32 v130, 0x1f0, v3                              // 00000014C98C: 370406FF 000001F0
	v_mul_u32_u24_e32 v3, 0x210, v148                          // 00000014C994: 160728FF 00000210
	s_cselect_b32 s4, -1, 0                                    // 00000014C99C: 980480C1
	v_ashrrev_i32_e32 v153, 2, v1                              // 00000014C9A0: 35320282
	v_lshrrev_b32_e32 v1, 1, v0                                // 00000014C9A4: 32020081
	v_add_nc_u32_e32 v155, 0xe700, v2                          // 00000014C9A8: 4B3604FF 0000E700
	v_add_nc_u32_e32 v0, 0xf300, v2                            // 00000014C9B0: 4A0004FF 0000F300
	v_add3_u32 v161, v3, v130, 0xc600                          // 00000014C9B8: D65500A1 03FF0503 0000C600
	v_mov_b32_e32 v3, v129                                     // 00000014C9C4: 7E060381
	v_and_b32_e32 v1, 0xf8, v1                                 // 00000014C9C8: 360202FF 000000F8
	v_dual_mov_b32 v7, v129 :: v_dual_add_nc_u32 v158, v6, v4  // 00000014C9D0: CA200181 079E0906
	v_lshl_or_b32 v159, v150, 2, v6                            // 00000014C9D8: D656009F 04190596
	v_mov_b32_e32 v6, v129                                     // 00000014C9E0: 7E0C0381
	s_delay_alu instid0(VALU_DEP_4)                            // 00000014C9E4: BF870004
	v_mul_u32_u24_e32 v2, 48, v1                               // 00000014C9E8: 160402B0
	s_cmp_lg_u64 s[20:21], 0                                   // 00000014C9EC: BF118014
	v_lshl_add_u32 v152, v147, 2, v5                           // 00000014C9F0: D6460098 04150593
	v_lshlrev_b32_e32 v5, 9, v148                              // 00000014C9F8: 300B2889
	s_cselect_b32 s5, -1, 0                                    // 00000014C9FC: 980580C1
	v_lshl_or_b32 v2, v147, 1, v2                              // 00000014CA00: D6560002 04090393
	s_ashr_i32 s25, s24, 31                                    // 00000014CA08: 86199F18
	s_add_i32 s12, s15, -1                                     // 00000014CA0C: 810CC10F
	s_lshl_b64 s[24:25], s[24:25], 9                           // 00000014CA10: 84988918
	v_mov_b32_e32 v10, v129                                    // 00000014CA14: 7E140381
	v_dual_mov_b32 v11, v129 :: v_dual_add_nc_u32 v162, 0x9600, v2// 00000014CA18: CA200181 0BA204FF 00009600
	v_mov_b32_e32 v2, v129                                     // 00000014CA24: 7E040381
	v_lshl_add_u32 v157, v131, 5, v5                           // 00000014CA28: D646009D 04150B83
	v_lshlrev_b32_e32 v131, 1, v1                              // 00000014CA30: 31060281
	s_add_u32 s6, s6, s24                                      // 00000014CA34: 80061806
	s_addc_u32 s1, s7, s25                                     // 00000014CA38: 82011907
	s_add_u32 s7, s8, s24                                      // 00000014CA3C: 80071808
	.long 0xd70006a5                                           // 00000014CA40: D70006A5
	v_cndmask_b32_e32 v1, s6, v130, vcc_lo                     // 00000014CA44: 02030406
	s_addc_u32 s8, s9, s25                                     // 00000014CA48: 82081909
	s_movk_i32 s9, 0x210                                       // 00000014CA4C: B0090210
	v_add_co_ci_u32_e64 v166, null, s1, 0, s6                  // 00000014CA50: D5207CA6 00190001
	.long 0xd70001a7                                           // 00000014CA58: D70001A7
	v_cndmask_b32_e32 v1, s7, v131, vcc_lo                     // 00000014CA5C: 02030607
	v_lshl_or_b32 v160, v147, 5, v5                            // 00000014CA60: D65600A0 04150B93
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v4, v129            // 00000014CA68: CA100080 01040181
	v_mov_b32_e32 v5, v129                                     // 00000014CA70: 7E0A0381
	v_dual_mov_b32 v12, v129 :: v_dual_mov_b32 v17, 0          // 00000014CA74: CA100181 0C100080
	v_mov_b32_e32 v13, v129                                    // 00000014CA7C: 7E1A0381
	v_dual_mov_b32 v14, v129 :: v_dual_mov_b32 v25, 0          // 00000014CA80: CA100181 0E180080
	v_mov_b32_e32 v15, v129                                    // 00000014CA88: 7E1E0381
	v_dual_mov_b32 v16, v129 :: v_dual_mov_b32 v33, 0          // 00000014CA8C: CA100181 10200080
	v_dual_mov_b32 v18, v129 :: v_dual_mov_b32 v41, 0          // 00000014CA94: CA100181 12280080
	v_mov_b32_e32 v19, v129                                    // 00000014CA9C: 7E260381
	v_dual_mov_b32 v20, v129 :: v_dual_mov_b32 v49, 0          // 00000014CAA0: CA100181 14300080
	v_mov_b32_e32 v21, v129                                    // 00000014CAA8: 7E2A0381
	v_dual_mov_b32 v22, v129 :: v_dual_mov_b32 v57, 0          // 00000014CAAC: CA100181 16380080
	v_mov_b32_e32 v23, v129                                    // 00000014CAB4: 7E2E0381
	v_dual_mov_b32 v24, v129 :: v_dual_mov_b32 v121, 0         // 00000014CAB8: CA100181 18780080
	v_dual_mov_b32 v26, v129 :: v_dual_mov_b32 v113, 0         // 00000014CAC0: CA100181 1A700080
	v_mov_b32_e32 v27, v129                                    // 00000014CAC8: 7E360381
	v_dual_mov_b32 v28, v129 :: v_dual_mov_b32 v105, 0         // 00000014CACC: CA100181 1C680080
	v_mov_b32_e32 v29, v129                                    // 00000014CAD4: 7E3A0381
	v_dual_mov_b32 v30, v129 :: v_dual_mov_b32 v97, 0          // 00000014CAD8: CA100181 1E600080
	v_mov_b32_e32 v31, v129                                    // 00000014CAE0: 7E3E0381
	v_dual_mov_b32 v32, v129 :: v_dual_mov_b32 v89, 0          // 00000014CAE4: CA100181 20580080
	v_dual_mov_b32 v34, v129 :: v_dual_mov_b32 v81, 0          // 00000014CAEC: CA100181 22500080
	v_mov_b32_e32 v35, v129                                    // 00000014CAF4: 7E460381
	v_dual_mov_b32 v36, v129 :: v_dual_mov_b32 v73, 0          // 00000014CAF8: CA100181 24480080
	v_mov_b32_e32 v37, v129                                    // 00000014CB00: 7E4A0381
	v_dual_mov_b32 v38, v129 :: v_dual_mov_b32 v65, 0          // 00000014CB04: CA100181 26400080
	v_mov_b32_e32 v39, v129                                    // 00000014CB0C: 7E4E0381
	v_dual_mov_b32 v40, v129 :: v_dual_mov_b32 v145, 0         // 00000014CB10: CA100181 28900080
	v_mov_b32_e32 v42, v129                                    // 00000014CB18: 7E540381
	v_mov_b32_e32 v43, v129                                    // 00000014CB1C: 7E560381
	v_mov_b32_e32 v44, v129                                    // 00000014CB20: 7E580381
	v_mov_b32_e32 v45, v129                                    // 00000014CB24: 7E5A0381
	v_mov_b32_e32 v46, v129                                    // 00000014CB28: 7E5C0381
	v_mov_b32_e32 v47, v129                                    // 00000014CB2C: 7E5E0381
	v_mov_b32_e32 v48, v129                                    // 00000014CB30: 7E600381
	v_mov_b32_e32 v50, v129                                    // 00000014CB34: 7E640381
	v_mov_b32_e32 v51, v129                                    // 00000014CB38: 7E660381
	v_mov_b32_e32 v52, v129                                    // 00000014CB3C: 7E680381
	v_mov_b32_e32 v53, v129                                    // 00000014CB40: 7E6A0381
	v_mov_b32_e32 v54, v129                                    // 00000014CB44: 7E6C0381
	v_mov_b32_e32 v55, v129                                    // 00000014CB48: 7E6E0381
	v_mov_b32_e32 v56, v129                                    // 00000014CB4C: 7E700381
	v_mov_b32_e32 v58, v129                                    // 00000014CB50: 7E740381
	v_mov_b32_e32 v59, v129                                    // 00000014CB54: 7E760381
	v_mov_b32_e32 v60, v129                                    // 00000014CB58: 7E780381
	v_mov_b32_e32 v61, v129                                    // 00000014CB5C: 7E7A0381
	v_mov_b32_e32 v62, v129                                    // 00000014CB60: 7E7C0381
	v_mov_b32_e32 v63, v129                                    // 00000014CB64: 7E7E0381
	v_mov_b32_e32 v64, v129                                    // 00000014CB68: 7E800381
	v_mov_b32_e32 v122, v129                                   // 00000014CB6C: 7EF40381
	v_mov_b32_e32 v123, v129                                   // 00000014CB70: 7EF60381
	v_mov_b32_e32 v124, v129                                   // 00000014CB74: 7EF80381
	v_mov_b32_e32 v125, v129                                   // 00000014CB78: 7EFA0381
	v_mov_b32_e32 v126, v129                                   // 00000014CB7C: 7EFC0381
	v_mov_b32_e32 v127, v129                                   // 00000014CB80: 7EFE0381
	v_mov_b32_e32 v128, v129                                   // 00000014CB84: 7F000381
	v_mov_b32_e32 v114, v129                                   // 00000014CB88: 7EE40381
	v_mov_b32_e32 v115, v129                                   // 00000014CB8C: 7EE60381
	v_mov_b32_e32 v116, v129                                   // 00000014CB90: 7EE80381
	v_mov_b32_e32 v117, v129                                   // 00000014CB94: 7EEA0381
	v_mov_b32_e32 v118, v129                                   // 00000014CB98: 7EEC0381
	v_mov_b32_e32 v119, v129                                   // 00000014CB9C: 7EEE0381
	v_mov_b32_e32 v120, v129                                   // 00000014CBA0: 7EF00381
	v_mov_b32_e32 v106, v129                                   // 00000014CBA4: 7ED40381
	v_mov_b32_e32 v107, v129                                   // 00000014CBA8: 7ED60381
	v_mov_b32_e32 v108, v129                                   // 00000014CBAC: 7ED80381
	v_mov_b32_e32 v109, v129                                   // 00000014CBB0: 7EDA0381
	v_mov_b32_e32 v110, v129                                   // 00000014CBB4: 7EDC0381
	v_mov_b32_e32 v111, v129                                   // 00000014CBB8: 7EDE0381
	v_mov_b32_e32 v112, v129                                   // 00000014CBBC: 7EE00381
	v_mov_b32_e32 v98, v129                                    // 00000014CBC0: 7EC40381
	v_mov_b32_e32 v99, v129                                    // 00000014CBC4: 7EC60381
	v_mov_b32_e32 v100, v129                                   // 00000014CBC8: 7EC80381
	v_mov_b32_e32 v101, v129                                   // 00000014CBCC: 7ECA0381
	v_mov_b32_e32 v102, v129                                   // 00000014CBD0: 7ECC0381
	v_mov_b32_e32 v103, v129                                   // 00000014CBD4: 7ECE0381
	v_mov_b32_e32 v104, v129                                   // 00000014CBD8: 7ED00381
	v_mov_b32_e32 v90, v129                                    // 00000014CBDC: 7EB40381
	v_mov_b32_e32 v91, v129                                    // 00000014CBE0: 7EB60381
	v_mov_b32_e32 v92, v129                                    // 00000014CBE4: 7EB80381
	v_mov_b32_e32 v93, v129                                    // 00000014CBE8: 7EBA0381
	v_mov_b32_e32 v94, v129                                    // 00000014CBEC: 7EBC0381
	v_mov_b32_e32 v95, v129                                    // 00000014CBF0: 7EBE0381
	v_mov_b32_e32 v96, v129                                    // 00000014CBF4: 7EC00381
	v_mov_b32_e32 v82, v129                                    // 00000014CBF8: 7EA40381
	v_mov_b32_e32 v83, v129                                    // 00000014CBFC: 7EA60381
	v_mov_b32_e32 v84, v129                                    // 00000014CC00: 7EA80381
	v_mov_b32_e32 v85, v129                                    // 00000014CC04: 7EAA0381
	v_mov_b32_e32 v86, v129                                    // 00000014CC08: 7EAC0381
	v_mov_b32_e32 v87, v129                                    // 00000014CC0C: 7EAE0381
	v_mov_b32_e32 v88, v129                                    // 00000014CC10: 7EB00381
	v_mov_b32_e32 v74, v129                                    // 00000014CC14: 7E940381
	v_mov_b32_e32 v75, v129                                    // 00000014CC18: 7E960381
	v_mov_b32_e32 v76, v129                                    // 00000014CC1C: 7E980381
	v_mov_b32_e32 v77, v129                                    // 00000014CC20: 7E9A0381
	v_mov_b32_e32 v78, v129                                    // 00000014CC24: 7E9C0381
	v_mov_b32_e32 v79, v129                                    // 00000014CC28: 7E9E0381
	v_mov_b32_e32 v80, v129                                    // 00000014CC2C: 7EA00381
	v_mov_b32_e32 v66, v129                                    // 00000014CC30: 7E840381
	v_mov_b32_e32 v67, v129                                    // 00000014CC34: 7E860381
	v_mov_b32_e32 v68, v129                                    // 00000014CC38: 7E880381
	v_mov_b32_e32 v69, v129                                    // 00000014CC3C: 7E8A0381
	v_mov_b32_e32 v70, v129                                    // 00000014CC40: 7E8C0381
	v_mov_b32_e32 v71, v129                                    // 00000014CC44: 7E8E0381
	v_mov_b32_e32 v72, v129                                    // 00000014CC48: 7E900381
	v_mad_u32_u24 v163, v147, s9, 0xc600                       // 00000014CC4C: D60B00A3 03FC1393 0000C600
	v_mad_u32_u24 v164, v147, 48, 0x9600                       // 00000014CC58: D60B00A4 03FD6193 00009600
	v_add_co_ci_u32_e64 v168, null, s8, 0, s1                  // 00000014CC64: D5207CA8 00050008
	s_mov_b32 s6, 0                                            // 00000014CC6C: BE860080
	s_branch 298                                               // 00000014CC70: BFA0012A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc1c>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014CC74: 8C7E017E
	v_add_f32_e32 v131, v133, v132                             // 00000014CC78: 07070985
	ds_load_b32 v132, v0                                       // 00000014CC7C: D8D80000 84000000
	v_add_f32_e32 v131, v131, v135                             // 00000014CC84: 07070F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014CC88: BF870091
	v_add_f32_e32 v131, v131, v134                             // 00000014CC8C: 07070D83
	v_add_f32_e32 v131, v131, v137                             // 00000014CC90: 07071383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014CC94: BF870091
	v_add_f32_e32 v131, v131, v136                             // 00000014CC98: 07071183
	v_add_f32_e32 v131, v131, v169                             // 00000014CC9C: 07075383
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014CCA0: BF870091
	v_add_f32_e32 v131, v131, v146                             // 00000014CCA4: 07072583
	v_add_f32_e32 v131, v131, v171                             // 00000014CCA8: 07075783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014CCAC: BF870091
	v_add_f32_e32 v131, v131, v170                             // 00000014CCB0: 07075583
	v_add_f32_e32 v131, v131, v173                             // 00000014CCB4: 07075B83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014CCB8: BF870091
	v_add_f32_e32 v131, v131, v172                             // 00000014CCBC: 07075983
	v_add_f32_e32 v131, v131, v175                             // 00000014CCC0: 07075F83
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014CCC4: BF870091
	v_add_f32_e32 v131, v131, v174                             // 00000014CCC8: 07075D83
	v_add_f32_e32 v131, v131, v177                             // 00000014CCCC: 07076383
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000014CCD0: BF8700A1
	v_add_f32_e32 v131, v131, v176                             // 00000014CCD4: 07076183
	s_waitcnt lgkmcnt(0)                                       // 00000014CCD8: BF89FC07
	v_fmac_f32_e32 v131, v178, v132                            // 00000014CCDC: 570709B2
	ds_store_b32 v155, v130                                    // 00000014CCE0: D8340000 0000829B
	ds_store_b32 v0, v131                                      // 00000014CCE8: D8340000 00008300
	ds_store_b32 v158, v178                                    // 00000014CCF0: D8340000 0000B29E
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014CCF8: 8C7E087E
	s_waitcnt lgkmcnt(0)                                       // 00000014CCFC: BF89FC07
	s_barrier                                                  // 00000014CD00: BFBD0000
	buffer_gl0_inv                                             // 00000014CD04: E0AC0000 00000000
	ds_load_2addr_b32 v[169:170], v159 offset1:2               // 00000014CD0C: D8DC0200 A900009F
	ds_load_2addr_b32 v[171:172], v159 offset0:4 offset1:6     // 00000014CD14: D8DC0604 AB00009F
	ds_load_2addr_b32 v[173:174], v159 offset0:8 offset1:10    // 00000014CD1C: D8DC0A08 AD00009F
	ds_load_2addr_b32 v[175:176], v159 offset0:12 offset1:14   // 00000014CD24: D8DC0E0C AF00009F
	ds_load_b128 v[130:133], v160                              // 00000014CD2C: DBFC0000 820000A0
	ds_load_b128 v[134:137], v160 offset:16                    // 00000014CD34: DBFC0010 860000A0
	s_waitcnt lgkmcnt(5)                                       // 00000014CD3C: BF89FC57
	v_dual_mul_f32 v121, v169, v121 :: v_dual_mul_f32 v122, v170, v122// 00000014CD40: C8C6F3A9 797AF5AA
	s_waitcnt lgkmcnt(4)                                       // 00000014CD48: BF89FC47
	v_dual_mul_f32 v123, v171, v123 :: v_dual_mul_f32 v124, v172, v124// 00000014CD4C: C8C6F7AB 7B7CF9AC
	s_waitcnt lgkmcnt(3)                                       // 00000014CD54: BF89FC37
	v_dual_mul_f32 v125, v173, v125 :: v_dual_mul_f32 v126, v174, v126// 00000014CD58: C8C6FBAD 7D7EFDAE
	s_waitcnt lgkmcnt(2)                                       // 00000014CD60: BF89FC27
	v_dual_mul_f32 v127, v175, v127 :: v_dual_mul_f32 v128, v176, v128// 00000014CD64: C8C6FFAF 7F8101B0
	v_dual_mul_f32 v113, v169, v113 :: v_dual_mul_f32 v114, v170, v114// 00000014CD6C: C8C6E3A9 7172E5AA
	v_dual_mul_f32 v115, v171, v115 :: v_dual_mul_f32 v116, v172, v116// 00000014CD74: C8C6E7AB 7374E9AC
	v_dual_mul_f32 v117, v173, v117 :: v_dual_mul_f32 v118, v174, v118// 00000014CD7C: C8C6EBAD 7576EDAE
	v_dual_mul_f32 v119, v175, v119 :: v_dual_mul_f32 v120, v176, v120// 00000014CD84: C8C6EFAF 7778F1B0
	v_dual_mul_f32 v105, v169, v105 :: v_dual_mul_f32 v106, v170, v106// 00000014CD8C: C8C6D3A9 696AD5AA
	v_dual_mul_f32 v107, v171, v107 :: v_dual_mul_f32 v108, v172, v108// 00000014CD94: C8C6D7AB 6B6CD9AC
	v_dual_mul_f32 v109, v173, v109 :: v_dual_mul_f32 v110, v174, v110// 00000014CD9C: C8C6DBAD 6D6EDDAE
	v_dual_mul_f32 v111, v175, v111 :: v_dual_mul_f32 v112, v176, v112// 00000014CDA4: C8C6DFAF 6F70E1B0
	v_dual_mul_f32 v97, v169, v97 :: v_dual_mul_f32 v98, v170, v98// 00000014CDAC: C8C6C3A9 6162C5AA
	v_dual_mul_f32 v99, v171, v99 :: v_dual_mul_f32 v100, v172, v100// 00000014CDB4: C8C6C7AB 6364C9AC
	v_dual_mul_f32 v101, v173, v101 :: v_dual_mul_f32 v102, v174, v102// 00000014CDBC: C8C6CBAD 6566CDAE
	v_dual_mul_f32 v103, v175, v103 :: v_dual_mul_f32 v104, v176, v104// 00000014CDC4: C8C6CFAF 6768D1B0
	v_dual_mul_f32 v89, v169, v89 :: v_dual_mul_f32 v90, v170, v90// 00000014CDCC: C8C6B3A9 595AB5AA
	v_dual_mul_f32 v91, v171, v91 :: v_dual_mul_f32 v92, v172, v92// 00000014CDD4: C8C6B7AB 5B5CB9AC
	v_dual_mul_f32 v93, v173, v93 :: v_dual_mul_f32 v94, v174, v94// 00000014CDDC: C8C6BBAD 5D5EBDAE
	v_dual_mul_f32 v95, v175, v95 :: v_dual_mul_f32 v96, v176, v96// 00000014CDE4: C8C6BFAF 5F60C1B0
	v_dual_mul_f32 v81, v169, v81 :: v_dual_mul_f32 v82, v170, v82// 00000014CDEC: C8C6A3A9 5152A5AA
	v_dual_mul_f32 v83, v171, v83 :: v_dual_mul_f32 v84, v172, v84// 00000014CDF4: C8C6A7AB 5354A9AC
	v_dual_mul_f32 v85, v173, v85 :: v_dual_mul_f32 v86, v174, v86// 00000014CDFC: C8C6ABAD 5556ADAE
	v_dual_mul_f32 v87, v175, v87 :: v_dual_mul_f32 v88, v176, v88// 00000014CE04: C8C6AFAF 5758B1B0
	v_dual_mul_f32 v73, v169, v73 :: v_dual_mul_f32 v74, v170, v74// 00000014CE0C: C8C693A9 494A95AA
	v_dual_mul_f32 v75, v171, v75 :: v_dual_mul_f32 v76, v172, v76// 00000014CE14: C8C697AB 4B4C99AC
	v_dual_mul_f32 v77, v173, v77 :: v_dual_mul_f32 v78, v174, v78// 00000014CE1C: C8C69BAD 4D4E9DAE
	v_dual_mul_f32 v79, v175, v79 :: v_dual_mul_f32 v80, v176, v80// 00000014CE24: C8C69FAF 4F50A1B0
	v_dual_mul_f32 v65, v169, v65 :: v_dual_mul_f32 v66, v170, v66// 00000014CE2C: C8C683A9 414285AA
	v_dual_mul_f32 v67, v171, v67 :: v_dual_mul_f32 v68, v172, v68// 00000014CE34: C8C687AB 434489AC
	v_dual_mul_f32 v69, v173, v69 :: v_dual_mul_f32 v70, v174, v70// 00000014CE3C: C8C68BAD 45468DAE
	v_dual_mul_f32 v71, v175, v71 :: v_dual_mul_f32 v72, v176, v72// 00000014CE44: C8C68FAF 474891B0
	v_dual_mul_f32 v57, v169, v57 :: v_dual_mul_f32 v58, v170, v58// 00000014CE4C: C8C673A9 393A75AA
	v_dual_mul_f32 v59, v171, v59 :: v_dual_mul_f32 v60, v172, v60// 00000014CE54: C8C677AB 3B3C79AC
	v_dual_mul_f32 v61, v173, v61 :: v_dual_mul_f32 v62, v174, v62// 00000014CE5C: C8C67BAD 3D3E7DAE
	v_dual_mul_f32 v63, v175, v63 :: v_dual_mul_f32 v64, v176, v64// 00000014CE64: C8C67FAF 3F4081B0
	v_dual_mul_f32 v49, v169, v49 :: v_dual_mul_f32 v50, v170, v50// 00000014CE6C: C8C663A9 313265AA
	v_dual_mul_f32 v51, v171, v51 :: v_dual_mul_f32 v52, v172, v52// 00000014CE74: C8C667AB 333469AC
	v_dual_mul_f32 v53, v173, v53 :: v_dual_mul_f32 v54, v174, v54// 00000014CE7C: C8C66BAD 35366DAE
	v_dual_mul_f32 v55, v175, v55 :: v_dual_mul_f32 v56, v176, v56// 00000014CE84: C8C66FAF 373871B0
	v_dual_mul_f32 v41, v169, v41 :: v_dual_mul_f32 v42, v170, v42// 00000014CE8C: C8C653A9 292A55AA
	v_dual_mul_f32 v43, v171, v43 :: v_dual_mul_f32 v44, v172, v44// 00000014CE94: C8C657AB 2B2C59AC
	v_dual_mul_f32 v45, v173, v45 :: v_dual_mul_f32 v46, v174, v46// 00000014CE9C: C8C65BAD 2D2E5DAE
	v_dual_mul_f32 v47, v175, v47 :: v_dual_mul_f32 v48, v176, v48// 00000014CEA4: C8C65FAF 2F3061B0
	v_dual_mul_f32 v33, v169, v33 :: v_dual_mul_f32 v34, v170, v34// 00000014CEAC: C8C643A9 212245AA
	v_dual_mul_f32 v35, v171, v35 :: v_dual_mul_f32 v36, v172, v36// 00000014CEB4: C8C647AB 232449AC
	v_dual_mul_f32 v37, v173, v37 :: v_dual_mul_f32 v38, v174, v38// 00000014CEBC: C8C64BAD 25264DAE
	v_dual_mul_f32 v39, v175, v39 :: v_dual_mul_f32 v40, v176, v40// 00000014CEC4: C8C64FAF 272851B0
	v_dual_mul_f32 v25, v169, v25 :: v_dual_mul_f32 v26, v170, v26// 00000014CECC: C8C633A9 191A35AA
	v_dual_mul_f32 v27, v171, v27 :: v_dual_mul_f32 v28, v172, v28// 00000014CED4: C8C637AB 1B1C39AC
	v_dual_mul_f32 v29, v173, v29 :: v_dual_mul_f32 v30, v174, v30// 00000014CEDC: C8C63BAD 1D1E3DAE
	v_dual_mul_f32 v31, v175, v31 :: v_dual_mul_f32 v32, v176, v32// 00000014CEE4: C8C63FAF 1F2041B0
	v_dual_mul_f32 v17, v169, v17 :: v_dual_mul_f32 v18, v170, v18// 00000014CEEC: C8C623A9 111225AA
	v_dual_mul_f32 v19, v171, v19 :: v_dual_mul_f32 v20, v172, v20// 00000014CEF4: C8C627AB 131429AC
	v_dual_mul_f32 v21, v173, v21 :: v_dual_mul_f32 v22, v174, v22// 00000014CEFC: C8C62BAD 15162DAE
	v_dual_mul_f32 v23, v175, v23 :: v_dual_mul_f32 v24, v176, v24// 00000014CF04: C8C62FAF 171831B0
	v_dual_mul_f32 v9, v169, v9 :: v_dual_mul_f32 v10, v170, v10// 00000014CF0C: C8C613A9 090A15AA
	v_dual_mul_f32 v11, v171, v11 :: v_dual_mul_f32 v12, v172, v12// 00000014CF14: C8C617AB 0B0C19AC
	v_dual_mul_f32 v13, v173, v13 :: v_dual_mul_f32 v14, v174, v14// 00000014CF1C: C8C61BAD 0D0E1DAE
	v_dual_mul_f32 v15, v175, v15 :: v_dual_mul_f32 v16, v176, v16// 00000014CF24: C8C61FAF 0F1021B0
	v_dual_mul_f32 v1, v169, v1 :: v_dual_mul_f32 v2, v170, v2 // 00000014CF2C: C8C603A9 010205AA
	v_dual_mul_f32 v3, v171, v3 :: v_dual_mul_f32 v4, v172, v4 // 00000014CF34: C8C607AB 030409AC
	v_dual_mul_f32 v5, v173, v5 :: v_dual_mul_f32 v6, v174, v6 // 00000014CF3C: C8C60BAD 05060DAE
	v_dual_mul_f32 v7, v175, v7 :: v_dual_mul_f32 v8, v176, v8 // 00000014CF44: C8C60FAF 070811B0
	ds_load_b128 v[169:172], v164                              // 00000014CF4C: DBFC0000 A90000A4
	ds_load_b128 v[173:176], v164 offset:16                    // 00000014CF54: DBFC0010 AD0000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014CF5C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[130:137], v[169:176], v[121:128]// 00000014CF60: CC414079 1DE75382
	ds_load_b128 v[173:176], v164 offset:784                   // 00000014CF68: DBFC0310 AD0000A4
	ds_load_b128 v[169:172], v164 offset:768                   // 00000014CF70: DBFC0300 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014CF78: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[130:137], v[169:176], v[113:120]// 00000014CF7C: CC414071 1DC75382
	ds_load_b128 v[173:176], v164 offset:1552                  // 00000014CF84: DBFC0610 AD0000A4
	ds_load_b128 v[169:172], v164 offset:1536                  // 00000014CF8C: DBFC0600 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014CF94: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[105:112], v[130:137], v[169:176], v[105:112]// 00000014CF98: CC414069 1DA75382
	ds_load_b128 v[173:176], v164 offset:2320                  // 00000014CFA0: DBFC0910 AD0000A4
	ds_load_b128 v[169:172], v164 offset:2304                  // 00000014CFA8: DBFC0900 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014CFB0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[130:137], v[169:176], v[97:104]// 00000014CFB4: CC414061 1D875382
	ds_load_b128 v[173:176], v164 offset:3088                  // 00000014CFBC: DBFC0C10 AD0000A4
	ds_load_b128 v[169:172], v164 offset:3072                  // 00000014CFC4: DBFC0C00 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014CFCC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[130:137], v[169:176], v[89:96]// 00000014CFD0: CC414059 1D675382
	ds_load_b128 v[173:176], v164 offset:3856                  // 00000014CFD8: DBFC0F10 AD0000A4
	ds_load_b128 v[169:172], v164 offset:3840                  // 00000014CFE0: DBFC0F00 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014CFE8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[130:137], v[169:176], v[81:88]// 00000014CFEC: CC414051 1D475382
	ds_load_b128 v[173:176], v164 offset:4624                  // 00000014CFF4: DBFC1210 AD0000A4
	ds_load_b128 v[169:172], v164 offset:4608                  // 00000014CFFC: DBFC1200 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014D004: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[130:137], v[169:176], v[73:80]// 00000014D008: CC414049 1D275382
	ds_load_b128 v[173:176], v164 offset:5392                  // 00000014D010: DBFC1510 AD0000A4
	ds_load_b128 v[169:172], v164 offset:5376                  // 00000014D018: DBFC1500 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014D020: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[130:137], v[169:176], v[65:72]// 00000014D024: CC414041 1D075382
	ds_load_b128 v[173:176], v164 offset:6160                  // 00000014D02C: DBFC1810 AD0000A4
	ds_load_b128 v[169:172], v164 offset:6144                  // 00000014D034: DBFC1800 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014D03C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[130:137], v[169:176], v[57:64]// 00000014D040: CC414039 1CE75382
	ds_load_b128 v[173:176], v164 offset:6928                  // 00000014D048: DBFC1B10 AD0000A4
	ds_load_b128 v[169:172], v164 offset:6912                  // 00000014D050: DBFC1B00 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014D058: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[130:137], v[169:176], v[49:56]// 00000014D05C: CC414031 1CC75382
	ds_load_b128 v[173:176], v164 offset:7696                  // 00000014D064: DBFC1E10 AD0000A4
	ds_load_b128 v[169:172], v164 offset:7680                  // 00000014D06C: DBFC1E00 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014D074: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[130:137], v[169:176], v[41:48]// 00000014D078: CC414029 1CA75382
	ds_load_b128 v[173:176], v164 offset:8464                  // 00000014D080: DBFC2110 AD0000A4
	ds_load_b128 v[169:172], v164 offset:8448                  // 00000014D088: DBFC2100 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014D090: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[130:137], v[169:176], v[33:40]// 00000014D094: CC414021 1C875382
	ds_load_b128 v[173:176], v164 offset:9232                  // 00000014D09C: DBFC2410 AD0000A4
	ds_load_b128 v[169:172], v164 offset:9216                  // 00000014D0A4: DBFC2400 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014D0AC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[169:176], v[25:32]// 00000014D0B0: CC414019 1C675382
	ds_load_b128 v[173:176], v164 offset:10000                 // 00000014D0B8: DBFC2710 AD0000A4
	ds_load_b128 v[169:172], v164 offset:9984                  // 00000014D0C0: DBFC2700 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014D0C8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[130:137], v[169:176], v[17:24]// 00000014D0CC: CC414011 1C475382
	ds_load_b128 v[173:176], v164 offset:10768                 // 00000014D0D4: DBFC2A10 AD0000A4
	ds_load_b128 v[169:172], v164 offset:10752                 // 00000014D0DC: DBFC2A00 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014D0E4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[130:137], v[169:176], v[9:16]// 00000014D0E8: CC414009 1C275382
	ds_load_b128 v[173:176], v164 offset:11536                 // 00000014D0F0: DBFC2D10 AD0000A4
	ds_load_b128 v[169:172], v164 offset:11520                 // 00000014D0F8: DBFC2D00 A90000A4
	s_waitcnt lgkmcnt(0)                                       // 00000014D100: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[130:137], v[169:176], v[1:8]// 00000014D104: CC414001 1C075382
	s_add_i32 s1, s6, 1                                        // 00000014D10C: 81018106
	s_cmp_eq_u32 s6, s2                                        // 00000014D110: BF060206
	s_mov_b32 s6, s1                                           // 00000014D114: BE860001
	s_cbranch_scc1 1701                                        // 00000014D118: BFA206A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x26b0>
	s_and_not1_b32 vcc_lo, exec_lo, s5                         // 00000014D11C: 916A057E
	s_mov_b32 s1, s4                                           // 00000014D120: BE810004
	s_cbranch_vccz 3                                           // 00000014D124: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc34>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000014D128: 916A017E
	s_cbranch_vccnz 65527                                      // 00000014D12C: BFA4FFF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc0c>
	s_branch 15                                                // 00000014D130: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc70>
	s_lshr_b32 s1, s6, 3                                       // 00000014D134: 85018306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000014D138: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 00000014D13C: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v130, s1                                     // 00000014D144: 7F040201
	global_load_b32 v130, v130, s[20:21]                       // 00000014D148: DC520000 82140082
	s_waitcnt vmcnt(0)                                         // 00000014D150: BF8903F7
	v_lshrrev_b32_e32 v130, s6, v130                           // 00000014D154: 33050406
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014D158: BF870091
	v_and_b32_e32 v130, 1, v130                                // 00000014D15C: 37050481
	.long 0xd44a0001                                           // 00000014D160: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000014D164: 02030481
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000014D168: 916A017E
	s_cbranch_vccnz 65511                                      // 00000014D16C: BFA4FFE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc0c>
	s_lshl_b32 s7, s6, 4                                       // 00000014D170: 84078406
	s_waitcnt vmcnt(0)                                         // 00000014D174: BF8903F7
	s_barrier                                                  // 00000014D178: BFBD0000
	buffer_gl0_inv                                             // 00000014D17C: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 00000014D184: BE812000
	s_cbranch_execz 64                                         // 00000014D188: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xd8c>
	v_or_b32_e32 v130, s7, v148                                // 00000014D18C: 39052807
	v_or_b32_e32 v131, s7, v147                                // 00000014D190: 39072607
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014D194: BF870112
	v_min_i32_e32 v130, s12, v130                              // 00000014D198: 2305040C
	v_min_i32_e32 v132, s12, v131                              // 00000014D19C: 2309060C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014D1A0: BF870112
	v_ashrrev_i32_e32 v133, 31, v130                           // 00000014D1A4: 350B049F
	v_ashrrev_i32_e32 v135, 31, v132                           // 00000014D1A8: 350F089F
	.long 0xd72c0086                                           // 00000014D1AC: D72C0086
	v_cndmask_b32_e32 v1, s11, v130, vcc_lo                    // 00000014D1B0: 0203040B
	v_mad_u64_u32 v[130:131], null, s10, v130, 0               // 00000014D1B4: D6FE7C82 0203040A
	.long 0xd72c0089                                           // 00000014D1BC: D72C0089
	v_cndmask_b32_e32 v1, s11, v132, vcc_lo                    // 00000014D1C0: 0203080B
	.long 0xd72c0088                                           // 00000014D1C4: D72C0088
	v_cndmask_b32_e32 v1, s10, v133, vcc_lo                    // 00000014D1C8: 02030A0A
	v_mad_u64_u32 v[132:133], null, s10, v132, 0               // 00000014D1CC: D6FE7C84 0203080A
	.long 0xd72c0087                                           // 00000014D1D4: D72C0087
	v_cndmask_b32_e32 v1, s10, v135, vcc_lo                    // 00000014D1D8: 02030E0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014D1DC: BF870113
	v_add3_u32 v131, v131, v136, v134                          // 00000014D1E0: D6550083 061B1183
	v_add3_u32 v133, v133, v135, v137                          // 00000014D1E8: D6550085 06270F85
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014D1F0: BF870112
	.long 0xd73c0082                                           // 00000014D1F4: D73C0082
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000014D1F8: 02030481
	.long 0xd73c0084                                           // 00000014D1FC: D73C0084
	v_cndmask_b32_e32 v1, 1, v132, vcc_lo                      // 00000014D200: 02030881
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014D204: BF870092
	.long 0xd7006a82                                           // 00000014D208: D7006A82
	v_cndmask_b32_e32 v1, v165, v130, vcc_lo                   // 00000014D20C: 020305A5
	v_add_co_ci_u32_e64 v131, null, v166, v131, vcc_lo         // 00000014D210: D5207C83 01AB07A6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014D218: BF870093
	.long 0xd7006a86                                           // 00000014D21C: D7006A86
	v_cndmask_b32_e32 v1, v167, v132, vcc_lo                   // 00000014D220: 020309A7
	v_add_co_ci_u32_e64 v135, null, v168, v133, vcc_lo         // 00000014D224: D5207C87 01AB0BA8
	global_load_b128 v[130:133], v[130:131], off               // 00000014D22C: DC5E0000 827C0082
	global_load_b128 v[134:137], v[134:135], off               // 00000014D234: DC5E0000 867C0086
	s_waitcnt vmcnt(1)                                         // 00000014D23C: BF8907F7
	ds_store_b128 v161, v[130:133]                             // 00000014D240: DB7C0000 000082A1
	s_waitcnt vmcnt(0)                                         // 00000014D248: BF8903F7
	ds_store_b16 v162, v134                                    // 00000014D24C: D87C0000 000086A2
	ds_store_b16_d16_hi v162, v134 offset:48                   // 00000014D254: DA840030 000086A2
	ds_store_b16 v162, v135 offset:96                          // 00000014D25C: D87C0060 000087A2
	ds_store_b16_d16_hi v162, v135 offset:144                  // 00000014D264: DA840090 000087A2
	ds_store_b16 v162, v136 offset:192                         // 00000014D26C: D87C00C0 000088A2
	ds_store_b16_d16_hi v162, v136 offset:240                  // 00000014D274: DA8400F0 000088A2
	ds_store_b16 v162, v137 offset:288                         // 00000014D27C: D87C0120 000089A2
	ds_store_b16_d16_hi v162, v137 offset:336                  // 00000014D284: DA840150 000089A2
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014D28C: 8C7E017E
	s_waitcnt lgkmcnt(0)                                       // 00000014D290: BF89FC07
	s_barrier                                                  // 00000014D294: BFBD0000
	buffer_gl0_inv                                             // 00000014D298: E0AC0000 00000000
	s_clause 0x1                                               // 00000014D2A0: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:16     // 00000014D2A4: DC5E0010 AD7C008F
	global_load_b128 v[169:172], v[143:144], off               // 00000014D2AC: DC5E0000 A97C008F
	ds_load_b128 v[177:180], v163                              // 00000014D2B4: DBFC0000 B10000A3
	ds_load_b128 v[181:184], v163 offset:16                    // 00000014D2BC: DBFC0010 B50000A3
	v_mov_b32_e32 v136, v129                                   // 00000014D2C4: 7F100381
	v_mov_b32_e32 v130, v129                                   // 00000014D2C8: 7F040381
	v_mov_b32_e32 v131, v129                                   // 00000014D2CC: 7F060381
	v_mov_b32_e32 v132, v129                                   // 00000014D2D0: 7F080381
	v_mov_b32_e32 v133, v129                                   // 00000014D2D4: 7F0A0381
	v_mov_b32_e32 v134, v129                                   // 00000014D2D8: 7F0C0381
	v_mov_b32_e32 v135, v129                                   // 00000014D2DC: 7F0E0381
	v_mov_b32_e32 v137, v136                                   // 00000014D2E0: 7F120388
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000014D2E4: BF870212
	v_mov_b32_e32 v136, v135                                   // 00000014D2E8: 7F100387
	v_mov_b32_e32 v135, v134                                   // 00000014D2EC: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 00000014D2F0: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 00000014D2F4: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 00000014D2F8: 7F080383
	v_mov_b32_e32 v131, v130                                   // 00000014D2FC: 7F060382
	v_mov_b32_e32 v130, v129                                   // 00000014D300: 7F040381
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D304: BF890007
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014D308: BF870001
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D30C: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D314: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:48     // 00000014D318: DC5E0030 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:32     // 00000014D320: DC5E0020 A97C008F
	ds_load_b128 v[177:180], v163 offset:32                    // 00000014D328: DBFC0020 B10000A3
	ds_load_b128 v[181:184], v163 offset:48                    // 00000014D330: DBFC0030 B50000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D338: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D33C: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D344: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:80     // 00000014D348: DC5E0050 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:64     // 00000014D350: DC5E0040 A97C008F
	ds_load_b128 v[181:184], v163 offset:80                    // 00000014D358: DBFC0050 B50000A3
	ds_load_b128 v[177:180], v163 offset:64                    // 00000014D360: DBFC0040 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D368: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D36C: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D374: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:112    // 00000014D378: DC5E0070 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:96     // 00000014D380: DC5E0060 A97C008F
	ds_load_b128 v[181:184], v163 offset:112                   // 00000014D388: DBFC0070 B50000A3
	ds_load_b128 v[177:180], v163 offset:96                    // 00000014D390: DBFC0060 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D398: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D39C: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D3A4: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:144    // 00000014D3A8: DC5E0090 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:128    // 00000014D3B0: DC5E0080 A97C008F
	ds_load_b128 v[181:184], v163 offset:144                   // 00000014D3B8: DBFC0090 B50000A3
	ds_load_b128 v[177:180], v163 offset:128                   // 00000014D3C0: DBFC0080 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D3C8: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D3CC: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D3D4: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:176    // 00000014D3D8: DC5E00B0 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:160    // 00000014D3E0: DC5E00A0 A97C008F
	ds_load_b128 v[181:184], v163 offset:176                   // 00000014D3E8: DBFC00B0 B50000A3
	ds_load_b128 v[177:180], v163 offset:160                   // 00000014D3F0: DBFC00A0 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D3F8: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D3FC: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D404: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:208    // 00000014D408: DC5E00D0 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:192    // 00000014D410: DC5E00C0 A97C008F
	ds_load_b128 v[181:184], v163 offset:208                   // 00000014D418: DBFC00D0 B50000A3
	ds_load_b128 v[177:180], v163 offset:192                   // 00000014D420: DBFC00C0 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D428: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D42C: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D434: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:240    // 00000014D438: DC5E00F0 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:224    // 00000014D440: DC5E00E0 A97C008F
	ds_load_b128 v[181:184], v163 offset:240                   // 00000014D448: DBFC00F0 B50000A3
	ds_load_b128 v[177:180], v163 offset:224                   // 00000014D450: DBFC00E0 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D458: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D45C: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D464: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:272    // 00000014D468: DC5E0110 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:256    // 00000014D470: DC5E0100 A97C008F
	ds_load_b128 v[181:184], v163 offset:272                   // 00000014D478: DBFC0110 B50000A3
	ds_load_b128 v[177:180], v163 offset:256                   // 00000014D480: DBFC0100 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D488: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D48C: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D494: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:304    // 00000014D498: DC5E0130 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:288    // 00000014D4A0: DC5E0120 A97C008F
	ds_load_b128 v[181:184], v163 offset:304                   // 00000014D4A8: DBFC0130 B50000A3
	ds_load_b128 v[177:180], v163 offset:288                   // 00000014D4B0: DBFC0120 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D4B8: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D4BC: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D4C4: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:336    // 00000014D4C8: DC5E0150 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:320    // 00000014D4D0: DC5E0140 A97C008F
	ds_load_b128 v[181:184], v163 offset:336                   // 00000014D4D8: DBFC0150 B50000A3
	ds_load_b128 v[177:180], v163 offset:320                   // 00000014D4E0: DBFC0140 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D4E8: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D4EC: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D4F4: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:368    // 00000014D4F8: DC5E0170 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:352    // 00000014D500: DC5E0160 A97C008F
	ds_load_b128 v[181:184], v163 offset:368                   // 00000014D508: DBFC0170 B50000A3
	ds_load_b128 v[177:180], v163 offset:352                   // 00000014D510: DBFC0160 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D518: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D51C: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D524: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:400    // 00000014D528: DC5E0190 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:384    // 00000014D530: DC5E0180 A97C008F
	ds_load_b128 v[181:184], v163 offset:400                   // 00000014D538: DBFC0190 B50000A3
	ds_load_b128 v[177:180], v163 offset:384                   // 00000014D540: DBFC0180 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D548: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D54C: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D554: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:432    // 00000014D558: DC5E01B0 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:416    // 00000014D560: DC5E01A0 A97C008F
	ds_load_b128 v[181:184], v163 offset:432                   // 00000014D568: DBFC01B0 B50000A3
	ds_load_b128 v[177:180], v163 offset:416                   // 00000014D570: DBFC01A0 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D578: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D57C: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D584: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:464    // 00000014D588: DC5E01D0 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:448    // 00000014D590: DC5E01C0 A97C008F
	ds_load_b128 v[181:184], v163 offset:464                   // 00000014D598: DBFC01D0 B50000A3
	ds_load_b128 v[177:180], v163 offset:448                   // 00000014D5A0: DBFC01C0 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D5A8: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D5AC: CC414082 1E0B63A9
	s_clause 0x1                                               // 00000014D5B4: BF850001
	global_load_b128 v[173:176], v[143:144], off offset:496    // 00000014D5B8: DC5E01F0 AD7C008F
	global_load_b128 v[169:172], v[143:144], off offset:480    // 00000014D5C0: DC5E01E0 A97C008F
	ds_load_b128 v[181:184], v163 offset:496                   // 00000014D5C8: DBFC01F0 B50000A3
	ds_load_b128 v[177:180], v163 offset:480                   // 00000014D5D0: DBFC01E0 B10000A3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000014D5D8: BF890007
	v_wmma_f32_16x16x16_bf16 v[130:137], v[169:176], v[177:184], v[130:137]// 00000014D5DC: CC414082 1E0B63A9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014D5E4: BF870111
	v_dual_mul_f32 v130, 0x3d800000, v130 :: v_dual_mul_f32 v131, 0x3d800000, v131// 00000014D5E8: C8C704FF 828306FF 3D800000
	v_mul_f32_e32 v146, 0x3d800000, v133                       // 00000014D5F4: 11250AFF 3D800000
	v_mov_b32_e32 v133, 0xffff                                 // 00000014D5FC: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 00000014D604: BF870004
	v_mul_f32_e32 v132, 0x3d800000, v132                       // 00000014D608: 110908FF 3D800000
	v_dual_mul_f32 v134, 0x3d800000, v134 :: v_dual_mul_f32 v135, 0x3d800000, v135// 00000014D610: C8C70CFF 86870EFF 3D800000
	v_dual_mul_f32 v136, 0x3d800000, v136 :: v_dual_mul_f32 v137, 0x3d800000, v137// 00000014D61C: C8C710FF 888912FF 3D800000
	ds_store_2addr_b32 v152, v130, v131 offset1:34             // 00000014D628: D8382200 00838298
	ds_store_2addr_b32 v152, v132, v146 offset0:68 offset1:102 // 00000014D630: D8386644 00928498
	ds_store_2addr_b32 v152, v134, v135 offset0:136 offset1:170// 00000014D638: D838AA88 00878698
	ds_store_2addr_b32 v152, v136, v137 offset0:204 offset1:238// 00000014D640: D838EECC 00898898
	s_waitcnt lgkmcnt(0)                                       // 00000014D648: BF89FC07
	s_barrier                                                  // 00000014D64C: BFBD0000
	buffer_gl0_inv                                             // 00000014D650: E0AC0000 00000000
	s_and_saveexec_b32 s8, s23                                 // 00000014D658: BE882017
	s_cbranch_execz 364                                        // 00000014D65C: BFA5016C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1710>
	s_lshl_b32 s9, s6, 2                                       // 00000014D660: 84098206
	s_mov_b32 s13, exec_lo                                     // 00000014D664: BE8D007E
	.long 0xd4c1007e                                           // 00000014D668: D4C1007E
	v_cndmask_b32_e32 v1, v145, v151, vcc_lo                   // 00000014D66C: 02032F91
	s_cbranch_execz 49                                         // 00000014D670: BFA50031 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1238>
	v_ashrrev_i32_e32 v146, 31, v145                           // 00000014D674: 3525229F
	s_mov_b32 s15, 0                                           // 00000014D678: BE8F0080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014D67C: BF870091
	.long 0xd73c0082                                           // 00000014D680: D73C0082
	v_cndmask_b32_e32 v1, 2, v145, vcc_lo                      // 00000014D684: 02032282
	.long 0xd7006a82                                           // 00000014D688: D7006A82
	v_cndmask_b32_e32 v1, v141, v130, vcc_lo                   // 00000014D68C: 0203058D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014D690: BF870001
	v_add_co_ci_u32_e64 v131, null, v142, v131, vcc_lo         // 00000014D694: D5207C83 01AB078E
	s_branch 16                                                // 00000014D69C: BFA00010 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11e0>
	s_nop 0                                                    // 00000014D6A0: BF800000
	s_nop 0                                                    // 00000014D6A4: BF800000
	s_nop 0                                                    // 00000014D6A8: BF800000
	s_nop 0                                                    // 00000014D6AC: BF800000
	s_nop 0                                                    // 00000014D6B0: BF800000
	s_nop 0                                                    // 00000014D6B4: BF800000
	s_nop 0                                                    // 00000014D6B8: BF800000
	s_nop 0                                                    // 00000014D6BC: BF800000
	s_or_b32 exec_lo, exec_lo, s24                             // 00000014D6C0: 8C7E187E
	v_mov_b32_e32 v133, v145                                   // 00000014D6C4: 7F0A0391
	v_mov_b32_e32 v145, v132                                   // 00000014D6C8: 7F220384
	s_and_b32 s1, exec_lo, s22                                 // 00000014D6CC: 8B01167E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000014D6D0: BF870499
	s_or_b32 s15, s1, s15                                      // 00000014D6D4: 8C0F0F01
	s_and_not1_b32 exec_lo, exec_lo, s15                       // 00000014D6D8: 917E0F7E
	s_cbranch_execz 20                                         // 00000014D6DC: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1230>
	global_load_b32 v132, v[130:131], off                      // 00000014D6E0: DC520000 847C0082
	s_or_b32 s22, s22, exec_lo                                 // 00000014D6E8: 8C167E16
	s_waitcnt vmcnt(0)                                         // 00000014D6EC: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s9, v132                          // 00000014D6F0: 7C890809
	s_and_saveexec_b32 s24, vcc_lo                             // 00000014D6F4: BE98206A
	s_cbranch_execz 65521                                      // 00000014D6F8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11c0>
	v_dual_mov_b32 v145, v151 :: v_dual_add_nc_u32 v132, 1, v145// 00000014D6FC: CA200197 91852281
	.long 0xd7000182                                           // 00000014D704: D7000182
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 00000014D708: 02010982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000014D70C: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, s1                // 00000014D710: D5207C83 00070680
	v_cmp_eq_u32_e32 vcc_lo, v151, v132                        // 00000014D718: 7C950997
	s_and_not1_b32 s1, s22, exec_lo                            // 00000014D71C: 91017E16
	s_and_b32 s22, vcc_lo, exec_lo                             // 00000014D720: 8B167E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014D724: BF870009
	s_or_b32 s22, s1, s22                                      // 00000014D728: 8C161601
	s_branch 65508                                             // 00000014D72C: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11c0>
	s_or_b32 exec_lo, exec_lo, s15                             // 00000014D730: 8C7E0F7E
	v_mov_b32_e32 v145, v133                                   // 00000014D734: 7F220385
	s_or_b32 exec_lo, exec_lo, s13                             // 00000014D738: 8C7E0D7E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014D73C: BF870001
	v_dual_mov_b32 v133, 15 :: v_dual_mov_b32 v130, v145       // 00000014D740: CA10008F 85820191
	s_mov_b32 s1, exec_lo                                      // 00000014D748: BE81007E
	.long 0xd4c1007e                                           // 00000014D74C: D4C1007E
	v_cndmask_b32_e32 v1, s9, v153, vcc_lo                     // 00000014D750: 02033209
	s_cbranch_execz 62                                         // 00000014D754: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1350>
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v145        // 00000014D758: CA100080 85820191
	s_mov_b32 s13, exec_lo                                     // 00000014D760: BE8D007E
	.long 0xd4c1007e                                           // 00000014D764: D4C1007E
	v_cndmask_b32_e32 v1, v145, v151, vcc_lo                   // 00000014D768: 02032F91
	s_cbranch_execz 54                                         // 00000014D76C: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1348>
	v_mov_b32_e32 v130, v145                                   // 00000014D770: 7F040391
	s_mov_b32 s22, 0                                           // 00000014D774: BE960080
	s_set_inst_prefetch_distance 0x1                           // 00000014D778: BF840001
	s_branch 10                                                // 00000014D77C: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12a8>
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014D780: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000014D784: BF870499
	s_and_b32 s26, exec_lo, s25                                // 00000014D788: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 00000014D78C: 8C16161A
	s_and_not1_b32 s15, s15, exec_lo                           // 00000014D790: 910F7E0F
	s_and_b32 s26, s24, exec_lo                                // 00000014D794: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014D798: BF870009
	s_or_b32 s15, s15, s26                                     // 00000014D79C: 8C0F1A0F
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 00000014D7A0: 917E167E
	s_cbranch_execz 28                                         // 00000014D7A4: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1318>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000014D7A8: BF8700C1
	v_mov_b32_e32 v131, v130                                   // 00000014D7AC: 7F060382
	s_or_b32 s24, s24, exec_lo                                 // 00000014D7B0: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 00000014D7B4: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 00000014D7B8: BE9A007E
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000014D7BC: 3509069F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014D7C0: BF870091
	.long 0xd73c0084                                           // 00000014D7C4: D73C0084
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000014D7C8: 02030682
	.long 0xd7006a84                                           // 00000014D7CC: D7006A84
	v_cndmask_b32_e32 v1, v141, v132, vcc_lo                   // 00000014D7D0: 0203098D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014D7D4: BF870001
	v_add_co_ci_u32_e64 v133, null, v142, v133, vcc_lo         // 00000014D7D8: D5207C85 01AB0B8E
	global_load_b32 v132, v[132:133], off                      // 00000014D7E0: DC520000 847C0084
	s_waitcnt vmcnt(0)                                         // 00000014D7E8: BF8903F7
	.long 0xd4c4007e                                           // 00000014D7EC: D4C4007E
	v_cndmask_b32_e32 v1, s9, v132, vcc_lo                     // 00000014D7F0: 02030809
	s_cbranch_execz 65506                                      // 00000014D7F4: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1280>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000014D7F8: 4B050681
	s_and_not1_b32 s25, s25, exec_lo                           // 00000014D7FC: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 00000014D800: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000014D804: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v151, v130                        // 00000014D808: 7C950597
	s_and_b32 s27, vcc_lo, exec_lo                             // 00000014D80C: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 00000014D810: 8C191B19
	s_branch 65498                                             // 00000014D814: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1280>
	s_set_inst_prefetch_distance 0x2                           // 00000014D818: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 00000014D81C: 8C7E167E
	v_dual_mov_b32 v133, 0 :: v_dual_mov_b32 v130, v151        // 00000014D820: CA100080 85820197
	s_and_saveexec_b32 s22, s15                                // 00000014D828: BE96200F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014D82C: BF870009
	s_xor_b32 s15, exec_lo, s22                                // 00000014D830: 8D0F167E
	v_cmp_eq_u32_e32 vcc_lo, s9, v132                          // 00000014D834: 7C950809
	v_mov_b32_e32 v130, v131                                   // 00000014D838: 7F040383
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 00000014D83C: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s15                             // 00000014D844: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014D848: BF870009
	s_or_b32 exec_lo, exec_lo, s13                             // 00000014D84C: 8C7E0D7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014D850: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014D854: 8C7E017E
	s_or_b32 s13, s9, 1                                        // 00000014D858: 8C0D8109
	s_mov_b32 s1, exec_lo                                      // 00000014D85C: BE81007E
	.long 0xd4c6007e                                           // 00000014D860: D4C6007E
	v_cndmask_b32_e32 v1, s13, v153, vcc_lo                    // 00000014D864: 0203320D
	s_xor_b32 s1, exec_lo, s1                                  // 00000014D868: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 00000014D86C: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 00000014D874: BE813001
	s_cbranch_execz 70                                         // 00000014D878: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1494>
	s_mov_b32 s15, exec_lo                                     // 00000014D87C: BE8F007E
	.long 0xd4c1007e                                           // 00000014D880: D4C1007E
	v_cndmask_b32_e32 v1, v130, v151, vcc_lo                   // 00000014D884: 02032F82
	s_cbranch_execz 64                                         // 00000014D888: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x148c>
	s_mov_b32 s24, 0                                           // 00000014D88C: BE980080
	s_set_inst_prefetch_distance 0x1                           // 00000014D890: BF840001
	s_branch 20                                                // 00000014D894: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13e8>
	s_nop 0                                                    // 00000014D898: BF800000
	s_nop 0                                                    // 00000014D89C: BF800000
	s_nop 0                                                    // 00000014D8A0: BF800000
	s_nop 0                                                    // 00000014D8A4: BF800000
	s_nop 0                                                    // 00000014D8A8: BF800000
	s_nop 0                                                    // 00000014D8AC: BF800000
	s_nop 0                                                    // 00000014D8B0: BF800000
	s_nop 0                                                    // 00000014D8B4: BF800000
	s_nop 0                                                    // 00000014D8B8: BF800000
	s_nop 0                                                    // 00000014D8BC: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 00000014D8C0: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000014D8C4: BF870499
	s_and_b32 s27, exec_lo, s26                                // 00000014D8C8: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 00000014D8CC: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 00000014D8D0: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 00000014D8D4: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014D8D8: BF870009
	s_or_b32 s22, s22, s27                                     // 00000014D8DC: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 00000014D8E0: 917E187E
	s_cbranch_execz 27                                         // 00000014D8E4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1454>
	v_mov_b32_e32 v131, v130                                   // 00000014D8E8: 7F060382
	s_or_b32 s25, s25, exec_lo                                 // 00000014D8EC: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 00000014D8F0: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 00000014D8F4: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014D8F8: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000014D8FC: 3509069F
	.long 0xd73c0086                                           // 00000014D900: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000014D904: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014D908: BF870091
	.long 0xd7006a86                                           // 00000014D90C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 00000014D910: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 00000014D914: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 00000014D91C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 00000014D924: BF8903F7
	.long 0xd4c6007e                                           // 00000014D928: D4C6007E
	v_cndmask_b32_e32 v1, s9, v132, vcc_lo                     // 00000014D92C: 02030809
	s_cbranch_execz 65507                                      // 00000014D930: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13c0>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000014D934: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 00000014D938: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 00000014D93C: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000014D940: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v151, v130                        // 00000014D944: 7C950597
	s_and_b32 s28, vcc_lo, exec_lo                             // 00000014D948: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 00000014D94C: 8C1A1C1A
	s_branch 65499                                             // 00000014D950: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13c0>
	s_set_inst_prefetch_distance 0x2                           // 00000014D954: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 00000014D958: 8C7E187E
	v_mov_b32_e32 v130, v151                                   // 00000014D95C: 7F040397
	s_and_saveexec_b32 s24, s22                                // 00000014D960: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014D964: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 00000014D968: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s13, v132                         // 00000014D96C: 7C95080D
	v_cndmask_b32_e64 v130, 0, 0xf0, vcc_lo                    // 00000014D970: D5010082 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014D97C: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000014D980: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 00000014D984: 7F040383
	s_or_b32 exec_lo, exec_lo, s22                             // 00000014D988: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014D98C: BF870009
	s_or_b32 exec_lo, exec_lo, s15                             // 00000014D990: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014D994: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014D998: 8C7E017E
	s_or_b32 s13, s9, 2                                        // 00000014D99C: 8C0D8209
	s_mov_b32 s1, exec_lo                                      // 00000014D9A0: BE81007E
	.long 0xd4c6007e                                           // 00000014D9A4: D4C6007E
	v_cndmask_b32_e32 v1, s13, v153, vcc_lo                    // 00000014D9A8: 0203320D
	s_xor_b32 s1, exec_lo, s1                                  // 00000014D9AC: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 00000014D9B0: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 00000014D9B8: BE813001
	s_cbranch_execz 69                                         // 00000014D9BC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15d4>
	s_mov_b32 s15, exec_lo                                     // 00000014D9C0: BE8F007E
	.long 0xd4c1007e                                           // 00000014D9C4: D4C1007E
	v_cndmask_b32_e32 v1, v130, v151, vcc_lo                   // 00000014D9C8: 02032F82
	s_cbranch_execz 63                                         // 00000014D9CC: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15cc>
	s_mov_b32 s24, 0                                           // 00000014D9D0: BE980080
	s_set_inst_prefetch_distance 0x1                           // 00000014D9D4: BF840001
	s_branch 19                                                // 00000014D9D8: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1528>
	s_nop 0                                                    // 00000014D9DC: BF800000
	s_nop 0                                                    // 00000014D9E0: BF800000
	s_nop 0                                                    // 00000014D9E4: BF800000
	s_nop 0                                                    // 00000014D9E8: BF800000
	s_nop 0                                                    // 00000014D9EC: BF800000
	s_nop 0                                                    // 00000014D9F0: BF800000
	s_nop 0                                                    // 00000014D9F4: BF800000
	s_nop 0                                                    // 00000014D9F8: BF800000
	s_nop 0                                                    // 00000014D9FC: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 00000014DA00: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000014DA04: BF870499
	s_and_b32 s27, exec_lo, s26                                // 00000014DA08: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 00000014DA0C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 00000014DA10: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 00000014DA14: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DA18: BF870009
	s_or_b32 s22, s22, s27                                     // 00000014DA1C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 00000014DA20: 917E187E
	s_cbranch_execz 27                                         // 00000014DA24: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1594>
	v_mov_b32_e32 v131, v130                                   // 00000014DA28: 7F060382
	s_or_b32 s25, s25, exec_lo                                 // 00000014DA2C: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 00000014DA30: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 00000014DA34: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014DA38: BF870091
	v_ashrrev_i32_e32 v132, 31, v131                           // 00000014DA3C: 3509069F
	.long 0xd73c0086                                           // 00000014DA40: D73C0086
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000014DA44: 02030682
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014DA48: BF870091
	.long 0xd7006a86                                           // 00000014DA4C: D7006A86
	v_cndmask_b32_e32 v1, v141, v134, vcc_lo                   // 00000014DA50: 02030D8D
	v_add_co_ci_u32_e64 v135, null, v142, v135, vcc_lo         // 00000014DA54: D5207C87 01AB0F8E
	global_load_b32 v132, v[134:135], off                      // 00000014DA5C: DC520000 847C0086
	s_waitcnt vmcnt(0)                                         // 00000014DA64: BF8903F7
	.long 0xd4c4007e                                           // 00000014DA68: D4C4007E
	v_cndmask_b32_e32 v1, s13, v132, vcc_lo                    // 00000014DA6C: 0203080D
	s_cbranch_execz 65507                                      // 00000014DA70: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1500>
	v_add_nc_u32_e32 v130, 1, v131                             // 00000014DA74: 4B050681
	s_and_not1_b32 s26, s26, exec_lo                           // 00000014DA78: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 00000014DA7C: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000014DA80: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v151, v130                        // 00000014DA84: 7C950597
	s_and_b32 s28, vcc_lo, exec_lo                             // 00000014DA88: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 00000014DA8C: 8C1A1C1A
	s_branch 65499                                             // 00000014DA90: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1500>
	s_set_inst_prefetch_distance 0x2                           // 00000014DA94: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 00000014DA98: 8C7E187E
	v_mov_b32_e32 v130, v151                                   // 00000014DA9C: 7F040397
	s_and_saveexec_b32 s24, s22                                // 00000014DAA0: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DAA4: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 00000014DAA8: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s13, v132                         // 00000014DAAC: 7C95080D
	v_cndmask_b32_e64 v130, 0, 0xf00, vcc_lo                   // 00000014DAB0: D5010082 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DABC: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000014DAC0: 390B0B82
	v_mov_b32_e32 v130, v131                                   // 00000014DAC4: 7F040383
	s_or_b32 exec_lo, exec_lo, s22                             // 00000014DAC8: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DACC: BF870009
	s_or_b32 exec_lo, exec_lo, s15                             // 00000014DAD0: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DAD4: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DAD8: 8C7E017E
	s_or_b32 s9, s9, 3                                         // 00000014DADC: 8C098309
	s_mov_b32 s1, exec_lo                                      // 00000014DAE0: BE81007E
	.long 0xd4c6007e                                           // 00000014DAE4: D4C6007E
	v_cndmask_b32_e32 v1, s9, v153, vcc_lo                     // 00000014DAE8: 02033209
	s_xor_b32 s1, exec_lo, s1                                  // 00000014DAEC: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 00000014DAF0: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 00000014DAF8: BE813001
	s_cbranch_execz 66                                         // 00000014DAFC: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1708>
	s_mov_b32 s13, exec_lo                                     // 00000014DB00: BE8D007E
	.long 0xd4c1007e                                           // 00000014DB04: D4C1007E
	v_cndmask_b32_e32 v1, v130, v151, vcc_lo                   // 00000014DB08: 02032F82
	s_cbranch_execz 60                                         // 00000014DB0C: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1700>
	s_mov_b32 s22, 0                                           // 00000014DB10: BE960080
	s_set_inst_prefetch_distance 0x1                           // 00000014DB14: BF840001
	s_branch 19                                                // 00000014DB18: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1668>
	s_nop 0                                                    // 00000014DB1C: BF800000
	s_nop 0                                                    // 00000014DB20: BF800000
	s_nop 0                                                    // 00000014DB24: BF800000
	s_nop 0                                                    // 00000014DB28: BF800000
	s_nop 0                                                    // 00000014DB2C: BF800000
	s_nop 0                                                    // 00000014DB30: BF800000
	s_nop 0                                                    // 00000014DB34: BF800000
	s_nop 0                                                    // 00000014DB38: BF800000
	s_nop 0                                                    // 00000014DB3C: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 00000014DB40: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000014DB44: BF870499
	s_and_b32 s26, exec_lo, s25                                // 00000014DB48: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 00000014DB4C: 8C16161A
	s_and_not1_b32 s15, s15, exec_lo                           // 00000014DB50: 910F7E0F
	s_and_b32 s26, s24, exec_lo                                // 00000014DB54: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DB58: BF870009
	s_or_b32 s15, s15, s26                                     // 00000014DB5C: 8C0F1A0F
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 00000014DB60: 917E167E
	s_cbranch_execz 26                                         // 00000014DB64: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16d0>
	v_ashrrev_i32_e32 v131, 31, v130                           // 00000014DB68: 3507049F
	s_or_b32 s24, s24, exec_lo                                 // 00000014DB6C: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 00000014DB70: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 00000014DB74: BE9A007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014DB78: BF870091
	.long 0xd73c0083                                           // 00000014DB7C: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 00000014DB80: 02030482
	.long 0xd7006a83                                           // 00000014DB84: D7006A83
	v_cndmask_b32_e32 v1, v141, v131, vcc_lo                   // 00000014DB88: 0203078D
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DB8C: BF870001
	v_add_co_ci_u32_e64 v132, null, v142, v132, vcc_lo         // 00000014DB90: D5207C84 01AB098E
	global_load_b32 v131, v[131:132], off                      // 00000014DB98: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 00000014DBA0: BF8903F7
	.long 0xd4c4007e                                           // 00000014DBA4: D4C4007E
	v_cndmask_b32_e32 v1, s9, v131, vcc_lo                     // 00000014DBA8: 02030609
	s_cbranch_execz 65508                                      // 00000014DBAC: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1640>
	v_add_nc_u32_e32 v130, 1, v130                             // 00000014DBB0: 4B050481
	s_and_not1_b32 s25, s25, exec_lo                           // 00000014DBB4: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 00000014DBB8: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000014DBBC: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v151, v130                        // 00000014DBC0: 7C950597
	s_and_b32 s27, vcc_lo, exec_lo                             // 00000014DBC4: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 00000014DBC8: 8C191B19
	s_branch 65500                                             // 00000014DBCC: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1640>
	s_set_inst_prefetch_distance 0x2                           // 00000014DBD0: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 00000014DBD4: 8C7E167E
	s_and_saveexec_b32 s22, s15                                // 00000014DBD8: BE96200F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DBDC: BF870009
	s_xor_b32 s15, exec_lo, s22                                // 00000014DBE0: 8D0F167E
	v_cmp_eq_u32_e32 vcc_lo, s9, v131                          // 00000014DBE4: 7C950609
	v_cndmask_b32_e64 v130, 0, 0xf000, vcc_lo                  // 00000014DBE8: D5010082 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DBF4: BF870001
	v_or_b32_e32 v133, v130, v133                              // 00000014DBF8: 390B0B82
	s_or_b32 exec_lo, exec_lo, s15                             // 00000014DBFC: 8C7E0F7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DC00: BF870009
	s_or_b32 exec_lo, exec_lo, s13                             // 00000014DC04: 8C7E0D7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DC08: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DC0C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DC10: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014DC14: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014DC18: BE882003
	s_cbranch_execz 64566                                      // 00000014DC1C: BFA5FC36 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7f8>
	ds_load_b32 v131, v155                                     // 00000014DC20: D8D80000 8300009B
	v_and_b32_e32 v130, 1, v133                                // 00000014DC28: 37050A81
	v_cmp_le_i32_e32 vcc_lo, s7, v154                          // 00000014DC2C: 7C873407
	s_delay_alu instid0(VALU_DEP_2)                            // 00000014DC30: BF870002
	.long 0xd44a0001                                           // 00000014DC34: D44A0001
	v_cndmask_b32_e32 v1, 1, v130, vcc_lo                      // 00000014DC38: 02030481
	s_and_b32 s35, vcc_lo, s1                                  // 00000014DC3C: 8B23016A
	s_waitcnt lgkmcnt(0)                                       // 00000014DC40: BF89FC07
	v_mov_b32_e32 v130, v131                                   // 00000014DC44: 7F040383
	s_and_saveexec_b32 s1, s35                                 // 00000014DC48: BE812023
	s_cbranch_execz 7                                          // 00000014DC4C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x176c>
	ds_load_b32 v130, v156                                     // 00000014DC50: D8D80000 8200009C
	v_max_f32_e32 v132, v131, v131                             // 00000014DC58: 21090783
	s_waitcnt lgkmcnt(0)                                       // 00000014DC5C: BF89FC07
	v_max_f32_e32 v130, v130, v130                             // 00000014DC60: 21050582
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DC64: BF870001
	v_max_f32_e32 v130, v132, v130                             // 00000014DC68: 21050584
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DC6C: 8C7E017E
	v_and_b32_e32 v132, 2, v133                                // 00000014DC70: 37090A82
	v_cmp_lt_i32_e32 vcc_lo, s7, v154                          // 00000014DC74: 7C833407
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000014DC78: BF8704A2
	.long 0xd44d0001                                           // 00000014DC7C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014DC80: 02030880
	s_and_b32 s34, vcc_lo, s1                                  // 00000014DC84: 8B22016A
	s_and_saveexec_b32 s1, s34                                 // 00000014DC88: BE812022
	s_cbranch_execz 7                                          // 00000014DC8C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17ac>
	ds_load_b32 v132, v156 offset:4                            // 00000014DC90: D8D80004 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014DC98: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014DC9C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014DCA0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DCA4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014DCA8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DCAC: 8C7E017E
	v_and_b32_e32 v132, 4, v133                                // 00000014DCB0: 37090A84
	s_or_b32 s1, s7, 2                                         // 00000014DCB4: 8C018207
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014DCB8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v154                          // 00000014DCBC: 7C873401
	.long 0xd44d0001                                           // 00000014DCC0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014DCC4: 02030880
	s_and_b32 s33, vcc_lo, s1                                  // 00000014DCC8: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DCCC: BF870009
	s_and_saveexec_b32 s1, s33                                 // 00000014DCD0: BE812021
	s_cbranch_execz 7                                          // 00000014DCD4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17f4>
	ds_load_b32 v132, v156 offset:8                            // 00000014DCD8: D8D80008 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014DCE0: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014DCE4: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014DCE8: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DCEC: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014DCF0: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DCF4: 8C7E017E
	v_and_b32_e32 v132, 8, v133                                // 00000014DCF8: 37090A88
	s_or_b32 s1, s7, 3                                         // 00000014DCFC: 8C018307
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014DD00: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v154                          // 00000014DD04: 7C873401
	.long 0xd44d0001                                           // 00000014DD08: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014DD0C: 02030880
	s_and_b32 s31, vcc_lo, s1                                  // 00000014DD10: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DD14: BF870009
	s_and_saveexec_b32 s1, s31                                 // 00000014DD18: BE81201F
	s_cbranch_execz 7                                          // 00000014DD1C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x183c>
	ds_load_b32 v132, v156 offset:12                           // 00000014DD20: D8D8000C 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014DD28: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014DD2C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014DD30: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DD34: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014DD38: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DD3C: 8C7E017E
	v_and_b32_e32 v132, 16, v133                               // 00000014DD40: 37090A90
	s_or_b32 s1, s7, 4                                         // 00000014DD44: 8C018407
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014DD48: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v154                          // 00000014DD4C: 7C873401
	.long 0xd44d0001                                           // 00000014DD50: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014DD54: 02030880
	s_and_b32 s30, vcc_lo, s1                                  // 00000014DD58: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DD5C: BF870009
	s_and_saveexec_b32 s1, s30                                 // 00000014DD60: BE81201E
	s_cbranch_execz 7                                          // 00000014DD64: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1884>
	ds_load_b32 v132, v156 offset:16                           // 00000014DD68: D8D80010 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014DD70: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014DD74: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014DD78: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DD7C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014DD80: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DD84: 8C7E017E
	v_and_b32_e32 v132, 32, v133                               // 00000014DD88: 37090AA0
	s_or_b32 s1, s7, 5                                         // 00000014DD8C: 8C018507
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014DD90: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v154                          // 00000014DD94: 7C873401
	.long 0xd44d0001                                           // 00000014DD98: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014DD9C: 02030880
	s_and_b32 s29, vcc_lo, s1                                  // 00000014DDA0: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DDA4: BF870009
	s_and_saveexec_b32 s1, s29                                 // 00000014DDA8: BE81201D
	s_cbranch_execz 7                                          // 00000014DDAC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18cc>
	ds_load_b32 v132, v156 offset:20                           // 00000014DDB0: D8D80014 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014DDB8: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014DDBC: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014DDC0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DDC4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014DDC8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DDCC: 8C7E017E
	v_and_b32_e32 v132, 64, v133                               // 00000014DDD0: 37090AC0
	s_or_b32 s1, s7, 6                                         // 00000014DDD4: 8C018607
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014DDD8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v154                          // 00000014DDDC: 7C873401
	.long 0xd44d0001                                           // 00000014DDE0: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014DDE4: 02030880
	s_and_b32 s28, vcc_lo, s1                                  // 00000014DDE8: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DDEC: BF870009
	s_and_saveexec_b32 s1, s28                                 // 00000014DDF0: BE81201C
	s_cbranch_execz 7                                          // 00000014DDF4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1914>
	ds_load_b32 v132, v156 offset:24                           // 00000014DDF8: D8D80018 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014DE00: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014DE04: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014DE08: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DE0C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014DE10: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DE14: 8C7E017E
	v_and_b32_e32 v132, 0x80, v133                             // 00000014DE18: 37090AFF 00000080
	s_or_b32 s1, s7, 7                                         // 00000014DE20: 8C018707
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014DE24: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v154                          // 00000014DE28: 7C873401
	.long 0xd44d0001                                           // 00000014DE2C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014DE30: 02030880
	s_and_b32 s27, vcc_lo, s1                                  // 00000014DE34: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DE38: BF870009
	s_and_saveexec_b32 s1, s27                                 // 00000014DE3C: BE81201B
	s_cbranch_execz 7                                          // 00000014DE40: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1960>
	ds_load_b32 v132, v156 offset:28                           // 00000014DE44: D8D8001C 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014DE4C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014DE50: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014DE54: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DE58: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014DE5C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DE60: 8C7E017E
	v_and_b32_e32 v132, 0x100, v133                            // 00000014DE64: 37090AFF 00000100
	s_or_b32 s1, s7, 8                                         // 00000014DE6C: 8C018807
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014DE70: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v154                          // 00000014DE74: 7C873401
	.long 0xd44d0001                                           // 00000014DE78: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014DE7C: 02030880
	s_and_b32 s26, vcc_lo, s1                                  // 00000014DE80: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DE84: BF870009
	s_and_saveexec_b32 s1, s26                                 // 00000014DE88: BE81201A
	s_cbranch_execz 7                                          // 00000014DE8C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19ac>
	ds_load_b32 v132, v156 offset:32                           // 00000014DE90: D8D80020 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014DE98: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014DE9C: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014DEA0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DEA4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014DEA8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DEAC: 8C7E017E
	v_and_b32_e32 v132, 0x200, v133                            // 00000014DEB0: 37090AFF 00000200
	s_or_b32 s1, s7, 9                                         // 00000014DEB8: 8C018907
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014DEBC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v154                          // 00000014DEC0: 7C873401
	.long 0xd44d0001                                           // 00000014DEC4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014DEC8: 02030880
	s_and_b32 s25, vcc_lo, s1                                  // 00000014DECC: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DED0: BF870009
	s_and_saveexec_b32 s1, s25                                 // 00000014DED4: BE812019
	s_cbranch_execz 7                                          // 00000014DED8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19f8>
	ds_load_b32 v132, v156 offset:36                           // 00000014DEDC: D8D80024 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014DEE4: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014DEE8: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014DEEC: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DEF0: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014DEF4: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DEF8: 8C7E017E
	v_and_b32_e32 v132, 0x400, v133                            // 00000014DEFC: 37090AFF 00000400
	s_or_b32 s1, s7, 10                                        // 00000014DF04: 8C018A07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014DF08: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v154                          // 00000014DF0C: 7C873401
	.long 0xd44d0001                                           // 00000014DF10: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014DF14: 02030880
	s_and_b32 s24, vcc_lo, s1                                  // 00000014DF18: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DF1C: BF870009
	s_and_saveexec_b32 s1, s24                                 // 00000014DF20: BE812018
	s_cbranch_execz 7                                          // 00000014DF24: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a44>
	ds_load_b32 v132, v156 offset:40                           // 00000014DF28: D8D80028 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014DF30: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014DF34: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014DF38: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DF3C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014DF40: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DF44: 8C7E017E
	v_and_b32_e32 v132, 0x800, v133                            // 00000014DF48: 37090AFF 00000800
	s_or_b32 s1, s7, 11                                        // 00000014DF50: 8C018B07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014DF54: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v154                          // 00000014DF58: 7C873401
	.long 0xd44d0001                                           // 00000014DF5C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014DF60: 02030880
	s_and_b32 s22, vcc_lo, s1                                  // 00000014DF64: 8B16016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DF68: BF870009
	s_and_saveexec_b32 s1, s22                                 // 00000014DF6C: BE812016
	s_cbranch_execz 7                                          // 00000014DF70: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a90>
	ds_load_b32 v132, v156 offset:44                           // 00000014DF74: D8D8002C 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014DF7C: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014DF80: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014DF84: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DF88: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014DF8C: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DF90: 8C7E017E
	v_and_b32_e32 v132, 0x1000, v133                           // 00000014DF94: 37090AFF 00001000
	s_or_b32 s1, s7, 12                                        // 00000014DF9C: 8C018C07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014DFA0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v154                          // 00000014DFA4: 7C873401
	.long 0xd44d0001                                           // 00000014DFA8: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014DFAC: 02030880
	s_and_b32 s15, vcc_lo, s1                                  // 00000014DFB0: 8B0F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014DFB4: BF870009
	s_and_saveexec_b32 s1, s15                                 // 00000014DFB8: BE81200F
	s_cbranch_execz 7                                          // 00000014DFBC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1adc>
	ds_load_b32 v132, v156 offset:48                           // 00000014DFC0: D8D80030 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014DFC8: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014DFCC: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014DFD0: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014DFD4: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014DFD8: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014DFDC: 8C7E017E
	v_and_b32_e32 v132, 0x2000, v133                           // 00000014DFE0: 37090AFF 00002000
	s_or_b32 s1, s7, 13                                        // 00000014DFE8: 8C018D07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014DFEC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v154                          // 00000014DFF0: 7C873401
	.long 0xd44d0001                                           // 00000014DFF4: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014DFF8: 02030880
	s_and_b32 s13, vcc_lo, s1                                  // 00000014DFFC: 8B0D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014E000: BF870009
	s_and_saveexec_b32 s1, s13                                 // 00000014E004: BE81200D
	s_cbranch_execz 7                                          // 00000014E008: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b28>
	ds_load_b32 v132, v156 offset:52                           // 00000014E00C: D8D80034 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014E014: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014E018: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014E01C: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014E020: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014E024: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014E028: 8C7E017E
	v_and_b32_e32 v132, 0x4000, v133                           // 00000014E02C: 37090AFF 00004000
	s_or_b32 s1, s7, 14                                        // 00000014E034: 8C018E07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014E038: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v154                          // 00000014E03C: 7C873401
	.long 0xd44d0001                                           // 00000014E040: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014E044: 02030880
	s_and_b32 s9, vcc_lo, s1                                   // 00000014E048: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014E04C: BF870009
	s_and_saveexec_b32 s1, s9                                  // 00000014E050: BE812009
	s_cbranch_execz 7                                          // 00000014E054: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b74>
	ds_load_b32 v132, v156 offset:56                           // 00000014E058: D8D80038 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014E060: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014E064: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014E068: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014E06C: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014E070: 21050982
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014E074: 8C7E017E
	v_and_b32_e32 v132, 0x8000, v133                           // 00000014E078: 37090AFF 00008000
	s_or_b32 s7, s7, 15                                        // 00000014E080: 8C078F07
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014E084: BF870119
	v_cmp_le_i32_e32 vcc_lo, s7, v154                          // 00000014E088: 7C873407
	.long 0xd44d0001                                           // 00000014E08C: D44D0001
	v_cndmask_b32_e32 v1, 0, v132, vcc_lo                      // 00000014E090: 02030880
	s_and_b32 s1, vcc_lo, s1                                   // 00000014E094: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000014E098: BF870009
	s_and_saveexec_b32 s7, s1                                  // 00000014E09C: BE872001
	s_cbranch_execz 7                                          // 00000014E0A0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1bc0>
	ds_load_b32 v132, v156 offset:60                           // 00000014E0A4: D8D8003C 8400009C
	v_max_f32_e32 v130, v130, v130                             // 00000014E0AC: 21050582
	s_waitcnt lgkmcnt(0)                                       // 00000014E0B0: BF89FC07
	v_max_f32_e32 v132, v132, v132                             // 00000014E0B4: 21090984
	s_delay_alu instid0(VALU_DEP_1)                            // 00000014E0B8: BF870001
	v_max_f32_e32 v130, v130, v132                             // 00000014E0BC: 21050982
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E0C0: 8C7E077E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v133, 0           // 00000014E0C4: CA100080 84840080
	s_and_saveexec_b32 s7, s35                                 // 00000014E0CC: BE872023
	s_cbranch_execz 30                                         // 00000014E0D0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c4c>
	ds_load_b32 v133, v156                                     // 00000014E0D4: D8D80000 8500009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E0DC: BF89FC07
	v_sub_f32_e32 v133, v133, v130                             // 00000014E0E0: 090B0585
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E0E4: BF870091
	v_mul_f32_e32 v134, 0x3fb8aa3b, v133                       // 00000014E0E8: 110D0AFF 3FB8AA3B
	v_fma_f32 v135, 0x3fb8aa3b, v133, -v134                    // 00000014E0F0: D6130087 861B0AFF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 00000014E0FC: 7F104786
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000014E100: BF870221
	v_sub_f32_e32 v134, v134, v136                             // 00000014E104: 090D1186
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 00000014E108: 7C370AFF C2CE8ED0
	v_fmac_f32_e32 v135, 0x32a5705f, v133                      // 00000014E110: 570F0AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E118: BF870121
	v_add_f32_e32 v134, v134, v135                             // 00000014E11C: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 00000014E120: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 00000014E124: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E128: BF870095
	.long 0xd71c0086                                           // 00000014E12C: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 00000014E130: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 00000014E134: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 00000014E138: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000014E140: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v134, vcc_lo           // 00000014E144: 030B0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E14C: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E150: BF870091
	v_bfe_u32 v134, v133, 16, 1                                // 00000014E154: D6100086 02052185
	v_add3_u32 v134, v133, v134, 0x7fff                        // 00000014E15C: D6550086 03FF0D85 00007FFF
	ds_store_b16_d16_hi v157, v134                             // 00000014E168: DA840000 0000869D
	s_and_saveexec_b32 s7, s34                                 // 00000014E170: BE872022
	s_cbranch_execz 30                                         // 00000014E174: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1cf0>
	ds_load_b32 v132, v156 offset:4                            // 00000014E178: D8D80004 8400009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E180: BF89FC07
	v_sub_f32_e32 v132, v132, v130                             // 00000014E184: 09090584
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E188: BF870121
	v_mul_f32_e32 v134, 0x3fb8aa3b, v132                       // 00000014E18C: 110D08FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v132                 // 00000014E194: 7C3708FF C2CE8ED0
	v_fma_f32 v135, 0x3fb8aa3b, v132, -v134                    // 00000014E19C: D6130087 861B08FF 3FB8AA3B
	v_rndne_f32_e32 v136, v134                                 // 00000014E1A8: 7F104786
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014E1AC: BF870112
	v_fmac_f32_e32 v135, 0x32a5705f, v132                      // 00000014E1B0: 570F08FF 32A5705F
	v_sub_f32_e32 v134, v134, v136                             // 00000014E1B8: 090D1186
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E1BC: BF870121
	v_add_f32_e32 v134, v134, v135                             // 00000014E1C0: 070D0F86
	v_cvt_i32_f32_e32 v135, v136                               // 00000014E1C4: 7F0E1188
	v_exp_f32_e32 v134, v134                                   // 00000014E1C8: 7F0C4B86
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E1CC: BF870095
	.long 0xd71c0086                                           // 00000014E1D0: D71C0086
	v_cndmask_b32_e32 v1, v134, v135, vcc_lo                   // 00000014E1D4: 02030F86
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 00000014E1D8: 030D0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v132                 // 00000014E1DC: 7C3D08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000014E1E4: BF870002
	v_cndmask_b32_e32 v132, 0x7f800000, v134, vcc_lo           // 00000014E1E8: 03090CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E1F0: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E1F4: BF870121
	v_bfe_u32 v134, v132, 16, 1                                // 00000014E1F8: D6100086 02052184
	v_mov_b32_e32 v135, 0                                      // 00000014E200: 7F0E0280
	v_add3_u32 v136, v132, v134, 0x7fff                        // 00000014E204: D6550088 03FF0D84 00007FFF
	v_mov_b32_e32 v134, 0                                      // 00000014E210: 7F0C0280
	ds_store_b16_d16_hi v157, v136 offset:2                    // 00000014E214: DA840002 0000889D
	s_and_saveexec_b32 s7, s33                                 // 00000014E21C: BE872021
	s_cbranch_execz 29                                         // 00000014E220: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d98>
	ds_load_b32 v135, v156 offset:8                            // 00000014E224: D8D80008 8700009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E22C: BF89FC07
	v_sub_f32_e32 v135, v135, v130                             // 00000014E230: 090F0587
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E234: BF870091
	v_mul_f32_e32 v136, 0x3fb8aa3b, v135                       // 00000014E238: 11110EFF 3FB8AA3B
	v_fma_f32 v137, 0x3fb8aa3b, v135, -v136                    // 00000014E240: D6130089 86230EFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 00000014E24C: 7F244788
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E250: BF870091
	v_dual_fmac_f32 v137, 0x32a5705f, v135 :: v_dual_sub_f32 v136, v136, v146// 00000014E254: C80B0EFF 89892588 32A5705F
	v_add_f32_e32 v136, v136, v137                             // 00000014E260: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 00000014E264: 7F121192
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 00000014E268: 7C370EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014E270: BF870293
	v_exp_f32_e32 v136, v136                                   // 00000014E274: 7F104B88
	.long 0xd71c0088                                           // 00000014E278: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 00000014E27C: 02031388
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E280: BF870121
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 00000014E284: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 00000014E288: 7C3D0EFF 42B17218
	v_cndmask_b32_e32 v135, 0x7f800000, v136, vcc_lo           // 00000014E290: 030F10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E298: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E29C: BF870091
	v_bfe_u32 v136, v135, 16, 1                                // 00000014E2A0: D6100088 02052187
	v_add3_u32 v136, v135, v136, 0x7fff                        // 00000014E2A8: D6550088 03FF1187 00007FFF
	ds_store_b16_d16_hi v157, v136 offset:4                    // 00000014E2B4: DA840004 0000889D
	s_and_saveexec_b32 s7, s31                                 // 00000014E2BC: BE87201F
	s_cbranch_execz 30                                         // 00000014E2C0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e3c>
	ds_load_b32 v134, v156 offset:12                           // 00000014E2C4: D8D8000C 8600009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E2CC: BF89FC07
	v_sub_f32_e32 v134, v134, v130                             // 00000014E2D0: 090D0586
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E2D4: BF870121
	v_mul_f32_e32 v136, 0x3fb8aa3b, v134                       // 00000014E2D8: 11110CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 00000014E2E0: 7C370CFF C2CE8ED0
	v_fma_f32 v137, 0x3fb8aa3b, v134, -v136                    // 00000014E2E8: D6130089 86230CFF 3FB8AA3B
	v_rndne_f32_e32 v146, v136                                 // 00000014E2F4: 7F244788
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014E2F8: BF870112
	v_fmac_f32_e32 v137, 0x32a5705f, v134                      // 00000014E2FC: 57130CFF 32A5705F
	v_sub_f32_e32 v136, v136, v146                             // 00000014E304: 09112588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E308: BF870121
	v_add_f32_e32 v136, v136, v137                             // 00000014E30C: 07111388
	v_cvt_i32_f32_e32 v137, v146                               // 00000014E310: 7F121192
	v_exp_f32_e32 v136, v136                                   // 00000014E314: 7F104B88
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E318: BF870095
	.long 0xd71c0088                                           // 00000014E31C: D71C0088
	v_cndmask_b32_e32 v1, v136, v137, vcc_lo                   // 00000014E320: 02031388
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 00000014E324: 03111080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 00000014E328: 7C3D0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000014E330: BF870002
	v_cndmask_b32_e32 v134, 0x7f800000, v136, vcc_lo           // 00000014E334: 030D10FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E33C: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E340: BF870121
	v_bfe_u32 v136, v134, 16, 1                                // 00000014E344: D6100088 02052186
	v_mov_b32_e32 v137, 0                                      // 00000014E34C: 7F120280
	v_add3_u32 v146, v134, v136, 0x7fff                        // 00000014E350: D6550092 03FF1186 00007FFF
	v_mov_b32_e32 v136, 0                                      // 00000014E35C: 7F100280
	ds_store_b16_d16_hi v157, v146 offset:6                    // 00000014E360: DA840006 0000929D
	s_and_saveexec_b32 s7, s30                                 // 00000014E368: BE87201E
	s_cbranch_execz 29                                         // 00000014E36C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1ee4>
	ds_load_b32 v137, v156 offset:16                           // 00000014E370: D8D80010 8900009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E378: BF89FC07
	v_sub_f32_e32 v137, v137, v130                             // 00000014E37C: 09130589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E380: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 00000014E384: 112512FF 3FB8AA3B
	v_fma_f32 v169, 0x3fb8aa3b, v137, -v146                    // 00000014E38C: D61300A9 864B12FF 3FB8AA3B
	v_rndne_f32_e32 v170, v146                                 // 00000014E398: 7F544792
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E39C: BF870091
	v_dual_fmac_f32 v169, 0x32a5705f, v137 :: v_dual_sub_f32 v146, v146, v170// 00000014E3A0: C80B12FF A9935592 32A5705F
	v_add_f32_e32 v146, v146, v169                             // 00000014E3AC: 07255392
	v_cvt_i32_f32_e32 v169, v170                               // 00000014E3B0: 7F5211AA
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v137                 // 00000014E3B4: 7C3712FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014E3BC: BF870293
	v_exp_f32_e32 v146, v146                                   // 00000014E3C0: 7F244B92
	.long 0xd71c0092                                           // 00000014E3C4: D71C0092
	v_cndmask_b32_e32 v1, v146, v169, vcc_lo                   // 00000014E3C8: 02035392
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E3CC: BF870121
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 00000014E3D0: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v137                 // 00000014E3D4: 7C3D12FF 42B17218
	v_cndmask_b32_e32 v137, 0x7f800000, v146, vcc_lo           // 00000014E3DC: 031324FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E3E4: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E3E8: BF870091
	v_bfe_u32 v146, v137, 16, 1                                // 00000014E3EC: D6100092 02052189
	v_add3_u32 v146, v137, v146, 0x7fff                        // 00000014E3F4: D6550092 03FF2589 00007FFF
	ds_store_b16_d16_hi v157, v146 offset:8                    // 00000014E400: DA840008 0000929D
	s_and_saveexec_b32 s7, s29                                 // 00000014E408: BE87201D
	s_cbranch_execz 29                                         // 00000014E40C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f84>
	ds_load_b32 v136, v156 offset:20                           // 00000014E410: D8D80014 8800009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E418: BF89FC07
	v_sub_f32_e32 v136, v136, v130                             // 00000014E41C: 09110588
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E420: BF870121
	v_mul_f32_e32 v146, 0x3fb8aa3b, v136                       // 00000014E424: 112510FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 00000014E42C: 7C3710FF C2CE8ED0
	v_fma_f32 v169, 0x3fb8aa3b, v136, -v146                    // 00000014E434: D61300A9 864B10FF 3FB8AA3B
	v_rndne_f32_e32 v170, v146                                 // 00000014E440: 7F544792
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E444: BF870091
	v_dual_fmac_f32 v169, 0x32a5705f, v136 :: v_dual_sub_f32 v146, v146, v170// 00000014E448: C80B10FF A9935592 32A5705F
	v_add_f32_e32 v146, v146, v169                             // 00000014E454: 07255392
	v_cvt_i32_f32_e32 v169, v170                               // 00000014E458: 7F5211AA
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014E45C: BF870292
	v_exp_f32_e32 v146, v146                                   // 00000014E460: 7F244B92
	.long 0xd71c0092                                           // 00000014E464: D71C0092
	v_cndmask_b32_e32 v1, v146, v169, vcc_lo                   // 00000014E468: 02035392
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E46C: BF870121
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 00000014E470: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 00000014E474: 7C3D10FF 42B17218
	v_cndmask_b32_e32 v136, 0x7f800000, v146, vcc_lo           // 00000014E47C: 031124FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E484: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E488: BF870121
	v_bfe_u32 v146, v136, 16, 1                                // 00000014E48C: D6100092 02052188
	v_mov_b32_e32 v169, 0                                      // 00000014E494: 7F520280
	v_add3_u32 v170, v136, v146, 0x7fff                        // 00000014E498: D65500AA 03FF2588 00007FFF
	v_mov_b32_e32 v146, 0                                      // 00000014E4A4: 7F240280
	ds_store_b16_d16_hi v157, v170 offset:10                   // 00000014E4A8: DA84000A 0000AA9D
	s_and_saveexec_b32 s7, s28                                 // 00000014E4B0: BE87201C
	s_cbranch_execz 30                                         // 00000014E4B4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2030>
	ds_load_b32 v169, v156 offset:24                           // 00000014E4B8: D8D80018 A900009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E4C0: BF89FC07
	v_sub_f32_e32 v169, v169, v130                             // 00000014E4C4: 095305A9
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E4C8: BF870091
	v_mul_f32_e32 v170, 0x3fb8aa3b, v169                       // 00000014E4CC: 115552FF 3FB8AA3B
	v_fma_f32 v171, 0x3fb8aa3b, v169, -v170                    // 00000014E4D4: D61300AB 86AB52FF 3FB8AA3B
	v_rndne_f32_e32 v172, v170                                 // 00000014E4E0: 7F5847AA
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000014E4E4: BF870221
	v_sub_f32_e32 v170, v170, v172                             // 00000014E4E8: 095559AA
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v169                 // 00000014E4EC: 7C3752FF C2CE8ED0
	v_fmac_f32_e32 v171, 0x32a5705f, v169                      // 00000014E4F4: 575752FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E4FC: BF870121
	v_add_f32_e32 v170, v170, v171                             // 00000014E500: 075557AA
	v_cvt_i32_f32_e32 v171, v172                               // 00000014E504: 7F5611AC
	v_exp_f32_e32 v170, v170                                   // 00000014E508: 7F544BAA
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E50C: BF870095
	.long 0xd71c00aa                                           // 00000014E510: D71C00AA
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                   // 00000014E514: 020357AA
	v_cndmask_b32_e32 v170, 0, v170, vcc_lo                    // 00000014E518: 03555480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v169                 // 00000014E51C: 7C3D52FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000014E524: BF870002
	v_cndmask_b32_e32 v169, 0x7f800000, v170, vcc_lo           // 00000014E528: 035354FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E530: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E534: BF870091
	v_bfe_u32 v170, v169, 16, 1                                // 00000014E538: D61000AA 020521A9
	v_add3_u32 v170, v169, v170, 0x7fff                        // 00000014E540: D65500AA 03FF55A9 00007FFF
	ds_store_b16_d16_hi v157, v170 offset:12                   // 00000014E54C: DA84000C 0000AA9D
	s_and_saveexec_b32 s7, s27                                 // 00000014E554: BE87201B
	s_cbranch_execz 29                                         // 00000014E558: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x20d0>
	ds_load_b32 v146, v156 offset:28                           // 00000014E55C: D8D8001C 9200009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E564: BF89FC07
	v_sub_f32_e32 v146, v146, v130                             // 00000014E568: 09250592
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E56C: BF870121
	v_mul_f32_e32 v170, 0x3fb8aa3b, v146                       // 00000014E570: 115524FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v146                 // 00000014E578: 7C3724FF C2CE8ED0
	v_fma_f32 v171, 0x3fb8aa3b, v146, -v170                    // 00000014E580: D61300AB 86AB24FF 3FB8AA3B
	v_rndne_f32_e32 v172, v170                                 // 00000014E58C: 7F5847AA
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E590: BF870091
	v_dual_fmac_f32 v171, 0x32a5705f, v146 :: v_dual_sub_f32 v170, v170, v172// 00000014E594: C80B24FF ABAB59AA 32A5705F
	v_add_f32_e32 v170, v170, v171                             // 00000014E5A0: 075557AA
	v_cvt_i32_f32_e32 v171, v172                               // 00000014E5A4: 7F5611AC
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014E5A8: BF870292
	v_exp_f32_e32 v170, v170                                   // 00000014E5AC: 7F544BAA
	.long 0xd71c00aa                                           // 00000014E5B0: D71C00AA
	v_cndmask_b32_e32 v1, v170, v171, vcc_lo                   // 00000014E5B4: 020357AA
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E5B8: BF870121
	v_cndmask_b32_e32 v170, 0, v170, vcc_lo                    // 00000014E5BC: 03555480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v146                 // 00000014E5C0: 7C3D24FF 42B17218
	v_cndmask_b32_e32 v146, 0x7f800000, v170, vcc_lo           // 00000014E5C8: 032554FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E5D0: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E5D4: BF870121
	v_bfe_u32 v170, v146, 16, 1                                // 00000014E5D8: D61000AA 02052192
	v_mov_b32_e32 v171, 0                                      // 00000014E5E0: 7F560280
	v_add3_u32 v172, v146, v170, 0x7fff                        // 00000014E5E4: D65500AC 03FF5592 00007FFF
	v_mov_b32_e32 v170, 0                                      // 00000014E5F0: 7F540280
	ds_store_b16_d16_hi v157, v172 offset:14                   // 00000014E5F4: DA84000E 0000AC9D
	s_and_saveexec_b32 s7, s26                                 // 00000014E5FC: BE87201A
	s_cbranch_execz 29                                         // 00000014E600: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2178>
	ds_load_b32 v171, v156 offset:32                           // 00000014E604: D8D80020 AB00009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E60C: BF89FC07
	v_sub_f32_e32 v171, v171, v130                             // 00000014E610: 095705AB
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E614: BF870091
	v_mul_f32_e32 v172, 0x3fb8aa3b, v171                       // 00000014E618: 115956FF 3FB8AA3B
	v_fma_f32 v173, 0x3fb8aa3b, v171, -v172                    // 00000014E620: D61300AD 86B356FF 3FB8AA3B
	v_rndne_f32_e32 v174, v172                                 // 00000014E62C: 7F5C47AC
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E630: BF870091
	v_dual_fmac_f32 v173, 0x32a5705f, v171 :: v_dual_sub_f32 v172, v172, v174// 00000014E634: C80B56FF ADAD5DAC 32A5705F
	v_add_f32_e32 v172, v172, v173                             // 00000014E640: 07595BAC
	v_cvt_i32_f32_e32 v173, v174                               // 00000014E644: 7F5A11AE
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v171                 // 00000014E648: 7C3756FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014E650: BF870293
	v_exp_f32_e32 v172, v172                                   // 00000014E654: 7F584BAC
	.long 0xd71c00ac                                           // 00000014E658: D71C00AC
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                   // 00000014E65C: 02035BAC
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E660: BF870121
	v_cndmask_b32_e32 v172, 0, v172, vcc_lo                    // 00000014E664: 03595880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v171                 // 00000014E668: 7C3D56FF 42B17218
	v_cndmask_b32_e32 v171, 0x7f800000, v172, vcc_lo           // 00000014E670: 035758FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E678: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E67C: BF870091
	v_bfe_u32 v172, v171, 16, 1                                // 00000014E680: D61000AC 020521AB
	v_add3_u32 v172, v171, v172, 0x7fff                        // 00000014E688: D65500AC 03FF59AB 00007FFF
	ds_store_b16_d16_hi v157, v172 offset:16                   // 00000014E694: DA840010 0000AC9D
	s_and_saveexec_b32 s7, s25                                 // 00000014E69C: BE872019
	s_cbranch_execz 30                                         // 00000014E6A0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x221c>
	ds_load_b32 v170, v156 offset:36                           // 00000014E6A4: D8D80024 AA00009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E6AC: BF89FC07
	v_sub_f32_e32 v170, v170, v130                             // 00000014E6B0: 095505AA
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E6B4: BF870121
	v_mul_f32_e32 v172, 0x3fb8aa3b, v170                       // 00000014E6B8: 115954FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v170                 // 00000014E6C0: 7C3754FF C2CE8ED0
	v_fma_f32 v173, 0x3fb8aa3b, v170, -v172                    // 00000014E6C8: D61300AD 86B354FF 3FB8AA3B
	v_rndne_f32_e32 v174, v172                                 // 00000014E6D4: 7F5C47AC
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014E6D8: BF870112
	v_fmac_f32_e32 v173, 0x32a5705f, v170                      // 00000014E6DC: 575B54FF 32A5705F
	v_sub_f32_e32 v172, v172, v174                             // 00000014E6E4: 09595DAC
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E6E8: BF870121
	v_add_f32_e32 v172, v172, v173                             // 00000014E6EC: 07595BAC
	v_cvt_i32_f32_e32 v173, v174                               // 00000014E6F0: 7F5A11AE
	v_exp_f32_e32 v172, v172                                   // 00000014E6F4: 7F584BAC
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E6F8: BF870095
	.long 0xd71c00ac                                           // 00000014E6FC: D71C00AC
	v_cndmask_b32_e32 v1, v172, v173, vcc_lo                   // 00000014E700: 02035BAC
	v_cndmask_b32_e32 v172, 0, v172, vcc_lo                    // 00000014E704: 03595880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v170                 // 00000014E708: 7C3D54FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000014E710: BF870002
	v_cndmask_b32_e32 v170, 0x7f800000, v172, vcc_lo           // 00000014E714: 035558FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E71C: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E720: BF870121
	v_bfe_u32 v172, v170, 16, 1                                // 00000014E724: D61000AC 020521AA
	v_mov_b32_e32 v173, 0                                      // 00000014E72C: 7F5A0280
	v_add3_u32 v174, v170, v172, 0x7fff                        // 00000014E730: D65500AE 03FF59AA 00007FFF
	v_mov_b32_e32 v172, 0                                      // 00000014E73C: 7F580280
	ds_store_b16_d16_hi v157, v174 offset:18                   // 00000014E740: DA840012 0000AE9D
	s_and_saveexec_b32 s7, s24                                 // 00000014E748: BE872018
	s_cbranch_execz 30                                         // 00000014E74C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x22c8>
	ds_load_b32 v173, v156 offset:40                           // 00000014E750: D8D80028 AD00009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E758: BF89FC07
	v_sub_f32_e32 v173, v173, v130                             // 00000014E75C: 095B05AD
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E760: BF870091
	v_mul_f32_e32 v174, 0x3fb8aa3b, v173                       // 00000014E764: 115D5AFF 3FB8AA3B
	v_fma_f32 v175, 0x3fb8aa3b, v173, -v174                    // 00000014E76C: D61300AF 86BB5AFF 3FB8AA3B
	v_rndne_f32_e32 v176, v174                                 // 00000014E778: 7F6047AE
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000014E77C: BF870221
	v_sub_f32_e32 v174, v174, v176                             // 00000014E780: 095D61AE
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v173                 // 00000014E784: 7C375AFF C2CE8ED0
	v_fmac_f32_e32 v175, 0x32a5705f, v173                      // 00000014E78C: 575F5AFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E794: BF870121
	v_add_f32_e32 v174, v174, v175                             // 00000014E798: 075D5FAE
	v_cvt_i32_f32_e32 v175, v176                               // 00000014E79C: 7F5E11B0
	v_exp_f32_e32 v174, v174                                   // 00000014E7A0: 7F5C4BAE
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E7A4: BF870095
	.long 0xd71c00ae                                           // 00000014E7A8: D71C00AE
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                   // 00000014E7AC: 02035FAE
	v_cndmask_b32_e32 v174, 0, v174, vcc_lo                    // 00000014E7B0: 035D5C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v173                 // 00000014E7B4: 7C3D5AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000014E7BC: BF870002
	v_cndmask_b32_e32 v173, 0x7f800000, v174, vcc_lo           // 00000014E7C0: 035B5CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E7C8: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E7CC: BF870091
	v_bfe_u32 v174, v173, 16, 1                                // 00000014E7D0: D61000AE 020521AD
	v_add3_u32 v174, v173, v174, 0x7fff                        // 00000014E7D8: D65500AE 03FF5DAD 00007FFF
	ds_store_b16_d16_hi v157, v174 offset:20                   // 00000014E7E4: DA840014 0000AE9D
	s_and_saveexec_b32 s7, s22                                 // 00000014E7EC: BE872016
	s_cbranch_execz 30                                         // 00000014E7F0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x236c>
	ds_load_b32 v172, v156 offset:44                           // 00000014E7F4: D8D8002C AC00009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E7FC: BF89FC07
	v_sub_f32_e32 v172, v172, v130                             // 00000014E800: 095905AC
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E804: BF870121
	v_mul_f32_e32 v174, 0x3fb8aa3b, v172                       // 00000014E808: 115D58FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v172                 // 00000014E810: 7C3758FF C2CE8ED0
	v_fma_f32 v175, 0x3fb8aa3b, v172, -v174                    // 00000014E818: D61300AF 86BB58FF 3FB8AA3B
	v_rndne_f32_e32 v176, v174                                 // 00000014E824: 7F6047AE
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014E828: BF870112
	v_fmac_f32_e32 v175, 0x32a5705f, v172                      // 00000014E82C: 575F58FF 32A5705F
	v_sub_f32_e32 v174, v174, v176                             // 00000014E834: 095D61AE
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E838: BF870121
	v_add_f32_e32 v174, v174, v175                             // 00000014E83C: 075D5FAE
	v_cvt_i32_f32_e32 v175, v176                               // 00000014E840: 7F5E11B0
	v_exp_f32_e32 v174, v174                                   // 00000014E844: 7F5C4BAE
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E848: BF870095
	.long 0xd71c00ae                                           // 00000014E84C: D71C00AE
	v_cndmask_b32_e32 v1, v174, v175, vcc_lo                   // 00000014E850: 02035FAE
	v_cndmask_b32_e32 v174, 0, v174, vcc_lo                    // 00000014E854: 035D5C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v172                 // 00000014E858: 7C3D58FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000014E860: BF870002
	v_cndmask_b32_e32 v172, 0x7f800000, v174, vcc_lo           // 00000014E864: 03595CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E86C: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E870: BF870121
	v_bfe_u32 v174, v172, 16, 1                                // 00000014E874: D61000AE 020521AC
	v_mov_b32_e32 v175, 0                                      // 00000014E87C: 7F5E0280
	v_add3_u32 v176, v172, v174, 0x7fff                        // 00000014E880: D65500B0 03FF5DAC 00007FFF
	v_mov_b32_e32 v174, 0                                      // 00000014E88C: 7F5C0280
	ds_store_b16_d16_hi v157, v176 offset:22                   // 00000014E890: DA840016 0000B09D
	s_and_saveexec_b32 s7, s15                                 // 00000014E898: BE87200F
	s_cbranch_execz 29                                         // 00000014E89C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2414>
	ds_load_b32 v175, v156 offset:48                           // 00000014E8A0: D8D80030 AF00009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E8A8: BF89FC07
	v_sub_f32_e32 v175, v175, v130                             // 00000014E8AC: 095F05AF
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E8B0: BF870091
	v_mul_f32_e32 v176, 0x3fb8aa3b, v175                       // 00000014E8B4: 11615EFF 3FB8AA3B
	v_fma_f32 v177, 0x3fb8aa3b, v175, -v176                    // 00000014E8BC: D61300B1 86C35EFF 3FB8AA3B
	v_rndne_f32_e32 v178, v176                                 // 00000014E8C8: 7F6447B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E8CC: BF870091
	v_dual_fmac_f32 v177, 0x32a5705f, v175 :: v_dual_sub_f32 v176, v176, v178// 00000014E8D0: C80B5EFF B1B165B0 32A5705F
	v_add_f32_e32 v176, v176, v177                             // 00000014E8DC: 076163B0
	v_cvt_i32_f32_e32 v177, v178                               // 00000014E8E0: 7F6211B2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v175                 // 00000014E8E4: 7C375EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014E8EC: BF870293
	v_exp_f32_e32 v176, v176                                   // 00000014E8F0: 7F604BB0
	.long 0xd71c00b0                                           // 00000014E8F4: D71C00B0
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                   // 00000014E8F8: 020363B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E8FC: BF870121
	v_cndmask_b32_e32 v176, 0, v176, vcc_lo                    // 00000014E900: 03616080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v175                 // 00000014E904: 7C3D5EFF 42B17218
	v_cndmask_b32_e32 v175, 0x7f800000, v176, vcc_lo           // 00000014E90C: 035F60FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E914: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E918: BF870091
	v_bfe_u32 v176, v175, 16, 1                                // 00000014E91C: D61000B0 020521AF
	v_add3_u32 v176, v175, v176, 0x7fff                        // 00000014E924: D65500B0 03FF61AF 00007FFF
	ds_store_b16_d16_hi v157, v176 offset:24                   // 00000014E930: DA840018 0000B09D
	s_and_saveexec_b32 s7, s13                                 // 00000014E938: BE87200D
	s_cbranch_execz 30                                         // 00000014E93C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x24b8>
	ds_load_b32 v174, v156 offset:52                           // 00000014E940: D8D80034 AE00009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E948: BF89FC07
	v_sub_f32_e32 v174, v174, v130                             // 00000014E94C: 095D05AE
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E950: BF870121
	v_mul_f32_e32 v176, 0x3fb8aa3b, v174                       // 00000014E954: 11615CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v174                 // 00000014E95C: 7C375CFF C2CE8ED0
	v_fma_f32 v177, 0x3fb8aa3b, v174, -v176                    // 00000014E964: D61300B1 86C35CFF 3FB8AA3B
	v_rndne_f32_e32 v178, v176                                 // 00000014E970: 7F6447B0
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014E974: BF870112
	v_fmac_f32_e32 v177, 0x32a5705f, v174                      // 00000014E978: 57635CFF 32A5705F
	v_sub_f32_e32 v176, v176, v178                             // 00000014E980: 096165B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E984: BF870121
	v_add_f32_e32 v176, v176, v177                             // 00000014E988: 076163B0
	v_cvt_i32_f32_e32 v177, v178                               // 00000014E98C: 7F6211B2
	v_exp_f32_e32 v176, v176                                   // 00000014E990: 7F604BB0
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E994: BF870095
	.long 0xd71c00b0                                           // 00000014E998: D71C00B0
	v_cndmask_b32_e32 v1, v176, v177, vcc_lo                   // 00000014E99C: 020363B0
	v_cndmask_b32_e32 v176, 0, v176, vcc_lo                    // 00000014E9A0: 03616080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v174                 // 00000014E9A4: 7C3D5CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000014E9AC: BF870002
	v_cndmask_b32_e32 v174, 0x7f800000, v176, vcc_lo           // 00000014E9B0: 035D60FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014E9B8: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014E9BC: BF870121
	v_bfe_u32 v176, v174, 16, 1                                // 00000014E9C0: D61000B0 020521AE
	v_mov_b32_e32 v177, 0                                      // 00000014E9C8: 7F620280
	v_add3_u32 v178, v174, v176, 0x7fff                        // 00000014E9CC: D65500B2 03FF61AE 00007FFF
	v_mov_b32_e32 v176, 0                                      // 00000014E9D8: 7F600280
	ds_store_b16_d16_hi v157, v178 offset:26                   // 00000014E9DC: DA84001A 0000B29D
	s_and_saveexec_b32 s7, s9                                  // 00000014E9E4: BE872009
	s_cbranch_execz 30                                         // 00000014E9E8: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2564>
	ds_load_b32 v177, v156 offset:56                           // 00000014E9EC: D8D80038 B100009C
	s_waitcnt lgkmcnt(0)                                       // 00000014E9F4: BF89FC07
	v_sub_f32_e32 v177, v177, v130                             // 00000014E9F8: 096305B1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014E9FC: BF870091
	v_mul_f32_e32 v178, 0x3fb8aa3b, v177                       // 00000014EA00: 116562FF 3FB8AA3B
	v_fma_f32 v179, 0x3fb8aa3b, v177, -v178                    // 00000014EA08: D61300B3 86CB62FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 00000014EA14: 7F6847B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000014EA18: BF870221
	v_sub_f32_e32 v178, v178, v180                             // 00000014EA1C: 096569B2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v177                 // 00000014EA20: 7C3762FF C2CE8ED0
	v_fmac_f32_e32 v179, 0x32a5705f, v177                      // 00000014EA28: 576762FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014EA30: BF870121
	v_add_f32_e32 v178, v178, v179                             // 00000014EA34: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 00000014EA38: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 00000014EA3C: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EA40: BF870095
	.long 0xd71c00b2                                           // 00000014EA44: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 00000014EA48: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 00000014EA4C: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v177                 // 00000014EA50: 7C3D62FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000014EA58: BF870002
	v_cndmask_b32_e32 v177, 0x7f800000, v178, vcc_lo           // 00000014EA5C: 036364FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014EA64: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EA68: BF870091
	v_bfe_u32 v178, v177, 16, 1                                // 00000014EA6C: D61000B2 020521B1
	v_add3_u32 v178, v177, v178, 0x7fff                        // 00000014EA74: D65500B2 03FF65B1 00007FFF
	ds_store_b16_d16_hi v157, v178 offset:28                   // 00000014EA80: DA84001C 0000B29D
	s_and_saveexec_b32 s7, s1                                  // 00000014EA88: BE872001
	s_cbranch_execz 30                                         // 00000014EA8C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2608>
	ds_load_b32 v176, v156 offset:60                           // 00000014EA90: D8D8003C B000009C
	s_waitcnt lgkmcnt(0)                                       // 00000014EA98: BF89FC07
	v_sub_f32_e32 v176, v176, v130                             // 00000014EA9C: 096105B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014EAA0: BF870121
	v_mul_f32_e32 v178, 0x3fb8aa3b, v176                       // 00000014EAA4: 116560FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v176                 // 00000014EAAC: 7C3760FF C2CE8ED0
	v_fma_f32 v179, 0x3fb8aa3b, v176, -v178                    // 00000014EAB4: D61300B3 86CB60FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 00000014EAC0: 7F6847B2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014EAC4: BF870112
	v_fmac_f32_e32 v179, 0x32a5705f, v176                      // 00000014EAC8: 576760FF 32A5705F
	v_sub_f32_e32 v178, v178, v180                             // 00000014EAD0: 096569B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014EAD4: BF870121
	v_add_f32_e32 v178, v178, v179                             // 00000014EAD8: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 00000014EADC: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 00000014EAE0: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EAE4: BF870095
	.long 0xd71c00b2                                           // 00000014EAE8: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 00000014EAEC: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 00000014EAF0: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v176                 // 00000014EAF4: 7C3D60FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000014EAFC: BF870002
	v_cndmask_b32_e32 v176, 0x7f800000, v178, vcc_lo           // 00000014EB00: 036164FF 7F800000
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014EB08: 8C7E077E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000014EB0C: BF8700A1
	v_bfe_u32 v178, v176, 16, 1                                // 00000014EB10: D61000B2 020521B0
	s_mov_b32 s1, exec_lo                                      // 00000014EB18: BE81007E
	v_add3_u32 v179, v176, v178, 0x7fff                        // 00000014EB1C: D65500B3 03FF65B0 00007FFF
	v_mov_b32_e32 v178, 0                                      // 00000014EB28: 7F640280
	ds_store_b16_d16_hi v157, v179 offset:30                   // 00000014EB2C: DA84001E 0000B39D
	v_cmpx_lt_f32_e32 0xefa18f08, v131                         // 00000014EB34: 7D2306FF EFA18F08
	s_cbranch_execz 63565                                      // 00000014EB3C: BFA5F84D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x774>
	v_sub_f32_e32 v131, v131, v130                             // 00000014EB40: 09070583
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EB44: BF870091
	v_mul_f32_e32 v178, 0x3fb8aa3b, v131                       // 00000014EB48: 116506FF 3FB8AA3B
	v_fma_f32 v179, 0x3fb8aa3b, v131, -v178                    // 00000014EB50: D61300B3 86CB06FF 3FB8AA3B
	v_rndne_f32_e32 v180, v178                                 // 00000014EB5C: 7F6847B2
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000014EB60: BF870221
	v_sub_f32_e32 v178, v178, v180                             // 00000014EB64: 096569B2
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 00000014EB68: 7C3706FF C2CE8ED0
	v_fmac_f32_e32 v179, 0x32a5705f, v131                      // 00000014EB70: 576706FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014EB78: BF870121
	v_add_f32_e32 v178, v178, v179                             // 00000014EB7C: 076567B2
	v_cvt_i32_f32_e32 v179, v180                               // 00000014EB80: 7F6611B4
	v_exp_f32_e32 v178, v178                                   // 00000014EB84: 7F644BB2
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EB88: BF870095
	.long 0xd71c00b2                                           // 00000014EB8C: D71C00B2
	v_cndmask_b32_e32 v1, v178, v179, vcc_lo                   // 00000014EB90: 020367B2
	v_cndmask_b32_e32 v178, 0, v178, vcc_lo                    // 00000014EB94: 03656480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 00000014EB98: 7C3D06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000014EBA0: BF870002
	v_cndmask_b32_e32 v178, 0x7f800000, v178, vcc_lo           // 00000014EBA4: 036564FF 7F800000
	s_branch 63537                                             // 00000014EBAC: BFA0F831 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x774>
	v_lshlrev_b32_e32 v0, 2, v150                              // 00000014EBB0: 30012C82
	.long 0xd700008b                                           // 00000014EBB4: D700008B
	v_cndmask_b32_e32 v1, s18, v139, vcc_lo                    // 00000014EBB8: 02031612
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000014EBBC: BF870191
	v_add_co_ci_u32_e64 v140, null, s19, v140, s0              // 00000014EBC0: D5207C8C 00031813
	v_lshl_or_b32 v0, v148, 6, v0                              // 00000014EBC8: D6560000 04010D94
	v_lshlrev_b32_e32 v147, 1, v147                            // 00000014EBD0: 31272681
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000014EBD4: BF870152
	v_add_nc_u32_e32 v133, 0xf000, v0                          // 00000014EBD8: 4B0A00FF 0000F000
	ds_load_2addr_b32 v[141:142], v133 offset0:192 offset1:194 // 00000014EBE0: D8DCC2C0 8D000085
	s_waitcnt lgkmcnt(0)                                       // 00000014EBE8: BF89FC07
	v_div_scale_f32 v143, null, v141, v141, 1.0                // 00000014EBEC: D6FC7C8F 03CB1B8D
	v_div_scale_f32 v145, vcc_lo, 1.0, v141, 1.0               // 00000014EBF4: D6FC6A91 03CB1AF2
	v_rcp_f32_e32 v144, v143                                   // 00000014EBFC: 7F20558F
	s_delay_alu instid0(TRANS32_DEP_1)                         // 00000014EC00: BF870005
	v_fma_f32 v0, -v143, v144, 1.0                             // 00000014EC04: D6130000 23CB218F
	v_lshlrev_b32_e32 v129, 9, v138                            // 00000014EC0C: 31031489
	ds_load_2addr_b32 v[137:138], v133 offset0:196 offset1:198 // 00000014EC10: D8DCC6C4 89000085
	ds_load_2addr_b32 v[135:136], v133 offset0:200 offset1:202 // 00000014EC18: D8DCCAC8 87000085
	ds_load_2addr_b32 v[133:134], v133 offset0:204 offset1:206 // 00000014EC20: D8DCCECC 85000085
	v_fmac_f32_e32 v144, v0, v144                              // 00000014EC28: 57212100
	v_ashrrev_i32_e32 v130, 31, v129                           // 00000014EC2C: 3505029F
	v_or_b32_e32 v0, v149, v150                                // 00000014EC30: 38012D95
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000014EC34: BF870193
	v_mul_f32_e32 v146, v145, v144                             // 00000014EC38: 11252191
	.long 0xd73c0083                                           // 00000014EC3C: D73C0083
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 00000014EC40: 02030281
	.long 0xd7000081                                           // 00000014EC44: D7000081
	v_cndmask_b32_e32 v1, v139, v147, vcc_lo                   // 00000014EC48: 0203278B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000014EC4C: BF870211
	v_add_co_ci_u32_e64 v130, null, 0, v140, s0                // 00000014EC50: D5207C82 00031880
	v_fma_f32 v148, -v143, v146, v145                          // 00000014EC58: D6130094 2647258F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EC60: BF870094
	.long 0xd7000083                                           // 00000014EC64: D7000083
	v_cndmask_b32_e32 v1, s16, v131, vcc_lo                    // 00000014EC68: 02030610
	v_add_co_ci_u32_e64 v132, null, s17, v132, s0              // 00000014EC6C: D5207C84 00030811
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014EC74: BF870123
	v_fmac_f32_e32 v146, v148, v144                            // 00000014EC78: 57252194
	.long 0xd4440000                                           // 00000014EC7C: D4440000
	v_cndmask_b32_e32 v1, s14, v0, vcc_lo                      // 00000014EC80: 0202000E
	v_fma_f32 v139, -v143, v146, v145                          // 00000014EC84: D613008B 2647258F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000014EC8C: BF8700A1
	v_div_fmas_f32 v139, v139, v144, v146                      // 00000014EC90: D637008B 064B218B
	.long 0xd7006a83                                           // 00000014EC98: D7006A83
	v_cndmask_b32_e32 v1, v131, v147, vcc_lo                   // 00000014EC9C: 02032783
	v_add_co_ci_u32_e64 v132, null, 0, v132, vcc_lo            // 00000014ECA0: D5207C84 01AB0880
	s_delay_alu instid0(VALU_DEP_3)                            // 00000014ECA8: BF870003
	v_div_fixup_f32 v139, v139, v141, 1.0                      // 00000014ECAC: D627008B 03CB1B8B
	s_and_saveexec_b32 s1, s0                                  // 00000014ECB4: BE812000
	s_cbranch_execz 70                                         // 00000014ECB8: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x28d4>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014ECBC: BF870112
	v_mad_i64_i32 v[140:141], null, 0x6000, v0, v[131:132]     // 00000014ECC0: D6FF7C8C 060E00FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 00000014ECCC: 10F2F38B
	global_load_u16 v140, v[140:141], off offset:512           // 00000014ECD0: DC4A0200 8C7C008C
	s_waitcnt vmcnt(0)                                         // 00000014ECD8: BF8903F7
	v_lshlrev_b32_e32 v140, 16, v140                           // 00000014ECDC: 31191890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014ECE0: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v140                       // 00000014ECE4: 111B18FF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v140, -v141                    // 00000014ECEC: D613008F 863718FF BFB8AA3B
	v_rndne_f32_e32 v144, v141                                 // 00000014ECF8: 7F20478D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014ECFC: BF870112
	v_fmamk_f32 v143, v140, 0xb2a5705f, v143                   // 00000014ED00: 591F1F8C B2A5705F
	v_sub_f32_e32 v141, v141, v144                             // 00000014ED08: 091B218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000014ED0C: BF8701B1
	v_add_f32_e32 v141, v141, v143                             // 00000014ED10: 071B1F8D
	v_cvt_i32_f32_e32 v143, v144                               // 00000014ED14: 7F1E1190
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v140                 // 00000014ED18: 7C3D18FF 42CE8ED0
	v_exp_f32_e32 v141, v141                                   // 00000014ED20: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014ED24: BF870095
	.long 0xd71c008d                                           // 00000014ED28: D71C008D
	v_cndmask_b32_e32 v1, v141, v143, vcc_lo                   // 00000014ED2C: 02031F8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 00000014ED30: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v140                 // 00000014ED34: 7C3718FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014ED3C: BF870092
	v_cndmask_b32_e32 v140, 0x7f800000, v141, vcc_lo           // 00000014ED40: 03191AFF 7F800000
	v_add_f32_e32 v140, 1.0, v140                              // 00000014ED48: 071918F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014ED4C: BF870091
	v_div_scale_f32 v141, null, v140, v140, v121               // 00000014ED50: D6FC7C8D 05E7198C
	v_rcp_f32_e32 v143, v141                                   // 00000014ED58: 7F1E558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014ED5C: BF870095
	v_fma_f32 v144, -v141, v143, 1.0                           // 00000014ED60: D6130090 23CB1F8D
	v_fmac_f32_e32 v143, v144, v143                            // 00000014ED68: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v140, v121             // 00000014ED6C: D6FC6A90 05E71979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014ED74: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000014ED78: 11231F90
	v_fma_f32 v146, -v141, v145, v144                          // 00000014ED7C: D6130092 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014ED84: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000014ED88: 57231F92
	v_fma_f32 v141, -v141, v145, v144                          // 00000014ED8C: D613008D 2643238D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014ED94: BF870091
	v_div_fmas_f32 v141, v141, v143, v145                      // 00000014ED98: D637008D 06471F8D
	v_div_fixup_f32 v121, v141, v140, v121                     // 00000014EDA0: D6270079 05E7198D
	v_mad_i64_i32 v[140:141], null, 0x3000, v0, v[129:130]     // 00000014EDA8: D6FF7C8C 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EDB4: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 00000014EDB8: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 00000014EDC0: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[140:141], v121, off              // 00000014EDCC: DC960000 007C798C
	s_or_b32 exec_lo, exec_lo, s1                              // 00000014EDD4: 8C7E017E
	v_div_scale_f32 v121, null, v142, v142, 1.0                // 00000014EDD8: D6FC7C79 03CB1D8E
	v_div_scale_f32 v143, vcc_lo, 1.0, v142, 1.0               // 00000014EDE0: D6FC6A8F 03CB1CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014EDE8: BF870292
	v_rcp_f32_e32 v140, v121                                   // 00000014EDEC: 7F185579
	v_fma_f32 v141, -v121, v140, 1.0                           // 00000014EDF0: D613008D 23CB1979
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EDF8: BF870091
	v_fmac_f32_e32 v140, v141, v140                            // 00000014EDFC: 5719198D
	v_mul_f32_e32 v141, v143, v140                             // 00000014EE00: 111B198F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EE04: BF870091
	v_fma_f32 v144, -v121, v141, v143                          // 00000014EE08: D6130090 263F1B79
	v_fmac_f32_e32 v141, v144, v140                            // 00000014EE10: 571B1990
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EE14: BF870091
	v_fma_f32 v121, -v121, v141, v143                          // 00000014EE18: D6130079 263F1B79
	v_div_fmas_f32 v140, v121, v140, v141                      // 00000014EE20: D637008C 06371979
	v_or_b32_e32 v121, 2, v0                                   // 00000014EE28: 38F20082
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014EE2C: BF870112
	v_div_fixup_f32 v140, v140, v142, 1.0                      // 00000014EE30: D627008C 03CB1D8C
	.long 0xd4440001                                           // 00000014EE38: D4440001
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 00000014EE3C: 0202F20E
	s_and_saveexec_b32 s2, s1                                  // 00000014EE40: BE822001
	s_cbranch_execz 69                                         // 00000014EE44: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2a5c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 00000014EE48: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v122, v140, v122                             // 00000014EE54: 10F4F58C
	global_load_u16 v141, v[141:142], off offset:512           // 00000014EE58: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000014EE60: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000014EE64: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EE68: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000014EE6C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000014EE74: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000014EE80: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000014EE84: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000014EE88: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000014EE8C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000014EE94: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014EE9C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000014EEA0: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000014EEA4: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000014EEA8: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EEAC: BF870095
	.long 0xd71c008e                                           // 00000014EEB0: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000014EEB4: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000014EEB8: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000014EEBC: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EEC4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000014EEC8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000014EED0: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EED4: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 00000014EED8: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000014EEE0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EEE4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000014EEE8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000014EEF0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 00000014EEF4: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EEFC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000014EF00: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000014EF04: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EF0C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000014EF10: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000014EF14: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EF1C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000014EF20: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 00000014EF28: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[129:130]   // 00000014EF30: D6FF7C8D 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EF3C: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 00000014EF40: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 00000014EF48: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 00000014EF54: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s2                              // 00000014EF5C: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 00000014EF60: BF89FC27
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 00000014EF64: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 00000014EF6C: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014EF74: BF870292
	v_rcp_f32_e32 v141, v122                                   // 00000014EF78: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 00000014EF7C: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EF84: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000014EF88: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000014EF8C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EF90: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 00000014EF94: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 00000014EF9C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EFA0: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 00000014EFA4: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 00000014EFAC: D637008D 063B1B7A
	v_or_b32_e32 v122, 4, v0                                   // 00000014EFB4: 38F40084
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014EFB8: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 00000014EFBC: D6270089 03CB138D
	.long 0xd4440002                                           // 00000014EFC4: D4440002
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 00000014EFC8: 0202F40E
	s_and_saveexec_b32 s3, s2                                  // 00000014EFCC: BE832002
	s_cbranch_execz 69                                         // 00000014EFD0: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2be8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[131:132]   // 00000014EFD4: D6FF7C8D 060EF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 00000014EFE0: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 00000014EFE4: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000014EFEC: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000014EFF0: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014EFF4: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000014EFF8: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000014F000: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000014F00C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000014F010: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000014F014: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000014F018: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000014F020: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014F028: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000014F02C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000014F030: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000014F034: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F038: BF870095
	.long 0xd71c008e                                           // 00000014F03C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000014F040: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000014F044: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000014F048: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F050: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000014F054: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000014F05C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F060: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 00000014F064: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000014F06C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F070: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000014F074: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000014F07C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 00000014F080: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F088: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000014F08C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000014F090: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F098: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000014F09C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000014F0A0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F0A8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000014F0AC: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 00000014F0B4: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[129:130]   // 00000014F0BC: D6FF7C8D 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F0C8: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 00000014F0CC: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 00000014F0D4: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 00000014F0E0: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s3                              // 00000014F0E8: 8C7E037E
	v_div_scale_f32 v123, null, v138, v138, 1.0                // 00000014F0EC: D6FC7C7B 03CB158A
	v_div_scale_f32 v143, vcc_lo, 1.0, v138, 1.0               // 00000014F0F4: D6FC6A8F 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014F0FC: BF870292
	v_rcp_f32_e32 v141, v123                                   // 00000014F100: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 00000014F104: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F10C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000014F110: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000014F114: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F118: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 00000014F11C: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 00000014F124: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F128: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 00000014F12C: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 00000014F134: D637008D 063B1B7B
	v_or_b32_e32 v123, 6, v0                                   // 00000014F13C: 38F60086
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014F140: BF870112
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 00000014F144: D627008A 03CB158D
	.long 0xd4440003                                           // 00000014F14C: D4440003
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 00000014F150: 0202F60E
	s_and_saveexec_b32 s4, s3                                  // 00000014F154: BE842003
	s_cbranch_execz 69                                         // 00000014F158: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2d70>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[131:132]   // 00000014F15C: D6FF7C8D 060EF6FF 00006000
	v_mul_f32_e32 v124, v138, v124                             // 00000014F168: 10F8F98A
	global_load_u16 v141, v[141:142], off offset:512           // 00000014F16C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000014F174: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000014F178: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F17C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000014F180: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000014F188: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000014F194: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000014F198: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000014F19C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000014F1A0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000014F1A8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014F1B0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000014F1B4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000014F1B8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000014F1BC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F1C0: BF870095
	.long 0xd71c008e                                           // 00000014F1C4: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000014F1C8: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000014F1CC: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000014F1D0: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F1D8: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000014F1DC: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000014F1E4: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F1E8: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 00000014F1EC: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 00000014F1F4: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F1F8: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000014F1FC: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000014F204: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 00000014F208: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F210: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000014F214: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000014F218: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F220: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000014F224: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000014F228: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F230: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000014F234: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 00000014F23C: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[129:130]   // 00000014F244: D6FF7C8D 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F250: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 00000014F254: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 00000014F25C: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 00000014F268: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000014F270: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 00000014F274: BF89FC17
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 00000014F278: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 00000014F280: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014F288: BF870292
	v_rcp_f32_e32 v141, v124                                   // 00000014F28C: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 00000014F290: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F298: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000014F29C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000014F2A0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F2A4: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 00000014F2A8: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 00000014F2B0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F2B4: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 00000014F2B8: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 00000014F2C0: D637008D 063B1B7C
	v_or_b32_e32 v124, 8, v0                                   // 00000014F2C8: 38F80088
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014F2CC: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 00000014F2D0: D6270087 03CB0F8D
	.long 0xd4440004                                           // 00000014F2D8: D4440004
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 00000014F2DC: 0202F80E
	s_and_saveexec_b32 s5, s4                                  // 00000014F2E0: BE852004
	s_cbranch_execz 69                                         // 00000014F2E4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2efc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[131:132]   // 00000014F2E8: D6FF7C8D 060EF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 00000014F2F4: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 00000014F2F8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000014F300: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000014F304: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F308: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000014F30C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000014F314: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000014F320: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000014F324: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000014F328: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000014F32C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000014F334: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014F33C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000014F340: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000014F344: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000014F348: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F34C: BF870095
	.long 0xd71c008e                                           // 00000014F350: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000014F354: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000014F358: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000014F35C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F364: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000014F368: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000014F370: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F374: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 00000014F378: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 00000014F380: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F384: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000014F388: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000014F390: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 00000014F394: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F39C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000014F3A0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000014F3A4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F3AC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000014F3B0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000014F3B4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F3BC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000014F3C0: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 00000014F3C8: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[129:130]   // 00000014F3D0: D6FF7C8D 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F3DC: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 00000014F3E0: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 00000014F3E8: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 00000014F3F4: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s5                              // 00000014F3FC: 8C7E057E
	v_div_scale_f32 v125, null, v136, v136, 1.0                // 00000014F400: D6FC7C7D 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 00000014F408: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014F410: BF870292
	v_rcp_f32_e32 v141, v125                                   // 00000014F414: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 00000014F418: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F420: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000014F424: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000014F428: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F42C: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 00000014F430: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 00000014F438: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F43C: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 00000014F440: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 00000014F448: D637008D 063B1B7D
	v_or_b32_e32 v125, 10, v0                                  // 00000014F450: 38FA008A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014F454: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 00000014F458: D6270088 03CB118D
	.long 0xd4440005                                           // 00000014F460: D4440005
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 00000014F464: 0202FA0E
	s_and_saveexec_b32 s6, s5                                  // 00000014F468: BE862005
	s_cbranch_execz 69                                         // 00000014F46C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3084>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[131:132]   // 00000014F470: D6FF7C8D 060EFAFF 00006000
	v_mul_f32_e32 v126, v136, v126                             // 00000014F47C: 10FCFD88
	global_load_u16 v141, v[141:142], off offset:512           // 00000014F480: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000014F488: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000014F48C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F490: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000014F494: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000014F49C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000014F4A8: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000014F4AC: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000014F4B0: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000014F4B4: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000014F4BC: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014F4C4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000014F4C8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000014F4CC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000014F4D0: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F4D4: BF870095
	.long 0xd71c008e                                           // 00000014F4D8: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000014F4DC: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000014F4E0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000014F4E4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F4EC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000014F4F0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000014F4F8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F4FC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 00000014F500: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000014F508: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F50C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000014F510: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000014F518: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 00000014F51C: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F524: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000014F528: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000014F52C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F534: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000014F538: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000014F53C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F544: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000014F548: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 00000014F550: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[129:130]   // 00000014F558: D6FF7C8D 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F564: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 00000014F568: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 00000014F570: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 00000014F57C: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s6                              // 00000014F584: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000014F588: BF89FC07
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 00000014F58C: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 00000014F594: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014F59C: BF870292
	v_rcp_f32_e32 v141, v126                                   // 00000014F5A0: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 00000014F5A4: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F5AC: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000014F5B0: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000014F5B4: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F5B8: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 00000014F5BC: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 00000014F5C4: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F5C8: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 00000014F5CC: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 00000014F5D4: D637008D 063B1B7E
	v_or_b32_e32 v126, 12, v0                                  // 00000014F5DC: 38FC008C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014F5E0: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 00000014F5E4: D6270085 03CB0B8D
	.long 0xd4440006                                           // 00000014F5EC: D4440006
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 00000014F5F0: 0202FC0E
	s_and_saveexec_b32 s7, s6                                  // 00000014F5F4: BE872006
	s_cbranch_execz 69                                         // 00000014F5F8: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3210>
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[131:132]   // 00000014F5FC: D6FF7C8D 060EFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 00000014F608: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 00000014F60C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000014F614: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000014F618: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F61C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000014F620: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000014F628: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000014F634: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000014F638: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000014F63C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000014F640: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000014F648: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014F650: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000014F654: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000014F658: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000014F65C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F660: BF870095
	.long 0xd71c008e                                           // 00000014F664: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000014F668: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000014F66C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000014F670: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F678: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000014F67C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000014F684: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F688: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 00000014F68C: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000014F694: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F698: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000014F69C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000014F6A4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 00000014F6A8: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F6B0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000014F6B4: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000014F6B8: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F6C0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000014F6C4: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000014F6C8: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F6D0: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000014F6D4: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 00000014F6DC: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[129:130]   // 00000014F6E4: D6FF7C8D 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F6F0: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 00000014F6F4: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 00000014F6FC: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 00000014F708: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s7                              // 00000014F710: 8C7E077E
	v_div_scale_f32 v127, null, v134, v134, 1.0                // 00000014F714: D6FC7C7F 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 00000014F71C: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000014F724: BF870292
	v_rcp_f32_e32 v141, v127                                   // 00000014F728: 7F1A557F
	v_fma_f32 v142, -v127, v141, 1.0                           // 00000014F72C: D613008E 23CB1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F734: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000014F738: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000014F73C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F740: BF870091
	v_fma_f32 v144, -v127, v142, v143                          // 00000014F744: D6130090 263F1D7F
	v_fmac_f32_e32 v142, v144, v141                            // 00000014F74C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014F750: BF870091
	v_fma_f32 v127, -v127, v142, v143                          // 00000014F754: D613007F 263F1D7F
	v_div_fmas_f32 v141, v127, v141, v142                      // 00000014F75C: D637008D 063B1B7F
	v_or_b32_e32 v127, 14, v0                                  // 00000014F764: 38FE008E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000014F768: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 00000014F76C: D6270086 03CB0D8D
	.long 0xd4440007                                           // 00000014F774: D4440007
	v_cndmask_b32_e32 v1, s14, v127, vcc_lo                    // 00000014F778: 0202FE0E
	s_and_saveexec_b32 s8, s7                                  // 00000014F77C: BE882007
	s_cbranch_execnz 363                                       // 00000014F780: BFA6016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3830>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F784: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014F788: BE882000
	s_cbranch_execnz 432                                       // 00000014F78C: BFA601B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3950>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F790: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014F794: BE882001
	s_cbranch_execnz 501                                       // 00000014F798: BFA601F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a70>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F79C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000014F7A0: BE882002
	s_cbranch_execnz 570                                       // 00000014F7A4: BFA6023A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b90>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F7A8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014F7AC: BE882003
	s_cbranch_execnz 639                                       // 00000014F7B0: BFA6027F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3cb0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F7B4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000014F7B8: BE882004
	s_cbranch_execnz 708                                       // 00000014F7BC: BFA602C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3dd0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F7C0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000014F7C4: BE882005
	s_cbranch_execnz 777                                       // 00000014F7C8: BFA60309 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ef0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F7CC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000014F7D0: BE882006
	s_cbranch_execnz 846                                       // 00000014F7D4: BFA6034E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4010>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F7D8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000014F7DC: BE882007
	s_cbranch_execnz 915                                       // 00000014F7E0: BFA60393 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4130>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F7E4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014F7E8: BE882000
	s_cbranch_execnz 984                                       // 00000014F7EC: BFA603D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4250>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F7F0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014F7F4: BE882001
	s_cbranch_execnz 1053                                      // 00000014F7F8: BFA6041D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4370>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F7FC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000014F800: BE882002
	s_cbranch_execnz 1122                                      // 00000014F804: BFA60462 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4490>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F808: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014F80C: BE882003
	s_cbranch_execnz 1191                                      // 00000014F810: BFA604A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x45b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F814: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000014F818: BE882004
	s_cbranch_execnz 1260                                      // 00000014F81C: BFA604EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x46d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F820: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000014F824: BE882005
	s_cbranch_execnz 1329                                      // 00000014F828: BFA60531 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x47f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F82C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000014F830: BE882006
	s_cbranch_execnz 1398                                      // 00000014F834: BFA60576 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4910>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F838: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000014F83C: BE882007
	s_cbranch_execnz 1467                                      // 00000014F840: BFA605BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4a30>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F844: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014F848: BE882000
	s_cbranch_execnz 1536                                      // 00000014F84C: BFA60600 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4b50>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F850: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014F854: BE882001
	s_cbranch_execnz 1605                                      // 00000014F858: BFA60645 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4c70>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F85C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000014F860: BE882002
	s_cbranch_execnz 1674                                      // 00000014F864: BFA6068A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4d90>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F868: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014F86C: BE882003
	s_cbranch_execnz 1743                                      // 00000014F870: BFA606CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4eb0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F874: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000014F878: BE882004
	s_cbranch_execnz 1812                                      // 00000014F87C: BFA60714 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4fd0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F880: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000014F884: BE882005
	s_cbranch_execnz 1881                                      // 00000014F888: BFA60759 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x50f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F88C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000014F890: BE882006
	s_cbranch_execnz 1950                                      // 00000014F894: BFA6079E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5210>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F898: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000014F89C: BE882007
	s_cbranch_execnz 2019                                      // 00000014F8A0: BFA607E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5330>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F8A4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014F8A8: BE882000
	s_cbranch_execnz 2088                                      // 00000014F8AC: BFA60828 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5450>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F8B0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014F8B4: BE882001
	s_cbranch_execnz 2157                                      // 00000014F8B8: BFA6086D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5570>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F8BC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000014F8C0: BE882002
	s_cbranch_execnz 2226                                      // 00000014F8C4: BFA608B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5690>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F8C8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014F8CC: BE882003
	s_cbranch_execnz 2295                                      // 00000014F8D0: BFA608F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x57b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F8D4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000014F8D8: BE882004
	s_cbranch_execnz 2364                                      // 00000014F8DC: BFA6093C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x58d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F8E0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000014F8E4: BE882005
	s_cbranch_execnz 2433                                      // 00000014F8E8: BFA60981 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x59f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F8EC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000014F8F0: BE882006
	s_cbranch_execnz 2502                                      // 00000014F8F4: BFA609C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5b10>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F8F8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000014F8FC: BE882007
	s_cbranch_execnz 2571                                      // 00000014F900: BFA60A0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5c30>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F904: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014F908: BE882000
	s_cbranch_execnz 2640                                      // 00000014F90C: BFA60A50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5d50>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F910: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014F914: BE882001
	s_cbranch_execnz 2709                                      // 00000014F918: BFA60A95 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5e70>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F91C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000014F920: BE882002
	s_cbranch_execnz 2778                                      // 00000014F924: BFA60ADA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5f90>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F928: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014F92C: BE882003
	s_cbranch_execnz 2847                                      // 00000014F930: BFA60B1F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x60b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F934: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000014F938: BE882004
	s_cbranch_execnz 2916                                      // 00000014F93C: BFA60B64 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x61d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F940: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000014F944: BE882005
	s_cbranch_execnz 2985                                      // 00000014F948: BFA60BA9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x62f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F94C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000014F950: BE882006
	s_cbranch_execnz 3054                                      // 00000014F954: BFA60BEE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6410>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F958: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000014F95C: BE882007
	s_cbranch_execnz 3123                                      // 00000014F960: BFA60C33 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6530>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F964: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014F968: BE882000
	s_cbranch_execnz 3192                                      // 00000014F96C: BFA60C78 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6650>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F970: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014F974: BE882001
	s_cbranch_execnz 3261                                      // 00000014F978: BFA60CBD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6770>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F97C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000014F980: BE882002
	s_cbranch_execnz 3330                                      // 00000014F984: BFA60D02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6890>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F988: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014F98C: BE882003
	s_cbranch_execnz 3399                                      // 00000014F990: BFA60D47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x69b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F994: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000014F998: BE882004
	s_cbranch_execnz 3468                                      // 00000014F99C: BFA60D8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6ad0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F9A0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000014F9A4: BE882005
	s_cbranch_execnz 3537                                      // 00000014F9A8: BFA60DD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6bf0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F9AC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000014F9B0: BE882006
	s_cbranch_execnz 3606                                      // 00000014F9B4: BFA60E16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6d10>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F9B8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000014F9BC: BE882007
	s_cbranch_execnz 3675                                      // 00000014F9C0: BFA60E5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6e30>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F9C4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014F9C8: BE882000
	s_cbranch_execnz 3744                                      // 00000014F9CC: BFA60EA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6f50>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F9D0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014F9D4: BE882001
	s_cbranch_execnz 3813                                      // 00000014F9D8: BFA60EE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7070>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F9DC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000014F9E0: BE882002
	s_cbranch_execnz 3882                                      // 00000014F9E4: BFA60F2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7190>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F9E8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014F9EC: BE882003
	s_cbranch_execnz 3951                                      // 00000014F9F0: BFA60F6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x72b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014F9F4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000014F9F8: BE882004
	s_cbranch_execnz 4020                                      // 00000014F9FC: BFA60FB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x73d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FA00: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000014FA04: BE882005
	s_cbranch_execnz 4089                                      // 00000014FA08: BFA60FF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x74f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FA0C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000014FA10: BE882006
	s_cbranch_execnz 4158                                      // 00000014FA14: BFA6103E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7610>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FA18: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000014FA1C: BE882007
	s_cbranch_execnz 4227                                      // 00000014FA20: BFA61083 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7730>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FA24: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014FA28: BE882000
	s_cbranch_execnz 4296                                      // 00000014FA2C: BFA610C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7850>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FA30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014FA34: BE882001
	s_cbranch_execnz 4365                                      // 00000014FA38: BFA6110D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7970>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FA3C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000014FA40: BE882002
	s_cbranch_execnz 4434                                      // 00000014FA44: BFA61152 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7a90>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FA48: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014FA4C: BE882003
	s_cbranch_execnz 4503                                      // 00000014FA50: BFA61197 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7bb0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FA54: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000014FA58: BE882004
	s_cbranch_execnz 4572                                      // 00000014FA5C: BFA611DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7cd0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FA60: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000014FA64: BE882005
	s_cbranch_execnz 4641                                      // 00000014FA68: BFA61221 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7df0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FA6C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000014FA70: BE882006
	s_cbranch_execnz 4710                                      // 00000014FA74: BFA61266 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7f10>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FA78: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000014FA7C: BE882007
	s_cbranch_execnz 4779                                      // 00000014FA80: BFA612AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8030>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FA84: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014FA88: BE882000
	s_cbranch_execnz 4848                                      // 00000014FA8C: BFA612F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8150>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FA90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014FA94: BE882001
	s_cbranch_execnz 4917                                      // 00000014FA98: BFA61335 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8270>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FA9C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000014FAA0: BE882002
	s_cbranch_execnz 4986                                      // 00000014FAA4: BFA6137A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8390>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FAA8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014FAAC: BE882003
	s_cbranch_execnz 5055                                      // 00000014FAB0: BFA613BF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x84b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FAB4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000014FAB8: BE882004
	s_cbranch_execnz 5124                                      // 00000014FABC: BFA61404 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x85d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FAC0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000014FAC4: BE882005
	s_cbranch_execnz 5193                                      // 00000014FAC8: BFA61449 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x86f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FACC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000014FAD0: BE882006
	s_cbranch_execnz 5262                                      // 00000014FAD4: BFA6148E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8810>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FAD8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000014FADC: BE882007
	s_cbranch_execnz 5331                                      // 00000014FAE0: BFA614D3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8930>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FAE4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014FAE8: BE882000
	s_cbranch_execnz 5400                                      // 00000014FAEC: BFA61518 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8a50>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FAF0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014FAF4: BE882001
	s_cbranch_execnz 5469                                      // 00000014FAF8: BFA6155D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b70>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FAFC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000014FB00: BE882002
	s_cbranch_execnz 5538                                      // 00000014FB04: BFA615A2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8c90>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FB08: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014FB0C: BE882003
	s_cbranch_execnz 5607                                      // 00000014FB10: BFA615E7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8db0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FB14: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000014FB18: BE882004
	s_cbranch_execnz 5676                                      // 00000014FB1C: BFA6162C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8ed0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FB20: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000014FB24: BE882005
	s_cbranch_execnz 5745                                      // 00000014FB28: BFA61671 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8ff0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FB2C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000014FB30: BE882006
	s_cbranch_execnz 5814                                      // 00000014FB34: BFA616B6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9110>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FB38: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000014FB3C: BE882007
	s_cbranch_execnz 5883                                      // 00000014FB40: BFA616FB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9230>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FB44: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014FB48: BE882000
	s_cbranch_execnz 5952                                      // 00000014FB4C: BFA61740 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9350>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FB50: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014FB54: BE882001
	s_cbranch_execnz 6021                                      // 00000014FB58: BFA61785 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9470>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FB5C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000014FB60: BE882002
	s_cbranch_execnz 6090                                      // 00000014FB64: BFA617CA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9590>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FB68: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014FB6C: BE882003
	s_cbranch_execnz 6159                                      // 00000014FB70: BFA6180F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x96b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FB74: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000014FB78: BE882004
	s_cbranch_execnz 6228                                      // 00000014FB7C: BFA61854 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x97d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FB80: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000014FB84: BE882005
	s_cbranch_execnz 6297                                      // 00000014FB88: BFA61899 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x98f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FB8C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000014FB90: BE882006
	s_cbranch_execnz 6366                                      // 00000014FB94: BFA618DE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9a10>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FB98: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000014FB9C: BE882007
	s_cbranch_execnz 6435                                      // 00000014FBA0: BFA61923 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9b30>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FBA4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014FBA8: BE882000
	s_cbranch_execnz 6504                                      // 00000014FBAC: BFA61968 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9c50>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FBB0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014FBB4: BE882001
	s_cbranch_execnz 6573                                      // 00000014FBB8: BFA619AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9d70>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FBBC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000014FBC0: BE882002
	s_cbranch_execnz 6642                                      // 00000014FBC4: BFA619F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9e90>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FBC8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014FBCC: BE882003
	s_cbranch_execnz 6711                                      // 00000014FBD0: BFA61A37 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9fb0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FBD4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000014FBD8: BE882004
	s_cbranch_execnz 6780                                      // 00000014FBDC: BFA61A7C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa0d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FBE0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000014FBE4: BE882005
	s_cbranch_execnz 6849                                      // 00000014FBE8: BFA61AC1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa1f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FBEC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000014FBF0: BE882006
	s_cbranch_execnz 6918                                      // 00000014FBF4: BFA61B06 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa310>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FBF8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000014FBFC: BE882007
	s_cbranch_execnz 6987                                      // 00000014FC00: BFA61B4B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa430>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FC04: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014FC08: BE882000
	s_cbranch_execnz 7056                                      // 00000014FC0C: BFA61B90 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa550>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FC10: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014FC14: BE882001
	s_cbranch_execnz 7125                                      // 00000014FC18: BFA61BD5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa670>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FC1C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000014FC20: BE882002
	s_cbranch_execnz 7194                                      // 00000014FC24: BFA61C1A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa790>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FC28: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014FC2C: BE882003
	s_cbranch_execnz 7263                                      // 00000014FC30: BFA61C5F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa8b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FC34: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000014FC38: BE882004
	s_cbranch_execnz 7332                                      // 00000014FC3C: BFA61CA4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa9d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FC40: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000014FC44: BE882005
	s_cbranch_execnz 7401                                      // 00000014FC48: BFA61CE9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaaf0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FC4C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000014FC50: BE882006
	s_cbranch_execnz 7470                                      // 00000014FC54: BFA61D2E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac10>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FC58: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000014FC5C: BE882007
	s_cbranch_execnz 7539                                      // 00000014FC60: BFA61D73 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xad30>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FC64: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014FC68: BE882000
	s_cbranch_execnz 7608                                      // 00000014FC6C: BFA61DB8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xae50>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FC70: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014FC74: BE882001
	s_cbranch_execnz 7677                                      // 00000014FC78: BFA61DFD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaf70>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FC7C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000014FC80: BE882002
	s_cbranch_execnz 7746                                      // 00000014FC84: BFA61E42 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb090>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FC88: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000014FC8C: BE882003
	s_cbranch_execnz 7815                                      // 00000014FC90: BFA61E87 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb1b0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FC94: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000014FC98: BE882004
	s_cbranch_execnz 7884                                      // 00000014FC9C: BFA61ECC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb2d0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FCA0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000014FCA4: BE882005
	s_cbranch_execnz 7953                                      // 00000014FCA8: BFA61F11 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb3f0>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FCAC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000014FCB0: BE882006
	s_cbranch_execnz 8022                                      // 00000014FCB4: BFA61F56 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb510>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FCB8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000014FCBC: BE882007
	s_cbranch_execnz 8091                                      // 00000014FCC0: BFA61F9B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb630>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FCC4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014FCC8: BE882000
	s_cbranch_execnz 8160                                      // 00000014FCCC: BFA61FE0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb750>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FCD0: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000014FCD4: BE802001
	s_cbranch_execnz 8229                                      // 00000014FCD8: BFA62025 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb870>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014FCDC: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000014FCE0: BE802002
	s_cbranch_execnz 8298                                      // 00000014FCE4: BFA6206A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb990>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014FCE8: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000014FCEC: BE802003
	s_cbranch_execnz 8367                                      // 00000014FCF0: BFA620AF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbab0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014FCF4: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000014FCF8: BE802004
	s_cbranch_execnz 8436                                      // 00000014FCFC: BFA620F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbbd0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014FD00: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000014FD04: BE802005
	s_cbranch_execnz 8505                                      // 00000014FD08: BFA62139 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbcf0>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014FD0C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000014FD10: BE802006
	s_cbranch_execnz 8574                                      // 00000014FD14: BFA6217E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbe10>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000014FD18: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000014FD1C: BE802007
	s_cbranch_execnz 8643                                      // 00000014FD20: BFA621C3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbf30>
	s_nop 0                                                    // 00000014FD24: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000014FD28: BFB60003
	s_endpgm                                                   // 00000014FD2C: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v127, v[131:132]   // 00000014FD30: D6FF7C8D 060EFEFF 00006000
	v_mul_f32_e32 v128, v134, v128                             // 00000014FD3C: 11010186
	global_load_u16 v141, v[141:142], off offset:512           // 00000014FD40: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000014FD48: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000014FD4C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FD50: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000014FD54: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000014FD5C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000014FD68: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000014FD6C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000014FD70: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000014FD74: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000014FD7C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014FD84: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000014FD88: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000014FD8C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000014FD90: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FD94: BF870095
	.long 0xd71c008e                                           // 00000014FD98: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000014FD9C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000014FDA0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000014FDA4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FDAC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000014FDB0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000014FDB8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FDBC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v128               // 00000014FDC0: D6FC7C8E 06031B8D
	v_rcp_f32_e32 v143, v142                                   // 00000014FDC8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FDCC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000014FDD0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000014FDD8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v128, v141, v128             // 00000014FDDC: D6FC6A90 06031B80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FDE4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000014FDE8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000014FDEC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FDF4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000014FDF8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000014FDFC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FE04: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000014FE08: D637008E 06471F8E
	v_div_fixup_f32 v128, v142, v141, v128                     // 00000014FE10: D6270080 06031B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v127, v[129:130]   // 00000014FE18: D6FF7C8D 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FE24: BF870092
	v_bfe_u32 v143, v128, 16, 1                                // 00000014FE28: D610008F 02052180
	v_add3_u32 v128, v128, v143, 0x7fff                        // 00000014FE30: D6550080 03FF1F80 00007FFF
	global_store_d16_hi_b16 v[141:142], v128, off              // 00000014FE3C: DC960000 007C808D
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FE44: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000014FE48: BE882000
	s_cbranch_execz 65104                                      // 00000014FE4C: BFA5FE50 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3290>
	v_mad_i64_i32 v[141:142], null, 0x6000, v0, v[131:132]     // 00000014FE50: D6FF7C8D 060E00FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 00000014FE5C: 10E2E38B
	global_load_u16 v128, v[141:142], off offset:544           // 00000014FE60: DC4A0220 807C008D
	s_waitcnt vmcnt(0)                                         // 00000014FE68: BF8903F7
	v_lshlrev_b32_e32 v128, 16, v128                           // 00000014FE6C: 31010090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FE70: BF870091
	v_mul_f32_e32 v141, 0xbfb8aa3b, v128                       // 00000014FE74: 111B00FF BFB8AA3B
	v_fma_f32 v142, 0xbfb8aa3b, v128, -v141                    // 00000014FE7C: D613008E 863700FF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 00000014FE88: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000014FE8C: BF870221
	v_sub_f32_e32 v141, v141, v143                             // 00000014FE90: 091B1F8D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v128                 // 00000014FE94: 7C3D00FF 42CE8ED0
	v_fmamk_f32 v142, v128, 0xb2a5705f, v142                   // 00000014FE9C: 591D1D80 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014FEA4: BF870121
	v_add_f32_e32 v141, v141, v142                             // 00000014FEA8: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 00000014FEAC: 7F1C118F
	v_exp_f32_e32 v141, v141                                   // 00000014FEB0: 7F1A4B8D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FEB4: BF870095
	.long 0xd71c008d                                           // 00000014FEB8: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 00000014FEBC: 02031D8D
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 00000014FEC0: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v128                 // 00000014FEC4: 7C3700FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FECC: BF870092
	v_cndmask_b32_e32 v128, 0x7f800000, v141, vcc_lo           // 00000014FED0: 03011AFF 7F800000
	v_add_f32_e32 v128, 1.0, v128                              // 00000014FED8: 070100F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FEDC: BF870091
	v_div_scale_f32 v141, null, v128, v128, v113               // 00000014FEE0: D6FC7C8D 05C70180
	v_rcp_f32_e32 v142, v141                                   // 00000014FEE8: 7F1C558D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FEEC: BF870095
	v_fma_f32 v143, -v141, v142, 1.0                           // 00000014FEF0: D613008F 23CB1D8D
	v_fmac_f32_e32 v142, v143, v142                            // 00000014FEF8: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v113, v128, v113             // 00000014FEFC: D6FC6A8F 05C70171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FF04: BF870091
	v_mul_f32_e32 v144, v143, v142                             // 00000014FF08: 11211D8F
	v_fma_f32 v145, -v141, v144, v143                          // 00000014FF0C: D6130091 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FF14: BF870091
	v_fmac_f32_e32 v144, v145, v142                            // 00000014FF18: 57211D91
	v_fma_f32 v141, -v141, v144, v143                          // 00000014FF1C: D613008D 263F218D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FF24: BF870091
	v_div_fmas_f32 v141, v141, v142, v144                      // 00000014FF28: D637008D 06431D8D
	v_div_fixup_f32 v113, v141, v128, v113                     // 00000014FF30: D6270071 05C7018D
	v_mad_i64_i32 v[141:142], null, 0x3000, v0, v[129:130]     // 00000014FF38: D6FF7C8D 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FF44: BF870092
	v_bfe_u32 v128, v113, 16, 1                                // 00000014FF48: D6100080 02052171
	v_add3_u32 v113, v113, v128, 0x7fff                        // 00000014FF50: D6550071 03FF0171 00007FFF
	global_store_d16_hi_b16 v[141:142], v113, off offset:32    // 00000014FF5C: DC960020 007C718D
	s_or_b32 exec_lo, exec_lo, s8                              // 00000014FF64: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000014FF68: BE882001
	s_cbranch_execz 65035                                      // 00000014FF6C: BFA5FE0B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x329c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[131:132]   // 00000014FF70: D6FF7C8D 060EF2FF 00006000
	v_mul_f32_e32 v114, v140, v114                             // 00000014FF7C: 10E4E58C
	global_load_u16 v113, v[141:142], off offset:544           // 00000014FF80: DC4A0220 717C008D
	s_waitcnt vmcnt(0)                                         // 00000014FF88: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000014FF8C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FF90: BF870091
	v_mul_f32_e32 v128, 0xbfb8aa3b, v113                       // 00000014FF94: 1100E2FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v113, -v128                    // 00000014FF9C: D613008D 8602E2FF BFB8AA3B
	v_rndne_f32_e32 v142, v128                                 // 00000014FFA8: 7F1C4780
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000014FFAC: BF870221
	v_sub_f32_e32 v128, v128, v142                             // 00000014FFB0: 09011D80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 00000014FFB4: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v141, v113, 0xb2a5705f, v141                   // 00000014FFBC: 591B1B71 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000014FFC4: BF870121
	v_add_f32_e32 v128, v128, v141                             // 00000014FFC8: 07011B80
	v_cvt_i32_f32_e32 v141, v142                               // 00000014FFCC: 7F1A118E
	v_exp_f32_e32 v128, v128                                   // 00000014FFD0: 7F004B80
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FFD4: BF870095
	.long 0xd71c0080                                           // 00000014FFD8: D71C0080
	v_cndmask_b32_e32 v1, v128, v141, vcc_lo                   // 00000014FFDC: 02031B80
	v_cndmask_b32_e32 v128, 0, v128, vcc_lo                    // 00000014FFE0: 03010080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 00000014FFE4: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FFEC: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v128, vcc_lo           // 00000014FFF0: 02E300FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 00000014FFF8: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000014FFFC: BF870091
	v_div_scale_f32 v128, null, v113, v113, v114               // 000000150000: D6FC7C80 05CAE371
	v_rcp_f32_e32 v141, v128                                   // 000000150008: 7F1A5580
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015000C: BF870095
	v_fma_f32 v142, -v128, v141, 1.0                           // 000000150010: D613008E 23CB1B80
	v_fmac_f32_e32 v141, v142, v141                            // 000000150018: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v114, v113, v114             // 00000015001C: D6FC6A8E 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150024: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 000000150028: 111F1B8E
	v_fma_f32 v144, -v128, v143, v142                          // 00000015002C: D6130090 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150034: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 000000150038: 571F1B90
	v_fma_f32 v128, -v128, v143, v142                          // 00000015003C: D6130080 263B1F80
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150044: BF870091
	v_div_fmas_f32 v128, v128, v141, v143                      // 000000150048: D6370080 063F1B80
	v_div_fixup_f32 v128, v128, v113, v114                     // 000000150050: D6270080 05CAE380
	v_mad_i64_i32 v[113:114], null, 0x3000, v121, v[129:130]   // 000000150058: D6FF7C71 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150064: BF870092
	v_bfe_u32 v141, v128, 16, 1                                // 000000150068: D610008D 02052180
	v_add3_u32 v128, v128, v141, 0x7fff                        // 000000150070: D6550080 03FF1B80 00007FFF
	global_store_d16_hi_b16 v[113:114], v128, off offset:32    // 00000015007C: DC960020 007C8071
	s_or_b32 exec_lo, exec_lo, s8                              // 000000150084: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000150088: BE882002
	s_cbranch_execz 64966                                      // 00000015008C: BFA5FDC6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32a8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v122, v[131:132]   // 000000150090: D6FF7C71 060EF4FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000015009C: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000001500A4: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000001500A8: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001500AC: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000001500B0: 10E4E2FF BFB8AA3B
	v_fma_f32 v128, 0xbfb8aa3b, v113, -v114                    // 0000001500B8: D6130080 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v141, v114                                 // 0000001500C4: 7F1A4772
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001500C8: BF870112
	v_fmamk_f32 v128, v113, 0xb2a5705f, v128                   // 0000001500CC: 59010171 B2A5705F
	v_sub_f32_e32 v114, v114, v141                             // 0000001500D4: 08E51B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001500D8: BF8701B1
	v_add_f32_e32 v114, v114, v128                             // 0000001500DC: 06E50172
	v_cvt_i32_f32_e32 v128, v141                               // 0000001500E0: 7F00118D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000001500E4: 7C3CE2FF 42CE8ED0
	v_exp_f32_e32 v114, v114                                   // 0000001500EC: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001500F0: BF870095
	.long 0xd71c0072                                           // 0000001500F4: D71C0072
	v_cndmask_b32_e32 v1, v114, v128, vcc_lo                   // 0000001500F8: 02030172
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000001500FC: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000150100: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150108: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v137, v115// 00000015010C: CA46E4FF 7172E789 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000150118: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015011C: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000150120: D6FC7C73 05CAE371
	v_rcp_f32_e32 v128, v115                                   // 000000150128: 7F005573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015012C: BF870095
	v_fma_f32 v141, -v115, v128, 1.0                           // 000000150130: D613008D 23CB0173
	v_fmac_f32_e32 v128, v141, v128                            // 000000150138: 5701018D
	v_div_scale_f32 v141, vcc_lo, v114, v113, v114             // 00000015013C: D6FC6A8D 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150144: BF870091
	v_mul_f32_e32 v142, v141, v128                             // 000000150148: 111D018D
	v_fma_f32 v143, -v115, v142, v141                          // 00000015014C: D613008F 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150154: BF870091
	v_fmac_f32_e32 v142, v143, v128                            // 000000150158: 571D018F
	v_fma_f32 v115, -v115, v142, v141                          // 00000015015C: D6130073 26371D73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150164: BF870091
	v_div_fmas_f32 v115, v115, v128, v142                      // 000000150168: D6370073 063B0173
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000150170: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v122, v[129:130]   // 000000150178: D6FF7C71 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150184: BF870092
	v_bfe_u32 v128, v115, 16, 1                                // 000000150188: D6100080 02052173
	v_add3_u32 v115, v115, v128, 0x7fff                        // 000000150190: D6550073 03FF0173 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000015019C: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001501A4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001501A8: BE882003
	s_cbranch_execz 64897                                      // 0000001501AC: BFA5FD81 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32b4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v123, v[131:132]   // 0000001501B0: D6FF7C71 060EF6FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000001501BC: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000001501C4: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000001501C8: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001501CC: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000001501D0: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000001501D8: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v128, v114                                 // 0000001501E4: 7F004772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001501E8: BF870221
	v_sub_f32_e32 v114, v114, v128                             // 0000001501EC: 08E50172
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 0000001501F0: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 0000001501F8: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000150200: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000150204: 06E4E772
	v_cvt_i32_f32_e32 v115, v128                               // 000000150208: 7EE61180
	v_exp_f32_e32 v114, v114                                   // 00000015020C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150210: BF870095
	.long 0xd71c0072                                           // 000000150214: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000150218: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000015021C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000150220: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150228: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v138, v116// 00000015022C: CA46E4FF 7172E98A 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000150238: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015023C: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000150240: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000150248: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015024C: BF870095
	v_fma_f32 v128, -v115, v116, 1.0                           // 000000150250: D6130080 23CAE973
	v_fmac_f32_e32 v116, v128, v116                            // 000000150258: 56E8E980
	v_div_scale_f32 v128, vcc_lo, v114, v113, v114             // 00000015025C: D6FC6A80 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150264: BF870091
	v_mul_f32_e32 v141, v128, v116                             // 000000150268: 111AE980
	v_fma_f32 v142, -v115, v141, v128                          // 00000015026C: D613008E 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150274: BF870091
	v_fmac_f32_e32 v141, v142, v116                            // 000000150278: 571AE98E
	v_fma_f32 v115, -v115, v141, v128                          // 00000015027C: D6130073 26031B73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150284: BF870091
	v_div_fmas_f32 v115, v115, v116, v141                      // 000000150288: D6370073 0636E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000150290: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v123, v[129:130]   // 000000150298: D6FF7C71 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001502A4: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000001502A8: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000001502B0: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000001502BC: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001502C4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001502C8: BE882004
	s_cbranch_execz 64828                                      // 0000001502CC: BFA5FD3C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32c0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v124, v[131:132]   // 0000001502D0: D6FF7C71 060EF8FF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000001502DC: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 0000001502E4: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 0000001502E8: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001502EC: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 0000001502F0: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 0000001502F8: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000150304: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000150308: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000015030C: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000150310: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000150318: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000150320: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000150324: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000150328: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000015032C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150330: BF870095
	.long 0xd71c0072                                           // 000000150334: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000150338: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000015033C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000150340: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150348: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v135, v117// 00000015034C: CA46E4FF 7172EB87 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000150358: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015035C: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000150360: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000150368: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015036C: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 000000150370: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 000000150378: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000015037C: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150384: BF870091
	v_mul_f32_e32 v128, v117, v116                             // 000000150388: 1100E975
	v_fma_f32 v141, -v115, v128, v117                          // 00000015038C: D613008D 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150394: BF870091
	v_fmac_f32_e32 v128, v141, v116                            // 000000150398: 5700E98D
	v_fma_f32 v115, -v115, v128, v117                          // 00000015039C: D6130073 25D70173
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001503A4: BF870091
	v_div_fmas_f32 v115, v115, v116, v128                      // 0000001503A8: D6370073 0602E973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000001503B0: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v124, v[129:130]   // 0000001503B8: D6FF7C71 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001503C4: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000001503C8: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000001503D0: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000001503DC: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001503E4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001503E8: BE882005
	s_cbranch_execz 64759                                      // 0000001503EC: BFA5FCF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32cc>
	v_mad_i64_i32 v[113:114], null, 0x6000, v125, v[131:132]   // 0000001503F0: D6FF7C71 060EFAFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 0000001503FC: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000150404: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000150408: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015040C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000150410: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000150418: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000150424: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000150428: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000015042C: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000150430: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000150438: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000150440: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000150444: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000150448: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000015044C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150450: BF870095
	.long 0xd71c0072                                           // 000000150454: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000150458: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000015045C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000150460: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150468: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 00000015046C: 02E2E4FF 7F800000
	v_dual_mul_f32 v114, v136, v118 :: v_dual_add_f32 v113, 1.0, v113// 000000150474: C8C8ED88 7270E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015047C: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 000000150480: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 000000150488: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015048C: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 000000150490: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 000000150498: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 00000015049C: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001504A4: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000001504A8: 10ECE975
	v_fma_f32 v128, -v115, v118, v117                          // 0000001504AC: D6130080 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001504B4: BF870091
	v_fmac_f32_e32 v118, v128, v116                            // 0000001504B8: 56ECE980
	v_fma_f32 v115, -v115, v118, v117                          // 0000001504BC: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001504C4: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000001504C8: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000001504D0: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v125, v[129:130]   // 0000001504D8: D6FF7C71 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001504E4: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 0000001504E8: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 0000001504F0: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 0000001504FC: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000150504: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000150508: BE882006
	s_cbranch_execz 64690                                      // 00000015050C: BFA5FCB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32d8>
	v_mad_i64_i32 v[113:114], null, 0x6000, v126, v[131:132]   // 000000150510: D6FF7C71 060EFCFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000015051C: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000150524: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000150528: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015052C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000150530: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000150538: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000150544: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000150548: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000015054C: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000150550: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000150558: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000150560: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000150564: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000150568: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000015056C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150570: BF870095
	.long 0xd71c0072                                           // 000000150574: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000150578: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000015057C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 000000150580: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150588: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v133, v119// 00000015058C: CA46E4FF 7172EF85 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 000000150598: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015059C: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000001505A0: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000001505A8: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001505AC: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000001505B0: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000001505B8: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000001505BC: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001505C4: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000001505C8: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000001505CC: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001505D4: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000001505D8: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000001505DC: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001505E4: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 0000001505E8: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 0000001505F0: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v126, v[129:130]   // 0000001505F8: D6FF7C71 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150604: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000150608: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000150610: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000015061C: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000150624: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000150628: BE882007
	s_cbranch_execz 64621                                      // 00000015062C: BFA5FC6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32e4>
	v_mad_i64_i32 v[113:114], null, 0x6000, v127, v[131:132]   // 000000150630: D6FF7C71 060EFEFF 00006000
	global_load_u16 v113, v[113:114], off offset:544           // 00000015063C: DC4A0220 717C0071
	s_waitcnt vmcnt(0)                                         // 000000150644: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 000000150648: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015064C: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000150650: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 000000150658: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000150664: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000150668: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 00000015066C: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000150670: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 000000150678: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000150680: BF870121
	v_add_f32_e32 v114, v114, v115                             // 000000150684: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 000000150688: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 00000015068C: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150690: BF870095
	.long 0xd71c0072                                           // 000000150694: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 000000150698: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 00000015069C: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000001506A0: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001506A8: BF870092
	v_dual_cndmask_b32 v113, 0x7f800000, v114 :: v_dual_mul_f32 v114, v134, v120// 0000001506AC: CA46E4FF 7172F186 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000001506B8: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001506BC: BF870091
	v_div_scale_f32 v115, null, v113, v113, v114               // 0000001506C0: D6FC7C73 05CAE371
	v_rcp_f32_e32 v116, v115                                   // 0000001506C8: 7EE85573
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001506CC: BF870095
	v_fma_f32 v117, -v115, v116, 1.0                           // 0000001506D0: D6130075 23CAE973
	v_fmac_f32_e32 v116, v117, v116                            // 0000001506D8: 56E8E975
	v_div_scale_f32 v117, vcc_lo, v114, v113, v114             // 0000001506DC: D6FC6A75 05CAE372
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001506E4: BF870091
	v_mul_f32_e32 v118, v117, v116                             // 0000001506E8: 10ECE975
	v_fma_f32 v119, -v115, v118, v117                          // 0000001506EC: D6130077 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001506F4: BF870091
	v_fmac_f32_e32 v118, v119, v116                            // 0000001506F8: 56ECE977
	v_fma_f32 v115, -v115, v118, v117                          // 0000001506FC: D6130073 25D6ED73
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150704: BF870091
	v_div_fmas_f32 v115, v115, v116, v118                      // 000000150708: D6370073 05DAE973
	v_div_fixup_f32 v115, v115, v113, v114                     // 000000150710: D6270073 05CAE373
	v_mad_i64_i32 v[113:114], null, 0x3000, v127, v[129:130]   // 000000150718: D6FF7C71 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150724: BF870092
	v_bfe_u32 v116, v115, 16, 1                                // 000000150728: D6100074 02052173
	v_add3_u32 v115, v115, v116, 0x7fff                        // 000000150730: D6550073 03FEE973 00007FFF
	global_store_d16_hi_b16 v[113:114], v115, off offset:32    // 00000015073C: DC960020 007C7371
	s_or_b32 exec_lo, exec_lo, s8                              // 000000150744: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000150748: BE882000
	s_cbranch_execz 64552                                      // 00000015074C: BFA5FC28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32f0>
	v_mad_i64_i32 v[113:114], null, 0x6000, v0, v[131:132]     // 000000150750: D6FF7C71 060E00FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 00000015075C: 10D2D38B
	global_load_u16 v113, v[113:114], off offset:576           // 000000150760: DC4A0240 717C0071
	s_waitcnt vmcnt(0)                                         // 000000150768: BF8903F7
	v_lshlrev_b32_e32 v113, 16, v113                           // 00000015076C: 30E2E290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150770: BF870091
	v_mul_f32_e32 v114, 0xbfb8aa3b, v113                       // 000000150774: 10E4E2FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v113, -v114                    // 00000015077C: D6130073 85CAE2FF BFB8AA3B
	v_rndne_f32_e32 v116, v114                                 // 000000150788: 7EE84772
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000015078C: BF870221
	v_sub_f32_e32 v114, v114, v116                             // 000000150790: 08E4E972
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v113                 // 000000150794: 7C3CE2FF 42CE8ED0
	v_fmamk_f32 v115, v113, 0xb2a5705f, v115                   // 00000015079C: 58E6E771 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001507A4: BF870121
	v_add_f32_e32 v114, v114, v115                             // 0000001507A8: 06E4E772
	v_cvt_i32_f32_e32 v115, v116                               // 0000001507AC: 7EE61174
	v_exp_f32_e32 v114, v114                                   // 0000001507B0: 7EE44B72
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001507B4: BF870095
	.long 0xd71c0072                                           // 0000001507B8: D71C0072
	v_cndmask_b32_e32 v1, v114, v115, vcc_lo                   // 0000001507BC: 0202E772
	v_cndmask_b32_e32 v114, 0, v114, vcc_lo                    // 0000001507C0: 02E4E480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v113                 // 0000001507C4: 7C36E2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001507CC: BF870092
	v_cndmask_b32_e32 v113, 0x7f800000, v114, vcc_lo           // 0000001507D0: 02E2E4FF 7F800000
	v_add_f32_e32 v113, 1.0, v113                              // 0000001507D8: 06E2E2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001507DC: BF870091
	v_div_scale_f32 v114, null, v113, v113, v105               // 0000001507E0: D6FC7C72 05A6E371
	v_rcp_f32_e32 v115, v114                                   // 0000001507E8: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001507EC: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 0000001507F0: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 0000001507F8: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v105, v113, v105             // 0000001507FC: D6FC6A74 05A6E369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150804: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 000000150808: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 00000015080C: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150814: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 000000150818: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 00000015081C: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150824: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 000000150828: D6370072 05D6E772
	v_div_fixup_f32 v105, v114, v113, v105                     // 000000150830: D6270069 05A6E372
	v_mad_i64_i32 v[113:114], null, 0x3000, v0, v[129:130]     // 000000150838: D6FF7C71 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150844: BF870092
	v_bfe_u32 v115, v105, 16, 1                                // 000000150848: D6100073 02052169
	v_add3_u32 v105, v105, v115, 0x7fff                        // 000000150850: D6550069 03FEE769 00007FFF
	global_store_d16_hi_b16 v[113:114], v105, off offset:64    // 00000015085C: DC960040 007C6971
	s_or_b32 exec_lo, exec_lo, s8                              // 000000150864: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000150868: BE882001
	s_cbranch_execz 64483                                      // 00000015086C: BFA5FBE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x32fc>
	v_mad_i64_i32 v[113:114], null, 0x6000, v121, v[131:132]   // 000000150870: D6FF7C71 060EF2FF 00006000
	v_mul_f32_e32 v106, v140, v106                             // 00000015087C: 10D4D58C
	global_load_u16 v105, v[113:114], off offset:576           // 000000150880: DC4A0240 697C0071
	s_waitcnt vmcnt(0)                                         // 000000150888: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000015088C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000150890: BF870121
	v_mul_f32_e32 v113, 0xbfb8aa3b, v105                       // 000000150894: 10E2D2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 00000015089C: 7C3CD2FF 42CE8ED0
	v_fma_f32 v114, 0xbfb8aa3b, v105, -v113                    // 0000001508A4: D6130072 85C6D2FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000001508B0: 7EE64771
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001508B4: BF870112
	v_fmamk_f32 v114, v105, 0xb2a5705f, v114                   // 0000001508B8: 58E4E569 B2A5705F
	v_sub_f32_e32 v113, v113, v115                             // 0000001508C0: 08E2E771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001508C4: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000001508C8: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000001508CC: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000001508D0: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001508D4: BF870095
	.long 0xd71c0071                                           // 0000001508D8: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000001508DC: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000001508E0: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000001508E4: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001508EC: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v113, vcc_lo           // 0000001508F0: 02D2E2FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000001508F8: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001508FC: BF870091
	v_div_scale_f32 v113, null, v105, v105, v106               // 000000150900: D6FC7C71 05AAD369
	v_rcp_f32_e32 v114, v113                                   // 000000150908: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015090C: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 000000150910: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 000000150918: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v106, v105, v106             // 00000015091C: D6FC6A73 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150924: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 000000150928: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 00000015092C: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150934: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 000000150938: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 00000015093C: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150944: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 000000150948: D6370071 05D2E571
	v_div_fixup_f32 v113, v113, v105, v106                     // 000000150950: D6270071 05AAD371
	v_mad_i64_i32 v[105:106], null, 0x3000, v121, v[129:130]   // 000000150958: D6FF7C69 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150964: BF870092
	v_bfe_u32 v114, v113, 16, 1                                // 000000150968: D6100072 02052171
	v_add3_u32 v113, v113, v114, 0x7fff                        // 000000150970: D6550071 03FEE571 00007FFF
	global_store_d16_hi_b16 v[105:106], v113, off offset:64    // 00000015097C: DC960040 007C7169
	s_or_b32 exec_lo, exec_lo, s8                              // 000000150984: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000150988: BE882002
	s_cbranch_execz 64414                                      // 00000015098C: BFA5FB9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3308>
	v_mad_i64_i32 v[105:106], null, 0x6000, v122, v[131:132]   // 000000150990: D6FF7C69 060EF4FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 00000015099C: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 0000001509A4: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 0000001509A8: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001509AC: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 0000001509B0: 10D4D2FF BFB8AA3B
	v_fma_f32 v113, 0xbfb8aa3b, v105, -v106                    // 0000001509B8: D6130071 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v114, v106                                 // 0000001509C4: 7EE4476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001509C8: BF870221
	v_sub_f32_e32 v106, v106, v114                             // 0000001509CC: 08D4E56A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 0000001509D0: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v113, v105, 0xb2a5705f, v113                   // 0000001509D8: 58E2E369 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001509E0: BF870121
	v_add_f32_e32 v106, v106, v113                             // 0000001509E4: 06D4E36A
	v_cvt_i32_f32_e32 v113, v114                               // 0000001509E8: 7EE21172
	v_exp_f32_e32 v106, v106                                   // 0000001509EC: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001509F0: BF870095
	.long 0xd71c006a                                           // 0000001509F4: D71C006A
	v_cndmask_b32_e32 v1, v106, v113, vcc_lo                   // 0000001509F8: 0202E36A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000001509FC: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000150A00: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150A08: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v137, v107// 000000150A0C: CA46D4FF 696AD789 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000150A18: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150A1C: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000150A20: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v113, v107                                   // 000000150A28: 7EE2556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150A2C: BF870095
	v_fma_f32 v114, -v107, v113, 1.0                           // 000000150A30: D6130072 23CAE36B
	v_fmac_f32_e32 v113, v114, v113                            // 000000150A38: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v106, v105, v106             // 000000150A3C: D6FC6A72 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150A44: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 000000150A48: 10E6E372
	v_fma_f32 v116, -v107, v115, v114                          // 000000150A4C: D6130074 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150A54: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 000000150A58: 56E6E374
	v_fma_f32 v107, -v107, v115, v114                          // 000000150A5C: D613006B 25CAE76B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150A64: BF870091
	v_div_fmas_f32 v107, v107, v113, v115                      // 000000150A68: D637006B 05CEE36B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000150A70: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v122, v[129:130]   // 000000150A78: D6FF7C69 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150A84: BF870092
	v_bfe_u32 v113, v107, 16, 1                                // 000000150A88: D6100071 0205216B
	v_add3_u32 v107, v107, v113, 0x7fff                        // 000000150A90: D655006B 03FEE36B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000150A9C: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000150AA4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000150AA8: BE882003
	s_cbranch_execz 64345                                      // 000000150AAC: BFA5FB59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3314>
	v_mad_i64_i32 v[105:106], null, 0x6000, v123, v[131:132]   // 000000150AB0: D6FF7C69 060EF6FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000150ABC: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000150AC4: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000150AC8: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150ACC: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000150AD0: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000150AD8: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v113, v106                                 // 000000150AE4: 7EE2476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150AE8: BF870091
	v_dual_fmamk_f32 v107, v105, 0xb2a5705f, v107 :: v_dual_sub_f32 v106, v106, v113// 000000150AEC: C88AD769 6B6AE36A B2A5705F
	v_add_f32_e32 v106, v106, v107                             // 000000150AF8: 06D4D76A
	v_cvt_i32_f32_e32 v107, v113                               // 000000150AFC: 7ED61171
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000150B00: 7C3CD2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000150B08: BF870293
	v_exp_f32_e32 v106, v106                                   // 000000150B0C: 7ED44B6A
	.long 0xd71c006a                                           // 000000150B10: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000150B14: 0202D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000150B18: BF870121
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000150B1C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000150B20: 7C36D2FF C2B17218
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v138, v108// 000000150B28: CA46D4FF 696AD98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150B34: BF870091
	v_add_f32_e32 v105, 1.0, v105                              // 000000150B38: 06D2D2F2
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000150B3C: D6FC7C6B 05AAD369
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000150B44: BF870291
	v_rcp_f32_e32 v108, v107                                   // 000000150B48: 7ED8556B
	v_fma_f32 v113, -v107, v108, 1.0                           // 000000150B4C: D6130071 23CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000150B54: BF8700A1
	v_fmac_f32_e32 v108, v113, v108                            // 000000150B58: 56D8D971
	v_div_scale_f32 v113, vcc_lo, v106, v105, v106             // 000000150B5C: D6FC6A71 05AAD36A
	v_mul_f32_e32 v114, v113, v108                             // 000000150B64: 10E4D971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150B68: BF870091
	v_fma_f32 v115, -v107, v114, v113                          // 000000150B6C: D6130073 25C6E56B
	v_fmac_f32_e32 v114, v115, v108                            // 000000150B74: 56E4D973
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150B78: BF870091
	v_fma_f32 v107, -v107, v114, v113                          // 000000150B7C: D613006B 25C6E56B
	v_div_fmas_f32 v107, v107, v108, v114                      // 000000150B84: D637006B 05CAD96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000150B8C: BF870121
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000150B90: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v123, v[129:130]   // 000000150B98: D6FF7C69 0606F6FF 00003000
	v_bfe_u32 v108, v107, 16, 1                                // 000000150BA4: D610006C 0205216B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000150BAC: BF870001
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000150BB0: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000150BBC: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000150BC4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000150BC8: BE882004
	s_cbranch_execz 64276                                      // 000000150BCC: BFA5FB14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3320>
	v_mad_i64_i32 v[105:106], null, 0x6000, v124, v[131:132]   // 000000150BD0: D6FF7C69 060EF8FF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000150BDC: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000150BE4: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000150BE8: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150BEC: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000150BF0: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000150BF8: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000150C04: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000150C08: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000150C0C: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000150C10: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000150C18: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000150C20: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000150C24: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000150C28: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000150C2C: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150C30: BF870095
	.long 0xd71c006a                                           // 000000150C34: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000150C38: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000150C3C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000150C40: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150C48: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v135, v109// 000000150C4C: CA46D4FF 696ADB87 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000150C58: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150C5C: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000150C60: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000150C68: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150C6C: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000150C70: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000150C78: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000150C7C: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150C84: BF870091
	v_mul_f32_e32 v113, v109, v108                             // 000000150C88: 10E2D96D
	v_fma_f32 v114, -v107, v113, v109                          // 000000150C8C: D6130072 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150C94: BF870091
	v_fmac_f32_e32 v113, v114, v108                            // 000000150C98: 56E2D972
	v_fma_f32 v107, -v107, v113, v109                          // 000000150C9C: D613006B 25B6E36B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150CA4: BF870091
	v_div_fmas_f32 v107, v107, v108, v113                      // 000000150CA8: D637006B 05C6D96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000150CB0: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v124, v[129:130]   // 000000150CB8: D6FF7C69 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150CC4: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000150CC8: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000150CD0: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000150CDC: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000150CE4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000150CE8: BE882005
	s_cbranch_execz 64207                                      // 000000150CEC: BFA5FACF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x332c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v125, v[131:132]   // 000000150CF0: D6FF7C69 060EFAFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000150CFC: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000150D04: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000150D08: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150D0C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000150D10: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000150D18: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000150D24: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000150D28: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000150D2C: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000150D30: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000150D38: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000150D40: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000150D44: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000150D48: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000150D4C: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150D50: BF870095
	.long 0xd71c006a                                           // 000000150D54: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000150D58: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000150D5C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000150D60: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150D68: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 000000150D6C: 02D2D4FF 7F800000
	v_dual_mul_f32 v106, v136, v110 :: v_dual_add_f32 v105, 1.0, v105// 000000150D74: C8C8DD88 6A68D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150D7C: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000150D80: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000150D88: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150D8C: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000150D90: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000150D98: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000150D9C: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150DA4: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000150DA8: 10DCD96D
	v_fma_f32 v113, -v107, v110, v109                          // 000000150DAC: D6130071 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150DB4: BF870091
	v_fmac_f32_e32 v110, v113, v108                            // 000000150DB8: 56DCD971
	v_fma_f32 v107, -v107, v110, v109                          // 000000150DBC: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150DC4: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000150DC8: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000150DD0: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v125, v[129:130]   // 000000150DD8: D6FF7C69 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150DE4: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000150DE8: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000150DF0: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000150DFC: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000150E04: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000150E08: BE882006
	s_cbranch_execz 64138                                      // 000000150E0C: BFA5FA8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3338>
	v_mad_i64_i32 v[105:106], null, 0x6000, v126, v[131:132]   // 000000150E10: D6FF7C69 060EFCFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000150E1C: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000150E24: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000150E28: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150E2C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000150E30: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000150E38: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000150E44: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000150E48: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000150E4C: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000150E50: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000150E58: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000150E60: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000150E64: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000150E68: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000150E6C: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150E70: BF870095
	.long 0xd71c006a                                           // 000000150E74: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000150E78: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000150E7C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000150E80: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150E88: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v133, v111// 000000150E8C: CA46D4FF 696ADF85 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000150E98: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150E9C: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000150EA0: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000150EA8: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150EAC: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000150EB0: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000150EB8: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000150EBC: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150EC4: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000150EC8: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 000000150ECC: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150ED4: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 000000150ED8: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 000000150EDC: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150EE4: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000150EE8: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000150EF0: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v126, v[129:130]   // 000000150EF8: D6FF7C69 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150F04: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000150F08: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000150F10: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 000000150F1C: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000150F24: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000150F28: BE882007
	s_cbranch_execz 64069                                      // 000000150F2C: BFA5FA45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3344>
	v_mad_i64_i32 v[105:106], null, 0x6000, v127, v[131:132]   // 000000150F30: D6FF7C69 060EFEFF 00006000
	global_load_u16 v105, v[105:106], off offset:576           // 000000150F3C: DC4A0240 697C0069
	s_waitcnt vmcnt(0)                                         // 000000150F44: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 000000150F48: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150F4C: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000150F50: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 000000150F58: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000150F64: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000150F68: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000150F6C: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000150F70: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 000000150F78: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000150F80: BF870121
	v_add_f32_e32 v106, v106, v107                             // 000000150F84: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 000000150F88: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 000000150F8C: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150F90: BF870095
	.long 0xd71c006a                                           // 000000150F94: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 000000150F98: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 000000150F9C: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 000000150FA0: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150FA8: BF870092
	v_dual_cndmask_b32 v105, 0x7f800000, v106 :: v_dual_mul_f32 v106, v134, v112// 000000150FAC: CA46D4FF 696AE186 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 000000150FB8: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150FBC: BF870091
	v_div_scale_f32 v107, null, v105, v105, v106               // 000000150FC0: D6FC7C6B 05AAD369
	v_rcp_f32_e32 v108, v107                                   // 000000150FC8: 7ED8556B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150FCC: BF870095
	v_fma_f32 v109, -v107, v108, 1.0                           // 000000150FD0: D613006D 23CAD96B
	v_fmac_f32_e32 v108, v109, v108                            // 000000150FD8: 56D8D96D
	v_div_scale_f32 v109, vcc_lo, v106, v105, v106             // 000000150FDC: D6FC6A6D 05AAD36A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150FE4: BF870091
	v_mul_f32_e32 v110, v109, v108                             // 000000150FE8: 10DCD96D
	v_fma_f32 v111, -v107, v110, v109                          // 000000150FEC: D613006F 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000150FF4: BF870091
	v_fmac_f32_e32 v110, v111, v108                            // 000000150FF8: 56DCD96F
	v_fma_f32 v107, -v107, v110, v109                          // 000000150FFC: D613006B 25B6DD6B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151004: BF870091
	v_div_fmas_f32 v107, v107, v108, v110                      // 000000151008: D637006B 05BAD96B
	v_div_fixup_f32 v107, v107, v105, v106                     // 000000151010: D627006B 05AAD36B
	v_mad_i64_i32 v[105:106], null, 0x3000, v127, v[129:130]   // 000000151018: D6FF7C69 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151024: BF870092
	v_bfe_u32 v108, v107, 16, 1                                // 000000151028: D610006C 0205216B
	v_add3_u32 v107, v107, v108, 0x7fff                        // 000000151030: D655006B 03FED96B 00007FFF
	global_store_d16_hi_b16 v[105:106], v107, off offset:64    // 00000015103C: DC960040 007C6B69
	s_or_b32 exec_lo, exec_lo, s8                              // 000000151044: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000151048: BE882000
	s_cbranch_execz 64000                                      // 00000015104C: BFA5FA00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3350>
	v_mad_i64_i32 v[105:106], null, 0x6000, v0, v[131:132]     // 000000151050: D6FF7C69 060E00FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 00000015105C: 10C2C38B
	global_load_u16 v105, v[105:106], off offset:608           // 000000151060: DC4A0260 697C0069
	s_waitcnt vmcnt(0)                                         // 000000151068: BF8903F7
	v_lshlrev_b32_e32 v105, 16, v105                           // 00000015106C: 30D2D290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151070: BF870091
	v_mul_f32_e32 v106, 0xbfb8aa3b, v105                       // 000000151074: 10D4D2FF BFB8AA3B
	v_fma_f32 v107, 0xbfb8aa3b, v105, -v106                    // 00000015107C: D613006B 85AAD2FF BFB8AA3B
	v_rndne_f32_e32 v108, v106                                 // 000000151088: 7ED8476A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000015108C: BF870221
	v_sub_f32_e32 v106, v106, v108                             // 000000151090: 08D4D96A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v105                 // 000000151094: 7C3CD2FF 42CE8ED0
	v_fmamk_f32 v107, v105, 0xb2a5705f, v107                   // 00000015109C: 58D6D769 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001510A4: BF870121
	v_add_f32_e32 v106, v106, v107                             // 0000001510A8: 06D4D76A
	v_cvt_i32_f32_e32 v107, v108                               // 0000001510AC: 7ED6116C
	v_exp_f32_e32 v106, v106                                   // 0000001510B0: 7ED44B6A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001510B4: BF870095
	.long 0xd71c006a                                           // 0000001510B8: D71C006A
	v_cndmask_b32_e32 v1, v106, v107, vcc_lo                   // 0000001510BC: 0202D76A
	v_cndmask_b32_e32 v106, 0, v106, vcc_lo                    // 0000001510C0: 02D4D480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v105                 // 0000001510C4: 7C36D2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001510CC: BF870092
	v_cndmask_b32_e32 v105, 0x7f800000, v106, vcc_lo           // 0000001510D0: 02D2D4FF 7F800000
	v_add_f32_e32 v105, 1.0, v105                              // 0000001510D8: 06D2D2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001510DC: BF870091
	v_div_scale_f32 v106, null, v105, v105, v97                // 0000001510E0: D6FC7C6A 0586D369
	v_rcp_f32_e32 v107, v106                                   // 0000001510E8: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001510EC: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 0000001510F0: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 0000001510F8: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v97, v105, v97               // 0000001510FC: D6FC6A6C 0586D361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151104: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 000000151108: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 00000015110C: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151114: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 000000151118: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 00000015111C: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151124: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 000000151128: D637006A 05B6D76A
	v_div_fixup_f32 v97, v106, v105, v97                       // 000000151130: D6270061 0586D36A
	v_mad_i64_i32 v[105:106], null, 0x3000, v0, v[129:130]     // 000000151138: D6FF7C69 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151144: BF870092
	v_bfe_u32 v107, v97, 16, 1                                 // 000000151148: D610006B 02052161
	v_add3_u32 v97, v97, v107, 0x7fff                          // 000000151150: D6550061 03FED761 00007FFF
	global_store_d16_hi_b16 v[105:106], v97, off offset:96     // 00000015115C: DC960060 007C6169
	s_or_b32 exec_lo, exec_lo, s8                              // 000000151164: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000151168: BE882001
	s_cbranch_execz 63931                                      // 00000015116C: BFA5F9BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x335c>
	v_mad_i64_i32 v[105:106], null, 0x6000, v121, v[131:132]   // 000000151170: D6FF7C69 060EF2FF 00006000
	v_mul_f32_e32 v98, v140, v98                               // 00000015117C: 10C4C58C
	global_load_u16 v97, v[105:106], off offset:608            // 000000151180: DC4A0260 617C0069
	s_waitcnt vmcnt(0)                                         // 000000151188: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000015118C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000151190: BF870121
	v_mul_f32_e32 v105, 0xbfb8aa3b, v97                        // 000000151194: 10D2C2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 00000015119C: 7C3CC2FF 42CE8ED0
	v_fma_f32 v106, 0xbfb8aa3b, v97, -v105                     // 0000001511A4: D613006A 85A6C2FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000001511B0: 7ED64769
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001511B4: BF870112
	v_fmamk_f32 v106, v97, 0xb2a5705f, v106                    // 0000001511B8: 58D4D561 B2A5705F
	v_sub_f32_e32 v105, v105, v107                             // 0000001511C0: 08D2D769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001511C4: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000001511C8: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000001511CC: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000001511D0: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001511D4: BF870095
	.long 0xd71c0069                                           // 0000001511D8: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000001511DC: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000001511E0: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001511E4: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001511EC: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v105, vcc_lo            // 0000001511F0: 02C2D2FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000001511F8: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001511FC: BF870091
	v_div_scale_f32 v105, null, v97, v97, v98                  // 000000151200: D6FC7C69 058AC361
	v_rcp_f32_e32 v106, v105                                   // 000000151208: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015120C: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 000000151210: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 000000151218: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v98, v97, v98                // 00000015121C: D6FC6A6B 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151224: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 000000151228: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 00000015122C: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151234: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 000000151238: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 00000015123C: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151244: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 000000151248: D6370069 05B2D569
	v_div_fixup_f32 v105, v105, v97, v98                       // 000000151250: D6270069 058AC369
	v_mad_i64_i32 v[97:98], null, 0x3000, v121, v[129:130]     // 000000151258: D6FF7C61 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151264: BF870092
	v_bfe_u32 v106, v105, 16, 1                                // 000000151268: D610006A 02052169
	v_add3_u32 v105, v105, v106, 0x7fff                        // 000000151270: D6550069 03FED569 00007FFF
	global_store_d16_hi_b16 v[97:98], v105, off offset:96      // 00000015127C: DC960060 007C6961
	s_or_b32 exec_lo, exec_lo, s8                              // 000000151284: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000151288: BE882002
	s_cbranch_execz 63862                                      // 00000015128C: BFA5F976 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3368>
	v_mad_i64_i32 v[97:98], null, 0x6000, v122, v[131:132]     // 000000151290: D6FF7C61 060EF4FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000015129C: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000001512A4: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000001512A8: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001512AC: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000001512B0: 10C4C2FF BFB8AA3B
	v_fma_f32 v105, 0xbfb8aa3b, v97, -v98                      // 0000001512B8: D6130069 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v106, v98                                  // 0000001512C4: 7ED44762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001512C8: BF870221
	v_sub_f32_e32 v98, v98, v106                               // 0000001512CC: 08C4D562
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001512D0: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v105, v97, 0xb2a5705f, v105                    // 0000001512D8: 58D2D361 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001512E0: BF870121
	v_add_f32_e32 v98, v98, v105                               // 0000001512E4: 06C4D362
	v_cvt_i32_f32_e32 v105, v106                               // 0000001512E8: 7ED2116A
	v_exp_f32_e32 v98, v98                                     // 0000001512EC: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001512F0: BF870095
	.long 0xd71c0062                                           // 0000001512F4: D71C0062
	v_cndmask_b32_e32 v1, v98, v105, vcc_lo                    // 0000001512F8: 0202D362
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000001512FC: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000151300: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151308: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v137, v99// 00000015130C: CA46C4FF 6162C789 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000151318: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015131C: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000151320: D6FC7C63 058AC361
	v_rcp_f32_e32 v105, v99                                    // 000000151328: 7ED25563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015132C: BF870095
	v_fma_f32 v106, -v99, v105, 1.0                            // 000000151330: D613006A 23CAD363
	v_fmac_f32_e32 v105, v106, v105                            // 000000151338: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v98, v97, v98                // 00000015133C: D6FC6A6A 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151344: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 000000151348: 10D6D36A
	v_fma_f32 v108, -v99, v107, v106                           // 00000015134C: D613006C 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151354: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 000000151358: 56D6D36C
	v_fma_f32 v99, -v99, v107, v106                            // 00000015135C: D6130063 25AAD763
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151364: BF870091
	v_div_fmas_f32 v99, v99, v105, v107                        // 000000151368: D6370063 05AED363
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000151370: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v122, v[129:130]     // 000000151378: D6FF7C61 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151384: BF870092
	v_bfe_u32 v105, v99, 16, 1                                 // 000000151388: D6100069 02052163
	v_add3_u32 v99, v99, v105, 0x7fff                          // 000000151390: D6550063 03FED363 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000015139C: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001513A4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001513A8: BE882003
	s_cbranch_execz 63793                                      // 0000001513AC: BFA5F931 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3374>
	v_mad_i64_i32 v[97:98], null, 0x6000, v123, v[131:132]     // 0000001513B0: D6FF7C61 060EF6FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000001513BC: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000001513C4: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000001513C8: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001513CC: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000001513D0: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000001513D8: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v105, v98                                  // 0000001513E4: 7ED24762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001513E8: BF870091
	v_dual_fmamk_f32 v99, v97, 0xb2a5705f, v99 :: v_dual_sub_f32 v98, v98, v105// 0000001513EC: C88AC761 6362D362 B2A5705F
	v_add_f32_e32 v98, v98, v99                                // 0000001513F8: 06C4C762
	v_cvt_i32_f32_e32 v99, v105                                // 0000001513FC: 7EC61169
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000151400: 7C3CC2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000151408: BF870293
	v_exp_f32_e32 v98, v98                                     // 00000015140C: 7EC44B62
	.long 0xd71c0062                                           // 000000151410: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000151414: 0202C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000151418: BF870121
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000015141C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000151420: 7C36C2FF C2B17218
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v138, v100// 000000151428: CA46C4FF 6162C98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151434: BF870091
	v_add_f32_e32 v97, 1.0, v97                                // 000000151438: 06C2C2F2
	v_div_scale_f32 v99, null, v97, v97, v98                   // 00000015143C: D6FC7C63 058AC361
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000151444: BF870291
	v_rcp_f32_e32 v100, v99                                    // 000000151448: 7EC85563
	v_fma_f32 v105, -v99, v100, 1.0                            // 00000015144C: D6130069 23CAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000151454: BF8700A1
	v_fmac_f32_e32 v100, v105, v100                            // 000000151458: 56C8C969
	v_div_scale_f32 v105, vcc_lo, v98, v97, v98                // 00000015145C: D6FC6A69 058AC362
	v_mul_f32_e32 v106, v105, v100                             // 000000151464: 10D4C969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151468: BF870091
	v_fma_f32 v107, -v99, v106, v105                           // 00000015146C: D613006B 25A6D563
	v_fmac_f32_e32 v106, v107, v100                            // 000000151474: 56D4C96B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151478: BF870091
	v_fma_f32 v99, -v99, v106, v105                            // 00000015147C: D6130063 25A6D563
	v_div_fmas_f32 v99, v99, v100, v106                        // 000000151484: D6370063 05AAC963
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015148C: BF870121
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000151490: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v123, v[129:130]     // 000000151498: D6FF7C61 0606F6FF 00003000
	v_bfe_u32 v100, v99, 16, 1                                 // 0000001514A4: D6100064 02052163
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001514AC: BF870001
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000001514B0: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000001514BC: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001514C4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001514C8: BE882004
	s_cbranch_execz 63724                                      // 0000001514CC: BFA5F8EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3380>
	v_mad_i64_i32 v[97:98], null, 0x6000, v124, v[131:132]     // 0000001514D0: D6FF7C61 060EF8FF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000001514DC: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 0000001514E4: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000001514E8: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001514EC: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 0000001514F0: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 0000001514F8: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000151504: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000151508: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000015150C: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000151510: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000151518: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000151520: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000151524: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000151528: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000015152C: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151530: BF870095
	.long 0xd71c0062                                           // 000000151534: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000151538: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000015153C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000151540: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151548: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v135, v101// 00000015154C: CA46C4FF 6162CB87 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000151558: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015155C: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000151560: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000151568: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015156C: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000151570: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000151578: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000015157C: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151584: BF870091
	v_mul_f32_e32 v105, v101, v100                             // 000000151588: 10D2C965
	v_fma_f32 v106, -v99, v105, v101                           // 00000015158C: D613006A 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151594: BF870091
	v_fmac_f32_e32 v105, v106, v100                            // 000000151598: 56D2C96A
	v_fma_f32 v99, -v99, v105, v101                            // 00000015159C: D6130063 2596D363
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001515A4: BF870091
	v_div_fmas_f32 v99, v99, v100, v105                        // 0000001515A8: D6370063 05A6C963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000001515B0: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v124, v[129:130]     // 0000001515B8: D6FF7C61 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001515C4: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000001515C8: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000001515D0: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000001515DC: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001515E4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001515E8: BE882005
	s_cbranch_execz 63655                                      // 0000001515EC: BFA5F8A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x338c>
	v_mad_i64_i32 v[97:98], null, 0x6000, v125, v[131:132]     // 0000001515F0: D6FF7C61 060EFAFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 0000001515FC: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000151604: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000151608: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015160C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000151610: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000151618: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000151624: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000151628: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000015162C: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000151630: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000151638: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000151640: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000151644: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000151648: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000015164C: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151650: BF870095
	.long 0xd71c0062                                           // 000000151654: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000151658: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000015165C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000151660: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151668: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 00000015166C: 02C2C4FF 7F800000
	v_dual_mul_f32 v98, v136, v102 :: v_dual_add_f32 v97, 1.0, v97// 000000151674: C8C8CD88 6260C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015167C: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 000000151680: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 000000151688: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015168C: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 000000151690: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 000000151698: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 00000015169C: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001516A4: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000001516A8: 10CCC965
	v_fma_f32 v105, -v99, v102, v101                           // 0000001516AC: D6130069 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001516B4: BF870091
	v_fmac_f32_e32 v102, v105, v100                            // 0000001516B8: 56CCC969
	v_fma_f32 v99, -v99, v102, v101                            // 0000001516BC: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001516C4: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000001516C8: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000001516D0: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v125, v[129:130]     // 0000001516D8: D6FF7C61 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001516E4: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 0000001516E8: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 0000001516F0: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 0000001516FC: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000151704: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000151708: BE882006
	s_cbranch_execz 63586                                      // 00000015170C: BFA5F862 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3398>
	v_mad_i64_i32 v[97:98], null, 0x6000, v126, v[131:132]     // 000000151710: D6FF7C61 060EFCFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000015171C: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000151724: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000151728: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015172C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000151730: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000151738: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000151744: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000151748: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000015174C: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000151750: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000151758: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000151760: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000151764: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000151768: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000015176C: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151770: BF870095
	.long 0xd71c0062                                           // 000000151774: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000151778: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000015177C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 000000151780: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151788: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v133, v103// 00000015178C: CA46C4FF 6162CF85 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 000000151798: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015179C: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000001517A0: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000001517A8: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001517AC: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000001517B0: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000001517B8: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000001517BC: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001517C4: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000001517C8: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000001517CC: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001517D4: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000001517D8: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000001517DC: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001517E4: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 0000001517E8: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 0000001517F0: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v126, v[129:130]     // 0000001517F8: D6FF7C61 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151804: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000151808: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000151810: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000015181C: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000151824: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000151828: BE882007
	s_cbranch_execz 63517                                      // 00000015182C: BFA5F81D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33a4>
	v_mad_i64_i32 v[97:98], null, 0x6000, v127, v[131:132]     // 000000151830: D6FF7C61 060EFEFF 00006000
	global_load_u16 v97, v[97:98], off offset:608              // 00000015183C: DC4A0260 617C0061
	s_waitcnt vmcnt(0)                                         // 000000151844: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 000000151848: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015184C: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000151850: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 000000151858: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000151864: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000151868: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 00000015186C: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000151870: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 000000151878: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000151880: BF870121
	v_add_f32_e32 v98, v98, v99                                // 000000151884: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 000000151888: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 00000015188C: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151890: BF870095
	.long 0xd71c0062                                           // 000000151894: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 000000151898: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 00000015189C: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001518A0: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001518A8: BF870092
	v_dual_cndmask_b32 v97, 0x7f800000, v98 :: v_dual_mul_f32 v98, v134, v104// 0000001518AC: CA46C4FF 6162D186 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000001518B8: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001518BC: BF870091
	v_div_scale_f32 v99, null, v97, v97, v98                   // 0000001518C0: D6FC7C63 058AC361
	v_rcp_f32_e32 v100, v99                                    // 0000001518C8: 7EC85563
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001518CC: BF870095
	v_fma_f32 v101, -v99, v100, 1.0                            // 0000001518D0: D6130065 23CAC963
	v_fmac_f32_e32 v100, v101, v100                            // 0000001518D8: 56C8C965
	v_div_scale_f32 v101, vcc_lo, v98, v97, v98                // 0000001518DC: D6FC6A65 058AC362
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001518E4: BF870091
	v_mul_f32_e32 v102, v101, v100                             // 0000001518E8: 10CCC965
	v_fma_f32 v103, -v99, v102, v101                           // 0000001518EC: D6130067 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001518F4: BF870091
	v_fmac_f32_e32 v102, v103, v100                            // 0000001518F8: 56CCC967
	v_fma_f32 v99, -v99, v102, v101                            // 0000001518FC: D6130063 2596CD63
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151904: BF870091
	v_div_fmas_f32 v99, v99, v100, v102                        // 000000151908: D6370063 059AC963
	v_div_fixup_f32 v99, v99, v97, v98                         // 000000151910: D6270063 058AC363
	v_mad_i64_i32 v[97:98], null, 0x3000, v127, v[129:130]     // 000000151918: D6FF7C61 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151924: BF870092
	v_bfe_u32 v100, v99, 16, 1                                 // 000000151928: D6100064 02052163
	v_add3_u32 v99, v99, v100, 0x7fff                          // 000000151930: D6550063 03FEC963 00007FFF
	global_store_d16_hi_b16 v[97:98], v99, off offset:96       // 00000015193C: DC960060 007C6361
	s_or_b32 exec_lo, exec_lo, s8                              // 000000151944: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000151948: BE882000
	s_cbranch_execz 63448                                      // 00000015194C: BFA5F7D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33b0>
	v_mad_i64_i32 v[97:98], null, 0x6000, v0, v[131:132]       // 000000151950: D6FF7C61 060E00FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 00000015195C: 10B2B38B
	global_load_u16 v97, v[97:98], off offset:640              // 000000151960: DC4A0280 617C0061
	s_waitcnt vmcnt(0)                                         // 000000151968: BF8903F7
	v_lshlrev_b32_e32 v97, 16, v97                             // 00000015196C: 30C2C290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151970: BF870091
	v_mul_f32_e32 v98, 0xbfb8aa3b, v97                         // 000000151974: 10C4C2FF BFB8AA3B
	v_fma_f32 v99, 0xbfb8aa3b, v97, -v98                       // 00000015197C: D6130063 858AC2FF BFB8AA3B
	v_rndne_f32_e32 v100, v98                                  // 000000151988: 7EC84762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000015198C: BF870221
	v_sub_f32_e32 v98, v98, v100                               // 000000151990: 08C4C962
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 000000151994: 7C3CC2FF 42CE8ED0
	v_fmamk_f32 v99, v97, 0xb2a5705f, v99                      // 00000015199C: 58C6C761 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001519A4: BF870121
	v_add_f32_e32 v98, v98, v99                                // 0000001519A8: 06C4C762
	v_cvt_i32_f32_e32 v99, v100                                // 0000001519AC: 7EC61164
	v_exp_f32_e32 v98, v98                                     // 0000001519B0: 7EC44B62
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001519B4: BF870095
	.long 0xd71c0062                                           // 0000001519B8: D71C0062
	v_cndmask_b32_e32 v1, v98, v99, vcc_lo                     // 0000001519BC: 0202C762
	v_cndmask_b32_e32 v98, 0, v98, vcc_lo                      // 0000001519C0: 02C4C480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001519C4: 7C36C2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001519CC: BF870092
	v_cndmask_b32_e32 v97, 0x7f800000, v98, vcc_lo             // 0000001519D0: 02C2C4FF 7F800000
	v_add_f32_e32 v97, 1.0, v97                                // 0000001519D8: 06C2C2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001519DC: BF870091
	v_div_scale_f32 v98, null, v97, v97, v89                   // 0000001519E0: D6FC7C62 0566C361
	v_rcp_f32_e32 v99, v98                                     // 0000001519E8: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001519EC: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 0000001519F0: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 0000001519F8: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v89, v97, v89                // 0000001519FC: D6FC6A64 0566C359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151A04: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 000000151A08: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 000000151A0C: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151A14: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 000000151A18: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 000000151A1C: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151A24: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 000000151A28: D6370062 0596C762
	v_div_fixup_f32 v89, v98, v97, v89                         // 000000151A30: D6270059 0566C362
	v_mad_i64_i32 v[97:98], null, 0x3000, v0, v[129:130]       // 000000151A38: D6FF7C61 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151A44: BF870092
	v_bfe_u32 v99, v89, 16, 1                                  // 000000151A48: D6100063 02052159
	v_add3_u32 v89, v89, v99, 0x7fff                           // 000000151A50: D6550059 03FEC759 00007FFF
	global_store_d16_hi_b16 v[97:98], v89, off offset:128      // 000000151A5C: DC960080 007C5961
	s_or_b32 exec_lo, exec_lo, s8                              // 000000151A64: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000151A68: BE882001
	s_cbranch_execz 63379                                      // 000000151A6C: BFA5F793 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33bc>
	v_mad_i64_i32 v[97:98], null, 0x6000, v121, v[131:132]     // 000000151A70: D6FF7C61 060EF2FF 00006000
	v_mul_f32_e32 v90, v140, v90                               // 000000151A7C: 10B4B58C
	global_load_u16 v89, v[97:98], off offset:640              // 000000151A80: DC4A0280 597C0061
	s_waitcnt vmcnt(0)                                         // 000000151A88: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000151A8C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000151A90: BF870121
	v_mul_f32_e32 v97, 0xbfb8aa3b, v89                         // 000000151A94: 10C2B2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000151A9C: 7C3CB2FF 42CE8ED0
	v_fma_f32 v98, 0xbfb8aa3b, v89, -v97                       // 000000151AA4: D6130062 8586B2FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 000000151AB0: 7EC64761
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000151AB4: BF870112
	v_fmamk_f32 v98, v89, 0xb2a5705f, v98                      // 000000151AB8: 58C4C559 B2A5705F
	v_sub_f32_e32 v97, v97, v99                                // 000000151AC0: 08C2C761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000151AC4: BF870121
	v_add_f32_e32 v97, v97, v98                                // 000000151AC8: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 000000151ACC: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 000000151AD0: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151AD4: BF870095
	.long 0xd71c0061                                           // 000000151AD8: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 000000151ADC: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 000000151AE0: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000151AE4: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151AEC: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v97, vcc_lo             // 000000151AF0: 02B2C2FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000151AF8: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151AFC: BF870091
	v_div_scale_f32 v97, null, v89, v89, v90                   // 000000151B00: D6FC7C61 056AB359
	v_rcp_f32_e32 v98, v97                                     // 000000151B08: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151B0C: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 000000151B10: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 000000151B18: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v90, v89, v90                 // 000000151B1C: D6FC6A63 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151B24: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 000000151B28: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 000000151B2C: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151B34: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 000000151B38: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 000000151B3C: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151B44: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 000000151B48: D6370061 0592C561
	v_div_fixup_f32 v97, v97, v89, v90                         // 000000151B50: D6270061 056AB361
	v_mad_i64_i32 v[89:90], null, 0x3000, v121, v[129:130]     // 000000151B58: D6FF7C59 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151B64: BF870092
	v_bfe_u32 v98, v97, 16, 1                                  // 000000151B68: D6100062 02052161
	v_add3_u32 v97, v97, v98, 0x7fff                           // 000000151B70: D6550061 03FEC561 00007FFF
	global_store_d16_hi_b16 v[89:90], v97, off offset:128      // 000000151B7C: DC960080 007C6159
	s_or_b32 exec_lo, exec_lo, s8                              // 000000151B84: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000151B88: BE882002
	s_cbranch_execz 63310                                      // 000000151B8C: BFA5F74E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33c8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v122, v[131:132]     // 000000151B90: D6FF7C59 060EF4FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000151B9C: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000151BA4: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000151BA8: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151BAC: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000151BB0: 10B4B2FF BFB8AA3B
	v_fma_f32 v97, 0xbfb8aa3b, v89, -v90                       // 000000151BB8: D6130061 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v98, v90                                   // 000000151BC4: 7EC4475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000151BC8: BF870221
	v_sub_f32_e32 v90, v90, v98                                // 000000151BCC: 08B4C55A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000151BD0: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v97, v89, 0xb2a5705f, v97                      // 000000151BD8: 58C2C359 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000151BE0: BF870121
	v_add_f32_e32 v90, v90, v97                                // 000000151BE4: 06B4C35A
	v_cvt_i32_f32_e32 v97, v98                                 // 000000151BE8: 7EC21162
	v_exp_f32_e32 v90, v90                                     // 000000151BEC: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151BF0: BF870095
	.long 0xd71c005a                                           // 000000151BF4: D71C005A
	v_cndmask_b32_e32 v1, v90, v97, vcc_lo                     // 000000151BF8: 0202C35A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000151BFC: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000151C00: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151C08: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v137, v91// 000000151C0C: CA46B4FF 595AB789 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000151C18: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151C1C: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000151C20: D6FC7C5B 056AB359
	v_rcp_f32_e32 v97, v91                                     // 000000151C28: 7EC2555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151C2C: BF870095
	v_fma_f32 v98, -v91, v97, 1.0                              // 000000151C30: D6130062 23CAC35B
	v_fmac_f32_e32 v97, v98, v97                               // 000000151C38: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v90, v89, v90                 // 000000151C3C: D6FC6A62 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151C44: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 000000151C48: 10C6C362
	v_fma_f32 v100, -v91, v99, v98                             // 000000151C4C: D6130064 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151C54: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 000000151C58: 56C6C364
	v_fma_f32 v91, -v91, v99, v98                              // 000000151C5C: D613005B 258AC75B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151C64: BF870091
	v_div_fmas_f32 v91, v91, v97, v99                          // 000000151C68: D637005B 058EC35B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000151C70: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v122, v[129:130]     // 000000151C78: D6FF7C59 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151C84: BF870092
	v_bfe_u32 v97, v91, 16, 1                                  // 000000151C88: D6100061 0205215B
	v_add3_u32 v91, v91, v97, 0x7fff                           // 000000151C90: D655005B 03FEC35B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000151C9C: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000151CA4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000151CA8: BE882003
	s_cbranch_execz 63241                                      // 000000151CAC: BFA5F709 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33d4>
	v_mad_i64_i32 v[89:90], null, 0x6000, v123, v[131:132]     // 000000151CB0: D6FF7C59 060EF6FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000151CBC: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000151CC4: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000151CC8: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151CCC: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000151CD0: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000151CD8: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v97, v90                                   // 000000151CE4: 7EC2475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151CE8: BF870091
	v_dual_fmamk_f32 v91, v89, 0xb2a5705f, v91 :: v_dual_sub_f32 v90, v90, v97// 000000151CEC: C88AB759 5B5AC35A B2A5705F
	v_add_f32_e32 v90, v90, v91                                // 000000151CF8: 06B4B75A
	v_cvt_i32_f32_e32 v91, v97                                 // 000000151CFC: 7EB61161
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000151D00: 7C3CB2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000151D08: BF870293
	v_exp_f32_e32 v90, v90                                     // 000000151D0C: 7EB44B5A
	.long 0xd71c005a                                           // 000000151D10: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000151D14: 0202B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000151D18: BF870121
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000151D1C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000151D20: 7C36B2FF C2B17218
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v138, v92// 000000151D28: CA46B4FF 595AB98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151D34: BF870091
	v_add_f32_e32 v89, 1.0, v89                                // 000000151D38: 06B2B2F2
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000151D3C: D6FC7C5B 056AB359
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000151D44: BF870291
	v_rcp_f32_e32 v92, v91                                     // 000000151D48: 7EB8555B
	v_fma_f32 v97, -v91, v92, 1.0                              // 000000151D4C: D6130061 23CAB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000151D54: BF8700A1
	v_fmac_f32_e32 v92, v97, v92                               // 000000151D58: 56B8B961
	v_div_scale_f32 v97, vcc_lo, v90, v89, v90                 // 000000151D5C: D6FC6A61 056AB35A
	v_mul_f32_e32 v98, v97, v92                                // 000000151D64: 10C4B961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151D68: BF870091
	v_fma_f32 v99, -v91, v98, v97                              // 000000151D6C: D6130063 2586C55B
	v_fmac_f32_e32 v98, v99, v92                               // 000000151D74: 56C4B963
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151D78: BF870091
	v_fma_f32 v91, -v91, v98, v97                              // 000000151D7C: D613005B 2586C55B
	v_div_fmas_f32 v91, v91, v92, v98                          // 000000151D84: D637005B 058AB95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000151D8C: BF870121
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000151D90: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v123, v[129:130]     // 000000151D98: D6FF7C59 0606F6FF 00003000
	v_bfe_u32 v92, v91, 16, 1                                  // 000000151DA4: D610005C 0205215B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000151DAC: BF870001
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000151DB0: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000151DBC: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000151DC4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000151DC8: BE882004
	s_cbranch_execz 63172                                      // 000000151DCC: BFA5F6C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33e0>
	v_mad_i64_i32 v[89:90], null, 0x6000, v124, v[131:132]     // 000000151DD0: D6FF7C59 060EF8FF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000151DDC: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000151DE4: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000151DE8: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151DEC: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000151DF0: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000151DF8: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000151E04: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000151E08: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000151E0C: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000151E10: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000151E18: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000151E20: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000151E24: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000151E28: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000151E2C: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151E30: BF870095
	.long 0xd71c005a                                           // 000000151E34: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000151E38: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000151E3C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000151E40: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151E48: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v135, v93// 000000151E4C: CA46B4FF 595ABB87 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000151E58: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151E5C: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000151E60: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000151E68: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151E6C: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000151E70: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000151E78: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000151E7C: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151E84: BF870091
	v_mul_f32_e32 v97, v93, v92                                // 000000151E88: 10C2B95D
	v_fma_f32 v98, -v91, v97, v93                              // 000000151E8C: D6130062 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151E94: BF870091
	v_fmac_f32_e32 v97, v98, v92                               // 000000151E98: 56C2B962
	v_fma_f32 v91, -v91, v97, v93                              // 000000151E9C: D613005B 2576C35B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151EA4: BF870091
	v_div_fmas_f32 v91, v91, v92, v97                          // 000000151EA8: D637005B 0586B95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000151EB0: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v124, v[129:130]     // 000000151EB8: D6FF7C59 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151EC4: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000151EC8: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000151ED0: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000151EDC: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000151EE4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000151EE8: BE882005
	s_cbranch_execz 63103                                      // 000000151EEC: BFA5F67F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33ec>
	v_mad_i64_i32 v[89:90], null, 0x6000, v125, v[131:132]     // 000000151EF0: D6FF7C59 060EFAFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 000000151EFC: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000151F04: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000151F08: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151F0C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000151F10: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000151F18: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000151F24: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000151F28: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000151F2C: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000151F30: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000151F38: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000151F40: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000151F44: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000151F48: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 000000151F4C: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151F50: BF870095
	.long 0xd71c005a                                           // 000000151F54: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000151F58: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 000000151F5C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000151F60: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151F68: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 000000151F6C: 02B2B4FF 7F800000
	v_dual_mul_f32 v90, v136, v94 :: v_dual_add_f32 v89, 1.0, v89// 000000151F74: C8C8BD88 5A58B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151F7C: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 000000151F80: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 000000151F88: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151F8C: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 000000151F90: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 000000151F98: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 000000151F9C: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151FA4: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 000000151FA8: 10BCB95D
	v_fma_f32 v97, -v91, v94, v93                              // 000000151FAC: D6130061 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151FB4: BF870091
	v_fmac_f32_e32 v94, v97, v92                               // 000000151FB8: 56BCB961
	v_fma_f32 v91, -v91, v94, v93                              // 000000151FBC: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151FC4: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000151FC8: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000151FD0: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v125, v[129:130]     // 000000151FD8: D6FF7C59 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000151FE4: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000151FE8: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000151FF0: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 000000151FFC: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000152004: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000152008: BE882006
	s_cbranch_execz 63034                                      // 00000015200C: BFA5F63A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33f8>
	v_mad_i64_i32 v[89:90], null, 0x6000, v126, v[131:132]     // 000000152010: D6FF7C59 060EFCFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000015201C: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000152024: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000152028: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015202C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000152030: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000152038: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000152044: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000152048: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000015204C: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000152050: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000152058: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152060: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000152064: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000152068: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000015206C: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152070: BF870095
	.long 0xd71c005a                                           // 000000152074: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000152078: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000015207C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 000000152080: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152088: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v133, v95// 00000015208C: CA46B4FF 595ABF85 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 000000152098: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015209C: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000001520A0: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000001520A8: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001520AC: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000001520B0: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000001520B8: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000001520BC: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001520C4: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000001520C8: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000001520CC: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001520D4: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000001520D8: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000001520DC: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001520E4: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 0000001520E8: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 0000001520F0: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v126, v[129:130]     // 0000001520F8: D6FF7C59 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152104: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000152108: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000152110: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000015211C: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000152124: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000152128: BE882007
	s_cbranch_execz 62965                                      // 00000015212C: BFA5F5F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3404>
	v_mad_i64_i32 v[89:90], null, 0x6000, v127, v[131:132]     // 000000152130: D6FF7C59 060EFEFF 00006000
	global_load_u16 v89, v[89:90], off offset:640              // 00000015213C: DC4A0280 597C0059
	s_waitcnt vmcnt(0)                                         // 000000152144: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 000000152148: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015214C: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000152150: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 000000152158: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000152164: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000152168: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 00000015216C: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000152170: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 000000152178: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152180: BF870121
	v_add_f32_e32 v90, v90, v91                                // 000000152184: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 000000152188: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 00000015218C: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152190: BF870095
	.long 0xd71c005a                                           // 000000152194: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 000000152198: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 00000015219C: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000001521A0: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001521A8: BF870092
	v_dual_cndmask_b32 v89, 0x7f800000, v90 :: v_dual_mul_f32 v90, v134, v96// 0000001521AC: CA46B4FF 595AC186 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000001521B8: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001521BC: BF870091
	v_div_scale_f32 v91, null, v89, v89, v90                   // 0000001521C0: D6FC7C5B 056AB359
	v_rcp_f32_e32 v92, v91                                     // 0000001521C8: 7EB8555B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001521CC: BF870095
	v_fma_f32 v93, -v91, v92, 1.0                              // 0000001521D0: D613005D 23CAB95B
	v_fmac_f32_e32 v92, v93, v92                               // 0000001521D8: 56B8B95D
	v_div_scale_f32 v93, vcc_lo, v90, v89, v90                 // 0000001521DC: D6FC6A5D 056AB35A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001521E4: BF870091
	v_mul_f32_e32 v94, v93, v92                                // 0000001521E8: 10BCB95D
	v_fma_f32 v95, -v91, v94, v93                              // 0000001521EC: D613005F 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001521F4: BF870091
	v_fmac_f32_e32 v94, v95, v92                               // 0000001521F8: 56BCB95F
	v_fma_f32 v91, -v91, v94, v93                              // 0000001521FC: D613005B 2576BD5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152204: BF870091
	v_div_fmas_f32 v91, v91, v92, v94                          // 000000152208: D637005B 057AB95B
	v_div_fixup_f32 v91, v91, v89, v90                         // 000000152210: D627005B 056AB35B
	v_mad_i64_i32 v[89:90], null, 0x3000, v127, v[129:130]     // 000000152218: D6FF7C59 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152224: BF870092
	v_bfe_u32 v92, v91, 16, 1                                  // 000000152228: D610005C 0205215B
	v_add3_u32 v91, v91, v92, 0x7fff                           // 000000152230: D655005B 03FEB95B 00007FFF
	global_store_d16_hi_b16 v[89:90], v91, off offset:128      // 00000015223C: DC960080 007C5B59
	s_or_b32 exec_lo, exec_lo, s8                              // 000000152244: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000152248: BE882000
	s_cbranch_execz 62896                                      // 00000015224C: BFA5F5B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3410>
	v_mad_i64_i32 v[89:90], null, 0x6000, v0, v[131:132]       // 000000152250: D6FF7C59 060E00FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 00000015225C: 10A2A38B
	global_load_u16 v89, v[89:90], off offset:672              // 000000152260: DC4A02A0 597C0059
	s_waitcnt vmcnt(0)                                         // 000000152268: BF8903F7
	v_lshlrev_b32_e32 v89, 16, v89                             // 00000015226C: 30B2B290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152270: BF870091
	v_mul_f32_e32 v90, 0xbfb8aa3b, v89                         // 000000152274: 10B4B2FF BFB8AA3B
	v_fma_f32 v91, 0xbfb8aa3b, v89, -v90                       // 00000015227C: D613005B 856AB2FF BFB8AA3B
	v_rndne_f32_e32 v92, v90                                   // 000000152288: 7EB8475A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000015228C: BF870221
	v_sub_f32_e32 v90, v90, v92                                // 000000152290: 08B4B95A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v89                  // 000000152294: 7C3CB2FF 42CE8ED0
	v_fmamk_f32 v91, v89, 0xb2a5705f, v91                      // 00000015229C: 58B6B759 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001522A4: BF870121
	v_add_f32_e32 v90, v90, v91                                // 0000001522A8: 06B4B75A
	v_cvt_i32_f32_e32 v91, v92                                 // 0000001522AC: 7EB6115C
	v_exp_f32_e32 v90, v90                                     // 0000001522B0: 7EB44B5A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001522B4: BF870095
	.long 0xd71c005a                                           // 0000001522B8: D71C005A
	v_cndmask_b32_e32 v1, v90, v91, vcc_lo                     // 0000001522BC: 0202B75A
	v_cndmask_b32_e32 v90, 0, v90, vcc_lo                      // 0000001522C0: 02B4B480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v89                  // 0000001522C4: 7C36B2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001522CC: BF870092
	v_cndmask_b32_e32 v89, 0x7f800000, v90, vcc_lo             // 0000001522D0: 02B2B4FF 7F800000
	v_add_f32_e32 v89, 1.0, v89                                // 0000001522D8: 06B2B2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001522DC: BF870091
	v_div_scale_f32 v90, null, v89, v89, v81                   // 0000001522E0: D6FC7C5A 0546B359
	v_rcp_f32_e32 v91, v90                                     // 0000001522E8: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001522EC: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 0000001522F0: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 0000001522F8: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v81, v89, v81                 // 0000001522FC: D6FC6A5C 0546B351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152304: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 000000152308: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 00000015230C: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152314: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 000000152318: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 00000015231C: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152324: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 000000152328: D637005A 0576B75A
	v_div_fixup_f32 v81, v90, v89, v81                         // 000000152330: D6270051 0546B35A
	v_mad_i64_i32 v[89:90], null, 0x3000, v0, v[129:130]       // 000000152338: D6FF7C59 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152344: BF870092
	v_bfe_u32 v91, v81, 16, 1                                  // 000000152348: D610005B 02052151
	v_add3_u32 v81, v81, v91, 0x7fff                           // 000000152350: D6550051 03FEB751 00007FFF
	global_store_d16_hi_b16 v[89:90], v81, off offset:160      // 00000015235C: DC9600A0 007C5159
	s_or_b32 exec_lo, exec_lo, s8                              // 000000152364: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000152368: BE882001
	s_cbranch_execz 62827                                      // 00000015236C: BFA5F56B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x341c>
	v_mad_i64_i32 v[89:90], null, 0x6000, v121, v[131:132]     // 000000152370: D6FF7C59 060EF2FF 00006000
	v_mul_f32_e32 v82, v140, v82                               // 00000015237C: 10A4A58C
	global_load_u16 v81, v[89:90], off offset:672              // 000000152380: DC4A02A0 517C0059
	s_waitcnt vmcnt(0)                                         // 000000152388: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 00000015238C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152390: BF870121
	v_mul_f32_e32 v89, 0xbfb8aa3b, v81                         // 000000152394: 10B2A2FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 00000015239C: 7C3CA2FF 42CE8ED0
	v_fma_f32 v90, 0xbfb8aa3b, v81, -v89                       // 0000001523A4: D613005A 8566A2FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000001523B0: 7EB64759
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001523B4: BF870112
	v_fmamk_f32 v90, v81, 0xb2a5705f, v90                      // 0000001523B8: 58B4B551 B2A5705F
	v_sub_f32_e32 v89, v89, v91                                // 0000001523C0: 08B2B759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001523C4: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000001523C8: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000001523CC: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000001523D0: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001523D4: BF870095
	.long 0xd71c0059                                           // 0000001523D8: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000001523DC: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000001523E0: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 0000001523E4: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001523EC: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v89, vcc_lo             // 0000001523F0: 02A2B2FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 0000001523F8: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001523FC: BF870091
	v_div_scale_f32 v89, null, v81, v81, v82                   // 000000152400: D6FC7C59 054AA351
	v_rcp_f32_e32 v90, v89                                     // 000000152408: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015240C: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 000000152410: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 000000152418: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v82, v81, v82                 // 00000015241C: D6FC6A5B 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152424: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 000000152428: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 00000015242C: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152434: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 000000152438: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 00000015243C: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152444: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 000000152448: D6370059 0572B559
	v_div_fixup_f32 v89, v89, v81, v82                         // 000000152450: D6270059 054AA359
	v_mad_i64_i32 v[81:82], null, 0x3000, v121, v[129:130]     // 000000152458: D6FF7C51 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152464: BF870092
	v_bfe_u32 v90, v89, 16, 1                                  // 000000152468: D610005A 02052159
	v_add3_u32 v89, v89, v90, 0x7fff                           // 000000152470: D6550059 03FEB559 00007FFF
	global_store_d16_hi_b16 v[81:82], v89, off offset:160      // 00000015247C: DC9600A0 007C5951
	s_or_b32 exec_lo, exec_lo, s8                              // 000000152484: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000152488: BE882002
	s_cbranch_execz 62758                                      // 00000015248C: BFA5F526 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3428>
	v_mad_i64_i32 v[81:82], null, 0x6000, v122, v[131:132]     // 000000152490: D6FF7C51 060EF4FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000015249C: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000001524A4: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000001524A8: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001524AC: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000001524B0: 10A4A2FF BFB8AA3B
	v_fma_f32 v89, 0xbfb8aa3b, v81, -v82                       // 0000001524B8: D6130059 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v90, v82                                   // 0000001524C4: 7EB44752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001524C8: BF870221
	v_sub_f32_e32 v82, v82, v90                                // 0000001524CC: 08A4B552
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 0000001524D0: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v89, v81, 0xb2a5705f, v89                      // 0000001524D8: 58B2B351 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001524E0: BF870121
	v_add_f32_e32 v82, v82, v89                                // 0000001524E4: 06A4B352
	v_cvt_i32_f32_e32 v89, v90                                 // 0000001524E8: 7EB2115A
	v_exp_f32_e32 v82, v82                                     // 0000001524EC: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001524F0: BF870095
	.long 0xd71c0052                                           // 0000001524F4: D71C0052
	v_cndmask_b32_e32 v1, v82, v89, vcc_lo                     // 0000001524F8: 0202B352
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 0000001524FC: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000152500: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152508: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v137, v83// 00000015250C: CA46A4FF 5152A789 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000152518: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015251C: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000152520: D6FC7C53 054AA351
	v_rcp_f32_e32 v89, v83                                     // 000000152528: 7EB25553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015252C: BF870095
	v_fma_f32 v90, -v83, v89, 1.0                              // 000000152530: D613005A 23CAB353
	v_fmac_f32_e32 v89, v90, v89                               // 000000152538: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v82, v81, v82                 // 00000015253C: D6FC6A5A 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152544: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 000000152548: 10B6B35A
	v_fma_f32 v92, -v83, v91, v90                              // 00000015254C: D613005C 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152554: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 000000152558: 56B6B35C
	v_fma_f32 v83, -v83, v91, v90                              // 00000015255C: D6130053 256AB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152564: BF870091
	v_div_fmas_f32 v83, v83, v89, v91                          // 000000152568: D6370053 056EB353
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000152570: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v122, v[129:130]     // 000000152578: D6FF7C51 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152584: BF870092
	v_bfe_u32 v89, v83, 16, 1                                  // 000000152588: D6100059 02052153
	v_add3_u32 v83, v83, v89, 0x7fff                           // 000000152590: D6550053 03FEB353 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 00000015259C: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001525A4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001525A8: BE882003
	s_cbranch_execz 62689                                      // 0000001525AC: BFA5F4E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3434>
	v_mad_i64_i32 v[81:82], null, 0x6000, v123, v[131:132]     // 0000001525B0: D6FF7C51 060EF6FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000001525BC: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000001525C4: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000001525C8: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001525CC: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000001525D0: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000001525D8: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v89, v82                                   // 0000001525E4: 7EB24752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001525E8: BF870091
	v_dual_fmamk_f32 v83, v81, 0xb2a5705f, v83 :: v_dual_sub_f32 v82, v82, v89// 0000001525EC: C88AA751 5352B352 B2A5705F
	v_add_f32_e32 v82, v82, v83                                // 0000001525F8: 06A4A752
	v_cvt_i32_f32_e32 v83, v89                                 // 0000001525FC: 7EA61159
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000152600: 7C3CA2FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000152608: BF870293
	v_exp_f32_e32 v82, v82                                     // 00000015260C: 7EA44B52
	.long 0xd71c0052                                           // 000000152610: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000152614: 0202A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152618: BF870121
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000015261C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000152620: 7C36A2FF C2B17218
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v138, v84// 000000152628: CA46A4FF 5152A98A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152634: BF870091
	v_add_f32_e32 v81, 1.0, v81                                // 000000152638: 06A2A2F2
	v_div_scale_f32 v83, null, v81, v81, v82                   // 00000015263C: D6FC7C53 054AA351
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000152644: BF870291
	v_rcp_f32_e32 v84, v83                                     // 000000152648: 7EA85553
	v_fma_f32 v89, -v83, v84, 1.0                              // 00000015264C: D6130059 23CAA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000152654: BF8700A1
	v_fmac_f32_e32 v84, v89, v84                               // 000000152658: 56A8A959
	v_div_scale_f32 v89, vcc_lo, v82, v81, v82                 // 00000015265C: D6FC6A59 054AA352
	v_mul_f32_e32 v90, v89, v84                                // 000000152664: 10B4A959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152668: BF870091
	v_fma_f32 v91, -v83, v90, v89                              // 00000015266C: D613005B 2566B553
	v_fmac_f32_e32 v90, v91, v84                               // 000000152674: 56B4A95B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152678: BF870091
	v_fma_f32 v83, -v83, v90, v89                              // 00000015267C: D6130053 2566B553
	v_div_fmas_f32 v83, v83, v84, v90                          // 000000152684: D6370053 056AA953
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015268C: BF870121
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000152690: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v123, v[129:130]     // 000000152698: D6FF7C51 0606F6FF 00003000
	v_bfe_u32 v84, v83, 16, 1                                  // 0000001526A4: D6100054 02052153
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001526AC: BF870001
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000001526B0: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000001526BC: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001526C4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001526C8: BE882004
	s_cbranch_execz 62620                                      // 0000001526CC: BFA5F49C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3440>
	v_mad_i64_i32 v[81:82], null, 0x6000, v124, v[131:132]     // 0000001526D0: D6FF7C51 060EF8FF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000001526DC: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 0000001526E4: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 0000001526E8: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001526EC: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 0000001526F0: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 0000001526F8: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000152704: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000152708: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000015270C: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000152710: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000152718: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152720: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000152724: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000152728: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000015272C: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152730: BF870095
	.long 0xd71c0052                                           // 000000152734: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000152738: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000015273C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000152740: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152748: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v135, v85// 00000015274C: CA46A4FF 5152AB87 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000152758: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015275C: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000152760: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000152768: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015276C: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000152770: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000152778: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000015277C: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152784: BF870091
	v_mul_f32_e32 v89, v85, v84                                // 000000152788: 10B2A955
	v_fma_f32 v90, -v83, v89, v85                              // 00000015278C: D613005A 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152794: BF870091
	v_fmac_f32_e32 v89, v90, v84                               // 000000152798: 56B2A95A
	v_fma_f32 v83, -v83, v89, v85                              // 00000015279C: D6130053 2556B353
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001527A4: BF870091
	v_div_fmas_f32 v83, v83, v84, v89                          // 0000001527A8: D6370053 0566A953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000001527B0: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v124, v[129:130]     // 0000001527B8: D6FF7C51 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001527C4: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000001527C8: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000001527D0: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000001527DC: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001527E4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001527E8: BE882005
	s_cbranch_execz 62551                                      // 0000001527EC: BFA5F457 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x344c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v125, v[131:132]     // 0000001527F0: D6FF7C51 060EFAFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 0000001527FC: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000152804: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000152808: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015280C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000152810: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000152818: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000152824: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000152828: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000015282C: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000152830: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000152838: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152840: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000152844: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000152848: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000015284C: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152850: BF870095
	.long 0xd71c0052                                           // 000000152854: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000152858: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000015285C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000152860: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152868: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 00000015286C: 02A2A4FF 7F800000
	v_dual_mul_f32 v82, v136, v86 :: v_dual_add_f32 v81, 1.0, v81// 000000152874: C8C8AD88 5250A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015287C: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000152880: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000152888: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015288C: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000152890: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000152898: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 00000015289C: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001528A4: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000001528A8: 10ACA955
	v_fma_f32 v89, -v83, v86, v85                              // 0000001528AC: D6130059 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001528B4: BF870091
	v_fmac_f32_e32 v86, v89, v84                               // 0000001528B8: 56ACA959
	v_fma_f32 v83, -v83, v86, v85                              // 0000001528BC: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001528C4: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000001528C8: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000001528D0: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v125, v[129:130]     // 0000001528D8: D6FF7C51 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001528E4: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 0000001528E8: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 0000001528F0: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 0000001528FC: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000152904: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000152908: BE882006
	s_cbranch_execz 62482                                      // 00000015290C: BFA5F412 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3458>
	v_mad_i64_i32 v[81:82], null, 0x6000, v126, v[131:132]     // 000000152910: D6FF7C51 060EFCFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 00000015291C: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000152924: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000152928: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015292C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000152930: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000152938: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000152944: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000152948: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 00000015294C: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000152950: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000152958: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152960: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000152964: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000152968: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 00000015296C: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152970: BF870095
	.long 0xd71c0052                                           // 000000152974: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000152978: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 00000015297C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000152980: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152988: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v133, v87// 00000015298C: CA46A4FF 5152AF85 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000152998: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015299C: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 0000001529A0: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 0000001529A8: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001529AC: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 0000001529B0: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 0000001529B8: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 0000001529BC: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001529C4: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 0000001529C8: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 0000001529CC: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001529D4: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 0000001529D8: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 0000001529DC: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001529E4: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 0000001529E8: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 0000001529F0: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v126, v[129:130]     // 0000001529F8: D6FF7C51 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152A04: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000152A08: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000152A10: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000152A1C: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000152A24: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000152A28: BE882007
	s_cbranch_execz 62413                                      // 000000152A2C: BFA5F3CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3464>
	v_mad_i64_i32 v[81:82], null, 0x6000, v127, v[131:132]     // 000000152A30: D6FF7C51 060EFEFF 00006000
	global_load_u16 v81, v[81:82], off offset:672              // 000000152A3C: DC4A02A0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000152A44: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000152A48: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152A4C: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000152A50: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000152A58: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000152A64: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000152A68: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000152A6C: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000152A70: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000152A78: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152A80: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000152A84: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000152A88: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000152A8C: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152A90: BF870095
	.long 0xd71c0052                                           // 000000152A94: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000152A98: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000152A9C: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000152AA0: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152AA8: BF870092
	v_dual_cndmask_b32 v81, 0x7f800000, v82 :: v_dual_mul_f32 v82, v134, v88// 000000152AAC: CA46A4FF 5152B186 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000152AB8: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152ABC: BF870091
	v_div_scale_f32 v83, null, v81, v81, v82                   // 000000152AC0: D6FC7C53 054AA351
	v_rcp_f32_e32 v84, v83                                     // 000000152AC8: 7EA85553
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152ACC: BF870095
	v_fma_f32 v85, -v83, v84, 1.0                              // 000000152AD0: D6130055 23CAA953
	v_fmac_f32_e32 v84, v85, v84                               // 000000152AD8: 56A8A955
	v_div_scale_f32 v85, vcc_lo, v82, v81, v82                 // 000000152ADC: D6FC6A55 054AA352
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152AE4: BF870091
	v_mul_f32_e32 v86, v85, v84                                // 000000152AE8: 10ACA955
	v_fma_f32 v87, -v83, v86, v85                              // 000000152AEC: D6130057 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152AF4: BF870091
	v_fmac_f32_e32 v86, v87, v84                               // 000000152AF8: 56ACA957
	v_fma_f32 v83, -v83, v86, v85                              // 000000152AFC: D6130053 2556AD53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152B04: BF870091
	v_div_fmas_f32 v83, v83, v84, v86                          // 000000152B08: D6370053 055AA953
	v_div_fixup_f32 v83, v83, v81, v82                         // 000000152B10: D6270053 054AA353
	v_mad_i64_i32 v[81:82], null, 0x3000, v127, v[129:130]     // 000000152B18: D6FF7C51 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152B24: BF870092
	v_bfe_u32 v84, v83, 16, 1                                  // 000000152B28: D6100054 02052153
	v_add3_u32 v83, v83, v84, 0x7fff                           // 000000152B30: D6550053 03FEA953 00007FFF
	global_store_d16_hi_b16 v[81:82], v83, off offset:160      // 000000152B3C: DC9600A0 007C5351
	s_or_b32 exec_lo, exec_lo, s8                              // 000000152B44: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000152B48: BE882000
	s_cbranch_execz 62344                                      // 000000152B4C: BFA5F388 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3470>
	v_mad_i64_i32 v[81:82], null, 0x6000, v0, v[131:132]       // 000000152B50: D6FF7C51 060E00FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 000000152B5C: 1092938B
	global_load_u16 v81, v[81:82], off offset:704              // 000000152B60: DC4A02C0 517C0051
	s_waitcnt vmcnt(0)                                         // 000000152B68: BF8903F7
	v_lshlrev_b32_e32 v81, 16, v81                             // 000000152B6C: 30A2A290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152B70: BF870091
	v_mul_f32_e32 v82, 0xbfb8aa3b, v81                         // 000000152B74: 10A4A2FF BFB8AA3B
	v_fma_f32 v83, 0xbfb8aa3b, v81, -v82                       // 000000152B7C: D6130053 854AA2FF BFB8AA3B
	v_rndne_f32_e32 v84, v82                                   // 000000152B88: 7EA84752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000152B8C: BF870221
	v_sub_f32_e32 v82, v82, v84                                // 000000152B90: 08A4A952
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v81                  // 000000152B94: 7C3CA2FF 42CE8ED0
	v_fmamk_f32 v83, v81, 0xb2a5705f, v83                      // 000000152B9C: 58A6A751 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152BA4: BF870121
	v_add_f32_e32 v82, v82, v83                                // 000000152BA8: 06A4A752
	v_cvt_i32_f32_e32 v83, v84                                 // 000000152BAC: 7EA61154
	v_exp_f32_e32 v82, v82                                     // 000000152BB0: 7EA44B52
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152BB4: BF870095
	.long 0xd71c0052                                           // 000000152BB8: D71C0052
	v_cndmask_b32_e32 v1, v82, v83, vcc_lo                     // 000000152BBC: 0202A752
	v_cndmask_b32_e32 v82, 0, v82, vcc_lo                      // 000000152BC0: 02A4A480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v81                  // 000000152BC4: 7C36A2FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152BCC: BF870092
	v_cndmask_b32_e32 v81, 0x7f800000, v82, vcc_lo             // 000000152BD0: 02A2A4FF 7F800000
	v_add_f32_e32 v81, 1.0, v81                                // 000000152BD8: 06A2A2F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152BDC: BF870091
	v_div_scale_f32 v82, null, v81, v81, v73                   // 000000152BE0: D6FC7C52 0526A351
	v_rcp_f32_e32 v83, v82                                     // 000000152BE8: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152BEC: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 000000152BF0: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 000000152BF8: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v73, v81, v73                 // 000000152BFC: D6FC6A54 0526A349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152C04: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 000000152C08: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 000000152C0C: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152C14: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 000000152C18: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 000000152C1C: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152C24: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 000000152C28: D6370052 0556A752
	v_div_fixup_f32 v73, v82, v81, v73                         // 000000152C30: D6270049 0526A352
	v_mad_i64_i32 v[81:82], null, 0x3000, v0, v[129:130]       // 000000152C38: D6FF7C51 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152C44: BF870092
	v_bfe_u32 v83, v73, 16, 1                                  // 000000152C48: D6100053 02052149
	v_add3_u32 v73, v73, v83, 0x7fff                           // 000000152C50: D6550049 03FEA749 00007FFF
	global_store_d16_hi_b16 v[81:82], v73, off offset:192      // 000000152C5C: DC9600C0 007C4951
	s_or_b32 exec_lo, exec_lo, s8                              // 000000152C64: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000152C68: BE882001
	s_cbranch_execz 62275                                      // 000000152C6C: BFA5F343 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x347c>
	v_mad_i64_i32 v[81:82], null, 0x6000, v121, v[131:132]     // 000000152C70: D6FF7C51 060EF2FF 00006000
	v_mul_f32_e32 v74, v140, v74                               // 000000152C7C: 1094958C
	global_load_u16 v73, v[81:82], off offset:704              // 000000152C80: DC4A02C0 497C0051
	s_waitcnt vmcnt(0)                                         // 000000152C88: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000152C8C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152C90: BF870121
	v_mul_f32_e32 v81, 0xbfb8aa3b, v73                         // 000000152C94: 10A292FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000152C9C: 7C3C92FF 42CE8ED0
	v_fma_f32 v82, 0xbfb8aa3b, v73, -v81                       // 000000152CA4: D6130052 854692FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 000000152CB0: 7EA64751
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000152CB4: BF870112
	v_fmamk_f32 v82, v73, 0xb2a5705f, v82                      // 000000152CB8: 58A4A549 B2A5705F
	v_sub_f32_e32 v81, v81, v83                                // 000000152CC0: 08A2A751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152CC4: BF870121
	v_add_f32_e32 v81, v81, v82                                // 000000152CC8: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 000000152CCC: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 000000152CD0: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152CD4: BF870095
	.long 0xd71c0051                                           // 000000152CD8: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 000000152CDC: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 000000152CE0: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000152CE4: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152CEC: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v81, vcc_lo             // 000000152CF0: 0292A2FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000152CF8: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152CFC: BF870091
	v_div_scale_f32 v81, null, v73, v73, v74                   // 000000152D00: D6FC7C51 052A9349
	v_rcp_f32_e32 v82, v81                                     // 000000152D08: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152D0C: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 000000152D10: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 000000152D18: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v74, v73, v74                 // 000000152D1C: D6FC6A53 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152D24: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 000000152D28: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 000000152D2C: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152D34: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 000000152D38: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 000000152D3C: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152D44: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 000000152D48: D6370051 0552A551
	v_div_fixup_f32 v81, v81, v73, v74                         // 000000152D50: D6270051 052A9351
	v_mad_i64_i32 v[73:74], null, 0x3000, v121, v[129:130]     // 000000152D58: D6FF7C49 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152D64: BF870092
	v_bfe_u32 v82, v81, 16, 1                                  // 000000152D68: D6100052 02052151
	v_add3_u32 v81, v81, v82, 0x7fff                           // 000000152D70: D6550051 03FEA551 00007FFF
	global_store_d16_hi_b16 v[73:74], v81, off offset:192      // 000000152D7C: DC9600C0 007C5149
	s_or_b32 exec_lo, exec_lo, s8                              // 000000152D84: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000152D88: BE882002
	s_cbranch_execz 62206                                      // 000000152D8C: BFA5F2FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3488>
	v_mad_i64_i32 v[73:74], null, 0x6000, v122, v[131:132]     // 000000152D90: D6FF7C49 060EF4FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000152D9C: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000152DA4: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000152DA8: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152DAC: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000152DB0: 109492FF BFB8AA3B
	v_fma_f32 v81, 0xbfb8aa3b, v73, -v74                       // 000000152DB8: D6130051 852A92FF BFB8AA3B
	v_rndne_f32_e32 v82, v74                                   // 000000152DC4: 7EA4474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000152DC8: BF870221
	v_sub_f32_e32 v74, v74, v82                                // 000000152DCC: 0894A54A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000152DD0: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v81, v73, 0xb2a5705f, v81                      // 000000152DD8: 58A2A349 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152DE0: BF870121
	v_add_f32_e32 v74, v74, v81                                // 000000152DE4: 0694A34A
	v_cvt_i32_f32_e32 v81, v82                                 // 000000152DE8: 7EA21152
	v_exp_f32_e32 v74, v74                                     // 000000152DEC: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152DF0: BF870095
	.long 0xd71c004a                                           // 000000152DF4: D71C004A
	v_cndmask_b32_e32 v1, v74, v81, vcc_lo                     // 000000152DF8: 0202A34A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000152DFC: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000152E00: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152E08: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v137, v75// 000000152E0C: CA4694FF 494A9789 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000152E18: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152E1C: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000152E20: D6FC7C4B 052A9349
	v_rcp_f32_e32 v81, v75                                     // 000000152E28: 7EA2554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152E2C: BF870095
	v_fma_f32 v82, -v75, v81, 1.0                              // 000000152E30: D6130052 23CAA34B
	v_fmac_f32_e32 v81, v82, v81                               // 000000152E38: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v74, v73, v74                 // 000000152E3C: D6FC6A52 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152E44: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 000000152E48: 10A6A352
	v_fma_f32 v84, -v75, v83, v82                              // 000000152E4C: D6130054 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152E54: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 000000152E58: 56A6A354
	v_fma_f32 v75, -v75, v83, v82                              // 000000152E5C: D613004B 254AA74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152E64: BF870091
	v_div_fmas_f32 v75, v75, v81, v83                          // 000000152E68: D637004B 054EA34B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000152E70: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v122, v[129:130]     // 000000152E78: D6FF7C49 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152E84: BF870092
	v_bfe_u32 v81, v75, 16, 1                                  // 000000152E88: D6100051 0205214B
	v_add3_u32 v75, v75, v81, 0x7fff                           // 000000152E90: D655004B 03FEA34B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000152E9C: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000152EA4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000152EA8: BE882003
	s_cbranch_execz 62137                                      // 000000152EAC: BFA5F2B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3494>
	v_mad_i64_i32 v[73:74], null, 0x6000, v123, v[131:132]     // 000000152EB0: D6FF7C49 060EF6FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000152EBC: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000152EC4: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000152EC8: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152ECC: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000152ED0: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000152ED8: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v81, v74                                   // 000000152EE4: 7EA2474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152EE8: BF870091
	v_dual_fmamk_f32 v75, v73, 0xb2a5705f, v75 :: v_dual_sub_f32 v74, v74, v81// 000000152EEC: C88A9749 4B4AA34A B2A5705F
	v_add_f32_e32 v74, v74, v75                                // 000000152EF8: 0694974A
	v_cvt_i32_f32_e32 v75, v81                                 // 000000152EFC: 7E961151
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000152F00: 7C3C92FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000152F08: BF870293
	v_exp_f32_e32 v74, v74                                     // 000000152F0C: 7E944B4A
	.long 0xd71c004a                                           // 000000152F10: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000152F14: 0202974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152F18: BF870121
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 000000152F1C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000152F20: 7C3692FF C2B17218
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v138, v76// 000000152F28: CA4694FF 494A998A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152F34: BF870091
	v_add_f32_e32 v73, 1.0, v73                                // 000000152F38: 069292F2
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000152F3C: D6FC7C4B 052A9349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000152F44: BF870291
	v_rcp_f32_e32 v76, v75                                     // 000000152F48: 7E98554B
	v_fma_f32 v81, -v75, v76, 1.0                              // 000000152F4C: D6130051 23CA994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000152F54: BF8700A1
	v_fmac_f32_e32 v76, v81, v76                               // 000000152F58: 56989951
	v_div_scale_f32 v81, vcc_lo, v74, v73, v74                 // 000000152F5C: D6FC6A51 052A934A
	v_mul_f32_e32 v82, v81, v76                                // 000000152F64: 10A49951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152F68: BF870091
	v_fma_f32 v83, -v75, v82, v81                              // 000000152F6C: D6130053 2546A54B
	v_fmac_f32_e32 v82, v83, v76                               // 000000152F74: 56A49953
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152F78: BF870091
	v_fma_f32 v75, -v75, v82, v81                              // 000000152F7C: D613004B 2546A54B
	v_div_fmas_f32 v75, v75, v76, v82                          // 000000152F84: D637004B 054A994B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000152F8C: BF870121
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000152F90: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v123, v[129:130]     // 000000152F98: D6FF7C49 0606F6FF 00003000
	v_bfe_u32 v76, v75, 16, 1                                  // 000000152FA4: D610004C 0205214B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000152FAC: BF870001
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000152FB0: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 000000152FBC: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000152FC4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000152FC8: BE882004
	s_cbranch_execz 62068                                      // 000000152FCC: BFA5F274 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34a0>
	v_mad_i64_i32 v[73:74], null, 0x6000, v124, v[131:132]     // 000000152FD0: D6FF7C49 060EF8FF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 000000152FDC: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000152FE4: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000152FE8: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000152FEC: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000152FF0: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000152FF8: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000153004: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000153008: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000015300C: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000153010: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000153018: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000153020: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000153024: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000153028: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000015302C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153030: BF870095
	.long 0xd71c004a                                           // 000000153034: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000153038: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000015303C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000153040: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153048: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v135, v77// 00000015304C: CA4694FF 494A9B87 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000153058: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015305C: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000153060: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000153068: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015306C: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000153070: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000153078: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 00000015307C: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153084: BF870091
	v_mul_f32_e32 v81, v77, v76                                // 000000153088: 10A2994D
	v_fma_f32 v82, -v75, v81, v77                              // 00000015308C: D6130052 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153094: BF870091
	v_fmac_f32_e32 v81, v82, v76                               // 000000153098: 56A29952
	v_fma_f32 v75, -v75, v81, v77                              // 00000015309C: D613004B 2536A34B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001530A4: BF870091
	v_div_fmas_f32 v75, v75, v76, v81                          // 0000001530A8: D637004B 0546994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000001530B0: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v124, v[129:130]     // 0000001530B8: D6FF7C49 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001530C4: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000001530C8: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000001530D0: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000001530DC: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001530E4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001530E8: BE882005
	s_cbranch_execz 61999                                      // 0000001530EC: BFA5F22F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34ac>
	v_mad_i64_i32 v[73:74], null, 0x6000, v125, v[131:132]     // 0000001530F0: D6FF7C49 060EFAFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 0000001530FC: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000153104: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000153108: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015310C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000153110: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000153118: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000153124: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000153128: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000015312C: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000153130: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000153138: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000153140: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000153144: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000153148: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000015314C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153150: BF870095
	.long 0xd71c004a                                           // 000000153154: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000153158: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000015315C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000153160: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153168: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 00000015316C: 029294FF 7F800000
	v_dual_mul_f32 v74, v136, v78 :: v_dual_add_f32 v73, 1.0, v73// 000000153174: C8C89D88 4A4892F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015317C: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 000000153180: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 000000153188: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015318C: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 000000153190: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 000000153198: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 00000015319C: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001531A4: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000001531A8: 109C994D
	v_fma_f32 v81, -v75, v78, v77                              // 0000001531AC: D6130051 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001531B4: BF870091
	v_fmac_f32_e32 v78, v81, v76                               // 0000001531B8: 569C9951
	v_fma_f32 v75, -v75, v78, v77                              // 0000001531BC: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001531C4: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000001531C8: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000001531D0: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v125, v[129:130]     // 0000001531D8: D6FF7C49 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001531E4: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 0000001531E8: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 0000001531F0: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 0000001531FC: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000153204: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000153208: BE882006
	s_cbranch_execz 61930                                      // 00000015320C: BFA5F1EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34b8>
	v_mad_i64_i32 v[73:74], null, 0x6000, v126, v[131:132]     // 000000153210: D6FF7C49 060EFCFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000015321C: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000153224: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000153228: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015322C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000153230: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000153238: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000153244: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000153248: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000015324C: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000153250: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000153258: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000153260: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000153264: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000153268: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000015326C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153270: BF870095
	.long 0xd71c004a                                           // 000000153274: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000153278: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000015327C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 000000153280: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153288: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v133, v79// 00000015328C: CA4694FF 494A9F85 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 000000153298: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015329C: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000001532A0: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000001532A8: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001532AC: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000001532B0: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000001532B8: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000001532BC: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001532C4: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000001532C8: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000001532CC: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001532D4: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000001532D8: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000001532DC: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001532E4: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 0000001532E8: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 0000001532F0: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v126, v[129:130]     // 0000001532F8: D6FF7C49 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153304: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000153308: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000153310: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000015331C: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000153324: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000153328: BE882007
	s_cbranch_execz 61861                                      // 00000015332C: BFA5F1A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34c4>
	v_mad_i64_i32 v[73:74], null, 0x6000, v127, v[131:132]     // 000000153330: D6FF7C49 060EFEFF 00006000
	global_load_u16 v73, v[73:74], off offset:704              // 00000015333C: DC4A02C0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000153344: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 000000153348: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015334C: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000153350: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 000000153358: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000153364: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000153368: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 00000015336C: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000153370: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 000000153378: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000153380: BF870121
	v_add_f32_e32 v74, v74, v75                                // 000000153384: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 000000153388: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 00000015338C: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153390: BF870095
	.long 0xd71c004a                                           // 000000153394: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 000000153398: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 00000015339C: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000001533A0: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001533A8: BF870092
	v_dual_cndmask_b32 v73, 0x7f800000, v74 :: v_dual_mul_f32 v74, v134, v80// 0000001533AC: CA4694FF 494AA186 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000001533B8: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001533BC: BF870091
	v_div_scale_f32 v75, null, v73, v73, v74                   // 0000001533C0: D6FC7C4B 052A9349
	v_rcp_f32_e32 v76, v75                                     // 0000001533C8: 7E98554B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001533CC: BF870095
	v_fma_f32 v77, -v75, v76, 1.0                              // 0000001533D0: D613004D 23CA994B
	v_fmac_f32_e32 v76, v77, v76                               // 0000001533D8: 5698994D
	v_div_scale_f32 v77, vcc_lo, v74, v73, v74                 // 0000001533DC: D6FC6A4D 052A934A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001533E4: BF870091
	v_mul_f32_e32 v78, v77, v76                                // 0000001533E8: 109C994D
	v_fma_f32 v79, -v75, v78, v77                              // 0000001533EC: D613004F 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001533F4: BF870091
	v_fmac_f32_e32 v78, v79, v76                               // 0000001533F8: 569C994F
	v_fma_f32 v75, -v75, v78, v77                              // 0000001533FC: D613004B 25369D4B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153404: BF870091
	v_div_fmas_f32 v75, v75, v76, v78                          // 000000153408: D637004B 053A994B
	v_div_fixup_f32 v75, v75, v73, v74                         // 000000153410: D627004B 052A934B
	v_mad_i64_i32 v[73:74], null, 0x3000, v127, v[129:130]     // 000000153418: D6FF7C49 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153424: BF870092
	v_bfe_u32 v76, v75, 16, 1                                  // 000000153428: D610004C 0205214B
	v_add3_u32 v75, v75, v76, 0x7fff                           // 000000153430: D655004B 03FE994B 00007FFF
	global_store_d16_hi_b16 v[73:74], v75, off offset:192      // 00000015343C: DC9600C0 007C4B49
	s_or_b32 exec_lo, exec_lo, s8                              // 000000153444: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000153448: BE882000
	s_cbranch_execz 61792                                      // 00000015344C: BFA5F160 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34d0>
	v_mad_i64_i32 v[73:74], null, 0x6000, v0, v[131:132]       // 000000153450: D6FF7C49 060E00FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 00000015345C: 1082838B
	global_load_u16 v73, v[73:74], off offset:736              // 000000153460: DC4A02E0 497C0049
	s_waitcnt vmcnt(0)                                         // 000000153468: BF8903F7
	v_lshlrev_b32_e32 v73, 16, v73                             // 00000015346C: 30929290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153470: BF870091
	v_mul_f32_e32 v74, 0xbfb8aa3b, v73                         // 000000153474: 109492FF BFB8AA3B
	v_fma_f32 v75, 0xbfb8aa3b, v73, -v74                       // 00000015347C: D613004B 852A92FF BFB8AA3B
	v_rndne_f32_e32 v76, v74                                   // 000000153488: 7E98474A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000015348C: BF870221
	v_sub_f32_e32 v74, v74, v76                                // 000000153490: 0894994A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 000000153494: 7C3C92FF 42CE8ED0
	v_fmamk_f32 v75, v73, 0xb2a5705f, v75                      // 00000015349C: 58969749 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001534A4: BF870121
	v_add_f32_e32 v74, v74, v75                                // 0000001534A8: 0694974A
	v_cvt_i32_f32_e32 v75, v76                                 // 0000001534AC: 7E96114C
	v_exp_f32_e32 v74, v74                                     // 0000001534B0: 7E944B4A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001534B4: BF870095
	.long 0xd71c004a                                           // 0000001534B8: D71C004A
	v_cndmask_b32_e32 v1, v74, v75, vcc_lo                     // 0000001534BC: 0202974A
	v_cndmask_b32_e32 v74, 0, v74, vcc_lo                      // 0000001534C0: 02949480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000001534C4: 7C3692FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001534CC: BF870092
	v_cndmask_b32_e32 v73, 0x7f800000, v74, vcc_lo             // 0000001534D0: 029294FF 7F800000
	v_add_f32_e32 v73, 1.0, v73                                // 0000001534D8: 069292F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001534DC: BF870091
	v_div_scale_f32 v74, null, v73, v73, v65                   // 0000001534E0: D6FC7C4A 05069349
	v_rcp_f32_e32 v75, v74                                     // 0000001534E8: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001534EC: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 0000001534F0: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 0000001534F8: 5696974C
	v_div_scale_f32 v76, vcc_lo, v65, v73, v65                 // 0000001534FC: D6FC6A4C 05069341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153504: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 000000153508: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 00000015350C: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153514: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 000000153518: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 00000015351C: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153524: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 000000153528: D637004A 0536974A
	v_div_fixup_f32 v65, v74, v73, v65                         // 000000153530: D6270041 0506934A
	v_mad_i64_i32 v[73:74], null, 0x3000, v0, v[129:130]       // 000000153538: D6FF7C49 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153544: BF870092
	v_bfe_u32 v75, v65, 16, 1                                  // 000000153548: D610004B 02052141
	v_add3_u32 v65, v65, v75, 0x7fff                           // 000000153550: D6550041 03FE9741 00007FFF
	global_store_d16_hi_b16 v[73:74], v65, off offset:224      // 00000015355C: DC9600E0 007C4149
	s_or_b32 exec_lo, exec_lo, s8                              // 000000153564: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000153568: BE882001
	s_cbranch_execz 61723                                      // 00000015356C: BFA5F11B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34dc>
	v_mad_i64_i32 v[73:74], null, 0x6000, v121, v[131:132]     // 000000153570: D6FF7C49 060EF2FF 00006000
	v_mul_f32_e32 v66, v140, v66                               // 00000015357C: 1084858C
	global_load_u16 v65, v[73:74], off offset:736              // 000000153580: DC4A02E0 417C0049
	s_waitcnt vmcnt(0)                                         // 000000153588: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 00000015358C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000153590: BF870121
	v_mul_f32_e32 v73, 0xbfb8aa3b, v65                         // 000000153594: 109282FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 00000015359C: 7C3C82FF 42CE8ED0
	v_fma_f32 v74, 0xbfb8aa3b, v65, -v73                       // 0000001535A4: D613004A 852682FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000001535B0: 7E964749
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001535B4: BF870112
	v_fmamk_f32 v74, v65, 0xb2a5705f, v74                      // 0000001535B8: 58949541 B2A5705F
	v_sub_f32_e32 v73, v73, v75                                // 0000001535C0: 08929749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001535C4: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000001535C8: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000001535CC: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000001535D0: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001535D4: BF870095
	.long 0xd71c0049                                           // 0000001535D8: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000001535DC: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000001535E0: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 0000001535E4: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001535EC: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v73, vcc_lo             // 0000001535F0: 028292FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 0000001535F8: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001535FC: BF870091
	v_div_scale_f32 v73, null, v65, v65, v66                   // 000000153600: D6FC7C49 050A8341
	v_rcp_f32_e32 v74, v73                                     // 000000153608: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015360C: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 000000153610: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 000000153618: 5694954B
	v_div_scale_f32 v75, vcc_lo, v66, v65, v66                 // 00000015361C: D6FC6A4B 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153624: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 000000153628: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 00000015362C: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153634: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 000000153638: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 00000015363C: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153644: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 000000153648: D6370049 05329549
	v_div_fixup_f32 v73, v73, v65, v66                         // 000000153650: D6270049 050A8349
	v_mad_i64_i32 v[65:66], null, 0x3000, v121, v[129:130]     // 000000153658: D6FF7C41 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153664: BF870092
	v_bfe_u32 v74, v73, 16, 1                                  // 000000153668: D610004A 02052149
	v_add3_u32 v73, v73, v74, 0x7fff                           // 000000153670: D6550049 03FE9549 00007FFF
	global_store_d16_hi_b16 v[65:66], v73, off offset:224      // 00000015367C: DC9600E0 007C4941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000153684: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000153688: BE882002
	s_cbranch_execz 61654                                      // 00000015368C: BFA5F0D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34e8>
	v_mad_i64_i32 v[65:66], null, 0x6000, v122, v[131:132]     // 000000153690: D6FF7C41 060EF4FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 00000015369C: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000001536A4: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000001536A8: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001536AC: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000001536B0: 108482FF BFB8AA3B
	v_fma_f32 v73, 0xbfb8aa3b, v65, -v66                       // 0000001536B8: D6130049 850A82FF BFB8AA3B
	v_rndne_f32_e32 v74, v66                                   // 0000001536C4: 7E944742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001536C8: BF870221
	v_sub_f32_e32 v66, v66, v74                                // 0000001536CC: 08849542
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 0000001536D0: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v73, v65, 0xb2a5705f, v73                      // 0000001536D8: 58929341 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001536E0: BF870121
	v_add_f32_e32 v66, v66, v73                                // 0000001536E4: 06849342
	v_cvt_i32_f32_e32 v73, v74                                 // 0000001536E8: 7E92114A
	v_exp_f32_e32 v66, v66                                     // 0000001536EC: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001536F0: BF870095
	.long 0xd71c0042                                           // 0000001536F4: D71C0042
	v_cndmask_b32_e32 v1, v66, v73, vcc_lo                     // 0000001536F8: 02029342
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 0000001536FC: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000153700: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153708: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v137, v67// 00000015370C: CA4684FF 41428789 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000153718: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015371C: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000153720: D6FC7C43 050A8341
	v_rcp_f32_e32 v73, v67                                     // 000000153728: 7E925543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015372C: BF870095
	v_fma_f32 v74, -v67, v73, 1.0                              // 000000153730: D613004A 23CA9343
	v_fmac_f32_e32 v73, v74, v73                               // 000000153738: 5692934A
	v_div_scale_f32 v74, vcc_lo, v66, v65, v66                 // 00000015373C: D6FC6A4A 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153744: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 000000153748: 1096934A
	v_fma_f32 v76, -v67, v75, v74                              // 00000015374C: D613004C 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153754: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 000000153758: 5696934C
	v_fma_f32 v67, -v67, v75, v74                              // 00000015375C: D6130043 252A9743
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153764: BF870091
	v_div_fmas_f32 v67, v67, v73, v75                          // 000000153768: D6370043 052E9343
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000153770: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v122, v[129:130]     // 000000153778: D6FF7C41 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153784: BF870092
	v_bfe_u32 v73, v67, 16, 1                                  // 000000153788: D6100049 02052143
	v_add3_u32 v67, v67, v73, 0x7fff                           // 000000153790: D6550043 03FE9343 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 00000015379C: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001537A4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001537A8: BE882003
	s_cbranch_execz 61585                                      // 0000001537AC: BFA5F091 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34f4>
	v_mad_i64_i32 v[65:66], null, 0x6000, v123, v[131:132]     // 0000001537B0: D6FF7C41 060EF6FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000001537BC: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000001537C4: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000001537C8: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001537CC: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000001537D0: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000001537D8: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v73, v66                                   // 0000001537E4: 7E924742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001537E8: BF870091
	v_dual_fmamk_f32 v67, v65, 0xb2a5705f, v67 :: v_dual_sub_f32 v66, v66, v73// 0000001537EC: C88A8741 43429342 B2A5705F
	v_add_f32_e32 v66, v66, v67                                // 0000001537F8: 06848742
	v_cvt_i32_f32_e32 v67, v73                                 // 0000001537FC: 7E861149
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000153800: 7C3C82FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000153808: BF870293
	v_exp_f32_e32 v66, v66                                     // 00000015380C: 7E844B42
	.long 0xd71c0042                                           // 000000153810: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000153814: 02028742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000153818: BF870121
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000015381C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000153820: 7C3682FF C2B17218
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v138, v68// 000000153828: CA4684FF 4142898A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153834: BF870091
	v_add_f32_e32 v65, 1.0, v65                                // 000000153838: 068282F2
	v_div_scale_f32 v67, null, v65, v65, v66                   // 00000015383C: D6FC7C43 050A8341
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000153844: BF870291
	v_rcp_f32_e32 v68, v67                                     // 000000153848: 7E885543
	v_fma_f32 v73, -v67, v68, 1.0                              // 00000015384C: D6130049 23CA8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000153854: BF8700A1
	v_fmac_f32_e32 v68, v73, v68                               // 000000153858: 56888949
	v_div_scale_f32 v73, vcc_lo, v66, v65, v66                 // 00000015385C: D6FC6A49 050A8342
	v_mul_f32_e32 v74, v73, v68                                // 000000153864: 10948949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153868: BF870091
	v_fma_f32 v75, -v67, v74, v73                              // 00000015386C: D613004B 25269543
	v_fmac_f32_e32 v74, v75, v68                               // 000000153874: 5694894B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153878: BF870091
	v_fma_f32 v67, -v67, v74, v73                              // 00000015387C: D6130043 25269543
	v_div_fmas_f32 v67, v67, v68, v74                          // 000000153884: D6370043 052A8943
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015388C: BF870121
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000153890: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v123, v[129:130]     // 000000153898: D6FF7C41 0606F6FF 00003000
	v_bfe_u32 v68, v67, 16, 1                                  // 0000001538A4: D6100044 02052143
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001538AC: BF870001
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000001538B0: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000001538BC: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001538C4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001538C8: BE882004
	s_cbranch_execz 61516                                      // 0000001538CC: BFA5F04C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3500>
	v_mad_i64_i32 v[65:66], null, 0x6000, v124, v[131:132]     // 0000001538D0: D6FF7C41 060EF8FF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000001538DC: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 0000001538E4: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 0000001538E8: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001538EC: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 0000001538F0: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 0000001538F8: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000153904: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000153908: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 00000015390C: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000153910: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000153918: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000153920: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000153924: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000153928: 7E861144
	v_exp_f32_e32 v66, v66                                     // 00000015392C: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153930: BF870095
	.long 0xd71c0042                                           // 000000153934: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000153938: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000015393C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000153940: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153948: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v135, v69// 00000015394C: CA4684FF 41428B87 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000153958: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015395C: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000153960: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000153968: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015396C: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000153970: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000153978: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 00000015397C: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153984: BF870091
	v_mul_f32_e32 v73, v69, v68                                // 000000153988: 10928945
	v_fma_f32 v74, -v67, v73, v69                              // 00000015398C: D613004A 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153994: BF870091
	v_fmac_f32_e32 v73, v74, v68                               // 000000153998: 5692894A
	v_fma_f32 v67, -v67, v73, v69                              // 00000015399C: D6130043 25169343
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001539A4: BF870091
	v_div_fmas_f32 v67, v67, v68, v73                          // 0000001539A8: D6370043 05268943
	v_div_fixup_f32 v67, v67, v65, v66                         // 0000001539B0: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v124, v[129:130]     // 0000001539B8: D6FF7C41 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001539C4: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 0000001539C8: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 0000001539D0: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 0000001539DC: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001539E4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001539E8: BE882005
	s_cbranch_execz 61447                                      // 0000001539EC: BFA5F007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x350c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v125, v[131:132]     // 0000001539F0: D6FF7C41 060EFAFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 0000001539FC: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000153A04: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000153A08: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153A0C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000153A10: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000153A18: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000153A24: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000153A28: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000153A2C: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000153A30: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000153A38: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000153A40: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000153A44: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000153A48: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000153A4C: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153A50: BF870095
	.long 0xd71c0042                                           // 000000153A54: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000153A58: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000153A5C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000153A60: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153A68: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000153A6C: 028284FF 7F800000
	v_dual_mul_f32 v66, v136, v70 :: v_dual_add_f32 v65, 1.0, v65// 000000153A74: C8C88D88 424082F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153A7C: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000153A80: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000153A88: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153A8C: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000153A90: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000153A98: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000153A9C: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153AA4: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000153AA8: 108C8945
	v_fma_f32 v73, -v67, v70, v69                              // 000000153AAC: D6130049 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153AB4: BF870091
	v_fmac_f32_e32 v70, v73, v68                               // 000000153AB8: 568C8949
	v_fma_f32 v67, -v67, v70, v69                              // 000000153ABC: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153AC4: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000153AC8: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000153AD0: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v125, v[129:130]     // 000000153AD8: D6FF7C41 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153AE4: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000153AE8: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000153AF0: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000153AFC: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000153B04: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000153B08: BE882006
	s_cbranch_execz 61378                                      // 000000153B0C: BFA5EFC2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3518>
	v_mad_i64_i32 v[65:66], null, 0x6000, v126, v[131:132]     // 000000153B10: D6FF7C41 060EFCFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000153B1C: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000153B24: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000153B28: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153B2C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000153B30: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000153B38: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000153B44: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000153B48: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000153B4C: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000153B50: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000153B58: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000153B60: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000153B64: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000153B68: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000153B6C: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153B70: BF870095
	.long 0xd71c0042                                           // 000000153B74: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000153B78: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000153B7C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000153B80: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153B88: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v133, v71// 000000153B8C: CA4684FF 41428F85 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000153B98: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153B9C: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000153BA0: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000153BA8: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153BAC: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000153BB0: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000153BB8: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000153BBC: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153BC4: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000153BC8: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000153BCC: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153BD4: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 000000153BD8: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000153BDC: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153BE4: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000153BE8: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000153BF0: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v126, v[129:130]     // 000000153BF8: D6FF7C41 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153C04: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000153C08: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000153C10: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000153C1C: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000153C24: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000153C28: BE882007
	s_cbranch_execz 61309                                      // 000000153C2C: BFA5EF7D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3524>
	v_mad_i64_i32 v[65:66], null, 0x6000, v127, v[131:132]     // 000000153C30: D6FF7C41 060EFEFF 00006000
	global_load_u16 v65, v[65:66], off offset:736              // 000000153C3C: DC4A02E0 417C0041
	s_waitcnt vmcnt(0)                                         // 000000153C44: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000153C48: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153C4C: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000153C50: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000153C58: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000153C64: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000153C68: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000153C6C: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000153C70: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000153C78: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000153C80: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000153C84: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000153C88: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000153C8C: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153C90: BF870095
	.long 0xd71c0042                                           // 000000153C94: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000153C98: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000153C9C: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000153CA0: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153CA8: BF870092
	v_dual_cndmask_b32 v65, 0x7f800000, v66 :: v_dual_mul_f32 v66, v134, v72// 000000153CAC: CA4684FF 41429186 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000153CB8: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153CBC: BF870091
	v_div_scale_f32 v67, null, v65, v65, v66                   // 000000153CC0: D6FC7C43 050A8341
	v_rcp_f32_e32 v68, v67                                     // 000000153CC8: 7E885543
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153CCC: BF870095
	v_fma_f32 v69, -v67, v68, 1.0                              // 000000153CD0: D6130045 23CA8943
	v_fmac_f32_e32 v68, v69, v68                               // 000000153CD8: 56888945
	v_div_scale_f32 v69, vcc_lo, v66, v65, v66                 // 000000153CDC: D6FC6A45 050A8342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153CE4: BF870091
	v_mul_f32_e32 v70, v69, v68                                // 000000153CE8: 108C8945
	v_fma_f32 v71, -v67, v70, v69                              // 000000153CEC: D6130047 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153CF4: BF870091
	v_fmac_f32_e32 v70, v71, v68                               // 000000153CF8: 568C8947
	v_fma_f32 v67, -v67, v70, v69                              // 000000153CFC: D6130043 25168D43
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153D04: BF870091
	v_div_fmas_f32 v67, v67, v68, v70                          // 000000153D08: D6370043 051A8943
	v_div_fixup_f32 v67, v67, v65, v66                         // 000000153D10: D6270043 050A8343
	v_mad_i64_i32 v[65:66], null, 0x3000, v127, v[129:130]     // 000000153D18: D6FF7C41 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153D24: BF870092
	v_bfe_u32 v68, v67, 16, 1                                  // 000000153D28: D6100044 02052143
	v_add3_u32 v67, v67, v68, 0x7fff                           // 000000153D30: D6550043 03FE8943 00007FFF
	global_store_d16_hi_b16 v[65:66], v67, off offset:224      // 000000153D3C: DC9600E0 007C4341
	s_or_b32 exec_lo, exec_lo, s8                              // 000000153D44: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000153D48: BE882000
	s_cbranch_execz 61240                                      // 000000153D4C: BFA5EF38 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3530>
	v_mad_i64_i32 v[65:66], null, 0x6000, v0, v[131:132]       // 000000153D50: D6FF7C41 060E00FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 000000153D5C: 1072738B
	global_load_u16 v65, v[65:66], off offset:768              // 000000153D60: DC4A0300 417C0041
	s_waitcnt vmcnt(0)                                         // 000000153D68: BF8903F7
	v_lshlrev_b32_e32 v65, 16, v65                             // 000000153D6C: 30828290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153D70: BF870091
	v_mul_f32_e32 v66, 0xbfb8aa3b, v65                         // 000000153D74: 108482FF BFB8AA3B
	v_fma_f32 v67, 0xbfb8aa3b, v65, -v66                       // 000000153D7C: D6130043 850A82FF BFB8AA3B
	v_rndne_f32_e32 v68, v66                                   // 000000153D88: 7E884742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000153D8C: BF870221
	v_sub_f32_e32 v66, v66, v68                                // 000000153D90: 08848942
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v65                  // 000000153D94: 7C3C82FF 42CE8ED0
	v_fmamk_f32 v67, v65, 0xb2a5705f, v67                      // 000000153D9C: 58868741 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000153DA4: BF870121
	v_add_f32_e32 v66, v66, v67                                // 000000153DA8: 06848742
	v_cvt_i32_f32_e32 v67, v68                                 // 000000153DAC: 7E861144
	v_exp_f32_e32 v66, v66                                     // 000000153DB0: 7E844B42
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153DB4: BF870095
	.long 0xd71c0042                                           // 000000153DB8: D71C0042
	v_cndmask_b32_e32 v1, v66, v67, vcc_lo                     // 000000153DBC: 02028742
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 000000153DC0: 02848480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v65                  // 000000153DC4: 7C3682FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153DCC: BF870092
	v_cndmask_b32_e32 v65, 0x7f800000, v66, vcc_lo             // 000000153DD0: 028284FF 7F800000
	v_add_f32_e32 v65, 1.0, v65                                // 000000153DD8: 068282F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153DDC: BF870091
	v_div_scale_f32 v66, null, v65, v65, v57                   // 000000153DE0: D6FC7C42 04E68341
	v_rcp_f32_e32 v67, v66                                     // 000000153DE8: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153DEC: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 000000153DF0: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 000000153DF8: 56868744
	v_div_scale_f32 v68, vcc_lo, v57, v65, v57                 // 000000153DFC: D6FC6A44 04E68339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153E04: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 000000153E08: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 000000153E0C: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153E14: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 000000153E18: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 000000153E1C: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153E24: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 000000153E28: D6370042 05168742
	v_div_fixup_f32 v57, v66, v65, v57                         // 000000153E30: D6270039 04E68342
	v_mad_i64_i32 v[65:66], null, 0x3000, v0, v[129:130]       // 000000153E38: D6FF7C41 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153E44: BF870092
	v_bfe_u32 v67, v57, 16, 1                                  // 000000153E48: D6100043 02052139
	v_add3_u32 v57, v57, v67, 0x7fff                           // 000000153E50: D6550039 03FE8739 00007FFF
	global_store_d16_hi_b16 v[65:66], v57, off offset:256      // 000000153E5C: DC960100 007C3941
	s_or_b32 exec_lo, exec_lo, s8                              // 000000153E64: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000153E68: BE882001
	s_cbranch_execz 61171                                      // 000000153E6C: BFA5EEF3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x353c>
	v_mad_i64_i32 v[65:66], null, 0x6000, v121, v[131:132]     // 000000153E70: D6FF7C41 060EF2FF 00006000
	v_mul_f32_e32 v58, v140, v58                               // 000000153E7C: 1074758C
	global_load_u16 v57, v[65:66], off offset:768              // 000000153E80: DC4A0300 397C0041
	s_waitcnt vmcnt(0)                                         // 000000153E88: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000153E8C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000153E90: BF870121
	v_mul_f32_e32 v65, 0xbfb8aa3b, v57                         // 000000153E94: 108272FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000153E9C: 7C3C72FF 42CE8ED0
	v_fma_f32 v66, 0xbfb8aa3b, v57, -v65                       // 000000153EA4: D6130042 850672FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 000000153EB0: 7E864741
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000153EB4: BF870112
	v_fmamk_f32 v66, v57, 0xb2a5705f, v66                      // 000000153EB8: 58848539 B2A5705F
	v_sub_f32_e32 v65, v65, v67                                // 000000153EC0: 08828741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000153EC4: BF870121
	v_add_f32_e32 v65, v65, v66                                // 000000153EC8: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000153ECC: 7E841143
	v_exp_f32_e32 v65, v65                                     // 000000153ED0: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153ED4: BF870095
	.long 0xd71c0041                                           // 000000153ED8: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000153EDC: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 000000153EE0: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000153EE4: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153EEC: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v65, vcc_lo             // 000000153EF0: 027282FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000153EF8: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153EFC: BF870091
	v_div_scale_f32 v65, null, v57, v57, v58                   // 000000153F00: D6FC7C41 04EA7339
	v_rcp_f32_e32 v66, v65                                     // 000000153F08: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153F0C: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 000000153F10: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 000000153F18: 56848543
	v_div_scale_f32 v67, vcc_lo, v58, v57, v58                 // 000000153F1C: D6FC6A43 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153F24: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 000000153F28: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 000000153F2C: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153F34: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 000000153F38: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 000000153F3C: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153F44: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 000000153F48: D6370041 05128541
	v_div_fixup_f32 v65, v65, v57, v58                         // 000000153F50: D6270041 04EA7341
	v_mad_i64_i32 v[57:58], null, 0x3000, v121, v[129:130]     // 000000153F58: D6FF7C39 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153F64: BF870092
	v_bfe_u32 v66, v65, 16, 1                                  // 000000153F68: D6100042 02052141
	v_add3_u32 v65, v65, v66, 0x7fff                           // 000000153F70: D6550041 03FE8541 00007FFF
	global_store_d16_hi_b16 v[57:58], v65, off offset:256      // 000000153F7C: DC960100 007C4139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000153F84: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000153F88: BE882002
	s_cbranch_execz 61102                                      // 000000153F8C: BFA5EEAE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3548>
	v_mad_i64_i32 v[57:58], null, 0x6000, v122, v[131:132]     // 000000153F90: D6FF7C39 060EF4FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 000000153F9C: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000153FA4: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000153FA8: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153FAC: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000153FB0: 107472FF BFB8AA3B
	v_fma_f32 v65, 0xbfb8aa3b, v57, -v58                       // 000000153FB8: D6130041 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v66, v58                                   // 000000153FC4: 7E84473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000153FC8: BF870221
	v_sub_f32_e32 v58, v58, v66                                // 000000153FCC: 0874853A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000153FD0: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v65, v57, 0xb2a5705f, v65                      // 000000153FD8: 58828339 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000153FE0: BF870121
	v_add_f32_e32 v58, v58, v65                                // 000000153FE4: 0674833A
	v_cvt_i32_f32_e32 v65, v66                                 // 000000153FE8: 7E821142
	v_exp_f32_e32 v58, v58                                     // 000000153FEC: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000153FF0: BF870095
	.long 0xd71c003a                                           // 000000153FF4: D71C003A
	v_cndmask_b32_e32 v1, v58, v65, vcc_lo                     // 000000153FF8: 0202833A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 000000153FFC: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000154000: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154008: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v137, v59// 00000015400C: CA4674FF 393A7789 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000154018: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015401C: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000154020: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v65, v59                                     // 000000154028: 7E82553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015402C: BF870095
	v_fma_f32 v66, -v59, v65, 1.0                              // 000000154030: D6130042 23CA833B
	v_fmac_f32_e32 v65, v66, v65                               // 000000154038: 56828342
	v_div_scale_f32 v66, vcc_lo, v58, v57, v58                 // 00000015403C: D6FC6A42 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154044: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 000000154048: 10868342
	v_fma_f32 v68, -v59, v67, v66                              // 00000015404C: D6130044 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154054: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 000000154058: 56868344
	v_fma_f32 v59, -v59, v67, v66                              // 00000015405C: D613003B 250A873B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154064: BF870091
	v_div_fmas_f32 v59, v59, v65, v67                          // 000000154068: D637003B 050E833B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000154070: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v122, v[129:130]     // 000000154078: D6FF7C39 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154084: BF870092
	v_bfe_u32 v65, v59, 16, 1                                  // 000000154088: D6100041 0205213B
	v_add3_u32 v59, v59, v65, 0x7fff                           // 000000154090: D655003B 03FE833B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000015409C: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001540A4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001540A8: BE882003
	s_cbranch_execz 61033                                      // 0000001540AC: BFA5EE69 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3554>
	v_mad_i64_i32 v[57:58], null, 0x6000, v123, v[131:132]     // 0000001540B0: D6FF7C39 060EF6FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000001540BC: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000001540C4: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000001540C8: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001540CC: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000001540D0: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000001540D8: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v65, v58                                   // 0000001540E4: 7E82473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001540E8: BF870091
	v_dual_fmamk_f32 v59, v57, 0xb2a5705f, v59 :: v_dual_sub_f32 v58, v58, v65// 0000001540EC: C88A7739 3B3A833A B2A5705F
	v_add_f32_e32 v58, v58, v59                                // 0000001540F8: 0674773A
	v_cvt_i32_f32_e32 v59, v65                                 // 0000001540FC: 7E761141
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000154100: 7C3C72FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000154108: BF870293
	v_exp_f32_e32 v58, v58                                     // 00000015410C: 7E744B3A
	.long 0xd71c003a                                           // 000000154110: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000154114: 0202773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000154118: BF870121
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000015411C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000154120: 7C3672FF C2B17218
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v138, v60// 000000154128: CA4674FF 393A798A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154134: BF870091
	v_add_f32_e32 v57, 1.0, v57                                // 000000154138: 067272F2
	v_div_scale_f32 v59, null, v57, v57, v58                   // 00000015413C: D6FC7C3B 04EA7339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000154144: BF870291
	v_rcp_f32_e32 v60, v59                                     // 000000154148: 7E78553B
	v_fma_f32 v65, -v59, v60, 1.0                              // 00000015414C: D6130041 23CA793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000154154: BF8700A1
	v_fmac_f32_e32 v60, v65, v60                               // 000000154158: 56787941
	v_div_scale_f32 v65, vcc_lo, v58, v57, v58                 // 00000015415C: D6FC6A41 04EA733A
	v_mul_f32_e32 v66, v65, v60                                // 000000154164: 10847941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154168: BF870091
	v_fma_f32 v67, -v59, v66, v65                              // 00000015416C: D6130043 2506853B
	v_fmac_f32_e32 v66, v67, v60                               // 000000154174: 56847943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154178: BF870091
	v_fma_f32 v59, -v59, v66, v65                              // 00000015417C: D613003B 2506853B
	v_div_fmas_f32 v59, v59, v60, v66                          // 000000154184: D637003B 050A793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015418C: BF870121
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000154190: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v123, v[129:130]     // 000000154198: D6FF7C39 0606F6FF 00003000
	v_bfe_u32 v60, v59, 16, 1                                  // 0000001541A4: D610003C 0205213B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001541AC: BF870001
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000001541B0: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000001541BC: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001541C4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001541C8: BE882004
	s_cbranch_execz 60964                                      // 0000001541CC: BFA5EE24 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3560>
	v_mad_i64_i32 v[57:58], null, 0x6000, v124, v[131:132]     // 0000001541D0: D6FF7C39 060EF8FF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000001541DC: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 0000001541E4: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 0000001541E8: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001541EC: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 0000001541F0: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 0000001541F8: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000154204: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000154208: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000015420C: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000154210: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000154218: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000154220: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000154224: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000154228: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000015422C: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154230: BF870095
	.long 0xd71c003a                                           // 000000154234: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000154238: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000015423C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000154240: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154248: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v135, v61// 00000015424C: CA4674FF 393A7B87 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000154258: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015425C: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000154260: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000154268: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015426C: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000154270: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000154278: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 00000015427C: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154284: BF870091
	v_mul_f32_e32 v65, v61, v60                                // 000000154288: 1082793D
	v_fma_f32 v66, -v59, v65, v61                              // 00000015428C: D6130042 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154294: BF870091
	v_fmac_f32_e32 v65, v66, v60                               // 000000154298: 56827942
	v_fma_f32 v59, -v59, v65, v61                              // 00000015429C: D613003B 24F6833B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001542A4: BF870091
	v_div_fmas_f32 v59, v59, v60, v65                          // 0000001542A8: D637003B 0506793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000001542B0: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v124, v[129:130]     // 0000001542B8: D6FF7C39 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001542C4: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000001542C8: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000001542D0: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000001542DC: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001542E4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001542E8: BE882005
	s_cbranch_execz 60895                                      // 0000001542EC: BFA5EDDF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x356c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v125, v[131:132]     // 0000001542F0: D6FF7C39 060EFAFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 0000001542FC: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000154304: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000154308: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015430C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000154310: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000154318: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000154324: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000154328: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000015432C: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000154330: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000154338: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000154340: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000154344: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000154348: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000015434C: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154350: BF870095
	.long 0xd71c003a                                           // 000000154354: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000154358: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000015435C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000154360: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154368: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 00000015436C: 027274FF 7F800000
	v_dual_mul_f32 v58, v136, v62 :: v_dual_add_f32 v57, 1.0, v57// 000000154374: C8C87D88 3A3872F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015437C: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 000000154380: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 000000154388: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015438C: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 000000154390: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 000000154398: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 00000015439C: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001543A4: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000001543A8: 107C793D
	v_fma_f32 v65, -v59, v62, v61                              // 0000001543AC: D6130041 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001543B4: BF870091
	v_fmac_f32_e32 v62, v65, v60                               // 0000001543B8: 567C7941
	v_fma_f32 v59, -v59, v62, v61                              // 0000001543BC: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001543C4: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000001543C8: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000001543D0: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v125, v[129:130]     // 0000001543D8: D6FF7C39 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001543E4: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 0000001543E8: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 0000001543F0: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 0000001543FC: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000154404: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000154408: BE882006
	s_cbranch_execz 60826                                      // 00000015440C: BFA5ED9A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3578>
	v_mad_i64_i32 v[57:58], null, 0x6000, v126, v[131:132]     // 000000154410: D6FF7C39 060EFCFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000015441C: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000154424: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000154428: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015442C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000154430: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000154438: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000154444: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000154448: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000015444C: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000154450: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000154458: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000154460: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000154464: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000154468: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000015446C: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154470: BF870095
	.long 0xd71c003a                                           // 000000154474: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000154478: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000015447C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 000000154480: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154488: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v133, v63// 00000015448C: CA4674FF 393A7F85 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 000000154498: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015449C: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000001544A0: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000001544A8: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001544AC: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000001544B0: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000001544B8: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000001544BC: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001544C4: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000001544C8: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000001544CC: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001544D4: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000001544D8: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000001544DC: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001544E4: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 0000001544E8: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 0000001544F0: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v126, v[129:130]     // 0000001544F8: D6FF7C39 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154504: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000154508: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000154510: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000015451C: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000154524: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000154528: BE882007
	s_cbranch_execz 60757                                      // 00000015452C: BFA5ED55 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3584>
	v_mad_i64_i32 v[57:58], null, 0x6000, v127, v[131:132]     // 000000154530: D6FF7C39 060EFEFF 00006000
	global_load_u16 v57, v[57:58], off offset:768              // 00000015453C: DC4A0300 397C0039
	s_waitcnt vmcnt(0)                                         // 000000154544: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 000000154548: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015454C: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000154550: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 000000154558: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000154564: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000154568: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 00000015456C: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000154570: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 000000154578: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000154580: BF870121
	v_add_f32_e32 v58, v58, v59                                // 000000154584: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 000000154588: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 00000015458C: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154590: BF870095
	.long 0xd71c003a                                           // 000000154594: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 000000154598: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 00000015459C: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000001545A0: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001545A8: BF870092
	v_dual_cndmask_b32 v57, 0x7f800000, v58 :: v_dual_mul_f32 v58, v134, v64// 0000001545AC: CA4674FF 393A8186 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000001545B8: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001545BC: BF870091
	v_div_scale_f32 v59, null, v57, v57, v58                   // 0000001545C0: D6FC7C3B 04EA7339
	v_rcp_f32_e32 v60, v59                                     // 0000001545C8: 7E78553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001545CC: BF870095
	v_fma_f32 v61, -v59, v60, 1.0                              // 0000001545D0: D613003D 23CA793B
	v_fmac_f32_e32 v60, v61, v60                               // 0000001545D8: 5678793D
	v_div_scale_f32 v61, vcc_lo, v58, v57, v58                 // 0000001545DC: D6FC6A3D 04EA733A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001545E4: BF870091
	v_mul_f32_e32 v62, v61, v60                                // 0000001545E8: 107C793D
	v_fma_f32 v63, -v59, v62, v61                              // 0000001545EC: D613003F 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001545F4: BF870091
	v_fmac_f32_e32 v62, v63, v60                               // 0000001545F8: 567C793F
	v_fma_f32 v59, -v59, v62, v61                              // 0000001545FC: D613003B 24F67D3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154604: BF870091
	v_div_fmas_f32 v59, v59, v60, v62                          // 000000154608: D637003B 04FA793B
	v_div_fixup_f32 v59, v59, v57, v58                         // 000000154610: D627003B 04EA733B
	v_mad_i64_i32 v[57:58], null, 0x3000, v127, v[129:130]     // 000000154618: D6FF7C39 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154624: BF870092
	v_bfe_u32 v60, v59, 16, 1                                  // 000000154628: D610003C 0205213B
	v_add3_u32 v59, v59, v60, 0x7fff                           // 000000154630: D655003B 03FE793B 00007FFF
	global_store_d16_hi_b16 v[57:58], v59, off offset:256      // 00000015463C: DC960100 007C3B39
	s_or_b32 exec_lo, exec_lo, s8                              // 000000154644: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000154648: BE882000
	s_cbranch_execz 60688                                      // 00000015464C: BFA5ED10 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3590>
	v_mad_i64_i32 v[57:58], null, 0x6000, v0, v[131:132]       // 000000154650: D6FF7C39 060E00FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 00000015465C: 1062638B
	global_load_u16 v57, v[57:58], off offset:800              // 000000154660: DC4A0320 397C0039
	s_waitcnt vmcnt(0)                                         // 000000154668: BF8903F7
	v_lshlrev_b32_e32 v57, 16, v57                             // 00000015466C: 30727290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154670: BF870091
	v_mul_f32_e32 v58, 0xbfb8aa3b, v57                         // 000000154674: 107472FF BFB8AA3B
	v_fma_f32 v59, 0xbfb8aa3b, v57, -v58                       // 00000015467C: D613003B 84EA72FF BFB8AA3B
	v_rndne_f32_e32 v60, v58                                   // 000000154688: 7E78473A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000015468C: BF870221
	v_sub_f32_e32 v58, v58, v60                                // 000000154690: 0874793A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v57                  // 000000154694: 7C3C72FF 42CE8ED0
	v_fmamk_f32 v59, v57, 0xb2a5705f, v59                      // 00000015469C: 58767739 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001546A4: BF870121
	v_add_f32_e32 v58, v58, v59                                // 0000001546A8: 0674773A
	v_cvt_i32_f32_e32 v59, v60                                 // 0000001546AC: 7E76113C
	v_exp_f32_e32 v58, v58                                     // 0000001546B0: 7E744B3A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001546B4: BF870095
	.long 0xd71c003a                                           // 0000001546B8: D71C003A
	v_cndmask_b32_e32 v1, v58, v59, vcc_lo                     // 0000001546BC: 0202773A
	v_cndmask_b32_e32 v58, 0, v58, vcc_lo                      // 0000001546C0: 02747480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v57                  // 0000001546C4: 7C3672FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001546CC: BF870092
	v_cndmask_b32_e32 v57, 0x7f800000, v58, vcc_lo             // 0000001546D0: 027274FF 7F800000
	v_add_f32_e32 v57, 1.0, v57                                // 0000001546D8: 067272F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001546DC: BF870091
	v_div_scale_f32 v58, null, v57, v57, v49                   // 0000001546E0: D6FC7C3A 04C67339
	v_rcp_f32_e32 v59, v58                                     // 0000001546E8: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001546EC: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 0000001546F0: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 0000001546F8: 5676773C
	v_div_scale_f32 v60, vcc_lo, v49, v57, v49                 // 0000001546FC: D6FC6A3C 04C67331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154704: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 000000154708: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 00000015470C: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154714: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 000000154718: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 00000015471C: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154724: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 000000154728: D637003A 04F6773A
	v_div_fixup_f32 v49, v58, v57, v49                         // 000000154730: D6270031 04C6733A
	v_mad_i64_i32 v[57:58], null, 0x3000, v0, v[129:130]       // 000000154738: D6FF7C39 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154744: BF870092
	v_bfe_u32 v59, v49, 16, 1                                  // 000000154748: D610003B 02052131
	v_add3_u32 v49, v49, v59, 0x7fff                           // 000000154750: D6550031 03FE7731 00007FFF
	global_store_d16_hi_b16 v[57:58], v49, off offset:288      // 00000015475C: DC960120 007C3139
	s_or_b32 exec_lo, exec_lo, s8                              // 000000154764: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000154768: BE882001
	s_cbranch_execz 60619                                      // 00000015476C: BFA5ECCB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x359c>
	v_mad_i64_i32 v[57:58], null, 0x6000, v121, v[131:132]     // 000000154770: D6FF7C39 060EF2FF 00006000
	v_mul_f32_e32 v50, v140, v50                               // 00000015477C: 1064658C
	global_load_u16 v49, v[57:58], off offset:800              // 000000154780: DC4A0320 317C0039
	s_waitcnt vmcnt(0)                                         // 000000154788: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 00000015478C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000154790: BF870121
	v_mul_f32_e32 v57, 0xbfb8aa3b, v49                         // 000000154794: 107262FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 00000015479C: 7C3C62FF 42CE8ED0
	v_fma_f32 v58, 0xbfb8aa3b, v49, -v57                       // 0000001547A4: D613003A 84E662FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 0000001547B0: 7E764739
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001547B4: BF870112
	v_fmamk_f32 v58, v49, 0xb2a5705f, v58                      // 0000001547B8: 58747531 B2A5705F
	v_sub_f32_e32 v57, v57, v59                                // 0000001547C0: 08727739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001547C4: BF870121
	v_add_f32_e32 v57, v57, v58                                // 0000001547C8: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 0000001547CC: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 0000001547D0: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001547D4: BF870095
	.long 0xd71c0039                                           // 0000001547D8: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 0000001547DC: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 0000001547E0: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001547E4: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001547EC: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v57, vcc_lo             // 0000001547F0: 026272FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 0000001547F8: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001547FC: BF870091
	v_div_scale_f32 v57, null, v49, v49, v50                   // 000000154800: D6FC7C39 04CA6331
	v_rcp_f32_e32 v58, v57                                     // 000000154808: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015480C: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 000000154810: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 000000154818: 5674753B
	v_div_scale_f32 v59, vcc_lo, v50, v49, v50                 // 00000015481C: D6FC6A3B 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154824: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 000000154828: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 00000015482C: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154834: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 000000154838: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 00000015483C: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154844: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 000000154848: D6370039 04F27539
	v_div_fixup_f32 v57, v57, v49, v50                         // 000000154850: D6270039 04CA6339
	v_mad_i64_i32 v[49:50], null, 0x3000, v121, v[129:130]     // 000000154858: D6FF7C31 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154864: BF870092
	v_bfe_u32 v58, v57, 16, 1                                  // 000000154868: D610003A 02052139
	v_add3_u32 v57, v57, v58, 0x7fff                           // 000000154870: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[49:50], v57, off offset:288      // 00000015487C: DC960120 007C3931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000154884: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000154888: BE882002
	s_cbranch_execz 60550                                      // 00000015488C: BFA5EC86 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35a8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v122, v[131:132]     // 000000154890: D6FF7C31 060EF4FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 00000015489C: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000001548A4: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000001548A8: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001548AC: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000001548B0: 106462FF BFB8AA3B
	v_fma_f32 v57, 0xbfb8aa3b, v49, -v50                       // 0000001548B8: D6130039 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v58, v50                                   // 0000001548C4: 7E744732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001548C8: BF870221
	v_sub_f32_e32 v50, v50, v58                                // 0000001548CC: 08647532
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001548D0: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v57, v49, 0xb2a5705f, v57                      // 0000001548D8: 58727331 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001548E0: BF870121
	v_add_f32_e32 v50, v50, v57                                // 0000001548E4: 06647332
	v_cvt_i32_f32_e32 v57, v58                                 // 0000001548E8: 7E72113A
	v_exp_f32_e32 v50, v50                                     // 0000001548EC: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001548F0: BF870095
	.long 0xd71c0032                                           // 0000001548F4: D71C0032
	v_cndmask_b32_e32 v1, v50, v57, vcc_lo                     // 0000001548F8: 02027332
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 0000001548FC: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000154900: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154908: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v137, v51// 00000015490C: CA4664FF 31326789 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000154918: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015491C: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000154920: D6FC7C33 04CA6331
	v_rcp_f32_e32 v57, v51                                     // 000000154928: 7E725533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015492C: BF870095
	v_fma_f32 v58, -v51, v57, 1.0                              // 000000154930: D613003A 23CA7333
	v_fmac_f32_e32 v57, v58, v57                               // 000000154938: 5672733A
	v_div_scale_f32 v58, vcc_lo, v50, v49, v50                 // 00000015493C: D6FC6A3A 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154944: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 000000154948: 1076733A
	v_fma_f32 v60, -v51, v59, v58                              // 00000015494C: D613003C 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154954: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 000000154958: 5676733C
	v_fma_f32 v51, -v51, v59, v58                              // 00000015495C: D6130033 24EA7733
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154964: BF870091
	v_div_fmas_f32 v51, v51, v57, v59                          // 000000154968: D6370033 04EE7333
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000154970: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v122, v[129:130]     // 000000154978: D6FF7C31 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154984: BF870092
	v_bfe_u32 v57, v51, 16, 1                                  // 000000154988: D6100039 02052133
	v_add3_u32 v51, v51, v57, 0x7fff                           // 000000154990: D6550033 03FE7333 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 00000015499C: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001549A4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001549A8: BE882003
	s_cbranch_execz 60481                                      // 0000001549AC: BFA5EC41 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35b4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v123, v[131:132]     // 0000001549B0: D6FF7C31 060EF6FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 0000001549BC: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 0000001549C4: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 0000001549C8: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001549CC: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 0000001549D0: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 0000001549D8: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v57, v50                                   // 0000001549E4: 7E724732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001549E8: BF870091
	v_dual_fmamk_f32 v51, v49, 0xb2a5705f, v51 :: v_dual_sub_f32 v50, v50, v57// 0000001549EC: C88A6731 33327332 B2A5705F
	v_add_f32_e32 v50, v50, v51                                // 0000001549F8: 06646732
	v_cvt_i32_f32_e32 v51, v57                                 // 0000001549FC: 7E661139
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000154A00: 7C3C62FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000154A08: BF870293
	v_exp_f32_e32 v50, v50                                     // 000000154A0C: 7E644B32
	.long 0xd71c0032                                           // 000000154A10: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000154A14: 02026732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000154A18: BF870121
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000154A1C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000154A20: 7C3662FF C2B17218
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v138, v52// 000000154A28: CA4664FF 3132698A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154A34: BF870091
	v_add_f32_e32 v49, 1.0, v49                                // 000000154A38: 066262F2
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000154A3C: D6FC7C33 04CA6331
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000154A44: BF870291
	v_rcp_f32_e32 v52, v51                                     // 000000154A48: 7E685533
	v_fma_f32 v57, -v51, v52, 1.0                              // 000000154A4C: D6130039 23CA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000154A54: BF8700A1
	v_fmac_f32_e32 v52, v57, v52                               // 000000154A58: 56686939
	v_div_scale_f32 v57, vcc_lo, v50, v49, v50                 // 000000154A5C: D6FC6A39 04CA6332
	v_mul_f32_e32 v58, v57, v52                                // 000000154A64: 10746939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154A68: BF870091
	v_fma_f32 v59, -v51, v58, v57                              // 000000154A6C: D613003B 24E67533
	v_fmac_f32_e32 v58, v59, v52                               // 000000154A74: 5674693B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154A78: BF870091
	v_fma_f32 v51, -v51, v58, v57                              // 000000154A7C: D6130033 24E67533
	v_div_fmas_f32 v51, v51, v52, v58                          // 000000154A84: D6370033 04EA6933
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000154A8C: BF870121
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000154A90: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v123, v[129:130]     // 000000154A98: D6FF7C31 0606F6FF 00003000
	v_bfe_u32 v52, v51, 16, 1                                  // 000000154AA4: D6100034 02052133
	s_delay_alu instid0(VALU_DEP_1)                            // 000000154AAC: BF870001
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000154AB0: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000154ABC: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000154AC4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000154AC8: BE882004
	s_cbranch_execz 60412                                      // 000000154ACC: BFA5EBFC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35c0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v124, v[131:132]     // 000000154AD0: D6FF7C31 060EF8FF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000154ADC: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000154AE4: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000154AE8: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154AEC: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000154AF0: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000154AF8: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000154B04: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000154B08: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000154B0C: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000154B10: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000154B18: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000154B20: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000154B24: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000154B28: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000154B2C: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154B30: BF870095
	.long 0xd71c0032                                           // 000000154B34: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000154B38: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000154B3C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000154B40: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154B48: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v135, v53// 000000154B4C: CA4664FF 31326B87 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000154B58: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154B5C: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000154B60: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000154B68: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154B6C: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000154B70: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000154B78: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000154B7C: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154B84: BF870091
	v_mul_f32_e32 v57, v53, v52                                // 000000154B88: 10726935
	v_fma_f32 v58, -v51, v57, v53                              // 000000154B8C: D613003A 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154B94: BF870091
	v_fmac_f32_e32 v57, v58, v52                               // 000000154B98: 5672693A
	v_fma_f32 v51, -v51, v57, v53                              // 000000154B9C: D6130033 24D67333
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154BA4: BF870091
	v_div_fmas_f32 v51, v51, v52, v57                          // 000000154BA8: D6370033 04E66933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000154BB0: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v124, v[129:130]     // 000000154BB8: D6FF7C31 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154BC4: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000154BC8: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000154BD0: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000154BDC: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000154BE4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000154BE8: BE882005
	s_cbranch_execz 60343                                      // 000000154BEC: BFA5EBB7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35cc>
	v_mad_i64_i32 v[49:50], null, 0x6000, v125, v[131:132]     // 000000154BF0: D6FF7C31 060EFAFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000154BFC: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000154C04: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000154C08: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154C0C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000154C10: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000154C18: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000154C24: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000154C28: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000154C2C: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000154C30: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000154C38: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000154C40: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000154C44: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000154C48: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000154C4C: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154C50: BF870095
	.long 0xd71c0032                                           // 000000154C54: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000154C58: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000154C5C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000154C60: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154C68: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000154C6C: 026264FF 7F800000
	v_dual_mul_f32 v50, v136, v54 :: v_dual_add_f32 v49, 1.0, v49// 000000154C74: C8C86D88 323062F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154C7C: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000154C80: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000154C88: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154C8C: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000154C90: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000154C98: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000154C9C: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154CA4: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000154CA8: 106C6935
	v_fma_f32 v57, -v51, v54, v53                              // 000000154CAC: D6130039 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154CB4: BF870091
	v_fmac_f32_e32 v54, v57, v52                               // 000000154CB8: 566C6939
	v_fma_f32 v51, -v51, v54, v53                              // 000000154CBC: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154CC4: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000154CC8: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000154CD0: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v125, v[129:130]     // 000000154CD8: D6FF7C31 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154CE4: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000154CE8: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000154CF0: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000154CFC: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000154D04: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000154D08: BE882006
	s_cbranch_execz 60274                                      // 000000154D0C: BFA5EB72 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35d8>
	v_mad_i64_i32 v[49:50], null, 0x6000, v126, v[131:132]     // 000000154D10: D6FF7C31 060EFCFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000154D1C: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000154D24: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000154D28: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154D2C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000154D30: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000154D38: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000154D44: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000154D48: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000154D4C: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000154D50: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000154D58: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000154D60: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000154D64: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000154D68: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000154D6C: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154D70: BF870095
	.long 0xd71c0032                                           // 000000154D74: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000154D78: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000154D7C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000154D80: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154D88: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v133, v55// 000000154D8C: CA4664FF 31326F85 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000154D98: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154D9C: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000154DA0: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000154DA8: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154DAC: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000154DB0: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000154DB8: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000154DBC: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154DC4: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000154DC8: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000154DCC: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154DD4: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 000000154DD8: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000154DDC: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154DE4: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000154DE8: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000154DF0: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v126, v[129:130]     // 000000154DF8: D6FF7C31 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154E04: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000154E08: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000154E10: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000154E1C: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000154E24: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000154E28: BE882007
	s_cbranch_execz 60205                                      // 000000154E2C: BFA5EB2D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35e4>
	v_mad_i64_i32 v[49:50], null, 0x6000, v127, v[131:132]     // 000000154E30: D6FF7C31 060EFEFF 00006000
	global_load_u16 v49, v[49:50], off offset:800              // 000000154E3C: DC4A0320 317C0031
	s_waitcnt vmcnt(0)                                         // 000000154E44: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000154E48: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154E4C: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000154E50: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000154E58: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000154E64: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000154E68: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000154E6C: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000154E70: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000154E78: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000154E80: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000154E84: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000154E88: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000154E8C: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154E90: BF870095
	.long 0xd71c0032                                           // 000000154E94: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000154E98: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000154E9C: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000154EA0: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154EA8: BF870092
	v_dual_cndmask_b32 v49, 0x7f800000, v50 :: v_dual_mul_f32 v50, v134, v56// 000000154EAC: CA4664FF 31327186 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000154EB8: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154EBC: BF870091
	v_div_scale_f32 v51, null, v49, v49, v50                   // 000000154EC0: D6FC7C33 04CA6331
	v_rcp_f32_e32 v52, v51                                     // 000000154EC8: 7E685533
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154ECC: BF870095
	v_fma_f32 v53, -v51, v52, 1.0                              // 000000154ED0: D6130035 23CA6933
	v_fmac_f32_e32 v52, v53, v52                               // 000000154ED8: 56686935
	v_div_scale_f32 v53, vcc_lo, v50, v49, v50                 // 000000154EDC: D6FC6A35 04CA6332
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154EE4: BF870091
	v_mul_f32_e32 v54, v53, v52                                // 000000154EE8: 106C6935
	v_fma_f32 v55, -v51, v54, v53                              // 000000154EEC: D6130037 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154EF4: BF870091
	v_fmac_f32_e32 v54, v55, v52                               // 000000154EF8: 566C6937
	v_fma_f32 v51, -v51, v54, v53                              // 000000154EFC: D6130033 24D66D33
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154F04: BF870091
	v_div_fmas_f32 v51, v51, v52, v54                          // 000000154F08: D6370033 04DA6933
	v_div_fixup_f32 v51, v51, v49, v50                         // 000000154F10: D6270033 04CA6333
	v_mad_i64_i32 v[49:50], null, 0x3000, v127, v[129:130]     // 000000154F18: D6FF7C31 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154F24: BF870092
	v_bfe_u32 v52, v51, 16, 1                                  // 000000154F28: D6100034 02052133
	v_add3_u32 v51, v51, v52, 0x7fff                           // 000000154F30: D6550033 03FE6933 00007FFF
	global_store_d16_hi_b16 v[49:50], v51, off offset:288      // 000000154F3C: DC960120 007C3331
	s_or_b32 exec_lo, exec_lo, s8                              // 000000154F44: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000154F48: BE882000
	s_cbranch_execz 60136                                      // 000000154F4C: BFA5EAE8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35f0>
	v_mad_i64_i32 v[49:50], null, 0x6000, v0, v[131:132]       // 000000154F50: D6FF7C31 060E00FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 000000154F5C: 1052538B
	global_load_u16 v49, v[49:50], off offset:832              // 000000154F60: DC4A0340 317C0031
	s_waitcnt vmcnt(0)                                         // 000000154F68: BF8903F7
	v_lshlrev_b32_e32 v49, 16, v49                             // 000000154F6C: 30626290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154F70: BF870091
	v_mul_f32_e32 v50, 0xbfb8aa3b, v49                         // 000000154F74: 106462FF BFB8AA3B
	v_fma_f32 v51, 0xbfb8aa3b, v49, -v50                       // 000000154F7C: D6130033 84CA62FF BFB8AA3B
	v_rndne_f32_e32 v52, v50                                   // 000000154F88: 7E684732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000154F8C: BF870221
	v_sub_f32_e32 v50, v50, v52                                // 000000154F90: 08646932
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 000000154F94: 7C3C62FF 42CE8ED0
	v_fmamk_f32 v51, v49, 0xb2a5705f, v51                      // 000000154F9C: 58666731 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000154FA4: BF870121
	v_add_f32_e32 v50, v50, v51                                // 000000154FA8: 06646732
	v_cvt_i32_f32_e32 v51, v52                                 // 000000154FAC: 7E661134
	v_exp_f32_e32 v50, v50                                     // 000000154FB0: 7E644B32
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154FB4: BF870095
	.long 0xd71c0032                                           // 000000154FB8: D71C0032
	v_cndmask_b32_e32 v1, v50, v51, vcc_lo                     // 000000154FBC: 02026732
	v_cndmask_b32_e32 v50, 0, v50, vcc_lo                      // 000000154FC0: 02646480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 000000154FC4: 7C3662FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154FCC: BF870092
	v_cndmask_b32_e32 v49, 0x7f800000, v50, vcc_lo             // 000000154FD0: 026264FF 7F800000
	v_add_f32_e32 v49, 1.0, v49                                // 000000154FD8: 066262F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154FDC: BF870091
	v_div_scale_f32 v50, null, v49, v49, v41                   // 000000154FE0: D6FC7C32 04A66331
	v_rcp_f32_e32 v51, v50                                     // 000000154FE8: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000154FEC: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 000000154FF0: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 000000154FF8: 56666734
	v_div_scale_f32 v52, vcc_lo, v41, v49, v41                 // 000000154FFC: D6FC6A34 04A66329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155004: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 000000155008: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 00000015500C: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155014: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 000000155018: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 00000015501C: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155024: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 000000155028: D6370032 04D66732
	v_div_fixup_f32 v41, v50, v49, v41                         // 000000155030: D6270029 04A66332
	v_mad_i64_i32 v[49:50], null, 0x3000, v0, v[129:130]       // 000000155038: D6FF7C31 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155044: BF870092
	v_bfe_u32 v51, v41, 16, 1                                  // 000000155048: D6100033 02052129
	v_add3_u32 v41, v41, v51, 0x7fff                           // 000000155050: D6550029 03FE6729 00007FFF
	global_store_d16_hi_b16 v[49:50], v41, off offset:320      // 00000015505C: DC960140 007C2931
	s_or_b32 exec_lo, exec_lo, s8                              // 000000155064: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000155068: BE882001
	s_cbranch_execz 60067                                      // 00000015506C: BFA5EAA3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35fc>
	v_mad_i64_i32 v[49:50], null, 0x6000, v121, v[131:132]     // 000000155070: D6FF7C31 060EF2FF 00006000
	v_mul_f32_e32 v42, v140, v42                               // 00000015507C: 1054558C
	global_load_u16 v41, v[49:50], off offset:832              // 000000155080: DC4A0340 297C0031
	s_waitcnt vmcnt(0)                                         // 000000155088: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000015508C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000155090: BF870121
	v_mul_f32_e32 v49, 0xbfb8aa3b, v41                         // 000000155094: 106252FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 00000015509C: 7C3C52FF 42CE8ED0
	v_fma_f32 v50, 0xbfb8aa3b, v41, -v49                       // 0000001550A4: D6130032 84C652FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 0000001550B0: 7E664731
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001550B4: BF870112
	v_fmamk_f32 v50, v41, 0xb2a5705f, v50                      // 0000001550B8: 58646529 B2A5705F
	v_sub_f32_e32 v49, v49, v51                                // 0000001550C0: 08626731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001550C4: BF870121
	v_add_f32_e32 v49, v49, v50                                // 0000001550C8: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 0000001550CC: 7E641133
	v_exp_f32_e32 v49, v49                                     // 0000001550D0: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001550D4: BF870095
	.long 0xd71c0031                                           // 0000001550D8: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 0000001550DC: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 0000001550E0: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000001550E4: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001550EC: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v49, vcc_lo             // 0000001550F0: 025262FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000001550F8: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001550FC: BF870091
	v_div_scale_f32 v49, null, v41, v41, v42                   // 000000155100: D6FC7C31 04AA5329
	v_rcp_f32_e32 v50, v49                                     // 000000155108: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015510C: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 000000155110: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 000000155118: 56646533
	v_div_scale_f32 v51, vcc_lo, v42, v41, v42                 // 00000015511C: D6FC6A33 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155124: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 000000155128: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 00000015512C: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155134: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 000000155138: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 00000015513C: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155144: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 000000155148: D6370031 04D26531
	v_div_fixup_f32 v49, v49, v41, v42                         // 000000155150: D6270031 04AA5331
	v_mad_i64_i32 v[41:42], null, 0x3000, v121, v[129:130]     // 000000155158: D6FF7C29 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155164: BF870092
	v_bfe_u32 v50, v49, 16, 1                                  // 000000155168: D6100032 02052131
	v_add3_u32 v49, v49, v50, 0x7fff                           // 000000155170: D6550031 03FE6531 00007FFF
	global_store_d16_hi_b16 v[41:42], v49, off offset:320      // 00000015517C: DC960140 007C3129
	s_or_b32 exec_lo, exec_lo, s8                              // 000000155184: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000155188: BE882002
	s_cbranch_execz 59998                                      // 00000015518C: BFA5EA5E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3608>
	v_mad_i64_i32 v[41:42], null, 0x6000, v122, v[131:132]     // 000000155190: D6FF7C29 060EF4FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000015519C: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000001551A4: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000001551A8: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001551AC: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000001551B0: 105452FF BFB8AA3B
	v_fma_f32 v49, 0xbfb8aa3b, v41, -v42                       // 0000001551B8: D6130031 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v50, v42                                   // 0000001551C4: 7E64472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001551C8: BF870221
	v_sub_f32_e32 v42, v42, v50                                // 0000001551CC: 0854652A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 0000001551D0: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v49, v41, 0xb2a5705f, v49                      // 0000001551D8: 58626329 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001551E0: BF870121
	v_add_f32_e32 v42, v42, v49                                // 0000001551E4: 0654632A
	v_cvt_i32_f32_e32 v49, v50                                 // 0000001551E8: 7E621132
	v_exp_f32_e32 v42, v42                                     // 0000001551EC: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001551F0: BF870095
	.long 0xd71c002a                                           // 0000001551F4: D71C002A
	v_cndmask_b32_e32 v1, v42, v49, vcc_lo                     // 0000001551F8: 0202632A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000001551FC: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000155200: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155208: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v137, v43// 00000015520C: CA4654FF 292A5789 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000155218: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015521C: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000155220: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v49, v43                                     // 000000155228: 7E62552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015522C: BF870095
	v_fma_f32 v50, -v43, v49, 1.0                              // 000000155230: D6130032 23CA632B
	v_fmac_f32_e32 v49, v50, v49                               // 000000155238: 56626332
	v_div_scale_f32 v50, vcc_lo, v42, v41, v42                 // 00000015523C: D6FC6A32 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155244: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 000000155248: 10666332
	v_fma_f32 v52, -v43, v51, v50                              // 00000015524C: D6130034 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155254: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 000000155258: 56666334
	v_fma_f32 v43, -v43, v51, v50                              // 00000015525C: D613002B 24CA672B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155264: BF870091
	v_div_fmas_f32 v43, v43, v49, v51                          // 000000155268: D637002B 04CE632B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000155270: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v122, v[129:130]     // 000000155278: D6FF7C29 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155284: BF870092
	v_bfe_u32 v49, v43, 16, 1                                  // 000000155288: D6100031 0205212B
	v_add3_u32 v43, v43, v49, 0x7fff                           // 000000155290: D655002B 03FE632B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000015529C: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001552A4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001552A8: BE882003
	s_cbranch_execz 59929                                      // 0000001552AC: BFA5EA19 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3614>
	v_mad_i64_i32 v[41:42], null, 0x6000, v123, v[131:132]     // 0000001552B0: D6FF7C29 060EF6FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000001552BC: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000001552C4: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000001552C8: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001552CC: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000001552D0: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000001552D8: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v49, v42                                   // 0000001552E4: 7E62472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001552E8: BF870091
	v_dual_fmamk_f32 v43, v41, 0xb2a5705f, v43 :: v_dual_sub_f32 v42, v42, v49// 0000001552EC: C88A5729 2B2A632A B2A5705F
	v_add_f32_e32 v42, v42, v43                                // 0000001552F8: 0654572A
	v_cvt_i32_f32_e32 v43, v49                                 // 0000001552FC: 7E561131
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000155300: 7C3C52FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000155308: BF870293
	v_exp_f32_e32 v42, v42                                     // 00000015530C: 7E544B2A
	.long 0xd71c002a                                           // 000000155310: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000155314: 0202572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000155318: BF870121
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000015531C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000155320: 7C3652FF C2B17218
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v138, v44// 000000155328: CA4654FF 292A598A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155334: BF870091
	v_add_f32_e32 v41, 1.0, v41                                // 000000155338: 065252F2
	v_div_scale_f32 v43, null, v41, v41, v42                   // 00000015533C: D6FC7C2B 04AA5329
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000155344: BF870291
	v_rcp_f32_e32 v44, v43                                     // 000000155348: 7E58552B
	v_fma_f32 v49, -v43, v44, 1.0                              // 00000015534C: D6130031 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000155354: BF8700A1
	v_fmac_f32_e32 v44, v49, v44                               // 000000155358: 56585931
	v_div_scale_f32 v49, vcc_lo, v42, v41, v42                 // 00000015535C: D6FC6A31 04AA532A
	v_mul_f32_e32 v50, v49, v44                                // 000000155364: 10645931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155368: BF870091
	v_fma_f32 v51, -v43, v50, v49                              // 00000015536C: D6130033 24C6652B
	v_fmac_f32_e32 v50, v51, v44                               // 000000155374: 56645933
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155378: BF870091
	v_fma_f32 v43, -v43, v50, v49                              // 00000015537C: D613002B 24C6652B
	v_div_fmas_f32 v43, v43, v44, v50                          // 000000155384: D637002B 04CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015538C: BF870121
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000155390: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v123, v[129:130]     // 000000155398: D6FF7C29 0606F6FF 00003000
	v_bfe_u32 v44, v43, 16, 1                                  // 0000001553A4: D610002C 0205212B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001553AC: BF870001
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000001553B0: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000001553BC: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001553C4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001553C8: BE882004
	s_cbranch_execz 59860                                      // 0000001553CC: BFA5E9D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3620>
	v_mad_i64_i32 v[41:42], null, 0x6000, v124, v[131:132]     // 0000001553D0: D6FF7C29 060EF8FF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000001553DC: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 0000001553E4: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000001553E8: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001553EC: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 0000001553F0: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 0000001553F8: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000155404: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000155408: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000015540C: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000155410: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000155418: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000155420: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000155424: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000155428: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000015542C: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155430: BF870095
	.long 0xd71c002a                                           // 000000155434: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000155438: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000015543C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000155440: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155448: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v135, v45// 00000015544C: CA4654FF 292A5B87 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000155458: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015545C: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000155460: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000155468: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015546C: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000155470: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000155478: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 00000015547C: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155484: BF870091
	v_mul_f32_e32 v49, v45, v44                                // 000000155488: 1062592D
	v_fma_f32 v50, -v43, v49, v45                              // 00000015548C: D6130032 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155494: BF870091
	v_fmac_f32_e32 v49, v50, v44                               // 000000155498: 56625932
	v_fma_f32 v43, -v43, v49, v45                              // 00000015549C: D613002B 24B6632B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001554A4: BF870091
	v_div_fmas_f32 v43, v43, v44, v49                          // 0000001554A8: D637002B 04C6592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000001554B0: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v124, v[129:130]     // 0000001554B8: D6FF7C29 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001554C4: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000001554C8: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000001554D0: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000001554DC: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001554E4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001554E8: BE882005
	s_cbranch_execz 59791                                      // 0000001554EC: BFA5E98F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x362c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v125, v[131:132]     // 0000001554F0: D6FF7C29 060EFAFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 0000001554FC: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000155504: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000155508: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015550C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000155510: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000155518: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000155524: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000155528: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000015552C: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000155530: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000155538: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000155540: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000155544: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000155548: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000015554C: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155550: BF870095
	.long 0xd71c002a                                           // 000000155554: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000155558: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000015555C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000155560: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155568: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 00000015556C: 025254FF 7F800000
	v_dual_mul_f32 v42, v136, v46 :: v_dual_add_f32 v41, 1.0, v41// 000000155574: C8C85D88 2A2852F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015557C: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 000000155580: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 000000155588: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015558C: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 000000155590: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 000000155598: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 00000015559C: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001555A4: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000001555A8: 105C592D
	v_fma_f32 v49, -v43, v46, v45                              // 0000001555AC: D6130031 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001555B4: BF870091
	v_fmac_f32_e32 v46, v49, v44                               // 0000001555B8: 565C5931
	v_fma_f32 v43, -v43, v46, v45                              // 0000001555BC: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001555C4: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000001555C8: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000001555D0: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v125, v[129:130]     // 0000001555D8: D6FF7C29 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001555E4: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 0000001555E8: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 0000001555F0: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 0000001555FC: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000155604: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000155608: BE882006
	s_cbranch_execz 59722                                      // 00000015560C: BFA5E94A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3638>
	v_mad_i64_i32 v[41:42], null, 0x6000, v126, v[131:132]     // 000000155610: D6FF7C29 060EFCFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000015561C: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000155624: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000155628: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015562C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000155630: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000155638: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000155644: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000155648: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000015564C: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000155650: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000155658: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000155660: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000155664: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000155668: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000015566C: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155670: BF870095
	.long 0xd71c002a                                           // 000000155674: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000155678: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000015567C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 000000155680: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155688: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v133, v47// 00000015568C: CA4654FF 292A5F85 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 000000155698: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015569C: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000001556A0: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000001556A8: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001556AC: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000001556B0: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000001556B8: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000001556BC: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001556C4: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000001556C8: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000001556CC: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001556D4: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000001556D8: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000001556DC: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001556E4: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 0000001556E8: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 0000001556F0: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v126, v[129:130]     // 0000001556F8: D6FF7C29 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155704: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000155708: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000155710: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000015571C: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000155724: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000155728: BE882007
	s_cbranch_execz 59653                                      // 00000015572C: BFA5E905 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3644>
	v_mad_i64_i32 v[41:42], null, 0x6000, v127, v[131:132]     // 000000155730: D6FF7C29 060EFEFF 00006000
	global_load_u16 v41, v[41:42], off offset:832              // 00000015573C: DC4A0340 297C0029
	s_waitcnt vmcnt(0)                                         // 000000155744: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 000000155748: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015574C: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000155750: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 000000155758: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000155764: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000155768: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 00000015576C: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000155770: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 000000155778: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000155780: BF870121
	v_add_f32_e32 v42, v42, v43                                // 000000155784: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 000000155788: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 00000015578C: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155790: BF870095
	.long 0xd71c002a                                           // 000000155794: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 000000155798: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 00000015579C: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000001557A0: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001557A8: BF870092
	v_dual_cndmask_b32 v41, 0x7f800000, v42 :: v_dual_mul_f32 v42, v134, v48// 0000001557AC: CA4654FF 292A6186 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000001557B8: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001557BC: BF870091
	v_div_scale_f32 v43, null, v41, v41, v42                   // 0000001557C0: D6FC7C2B 04AA5329
	v_rcp_f32_e32 v44, v43                                     // 0000001557C8: 7E58552B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001557CC: BF870095
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000001557D0: D613002D 23CA592B
	v_fmac_f32_e32 v44, v45, v44                               // 0000001557D8: 5658592D
	v_div_scale_f32 v45, vcc_lo, v42, v41, v42                 // 0000001557DC: D6FC6A2D 04AA532A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001557E4: BF870091
	v_mul_f32_e32 v46, v45, v44                                // 0000001557E8: 105C592D
	v_fma_f32 v47, -v43, v46, v45                              // 0000001557EC: D613002F 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001557F4: BF870091
	v_fmac_f32_e32 v46, v47, v44                               // 0000001557F8: 565C592F
	v_fma_f32 v43, -v43, v46, v45                              // 0000001557FC: D613002B 24B65D2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155804: BF870091
	v_div_fmas_f32 v43, v43, v44, v46                          // 000000155808: D637002B 04BA592B
	v_div_fixup_f32 v43, v43, v41, v42                         // 000000155810: D627002B 04AA532B
	v_mad_i64_i32 v[41:42], null, 0x3000, v127, v[129:130]     // 000000155818: D6FF7C29 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155824: BF870092
	v_bfe_u32 v44, v43, 16, 1                                  // 000000155828: D610002C 0205212B
	v_add3_u32 v43, v43, v44, 0x7fff                           // 000000155830: D655002B 03FE592B 00007FFF
	global_store_d16_hi_b16 v[41:42], v43, off offset:320      // 00000015583C: DC960140 007C2B29
	s_or_b32 exec_lo, exec_lo, s8                              // 000000155844: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000155848: BE882000
	s_cbranch_execz 59584                                      // 00000015584C: BFA5E8C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3650>
	v_mad_i64_i32 v[41:42], null, 0x6000, v0, v[131:132]       // 000000155850: D6FF7C29 060E00FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 00000015585C: 1042438B
	global_load_u16 v41, v[41:42], off offset:864              // 000000155860: DC4A0360 297C0029
	s_waitcnt vmcnt(0)                                         // 000000155868: BF8903F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 00000015586C: 30525290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155870: BF870091
	v_mul_f32_e32 v42, 0xbfb8aa3b, v41                         // 000000155874: 105452FF BFB8AA3B
	v_fma_f32 v43, 0xbfb8aa3b, v41, -v42                       // 00000015587C: D613002B 84AA52FF BFB8AA3B
	v_rndne_f32_e32 v44, v42                                   // 000000155888: 7E58472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000015588C: BF870221
	v_sub_f32_e32 v42, v42, v44                                // 000000155890: 0854592A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v41                  // 000000155894: 7C3C52FF 42CE8ED0
	v_fmamk_f32 v43, v41, 0xb2a5705f, v43                      // 00000015589C: 58565729 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001558A4: BF870121
	v_add_f32_e32 v42, v42, v43                                // 0000001558A8: 0654572A
	v_cvt_i32_f32_e32 v43, v44                                 // 0000001558AC: 7E56112C
	v_exp_f32_e32 v42, v42                                     // 0000001558B0: 7E544B2A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001558B4: BF870095
	.long 0xd71c002a                                           // 0000001558B8: D71C002A
	v_cndmask_b32_e32 v1, v42, v43, vcc_lo                     // 0000001558BC: 0202572A
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000001558C0: 02545480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v41                  // 0000001558C4: 7C3652FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001558CC: BF870092
	v_cndmask_b32_e32 v41, 0x7f800000, v42, vcc_lo             // 0000001558D0: 025254FF 7F800000
	v_add_f32_e32 v41, 1.0, v41                                // 0000001558D8: 065252F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001558DC: BF870091
	v_div_scale_f32 v42, null, v41, v41, v33                   // 0000001558E0: D6FC7C2A 04865329
	v_rcp_f32_e32 v43, v42                                     // 0000001558E8: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001558EC: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000001558F0: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000001558F8: 5656572C
	v_div_scale_f32 v44, vcc_lo, v33, v41, v33                 // 0000001558FC: D6FC6A2C 04865321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155904: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 000000155908: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 00000015590C: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155914: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 000000155918: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 00000015591C: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155924: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 000000155928: D637002A 04B6572A
	v_div_fixup_f32 v33, v42, v41, v33                         // 000000155930: D6270021 0486532A
	v_mad_i64_i32 v[41:42], null, 0x3000, v0, v[129:130]       // 000000155938: D6FF7C29 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155944: BF870092
	v_bfe_u32 v43, v33, 16, 1                                  // 000000155948: D610002B 02052121
	v_add3_u32 v33, v33, v43, 0x7fff                           // 000000155950: D6550021 03FE5721 00007FFF
	global_store_d16_hi_b16 v[41:42], v33, off offset:352      // 00000015595C: DC960160 007C2129
	s_or_b32 exec_lo, exec_lo, s8                              // 000000155964: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000155968: BE882001
	s_cbranch_execz 59515                                      // 00000015596C: BFA5E87B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x365c>
	v_mad_i64_i32 v[41:42], null, 0x6000, v121, v[131:132]     // 000000155970: D6FF7C29 060EF2FF 00006000
	v_mul_f32_e32 v34, v140, v34                               // 00000015597C: 1044458C
	global_load_u16 v33, v[41:42], off offset:864              // 000000155980: DC4A0360 217C0029
	s_waitcnt vmcnt(0)                                         // 000000155988: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000015598C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000155990: BF870121
	v_mul_f32_e32 v41, 0xbfb8aa3b, v33                         // 000000155994: 105242FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 00000015599C: 7C3C42FF 42CE8ED0
	v_fma_f32 v42, 0xbfb8aa3b, v33, -v41                       // 0000001559A4: D613002A 84A642FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000001559B0: 7E564729
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001559B4: BF870112
	v_fmamk_f32 v42, v33, 0xb2a5705f, v42                      // 0000001559B8: 58545521 B2A5705F
	v_sub_f32_e32 v41, v41, v43                                // 0000001559C0: 08525729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001559C4: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000001559C8: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000001559CC: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 0000001559D0: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001559D4: BF870095
	.long 0xd71c0029                                           // 0000001559D8: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000001559DC: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000001559E0: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000001559E4: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001559EC: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v41, vcc_lo             // 0000001559F0: 024252FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000001559F8: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001559FC: BF870091
	v_div_scale_f32 v41, null, v33, v33, v34                   // 000000155A00: D6FC7C29 048A4321
	v_rcp_f32_e32 v42, v41                                     // 000000155A08: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155A0C: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 000000155A10: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 000000155A18: 5654552B
	v_div_scale_f32 v43, vcc_lo, v34, v33, v34                 // 000000155A1C: D6FC6A2B 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155A24: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 000000155A28: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 000000155A2C: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155A34: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 000000155A38: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 000000155A3C: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155A44: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 000000155A48: D6370029 04B25529
	v_div_fixup_f32 v41, v41, v33, v34                         // 000000155A50: D6270029 048A4329
	v_mad_i64_i32 v[33:34], null, 0x3000, v121, v[129:130]     // 000000155A58: D6FF7C21 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155A64: BF870092
	v_bfe_u32 v42, v41, 16, 1                                  // 000000155A68: D610002A 02052129
	v_add3_u32 v41, v41, v42, 0x7fff                           // 000000155A70: D6550029 03FE5529 00007FFF
	global_store_d16_hi_b16 v[33:34], v41, off offset:352      // 000000155A7C: DC960160 007C2921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000155A84: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000155A88: BE882002
	s_cbranch_execz 59446                                      // 000000155A8C: BFA5E836 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3668>
	v_mad_i64_i32 v[33:34], null, 0x6000, v122, v[131:132]     // 000000155A90: D6FF7C21 060EF4FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000155A9C: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000155AA4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000155AA8: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155AAC: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000155AB0: 104442FF BFB8AA3B
	v_fma_f32 v41, 0xbfb8aa3b, v33, -v34                       // 000000155AB8: D6130029 848A42FF BFB8AA3B
	v_rndne_f32_e32 v42, v34                                   // 000000155AC4: 7E544722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000155AC8: BF870221
	v_sub_f32_e32 v34, v34, v42                                // 000000155ACC: 08445522
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000155AD0: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v41, v33, 0xb2a5705f, v41                      // 000000155AD8: 58525321 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000155AE0: BF870121
	v_add_f32_e32 v34, v34, v41                                // 000000155AE4: 06445322
	v_cvt_i32_f32_e32 v41, v42                                 // 000000155AE8: 7E52112A
	v_exp_f32_e32 v34, v34                                     // 000000155AEC: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155AF0: BF870095
	.long 0xd71c0022                                           // 000000155AF4: D71C0022
	v_cndmask_b32_e32 v1, v34, v41, vcc_lo                     // 000000155AF8: 02025322
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000155AFC: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000155B00: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155B08: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v137, v35// 000000155B0C: CA4644FF 21224789 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000155B18: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155B1C: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000155B20: D6FC7C23 048A4321
	v_rcp_f32_e32 v41, v35                                     // 000000155B28: 7E525523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155B2C: BF870095
	v_fma_f32 v42, -v35, v41, 1.0                              // 000000155B30: D613002A 23CA5323
	v_fmac_f32_e32 v41, v42, v41                               // 000000155B38: 5652532A
	v_div_scale_f32 v42, vcc_lo, v34, v33, v34                 // 000000155B3C: D6FC6A2A 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155B44: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 000000155B48: 1056532A
	v_fma_f32 v44, -v35, v43, v42                              // 000000155B4C: D613002C 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155B54: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 000000155B58: 5656532C
	v_fma_f32 v35, -v35, v43, v42                              // 000000155B5C: D6130023 24AA5723
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155B64: BF870091
	v_div_fmas_f32 v35, v35, v41, v43                          // 000000155B68: D6370023 04AE5323
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000155B70: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v122, v[129:130]     // 000000155B78: D6FF7C21 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155B84: BF870092
	v_bfe_u32 v41, v35, 16, 1                                  // 000000155B88: D6100029 02052123
	v_add3_u32 v35, v35, v41, 0x7fff                           // 000000155B90: D6550023 03FE5323 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000155B9C: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000155BA4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000155BA8: BE882003
	s_cbranch_execz 59377                                      // 000000155BAC: BFA5E7F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3674>
	v_mad_i64_i32 v[33:34], null, 0x6000, v123, v[131:132]     // 000000155BB0: D6FF7C21 060EF6FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000155BBC: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000155BC4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000155BC8: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155BCC: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000155BD0: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000155BD8: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v41, v34                                   // 000000155BE4: 7E524722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155BE8: BF870091
	v_dual_fmamk_f32 v35, v33, 0xb2a5705f, v35 :: v_dual_sub_f32 v34, v34, v41// 000000155BEC: C88A4721 23225322 B2A5705F
	v_add_f32_e32 v34, v34, v35                                // 000000155BF8: 06444722
	v_cvt_i32_f32_e32 v35, v41                                 // 000000155BFC: 7E461129
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000155C00: 7C3C42FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000155C08: BF870293
	v_exp_f32_e32 v34, v34                                     // 000000155C0C: 7E444B22
	.long 0xd71c0022                                           // 000000155C10: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000155C14: 02024722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000155C18: BF870121
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000155C1C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000155C20: 7C3642FF C2B17218
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v138, v36// 000000155C28: CA4644FF 2122498A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155C34: BF870091
	v_add_f32_e32 v33, 1.0, v33                                // 000000155C38: 064242F2
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000155C3C: D6FC7C23 048A4321
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000155C44: BF870291
	v_rcp_f32_e32 v36, v35                                     // 000000155C48: 7E485523
	v_fma_f32 v41, -v35, v36, 1.0                              // 000000155C4C: D6130029 23CA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000155C54: BF8700A1
	v_fmac_f32_e32 v36, v41, v36                               // 000000155C58: 56484929
	v_div_scale_f32 v41, vcc_lo, v34, v33, v34                 // 000000155C5C: D6FC6A29 048A4322
	v_mul_f32_e32 v42, v41, v36                                // 000000155C64: 10544929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155C68: BF870091
	v_fma_f32 v43, -v35, v42, v41                              // 000000155C6C: D613002B 24A65523
	v_fmac_f32_e32 v42, v43, v36                               // 000000155C74: 5654492B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155C78: BF870091
	v_fma_f32 v35, -v35, v42, v41                              // 000000155C7C: D6130023 24A65523
	v_div_fmas_f32 v35, v35, v36, v42                          // 000000155C84: D6370023 04AA4923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000155C8C: BF870121
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000155C90: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v123, v[129:130]     // 000000155C98: D6FF7C21 0606F6FF 00003000
	v_bfe_u32 v36, v35, 16, 1                                  // 000000155CA4: D6100024 02052123
	s_delay_alu instid0(VALU_DEP_1)                            // 000000155CAC: BF870001
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000155CB0: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000155CBC: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000155CC4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000155CC8: BE882004
	s_cbranch_execz 59308                                      // 000000155CCC: BFA5E7AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3680>
	v_mad_i64_i32 v[33:34], null, 0x6000, v124, v[131:132]     // 000000155CD0: D6FF7C21 060EF8FF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000155CDC: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000155CE4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000155CE8: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155CEC: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000155CF0: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000155CF8: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000155D04: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000155D08: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000155D0C: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000155D10: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000155D18: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000155D20: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000155D24: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000155D28: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000155D2C: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155D30: BF870095
	.long 0xd71c0022                                           // 000000155D34: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000155D38: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000155D3C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000155D40: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155D48: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v135, v37// 000000155D4C: CA4644FF 21224B87 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000155D58: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155D5C: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000155D60: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000155D68: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155D6C: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000155D70: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000155D78: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000155D7C: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155D84: BF870091
	v_mul_f32_e32 v41, v37, v36                                // 000000155D88: 10524925
	v_fma_f32 v42, -v35, v41, v37                              // 000000155D8C: D613002A 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155D94: BF870091
	v_fmac_f32_e32 v41, v42, v36                               // 000000155D98: 5652492A
	v_fma_f32 v35, -v35, v41, v37                              // 000000155D9C: D6130023 24965323
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155DA4: BF870091
	v_div_fmas_f32 v35, v35, v36, v41                          // 000000155DA8: D6370023 04A64923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000155DB0: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v124, v[129:130]     // 000000155DB8: D6FF7C21 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155DC4: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000155DC8: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000155DD0: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000155DDC: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000155DE4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000155DE8: BE882005
	s_cbranch_execz 59239                                      // 000000155DEC: BFA5E767 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x368c>
	v_mad_i64_i32 v[33:34], null, 0x6000, v125, v[131:132]     // 000000155DF0: D6FF7C21 060EFAFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000155DFC: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000155E04: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000155E08: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155E0C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000155E10: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000155E18: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000155E24: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000155E28: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000155E2C: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000155E30: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000155E38: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000155E40: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000155E44: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000155E48: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000155E4C: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155E50: BF870095
	.long 0xd71c0022                                           // 000000155E54: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000155E58: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000155E5C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000155E60: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155E68: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 000000155E6C: 024244FF 7F800000
	v_dual_mul_f32 v34, v136, v38 :: v_dual_add_f32 v33, 1.0, v33// 000000155E74: C8C84D88 222042F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155E7C: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000155E80: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000155E88: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155E8C: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000155E90: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000155E98: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000155E9C: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155EA4: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000155EA8: 104C4925
	v_fma_f32 v41, -v35, v38, v37                              // 000000155EAC: D6130029 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155EB4: BF870091
	v_fmac_f32_e32 v38, v41, v36                               // 000000155EB8: 564C4929
	v_fma_f32 v35, -v35, v38, v37                              // 000000155EBC: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155EC4: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000155EC8: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000155ED0: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v125, v[129:130]     // 000000155ED8: D6FF7C21 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155EE4: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000155EE8: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000155EF0: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 000000155EFC: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000155F04: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000155F08: BE882006
	s_cbranch_execz 59170                                      // 000000155F0C: BFA5E722 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3698>
	v_mad_i64_i32 v[33:34], null, 0x6000, v126, v[131:132]     // 000000155F10: D6FF7C21 060EFCFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 000000155F1C: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000155F24: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000155F28: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155F2C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000155F30: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000155F38: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000155F44: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000155F48: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000155F4C: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000155F50: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000155F58: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000155F60: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000155F64: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000155F68: 7E461124
	v_exp_f32_e32 v34, v34                                     // 000000155F6C: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155F70: BF870095
	.long 0xd71c0022                                           // 000000155F74: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000155F78: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 000000155F7C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 000000155F80: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155F88: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v133, v39// 000000155F8C: CA4644FF 21224F85 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 000000155F98: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155F9C: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 000000155FA0: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 000000155FA8: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155FAC: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 000000155FB0: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 000000155FB8: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 000000155FBC: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155FC4: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 000000155FC8: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 000000155FCC: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155FD4: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 000000155FD8: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 000000155FDC: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000155FE4: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000155FE8: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000155FF0: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v126, v[129:130]     // 000000155FF8: D6FF7C21 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156004: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000156008: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000156010: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000015601C: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000156024: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000156028: BE882007
	s_cbranch_execz 59101                                      // 00000015602C: BFA5E6DD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36a4>
	v_mad_i64_i32 v[33:34], null, 0x6000, v127, v[131:132]     // 000000156030: D6FF7C21 060EFEFF 00006000
	global_load_u16 v33, v[33:34], off offset:864              // 00000015603C: DC4A0360 217C0021
	s_waitcnt vmcnt(0)                                         // 000000156044: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 000000156048: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015604C: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000156050: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 000000156058: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000156064: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000156068: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 00000015606C: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000156070: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 000000156078: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000156080: BF870121
	v_add_f32_e32 v34, v34, v35                                // 000000156084: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 000000156088: 7E461124
	v_exp_f32_e32 v34, v34                                     // 00000015608C: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156090: BF870095
	.long 0xd71c0022                                           // 000000156094: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 000000156098: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 00000015609C: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000001560A0: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001560A8: BF870092
	v_dual_cndmask_b32 v33, 0x7f800000, v34 :: v_dual_mul_f32 v34, v134, v40// 0000001560AC: CA4644FF 21225186 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000001560B8: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001560BC: BF870091
	v_div_scale_f32 v35, null, v33, v33, v34                   // 0000001560C0: D6FC7C23 048A4321
	v_rcp_f32_e32 v36, v35                                     // 0000001560C8: 7E485523
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001560CC: BF870095
	v_fma_f32 v37, -v35, v36, 1.0                              // 0000001560D0: D6130025 23CA4923
	v_fmac_f32_e32 v36, v37, v36                               // 0000001560D8: 56484925
	v_div_scale_f32 v37, vcc_lo, v34, v33, v34                 // 0000001560DC: D6FC6A25 048A4322
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001560E4: BF870091
	v_mul_f32_e32 v38, v37, v36                                // 0000001560E8: 104C4925
	v_fma_f32 v39, -v35, v38, v37                              // 0000001560EC: D6130027 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001560F4: BF870091
	v_fmac_f32_e32 v38, v39, v36                               // 0000001560F8: 564C4927
	v_fma_f32 v35, -v35, v38, v37                              // 0000001560FC: D6130023 24964D23
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156104: BF870091
	v_div_fmas_f32 v35, v35, v36, v38                          // 000000156108: D6370023 049A4923
	v_div_fixup_f32 v35, v35, v33, v34                         // 000000156110: D6270023 048A4323
	v_mad_i64_i32 v[33:34], null, 0x3000, v127, v[129:130]     // 000000156118: D6FF7C21 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156124: BF870092
	v_bfe_u32 v36, v35, 16, 1                                  // 000000156128: D6100024 02052123
	v_add3_u32 v35, v35, v36, 0x7fff                           // 000000156130: D6550023 03FE4923 00007FFF
	global_store_d16_hi_b16 v[33:34], v35, off offset:352      // 00000015613C: DC960160 007C2321
	s_or_b32 exec_lo, exec_lo, s8                              // 000000156144: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000156148: BE882000
	s_cbranch_execz 59032                                      // 00000015614C: BFA5E698 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36b0>
	v_mad_i64_i32 v[33:34], null, 0x6000, v0, v[131:132]       // 000000156150: D6FF7C21 060E00FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 00000015615C: 1032338B
	global_load_u16 v33, v[33:34], off offset:896              // 000000156160: DC4A0380 217C0021
	s_waitcnt vmcnt(0)                                         // 000000156168: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 00000015616C: 30424290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156170: BF870091
	v_mul_f32_e32 v34, 0xbfb8aa3b, v33                         // 000000156174: 104442FF BFB8AA3B
	v_fma_f32 v35, 0xbfb8aa3b, v33, -v34                       // 00000015617C: D6130023 848A42FF BFB8AA3B
	v_rndne_f32_e32 v36, v34                                   // 000000156188: 7E484722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000015618C: BF870221
	v_sub_f32_e32 v34, v34, v36                                // 000000156190: 08444922
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v33                  // 000000156194: 7C3C42FF 42CE8ED0
	v_fmamk_f32 v35, v33, 0xb2a5705f, v35                      // 00000015619C: 58464721 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001561A4: BF870121
	v_add_f32_e32 v34, v34, v35                                // 0000001561A8: 06444722
	v_cvt_i32_f32_e32 v35, v36                                 // 0000001561AC: 7E461124
	v_exp_f32_e32 v34, v34                                     // 0000001561B0: 7E444B22
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001561B4: BF870095
	.long 0xd71c0022                                           // 0000001561B8: D71C0022
	v_cndmask_b32_e32 v1, v34, v35, vcc_lo                     // 0000001561BC: 02024722
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000001561C0: 02444480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v33                  // 0000001561C4: 7C3642FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001561CC: BF870092
	v_cndmask_b32_e32 v33, 0x7f800000, v34, vcc_lo             // 0000001561D0: 024244FF 7F800000
	v_add_f32_e32 v33, 1.0, v33                                // 0000001561D8: 064242F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001561DC: BF870091
	v_div_scale_f32 v34, null, v33, v33, v25                   // 0000001561E0: D6FC7C22 04664321
	v_rcp_f32_e32 v35, v34                                     // 0000001561E8: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001561EC: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000001561F0: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000001561F8: 56464724
	v_div_scale_f32 v36, vcc_lo, v25, v33, v25                 // 0000001561FC: D6FC6A24 04664319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156204: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 000000156208: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 00000015620C: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156214: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 000000156218: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 00000015621C: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156224: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 000000156228: D6370022 04964722
	v_div_fixup_f32 v25, v34, v33, v25                         // 000000156230: D6270019 04664322
	v_mad_i64_i32 v[33:34], null, 0x3000, v0, v[129:130]       // 000000156238: D6FF7C21 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156244: BF870092
	v_bfe_u32 v35, v25, 16, 1                                  // 000000156248: D6100023 02052119
	v_add3_u32 v25, v25, v35, 0x7fff                           // 000000156250: D6550019 03FE4719 00007FFF
	global_store_d16_hi_b16 v[33:34], v25, off offset:384      // 00000015625C: DC960180 007C1921
	s_or_b32 exec_lo, exec_lo, s8                              // 000000156264: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000156268: BE882001
	s_cbranch_execz 58963                                      // 00000015626C: BFA5E653 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36bc>
	v_mad_i64_i32 v[33:34], null, 0x6000, v121, v[131:132]     // 000000156270: D6FF7C21 060EF2FF 00006000
	v_mul_f32_e32 v26, v140, v26                               // 00000015627C: 1034358C
	global_load_u16 v25, v[33:34], off offset:896              // 000000156280: DC4A0380 197C0021
	s_waitcnt vmcnt(0)                                         // 000000156288: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 00000015628C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000156290: BF870121
	v_mul_f32_e32 v33, 0xbfb8aa3b, v25                         // 000000156294: 104232FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 00000015629C: 7C3C32FF 42CE8ED0
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v33                       // 0000001562A4: D6130022 848632FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 0000001562B0: 7E464721
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001562B4: BF870112
	v_fmamk_f32 v34, v25, 0xb2a5705f, v34                      // 0000001562B8: 58444519 B2A5705F
	v_sub_f32_e32 v33, v33, v35                                // 0000001562C0: 08424721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001562C4: BF870121
	v_add_f32_e32 v33, v33, v34                                // 0000001562C8: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 0000001562CC: 7E441123
	v_exp_f32_e32 v33, v33                                     // 0000001562D0: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001562D4: BF870095
	.long 0xd71c0021                                           // 0000001562D8: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 0000001562DC: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 0000001562E0: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001562E4: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001562EC: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v33, vcc_lo             // 0000001562F0: 023242FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000001562F8: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001562FC: BF870091
	v_div_scale_f32 v33, null, v25, v25, v26                   // 000000156300: D6FC7C21 046A3319
	v_rcp_f32_e32 v34, v33                                     // 000000156308: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015630C: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 000000156310: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 000000156318: 56444523
	v_div_scale_f32 v35, vcc_lo, v26, v25, v26                 // 00000015631C: D6FC6A23 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156324: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 000000156328: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 00000015632C: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156334: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 000000156338: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 00000015633C: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156344: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 000000156348: D6370021 04924521
	v_div_fixup_f32 v33, v33, v25, v26                         // 000000156350: D6270021 046A3321
	v_mad_i64_i32 v[25:26], null, 0x3000, v121, v[129:130]     // 000000156358: D6FF7C19 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156364: BF870092
	v_bfe_u32 v34, v33, 16, 1                                  // 000000156368: D6100022 02052121
	v_add3_u32 v33, v33, v34, 0x7fff                           // 000000156370: D6550021 03FE4521 00007FFF
	global_store_d16_hi_b16 v[25:26], v33, off offset:384      // 00000015637C: DC960180 007C2119
	s_or_b32 exec_lo, exec_lo, s8                              // 000000156384: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000156388: BE882002
	s_cbranch_execz 58894                                      // 00000015638C: BFA5E60E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36c8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v122, v[131:132]     // 000000156390: D6FF7C19 060EF4FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000015639C: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000001563A4: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000001563A8: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001563AC: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000001563B0: 103432FF BFB8AA3B
	v_fma_f32 v33, 0xbfb8aa3b, v25, -v26                       // 0000001563B8: D6130021 846A32FF BFB8AA3B
	v_rndne_f32_e32 v34, v26                                   // 0000001563C4: 7E44471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001563C8: BF870221
	v_sub_f32_e32 v26, v26, v34                                // 0000001563CC: 0834451A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 0000001563D0: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v33, v25, 0xb2a5705f, v33                      // 0000001563D8: 58424319 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001563E0: BF870121
	v_add_f32_e32 v26, v26, v33                                // 0000001563E4: 0634431A
	v_cvt_i32_f32_e32 v33, v34                                 // 0000001563E8: 7E421122
	v_exp_f32_e32 v26, v26                                     // 0000001563EC: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001563F0: BF870095
	.long 0xd71c001a                                           // 0000001563F4: D71C001A
	v_cndmask_b32_e32 v1, v26, v33, vcc_lo                     // 0000001563F8: 0202431A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 0000001563FC: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000156400: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156408: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v137, v27// 00000015640C: CA4634FF 191A3789 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000156418: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015641C: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000156420: D6FC7C1B 046A3319
	v_rcp_f32_e32 v33, v27                                     // 000000156428: 7E42551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015642C: BF870095
	v_fma_f32 v34, -v27, v33, 1.0                              // 000000156430: D6130022 23CA431B
	v_fmac_f32_e32 v33, v34, v33                               // 000000156438: 56424322
	v_div_scale_f32 v34, vcc_lo, v26, v25, v26                 // 00000015643C: D6FC6A22 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156444: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 000000156448: 10464322
	v_fma_f32 v36, -v27, v35, v34                              // 00000015644C: D6130024 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156454: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 000000156458: 56464324
	v_fma_f32 v27, -v27, v35, v34                              // 00000015645C: D613001B 248A471B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156464: BF870091
	v_div_fmas_f32 v27, v27, v33, v35                          // 000000156468: D637001B 048E431B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000156470: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v122, v[129:130]     // 000000156478: D6FF7C19 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156484: BF870092
	v_bfe_u32 v33, v27, 16, 1                                  // 000000156488: D6100021 0205211B
	v_add3_u32 v27, v27, v33, 0x7fff                           // 000000156490: D655001B 03FE431B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000015649C: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001564A4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001564A8: BE882003
	s_cbranch_execz 58825                                      // 0000001564AC: BFA5E5C9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36d4>
	v_mad_i64_i32 v[25:26], null, 0x6000, v123, v[131:132]     // 0000001564B0: D6FF7C19 060EF6FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000001564BC: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000001564C4: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000001564C8: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001564CC: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000001564D0: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000001564D8: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v33, v26                                   // 0000001564E4: 7E42471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001564E8: BF870091
	v_dual_fmamk_f32 v27, v25, 0xb2a5705f, v27 :: v_dual_sub_f32 v26, v26, v33// 0000001564EC: C88A3719 1B1A431A B2A5705F
	v_add_f32_e32 v26, v26, v27                                // 0000001564F8: 0634371A
	v_cvt_i32_f32_e32 v27, v33                                 // 0000001564FC: 7E361121
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000156500: 7C3C32FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000156508: BF870293
	v_exp_f32_e32 v26, v26                                     // 00000015650C: 7E344B1A
	.long 0xd71c001a                                           // 000000156510: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000156514: 0202371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000156518: BF870121
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000015651C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000156520: 7C3632FF C2B17218
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v138, v28// 000000156528: CA4634FF 191A398A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156534: BF870091
	v_add_f32_e32 v25, 1.0, v25                                // 000000156538: 063232F2
	v_div_scale_f32 v27, null, v25, v25, v26                   // 00000015653C: D6FC7C1B 046A3319
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000156544: BF870291
	v_rcp_f32_e32 v28, v27                                     // 000000156548: 7E38551B
	v_fma_f32 v33, -v27, v28, 1.0                              // 00000015654C: D6130021 23CA391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000156554: BF8700A1
	v_fmac_f32_e32 v28, v33, v28                               // 000000156558: 56383921
	v_div_scale_f32 v33, vcc_lo, v26, v25, v26                 // 00000015655C: D6FC6A21 046A331A
	v_mul_f32_e32 v34, v33, v28                                // 000000156564: 10443921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156568: BF870091
	v_fma_f32 v35, -v27, v34, v33                              // 00000015656C: D6130023 2486451B
	v_fmac_f32_e32 v34, v35, v28                               // 000000156574: 56443923
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156578: BF870091
	v_fma_f32 v27, -v27, v34, v33                              // 00000015657C: D613001B 2486451B
	v_div_fmas_f32 v27, v27, v28, v34                          // 000000156584: D637001B 048A391B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015658C: BF870121
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000156590: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v123, v[129:130]     // 000000156598: D6FF7C19 0606F6FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001565A4: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001565AC: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001565B0: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000001565BC: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001565C4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001565C8: BE882004
	s_cbranch_execz 58756                                      // 0000001565CC: BFA5E584 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36e0>
	v_mad_i64_i32 v[25:26], null, 0x6000, v124, v[131:132]     // 0000001565D0: D6FF7C19 060EF8FF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000001565DC: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 0000001565E4: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 0000001565E8: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001565EC: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 0000001565F0: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 0000001565F8: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000156604: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000156608: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000015660C: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000156610: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000156618: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000156620: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000156624: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000156628: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000015662C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156630: BF870095
	.long 0xd71c001a                                           // 000000156634: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000156638: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000015663C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000156640: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156648: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v135, v29// 00000015664C: CA4634FF 191A3B87 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000156658: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015665C: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000156660: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000156668: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015666C: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000156670: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000156678: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000015667C: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156684: BF870091
	v_mul_f32_e32 v33, v29, v28                                // 000000156688: 1042391D
	v_fma_f32 v34, -v27, v33, v29                              // 00000015668C: D6130022 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156694: BF870091
	v_fmac_f32_e32 v33, v34, v28                               // 000000156698: 56423922
	v_fma_f32 v27, -v27, v33, v29                              // 00000015669C: D613001B 2476431B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001566A4: BF870091
	v_div_fmas_f32 v27, v27, v28, v33                          // 0000001566A8: D637001B 0486391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000001566B0: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v124, v[129:130]     // 0000001566B8: D6FF7C19 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001566C4: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001566C8: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001566D0: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000001566DC: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001566E4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001566E8: BE882005
	s_cbranch_execz 58687                                      // 0000001566EC: BFA5E53F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36ec>
	v_mad_i64_i32 v[25:26], null, 0x6000, v125, v[131:132]     // 0000001566F0: D6FF7C19 060EFAFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 0000001566FC: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000156704: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000156708: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015670C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000156710: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000156718: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000156724: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000156728: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000015672C: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000156730: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000156738: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000156740: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000156744: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000156748: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000015674C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156750: BF870095
	.long 0xd71c001a                                           // 000000156754: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000156758: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000015675C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000156760: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156768: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 00000015676C: 023234FF 7F800000
	v_dual_mul_f32 v26, v136, v30 :: v_dual_add_f32 v25, 1.0, v25// 000000156774: C8C83D88 1A1832F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015677C: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 000000156780: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 000000156788: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015678C: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 000000156790: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 000000156798: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 00000015679C: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001567A4: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000001567A8: 103C391D
	v_fma_f32 v33, -v27, v30, v29                              // 0000001567AC: D6130021 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001567B4: BF870091
	v_fmac_f32_e32 v30, v33, v28                               // 0000001567B8: 563C3921
	v_fma_f32 v27, -v27, v30, v29                              // 0000001567BC: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001567C4: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000001567C8: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000001567D0: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v125, v[129:130]     // 0000001567D8: D6FF7C19 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001567E4: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001567E8: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001567F0: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 0000001567FC: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000156804: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000156808: BE882006
	s_cbranch_execz 58618                                      // 00000015680C: BFA5E4FA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36f8>
	v_mad_i64_i32 v[25:26], null, 0x6000, v126, v[131:132]     // 000000156810: D6FF7C19 060EFCFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000015681C: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000156824: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000156828: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015682C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000156830: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000156838: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000156844: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000156848: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000015684C: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000156850: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000156858: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000156860: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000156864: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000156868: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000015686C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156870: BF870095
	.long 0xd71c001a                                           // 000000156874: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000156878: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000015687C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000156880: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156888: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v133, v31// 00000015688C: CA4634FF 191A3F85 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000156898: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015689C: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000001568A0: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000001568A8: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001568AC: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000001568B0: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000001568B8: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000001568BC: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001568C4: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000001568C8: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000001568CC: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001568D4: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000001568D8: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000001568DC: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001568E4: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 0000001568E8: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 0000001568F0: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v126, v[129:130]     // 0000001568F8: D6FF7C19 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156904: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000156908: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000156910: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 00000015691C: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000156924: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000156928: BE882007
	s_cbranch_execz 58549                                      // 00000015692C: BFA5E4B5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3704>
	v_mad_i64_i32 v[25:26], null, 0x6000, v127, v[131:132]     // 000000156930: D6FF7C19 060EFEFF 00006000
	global_load_u16 v25, v[25:26], off offset:896              // 00000015693C: DC4A0380 197C0019
	s_waitcnt vmcnt(0)                                         // 000000156944: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000156948: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015694C: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000156950: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000156958: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000156964: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000156968: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 00000015696C: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000156970: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000156978: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000156980: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000156984: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000156988: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000015698C: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156990: BF870095
	.long 0xd71c001a                                           // 000000156994: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000156998: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 00000015699C: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001569A0: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001569A8: BF870092
	v_dual_cndmask_b32 v25, 0x7f800000, v26 :: v_dual_mul_f32 v26, v134, v32// 0000001569AC: CA4634FF 191A4186 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 0000001569B8: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001569BC: BF870091
	v_div_scale_f32 v27, null, v25, v25, v26                   // 0000001569C0: D6FC7C1B 046A3319
	v_rcp_f32_e32 v28, v27                                     // 0000001569C8: 7E38551B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001569CC: BF870095
	v_fma_f32 v29, -v27, v28, 1.0                              // 0000001569D0: D613001D 23CA391B
	v_fmac_f32_e32 v28, v29, v28                               // 0000001569D8: 5638391D
	v_div_scale_f32 v29, vcc_lo, v26, v25, v26                 // 0000001569DC: D6FC6A1D 046A331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001569E4: BF870091
	v_mul_f32_e32 v30, v29, v28                                // 0000001569E8: 103C391D
	v_fma_f32 v31, -v27, v30, v29                              // 0000001569EC: D613001F 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001569F4: BF870091
	v_fmac_f32_e32 v30, v31, v28                               // 0000001569F8: 563C391F
	v_fma_f32 v27, -v27, v30, v29                              // 0000001569FC: D613001B 24763D1B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156A04: BF870091
	v_div_fmas_f32 v27, v27, v28, v30                          // 000000156A08: D637001B 047A391B
	v_div_fixup_f32 v27, v27, v25, v26                         // 000000156A10: D627001B 046A331B
	v_mad_i64_i32 v[25:26], null, 0x3000, v127, v[129:130]     // 000000156A18: D6FF7C19 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156A24: BF870092
	v_bfe_u32 v28, v27, 16, 1                                  // 000000156A28: D610001C 0205211B
	v_add3_u32 v27, v27, v28, 0x7fff                           // 000000156A30: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off offset:384      // 000000156A3C: DC960180 007C1B19
	s_or_b32 exec_lo, exec_lo, s8                              // 000000156A44: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000156A48: BE882000
	s_cbranch_execz 58480                                      // 000000156A4C: BFA5E470 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3710>
	v_mad_i64_i32 v[25:26], null, 0x6000, v0, v[131:132]       // 000000156A50: D6FF7C19 060E00FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 000000156A5C: 1022238B
	global_load_u16 v25, v[25:26], off offset:928              // 000000156A60: DC4A03A0 197C0019
	s_waitcnt vmcnt(0)                                         // 000000156A68: BF8903F7
	v_lshlrev_b32_e32 v25, 16, v25                             // 000000156A6C: 30323290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156A70: BF870091
	v_mul_f32_e32 v26, 0xbfb8aa3b, v25                         // 000000156A74: 103432FF BFB8AA3B
	v_fma_f32 v27, 0xbfb8aa3b, v25, -v26                       // 000000156A7C: D613001B 846A32FF BFB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 000000156A88: 7E38471A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000156A8C: BF870221
	v_sub_f32_e32 v26, v26, v28                                // 000000156A90: 0834391A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v25                  // 000000156A94: 7C3C32FF 42CE8ED0
	v_fmamk_f32 v27, v25, 0xb2a5705f, v27                      // 000000156A9C: 58363719 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000156AA4: BF870121
	v_add_f32_e32 v26, v26, v27                                // 000000156AA8: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000156AAC: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000156AB0: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156AB4: BF870095
	.long 0xd71c001a                                           // 000000156AB8: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 000000156ABC: 0202371A
	v_cndmask_b32_e32 v26, 0, v26, vcc_lo                      // 000000156AC0: 02343480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 000000156AC4: 7C3632FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156ACC: BF870092
	v_cndmask_b32_e32 v25, 0x7f800000, v26, vcc_lo             // 000000156AD0: 023234FF 7F800000
	v_add_f32_e32 v25, 1.0, v25                                // 000000156AD8: 063232F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156ADC: BF870091
	v_div_scale_f32 v26, null, v25, v25, v17                   // 000000156AE0: D6FC7C1A 04463319
	v_rcp_f32_e32 v27, v26                                     // 000000156AE8: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156AEC: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 000000156AF0: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 000000156AF8: 5636371C
	v_div_scale_f32 v28, vcc_lo, v17, v25, v17                 // 000000156AFC: D6FC6A1C 04463311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156B04: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 000000156B08: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 000000156B0C: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156B14: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 000000156B18: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 000000156B1C: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156B24: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 000000156B28: D637001A 0476371A
	v_div_fixup_f32 v17, v26, v25, v17                         // 000000156B30: D6270011 0446331A
	v_mad_i64_i32 v[25:26], null, 0x3000, v0, v[129:130]       // 000000156B38: D6FF7C19 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156B44: BF870092
	v_bfe_u32 v27, v17, 16, 1                                  // 000000156B48: D610001B 02052111
	v_add3_u32 v17, v17, v27, 0x7fff                           // 000000156B50: D6550011 03FE3711 00007FFF
	global_store_d16_hi_b16 v[25:26], v17, off offset:416      // 000000156B5C: DC9601A0 007C1119
	s_or_b32 exec_lo, exec_lo, s8                              // 000000156B64: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000156B68: BE882001
	s_cbranch_execz 58411                                      // 000000156B6C: BFA5E42B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x371c>
	v_mad_i64_i32 v[25:26], null, 0x6000, v121, v[131:132]     // 000000156B70: D6FF7C19 060EF2FF 00006000
	v_mul_f32_e32 v18, v140, v18                               // 000000156B7C: 1024258C
	global_load_u16 v17, v[25:26], off offset:928              // 000000156B80: DC4A03A0 117C0019
	s_waitcnt vmcnt(0)                                         // 000000156B88: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000156B8C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000156B90: BF870121
	v_mul_f32_e32 v25, 0xbfb8aa3b, v17                         // 000000156B94: 103222FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000156B9C: 7C3C22FF 42CE8ED0
	v_fma_f32 v26, 0xbfb8aa3b, v17, -v25                       // 000000156BA4: D613001A 846622FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 000000156BB0: 7E364719
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000156BB4: BF870112
	v_fmamk_f32 v26, v17, 0xb2a5705f, v26                      // 000000156BB8: 58343511 B2A5705F
	v_sub_f32_e32 v25, v25, v27                                // 000000156BC0: 08323719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000156BC4: BF870121
	v_add_f32_e32 v25, v25, v26                                // 000000156BC8: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 000000156BCC: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 000000156BD0: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156BD4: BF870095
	.long 0xd71c0019                                           // 000000156BD8: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000156BDC: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000156BE0: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000156BE4: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156BEC: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v25, vcc_lo             // 000000156BF0: 022232FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000156BF8: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156BFC: BF870091
	v_div_scale_f32 v25, null, v17, v17, v18                   // 000000156C00: D6FC7C19 044A2311
	v_rcp_f32_e32 v26, v25                                     // 000000156C08: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156C0C: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 000000156C10: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 000000156C18: 5634351B
	v_div_scale_f32 v27, vcc_lo, v18, v17, v18                 // 000000156C1C: D6FC6A1B 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156C24: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 000000156C28: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 000000156C2C: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156C34: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 000000156C38: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 000000156C3C: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156C44: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 000000156C48: D6370019 04723519
	v_div_fixup_f32 v25, v25, v17, v18                         // 000000156C50: D6270019 044A2319
	v_mad_i64_i32 v[17:18], null, 0x3000, v121, v[129:130]     // 000000156C58: D6FF7C11 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156C64: BF870092
	v_bfe_u32 v26, v25, 16, 1                                  // 000000156C68: D610001A 02052119
	v_add3_u32 v25, v25, v26, 0x7fff                           // 000000156C70: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[17:18], v25, off offset:416      // 000000156C7C: DC9601A0 007C1911
	s_or_b32 exec_lo, exec_lo, s8                              // 000000156C84: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000156C88: BE882002
	s_cbranch_execz 58342                                      // 000000156C8C: BFA5E3E6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3728>
	v_mad_i64_i32 v[17:18], null, 0x6000, v122, v[131:132]     // 000000156C90: D6FF7C11 060EF4FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000156C9C: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000156CA4: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000156CA8: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156CAC: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000156CB0: 102422FF BFB8AA3B
	v_fma_f32 v25, 0xbfb8aa3b, v17, -v18                       // 000000156CB8: D6130019 844A22FF BFB8AA3B
	v_rndne_f32_e32 v26, v18                                   // 000000156CC4: 7E344712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000156CC8: BF870221
	v_sub_f32_e32 v18, v18, v26                                // 000000156CCC: 08243512
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000156CD0: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v25, v17, 0xb2a5705f, v25                      // 000000156CD8: 58323311 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000156CE0: BF870121
	v_add_f32_e32 v18, v18, v25                                // 000000156CE4: 06243312
	v_cvt_i32_f32_e32 v25, v26                                 // 000000156CE8: 7E32111A
	v_exp_f32_e32 v18, v18                                     // 000000156CEC: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156CF0: BF870095
	.long 0xd71c0012                                           // 000000156CF4: D71C0012
	v_cndmask_b32_e32 v1, v18, v25, vcc_lo                     // 000000156CF8: 02023312
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000156CFC: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000156D00: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156D08: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v137, v19// 000000156D0C: CA4624FF 11122789 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000156D18: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156D1C: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000156D20: D6FC7C13 044A2311
	v_rcp_f32_e32 v25, v19                                     // 000000156D28: 7E325513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156D2C: BF870095
	v_fma_f32 v26, -v19, v25, 1.0                              // 000000156D30: D613001A 23CA3313
	v_fmac_f32_e32 v25, v26, v25                               // 000000156D38: 5632331A
	v_div_scale_f32 v26, vcc_lo, v18, v17, v18                 // 000000156D3C: D6FC6A1A 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156D44: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 000000156D48: 1036331A
	v_fma_f32 v28, -v19, v27, v26                              // 000000156D4C: D613001C 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156D54: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 000000156D58: 5636331C
	v_fma_f32 v19, -v19, v27, v26                              // 000000156D5C: D6130013 246A3713
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156D64: BF870091
	v_div_fmas_f32 v19, v19, v25, v27                          // 000000156D68: D6370013 046E3313
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000156D70: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v122, v[129:130]     // 000000156D78: D6FF7C11 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156D84: BF870092
	v_bfe_u32 v25, v19, 16, 1                                  // 000000156D88: D6100019 02052113
	v_add3_u32 v19, v19, v25, 0x7fff                           // 000000156D90: D6550013 03FE3313 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000156D9C: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000156DA4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000156DA8: BE882003
	s_cbranch_execz 58273                                      // 000000156DAC: BFA5E3A1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3734>
	v_mad_i64_i32 v[17:18], null, 0x6000, v123, v[131:132]     // 000000156DB0: D6FF7C11 060EF6FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000156DBC: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000156DC4: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000156DC8: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156DCC: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000156DD0: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000156DD8: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v25, v18                                   // 000000156DE4: 7E324712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156DE8: BF870091
	v_dual_fmamk_f32 v19, v17, 0xb2a5705f, v19 :: v_dual_sub_f32 v18, v18, v25// 000000156DEC: C88A2711 13123312 B2A5705F
	v_add_f32_e32 v18, v18, v19                                // 000000156DF8: 06242712
	v_cvt_i32_f32_e32 v19, v25                                 // 000000156DFC: 7E261119
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000156E00: 7C3C22FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000156E08: BF870293
	v_exp_f32_e32 v18, v18                                     // 000000156E0C: 7E244B12
	.long 0xd71c0012                                           // 000000156E10: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000156E14: 02022712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000156E18: BF870121
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000156E1C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000156E20: 7C3622FF C2B17218
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v138, v20// 000000156E28: CA4624FF 1112298A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156E34: BF870091
	v_add_f32_e32 v17, 1.0, v17                                // 000000156E38: 062222F2
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000156E3C: D6FC7C13 044A2311
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000156E44: BF870291
	v_rcp_f32_e32 v20, v19                                     // 000000156E48: 7E285513
	v_fma_f32 v25, -v19, v20, 1.0                              // 000000156E4C: D6130019 23CA2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000156E54: BF8700A1
	v_fmac_f32_e32 v20, v25, v20                               // 000000156E58: 56282919
	v_div_scale_f32 v25, vcc_lo, v18, v17, v18                 // 000000156E5C: D6FC6A19 044A2312
	v_mul_f32_e32 v26, v25, v20                                // 000000156E64: 10342919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156E68: BF870091
	v_fma_f32 v27, -v19, v26, v25                              // 000000156E6C: D613001B 24663513
	v_fmac_f32_e32 v26, v27, v20                               // 000000156E74: 5634291B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156E78: BF870091
	v_fma_f32 v19, -v19, v26, v25                              // 000000156E7C: D6130013 24663513
	v_div_fmas_f32 v19, v19, v20, v26                          // 000000156E84: D6370013 046A2913
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000156E8C: BF870121
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000156E90: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v123, v[129:130]     // 000000156E98: D6FF7C11 0606F6FF 00003000
	v_bfe_u32 v20, v19, 16, 1                                  // 000000156EA4: D6100014 02052113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000156EAC: BF870001
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000156EB0: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000156EBC: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000156EC4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000156EC8: BE882004
	s_cbranch_execz 58204                                      // 000000156ECC: BFA5E35C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3740>
	v_mad_i64_i32 v[17:18], null, 0x6000, v124, v[131:132]     // 000000156ED0: D6FF7C11 060EF8FF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000156EDC: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000156EE4: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000156EE8: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156EEC: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000156EF0: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000156EF8: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000156F04: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000156F08: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000156F0C: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000156F10: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000156F18: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000156F20: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000156F24: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000156F28: 7E261114
	v_exp_f32_e32 v18, v18                                     // 000000156F2C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156F30: BF870095
	.long 0xd71c0012                                           // 000000156F34: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000156F38: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 000000156F3C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000156F40: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156F48: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v135, v21// 000000156F4C: CA4624FF 11122B87 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000156F58: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156F5C: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000156F60: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000156F68: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156F6C: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000156F70: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000156F78: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 000000156F7C: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156F84: BF870091
	v_mul_f32_e32 v25, v21, v20                                // 000000156F88: 10322915
	v_fma_f32 v26, -v19, v25, v21                              // 000000156F8C: D613001A 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156F94: BF870091
	v_fmac_f32_e32 v25, v26, v20                               // 000000156F98: 5632291A
	v_fma_f32 v19, -v19, v25, v21                              // 000000156F9C: D6130013 24563313
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156FA4: BF870091
	v_div_fmas_f32 v19, v19, v20, v25                          // 000000156FA8: D6370013 04662913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000156FB0: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v124, v[129:130]     // 000000156FB8: D6FF7C11 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000156FC4: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000156FC8: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000156FD0: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 000000156FDC: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000156FE4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000156FE8: BE882005
	s_cbranch_execz 58135                                      // 000000156FEC: BFA5E317 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x374c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v125, v[131:132]     // 000000156FF0: D6FF7C11 060EFAFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 000000156FFC: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000157004: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000157008: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015700C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000157010: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000157018: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000157024: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000157028: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000015702C: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000157030: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000157038: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000157040: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000157044: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000157048: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000015704C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157050: BF870095
	.long 0xd71c0012                                           // 000000157054: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000157058: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000015705C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000157060: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157068: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 00000015706C: 022224FF 7F800000
	v_dual_mul_f32 v18, v136, v22 :: v_dual_add_f32 v17, 1.0, v17// 000000157074: C8C82D88 121022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015707C: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 000000157080: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 000000157088: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015708C: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 000000157090: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 000000157098: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 00000015709C: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001570A4: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000001570A8: 102C2915
	v_fma_f32 v25, -v19, v22, v21                              // 0000001570AC: D6130019 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001570B4: BF870091
	v_fmac_f32_e32 v22, v25, v20                               // 0000001570B8: 562C2919
	v_fma_f32 v19, -v19, v22, v21                              // 0000001570BC: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001570C4: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000001570C8: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000001570D0: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v125, v[129:130]     // 0000001570D8: D6FF7C11 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001570E4: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 0000001570E8: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 0000001570F0: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 0000001570FC: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000157104: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000157108: BE882006
	s_cbranch_execz 58066                                      // 00000015710C: BFA5E2D2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3758>
	v_mad_i64_i32 v[17:18], null, 0x6000, v126, v[131:132]     // 000000157110: D6FF7C11 060EFCFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000015711C: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000157124: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000157128: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015712C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000157130: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000157138: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000157144: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000157148: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000015714C: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000157150: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000157158: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000157160: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000157164: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000157168: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000015716C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157170: BF870095
	.long 0xd71c0012                                           // 000000157174: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000157178: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000015717C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 000000157180: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157188: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v133, v23// 00000015718C: CA4624FF 11122F85 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 000000157198: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015719C: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000001571A0: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000001571A8: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001571AC: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000001571B0: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000001571B8: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000001571BC: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001571C4: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000001571C8: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000001571CC: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001571D4: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000001571D8: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000001571DC: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001571E4: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 0000001571E8: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 0000001571F0: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v126, v[129:130]     // 0000001571F8: D6FF7C11 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157204: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000157208: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000157210: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000015721C: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000157224: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000157228: BE882007
	s_cbranch_execz 57997                                      // 00000015722C: BFA5E28D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3764>
	v_mad_i64_i32 v[17:18], null, 0x6000, v127, v[131:132]     // 000000157230: D6FF7C11 060EFEFF 00006000
	global_load_u16 v17, v[17:18], off offset:928              // 00000015723C: DC4A03A0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000157244: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 000000157248: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015724C: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000157250: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 000000157258: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000157264: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000157268: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 00000015726C: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000157270: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 000000157278: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000157280: BF870121
	v_add_f32_e32 v18, v18, v19                                // 000000157284: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 000000157288: 7E261114
	v_exp_f32_e32 v18, v18                                     // 00000015728C: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157290: BF870095
	.long 0xd71c0012                                           // 000000157294: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 000000157298: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 00000015729C: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000001572A0: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001572A8: BF870092
	v_dual_cndmask_b32 v17, 0x7f800000, v18 :: v_dual_mul_f32 v18, v134, v24// 0000001572AC: CA4624FF 11123186 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000001572B8: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001572BC: BF870091
	v_div_scale_f32 v19, null, v17, v17, v18                   // 0000001572C0: D6FC7C13 044A2311
	v_rcp_f32_e32 v20, v19                                     // 0000001572C8: 7E285513
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001572CC: BF870095
	v_fma_f32 v21, -v19, v20, 1.0                              // 0000001572D0: D6130015 23CA2913
	v_fmac_f32_e32 v20, v21, v20                               // 0000001572D8: 56282915
	v_div_scale_f32 v21, vcc_lo, v18, v17, v18                 // 0000001572DC: D6FC6A15 044A2312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001572E4: BF870091
	v_mul_f32_e32 v22, v21, v20                                // 0000001572E8: 102C2915
	v_fma_f32 v23, -v19, v22, v21                              // 0000001572EC: D6130017 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001572F4: BF870091
	v_fmac_f32_e32 v22, v23, v20                               // 0000001572F8: 562C2917
	v_fma_f32 v19, -v19, v22, v21                              // 0000001572FC: D6130013 24562D13
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157304: BF870091
	v_div_fmas_f32 v19, v19, v20, v22                          // 000000157308: D6370013 045A2913
	v_div_fixup_f32 v19, v19, v17, v18                         // 000000157310: D6270013 044A2313
	v_mad_i64_i32 v[17:18], null, 0x3000, v127, v[129:130]     // 000000157318: D6FF7C11 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157324: BF870092
	v_bfe_u32 v20, v19, 16, 1                                  // 000000157328: D6100014 02052113
	v_add3_u32 v19, v19, v20, 0x7fff                           // 000000157330: D6550013 03FE2913 00007FFF
	global_store_d16_hi_b16 v[17:18], v19, off offset:416      // 00000015733C: DC9601A0 007C1311
	s_or_b32 exec_lo, exec_lo, s8                              // 000000157344: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000157348: BE882000
	s_cbranch_execz 57928                                      // 00000015734C: BFA5E248 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3770>
	v_mad_i64_i32 v[17:18], null, 0x6000, v0, v[131:132]       // 000000157350: D6FF7C11 060E00FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 00000015735C: 1012138B
	global_load_u16 v17, v[17:18], off offset:960              // 000000157360: DC4A03C0 117C0011
	s_waitcnt vmcnt(0)                                         // 000000157368: BF8903F7
	v_lshlrev_b32_e32 v17, 16, v17                             // 00000015736C: 30222290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157370: BF870091
	v_mul_f32_e32 v18, 0xbfb8aa3b, v17                         // 000000157374: 102422FF BFB8AA3B
	v_fma_f32 v19, 0xbfb8aa3b, v17, -v18                       // 00000015737C: D6130013 844A22FF BFB8AA3B
	v_rndne_f32_e32 v20, v18                                   // 000000157388: 7E284712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000015738C: BF870221
	v_sub_f32_e32 v18, v18, v20                                // 000000157390: 08242912
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v17                  // 000000157394: 7C3C22FF 42CE8ED0
	v_fmamk_f32 v19, v17, 0xb2a5705f, v19                      // 00000015739C: 58262711 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001573A4: BF870121
	v_add_f32_e32 v18, v18, v19                                // 0000001573A8: 06242712
	v_cvt_i32_f32_e32 v19, v20                                 // 0000001573AC: 7E261114
	v_exp_f32_e32 v18, v18                                     // 0000001573B0: 7E244B12
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001573B4: BF870095
	.long 0xd71c0012                                           // 0000001573B8: D71C0012
	v_cndmask_b32_e32 v1, v18, v19, vcc_lo                     // 0000001573BC: 02022712
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001573C0: 02242480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v17                  // 0000001573C4: 7C3622FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001573CC: BF870092
	v_cndmask_b32_e32 v17, 0x7f800000, v18, vcc_lo             // 0000001573D0: 022224FF 7F800000
	v_add_f32_e32 v17, 1.0, v17                                // 0000001573D8: 062222F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001573DC: BF870091
	v_div_scale_f32 v18, null, v17, v17, v9                    // 0000001573E0: D6FC7C12 04262311
	v_rcp_f32_e32 v19, v18                                     // 0000001573E8: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001573EC: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000001573F0: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 0000001573F8: 56262714
	v_div_scale_f32 v20, vcc_lo, v9, v17, v9                   // 0000001573FC: D6FC6A14 04262309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157404: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 000000157408: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 00000015740C: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157414: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 000000157418: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 00000015741C: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157424: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 000000157428: D6370012 04562712
	v_div_fixup_f32 v9, v18, v17, v9                           // 000000157430: D6270009 04262312
	v_mad_i64_i32 v[17:18], null, 0x3000, v0, v[129:130]       // 000000157438: D6FF7C11 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157444: BF870092
	v_bfe_u32 v19, v9, 16, 1                                   // 000000157448: D6100013 02052109
	v_add3_u32 v9, v9, v19, 0x7fff                             // 000000157450: D6550009 03FE2709 00007FFF
	global_store_d16_hi_b16 v[17:18], v9, off offset:448       // 00000015745C: DC9601C0 007C0911
	s_or_b32 exec_lo, exec_lo, s8                              // 000000157464: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000157468: BE882001
	s_cbranch_execz 57859                                      // 00000015746C: BFA5E203 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x377c>
	v_mad_i64_i32 v[17:18], null, 0x6000, v121, v[131:132]     // 000000157470: D6FF7C11 060EF2FF 00006000
	v_mul_f32_e32 v10, v140, v10                               // 00000015747C: 1014158C
	global_load_u16 v9, v[17:18], off offset:960               // 000000157480: DC4A03C0 097C0011
	s_waitcnt vmcnt(0)                                         // 000000157488: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 00000015748C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000157490: BF870121
	v_mul_f32_e32 v17, 0xbfb8aa3b, v9                          // 000000157494: 102212FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 00000015749C: 7C3C12FF 42CE8ED0
	v_fma_f32 v18, 0xbfb8aa3b, v9, -v17                        // 0000001574A4: D6130012 844612FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 0000001574B0: 7E264711
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001574B4: BF870112
	v_fmamk_f32 v18, v9, 0xb2a5705f, v18                       // 0000001574B8: 58242509 B2A5705F
	v_sub_f32_e32 v17, v17, v19                                // 0000001574C0: 08222711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001574C4: BF870121
	v_add_f32_e32 v17, v17, v18                                // 0000001574C8: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 0000001574CC: 7E241113
	v_exp_f32_e32 v17, v17                                     // 0000001574D0: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001574D4: BF870095
	.long 0xd71c0011                                           // 0000001574D8: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 0000001574DC: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000001574E0: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 0000001574E4: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001574EC: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v17, vcc_lo              // 0000001574F0: 021222FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 0000001574F8: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001574FC: BF870091
	v_div_scale_f32 v17, null, v9, v9, v10                     // 000000157500: D6FC7C11 042A1309
	v_rcp_f32_e32 v18, v17                                     // 000000157508: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015750C: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 000000157510: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 000000157518: 56242513
	v_div_scale_f32 v19, vcc_lo, v10, v9, v10                  // 00000015751C: D6FC6A13 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157524: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 000000157528: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 00000015752C: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157534: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 000000157538: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 00000015753C: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157544: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 000000157548: D6370011 04522511
	v_div_fixup_f32 v17, v17, v9, v10                          // 000000157550: D6270011 042A1311
	v_mad_i64_i32 v[9:10], null, 0x3000, v121, v[129:130]      // 000000157558: D6FF7C09 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157564: BF870092
	v_bfe_u32 v18, v17, 16, 1                                  // 000000157568: D6100012 02052111
	v_add3_u32 v17, v17, v18, 0x7fff                           // 000000157570: D6550011 03FE2511 00007FFF
	global_store_d16_hi_b16 v[9:10], v17, off offset:448       // 00000015757C: DC9601C0 007C1109
	s_or_b32 exec_lo, exec_lo, s8                              // 000000157584: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000157588: BE882002
	s_cbranch_execz 57790                                      // 00000015758C: BFA5E1BE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3788>
	v_mad_i64_i32 v[9:10], null, 0x6000, v122, v[131:132]      // 000000157590: D6FF7C09 060EF4FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 00000015759C: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000001575A4: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000001575A8: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001575AC: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000001575B0: 101412FF BFB8AA3B
	v_fma_f32 v17, 0xbfb8aa3b, v9, -v10                        // 0000001575B8: D6130011 842A12FF BFB8AA3B
	v_rndne_f32_e32 v18, v10                                   // 0000001575C4: 7E24470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001575C8: BF870221
	v_sub_f32_e32 v10, v10, v18                                // 0000001575CC: 0814250A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 0000001575D0: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v17, v9, 0xb2a5705f, v17                       // 0000001575D8: 58222309 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001575E0: BF870121
	v_add_f32_e32 v10, v10, v17                                // 0000001575E4: 0614230A
	v_cvt_i32_f32_e32 v17, v18                                 // 0000001575E8: 7E221112
	v_exp_f32_e32 v10, v10                                     // 0000001575EC: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001575F0: BF870095
	.long 0xd71c000a                                           // 0000001575F4: D71C000A
	v_cndmask_b32_e32 v1, v10, v17, vcc_lo                     // 0000001575F8: 0202230A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000001575FC: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000157600: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157608: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v137, v11// 00000015760C: CA4614FF 090A1789 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000157618: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015761C: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000157620: D6FC7C0B 042A1309
	v_rcp_f32_e32 v17, v11                                     // 000000157628: 7E22550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015762C: BF870095
	v_fma_f32 v18, -v11, v17, 1.0                              // 000000157630: D6130012 23CA230B
	v_fmac_f32_e32 v17, v18, v17                               // 000000157638: 56222312
	v_div_scale_f32 v18, vcc_lo, v10, v9, v10                  // 00000015763C: D6FC6A12 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157644: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 000000157648: 10262312
	v_fma_f32 v20, -v11, v19, v18                              // 00000015764C: D6130014 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157654: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 000000157658: 56262314
	v_fma_f32 v11, -v11, v19, v18                              // 00000015765C: D613000B 244A270B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157664: BF870091
	v_div_fmas_f32 v11, v11, v17, v19                          // 000000157668: D637000B 044E230B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000157670: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v122, v[129:130]      // 000000157678: D6FF7C09 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157684: BF870092
	v_bfe_u32 v17, v11, 16, 1                                  // 000000157688: D6100011 0205210B
	v_add3_u32 v11, v11, v17, 0x7fff                           // 000000157690: D655000B 03FE230B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 00000015769C: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001576A4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 0000001576A8: BE882003
	s_cbranch_execz 57721                                      // 0000001576AC: BFA5E179 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3794>
	v_mad_i64_i32 v[9:10], null, 0x6000, v123, v[131:132]      // 0000001576B0: D6FF7C09 060EF6FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000001576BC: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000001576C4: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000001576C8: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001576CC: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000001576D0: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000001576D8: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v17, v10                                   // 0000001576E4: 7E22470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001576E8: BF870091
	v_dual_fmamk_f32 v11, v9, 0xb2a5705f, v11 :: v_dual_sub_f32 v10, v10, v17// 0000001576EC: C88A1709 0B0A230A B2A5705F
	v_add_f32_e32 v10, v10, v11                                // 0000001576F8: 0614170A
	v_cvt_i32_f32_e32 v11, v17                                 // 0000001576FC: 7E161111
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000157700: 7C3C12FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000157708: BF870293
	v_exp_f32_e32 v10, v10                                     // 00000015770C: 7E144B0A
	.long 0xd71c000a                                           // 000000157710: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000157714: 0202170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000157718: BF870121
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000015771C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000157720: 7C3612FF C2B17218
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v138, v12// 000000157728: CA4614FF 090A198A 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157734: BF870091
	v_add_f32_e32 v9, 1.0, v9                                  // 000000157738: 061212F2
	v_div_scale_f32 v11, null, v9, v9, v10                     // 00000015773C: D6FC7C0B 042A1309
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000157744: BF870291
	v_rcp_f32_e32 v12, v11                                     // 000000157748: 7E18550B
	v_fma_f32 v17, -v11, v12, 1.0                              // 00000015774C: D6130011 23CA190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000157754: BF8700A1
	v_fmac_f32_e32 v12, v17, v12                               // 000000157758: 56181911
	v_div_scale_f32 v17, vcc_lo, v10, v9, v10                  // 00000015775C: D6FC6A11 042A130A
	v_mul_f32_e32 v18, v17, v12                                // 000000157764: 10241911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157768: BF870091
	v_fma_f32 v19, -v11, v18, v17                              // 00000015776C: D6130013 2446250B
	v_fmac_f32_e32 v18, v19, v12                               // 000000157774: 56241913
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157778: BF870091
	v_fma_f32 v11, -v11, v18, v17                              // 00000015777C: D613000B 2446250B
	v_div_fmas_f32 v11, v11, v12, v18                          // 000000157784: D637000B 044A190B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000015778C: BF870121
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000157790: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v123, v[129:130]      // 000000157798: D6FF7C09 0606F6FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001577A4: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001577AC: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001577B0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000001577BC: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001577C4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 0000001577C8: BE882004
	s_cbranch_execz 57652                                      // 0000001577CC: BFA5E134 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37a0>
	v_mad_i64_i32 v[9:10], null, 0x6000, v124, v[131:132]      // 0000001577D0: D6FF7C09 060EF8FF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000001577DC: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 0000001577E4: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000001577E8: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001577EC: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 0000001577F0: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 0000001577F8: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000157804: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000157808: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000015780C: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000157810: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000157818: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000157820: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000157824: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000157828: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000015782C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157830: BF870095
	.long 0xd71c000a                                           // 000000157834: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000157838: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000015783C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000157840: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157848: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v135, v13// 00000015784C: CA4614FF 090A1B87 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000157858: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015785C: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000157860: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000157868: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015786C: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000157870: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000157878: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000015787C: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157884: BF870091
	v_mul_f32_e32 v17, v13, v12                                // 000000157888: 1022190D
	v_fma_f32 v18, -v11, v17, v13                              // 00000015788C: D6130012 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157894: BF870091
	v_fmac_f32_e32 v17, v18, v12                               // 000000157898: 56221912
	v_fma_f32 v11, -v11, v17, v13                              // 00000015789C: D613000B 2436230B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001578A4: BF870091
	v_div_fmas_f32 v11, v11, v12, v17                          // 0000001578A8: D637000B 0446190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000001578B0: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v124, v[129:130]      // 0000001578B8: D6FF7C09 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001578C4: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001578C8: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001578D0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000001578DC: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001578E4: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001578E8: BE882005
	s_cbranch_execz 57583                                      // 0000001578EC: BFA5E0EF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37ac>
	v_mad_i64_i32 v[9:10], null, 0x6000, v125, v[131:132]      // 0000001578F0: D6FF7C09 060EFAFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 0000001578FC: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000157904: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000157908: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015790C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000157910: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000157918: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000157924: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000157928: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 00000015792C: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000157930: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000157938: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000157940: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000157944: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000157948: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 00000015794C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157950: BF870095
	.long 0xd71c000a                                           // 000000157954: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000157958: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 00000015795C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000157960: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157968: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 00000015796C: 021214FF 7F800000
	v_dual_mul_f32 v10, v136, v14 :: v_dual_add_f32 v9, 1.0, v9// 000000157974: C8C81D88 0A0812F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015797C: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000157980: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000157988: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015798C: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000157990: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000157998: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 00000015799C: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001579A4: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 0000001579A8: 101C190D
	v_fma_f32 v17, -v11, v14, v13                              // 0000001579AC: D6130011 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001579B4: BF870091
	v_fmac_f32_e32 v14, v17, v12                               // 0000001579B8: 561C1911
	v_fma_f32 v11, -v11, v14, v13                              // 0000001579BC: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001579C4: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 0000001579C8: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 0000001579D0: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v125, v[129:130]      // 0000001579D8: D6FF7C09 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001579E4: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001579E8: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001579F0: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 0000001579FC: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000157A04: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000157A08: BE882006
	s_cbranch_execz 57514                                      // 000000157A0C: BFA5E0AA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37b8>
	v_mad_i64_i32 v[9:10], null, 0x6000, v126, v[131:132]      // 000000157A10: D6FF7C09 060EFCFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000157A1C: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000157A24: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000157A28: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157A2C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000157A30: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000157A38: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000157A44: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000157A48: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000157A4C: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000157A50: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000157A58: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000157A60: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000157A64: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000157A68: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000157A6C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157A70: BF870095
	.long 0xd71c000a                                           // 000000157A74: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000157A78: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000157A7C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000157A80: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157A88: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v133, v15// 000000157A8C: CA4614FF 090A1F85 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000157A98: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157A9C: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000157AA0: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000157AA8: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157AAC: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000157AB0: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000157AB8: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000157ABC: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157AC4: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000157AC8: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000157ACC: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157AD4: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000157AD8: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000157ADC: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157AE4: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000157AE8: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000157AF0: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v126, v[129:130]      // 000000157AF8: D6FF7C09 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157B04: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000157B08: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000157B10: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000157B1C: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000157B24: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000157B28: BE882007
	s_cbranch_execz 57445                                      // 000000157B2C: BFA5E065 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37c4>
	v_mad_i64_i32 v[9:10], null, 0x6000, v127, v[131:132]      // 000000157B30: D6FF7C09 060EFEFF 00006000
	global_load_u16 v9, v[9:10], off offset:960                // 000000157B3C: DC4A03C0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000157B44: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000157B48: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157B4C: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000157B50: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000157B58: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000157B64: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000157B68: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000157B6C: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000157B70: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000157B78: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000157B80: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000157B84: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000157B88: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000157B8C: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157B90: BF870095
	.long 0xd71c000a                                           // 000000157B94: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000157B98: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000157B9C: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000157BA0: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157BA8: BF870092
	v_dual_cndmask_b32 v9, 0x7f800000, v10 :: v_dual_mul_f32 v10, v134, v16// 000000157BAC: CA4614FF 090A2186 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000157BB8: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157BBC: BF870091
	v_div_scale_f32 v11, null, v9, v9, v10                     // 000000157BC0: D6FC7C0B 042A1309
	v_rcp_f32_e32 v12, v11                                     // 000000157BC8: 7E18550B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157BCC: BF870095
	v_fma_f32 v13, -v11, v12, 1.0                              // 000000157BD0: D613000D 23CA190B
	v_fmac_f32_e32 v12, v13, v12                               // 000000157BD8: 5618190D
	v_div_scale_f32 v13, vcc_lo, v10, v9, v10                  // 000000157BDC: D6FC6A0D 042A130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157BE4: BF870091
	v_mul_f32_e32 v14, v13, v12                                // 000000157BE8: 101C190D
	v_fma_f32 v15, -v11, v14, v13                              // 000000157BEC: D613000F 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157BF4: BF870091
	v_fmac_f32_e32 v14, v15, v12                               // 000000157BF8: 561C190F
	v_fma_f32 v11, -v11, v14, v13                              // 000000157BFC: D613000B 24361D0B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157C04: BF870091
	v_div_fmas_f32 v11, v11, v12, v14                          // 000000157C08: D637000B 043A190B
	v_div_fixup_f32 v11, v11, v9, v10                          // 000000157C10: D627000B 042A130B
	v_mad_i64_i32 v[9:10], null, 0x3000, v127, v[129:130]      // 000000157C18: D6FF7C09 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157C24: BF870092
	v_bfe_u32 v12, v11, 16, 1                                  // 000000157C28: D610000C 0205210B
	v_add3_u32 v11, v11, v12, 0x7fff                           // 000000157C30: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:448       // 000000157C3C: DC9601C0 007C0B09
	s_or_b32 exec_lo, exec_lo, s8                              // 000000157C44: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000157C48: BE882000
	s_cbranch_execz 57376                                      // 000000157C4C: BFA5E020 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37d0>
	v_mad_i64_i32 v[9:10], null, 0x6000, v0, v[131:132]        // 000000157C50: D6FF7C09 060E00FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 000000157C5C: 1002038B
	global_load_u16 v9, v[9:10], off offset:992                // 000000157C60: DC4A03E0 097C0009
	s_waitcnt vmcnt(0)                                         // 000000157C68: BF8903F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 000000157C6C: 30121290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157C70: BF870091
	v_mul_f32_e32 v10, 0xbfb8aa3b, v9                          // 000000157C74: 101412FF BFB8AA3B
	v_fma_f32 v11, 0xbfb8aa3b, v9, -v10                        // 000000157C7C: D613000B 842A12FF BFB8AA3B
	v_rndne_f32_e32 v12, v10                                   // 000000157C88: 7E18470A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000157C8C: BF870221
	v_sub_f32_e32 v10, v10, v12                                // 000000157C90: 0814190A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v9                   // 000000157C94: 7C3C12FF 42CE8ED0
	v_fmamk_f32 v11, v9, 0xb2a5705f, v11                       // 000000157C9C: 58161709 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000157CA4: BF870121
	v_add_f32_e32 v10, v10, v11                                // 000000157CA8: 0614170A
	v_cvt_i32_f32_e32 v11, v12                                 // 000000157CAC: 7E16110C
	v_exp_f32_e32 v10, v10                                     // 000000157CB0: 7E144B0A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157CB4: BF870095
	.long 0xd71c000a                                           // 000000157CB8: D71C000A
	v_cndmask_b32_e32 v1, v10, v11, vcc_lo                     // 000000157CBC: 0202170A
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 000000157CC0: 02141480
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v9                   // 000000157CC4: 7C3612FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157CCC: BF870092
	v_cndmask_b32_e32 v9, 0x7f800000, v10, vcc_lo              // 000000157CD0: 021214FF 7F800000
	v_add_f32_e32 v9, 1.0, v9                                  // 000000157CD8: 061212F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157CDC: BF870091
	v_div_scale_f32 v10, null, v9, v9, v1                      // 000000157CE0: D6FC7C0A 04061309
	v_rcp_f32_e32 v11, v10                                     // 000000157CE8: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157CEC: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 000000157CF0: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 000000157CF8: 5616170C
	v_div_scale_f32 v12, vcc_lo, v1, v9, v1                    // 000000157CFC: D6FC6A0C 04061301
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157D04: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 000000157D08: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 000000157D0C: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157D14: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 000000157D18: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 000000157D1C: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157D24: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 000000157D28: D637000A 0436170A
	v_div_fixup_f32 v9, v10, v9, v1                            // 000000157D30: D6270009 0406130A
	v_mad_i64_i32 v[0:1], null, 0x3000, v0, v[129:130]         // 000000157D38: D6FF7C00 060600FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157D44: BF870092
	v_bfe_u32 v10, v9, 16, 1                                   // 000000157D48: D610000A 02052109
	v_add3_u32 v9, v9, v10, 0x7fff                             // 000000157D50: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[0:1], v9, off offset:480         // 000000157D5C: DC9601E0 007C0900
	s_or_b32 exec_lo, exec_lo, s8                              // 000000157D64: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000157D68: BE802001
	s_cbranch_execz 57307                                      // 000000157D6C: BFA5DFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37dc>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[131:132]       // 000000157D70: D6FF7C00 060EF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000157D7C: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000157D84: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000157D88: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157D8C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000157D90: 100200FF BFB8AA3B
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v1                          // 000000157D98: D6130009 840600FF BFB8AA3B
	v_rndne_f32_e32 v10, v1                                    // 000000157DA4: 7E144701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000157DA8: BF870191
	v_sub_f32_e32 v1, v1, v10                                  // 000000157DAC: 08021501
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 000000157DB0: 58121300 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000157DB8: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000157DC0: BF870122
	v_add_f32_e32 v1, v1, v9                                   // 000000157DC4: 06021301
	v_cvt_i32_f32_e32 v9, v10                                  // 000000157DC8: 7E12110A
	v_exp_f32_e32 v1, v1                                       // 000000157DCC: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157DD0: BF870095
	.long 0xd71c0001                                           // 000000157DD4: D71C0001
	v_cndmask_b32_e32 v1, v1, v9, vcc_lo                       // 000000157DD8: 02021301
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000157DDC: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000157DE0: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157DE8: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v140, v2// 000000157DEC: CA4602FF 0000058C 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000157DF8: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157DFC: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000157E00: D6FC7C02 04060100
	v_rcp_f32_e32 v9, v2                                       // 000000157E08: 7E125502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157E0C: BF870095
	v_fma_f32 v10, -v2, v9, 1.0                                // 000000157E10: D613000A 23CA1302
	v_fmac_f32_e32 v9, v10, v9                                 // 000000157E18: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 000000157E1C: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157E24: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 000000157E28: 1016130A
	v_fma_f32 v12, -v2, v11, v10                               // 000000157E2C: D613000C 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157E34: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 000000157E38: 5616130C
	v_fma_f32 v2, -v2, v11, v10                                // 000000157E3C: D6130002 242A1702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157E44: BF870091
	v_div_fmas_f32 v2, v2, v9, v11                             // 000000157E48: D6370002 042E1302
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000157E50: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[129:130]       // 000000157E58: D6FF7C00 0606F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157E64: BF870092
	v_bfe_u32 v9, v2, 16, 1                                    // 000000157E68: D6100009 02052102
	v_add3_u32 v2, v2, v9, 0x7fff                              // 000000157E70: D6550002 03FE1302 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000157E7C: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000157E84: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 000000157E88: BE802002
	s_cbranch_execz 57238                                      // 000000157E8C: BFA5DF96 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37e8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[131:132]       // 000000157E90: D6FF7C00 060EF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000157E9C: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000157EA4: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000157EA8: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157EAC: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000157EB0: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000157EB8: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 000000157EC4: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000157EC8: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 000000157ECC: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000157ED0: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000157ED8: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000157EE0: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000157EE4: 06020501
	v_cvt_i32_f32_e32 v2, v9                                   // 000000157EE8: 7E041109
	v_exp_f32_e32 v1, v1                                       // 000000157EEC: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157EF0: BF870095
	.long 0xd71c0001                                           // 000000157EF4: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000157EF8: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000157EFC: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000157F00: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157F08: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 000000157F0C: CA4602FF 00000789 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000157F18: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157F1C: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000157F20: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000157F28: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157F2C: BF870095
	v_fma_f32 v9, -v2, v3, 1.0                                 // 000000157F30: D6130009 23CA0702
	v_fmac_f32_e32 v3, v9, v3                                  // 000000157F38: 56060709
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 000000157F3C: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157F44: BF870091
	v_mul_f32_e32 v10, v9, v3                                  // 000000157F48: 10140709
	v_fma_f32 v11, -v2, v10, v9                                // 000000157F4C: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157F54: BF870091
	v_fmac_f32_e32 v10, v11, v3                                // 000000157F58: 5614070B
	v_fma_f32 v2, -v2, v10, v9                                 // 000000157F5C: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157F64: BF870091
	v_div_fmas_f32 v2, v2, v3, v10                             // 000000157F68: D6370002 042A0702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000157F70: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[129:130]       // 000000157F78: D6FF7C00 0606F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157F84: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000157F88: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000157F90: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000157F9C: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000157FA4: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 000000157FA8: BE802003
	s_cbranch_execz 57169                                      // 000000157FAC: BFA5DF51 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37f4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[131:132]       // 000000157FB0: D6FF7C00 060EF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000157FBC: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000157FC4: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000157FC8: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000157FCC: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000157FD0: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000157FD8: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000157FE4: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000157FE8: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000157FEC: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000157FF0: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000157FF8: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000158000: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000158004: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000158008: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000015800C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158010: BF870095
	.long 0xd71c0001                                           // 000000158014: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000158018: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000015801C: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000158020: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158028: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v138, v4// 00000015802C: CA4602FF 0000098A 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000158038: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015803C: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000158040: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000158048: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015804C: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000158050: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000158058: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000015805C: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158064: BF870091
	v_mul_f32_e32 v9, v4, v3                                   // 000000158068: 10120704
	v_fma_f32 v10, -v2, v9, v4                                 // 00000015806C: D613000A 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158074: BF870091
	v_fmac_f32_e32 v9, v10, v3                                 // 000000158078: 5612070A
	v_fma_f32 v2, -v2, v9, v4                                  // 00000015807C: D6130002 24121302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158084: BF870091
	v_div_fmas_f32 v2, v2, v3, v9                              // 000000158088: D6370002 04260702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000158090: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[129:130]       // 000000158098: D6FF7C00 0606F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001580A4: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000001580A8: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000001580B0: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001580BC: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001580C4: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 0000001580C8: BE802004
	s_cbranch_execz 57100                                      // 0000001580CC: BFA5DF0C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3800>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[131:132]       // 0000001580D0: D6FF7C00 060EF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000001580DC: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000001580E4: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000001580E8: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001580EC: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000001580F0: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000001580F8: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000158104: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000158108: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000015810C: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000158110: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000158118: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000158120: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000158124: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000158128: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000015812C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158130: BF870095
	.long 0xd71c0001                                           // 000000158134: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000158138: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000015813C: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000158140: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158148: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 00000015814C: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 000000158154: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015815C: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000158160: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000158168: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015816C: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000158170: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000158178: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000015817C: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158184: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 000000158188: 100A0704
	v_fma_f32 v9, -v2, v5, v4                                  // 00000015818C: D6130009 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158194: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 000000158198: 560A0709
	v_fma_f32 v2, -v2, v5, v4                                  // 00000015819C: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001581A4: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000001581A8: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000001581B0: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[129:130]       // 0000001581B8: D6FF7C00 0606F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001581C4: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000001581C8: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000001581D0: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001581DC: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001581E4: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000001581E8: BE802005
	s_cbranch_execz 57031                                      // 0000001581EC: BFA5DEC7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x380c>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[131:132]       // 0000001581F0: D6FF7C00 060EFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000001581FC: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000158204: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000158208: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015820C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000158210: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000158218: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000158224: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000158228: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000015822C: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000158230: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000158238: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000158240: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000158244: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000158248: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000015824C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158250: BF870095
	.long 0xd71c0001                                           // 000000158254: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000158258: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000015825C: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000158260: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158268: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v6// 00000015826C: CA4602FF 00000D88 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000158278: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015827C: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000158280: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 000000158288: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015828C: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000158290: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 000000158298: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000015829C: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001582A4: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000001582A8: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000001582AC: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001582B4: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000001582B8: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000001582BC: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001582C4: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000001582C8: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000001582D0: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[129:130]       // 0000001582D8: D6FF7C00 0606FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001582E4: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000001582E8: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000001582F0: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001582FC: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000158304: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 000000158308: BE802006
	s_cbranch_execz 56962                                      // 00000015830C: BFA5DE82 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3818>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[131:132]       // 000000158310: D6FF7C00 060EFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000015831C: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000158324: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000158328: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015832C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000158330: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000158338: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000158344: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000158348: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000015834C: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000158350: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000158358: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000158360: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000158364: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000158368: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000015836C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158370: BF870095
	.long 0xd71c0001                                           // 000000158374: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000158378: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000015837C: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000158380: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158388: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 00000015838C: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000158398: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015839C: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000001583A0: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000001583A8: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001583AC: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000001583B0: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000001583B8: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000001583BC: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001583C4: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000001583C8: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000001583CC: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001583D4: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000001583D8: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000001583DC: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001583E4: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000001583E8: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000001583F0: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[129:130]       // 0000001583F8: D6FF7C00 0606FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158404: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000158408: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000158410: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000015841C: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000158424: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 000000158428: BE802007
	s_cbranch_execz 56893                                      // 00000015842C: BFA5DE3D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb0ELi0ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3824>
	v_mad_i64_i32 v[0:1], null, 0x6000, v127, v[131:132]       // 000000158430: D6FF7C00 060EFEFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000015843C: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000158444: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000158448: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000015844C: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000158450: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 000000158458: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000158464: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000158468: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000015846C: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000158470: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 000000158478: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000158480: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000158484: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 000000158488: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000015848C: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158490: BF870095
	.long 0xd71c0001                                           // 000000158494: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 000000158498: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000015849C: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000001584A0: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001584A8: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v8// 0000001584AC: CA4602FF 00001186 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000001584B8: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001584BC: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000001584C0: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 0000001584C8: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001584CC: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000001584D0: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000001584D8: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000001584DC: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001584E4: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000001584E8: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000001584EC: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001584F4: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000001584F8: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000001584FC: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158504: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 000000158508: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000158510: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v127, v[129:130]       // 000000158518: D6FF7C00 0606FEFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000158524: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 000000158528: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000158530: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000015853C: DC9601E0 007C0200
	s_nop 0                                                    // 000000158544: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000158548: BFB60003
	s_endpgm                                                   // 00000015854C: BFB00000
		...

