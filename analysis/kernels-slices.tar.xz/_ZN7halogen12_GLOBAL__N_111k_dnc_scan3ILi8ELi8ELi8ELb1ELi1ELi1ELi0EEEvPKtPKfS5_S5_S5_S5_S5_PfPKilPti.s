000000000006bd00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 00000006BD00: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 00000006BD04: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000006BD0C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 00000006BD14: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 00000006BD18: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000006BD1C: 861B9F1A
	v_dual_mov_b32 v5, v0 :: v_dual_and_b32 v4, 15, v0         // 00000006BD20: CA240100 0504008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000006BD28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v4                                // 00000006BD2C: 30020882
	s_waitcnt lgkmcnt(0)                                       // 00000006BD30: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 00000006BD34: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000006BD3C: 84928214
	s_add_u32 s25, s16, s18                                    // 00000006BD40: 80191210
	s_addc_u32 s28, s17, s19                                   // 00000006BD44: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 00000006BD48: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006BD4C: BF870009
	s_add_u32 s25, s25, s20                                    // 00000006BD50: 80191419
	s_addc_u32 s30, s28, s21                                   // 00000006BD54: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 00000006BD58: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000006BD5C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 00000006BD64: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000006BD6C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 00000006BD70: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 00000006BD74: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000006BD78: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000006BD7C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 00000006BD80: 821E191E
	.long 0xd7001f02                                           // 00000006BD84: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 00000006BD88: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000006BD8C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 00000006BD94: BE9E0080
	s_nop 0                                                    // 00000006BD98: BF800000
	s_nop 0                                                    // 00000006BD9C: BF800000
	s_nop 0                                                    // 00000006BDA0: BF800000
	s_nop 0                                                    // 00000006BDA4: BF800000
	s_nop 0                                                    // 00000006BDA8: BF800000
	s_nop 0                                                    // 00000006BDAC: BF800000
	s_nop 0                                                    // 00000006BDB0: BF800000
	s_nop 0                                                    // 00000006BDB4: BF800000
	s_nop 0                                                    // 00000006BDB8: BF800000
	s_nop 0                                                    // 00000006BDBC: BF800000
	v_lshrrev_b32_e32 v8, 4, v5                                // 00000006BDC0: 32100A84
	v_add_nc_u32_e32 v10, 0x80, v5                             // 00000006BDC4: 4A140AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BDCC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 00000006BDD0: 300C1089
	.long 0xd7006a06                                           // 00000006BDD4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000006BDD8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006BDDC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 00000006BDE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v5                         // 00000006BDE8: 7C920AFF 0000077F
	v_mov_b32_e32 v5, v10                                      // 00000006BDF0: 7E0A030A
	global_load_b32 v9, v[6:7], off                            // 00000006BDF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 00000006BDFC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 00000006BE08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000006BE0C: BF8903F7
	ds_store_b32 v6, v9                                        // 00000006BE10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 00000006BE18: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000006BE1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 00000006BE20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 00000006BE24: F4000780 F8000058
	v_or_b32_e32 v51, 0xffffff80, v0                           // 00000006BE2C: 386600FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 00000006BE34: 32040084
	s_mov_b32 s0, 0                                            // 00000006BE38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000006BE3C: BF89FC07
	s_barrier                                                  // 00000006BE40: BFBD0000
	buffer_gl0_inv                                             // 00000006BE44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000006BE4C: BF02801E
	s_cbranch_scc1 12                                          // 00000006BE50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 00000006BE54: 160604FF 00000044
	v_or_b32_e32 v5, 0xffffff80, v0                            // 00000006BE5C: 380A00FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000006BE64: BF870002
	v_lshl_add_u32 v50, v4, 2, v3                              // 00000006BE68: D6460032 040D0504
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v52, 2, v4      // 00000006BE70: CA220080 03340882
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000006BE78: 916A007E
	s_cbranch_vccz 2                                           // 00000006BE7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 3502                                              // 00000006BE80: BFA00DAE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x383c>
	v_lshlrev_b32_e32 v52, 2, v4                               // 00000006BE84: 30680882
	s_add_i32 s0, s30, 63                                      // 00000006BE88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000006BE8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 00000006BE94: 85218600
	s_add_u32 s34, s10, s24                                    // 00000006BE98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000006BE9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 00000006BEA0: 84008702
	v_lshlrev_b32_e32 v53, 2, v0                               // 00000006BEA4: 306A0082
	s_ashr_i32 s1, s0, 31                                      // 00000006BEA8: 86019F00
	v_lshlrev_b32_e32 v4, 1, v4                                // 00000006BEAC: 30080881
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000006BEB0: 84808100
	v_lshlrev_b32_e32 v24, 8, v2                               // 00000006BEB4: 30300488
	s_add_u32 s22, s22, s0                                     // 00000006BEB8: 80160016
	s_addc_u32 s1, s23, s1                                     // 00000006BEBC: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 00000006BEC0: 848A811A
	v_mad_u32_u24 v50, 0x44, v2, v52                           // 00000006BEC4: D60B0032 04D204FF 00000044
	s_add_u32 s22, s22, s10                                    // 00000006BED0: 80160A16
	s_addc_u32 s1, s1, s11                                     // 00000006BED4: 82010B01
	s_movk_i32 s10, 0x204                                      // 00000006BED8: B00A0204
	.long 0xd7000b39                                           // 00000006BEDC: D7000B39
	v_cndmask_b32_e32 v1, s34, v52, vcc_lo                     // 00000006BEE0: 02026822
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000006BEE4: BF8704B1
	v_add_co_ci_u32_e64 v58, null, s35, 0, s11                 // 00000006BEE8: D5207C3A 002D0023
	v_mad_u32_u24 v59, v2, s10, 0x3300                         // 00000006BEF0: D60B003B 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 00000006BEFC: 848A8902
	v_dual_mov_b32 v27, s11 :: v_dual_add_nc_u32 v56, 1, v2    // 00000006BF00: CA20000B 1B380481
	v_or_b32_e32 v26, s10, v53                                 // 00000006BF08: 38346A0A
	.long 0xd7000a04                                           // 00000006BF0C: D7000A04
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 00000006BF10: 02020816
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006BF14: BF870191
	v_add_co_ci_u32_e64 v5, null, s1, 0, s10                   // 00000006BF18: D5207C05 00290001
	.long 0xd700011c                                           // 00000006BF20: D700011C
	v_cndmask_b32_e32 v1, 0x30000, v26, vcc_lo                 // 00000006BF24: 020234FF 00030000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006BF2C: BF8700A1
	v_add_co_ci_u32_e64 v29, null, 0, v27, s1                  // 00000006BF30: D5207C1D 00063680
	.long 0xd7000106                                           // 00000006BF38: D7000106
	v_cndmask_b32_e32 v1, s12, v26, vcc_lo                     // 00000006BF3C: 0202340C
	v_add_co_ci_u32_e64 v7, null, s13, v27, s1                 // 00000006BF40: D5207C07 0006360D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BF48: BF870094
	.long 0xd7000108                                           // 00000006BF4C: D7000108
	v_cndmask_b32_e32 v1, s12, v28, vcc_lo                     // 00000006BF50: 0202380C
	v_add_co_ci_u32_e64 v9, null, s13, v29, s1                 // 00000006BF54: D5207C09 00063A0D
	.long 0xd700011e                                           // 00000006BF5C: D700011E
	v_cndmask_b32_e32 v1, 0x60000, v26, vcc_lo                 // 00000006BF60: 020234FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006BF68: BF8700A1
	v_add_co_ci_u32_e64 v31, null, 0, v27, s1                  // 00000006BF6C: D5207C1F 00063680
	.long 0xd7000120                                           // 00000006BF74: D7000120
	v_cndmask_b32_e32 v1, 0x90000, v26, vcc_lo                 // 00000006BF78: 020234FF 00090000
	v_add_co_ci_u32_e64 v33, null, 0, v27, s1                  // 00000006BF80: D5207C21 00063680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BF88: BF870094
	.long 0xd700010a                                           // 00000006BF8C: D700010A
	v_cndmask_b32_e32 v1, s12, v30, vcc_lo                     // 00000006BF90: 02023C0C
	v_add_co_ci_u32_e64 v11, null, s13, v31, s1                // 00000006BF94: D5207C0B 00063E0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BF9C: BF870094
	.long 0xd700010c                                           // 00000006BFA0: D700010C
	v_cndmask_b32_e32 v1, s12, v32, vcc_lo                     // 00000006BFA4: 0202400C
	v_add_co_ci_u32_e64 v13, null, s13, v33, s1                // 00000006BFA8: D5207C0D 0006420D
	.long 0xd7000122                                           // 00000006BFB0: D7000122
	v_cndmask_b32_e32 v1, 0xc0000, v26, vcc_lo                 // 00000006BFB4: 020234FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006BFBC: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v27, s1                  // 00000006BFC0: D5207C23 00063680
	.long 0xd7000124                                           // 00000006BFC8: D7000124
	v_cndmask_b32_e32 v1, 0xf0000, v26, vcc_lo                 // 00000006BFCC: 020234FF 000F0000
	v_add_co_ci_u32_e64 v37, null, 0, v27, s1                  // 00000006BFD4: D5207C25 00063680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BFDC: BF870094
	.long 0xd700010e                                           // 00000006BFE0: D700010E
	v_cndmask_b32_e32 v1, s12, v34, vcc_lo                     // 00000006BFE4: 0202440C
	v_add_co_ci_u32_e64 v15, null, s13, v35, s1                // 00000006BFE8: D5207C0F 0006460D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006BFF0: BF870094
	.long 0xd7000110                                           // 00000006BFF4: D7000110
	v_cndmask_b32_e32 v1, s12, v36, vcc_lo                     // 00000006BFF8: 0202480C
	v_add_co_ci_u32_e64 v17, null, s13, v37, s1                // 00000006BFFC: D5207C11 00064A0D
	.long 0xd7000126                                           // 00000006C004: D7000126
	v_cndmask_b32_e32 v1, 0x120000, v26, vcc_lo                // 00000006C008: 020234FF 00120000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006C010: BF8700A1
	v_add_co_ci_u32_e64 v39, null, 0, v27, s1                  // 00000006C014: D5207C27 00063680
	.long 0xd7000128                                           // 00000006C01C: D7000128
	v_cndmask_b32_e32 v1, 0x150000, v26, vcc_lo                // 00000006C020: 020234FF 00150000
	v_add_co_ci_u32_e64 v41, null, 0, v27, s1                  // 00000006C028: D5207C29 00063680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C030: BF870094
	.long 0xd7000112                                           // 00000006C034: D7000112
	v_cndmask_b32_e32 v1, s12, v38, vcc_lo                     // 00000006C038: 02024C0C
	v_add_co_ci_u32_e64 v19, null, s13, v39, s1                // 00000006C03C: D5207C13 00064E0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C044: BF870094
	.long 0xd7000114                                           // 00000006C048: D7000114
	v_cndmask_b32_e32 v1, s12, v40, vcc_lo                     // 00000006C04C: 0202500C
	v_add_co_ci_u32_e64 v21, null, s13, v41, s1                // 00000006C050: D5207C15 0006520D
	s_lshl_b64 s[10:11], s[2:3], 14                            // 00000006C058: 848A8E02
	.long 0xd7000116                                           // 00000006C05C: D7000116
	v_cndmask_b32_e32 v1, s4, v26, vcc_lo                      // 00000006C060: 02023404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000006C064: BF8700C1
	v_add_co_ci_u32_e64 v23, null, s5, v27, s1                 // 00000006C068: D5207C17 00063605
	s_add_u32 s1, s14, s10                                     // 00000006C070: 80010A0E
	s_addc_u32 s4, s15, s11                                    // 00000006C074: 82040B0F
	.long 0xd7000118                                           // 00000006C078: D7000118
	v_cndmask_b32_e32 v1, s1, v24, vcc_lo                      // 00000006C07C: 02023001
	v_add_co_ci_u32_e64 v25, null, s4, 0, s1                   // 00000006C080: D5207C19 00050004
	.long 0xd700011a                                           // 00000006C088: D700011A
	v_cndmask_b32_e32 v1, s6, v26, vcc_lo                      // 00000006C08C: 02023406
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006C090: BF8700A1
	v_add_co_ci_u32_e64 v27, null, s7, v27, s1                 // 00000006C094: D5207C1B 00063607
	.long 0xd700011c                                           // 00000006C09C: D700011C
	v_cndmask_b32_e32 v1, s6, v28, vcc_lo                      // 00000006C0A0: 02023806
	v_add_co_ci_u32_e64 v29, null, s7, v29, s1                 // 00000006C0A4: D5207C1D 00063A07
	.long 0xd700011e                                           // 00000006C0AC: D700011E
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 00000006C0B0: 02023C06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006C0B4: BF8700A1
	v_add_co_ci_u32_e64 v31, null, s7, v31, s1                 // 00000006C0B8: D5207C1F 00063E07
	.long 0xd7000120                                           // 00000006C0C0: D7000120
	v_cndmask_b32_e32 v1, s6, v32, vcc_lo                      // 00000006C0C4: 02024006
	v_add_co_ci_u32_e64 v33, null, s7, v33, s1                 // 00000006C0C8: D5207C21 00064207
	.long 0xd7000122                                           // 00000006C0D0: D7000122
	v_cndmask_b32_e32 v1, s6, v34, vcc_lo                      // 00000006C0D4: 02024406
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006C0D8: BF8700A1
	v_add_co_ci_u32_e64 v35, null, s7, v35, s1                 // 00000006C0DC: D5207C23 00064607
	.long 0xd7000124                                           // 00000006C0E4: D7000124
	v_cndmask_b32_e32 v1, s6, v36, vcc_lo                      // 00000006C0E8: 02024806
	v_add_co_ci_u32_e64 v37, null, s7, v37, s1                 // 00000006C0EC: D5207C25 00064A07
	.long 0xd7000126                                           // 00000006C0F4: D7000126
	v_cndmask_b32_e32 v1, s6, v38, vcc_lo                      // 00000006C0F8: 02024C06
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006C0FC: BF870001
	v_add_co_ci_u32_e64 v39, null, s7, v39, s1                 // 00000006C100: D5207C27 00064E07
	.long 0xd7000128                                           // 00000006C108: D7000128
	v_cndmask_b32_e32 v1, s6, v40, vcc_lo                      // 00000006C10C: 02025006
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v54, 0x4320, v53 // 00000006C110: CA200080 03366AFF 00004320
	v_add_nc_u32_e32 v55, 0x4420, v53                          // 00000006C11C: 4A6E6AFF 00004420
	.long 0xd44c0000                                           // 00000006C124: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000006C128: 020200FF 00000080
	v_add_nc_u32_e32 v60, 0x2200, v50                          // 00000006C130: 4A7864FF 00002200
	v_or_b32_e32 v61, 0x2200, v1                               // 00000006C138: 387A02FF 00002200
	v_add_co_ci_u32_e64 v41, null, s7, v41, s1                 // 00000006C140: D5207C29 00065207
	s_mov_b32 s5, 0                                            // 00000006C148: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000006C14C: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 00000006C150: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000006C158: BF870499
	s_add_i32 s6, s31, s1                                      // 00000006C15C: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 00000006C160: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006C164: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 00000006C168: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 00000006C16C: 84078605
	s_add_u32 s10, s8, s10                                     // 00000006C170: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 00000006C174: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 00000006C178: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 00000006C180: BE84206A
	s_cbranch_execz 77                                         // 00000006C184: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5bc>
	v_or_b32_e32 v42, s7, v0                                   // 00000006C188: 38540007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C18C: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000006C190: D6FE7C2A 0009612A
	v_ashrrev_i32_e32 v43, 31, v42                             // 00000006C198: 3456549F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C19C: BF870091
	.long 0xd73c002a                                           // 00000006C1A0: D73C002A
	v_cndmask_b32_e32 v1, 2, v42, vcc_lo                       // 00000006C1A4: 02025482
	.long 0xd700012a                                           // 00000006C1A8: D700012A
	v_cndmask_b32_e32 v1, s8, v42, vcc_lo                      // 00000006C1AC: 02025408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000006C1B0: BF8700C1
	v_add_co_ci_u32_e64 v43, null, s9, v43, s1                 // 00000006C1B4: D5207C2B 00065609
	global_load_b32 v42, v[42:43], off                         // 00000006C1BC: DC520000 2A7C002A
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000006C1C4: BF890007
	v_sub_f32_e32 v43, s6, v42                                 // 00000006C1C8: 08565406
	v_dual_mul_f32 v45, 0x3fb8aa3b, v42 :: v_dual_mul_f32 v44, 0x3fb8aa3b, v43// 00000006C1CC: C8C654FF 2D2C56FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000006C1D8: BF8701A1
	v_fma_f32 v48, 0x3fb8aa3b, v42, -v45                       // 00000006C1DC: D6130030 84B654FF 3FB8AA3B
	v_rndne_f32_e32 v49, v45                                   // 00000006C1E8: 7E62472D
	v_fma_f32 v46, 0x3fb8aa3b, v43, -v44                       // 00000006C1EC: D613002E 84B256FF 3FB8AA3B
	v_rndne_f32_e32 v47, v44                                   // 00000006C1F8: 7E5E472C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006C1FC: BF870113
	v_dual_fmac_f32 v48, 0x32a5705f, v42 :: v_dual_sub_f32 v45, v45, v49// 00000006C200: C80A54FF 302C632D 32A5705F
	v_sub_f32_e32 v44, v44, v47                                // 00000006C20C: 08585F2C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006C210: BF870124
	v_fmac_f32_e32 v46, 0x32a5705f, v43                        // 00000006C214: 565C56FF 32A5705F
	.long 0xd41b0001                                           // 00000006C21C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v43, vcc_lo              // 00000006C220: 020256FF C2CE8ED0
	v_dual_add_f32 v45, v45, v48 :: v_dual_add_f32 v44, v44, v46// 00000006C228: C908612D 2D2C5D2C
	v_cvt_i32_f32_e32 v46, v47                                 // 00000006C230: 7E5C112F
	v_cvt_i32_f32_e32 v47, v49                                 // 00000006C234: 7E5E1131
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006C238: BF870193
	v_exp_f32_e32 v45, v45                                     // 00000006C23C: 7E5A4B2D
	v_exp_f32_e32 v44, v44                                     // 00000006C240: 7E584B2C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000006C244: BF870296
	.long 0xd71c002d                                           // 00000006C248: D71C002D
	v_cndmask_b32_e32 v1, v45, v47, vcc_lo                     // 00000006C24C: 02025F2D
	.long 0xd71c002c                                           // 00000006C250: D71C002C
	v_cndmask_b32_e32 v1, v44, v46, vcc_lo                     // 00000006C254: 02025D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006C258: BF8700A1
	v_cndmask_b32_e64 v44, 0, v44, s1                          // 00000006C25C: D501002C 00065880
	.long 0xd41b0001                                           // 00000006C264: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v42, vcc_lo              // 00000006C268: 020254FF C2CE8ED0
	v_cndmask_b32_e64 v45, 0, v45, s1                          // 00000006C270: D501002D 00065A80
	.long 0xd41e0001                                           // 00000006C278: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v43, vcc_lo              // 00000006C27C: 020256FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006C284: BF8700A1
	v_cndmask_b32_e64 v43, 0x7f800000, v44, s1                 // 00000006C288: D501002B 000658FF 7F800000
	.long 0xd41e0001                                           // 00000006C294: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v42, vcc_lo              // 00000006C298: 020254FF 42B17218
	v_cndmask_b32_e64 v42, 0x7f800000, v45, s1                 // 00000006C2A0: D501002A 00065AFF 7F800000
	ds_store_b32 v54, v43                                      // 00000006C2AC: D8340000 00002B36
	ds_store_b32 v55, v42                                      // 00000006C2B4: D8340000 00002A37
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006C2BC: 8C7E047E
	v_dual_mov_b32 v43, v7 :: v_dual_mov_b32 v42, v6           // 00000006C2C0: CA100107 2B2A0106
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 00000006C2C8: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 00000006C2D0: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000006C2D4: BF89FC07
	s_barrier                                                  // 00000006C2D8: BFBD0000
	buffer_gl0_inv                                             // 00000006C2DC: E0AC0000 00000000
	s_nop 0                                                    // 00000006C2E4: BF800000
	s_nop 0                                                    // 00000006C2E8: BF800000
	s_nop 0                                                    // 00000006C2EC: BF800000
	s_nop 0                                                    // 00000006C2F0: BF800000
	s_nop 0                                                    // 00000006C2F4: BF800000
	s_nop 0                                                    // 00000006C2F8: BF800000
	s_nop 0                                                    // 00000006C2FC: BF800000
	global_load_b32 v46, v[42:43], off                         // 00000006C300: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 00000006C308: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 00000006C310: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006C314: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006C31C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006C320: D5207C2B 00065680
	.long 0xd4490004                                           // 00000006C328: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000006C32C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 00000006C334: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 00000006C338: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000006C33C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006C344: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000006C34C: 917E0A7E
	s_cbranch_execnz 65515                                     // 00000006C350: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x600>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000006C354: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 00000006C358: BF89FC07
	s_barrier                                                  // 00000006C35C: BFBD0000
	buffer_gl0_inv                                             // 00000006C360: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000006C368: BE842000
	s_cbranch_execz 140                                        // 00000006C36C: BFA5008C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8a0>
	v_or_b32_e32 v42, s7, v2                                   // 00000006C370: 38540407
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C374: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000006C378: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 00000006C380: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000006C384: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C388: BF870091
	.long 0xd700012a                                           // 00000006C38C: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 00000006C390: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 00000006C394: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 00000006C39C: BE810080
	global_load_b32 v42, v[42:43], off                         // 00000006C3A0: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 00000006C3A8: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 00000006C3B4: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 00000006C3BC: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 00000006C3C0: B6810070
	s_mov_b32 s1, s10                                          // 00000006C3C4: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 00000006C3C8: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 00000006C3D0: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 00000006C3D8: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 00000006C3E0: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 00000006C3E8: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 00000006C3F0: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 00000006C3F8: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 00000006C3FC: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 00000006C400: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 00000006C404: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006C40C: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 00000006C410: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 00000006C414: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000006C418: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006C420: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 00000006C424: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000006C428: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 00000006C42C: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 00000006C434: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000006C438: 7E56152C
	s_waitcnt vmcnt(0)                                         // 00000006C43C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000006C440: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 00000006C444: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 00000006C44C: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 00000006C450: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 00000006C454: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 00000006C45C: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 00000006C464: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000006C468: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 00000006C46C: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 00000006C470: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 00000006C474: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000006C478: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 00000006C480: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000006C488: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 00000006C490: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 00000006C494: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000006C498: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 00000006C4A0: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 00000006C4A8: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 00000006C4AC: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 00000006C4B4: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 00000006C4BC: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 00000006C4C4: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 00000006C4CC: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 00000006C4D4: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 00000006C4D8: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 00000006C4DC: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006C4E0: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006C4E4: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 00000006C4EC: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 00000006C4F0: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 00000006C4F4: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006C4F8: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 00000006C500: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 00000006C504: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006C508: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006C50C: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 00000006C514: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000006C518: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 00000006C51C: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006C520: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000006C528: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 00000006C52C: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006C530: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006C534: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 00000006C53C: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 00000006C540: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 00000006C544: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006C548: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 00000006C550: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 00000006C554: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006C558: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006C55C: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 00000006C564: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000006C568: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 00000006C56C: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006C570: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000006C578: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 00000006C57C: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C580: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006C584: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006C58C: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 00000006C594: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6a8>
	ds_store_b32 v60, v42                                      // 00000006C598: D8340000 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006C5A0: 8C7E047E
	v_dual_mov_b32 v43, v9 :: v_dual_mov_b32 v42, v8           // 00000006C5A4: CA100109 2B2A0108
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 00000006C5AC: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 00000006C5B4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000006C5B8: BF89FC07
	s_barrier                                                  // 00000006C5BC: BFBD0000
	buffer_gl0_inv                                             // 00000006C5C0: E0AC0000 00000000
	s_nop 0                                                    // 00000006C5C8: BF800000
	s_nop 0                                                    // 00000006C5CC: BF800000
	s_nop 0                                                    // 00000006C5D0: BF800000
	s_nop 0                                                    // 00000006C5D4: BF800000
	s_nop 0                                                    // 00000006C5D8: BF800000
	s_nop 0                                                    // 00000006C5DC: BF800000
	s_nop 0                                                    // 00000006C5E0: BF800000
	s_nop 0                                                    // 00000006C5E4: BF800000
	s_nop 0                                                    // 00000006C5E8: BF800000
	s_nop 0                                                    // 00000006C5EC: BF800000
	s_nop 0                                                    // 00000006C5F0: BF800000
	s_nop 0                                                    // 00000006C5F4: BF800000
	s_nop 0                                                    // 00000006C5F8: BF800000
	s_nop 0                                                    // 00000006C5FC: BF800000
	global_load_b32 v46, v[42:43], off                         // 00000006C600: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 00000006C608: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 00000006C610: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006C614: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006C61C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006C620: D5207C2B 00065680
	.long 0xd4490004                                           // 00000006C628: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000006C62C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 00000006C634: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 00000006C638: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000006C63C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006C644: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000006C64C: 917E0A7E
	s_cbranch_execnz 65515                                     // 00000006C650: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x900>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000006C654: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 00000006C658: BF89FC07
	s_barrier                                                  // 00000006C65C: BFBD0000
	buffer_gl0_inv                                             // 00000006C660: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000006C668: BE842000
	s_cbranch_execz 141                                        // 00000006C66C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xba4>
	v_add3_u32 v42, v2, s7, 8                                  // 00000006C670: D655002A 02200F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C678: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000006C67C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 00000006C684: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000006C688: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C68C: BF870091
	.long 0xd700012a                                           // 00000006C690: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 00000006C694: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 00000006C698: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 00000006C6A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 00000006C6A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 00000006C6AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 00000006C6B8: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 00000006C6C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 00000006C6C4: B6810070
	s_mov_b32 s1, s10                                          // 00000006C6C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 00000006C6CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 00000006C6D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 00000006C6DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 00000006C6E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 00000006C6EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 00000006C6F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 00000006C6FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 00000006C700: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 00000006C704: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 00000006C708: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006C710: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 00000006C714: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 00000006C718: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000006C71C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006C724: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 00000006C728: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000006C72C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 00000006C730: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 00000006C738: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000006C73C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 00000006C740: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000006C744: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 00000006C748: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 00000006C750: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 00000006C754: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 00000006C758: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 00000006C760: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 00000006C768: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000006C76C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 00000006C770: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 00000006C774: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 00000006C778: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000006C77C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 00000006C784: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000006C78C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 00000006C794: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 00000006C798: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000006C79C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 00000006C7A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 00000006C7AC: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 00000006C7B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 00000006C7B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 00000006C7C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 00000006C7C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 00000006C7D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 00000006C7D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 00000006C7DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 00000006C7E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006C7E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006C7E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 00000006C7F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 00000006C7F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 00000006C7F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006C7FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 00000006C804: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 00000006C808: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006C80C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006C810: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 00000006C818: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000006C81C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 00000006C820: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006C824: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000006C82C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 00000006C830: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006C834: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006C838: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 00000006C840: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 00000006C844: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 00000006C848: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006C84C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 00000006C854: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 00000006C858: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006C85C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006C860: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 00000006C868: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000006C86C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 00000006C870: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006C874: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000006C87C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 00000006C880: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C884: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006C888: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006C890: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 00000006C898: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x9ac>
	ds_store_b32 v60, v42 offset:544                           // 00000006C89C: D8340220 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006C8A4: 8C7E047E
	v_dual_mov_b32 v43, v11 :: v_dual_mov_b32 v42, v10         // 00000006C8A8: CA10010B 2B2A010A
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 00000006C8B0: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 00000006C8B8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000006C8BC: BF89FC07
	s_barrier                                                  // 00000006C8C0: BFBD0000
	buffer_gl0_inv                                             // 00000006C8C4: E0AC0000 00000000
	s_nop 0                                                    // 00000006C8CC: BF800000
	s_nop 0                                                    // 00000006C8D0: BF800000
	s_nop 0                                                    // 00000006C8D4: BF800000
	s_nop 0                                                    // 00000006C8D8: BF800000
	s_nop 0                                                    // 00000006C8DC: BF800000
	s_nop 0                                                    // 00000006C8E0: BF800000
	s_nop 0                                                    // 00000006C8E4: BF800000
	s_nop 0                                                    // 00000006C8E8: BF800000
	s_nop 0                                                    // 00000006C8EC: BF800000
	s_nop 0                                                    // 00000006C8F0: BF800000
	s_nop 0                                                    // 00000006C8F4: BF800000
	s_nop 0                                                    // 00000006C8F8: BF800000
	s_nop 0                                                    // 00000006C8FC: BF800000
	global_load_b32 v46, v[42:43], off                         // 00000006C900: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 00000006C908: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 00000006C910: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006C914: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006C91C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006C920: D5207C2B 00065680
	.long 0xd4490004                                           // 00000006C928: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000006C92C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 00000006C934: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 00000006C938: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000006C93C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006C944: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000006C94C: 917E0A7E
	s_cbranch_execnz 65515                                     // 00000006C950: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc00>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000006C954: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 00000006C958: BF89FC07
	s_barrier                                                  // 00000006C95C: BFBD0000
	buffer_gl0_inv                                             // 00000006C960: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000006C968: BE842000
	s_cbranch_execz 141                                        // 00000006C96C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xea4>
	v_add3_u32 v42, v2, s7, 16                                 // 00000006C970: D655002A 02400F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C978: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000006C97C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 00000006C984: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000006C988: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006C98C: BF870091
	.long 0xd700012a                                           // 00000006C990: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 00000006C994: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 00000006C998: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 00000006C9A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 00000006C9A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 00000006C9AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 00000006C9B8: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 00000006C9C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 00000006C9C4: B6810070
	s_mov_b32 s1, s10                                          // 00000006C9C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 00000006C9CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 00000006C9D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 00000006C9DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 00000006C9E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 00000006C9EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 00000006C9F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 00000006C9FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 00000006CA00: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 00000006CA04: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 00000006CA08: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006CA10: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 00000006CA14: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 00000006CA18: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000006CA1C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006CA24: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 00000006CA28: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000006CA2C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 00000006CA30: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 00000006CA38: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000006CA3C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 00000006CA40: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000006CA44: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 00000006CA48: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 00000006CA50: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 00000006CA54: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 00000006CA58: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 00000006CA60: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 00000006CA68: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000006CA6C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 00000006CA70: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 00000006CA74: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 00000006CA78: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000006CA7C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 00000006CA84: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000006CA8C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 00000006CA94: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 00000006CA98: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000006CA9C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 00000006CAA4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 00000006CAAC: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 00000006CAB0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 00000006CAB8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 00000006CAC0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 00000006CAC8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 00000006CAD0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 00000006CAD8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 00000006CADC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 00000006CAE0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006CAE4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006CAE8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 00000006CAF0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 00000006CAF4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 00000006CAF8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006CAFC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 00000006CB04: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 00000006CB08: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006CB0C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006CB10: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 00000006CB18: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000006CB1C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 00000006CB20: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006CB24: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000006CB2C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 00000006CB30: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006CB34: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006CB38: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 00000006CB40: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 00000006CB44: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 00000006CB48: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006CB4C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 00000006CB54: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 00000006CB58: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006CB5C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006CB60: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 00000006CB68: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000006CB6C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 00000006CB70: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006CB74: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000006CB7C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 00000006CB80: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CB84: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006CB88: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006CB90: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 00000006CB98: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xcac>
	ds_store_b32 v60, v42 offset:1088                          // 00000006CB9C: D8340440 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006CBA4: 8C7E047E
	v_dual_mov_b32 v43, v13 :: v_dual_mov_b32 v42, v12         // 00000006CBA8: CA10010D 2B2A010C
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 00000006CBB0: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 00000006CBB8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000006CBBC: BF89FC07
	s_barrier                                                  // 00000006CBC0: BFBD0000
	buffer_gl0_inv                                             // 00000006CBC4: E0AC0000 00000000
	s_nop 0                                                    // 00000006CBCC: BF800000
	s_nop 0                                                    // 00000006CBD0: BF800000
	s_nop 0                                                    // 00000006CBD4: BF800000
	s_nop 0                                                    // 00000006CBD8: BF800000
	s_nop 0                                                    // 00000006CBDC: BF800000
	s_nop 0                                                    // 00000006CBE0: BF800000
	s_nop 0                                                    // 00000006CBE4: BF800000
	s_nop 0                                                    // 00000006CBE8: BF800000
	s_nop 0                                                    // 00000006CBEC: BF800000
	s_nop 0                                                    // 00000006CBF0: BF800000
	s_nop 0                                                    // 00000006CBF4: BF800000
	s_nop 0                                                    // 00000006CBF8: BF800000
	s_nop 0                                                    // 00000006CBFC: BF800000
	global_load_b32 v46, v[42:43], off                         // 00000006CC00: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 00000006CC08: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 00000006CC10: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006CC14: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006CC1C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006CC20: D5207C2B 00065680
	.long 0xd4490004                                           // 00000006CC28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000006CC2C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 00000006CC34: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 00000006CC38: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000006CC3C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006CC44: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000006CC4C: 917E0A7E
	s_cbranch_execnz 65515                                     // 00000006CC50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xf00>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000006CC54: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 00000006CC58: BF89FC07
	s_barrier                                                  // 00000006CC5C: BFBD0000
	buffer_gl0_inv                                             // 00000006CC60: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000006CC68: BE842000
	s_cbranch_execz 141                                        // 00000006CC6C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11a4>
	v_add3_u32 v42, v2, s7, 24                                 // 00000006CC70: D655002A 02600F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CC78: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000006CC7C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 00000006CC84: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000006CC88: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CC8C: BF870091
	.long 0xd700012a                                           // 00000006CC90: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 00000006CC94: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 00000006CC98: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 00000006CCA0: BE810080
	global_load_b32 v42, v[42:43], off                         // 00000006CCA4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 00000006CCAC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 00000006CCB8: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 00000006CCC0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 00000006CCC4: B6810070
	s_mov_b32 s1, s10                                          // 00000006CCC8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 00000006CCCC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 00000006CCD4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 00000006CCDC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 00000006CCE4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 00000006CCEC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 00000006CCF4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 00000006CCFC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 00000006CD00: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 00000006CD04: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 00000006CD08: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006CD10: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 00000006CD14: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 00000006CD18: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000006CD1C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006CD24: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 00000006CD28: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000006CD2C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 00000006CD30: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 00000006CD38: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000006CD3C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 00000006CD40: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000006CD44: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 00000006CD48: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 00000006CD50: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 00000006CD54: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 00000006CD58: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 00000006CD60: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 00000006CD68: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000006CD6C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 00000006CD70: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 00000006CD74: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 00000006CD78: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000006CD7C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 00000006CD84: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000006CD8C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 00000006CD94: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 00000006CD98: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000006CD9C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 00000006CDA4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 00000006CDAC: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 00000006CDB0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 00000006CDB8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 00000006CDC0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 00000006CDC8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 00000006CDD0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 00000006CDD8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 00000006CDDC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 00000006CDE0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006CDE4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006CDE8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 00000006CDF0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 00000006CDF4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 00000006CDF8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006CDFC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 00000006CE04: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 00000006CE08: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006CE0C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006CE10: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 00000006CE18: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000006CE1C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 00000006CE20: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006CE24: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000006CE2C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 00000006CE30: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006CE34: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006CE38: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 00000006CE40: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 00000006CE44: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 00000006CE48: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006CE4C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 00000006CE54: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 00000006CE58: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006CE5C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006CE60: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 00000006CE68: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000006CE6C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 00000006CE70: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006CE74: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000006CE7C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 00000006CE80: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CE84: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006CE88: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006CE90: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 00000006CE98: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfac>
	ds_store_b32 v60, v42 offset:1632                          // 00000006CE9C: D8340660 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006CEA4: 8C7E047E
	v_dual_mov_b32 v43, v15 :: v_dual_mov_b32 v42, v14         // 00000006CEA8: CA10010F 2B2A010E
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 00000006CEB0: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 00000006CEB8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000006CEBC: BF89FC07
	s_barrier                                                  // 00000006CEC0: BFBD0000
	buffer_gl0_inv                                             // 00000006CEC4: E0AC0000 00000000
	s_nop 0                                                    // 00000006CECC: BF800000
	s_nop 0                                                    // 00000006CED0: BF800000
	s_nop 0                                                    // 00000006CED4: BF800000
	s_nop 0                                                    // 00000006CED8: BF800000
	s_nop 0                                                    // 00000006CEDC: BF800000
	s_nop 0                                                    // 00000006CEE0: BF800000
	s_nop 0                                                    // 00000006CEE4: BF800000
	s_nop 0                                                    // 00000006CEE8: BF800000
	s_nop 0                                                    // 00000006CEEC: BF800000
	s_nop 0                                                    // 00000006CEF0: BF800000
	s_nop 0                                                    // 00000006CEF4: BF800000
	s_nop 0                                                    // 00000006CEF8: BF800000
	s_nop 0                                                    // 00000006CEFC: BF800000
	global_load_b32 v46, v[42:43], off                         // 00000006CF00: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 00000006CF08: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 00000006CF10: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006CF14: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006CF1C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006CF20: D5207C2B 00065680
	.long 0xd4490004                                           // 00000006CF28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000006CF2C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 00000006CF34: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 00000006CF38: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000006CF3C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006CF44: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000006CF4C: 917E0A7E
	s_cbranch_execnz 65515                                     // 00000006CF50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1200>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000006CF54: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 00000006CF58: BF89FC07
	s_barrier                                                  // 00000006CF5C: BFBD0000
	buffer_gl0_inv                                             // 00000006CF60: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000006CF68: BE842000
	s_cbranch_execz 141                                        // 00000006CF6C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14a4>
	v_add3_u32 v42, v2, s7, 32                                 // 00000006CF70: D655002A 02800F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CF78: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000006CF7C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 00000006CF84: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000006CF88: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006CF8C: BF870091
	.long 0xd700012a                                           // 00000006CF90: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 00000006CF94: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 00000006CF98: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 00000006CFA0: BE810080
	global_load_b32 v42, v[42:43], off                         // 00000006CFA4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 00000006CFAC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 00000006CFB8: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 00000006CFC0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 00000006CFC4: B6810070
	s_mov_b32 s1, s10                                          // 00000006CFC8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 00000006CFCC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 00000006CFD4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 00000006CFDC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 00000006CFE4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 00000006CFEC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 00000006CFF4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 00000006CFFC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 00000006D000: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 00000006D004: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 00000006D008: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006D010: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 00000006D014: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 00000006D018: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000006D01C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006D024: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 00000006D028: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000006D02C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 00000006D030: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 00000006D038: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000006D03C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 00000006D040: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000006D044: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 00000006D048: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 00000006D050: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 00000006D054: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 00000006D058: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 00000006D060: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 00000006D068: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000006D06C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 00000006D070: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 00000006D074: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 00000006D078: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000006D07C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 00000006D084: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000006D08C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 00000006D094: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 00000006D098: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000006D09C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 00000006D0A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 00000006D0AC: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 00000006D0B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 00000006D0B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 00000006D0C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 00000006D0C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 00000006D0D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 00000006D0D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 00000006D0DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 00000006D0E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006D0E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D0E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 00000006D0F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 00000006D0F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 00000006D0F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D0FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 00000006D104: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 00000006D108: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006D10C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D110: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 00000006D118: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000006D11C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 00000006D120: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D124: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000006D12C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 00000006D130: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006D134: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D138: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 00000006D140: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 00000006D144: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 00000006D148: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D14C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 00000006D154: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 00000006D158: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006D15C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D160: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 00000006D168: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000006D16C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 00000006D170: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D174: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000006D17C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 00000006D180: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D184: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D188: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D190: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 00000006D198: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x12ac>
	ds_store_b32 v60, v42 offset:2176                          // 00000006D19C: D8340880 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006D1A4: 8C7E047E
	v_dual_mov_b32 v43, v17 :: v_dual_mov_b32 v42, v16         // 00000006D1A8: CA100111 2B2A0110
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 00000006D1B0: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 00000006D1B8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000006D1BC: BF89FC07
	s_barrier                                                  // 00000006D1C0: BFBD0000
	buffer_gl0_inv                                             // 00000006D1C4: E0AC0000 00000000
	s_nop 0                                                    // 00000006D1CC: BF800000
	s_nop 0                                                    // 00000006D1D0: BF800000
	s_nop 0                                                    // 00000006D1D4: BF800000
	s_nop 0                                                    // 00000006D1D8: BF800000
	s_nop 0                                                    // 00000006D1DC: BF800000
	s_nop 0                                                    // 00000006D1E0: BF800000
	s_nop 0                                                    // 00000006D1E4: BF800000
	s_nop 0                                                    // 00000006D1E8: BF800000
	s_nop 0                                                    // 00000006D1EC: BF800000
	s_nop 0                                                    // 00000006D1F0: BF800000
	s_nop 0                                                    // 00000006D1F4: BF800000
	s_nop 0                                                    // 00000006D1F8: BF800000
	s_nop 0                                                    // 00000006D1FC: BF800000
	global_load_b32 v46, v[42:43], off                         // 00000006D200: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 00000006D208: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 00000006D210: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006D214: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006D21C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006D220: D5207C2B 00065680
	.long 0xd4490004                                           // 00000006D228: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000006D22C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 00000006D234: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 00000006D238: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000006D23C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006D244: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000006D24C: 917E0A7E
	s_cbranch_execnz 65515                                     // 00000006D250: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1500>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000006D254: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 00000006D258: BF89FC07
	s_barrier                                                  // 00000006D25C: BFBD0000
	buffer_gl0_inv                                             // 00000006D260: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000006D268: BE842000
	s_cbranch_execz 141                                        // 00000006D26C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17a4>
	v_add3_u32 v42, v2, s7, 40                                 // 00000006D270: D655002A 02A00F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D278: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000006D27C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 00000006D284: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000006D288: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D28C: BF870091
	.long 0xd700012a                                           // 00000006D290: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 00000006D294: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 00000006D298: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 00000006D2A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 00000006D2A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 00000006D2AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 00000006D2B8: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 00000006D2C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 00000006D2C4: B6810070
	s_mov_b32 s1, s10                                          // 00000006D2C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 00000006D2CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 00000006D2D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 00000006D2DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 00000006D2E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 00000006D2EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 00000006D2F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 00000006D2FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 00000006D300: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 00000006D304: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 00000006D308: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006D310: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 00000006D314: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 00000006D318: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000006D31C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006D324: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 00000006D328: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000006D32C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 00000006D330: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 00000006D338: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000006D33C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 00000006D340: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000006D344: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 00000006D348: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 00000006D350: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 00000006D354: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 00000006D358: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 00000006D360: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 00000006D368: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000006D36C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 00000006D370: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 00000006D374: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 00000006D378: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000006D37C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 00000006D384: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000006D38C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 00000006D394: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 00000006D398: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000006D39C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 00000006D3A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 00000006D3AC: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 00000006D3B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 00000006D3B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 00000006D3C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 00000006D3C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 00000006D3D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 00000006D3D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 00000006D3DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 00000006D3E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006D3E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D3E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 00000006D3F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 00000006D3F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 00000006D3F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D3FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 00000006D404: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 00000006D408: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006D40C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D410: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 00000006D418: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000006D41C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 00000006D420: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D424: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000006D42C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 00000006D430: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006D434: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D438: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 00000006D440: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 00000006D444: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 00000006D448: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D44C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 00000006D454: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 00000006D458: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006D45C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D460: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 00000006D468: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000006D46C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 00000006D470: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D474: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000006D47C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 00000006D480: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D484: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D488: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D490: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 00000006D498: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15ac>
	ds_store_b32 v60, v42 offset:2720                          // 00000006D49C: D8340AA0 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006D4A4: 8C7E047E
	v_dual_mov_b32 v43, v19 :: v_dual_mov_b32 v42, v18         // 00000006D4A8: CA100113 2B2A0112
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 00000006D4B0: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 00000006D4B8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000006D4BC: BF89FC07
	s_barrier                                                  // 00000006D4C0: BFBD0000
	buffer_gl0_inv                                             // 00000006D4C4: E0AC0000 00000000
	s_nop 0                                                    // 00000006D4CC: BF800000
	s_nop 0                                                    // 00000006D4D0: BF800000
	s_nop 0                                                    // 00000006D4D4: BF800000
	s_nop 0                                                    // 00000006D4D8: BF800000
	s_nop 0                                                    // 00000006D4DC: BF800000
	s_nop 0                                                    // 00000006D4E0: BF800000
	s_nop 0                                                    // 00000006D4E4: BF800000
	s_nop 0                                                    // 00000006D4E8: BF800000
	s_nop 0                                                    // 00000006D4EC: BF800000
	s_nop 0                                                    // 00000006D4F0: BF800000
	s_nop 0                                                    // 00000006D4F4: BF800000
	s_nop 0                                                    // 00000006D4F8: BF800000
	s_nop 0                                                    // 00000006D4FC: BF800000
	global_load_b32 v46, v[42:43], off                         // 00000006D500: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 00000006D508: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 00000006D510: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006D514: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006D51C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006D520: D5207C2B 00065680
	.long 0xd4490004                                           // 00000006D528: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000006D52C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 00000006D534: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 00000006D538: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000006D53C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006D544: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000006D54C: 917E0A7E
	s_cbranch_execnz 65515                                     // 00000006D550: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1800>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000006D554: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 00000006D558: BF89FC07
	s_barrier                                                  // 00000006D55C: BFBD0000
	buffer_gl0_inv                                             // 00000006D560: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000006D568: BE842000
	s_cbranch_execz 141                                        // 00000006D56C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1aa4>
	v_add3_u32 v42, v2, s7, 48                                 // 00000006D570: D655002A 02C00F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D578: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000006D57C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 00000006D584: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000006D588: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D58C: BF870091
	.long 0xd700012a                                           // 00000006D590: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 00000006D594: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 00000006D598: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 00000006D5A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 00000006D5A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 00000006D5AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 00000006D5B8: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 00000006D5C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 00000006D5C4: B6810070
	s_mov_b32 s1, s10                                          // 00000006D5C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 00000006D5CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 00000006D5D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 00000006D5DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 00000006D5E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 00000006D5EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 00000006D5F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 00000006D5FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 00000006D600: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 00000006D604: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 00000006D608: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006D610: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 00000006D614: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 00000006D618: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000006D61C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006D624: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 00000006D628: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000006D62C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 00000006D630: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 00000006D638: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000006D63C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 00000006D640: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000006D644: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 00000006D648: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 00000006D650: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 00000006D654: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 00000006D658: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 00000006D660: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 00000006D668: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000006D66C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 00000006D670: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 00000006D674: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 00000006D678: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000006D67C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 00000006D684: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000006D68C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 00000006D694: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 00000006D698: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000006D69C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 00000006D6A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 00000006D6AC: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 00000006D6B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 00000006D6B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 00000006D6C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 00000006D6C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 00000006D6D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 00000006D6D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 00000006D6DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 00000006D6E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006D6E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D6E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 00000006D6F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 00000006D6F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 00000006D6F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D6FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 00000006D704: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 00000006D708: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006D70C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D710: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 00000006D718: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000006D71C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 00000006D720: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D724: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000006D72C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 00000006D730: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006D734: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D738: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 00000006D740: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 00000006D744: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 00000006D748: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D74C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 00000006D754: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 00000006D758: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006D75C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D760: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 00000006D768: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000006D76C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 00000006D770: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D774: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000006D77C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 00000006D780: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D784: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D788: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D790: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 00000006D798: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18ac>
	ds_store_b32 v60, v42 offset:3264                          // 00000006D79C: D8340CC0 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006D7A4: 8C7E047E
	v_dual_mov_b32 v43, v21 :: v_dual_mov_b32 v42, v20         // 00000006D7A8: CA100115 2B2A0114
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 00000006D7B0: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 00000006D7B8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000006D7BC: BF89FC07
	s_barrier                                                  // 00000006D7C0: BFBD0000
	buffer_gl0_inv                                             // 00000006D7C4: E0AC0000 00000000
	s_nop 0                                                    // 00000006D7CC: BF800000
	s_nop 0                                                    // 00000006D7D0: BF800000
	s_nop 0                                                    // 00000006D7D4: BF800000
	s_nop 0                                                    // 00000006D7D8: BF800000
	s_nop 0                                                    // 00000006D7DC: BF800000
	s_nop 0                                                    // 00000006D7E0: BF800000
	s_nop 0                                                    // 00000006D7E4: BF800000
	s_nop 0                                                    // 00000006D7E8: BF800000
	s_nop 0                                                    // 00000006D7EC: BF800000
	s_nop 0                                                    // 00000006D7F0: BF800000
	s_nop 0                                                    // 00000006D7F4: BF800000
	s_nop 0                                                    // 00000006D7F8: BF800000
	s_nop 0                                                    // 00000006D7FC: BF800000
	global_load_b32 v46, v[42:43], off                         // 00000006D800: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 00000006D808: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 00000006D810: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006D814: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006D81C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006D820: D5207C2B 00065680
	.long 0xd4490004                                           // 00000006D828: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000006D82C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 00000006D834: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 00000006D838: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000006D83C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006D844: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000006D84C: 917E0A7E
	s_cbranch_execnz 65515                                     // 00000006D850: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000006D854: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 00000006D858: BF89FC07
	s_barrier                                                  // 00000006D85C: BFBD0000
	buffer_gl0_inv                                             // 00000006D860: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000006D868: BE842000
	s_cbranch_execz 141                                        // 00000006D86C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1da4>
	v_add3_u32 v42, v2, s7, 56                                 // 00000006D870: D655002A 02E00F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D878: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000006D87C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 00000006D884: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 00000006D888: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006D88C: BF870091
	.long 0xd700012a                                           // 00000006D890: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 00000006D894: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 00000006D898: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 00000006D8A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 00000006D8A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 00000006D8AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 00000006D8B8: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 00000006D8C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 00000006D8C4: B6810070
	s_mov_b32 s1, s10                                          // 00000006D8C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 00000006D8CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 00000006D8D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 00000006D8DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 00000006D8E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 00000006D8EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 00000006D8F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 00000006D8FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 00000006D900: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 00000006D904: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 00000006D908: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006D910: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 00000006D914: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 00000006D918: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000006D91C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 00000006D924: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 00000006D928: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000006D92C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 00000006D930: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 00000006D938: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000006D93C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 00000006D940: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000006D944: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 00000006D948: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 00000006D950: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 00000006D954: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 00000006D958: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 00000006D960: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 00000006D968: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000006D96C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 00000006D970: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 00000006D974: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 00000006D978: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000006D97C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 00000006D984: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000006D98C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 00000006D994: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 00000006D998: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000006D99C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 00000006D9A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 00000006D9AC: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 00000006D9B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 00000006D9B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 00000006D9C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 00000006D9C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 00000006D9D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 00000006D9D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 00000006D9DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 00000006D9E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006D9E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006D9E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 00000006D9F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 00000006D9F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 00000006D9F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006D9FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 00000006DA04: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 00000006DA08: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006DA0C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006DA10: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 00000006DA18: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000006DA1C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 00000006DA20: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006DA24: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000006DA2C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 00000006DA30: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006DA34: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006DA38: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 00000006DA40: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 00000006DA44: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 00000006DA48: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006DA4C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 00000006DA54: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 00000006DA58: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000006DA5C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006DA60: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 00000006DA68: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000006DA6C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 00000006DA70: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006DA74: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000006DA7C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 00000006DA80: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DA84: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 00000006DA88: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000006DA90: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 00000006DA98: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1bac>
	ds_store_b32 v60, v42 offset:3808                          // 00000006DA9C: D8340EE0 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006DAA4: 8C7E047E
	v_mov_b32_e32 v43, v25                                     // 00000006DAA8: 7E560319
	v_dual_mov_b32 v45, v23 :: v_dual_mov_b32 v42, v24         // 00000006DAAC: CA100117 2D2A0118
	v_mov_b32_e32 v44, v22                                     // 00000006DAB4: 7E580316
	v_mov_b32_e32 v48, v56                                     // 00000006DAB8: 7E600338
	s_waitcnt lgkmcnt(0)                                       // 00000006DABC: BF89FC07
	s_barrier                                                  // 00000006DAC0: BFBD0000
	s_mov_b32 s10, 0                                           // 00000006DAC4: BE8A0080
	buffer_gl0_inv                                             // 00000006DAC8: E0AC0000 00000000
	s_branch 21                                                // 00000006DAD0: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e28>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000006DAD4: 8C7E0B7E
	.long 0xd700012c                                           // 00000006DAD8: D700012C
	v_cndmask_b32_e32 v1, 0x30000, v44, vcc_lo                 // 00000006DADC: 020258FF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006DAE4: BF870001
	v_add_co_ci_u32_e64 v45, null, 0, v45, s1                  // 00000006DAE8: D5207C2D 00065A80
	.long 0xd700012a                                           // 00000006DAF0: D700012A
	v_cndmask_b32_e32 v1, 0x800, v42, vcc_lo                   // 00000006DAF4: 020254FF 00000800
	v_add_nc_u32_e32 v48, 8, v48                               // 00000006DAFC: 4A606088
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006DB00: D5207C2B 00065680
	s_add_i32 s1, s10, 8                                       // 00000006DB08: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000006DB0C: BF08B70A
	s_mov_b32 s10, s1                                          // 00000006DB10: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 00000006DB14: BC7C0000
	s_barrier                                                  // 00000006DB18: BFBD0000
	buffer_gl0_inv                                             // 00000006DB1C: E0AC0000 00000000
	s_cbranch_scc1 614                                         // 00000006DB24: BFA20266 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27c0>
	v_dual_mov_b32 v47, v45 :: v_dual_mov_b32 v46, v44         // 00000006DB28: CA10012D 2F2E012C
	v_dual_mov_b32 v49, v53 :: v_dual_mov_b32 v62, v51         // 00000006DB30: CA100135 313E0133
	s_mov_b32 s11, 0                                           // 00000006DB38: BE8B0080
	s_nop 0                                                    // 00000006DB3C: BF800000
	global_load_b32 v63, v[46:47], off                         // 00000006DB40: DC520000 3F7C002E
	v_add_nc_u32_e32 v62, 0x80, v62                            // 00000006DB48: 4A7C7CFF 00000080
	.long 0xd700012e                                           // 00000006DB50: D700012E
	v_cndmask_b32_e32 v1, 0x6000, v46, vcc_lo                  // 00000006DB54: 02025CFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006DB5C: BF870191
	v_add_co_ci_u32_e64 v47, null, 0, v47, s1                  // 00000006DB60: D5207C2F 00065E80
	.long 0xd4490004                                           // 00000006DB68: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v62, vcc_lo                   // 00000006DB6C: 02027CFF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000006DB74: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000006DB78: BF8903F7
	ds_store_b32 v49, v63 offset:13056                         // 00000006DB7C: D8343300 00003F31
	v_add_nc_u32_e32 v49, 0x204, v49                           // 00000006DB84: 4A6262FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000006DB8C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000006DB90: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e40>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000006DB94: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000006DB98: BF89FC07
	s_barrier                                                  // 00000006DB9C: BFBD0000
	buffer_gl0_inv                                             // 00000006DBA0: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 00000006DBA8: BE8B2000
	s_cbranch_execz 65481                                      // 00000006DBAC: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dd4>
	v_or_b32_e32 v46, s10, v2                                  // 00000006DBB0: 385C040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DBB4: BF870091
	v_or_b32_e32 v49, s7, v46                                  // 00000006DBB8: 38625C07
	.long 0xd4440001                                           // 00000006DBBC: D4440001
	v_cndmask_b32_e32 v1, s30, v49, vcc_lo                     // 00000006DBC0: 0202621E
	s_and_b32 exec_lo, exec_lo, s1                             // 00000006DBC4: 8B7E017E
	s_cbranch_execz 65474                                      // 00000006DBC8: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dd4>
	ds_load_2addr_b32 v[62:63], v59 offset1:1                  // 00000006DBCC: D8DC0100 3E00003B
	ds_load_2addr_b32 v[64:65], v1 offset1:17                  // 00000006DBD4: D8DC1100 40000001
	ds_load_2addr_b32 v[66:67], v59 offset0:2 offset1:3        // 00000006DBDC: D8DC0302 4200003B
	ds_load_2addr_b32 v[68:69], v1 offset0:34 offset1:51       // 00000006DBE4: D8DC3322 44000001
	ds_load_2addr_b32 v[70:71], v59 offset0:4 offset1:5        // 00000006DBEC: D8DC0504 4600003B
	ds_load_2addr_b32 v[72:73], v59 offset0:6 offset1:7        // 00000006DBF4: D8DC0706 4800003B
	ds_load_2addr_b32 v[74:75], v1 offset0:68 offset1:85       // 00000006DBFC: D8DC5544 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:102 offset1:119     // 00000006DC04: D8DC7766 4C000001
	ds_load_2addr_b32 v[79:80], v59 offset0:28 offset1:29      // 00000006DC0C: D8DC1D1C 4F00003B
	ds_load_2addr_b32 v[81:82], v59 offset0:30 offset1:31      // 00000006DC14: D8DC1F1E 5100003B
	v_lshlrev_b32_e32 v46, 2, v46                              // 00000006DC1C: 305C5C82
	s_mov_b32 s12, 0                                           // 00000006DC20: BE8C0080
	s_waitcnt lgkmcnt(8)                                       // 00000006DC24: BF89FC87
	v_fma_f32 v62, v62, v64, 0                                 // 00000006DC28: D613003E 0202813E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DC30: BF8700A1
	v_fmac_f32_e32 v62, v63, v65                               // 00000006DC34: 567C833F
	s_waitcnt lgkmcnt(6)                                       // 00000006DC38: BF89FC67
	v_fmac_f32_e32 v62, v66, v68                               // 00000006DC3C: 567C8942
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DC40: BF8700A1
	v_fmac_f32_e32 v62, v67, v69                               // 00000006DC44: 567C8B43
	s_waitcnt lgkmcnt(3)                                       // 00000006DC48: BF89FC37
	v_fmac_f32_e32 v62, v70, v74                               // 00000006DC4C: 567C9546
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DC50: BF8700A1
	v_fmac_f32_e32 v62, v71, v75                               // 00000006DC54: 567C9747
	s_waitcnt lgkmcnt(2)                                       // 00000006DC58: BF89FC27
	v_fmac_f32_e32 v62, v72, v76                               // 00000006DC5C: 567C9948
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006DC60: BF870001
	v_fmac_f32_e32 v62, v73, v77                               // 00000006DC64: 567C9B49
	ds_load_2addr_b32 v[63:64], v59 offset0:8 offset1:9        // 00000006DC68: D8DC0908 3F00003B
	ds_load_2addr_b32 v[65:66], v1 offset0:136 offset1:153     // 00000006DC70: D8DC9988 41000001
	ds_load_2addr_b32 v[67:68], v59 offset0:10 offset1:11      // 00000006DC78: D8DC0B0A 4300003B
	ds_load_2addr_b32 v[69:70], v1 offset0:170 offset1:187     // 00000006DC80: D8DCBBAA 45000001
	ds_load_2addr_b32 v[71:72], v59 offset0:12 offset1:13      // 00000006DC88: D8DC0D0C 4700003B
	ds_load_2addr_b32 v[73:74], v59 offset0:14 offset1:15      // 00000006DC90: D8DC0F0E 4900003B
	ds_load_2addr_b32 v[75:76], v1 offset0:204 offset1:221     // 00000006DC98: D8DCDDCC 4B000001
	ds_load_2addr_b32 v[77:78], v1 offset0:238 offset1:255     // 00000006DCA0: D8DCFFEE 4D000001
	s_waitcnt lgkmcnt(6)                                       // 00000006DCA8: BF89FC67
	v_fmac_f32_e32 v62, v63, v65                               // 00000006DCAC: 567C833F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DCB0: BF8700A1
	v_fmac_f32_e32 v62, v64, v66                               // 00000006DCB4: 567C8540
	s_waitcnt lgkmcnt(4)                                       // 00000006DCB8: BF89FC47
	v_fmac_f32_e32 v62, v67, v69                               // 00000006DCBC: 567C8B43
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DCC0: BF8700A1
	v_fmac_f32_e32 v62, v68, v70                               // 00000006DCC4: 567C8D44
	s_waitcnt lgkmcnt(1)                                       // 00000006DCC8: BF89FC17
	v_fmac_f32_e32 v62, v71, v75                               // 00000006DCCC: 567C9747
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DCD0: BF8700A1
	v_fmac_f32_e32 v62, v72, v76                               // 00000006DCD4: 567C9948
	s_waitcnt lgkmcnt(0)                                       // 00000006DCD8: BF89FC07
	v_fmac_f32_e32 v62, v73, v77                               // 00000006DCDC: 567C9B49
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006DCE0: BF870001
	v_fmac_f32_e32 v62, v74, v78                               // 00000006DCE4: 567C9D4A
	ds_load_2addr_b32 v[63:64], v59 offset0:16 offset1:17      // 00000006DCE8: D8DC1110 3F00003B
	ds_load_2addr_b32 v[65:66], v59 offset0:18 offset1:19      // 00000006DCF0: D8DC1312 4100003B
	ds_load_2addr_b32 v[67:68], v59 offset0:20 offset1:21      // 00000006DCF8: D8DC1514 4300003B
	ds_load_2addr_b32 v[69:70], v59 offset0:22 offset1:23      // 00000006DD00: D8DC1716 4500003B
	ds_load_2addr_b32 v[75:76], v59 offset0:24 offset1:25      // 00000006DD08: D8DC1918 4B00003B
	ds_load_2addr_b32 v[77:78], v59 offset0:26 offset1:27      // 00000006DD10: D8DC1B1A 4D00003B
	v_add_nc_u32_e32 v47, 0x400, v1                            // 00000006DD18: 4A5E02FF 00000400
	v_add_nc_u32_e32 v95, 0x800, v1                            // 00000006DD20: 4ABE02FF 00000800
	v_add_nc_u32_e32 v101, 0x1000, v1                          // 00000006DD28: 4ACA02FF 00001000
	v_add_nc_u32_e32 v103, 0x1800, v1                          // 00000006DD30: 4ACE02FF 00001800
	ds_load_2addr_b32 v[71:72], v47 offset0:16 offset1:33      // 00000006DD38: D8DC2110 4700002F
	ds_load_2addr_b32 v[73:74], v47 offset0:50 offset1:67      // 00000006DD40: D8DC4332 4900002F
	ds_load_2addr_b32 v[83:84], v47 offset0:84 offset1:101     // 00000006DD48: D8DC6554 5300002F
	ds_load_2addr_b32 v[85:86], v47 offset0:118 offset1:135    // 00000006DD50: D8DC8776 5500002F
	ds_load_2addr_b32 v[87:88], v47 offset0:152 offset1:169    // 00000006DD58: D8DCA998 5700002F
	ds_load_2addr_b32 v[89:90], v47 offset0:186 offset1:203    // 00000006DD60: D8DCCBBA 5900002F
	ds_load_2addr_b32 v[91:92], v47 offset0:220 offset1:237    // 00000006DD68: D8DCEDDC 5B00002F
	ds_load_2addr_b32 v[93:94], v95 offset0:202 offset1:219    // 00000006DD70: D8DCDBCA 5D00005F
	ds_load_2addr_b32 v[99:100], v101 offset0:200 offset1:217  // 00000006DD78: D8DCD9C8 63000065
	s_waitcnt lgkmcnt(8)                                       // 00000006DD80: BF89FC87
	v_fmac_f32_e32 v62, v63, v71                               // 00000006DD84: 567C8F3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DD88: BF8700A1
	v_fmac_f32_e32 v62, v64, v72                               // 00000006DD8C: 567C9140
	s_waitcnt lgkmcnt(7)                                       // 00000006DD90: BF89FC77
	v_fmac_f32_e32 v62, v65, v73                               // 00000006DD94: 567C9341
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DD98: BF8700A1
	v_fmac_f32_e32 v62, v66, v74                               // 00000006DD9C: 567C9542
	s_waitcnt lgkmcnt(6)                                       // 00000006DDA0: BF89FC67
	v_fmac_f32_e32 v62, v67, v83                               // 00000006DDA4: 567CA743
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DDA8: BF8700A1
	v_fmac_f32_e32 v62, v68, v84                               // 00000006DDAC: 567CA944
	s_waitcnt lgkmcnt(5)                                       // 00000006DDB0: BF89FC57
	v_fmac_f32_e32 v62, v69, v85                               // 00000006DDB4: 567CAB45
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006DDB8: BF870001
	v_fmac_f32_e32 v62, v70, v86                               // 00000006DDBC: 567CAD46
	ds_load_2addr_b32 v[63:64], v59 offset0:32 offset1:33      // 00000006DDC0: D8DC2120 3F00003B
	ds_load_2addr_b32 v[65:66], v59 offset0:34 offset1:35      // 00000006DDC8: D8DC2322 4100003B
	ds_load_2addr_b32 v[67:68], v59 offset0:36 offset1:37      // 00000006DDD0: D8DC2524 4300003B
	ds_load_2addr_b32 v[69:70], v59 offset0:38 offset1:39      // 00000006DDD8: D8DC2726 4500003B
	ds_load_2addr_b32 v[73:74], v95 offset0:32 offset1:49      // 00000006DDE0: D8DC3120 4900005F
	ds_load_2addr_b32 v[83:84], v59 offset0:40 offset1:41      // 00000006DDE8: D8DC2928 5300003B
	ds_load_2addr_b32 v[85:86], v59 offset0:42 offset1:43      // 00000006DDF0: D8DC2B2A 5500003B
	s_waitcnt lgkmcnt(11)                                      // 00000006DDF8: BF89FCB7
	v_dual_fmac_f32 v62, v75, v87 :: v_dual_add_nc_u32 v47, 0x600, v1// 00000006DDFC: C820AF4B 3E2E02FF 00000600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DE08: BF8700A1
	v_fmac_f32_e32 v62, v76, v88                               // 00000006DE0C: 567CB14C
	s_waitcnt lgkmcnt(10)                                      // 00000006DE10: BF89FCA7
	v_fmac_f32_e32 v62, v77, v89                               // 00000006DE14: 567CB34D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DE18: BF8700A1
	v_fmac_f32_e32 v62, v78, v90                               // 00000006DE1C: 567CB54E
	s_waitcnt lgkmcnt(9)                                       // 00000006DE20: BF89FC97
	v_fmac_f32_e32 v62, v79, v91                               // 00000006DE24: 567CB74F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006DE28: BF870001
	v_fmac_f32_e32 v62, v80, v92                               // 00000006DE2C: 567CB950
	ds_load_2addr_b32 v[71:72], v47 offset0:126 offset1:143    // 00000006DE30: D8DC8F7E 4700002F
	ds_load_2addr_b32 v[75:76], v95 offset0:66 offset1:83      // 00000006DE38: D8DC5342 4B00005F
	ds_load_2addr_b32 v[77:78], v95 offset0:100 offset1:117    // 00000006DE40: D8DC7564 4D00005F
	ds_load_2addr_b32 v[79:80], v95 offset0:134 offset1:151    // 00000006DE48: D8DC9786 4F00005F
	ds_load_2addr_b32 v[87:88], v59 offset0:44 offset1:45      // 00000006DE50: D8DC2D2C 5700003B
	ds_load_2addr_b32 v[89:90], v59 offset0:46 offset1:47      // 00000006DE58: D8DC2F2E 5900003B
	ds_load_2addr_b32 v[91:92], v95 offset0:168 offset1:185    // 00000006DE60: D8DCB9A8 5B00005F
	ds_load_2addr_b32 v[95:96], v95 offset0:236 offset1:253    // 00000006DE68: D8DCFDEC 5F00005F
	s_waitcnt lgkmcnt(7)                                       // 00000006DE70: BF89FC77
	v_fmac_f32_e32 v62, v81, v71                               // 00000006DE74: 567C8F51
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DE78: BF870091
	v_fmac_f32_e32 v62, v82, v72                               // 00000006DE7C: 567C9152
	v_fmac_f32_e32 v62, v63, v73                               // 00000006DE80: 567C933F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DE84: BF8700A1
	v_fmac_f32_e32 v62, v64, v74                               // 00000006DE88: 567C9540
	s_waitcnt lgkmcnt(6)                                       // 00000006DE8C: BF89FC67
	v_fmac_f32_e32 v62, v65, v75                               // 00000006DE90: 567C9741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DE94: BF8700A1
	v_fmac_f32_e32 v62, v66, v76                               // 00000006DE98: 567C9942
	s_waitcnt lgkmcnt(5)                                       // 00000006DE9C: BF89FC57
	v_fmac_f32_e32 v62, v67, v77                               // 00000006DEA0: 567C9B43
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006DEA4: BF870001
	v_fmac_f32_e32 v62, v68, v78                               // 00000006DEA8: 567C9D44
	ds_load_2addr_b32 v[63:64], v59 offset0:48 offset1:49      // 00000006DEAC: D8DC3130 3F00003B
	ds_load_2addr_b32 v[65:66], v59 offset0:50 offset1:51      // 00000006DEB4: D8DC3332 4100003B
	ds_load_2addr_b32 v[67:68], v59 offset0:52 offset1:53      // 00000006DEBC: D8DC3534 4300003B
	ds_load_2addr_b32 v[71:72], v59 offset0:54 offset1:55      // 00000006DEC4: D8DC3736 4700003B
	ds_load_2addr_b32 v[81:82], v59 offset0:56 offset1:57      // 00000006DECC: D8DC3938 5100003B
	s_waitcnt lgkmcnt(9)                                       // 00000006DED4: BF89FC97
	v_dual_fmac_f32 v62, v69, v79 :: v_dual_add_nc_u32 v47, 0xc00, v1// 00000006DED8: C8209F45 3E2E02FF 00000C00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DEE4: BF8700A1
	v_fmac_f32_e32 v62, v70, v80                               // 00000006DEE8: 567CA146
	s_waitcnt lgkmcnt(6)                                       // 00000006DEEC: BF89FC67
	v_fmac_f32_e32 v62, v83, v91                               // 00000006DEF0: 567CB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DEF4: BF870091
	v_fmac_f32_e32 v62, v84, v92                               // 00000006DEF8: 567CB954
	v_fmac_f32_e32 v62, v85, v93                               // 00000006DEFC: 567CBB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006DF00: BF8700A1
	v_fmac_f32_e32 v62, v86, v94                               // 00000006DF04: 567CBD56
	s_waitcnt lgkmcnt(5)                                       // 00000006DF08: BF89FC57
	v_fmac_f32_e32 v62, v87, v95                               // 00000006DF0C: 567CBF57
	ds_load_2addr_b32 v[69:70], v47 offset0:14 offset1:31      // 00000006DF10: D8DC1F0E 4500002F
	ds_load_2addr_b32 v[73:74], v47 offset0:48 offset1:65      // 00000006DF18: D8DC4130 4900002F
	ds_load_2addr_b32 v[75:76], v47 offset0:82 offset1:99      // 00000006DF20: D8DC6352 4B00002F
	ds_load_2addr_b32 v[77:78], v47 offset0:116 offset1:133    // 00000006DF28: D8DC8574 4D00002F
	ds_load_2addr_b32 v[79:80], v47 offset0:150 offset1:167    // 00000006DF30: D8DCA796 4F00002F
	ds_load_2addr_b32 v[83:84], v59 offset0:58 offset1:59      // 00000006DF38: D8DC3B3A 5300003B
	ds_load_2addr_b32 v[85:86], v59 offset0:60 offset1:61      // 00000006DF40: D8DC3D3C 5500003B
	ds_load_2addr_b32 v[91:92], v59 offset0:62 offset1:63      // 00000006DF48: D8DC3F3E 5B00003B
	ds_load_2addr_b32 v[93:94], v47 offset0:184 offset1:201    // 00000006DF50: D8DCC9B8 5D00002F
	ds_load_2addr_b32 v[97:98], v47 offset0:218 offset1:235    // 00000006DF58: D8DCEBDA 6100002F
	v_fmac_f32_e32 v62, v88, v96                               // 00000006DF60: 567CC158
	s_waitcnt lgkmcnt(9)                                       // 00000006DF64: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DF68: BF870091
	v_fmac_f32_e32 v62, v89, v69                               // 00000006DF6C: 567C8B59
	v_fmac_f32_e32 v62, v90, v70                               // 00000006DF70: 567C8D5A
	s_waitcnt lgkmcnt(8)                                       // 00000006DF74: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DF78: BF870091
	v_fmac_f32_e32 v62, v63, v73                               // 00000006DF7C: 567C933F
	v_fmac_f32_e32 v62, v64, v74                               // 00000006DF80: 567C9540
	s_waitcnt lgkmcnt(7)                                       // 00000006DF84: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DF88: BF870091
	v_fmac_f32_e32 v62, v65, v75                               // 00000006DF8C: 567C9741
	v_fmac_f32_e32 v62, v66, v76                               // 00000006DF90: 567C9942
	s_waitcnt lgkmcnt(6)                                       // 00000006DF94: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006DF98: BF870001
	v_fmac_f32_e32 v62, v67, v77                               // 00000006DF9C: 567C9B43
	ds_load_2addr_b32 v[63:64], v59 offset0:64 offset1:65      // 00000006DFA0: D8DC4140 3F00003B
	ds_load_2addr_b32 v[65:66], v59 offset0:66 offset1:67      // 00000006DFA8: D8DC4342 4100003B
	ds_load_2addr_b32 v[69:70], v59 offset0:68 offset1:69      // 00000006DFB0: D8DC4544 4500003B
	ds_load_2addr_b32 v[73:74], v59 offset0:70 offset1:71      // 00000006DFB8: D8DC4746 4900003B
	ds_load_2addr_b32 v[75:76], v101 offset0:64 offset1:81     // 00000006DFC0: D8DC5140 4B000065
	ds_load_2addr_b32 v[87:88], v59 offset0:72 offset1:73      // 00000006DFC8: D8DC4948 5700003B
	ds_load_2addr_b32 v[89:90], v59 offset0:74 offset1:75      // 00000006DFD0: D8DC4B4A 5900003B
	ds_load_2addr_b32 v[95:96], v59 offset0:78 offset1:79      // 00000006DFD8: D8DC4F4E 5F00003B
	v_dual_fmac_f32 v62, v68, v78 :: v_dual_add_nc_u32 v47, 0xe00, v1// 00000006DFE0: C8209D44 3E2E02FF 00000E00
	s_waitcnt lgkmcnt(13)                                      // 00000006DFEC: BF89FCD7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006DFF0: BF870091
	v_fmac_f32_e32 v62, v71, v79                               // 00000006DFF4: 567C9F47
	v_fmac_f32_e32 v62, v72, v80                               // 00000006DFF8: 567CA148
	s_waitcnt lgkmcnt(9)                                       // 00000006DFFC: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E000: BF870091
	v_fmac_f32_e32 v62, v81, v93                               // 00000006E004: 567CBB51
	v_fmac_f32_e32 v62, v82, v94                               // 00000006E008: 567CBD52
	s_waitcnt lgkmcnt(8)                                       // 00000006E00C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E010: BF870091
	v_fmac_f32_e32 v62, v83, v97                               // 00000006E014: 567CC353
	v_fmac_f32_e32 v62, v84, v98                               // 00000006E018: 567CC554
	ds_load_2addr_b32 v[67:68], v47 offset0:124 offset1:141    // 00000006E01C: D8DC8D7C 4300002F
	ds_load_2addr_b32 v[71:72], v101 offset0:30 offset1:47     // 00000006E024: D8DC2F1E 47000065
	ds_load_2addr_b32 v[77:78], v101 offset0:98 offset1:115    // 00000006E02C: D8DC7362 4D000065
	ds_load_2addr_b32 v[79:80], v101 offset0:132 offset1:149   // 00000006E034: D8DC9584 4F000065
	ds_load_2addr_b32 v[81:82], v101 offset0:166 offset1:183   // 00000006E03C: D8DCB7A6 51000065
	ds_load_2addr_b32 v[93:94], v59 offset0:76 offset1:77      // 00000006E044: D8DC4D4C 5D00003B
	ds_load_2addr_b32 v[101:102], v101 offset0:234 offset1:251 // 00000006E04C: D8DCFBEA 65000065
	ds_load_2addr_b32 v[83:84], v59 offset0:88 offset1:89      // 00000006E054: D8DC5958 5300003B
	s_waitcnt lgkmcnt(7)                                       // 00000006E05C: BF89FC77
	v_fmac_f32_e32 v62, v85, v67                               // 00000006E060: 567C8755
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006E064: BF8700A1
	v_fmac_f32_e32 v62, v86, v68                               // 00000006E068: 567C8956
	s_waitcnt lgkmcnt(6)                                       // 00000006E06C: BF89FC67
	v_fmac_f32_e32 v62, v91, v71                               // 00000006E070: 567C8F5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E074: BF870091
	v_fmac_f32_e32 v62, v92, v72                               // 00000006E078: 567C915C
	v_fmac_f32_e32 v62, v63, v75                               // 00000006E07C: 567C973F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006E080: BF8700A1
	v_fmac_f32_e32 v62, v64, v76                               // 00000006E084: 567C9940
	s_waitcnt lgkmcnt(5)                                       // 00000006E088: BF89FC57
	v_fmac_f32_e32 v62, v65, v77                               // 00000006E08C: 567C9B41
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006E090: BF870001
	v_fmac_f32_e32 v62, v66, v78                               // 00000006E094: 567C9D42
	ds_load_2addr_b32 v[63:64], v59 offset0:80 offset1:81      // 00000006E098: D8DC5150 3F00003B
	ds_load_2addr_b32 v[67:68], v59 offset0:82 offset1:83      // 00000006E0A0: D8DC5352 4300003B
	ds_load_2addr_b32 v[71:72], v59 offset0:84 offset1:85      // 00000006E0A8: D8DC5554 4700003B
	ds_load_2addr_b32 v[75:76], v59 offset0:86 offset1:87      // 00000006E0B0: D8DC5756 4B00003B
	ds_load_2addr_b32 v[85:86], v59 offset0:90 offset1:91      // 00000006E0B8: D8DC5B5A 5500003B
	ds_load_2addr_b32 v[91:92], v59 offset0:94 offset1:95      // 00000006E0C0: D8DC5F5E 5B00003B
	s_waitcnt lgkmcnt(10)                                      // 00000006E0C8: BF89FCA7
	v_dual_fmac_f32 v62, v69, v79 :: v_dual_add_nc_u32 v47, 0x1400, v1// 00000006E0CC: C8209F45 3E2E02FF 00001400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006E0D8: BF8700A1
	v_fmac_f32_e32 v62, v70, v80                               // 00000006E0DC: 567CA146
	s_waitcnt lgkmcnt(9)                                       // 00000006E0E0: BF89FC97
	v_fmac_f32_e32 v62, v73, v81                               // 00000006E0E4: 567CA349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E0E8: BF870091
	v_fmac_f32_e32 v62, v74, v82                               // 00000006E0EC: 567CA54A
	v_fmac_f32_e32 v62, v87, v99                               // 00000006E0F0: 567CC757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006E0F4: BF8700A1
	v_fmac_f32_e32 v62, v88, v100                              // 00000006E0F8: 567CC958
	s_waitcnt lgkmcnt(7)                                       // 00000006E0FC: BF89FC77
	v_fmac_f32_e32 v62, v89, v101                              // 00000006E100: 567CCB59
	ds_load_2addr_b32 v[65:66], v47 offset0:12 offset1:29      // 00000006E104: D8DC1D0C 4100002F
	ds_load_2addr_b32 v[69:70], v47 offset0:46 offset1:63      // 00000006E10C: D8DC3F2E 4500002F
	ds_load_2addr_b32 v[73:74], v47 offset0:80 offset1:97      // 00000006E114: D8DC6150 4900002F
	ds_load_2addr_b32 v[77:78], v47 offset0:114 offset1:131    // 00000006E11C: D8DC8372 4D00002F
	ds_load_2addr_b32 v[79:80], v47 offset0:148 offset1:165    // 00000006E124: D8DCA594 4F00002F
	ds_load_2addr_b32 v[81:82], v47 offset0:182 offset1:199    // 00000006E12C: D8DCC7B6 5100002F
	ds_load_2addr_b32 v[87:88], v59 offset0:92 offset1:93      // 00000006E134: D8DC5D5C 5700003B
	ds_load_2addr_b32 v[97:98], v47 offset0:216 offset1:233    // 00000006E13C: D8DCE9D8 6100002F
	ds_load_2addr_b32 v[99:100], v59 offset0:108 offset1:109   // 00000006E144: D8DC6D6C 6300003B
	v_fmac_f32_e32 v62, v90, v102                              // 00000006E14C: 567CCD5A
	s_waitcnt lgkmcnt(8)                                       // 00000006E150: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E154: BF870091
	v_fmac_f32_e32 v62, v93, v65                               // 00000006E158: 567C835D
	v_fmac_f32_e32 v62, v94, v66                               // 00000006E15C: 567C855E
	s_waitcnt lgkmcnt(7)                                       // 00000006E160: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E164: BF870091
	v_fmac_f32_e32 v62, v95, v69                               // 00000006E168: 567C8B5F
	v_fmac_f32_e32 v62, v96, v70                               // 00000006E16C: 567C8D60
	s_waitcnt lgkmcnt(6)                                       // 00000006E170: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E174: BF870091
	v_fmac_f32_e32 v62, v63, v73                               // 00000006E178: 567C933F
	v_fmac_f32_e32 v62, v64, v74                               // 00000006E17C: 567C9540
	s_waitcnt lgkmcnt(5)                                       // 00000006E180: BF89FC57
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006E184: BF870001
	v_fmac_f32_e32 v62, v67, v77                               // 00000006E188: 567C9B43
	ds_load_2addr_b32 v[63:64], v59 offset0:96 offset1:97      // 00000006E18C: D8DC6160 3F00003B
	ds_load_2addr_b32 v[65:66], v59 offset0:98 offset1:99      // 00000006E194: D8DC6362 4100003B
	ds_load_2addr_b32 v[69:70], v59 offset0:100 offset1:101    // 00000006E19C: D8DC6564 4500003B
	ds_load_2addr_b32 v[73:74], v59 offset0:102 offset1:103    // 00000006E1A4: D8DC6766 4900003B
	ds_load_2addr_b32 v[89:90], v103 offset0:198 offset1:215   // 00000006E1AC: D8DCD7C6 59000067
	ds_load_2addr_b32 v[93:94], v59 offset0:104 offset1:105    // 00000006E1B4: D8DC6968 5D00003B
	ds_load_2addr_b32 v[95:96], v59 offset0:106 offset1:107    // 00000006E1BC: D8DC6B6A 5F00003B
	ds_load_2addr_b32 v[101:102], v59 offset0:110 offset1:111  // 00000006E1C4: D8DC6F6E 6500003B
	v_dual_fmac_f32 v62, v68, v78 :: v_dual_add_nc_u32 v47, 0x1600, v1// 00000006E1CC: C8209D44 3E2E02FF 00001600
	s_waitcnt lgkmcnt(12)                                      // 00000006E1D8: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E1DC: BF870091
	v_fmac_f32_e32 v62, v71, v79                               // 00000006E1E0: 567C9F47
	v_fmac_f32_e32 v62, v72, v80                               // 00000006E1E4: 567CA148
	s_waitcnt lgkmcnt(11)                                      // 00000006E1E8: BF89FCB7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E1EC: BF870091
	v_fmac_f32_e32 v62, v75, v81                               // 00000006E1F0: 567CA34B
	v_fmac_f32_e32 v62, v76, v82                               // 00000006E1F4: 567CA54C
	s_waitcnt lgkmcnt(9)                                       // 00000006E1F8: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E1FC: BF870091
	v_fmac_f32_e32 v62, v83, v97                               // 00000006E200: 567CC353
	v_fmac_f32_e32 v62, v84, v98                               // 00000006E204: 567CC554
	ds_load_2addr_b32 v[67:68], v47 offset0:122 offset1:139    // 00000006E208: D8DC8B7A 4300002F
	ds_load_2addr_b32 v[71:72], v103 offset0:28 offset1:45     // 00000006E210: D8DC2D1C 47000067
	ds_load_2addr_b32 v[75:76], v103 offset0:62 offset1:79     // 00000006E218: D8DC4F3E 4B000067
	ds_load_2addr_b32 v[77:78], v103 offset0:96 offset1:113    // 00000006E220: D8DC7160 4D000067
	ds_load_2addr_b32 v[79:80], v103 offset0:130 offset1:147   // 00000006E228: D8DC9382 4F000067
	ds_load_2addr_b32 v[81:82], v103 offset0:164 offset1:181   // 00000006E230: D8DCB5A4 51000067
	ds_load_2addr_b32 v[103:104], v103 offset0:232 offset1:249 // 00000006E238: D8DCF9E8 67000067
	s_waitcnt lgkmcnt(6)                                       // 00000006E240: BF89FC67
	v_fmac_f32_e32 v62, v85, v67                               // 00000006E244: 567C8755
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006E248: BF8700A1
	v_fmac_f32_e32 v62, v86, v68                               // 00000006E24C: 567C8956
	s_waitcnt lgkmcnt(5)                                       // 00000006E250: BF89FC57
	v_fmac_f32_e32 v62, v87, v71                               // 00000006E254: 567C8F57
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006E258: BF8700A1
	v_fmac_f32_e32 v62, v88, v72                               // 00000006E25C: 567C9158
	s_waitcnt lgkmcnt(4)                                       // 00000006E260: BF89FC47
	v_fmac_f32_e32 v62, v91, v75                               // 00000006E264: 567C975B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006E268: BF8700A1
	v_fmac_f32_e32 v62, v92, v76                               // 00000006E26C: 567C995C
	s_waitcnt lgkmcnt(3)                                       // 00000006E270: BF89FC37
	v_fmac_f32_e32 v62, v63, v77                               // 00000006E274: 567C9B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006E278: BF8700A1
	v_dual_fmac_f32 v62, v64, v78 :: v_dual_add_nc_u32 v47, 0x1e00, v1// 00000006E27C: C8209D40 3E2E02FF 00001E00
	s_waitcnt lgkmcnt(2)                                       // 00000006E288: BF89FC27
	v_fmac_f32_e32 v62, v65, v79                               // 00000006E28C: 567C9F41
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006E290: BF8700A1
	v_fmac_f32_e32 v62, v66, v80                               // 00000006E294: 567CA142
	s_waitcnt lgkmcnt(1)                                       // 00000006E298: BF89FC17
	v_fmac_f32_e32 v62, v69, v81                               // 00000006E29C: 567CA345
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E2A0: BF870091
	v_fmac_f32_e32 v62, v70, v82                               // 00000006E2A4: 567CA546
	v_fmac_f32_e32 v62, v73, v89                               // 00000006E2A8: 567CB349
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006E2AC: BF870001
	v_fmac_f32_e32 v62, v74, v90                               // 00000006E2B0: 567CB54A
	ds_load_2addr_b32 v[77:78], v47 offset0:120 offset1:137    // 00000006E2B4: D8DC8978 4D00002F
	v_add_nc_u32_e32 v47, 0x1c00, v1                           // 00000006E2BC: 4A5E02FF 00001C00
	ds_load_2addr_b32 v[87:88], v47 offset0:10 offset1:27      // 00000006E2C4: D8DC1B0A 5700002F
	ds_load_2addr_b32 v[89:90], v47 offset0:44 offset1:61      // 00000006E2CC: D8DC3D2C 5900002F
	ds_load_2addr_b32 v[91:92], v47 offset0:78 offset1:95      // 00000006E2D4: D8DC5F4E 5B00002F
	s_waitcnt lgkmcnt(4)                                       // 00000006E2DC: BF89FC47
	v_fmac_f32_e32 v62, v93, v103                              // 00000006E2E0: 567CCF5D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006E2E4: BF8700A1
	v_fmac_f32_e32 v62, v94, v104                              // 00000006E2E8: 567CD15E
	s_waitcnt lgkmcnt(2)                                       // 00000006E2EC: BF89FC27
	v_fmac_f32_e32 v62, v95, v87                               // 00000006E2F0: 567CAF5F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006E2F4: BF8700A1
	v_fmac_f32_e32 v62, v96, v88                               // 00000006E2F8: 567CB160
	s_waitcnt lgkmcnt(1)                                       // 00000006E2FC: BF89FC17
	v_fmac_f32_e32 v62, v99, v89                               // 00000006E300: 567CB363
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006E304: BF8700A1
	v_fmac_f32_e32 v62, v100, v90                              // 00000006E308: 567CB564
	s_waitcnt lgkmcnt(0)                                       // 00000006E30C: BF89FC07
	v_fmac_f32_e32 v62, v101, v91                              // 00000006E310: 567CB765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000006E314: BF8700D1
	v_fmac_f32_e32 v62, v102, v92                              // 00000006E318: 567CB966
	ds_load_2addr_b32 v[67:68], v59 offset0:112 offset1:113    // 00000006E31C: D8DC7170 4300003B
	ds_load_2addr_b32 v[97:98], v47 offset0:112 offset1:129    // 00000006E324: D8DC8170 6100002F
	s_waitcnt lgkmcnt(0)                                       // 00000006E32C: BF89FC07
	v_fmac_f32_e32 v62, v67, v97                               // 00000006E330: 567CC343
	v_fmac_f32_e32 v62, v68, v98                               // 00000006E334: 567CC544
	ds_load_2addr_b32 v[71:72], v59 offset0:114 offset1:115    // 00000006E338: D8DC7372 4700003B
	ds_load_2addr_b32 v[105:106], v47 offset0:146 offset1:163  // 00000006E340: D8DCA392 6900002F
	s_waitcnt lgkmcnt(0)                                       // 00000006E348: BF89FC07
	v_fmac_f32_e32 v62, v71, v105                              // 00000006E34C: 567CD347
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006E350: BF870001
	v_fmac_f32_e32 v62, v72, v106                              // 00000006E354: 567CD548
	ds_load_2addr_b32 v[83:84], v59 offset0:118 offset1:119    // 00000006E358: D8DC7776 5300003B
	ds_load_2addr_b32 v[75:76], v59 offset0:116 offset1:117    // 00000006E360: D8DC7574 4B00003B
	ds_load_2addr_b32 v[63:64], v59 offset0:120 offset1:121    // 00000006E368: D8DC7978 3F00003B
	v_add_nc_u32_e32 v85, 0x2000, v1                           // 00000006E370: 4AAA02FF 00002000
	ds_load_2addr_b32 v[107:108], v47 offset0:180 offset1:197  // 00000006E378: D8DCC5B4 6B00002F
	ds_load_2addr_b32 v[109:110], v47 offset0:214 offset1:231  // 00000006E380: D8DCE7D6 6D00002F
	ds_load_2addr_b32 v[65:66], v59 offset0:122 offset1:123    // 00000006E388: D8DC7B7A 4100003B
	ds_load_2addr_b32 v[69:70], v59 offset0:124 offset1:125    // 00000006E390: D8DC7D7C 4500003B
	ds_load_2addr_b32 v[79:80], v85 offset0:26 offset1:43      // 00000006E398: D8DC2B1A 4F000055
	ds_load_2addr_b32 v[81:82], v85 offset0:60 offset1:77      // 00000006E3A0: D8DC4D3C 51000055
	ds_load_2addr_b32 v[73:74], v59 offset0:126 offset1:127    // 00000006E3A8: D8DC7F7E 4900003B
	ds_load_2addr_b32 v[85:86], v85 offset0:94 offset1:111     // 00000006E3B0: D8DC6F5E 55000055
	s_waitcnt lgkmcnt(7)                                       // 00000006E3B8: BF89FC77
	v_fmac_f32_e32 v62, v75, v107                              // 00000006E3BC: 567CD74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006E3C0: BF8700A1
	v_fmac_f32_e32 v62, v76, v108                              // 00000006E3C4: 567CD94C
	s_waitcnt lgkmcnt(6)                                       // 00000006E3C8: BF89FC67
	v_fmac_f32_e32 v62, v83, v109                              // 00000006E3CC: 567CDB53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E3D0: BF870091
	v_fmac_f32_e32 v62, v84, v110                              // 00000006E3D4: 567CDD54
	v_dual_fmac_f32 v62, v63, v77 :: v_dual_mov_b32 v63, v1    // 00000006E3D8: C8109B3F 3E3E0101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000006E3E0: BF8700D1
	v_fmac_f32_e32 v62, v64, v78                               // 00000006E3E4: 567C9D40
	ds_load_b32 v64, v46 offset:17440                          // 00000006E3E8: D8D84420 4000002E
	v_dual_mov_b32 v47, v43 :: v_dual_mov_b32 v46, v42         // 00000006E3F0: CA10012B 2F2E012A
	s_waitcnt lgkmcnt(4)                                       // 00000006E3F8: BF89FC47
	v_fmac_f32_e32 v62, v65, v79                               // 00000006E3FC: 567C9F41
	v_fmac_f32_e32 v62, v66, v80                               // 00000006E400: 567CA142
	s_waitcnt lgkmcnt(3)                                       // 00000006E404: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E408: BF870091
	v_fmac_f32_e32 v62, v69, v81                               // 00000006E40C: 567CA345
	v_fmac_f32_e32 v62, v70, v82                               // 00000006E410: 567CA546
	s_waitcnt lgkmcnt(1)                                       // 00000006E414: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E418: BF870091
	v_fmac_f32_e32 v62, v73, v85                               // 00000006E41C: 567CAB49
	v_fmac_f32_e32 v62, v74, v86                               // 00000006E420: 567CAD4A
	s_waitcnt lgkmcnt(0)                                       // 00000006E424: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006E428: BF870001
	v_mul_f32_e32 v62, v62, v64                                // 00000006E42C: 107C813E
	v_mov_b32_e32 v64, v48                                     // 00000006E430: 7E800330
	s_nop 0                                                    // 00000006E434: BF800000
	s_nop 0                                                    // 00000006E438: BF800000
	s_nop 0                                                    // 00000006E43C: BF800000
	global_load_b32 v65, v[46:47], off                         // 00000006E440: DC520000 417C002E
	ds_load_b32 v66, v63 offset:8704                           // 00000006E448: D8D82200 4200003F
	v_add_nc_u32_e32 v64, -1, v64                              // 00000006E450: 4A8080C1
	.long 0xd700012e                                           // 00000006E454: D700012E
	v_cndmask_b32_e32 v0, v46, v132, vcc_lo                    // 00000006E458: 0201092E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000006E45C: BF870191
	v_add_co_ci_u32_e64 v47, null, 0, v47, s1                  // 00000006E460: D5207C2F 00065E80
	.long 0xd44a0004                                           // 00000006E468: D44A0004
	v_cndmask_b32_e32 v1, 0, v64, vcc_lo                       // 00000006E46C: 02028080
	v_add_nc_u32_e32 v63, 0x44, v63                            // 00000006E470: 4A7E7EFF 00000044
	s_or_b32 s12, s4, s12                                      // 00000006E478: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000006E47C: BF890007
	v_fmac_f32_e32 v62, v65, v66                               // 00000006E480: 567C8541
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 00000006E484: 917E0C7E
	s_cbranch_execnz 65517                                     // 00000006E488: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2740>
	s_or_b32 exec_lo, exec_lo, s12                             // 00000006E48C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006E490: BF870121
	v_bfe_u32 v63, v62, 16, 1                                  // 00000006E494: D610003F 0205213E
	v_mad_u64_u32 v[46:47], null, 0x3000, v49, v[4:5]          // 00000006E49C: D6FE7C2E 041262FF 00003000
	v_add3_u32 v49, v62, v63, 0x7fff                           // 00000006E4A8: D6550031 03FE7F3E 00007FFF
	global_store_d16_hi_b16 v[46:47], v49, off                 // 00000006E4B4: DC960000 007C312E
	s_branch 64901                                             // 00000006E4BC: BFA0FD85 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dd4>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 00000006E4C0: A201FF06 3FB8AA3B
	v_mov_b32_e32 v44, v51                                     // 00000006E4C8: 7E580333
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000006E4CC: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 00000006E4D0: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 00000006E4D8: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 00000006E4DC: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 00000006E4E4: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 00000006E4EC: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000006E4F0: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 00000006E4F4: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 00000006E4FC: A0010401
	s_mov_b32 s4, 0                                            // 00000006E500: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 00000006E504: BF87000A
	v_exp_f32_e32 v42, s1                                      // 00000006E508: 7E544A01
	s_cvt_i32_f32 s1, s7                                       // 00000006E50C: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000006E510: BF870585
	.long 0xd71c002a                                           // 00000006E514: D71C002A
	v_cndmask_b32_e32 v0, v42, v1, vcc_lo                      // 00000006E518: 0200032A
	s_cselect_b32 s1, -1, 0                                    // 00000006E51C: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 00000006E520: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000006E528: BF870131
	v_cndmask_b32_e64 v43, 0, v42, s1                          // 00000006E52C: D501002B 00065480
	s_cselect_b32 s1, -1, 0                                    // 00000006E534: 980180C1
	v_mov_b32_e32 v42, v50                                     // 00000006E538: 7E540332
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 00000006E53C: D501002B 000656FF 7F800000
	ds_load_b32 v45, v42                                       // 00000006E548: D8D80000 2D00002A
	v_add_nc_u32_e32 v44, 0x80, v44                            // 00000006E550: 4A5858FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006E558: BF870001
	.long 0xd4490001                                           // 00000006E55C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v44, vcc_lo                   // 00000006E560: 020258FF 0000077F
	s_or_b32 s4, s1, s4                                        // 00000006E568: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 00000006E56C: BF89FC07
	v_mul_f32_e32 v45, v43, v45                                // 00000006E570: 105A5B2B
	ds_store_b32 v42, v45                                      // 00000006E574: D8340000 00002D2A
	v_add_nc_u32_e32 v42, 0x220, v42                           // 00000006E57C: 4A5454FF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000006E584: 917E047E
	s_cbranch_execnz 65519                                     // 00000006E588: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2848>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006E58C: 8C7E047E
	v_dual_mov_b32 v43, v27 :: v_dual_mov_b32 v42, v26         // 00000006E590: CA10011B 2B2A011A
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v45, v53           // 00000006E598: CA100080 2C2C0135
	v_mov_b32_e32 v46, v51                                     // 00000006E5A0: 7E5C0333
	s_mov_b32 s6, 0                                            // 00000006E5A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000006E5A8: BF89FC07
	s_barrier                                                  // 00000006E5AC: BFBD0000
	buffer_gl0_inv                                             // 00000006E5B0: E0AC0000 00000000
	s_nop 0                                                    // 00000006E5B8: BF800000
	s_nop 0                                                    // 00000006E5BC: BF800000
	global_load_b32 v47, v[42:43], off                         // 00000006E5C0: DC520000 2F7C002A
	ds_load_b32 v48, v44 offset:17184                          // 00000006E5C8: D8D84320 3000002C
	v_add_nc_u32_e32 v46, 0x80, v46                            // 00000006E5D0: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 00000006E5D8: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006E5DC: 020254FF 00006000
	v_add_nc_u32_e32 v44, 4, v44                               // 00000006E5E4: 4A585884
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006E5E8: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000006E5F0: BF870004
	.long 0xd4490004                                           // 00000006E5F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 00000006E5F8: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000006E600: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000006E604: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 00000006E608: 105E612F
	ds_store_b32 v45, v47 offset:13056                         // 00000006E60C: D8343300 00002F2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 00000006E614: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000006E61C: 917E067E
	s_cbranch_execnz 65511                                     // 00000006E620: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x28c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000006E624: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000006E628: BF89FC07
	s_barrier                                                  // 00000006E62C: BFBD0000
	buffer_gl0_inv                                             // 00000006E630: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v61 offset1:17                 // 00000006E638: D8DC1100 2A00003D
	ds_load_2addr_b32 v[44:45], v61 offset0:34 offset1:51      // 00000006E640: D8DC3322 2C00003D
	ds_load_2addr_b32 v[46:47], v61 offset0:68 offset1:85      // 00000006E648: D8DC5544 2E00003D
	ds_load_2addr_b32 v[48:49], v61 offset0:102 offset1:119    // 00000006E650: D8DC7766 3000003D
	v_mov_b32_e32 v62, v0                                      // 00000006E658: 7E7C0300
	s_mov_b32 s4, 0                                            // 00000006E65C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000006E660: BF840001
	s_nop 0                                                    // 00000006E664: BF800000
	s_nop 0                                                    // 00000006E668: BF800000
	s_nop 0                                                    // 00000006E66C: BF800000
	s_nop 0                                                    // 00000006E670: BF800000
	s_nop 0                                                    // 00000006E674: BF800000
	s_nop 0                                                    // 00000006E678: BF800000
	s_nop 0                                                    // 00000006E67C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006E680: BF870121
	v_lshrrev_b32_e32 v63, 4, v62                              // 00000006E684: 327E7C84
	.long 0xd4490001                                           // 00000006E688: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v62, vcc_lo                   // 00000006E68C: 02027CFF 0000077F
	v_lshlrev_b32_e32 v70, 2, v63                              // 00000006E694: 308C7E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 00000006E698: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000006E6A4: 8C040401
	v_add_nc_u32_e32 v64, 0x3200, v70                          // 00000006E6A8: 4A808CFF 00003200
	v_add_nc_u32_e32 v66, 0x3600, v70                          // 00000006E6B0: 4A848CFF 00003600
	v_add_nc_u32_e32 v68, 0x3a00, v70                          // 00000006E6B8: 4A888CFF 00003A00
	ds_load_b32 v71, v63                                       // 00000006E6C0: D8D80000 4700003F
	ds_load_2addr_b32 v[64:65], v64 offset0:64 offset1:193     // 00000006E6C8: D8DCC140 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:66 offset1:195     // 00000006E6D0: D8DCC342 42000042
	ds_load_2addr_b32 v[68:69], v68 offset0:68 offset1:197     // 00000006E6D8: D8DCC544 44000044
	s_waitcnt lgkmcnt(2)                                       // 00000006E6E0: BF89FC27
	v_fmac_f32_e32 v71, v64, v42                               // 00000006E6E4: 568E5540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000006E6E8: BF8700C1
	v_dual_fmac_f32 v71, v65, v43 :: v_dual_add_nc_u32 v64, 0x3e00, v70// 00000006E6EC: C8205741 47408CFF 00003E00
	ds_load_2addr_b32 v[64:65], v64 offset0:70 offset1:199     // 00000006E6F8: D8DCC746 40000040
	s_waitcnt lgkmcnt(2)                                       // 00000006E700: BF89FC27
	v_fmac_f32_e32 v71, v66, v44                               // 00000006E704: 568E5942
	v_fmac_f32_e32 v71, v67, v45                               // 00000006E708: 568E5B43
	s_waitcnt lgkmcnt(1)                                       // 00000006E70C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E710: BF870091
	v_fmac_f32_e32 v71, v68, v46                               // 00000006E714: 568E5D44
	v_fmac_f32_e32 v71, v69, v47                               // 00000006E718: 568E5F45
	s_waitcnt lgkmcnt(0)                                       // 00000006E71C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E720: BF870091
	v_dual_fmac_f32 v71, v64, v48 :: v_dual_add_nc_u32 v64, 0x80, v62// 00000006E724: C8206140 47407CFF 00000080
	v_dual_fmac_f32 v71, v65, v49 :: v_dual_mov_b32 v62, v64   // 00000006E730: C8106341 473E0140
	ds_store_b32 v63, v71                                      // 00000006E738: D8340000 0000473F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000006E740: 917E047E
	s_cbranch_execnz 65486                                     // 00000006E744: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2980>
	s_set_inst_prefetch_distance 0x2                           // 00000006E748: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006E74C: 8C7E047E
	v_dual_mov_b32 v43, v29 :: v_dual_mov_b32 v42, v28         // 00000006E750: CA10011D 2B2A011C
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, 0           // 00000006E758: CA100135 2C2C0080
	v_mov_b32_e32 v46, v51                                     // 00000006E760: 7E5C0333
	s_mov_b32 s6, 0                                            // 00000006E764: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000006E768: BF89FC07
	s_barrier                                                  // 00000006E76C: BFBD0000
	buffer_gl0_inv                                             // 00000006E770: E0AC0000 00000000
	s_nop 0                                                    // 00000006E778: BF800000
	s_nop 0                                                    // 00000006E77C: BF800000
	global_load_b32 v47, v[42:43], off                         // 00000006E780: DC520000 2F7C002A
	ds_load_b32 v48, v45 offset:17216                          // 00000006E788: D8D84340 3000002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 00000006E790: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 00000006E798: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006E79C: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 00000006E7A4: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006E7A8: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000006E7B0: BF870004
	.long 0xd4490004                                           // 00000006E7B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 00000006E7B8: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000006E7C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000006E7C4: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 00000006E7C8: 105E612F
	ds_store_b32 v44, v47 offset:13056                         // 00000006E7CC: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006E7D4: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000006E7DC: 917E067E
	s_cbranch_execnz 65511                                     // 00000006E7E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a80>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000006E7E4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000006E7E8: BF89FC07
	s_barrier                                                  // 00000006E7EC: BFBD0000
	buffer_gl0_inv                                             // 00000006E7F0: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v61 offset0:136 offset1:153    // 00000006E7F8: D8DC9988 2A00003D
	ds_load_2addr_b32 v[44:45], v61 offset0:170 offset1:187    // 00000006E800: D8DCBBAA 2C00003D
	ds_load_2addr_b32 v[46:47], v61 offset0:204 offset1:221    // 00000006E808: D8DCDDCC 2E00003D
	ds_load_2addr_b32 v[48:49], v61 offset0:238 offset1:255    // 00000006E810: D8DCFFEE 3000003D
	v_mov_b32_e32 v62, v0                                      // 00000006E818: 7E7C0300
	s_mov_b32 s4, 0                                            // 00000006E81C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000006E820: BF840001
	s_nop 0                                                    // 00000006E824: BF800000
	s_nop 0                                                    // 00000006E828: BF800000
	s_nop 0                                                    // 00000006E82C: BF800000
	s_nop 0                                                    // 00000006E830: BF800000
	s_nop 0                                                    // 00000006E834: BF800000
	s_nop 0                                                    // 00000006E838: BF800000
	s_nop 0                                                    // 00000006E83C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006E840: BF870121
	v_lshrrev_b32_e32 v63, 4, v62                              // 00000006E844: 327E7C84
	.long 0xd4490001                                           // 00000006E848: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v62, vcc_lo                   // 00000006E84C: 02027CFF 0000077F
	v_lshlrev_b32_e32 v70, 2, v63                              // 00000006E854: 308C7E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 00000006E858: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000006E864: 8C040401
	v_add_nc_u32_e32 v64, 0x3200, v70                          // 00000006E868: 4A808CFF 00003200
	v_add_nc_u32_e32 v66, 0x3600, v70                          // 00000006E870: 4A848CFF 00003600
	v_add_nc_u32_e32 v68, 0x3a00, v70                          // 00000006E878: 4A888CFF 00003A00
	ds_load_b32 v71, v63                                       // 00000006E880: D8D80000 4700003F
	ds_load_2addr_b32 v[64:65], v64 offset0:64 offset1:193     // 00000006E888: D8DCC140 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:66 offset1:195     // 00000006E890: D8DCC342 42000042
	ds_load_2addr_b32 v[68:69], v68 offset0:68 offset1:197     // 00000006E898: D8DCC544 44000044
	s_waitcnt lgkmcnt(2)                                       // 00000006E8A0: BF89FC27
	v_fmac_f32_e32 v71, v64, v42                               // 00000006E8A4: 568E5540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000006E8A8: BF8700C1
	v_dual_fmac_f32 v71, v65, v43 :: v_dual_add_nc_u32 v64, 0x3e00, v70// 00000006E8AC: C8205741 47408CFF 00003E00
	ds_load_2addr_b32 v[64:65], v64 offset0:70 offset1:199     // 00000006E8B8: D8DCC746 40000040
	s_waitcnt lgkmcnt(2)                                       // 00000006E8C0: BF89FC27
	v_fmac_f32_e32 v71, v66, v44                               // 00000006E8C4: 568E5942
	v_fmac_f32_e32 v71, v67, v45                               // 00000006E8C8: 568E5B43
	s_waitcnt lgkmcnt(1)                                       // 00000006E8CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E8D0: BF870091
	v_fmac_f32_e32 v71, v68, v46                               // 00000006E8D4: 568E5D44
	v_fmac_f32_e32 v71, v69, v47                               // 00000006E8D8: 568E5F45
	s_waitcnt lgkmcnt(0)                                       // 00000006E8DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006E8E0: BF870091
	v_dual_fmac_f32 v71, v64, v48 :: v_dual_add_nc_u32 v64, 0x80, v62// 00000006E8E4: C8206140 47407CFF 00000080
	v_dual_fmac_f32 v71, v65, v49 :: v_dual_mov_b32 v62, v64   // 00000006E8F0: C8106341 473E0140
	ds_store_b32 v63, v71                                      // 00000006E8F8: D8340000 0000473F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000006E900: 917E047E
	s_cbranch_execnz 65486                                     // 00000006E904: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b40>
	s_set_inst_prefetch_distance 0x2                           // 00000006E908: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006E90C: 8C7E047E
	v_dual_mov_b32 v43, v31 :: v_dual_mov_b32 v42, v30         // 00000006E910: CA10011F 2B2A011E
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, 0           // 00000006E918: CA100135 2C2C0080
	v_mov_b32_e32 v46, v51                                     // 00000006E920: 7E5C0333
	s_mov_b32 s6, 0                                            // 00000006E924: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000006E928: BF89FC07
	s_barrier                                                  // 00000006E92C: BFBD0000
	buffer_gl0_inv                                             // 00000006E930: E0AC0000 00000000
	s_nop 0                                                    // 00000006E938: BF800000
	s_nop 0                                                    // 00000006E93C: BF800000
	global_load_b32 v47, v[42:43], off                         // 00000006E940: DC520000 2F7C002A
	ds_load_b32 v48, v45 offset:17248                          // 00000006E948: D8D84360 3000002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 00000006E950: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 00000006E958: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006E95C: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 00000006E964: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006E968: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000006E970: BF870004
	.long 0xd4490004                                           // 00000006E974: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 00000006E978: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000006E980: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000006E984: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 00000006E988: 105E612F
	ds_store_b32 v44, v47 offset:13056                         // 00000006E98C: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006E994: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000006E99C: 917E067E
	s_cbranch_execnz 65511                                     // 00000006E9A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c40>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000006E9A4: 8C7E067E
	v_add_nc_u32_e32 v62, 0x400, v61                           // 00000006E9A8: 4A7C7AFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 00000006E9B0: BF89FC07
	s_barrier                                                  // 00000006E9B4: BFBD0000
	buffer_gl0_inv                                             // 00000006E9B8: E0AC0000 00000000
	v_mov_b32_e32 v63, v0                                      // 00000006E9C0: 7E7E0300
	ds_load_2addr_b32 v[42:43], v62 offset0:16 offset1:33      // 00000006E9C4: D8DC2110 2A00003E
	ds_load_2addr_b32 v[44:45], v62 offset0:50 offset1:67      // 00000006E9CC: D8DC4332 2C00003E
	ds_load_2addr_b32 v[46:47], v62 offset0:84 offset1:101     // 00000006E9D4: D8DC6554 2E00003E
	ds_load_2addr_b32 v[48:49], v62 offset0:118 offset1:135    // 00000006E9DC: D8DC8776 3000003E
	s_mov_b32 s4, 0                                            // 00000006E9E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000006E9E8: BF840001
	s_nop 0                                                    // 00000006E9EC: BF800000
	s_nop 0                                                    // 00000006E9F0: BF800000
	s_nop 0                                                    // 00000006E9F4: BF800000
	s_nop 0                                                    // 00000006E9F8: BF800000
	s_nop 0                                                    // 00000006E9FC: BF800000
	v_lshrrev_b32_e32 v64, 4, v63                              // 00000006EA00: 32807E84
	.long 0xd4490001                                           // 00000006EA04: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v63, vcc_lo                   // 00000006EA08: 02027EFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000006EA10: BF870002
	v_lshlrev_b32_e32 v71, 2, v64                              // 00000006EA14: 308E8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 00000006EA18: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 00000006EA24: 8C040401
	v_add_nc_u32_e32 v65, 0x3200, v71                          // 00000006EA28: 4A828EFF 00003200
	v_add_nc_u32_e32 v67, 0x3600, v71                          // 00000006EA30: 4A868EFF 00003600
	v_add_nc_u32_e32 v69, 0x3a00, v71                          // 00000006EA38: 4A8A8EFF 00003A00
	ds_load_b32 v72, v64                                       // 00000006EA40: D8D80000 48000040
	ds_load_2addr_b32 v[65:66], v65 offset0:64 offset1:193     // 00000006EA48: D8DCC140 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:66 offset1:195     // 00000006EA50: D8DCC342 43000043
	ds_load_2addr_b32 v[69:70], v69 offset0:68 offset1:197     // 00000006EA58: D8DCC544 45000045
	s_waitcnt lgkmcnt(2)                                       // 00000006EA60: BF89FC27
	v_dual_fmac_f32 v72, v65, v42 :: v_dual_add_nc_u32 v65, 0x3e00, v71// 00000006EA64: C8205541 48408EFF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000006EA70: BF8700C1
	v_fmac_f32_e32 v72, v66, v43                               // 00000006EA74: 56905742
	ds_load_2addr_b32 v[65:66], v65 offset0:70 offset1:199     // 00000006EA78: D8DCC746 41000041
	s_waitcnt lgkmcnt(2)                                       // 00000006EA80: BF89FC27
	v_fmac_f32_e32 v72, v67, v44                               // 00000006EA84: 56905943
	v_fmac_f32_e32 v72, v68, v45                               // 00000006EA88: 56905B44
	s_waitcnt lgkmcnt(1)                                       // 00000006EA8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006EA90: BF870091
	v_fmac_f32_e32 v72, v69, v46                               // 00000006EA94: 56905D45
	v_fmac_f32_e32 v72, v70, v47                               // 00000006EA98: 56905F46
	s_waitcnt lgkmcnt(0)                                       // 00000006EA9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006EAA0: BF870091
	v_dual_fmac_f32 v72, v65, v48 :: v_dual_add_nc_u32 v65, 0x80, v63// 00000006EAA4: C8206141 48407EFF 00000080
	v_dual_fmac_f32 v72, v66, v49 :: v_dual_mov_b32 v63, v65   // 00000006EAB0: C8106342 483E0141
	ds_store_b32 v64, v72                                      // 00000006EAB8: D8340000 00004840
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000006EAC0: 917E047E
	s_cbranch_execnz 65486                                     // 00000006EAC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d00>
	s_set_inst_prefetch_distance 0x2                           // 00000006EAC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006EACC: 8C7E047E
	v_dual_mov_b32 v43, v33 :: v_dual_mov_b32 v42, v32         // 00000006EAD0: CA100121 2B2A0120
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, 0           // 00000006EAD8: CA100135 2C2C0080
	v_mov_b32_e32 v46, v51                                     // 00000006EAE0: 7E5C0333
	s_mov_b32 s6, 0                                            // 00000006EAE4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000006EAE8: BF89FC07
	s_barrier                                                  // 00000006EAEC: BFBD0000
	buffer_gl0_inv                                             // 00000006EAF0: E0AC0000 00000000
	s_nop 0                                                    // 00000006EAF8: BF800000
	s_nop 0                                                    // 00000006EAFC: BF800000
	global_load_b32 v47, v[42:43], off                         // 00000006EB00: DC520000 2F7C002A
	ds_load_b32 v48, v45 offset:17280                          // 00000006EB08: D8D84380 3000002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 00000006EB10: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 00000006EB18: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006EB1C: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 00000006EB24: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006EB28: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000006EB30: BF870004
	.long 0xd4490004                                           // 00000006EB34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 00000006EB38: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000006EB40: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000006EB44: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 00000006EB48: 105E612F
	ds_store_b32 v44, v47 offset:13056                         // 00000006EB4C: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006EB54: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000006EB5C: 917E067E
	s_cbranch_execnz 65511                                     // 00000006EB60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e00>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000006EB64: 8C7E067E
	v_add_nc_u32_e32 v48, 0x600, v61                           // 00000006EB68: 4A607AFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 00000006EB70: BF89FC07
	s_barrier                                                  // 00000006EB74: BFBD0000
	buffer_gl0_inv                                             // 00000006EB78: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v62 offset0:152 offset1:169    // 00000006EB80: D8DCA998 2A00003E
	ds_load_2addr_b32 v[44:45], v62 offset0:186 offset1:203    // 00000006EB88: D8DCCBBA 2C00003E
	ds_load_2addr_b32 v[46:47], v62 offset0:220 offset1:237    // 00000006EB90: D8DCEDDC 2E00003E
	ds_load_2addr_b32 v[48:49], v48 offset0:126 offset1:143    // 00000006EB98: D8DC8F7E 30000030
	v_mov_b32_e32 v62, v0                                      // 00000006EBA0: 7E7C0300
	s_mov_b32 s4, 0                                            // 00000006EBA4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000006EBA8: BF840001
	s_nop 0                                                    // 00000006EBAC: BF800000
	s_nop 0                                                    // 00000006EBB0: BF800000
	s_nop 0                                                    // 00000006EBB4: BF800000
	s_nop 0                                                    // 00000006EBB8: BF800000
	s_nop 0                                                    // 00000006EBBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006EBC0: BF870121
	v_lshrrev_b32_e32 v63, 4, v62                              // 00000006EBC4: 327E7C84
	.long 0xd4490001                                           // 00000006EBC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v62, vcc_lo                   // 00000006EBCC: 02027CFF 0000077F
	v_lshlrev_b32_e32 v70, 2, v63                              // 00000006EBD4: 308C7E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 00000006EBD8: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000006EBE4: 8C040401
	v_add_nc_u32_e32 v64, 0x3200, v70                          // 00000006EBE8: 4A808CFF 00003200
	v_add_nc_u32_e32 v66, 0x3600, v70                          // 00000006EBF0: 4A848CFF 00003600
	v_add_nc_u32_e32 v68, 0x3a00, v70                          // 00000006EBF8: 4A888CFF 00003A00
	ds_load_b32 v71, v63                                       // 00000006EC00: D8D80000 4700003F
	ds_load_2addr_b32 v[64:65], v64 offset0:64 offset1:193     // 00000006EC08: D8DCC140 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:66 offset1:195     // 00000006EC10: D8DCC342 42000042
	ds_load_2addr_b32 v[68:69], v68 offset0:68 offset1:197     // 00000006EC18: D8DCC544 44000044
	s_waitcnt lgkmcnt(2)                                       // 00000006EC20: BF89FC27
	v_fmac_f32_e32 v71, v64, v42                               // 00000006EC24: 568E5540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000006EC28: BF8700C1
	v_dual_fmac_f32 v71, v65, v43 :: v_dual_add_nc_u32 v64, 0x3e00, v70// 00000006EC2C: C8205741 47408CFF 00003E00
	ds_load_2addr_b32 v[64:65], v64 offset0:70 offset1:199     // 00000006EC38: D8DCC746 40000040
	s_waitcnt lgkmcnt(2)                                       // 00000006EC40: BF89FC27
	v_fmac_f32_e32 v71, v66, v44                               // 00000006EC44: 568E5942
	v_fmac_f32_e32 v71, v67, v45                               // 00000006EC48: 568E5B43
	s_waitcnt lgkmcnt(1)                                       // 00000006EC4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006EC50: BF870091
	v_fmac_f32_e32 v71, v68, v46                               // 00000006EC54: 568E5D44
	v_fmac_f32_e32 v71, v69, v47                               // 00000006EC58: 568E5F45
	s_waitcnt lgkmcnt(0)                                       // 00000006EC5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006EC60: BF870091
	v_dual_fmac_f32 v71, v64, v48 :: v_dual_add_nc_u32 v64, 0x80, v62// 00000006EC64: C8206140 47407CFF 00000080
	v_dual_fmac_f32 v71, v65, v49 :: v_dual_mov_b32 v62, v64   // 00000006EC70: C8106341 473E0140
	ds_store_b32 v63, v71                                      // 00000006EC78: D8340000 0000473F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000006EC80: 917E047E
	s_cbranch_execnz 65486                                     // 00000006EC84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ec0>
	s_set_inst_prefetch_distance 0x2                           // 00000006EC88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006EC8C: 8C7E047E
	v_dual_mov_b32 v43, v35 :: v_dual_mov_b32 v42, v34         // 00000006EC90: CA100123 2B2A0122
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, 0           // 00000006EC98: CA100135 2C2C0080
	v_mov_b32_e32 v46, v51                                     // 00000006ECA0: 7E5C0333
	s_mov_b32 s6, 0                                            // 00000006ECA4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000006ECA8: BF89FC07
	s_barrier                                                  // 00000006ECAC: BFBD0000
	buffer_gl0_inv                                             // 00000006ECB0: E0AC0000 00000000
	s_nop 0                                                    // 00000006ECB8: BF800000
	s_nop 0                                                    // 00000006ECBC: BF800000
	global_load_b32 v47, v[42:43], off                         // 00000006ECC0: DC520000 2F7C002A
	ds_load_b32 v48, v45 offset:17312                          // 00000006ECC8: D8D843A0 3000002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 00000006ECD0: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 00000006ECD8: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006ECDC: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 00000006ECE4: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006ECE8: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000006ECF0: BF870004
	.long 0xd4490004                                           // 00000006ECF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 00000006ECF8: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000006ED00: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000006ED04: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 00000006ED08: 105E612F
	ds_store_b32 v44, v47 offset:13056                         // 00000006ED0C: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006ED14: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000006ED1C: 917E067E
	s_cbranch_execnz 65511                                     // 00000006ED20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2fc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000006ED24: 8C7E067E
	v_add_nc_u32_e32 v63, 0x800, v61                           // 00000006ED28: 4A7E7AFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 00000006ED30: BF89FC07
	s_barrier                                                  // 00000006ED34: BFBD0000
	buffer_gl0_inv                                             // 00000006ED38: E0AC0000 00000000
	v_mov_b32_e32 v62, v0                                      // 00000006ED40: 7E7C0300
	ds_load_2addr_b32 v[42:43], v63 offset0:32 offset1:49      // 00000006ED44: D8DC3120 2A00003F
	ds_load_2addr_b32 v[44:45], v63 offset0:66 offset1:83      // 00000006ED4C: D8DC5342 2C00003F
	ds_load_2addr_b32 v[46:47], v63 offset0:100 offset1:117    // 00000006ED54: D8DC7564 2E00003F
	ds_load_2addr_b32 v[48:49], v63 offset0:134 offset1:151    // 00000006ED5C: D8DC9786 3000003F
	s_mov_b32 s4, 0                                            // 00000006ED64: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000006ED68: BF840001
	s_nop 0                                                    // 00000006ED6C: BF800000
	s_nop 0                                                    // 00000006ED70: BF800000
	s_nop 0                                                    // 00000006ED74: BF800000
	s_nop 0                                                    // 00000006ED78: BF800000
	s_nop 0                                                    // 00000006ED7C: BF800000
	v_lshrrev_b32_e32 v64, 4, v62                              // 00000006ED80: 32807C84
	.long 0xd4490001                                           // 00000006ED84: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v62, vcc_lo                   // 00000006ED88: 02027CFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 00000006ED90: BF870002
	v_lshlrev_b32_e32 v71, 2, v64                              // 00000006ED94: 308E8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 00000006ED98: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 00000006EDA4: 8C040401
	v_add_nc_u32_e32 v65, 0x3200, v71                          // 00000006EDA8: 4A828EFF 00003200
	v_add_nc_u32_e32 v67, 0x3600, v71                          // 00000006EDB0: 4A868EFF 00003600
	v_add_nc_u32_e32 v69, 0x3a00, v71                          // 00000006EDB8: 4A8A8EFF 00003A00
	ds_load_b32 v72, v64                                       // 00000006EDC0: D8D80000 48000040
	ds_load_2addr_b32 v[65:66], v65 offset0:64 offset1:193     // 00000006EDC8: D8DCC140 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:66 offset1:195     // 00000006EDD0: D8DCC342 43000043
	ds_load_2addr_b32 v[69:70], v69 offset0:68 offset1:197     // 00000006EDD8: D8DCC544 45000045
	s_waitcnt lgkmcnt(2)                                       // 00000006EDE0: BF89FC27
	v_dual_fmac_f32 v72, v65, v42 :: v_dual_add_nc_u32 v65, 0x3e00, v71// 00000006EDE4: C8205541 48408EFF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000006EDF0: BF8700C1
	v_fmac_f32_e32 v72, v66, v43                               // 00000006EDF4: 56905742
	ds_load_2addr_b32 v[65:66], v65 offset0:70 offset1:199     // 00000006EDF8: D8DCC746 41000041
	s_waitcnt lgkmcnt(2)                                       // 00000006EE00: BF89FC27
	v_fmac_f32_e32 v72, v67, v44                               // 00000006EE04: 56905943
	v_fmac_f32_e32 v72, v68, v45                               // 00000006EE08: 56905B44
	s_waitcnt lgkmcnt(1)                                       // 00000006EE0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006EE10: BF870091
	v_fmac_f32_e32 v72, v69, v46                               // 00000006EE14: 56905D45
	v_fmac_f32_e32 v72, v70, v47                               // 00000006EE18: 56905F46
	s_waitcnt lgkmcnt(0)                                       // 00000006EE1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006EE20: BF870091
	v_dual_fmac_f32 v72, v65, v48 :: v_dual_add_nc_u32 v65, 0x80, v62// 00000006EE24: C8206141 48407CFF 00000080
	v_fmac_f32_e32 v72, v66, v49                               // 00000006EE30: 56906342
	s_delay_alu instid0(VALU_DEP_2)                            // 00000006EE34: BF870002
	v_mov_b32_e32 v62, v65                                     // 00000006EE38: 7E7C0341
	ds_store_b32 v64, v72                                      // 00000006EE3C: D8340000 00004840
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000006EE44: 917E047E
	s_cbranch_execnz 65485                                     // 00000006EE48: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3080>
	s_set_inst_prefetch_distance 0x2                           // 00000006EE4C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006EE50: 8C7E047E
	v_dual_mov_b32 v43, v37 :: v_dual_mov_b32 v42, v36         // 00000006EE54: CA100125 2B2A0124
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, 0           // 00000006EE5C: CA100135 2C2C0080
	v_mov_b32_e32 v46, v51                                     // 00000006EE64: 7E5C0333
	s_mov_b32 s6, 0                                            // 00000006EE68: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000006EE6C: BF89FC07
	s_barrier                                                  // 00000006EE70: BFBD0000
	buffer_gl0_inv                                             // 00000006EE74: E0AC0000 00000000
	s_nop 0                                                    // 00000006EE7C: BF800000
	global_load_b32 v47, v[42:43], off                         // 00000006EE80: DC520000 2F7C002A
	ds_load_b32 v48, v45 offset:17344                          // 00000006EE88: D8D843C0 3000002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 00000006EE90: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 00000006EE98: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006EE9C: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 00000006EEA4: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006EEA8: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000006EEB0: BF870004
	.long 0xd4490004                                           // 00000006EEB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 00000006EEB8: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000006EEC0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000006EEC4: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 00000006EEC8: 105E612F
	ds_store_b32 v44, v47 offset:13056                         // 00000006EECC: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006EED4: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000006EEDC: 917E067E
	s_cbranch_execnz 65511                                     // 00000006EEE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3180>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000006EEE4: 8C7E067E
	v_add_nc_u32_e32 v62, 0xc00, v61                           // 00000006EEE8: 4A7C7AFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 00000006EEF0: BF89FC07
	s_barrier                                                  // 00000006EEF4: BFBD0000
	buffer_gl0_inv                                             // 00000006EEF8: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v63 offset0:168 offset1:185    // 00000006EF00: D8DCB9A8 2A00003F
	ds_load_2addr_b32 v[44:45], v63 offset0:202 offset1:219    // 00000006EF08: D8DCDBCA 2C00003F
	ds_load_2addr_b32 v[46:47], v63 offset0:236 offset1:253    // 00000006EF10: D8DCFDEC 2E00003F
	ds_load_2addr_b32 v[48:49], v62 offset0:14 offset1:31      // 00000006EF18: D8DC1F0E 3000003E
	v_mov_b32_e32 v63, v0                                      // 00000006EF20: 7E7E0300
	s_mov_b32 s4, 0                                            // 00000006EF24: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000006EF28: BF840001
	s_nop 0                                                    // 00000006EF2C: BF800000
	s_nop 0                                                    // 00000006EF30: BF800000
	s_nop 0                                                    // 00000006EF34: BF800000
	s_nop 0                                                    // 00000006EF38: BF800000
	s_nop 0                                                    // 00000006EF3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006EF40: BF870121
	v_lshrrev_b32_e32 v64, 4, v63                              // 00000006EF44: 32807E84
	.long 0xd4490001                                           // 00000006EF48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v63, vcc_lo                   // 00000006EF4C: 02027EFF 0000077F
	v_lshlrev_b32_e32 v71, 2, v64                              // 00000006EF54: 308E8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 00000006EF58: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 00000006EF64: 8C040401
	v_add_nc_u32_e32 v65, 0x3200, v71                          // 00000006EF68: 4A828EFF 00003200
	v_add_nc_u32_e32 v67, 0x3600, v71                          // 00000006EF70: 4A868EFF 00003600
	v_add_nc_u32_e32 v69, 0x3a00, v71                          // 00000006EF78: 4A8A8EFF 00003A00
	ds_load_b32 v72, v64                                       // 00000006EF80: D8D80000 48000040
	ds_load_2addr_b32 v[65:66], v65 offset0:64 offset1:193     // 00000006EF88: D8DCC140 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:66 offset1:195     // 00000006EF90: D8DCC342 43000043
	ds_load_2addr_b32 v[69:70], v69 offset0:68 offset1:197     // 00000006EF98: D8DCC544 45000045
	s_waitcnt lgkmcnt(2)                                       // 00000006EFA0: BF89FC27
	v_dual_fmac_f32 v72, v65, v42 :: v_dual_add_nc_u32 v65, 0x3e00, v71// 00000006EFA4: C8205541 48408EFF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000006EFB0: BF8700C1
	v_fmac_f32_e32 v72, v66, v43                               // 00000006EFB4: 56905742
	ds_load_2addr_b32 v[65:66], v65 offset0:70 offset1:199     // 00000006EFB8: D8DCC746 41000041
	s_waitcnt lgkmcnt(2)                                       // 00000006EFC0: BF89FC27
	v_fmac_f32_e32 v72, v67, v44                               // 00000006EFC4: 56905943
	v_fmac_f32_e32 v72, v68, v45                               // 00000006EFC8: 56905B44
	s_waitcnt lgkmcnt(1)                                       // 00000006EFCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006EFD0: BF870091
	v_fmac_f32_e32 v72, v69, v46                               // 00000006EFD4: 56905D45
	v_fmac_f32_e32 v72, v70, v47                               // 00000006EFD8: 56905F46
	s_waitcnt lgkmcnt(0)                                       // 00000006EFDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006EFE0: BF870091
	v_dual_fmac_f32 v72, v65, v48 :: v_dual_add_nc_u32 v65, 0x80, v63// 00000006EFE4: C8206141 48407EFF 00000080
	v_dual_fmac_f32 v72, v66, v49 :: v_dual_mov_b32 v63, v65   // 00000006EFF0: C8106342 483E0141
	ds_store_b32 v64, v72                                      // 00000006EFF8: D8340000 00004840
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000006F000: 917E047E
	s_cbranch_execnz 65486                                     // 00000006F004: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3240>
	s_set_inst_prefetch_distance 0x2                           // 00000006F008: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006F00C: 8C7E047E
	v_dual_mov_b32 v43, v39 :: v_dual_mov_b32 v42, v38         // 00000006F010: CA100127 2B2A0126
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, 0           // 00000006F018: CA100135 2C2C0080
	v_mov_b32_e32 v46, v51                                     // 00000006F020: 7E5C0333
	s_mov_b32 s6, 0                                            // 00000006F024: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000006F028: BF89FC07
	s_barrier                                                  // 00000006F02C: BFBD0000
	buffer_gl0_inv                                             // 00000006F030: E0AC0000 00000000
	s_nop 0                                                    // 00000006F038: BF800000
	s_nop 0                                                    // 00000006F03C: BF800000
	global_load_b32 v47, v[42:43], off                         // 00000006F040: DC520000 2F7C002A
	ds_load_b32 v48, v45 offset:17376                          // 00000006F048: D8D843E0 3000002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 00000006F050: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 00000006F058: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006F05C: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 00000006F064: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006F068: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000006F070: BF870004
	.long 0xd4490004                                           // 00000006F074: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 00000006F078: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000006F080: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000006F084: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 00000006F088: 105E612F
	ds_store_b32 v44, v47 offset:13056                         // 00000006F08C: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006F094: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000006F09C: 917E067E
	s_cbranch_execnz 65511                                     // 00000006F0A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3340>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000006F0A4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000006F0A8: BF89FC07
	s_barrier                                                  // 00000006F0AC: BFBD0000
	buffer_gl0_inv                                             // 00000006F0B0: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v62 offset0:48 offset1:65      // 00000006F0B8: D8DC4130 2A00003E
	ds_load_2addr_b32 v[44:45], v62 offset0:82 offset1:99      // 00000006F0C0: D8DC6352 2C00003E
	ds_load_2addr_b32 v[46:47], v62 offset0:116 offset1:133    // 00000006F0C8: D8DC8574 2E00003E
	ds_load_2addr_b32 v[48:49], v62 offset0:150 offset1:167    // 00000006F0D0: D8DCA796 3000003E
	v_mov_b32_e32 v63, v0                                      // 00000006F0D8: 7E7E0300
	s_mov_b32 s4, 0                                            // 00000006F0DC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000006F0E0: BF840001
	s_nop 0                                                    // 00000006F0E4: BF800000
	s_nop 0                                                    // 00000006F0E8: BF800000
	s_nop 0                                                    // 00000006F0EC: BF800000
	s_nop 0                                                    // 00000006F0F0: BF800000
	s_nop 0                                                    // 00000006F0F4: BF800000
	s_nop 0                                                    // 00000006F0F8: BF800000
	s_nop 0                                                    // 00000006F0FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006F100: BF870121
	v_lshrrev_b32_e32 v64, 4, v63                              // 00000006F104: 32807E84
	.long 0xd4490001                                           // 00000006F108: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v63, vcc_lo                   // 00000006F10C: 02027EFF 0000077F
	v_lshlrev_b32_e32 v71, 2, v64                              // 00000006F114: 308E8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 00000006F118: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 00000006F124: 8C040401
	v_add_nc_u32_e32 v65, 0x3200, v71                          // 00000006F128: 4A828EFF 00003200
	v_add_nc_u32_e32 v67, 0x3600, v71                          // 00000006F130: 4A868EFF 00003600
	v_add_nc_u32_e32 v69, 0x3a00, v71                          // 00000006F138: 4A8A8EFF 00003A00
	ds_load_b32 v72, v64                                       // 00000006F140: D8D80000 48000040
	ds_load_2addr_b32 v[65:66], v65 offset0:64 offset1:193     // 00000006F148: D8DCC140 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:66 offset1:195     // 00000006F150: D8DCC342 43000043
	ds_load_2addr_b32 v[69:70], v69 offset0:68 offset1:197     // 00000006F158: D8DCC544 45000045
	s_waitcnt lgkmcnt(2)                                       // 00000006F160: BF89FC27
	v_dual_fmac_f32 v72, v65, v42 :: v_dual_add_nc_u32 v65, 0x3e00, v71// 00000006F164: C8205541 48408EFF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000006F170: BF8700C1
	v_fmac_f32_e32 v72, v66, v43                               // 00000006F174: 56905742
	ds_load_2addr_b32 v[65:66], v65 offset0:70 offset1:199     // 00000006F178: D8DCC746 41000041
	s_waitcnt lgkmcnt(2)                                       // 00000006F180: BF89FC27
	v_fmac_f32_e32 v72, v67, v44                               // 00000006F184: 56905943
	v_fmac_f32_e32 v72, v68, v45                               // 00000006F188: 56905B44
	s_waitcnt lgkmcnt(1)                                       // 00000006F18C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006F190: BF870091
	v_fmac_f32_e32 v72, v69, v46                               // 00000006F194: 56905D45
	v_fmac_f32_e32 v72, v70, v47                               // 00000006F198: 56905F46
	s_waitcnt lgkmcnt(0)                                       // 00000006F19C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006F1A0: BF870091
	v_dual_fmac_f32 v72, v65, v48 :: v_dual_add_nc_u32 v65, 0x80, v63// 00000006F1A4: C8206141 48407EFF 00000080
	v_dual_fmac_f32 v72, v66, v49 :: v_dual_mov_b32 v63, v65   // 00000006F1B0: C8106342 483E0141
	ds_store_b32 v64, v72                                      // 00000006F1B8: D8340000 00004840
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000006F1C0: 917E047E
	s_cbranch_execnz 65486                                     // 00000006F1C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3400>
	s_set_inst_prefetch_distance 0x2                           // 00000006F1C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006F1CC: 8C7E047E
	v_dual_mov_b32 v43, v41 :: v_dual_mov_b32 v42, v40         // 00000006F1D0: CA100129 2B2A0128
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, 0           // 00000006F1D8: CA100135 2C2C0080
	v_mov_b32_e32 v46, v51                                     // 00000006F1E0: 7E5C0333
	s_mov_b32 s6, 0                                            // 00000006F1E4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000006F1E8: BF89FC07
	s_barrier                                                  // 00000006F1EC: BFBD0000
	buffer_gl0_inv                                             // 00000006F1F0: E0AC0000 00000000
	s_nop 0                                                    // 00000006F1F8: BF800000
	s_nop 0                                                    // 00000006F1FC: BF800000
	global_load_b32 v47, v[42:43], off                         // 00000006F200: DC520000 2F7C002A
	ds_load_b32 v48, v45 offset:17408                          // 00000006F208: D8D84400 3000002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 00000006F210: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 00000006F218: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000006F21C: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 00000006F224: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 00000006F228: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000006F230: BF870004
	.long 0xd4490004                                           // 00000006F234: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 00000006F238: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 00000006F240: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000006F244: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 00000006F248: 105E612F
	ds_store_b32 v44, v47 offset:13056                         // 00000006F24C: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000006F254: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000006F25C: 917E067E
	s_cbranch_execnz 65511                                     // 00000006F260: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3500>
	s_or_b32 exec_lo, exec_lo, s6                              // 00000006F264: 8C7E067E
	v_add_nc_u32_e32 v46, 0xe00, v61                           // 00000006F268: 4A5C7AFF 00000E00
	v_add_nc_u32_e32 v48, 0x1000, v61                          // 00000006F270: 4A607AFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 00000006F278: BF89FC07
	s_barrier                                                  // 00000006F27C: BFBD0000
	buffer_gl0_inv                                             // 00000006F280: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v62 offset0:184 offset1:201    // 00000006F288: D8DCC9B8 2A00003E
	ds_load_2addr_b32 v[44:45], v62 offset0:218 offset1:235    // 00000006F290: D8DCEBDA 2C00003E
	ds_load_2addr_b32 v[46:47], v46 offset0:124 offset1:141    // 00000006F298: D8DC8D7C 2E00002E
	ds_load_2addr_b32 v[48:49], v48 offset0:30 offset1:47      // 00000006F2A0: D8DC2F1E 30000030
	v_mov_b32_e32 v62, v0                                      // 00000006F2A8: 7E7C0300
	s_mov_b32 s4, 0                                            // 00000006F2AC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000006F2B0: BF840001
	s_nop 0                                                    // 00000006F2B4: BF800000
	s_nop 0                                                    // 00000006F2B8: BF800000
	s_nop 0                                                    // 00000006F2BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006F2C0: BF870121
	v_lshrrev_b32_e32 v63, 4, v62                              // 00000006F2C4: 327E7C84
	.long 0xd4490001                                           // 00000006F2C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v62, vcc_lo                   // 00000006F2CC: 02027CFF 0000077F
	v_lshlrev_b32_e32 v70, 2, v63                              // 00000006F2D4: 308C7E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 00000006F2D8: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000006F2E4: 8C040401
	v_add_nc_u32_e32 v64, 0x3200, v70                          // 00000006F2E8: 4A808CFF 00003200
	v_add_nc_u32_e32 v66, 0x3600, v70                          // 00000006F2F0: 4A848CFF 00003600
	v_add_nc_u32_e32 v68, 0x3a00, v70                          // 00000006F2F8: 4A888CFF 00003A00
	ds_load_b32 v71, v63                                       // 00000006F300: D8D80000 4700003F
	ds_load_2addr_b32 v[64:65], v64 offset0:64 offset1:193     // 00000006F308: D8DCC140 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:66 offset1:195     // 00000006F310: D8DCC342 42000042
	ds_load_2addr_b32 v[68:69], v68 offset0:68 offset1:197     // 00000006F318: D8DCC544 44000044
	s_waitcnt lgkmcnt(2)                                       // 00000006F320: BF89FC27
	v_fmac_f32_e32 v71, v64, v42                               // 00000006F324: 568E5540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000006F328: BF8700C1
	v_dual_fmac_f32 v71, v65, v43 :: v_dual_add_nc_u32 v64, 0x3e00, v70// 00000006F32C: C8205741 47408CFF 00003E00
	ds_load_2addr_b32 v[64:65], v64 offset0:70 offset1:199     // 00000006F338: D8DCC746 40000040
	s_waitcnt lgkmcnt(2)                                       // 00000006F340: BF89FC27
	v_fmac_f32_e32 v71, v66, v44                               // 00000006F344: 568E5942
	v_fmac_f32_e32 v71, v67, v45                               // 00000006F348: 568E5B43
	s_waitcnt lgkmcnt(1)                                       // 00000006F34C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006F350: BF870091
	v_fmac_f32_e32 v71, v68, v46                               // 00000006F354: 568E5D44
	v_fmac_f32_e32 v71, v69, v47                               // 00000006F358: 568E5F45
	s_waitcnt lgkmcnt(0)                                       // 00000006F35C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006F360: BF870091
	v_dual_fmac_f32 v71, v64, v48 :: v_dual_add_nc_u32 v64, 0x80, v62// 00000006F364: C8206140 47407CFF 00000080
	v_dual_fmac_f32 v71, v65, v49 :: v_dual_mov_b32 v62, v64   // 00000006F370: C8106341 473E0140
	ds_store_b32 v63, v71                                      // 00000006F378: D8340000 0000473F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000006F380: 917E047E
	s_cbranch_execnz 65486                                     // 00000006F384: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x35c0>
	s_set_inst_prefetch_distance 0x2                           // 00000006F388: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000006F38C: 8C7E047E
	.long 0xd7000106                                           // 00000006F390: D7000106
	v_cndmask_b32_e32 v1, 0x180000, v6, vcc_lo                 // 00000006F394: 02020CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006F39C: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v7, s1                    // 00000006F3A0: D5207C07 00060E80
	.long 0xd7000108                                           // 00000006F3A8: D7000108
	v_cndmask_b32_e32 v1, 0x180000, v8, vcc_lo                 // 00000006F3AC: 020210FF 00180000
	v_add_co_ci_u32_e64 v9, null, 0, v9, s1                    // 00000006F3B4: D5207C09 00061280
	.long 0xd700010a                                           // 00000006F3BC: D700010A
	v_cndmask_b32_e32 v1, 0x180000, v10, vcc_lo                // 00000006F3C0: 020214FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006F3C8: BF8700A1
	v_add_co_ci_u32_e64 v11, null, 0, v11, s1                  // 00000006F3CC: D5207C0B 00061680
	.long 0xd700010c                                           // 00000006F3D4: D700010C
	v_cndmask_b32_e32 v1, 0x180000, v12, vcc_lo                // 00000006F3D8: 020218FF 00180000
	v_add_co_ci_u32_e64 v13, null, 0, v13, s1                  // 00000006F3E0: D5207C0D 00061A80
	.long 0xd700010e                                           // 00000006F3E8: D700010E
	v_cndmask_b32_e32 v1, 0x180000, v14, vcc_lo                // 00000006F3EC: 02021CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006F3F4: BF8700A1
	v_add_co_ci_u32_e64 v15, null, 0, v15, s1                  // 00000006F3F8: D5207C0F 00061E80
	.long 0xd7000110                                           // 00000006F400: D7000110
	v_cndmask_b32_e32 v1, 0x180000, v16, vcc_lo                // 00000006F404: 020220FF 00180000
	v_add_co_ci_u32_e64 v17, null, 0, v17, s1                  // 00000006F40C: D5207C11 00062280
	.long 0xd7000112                                           // 00000006F414: D7000112
	v_cndmask_b32_e32 v1, 0x180000, v18, vcc_lo                // 00000006F418: 020224FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006F420: BF8700A1
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 00000006F424: D5207C13 00062680
	.long 0xd7000114                                           // 00000006F42C: D7000114
	v_cndmask_b32_e32 v1, 0x180000, v20, vcc_lo                // 00000006F430: 020228FF 00180000
	v_add_co_ci_u32_e64 v21, null, 0, v21, s1                  // 00000006F438: D5207C15 00062A80
	.long 0xd7000116                                           // 00000006F440: D7000116
	v_cndmask_b32_e32 v1, 0x180000, v22, vcc_lo                // 00000006F444: 02022CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006F44C: BF8700A1
	v_add_co_ci_u32_e64 v23, null, 0, v23, s1                  // 00000006F450: D5207C17 00062E80
	.long 0xd7000118                                           // 00000006F458: D7000118
	v_cndmask_b32_e32 v1, 0xc0000, v24, vcc_lo                 // 00000006F45C: 020230FF 000C0000
	v_add_co_ci_u32_e64 v25, null, 0, v25, s1                  // 00000006F464: D5207C19 00063280
	.long 0xd700011a                                           // 00000006F46C: D700011A
	v_cndmask_b32_e32 v1, 0x180000, v26, vcc_lo                // 00000006F470: 020234FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006F478: BF8700A1
	v_add_co_ci_u32_e64 v27, null, 0, v27, s1                  // 00000006F47C: D5207C1B 00063680
	.long 0xd700011c                                           // 00000006F484: D700011C
	v_cndmask_b32_e32 v1, 0x180000, v28, vcc_lo                // 00000006F488: 020238FF 00180000
	v_add_co_ci_u32_e64 v29, null, 0, v29, s1                  // 00000006F490: D5207C1D 00063A80
	.long 0xd700011e                                           // 00000006F498: D700011E
	v_cndmask_b32_e32 v1, 0x180000, v30, vcc_lo                // 00000006F49C: 02023CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006F4A4: BF8700A1
	v_add_co_ci_u32_e64 v31, null, 0, v31, s1                  // 00000006F4A8: D5207C1F 00063E80
	.long 0xd7000120                                           // 00000006F4B0: D7000120
	v_cndmask_b32_e32 v1, 0x180000, v32, vcc_lo                // 00000006F4B4: 020240FF 00180000
	v_add_co_ci_u32_e64 v33, null, 0, v33, s1                  // 00000006F4BC: D5207C21 00064280
	.long 0xd7000122                                           // 00000006F4C4: D7000122
	v_cndmask_b32_e32 v1, 0x180000, v34, vcc_lo                // 00000006F4C8: 020244FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006F4D0: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v35, s1                  // 00000006F4D4: D5207C23 00064680
	.long 0xd7000124                                           // 00000006F4DC: D7000124
	v_cndmask_b32_e32 v1, 0x180000, v36, vcc_lo                // 00000006F4E0: 020248FF 00180000
	v_add_co_ci_u32_e64 v37, null, 0, v37, s1                  // 00000006F4E8: D5207C25 00064A80
	.long 0xd7000126                                           // 00000006F4F0: D7000126
	v_cndmask_b32_e32 v1, 0x180000, v38, vcc_lo                // 00000006F4F4: 02024CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006F4FC: BF8700A1
	v_add_co_ci_u32_e64 v39, null, 0, v39, s1                  // 00000006F500: D5207C27 00064E80
	.long 0xd7000128                                           // 00000006F508: D7000128
	v_cndmask_b32_e32 v1, 0x180000, v40, vcc_lo                // 00000006F50C: 020250FF 00180000
	v_add_co_ci_u32_e64 v41, null, 0, v41, s1                  // 00000006F514: D5207C29 00065280
	s_add_i32 s5, s5, 1                                        // 00000006F51C: 81058105
	s_waitcnt lgkmcnt(0)                                       // 00000006F520: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 00000006F524: BF062105
	s_barrier                                                  // 00000006F528: BFBD0000
	buffer_gl0_inv                                             // 00000006F52C: E0AC0000 00000000
	s_cbranch_scc0 62214                                       // 00000006F534: BFA1F306 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x450>
	v_mov_b32_e32 v5, v51                                      // 00000006F538: 7E0A0333
	s_add_u32 s0, s28, s20                                     // 00000006F53C: 8000141C
	.long 0xd73c0000                                           // 00000006F540: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000006F544: 02020489
	s_addc_u32 s1, s29, s21                                    // 00000006F548: 8201151D
	s_add_u32 s2, s24, s18                                     // 00000006F54C: 80021218
	s_addc_u32 s3, s25, s19                                    // 00000006F550: 82031319
	s_add_u32 s0, s2, s0                                       // 00000006F554: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000006F558: 82010103
	.long 0xd7006a00                                           // 00000006F55C: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000006F560: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000006F564: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000006F568: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000006F570: BE810080
	.long 0xd7006a00                                           // 00000006F574: D7006A00
	v_cndmask_b32_e32 v1, v0, v52, vcc_lo                      // 00000006F578: 02026900
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000006F57C: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006F584: BF870092
	.long 0xd7006a00                                           // 00000006F588: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000006F58C: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000006F590: D5207C01 01AA0211
	s_nop 0                                                    // 00000006F598: BF800000
	s_nop 0                                                    // 00000006F59C: BF800000
	s_nop 0                                                    // 00000006F5A0: BF800000
	s_nop 0                                                    // 00000006F5A4: BF800000
	s_nop 0                                                    // 00000006F5A8: BF800000
	s_nop 0                                                    // 00000006F5AC: BF800000
	s_nop 0                                                    // 00000006F5B0: BF800000
	s_nop 0                                                    // 00000006F5B4: BF800000
	s_nop 0                                                    // 00000006F5B8: BF800000
	s_nop 0                                                    // 00000006F5BC: BF800000
	ds_load_b32 v2, v50                                        // 00000006F5C0: D8D80000 02000032
	v_add_nc_u32_e32 v5, 0x80, v5                              // 00000006F5C8: 4A0A0AFF 00000080
	v_add_nc_u32_e32 v50, 0x220, v50                           // 00000006F5D0: 4A6464FF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000006F5D8: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v5                         // 00000006F5DC: 7C920AFF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 00000006F5E4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000006F5E8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 00000006F5EC: DC6A0000 007C0200
	.long 0xd7000000                                           // 00000006F5F4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000006F5F8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000006F600: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000006F608: 917E017E
	s_cbranch_execnz 65516                                     // 00000006F60C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi1ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x38c0>
	s_nop 0                                                    // 00000006F610: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000006F614: BFB60003
	s_endpgm                                                   // 00000006F618: BFB00000
		...

