0000000000127500 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 000000127500: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 000000127504: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 00000012750C: F4080500 F8000050
	v_and_b32_e32 v130, 31, v0                                 // 000000127514: 3704009F
	v_lshrrev_b32_e32 v157, 5, v0                              // 000000127518: 333A0085
	s_mov_b32 s24, s3                                          // 00000012751C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000127520: BF870112
	.long 0xd44c0003                                           // 000000127524: D44C0003
	v_cndmask_b32_e32 v1, 16, v130, vcc_lo                     // 000000127528: 02030490
	v_lshlrev_b32_e32 v131, 6, v157                            // 00000012752C: 31073A86
	s_waitcnt lgkmcnt(0)                                       // 000000127530: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 000000127534: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 00000012753C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 000000127540: BF870001
	v_lshl_add_u32 v1, v130, 2, v131                           // 000000127544: D6460001 060D0582
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 00000012754C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:231 offset1:243// 000000127558: D83CF3E7 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 000000127560: 8C7E047E
	v_mul_u32_u24_e32 v1, 0x2ab, v0                            // 000000127564: 160200FF 000002AB
	s_clause 0x1                                               // 00000012756C: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000127570: F40C0100 F8000000
	s_load_b128 s[16:19], s[0:1], 0x20                         // 000000127578: F4080400 F8000020
	s_lshl_b32 s27, s2, 5                                      // 000000127580: 841B8502
	v_dual_mov_b32 v144, 0 :: v_dual_and_b32 v159, 15, v0      // 000000127584: CA240080 909E008F
	.long 0xd7381001                                           // 00000012758C: D7381001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000127590: 02020282
	.long 0x7f023880                                           // 000000127594: 7F023880
	s_cmp_eq_u64 s[14:15], 0                                   // 000000127598: BF10800E
	v_mov_b32_e32 v145, 0                                      // 00000012759C: 7F220280
	s_cselect_b32 s25, -1, 0                                   // 0000001275A0: 981980C1
	.long 0xd7620001                                           // 0000001275A4: D7620001
	v_cndmask_b32_e32 v0, v1, v176, vcc_lo                     // 0000001275A8: 02016101
	s_and_b32 vcc_lo, exec_lo, s25                             // 0000001275AC: 8B6A197E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001275B0: BF870091
	v_add_nc_u32_e32 v158, s27, v1                             // 0000001275B4: 4B3C021B
	v_or_b32_e32 v128, v158, v159                              // 0000001275B8: 39013F9E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001275BC: BF870001
	v_ashrrev_i32_e32 v129, 31, v128                           // 0000001275C0: 3503009F
	s_cbranch_vccnz 10                                         // 0000001275C4: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf0>
	v_mad_i64_i32 v[1:2], null, s23, v128, 0                   // 0000001275C8: D6FF7C01 02030017
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001275D0: BF870091
	.long 0xd73c0001                                           // 0000001275D4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000001275D8: 02020282
	.long 0xd7006a90                                           // 0000001275DC: D7006A90
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000001275E0: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001275E4: BF870001
	v_add_co_ci_u32_e64 v145, null, s15, v2, vcc_lo            // 0000001275E8: D5207C91 01AA040F
	s_load_b64 s[14:15], s[0:1], 0x38                          // 0000001275F0: F4040380 F8000038
	v_mov_b32_e32 v161, 0                                      // 0000001275F8: 7F420280
	s_xor_b32 s0, s25, -1                                      // 0000001275FC: 8D00C119
	s_waitcnt lgkmcnt(0)                                       // 000000127600: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v128                         // 000000127604: 7C89000E
	s_and_b32 s23, s0, vcc_lo                                  // 000000127608: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000012760C: BF870009
	s_and_saveexec_b32 s0, s23                                 // 000000127610: BE802017
	s_cbranch_execz 9                                          // 000000127614: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13c>
	.long 0xd73c0001                                           // 000000127618: D73C0001
	v_cndmask_b32_e32 v1, 2, v128, vcc_lo                      // 00000012761C: 02030082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127620: BF870091
	.long 0xd7006a01                                           // 000000127624: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 000000127628: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 00000012762C: D5207C02 01AA0415
	global_load_b32 v161, v[1:2], off                          // 000000127634: DC520000 A17C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 00000012763C: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 000000127640: BF10800C
	s_mov_b64 s[20:21], 0                                      // 000000127644: BE940180
	s_cbranch_scc1 10                                          // 000000127648: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x174>
	s_ashr_i32 s0, s22, 31                                     // 00000012764C: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 000000127650: 96810216
	s_mul_i32 s0, s0, s2                                       // 000000127654: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000127658: BF8704A9
	s_add_i32 s1, s1, s0                                       // 00000012765C: 81010001
	s_mul_i32 s0, s22, s2                                      // 000000127660: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 000000127664: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000127668: BF870009
	s_add_u32 s20, s12, s0                                     // 00000012766C: 8014000C
	s_addc_u32 s21, s13, s1                                    // 000000127670: 8215010D
	v_lshrrev_b32_e32 v1, 1, v0                                // 000000127674: 32020081
	v_mov_b32_e32 v7, 0                                        // 000000127678: 7E0E0280
	.long 0xd44c0000                                           // 00000012767C: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000127680: 020200FF 00000200
	v_dual_mov_b32 v137, 0 :: v_dual_lshlrev_b32 v0, 3, v130   // 000000127688: CA220080 89010483
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000127690: BF8701A3
	v_dual_mov_b32 v10, v7 :: v_dual_and_b32 v133, 0x1f8, v1   // 000000127694: CA240107 0A8402FF 000001F8
	v_mov_b32_e32 v8, v7                                       // 0000001276A0: 7E100307
	v_dual_mov_b32 v9, v7 :: v_dual_lshlrev_b32 v132, 1, v0    // 0000001276A4: CA220107 09840081
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001276AC: BF870003
	v_dual_mov_b32 v138, 0 :: v_dual_lshlrev_b32 v129, 1, v133 // 0000001276B0: CA220080 8A810A81
	v_dual_mov_b32 v139, 0 :: v_dual_mov_b32 v140, 0           // 0000001276B8: CA100080 8B8C0080
	scratch_store_b128 off, v[7:10], off                       // 0000001276C0: DC750000 007C0700
	s_and_saveexec_b32 s1, s0                                  // 0000001276C8: BE812000
	s_cbranch_execz 67                                         // 0000001276CC: BFA50043 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2dc>
	s_add_i32 s2, s15, -1                                      // 0000001276D0: 8102C10F
	s_ashr_i32 s25, s24, 31                                    // 0000001276D4: 86199F18
	v_min_i32_e32 v0, s2, v157                                 // 0000001276D8: 22013A02
	v_min_i32_e32 v2, s2, v159                                 // 0000001276DC: 22053E02
	s_lshl_b64 s[12:13], s[24:25], 9                           // 0000001276E0: 848C8918
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001276E4: BF870112
	v_ashrrev_i32_e32 v3, 31, v0                               // 0000001276E8: 3406009F
	v_ashrrev_i32_e32 v5, 31, v2                               // 0000001276EC: 340A049F
	.long 0xd72c0004                                           // 0000001276F0: D72C0004
	v_cndmask_b32_e32 v1, s11, v0, vcc_lo                      // 0000001276F4: 0202000B
	v_mad_u64_u32 v[0:1], null, s10, v0, 0                     // 0000001276F8: D6FE7C00 0202000A
	.long 0xd72c0008                                           // 000000127700: D72C0008
	v_cndmask_b32_e32 v1, s11, v2, vcc_lo                      // 000000127704: 0202040B
	.long 0xd72c0006                                           // 000000127708: D72C0006
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 00000012770C: 0202060A
	v_mad_u64_u32 v[2:3], null, s10, v2, 0                     // 000000127710: D6FE7C02 0202040A
	.long 0xd72c0005                                           // 000000127718: D72C0005
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 00000012771C: 02020A0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000127720: BF870113
	v_add3_u32 v1, v1, v6, v4                                  // 000000127724: D6550001 04120D01
	v_add3_u32 v3, v3, v5, v8                                  // 00000012772C: D6550003 04220B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000127734: BF870112
	.long 0xd73c0000                                           // 000000127738: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 00000012773C: 02020081
	.long 0xd73c0002                                           // 000000127740: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 000000127744: 02020481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127748: BF870092
	.long 0xd7006a00                                           // 00000012774C: D7006A00
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 000000127750: 02020006
	v_add_co_ci_u32_e64 v1, null, s7, v1, vcc_lo               // 000000127754: D5207C01 01AA0207
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012775C: BF870093
	.long 0xd7006a02                                           // 000000127760: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 000000127764: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 000000127768: D5207C03 01AA0609
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127770: BF870094
	.long 0xd7006a00                                           // 000000127774: D7006A00
	v_cndmask_b32_e32 v0, v0, v12, vcc_lo                      // 000000127778: 02001900
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 00000012777C: D5207C01 01AA020D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127784: BF870094
	.long 0xd7006a02                                           // 000000127788: D7006A02
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 00000012778C: 02001902
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000127790: D5207C03 01AA060D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127798: BF870094
	.long 0xd7006a00                                           // 00000012779C: D7006A00
	v_cndmask_b32_e32 v1, v0, v132, vcc_lo                     // 0000001277A0: 02030900
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000001277A4: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001277AC: BF870094
	.long 0xd7006a04                                           // 0000001277B0: D7006A04
	v_cndmask_b32_e32 v1, v2, v129, vcc_lo                     // 0000001277B4: 02030302
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 0000001277B8: D5207C05 01AA0680
	global_load_b128 v[0:3], v[0:1], off                       // 0000001277C0: DC5E0000 007C0000
	global_load_b128 v[137:140], v[4:5], off                   // 0000001277C8: DC5E0000 897C0004
	s_waitcnt vmcnt(1)                                         // 0000001277D0: BF8907F7
	scratch_store_b128 off, v[0:3], off                        // 0000001277D4: DC750000 007C0000
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001277DC: 8C7E017E
	.long 0xd7050000                                           // 0000001277E0: D7050000
	v_cndmask_b32_e32 v0, v157, v150, vcc_lo                   // 0000001277E4: 02012D9D
	s_or_b32 s27, s27, 31                                      // 0000001277E8: 8C1B9F1B
	s_add_i32 s1, s14, -1                                      // 0000001277EC: 8101C10E
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v5, 0               // 0000001277F0: CA100080 06040080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001277F8: BF8701C2
	.long 0xd7390000                                           // 0000001277FC: D7390000
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 000000127800: 02020088
	s_min_i32 s1, s27, s1                                      // 000000127804: 8901011B
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 000000127808: CA100080 04020080
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 000000127810: CA100080 02000080
	.long 0xd7050008                                           // 000000127818: D7050008
	v_cndmask_b32_e32 v0, v0, v140, vcc_lo                     // 00000012781C: 02011900
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v15, 0              // 000000127820: CA100080 000E0080
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 000000127828: CA100080 0E0C0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000127830: BF8701B3
	.long 0xd7040008                                           // 000000127834: D7040008
	v_cndmask_b32_e32 v1, v157, v8, vcc_lo                     // 000000127838: 0202119D
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 00000012783C: CA100080 0C0A0080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 000000127844: CA100080 0A080080
	v_dual_mov_b32 v23, 0 :: v_dual_and_b32 v16, 0xff, v8      // 00000012784C: CA240080 171010FF 000000FF
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v21, 0              // 000000127858: CA100080 08140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v19, 0             // 000000127860: CA100080 16120080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000127868: BF870243
	v_mad_u64_u32 v[141:142], null, s24, 12, v[16:17]          // 00000012786C: D6FE7C8D 04411818
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v17, 0             // 000000127874: CA100080 14100080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v31, 0             // 00000012787C: CA100080 121E0080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v29, 0             // 000000127884: CA100080 101C0080
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v32, 8, v141   // 00000012788C: CA220080 19211A88
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v27, 0             // 000000127894: CA100080 1E1A0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v39, 0             // 00000012789C: CA100080 1C260080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001278A4: BF8701B3
	v_ashrrev_i32_e32 v33, 31, v32                             // 0000001278A8: 3442409F
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v37, 0             // 0000001278AC: CA100080 1A240080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v35, 0             // 0000001278B4: CA100080 18220080
	.long 0xd73c008e                                           // 0000001278BC: D73C008E
	v_cndmask_b32_e32 v1, 1, v32, vcc_lo                       // 0000001278C0: 02024081
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v33, 0             // 0000001278C4: CA100080 26200080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v47, 0             // 0000001278CC: CA100080 242E0080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v45, 0             // 0000001278D4: CA100080 222C0080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v43, 0             // 0000001278DC: CA100080 202A0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v41, 0             // 0000001278E4: CA100080 2E280080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v55, 0             // 0000001278EC: CA100080 2C360080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v53, 0             // 0000001278F4: CA100080 2A340080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v51, 0             // 0000001278FC: CA100080 28320080
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v49, 0             // 000000127904: CA100080 36300080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v63, 0             // 00000012790C: CA100080 343E0080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v61, 0             // 000000127914: CA100080 323C0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v59, 0             // 00000012791C: CA100080 303A0080
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v57, 0             // 000000127924: CA100080 3E380080
	v_dual_mov_b32 v60, 0 :: v_dual_mov_b32 v71, 0             // 00000012792C: CA100080 3C460080
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v69, 0             // 000000127934: CA100080 3A440080
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v67, 0             // 00000012793C: CA100080 38420080
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v65, 0             // 000000127944: CA100080 46400080
	v_dual_mov_b32 v68, 0 :: v_dual_mov_b32 v79, 0             // 00000012794C: CA100080 444E0080
	v_dual_mov_b32 v66, 0 :: v_dual_mov_b32 v77, 0             // 000000127954: CA100080 424C0080
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v75, 0             // 00000012795C: CA100080 404A0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v73, 0             // 000000127964: CA100080 4E480080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v87, 0             // 00000012796C: CA100080 4C560080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v85, 0             // 000000127974: CA100080 4A540080
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v83, 0             // 00000012797C: CA100080 48520080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v81, 0             // 000000127984: CA100080 56500080
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v95, 0             // 00000012798C: CA100080 545E0080
	v_dual_mov_b32 v82, 0 :: v_dual_mov_b32 v93, 0             // 000000127994: CA100080 525C0080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v91, 0             // 00000012799C: CA100080 505A0080
	v_dual_mov_b32 v94, 0 :: v_dual_mov_b32 v89, 0             // 0000001279A4: CA100080 5E580080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v103, 0            // 0000001279AC: CA100080 5C660080
	v_dual_mov_b32 v90, 0 :: v_dual_mov_b32 v101, 0            // 0000001279B4: CA100080 5A640080
	v_dual_mov_b32 v88, 0 :: v_dual_mov_b32 v99, 0             // 0000001279BC: CA100080 58620080
	v_dual_mov_b32 v102, 0 :: v_dual_mov_b32 v97, 0            // 0000001279C4: CA100080 66600080
	v_dual_mov_b32 v100, 0 :: v_dual_mov_b32 v111, 0           // 0000001279CC: CA100080 646E0080
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v109, 0            // 0000001279D4: CA100080 626C0080
	v_dual_mov_b32 v96, 0 :: v_dual_mov_b32 v107, 0            // 0000001279DC: CA100080 606A0080
	v_dual_mov_b32 v110, 0 :: v_dual_mov_b32 v105, 0           // 0000001279E4: CA100080 6E680080
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v119, 0           // 0000001279EC: CA100080 6C760080
	v_dual_mov_b32 v106, 0 :: v_dual_mov_b32 v117, 0           // 0000001279F4: CA100080 6A740080
	v_dual_mov_b32 v104, 0 :: v_dual_mov_b32 v115, 0           // 0000001279FC: CA100080 68720080
	v_dual_mov_b32 v118, 0 :: v_dual_mov_b32 v113, 0           // 000000127A04: CA100080 76700080
	v_dual_mov_b32 v116, 0 :: v_dual_mov_b32 v127, 0           // 000000127A0C: CA100080 747E0080
	v_dual_mov_b32 v114, 0 :: v_dual_mov_b32 v125, 0           // 000000127A14: CA100080 727C0080
	v_dual_mov_b32 v112, 0 :: v_dual_mov_b32 v123, 0           // 000000127A1C: CA100080 707A0080
	v_dual_mov_b32 v126, 0 :: v_dual_mov_b32 v121, 0           // 000000127A24: CA100080 7E780080
	v_mov_b32_e32 v124, 0                                      // 000000127A2C: 7EF80280
	v_mov_b32_e32 v122, 0                                      // 000000127A30: 7EF40280
	v_mov_b32_e32 v120, 0                                      // 000000127A34: 7EF00280
	v_lshrrev_b32_e32 v162, 4, v130                            // 000000127A38: 33450484
	v_lshlrev_b32_e32 v160, 1, v159                            // 000000127A3C: 31413E81
	s_add_i32 s1, s26, s1                                      // 000000127A40: 8101011A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000127A44: BF870009
	s_cmp_lt_i32 s1, -15                                       // 000000127A48: BF04CF01
	s_cbranch_scc1 2255                                        // 000000127A4C: BFA208CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x288c>
	v_mad_i64_i32 v[0:1], null, 0x3000, v128, s[4:5]           // 000000127A50: D6FF7C00 001300FF 00003000
	s_ashr_i32 s2, s1, 31                                      // 000000127A5C: 86029F01
	v_mul_u32_u24_e32 v2, 0x210, v157                          // 000000127A60: 16053AFF 00000210
	s_lshr_b32 s2, s2, 28                                      // 000000127A68: 85029C02
	v_add3_u32 v171, v158, v130, s26                           // 000000127A6C: D65500AB 006B059E
	s_add_i32 s1, s1, s2                                       // 000000127A74: 81010201
	v_mad_u32_u24 v180, v159, 48, 0x9600                       // 000000127A78: D60B00B4 03FD619F 00009600
	s_ashr_i32 s5, s1, 4                                       // 000000127A84: 86058401
	.long 0xd7006a92                                           // 000000127A88: D7006A92
	v_cndmask_b32_e32 v1, v0, v142, vcc_lo                     // 000000127A8C: 02031D00
	s_cmp_eq_u64 s[20:21], 0                                   // 000000127A90: BF108014
	v_add_co_ci_u32_e64 v147, null, v1, v143, vcc_lo           // 000000127A94: D5207C93 01AB1F01
	v_mul_u32_u24_e32 v0, 48, v133                             // 000000127A9C: 16010AB0
	v_add3_u32 v1, v128, s26, 1                                // 000000127AA0: D6550001 02043580
	s_cselect_b32 s12, -1, 0                                   // 000000127AA8: 980C80C1
	s_cmp_lg_u64 s[20:21], 0                                   // 000000127AAC: BF118014
	v_add3_u32 v163, v2, v132, 0xc600                          // 000000127AB0: D65500A3 03FF0902 0000C600
	s_cselect_b32 s13, -1, 0                                   // 000000127ABC: 980D80C1
	s_ashr_i32 s25, s24, 31                                    // 000000127AC0: 86199F18
	v_add3_u32 v164, v0, v160, 0x9600                          // 000000127AC4: D65500A4 03FF4100 00009600
	v_ashrrev_i32_e32 v0, 31, v1                               // 000000127AD0: 3400029F
	s_lshl_b64 s[24:25], s[24:25], 9                           // 000000127AD4: 84988918
	s_add_i32 s15, s15, -1                                     // 000000127AD8: 810FC10F
	s_add_u32 s2, s6, s24                                      // 000000127ADC: 80021806
	s_movk_i32 s6, 0x440                                       // 000000127AE0: B0060440
	v_lshrrev_b32_e32 v0, 30, v0                               // 000000127AE4: 3200009E
	v_mad_u32_u24 v2, v157, s6, 0x3000                         // 000000127AE8: D60B0002 03FC0D9D 00003000
	v_mov_b32_e32 v128, 0                                      // 000000127AF4: 7F000280
	s_addc_u32 s4, s7, s25                                     // 000000127AF8: 82041907
	.long 0xd70002a5                                           // 000000127AFC: D70002A5
	v_cndmask_b32_e32 v1, s2, v132, vcc_lo                     // 000000127B00: 02030802
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000127B04: BF870243
	v_mad_u32_u24 v3, 0x44, v162, v2                           // 000000127B08: D60B0003 040B44FF 00000044
	v_add_nc_u32_e32 v0, v1, v0                                // 000000127B14: 4A000101
	v_lshlrev_b32_e32 v1, 2, v130                              // 000000127B18: 30030482
	v_dual_mov_b32 v125, v128 :: v_dual_add_nc_u32 v4, 0xed00, v131// 000000127B1C: CA200180 7D0506FF 0000ED00
	v_lshl_add_u32 v169, v159, 2, v3                           // 000000127B28: D64600A9 040D059F
	v_mov_b32_e32 v121, v128                                   // 000000127B30: 7EF20380
	s_delay_alu instid0(VALU_DEP_4)                            // 000000127B34: BF870004
	v_dual_mov_b32 v120, 0 :: v_dual_add_nc_u32 v3, v131, v1   // 000000127B38: CA200080 78020383
	v_ashrrev_i32_e32 v170, 2, v0                              // 000000127B40: 35540082
	v_dual_mov_b32 v123, v128 :: v_dual_lshlrev_b32 v0, 9, v157// 000000127B44: CA220180 7B013A89
	v_add_co_ci_u32_e64 v166, null, s4, 0, s2                  // 000000127B4C: D5207CA6 00090004
	s_add_u32 s2, s8, s24                                      // 000000127B54: 80021808
	s_mov_b32 s1, 0xc600                                       // 000000127B58: BE8100FF 0000C600
	s_addc_u32 s4, s9, s25                                     // 000000127B60: 82041909
	.long 0xd70002a7                                           // 000000127B64: D70002A7
	v_cndmask_b32_e32 v1, s2, v129, vcc_lo                     // 000000127B68: 02030202
	s_delay_alu instid0(VALU_DEP_1)                            // 000000127B6C: BF870001
	v_add_co_ci_u32_e64 v168, null, s4, 0, s2                  // 000000127B70: D5207CA8 00090004
	v_dual_mov_b32 v127, v128 :: v_dual_add_nc_u32 v172, 0xe700, v3// 000000127B78: CA200180 7FAC06FF 0000E700
	v_mad_u32_u24 v173, 0x44, v130, v2                         // 000000127B84: D60B00AD 040B04FF 00000044
	v_lshl_add_u32 v174, v130, 5, v0                           // 000000127B90: D64600AE 04010B82
	v_dual_mov_b32 v122, v128 :: v_dual_add_nc_u32 v175, 0xf300, v3// 000000127B98: CA200180 7AAE06FF 0000F300
	v_add_nc_u32_e32 v176, v4, v1                              // 000000127BA4: 4B600304
	v_lshl_or_b32 v177, v162, 2, v4                            // 000000127BA8: D65600B1 041105A2
	v_lshl_or_b32 v178, v159, 5, v0                            // 000000127BB0: D65600B2 04010B9F
	v_mov_b32_e32 v124, v128                                   // 000000127BB8: 7EF80380
	v_mov_b32_e32 v126, v128                                   // 000000127BBC: 7EFC0380
	v_dual_mov_b32 v112, 0 :: v_dual_mov_b32 v113, v128        // 000000127BC0: CA100080 70700180
	v_mov_b32_e32 v114, v128                                   // 000000127BC8: 7EE40380
	v_dual_mov_b32 v115, v128 :: v_dual_mov_b32 v104, 0        // 000000127BCC: CA100180 73680080
	v_mov_b32_e32 v116, v128                                   // 000000127BD4: 7EE80380
	v_dual_mov_b32 v117, v128 :: v_dual_mov_b32 v96, 0         // 000000127BD8: CA100180 75600080
	v_mov_b32_e32 v118, v128                                   // 000000127BE0: 7EEC0380
	v_dual_mov_b32 v119, v128 :: v_dual_mov_b32 v88, 0         // 000000127BE4: CA100180 77580080
	v_dual_mov_b32 v105, v128 :: v_dual_mov_b32 v80, 0         // 000000127BEC: CA100180 69500080
	v_mov_b32_e32 v106, v128                                   // 000000127BF4: 7ED40380
	v_dual_mov_b32 v107, v128 :: v_dual_mov_b32 v72, 0         // 000000127BF8: CA100180 6B480080
	v_mov_b32_e32 v108, v128                                   // 000000127C00: 7ED80380
	v_dual_mov_b32 v109, v128 :: v_dual_mov_b32 v64, 0         // 000000127C04: CA100180 6D400080
	v_mov_b32_e32 v110, v128                                   // 000000127C0C: 7EDC0380
	v_dual_mov_b32 v111, v128 :: v_dual_mov_b32 v56, 0         // 000000127C10: CA100180 6F380080
	v_dual_mov_b32 v97, v128 :: v_dual_mov_b32 v48, 0          // 000000127C18: CA100180 61300080
	v_mov_b32_e32 v98, v128                                    // 000000127C20: 7EC40380
	v_dual_mov_b32 v99, v128 :: v_dual_mov_b32 v40, 0          // 000000127C24: CA100180 63280080
	v_mov_b32_e32 v100, v128                                   // 000000127C2C: 7EC80380
	v_dual_mov_b32 v101, v128 :: v_dual_mov_b32 v32, 0         // 000000127C30: CA100180 65200080
	v_mov_b32_e32 v102, v128                                   // 000000127C38: 7ECC0380
	v_dual_mov_b32 v103, v128 :: v_dual_mov_b32 v24, 0         // 000000127C3C: CA100180 67180080
	v_dual_mov_b32 v89, v128 :: v_dual_mov_b32 v16, 0          // 000000127C44: CA100180 59100080
	v_mov_b32_e32 v90, v128                                    // 000000127C4C: 7EB40380
	v_dual_mov_b32 v91, v128 :: v_dual_mov_b32 v8, 0           // 000000127C50: CA100180 5B080080
	v_mov_b32_e32 v92, v128                                    // 000000127C58: 7EB80380
	v_dual_mov_b32 v93, v128 :: v_dual_mov_b32 v0, 0           // 000000127C5C: CA100180 5D000080
	v_mov_b32_e32 v94, v128                                    // 000000127C64: 7EBC0380
	v_dual_mov_b32 v95, v128 :: v_dual_mov_b32 v148, 0         // 000000127C68: CA100180 5F940080
	v_mov_b32_e32 v81, v128                                    // 000000127C70: 7EA20380
	v_mov_b32_e32 v82, v128                                    // 000000127C74: 7EA40380
	v_mov_b32_e32 v83, v128                                    // 000000127C78: 7EA60380
	v_mov_b32_e32 v84, v128                                    // 000000127C7C: 7EA80380
	v_mov_b32_e32 v85, v128                                    // 000000127C80: 7EAA0380
	v_mov_b32_e32 v86, v128                                    // 000000127C84: 7EAC0380
	v_mov_b32_e32 v87, v128                                    // 000000127C88: 7EAE0380
	v_mov_b32_e32 v73, v128                                    // 000000127C8C: 7E920380
	v_mov_b32_e32 v74, v128                                    // 000000127C90: 7E940380
	v_mov_b32_e32 v75, v128                                    // 000000127C94: 7E960380
	v_mov_b32_e32 v76, v128                                    // 000000127C98: 7E980380
	v_mov_b32_e32 v77, v128                                    // 000000127C9C: 7E9A0380
	v_mov_b32_e32 v78, v128                                    // 000000127CA0: 7E9C0380
	v_mov_b32_e32 v79, v128                                    // 000000127CA4: 7E9E0380
	v_mov_b32_e32 v65, v128                                    // 000000127CA8: 7E820380
	v_mov_b32_e32 v66, v128                                    // 000000127CAC: 7E840380
	v_mov_b32_e32 v67, v128                                    // 000000127CB0: 7E860380
	v_mov_b32_e32 v68, v128                                    // 000000127CB4: 7E880380
	v_mov_b32_e32 v69, v128                                    // 000000127CB8: 7E8A0380
	v_mov_b32_e32 v70, v128                                    // 000000127CBC: 7E8C0380
	v_mov_b32_e32 v71, v128                                    // 000000127CC0: 7E8E0380
	v_mov_b32_e32 v57, v128                                    // 000000127CC4: 7E720380
	v_mov_b32_e32 v58, v128                                    // 000000127CC8: 7E740380
	v_mov_b32_e32 v59, v128                                    // 000000127CCC: 7E760380
	v_mov_b32_e32 v60, v128                                    // 000000127CD0: 7E780380
	v_mov_b32_e32 v61, v128                                    // 000000127CD4: 7E7A0380
	v_mov_b32_e32 v62, v128                                    // 000000127CD8: 7E7C0380
	v_mov_b32_e32 v63, v128                                    // 000000127CDC: 7E7E0380
	v_mov_b32_e32 v49, v128                                    // 000000127CE0: 7E620380
	v_mov_b32_e32 v50, v128                                    // 000000127CE4: 7E640380
	v_mov_b32_e32 v51, v128                                    // 000000127CE8: 7E660380
	v_mov_b32_e32 v52, v128                                    // 000000127CEC: 7E680380
	v_mov_b32_e32 v53, v128                                    // 000000127CF0: 7E6A0380
	v_mov_b32_e32 v54, v128                                    // 000000127CF4: 7E6C0380
	v_mov_b32_e32 v55, v128                                    // 000000127CF8: 7E6E0380
	v_mov_b32_e32 v41, v128                                    // 000000127CFC: 7E520380
	v_mov_b32_e32 v42, v128                                    // 000000127D00: 7E540380
	v_mov_b32_e32 v43, v128                                    // 000000127D04: 7E560380
	v_mov_b32_e32 v44, v128                                    // 000000127D08: 7E580380
	v_mov_b32_e32 v45, v128                                    // 000000127D0C: 7E5A0380
	v_mov_b32_e32 v46, v128                                    // 000000127D10: 7E5C0380
	v_mov_b32_e32 v47, v128                                    // 000000127D14: 7E5E0380
	v_mov_b32_e32 v33, v128                                    // 000000127D18: 7E420380
	v_mov_b32_e32 v34, v128                                    // 000000127D1C: 7E440380
	v_mov_b32_e32 v35, v128                                    // 000000127D20: 7E460380
	v_mov_b32_e32 v36, v128                                    // 000000127D24: 7E480380
	v_mov_b32_e32 v37, v128                                    // 000000127D28: 7E4A0380
	v_mov_b32_e32 v38, v128                                    // 000000127D2C: 7E4C0380
	v_mov_b32_e32 v39, v128                                    // 000000127D30: 7E4E0380
	v_mov_b32_e32 v25, v128                                    // 000000127D34: 7E320380
	v_mov_b32_e32 v26, v128                                    // 000000127D38: 7E340380
	v_mov_b32_e32 v27, v128                                    // 000000127D3C: 7E360380
	v_mov_b32_e32 v28, v128                                    // 000000127D40: 7E380380
	v_mov_b32_e32 v29, v128                                    // 000000127D44: 7E3A0380
	v_mov_b32_e32 v30, v128                                    // 000000127D48: 7E3C0380
	v_mov_b32_e32 v31, v128                                    // 000000127D4C: 7E3E0380
	v_mov_b32_e32 v17, v128                                    // 000000127D50: 7E220380
	v_mov_b32_e32 v18, v128                                    // 000000127D54: 7E240380
	v_mov_b32_e32 v19, v128                                    // 000000127D58: 7E260380
	v_mov_b32_e32 v20, v128                                    // 000000127D5C: 7E280380
	v_mov_b32_e32 v21, v128                                    // 000000127D60: 7E2A0380
	v_mov_b32_e32 v22, v128                                    // 000000127D64: 7E2C0380
	v_mov_b32_e32 v23, v128                                    // 000000127D68: 7E2E0380
	v_mov_b32_e32 v9, v128                                     // 000000127D6C: 7E120380
	v_mov_b32_e32 v10, v128                                    // 000000127D70: 7E140380
	v_mov_b32_e32 v11, v128                                    // 000000127D74: 7E160380
	v_mov_b32_e32 v12, v128                                    // 000000127D78: 7E180380
	v_mov_b32_e32 v13, v128                                    // 000000127D7C: 7E1A0380
	v_mov_b32_e32 v14, v128                                    // 000000127D80: 7E1C0380
	v_mov_b32_e32 v15, v128                                    // 000000127D84: 7E1E0380
	v_mov_b32_e32 v1, v128                                     // 000000127D88: 7E020380
	v_mov_b32_e32 v2, v128                                     // 000000127D8C: 7E040380
	v_mov_b32_e32 v3, v128                                     // 000000127D90: 7E060380
	v_mov_b32_e32 v4, v128                                     // 000000127D94: 7E080380
	v_mov_b32_e32 v5, v128                                     // 000000127D98: 7E0A0380
	v_mov_b32_e32 v6, v128                                     // 000000127D9C: 7E0C0380
	v_mov_b32_e32 v7, v128                                     // 000000127DA0: 7E0E0380
	v_mad_u32_u24 v179, 0x210, v159, s1                        // 000000127DA4: D60B00B3 00073EFF 00000210
	s_mov_b32 s6, 0                                            // 000000127DB0: BE860080
	s_branch 116                                               // 000000127DB4: BFA00074 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa88>
	ds_load_b128 v[149:152], v180                              // 000000127DB8: DBFC0000 950000B4
	ds_load_b128 v[153:156], v180 offset:16                    // 000000127DC0: DBFC0010 990000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127DC8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[120:127], v[129:136], v[149:156], v[120:127]// 000000127DCC: CC414078 1DE32B81
	ds_load_b128 v[153:156], v180 offset:784                   // 000000127DD4: DBFC0310 990000B4
	ds_load_b128 v[149:152], v180 offset:768                   // 000000127DDC: DBFC0300 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127DE4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[112:119], v[129:136], v[149:156], v[112:119]// 000000127DE8: CC414070 1DC32B81
	ds_load_b128 v[153:156], v180 offset:1552                  // 000000127DF0: DBFC0610 990000B4
	ds_load_b128 v[149:152], v180 offset:1536                  // 000000127DF8: DBFC0600 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127E00: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[104:111], v[129:136], v[149:156], v[104:111]// 000000127E04: CC414068 1DA32B81
	ds_load_b128 v[153:156], v180 offset:2320                  // 000000127E0C: DBFC0910 990000B4
	ds_load_b128 v[149:152], v180 offset:2304                  // 000000127E14: DBFC0900 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127E1C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[96:103], v[129:136], v[149:156], v[96:103]// 000000127E20: CC414060 1D832B81
	ds_load_b128 v[153:156], v180 offset:3088                  // 000000127E28: DBFC0C10 990000B4
	ds_load_b128 v[149:152], v180 offset:3072                  // 000000127E30: DBFC0C00 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127E38: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[88:95], v[129:136], v[149:156], v[88:95]// 000000127E3C: CC414058 1D632B81
	ds_load_b128 v[153:156], v180 offset:3856                  // 000000127E44: DBFC0F10 990000B4
	ds_load_b128 v[149:152], v180 offset:3840                  // 000000127E4C: DBFC0F00 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127E54: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[80:87], v[129:136], v[149:156], v[80:87]// 000000127E58: CC414050 1D432B81
	ds_load_b128 v[153:156], v180 offset:4624                  // 000000127E60: DBFC1210 990000B4
	ds_load_b128 v[149:152], v180 offset:4608                  // 000000127E68: DBFC1200 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127E70: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[72:79], v[129:136], v[149:156], v[72:79]// 000000127E74: CC414048 1D232B81
	ds_load_b128 v[153:156], v180 offset:5392                  // 000000127E7C: DBFC1510 990000B4
	ds_load_b128 v[149:152], v180 offset:5376                  // 000000127E84: DBFC1500 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127E8C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[64:71], v[129:136], v[149:156], v[64:71]// 000000127E90: CC414040 1D032B81
	ds_load_b128 v[153:156], v180 offset:6160                  // 000000127E98: DBFC1810 990000B4
	ds_load_b128 v[149:152], v180 offset:6144                  // 000000127EA0: DBFC1800 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127EA8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[56:63], v[129:136], v[149:156], v[56:63]// 000000127EAC: CC414038 1CE32B81
	ds_load_b128 v[153:156], v180 offset:6928                  // 000000127EB4: DBFC1B10 990000B4
	ds_load_b128 v[149:152], v180 offset:6912                  // 000000127EBC: DBFC1B00 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127EC4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[48:55], v[129:136], v[149:156], v[48:55]// 000000127EC8: CC414030 1CC32B81
	ds_load_b128 v[153:156], v180 offset:7696                  // 000000127ED0: DBFC1E10 990000B4
	ds_load_b128 v[149:152], v180 offset:7680                  // 000000127ED8: DBFC1E00 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127EE0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[40:47], v[129:136], v[149:156], v[40:47]// 000000127EE4: CC414028 1CA32B81
	ds_load_b128 v[153:156], v180 offset:8464                  // 000000127EEC: DBFC2110 990000B4
	ds_load_b128 v[149:152], v180 offset:8448                  // 000000127EF4: DBFC2100 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127EFC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[32:39], v[129:136], v[149:156], v[32:39]// 000000127F00: CC414020 1C832B81
	ds_load_b128 v[153:156], v180 offset:9232                  // 000000127F08: DBFC2410 990000B4
	ds_load_b128 v[149:152], v180 offset:9216                  // 000000127F10: DBFC2400 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127F18: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[24:31], v[129:136], v[149:156], v[24:31]// 000000127F1C: CC414018 1C632B81
	ds_load_b128 v[153:156], v180 offset:10000                 // 000000127F24: DBFC2710 990000B4
	ds_load_b128 v[149:152], v180 offset:9984                  // 000000127F2C: DBFC2700 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127F34: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[16:23], v[129:136], v[149:156], v[16:23]// 000000127F38: CC414010 1C432B81
	ds_load_b128 v[153:156], v180 offset:10768                 // 000000127F40: DBFC2A10 990000B4
	ds_load_b128 v[149:152], v180 offset:10752                 // 000000127F48: DBFC2A00 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127F50: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[8:15], v[129:136], v[149:156], v[8:15]// 000000127F54: CC414008 1C232B81
	ds_load_b128 v[153:156], v180 offset:11536                 // 000000127F5C: DBFC2D10 990000B4
	ds_load_b128 v[149:152], v180 offset:11520                 // 000000127F64: DBFC2D00 950000B4
	s_waitcnt lgkmcnt(0)                                       // 000000127F6C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[0:7], v[129:136], v[149:156], v[0:7]// 000000127F70: CC414000 1C032B81
	s_add_i32 s1, s6, 1                                        // 000000127F78: 81018106
	s_cmp_eq_u32 s6, s5                                        // 000000127F7C: BF060506
	s_mov_b32 s6, s1                                           // 000000127F80: BE860001
	s_cbranch_scc1 1921                                        // 000000127F84: BFA20781 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x288c>
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 000000127F88: 916A0D7E
	s_mov_b32 s1, s12                                          // 000000127F8C: BE81000C
	s_cbranch_vccz 3                                           // 000000127F90: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaa0>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000127F94: 916A017E
	s_cbranch_vccnz 65527                                      // 000000127F98: BFA4FFF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa78>
	s_branch 15                                                // 000000127F9C: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xadc>
	s_lshr_b32 s1, s6, 3                                       // 000000127FA0: 85018306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000127FA4: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 000000127FA8: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v129, s1                                     // 000000127FB0: 7F020201
	global_load_b32 v129, v129, s[20:21]                       // 000000127FB4: DC520000 81140081
	s_waitcnt vmcnt(0)                                         // 000000127FBC: BF8903F7
	v_lshrrev_b32_e32 v129, s6, v129                           // 000000127FC0: 33030206
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000127FC4: BF870091
	v_and_b32_e32 v129, 1, v129                                // 000000127FC8: 37030281
	.long 0xd44a0001                                           // 000000127FCC: D44A0001
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 000000127FD0: 02030281
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 000000127FD4: 916A017E
	s_cbranch_vccnz 65511                                      // 000000127FD8: BFA4FFE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa78>
	s_lshl_b32 s2, s6, 4                                       // 000000127FDC: 84028406
	s_waitcnt vmcnt(0)                                         // 000000127FE0: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 000000127FE4: BC7C0000
	s_barrier                                                  // 000000127FE8: BFBD0000
	buffer_gl0_inv                                             // 000000127FEC: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 000000127FF4: BE812000
	s_cbranch_execz 72                                         // 000000127FF8: BFA50048 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc1c>
	scratch_load_b128 v[129:132], off, off                     // 000000127FFC: DC5D0000 817C0000
	s_cmp_ge_i32 s6, s5                                        // 000000128004: BF030506
	s_waitcnt vmcnt(0)                                         // 000000128008: BF8903F7
	ds_store_b128 v163, v[129:132]                             // 00000012800C: DB7C0000 000081A3
	ds_store_b16 v164, v137                                    // 000000128014: D87C0000 000089A4
	ds_store_b16_d16_hi v164, v137 offset:48                   // 00000012801C: DA840030 000089A4
	ds_store_b16 v164, v138 offset:96                          // 000000128024: D87C0060 00008AA4
	ds_store_b16_d16_hi v164, v138 offset:144                  // 00000012802C: DA840090 00008AA4
	ds_store_b16 v164, v139 offset:192                         // 000000128034: D87C00C0 00008BA4
	ds_store_b16_d16_hi v164, v139 offset:240                  // 00000012803C: DA8400F0 00008BA4
	ds_store_b16 v164, v140 offset:288                         // 000000128044: D87C0120 00008CA4
	ds_store_b16_d16_hi v164, v140 offset:336                  // 00000012804C: DA840150 00008CA4
	s_cbranch_scc1 49                                          // 000000128054: BFA20031 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc1c>
	s_add_i32 s4, s2, 16                                       // 000000128058: 81049002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012805C: BF870129
	v_or_b32_e32 v129, s4, v157                                // 000000128060: 39033A04
	v_or_b32_e32 v130, s4, v159                                // 000000128064: 39053E04
	v_min_i32_e32 v129, s15, v129                              // 000000128068: 2303020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012806C: BF870112
	v_min_i32_e32 v131, s15, v130                              // 000000128070: 2307040F
	v_ashrrev_i32_e32 v132, 31, v129                           // 000000128074: 3509029F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000128078: BF870002
	v_ashrrev_i32_e32 v134, 31, v131                           // 00000012807C: 350D069F
	.long 0xd72c0085                                           // 000000128080: D72C0085
	v_cndmask_b32_e32 v1, s11, v129, vcc_lo                    // 000000128084: 0203020B
	v_mad_u64_u32 v[129:130], null, s10, v129, 0               // 000000128088: D6FE7C81 0203020A
	.long 0xd72c0088                                           // 000000128090: D72C0088
	v_cndmask_b32_e32 v1, s11, v131, vcc_lo                    // 000000128094: 0203060B
	.long 0xd72c0087                                           // 000000128098: D72C0087
	v_cndmask_b32_e32 v1, s10, v132, vcc_lo                    // 00000012809C: 0203080A
	v_mad_u64_u32 v[131:132], null, s10, v131, 0               // 0000001280A0: D6FE7C83 0203060A
	.long 0xd72c0086                                           // 0000001280A8: D72C0086
	v_cndmask_b32_e32 v1, s10, v134, vcc_lo                    // 0000001280AC: 02030C0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001280B0: BF870113
	v_add3_u32 v130, v130, v135, v133                          // 0000001280B4: D6550082 06170F82
	v_add3_u32 v132, v132, v134, v136                          // 0000001280BC: D6550084 06230D84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001280C4: BF870112
	.long 0xd73c0081                                           // 0000001280C8: D73C0081
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000001280CC: 02030281
	.long 0xd73c0083                                           // 0000001280D0: D73C0083
	v_cndmask_b32_e32 v1, 1, v131, vcc_lo                      // 0000001280D4: 02030681
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001280D8: BF870092
	.long 0xd7006a81                                           // 0000001280DC: D7006A81
	v_cndmask_b32_e32 v1, v165, v129, vcc_lo                   // 0000001280E0: 020303A5
	v_add_co_ci_u32_e64 v130, null, v166, v130, vcc_lo         // 0000001280E4: D5207C82 01AB05A6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001280EC: BF870093
	.long 0xd7006a85                                           // 0000001280F0: D7006A85
	v_cndmask_b32_e32 v1, v167, v131, vcc_lo                   // 0000001280F4: 020307A7
	v_add_co_ci_u32_e64 v134, null, v168, v132, vcc_lo         // 0000001280F8: D5207C86 01AB09A8
	global_load_b128 v[129:132], v[129:130], off               // 000000128100: DC5E0000 817C0081
	global_load_b128 v[137:140], v[133:134], off               // 000000128108: DC5E0000 897C0085
	s_waitcnt vmcnt(1)                                         // 000000128110: BF8907F7
	scratch_store_b128 off, v[129:132], off                    // 000000128114: DC750000 007C8100
	s_or_b32 exec_lo, exec_lo, s1                              // 00000012811C: 8C7E017E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000128120: BF890007
	s_waitcnt_vscnt null, 0x0                                  // 000000128124: BC7C0000
	s_barrier                                                  // 000000128128: BFBD0000
	buffer_gl0_inv                                             // 00000012812C: E0AC0000 00000000
	s_clause 0x1                                               // 000000128134: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:16     // 000000128138: DC5E0010 997C0092
	global_load_b128 v[149:152], v[146:147], off               // 000000128140: DC5E0000 957C0092
	ds_load_b128 v[181:184], v179                              // 000000128148: DBFC0000 B50000B3
	ds_load_b128 v[185:188], v179 offset:16                    // 000000128150: DBFC0010 B90000B3
	v_mov_b32_e32 v135, v128                                   // 000000128158: 7F0E0380
	v_mov_b32_e32 v129, v128                                   // 00000012815C: 7F020380
	v_mov_b32_e32 v130, v128                                   // 000000128160: 7F040380
	v_mov_b32_e32 v131, v128                                   // 000000128164: 7F060380
	v_mov_b32_e32 v132, v128                                   // 000000128168: 7F080380
	v_mov_b32_e32 v133, v128                                   // 00000012816C: 7F0A0380
	v_mov_b32_e32 v134, v128                                   // 000000128170: 7F0C0380
	v_mov_b32_e32 v136, v135                                   // 000000128174: 7F100387
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000128178: BF870212
	v_mov_b32_e32 v135, v134                                   // 00000012817C: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 000000128180: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 000000128184: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 000000128188: 7F080383
	v_mov_b32_e32 v131, v130                                   // 00000012818C: 7F060382
	v_mov_b32_e32 v130, v129                                   // 000000128190: 7F040381
	v_mov_b32_e32 v129, v128                                   // 000000128194: 7F020380
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000128198: BF890007
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012819C: BF870001
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000001281A0: CC414081 1E076B95
	s_clause 0x1                                               // 0000001281A8: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:48     // 0000001281AC: DC5E0030 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:32     // 0000001281B4: DC5E0020 957C0092
	ds_load_b128 v[181:184], v179 offset:32                    // 0000001281BC: DBFC0020 B50000B3
	ds_load_b128 v[185:188], v179 offset:48                    // 0000001281C4: DBFC0030 B90000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001281CC: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000001281D0: CC414081 1E076B95
	s_clause 0x1                                               // 0000001281D8: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:80     // 0000001281DC: DC5E0050 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:64     // 0000001281E4: DC5E0040 957C0092
	ds_load_b128 v[185:188], v179 offset:80                    // 0000001281EC: DBFC0050 B90000B3
	ds_load_b128 v[181:184], v179 offset:64                    // 0000001281F4: DBFC0040 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001281FC: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 000000128200: CC414081 1E076B95
	s_clause 0x1                                               // 000000128208: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:112    // 00000012820C: DC5E0070 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:96     // 000000128214: DC5E0060 957C0092
	ds_load_b128 v[185:188], v179 offset:112                   // 00000012821C: DBFC0070 B90000B3
	ds_load_b128 v[181:184], v179 offset:96                    // 000000128224: DBFC0060 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012822C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 000000128230: CC414081 1E076B95
	s_clause 0x1                                               // 000000128238: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:144    // 00000012823C: DC5E0090 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:128    // 000000128244: DC5E0080 957C0092
	ds_load_b128 v[185:188], v179 offset:144                   // 00000012824C: DBFC0090 B90000B3
	ds_load_b128 v[181:184], v179 offset:128                   // 000000128254: DBFC0080 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012825C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 000000128260: CC414081 1E076B95
	s_clause 0x1                                               // 000000128268: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:176    // 00000012826C: DC5E00B0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:160    // 000000128274: DC5E00A0 957C0092
	ds_load_b128 v[185:188], v179 offset:176                   // 00000012827C: DBFC00B0 B90000B3
	ds_load_b128 v[181:184], v179 offset:160                   // 000000128284: DBFC00A0 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012828C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 000000128290: CC414081 1E076B95
	s_clause 0x1                                               // 000000128298: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:208    // 00000012829C: DC5E00D0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:192    // 0000001282A4: DC5E00C0 957C0092
	ds_load_b128 v[185:188], v179 offset:208                   // 0000001282AC: DBFC00D0 B90000B3
	ds_load_b128 v[181:184], v179 offset:192                   // 0000001282B4: DBFC00C0 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001282BC: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000001282C0: CC414081 1E076B95
	s_clause 0x1                                               // 0000001282C8: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:240    // 0000001282CC: DC5E00F0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:224    // 0000001282D4: DC5E00E0 957C0092
	ds_load_b128 v[185:188], v179 offset:240                   // 0000001282DC: DBFC00F0 B90000B3
	ds_load_b128 v[181:184], v179 offset:224                   // 0000001282E4: DBFC00E0 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001282EC: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000001282F0: CC414081 1E076B95
	s_clause 0x1                                               // 0000001282F8: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:272    // 0000001282FC: DC5E0110 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:256    // 000000128304: DC5E0100 957C0092
	ds_load_b128 v[185:188], v179 offset:272                   // 00000012830C: DBFC0110 B90000B3
	ds_load_b128 v[181:184], v179 offset:256                   // 000000128314: DBFC0100 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012831C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 000000128320: CC414081 1E076B95
	s_clause 0x1                                               // 000000128328: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:304    // 00000012832C: DC5E0130 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:288    // 000000128334: DC5E0120 957C0092
	ds_load_b128 v[185:188], v179 offset:304                   // 00000012833C: DBFC0130 B90000B3
	ds_load_b128 v[181:184], v179 offset:288                   // 000000128344: DBFC0120 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012834C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 000000128350: CC414081 1E076B95
	s_clause 0x1                                               // 000000128358: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:336    // 00000012835C: DC5E0150 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:320    // 000000128364: DC5E0140 957C0092
	ds_load_b128 v[185:188], v179 offset:336                   // 00000012836C: DBFC0150 B90000B3
	ds_load_b128 v[181:184], v179 offset:320                   // 000000128374: DBFC0140 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012837C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 000000128380: CC414081 1E076B95
	s_clause 0x1                                               // 000000128388: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:368    // 00000012838C: DC5E0170 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:352    // 000000128394: DC5E0160 957C0092
	ds_load_b128 v[185:188], v179 offset:368                   // 00000012839C: DBFC0170 B90000B3
	ds_load_b128 v[181:184], v179 offset:352                   // 0000001283A4: DBFC0160 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001283AC: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000001283B0: CC414081 1E076B95
	s_clause 0x1                                               // 0000001283B8: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:400    // 0000001283BC: DC5E0190 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:384    // 0000001283C4: DC5E0180 957C0092
	ds_load_b128 v[185:188], v179 offset:400                   // 0000001283CC: DBFC0190 B90000B3
	ds_load_b128 v[181:184], v179 offset:384                   // 0000001283D4: DBFC0180 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001283DC: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 0000001283E0: CC414081 1E076B95
	s_clause 0x1                                               // 0000001283E8: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:432    // 0000001283EC: DC5E01B0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:416    // 0000001283F4: DC5E01A0 957C0092
	ds_load_b128 v[185:188], v179 offset:432                   // 0000001283FC: DBFC01B0 B90000B3
	ds_load_b128 v[181:184], v179 offset:416                   // 000000128404: DBFC01A0 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012840C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 000000128410: CC414081 1E076B95
	s_clause 0x1                                               // 000000128418: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:464    // 00000012841C: DC5E01D0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:448    // 000000128424: DC5E01C0 957C0092
	ds_load_b128 v[185:188], v179 offset:464                   // 00000012842C: DBFC01D0 B90000B3
	ds_load_b128 v[181:184], v179 offset:448                   // 000000128434: DBFC01C0 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012843C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 000000128440: CC414081 1E076B95
	s_clause 0x1                                               // 000000128448: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:496    // 00000012844C: DC5E01F0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:480    // 000000128454: DC5E01E0 957C0092
	ds_load_b128 v[185:188], v179 offset:496                   // 00000012845C: DBFC01F0 B90000B3
	ds_load_b128 v[181:184], v179 offset:480                   // 000000128464: DBFC01E0 B50000B3
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012846C: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[181:188], v[129:136]// 000000128470: CC414081 1E076B95
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128478: BF870111
	v_dual_mul_f32 v129, 0x3d800000, v129 :: v_dual_mul_f32 v130, 0x3d800000, v130// 00000012847C: C8C702FF 818304FF 3D800000
	v_mul_f32_e32 v149, 0x3d800000, v132                       // 000000128488: 112B08FF 3D800000
	v_mov_b32_e32 v132, 0xffff                                 // 000000128490: 7F0802FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000128498: BF870004
	v_mul_f32_e32 v131, 0x3d800000, v131                       // 00000012849C: 110706FF 3D800000
	v_dual_mul_f32 v133, 0x3d800000, v133 :: v_dual_mul_f32 v134, 0x3d800000, v134// 0000001284A4: C8C70AFF 85870CFF 3D800000
	v_dual_mul_f32 v135, 0x3d800000, v135 :: v_dual_mul_f32 v136, 0x3d800000, v136// 0000001284B0: C8C70EFF 878910FF 3D800000
	ds_store_2addr_b32 v169, v129, v130 offset1:34             // 0000001284BC: D8382200 008281A9
	ds_store_2addr_b32 v169, v131, v149 offset0:68 offset1:102 // 0000001284C4: D8386644 009583A9
	ds_store_2addr_b32 v169, v133, v134 offset0:136 offset1:170// 0000001284CC: D838AA88 008685A9
	ds_store_2addr_b32 v169, v135, v136 offset0:204 offset1:238// 0000001284D4: D838EECC 008887A9
	s_and_saveexec_b32 s4, s23                                 // 0000001284DC: BE842017
	s_cbranch_execz 363                                        // 0000001284E0: BFA5016B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1590>
	s_lshl_b32 s7, s6, 2                                       // 0000001284E4: 84078206
	s_mov_b32 s8, exec_lo                                      // 0000001284E8: BE88007E
	.long 0xd4c1007e                                           // 0000001284EC: D4C1007E
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 0000001284F0: 02034394
	s_cbranch_execz 48                                         // 0000001284F4: BFA50030 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10b8>
	v_ashrrev_i32_e32 v149, 31, v148                           // 0000001284F8: 352B289F
	s_mov_b32 s9, 0                                            // 0000001284FC: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128500: BF870091
	.long 0xd73c0081                                           // 000000128504: D73C0081
	v_cndmask_b32_e32 v1, 2, v148, vcc_lo                      // 000000128508: 02032882
	.long 0xd7006a81                                           // 00000012850C: D7006A81
	v_cndmask_b32_e32 v1, v144, v129, vcc_lo                   // 000000128510: 02030390
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128514: BF870001
	v_add_co_ci_u32_e64 v130, null, v145, v130, vcc_lo         // 000000128518: D5207C82 01AB0591
	s_branch 15                                                // 000000128520: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1060>
	s_nop 0                                                    // 000000128524: BF800000
	s_nop 0                                                    // 000000128528: BF800000
	s_nop 0                                                    // 00000012852C: BF800000
	s_nop 0                                                    // 000000128530: BF800000
	s_nop 0                                                    // 000000128534: BF800000
	s_nop 0                                                    // 000000128538: BF800000
	s_nop 0                                                    // 00000012853C: BF800000
	s_or_b32 exec_lo, exec_lo, s24                             // 000000128540: 8C7E187E
	v_mov_b32_e32 v132, v148                                   // 000000128544: 7F080394
	v_mov_b32_e32 v148, v131                                   // 000000128548: 7F280383
	s_and_b32 s1, exec_lo, s22                                 // 00000012854C: 8B01167E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000128550: BF870499
	s_or_b32 s9, s1, s9                                        // 000000128554: 8C090901
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 000000128558: 917E097E
	s_cbranch_execz 20                                         // 00000012855C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10b0>
	global_load_b32 v131, v[129:130], off                      // 000000128560: DC520000 837C0081
	s_or_b32 s22, s22, exec_lo                                 // 000000128568: 8C167E16
	s_waitcnt vmcnt(0)                                         // 00000012856C: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s7, v131                          // 000000128570: 7C890607
	s_and_saveexec_b32 s24, vcc_lo                             // 000000128574: BE98206A
	s_cbranch_execz 65521                                      // 000000128578: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	v_dual_mov_b32 v148, v161 :: v_dual_add_nc_u32 v131, 1, v148// 00000012857C: CA2001A1 94832881
	.long 0xd7000181                                           // 000000128584: D7000181
	v_cndmask_b32_e32 v0, v129, v132, vcc_lo                   // 000000128588: 02010981
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012858C: BF870191
	v_add_co_ci_u32_e64 v130, null, 0, v130, s1                // 000000128590: D5207C82 00070480
	v_cmp_eq_u32_e32 vcc_lo, v161, v131                        // 000000128598: 7C9507A1
	s_and_not1_b32 s1, s22, exec_lo                            // 00000012859C: 91017E16
	s_and_b32 s22, vcc_lo, exec_lo                             // 0000001285A0: 8B167E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001285A4: BF870009
	s_or_b32 s22, s1, s22                                      // 0000001285A8: 8C161601
	s_branch 65508                                             // 0000001285AC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	s_or_b32 exec_lo, exec_lo, s9                              // 0000001285B0: 8C7E097E
	v_mov_b32_e32 v148, v132                                   // 0000001285B4: 7F280384
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001285B8: 8C7E087E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001285BC: BF870001
	v_dual_mov_b32 v132, 15 :: v_dual_mov_b32 v129, v148       // 0000001285C0: CA10008F 84800194
	s_mov_b32 s1, exec_lo                                      // 0000001285C8: BE81007E
	.long 0xd4c1007e                                           // 0000001285CC: D4C1007E
	v_cndmask_b32_e32 v1, s7, v170, vcc_lo                     // 0000001285D0: 02035407
	s_cbranch_execz 62                                         // 0000001285D4: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11d0>
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v129, v148        // 0000001285D8: CA100080 84800194
	s_mov_b32 s8, exec_lo                                      // 0000001285E0: BE88007E
	.long 0xd4c1007e                                           // 0000001285E4: D4C1007E
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 0000001285E8: 02034394
	s_cbranch_execz 54                                         // 0000001285EC: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11c8>
	v_mov_b32_e32 v129, v148                                   // 0000001285F0: 7F020394
	s_mov_b32 s22, 0                                           // 0000001285F4: BE960080
	s_set_inst_prefetch_distance 0x1                           // 0000001285F8: BF840001
	s_branch 10                                                // 0000001285FC: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1128>
	s_or_b32 exec_lo, exec_lo, s26                             // 000000128600: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000128604: BF870499
	s_and_b32 s26, exec_lo, s25                                // 000000128608: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 00000012860C: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 000000128610: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 000000128614: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128618: BF870009
	s_or_b32 s9, s9, s26                                       // 00000012861C: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 000000128620: 917E167E
	s_cbranch_execz 28                                         // 000000128624: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1198>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000128628: BF8700C1
	v_mov_b32_e32 v130, v129                                   // 00000012862C: 7F040381
	s_or_b32 s24, s24, exec_lo                                 // 000000128630: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 000000128634: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 000000128638: BE9A007E
	v_ashrrev_i32_e32 v131, 31, v130                           // 00000012863C: 3507049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128640: BF870091
	.long 0xd73c0083                                           // 000000128644: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 000000128648: 02030482
	.long 0xd7006a83                                           // 00000012864C: D7006A83
	v_cndmask_b32_e32 v1, v144, v131, vcc_lo                   // 000000128650: 02030790
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128654: BF870001
	v_add_co_ci_u32_e64 v132, null, v145, v132, vcc_lo         // 000000128658: D5207C84 01AB0991
	global_load_b32 v131, v[131:132], off                      // 000000128660: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 000000128668: BF8903F7
	.long 0xd4c4007e                                           // 00000012866C: D4C4007E
	v_cndmask_b32_e32 v1, s7, v131, vcc_lo                     // 000000128670: 02030607
	s_cbranch_execz 65506                                      // 000000128674: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1100>
	v_add_nc_u32_e32 v129, 1, v130                             // 000000128678: 4B030481
	s_and_not1_b32 s25, s25, exec_lo                           // 00000012867C: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 000000128680: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000128684: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 000000128688: 7C9503A1
	s_and_b32 s27, vcc_lo, exec_lo                             // 00000012868C: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 000000128690: 8C191B19
	s_branch 65498                                             // 000000128694: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1100>
	s_set_inst_prefetch_distance 0x2                           // 000000128698: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 00000012869C: 8C7E167E
	v_dual_mov_b32 v132, 0 :: v_dual_mov_b32 v129, v161        // 0000001286A0: CA100080 848001A1
	s_and_saveexec_b32 s22, s9                                 // 0000001286A8: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001286AC: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 0000001286B0: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v131                          // 0000001286B4: 7C950607
	v_mov_b32_e32 v129, v130                                   // 0000001286B8: 7F020382
	v_cndmask_b32_e64 v132, 0, 15, vcc_lo                      // 0000001286BC: D5010084 01A91E80
	s_or_b32 exec_lo, exec_lo, s9                              // 0000001286C4: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001286C8: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001286CC: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001286D0: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001286D4: 8C7E017E
	s_or_b32 s8, s7, 1                                         // 0000001286D8: 8C088107
	s_mov_b32 s1, exec_lo                                      // 0000001286DC: BE81007E
	.long 0xd4c6007e                                           // 0000001286E0: D4C6007E
	v_cndmask_b32_e32 v1, s8, v170, vcc_lo                     // 0000001286E4: 02035408
	s_xor_b32 s1, exec_lo, s1                                  // 0000001286E8: 8D01017E
	v_or_b32_e32 v132, 0xf0, v132                              // 0000001286EC: 390908FF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 0000001286F4: BE813001
	s_cbranch_execz 70                                         // 0000001286F8: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1314>
	s_mov_b32 s9, exec_lo                                      // 0000001286FC: BE89007E
	.long 0xd4c1007e                                           // 000000128700: D4C1007E
	v_cndmask_b32_e32 v1, v129, v161, vcc_lo                   // 000000128704: 02034381
	s_cbranch_execz 64                                         // 000000128708: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x130c>
	s_mov_b32 s24, 0                                           // 00000012870C: BE980080
	s_set_inst_prefetch_distance 0x1                           // 000000128710: BF840001
	s_branch 20                                                // 000000128714: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1268>
	s_nop 0                                                    // 000000128718: BF800000
	s_nop 0                                                    // 00000012871C: BF800000
	s_nop 0                                                    // 000000128720: BF800000
	s_nop 0                                                    // 000000128724: BF800000
	s_nop 0                                                    // 000000128728: BF800000
	s_nop 0                                                    // 00000012872C: BF800000
	s_nop 0                                                    // 000000128730: BF800000
	s_nop 0                                                    // 000000128734: BF800000
	s_nop 0                                                    // 000000128738: BF800000
	s_nop 0                                                    // 00000012873C: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 000000128740: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000128744: BF870499
	s_and_b32 s27, exec_lo, s26                                // 000000128748: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 00000012874C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 000000128750: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 000000128754: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128758: BF870009
	s_or_b32 s22, s22, s27                                     // 00000012875C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 000000128760: 917E187E
	s_cbranch_execz 27                                         // 000000128764: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12d4>
	v_mov_b32_e32 v130, v129                                   // 000000128768: 7F040381
	s_or_b32 s25, s25, exec_lo                                 // 00000012876C: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 000000128770: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 000000128774: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128778: BF870091
	v_ashrrev_i32_e32 v131, 31, v130                           // 00000012877C: 3507049F
	.long 0xd73c0085                                           // 000000128780: D73C0085
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 000000128784: 02030482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128788: BF870091
	.long 0xd7006a85                                           // 00000012878C: D7006A85
	v_cndmask_b32_e32 v1, v144, v133, vcc_lo                   // 000000128790: 02030B90
	v_add_co_ci_u32_e64 v134, null, v145, v134, vcc_lo         // 000000128794: D5207C86 01AB0D91
	global_load_b32 v131, v[133:134], off                      // 00000012879C: DC520000 837C0085
	s_waitcnt vmcnt(0)                                         // 0000001287A4: BF8903F7
	.long 0xd4c6007e                                           // 0000001287A8: D4C6007E
	v_cndmask_b32_e32 v1, s7, v131, vcc_lo                     // 0000001287AC: 02030607
	s_cbranch_execz 65507                                      // 0000001287B0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	v_add_nc_u32_e32 v129, 1, v130                             // 0000001287B4: 4B030481
	s_and_not1_b32 s26, s26, exec_lo                           // 0000001287B8: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 0000001287BC: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000001287C0: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 0000001287C4: 7C9503A1
	s_and_b32 s28, vcc_lo, exec_lo                             // 0000001287C8: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 0000001287CC: 8C1A1C1A
	s_branch 65499                                             // 0000001287D0: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	s_set_inst_prefetch_distance 0x2                           // 0000001287D4: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 0000001287D8: 8C7E187E
	v_mov_b32_e32 v129, v161                                   // 0000001287DC: 7F0203A1
	s_and_saveexec_b32 s24, s22                                // 0000001287E0: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001287E4: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 0000001287E8: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v131                          // 0000001287EC: 7C950608
	v_cndmask_b32_e64 v129, 0, 0xf0, vcc_lo                    // 0000001287F0: D5010081 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001287FC: BF870001
	v_or_b32_e32 v132, v129, v132                              // 000000128800: 39090981
	v_mov_b32_e32 v129, v130                                   // 000000128804: 7F020382
	s_or_b32 exec_lo, exec_lo, s22                             // 000000128808: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000012880C: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 000000128810: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128814: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128818: 8C7E017E
	s_or_b32 s8, s7, 2                                         // 00000012881C: 8C088207
	s_mov_b32 s1, exec_lo                                      // 000000128820: BE81007E
	.long 0xd4c6007e                                           // 000000128824: D4C6007E
	v_cndmask_b32_e32 v1, s8, v170, vcc_lo                     // 000000128828: 02035408
	s_xor_b32 s1, exec_lo, s1                                  // 00000012882C: 8D01017E
	v_or_b32_e32 v132, 0xf00, v132                             // 000000128830: 390908FF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 000000128838: BE813001
	s_cbranch_execz 69                                         // 00000012883C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1454>
	s_mov_b32 s9, exec_lo                                      // 000000128840: BE89007E
	.long 0xd4c1007e                                           // 000000128844: D4C1007E
	v_cndmask_b32_e32 v1, v129, v161, vcc_lo                   // 000000128848: 02034381
	s_cbranch_execz 63                                         // 00000012884C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x144c>
	s_mov_b32 s24, 0                                           // 000000128850: BE980080
	s_set_inst_prefetch_distance 0x1                           // 000000128854: BF840001
	s_branch 19                                                // 000000128858: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13a8>
	s_nop 0                                                    // 00000012885C: BF800000
	s_nop 0                                                    // 000000128860: BF800000
	s_nop 0                                                    // 000000128864: BF800000
	s_nop 0                                                    // 000000128868: BF800000
	s_nop 0                                                    // 00000012886C: BF800000
	s_nop 0                                                    // 000000128870: BF800000
	s_nop 0                                                    // 000000128874: BF800000
	s_nop 0                                                    // 000000128878: BF800000
	s_nop 0                                                    // 00000012887C: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 000000128880: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000128884: BF870499
	s_and_b32 s27, exec_lo, s26                                // 000000128888: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 00000012888C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 000000128890: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 000000128894: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128898: BF870009
	s_or_b32 s22, s22, s27                                     // 00000012889C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 0000001288A0: 917E187E
	s_cbranch_execz 27                                         // 0000001288A4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1414>
	v_mov_b32_e32 v130, v129                                   // 0000001288A8: 7F040381
	s_or_b32 s25, s25, exec_lo                                 // 0000001288AC: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 0000001288B0: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 0000001288B4: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001288B8: BF870091
	v_ashrrev_i32_e32 v131, 31, v130                           // 0000001288BC: 3507049F
	.long 0xd73c0085                                           // 0000001288C0: D73C0085
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 0000001288C4: 02030482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001288C8: BF870091
	.long 0xd7006a85                                           // 0000001288CC: D7006A85
	v_cndmask_b32_e32 v1, v144, v133, vcc_lo                   // 0000001288D0: 02030B90
	v_add_co_ci_u32_e64 v134, null, v145, v134, vcc_lo         // 0000001288D4: D5207C86 01AB0D91
	global_load_b32 v131, v[133:134], off                      // 0000001288DC: DC520000 837C0085
	s_waitcnt vmcnt(0)                                         // 0000001288E4: BF8903F7
	.long 0xd4c4007e                                           // 0000001288E8: D4C4007E
	v_cndmask_b32_e32 v1, s8, v131, vcc_lo                     // 0000001288EC: 02030608
	s_cbranch_execz 65507                                      // 0000001288F0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1380>
	v_add_nc_u32_e32 v129, 1, v130                             // 0000001288F4: 4B030481
	s_and_not1_b32 s26, s26, exec_lo                           // 0000001288F8: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 0000001288FC: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000128900: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 000000128904: 7C9503A1
	s_and_b32 s28, vcc_lo, exec_lo                             // 000000128908: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 00000012890C: 8C1A1C1A
	s_branch 65499                                             // 000000128910: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1380>
	s_set_inst_prefetch_distance 0x2                           // 000000128914: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 000000128918: 8C7E187E
	v_mov_b32_e32 v129, v161                                   // 00000012891C: 7F0203A1
	s_and_saveexec_b32 s24, s22                                // 000000128920: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128924: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 000000128928: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v131                          // 00000012892C: 7C950608
	v_cndmask_b32_e64 v129, 0, 0xf00, vcc_lo                   // 000000128930: D5010081 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012893C: BF870001
	v_or_b32_e32 v132, v129, v132                              // 000000128940: 39090981
	v_mov_b32_e32 v129, v130                                   // 000000128944: 7F020382
	s_or_b32 exec_lo, exec_lo, s22                             // 000000128948: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000012894C: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 000000128950: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128954: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128958: 8C7E017E
	s_or_b32 s7, s7, 3                                         // 00000012895C: 8C078307
	s_mov_b32 s1, exec_lo                                      // 000000128960: BE81007E
	.long 0xd4c6007e                                           // 000000128964: D4C6007E
	v_cndmask_b32_e32 v1, s7, v170, vcc_lo                     // 000000128968: 02035407
	s_xor_b32 s1, exec_lo, s1                                  // 00000012896C: 8D01017E
	v_or_b32_e32 v132, 0xf000, v132                            // 000000128970: 390908FF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 000000128978: BE813001
	s_cbranch_execz 66                                         // 00000012897C: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1588>
	s_mov_b32 s8, exec_lo                                      // 000000128980: BE88007E
	.long 0xd4c1007e                                           // 000000128984: D4C1007E
	v_cndmask_b32_e32 v1, v129, v161, vcc_lo                   // 000000128988: 02034381
	s_cbranch_execz 60                                         // 00000012898C: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1580>
	s_mov_b32 s22, 0                                           // 000000128990: BE960080
	s_set_inst_prefetch_distance 0x1                           // 000000128994: BF840001
	s_branch 19                                                // 000000128998: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14e8>
	s_nop 0                                                    // 00000012899C: BF800000
	s_nop 0                                                    // 0000001289A0: BF800000
	s_nop 0                                                    // 0000001289A4: BF800000
	s_nop 0                                                    // 0000001289A8: BF800000
	s_nop 0                                                    // 0000001289AC: BF800000
	s_nop 0                                                    // 0000001289B0: BF800000
	s_nop 0                                                    // 0000001289B4: BF800000
	s_nop 0                                                    // 0000001289B8: BF800000
	s_nop 0                                                    // 0000001289BC: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 0000001289C0: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001289C4: BF870499
	s_and_b32 s26, exec_lo, s25                                // 0000001289C8: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 0000001289CC: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 0000001289D0: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 0000001289D4: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001289D8: BF870009
	s_or_b32 s9, s9, s26                                       // 0000001289DC: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000001289E0: 917E167E
	s_cbranch_execz 26                                         // 0000001289E4: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1550>
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000001289E8: 3505029F
	s_or_b32 s24, s24, exec_lo                                 // 0000001289EC: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 0000001289F0: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 0000001289F4: BE9A007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001289F8: BF870091
	.long 0xd73c0082                                           // 0000001289FC: D73C0082
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 000000128A00: 02030282
	.long 0xd7006a82                                           // 000000128A04: D7006A82
	v_cndmask_b32_e32 v1, v144, v130, vcc_lo                   // 000000128A08: 02030590
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128A0C: BF870001
	v_add_co_ci_u32_e64 v131, null, v145, v131, vcc_lo         // 000000128A10: D5207C83 01AB0791
	global_load_b32 v130, v[130:131], off                      // 000000128A18: DC520000 827C0082
	s_waitcnt vmcnt(0)                                         // 000000128A20: BF8903F7
	.long 0xd4c4007e                                           // 000000128A24: D4C4007E
	v_cndmask_b32_e32 v1, s7, v130, vcc_lo                     // 000000128A28: 02030407
	s_cbranch_execz 65508                                      // 000000128A2C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	v_add_nc_u32_e32 v129, 1, v129                             // 000000128A30: 4B030281
	s_and_not1_b32 s25, s25, exec_lo                           // 000000128A34: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 000000128A38: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000128A3C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 000000128A40: 7C9503A1
	s_and_b32 s27, vcc_lo, exec_lo                             // 000000128A44: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 000000128A48: 8C191B19
	s_branch 65500                                             // 000000128A4C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	s_set_inst_prefetch_distance 0x2                           // 000000128A50: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 000000128A54: 8C7E167E
	s_and_saveexec_b32 s22, s9                                 // 000000128A58: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128A5C: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 000000128A60: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v130                          // 000000128A64: 7C950407
	v_cndmask_b32_e64 v129, 0, 0xf000, vcc_lo                  // 000000128A68: D5010081 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128A74: BF870001
	v_or_b32_e32 v132, v129, v132                              // 000000128A78: 39090981
	s_or_b32 exec_lo, exec_lo, s9                              // 000000128A7C: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128A80: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 000000128A84: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128A88: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128A8C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128A90: BF870009
	s_or_b32 exec_lo, exec_lo, s4                              // 000000128A94: 8C7E047E
	s_and_saveexec_b32 s4, s3                                  // 000000128A98: BE842003
	s_cbranch_execz 1029                                       // 000000128A9C: BFA50405 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x25b4>
	ds_load_b32 v130, v172                                     // 000000128AA0: D8D80000 820000AC
	v_and_b32_e32 v129, 1, v132                                // 000000128AA8: 37030881
	v_cmp_le_i32_e32 vcc_lo, s2, v171                          // 000000128AAC: 7C875602
	s_delay_alu instid0(VALU_DEP_2)                            // 000000128AB0: BF870002
	.long 0xd44a0001                                           // 000000128AB4: D44A0001
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 000000128AB8: 02030281
	s_and_b32 s35, vcc_lo, s1                                  // 000000128ABC: 8B23016A
	s_waitcnt lgkmcnt(0)                                       // 000000128AC0: BF89FC07
	v_mov_b32_e32 v129, v130                                   // 000000128AC4: 7F020382
	s_and_saveexec_b32 s1, s35                                 // 000000128AC8: BE812023
	s_cbranch_execz 7                                          // 000000128ACC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15ec>
	ds_load_b32 v129, v173                                     // 000000128AD0: D8D80000 810000AD
	v_max_f32_e32 v131, v130, v130                             // 000000128AD8: 21070582
	s_waitcnt lgkmcnt(0)                                       // 000000128ADC: BF89FC07
	v_max_f32_e32 v129, v129, v129                             // 000000128AE0: 21030381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128AE4: BF870001
	v_max_f32_e32 v129, v131, v129                             // 000000128AE8: 21030383
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128AEC: 8C7E017E
	v_and_b32_e32 v131, 2, v132                                // 000000128AF0: 37070882
	v_cmp_lt_i32_e32 vcc_lo, s2, v171                          // 000000128AF4: 7C835602
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000128AF8: BF8704A2
	.long 0xd44d0001                                           // 000000128AFC: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128B00: 02030680
	s_and_b32 s34, vcc_lo, s1                                  // 000000128B04: 8B22016A
	s_and_saveexec_b32 s1, s34                                 // 000000128B08: BE812022
	s_cbranch_execz 7                                          // 000000128B0C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x162c>
	ds_load_b32 v131, v173 offset:4                            // 000000128B10: D8D80004 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128B18: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128B1C: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128B20: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128B24: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128B28: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128B2C: 8C7E017E
	v_and_b32_e32 v131, 4, v132                                // 000000128B30: 37070884
	s_or_b32 s1, s2, 2                                         // 000000128B34: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128B38: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 000000128B3C: 7C875601
	.long 0xd44d0001                                           // 000000128B40: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128B44: 02030680
	s_and_b32 s33, vcc_lo, s1                                  // 000000128B48: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128B4C: BF870009
	s_and_saveexec_b32 s1, s33                                 // 000000128B50: BE812021
	s_cbranch_execz 7                                          // 000000128B54: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1674>
	ds_load_b32 v131, v173 offset:8                            // 000000128B58: D8D80008 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128B60: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128B64: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128B68: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128B6C: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128B70: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128B74: 8C7E017E
	v_and_b32_e32 v131, 8, v132                                // 000000128B78: 37070888
	s_or_b32 s1, s2, 3                                         // 000000128B7C: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128B80: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 000000128B84: 7C875601
	.long 0xd44d0001                                           // 000000128B88: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128B8C: 02030680
	s_and_b32 s31, vcc_lo, s1                                  // 000000128B90: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128B94: BF870009
	s_and_saveexec_b32 s1, s31                                 // 000000128B98: BE81201F
	s_cbranch_execz 7                                          // 000000128B9C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16bc>
	ds_load_b32 v131, v173 offset:12                           // 000000128BA0: D8D8000C 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128BA8: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128BAC: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128BB0: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128BB4: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128BB8: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128BBC: 8C7E017E
	v_and_b32_e32 v131, 16, v132                               // 000000128BC0: 37070890
	s_or_b32 s1, s2, 4                                         // 000000128BC4: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128BC8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 000000128BCC: 7C875601
	.long 0xd44d0001                                           // 000000128BD0: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128BD4: 02030680
	s_and_b32 s30, vcc_lo, s1                                  // 000000128BD8: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128BDC: BF870009
	s_and_saveexec_b32 s1, s30                                 // 000000128BE0: BE81201E
	s_cbranch_execz 7                                          // 000000128BE4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1704>
	ds_load_b32 v131, v173 offset:16                           // 000000128BE8: D8D80010 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128BF0: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128BF4: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128BF8: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128BFC: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128C00: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128C04: 8C7E017E
	v_and_b32_e32 v131, 32, v132                               // 000000128C08: 370708A0
	s_or_b32 s1, s2, 5                                         // 000000128C0C: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128C10: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 000000128C14: 7C875601
	.long 0xd44d0001                                           // 000000128C18: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128C1C: 02030680
	s_and_b32 s29, vcc_lo, s1                                  // 000000128C20: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128C24: BF870009
	s_and_saveexec_b32 s1, s29                                 // 000000128C28: BE81201D
	s_cbranch_execz 7                                          // 000000128C2C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x174c>
	ds_load_b32 v131, v173 offset:20                           // 000000128C30: D8D80014 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128C38: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128C3C: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128C40: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128C44: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128C48: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128C4C: 8C7E017E
	v_and_b32_e32 v131, 64, v132                               // 000000128C50: 370708C0
	s_or_b32 s1, s2, 6                                         // 000000128C54: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128C58: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 000000128C5C: 7C875601
	.long 0xd44d0001                                           // 000000128C60: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128C64: 02030680
	s_and_b32 s28, vcc_lo, s1                                  // 000000128C68: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128C6C: BF870009
	s_and_saveexec_b32 s1, s28                                 // 000000128C70: BE81201C
	s_cbranch_execz 7                                          // 000000128C74: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1794>
	ds_load_b32 v131, v173 offset:24                           // 000000128C78: D8D80018 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128C80: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128C84: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128C88: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128C8C: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128C90: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128C94: 8C7E017E
	v_and_b32_e32 v131, 0x80, v132                             // 000000128C98: 370708FF 00000080
	s_or_b32 s1, s2, 7                                         // 000000128CA0: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128CA4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 000000128CA8: 7C875601
	.long 0xd44d0001                                           // 000000128CAC: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128CB0: 02030680
	s_and_b32 s27, vcc_lo, s1                                  // 000000128CB4: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128CB8: BF870009
	s_and_saveexec_b32 s1, s27                                 // 000000128CBC: BE81201B
	s_cbranch_execz 7                                          // 000000128CC0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17e0>
	ds_load_b32 v131, v173 offset:28                           // 000000128CC4: D8D8001C 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128CCC: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128CD0: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128CD4: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128CD8: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128CDC: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128CE0: 8C7E017E
	v_and_b32_e32 v131, 0x100, v132                            // 000000128CE4: 370708FF 00000100
	s_or_b32 s1, s2, 8                                         // 000000128CEC: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128CF0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 000000128CF4: 7C875601
	.long 0xd44d0001                                           // 000000128CF8: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128CFC: 02030680
	s_and_b32 s26, vcc_lo, s1                                  // 000000128D00: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128D04: BF870009
	s_and_saveexec_b32 s1, s26                                 // 000000128D08: BE81201A
	s_cbranch_execz 7                                          // 000000128D0C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x182c>
	ds_load_b32 v131, v173 offset:32                           // 000000128D10: D8D80020 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128D18: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128D1C: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128D20: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128D24: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128D28: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128D2C: 8C7E017E
	v_and_b32_e32 v131, 0x200, v132                            // 000000128D30: 370708FF 00000200
	s_or_b32 s1, s2, 9                                         // 000000128D38: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128D3C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 000000128D40: 7C875601
	.long 0xd44d0001                                           // 000000128D44: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128D48: 02030680
	s_and_b32 s25, vcc_lo, s1                                  // 000000128D4C: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128D50: BF870009
	s_and_saveexec_b32 s1, s25                                 // 000000128D54: BE812019
	s_cbranch_execz 7                                          // 000000128D58: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1878>
	ds_load_b32 v131, v173 offset:36                           // 000000128D5C: D8D80024 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128D64: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128D68: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128D6C: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128D70: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128D74: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128D78: 8C7E017E
	v_and_b32_e32 v131, 0x400, v132                            // 000000128D7C: 370708FF 00000400
	s_or_b32 s1, s2, 10                                        // 000000128D84: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128D88: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 000000128D8C: 7C875601
	.long 0xd44d0001                                           // 000000128D90: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128D94: 02030680
	s_and_b32 s24, vcc_lo, s1                                  // 000000128D98: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128D9C: BF870009
	s_and_saveexec_b32 s1, s24                                 // 000000128DA0: BE812018
	s_cbranch_execz 7                                          // 000000128DA4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18c4>
	ds_load_b32 v131, v173 offset:40                           // 000000128DA8: D8D80028 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128DB0: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128DB4: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128DB8: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128DBC: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128DC0: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128DC4: 8C7E017E
	v_and_b32_e32 v131, 0x800, v132                            // 000000128DC8: 370708FF 00000800
	s_or_b32 s1, s2, 11                                        // 000000128DD0: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128DD4: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 000000128DD8: 7C875601
	.long 0xd44d0001                                           // 000000128DDC: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128DE0: 02030680
	s_and_b32 s22, vcc_lo, s1                                  // 000000128DE4: 8B16016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128DE8: BF870009
	s_and_saveexec_b32 s1, s22                                 // 000000128DEC: BE812016
	s_cbranch_execz 7                                          // 000000128DF0: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1910>
	ds_load_b32 v131, v173 offset:44                           // 000000128DF4: D8D8002C 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128DFC: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128E00: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128E04: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128E08: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128E0C: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128E10: 8C7E017E
	v_and_b32_e32 v131, 0x1000, v132                           // 000000128E14: 370708FF 00001000
	s_or_b32 s1, s2, 12                                        // 000000128E1C: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128E20: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 000000128E24: 7C875601
	.long 0xd44d0001                                           // 000000128E28: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128E2C: 02030680
	s_and_b32 s9, vcc_lo, s1                                   // 000000128E30: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128E34: BF870009
	s_and_saveexec_b32 s1, s9                                  // 000000128E38: BE812009
	s_cbranch_execz 7                                          // 000000128E3C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x195c>
	ds_load_b32 v131, v173 offset:48                           // 000000128E40: D8D80030 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128E48: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128E4C: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128E50: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128E54: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128E58: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128E5C: 8C7E017E
	v_and_b32_e32 v131, 0x2000, v132                           // 000000128E60: 370708FF 00002000
	s_or_b32 s1, s2, 13                                        // 000000128E68: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128E6C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 000000128E70: 7C875601
	.long 0xd44d0001                                           // 000000128E74: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128E78: 02030680
	s_and_b32 s8, vcc_lo, s1                                   // 000000128E7C: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128E80: BF870009
	s_and_saveexec_b32 s1, s8                                  // 000000128E84: BE812008
	s_cbranch_execz 7                                          // 000000128E88: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19a8>
	ds_load_b32 v131, v173 offset:52                           // 000000128E8C: D8D80034 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128E94: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128E98: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128E9C: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128EA0: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128EA4: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128EA8: 8C7E017E
	v_and_b32_e32 v131, 0x4000, v132                           // 000000128EAC: 370708FF 00004000
	s_or_b32 s1, s2, 14                                        // 000000128EB4: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128EB8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v171                          // 000000128EBC: 7C875601
	.long 0xd44d0001                                           // 000000128EC0: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128EC4: 02030680
	s_and_b32 s7, vcc_lo, s1                                   // 000000128EC8: 8B07016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128ECC: BF870009
	s_and_saveexec_b32 s1, s7                                  // 000000128ED0: BE812007
	s_cbranch_execz 7                                          // 000000128ED4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19f4>
	ds_load_b32 v131, v173 offset:56                           // 000000128ED8: D8D80038 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128EE0: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128EE4: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128EE8: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128EEC: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128EF0: 21030781
	s_or_b32 exec_lo, exec_lo, s1                              // 000000128EF4: 8C7E017E
	v_and_b32_e32 v131, 0x8000, v132                           // 000000128EF8: 370708FF 00008000
	s_or_b32 s2, s2, 15                                        // 000000128F00: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000128F04: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v171                          // 000000128F08: 7C875602
	.long 0xd44d0001                                           // 000000128F0C: D44D0001
	v_cndmask_b32_e32 v1, 0, v131, vcc_lo                      // 000000128F10: 02030680
	s_and_b32 s1, vcc_lo, s1                                   // 000000128F14: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000128F18: BF870009
	s_and_saveexec_b32 s2, s1                                  // 000000128F1C: BE822001
	s_cbranch_execz 7                                          // 000000128F20: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a40>
	ds_load_b32 v131, v173 offset:60                           // 000000128F24: D8D8003C 830000AD
	v_max_f32_e32 v129, v129, v129                             // 000000128F2C: 21030381
	s_waitcnt lgkmcnt(0)                                       // 000000128F30: BF89FC07
	v_max_f32_e32 v131, v131, v131                             // 000000128F34: 21070783
	s_delay_alu instid0(VALU_DEP_1)                            // 000000128F38: BF870001
	v_max_f32_e32 v129, v129, v131                             // 000000128F3C: 21030781
	s_or_b32 exec_lo, exec_lo, s2                              // 000000128F40: 8C7E027E
	v_dual_mov_b32 v131, 0 :: v_dual_mov_b32 v132, 0           // 000000128F44: CA100080 83840080
	s_and_saveexec_b32 s2, s35                                 // 000000128F4C: BE822023
	s_cbranch_execz 30                                         // 000000128F50: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1acc>
	ds_load_b32 v132, v173                                     // 000000128F54: D8D80000 840000AD
	s_waitcnt lgkmcnt(0)                                       // 000000128F5C: BF89FC07
	v_sub_f32_e32 v132, v132, v129                             // 000000128F60: 09090384
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128F64: BF870091
	v_mul_f32_e32 v133, 0x3fb8aa3b, v132                       // 000000128F68: 110B08FF 3FB8AA3B
	v_fma_f32 v134, 0x3fb8aa3b, v132, -v133                    // 000000128F70: D6130086 861708FF 3FB8AA3B
	v_rndne_f32_e32 v135, v133                                 // 000000128F7C: 7F0E4785
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000128F80: BF870221
	v_sub_f32_e32 v133, v133, v135                             // 000000128F84: 090B0F85
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v132                 // 000000128F88: 7C3708FF C2CE8ED0
	v_fmac_f32_e32 v134, 0x32a5705f, v132                      // 000000128F90: 570D08FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000128F98: BF870121
	v_add_f32_e32 v133, v133, v134                             // 000000128F9C: 070B0D85
	v_cvt_i32_f32_e32 v134, v135                               // 000000128FA0: 7F0C1187
	v_exp_f32_e32 v133, v133                                   // 000000128FA4: 7F0A4B85
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128FA8: BF870095
	.long 0xd71c0085                                           // 000000128FAC: D71C0085
	v_cndmask_b32_e32 v1, v133, v134, vcc_lo                   // 000000128FB0: 02030D85
	v_cndmask_b32_e32 v133, 0, v133, vcc_lo                    // 000000128FB4: 030B0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v132                 // 000000128FB8: 7C3D08FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000128FC0: BF870002
	v_cndmask_b32_e32 v132, 0x7f800000, v133, vcc_lo           // 000000128FC4: 03090AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000128FCC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000128FD0: BF870091
	v_bfe_u32 v133, v132, 16, 1                                // 000000128FD4: D6100085 02052184
	v_add3_u32 v133, v132, v133, 0x7fff                        // 000000128FDC: D6550085 03FF0B84 00007FFF
	ds_store_b16_d16_hi v174, v133                             // 000000128FE8: DA840000 000085AE
	s_and_saveexec_b32 s2, s34                                 // 000000128FF0: BE822022
	s_cbranch_execz 30                                         // 000000128FF4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b70>
	ds_load_b32 v131, v173 offset:4                            // 000000128FF8: D8D80004 830000AD
	s_waitcnt lgkmcnt(0)                                       // 000000129000: BF89FC07
	v_sub_f32_e32 v131, v131, v129                             // 000000129004: 09070383
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129008: BF870121
	v_mul_f32_e32 v133, 0x3fb8aa3b, v131                       // 00000012900C: 110B06FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v131                 // 000000129014: 7C3706FF C2CE8ED0
	v_fma_f32 v134, 0x3fb8aa3b, v131, -v133                    // 00000012901C: D6130086 861706FF 3FB8AA3B
	v_rndne_f32_e32 v135, v133                                 // 000000129028: 7F0E4785
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012902C: BF870112
	v_fmac_f32_e32 v134, 0x32a5705f, v131                      // 000000129030: 570D06FF 32A5705F
	v_sub_f32_e32 v133, v133, v135                             // 000000129038: 090B0F85
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012903C: BF870121
	v_add_f32_e32 v133, v133, v134                             // 000000129040: 070B0D85
	v_cvt_i32_f32_e32 v134, v135                               // 000000129044: 7F0C1187
	v_exp_f32_e32 v133, v133                                   // 000000129048: 7F0A4B85
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012904C: BF870095
	.long 0xd71c0085                                           // 000000129050: D71C0085
	v_cndmask_b32_e32 v1, v133, v134, vcc_lo                   // 000000129054: 02030D85
	v_cndmask_b32_e32 v133, 0, v133, vcc_lo                    // 000000129058: 030B0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v131                 // 00000012905C: 7C3D06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000129064: BF870002
	v_cndmask_b32_e32 v131, 0x7f800000, v133, vcc_lo           // 000000129068: 03070AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000129070: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129074: BF870121
	v_bfe_u32 v133, v131, 16, 1                                // 000000129078: D6100085 02052183
	v_mov_b32_e32 v134, 0                                      // 000000129080: 7F0C0280
	v_add3_u32 v135, v131, v133, 0x7fff                        // 000000129084: D6550087 03FF0B83 00007FFF
	v_mov_b32_e32 v133, 0                                      // 000000129090: 7F0A0280
	ds_store_b16_d16_hi v174, v135 offset:2                    // 000000129094: DA840002 000087AE
	s_and_saveexec_b32 s2, s33                                 // 00000012909C: BE822021
	s_cbranch_execz 29                                         // 0000001290A0: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c18>
	ds_load_b32 v134, v173 offset:8                            // 0000001290A4: D8D80008 860000AD
	s_waitcnt lgkmcnt(0)                                       // 0000001290AC: BF89FC07
	v_sub_f32_e32 v134, v134, v129                             // 0000001290B0: 090D0386
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001290B4: BF870091
	v_mul_f32_e32 v135, 0x3fb8aa3b, v134                       // 0000001290B8: 110F0CFF 3FB8AA3B
	v_fma_f32 v136, 0x3fb8aa3b, v134, -v135                    // 0000001290C0: D6130088 861F0CFF 3FB8AA3B
	v_rndne_f32_e32 v149, v135                                 // 0000001290CC: 7F2A4787
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001290D0: BF870091
	v_dual_fmac_f32 v136, 0x32a5705f, v134 :: v_dual_sub_f32 v135, v135, v149// 0000001290D4: C80B0CFF 88872B87 32A5705F
	v_add_f32_e32 v135, v135, v136                             // 0000001290E0: 070F1187
	v_cvt_i32_f32_e32 v136, v149                               // 0000001290E4: 7F101195
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 0000001290E8: 7C370CFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001290F0: BF870293
	v_exp_f32_e32 v135, v135                                   // 0000001290F4: 7F0E4B87
	.long 0xd71c0087                                           // 0000001290F8: D71C0087
	v_cndmask_b32_e32 v1, v135, v136, vcc_lo                   // 0000001290FC: 02031187
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129100: BF870121
	v_cndmask_b32_e32 v135, 0, v135, vcc_lo                    // 000000129104: 030F0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 000000129108: 7C3D0CFF 42B17218
	v_cndmask_b32_e32 v134, 0x7f800000, v135, vcc_lo           // 000000129110: 030D0EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000129118: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012911C: BF870091
	v_bfe_u32 v135, v134, 16, 1                                // 000000129120: D6100087 02052186
	v_add3_u32 v135, v134, v135, 0x7fff                        // 000000129128: D6550087 03FF0F86 00007FFF
	ds_store_b16_d16_hi v174, v135 offset:4                    // 000000129134: DA840004 000087AE
	s_and_saveexec_b32 s2, s31                                 // 00000012913C: BE82201F
	s_cbranch_execz 30                                         // 000000129140: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1cbc>
	ds_load_b32 v133, v173 offset:12                           // 000000129144: D8D8000C 850000AD
	s_waitcnt lgkmcnt(0)                                       // 00000012914C: BF89FC07
	v_sub_f32_e32 v133, v133, v129                             // 000000129150: 090B0385
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129154: BF870121
	v_mul_f32_e32 v135, 0x3fb8aa3b, v133                       // 000000129158: 110F0AFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 000000129160: 7C370AFF C2CE8ED0
	v_fma_f32 v136, 0x3fb8aa3b, v133, -v135                    // 000000129168: D6130088 861F0AFF 3FB8AA3B
	v_rndne_f32_e32 v149, v135                                 // 000000129174: 7F2A4787
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000129178: BF870112
	v_fmac_f32_e32 v136, 0x32a5705f, v133                      // 00000012917C: 57110AFF 32A5705F
	v_sub_f32_e32 v135, v135, v149                             // 000000129184: 090F2B87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129188: BF870121
	v_add_f32_e32 v135, v135, v136                             // 00000012918C: 070F1187
	v_cvt_i32_f32_e32 v136, v149                               // 000000129190: 7F101195
	v_exp_f32_e32 v135, v135                                   // 000000129194: 7F0E4B87
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129198: BF870095
	.long 0xd71c0087                                           // 00000012919C: D71C0087
	v_cndmask_b32_e32 v1, v135, v136, vcc_lo                   // 0000001291A0: 02031187
	v_cndmask_b32_e32 v135, 0, v135, vcc_lo                    // 0000001291A4: 030F0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 0000001291A8: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001291B0: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v135, vcc_lo           // 0000001291B4: 030B0EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001291BC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001291C0: BF870121
	v_bfe_u32 v135, v133, 16, 1                                // 0000001291C4: D6100087 02052185
	v_mov_b32_e32 v136, 0                                      // 0000001291CC: 7F100280
	v_add3_u32 v149, v133, v135, 0x7fff                        // 0000001291D0: D6550095 03FF0F85 00007FFF
	v_mov_b32_e32 v135, 0                                      // 0000001291DC: 7F0E0280
	ds_store_b16_d16_hi v174, v149 offset:6                    // 0000001291E0: DA840006 000095AE
	s_and_saveexec_b32 s2, s30                                 // 0000001291E8: BE82201E
	s_cbranch_execz 30                                         // 0000001291EC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d68>
	ds_load_b32 v136, v173 offset:16                           // 0000001291F0: D8D80010 880000AD
	s_waitcnt lgkmcnt(0)                                       // 0000001291F8: BF89FC07
	v_sub_f32_e32 v136, v136, v129                             // 0000001291FC: 09110388
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129200: BF870091
	v_mul_f32_e32 v149, 0x3fb8aa3b, v136                       // 000000129204: 112B10FF 3FB8AA3B
	v_fma_f32 v150, 0x3fb8aa3b, v136, -v149                    // 00000012920C: D6130096 865710FF 3FB8AA3B
	v_rndne_f32_e32 v151, v149                                 // 000000129218: 7F2E4795
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012921C: BF870221
	v_sub_f32_e32 v149, v149, v151                             // 000000129220: 092B2F95
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 000000129224: 7C3710FF C2CE8ED0
	v_fmac_f32_e32 v150, 0x32a5705f, v136                      // 00000012922C: 572D10FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129234: BF870121
	v_add_f32_e32 v149, v149, v150                             // 000000129238: 072B2D95
	v_cvt_i32_f32_e32 v150, v151                               // 00000012923C: 7F2C1197
	v_exp_f32_e32 v149, v149                                   // 000000129240: 7F2A4B95
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129244: BF870095
	.long 0xd71c0095                                           // 000000129248: D71C0095
	v_cndmask_b32_e32 v1, v149, v150, vcc_lo                   // 00000012924C: 02032D95
	v_cndmask_b32_e32 v149, 0, v149, vcc_lo                    // 000000129250: 032B2A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 000000129254: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000012925C: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v149, vcc_lo           // 000000129260: 03112AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000129268: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012926C: BF870091
	v_bfe_u32 v149, v136, 16, 1                                // 000000129270: D6100095 02052188
	v_add3_u32 v149, v136, v149, 0x7fff                        // 000000129278: D6550095 03FF2B88 00007FFF
	ds_store_b16_d16_hi v174, v149 offset:8                    // 000000129284: DA840008 000095AE
	s_and_saveexec_b32 s2, s29                                 // 00000012928C: BE82201D
	s_cbranch_execz 30                                         // 000000129290: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e0c>
	ds_load_b32 v135, v173 offset:20                           // 000000129294: D8D80014 870000AD
	s_waitcnt lgkmcnt(0)                                       // 00000012929C: BF89FC07
	v_sub_f32_e32 v135, v135, v129                             // 0000001292A0: 090F0387
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001292A4: BF870121
	v_mul_f32_e32 v149, 0x3fb8aa3b, v135                       // 0000001292A8: 112B0EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 0000001292B0: 7C370EFF C2CE8ED0
	v_fma_f32 v150, 0x3fb8aa3b, v135, -v149                    // 0000001292B8: D6130096 86570EFF 3FB8AA3B
	v_rndne_f32_e32 v151, v149                                 // 0000001292C4: 7F2E4795
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001292C8: BF870112
	v_fmac_f32_e32 v150, 0x32a5705f, v135                      // 0000001292CC: 572D0EFF 32A5705F
	v_sub_f32_e32 v149, v149, v151                             // 0000001292D4: 092B2F95
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001292D8: BF870121
	v_add_f32_e32 v149, v149, v150                             // 0000001292DC: 072B2D95
	v_cvt_i32_f32_e32 v150, v151                               // 0000001292E0: 7F2C1197
	v_exp_f32_e32 v149, v149                                   // 0000001292E4: 7F2A4B95
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001292E8: BF870095
	.long 0xd71c0095                                           // 0000001292EC: D71C0095
	v_cndmask_b32_e32 v1, v149, v150, vcc_lo                   // 0000001292F0: 02032D95
	v_cndmask_b32_e32 v149, 0, v149, vcc_lo                    // 0000001292F4: 032B2A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 0000001292F8: 7C3D0EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000129300: BF870002
	v_cndmask_b32_e32 v135, 0x7f800000, v149, vcc_lo           // 000000129304: 030F2AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000012930C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129310: BF870121
	v_bfe_u32 v149, v135, 16, 1                                // 000000129314: D6100095 02052187
	v_mov_b32_e32 v150, 0                                      // 00000012931C: 7F2C0280
	v_add3_u32 v151, v135, v149, 0x7fff                        // 000000129320: D6550097 03FF2B87 00007FFF
	v_mov_b32_e32 v149, 0                                      // 00000012932C: 7F2A0280
	ds_store_b16_d16_hi v174, v151 offset:10                   // 000000129330: DA84000A 000097AE
	s_and_saveexec_b32 s2, s28                                 // 000000129338: BE82201C
	s_cbranch_execz 29                                         // 00000012933C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1eb4>
	ds_load_b32 v150, v173 offset:24                           // 000000129340: D8D80018 960000AD
	s_waitcnt lgkmcnt(0)                                       // 000000129348: BF89FC07
	v_sub_f32_e32 v150, v150, v129                             // 00000012934C: 092D0396
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129350: BF870091
	v_mul_f32_e32 v151, 0x3fb8aa3b, v150                       // 000000129354: 112F2CFF 3FB8AA3B
	v_fma_f32 v152, 0x3fb8aa3b, v150, -v151                    // 00000012935C: D6130098 865F2CFF 3FB8AA3B
	v_rndne_f32_e32 v153, v151                                 // 000000129368: 7F324797
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012936C: BF870091
	v_dual_fmac_f32 v152, 0x32a5705f, v150 :: v_dual_sub_f32 v151, v151, v153// 000000129370: C80B2CFF 98973397 32A5705F
	v_add_f32_e32 v151, v151, v152                             // 00000012937C: 072F3197
	v_cvt_i32_f32_e32 v152, v153                               // 000000129380: 7F301199
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 000000129384: 7C372CFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012938C: BF870293
	v_exp_f32_e32 v151, v151                                   // 000000129390: 7F2E4B97
	.long 0xd71c0097                                           // 000000129394: D71C0097
	v_cndmask_b32_e32 v1, v151, v152, vcc_lo                   // 000000129398: 02033197
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012939C: BF870121
	v_cndmask_b32_e32 v151, 0, v151, vcc_lo                    // 0000001293A0: 032F2E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 0000001293A4: 7C3D2CFF 42B17218
	v_cndmask_b32_e32 v150, 0x7f800000, v151, vcc_lo           // 0000001293AC: 032D2EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001293B4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001293B8: BF870091
	v_bfe_u32 v151, v150, 16, 1                                // 0000001293BC: D6100097 02052196
	v_add3_u32 v151, v150, v151, 0x7fff                        // 0000001293C4: D6550097 03FF2F96 00007FFF
	ds_store_b16_d16_hi v174, v151 offset:12                   // 0000001293D0: DA84000C 000097AE
	s_and_saveexec_b32 s2, s27                                 // 0000001293D8: BE82201B
	s_cbranch_execz 30                                         // 0000001293DC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f58>
	ds_load_b32 v149, v173 offset:28                           // 0000001293E0: D8D8001C 950000AD
	s_waitcnt lgkmcnt(0)                                       // 0000001293E8: BF89FC07
	v_sub_f32_e32 v149, v149, v129                             // 0000001293EC: 092B0395
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001293F0: BF870121
	v_mul_f32_e32 v151, 0x3fb8aa3b, v149                       // 0000001293F4: 112F2AFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 0000001293FC: 7C372AFF C2CE8ED0
	v_fma_f32 v152, 0x3fb8aa3b, v149, -v151                    // 000000129404: D6130098 865F2AFF 3FB8AA3B
	v_rndne_f32_e32 v153, v151                                 // 000000129410: 7F324797
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000129414: BF870112
	v_fmac_f32_e32 v152, 0x32a5705f, v149                      // 000000129418: 57312AFF 32A5705F
	v_sub_f32_e32 v151, v151, v153                             // 000000129420: 092F3397
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129424: BF870121
	v_add_f32_e32 v151, v151, v152                             // 000000129428: 072F3197
	v_cvt_i32_f32_e32 v152, v153                               // 00000012942C: 7F301199
	v_exp_f32_e32 v151, v151                                   // 000000129430: 7F2E4B97
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129434: BF870095
	.long 0xd71c0097                                           // 000000129438: D71C0097
	v_cndmask_b32_e32 v1, v151, v152, vcc_lo                   // 00000012943C: 02033197
	v_cndmask_b32_e32 v151, 0, v151, vcc_lo                    // 000000129440: 032F2E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 000000129444: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000012944C: BF870002
	v_cndmask_b32_e32 v149, 0x7f800000, v151, vcc_lo           // 000000129450: 032B2EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000129458: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012945C: BF870121
	v_bfe_u32 v151, v149, 16, 1                                // 000000129460: D6100097 02052195
	v_mov_b32_e32 v152, 0                                      // 000000129468: 7F300280
	v_add3_u32 v153, v149, v151, 0x7fff                        // 00000012946C: D6550099 03FF2F95 00007FFF
	v_mov_b32_e32 v151, 0                                      // 000000129478: 7F2E0280
	ds_store_b16_d16_hi v174, v153 offset:14                   // 00000012947C: DA84000E 000099AE
	s_and_saveexec_b32 s2, s26                                 // 000000129484: BE82201A
	s_cbranch_execz 30                                         // 000000129488: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2004>
	ds_load_b32 v152, v173 offset:32                           // 00000012948C: D8D80020 980000AD
	s_waitcnt lgkmcnt(0)                                       // 000000129494: BF89FC07
	v_sub_f32_e32 v152, v152, v129                             // 000000129498: 09310398
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012949C: BF870091
	v_mul_f32_e32 v153, 0x3fb8aa3b, v152                       // 0000001294A0: 113330FF 3FB8AA3B
	v_fma_f32 v154, 0x3fb8aa3b, v152, -v153                    // 0000001294A8: D613009A 866730FF 3FB8AA3B
	v_rndne_f32_e32 v155, v153                                 // 0000001294B4: 7F364799
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001294B8: BF870221
	v_sub_f32_e32 v153, v153, v155                             // 0000001294BC: 09333799
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 0000001294C0: 7C3730FF C2CE8ED0
	v_fmac_f32_e32 v154, 0x32a5705f, v152                      // 0000001294C8: 573530FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001294D0: BF870121
	v_add_f32_e32 v153, v153, v154                             // 0000001294D4: 07333599
	v_cvt_i32_f32_e32 v154, v155                               // 0000001294D8: 7F34119B
	v_exp_f32_e32 v153, v153                                   // 0000001294DC: 7F324B99
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001294E0: BF870095
	.long 0xd71c0099                                           // 0000001294E4: D71C0099
	v_cndmask_b32_e32 v1, v153, v154, vcc_lo                   // 0000001294E8: 02033599
	v_cndmask_b32_e32 v153, 0, v153, vcc_lo                    // 0000001294EC: 03333280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 0000001294F0: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001294F8: BF870002
	v_cndmask_b32_e32 v152, 0x7f800000, v153, vcc_lo           // 0000001294FC: 033132FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000129504: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129508: BF870091
	v_bfe_u32 v153, v152, 16, 1                                // 00000012950C: D6100099 02052198
	v_add3_u32 v153, v152, v153, 0x7fff                        // 000000129514: D6550099 03FF3398 00007FFF
	ds_store_b16_d16_hi v174, v153 offset:16                   // 000000129520: DA840010 000099AE
	s_and_saveexec_b32 s2, s25                                 // 000000129528: BE822019
	s_cbranch_execz 30                                         // 00000012952C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x20a8>
	ds_load_b32 v151, v173 offset:36                           // 000000129530: D8D80024 970000AD
	s_waitcnt lgkmcnt(0)                                       // 000000129538: BF89FC07
	v_sub_f32_e32 v151, v151, v129                             // 00000012953C: 092F0397
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129540: BF870121
	v_mul_f32_e32 v153, 0x3fb8aa3b, v151                       // 000000129544: 11332EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 00000012954C: 7C372EFF C2CE8ED0
	v_fma_f32 v154, 0x3fb8aa3b, v151, -v153                    // 000000129554: D613009A 86672EFF 3FB8AA3B
	v_rndne_f32_e32 v155, v153                                 // 000000129560: 7F364799
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000129564: BF870112
	v_fmac_f32_e32 v154, 0x32a5705f, v151                      // 000000129568: 57352EFF 32A5705F
	v_sub_f32_e32 v153, v153, v155                             // 000000129570: 09333799
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129574: BF870121
	v_add_f32_e32 v153, v153, v154                             // 000000129578: 07333599
	v_cvt_i32_f32_e32 v154, v155                               // 00000012957C: 7F34119B
	v_exp_f32_e32 v153, v153                                   // 000000129580: 7F324B99
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129584: BF870095
	.long 0xd71c0099                                           // 000000129588: D71C0099
	v_cndmask_b32_e32 v1, v153, v154, vcc_lo                   // 00000012958C: 02033599
	v_cndmask_b32_e32 v153, 0, v153, vcc_lo                    // 000000129590: 03333280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 000000129594: 7C3D2EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000012959C: BF870002
	v_cndmask_b32_e32 v151, 0x7f800000, v153, vcc_lo           // 0000001295A0: 032F32FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001295A8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001295AC: BF870121
	v_bfe_u32 v153, v151, 16, 1                                // 0000001295B0: D6100099 02052197
	v_mov_b32_e32 v154, 0                                      // 0000001295B8: 7F340280
	v_add3_u32 v155, v151, v153, 0x7fff                        // 0000001295BC: D655009B 03FF3397 00007FFF
	v_mov_b32_e32 v153, 0                                      // 0000001295C8: 7F320280
	ds_store_b16_d16_hi v174, v155 offset:18                   // 0000001295CC: DA840012 00009BAE
	s_and_saveexec_b32 s2, s24                                 // 0000001295D4: BE822018
	s_cbranch_execz 29                                         // 0000001295D8: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2150>
	ds_load_b32 v154, v173 offset:40                           // 0000001295DC: D8D80028 9A0000AD
	s_waitcnt lgkmcnt(0)                                       // 0000001295E4: BF89FC07
	v_sub_f32_e32 v154, v154, v129                             // 0000001295E8: 0935039A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001295EC: BF870091
	v_mul_f32_e32 v155, 0x3fb8aa3b, v154                       // 0000001295F0: 113734FF 3FB8AA3B
	v_fma_f32 v156, 0x3fb8aa3b, v154, -v155                    // 0000001295F8: D613009C 866F34FF 3FB8AA3B
	v_rndne_f32_e32 v181, v155                                 // 000000129604: 7F6A479B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129608: BF870091
	v_dual_fmac_f32 v156, 0x32a5705f, v154 :: v_dual_sub_f32 v155, v155, v181// 00000012960C: C80B34FF 9C9B6B9B 32A5705F
	v_add_f32_e32 v155, v155, v156                             // 000000129618: 0737399B
	v_cvt_i32_f32_e32 v156, v181                               // 00000012961C: 7F3811B5
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v154                 // 000000129620: 7C3734FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000129628: BF870293
	v_exp_f32_e32 v155, v155                                   // 00000012962C: 7F364B9B
	.long 0xd71c009b                                           // 000000129630: D71C009B
	v_cndmask_b32_e32 v1, v155, v156, vcc_lo                   // 000000129634: 0203399B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129638: BF870121
	v_cndmask_b32_e32 v155, 0, v155, vcc_lo                    // 00000012963C: 03373680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v154                 // 000000129640: 7C3D34FF 42B17218
	v_cndmask_b32_e32 v154, 0x7f800000, v155, vcc_lo           // 000000129648: 033536FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000129650: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129654: BF870091
	v_bfe_u32 v155, v154, 16, 1                                // 000000129658: D610009B 0205219A
	v_add3_u32 v155, v154, v155, 0x7fff                        // 000000129660: D655009B 03FF379A 00007FFF
	ds_store_b16_d16_hi v174, v155 offset:20                   // 00000012966C: DA840014 00009BAE
	s_and_saveexec_b32 s2, s22                                 // 000000129674: BE822016
	s_cbranch_execz 30                                         // 000000129678: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21f4>
	ds_load_b32 v153, v173 offset:44                           // 00000012967C: D8D8002C 990000AD
	s_waitcnt lgkmcnt(0)                                       // 000000129684: BF89FC07
	v_sub_f32_e32 v153, v153, v129                             // 000000129688: 09330399
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012968C: BF870121
	v_mul_f32_e32 v155, 0x3fb8aa3b, v153                       // 000000129690: 113732FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 000000129698: 7C3732FF C2CE8ED0
	v_fma_f32 v156, 0x3fb8aa3b, v153, -v155                    // 0000001296A0: D613009C 866F32FF 3FB8AA3B
	v_rndne_f32_e32 v181, v155                                 // 0000001296AC: 7F6A479B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001296B0: BF870112
	v_fmac_f32_e32 v156, 0x32a5705f, v153                      // 0000001296B4: 573932FF 32A5705F
	v_sub_f32_e32 v155, v155, v181                             // 0000001296BC: 09376B9B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001296C0: BF870121
	v_add_f32_e32 v155, v155, v156                             // 0000001296C4: 0737399B
	v_cvt_i32_f32_e32 v156, v181                               // 0000001296C8: 7F3811B5
	v_exp_f32_e32 v155, v155                                   // 0000001296CC: 7F364B9B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001296D0: BF870095
	.long 0xd71c009b                                           // 0000001296D4: D71C009B
	v_cndmask_b32_e32 v1, v155, v156, vcc_lo                   // 0000001296D8: 0203399B
	v_cndmask_b32_e32 v155, 0, v155, vcc_lo                    // 0000001296DC: 03373680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 0000001296E0: 7C3D32FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001296E8: BF870002
	v_cndmask_b32_e32 v153, 0x7f800000, v155, vcc_lo           // 0000001296EC: 033336FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001296F4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001296F8: BF870121
	v_bfe_u32 v155, v153, 16, 1                                // 0000001296FC: D610009B 02052199
	v_mov_b32_e32 v156, 0                                      // 000000129704: 7F380280
	v_add3_u32 v181, v153, v155, 0x7fff                        // 000000129708: D65500B5 03FF3799 00007FFF
	v_mov_b32_e32 v155, 0                                      // 000000129714: 7F360280
	ds_store_b16_d16_hi v174, v181 offset:22                   // 000000129718: DA840016 0000B5AE
	s_and_saveexec_b32 s2, s9                                  // 000000129720: BE822009
	s_cbranch_execz 30                                         // 000000129724: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x22a0>
	ds_load_b32 v156, v173 offset:48                           // 000000129728: D8D80030 9C0000AD
	s_waitcnt lgkmcnt(0)                                       // 000000129730: BF89FC07
	v_sub_f32_e32 v156, v156, v129                             // 000000129734: 0939039C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129738: BF870091
	v_mul_f32_e32 v181, 0x3fb8aa3b, v156                       // 00000012973C: 116B38FF 3FB8AA3B
	v_fma_f32 v182, 0x3fb8aa3b, v156, -v181                    // 000000129744: D61300B6 86D738FF 3FB8AA3B
	v_rndne_f32_e32 v183, v181                                 // 000000129750: 7F6E47B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000129754: BF870221
	v_sub_f32_e32 v181, v181, v183                             // 000000129758: 096B6FB5
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v156                 // 00000012975C: 7C3738FF C2CE8ED0
	v_fmac_f32_e32 v182, 0x32a5705f, v156                      // 000000129764: 576D38FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012976C: BF870121
	v_add_f32_e32 v181, v181, v182                             // 000000129770: 076B6DB5
	v_cvt_i32_f32_e32 v182, v183                               // 000000129774: 7F6C11B7
	v_exp_f32_e32 v181, v181                                   // 000000129778: 7F6A4BB5
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012977C: BF870095
	.long 0xd71c00b5                                           // 000000129780: D71C00B5
	v_cndmask_b32_e32 v1, v181, v182, vcc_lo                   // 000000129784: 02036DB5
	v_cndmask_b32_e32 v181, 0, v181, vcc_lo                    // 000000129788: 036B6A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v156                 // 00000012978C: 7C3D38FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000129794: BF870002
	v_cndmask_b32_e32 v156, 0x7f800000, v181, vcc_lo           // 000000129798: 03396AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001297A0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001297A4: BF870091
	v_bfe_u32 v181, v156, 16, 1                                // 0000001297A8: D61000B5 0205219C
	v_add3_u32 v181, v156, v181, 0x7fff                        // 0000001297B0: D65500B5 03FF6B9C 00007FFF
	ds_store_b16_d16_hi v174, v181 offset:24                   // 0000001297BC: DA840018 0000B5AE
	s_and_saveexec_b32 s2, s8                                  // 0000001297C4: BE822008
	s_cbranch_execz 30                                         // 0000001297C8: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2344>
	ds_load_b32 v155, v173 offset:52                           // 0000001297CC: D8D80034 9B0000AD
	s_waitcnt lgkmcnt(0)                                       // 0000001297D4: BF89FC07
	v_sub_f32_e32 v155, v155, v129                             // 0000001297D8: 0937039B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001297DC: BF870121
	v_mul_f32_e32 v181, 0x3fb8aa3b, v155                       // 0000001297E0: 116B36FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v155                 // 0000001297E8: 7C3736FF C2CE8ED0
	v_fma_f32 v182, 0x3fb8aa3b, v155, -v181                    // 0000001297F0: D61300B6 86D736FF 3FB8AA3B
	v_rndne_f32_e32 v183, v181                                 // 0000001297FC: 7F6E47B5
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000129800: BF870112
	v_fmac_f32_e32 v182, 0x32a5705f, v155                      // 000000129804: 576D36FF 32A5705F
	v_sub_f32_e32 v181, v181, v183                             // 00000012980C: 096B6FB5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129810: BF870121
	v_add_f32_e32 v181, v181, v182                             // 000000129814: 076B6DB5
	v_cvt_i32_f32_e32 v182, v183                               // 000000129818: 7F6C11B7
	v_exp_f32_e32 v181, v181                                   // 00000012981C: 7F6A4BB5
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129820: BF870095
	.long 0xd71c00b5                                           // 000000129824: D71C00B5
	v_cndmask_b32_e32 v1, v181, v182, vcc_lo                   // 000000129828: 02036DB5
	v_cndmask_b32_e32 v181, 0, v181, vcc_lo                    // 00000012982C: 036B6A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v155                 // 000000129830: 7C3D36FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000129838: BF870002
	v_cndmask_b32_e32 v155, 0x7f800000, v181, vcc_lo           // 00000012983C: 03376AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000129844: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129848: BF870121
	v_bfe_u32 v181, v155, 16, 1                                // 00000012984C: D61000B5 0205219B
	v_mov_b32_e32 v182, 0                                      // 000000129854: 7F6C0280
	v_add3_u32 v183, v155, v181, 0x7fff                        // 000000129858: D65500B7 03FF6B9B 00007FFF
	v_mov_b32_e32 v181, 0                                      // 000000129864: 7F6A0280
	ds_store_b16_d16_hi v174, v183 offset:26                   // 000000129868: DA84001A 0000B7AE
	s_and_saveexec_b32 s2, s7                                  // 000000129870: BE822007
	s_cbranch_execz 29                                         // 000000129874: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x23ec>
	ds_load_b32 v182, v173 offset:56                           // 000000129878: D8D80038 B60000AD
	s_waitcnt lgkmcnt(0)                                       // 000000129880: BF89FC07
	v_sub_f32_e32 v182, v182, v129                             // 000000129884: 096D03B6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129888: BF870091
	v_mul_f32_e32 v183, 0x3fb8aa3b, v182                       // 00000012988C: 116F6CFF 3FB8AA3B
	v_fma_f32 v184, 0x3fb8aa3b, v182, -v183                    // 000000129894: D61300B8 86DF6CFF 3FB8AA3B
	v_rndne_f32_e32 v185, v183                                 // 0000001298A0: 7F7247B7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001298A4: BF870091
	v_dual_fmac_f32 v184, 0x32a5705f, v182 :: v_dual_sub_f32 v183, v183, v185// 0000001298A8: C80B6CFF B8B773B7 32A5705F
	v_add_f32_e32 v183, v183, v184                             // 0000001298B4: 076F71B7
	v_cvt_i32_f32_e32 v184, v185                               // 0000001298B8: 7F7011B9
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v182                 // 0000001298BC: 7C376CFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001298C4: BF870293
	v_exp_f32_e32 v183, v183                                   // 0000001298C8: 7F6E4BB7
	.long 0xd71c00b7                                           // 0000001298CC: D71C00B7
	v_cndmask_b32_e32 v1, v183, v184, vcc_lo                   // 0000001298D0: 020371B7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001298D4: BF870121
	v_cndmask_b32_e32 v183, 0, v183, vcc_lo                    // 0000001298D8: 036F6E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v182                 // 0000001298DC: 7C3D6CFF 42B17218
	v_cndmask_b32_e32 v182, 0x7f800000, v183, vcc_lo           // 0000001298E4: 036D6EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001298EC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001298F0: BF870091
	v_bfe_u32 v183, v182, 16, 1                                // 0000001298F4: D61000B7 020521B6
	v_add3_u32 v183, v182, v183, 0x7fff                        // 0000001298FC: D65500B7 03FF6FB6 00007FFF
	ds_store_b16_d16_hi v174, v183 offset:28                   // 000000129908: DA84001C 0000B7AE
	s_and_saveexec_b32 s2, s1                                  // 000000129910: BE822001
	s_cbranch_execz 30                                         // 000000129914: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2490>
	ds_load_b32 v181, v173 offset:60                           // 000000129918: D8D8003C B50000AD
	s_waitcnt lgkmcnt(0)                                       // 000000129920: BF89FC07
	v_sub_f32_e32 v181, v181, v129                             // 000000129924: 096B03B5
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129928: BF870121
	v_mul_f32_e32 v183, 0x3fb8aa3b, v181                       // 00000012992C: 116F6AFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v181                 // 000000129934: 7C376AFF C2CE8ED0
	v_fma_f32 v184, 0x3fb8aa3b, v181, -v183                    // 00000012993C: D61300B8 86DF6AFF 3FB8AA3B
	v_rndne_f32_e32 v185, v183                                 // 000000129948: 7F7247B7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012994C: BF870112
	v_fmac_f32_e32 v184, 0x32a5705f, v181                      // 000000129950: 57716AFF 32A5705F
	v_sub_f32_e32 v183, v183, v185                             // 000000129958: 096F73B7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012995C: BF870121
	v_add_f32_e32 v183, v183, v184                             // 000000129960: 076F71B7
	v_cvt_i32_f32_e32 v184, v185                               // 000000129964: 7F7011B9
	v_exp_f32_e32 v183, v183                                   // 000000129968: 7F6E4BB7
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012996C: BF870095
	.long 0xd71c00b7                                           // 000000129970: D71C00B7
	v_cndmask_b32_e32 v1, v183, v184, vcc_lo                   // 000000129974: 020371B7
	v_cndmask_b32_e32 v183, 0, v183, vcc_lo                    // 000000129978: 036F6E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v181                 // 00000012997C: 7C3D6AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000129984: BF870002
	v_cndmask_b32_e32 v181, 0x7f800000, v183, vcc_lo           // 000000129988: 036B6EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000129990: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000129994: BF8700A1
	v_bfe_u32 v183, v181, 16, 1                                // 000000129998: D61000B7 020521B5
	s_mov_b32 s1, exec_lo                                      // 0000001299A0: BE81007E
	v_add3_u32 v184, v181, v183, 0x7fff                        // 0000001299A4: D65500B8 03FF6FB5 00007FFF
	v_mov_b32_e32 v183, 0                                      // 0000001299B0: 7F6E0280
	ds_store_b16_d16_hi v174, v184 offset:30                   // 0000001299B4: DA84001E 0000B8AE
	v_cmpx_lt_f32_e32 0xefa18f08, v130                         // 0000001299BC: 7D2304FF EFA18F08
	s_cbranch_execz 26                                         // 0000001299C4: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2530>
	v_sub_f32_e32 v130, v130, v129                             // 0000001299C8: 09050382
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001299CC: BF870091
	v_mul_f32_e32 v183, 0x3fb8aa3b, v130                       // 0000001299D0: 116F04FF 3FB8AA3B
	v_fma_f32 v184, 0x3fb8aa3b, v130, -v183                    // 0000001299D8: D61300B8 86DF04FF 3FB8AA3B
	v_rndne_f32_e32 v185, v183                                 // 0000001299E4: 7F7247B7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001299E8: BF870091
	v_dual_fmac_f32 v184, 0x32a5705f, v130 :: v_dual_sub_f32 v183, v183, v185// 0000001299EC: C80B04FF B8B773B7 32A5705F
	v_add_f32_e32 v183, v183, v184                             // 0000001299F8: 076F71B7
	v_cvt_i32_f32_e32 v184, v185                               // 0000001299FC: 7F7011B9
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 000000129A00: 7C3704FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000129A08: BF870293
	v_exp_f32_e32 v183, v183                                   // 000000129A0C: 7F6E4BB7
	.long 0xd71c00b7                                           // 000000129A10: D71C00B7
	v_cndmask_b32_e32 v1, v183, v184, vcc_lo                   // 000000129A14: 020371B7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129A18: BF870121
	v_cndmask_b32_e32 v183, 0, v183, vcc_lo                    // 000000129A1C: 036F6E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 000000129A20: 7C3D04FF 42B17218
	v_cndmask_b32_e32 v183, 0x7f800000, v183, vcc_lo           // 000000129A28: 036F6EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000129A30: 8C7E017E
	v_add_f32_e32 v130, v132, v131                             // 000000129A34: 07050784
	ds_load_b32 v131, v175                                     // 000000129A38: D8D80000 830000AF
	v_add_f32_e32 v130, v130, v134                             // 000000129A40: 07050D82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129A44: BF870091
	v_add_f32_e32 v130, v130, v133                             // 000000129A48: 07050B82
	v_add_f32_e32 v130, v130, v136                             // 000000129A4C: 07051182
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129A50: BF870091
	v_add_f32_e32 v130, v130, v135                             // 000000129A54: 07050F82
	v_add_f32_e32 v130, v130, v150                             // 000000129A58: 07052D82
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129A5C: BF870091
	v_add_f32_e32 v130, v130, v149                             // 000000129A60: 07052B82
	v_add_f32_e32 v130, v130, v152                             // 000000129A64: 07053182
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129A68: BF870091
	v_add_f32_e32 v130, v130, v151                             // 000000129A6C: 07052F82
	v_add_f32_e32 v130, v130, v154                             // 000000129A70: 07053582
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129A74: BF870091
	v_add_f32_e32 v130, v130, v153                             // 000000129A78: 07053382
	v_add_f32_e32 v130, v130, v156                             // 000000129A7C: 07053982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129A80: BF870091
	v_add_f32_e32 v130, v130, v155                             // 000000129A84: 07053782
	v_add_f32_e32 v130, v130, v182                             // 000000129A88: 07056D82
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000129A8C: BF8700A1
	v_add_f32_e32 v130, v130, v181                             // 000000129A90: 07056B82
	s_waitcnt lgkmcnt(0)                                       // 000000129A94: BF89FC07
	v_fmac_f32_e32 v130, v183, v131                            // 000000129A98: 570507B7
	ds_store_b32 v172, v129                                    // 000000129A9C: D8340000 000081AC
	ds_store_b32 v175, v130                                    // 000000129AA4: D8340000 000082AF
	ds_store_b32 v176, v183                                    // 000000129AAC: D8340000 0000B7B0
	s_or_b32 exec_lo, exec_lo, s4                              // 000000129AB4: 8C7E047E
	ds_load_2addr_b32 v[155:156], v177 offset1:2               // 000000129AB8: D8DC0200 9B0000B1
	ds_load_2addr_b32 v[153:154], v177 offset0:4 offset1:6     // 000000129AC0: D8DC0604 990000B1
	ds_load_2addr_b32 v[151:152], v177 offset0:8 offset1:10    // 000000129AC8: D8DC0A08 970000B1
	ds_load_2addr_b32 v[149:150], v177 offset0:12 offset1:14   // 000000129AD0: D8DC0E0C 950000B1
	s_waitcnt lgkmcnt(3)                                       // 000000129AD8: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v155                         // 000000129ADC: 7C2536F2
	.long 0xd4120001                                           // 000000129AE0: D4120001
	v_cndmask_b32_e32 v1, 1.0, v156, vcc_lo                    // 000000129AE4: 020338F2
	s_waitcnt lgkmcnt(2)                                       // 000000129AE8: BF89FC27
	.long 0xd4120002                                           // 000000129AEC: D4120002
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 000000129AF0: 020332F2
	.long 0xd4120004                                           // 000000129AF4: D4120004
	v_cndmask_b32_e32 v1, 1.0, v154, vcc_lo                    // 000000129AF8: 020334F2
	s_and_b32 s1, vcc_lo, s1                                   // 000000129AFC: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 000000129B00: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v151                         // 000000129B04: 7C252EF2
	s_and_b32 s2, s1, s2                                       // 000000129B08: 8B020201
	.long 0xd4120001                                           // 000000129B0C: D4120001
	v_cndmask_b32_e32 v1, 1.0, v152, vcc_lo                    // 000000129B10: 020330F2
	s_and_b32 s4, s2, s4                                       // 000000129B14: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 000000129B18: BF89FC07
	.long 0xd4120002                                           // 000000129B1C: D4120002
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 000000129B20: 02032AF2
	s_and_b32 s4, s4, vcc_lo                                   // 000000129B24: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v150                         // 000000129B28: 7C252CF2
	s_and_b32 s1, s4, s1                                       // 000000129B2C: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000129B30: BF870499
	s_and_b32 s1, s1, s2                                       // 000000129B34: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 000000129B38: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129B3C: BF870099
	v_cndmask_b32_e64 v129, 0, 1, s1                           // 000000129B40: D5010081 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v129                           // 000000129B48: 7C9B0280
	ds_load_b128 v[129:132], v178                              // 000000129B4C: DBFC0000 810000B2
	ds_load_b128 v[133:136], v178 offset:16                    // 000000129B54: DBFC0010 850000B2
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 000000129B5C: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 000000129B60: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129B64: BF870099
	v_cndmask_b32_e64 v181, 0, 1, s1                           // 000000129B68: D50100B5 00050280
	v_readfirstlane_b32 s1, v181                               // 000000129B70: 7E0205B5
	s_bitcmp1_b32 s1, 0                                        // 000000129B74: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 000000129B78: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000129B7C: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000129B80: 8B6A017E
	s_cbranch_vccnz 63628                                      // 000000129B84: BFA4F88C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b8>
	v_dual_mul_f32 v120, v155, v120 :: v_dual_mul_f32 v121, v156, v121// 000000129B88: C8C6F19B 7878F39C
	v_dual_mul_f32 v122, v153, v122 :: v_dual_mul_f32 v123, v154, v123// 000000129B90: C8C6F599 7A7AF79A
	v_dual_mul_f32 v124, v151, v124 :: v_dual_mul_f32 v125, v152, v125// 000000129B98: C8C6F997 7C7CFB98
	v_dual_mul_f32 v126, v149, v126 :: v_dual_mul_f32 v127, v150, v127// 000000129BA0: C8C6FD95 7E7EFF96
	v_dual_mul_f32 v112, v155, v112 :: v_dual_mul_f32 v113, v156, v113// 000000129BA8: C8C6E19B 7070E39C
	v_dual_mul_f32 v114, v153, v114 :: v_dual_mul_f32 v115, v154, v115// 000000129BB0: C8C6E599 7272E79A
	v_dual_mul_f32 v116, v151, v116 :: v_dual_mul_f32 v117, v152, v117// 000000129BB8: C8C6E997 7474EB98
	v_dual_mul_f32 v118, v149, v118 :: v_dual_mul_f32 v119, v150, v119// 000000129BC0: C8C6ED95 7676EF96
	v_dual_mul_f32 v104, v155, v104 :: v_dual_mul_f32 v105, v156, v105// 000000129BC8: C8C6D19B 6868D39C
	v_dual_mul_f32 v106, v153, v106 :: v_dual_mul_f32 v107, v154, v107// 000000129BD0: C8C6D599 6A6AD79A
	v_dual_mul_f32 v108, v151, v108 :: v_dual_mul_f32 v109, v152, v109// 000000129BD8: C8C6D997 6C6CDB98
	v_dual_mul_f32 v110, v149, v110 :: v_dual_mul_f32 v111, v150, v111// 000000129BE0: C8C6DD95 6E6EDF96
	v_dual_mul_f32 v96, v155, v96 :: v_dual_mul_f32 v97, v156, v97// 000000129BE8: C8C6C19B 6060C39C
	v_dual_mul_f32 v98, v153, v98 :: v_dual_mul_f32 v99, v154, v99// 000000129BF0: C8C6C599 6262C79A
	v_dual_mul_f32 v100, v151, v100 :: v_dual_mul_f32 v101, v152, v101// 000000129BF8: C8C6C997 6464CB98
	v_dual_mul_f32 v102, v149, v102 :: v_dual_mul_f32 v103, v150, v103// 000000129C00: C8C6CD95 6666CF96
	v_dual_mul_f32 v88, v155, v88 :: v_dual_mul_f32 v89, v156, v89// 000000129C08: C8C6B19B 5858B39C
	v_dual_mul_f32 v90, v153, v90 :: v_dual_mul_f32 v91, v154, v91// 000000129C10: C8C6B599 5A5AB79A
	v_dual_mul_f32 v92, v151, v92 :: v_dual_mul_f32 v93, v152, v93// 000000129C18: C8C6B997 5C5CBB98
	v_dual_mul_f32 v94, v149, v94 :: v_dual_mul_f32 v95, v150, v95// 000000129C20: C8C6BD95 5E5EBF96
	v_dual_mul_f32 v80, v155, v80 :: v_dual_mul_f32 v81, v156, v81// 000000129C28: C8C6A19B 5050A39C
	v_dual_mul_f32 v82, v153, v82 :: v_dual_mul_f32 v83, v154, v83// 000000129C30: C8C6A599 5252A79A
	v_dual_mul_f32 v84, v151, v84 :: v_dual_mul_f32 v85, v152, v85// 000000129C38: C8C6A997 5454AB98
	v_dual_mul_f32 v86, v149, v86 :: v_dual_mul_f32 v87, v150, v87// 000000129C40: C8C6AD95 5656AF96
	v_dual_mul_f32 v72, v155, v72 :: v_dual_mul_f32 v73, v156, v73// 000000129C48: C8C6919B 4848939C
	v_dual_mul_f32 v74, v153, v74 :: v_dual_mul_f32 v75, v154, v75// 000000129C50: C8C69599 4A4A979A
	v_dual_mul_f32 v76, v151, v76 :: v_dual_mul_f32 v77, v152, v77// 000000129C58: C8C69997 4C4C9B98
	v_dual_mul_f32 v78, v149, v78 :: v_dual_mul_f32 v79, v150, v79// 000000129C60: C8C69D95 4E4E9F96
	v_dual_mul_f32 v64, v155, v64 :: v_dual_mul_f32 v65, v156, v65// 000000129C68: C8C6819B 4040839C
	v_dual_mul_f32 v66, v153, v66 :: v_dual_mul_f32 v67, v154, v67// 000000129C70: C8C68599 4242879A
	v_dual_mul_f32 v68, v151, v68 :: v_dual_mul_f32 v69, v152, v69// 000000129C78: C8C68997 44448B98
	v_dual_mul_f32 v70, v149, v70 :: v_dual_mul_f32 v71, v150, v71// 000000129C80: C8C68D95 46468F96
	v_dual_mul_f32 v56, v155, v56 :: v_dual_mul_f32 v57, v156, v57// 000000129C88: C8C6719B 3838739C
	v_dual_mul_f32 v58, v153, v58 :: v_dual_mul_f32 v59, v154, v59// 000000129C90: C8C67599 3A3A779A
	v_dual_mul_f32 v60, v151, v60 :: v_dual_mul_f32 v61, v152, v61// 000000129C98: C8C67997 3C3C7B98
	v_dual_mul_f32 v62, v149, v62 :: v_dual_mul_f32 v63, v150, v63// 000000129CA0: C8C67D95 3E3E7F96
	v_dual_mul_f32 v48, v155, v48 :: v_dual_mul_f32 v49, v156, v49// 000000129CA8: C8C6619B 3030639C
	v_dual_mul_f32 v50, v153, v50 :: v_dual_mul_f32 v51, v154, v51// 000000129CB0: C8C66599 3232679A
	v_dual_mul_f32 v52, v151, v52 :: v_dual_mul_f32 v53, v152, v53// 000000129CB8: C8C66997 34346B98
	v_dual_mul_f32 v54, v149, v54 :: v_dual_mul_f32 v55, v150, v55// 000000129CC0: C8C66D95 36366F96
	v_dual_mul_f32 v40, v155, v40 :: v_dual_mul_f32 v41, v156, v41// 000000129CC8: C8C6519B 2828539C
	v_dual_mul_f32 v42, v153, v42 :: v_dual_mul_f32 v43, v154, v43// 000000129CD0: C8C65599 2A2A579A
	v_dual_mul_f32 v44, v151, v44 :: v_dual_mul_f32 v45, v152, v45// 000000129CD8: C8C65997 2C2C5B98
	v_dual_mul_f32 v46, v149, v46 :: v_dual_mul_f32 v47, v150, v47// 000000129CE0: C8C65D95 2E2E5F96
	v_dual_mul_f32 v32, v155, v32 :: v_dual_mul_f32 v33, v156, v33// 000000129CE8: C8C6419B 2020439C
	v_dual_mul_f32 v34, v153, v34 :: v_dual_mul_f32 v35, v154, v35// 000000129CF0: C8C64599 2222479A
	v_dual_mul_f32 v36, v151, v36 :: v_dual_mul_f32 v37, v152, v37// 000000129CF8: C8C64997 24244B98
	v_dual_mul_f32 v38, v149, v38 :: v_dual_mul_f32 v39, v150, v39// 000000129D00: C8C64D95 26264F96
	v_dual_mul_f32 v24, v155, v24 :: v_dual_mul_f32 v25, v156, v25// 000000129D08: C8C6319B 1818339C
	v_dual_mul_f32 v26, v153, v26 :: v_dual_mul_f32 v27, v154, v27// 000000129D10: C8C63599 1A1A379A
	v_dual_mul_f32 v28, v151, v28 :: v_dual_mul_f32 v29, v152, v29// 000000129D18: C8C63997 1C1C3B98
	v_dual_mul_f32 v30, v149, v30 :: v_dual_mul_f32 v31, v150, v31// 000000129D20: C8C63D95 1E1E3F96
	v_dual_mul_f32 v16, v155, v16 :: v_dual_mul_f32 v17, v156, v17// 000000129D28: C8C6219B 1010239C
	v_dual_mul_f32 v18, v153, v18 :: v_dual_mul_f32 v19, v154, v19// 000000129D30: C8C62599 1212279A
	v_dual_mul_f32 v20, v151, v20 :: v_dual_mul_f32 v21, v152, v21// 000000129D38: C8C62997 14142B98
	v_dual_mul_f32 v22, v149, v22 :: v_dual_mul_f32 v23, v150, v23// 000000129D40: C8C62D95 16162F96
	v_dual_mul_f32 v8, v155, v8 :: v_dual_mul_f32 v9, v156, v9 // 000000129D48: C8C6119B 0808139C
	v_dual_mul_f32 v10, v153, v10 :: v_dual_mul_f32 v11, v154, v11// 000000129D50: C8C61599 0A0A179A
	v_dual_mul_f32 v12, v151, v12 :: v_dual_mul_f32 v13, v152, v13// 000000129D58: C8C61997 0C0C1B98
	v_dual_mul_f32 v14, v149, v14 :: v_dual_mul_f32 v15, v150, v15// 000000129D60: C8C61D95 0E0E1F96
	v_dual_mul_f32 v0, v155, v0 :: v_dual_mul_f32 v1, v156, v1 // 000000129D68: C8C6019B 0000039C
	v_dual_mul_f32 v2, v153, v2 :: v_dual_mul_f32 v3, v154, v3 // 000000129D70: C8C60599 0202079A
	v_dual_mul_f32 v4, v151, v4 :: v_dual_mul_f32 v5, v152, v5 // 000000129D78: C8C60997 04040B98
	v_dual_mul_f32 v6, v149, v6 :: v_dual_mul_f32 v7, v150, v7 // 000000129D80: C8C60D95 06060F96
	s_branch 63499                                             // 000000129D88: BFA0F80B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b8>
	v_lshlrev_b32_e32 v128, 2, v162                            // 000000129D8C: 31014482
	.long 0xd700008e                                           // 000000129D90: D700008E
	v_cndmask_b32_e32 v1, s18, v142, vcc_lo                    // 000000129D94: 02031C12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000129D98: BF870191
	v_add_co_ci_u32_e64 v143, null, s19, v143, s0              // 000000129D9C: D5207C8F 00031E13
	v_lshl_or_b32 v128, v157, 6, v128                          // 000000129DA4: D6560080 06010D9D
	s_waitcnt vmcnt(0)                                         // 000000129DAC: BF8903F7
	v_or_b32_e32 v140, v158, v162                              // 000000129DB0: 3919459E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000129DB4: BF870002
	v_add_nc_u32_e32 v132, 0xf000, v128                        // 000000129DB8: 4B0900FF 0000F000
	v_lshlrev_b32_e32 v128, 9, v141                            // 000000129DC0: 31011A89
	ds_load_2addr_b32 v[138:139], v132 offset0:192 offset1:194 // 000000129DC4: D8DCC2C0 8A000084
	ds_load_2addr_b32 v[136:137], v132 offset0:196 offset1:198 // 000000129DCC: D8DCC6C4 88000084
	ds_load_2addr_b32 v[134:135], v132 offset0:200 offset1:202 // 000000129DD4: D8DCCAC8 86000084
	ds_load_2addr_b32 v[132:133], v132 offset0:204 offset1:206 // 000000129DDC: D8DCCECC 84000084
	s_waitcnt lgkmcnt(3)                                       // 000000129DE4: BF89FC37
	v_div_scale_f32 v144, null, v138, v138, 1.0                // 000000129DE8: D6FC7C90 03CB158A
	v_div_scale_f32 v141, vcc_lo, 1.0, v138, 1.0               // 000000129DF0: D6FC6A8D 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000129DF8: BF870292
	v_rcp_f32_e32 v145, v144                                   // 000000129DFC: 7F225590
	v_fma_f32 v129, -v144, v145, 1.0                           // 000000129E00: D6130081 23CB2390
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129E08: BF870121
	v_fmac_f32_e32 v145, v129, v145                            // 000000129E0C: 57232381
	v_ashrrev_i32_e32 v129, 31, v128                           // 000000129E10: 3503009F
	v_mul_f32_e32 v146, v141, v145                             // 000000129E14: 1125238D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000129E18: BF8700A2
	.long 0xd73c0082                                           // 000000129E1C: D73C0082
	v_cndmask_b32_e32 v1, 1, v128, vcc_lo                      // 000000129E20: 02030081
	.long 0xd7000080                                           // 000000129E24: D7000080
	v_cndmask_b32_e32 v1, v142, v160, vcc_lo                   // 000000129E28: 0203418E
	v_add_co_ci_u32_e64 v129, null, 0, v143, s0                // 000000129E2C: D5207C81 00031E80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000129E34: BF870214
	v_fma_f32 v147, -v144, v146, v141                          // 000000129E38: D6130093 26372590
	.long 0xd7000082                                           // 000000129E40: D7000082
	v_cndmask_b32_e32 v1, s16, v130, vcc_lo                    // 000000129E44: 02030410
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000129E48: BF870191
	v_add_co_ci_u32_e64 v131, null, s17, v131, s0              // 000000129E4C: D5207C83 00030611
	v_fmac_f32_e32 v146, v147, v145                            // 000000129E54: 57252393
	.long 0xd4440000                                           // 000000129E58: D4440000
	v_cndmask_b32_e32 v1, s14, v140, vcc_lo                    // 000000129E5C: 0203180E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129E60: BF870092
	v_fma_f32 v141, -v144, v146, v141                          // 000000129E64: D613008D 26372590
	v_div_fmas_f32 v141, v141, v145, v146                      // 000000129E6C: D637008D 064B238D
	.long 0xd7006a82                                           // 000000129E74: D7006A82
	v_cndmask_b32_e32 v1, v130, v160, vcc_lo                   // 000000129E78: 02034182
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000129E7C: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, vcc_lo            // 000000129E80: D5207C83 01AB0680
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 000000129E88: D627008A 03CB158D
	s_and_saveexec_b32 s1, s0                                  // 000000129E90: BE812000
	s_cbranch_execz 70                                         // 000000129E94: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2ab0>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000129E98: BF870112
	v_mad_i64_i32 v[141:142], null, 0x6000, v140, v[130:131]   // 000000129E9C: D6FF7C8D 060B18FF 00006000
	v_mul_f32_e32 v120, v138, v120                             // 000000129EA8: 10F0F18A
	global_load_u16 v141, v[141:142], off offset:512           // 000000129EAC: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000129EB4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000129EB8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129EBC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000129EC0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000129EC8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000129ED4: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000129ED8: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000129EDC: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000129EE0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000129EE8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000129EF0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000129EF4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000129EF8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000129EFC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129F00: BF870095
	.long 0xd71c008e                                           // 000000129F04: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000129F08: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000129F0C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000129F10: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129F18: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000129F1C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000129F24: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129F28: BF870091
	v_div_scale_f32 v142, null, v141, v141, v120               // 000000129F2C: D6FC7C8E 05E31B8D
	v_rcp_f32_e32 v143, v142                                   // 000000129F34: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129F38: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000129F3C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000129F44: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v120, v141, v120             // 000000129F48: D6FC6A90 05E31B78
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129F50: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000129F54: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000129F58: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129F60: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000129F64: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000129F68: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129F70: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000129F74: D637008E 06471F8E
	v_div_fixup_f32 v120, v142, v141, v120                     // 000000129F7C: D6270078 05E31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v140, v[128:129]   // 000000129F84: D6FF7C8D 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129F90: BF870092
	v_bfe_u32 v143, v120, 16, 1                                // 000000129F94: D610008F 02052178
	v_add3_u32 v120, v120, v143, 0x7fff                        // 000000129F9C: D6550078 03FF1F78 00007FFF
	global_store_d16_hi_b16 v[141:142], v120, off              // 000000129FA8: DC960000 007C788D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000129FB0: 8C7E017E
	v_div_scale_f32 v120, null, v139, v139, 1.0                // 000000129FB4: D6FC7C78 03CB178B
	v_div_scale_f32 v143, vcc_lo, 1.0, v139, 1.0               // 000000129FBC: D6FC6A8F 03CB16F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000129FC4: BF870292
	v_rcp_f32_e32 v141, v120                                   // 000000129FC8: 7F1A5578
	v_fma_f32 v142, -v120, v141, 1.0                           // 000000129FCC: D613008E 23CB1B78
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129FD4: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000129FD8: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000129FDC: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129FE0: BF870091
	v_fma_f32 v144, -v120, v142, v143                          // 000000129FE4: D6130090 263F1D78
	v_fmac_f32_e32 v142, v144, v141                            // 000000129FEC: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000129FF0: BF870091
	v_fma_f32 v120, -v120, v142, v143                          // 000000129FF4: D6130078 263F1D78
	v_div_fmas_f32 v141, v120, v141, v142                      // 000000129FFC: D637008D 063B1B78
	v_or_b32_e32 v120, 2, v140                                 // 00000012A004: 38F11882
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012A008: BF870112
	v_div_fixup_f32 v139, v141, v139, 1.0                      // 00000012A00C: D627008B 03CB178D
	.long 0xd4440001                                           // 00000012A014: D4440001
	v_cndmask_b32_e32 v1, s14, v120, vcc_lo                    // 00000012A018: 0202F00E
	s_and_saveexec_b32 s2, s1                                  // 00000012A01C: BE822001
	s_cbranch_execz 69                                         // 00000012A020: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2c38>
	v_mad_i64_i32 v[141:142], null, 0x6000, v120, v[130:131]   // 00000012A024: D6FF7C8D 060AF0FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 00000012A030: 10F2F38B
	global_load_u16 v141, v[141:142], off offset:512           // 00000012A034: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000012A03C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000012A040: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A044: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000012A048: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000012A050: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000012A05C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012A060: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000012A064: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000012A068: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000012A070: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012A078: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000012A07C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000012A080: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000012A084: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A088: BF870095
	.long 0xd71c008e                                           // 00000012A08C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000012A090: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000012A094: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000012A098: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A0A0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000012A0A4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000012A0AC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A0B0: BF870091
	v_div_scale_f32 v142, null, v141, v141, v121               // 00000012A0B4: D6FC7C8E 05E71B8D
	v_rcp_f32_e32 v143, v142                                   // 00000012A0BC: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A0C0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000012A0C4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000012A0CC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v141, v121             // 00000012A0D0: D6FC6A90 05E71B79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A0D8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000012A0DC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000012A0E0: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A0E8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000012A0EC: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000012A0F0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A0F8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000012A0FC: D637008E 06471F8E
	v_div_fixup_f32 v121, v142, v141, v121                     // 00000012A104: D6270079 05E71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v120, v[128:129]   // 00000012A10C: D6FF7C8D 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A118: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 00000012A11C: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 00000012A124: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[141:142], v121, off              // 00000012A130: DC960000 007C798D
	s_or_b32 exec_lo, exec_lo, s2                              // 00000012A138: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 00000012A13C: BF89FC27
	v_div_scale_f32 v121, null, v136, v136, 1.0                // 00000012A140: D6FC7C79 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 00000012A148: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012A150: BF870292
	v_rcp_f32_e32 v141, v121                                   // 00000012A154: 7F1A5579
	v_fma_f32 v142, -v121, v141, 1.0                           // 00000012A158: D613008E 23CB1B79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A160: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000012A164: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000012A168: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A16C: BF870091
	v_fma_f32 v144, -v121, v142, v143                          // 00000012A170: D6130090 263F1D79
	v_fmac_f32_e32 v142, v144, v141                            // 00000012A178: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A17C: BF870091
	v_fma_f32 v121, -v121, v142, v143                          // 00000012A180: D6130079 263F1D79
	v_div_fmas_f32 v141, v121, v141, v142                      // 00000012A188: D637008D 063B1B79
	v_or_b32_e32 v121, 4, v140                                 // 00000012A190: 38F31884
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012A194: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 00000012A198: D6270088 03CB118D
	.long 0xd4440002                                           // 00000012A1A0: D4440002
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 00000012A1A4: 0202F20E
	s_and_saveexec_b32 s3, s2                                  // 00000012A1A8: BE832002
	s_cbranch_execz 69                                         // 00000012A1AC: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2dc4>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[130:131]   // 00000012A1B0: D6FF7C8D 060AF2FF 00006000
	v_mul_f32_e32 v122, v136, v122                             // 00000012A1BC: 10F4F588
	global_load_u16 v141, v[141:142], off offset:512           // 00000012A1C0: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000012A1C8: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000012A1CC: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A1D0: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000012A1D4: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000012A1DC: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000012A1E8: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012A1EC: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000012A1F0: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000012A1F4: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000012A1FC: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012A204: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000012A208: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000012A20C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000012A210: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A214: BF870095
	.long 0xd71c008e                                           // 00000012A218: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000012A21C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000012A220: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000012A224: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A22C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000012A230: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000012A238: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A23C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 00000012A240: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000012A248: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A24C: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000012A250: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000012A258: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 00000012A25C: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A264: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000012A268: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000012A26C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A274: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000012A278: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000012A27C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A284: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000012A288: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 00000012A290: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[128:129]   // 00000012A298: D6FF7C8D 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A2A4: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 00000012A2A8: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 00000012A2B0: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 00000012A2BC: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s3                              // 00000012A2C4: 8C7E037E
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 00000012A2C8: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 00000012A2D0: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012A2D8: BF870292
	v_rcp_f32_e32 v141, v122                                   // 00000012A2DC: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 00000012A2E0: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A2E8: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000012A2EC: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000012A2F0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A2F4: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 00000012A2F8: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 00000012A300: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A304: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 00000012A308: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 00000012A310: D637008D 063B1B7A
	v_or_b32_e32 v122, 6, v140                                 // 00000012A318: 38F51886
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012A31C: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 00000012A320: D6270089 03CB138D
	.long 0xd4440003                                           // 00000012A328: D4440003
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 00000012A32C: 0202F40E
	s_and_saveexec_b32 s4, s3                                  // 00000012A330: BE842003
	s_cbranch_execz 69                                         // 00000012A334: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2f4c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[130:131]   // 00000012A338: D6FF7C8D 060AF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 00000012A344: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 00000012A348: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000012A350: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000012A354: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A358: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000012A35C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000012A364: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000012A370: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012A374: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000012A378: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000012A37C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000012A384: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012A38C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000012A390: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000012A394: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000012A398: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A39C: BF870095
	.long 0xd71c008e                                           // 00000012A3A0: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000012A3A4: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000012A3A8: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000012A3AC: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A3B4: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000012A3B8: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000012A3C0: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A3C4: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 00000012A3C8: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000012A3D0: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A3D4: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000012A3D8: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000012A3E0: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 00000012A3E4: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A3EC: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000012A3F0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000012A3F4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A3FC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000012A400: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000012A404: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A40C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000012A410: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 00000012A418: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[128:129]   // 00000012A420: D6FF7C8D 0602F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A42C: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 00000012A430: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 00000012A438: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 00000012A444: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012A44C: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 00000012A450: BF89FC17
	v_div_scale_f32 v123, null, v134, v134, 1.0                // 00000012A454: D6FC7C7B 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 00000012A45C: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012A464: BF870292
	v_rcp_f32_e32 v141, v123                                   // 00000012A468: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 00000012A46C: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A474: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000012A478: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000012A47C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A480: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 00000012A484: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 00000012A48C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A490: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 00000012A494: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 00000012A49C: D637008D 063B1B7B
	v_or_b32_e32 v123, 8, v140                                 // 00000012A4A4: 38F71888
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012A4A8: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 00000012A4AC: D6270086 03CB0D8D
	.long 0xd4440004                                           // 00000012A4B4: D4440004
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 00000012A4B8: 0202F60E
	s_and_saveexec_b32 s5, s4                                  // 00000012A4BC: BE852004
	s_cbranch_execz 69                                         // 00000012A4C0: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x30d8>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[130:131]   // 00000012A4C4: D6FF7C8D 060AF6FF 00006000
	v_mul_f32_e32 v124, v134, v124                             // 00000012A4D0: 10F8F986
	global_load_u16 v141, v[141:142], off offset:512           // 00000012A4D4: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000012A4DC: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000012A4E0: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A4E4: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000012A4E8: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000012A4F0: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000012A4FC: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012A500: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000012A504: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000012A508: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000012A510: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012A518: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000012A51C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000012A520: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000012A524: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A528: BF870095
	.long 0xd71c008e                                           // 00000012A52C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000012A530: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000012A534: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000012A538: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A540: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000012A544: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000012A54C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A550: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 00000012A554: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 00000012A55C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A560: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000012A564: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000012A56C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 00000012A570: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A578: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000012A57C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000012A580: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A588: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000012A58C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000012A590: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A598: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000012A59C: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 00000012A5A4: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[128:129]   // 00000012A5AC: D6FF7C8D 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A5B8: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 00000012A5BC: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 00000012A5C4: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 00000012A5D0: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s5                              // 00000012A5D8: 8C7E057E
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 00000012A5DC: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 00000012A5E4: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012A5EC: BF870292
	v_rcp_f32_e32 v141, v124                                   // 00000012A5F0: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 00000012A5F4: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A5FC: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000012A600: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000012A604: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A608: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 00000012A60C: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 00000012A614: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A618: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 00000012A61C: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 00000012A624: D637008D 063B1B7C
	v_or_b32_e32 v124, 10, v140                                // 00000012A62C: 38F9188A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012A630: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 00000012A634: D6270087 03CB0F8D
	.long 0xd4440005                                           // 00000012A63C: D4440005
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 00000012A640: 0202F80E
	s_and_saveexec_b32 s6, s5                                  // 00000012A644: BE862005
	s_cbranch_execz 69                                         // 00000012A648: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3260>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[130:131]   // 00000012A64C: D6FF7C8D 060AF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 00000012A658: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 00000012A65C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000012A664: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000012A668: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A66C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000012A670: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000012A678: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000012A684: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012A688: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000012A68C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000012A690: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000012A698: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012A6A0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000012A6A4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000012A6A8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000012A6AC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A6B0: BF870095
	.long 0xd71c008e                                           // 00000012A6B4: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000012A6B8: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000012A6BC: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000012A6C0: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A6C8: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000012A6CC: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000012A6D4: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A6D8: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 00000012A6DC: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 00000012A6E4: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A6E8: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000012A6EC: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000012A6F4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 00000012A6F8: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A700: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000012A704: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000012A708: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A710: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000012A714: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000012A718: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A720: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000012A724: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 00000012A72C: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[128:129]   // 00000012A734: D6FF7C8D 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A740: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 00000012A744: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 00000012A74C: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 00000012A758: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s6                              // 00000012A760: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 00000012A764: BF89FC07
	v_div_scale_f32 v125, null, v132, v132, 1.0                // 00000012A768: D6FC7C7D 03CB0984
	v_div_scale_f32 v143, vcc_lo, 1.0, v132, 1.0               // 00000012A770: D6FC6A8F 03CB08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012A778: BF870292
	v_rcp_f32_e32 v141, v125                                   // 00000012A77C: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 00000012A780: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A788: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000012A78C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000012A790: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A794: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 00000012A798: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 00000012A7A0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A7A4: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 00000012A7A8: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 00000012A7B0: D637008D 063B1B7D
	v_or_b32_e32 v125, 12, v140                                // 00000012A7B8: 38FB188C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012A7BC: BF870112
	v_div_fixup_f32 v132, v141, v132, 1.0                      // 00000012A7C0: D6270084 03CB098D
	.long 0xd4440006                                           // 00000012A7C8: D4440006
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 00000012A7CC: 0202FA0E
	s_and_saveexec_b32 s7, s6                                  // 00000012A7D0: BE872006
	s_cbranch_execz 69                                         // 00000012A7D4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x33ec>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[130:131]   // 00000012A7D8: D6FF7C8D 060AFAFF 00006000
	v_mul_f32_e32 v126, v132, v126                             // 00000012A7E4: 10FCFD84
	global_load_u16 v141, v[141:142], off offset:512           // 00000012A7E8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000012A7F0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000012A7F4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A7F8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000012A7FC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000012A804: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000012A810: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012A814: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000012A818: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000012A81C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000012A824: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012A82C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000012A830: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000012A834: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000012A838: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A83C: BF870095
	.long 0xd71c008e                                           // 00000012A840: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000012A844: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000012A848: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000012A84C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A854: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000012A858: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000012A860: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A864: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 00000012A868: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000012A870: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A874: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000012A878: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000012A880: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 00000012A884: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A88C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000012A890: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000012A894: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A89C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000012A8A0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000012A8A4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A8AC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000012A8B0: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 00000012A8B8: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[128:129]   // 00000012A8C0: D6FF7C8D 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A8CC: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 00000012A8D0: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 00000012A8D8: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 00000012A8E4: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s7                              // 00000012A8EC: 8C7E077E
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 00000012A8F0: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 00000012A8F8: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012A900: BF870292
	v_rcp_f32_e32 v141, v126                                   // 00000012A904: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 00000012A908: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A910: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000012A914: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000012A918: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A91C: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 00000012A920: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 00000012A928: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012A92C: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 00000012A930: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 00000012A938: D637008D 063B1B7E
	v_or_b32_e32 v126, 14, v140                                // 00000012A940: 38FD188E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012A944: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 00000012A948: D6270085 03CB0B8D
	.long 0xd4440007                                           // 00000012A950: D4440007
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 00000012A954: 0202FC0E
	s_and_saveexec_b32 s8, s7                                  // 00000012A958: BE882007
	s_cbranch_execnz 361                                       // 00000012A95C: BFA60169 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a04>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012A960: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012A964: BE882000
	s_cbranch_execnz 430                                       // 00000012A968: BFA601AE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3b24>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012A96C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012A970: BE882001
	s_cbranch_execnz 499                                       // 00000012A974: BFA601F3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c44>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012A978: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012A97C: BE882002
	s_cbranch_execnz 568                                       // 00000012A980: BFA60238 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3d64>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012A984: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012A988: BE882003
	s_cbranch_execnz 637                                       // 00000012A98C: BFA6027D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e84>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012A990: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012A994: BE882004
	s_cbranch_execnz 706                                       // 00000012A998: BFA602C2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fa4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012A99C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012A9A0: BE882005
	s_cbranch_execnz 775                                       // 00000012A9A4: BFA60307 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012A9A8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012A9AC: BE882006
	s_cbranch_execnz 844                                       // 00000012A9B0: BFA6034C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012A9B4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012A9B8: BE882007
	s_cbranch_execnz 913                                       // 00000012A9BC: BFA60391 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4304>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012A9C0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012A9C4: BE882000
	s_cbranch_execnz 982                                       // 00000012A9C8: BFA603D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4424>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012A9CC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012A9D0: BE882001
	s_cbranch_execnz 1051                                      // 00000012A9D4: BFA6041B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4544>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012A9D8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012A9DC: BE882002
	s_cbranch_execnz 1120                                      // 00000012A9E0: BFA60460 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4664>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012A9E4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012A9E8: BE882003
	s_cbranch_execnz 1189                                      // 00000012A9EC: BFA604A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4784>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012A9F0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012A9F4: BE882004
	s_cbranch_execnz 1258                                      // 00000012A9F8: BFA604EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x48a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012A9FC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012AA00: BE882005
	s_cbranch_execnz 1327                                      // 00000012AA04: BFA6052F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x49c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AA08: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012AA0C: BE882006
	s_cbranch_execnz 1396                                      // 00000012AA10: BFA60574 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4ae4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AA14: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012AA18: BE882007
	s_cbranch_execnz 1465                                      // 00000012AA1C: BFA605B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4c04>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AA20: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012AA24: BE882000
	s_cbranch_execnz 1534                                      // 00000012AA28: BFA605FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4d24>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AA2C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012AA30: BE882001
	s_cbranch_execnz 1603                                      // 00000012AA34: BFA60643 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4e44>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AA38: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012AA3C: BE882002
	s_cbranch_execnz 1672                                      // 00000012AA40: BFA60688 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4f64>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AA44: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012AA48: BE882003
	s_cbranch_execnz 1741                                      // 00000012AA4C: BFA606CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5084>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AA50: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012AA54: BE882004
	s_cbranch_execnz 1810                                      // 00000012AA58: BFA60712 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x51a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AA5C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012AA60: BE882005
	s_cbranch_execnz 1879                                      // 00000012AA64: BFA60757 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x52c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AA68: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012AA6C: BE882006
	s_cbranch_execnz 1948                                      // 00000012AA70: BFA6079C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x53e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AA74: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012AA78: BE882007
	s_cbranch_execnz 2017                                      // 00000012AA7C: BFA607E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5504>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AA80: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012AA84: BE882000
	s_cbranch_execnz 2086                                      // 00000012AA88: BFA60826 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5624>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AA8C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012AA90: BE882001
	s_cbranch_execnz 2155                                      // 00000012AA94: BFA6086B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5744>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AA98: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012AA9C: BE882002
	s_cbranch_execnz 2224                                      // 00000012AAA0: BFA608B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5864>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AAA4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012AAA8: BE882003
	s_cbranch_execnz 2293                                      // 00000012AAAC: BFA608F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5984>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AAB0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012AAB4: BE882004
	s_cbranch_execnz 2362                                      // 00000012AAB8: BFA6093A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5aa4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AABC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012AAC0: BE882005
	s_cbranch_execnz 2431                                      // 00000012AAC4: BFA6097F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5bc4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AAC8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012AACC: BE882006
	s_cbranch_execnz 2500                                      // 00000012AAD0: BFA609C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5ce4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AAD4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012AAD8: BE882007
	s_cbranch_execnz 2569                                      // 00000012AADC: BFA60A09 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5e04>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AAE0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012AAE4: BE882000
	s_cbranch_execnz 2638                                      // 00000012AAE8: BFA60A4E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5f24>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AAEC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012AAF0: BE882001
	s_cbranch_execnz 2707                                      // 00000012AAF4: BFA60A93 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6044>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AAF8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012AAFC: BE882002
	s_cbranch_execnz 2776                                      // 00000012AB00: BFA60AD8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6164>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AB04: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012AB08: BE882003
	s_cbranch_execnz 2845                                      // 00000012AB0C: BFA60B1D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6284>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AB10: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012AB14: BE882004
	s_cbranch_execnz 2914                                      // 00000012AB18: BFA60B62 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x63a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AB1C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012AB20: BE882005
	s_cbranch_execnz 2983                                      // 00000012AB24: BFA60BA7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x64c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AB28: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012AB2C: BE882006
	s_cbranch_execnz 3052                                      // 00000012AB30: BFA60BEC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x65e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AB34: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012AB38: BE882007
	s_cbranch_execnz 3121                                      // 00000012AB3C: BFA60C31 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6704>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AB40: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012AB44: BE882000
	s_cbranch_execnz 3190                                      // 00000012AB48: BFA60C76 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6824>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AB4C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012AB50: BE882001
	s_cbranch_execnz 3259                                      // 00000012AB54: BFA60CBB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6944>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AB58: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012AB5C: BE882002
	s_cbranch_execnz 3328                                      // 00000012AB60: BFA60D00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6a64>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AB64: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012AB68: BE882003
	s_cbranch_execnz 3397                                      // 00000012AB6C: BFA60D45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6b84>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AB70: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012AB74: BE882004
	s_cbranch_execnz 3466                                      // 00000012AB78: BFA60D8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6ca4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AB7C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012AB80: BE882005
	s_cbranch_execnz 3535                                      // 00000012AB84: BFA60DCF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6dc4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AB88: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012AB8C: BE882006
	s_cbranch_execnz 3604                                      // 00000012AB90: BFA60E14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6ee4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AB94: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012AB98: BE882007
	s_cbranch_execnz 3673                                      // 00000012AB9C: BFA60E59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7004>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ABA0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012ABA4: BE882000
	s_cbranch_execnz 3742                                      // 00000012ABA8: BFA60E9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7124>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ABAC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012ABB0: BE882001
	s_cbranch_execnz 3811                                      // 00000012ABB4: BFA60EE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7244>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ABB8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012ABBC: BE882002
	s_cbranch_execnz 3880                                      // 00000012ABC0: BFA60F28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7364>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ABC4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012ABC8: BE882003
	s_cbranch_execnz 3949                                      // 00000012ABCC: BFA60F6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7484>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ABD0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012ABD4: BE882004
	s_cbranch_execnz 4018                                      // 00000012ABD8: BFA60FB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x75a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ABDC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012ABE0: BE882005
	s_cbranch_execnz 4087                                      // 00000012ABE4: BFA60FF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x76c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ABE8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012ABEC: BE882006
	s_cbranch_execnz 4156                                      // 00000012ABF0: BFA6103C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x77e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ABF4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012ABF8: BE882007
	s_cbranch_execnz 4225                                      // 00000012ABFC: BFA61081 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7904>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AC00: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012AC04: BE882000
	s_cbranch_execnz 4294                                      // 00000012AC08: BFA610C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7a24>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AC0C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012AC10: BE882001
	s_cbranch_execnz 4363                                      // 00000012AC14: BFA6110B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7b44>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AC18: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012AC1C: BE882002
	s_cbranch_execnz 4432                                      // 00000012AC20: BFA61150 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7c64>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AC24: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012AC28: BE882003
	s_cbranch_execnz 4501                                      // 00000012AC2C: BFA61195 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7d84>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AC30: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012AC34: BE882004
	s_cbranch_execnz 4570                                      // 00000012AC38: BFA611DA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7ea4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AC3C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012AC40: BE882005
	s_cbranch_execnz 4639                                      // 00000012AC44: BFA6121F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7fc4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AC48: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012AC4C: BE882006
	s_cbranch_execnz 4708                                      // 00000012AC50: BFA61264 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x80e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AC54: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012AC58: BE882007
	s_cbranch_execnz 4777                                      // 00000012AC5C: BFA612A9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8204>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AC60: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012AC64: BE882000
	s_cbranch_execnz 4846                                      // 00000012AC68: BFA612EE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8324>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AC6C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012AC70: BE882001
	s_cbranch_execnz 4915                                      // 00000012AC74: BFA61333 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8444>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AC78: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012AC7C: BE882002
	s_cbranch_execnz 4984                                      // 00000012AC80: BFA61378 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8564>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AC84: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012AC88: BE882003
	s_cbranch_execnz 5053                                      // 00000012AC8C: BFA613BD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8684>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AC90: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012AC94: BE882004
	s_cbranch_execnz 5122                                      // 00000012AC98: BFA61402 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x87a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AC9C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012ACA0: BE882005
	s_cbranch_execnz 5191                                      // 00000012ACA4: BFA61447 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x88c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ACA8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012ACAC: BE882006
	s_cbranch_execnz 5260                                      // 00000012ACB0: BFA6148C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x89e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ACB4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012ACB8: BE882007
	s_cbranch_execnz 5329                                      // 00000012ACBC: BFA614D1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b04>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ACC0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012ACC4: BE882000
	s_cbranch_execnz 5398                                      // 00000012ACC8: BFA61516 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8c24>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ACCC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012ACD0: BE882001
	s_cbranch_execnz 5467                                      // 00000012ACD4: BFA6155B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8d44>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ACD8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012ACDC: BE882002
	s_cbranch_execnz 5536                                      // 00000012ACE0: BFA615A0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8e64>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ACE4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012ACE8: BE882003
	s_cbranch_execnz 5605                                      // 00000012ACEC: BFA615E5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8f84>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ACF0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012ACF4: BE882004
	s_cbranch_execnz 5674                                      // 00000012ACF8: BFA6162A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x90a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ACFC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012AD00: BE882005
	s_cbranch_execnz 5743                                      // 00000012AD04: BFA6166F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x91c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AD08: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012AD0C: BE882006
	s_cbranch_execnz 5812                                      // 00000012AD10: BFA616B4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x92e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AD14: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012AD18: BE882007
	s_cbranch_execnz 5881                                      // 00000012AD1C: BFA616F9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9404>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AD20: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012AD24: BE882000
	s_cbranch_execnz 5950                                      // 00000012AD28: BFA6173E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9524>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AD2C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012AD30: BE882001
	s_cbranch_execnz 6019                                      // 00000012AD34: BFA61783 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9644>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AD38: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012AD3C: BE882002
	s_cbranch_execnz 6088                                      // 00000012AD40: BFA617C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9764>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AD44: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012AD48: BE882003
	s_cbranch_execnz 6157                                      // 00000012AD4C: BFA6180D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9884>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AD50: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012AD54: BE882004
	s_cbranch_execnz 6226                                      // 00000012AD58: BFA61852 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x99a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AD5C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012AD60: BE882005
	s_cbranch_execnz 6295                                      // 00000012AD64: BFA61897 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9ac4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AD68: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012AD6C: BE882006
	s_cbranch_execnz 6364                                      // 00000012AD70: BFA618DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9be4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AD74: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012AD78: BE882007
	s_cbranch_execnz 6433                                      // 00000012AD7C: BFA61921 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9d04>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AD80: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012AD84: BE882000
	s_cbranch_execnz 6502                                      // 00000012AD88: BFA61966 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9e24>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AD8C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012AD90: BE882001
	s_cbranch_execnz 6571                                      // 00000012AD94: BFA619AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9f44>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AD98: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012AD9C: BE882002
	s_cbranch_execnz 6640                                      // 00000012ADA0: BFA619F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa064>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ADA4: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012ADA8: BE882003
	s_cbranch_execnz 6709                                      // 00000012ADAC: BFA61A35 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa184>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ADB0: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012ADB4: BE882004
	s_cbranch_execnz 6778                                      // 00000012ADB8: BFA61A7A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa2a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ADBC: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012ADC0: BE882005
	s_cbranch_execnz 6847                                      // 00000012ADC4: BFA61ABF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa3c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ADC8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012ADCC: BE882006
	s_cbranch_execnz 6916                                      // 00000012ADD0: BFA61B04 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa4e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ADD4: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012ADD8: BE882007
	s_cbranch_execnz 6985                                      // 00000012ADDC: BFA61B49 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa604>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ADE0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012ADE4: BE882000
	s_cbranch_execnz 7054                                      // 00000012ADE8: BFA61B8E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa724>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ADEC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012ADF0: BE882001
	s_cbranch_execnz 7123                                      // 00000012ADF4: BFA61BD3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa844>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ADF8: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012ADFC: BE882002
	s_cbranch_execnz 7192                                      // 00000012AE00: BFA61C18 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa964>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AE04: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012AE08: BE882003
	s_cbranch_execnz 7261                                      // 00000012AE0C: BFA61C5D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaa84>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AE10: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012AE14: BE882004
	s_cbranch_execnz 7330                                      // 00000012AE18: BFA61CA2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaba4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AE1C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012AE20: BE882005
	s_cbranch_execnz 7399                                      // 00000012AE24: BFA61CE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xacc4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AE28: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012AE2C: BE882006
	s_cbranch_execnz 7468                                      // 00000012AE30: BFA61D2C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xade4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AE34: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012AE38: BE882007
	s_cbranch_execnz 7537                                      // 00000012AE3C: BFA61D71 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaf04>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AE40: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012AE44: BE882000
	s_cbranch_execnz 7606                                      // 00000012AE48: BFA61DB6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb024>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AE4C: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012AE50: BE882001
	s_cbranch_execnz 7675                                      // 00000012AE54: BFA61DFB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb144>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AE58: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012AE5C: BE882002
	s_cbranch_execnz 7744                                      // 00000012AE60: BFA61E40 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb264>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AE64: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012AE68: BE882003
	s_cbranch_execnz 7813                                      // 00000012AE6C: BFA61E85 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb384>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AE70: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012AE74: BE882004
	s_cbranch_execnz 7882                                      // 00000012AE78: BFA61ECA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb4a4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AE7C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012AE80: BE882005
	s_cbranch_execnz 7951                                      // 00000012AE84: BFA61F0F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb5c4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AE88: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012AE8C: BE882006
	s_cbranch_execnz 8020                                      // 00000012AE90: BFA61F54 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb6e4>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AE94: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012AE98: BE882007
	s_cbranch_execnz 8089                                      // 00000012AE9C: BFA61F99 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb804>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AEA0: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012AEA4: BE882000
	s_cbranch_execnz 8158                                      // 00000012AEA8: BFA61FDE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb924>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012AEAC: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000012AEB0: BE802001
	s_cbranch_execnz 8227                                      // 00000012AEB4: BFA62023 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xba44>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000012AEB8: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000012AEBC: BE802002
	s_cbranch_execnz 8296                                      // 00000012AEC0: BFA62068 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbb64>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000012AEC4: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000012AEC8: BE802003
	s_cbranch_execnz 8365                                      // 00000012AECC: BFA620AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbc84>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000012AED0: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000012AED4: BE802004
	s_cbranch_execnz 8434                                      // 00000012AED8: BFA620F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbda4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000012AEDC: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000012AEE0: BE802005
	s_cbranch_execnz 8503                                      // 00000012AEE4: BFA62137 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbec4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000012AEE8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000012AEEC: BE802006
	s_cbranch_execnz 8572                                      // 00000012AEF0: BFA6217C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbfe4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000012AEF4: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000012AEF8: BE802007
	s_cbranch_execnz 8641                                      // 00000012AEFC: BFA621C1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc104>
	s_endpgm                                                   // 00000012AF00: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[130:131]   // 00000012AF04: D6FF7C8D 060AFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 00000012AF10: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 00000012AF14: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000012AF1C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000012AF20: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012AF24: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000012AF28: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000012AF30: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 00000012AF3C: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012AF40: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000012AF44: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000012AF48: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000012AF50: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012AF58: BF870121
	v_add_f32_e32 v142, v142, v143                             // 00000012AF5C: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000012AF60: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000012AF64: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012AF68: BF870095
	.long 0xd71c008e                                           // 00000012AF6C: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000012AF70: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000012AF74: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000012AF78: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012AF80: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000012AF84: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 00000012AF8C: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012AF90: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 00000012AF94: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000012AF9C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012AFA0: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000012AFA4: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000012AFAC: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 00000012AFB0: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012AFB8: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000012AFBC: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000012AFC0: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012AFC8: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000012AFCC: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000012AFD0: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012AFD8: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000012AFDC: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 00000012AFE4: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[128:129]   // 00000012AFEC: D6FF7C8D 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012AFF8: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 00000012AFFC: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 00000012B004: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 00000012B010: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012B018: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012B01C: BE882000
	s_cbranch_execz 65106                                      // 00000012B020: BFA5FE52 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x346c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v140, v[130:131]   // 00000012B024: D6FF7C8D 060B18FF 00006000
	v_mul_f32_e32 v112, v138, v112                             // 00000012B030: 10E0E18A
	global_load_u16 v127, v[141:142], off offset:544           // 00000012B034: DC4A0220 7F7C008D
	s_waitcnt vmcnt(0)                                         // 00000012B03C: BF8903F7
	v_lshlrev_b32_e32 v127, 16, v127                           // 00000012B040: 30FEFE90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B044: BF870121
	v_mul_f32_e32 v141, 0xbfb8aa3b, v127                       // 00000012B048: 111AFEFF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v127                 // 00000012B050: 7C3CFEFF 42CE8ED0
	v_fma_f32 v142, 0xbfb8aa3b, v127, -v141                    // 00000012B058: D613008E 8636FEFF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 00000012B064: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B068: BF870091
	v_dual_fmamk_f32 v142, v127, 0xb2a5705f, v142 :: v_dual_sub_f32 v141, v141, v143// 00000012B06C: C88B1D7F 8E8D1F8D B2A5705F
	v_add_f32_e32 v141, v141, v142                             // 00000012B078: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 00000012B07C: 7F1C118F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012B080: BF870292
	v_exp_f32_e32 v141, v141                                   // 00000012B084: 7F1A4B8D
	.long 0xd71c008d                                           // 00000012B088: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 00000012B08C: 02031D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B090: BF870121
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 00000012B094: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v127                 // 00000012B098: 7C36FEFF C2B17218
	v_cndmask_b32_e32 v127, 0x7f800000, v141, vcc_lo           // 00000012B0A0: 02FF1AFF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B0A8: BF870091
	v_add_f32_e32 v127, 1.0, v127                              // 00000012B0AC: 06FEFEF2
	v_div_scale_f32 v141, null, v127, v127, v112               // 00000012B0B0: D6FC7C8D 05C2FF7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012B0B8: BF870291
	v_rcp_f32_e32 v142, v141                                   // 00000012B0BC: 7F1C558D
	v_fma_f32 v143, -v141, v142, 1.0                           // 00000012B0C0: D613008F 23CB1D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012B0C8: BF8700A1
	v_fmac_f32_e32 v142, v143, v142                            // 00000012B0CC: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v112, v127, v112             // 00000012B0D0: D6FC6A8F 05C2FF70
	v_mul_f32_e32 v144, v143, v142                             // 00000012B0D8: 11211D8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B0DC: BF870091
	v_fma_f32 v145, -v141, v144, v143                          // 00000012B0E0: D6130091 263F218D
	v_fmac_f32_e32 v144, v145, v142                            // 00000012B0E8: 57211D91
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B0EC: BF870091
	v_fma_f32 v141, -v141, v144, v143                          // 00000012B0F0: D613008D 263F218D
	v_div_fmas_f32 v141, v141, v142, v144                      // 00000012B0F8: D637008D 06431D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B100: BF870121
	v_div_fixup_f32 v112, v141, v127, v112                     // 00000012B104: D6270070 05C2FF8D
	v_mad_i64_i32 v[141:142], null, 0x3000, v140, v[128:129]   // 00000012B10C: D6FF7C8D 060318FF 00003000
	v_bfe_u32 v127, v112, 16, 1                                // 00000012B118: D610007F 02052170
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012B120: BF870001
	v_add3_u32 v112, v112, v127, 0x7fff                        // 00000012B124: D6550070 03FEFF70 00007FFF
	global_store_d16_hi_b16 v[141:142], v112, off offset:32    // 00000012B130: DC960020 007C708D
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012B138: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012B13C: BE882001
	s_cbranch_execz 65037                                      // 00000012B140: BFA5FE0D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3478>
	v_mad_i64_i32 v[141:142], null, 0x6000, v120, v[130:131]   // 00000012B144: D6FF7C8D 060AF0FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 00000012B150: 10E2E38B
	global_load_u16 v112, v[141:142], off offset:544           // 00000012B154: DC4A0220 707C008D
	s_waitcnt vmcnt(0)                                         // 00000012B15C: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 00000012B160: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B164: BF870091
	v_mul_f32_e32 v127, 0xbfb8aa3b, v112                       // 00000012B168: 10FEE0FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v112, -v127                    // 00000012B170: D613008D 85FEE0FF BFB8AA3B
	v_rndne_f32_e32 v142, v127                                 // 00000012B17C: 7F1C477F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012B180: BF870191
	v_sub_f32_e32 v127, v127, v142                             // 00000012B184: 08FF1D7F
	v_fmamk_f32 v141, v112, 0xb2a5705f, v141                   // 00000012B188: 591B1B70 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 00000012B190: 7C3CE0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B198: BF870122
	v_add_f32_e32 v127, v127, v141                             // 00000012B19C: 06FF1B7F
	v_cvt_i32_f32_e32 v141, v142                               // 00000012B1A0: 7F1A118E
	v_exp_f32_e32 v127, v127                                   // 00000012B1A4: 7EFE4B7F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B1A8: BF870095
	.long 0xd71c007f                                           // 00000012B1AC: D71C007F
	v_cndmask_b32_e32 v1, v127, v141, vcc_lo                   // 00000012B1B0: 02031B7F
	v_cndmask_b32_e32 v127, 0, v127, vcc_lo                    // 00000012B1B4: 02FEFE80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 00000012B1B8: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B1C0: BF870092
	v_cndmask_b32_e32 v112, 0x7f800000, v127, vcc_lo           // 00000012B1C4: 02E0FEFF 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 00000012B1CC: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B1D0: BF870091
	v_div_scale_f32 v127, null, v112, v112, v113               // 00000012B1D4: D6FC7C7F 05C6E170
	v_rcp_f32_e32 v141, v127                                   // 00000012B1DC: 7F1A557F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B1E0: BF870095
	v_fma_f32 v142, -v127, v141, 1.0                           // 00000012B1E4: D613008E 23CB1B7F
	v_fmac_f32_e32 v141, v142, v141                            // 00000012B1EC: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v113, v112, v113             // 00000012B1F0: D6FC6A8E 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B1F8: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 00000012B1FC: 111F1B8E
	v_fma_f32 v144, -v127, v143, v142                          // 00000012B200: D6130090 263B1F7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B208: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 00000012B20C: 571F1B90
	v_fma_f32 v127, -v127, v143, v142                          // 00000012B210: D613007F 263B1F7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B218: BF870091
	v_div_fmas_f32 v127, v127, v141, v143                      // 00000012B21C: D637007F 063F1B7F
	v_div_fixup_f32 v127, v127, v112, v113                     // 00000012B224: D627007F 05C6E17F
	v_mad_i64_i32 v[112:113], null, 0x3000, v120, v[128:129]   // 00000012B22C: D6FF7C70 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B238: BF870092
	v_bfe_u32 v141, v127, 16, 1                                // 00000012B23C: D610008D 0205217F
	v_add3_u32 v127, v127, v141, 0x7fff                        // 00000012B244: D655007F 03FF1B7F 00007FFF
	global_store_d16_hi_b16 v[112:113], v127, off offset:32    // 00000012B250: DC960020 007C7F70
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012B258: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012B25C: BE882002
	s_cbranch_execz 64968                                      // 00000012B260: BFA5FDC8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3484>
	v_mad_i64_i32 v[112:113], null, 0x6000, v121, v[130:131]   // 00000012B264: D6FF7C70 060AF2FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 00000012B270: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 00000012B278: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 00000012B27C: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B280: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 00000012B284: 10E2E0FF BFB8AA3B
	v_fma_f32 v127, 0xbfb8aa3b, v112, -v113                    // 00000012B28C: D613007F 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v141, v113                                 // 00000012B298: 7F1A4771
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012B29C: BF870191
	v_sub_f32_e32 v113, v113, v141                             // 00000012B2A0: 08E31B71
	v_fmamk_f32 v127, v112, 0xb2a5705f, v127                   // 00000012B2A4: 58FEFF70 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 00000012B2AC: 7C3CE0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B2B4: BF870122
	v_add_f32_e32 v113, v113, v127                             // 00000012B2B8: 06E2FF71
	v_cvt_i32_f32_e32 v127, v141                               // 00000012B2BC: 7EFE118D
	v_exp_f32_e32 v113, v113                                   // 00000012B2C0: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B2C4: BF870095
	.long 0xd71c0071                                           // 00000012B2C8: D71C0071
	v_cndmask_b32_e32 v1, v113, v127, vcc_lo                   // 00000012B2CC: 0202FF71
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 00000012B2D0: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 00000012B2D4: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B2DC: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v136, v114// 00000012B2E0: CA46E2FF 7070E588 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 00000012B2EC: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B2F0: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 00000012B2F4: D6FC7C72 05C6E170
	v_rcp_f32_e32 v127, v114                                   // 00000012B2FC: 7EFE5572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B300: BF870095
	v_fma_f32 v141, -v114, v127, 1.0                           // 00000012B304: D613008D 23CAFF72
	v_fmac_f32_e32 v127, v141, v127                            // 00000012B30C: 56FEFF8D
	v_div_scale_f32 v141, vcc_lo, v113, v112, v113             // 00000012B310: D6FC6A8D 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B318: BF870091
	v_mul_f32_e32 v142, v141, v127                             // 00000012B31C: 111CFF8D
	v_fma_f32 v143, -v114, v142, v141                          // 00000012B320: D613008F 26371D72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B328: BF870091
	v_fmac_f32_e32 v142, v143, v127                            // 00000012B32C: 571CFF8F
	v_fma_f32 v114, -v114, v142, v141                          // 00000012B330: D6130072 26371D72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B338: BF870091
	v_div_fmas_f32 v114, v114, v127, v142                      // 00000012B33C: D6370072 063AFF72
	v_div_fixup_f32 v114, v114, v112, v113                     // 00000012B344: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v121, v[128:129]   // 00000012B34C: D6FF7C70 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B358: BF870092
	v_bfe_u32 v127, v114, 16, 1                                // 00000012B35C: D610007F 02052172
	v_add3_u32 v114, v114, v127, 0x7fff                        // 00000012B364: D6550072 03FEFF72 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 00000012B370: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012B378: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012B37C: BE882003
	s_cbranch_execz 64899                                      // 00000012B380: BFA5FD83 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3490>
	v_mad_i64_i32 v[112:113], null, 0x6000, v122, v[130:131]   // 00000012B384: D6FF7C70 060AF4FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 00000012B390: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 00000012B398: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 00000012B39C: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B3A0: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 00000012B3A4: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 00000012B3AC: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v127, v113                                 // 00000012B3B8: 7EFE4771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012B3BC: BF870221
	v_sub_f32_e32 v113, v113, v127                             // 00000012B3C0: 08E2FF71
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 00000012B3C4: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 00000012B3CC: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B3D4: BF870121
	v_add_f32_e32 v113, v113, v114                             // 00000012B3D8: 06E2E571
	v_cvt_i32_f32_e32 v114, v127                               // 00000012B3DC: 7EE4117F
	v_exp_f32_e32 v113, v113                                   // 00000012B3E0: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B3E4: BF870095
	.long 0xd71c0071                                           // 00000012B3E8: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 00000012B3EC: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 00000012B3F0: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 00000012B3F4: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B3FC: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v137, v115// 00000012B400: CA46E2FF 7070E789 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 00000012B40C: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B410: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 00000012B414: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 00000012B41C: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B420: BF870095
	v_fma_f32 v127, -v114, v115, 1.0                           // 00000012B424: D613007F 23CAE772
	v_fmac_f32_e32 v115, v127, v115                            // 00000012B42C: 56E6E77F
	v_div_scale_f32 v127, vcc_lo, v113, v112, v113             // 00000012B430: D6FC6A7F 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B438: BF870091
	v_mul_f32_e32 v141, v127, v115                             // 00000012B43C: 111AE77F
	v_fma_f32 v142, -v114, v141, v127                          // 00000012B440: D613008E 25FF1B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B448: BF870091
	v_fmac_f32_e32 v141, v142, v115                            // 00000012B44C: 571AE78E
	v_fma_f32 v114, -v114, v141, v127                          // 00000012B450: D6130072 25FF1B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B458: BF870091
	v_div_fmas_f32 v114, v114, v115, v141                      // 00000012B45C: D6370072 0636E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 00000012B464: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v122, v[128:129]   // 00000012B46C: D6FF7C70 0602F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B478: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 00000012B47C: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 00000012B484: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 00000012B490: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012B498: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012B49C: BE882004
	s_cbranch_execz 64830                                      // 00000012B4A0: BFA5FD3E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x349c>
	v_mad_i64_i32 v[112:113], null, 0x6000, v123, v[130:131]   // 00000012B4A4: D6FF7C70 060AF6FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 00000012B4B0: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 00000012B4B8: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 00000012B4BC: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B4C0: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 00000012B4C4: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 00000012B4CC: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 00000012B4D8: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012B4DC: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 00000012B4E0: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 00000012B4E4: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 00000012B4EC: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B4F4: BF870121
	v_add_f32_e32 v113, v113, v114                             // 00000012B4F8: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 00000012B4FC: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 00000012B500: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B504: BF870095
	.long 0xd71c0071                                           // 00000012B508: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 00000012B50C: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 00000012B510: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 00000012B514: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B51C: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v134, v116// 00000012B520: CA46E2FF 7070E986 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 00000012B52C: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B530: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 00000012B534: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 00000012B53C: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B540: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 00000012B544: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 00000012B54C: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 00000012B550: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B558: BF870091
	v_mul_f32_e32 v127, v116, v115                             // 00000012B55C: 10FEE774
	v_fma_f32 v141, -v114, v127, v116                          // 00000012B560: D613008D 25D2FF72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B568: BF870091
	v_fmac_f32_e32 v127, v141, v115                            // 00000012B56C: 56FEE78D
	v_fma_f32 v114, -v114, v127, v116                          // 00000012B570: D6130072 25D2FF72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B578: BF870091
	v_div_fmas_f32 v114, v114, v115, v127                      // 00000012B57C: D6370072 05FEE772
	v_div_fixup_f32 v114, v114, v112, v113                     // 00000012B584: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v123, v[128:129]   // 00000012B58C: D6FF7C70 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B598: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 00000012B59C: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 00000012B5A4: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 00000012B5B0: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012B5B8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012B5BC: BE882005
	s_cbranch_execz 64761                                      // 00000012B5C0: BFA5FCF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34a8>
	v_mad_i64_i32 v[112:113], null, 0x6000, v124, v[130:131]   // 00000012B5C4: D6FF7C70 060AF8FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 00000012B5D0: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 00000012B5D8: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 00000012B5DC: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B5E0: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 00000012B5E4: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 00000012B5EC: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 00000012B5F8: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012B5FC: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 00000012B600: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 00000012B604: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 00000012B60C: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B614: BF870121
	v_add_f32_e32 v113, v113, v114                             // 00000012B618: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 00000012B61C: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 00000012B620: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B624: BF870095
	.long 0xd71c0071                                           // 00000012B628: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 00000012B62C: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 00000012B630: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 00000012B634: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B63C: BF870092
	v_cndmask_b32_e32 v112, 0x7f800000, v113, vcc_lo           // 00000012B640: 02E0E2FF 7F800000
	v_dual_mul_f32 v113, v135, v117 :: v_dual_add_f32 v112, 1.0, v112// 00000012B648: C8C8EB87 7170E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B650: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 00000012B654: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 00000012B65C: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B660: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 00000012B664: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 00000012B66C: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 00000012B670: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B678: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 00000012B67C: 10EAE774
	v_fma_f32 v127, -v114, v117, v116                          // 00000012B680: D613007F 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B688: BF870091
	v_fmac_f32_e32 v117, v127, v115                            // 00000012B68C: 56EAE77F
	v_fma_f32 v114, -v114, v117, v116                          // 00000012B690: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B698: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 00000012B69C: D6370072 05D6E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 00000012B6A4: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v124, v[128:129]   // 00000012B6AC: D6FF7C70 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B6B8: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 00000012B6BC: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 00000012B6C4: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 00000012B6D0: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012B6D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012B6DC: BE882006
	s_cbranch_execz 64692                                      // 00000012B6E0: BFA5FCB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34b4>
	v_mad_i64_i32 v[112:113], null, 0x6000, v125, v[130:131]   // 00000012B6E4: D6FF7C70 060AFAFF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 00000012B6F0: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 00000012B6F8: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 00000012B6FC: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B700: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 00000012B704: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 00000012B70C: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 00000012B718: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012B71C: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 00000012B720: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 00000012B724: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 00000012B72C: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B734: BF870121
	v_add_f32_e32 v113, v113, v114                             // 00000012B738: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 00000012B73C: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 00000012B740: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B744: BF870095
	.long 0xd71c0071                                           // 00000012B748: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 00000012B74C: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 00000012B750: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 00000012B754: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B75C: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v132, v118// 00000012B760: CA46E2FF 7070ED84 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 00000012B76C: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B770: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 00000012B774: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 00000012B77C: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B780: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 00000012B784: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 00000012B78C: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 00000012B790: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B798: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 00000012B79C: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 00000012B7A0: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B7A8: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 00000012B7AC: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 00000012B7B0: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B7B8: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 00000012B7BC: D6370072 05D6E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 00000012B7C4: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v125, v[128:129]   // 00000012B7CC: D6FF7C70 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B7D8: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 00000012B7DC: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 00000012B7E4: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 00000012B7F0: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012B7F8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012B7FC: BE882007
	s_cbranch_execz 64623                                      // 00000012B800: BFA5FC6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34c0>
	v_mad_i64_i32 v[112:113], null, 0x6000, v126, v[130:131]   // 00000012B804: D6FF7C70 060AFCFF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 00000012B810: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 00000012B818: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 00000012B81C: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B820: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 00000012B824: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 00000012B82C: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 00000012B838: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012B83C: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 00000012B840: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 00000012B844: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 00000012B84C: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B854: BF870121
	v_add_f32_e32 v113, v113, v114                             // 00000012B858: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 00000012B85C: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 00000012B860: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B864: BF870095
	.long 0xd71c0071                                           // 00000012B868: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 00000012B86C: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 00000012B870: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 00000012B874: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B87C: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v133, v119// 00000012B880: CA46E2FF 7070EF85 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 00000012B88C: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B890: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 00000012B894: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 00000012B89C: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B8A0: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 00000012B8A4: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 00000012B8AC: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 00000012B8B0: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B8B8: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 00000012B8BC: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 00000012B8C0: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B8C8: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 00000012B8CC: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 00000012B8D0: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B8D8: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 00000012B8DC: D6370072 05D6E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 00000012B8E4: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v126, v[128:129]   // 00000012B8EC: D6FF7C70 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B8F8: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 00000012B8FC: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 00000012B904: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 00000012B910: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012B918: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012B91C: BE882000
	s_cbranch_execz 64554                                      // 00000012B920: BFA5FC2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34cc>
	v_mad_i64_i32 v[112:113], null, 0x6000, v140, v[130:131]   // 00000012B924: D6FF7C70 060B18FF 00006000
	v_mul_f32_e32 v104, v138, v104                             // 00000012B930: 10D0D18A
	global_load_u16 v112, v[112:113], off offset:576           // 00000012B934: DC4A0240 707C0070
	s_waitcnt vmcnt(0)                                         // 00000012B93C: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 00000012B940: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B944: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 00000012B948: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 00000012B950: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 00000012B95C: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012B960: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 00000012B964: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 00000012B968: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 00000012B970: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012B978: BF870121
	v_add_f32_e32 v113, v113, v114                             // 00000012B97C: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 00000012B980: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 00000012B984: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B988: BF870095
	.long 0xd71c0071                                           // 00000012B98C: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 00000012B990: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 00000012B994: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 00000012B998: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B9A0: BF870092
	v_cndmask_b32_e32 v112, 0x7f800000, v113, vcc_lo           // 00000012B9A4: 02E0E2FF 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 00000012B9AC: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B9B0: BF870091
	v_div_scale_f32 v113, null, v112, v112, v104               // 00000012B9B4: D6FC7C71 05A2E170
	v_rcp_f32_e32 v114, v113                                   // 00000012B9BC: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B9C0: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 00000012B9C4: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 00000012B9CC: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v104, v112, v104             // 00000012B9D0: D6FC6A73 05A2E168
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B9D8: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 00000012B9DC: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 00000012B9E0: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B9E8: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 00000012B9EC: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 00000012B9F0: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012B9F8: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 00000012B9FC: D6370071 05D2E571
	v_div_fixup_f32 v104, v113, v112, v104                     // 00000012BA04: D6270068 05A2E171
	v_mad_i64_i32 v[112:113], null, 0x3000, v140, v[128:129]   // 00000012BA0C: D6FF7C70 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BA18: BF870092
	v_bfe_u32 v114, v104, 16, 1                                // 00000012BA1C: D6100072 02052168
	v_add3_u32 v104, v104, v114, 0x7fff                        // 00000012BA24: D6550068 03FEE568 00007FFF
	global_store_d16_hi_b16 v[112:113], v104, off offset:64    // 00000012BA30: DC960040 007C6870
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012BA38: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012BA3C: BE882001
	s_cbranch_execz 64485                                      // 00000012BA40: BFA5FBE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34d8>
	v_mad_i64_i32 v[112:113], null, 0x6000, v120, v[130:131]   // 00000012BA44: D6FF7C70 060AF0FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 00000012BA50: 10D2D38B
	global_load_u16 v104, v[112:113], off offset:576           // 00000012BA54: DC4A0240 687C0070
	s_waitcnt vmcnt(0)                                         // 00000012BA5C: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 00000012BA60: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012BA64: BF870121
	v_mul_f32_e32 v112, 0xbfb8aa3b, v104                       // 00000012BA68: 10E0D0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 00000012BA70: 7C3CD0FF 42CE8ED0
	v_fma_f32 v113, 0xbfb8aa3b, v104, -v112                    // 00000012BA78: D6130071 85C2D0FF BFB8AA3B
	v_rndne_f32_e32 v114, v112                                 // 00000012BA84: 7EE44770
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012BA88: BF870112
	v_fmamk_f32 v113, v104, 0xb2a5705f, v113                   // 00000012BA8C: 58E2E368 B2A5705F
	v_sub_f32_e32 v112, v112, v114                             // 00000012BA94: 08E0E570
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012BA98: BF870121
	v_add_f32_e32 v112, v112, v113                             // 00000012BA9C: 06E0E370
	v_cvt_i32_f32_e32 v113, v114                               // 00000012BAA0: 7EE21172
	v_exp_f32_e32 v112, v112                                   // 00000012BAA4: 7EE04B70
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BAA8: BF870095
	.long 0xd71c0070                                           // 00000012BAAC: D71C0070
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                   // 00000012BAB0: 0202E370
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 00000012BAB4: 02E0E080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 00000012BAB8: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BAC0: BF870092
	v_cndmask_b32_e32 v104, 0x7f800000, v112, vcc_lo           // 00000012BAC4: 02D0E0FF 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 00000012BACC: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BAD0: BF870091
	v_div_scale_f32 v112, null, v104, v104, v105               // 00000012BAD4: D6FC7C70 05A6D168
	v_rcp_f32_e32 v113, v112                                   // 00000012BADC: 7EE25570
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BAE0: BF870095
	v_fma_f32 v114, -v112, v113, 1.0                           // 00000012BAE4: D6130072 23CAE370
	v_fmac_f32_e32 v113, v114, v113                            // 00000012BAEC: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v105, v104, v105             // 00000012BAF0: D6FC6A72 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BAF8: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 00000012BAFC: 10E6E372
	v_fma_f32 v116, -v112, v115, v114                          // 00000012BB00: D6130074 25CAE770
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BB08: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 00000012BB0C: 56E6E374
	v_fma_f32 v112, -v112, v115, v114                          // 00000012BB10: D6130070 25CAE770
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BB18: BF870091
	v_div_fmas_f32 v112, v112, v113, v115                      // 00000012BB1C: D6370070 05CEE370
	v_div_fixup_f32 v112, v112, v104, v105                     // 00000012BB24: D6270070 05A6D170
	v_mad_i64_i32 v[104:105], null, 0x3000, v120, v[128:129]   // 00000012BB2C: D6FF7C68 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BB38: BF870092
	v_bfe_u32 v113, v112, 16, 1                                // 00000012BB3C: D6100071 02052170
	v_add3_u32 v112, v112, v113, 0x7fff                        // 00000012BB44: D6550070 03FEE370 00007FFF
	global_store_d16_hi_b16 v[104:105], v112, off offset:64    // 00000012BB50: DC960040 007C7068
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012BB58: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012BB5C: BE882002
	s_cbranch_execz 64416                                      // 00000012BB60: BFA5FBA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34e4>
	v_mad_i64_i32 v[104:105], null, 0x6000, v121, v[130:131]   // 00000012BB64: D6FF7C68 060AF2FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 00000012BB70: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 00000012BB78: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 00000012BB7C: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BB80: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 00000012BB84: 10D2D0FF BFB8AA3B
	v_fma_f32 v112, 0xbfb8aa3b, v104, -v105                    // 00000012BB8C: D6130070 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v113, v105                                 // 00000012BB98: 7EE24769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012BB9C: BF870221
	v_sub_f32_e32 v105, v105, v113                             // 00000012BBA0: 08D2E369
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 00000012BBA4: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v112, v104, 0xb2a5705f, v112                   // 00000012BBAC: 58E0E168 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012BBB4: BF870121
	v_add_f32_e32 v105, v105, v112                             // 00000012BBB8: 06D2E169
	v_cvt_i32_f32_e32 v112, v113                               // 00000012BBBC: 7EE01171
	v_exp_f32_e32 v105, v105                                   // 00000012BBC0: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BBC4: BF870095
	.long 0xd71c0069                                           // 00000012BBC8: D71C0069
	v_cndmask_b32_e32 v1, v105, v112, vcc_lo                   // 00000012BBCC: 0202E169
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 00000012BBD0: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 00000012BBD4: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BBDC: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v136, v106// 00000012BBE0: CA46D2FF 6868D588 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 00000012BBEC: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BBF0: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 00000012BBF4: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v112, v106                                   // 00000012BBFC: 7EE0556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BC00: BF870095
	v_fma_f32 v113, -v106, v112, 1.0                           // 00000012BC04: D6130071 23CAE16A
	v_fmac_f32_e32 v112, v113, v112                            // 00000012BC0C: 56E0E171
	v_div_scale_f32 v113, vcc_lo, v105, v104, v105             // 00000012BC10: D6FC6A71 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BC18: BF870091
	v_mul_f32_e32 v114, v113, v112                             // 00000012BC1C: 10E4E171
	v_fma_f32 v115, -v106, v114, v113                          // 00000012BC20: D6130073 25C6E56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BC28: BF870091
	v_fmac_f32_e32 v114, v115, v112                            // 00000012BC2C: 56E4E173
	v_fma_f32 v106, -v106, v114, v113                          // 00000012BC30: D613006A 25C6E56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BC38: BF870091
	v_div_fmas_f32 v106, v106, v112, v114                      // 00000012BC3C: D637006A 05CAE16A
	v_div_fixup_f32 v106, v106, v104, v105                     // 00000012BC44: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v121, v[128:129]   // 00000012BC4C: D6FF7C68 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BC58: BF870092
	v_bfe_u32 v112, v106, 16, 1                                // 00000012BC5C: D6100070 0205216A
	v_add3_u32 v106, v106, v112, 0x7fff                        // 00000012BC64: D655006A 03FEE16A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 00000012BC70: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012BC78: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012BC7C: BE882003
	s_cbranch_execz 64347                                      // 00000012BC80: BFA5FB5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34f0>
	v_mad_i64_i32 v[104:105], null, 0x6000, v122, v[130:131]   // 00000012BC84: D6FF7C68 060AF4FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 00000012BC90: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 00000012BC98: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 00000012BC9C: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BCA0: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 00000012BCA4: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 00000012BCAC: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v112, v105                                 // 00000012BCB8: 7EE04769
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BCBC: BF870091
	v_dual_fmamk_f32 v106, v104, 0xb2a5705f, v106 :: v_dual_sub_f32 v105, v105, v112// 00000012BCC0: C88AD568 6A68E169 B2A5705F
	v_add_f32_e32 v105, v105, v106                             // 00000012BCCC: 06D2D569
	v_cvt_i32_f32_e32 v106, v112                               // 00000012BCD0: 7ED41170
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 00000012BCD4: 7C3CD0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012BCDC: BF870293
	v_exp_f32_e32 v105, v105                                   // 00000012BCE0: 7ED24B69
	.long 0xd71c0069                                           // 00000012BCE4: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 00000012BCE8: 0202D569
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012BCEC: BF870121
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 00000012BCF0: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 00000012BCF4: 7C36D0FF C2B17218
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v137, v107// 00000012BCFC: CA46D2FF 6868D789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BD08: BF870091
	v_add_f32_e32 v104, 1.0, v104                              // 00000012BD0C: 06D0D0F2
	v_div_scale_f32 v106, null, v104, v104, v105               // 00000012BD10: D6FC7C6A 05A6D168
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012BD18: BF870291
	v_rcp_f32_e32 v107, v106                                   // 00000012BD1C: 7ED6556A
	v_fma_f32 v112, -v106, v107, 1.0                           // 00000012BD20: D6130070 23CAD76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012BD28: BF8700A1
	v_fmac_f32_e32 v107, v112, v107                            // 00000012BD2C: 56D6D770
	v_div_scale_f32 v112, vcc_lo, v105, v104, v105             // 00000012BD30: D6FC6A70 05A6D169
	v_mul_f32_e32 v113, v112, v107                             // 00000012BD38: 10E2D770
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BD3C: BF870091
	v_fma_f32 v114, -v106, v113, v112                          // 00000012BD40: D6130072 25C2E36A
	v_fmac_f32_e32 v113, v114, v107                            // 00000012BD48: 56E2D772
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BD4C: BF870091
	v_fma_f32 v106, -v106, v113, v112                          // 00000012BD50: D613006A 25C2E36A
	v_div_fmas_f32 v106, v106, v107, v113                      // 00000012BD58: D637006A 05C6D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012BD60: BF870121
	v_div_fixup_f32 v106, v106, v104, v105                     // 00000012BD64: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v122, v[128:129]   // 00000012BD6C: D6FF7C68 0602F4FF 00003000
	v_bfe_u32 v107, v106, 16, 1                                // 00000012BD78: D610006B 0205216A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012BD80: BF870001
	v_add3_u32 v106, v106, v107, 0x7fff                        // 00000012BD84: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 00000012BD90: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012BD98: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012BD9C: BE882004
	s_cbranch_execz 64278                                      // 00000012BDA0: BFA5FB16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x34fc>
	v_mad_i64_i32 v[104:105], null, 0x6000, v123, v[130:131]   // 00000012BDA4: D6FF7C68 060AF6FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 00000012BDB0: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 00000012BDB8: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 00000012BDBC: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BDC0: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 00000012BDC4: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 00000012BDCC: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 00000012BDD8: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012BDDC: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 00000012BDE0: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 00000012BDE4: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 00000012BDEC: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012BDF4: BF870121
	v_add_f32_e32 v105, v105, v106                             // 00000012BDF8: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 00000012BDFC: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 00000012BE00: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BE04: BF870095
	.long 0xd71c0069                                           // 00000012BE08: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 00000012BE0C: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 00000012BE10: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 00000012BE14: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BE1C: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v134, v108// 00000012BE20: CA46D2FF 6868D986 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 00000012BE2C: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BE30: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 00000012BE34: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 00000012BE3C: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BE40: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 00000012BE44: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 00000012BE4C: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 00000012BE50: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BE58: BF870091
	v_mul_f32_e32 v112, v108, v107                             // 00000012BE5C: 10E0D76C
	v_fma_f32 v113, -v106, v112, v108                          // 00000012BE60: D6130071 25B2E16A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BE68: BF870091
	v_fmac_f32_e32 v112, v113, v107                            // 00000012BE6C: 56E0D771
	v_fma_f32 v106, -v106, v112, v108                          // 00000012BE70: D613006A 25B2E16A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BE78: BF870091
	v_div_fmas_f32 v106, v106, v107, v112                      // 00000012BE7C: D637006A 05C2D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 00000012BE84: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v123, v[128:129]   // 00000012BE8C: D6FF7C68 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BE98: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 00000012BE9C: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 00000012BEA4: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 00000012BEB0: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012BEB8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012BEBC: BE882005
	s_cbranch_execz 64209                                      // 00000012BEC0: BFA5FAD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3508>
	v_mad_i64_i32 v[104:105], null, 0x6000, v124, v[130:131]   // 00000012BEC4: D6FF7C68 060AF8FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 00000012BED0: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 00000012BED8: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 00000012BEDC: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BEE0: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 00000012BEE4: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 00000012BEEC: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 00000012BEF8: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012BEFC: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 00000012BF00: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 00000012BF04: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 00000012BF0C: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012BF14: BF870121
	v_add_f32_e32 v105, v105, v106                             // 00000012BF18: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 00000012BF1C: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 00000012BF20: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BF24: BF870095
	.long 0xd71c0069                                           // 00000012BF28: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 00000012BF2C: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 00000012BF30: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 00000012BF34: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BF3C: BF870092
	v_cndmask_b32_e32 v104, 0x7f800000, v105, vcc_lo           // 00000012BF40: 02D0D2FF 7F800000
	v_dual_mul_f32 v105, v135, v109 :: v_dual_add_f32 v104, 1.0, v104// 00000012BF48: C8C8DB87 6968D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BF50: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 00000012BF54: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 00000012BF5C: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BF60: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 00000012BF64: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 00000012BF6C: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 00000012BF70: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BF78: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 00000012BF7C: 10DAD76C
	v_fma_f32 v112, -v106, v109, v108                          // 00000012BF80: D6130070 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BF88: BF870091
	v_fmac_f32_e32 v109, v112, v107                            // 00000012BF8C: 56DAD770
	v_fma_f32 v106, -v106, v109, v108                          // 00000012BF90: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BF98: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 00000012BF9C: D637006A 05B6D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 00000012BFA4: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v124, v[128:129]   // 00000012BFAC: D6FF7C68 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012BFB8: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 00000012BFBC: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 00000012BFC4: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 00000012BFD0: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012BFD8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012BFDC: BE882006
	s_cbranch_execz 64140                                      // 00000012BFE0: BFA5FA8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3514>
	v_mad_i64_i32 v[104:105], null, 0x6000, v125, v[130:131]   // 00000012BFE4: D6FF7C68 060AFAFF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 00000012BFF0: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 00000012BFF8: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 00000012BFFC: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C000: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 00000012C004: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 00000012C00C: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 00000012C018: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012C01C: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 00000012C020: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 00000012C024: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 00000012C02C: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012C034: BF870121
	v_add_f32_e32 v105, v105, v106                             // 00000012C038: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 00000012C03C: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 00000012C040: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C044: BF870095
	.long 0xd71c0069                                           // 00000012C048: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 00000012C04C: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 00000012C050: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 00000012C054: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C05C: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v132, v110// 00000012C060: CA46D2FF 6868DD84 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 00000012C06C: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C070: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 00000012C074: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 00000012C07C: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C080: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 00000012C084: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 00000012C08C: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 00000012C090: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C098: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 00000012C09C: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 00000012C0A0: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C0A8: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 00000012C0AC: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 00000012C0B0: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C0B8: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 00000012C0BC: D637006A 05B6D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 00000012C0C4: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v125, v[128:129]   // 00000012C0CC: D6FF7C68 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C0D8: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 00000012C0DC: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 00000012C0E4: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 00000012C0F0: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012C0F8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012C0FC: BE882007
	s_cbranch_execz 64071                                      // 00000012C100: BFA5FA47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3520>
	v_mad_i64_i32 v[104:105], null, 0x6000, v126, v[130:131]   // 00000012C104: D6FF7C68 060AFCFF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 00000012C110: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 00000012C118: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 00000012C11C: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C120: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 00000012C124: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 00000012C12C: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 00000012C138: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012C13C: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 00000012C140: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 00000012C144: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 00000012C14C: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012C154: BF870121
	v_add_f32_e32 v105, v105, v106                             // 00000012C158: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 00000012C15C: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 00000012C160: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C164: BF870095
	.long 0xd71c0069                                           // 00000012C168: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 00000012C16C: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 00000012C170: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 00000012C174: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C17C: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v133, v111// 00000012C180: CA46D2FF 6868DF85 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 00000012C18C: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C190: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 00000012C194: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 00000012C19C: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C1A0: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 00000012C1A4: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 00000012C1AC: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 00000012C1B0: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C1B8: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 00000012C1BC: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 00000012C1C0: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C1C8: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 00000012C1CC: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 00000012C1D0: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C1D8: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 00000012C1DC: D637006A 05B6D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 00000012C1E4: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v126, v[128:129]   // 00000012C1EC: D6FF7C68 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C1F8: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 00000012C1FC: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 00000012C204: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 00000012C210: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012C218: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012C21C: BE882000
	s_cbranch_execz 64002                                      // 00000012C220: BFA5FA02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x352c>
	v_mad_i64_i32 v[104:105], null, 0x6000, v140, v[130:131]   // 00000012C224: D6FF7C68 060B18FF 00006000
	v_mul_f32_e32 v96, v138, v96                               // 00000012C230: 10C0C18A
	global_load_u16 v104, v[104:105], off offset:608           // 00000012C234: DC4A0260 687C0068
	s_waitcnt vmcnt(0)                                         // 00000012C23C: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 00000012C240: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C244: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 00000012C248: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 00000012C250: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 00000012C25C: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012C260: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 00000012C264: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 00000012C268: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 00000012C270: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012C278: BF870121
	v_add_f32_e32 v105, v105, v106                             // 00000012C27C: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 00000012C280: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 00000012C284: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C288: BF870095
	.long 0xd71c0069                                           // 00000012C28C: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 00000012C290: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 00000012C294: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 00000012C298: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C2A0: BF870092
	v_cndmask_b32_e32 v104, 0x7f800000, v105, vcc_lo           // 00000012C2A4: 02D0D2FF 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 00000012C2AC: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C2B0: BF870091
	v_div_scale_f32 v105, null, v104, v104, v96                // 00000012C2B4: D6FC7C69 0582D168
	v_rcp_f32_e32 v106, v105                                   // 00000012C2BC: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C2C0: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 00000012C2C4: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 00000012C2CC: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v96, v104, v96               // 00000012C2D0: D6FC6A6B 0582D160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C2D8: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 00000012C2DC: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 00000012C2E0: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C2E8: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 00000012C2EC: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 00000012C2F0: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C2F8: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 00000012C2FC: D6370069 05B2D569
	v_div_fixup_f32 v96, v105, v104, v96                       // 00000012C304: D6270060 0582D169
	v_mad_i64_i32 v[104:105], null, 0x3000, v140, v[128:129]   // 00000012C30C: D6FF7C68 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C318: BF870092
	v_bfe_u32 v106, v96, 16, 1                                 // 00000012C31C: D610006A 02052160
	v_add3_u32 v96, v96, v106, 0x7fff                          // 00000012C324: D6550060 03FED560 00007FFF
	global_store_d16_hi_b16 v[104:105], v96, off offset:96     // 00000012C330: DC960060 007C6068
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012C338: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012C33C: BE882001
	s_cbranch_execz 63933                                      // 00000012C340: BFA5F9BD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3538>
	v_mad_i64_i32 v[104:105], null, 0x6000, v120, v[130:131]   // 00000012C344: D6FF7C68 060AF0FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 00000012C350: 10C2C38B
	global_load_u16 v96, v[104:105], off offset:608            // 00000012C354: DC4A0260 607C0068
	s_waitcnt vmcnt(0)                                         // 00000012C35C: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 00000012C360: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012C364: BF870121
	v_mul_f32_e32 v104, 0xbfb8aa3b, v96                        // 00000012C368: 10D0C0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 00000012C370: 7C3CC0FF 42CE8ED0
	v_fma_f32 v105, 0xbfb8aa3b, v96, -v104                     // 00000012C378: D6130069 85A2C0FF BFB8AA3B
	v_rndne_f32_e32 v106, v104                                 // 00000012C384: 7ED44768
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012C388: BF870112
	v_fmamk_f32 v105, v96, 0xb2a5705f, v105                    // 00000012C38C: 58D2D360 B2A5705F
	v_sub_f32_e32 v104, v104, v106                             // 00000012C394: 08D0D568
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012C398: BF870121
	v_add_f32_e32 v104, v104, v105                             // 00000012C39C: 06D0D368
	v_cvt_i32_f32_e32 v105, v106                               // 00000012C3A0: 7ED2116A
	v_exp_f32_e32 v104, v104                                   // 00000012C3A4: 7ED04B68
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C3A8: BF870095
	.long 0xd71c0068                                           // 00000012C3AC: D71C0068
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                   // 00000012C3B0: 0202D368
	v_cndmask_b32_e32 v104, 0, v104, vcc_lo                    // 00000012C3B4: 02D0D080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 00000012C3B8: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C3C0: BF870092
	v_cndmask_b32_e32 v96, 0x7f800000, v104, vcc_lo            // 00000012C3C4: 02C0D0FF 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 00000012C3CC: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C3D0: BF870091
	v_div_scale_f32 v104, null, v96, v96, v97                  // 00000012C3D4: D6FC7C68 0586C160
	v_rcp_f32_e32 v105, v104                                   // 00000012C3DC: 7ED25568
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C3E0: BF870095
	v_fma_f32 v106, -v104, v105, 1.0                           // 00000012C3E4: D613006A 23CAD368
	v_fmac_f32_e32 v105, v106, v105                            // 00000012C3EC: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v97, v96, v97                // 00000012C3F0: D6FC6A6A 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C3F8: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 00000012C3FC: 10D6D36A
	v_fma_f32 v108, -v104, v107, v106                          // 00000012C400: D613006C 25AAD768
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C408: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 00000012C40C: 56D6D36C
	v_fma_f32 v104, -v104, v107, v106                          // 00000012C410: D6130068 25AAD768
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C418: BF870091
	v_div_fmas_f32 v104, v104, v105, v107                      // 00000012C41C: D6370068 05AED368
	v_div_fixup_f32 v104, v104, v96, v97                       // 00000012C424: D6270068 0586C168
	v_mad_i64_i32 v[96:97], null, 0x3000, v120, v[128:129]     // 00000012C42C: D6FF7C60 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C438: BF870092
	v_bfe_u32 v105, v104, 16, 1                                // 00000012C43C: D6100069 02052168
	v_add3_u32 v104, v104, v105, 0x7fff                        // 00000012C444: D6550068 03FED368 00007FFF
	global_store_d16_hi_b16 v[96:97], v104, off offset:96      // 00000012C450: DC960060 007C6860
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012C458: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012C45C: BE882002
	s_cbranch_execz 63864                                      // 00000012C460: BFA5F978 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3544>
	v_mad_i64_i32 v[96:97], null, 0x6000, v121, v[130:131]     // 00000012C464: D6FF7C60 060AF2FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 00000012C470: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 00000012C478: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 00000012C47C: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C480: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 00000012C484: 10C2C0FF BFB8AA3B
	v_fma_f32 v104, 0xbfb8aa3b, v96, -v97                      // 00000012C48C: D6130068 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v105, v97                                  // 00000012C498: 7ED24761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012C49C: BF870221
	v_sub_f32_e32 v97, v97, v105                               // 00000012C4A0: 08C2D361
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 00000012C4A4: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v104, v96, 0xb2a5705f, v104                    // 00000012C4AC: 58D0D160 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012C4B4: BF870121
	v_add_f32_e32 v97, v97, v104                               // 00000012C4B8: 06C2D161
	v_cvt_i32_f32_e32 v104, v105                               // 00000012C4BC: 7ED01169
	v_exp_f32_e32 v97, v97                                     // 00000012C4C0: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C4C4: BF870095
	.long 0xd71c0061                                           // 00000012C4C8: D71C0061
	v_cndmask_b32_e32 v1, v97, v104, vcc_lo                    // 00000012C4CC: 0202D161
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 00000012C4D0: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 00000012C4D4: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C4DC: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v136, v98// 00000012C4E0: CA46C2FF 6060C588 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 00000012C4EC: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C4F0: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 00000012C4F4: D6FC7C62 0586C160
	v_rcp_f32_e32 v104, v98                                    // 00000012C4FC: 7ED05562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C500: BF870095
	v_fma_f32 v105, -v98, v104, 1.0                            // 00000012C504: D6130069 23CAD162
	v_fmac_f32_e32 v104, v105, v104                            // 00000012C50C: 56D0D169
	v_div_scale_f32 v105, vcc_lo, v97, v96, v97                // 00000012C510: D6FC6A69 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C518: BF870091
	v_mul_f32_e32 v106, v105, v104                             // 00000012C51C: 10D4D169
	v_fma_f32 v107, -v98, v106, v105                           // 00000012C520: D613006B 25A6D562
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C528: BF870091
	v_fmac_f32_e32 v106, v107, v104                            // 00000012C52C: 56D4D16B
	v_fma_f32 v98, -v98, v106, v105                            // 00000012C530: D6130062 25A6D562
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C538: BF870091
	v_div_fmas_f32 v98, v98, v104, v106                        // 00000012C53C: D6370062 05AAD162
	v_div_fixup_f32 v98, v98, v96, v97                         // 00000012C544: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v121, v[128:129]     // 00000012C54C: D6FF7C60 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C558: BF870092
	v_bfe_u32 v104, v98, 16, 1                                 // 00000012C55C: D6100068 02052162
	v_add3_u32 v98, v98, v104, 0x7fff                          // 00000012C564: D6550062 03FED162 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 00000012C570: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012C578: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012C57C: BE882003
	s_cbranch_execz 63795                                      // 00000012C580: BFA5F933 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3550>
	v_mad_i64_i32 v[96:97], null, 0x6000, v122, v[130:131]     // 00000012C584: D6FF7C60 060AF4FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 00000012C590: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 00000012C598: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 00000012C59C: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C5A0: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 00000012C5A4: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 00000012C5AC: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v104, v97                                  // 00000012C5B8: 7ED04761
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C5BC: BF870091
	v_dual_fmamk_f32 v98, v96, 0xb2a5705f, v98 :: v_dual_sub_f32 v97, v97, v104// 00000012C5C0: C88AC560 6260D161 B2A5705F
	v_add_f32_e32 v97, v97, v98                                // 00000012C5CC: 06C2C561
	v_cvt_i32_f32_e32 v98, v104                                // 00000012C5D0: 7EC41168
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 00000012C5D4: 7C3CC0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012C5DC: BF870293
	v_exp_f32_e32 v97, v97                                     // 00000012C5E0: 7EC24B61
	.long 0xd71c0061                                           // 00000012C5E4: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 00000012C5E8: 0202C561
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012C5EC: BF870121
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 00000012C5F0: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 00000012C5F4: 7C36C0FF C2B17218
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v137, v99// 00000012C5FC: CA46C2FF 6060C789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C608: BF870091
	v_add_f32_e32 v96, 1.0, v96                                // 00000012C60C: 06C0C0F2
	v_div_scale_f32 v98, null, v96, v96, v97                   // 00000012C610: D6FC7C62 0586C160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012C618: BF870291
	v_rcp_f32_e32 v99, v98                                     // 00000012C61C: 7EC65562
	v_fma_f32 v104, -v98, v99, 1.0                             // 00000012C620: D6130068 23CAC762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012C628: BF8700A1
	v_fmac_f32_e32 v99, v104, v99                              // 00000012C62C: 56C6C768
	v_div_scale_f32 v104, vcc_lo, v97, v96, v97                // 00000012C630: D6FC6A68 0586C161
	v_mul_f32_e32 v105, v104, v99                              // 00000012C638: 10D2C768
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C63C: BF870091
	v_fma_f32 v106, -v98, v105, v104                           // 00000012C640: D613006A 25A2D362
	v_fmac_f32_e32 v105, v106, v99                             // 00000012C648: 56D2C76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C64C: BF870091
	v_fma_f32 v98, -v98, v105, v104                            // 00000012C650: D6130062 25A2D362
	v_div_fmas_f32 v98, v98, v99, v105                         // 00000012C658: D6370062 05A6C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012C660: BF870121
	v_div_fixup_f32 v98, v98, v96, v97                         // 00000012C664: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v122, v[128:129]     // 00000012C66C: D6FF7C60 0602F4FF 00003000
	v_bfe_u32 v99, v98, 16, 1                                  // 00000012C678: D6100063 02052162
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012C680: BF870001
	v_add3_u32 v98, v98, v99, 0x7fff                           // 00000012C684: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 00000012C690: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012C698: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012C69C: BE882004
	s_cbranch_execz 63726                                      // 00000012C6A0: BFA5F8EE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x355c>
	v_mad_i64_i32 v[96:97], null, 0x6000, v123, v[130:131]     // 00000012C6A4: D6FF7C60 060AF6FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 00000012C6B0: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 00000012C6B8: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 00000012C6BC: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C6C0: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 00000012C6C4: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 00000012C6CC: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 00000012C6D8: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012C6DC: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 00000012C6E0: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 00000012C6E4: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 00000012C6EC: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012C6F4: BF870121
	v_add_f32_e32 v97, v97, v98                                // 00000012C6F8: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 00000012C6FC: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 00000012C700: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C704: BF870095
	.long 0xd71c0061                                           // 00000012C708: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 00000012C70C: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 00000012C710: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 00000012C714: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C71C: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v134, v100// 00000012C720: CA46C2FF 6060C986 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 00000012C72C: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C730: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 00000012C734: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 00000012C73C: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C740: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 00000012C744: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 00000012C74C: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 00000012C750: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C758: BF870091
	v_mul_f32_e32 v104, v100, v99                              // 00000012C75C: 10D0C764
	v_fma_f32 v105, -v98, v104, v100                           // 00000012C760: D6130069 2592D162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C768: BF870091
	v_fmac_f32_e32 v104, v105, v99                             // 00000012C76C: 56D0C769
	v_fma_f32 v98, -v98, v104, v100                            // 00000012C770: D6130062 2592D162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C778: BF870091
	v_div_fmas_f32 v98, v98, v99, v104                         // 00000012C77C: D6370062 05A2C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 00000012C784: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v123, v[128:129]     // 00000012C78C: D6FF7C60 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C798: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 00000012C79C: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 00000012C7A4: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 00000012C7B0: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012C7B8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012C7BC: BE882005
	s_cbranch_execz 63657                                      // 00000012C7C0: BFA5F8A9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3568>
	v_mad_i64_i32 v[96:97], null, 0x6000, v124, v[130:131]     // 00000012C7C4: D6FF7C60 060AF8FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 00000012C7D0: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 00000012C7D8: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 00000012C7DC: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C7E0: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 00000012C7E4: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 00000012C7EC: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 00000012C7F8: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012C7FC: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 00000012C800: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 00000012C804: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 00000012C80C: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012C814: BF870121
	v_add_f32_e32 v97, v97, v98                                // 00000012C818: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 00000012C81C: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 00000012C820: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C824: BF870095
	.long 0xd71c0061                                           // 00000012C828: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 00000012C82C: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 00000012C830: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 00000012C834: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C83C: BF870092
	v_cndmask_b32_e32 v96, 0x7f800000, v97, vcc_lo             // 00000012C840: 02C0C2FF 7F800000
	v_dual_mul_f32 v97, v135, v101 :: v_dual_add_f32 v96, 1.0, v96// 00000012C848: C8C8CB87 6160C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C850: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 00000012C854: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 00000012C85C: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C860: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 00000012C864: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 00000012C86C: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 00000012C870: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C878: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 00000012C87C: 10CAC764
	v_fma_f32 v104, -v98, v101, v100                           // 00000012C880: D6130068 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C888: BF870091
	v_fmac_f32_e32 v101, v104, v99                             // 00000012C88C: 56CAC768
	v_fma_f32 v98, -v98, v101, v100                            // 00000012C890: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C898: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 00000012C89C: D6370062 0596C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 00000012C8A4: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v124, v[128:129]     // 00000012C8AC: D6FF7C60 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C8B8: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 00000012C8BC: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 00000012C8C4: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 00000012C8D0: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012C8D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012C8DC: BE882006
	s_cbranch_execz 63588                                      // 00000012C8E0: BFA5F864 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3574>
	v_mad_i64_i32 v[96:97], null, 0x6000, v125, v[130:131]     // 00000012C8E4: D6FF7C60 060AFAFF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 00000012C8F0: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 00000012C8F8: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 00000012C8FC: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C900: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 00000012C904: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 00000012C90C: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 00000012C918: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012C91C: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 00000012C920: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 00000012C924: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 00000012C92C: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012C934: BF870121
	v_add_f32_e32 v97, v97, v98                                // 00000012C938: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 00000012C93C: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 00000012C940: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C944: BF870095
	.long 0xd71c0061                                           // 00000012C948: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 00000012C94C: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 00000012C950: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 00000012C954: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C95C: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v132, v102// 00000012C960: CA46C2FF 6060CD84 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 00000012C96C: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C970: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 00000012C974: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 00000012C97C: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C980: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 00000012C984: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 00000012C98C: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 00000012C990: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C998: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 00000012C99C: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 00000012C9A0: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C9A8: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 00000012C9AC: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 00000012C9B0: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C9B8: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 00000012C9BC: D6370062 0596C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 00000012C9C4: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v125, v[128:129]     // 00000012C9CC: D6FF7C60 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012C9D8: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 00000012C9DC: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 00000012C9E4: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 00000012C9F0: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012C9F8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012C9FC: BE882007
	s_cbranch_execz 63519                                      // 00000012CA00: BFA5F81F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3580>
	v_mad_i64_i32 v[96:97], null, 0x6000, v126, v[130:131]     // 00000012CA04: D6FF7C60 060AFCFF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 00000012CA10: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 00000012CA18: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 00000012CA1C: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CA20: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 00000012CA24: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 00000012CA2C: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 00000012CA38: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012CA3C: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 00000012CA40: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 00000012CA44: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 00000012CA4C: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012CA54: BF870121
	v_add_f32_e32 v97, v97, v98                                // 00000012CA58: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 00000012CA5C: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 00000012CA60: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CA64: BF870095
	.long 0xd71c0061                                           // 00000012CA68: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 00000012CA6C: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 00000012CA70: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 00000012CA74: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CA7C: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v133, v103// 00000012CA80: CA46C2FF 6060CF85 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 00000012CA8C: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CA90: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 00000012CA94: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 00000012CA9C: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CAA0: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 00000012CAA4: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 00000012CAAC: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 00000012CAB0: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CAB8: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 00000012CABC: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 00000012CAC0: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CAC8: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 00000012CACC: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 00000012CAD0: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CAD8: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 00000012CADC: D6370062 0596C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 00000012CAE4: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v126, v[128:129]     // 00000012CAEC: D6FF7C60 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CAF8: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 00000012CAFC: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 00000012CB04: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 00000012CB10: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012CB18: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012CB1C: BE882000
	s_cbranch_execz 63450                                      // 00000012CB20: BFA5F7DA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x358c>
	v_mad_i64_i32 v[96:97], null, 0x6000, v140, v[130:131]     // 00000012CB24: D6FF7C60 060B18FF 00006000
	v_mul_f32_e32 v88, v138, v88                               // 00000012CB30: 10B0B18A
	global_load_u16 v96, v[96:97], off offset:640              // 00000012CB34: DC4A0280 607C0060
	s_waitcnt vmcnt(0)                                         // 00000012CB3C: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 00000012CB40: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CB44: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 00000012CB48: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 00000012CB50: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 00000012CB5C: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012CB60: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 00000012CB64: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 00000012CB68: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 00000012CB70: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012CB78: BF870121
	v_add_f32_e32 v97, v97, v98                                // 00000012CB7C: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 00000012CB80: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 00000012CB84: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CB88: BF870095
	.long 0xd71c0061                                           // 00000012CB8C: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 00000012CB90: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 00000012CB94: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 00000012CB98: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CBA0: BF870092
	v_cndmask_b32_e32 v96, 0x7f800000, v97, vcc_lo             // 00000012CBA4: 02C0C2FF 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 00000012CBAC: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CBB0: BF870091
	v_div_scale_f32 v97, null, v96, v96, v88                   // 00000012CBB4: D6FC7C61 0562C160
	v_rcp_f32_e32 v98, v97                                     // 00000012CBBC: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CBC0: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 00000012CBC4: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 00000012CBCC: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v88, v96, v88                 // 00000012CBD0: D6FC6A63 0562C158
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CBD8: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 00000012CBDC: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 00000012CBE0: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CBE8: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 00000012CBEC: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 00000012CBF0: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CBF8: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 00000012CBFC: D6370061 0592C561
	v_div_fixup_f32 v88, v97, v96, v88                         // 00000012CC04: D6270058 0562C161
	v_mad_i64_i32 v[96:97], null, 0x3000, v140, v[128:129]     // 00000012CC0C: D6FF7C60 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CC18: BF870092
	v_bfe_u32 v98, v88, 16, 1                                  // 00000012CC1C: D6100062 02052158
	v_add3_u32 v88, v88, v98, 0x7fff                           // 00000012CC24: D6550058 03FEC558 00007FFF
	global_store_d16_hi_b16 v[96:97], v88, off offset:128      // 00000012CC30: DC960080 007C5860
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012CC38: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012CC3C: BE882001
	s_cbranch_execz 63381                                      // 00000012CC40: BFA5F795 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3598>
	v_mad_i64_i32 v[96:97], null, 0x6000, v120, v[130:131]     // 00000012CC44: D6FF7C60 060AF0FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 00000012CC50: 10B2B38B
	global_load_u16 v88, v[96:97], off offset:640              // 00000012CC54: DC4A0280 587C0060
	s_waitcnt vmcnt(0)                                         // 00000012CC5C: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 00000012CC60: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012CC64: BF870121
	v_mul_f32_e32 v96, 0xbfb8aa3b, v88                         // 00000012CC68: 10C0B0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 00000012CC70: 7C3CB0FF 42CE8ED0
	v_fma_f32 v97, 0xbfb8aa3b, v88, -v96                       // 00000012CC78: D6130061 8582B0FF BFB8AA3B
	v_rndne_f32_e32 v98, v96                                   // 00000012CC84: 7EC44760
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012CC88: BF870112
	v_fmamk_f32 v97, v88, 0xb2a5705f, v97                      // 00000012CC8C: 58C2C358 B2A5705F
	v_sub_f32_e32 v96, v96, v98                                // 00000012CC94: 08C0C560
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012CC98: BF870121
	v_add_f32_e32 v96, v96, v97                                // 00000012CC9C: 06C0C360
	v_cvt_i32_f32_e32 v97, v98                                 // 00000012CCA0: 7EC21162
	v_exp_f32_e32 v96, v96                                     // 00000012CCA4: 7EC04B60
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CCA8: BF870095
	.long 0xd71c0060                                           // 00000012CCAC: D71C0060
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                     // 00000012CCB0: 0202C360
	v_cndmask_b32_e32 v96, 0, v96, vcc_lo                      // 00000012CCB4: 02C0C080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 00000012CCB8: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CCC0: BF870092
	v_cndmask_b32_e32 v88, 0x7f800000, v96, vcc_lo             // 00000012CCC4: 02B0C0FF 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 00000012CCCC: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CCD0: BF870091
	v_div_scale_f32 v96, null, v88, v88, v89                   // 00000012CCD4: D6FC7C60 0566B158
	v_rcp_f32_e32 v97, v96                                     // 00000012CCDC: 7EC25560
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CCE0: BF870095
	v_fma_f32 v98, -v96, v97, 1.0                              // 00000012CCE4: D6130062 23CAC360
	v_fmac_f32_e32 v97, v98, v97                               // 00000012CCEC: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v89, v88, v89                 // 00000012CCF0: D6FC6A62 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CCF8: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 00000012CCFC: 10C6C362
	v_fma_f32 v100, -v96, v99, v98                             // 00000012CD00: D6130064 258AC760
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CD08: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 00000012CD0C: 56C6C364
	v_fma_f32 v96, -v96, v99, v98                              // 00000012CD10: D6130060 258AC760
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CD18: BF870091
	v_div_fmas_f32 v96, v96, v97, v99                          // 00000012CD1C: D6370060 058EC360
	v_div_fixup_f32 v96, v96, v88, v89                         // 00000012CD24: D6270060 0566B160
	v_mad_i64_i32 v[88:89], null, 0x3000, v120, v[128:129]     // 00000012CD2C: D6FF7C58 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CD38: BF870092
	v_bfe_u32 v97, v96, 16, 1                                  // 00000012CD3C: D6100061 02052160
	v_add3_u32 v96, v96, v97, 0x7fff                           // 00000012CD44: D6550060 03FEC360 00007FFF
	global_store_d16_hi_b16 v[88:89], v96, off offset:128      // 00000012CD50: DC960080 007C6058
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012CD58: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012CD5C: BE882002
	s_cbranch_execz 63312                                      // 00000012CD60: BFA5F750 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35a4>
	v_mad_i64_i32 v[88:89], null, 0x6000, v121, v[130:131]     // 00000012CD64: D6FF7C58 060AF2FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 00000012CD70: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 00000012CD78: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 00000012CD7C: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CD80: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 00000012CD84: 10B2B0FF BFB8AA3B
	v_fma_f32 v96, 0xbfb8aa3b, v88, -v89                       // 00000012CD8C: D6130060 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v97, v89                                   // 00000012CD98: 7EC24759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012CD9C: BF870221
	v_sub_f32_e32 v89, v89, v97                                // 00000012CDA0: 08B2C359
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 00000012CDA4: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v96, v88, 0xb2a5705f, v96                      // 00000012CDAC: 58C0C158 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012CDB4: BF870121
	v_add_f32_e32 v89, v89, v96                                // 00000012CDB8: 06B2C159
	v_cvt_i32_f32_e32 v96, v97                                 // 00000012CDBC: 7EC01161
	v_exp_f32_e32 v89, v89                                     // 00000012CDC0: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CDC4: BF870095
	.long 0xd71c0059                                           // 00000012CDC8: D71C0059
	v_cndmask_b32_e32 v1, v89, v96, vcc_lo                     // 00000012CDCC: 0202C159
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000012CDD0: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 00000012CDD4: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CDDC: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v136, v90// 00000012CDE0: CA46B2FF 5858B588 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 00000012CDEC: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CDF0: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 00000012CDF4: D6FC7C5A 0566B158
	v_rcp_f32_e32 v96, v90                                     // 00000012CDFC: 7EC0555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CE00: BF870095
	v_fma_f32 v97, -v90, v96, 1.0                              // 00000012CE04: D6130061 23CAC15A
	v_fmac_f32_e32 v96, v97, v96                               // 00000012CE0C: 56C0C161
	v_div_scale_f32 v97, vcc_lo, v89, v88, v89                 // 00000012CE10: D6FC6A61 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CE18: BF870091
	v_mul_f32_e32 v98, v97, v96                                // 00000012CE1C: 10C4C161
	v_fma_f32 v99, -v90, v98, v97                              // 00000012CE20: D6130063 2586C55A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CE28: BF870091
	v_fmac_f32_e32 v98, v99, v96                               // 00000012CE2C: 56C4C163
	v_fma_f32 v90, -v90, v98, v97                              // 00000012CE30: D613005A 2586C55A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CE38: BF870091
	v_div_fmas_f32 v90, v90, v96, v98                          // 00000012CE3C: D637005A 058AC15A
	v_div_fixup_f32 v90, v90, v88, v89                         // 00000012CE44: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v121, v[128:129]     // 00000012CE4C: D6FF7C58 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CE58: BF870092
	v_bfe_u32 v96, v90, 16, 1                                  // 00000012CE5C: D6100060 0205215A
	v_add3_u32 v90, v90, v96, 0x7fff                           // 00000012CE64: D655005A 03FEC15A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 00000012CE70: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012CE78: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012CE7C: BE882003
	s_cbranch_execz 63243                                      // 00000012CE80: BFA5F70B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35b0>
	v_mad_i64_i32 v[88:89], null, 0x6000, v122, v[130:131]     // 00000012CE84: D6FF7C58 060AF4FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 00000012CE90: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 00000012CE98: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 00000012CE9C: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CEA0: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 00000012CEA4: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 00000012CEAC: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v96, v89                                   // 00000012CEB8: 7EC04759
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CEBC: BF870091
	v_dual_fmamk_f32 v90, v88, 0xb2a5705f, v90 :: v_dual_sub_f32 v89, v89, v96// 00000012CEC0: C88AB558 5A58C159 B2A5705F
	v_add_f32_e32 v89, v89, v90                                // 00000012CECC: 06B2B559
	v_cvt_i32_f32_e32 v90, v96                                 // 00000012CED0: 7EB41160
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 00000012CED4: 7C3CB0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012CEDC: BF870293
	v_exp_f32_e32 v89, v89                                     // 00000012CEE0: 7EB24B59
	.long 0xd71c0059                                           // 00000012CEE4: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 00000012CEE8: 0202B559
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012CEEC: BF870121
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000012CEF0: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 00000012CEF4: 7C36B0FF C2B17218
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v137, v91// 00000012CEFC: CA46B2FF 5858B789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CF08: BF870091
	v_add_f32_e32 v88, 1.0, v88                                // 00000012CF0C: 06B0B0F2
	v_div_scale_f32 v90, null, v88, v88, v89                   // 00000012CF10: D6FC7C5A 0566B158
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012CF18: BF870291
	v_rcp_f32_e32 v91, v90                                     // 00000012CF1C: 7EB6555A
	v_fma_f32 v96, -v90, v91, 1.0                              // 00000012CF20: D6130060 23CAB75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012CF28: BF8700A1
	v_fmac_f32_e32 v91, v96, v91                               // 00000012CF2C: 56B6B760
	v_div_scale_f32 v96, vcc_lo, v89, v88, v89                 // 00000012CF30: D6FC6A60 0566B159
	v_mul_f32_e32 v97, v96, v91                                // 00000012CF38: 10C2B760
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CF3C: BF870091
	v_fma_f32 v98, -v90, v97, v96                              // 00000012CF40: D6130062 2582C35A
	v_fmac_f32_e32 v97, v98, v91                               // 00000012CF48: 56C2B762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CF4C: BF870091
	v_fma_f32 v90, -v90, v97, v96                              // 00000012CF50: D613005A 2582C35A
	v_div_fmas_f32 v90, v90, v91, v97                          // 00000012CF58: D637005A 0586B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012CF60: BF870121
	v_div_fixup_f32 v90, v90, v88, v89                         // 00000012CF64: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v122, v[128:129]     // 00000012CF6C: D6FF7C58 0602F4FF 00003000
	v_bfe_u32 v91, v90, 16, 1                                  // 00000012CF78: D610005B 0205215A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012CF80: BF870001
	v_add3_u32 v90, v90, v91, 0x7fff                           // 00000012CF84: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 00000012CF90: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012CF98: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012CF9C: BE882004
	s_cbranch_execz 63174                                      // 00000012CFA0: BFA5F6C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35bc>
	v_mad_i64_i32 v[88:89], null, 0x6000, v123, v[130:131]     // 00000012CFA4: D6FF7C58 060AF6FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 00000012CFB0: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 00000012CFB8: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 00000012CFBC: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012CFC0: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 00000012CFC4: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 00000012CFCC: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 00000012CFD8: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012CFDC: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 00000012CFE0: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 00000012CFE4: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 00000012CFEC: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012CFF4: BF870121
	v_add_f32_e32 v89, v89, v90                                // 00000012CFF8: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 00000012CFFC: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 00000012D000: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D004: BF870095
	.long 0xd71c0059                                           // 00000012D008: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 00000012D00C: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000012D010: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 00000012D014: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D01C: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v134, v92// 00000012D020: CA46B2FF 5858B986 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 00000012D02C: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D030: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 00000012D034: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 00000012D03C: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D040: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 00000012D044: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 00000012D04C: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 00000012D050: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D058: BF870091
	v_mul_f32_e32 v96, v92, v91                                // 00000012D05C: 10C0B75C
	v_fma_f32 v97, -v90, v96, v92                              // 00000012D060: D6130061 2572C15A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D068: BF870091
	v_fmac_f32_e32 v96, v97, v91                               // 00000012D06C: 56C0B761
	v_fma_f32 v90, -v90, v96, v92                              // 00000012D070: D613005A 2572C15A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D078: BF870091
	v_div_fmas_f32 v90, v90, v91, v96                          // 00000012D07C: D637005A 0582B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 00000012D084: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v123, v[128:129]     // 00000012D08C: D6FF7C58 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D098: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 00000012D09C: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 00000012D0A4: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 00000012D0B0: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012D0B8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012D0BC: BE882005
	s_cbranch_execz 63105                                      // 00000012D0C0: BFA5F681 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35c8>
	v_mad_i64_i32 v[88:89], null, 0x6000, v124, v[130:131]     // 00000012D0C4: D6FF7C58 060AF8FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 00000012D0D0: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 00000012D0D8: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 00000012D0DC: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D0E0: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 00000012D0E4: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 00000012D0EC: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 00000012D0F8: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012D0FC: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 00000012D100: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 00000012D104: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 00000012D10C: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012D114: BF870121
	v_add_f32_e32 v89, v89, v90                                // 00000012D118: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 00000012D11C: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 00000012D120: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D124: BF870095
	.long 0xd71c0059                                           // 00000012D128: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 00000012D12C: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000012D130: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 00000012D134: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D13C: BF870092
	v_cndmask_b32_e32 v88, 0x7f800000, v89, vcc_lo             // 00000012D140: 02B0B2FF 7F800000
	v_dual_mul_f32 v89, v135, v93 :: v_dual_add_f32 v88, 1.0, v88// 00000012D148: C8C8BB87 5958B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D150: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 00000012D154: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 00000012D15C: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D160: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 00000012D164: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 00000012D16C: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 00000012D170: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D178: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 00000012D17C: 10BAB75C
	v_fma_f32 v96, -v90, v93, v92                              // 00000012D180: D6130060 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D188: BF870091
	v_fmac_f32_e32 v93, v96, v91                               // 00000012D18C: 56BAB760
	v_fma_f32 v90, -v90, v93, v92                              // 00000012D190: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D198: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 00000012D19C: D637005A 0576B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 00000012D1A4: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v124, v[128:129]     // 00000012D1AC: D6FF7C58 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D1B8: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 00000012D1BC: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 00000012D1C4: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 00000012D1D0: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012D1D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012D1DC: BE882006
	s_cbranch_execz 63036                                      // 00000012D1E0: BFA5F63C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35d4>
	v_mad_i64_i32 v[88:89], null, 0x6000, v125, v[130:131]     // 00000012D1E4: D6FF7C58 060AFAFF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 00000012D1F0: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 00000012D1F8: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 00000012D1FC: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D200: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 00000012D204: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 00000012D20C: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 00000012D218: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012D21C: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 00000012D220: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 00000012D224: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 00000012D22C: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012D234: BF870121
	v_add_f32_e32 v89, v89, v90                                // 00000012D238: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 00000012D23C: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 00000012D240: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D244: BF870095
	.long 0xd71c0059                                           // 00000012D248: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 00000012D24C: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000012D250: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 00000012D254: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D25C: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v132, v94// 00000012D260: CA46B2FF 5858BD84 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 00000012D26C: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D270: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 00000012D274: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 00000012D27C: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D280: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 00000012D284: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 00000012D28C: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 00000012D290: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D298: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 00000012D29C: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 00000012D2A0: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D2A8: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 00000012D2AC: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 00000012D2B0: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D2B8: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 00000012D2BC: D637005A 0576B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 00000012D2C4: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v125, v[128:129]     // 00000012D2CC: D6FF7C58 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D2D8: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 00000012D2DC: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 00000012D2E4: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 00000012D2F0: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012D2F8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012D2FC: BE882007
	s_cbranch_execz 62967                                      // 00000012D300: BFA5F5F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35e0>
	v_mad_i64_i32 v[88:89], null, 0x6000, v126, v[130:131]     // 00000012D304: D6FF7C58 060AFCFF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 00000012D310: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 00000012D318: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 00000012D31C: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D320: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 00000012D324: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 00000012D32C: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 00000012D338: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012D33C: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 00000012D340: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 00000012D344: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 00000012D34C: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012D354: BF870121
	v_add_f32_e32 v89, v89, v90                                // 00000012D358: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 00000012D35C: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 00000012D360: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D364: BF870095
	.long 0xd71c0059                                           // 00000012D368: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 00000012D36C: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000012D370: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 00000012D374: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D37C: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v133, v95// 00000012D380: CA46B2FF 5858BF85 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 00000012D38C: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D390: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 00000012D394: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 00000012D39C: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D3A0: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 00000012D3A4: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 00000012D3AC: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 00000012D3B0: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D3B8: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 00000012D3BC: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 00000012D3C0: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D3C8: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 00000012D3CC: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 00000012D3D0: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D3D8: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 00000012D3DC: D637005A 0576B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 00000012D3E4: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v126, v[128:129]     // 00000012D3EC: D6FF7C58 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D3F8: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 00000012D3FC: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 00000012D404: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 00000012D410: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012D418: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012D41C: BE882000
	s_cbranch_execz 62898                                      // 00000012D420: BFA5F5B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35ec>
	v_mad_i64_i32 v[88:89], null, 0x6000, v140, v[130:131]     // 00000012D424: D6FF7C58 060B18FF 00006000
	v_mul_f32_e32 v80, v138, v80                               // 00000012D430: 10A0A18A
	global_load_u16 v88, v[88:89], off offset:672              // 00000012D434: DC4A02A0 587C0058
	s_waitcnt vmcnt(0)                                         // 00000012D43C: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 00000012D440: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D444: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 00000012D448: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 00000012D450: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 00000012D45C: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012D460: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 00000012D464: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 00000012D468: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 00000012D470: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012D478: BF870121
	v_add_f32_e32 v89, v89, v90                                // 00000012D47C: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 00000012D480: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 00000012D484: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D488: BF870095
	.long 0xd71c0059                                           // 00000012D48C: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 00000012D490: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 00000012D494: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 00000012D498: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D4A0: BF870092
	v_cndmask_b32_e32 v88, 0x7f800000, v89, vcc_lo             // 00000012D4A4: 02B0B2FF 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 00000012D4AC: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D4B0: BF870091
	v_div_scale_f32 v89, null, v88, v88, v80                   // 00000012D4B4: D6FC7C59 0542B158
	v_rcp_f32_e32 v90, v89                                     // 00000012D4BC: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D4C0: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 00000012D4C4: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 00000012D4CC: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v80, v88, v80                 // 00000012D4D0: D6FC6A5B 0542B150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D4D8: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 00000012D4DC: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 00000012D4E0: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D4E8: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 00000012D4EC: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 00000012D4F0: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D4F8: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 00000012D4FC: D6370059 0572B559
	v_div_fixup_f32 v80, v89, v88, v80                         // 00000012D504: D6270050 0542B159
	v_mad_i64_i32 v[88:89], null, 0x3000, v140, v[128:129]     // 00000012D50C: D6FF7C58 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D518: BF870092
	v_bfe_u32 v90, v80, 16, 1                                  // 00000012D51C: D610005A 02052150
	v_add3_u32 v80, v80, v90, 0x7fff                           // 00000012D524: D6550050 03FEB550 00007FFF
	global_store_d16_hi_b16 v[88:89], v80, off offset:160      // 00000012D530: DC9600A0 007C5058
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012D538: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012D53C: BE882001
	s_cbranch_execz 62829                                      // 00000012D540: BFA5F56D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35f8>
	v_mad_i64_i32 v[88:89], null, 0x6000, v120, v[130:131]     // 00000012D544: D6FF7C58 060AF0FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 00000012D550: 10A2A38B
	global_load_u16 v80, v[88:89], off offset:672              // 00000012D554: DC4A02A0 507C0058
	s_waitcnt vmcnt(0)                                         // 00000012D55C: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000012D560: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012D564: BF870121
	v_mul_f32_e32 v88, 0xbfb8aa3b, v80                         // 00000012D568: 10B0A0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000012D570: 7C3CA0FF 42CE8ED0
	v_fma_f32 v89, 0xbfb8aa3b, v80, -v88                       // 00000012D578: D6130059 8562A0FF BFB8AA3B
	v_rndne_f32_e32 v90, v88                                   // 00000012D584: 7EB44758
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012D588: BF870112
	v_fmamk_f32 v89, v80, 0xb2a5705f, v89                      // 00000012D58C: 58B2B350 B2A5705F
	v_sub_f32_e32 v88, v88, v90                                // 00000012D594: 08B0B558
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012D598: BF870121
	v_add_f32_e32 v88, v88, v89                                // 00000012D59C: 06B0B358
	v_cvt_i32_f32_e32 v89, v90                                 // 00000012D5A0: 7EB2115A
	v_exp_f32_e32 v88, v88                                     // 00000012D5A4: 7EB04B58
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D5A8: BF870095
	.long 0xd71c0058                                           // 00000012D5AC: D71C0058
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                     // 00000012D5B0: 0202B358
	v_cndmask_b32_e32 v88, 0, v88, vcc_lo                      // 00000012D5B4: 02B0B080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000012D5B8: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D5C0: BF870092
	v_cndmask_b32_e32 v80, 0x7f800000, v88, vcc_lo             // 00000012D5C4: 02A0B0FF 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 00000012D5CC: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D5D0: BF870091
	v_div_scale_f32 v88, null, v80, v80, v81                   // 00000012D5D4: D6FC7C58 0546A150
	v_rcp_f32_e32 v89, v88                                     // 00000012D5DC: 7EB25558
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D5E0: BF870095
	v_fma_f32 v90, -v88, v89, 1.0                              // 00000012D5E4: D613005A 23CAB358
	v_fmac_f32_e32 v89, v90, v89                               // 00000012D5EC: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v81, v80, v81                 // 00000012D5F0: D6FC6A5A 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D5F8: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 00000012D5FC: 10B6B35A
	v_fma_f32 v92, -v88, v91, v90                              // 00000012D600: D613005C 256AB758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D608: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 00000012D60C: 56B6B35C
	v_fma_f32 v88, -v88, v91, v90                              // 00000012D610: D6130058 256AB758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D618: BF870091
	v_div_fmas_f32 v88, v88, v89, v91                          // 00000012D61C: D6370058 056EB358
	v_div_fixup_f32 v88, v88, v80, v81                         // 00000012D624: D6270058 0546A158
	v_mad_i64_i32 v[80:81], null, 0x3000, v120, v[128:129]     // 00000012D62C: D6FF7C50 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D638: BF870092
	v_bfe_u32 v89, v88, 16, 1                                  // 00000012D63C: D6100059 02052158
	v_add3_u32 v88, v88, v89, 0x7fff                           // 00000012D644: D6550058 03FEB358 00007FFF
	global_store_d16_hi_b16 v[80:81], v88, off offset:160      // 00000012D650: DC9600A0 007C5850
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012D658: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012D65C: BE882002
	s_cbranch_execz 62760                                      // 00000012D660: BFA5F528 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3604>
	v_mad_i64_i32 v[80:81], null, 0x6000, v121, v[130:131]     // 00000012D664: D6FF7C50 060AF2FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 00000012D670: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000012D678: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000012D67C: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D680: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 00000012D684: 10A2A0FF BFB8AA3B
	v_fma_f32 v88, 0xbfb8aa3b, v80, -v81                       // 00000012D68C: D6130058 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v89, v81                                   // 00000012D698: 7EB24751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012D69C: BF870221
	v_sub_f32_e32 v81, v81, v89                                // 00000012D6A0: 08A2B351
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000012D6A4: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v88, v80, 0xb2a5705f, v88                      // 00000012D6AC: 58B0B150 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012D6B4: BF870121
	v_add_f32_e32 v81, v81, v88                                // 00000012D6B8: 06A2B151
	v_cvt_i32_f32_e32 v88, v89                                 // 00000012D6BC: 7EB01159
	v_exp_f32_e32 v81, v81                                     // 00000012D6C0: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D6C4: BF870095
	.long 0xd71c0051                                           // 00000012D6C8: D71C0051
	v_cndmask_b32_e32 v1, v81, v88, vcc_lo                     // 00000012D6CC: 0202B151
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000012D6D0: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000012D6D4: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D6DC: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v136, v82// 00000012D6E0: CA46A2FF 5050A588 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 00000012D6EC: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D6F0: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 00000012D6F4: D6FC7C52 0546A150
	v_rcp_f32_e32 v88, v82                                     // 00000012D6FC: 7EB05552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D700: BF870095
	v_fma_f32 v89, -v82, v88, 1.0                              // 00000012D704: D6130059 23CAB152
	v_fmac_f32_e32 v88, v89, v88                               // 00000012D70C: 56B0B159
	v_div_scale_f32 v89, vcc_lo, v81, v80, v81                 // 00000012D710: D6FC6A59 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D718: BF870091
	v_mul_f32_e32 v90, v89, v88                                // 00000012D71C: 10B4B159
	v_fma_f32 v91, -v82, v90, v89                              // 00000012D720: D613005B 2566B552
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D728: BF870091
	v_fmac_f32_e32 v90, v91, v88                               // 00000012D72C: 56B4B15B
	v_fma_f32 v82, -v82, v90, v89                              // 00000012D730: D6130052 2566B552
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D738: BF870091
	v_div_fmas_f32 v82, v82, v88, v90                          // 00000012D73C: D6370052 056AB152
	v_div_fixup_f32 v82, v82, v80, v81                         // 00000012D744: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v121, v[128:129]     // 00000012D74C: D6FF7C50 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D758: BF870092
	v_bfe_u32 v88, v82, 16, 1                                  // 00000012D75C: D6100058 02052152
	v_add3_u32 v82, v82, v88, 0x7fff                           // 00000012D764: D6550052 03FEB152 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 00000012D770: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012D778: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012D77C: BE882003
	s_cbranch_execz 62691                                      // 00000012D780: BFA5F4E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3610>
	v_mad_i64_i32 v[80:81], null, 0x6000, v122, v[130:131]     // 00000012D784: D6FF7C50 060AF4FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 00000012D790: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000012D798: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000012D79C: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D7A0: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 00000012D7A4: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 00000012D7AC: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v88, v81                                   // 00000012D7B8: 7EB04751
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D7BC: BF870091
	v_dual_fmamk_f32 v82, v80, 0xb2a5705f, v82 :: v_dual_sub_f32 v81, v81, v88// 00000012D7C0: C88AA550 5250B151 B2A5705F
	v_add_f32_e32 v81, v81, v82                                // 00000012D7CC: 06A2A551
	v_cvt_i32_f32_e32 v82, v88                                 // 00000012D7D0: 7EA41158
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000012D7D4: 7C3CA0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012D7DC: BF870293
	v_exp_f32_e32 v81, v81                                     // 00000012D7E0: 7EA24B51
	.long 0xd71c0051                                           // 00000012D7E4: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000012D7E8: 0202A551
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012D7EC: BF870121
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000012D7F0: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000012D7F4: 7C36A0FF C2B17218
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v137, v83// 00000012D7FC: CA46A2FF 5050A789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D808: BF870091
	v_add_f32_e32 v80, 1.0, v80                                // 00000012D80C: 06A0A0F2
	v_div_scale_f32 v82, null, v80, v80, v81                   // 00000012D810: D6FC7C52 0546A150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012D818: BF870291
	v_rcp_f32_e32 v83, v82                                     // 00000012D81C: 7EA65552
	v_fma_f32 v88, -v82, v83, 1.0                              // 00000012D820: D6130058 23CAA752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012D828: BF8700A1
	v_fmac_f32_e32 v83, v88, v83                               // 00000012D82C: 56A6A758
	v_div_scale_f32 v88, vcc_lo, v81, v80, v81                 // 00000012D830: D6FC6A58 0546A151
	v_mul_f32_e32 v89, v88, v83                                // 00000012D838: 10B2A758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D83C: BF870091
	v_fma_f32 v90, -v82, v89, v88                              // 00000012D840: D613005A 2562B352
	v_fmac_f32_e32 v89, v90, v83                               // 00000012D848: 56B2A75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D84C: BF870091
	v_fma_f32 v82, -v82, v89, v88                              // 00000012D850: D6130052 2562B352
	v_div_fmas_f32 v82, v82, v83, v89                          // 00000012D858: D6370052 0566A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012D860: BF870121
	v_div_fixup_f32 v82, v82, v80, v81                         // 00000012D864: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v122, v[128:129]     // 00000012D86C: D6FF7C50 0602F4FF 00003000
	v_bfe_u32 v83, v82, 16, 1                                  // 00000012D878: D6100053 02052152
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012D880: BF870001
	v_add3_u32 v82, v82, v83, 0x7fff                           // 00000012D884: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 00000012D890: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012D898: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012D89C: BE882004
	s_cbranch_execz 62622                                      // 00000012D8A0: BFA5F49E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x361c>
	v_mad_i64_i32 v[80:81], null, 0x6000, v123, v[130:131]     // 00000012D8A4: D6FF7C50 060AF6FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 00000012D8B0: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000012D8B8: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000012D8BC: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D8C0: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 00000012D8C4: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 00000012D8CC: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000012D8D8: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012D8DC: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 00000012D8E0: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000012D8E4: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 00000012D8EC: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012D8F4: BF870121
	v_add_f32_e32 v81, v81, v82                                // 00000012D8F8: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 00000012D8FC: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000012D900: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D904: BF870095
	.long 0xd71c0051                                           // 00000012D908: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000012D90C: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000012D910: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000012D914: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D91C: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v134, v84// 00000012D920: CA46A2FF 5050A986 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 00000012D92C: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D930: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 00000012D934: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 00000012D93C: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D940: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 00000012D944: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 00000012D94C: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 00000012D950: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D958: BF870091
	v_mul_f32_e32 v88, v84, v83                                // 00000012D95C: 10B0A754
	v_fma_f32 v89, -v82, v88, v84                              // 00000012D960: D6130059 2552B152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D968: BF870091
	v_fmac_f32_e32 v88, v89, v83                               // 00000012D96C: 56B0A759
	v_fma_f32 v82, -v82, v88, v84                              // 00000012D970: D6130052 2552B152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D978: BF870091
	v_div_fmas_f32 v82, v82, v83, v88                          // 00000012D97C: D6370052 0562A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 00000012D984: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v123, v[128:129]     // 00000012D98C: D6FF7C50 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D998: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 00000012D99C: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 00000012D9A4: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 00000012D9B0: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012D9B8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012D9BC: BE882005
	s_cbranch_execz 62553                                      // 00000012D9C0: BFA5F459 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3628>
	v_mad_i64_i32 v[80:81], null, 0x6000, v124, v[130:131]     // 00000012D9C4: D6FF7C50 060AF8FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 00000012D9D0: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000012D9D8: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000012D9DC: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012D9E0: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 00000012D9E4: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 00000012D9EC: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000012D9F8: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012D9FC: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 00000012DA00: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000012DA04: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 00000012DA0C: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012DA14: BF870121
	v_add_f32_e32 v81, v81, v82                                // 00000012DA18: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 00000012DA1C: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000012DA20: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DA24: BF870095
	.long 0xd71c0051                                           // 00000012DA28: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000012DA2C: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000012DA30: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000012DA34: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DA3C: BF870092
	v_cndmask_b32_e32 v80, 0x7f800000, v81, vcc_lo             // 00000012DA40: 02A0A2FF 7F800000
	v_dual_mul_f32 v81, v135, v85 :: v_dual_add_f32 v80, 1.0, v80// 00000012DA48: C8C8AB87 5150A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DA50: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 00000012DA54: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 00000012DA5C: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DA60: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 00000012DA64: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 00000012DA6C: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 00000012DA70: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DA78: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 00000012DA7C: 10AAA754
	v_fma_f32 v88, -v82, v85, v84                              // 00000012DA80: D6130058 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DA88: BF870091
	v_fmac_f32_e32 v85, v88, v83                               // 00000012DA8C: 56AAA758
	v_fma_f32 v82, -v82, v85, v84                              // 00000012DA90: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DA98: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 00000012DA9C: D6370052 0556A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 00000012DAA4: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v124, v[128:129]     // 00000012DAAC: D6FF7C50 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DAB8: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 00000012DABC: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 00000012DAC4: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 00000012DAD0: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012DAD8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012DADC: BE882006
	s_cbranch_execz 62484                                      // 00000012DAE0: BFA5F414 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3634>
	v_mad_i64_i32 v[80:81], null, 0x6000, v125, v[130:131]     // 00000012DAE4: D6FF7C50 060AFAFF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 00000012DAF0: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000012DAF8: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000012DAFC: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DB00: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 00000012DB04: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 00000012DB0C: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000012DB18: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012DB1C: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 00000012DB20: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000012DB24: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 00000012DB2C: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012DB34: BF870121
	v_add_f32_e32 v81, v81, v82                                // 00000012DB38: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 00000012DB3C: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000012DB40: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DB44: BF870095
	.long 0xd71c0051                                           // 00000012DB48: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000012DB4C: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000012DB50: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000012DB54: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DB5C: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v132, v86// 00000012DB60: CA46A2FF 5050AD84 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 00000012DB6C: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DB70: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 00000012DB74: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 00000012DB7C: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DB80: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 00000012DB84: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 00000012DB8C: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 00000012DB90: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DB98: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 00000012DB9C: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 00000012DBA0: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DBA8: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 00000012DBAC: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 00000012DBB0: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DBB8: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 00000012DBBC: D6370052 0556A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 00000012DBC4: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v125, v[128:129]     // 00000012DBCC: D6FF7C50 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DBD8: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 00000012DBDC: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 00000012DBE4: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 00000012DBF0: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012DBF8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012DBFC: BE882007
	s_cbranch_execz 62415                                      // 00000012DC00: BFA5F3CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3640>
	v_mad_i64_i32 v[80:81], null, 0x6000, v126, v[130:131]     // 00000012DC04: D6FF7C50 060AFCFF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 00000012DC10: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000012DC18: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000012DC1C: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DC20: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 00000012DC24: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 00000012DC2C: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000012DC38: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012DC3C: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 00000012DC40: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000012DC44: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 00000012DC4C: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012DC54: BF870121
	v_add_f32_e32 v81, v81, v82                                // 00000012DC58: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 00000012DC5C: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000012DC60: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DC64: BF870095
	.long 0xd71c0051                                           // 00000012DC68: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000012DC6C: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000012DC70: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000012DC74: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DC7C: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v133, v87// 00000012DC80: CA46A2FF 5050AF85 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 00000012DC8C: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DC90: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 00000012DC94: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 00000012DC9C: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DCA0: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 00000012DCA4: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 00000012DCAC: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 00000012DCB0: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DCB8: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 00000012DCBC: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 00000012DCC0: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DCC8: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 00000012DCCC: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 00000012DCD0: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DCD8: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 00000012DCDC: D6370052 0556A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 00000012DCE4: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v126, v[128:129]     // 00000012DCEC: D6FF7C50 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DCF8: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 00000012DCFC: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 00000012DD04: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 00000012DD10: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012DD18: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012DD1C: BE882000
	s_cbranch_execz 62346                                      // 00000012DD20: BFA5F38A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x364c>
	v_mad_i64_i32 v[80:81], null, 0x6000, v140, v[130:131]     // 00000012DD24: D6FF7C50 060B18FF 00006000
	v_mul_f32_e32 v72, v138, v72                               // 00000012DD30: 1090918A
	global_load_u16 v80, v[80:81], off offset:704              // 00000012DD34: DC4A02C0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000012DD3C: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 00000012DD40: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DD44: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 00000012DD48: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 00000012DD50: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 00000012DD5C: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012DD60: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 00000012DD64: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 00000012DD68: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 00000012DD70: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012DD78: BF870121
	v_add_f32_e32 v81, v81, v82                                // 00000012DD7C: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 00000012DD80: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 00000012DD84: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DD88: BF870095
	.long 0xd71c0051                                           // 00000012DD8C: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 00000012DD90: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 00000012DD94: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000012DD98: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DDA0: BF870092
	v_cndmask_b32_e32 v80, 0x7f800000, v81, vcc_lo             // 00000012DDA4: 02A0A2FF 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 00000012DDAC: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DDB0: BF870091
	v_div_scale_f32 v81, null, v80, v80, v72                   // 00000012DDB4: D6FC7C51 0522A150
	v_rcp_f32_e32 v82, v81                                     // 00000012DDBC: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DDC0: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 00000012DDC4: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 00000012DDCC: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v72, v80, v72                 // 00000012DDD0: D6FC6A53 0522A148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DDD8: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 00000012DDDC: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 00000012DDE0: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DDE8: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 00000012DDEC: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 00000012DDF0: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DDF8: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 00000012DDFC: D6370051 0552A551
	v_div_fixup_f32 v72, v81, v80, v72                         // 00000012DE04: D6270048 0522A151
	v_mad_i64_i32 v[80:81], null, 0x3000, v140, v[128:129]     // 00000012DE0C: D6FF7C50 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DE18: BF870092
	v_bfe_u32 v82, v72, 16, 1                                  // 00000012DE1C: D6100052 02052148
	v_add3_u32 v72, v72, v82, 0x7fff                           // 00000012DE24: D6550048 03FEA548 00007FFF
	global_store_d16_hi_b16 v[80:81], v72, off offset:192      // 00000012DE30: DC9600C0 007C4850
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012DE38: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012DE3C: BE882001
	s_cbranch_execz 62277                                      // 00000012DE40: BFA5F345 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3658>
	v_mad_i64_i32 v[80:81], null, 0x6000, v120, v[130:131]     // 00000012DE44: D6FF7C50 060AF0FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 00000012DE50: 1092938B
	global_load_u16 v72, v[80:81], off offset:704              // 00000012DE54: DC4A02C0 487C0050
	s_waitcnt vmcnt(0)                                         // 00000012DE5C: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000012DE60: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012DE64: BF870121
	v_mul_f32_e32 v80, 0xbfb8aa3b, v72                         // 00000012DE68: 10A090FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000012DE70: 7C3C90FF 42CE8ED0
	v_fma_f32 v81, 0xbfb8aa3b, v72, -v80                       // 00000012DE78: D6130051 854290FF BFB8AA3B
	v_rndne_f32_e32 v82, v80                                   // 00000012DE84: 7EA44750
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012DE88: BF870112
	v_fmamk_f32 v81, v72, 0xb2a5705f, v81                      // 00000012DE8C: 58A2A348 B2A5705F
	v_sub_f32_e32 v80, v80, v82                                // 00000012DE94: 08A0A550
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012DE98: BF870121
	v_add_f32_e32 v80, v80, v81                                // 00000012DE9C: 06A0A350
	v_cvt_i32_f32_e32 v81, v82                                 // 00000012DEA0: 7EA21152
	v_exp_f32_e32 v80, v80                                     // 00000012DEA4: 7EA04B50
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DEA8: BF870095
	.long 0xd71c0050                                           // 00000012DEAC: D71C0050
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                     // 00000012DEB0: 0202A350
	v_cndmask_b32_e32 v80, 0, v80, vcc_lo                      // 00000012DEB4: 02A0A080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000012DEB8: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DEC0: BF870092
	v_cndmask_b32_e32 v72, 0x7f800000, v80, vcc_lo             // 00000012DEC4: 0290A0FF 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 00000012DECC: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DED0: BF870091
	v_div_scale_f32 v80, null, v72, v72, v73                   // 00000012DED4: D6FC7C50 05269148
	v_rcp_f32_e32 v81, v80                                     // 00000012DEDC: 7EA25550
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DEE0: BF870095
	v_fma_f32 v82, -v80, v81, 1.0                              // 00000012DEE4: D6130052 23CAA350
	v_fmac_f32_e32 v81, v82, v81                               // 00000012DEEC: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v73, v72, v73                 // 00000012DEF0: D6FC6A52 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DEF8: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 00000012DEFC: 10A6A352
	v_fma_f32 v84, -v80, v83, v82                              // 00000012DF00: D6130054 254AA750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DF08: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 00000012DF0C: 56A6A354
	v_fma_f32 v80, -v80, v83, v82                              // 00000012DF10: D6130050 254AA750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DF18: BF870091
	v_div_fmas_f32 v80, v80, v81, v83                          // 00000012DF1C: D6370050 054EA350
	v_div_fixup_f32 v80, v80, v72, v73                         // 00000012DF24: D6270050 05269150
	v_mad_i64_i32 v[72:73], null, 0x3000, v120, v[128:129]     // 00000012DF2C: D6FF7C48 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DF38: BF870092
	v_bfe_u32 v81, v80, 16, 1                                  // 00000012DF3C: D6100051 02052150
	v_add3_u32 v80, v80, v81, 0x7fff                           // 00000012DF44: D6550050 03FEA350 00007FFF
	global_store_d16_hi_b16 v[72:73], v80, off offset:192      // 00000012DF50: DC9600C0 007C5048
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012DF58: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012DF5C: BE882002
	s_cbranch_execz 62208                                      // 00000012DF60: BFA5F300 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3664>
	v_mad_i64_i32 v[72:73], null, 0x6000, v121, v[130:131]     // 00000012DF64: D6FF7C48 060AF2FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 00000012DF70: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000012DF78: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000012DF7C: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DF80: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000012DF84: 109290FF BFB8AA3B
	v_fma_f32 v80, 0xbfb8aa3b, v72, -v73                       // 00000012DF8C: D6130050 852690FF BFB8AA3B
	v_rndne_f32_e32 v81, v73                                   // 00000012DF98: 7EA24749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012DF9C: BF870221
	v_sub_f32_e32 v73, v73, v81                                // 00000012DFA0: 0892A349
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000012DFA4: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v80, v72, 0xb2a5705f, v80                      // 00000012DFAC: 58A0A148 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012DFB4: BF870121
	v_add_f32_e32 v73, v73, v80                                // 00000012DFB8: 0692A149
	v_cvt_i32_f32_e32 v80, v81                                 // 00000012DFBC: 7EA01151
	v_exp_f32_e32 v73, v73                                     // 00000012DFC0: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DFC4: BF870095
	.long 0xd71c0049                                           // 00000012DFC8: D71C0049
	v_cndmask_b32_e32 v1, v73, v80, vcc_lo                     // 00000012DFCC: 0202A149
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000012DFD0: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000012DFD4: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DFDC: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v136, v74// 00000012DFE0: CA4692FF 48489588 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 00000012DFEC: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012DFF0: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 00000012DFF4: D6FC7C4A 05269148
	v_rcp_f32_e32 v80, v74                                     // 00000012DFFC: 7EA0554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E000: BF870095
	v_fma_f32 v81, -v74, v80, 1.0                              // 00000012E004: D6130051 23CAA14A
	v_fmac_f32_e32 v80, v81, v80                               // 00000012E00C: 56A0A151
	v_div_scale_f32 v81, vcc_lo, v73, v72, v73                 // 00000012E010: D6FC6A51 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E018: BF870091
	v_mul_f32_e32 v82, v81, v80                                // 00000012E01C: 10A4A151
	v_fma_f32 v83, -v74, v82, v81                              // 00000012E020: D6130053 2546A54A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E028: BF870091
	v_fmac_f32_e32 v82, v83, v80                               // 00000012E02C: 56A4A153
	v_fma_f32 v74, -v74, v82, v81                              // 00000012E030: D613004A 2546A54A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E038: BF870091
	v_div_fmas_f32 v74, v74, v80, v82                          // 00000012E03C: D637004A 054AA14A
	v_div_fixup_f32 v74, v74, v72, v73                         // 00000012E044: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v121, v[128:129]     // 00000012E04C: D6FF7C48 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E058: BF870092
	v_bfe_u32 v80, v74, 16, 1                                  // 00000012E05C: D6100050 0205214A
	v_add3_u32 v74, v74, v80, 0x7fff                           // 00000012E064: D655004A 03FEA14A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 00000012E070: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012E078: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012E07C: BE882003
	s_cbranch_execz 62139                                      // 00000012E080: BFA5F2BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3670>
	v_mad_i64_i32 v[72:73], null, 0x6000, v122, v[130:131]     // 00000012E084: D6FF7C48 060AF4FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 00000012E090: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000012E098: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000012E09C: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E0A0: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000012E0A4: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 00000012E0AC: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v80, v73                                   // 00000012E0B8: 7EA04749
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E0BC: BF870091
	v_dual_fmamk_f32 v74, v72, 0xb2a5705f, v74 :: v_dual_sub_f32 v73, v73, v80// 00000012E0C0: C88A9548 4A48A149 B2A5705F
	v_add_f32_e32 v73, v73, v74                                // 00000012E0CC: 06929549
	v_cvt_i32_f32_e32 v74, v80                                 // 00000012E0D0: 7E941150
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000012E0D4: 7C3C90FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012E0DC: BF870293
	v_exp_f32_e32 v73, v73                                     // 00000012E0E0: 7E924B49
	.long 0xd71c0049                                           // 00000012E0E4: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000012E0E8: 02029549
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012E0EC: BF870121
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000012E0F0: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000012E0F4: 7C3690FF C2B17218
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v137, v75// 00000012E0FC: CA4692FF 48489789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E108: BF870091
	v_add_f32_e32 v72, 1.0, v72                                // 00000012E10C: 069090F2
	v_div_scale_f32 v74, null, v72, v72, v73                   // 00000012E110: D6FC7C4A 05269148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012E118: BF870291
	v_rcp_f32_e32 v75, v74                                     // 00000012E11C: 7E96554A
	v_fma_f32 v80, -v74, v75, 1.0                              // 00000012E120: D6130050 23CA974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012E128: BF8700A1
	v_fmac_f32_e32 v75, v80, v75                               // 00000012E12C: 56969750
	v_div_scale_f32 v80, vcc_lo, v73, v72, v73                 // 00000012E130: D6FC6A50 05269149
	v_mul_f32_e32 v81, v80, v75                                // 00000012E138: 10A29750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E13C: BF870091
	v_fma_f32 v82, -v74, v81, v80                              // 00000012E140: D6130052 2542A34A
	v_fmac_f32_e32 v81, v82, v75                               // 00000012E148: 56A29752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E14C: BF870091
	v_fma_f32 v74, -v74, v81, v80                              // 00000012E150: D613004A 2542A34A
	v_div_fmas_f32 v74, v74, v75, v81                          // 00000012E158: D637004A 0546974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012E160: BF870121
	v_div_fixup_f32 v74, v74, v72, v73                         // 00000012E164: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v122, v[128:129]     // 00000012E16C: D6FF7C48 0602F4FF 00003000
	v_bfe_u32 v75, v74, 16, 1                                  // 00000012E178: D610004B 0205214A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012E180: BF870001
	v_add3_u32 v74, v74, v75, 0x7fff                           // 00000012E184: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 00000012E190: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012E198: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012E19C: BE882004
	s_cbranch_execz 62070                                      // 00000012E1A0: BFA5F276 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x367c>
	v_mad_i64_i32 v[72:73], null, 0x6000, v123, v[130:131]     // 00000012E1A4: D6FF7C48 060AF6FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 00000012E1B0: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000012E1B8: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000012E1BC: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E1C0: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000012E1C4: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 00000012E1CC: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000012E1D8: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012E1DC: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 00000012E1E0: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000012E1E4: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 00000012E1EC: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012E1F4: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000012E1F8: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 00000012E1FC: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000012E200: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E204: BF870095
	.long 0xd71c0049                                           // 00000012E208: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000012E20C: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000012E210: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000012E214: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E21C: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v134, v76// 00000012E220: CA4692FF 48489986 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 00000012E22C: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E230: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 00000012E234: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 00000012E23C: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E240: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 00000012E244: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 00000012E24C: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 00000012E250: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E258: BF870091
	v_mul_f32_e32 v80, v76, v75                                // 00000012E25C: 10A0974C
	v_fma_f32 v81, -v74, v80, v76                              // 00000012E260: D6130051 2532A14A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E268: BF870091
	v_fmac_f32_e32 v80, v81, v75                               // 00000012E26C: 56A09751
	v_fma_f32 v74, -v74, v80, v76                              // 00000012E270: D613004A 2532A14A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E278: BF870091
	v_div_fmas_f32 v74, v74, v75, v80                          // 00000012E27C: D637004A 0542974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 00000012E284: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v123, v[128:129]     // 00000012E28C: D6FF7C48 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E298: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 00000012E29C: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 00000012E2A4: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 00000012E2B0: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012E2B8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012E2BC: BE882005
	s_cbranch_execz 62001                                      // 00000012E2C0: BFA5F231 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3688>
	v_mad_i64_i32 v[72:73], null, 0x6000, v124, v[130:131]     // 00000012E2C4: D6FF7C48 060AF8FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 00000012E2D0: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000012E2D8: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000012E2DC: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E2E0: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000012E2E4: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 00000012E2EC: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000012E2F8: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012E2FC: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 00000012E300: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000012E304: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 00000012E30C: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012E314: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000012E318: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 00000012E31C: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000012E320: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E324: BF870095
	.long 0xd71c0049                                           // 00000012E328: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000012E32C: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000012E330: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000012E334: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E33C: BF870092
	v_cndmask_b32_e32 v72, 0x7f800000, v73, vcc_lo             // 00000012E340: 029092FF 7F800000
	v_dual_mul_f32 v73, v135, v77 :: v_dual_add_f32 v72, 1.0, v72// 00000012E348: C8C89B87 494890F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E350: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 00000012E354: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 00000012E35C: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E360: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 00000012E364: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 00000012E36C: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 00000012E370: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E378: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 00000012E37C: 109A974C
	v_fma_f32 v80, -v74, v77, v76                              // 00000012E380: D6130050 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E388: BF870091
	v_fmac_f32_e32 v77, v80, v75                               // 00000012E38C: 569A9750
	v_fma_f32 v74, -v74, v77, v76                              // 00000012E390: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E398: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 00000012E39C: D637004A 0536974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 00000012E3A4: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v124, v[128:129]     // 00000012E3AC: D6FF7C48 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E3B8: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 00000012E3BC: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 00000012E3C4: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 00000012E3D0: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012E3D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012E3DC: BE882006
	s_cbranch_execz 61932                                      // 00000012E3E0: BFA5F1EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3694>
	v_mad_i64_i32 v[72:73], null, 0x6000, v125, v[130:131]     // 00000012E3E4: D6FF7C48 060AFAFF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 00000012E3F0: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000012E3F8: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000012E3FC: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E400: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000012E404: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 00000012E40C: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000012E418: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012E41C: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 00000012E420: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000012E424: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 00000012E42C: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012E434: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000012E438: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 00000012E43C: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000012E440: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E444: BF870095
	.long 0xd71c0049                                           // 00000012E448: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000012E44C: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000012E450: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000012E454: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E45C: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v132, v78// 00000012E460: CA4692FF 48489D84 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 00000012E46C: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E470: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 00000012E474: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 00000012E47C: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E480: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 00000012E484: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 00000012E48C: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 00000012E490: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E498: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 00000012E49C: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 00000012E4A0: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E4A8: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 00000012E4AC: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 00000012E4B0: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E4B8: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 00000012E4BC: D637004A 0536974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 00000012E4C4: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v125, v[128:129]     // 00000012E4CC: D6FF7C48 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E4D8: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 00000012E4DC: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 00000012E4E4: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 00000012E4F0: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012E4F8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012E4FC: BE882007
	s_cbranch_execz 61863                                      // 00000012E500: BFA5F1A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36a0>
	v_mad_i64_i32 v[72:73], null, 0x6000, v126, v[130:131]     // 00000012E504: D6FF7C48 060AFCFF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 00000012E510: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000012E518: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000012E51C: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E520: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000012E524: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 00000012E52C: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000012E538: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012E53C: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 00000012E540: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000012E544: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 00000012E54C: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012E554: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000012E558: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 00000012E55C: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000012E560: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E564: BF870095
	.long 0xd71c0049                                           // 00000012E568: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000012E56C: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000012E570: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000012E574: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E57C: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v133, v79// 00000012E580: CA4692FF 48489F85 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 00000012E58C: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E590: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 00000012E594: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 00000012E59C: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E5A0: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 00000012E5A4: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 00000012E5AC: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 00000012E5B0: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E5B8: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 00000012E5BC: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 00000012E5C0: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E5C8: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 00000012E5CC: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 00000012E5D0: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E5D8: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 00000012E5DC: D637004A 0536974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 00000012E5E4: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v126, v[128:129]     // 00000012E5EC: D6FF7C48 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E5F8: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 00000012E5FC: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 00000012E604: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 00000012E610: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012E618: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012E61C: BE882000
	s_cbranch_execz 61794                                      // 00000012E620: BFA5F162 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36ac>
	v_mad_i64_i32 v[72:73], null, 0x6000, v140, v[130:131]     // 00000012E624: D6FF7C48 060B18FF 00006000
	v_mul_f32_e32 v64, v138, v64                               // 00000012E630: 1080818A
	global_load_u16 v72, v[72:73], off offset:736              // 00000012E634: DC4A02E0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000012E63C: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 00000012E640: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E644: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000012E648: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 00000012E650: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000012E65C: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012E660: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 00000012E664: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000012E668: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 00000012E670: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012E678: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000012E67C: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 00000012E680: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 00000012E684: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E688: BF870095
	.long 0xd71c0049                                           // 00000012E68C: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 00000012E690: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000012E694: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000012E698: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E6A0: BF870092
	v_cndmask_b32_e32 v72, 0x7f800000, v73, vcc_lo             // 00000012E6A4: 029092FF 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 00000012E6AC: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E6B0: BF870091
	v_div_scale_f32 v73, null, v72, v72, v64                   // 00000012E6B4: D6FC7C49 05029148
	v_rcp_f32_e32 v74, v73                                     // 00000012E6BC: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E6C0: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 00000012E6C4: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 00000012E6CC: 5694954B
	v_div_scale_f32 v75, vcc_lo, v64, v72, v64                 // 00000012E6D0: D6FC6A4B 05029140
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E6D8: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 00000012E6DC: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 00000012E6E0: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E6E8: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 00000012E6EC: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 00000012E6F0: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E6F8: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 00000012E6FC: D6370049 05329549
	v_div_fixup_f32 v64, v73, v72, v64                         // 00000012E704: D6270040 05029149
	v_mad_i64_i32 v[72:73], null, 0x3000, v140, v[128:129]     // 00000012E70C: D6FF7C48 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E718: BF870092
	v_bfe_u32 v74, v64, 16, 1                                  // 00000012E71C: D610004A 02052140
	v_add3_u32 v64, v64, v74, 0x7fff                           // 00000012E724: D6550040 03FE9540 00007FFF
	global_store_d16_hi_b16 v[72:73], v64, off offset:224      // 00000012E730: DC9600E0 007C4048
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012E738: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012E73C: BE882001
	s_cbranch_execz 61725                                      // 00000012E740: BFA5F11D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36b8>
	v_mad_i64_i32 v[72:73], null, 0x6000, v120, v[130:131]     // 00000012E744: D6FF7C48 060AF0FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 00000012E750: 1082838B
	global_load_u16 v64, v[72:73], off offset:736              // 00000012E754: DC4A02E0 407C0048
	s_waitcnt vmcnt(0)                                         // 00000012E75C: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000012E760: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012E764: BF870121
	v_mul_f32_e32 v72, 0xbfb8aa3b, v64                         // 00000012E768: 109080FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000012E770: 7C3C80FF 42CE8ED0
	v_fma_f32 v73, 0xbfb8aa3b, v64, -v72                       // 00000012E778: D6130049 852280FF BFB8AA3B
	v_rndne_f32_e32 v74, v72                                   // 00000012E784: 7E944748
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012E788: BF870112
	v_fmamk_f32 v73, v64, 0xb2a5705f, v73                      // 00000012E78C: 58929340 B2A5705F
	v_sub_f32_e32 v72, v72, v74                                // 00000012E794: 08909548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012E798: BF870121
	v_add_f32_e32 v72, v72, v73                                // 00000012E79C: 06909348
	v_cvt_i32_f32_e32 v73, v74                                 // 00000012E7A0: 7E92114A
	v_exp_f32_e32 v72, v72                                     // 00000012E7A4: 7E904B48
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E7A8: BF870095
	.long 0xd71c0048                                           // 00000012E7AC: D71C0048
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                     // 00000012E7B0: 02029348
	v_cndmask_b32_e32 v72, 0, v72, vcc_lo                      // 00000012E7B4: 02909080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000012E7B8: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E7C0: BF870092
	v_cndmask_b32_e32 v64, 0x7f800000, v72, vcc_lo             // 00000012E7C4: 028090FF 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 00000012E7CC: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E7D0: BF870091
	v_div_scale_f32 v72, null, v64, v64, v65                   // 00000012E7D4: D6FC7C48 05068140
	v_rcp_f32_e32 v73, v72                                     // 00000012E7DC: 7E925548
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E7E0: BF870095
	v_fma_f32 v74, -v72, v73, 1.0                              // 00000012E7E4: D613004A 23CA9348
	v_fmac_f32_e32 v73, v74, v73                               // 00000012E7EC: 5692934A
	v_div_scale_f32 v74, vcc_lo, v65, v64, v65                 // 00000012E7F0: D6FC6A4A 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E7F8: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 00000012E7FC: 1096934A
	v_fma_f32 v76, -v72, v75, v74                              // 00000012E800: D613004C 252A9748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E808: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 00000012E80C: 5696934C
	v_fma_f32 v72, -v72, v75, v74                              // 00000012E810: D6130048 252A9748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E818: BF870091
	v_div_fmas_f32 v72, v72, v73, v75                          // 00000012E81C: D6370048 052E9348
	v_div_fixup_f32 v72, v72, v64, v65                         // 00000012E824: D6270048 05068148
	v_mad_i64_i32 v[64:65], null, 0x3000, v120, v[128:129]     // 00000012E82C: D6FF7C40 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E838: BF870092
	v_bfe_u32 v73, v72, 16, 1                                  // 00000012E83C: D6100049 02052148
	v_add3_u32 v72, v72, v73, 0x7fff                           // 00000012E844: D6550048 03FE9348 00007FFF
	global_store_d16_hi_b16 v[64:65], v72, off offset:224      // 00000012E850: DC9600E0 007C4840
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012E858: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012E85C: BE882002
	s_cbranch_execz 61656                                      // 00000012E860: BFA5F0D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36c4>
	v_mad_i64_i32 v[64:65], null, 0x6000, v121, v[130:131]     // 00000012E864: D6FF7C40 060AF2FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 00000012E870: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 00000012E878: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000012E87C: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E880: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000012E884: 108280FF BFB8AA3B
	v_fma_f32 v72, 0xbfb8aa3b, v64, -v65                       // 00000012E88C: D6130048 850680FF BFB8AA3B
	v_rndne_f32_e32 v73, v65                                   // 00000012E898: 7E924741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012E89C: BF870221
	v_sub_f32_e32 v65, v65, v73                                // 00000012E8A0: 08829341
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000012E8A4: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v72, v64, 0xb2a5705f, v72                      // 00000012E8AC: 58909140 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012E8B4: BF870121
	v_add_f32_e32 v65, v65, v72                                // 00000012E8B8: 06829141
	v_cvt_i32_f32_e32 v72, v73                                 // 00000012E8BC: 7E901149
	v_exp_f32_e32 v65, v65                                     // 00000012E8C0: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E8C4: BF870095
	.long 0xd71c0041                                           // 00000012E8C8: D71C0041
	v_cndmask_b32_e32 v1, v65, v72, vcc_lo                     // 00000012E8CC: 02029141
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000012E8D0: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000012E8D4: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E8DC: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v136, v66// 00000012E8E0: CA4682FF 40408588 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 00000012E8EC: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E8F0: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 00000012E8F4: D6FC7C42 05068140
	v_rcp_f32_e32 v72, v66                                     // 00000012E8FC: 7E905542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E900: BF870095
	v_fma_f32 v73, -v66, v72, 1.0                              // 00000012E904: D6130049 23CA9142
	v_fmac_f32_e32 v72, v73, v72                               // 00000012E90C: 56909149
	v_div_scale_f32 v73, vcc_lo, v65, v64, v65                 // 00000012E910: D6FC6A49 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E918: BF870091
	v_mul_f32_e32 v74, v73, v72                                // 00000012E91C: 10949149
	v_fma_f32 v75, -v66, v74, v73                              // 00000012E920: D613004B 25269542
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E928: BF870091
	v_fmac_f32_e32 v74, v75, v72                               // 00000012E92C: 5694914B
	v_fma_f32 v66, -v66, v74, v73                              // 00000012E930: D6130042 25269542
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E938: BF870091
	v_div_fmas_f32 v66, v66, v72, v74                          // 00000012E93C: D6370042 052A9142
	v_div_fixup_f32 v66, v66, v64, v65                         // 00000012E944: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v121, v[128:129]     // 00000012E94C: D6FF7C40 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E958: BF870092
	v_bfe_u32 v72, v66, 16, 1                                  // 00000012E95C: D6100048 02052142
	v_add3_u32 v66, v66, v72, 0x7fff                           // 00000012E964: D6550042 03FE9142 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 00000012E970: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012E978: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012E97C: BE882003
	s_cbranch_execz 61587                                      // 00000012E980: BFA5F093 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36d0>
	v_mad_i64_i32 v[64:65], null, 0x6000, v122, v[130:131]     // 00000012E984: D6FF7C40 060AF4FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 00000012E990: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 00000012E998: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000012E99C: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E9A0: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000012E9A4: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 00000012E9AC: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v72, v65                                   // 00000012E9B8: 7E904741
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012E9BC: BF870091
	v_dual_fmamk_f32 v66, v64, 0xb2a5705f, v66 :: v_dual_sub_f32 v65, v65, v72// 00000012E9C0: C88A8540 42409141 B2A5705F
	v_add_f32_e32 v65, v65, v66                                // 00000012E9CC: 06828541
	v_cvt_i32_f32_e32 v66, v72                                 // 00000012E9D0: 7E841148
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000012E9D4: 7C3C80FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012E9DC: BF870293
	v_exp_f32_e32 v65, v65                                     // 00000012E9E0: 7E824B41
	.long 0xd71c0041                                           // 00000012E9E4: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000012E9E8: 02028541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012E9EC: BF870121
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000012E9F0: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000012E9F4: 7C3680FF C2B17218
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v137, v67// 00000012E9FC: CA4682FF 40408789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EA08: BF870091
	v_add_f32_e32 v64, 1.0, v64                                // 00000012EA0C: 068080F2
	v_div_scale_f32 v66, null, v64, v64, v65                   // 00000012EA10: D6FC7C42 05068140
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012EA18: BF870291
	v_rcp_f32_e32 v67, v66                                     // 00000012EA1C: 7E865542
	v_fma_f32 v72, -v66, v67, 1.0                              // 00000012EA20: D6130048 23CA8742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012EA28: BF8700A1
	v_fmac_f32_e32 v67, v72, v67                               // 00000012EA2C: 56868748
	v_div_scale_f32 v72, vcc_lo, v65, v64, v65                 // 00000012EA30: D6FC6A48 05068141
	v_mul_f32_e32 v73, v72, v67                                // 00000012EA38: 10928748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EA3C: BF870091
	v_fma_f32 v74, -v66, v73, v72                              // 00000012EA40: D613004A 25229342
	v_fmac_f32_e32 v73, v74, v67                               // 00000012EA48: 5692874A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EA4C: BF870091
	v_fma_f32 v66, -v66, v73, v72                              // 00000012EA50: D6130042 25229342
	v_div_fmas_f32 v66, v66, v67, v73                          // 00000012EA58: D6370042 05268742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012EA60: BF870121
	v_div_fixup_f32 v66, v66, v64, v65                         // 00000012EA64: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v122, v[128:129]     // 00000012EA6C: D6FF7C40 0602F4FF 00003000
	v_bfe_u32 v67, v66, 16, 1                                  // 00000012EA78: D6100043 02052142
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012EA80: BF870001
	v_add3_u32 v66, v66, v67, 0x7fff                           // 00000012EA84: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 00000012EA90: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012EA98: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012EA9C: BE882004
	s_cbranch_execz 61518                                      // 00000012EAA0: BFA5F04E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36dc>
	v_mad_i64_i32 v[64:65], null, 0x6000, v123, v[130:131]     // 00000012EAA4: D6FF7C40 060AF6FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 00000012EAB0: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 00000012EAB8: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000012EABC: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EAC0: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000012EAC4: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 00000012EACC: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000012EAD8: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012EADC: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 00000012EAE0: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000012EAE4: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 00000012EAEC: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012EAF4: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000012EAF8: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000012EAFC: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000012EB00: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EB04: BF870095
	.long 0xd71c0041                                           // 00000012EB08: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000012EB0C: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000012EB10: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000012EB14: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EB1C: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v134, v68// 00000012EB20: CA4682FF 40408986 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 00000012EB2C: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EB30: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 00000012EB34: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 00000012EB3C: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EB40: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 00000012EB44: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 00000012EB4C: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 00000012EB50: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EB58: BF870091
	v_mul_f32_e32 v72, v68, v67                                // 00000012EB5C: 10908744
	v_fma_f32 v73, -v66, v72, v68                              // 00000012EB60: D6130049 25129142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EB68: BF870091
	v_fmac_f32_e32 v72, v73, v67                               // 00000012EB6C: 56908749
	v_fma_f32 v66, -v66, v72, v68                              // 00000012EB70: D6130042 25129142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EB78: BF870091
	v_div_fmas_f32 v66, v66, v67, v72                          // 00000012EB7C: D6370042 05228742
	v_div_fixup_f32 v66, v66, v64, v65                         // 00000012EB84: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v123, v[128:129]     // 00000012EB8C: D6FF7C40 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EB98: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 00000012EB9C: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 00000012EBA4: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 00000012EBB0: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012EBB8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012EBBC: BE882005
	s_cbranch_execz 61449                                      // 00000012EBC0: BFA5F009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36e8>
	v_mad_i64_i32 v[64:65], null, 0x6000, v124, v[130:131]     // 00000012EBC4: D6FF7C40 060AF8FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 00000012EBD0: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 00000012EBD8: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000012EBDC: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EBE0: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000012EBE4: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 00000012EBEC: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000012EBF8: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012EBFC: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 00000012EC00: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000012EC04: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 00000012EC0C: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012EC14: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000012EC18: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000012EC1C: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000012EC20: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EC24: BF870095
	.long 0xd71c0041                                           // 00000012EC28: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000012EC2C: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000012EC30: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000012EC34: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EC3C: BF870092
	v_cndmask_b32_e32 v64, 0x7f800000, v65, vcc_lo             // 00000012EC40: 028082FF 7F800000
	v_dual_mul_f32 v65, v135, v69 :: v_dual_add_f32 v64, 1.0, v64// 00000012EC48: C8C88B87 414080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EC50: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 00000012EC54: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 00000012EC5C: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EC60: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 00000012EC64: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 00000012EC6C: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 00000012EC70: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EC78: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 00000012EC7C: 108A8744
	v_fma_f32 v72, -v66, v69, v68                              // 00000012EC80: D6130048 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EC88: BF870091
	v_fmac_f32_e32 v69, v72, v67                               // 00000012EC8C: 568A8748
	v_fma_f32 v66, -v66, v69, v68                              // 00000012EC90: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EC98: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 00000012EC9C: D6370042 05168742
	v_div_fixup_f32 v66, v66, v64, v65                         // 00000012ECA4: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v124, v[128:129]     // 00000012ECAC: D6FF7C40 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012ECB8: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 00000012ECBC: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 00000012ECC4: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 00000012ECD0: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012ECD8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012ECDC: BE882006
	s_cbranch_execz 61380                                      // 00000012ECE0: BFA5EFC4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x36f4>
	v_mad_i64_i32 v[64:65], null, 0x6000, v125, v[130:131]     // 00000012ECE4: D6FF7C40 060AFAFF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 00000012ECF0: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 00000012ECF8: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000012ECFC: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012ED00: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000012ED04: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 00000012ED0C: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000012ED18: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012ED1C: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 00000012ED20: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000012ED24: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 00000012ED2C: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012ED34: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000012ED38: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000012ED3C: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000012ED40: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012ED44: BF870095
	.long 0xd71c0041                                           // 00000012ED48: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000012ED4C: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000012ED50: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000012ED54: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012ED5C: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v132, v70// 00000012ED60: CA4682FF 40408D84 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 00000012ED6C: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012ED70: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 00000012ED74: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 00000012ED7C: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012ED80: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 00000012ED84: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 00000012ED8C: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 00000012ED90: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012ED98: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 00000012ED9C: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 00000012EDA0: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EDA8: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 00000012EDAC: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 00000012EDB0: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EDB8: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 00000012EDBC: D6370042 05168742
	v_div_fixup_f32 v66, v66, v64, v65                         // 00000012EDC4: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v125, v[128:129]     // 00000012EDCC: D6FF7C40 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EDD8: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 00000012EDDC: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 00000012EDE4: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 00000012EDF0: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012EDF8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012EDFC: BE882007
	s_cbranch_execz 61311                                      // 00000012EE00: BFA5EF7F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3700>
	v_mad_i64_i32 v[64:65], null, 0x6000, v126, v[130:131]     // 00000012EE04: D6FF7C40 060AFCFF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 00000012EE10: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 00000012EE18: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000012EE1C: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EE20: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000012EE24: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 00000012EE2C: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000012EE38: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012EE3C: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 00000012EE40: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000012EE44: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 00000012EE4C: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012EE54: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000012EE58: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000012EE5C: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000012EE60: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EE64: BF870095
	.long 0xd71c0041                                           // 00000012EE68: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000012EE6C: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000012EE70: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000012EE74: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EE7C: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v133, v71// 00000012EE80: CA4682FF 40408F85 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 00000012EE8C: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EE90: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 00000012EE94: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 00000012EE9C: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EEA0: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 00000012EEA4: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 00000012EEAC: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 00000012EEB0: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EEB8: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 00000012EEBC: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 00000012EEC0: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EEC8: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 00000012EECC: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 00000012EED0: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EED8: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 00000012EEDC: D6370042 05168742
	v_div_fixup_f32 v66, v66, v64, v65                         // 00000012EEE4: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v126, v[128:129]     // 00000012EEEC: D6FF7C40 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EEF8: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 00000012EEFC: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 00000012EF04: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 00000012EF10: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012EF18: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012EF1C: BE882000
	s_cbranch_execz 61242                                      // 00000012EF20: BFA5EF3A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x370c>
	v_mad_i64_i32 v[64:65], null, 0x6000, v140, v[130:131]     // 00000012EF24: D6FF7C40 060B18FF 00006000
	v_mul_f32_e32 v56, v138, v56                               // 00000012EF30: 1070718A
	global_load_u16 v64, v[64:65], off offset:768              // 00000012EF34: DC4A0300 407C0040
	s_waitcnt vmcnt(0)                                         // 00000012EF3C: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000012EF40: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EF44: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000012EF48: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 00000012EF50: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000012EF5C: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012EF60: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 00000012EF64: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000012EF68: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 00000012EF70: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012EF78: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000012EF7C: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000012EF80: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000012EF84: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EF88: BF870095
	.long 0xd71c0041                                           // 00000012EF8C: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000012EF90: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000012EF94: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000012EF98: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EFA0: BF870092
	v_cndmask_b32_e32 v64, 0x7f800000, v65, vcc_lo             // 00000012EFA4: 028082FF 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 00000012EFAC: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EFB0: BF870091
	v_div_scale_f32 v65, null, v64, v64, v56                   // 00000012EFB4: D6FC7C41 04E28140
	v_rcp_f32_e32 v66, v65                                     // 00000012EFBC: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EFC0: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 00000012EFC4: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 00000012EFCC: 56848543
	v_div_scale_f32 v67, vcc_lo, v56, v64, v56                 // 00000012EFD0: D6FC6A43 04E28138
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EFD8: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 00000012EFDC: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 00000012EFE0: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EFE8: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 00000012EFEC: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 00000012EFF0: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012EFF8: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 00000012EFFC: D6370041 05128541
	v_div_fixup_f32 v56, v65, v64, v56                         // 00000012F004: D6270038 04E28141
	v_mad_i64_i32 v[64:65], null, 0x3000, v140, v[128:129]     // 00000012F00C: D6FF7C40 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F018: BF870092
	v_bfe_u32 v66, v56, 16, 1                                  // 00000012F01C: D6100042 02052138
	v_add3_u32 v56, v56, v66, 0x7fff                           // 00000012F024: D6550038 03FE8538 00007FFF
	global_store_d16_hi_b16 v[64:65], v56, off offset:256      // 00000012F030: DC960100 007C3840
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012F038: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012F03C: BE882001
	s_cbranch_execz 61173                                      // 00000012F040: BFA5EEF5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3718>
	v_mad_i64_i32 v[64:65], null, 0x6000, v120, v[130:131]     // 00000012F044: D6FF7C40 060AF0FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 00000012F050: 1072738B
	global_load_u16 v56, v[64:65], off offset:768              // 00000012F054: DC4A0300 387C0040
	s_waitcnt vmcnt(0)                                         // 00000012F05C: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000012F060: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012F064: BF870121
	v_mul_f32_e32 v64, 0xbfb8aa3b, v56                         // 00000012F068: 108070FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000012F070: 7C3C70FF 42CE8ED0
	v_fma_f32 v65, 0xbfb8aa3b, v56, -v64                       // 00000012F078: D6130041 850270FF BFB8AA3B
	v_rndne_f32_e32 v66, v64                                   // 00000012F084: 7E844740
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012F088: BF870112
	v_fmamk_f32 v65, v56, 0xb2a5705f, v65                      // 00000012F08C: 58828338 B2A5705F
	v_sub_f32_e32 v64, v64, v66                                // 00000012F094: 08808540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012F098: BF870121
	v_add_f32_e32 v64, v64, v65                                // 00000012F09C: 06808340
	v_cvt_i32_f32_e32 v65, v66                                 // 00000012F0A0: 7E821142
	v_exp_f32_e32 v64, v64                                     // 00000012F0A4: 7E804B40
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F0A8: BF870095
	.long 0xd71c0040                                           // 00000012F0AC: D71C0040
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                     // 00000012F0B0: 02028340
	v_cndmask_b32_e32 v64, 0, v64, vcc_lo                      // 00000012F0B4: 02808080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000012F0B8: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F0C0: BF870092
	v_cndmask_b32_e32 v56, 0x7f800000, v64, vcc_lo             // 00000012F0C4: 027080FF 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000012F0CC: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F0D0: BF870091
	v_div_scale_f32 v64, null, v56, v56, v57                   // 00000012F0D4: D6FC7C40 04E67138
	v_rcp_f32_e32 v65, v64                                     // 00000012F0DC: 7E825540
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F0E0: BF870095
	v_fma_f32 v66, -v64, v65, 1.0                              // 00000012F0E4: D6130042 23CA8340
	v_fmac_f32_e32 v65, v66, v65                               // 00000012F0EC: 56828342
	v_div_scale_f32 v66, vcc_lo, v57, v56, v57                 // 00000012F0F0: D6FC6A42 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F0F8: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 00000012F0FC: 10868342
	v_fma_f32 v68, -v64, v67, v66                              // 00000012F100: D6130044 250A8740
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F108: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 00000012F10C: 56868344
	v_fma_f32 v64, -v64, v67, v66                              // 00000012F110: D6130040 250A8740
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F118: BF870091
	v_div_fmas_f32 v64, v64, v65, v67                          // 00000012F11C: D6370040 050E8340
	v_div_fixup_f32 v64, v64, v56, v57                         // 00000012F124: D6270040 04E67140
	v_mad_i64_i32 v[56:57], null, 0x3000, v120, v[128:129]     // 00000012F12C: D6FF7C38 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F138: BF870092
	v_bfe_u32 v65, v64, 16, 1                                  // 00000012F13C: D6100041 02052140
	v_add3_u32 v64, v64, v65, 0x7fff                           // 00000012F144: D6550040 03FE8340 00007FFF
	global_store_d16_hi_b16 v[56:57], v64, off offset:256      // 00000012F150: DC960100 007C4038
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012F158: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012F15C: BE882002
	s_cbranch_execz 61104                                      // 00000012F160: BFA5EEB0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3724>
	v_mad_i64_i32 v[56:57], null, 0x6000, v121, v[130:131]     // 00000012F164: D6FF7C38 060AF2FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000012F170: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000012F178: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000012F17C: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F180: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000012F184: 107270FF BFB8AA3B
	v_fma_f32 v64, 0xbfb8aa3b, v56, -v57                       // 00000012F18C: D6130040 84E670FF BFB8AA3B
	v_rndne_f32_e32 v65, v57                                   // 00000012F198: 7E824739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012F19C: BF870221
	v_sub_f32_e32 v57, v57, v65                                // 00000012F1A0: 08728339
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000012F1A4: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v64, v56, 0xb2a5705f, v64                      // 00000012F1AC: 58808138 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012F1B4: BF870121
	v_add_f32_e32 v57, v57, v64                                // 00000012F1B8: 06728139
	v_cvt_i32_f32_e32 v64, v65                                 // 00000012F1BC: 7E801141
	v_exp_f32_e32 v57, v57                                     // 00000012F1C0: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F1C4: BF870095
	.long 0xd71c0039                                           // 00000012F1C8: D71C0039
	v_cndmask_b32_e32 v1, v57, v64, vcc_lo                     // 00000012F1CC: 02028139
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000012F1D0: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000012F1D4: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F1DC: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v136, v58// 00000012F1E0: CA4672FF 38387588 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000012F1EC: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F1F0: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000012F1F4: D6FC7C3A 04E67138
	v_rcp_f32_e32 v64, v58                                     // 00000012F1FC: 7E80553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F200: BF870095
	v_fma_f32 v65, -v58, v64, 1.0                              // 00000012F204: D6130041 23CA813A
	v_fmac_f32_e32 v64, v65, v64                               // 00000012F20C: 56808141
	v_div_scale_f32 v65, vcc_lo, v57, v56, v57                 // 00000012F210: D6FC6A41 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F218: BF870091
	v_mul_f32_e32 v66, v65, v64                                // 00000012F21C: 10848141
	v_fma_f32 v67, -v58, v66, v65                              // 00000012F220: D6130043 2506853A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F228: BF870091
	v_fmac_f32_e32 v66, v67, v64                               // 00000012F22C: 56848143
	v_fma_f32 v58, -v58, v66, v65                              // 00000012F230: D613003A 2506853A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F238: BF870091
	v_div_fmas_f32 v58, v58, v64, v66                          // 00000012F23C: D637003A 050A813A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000012F244: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v121, v[128:129]     // 00000012F24C: D6FF7C38 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F258: BF870092
	v_bfe_u32 v64, v58, 16, 1                                  // 00000012F25C: D6100040 0205213A
	v_add3_u32 v58, v58, v64, 0x7fff                           // 00000012F264: D655003A 03FE813A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000012F270: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012F278: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012F27C: BE882003
	s_cbranch_execz 61035                                      // 00000012F280: BFA5EE6B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3730>
	v_mad_i64_i32 v[56:57], null, 0x6000, v122, v[130:131]     // 00000012F284: D6FF7C38 060AF4FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000012F290: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000012F298: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000012F29C: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F2A0: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000012F2A4: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000012F2AC: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v64, v57                                   // 00000012F2B8: 7E804739
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F2BC: BF870091
	v_dual_fmamk_f32 v58, v56, 0xb2a5705f, v58 :: v_dual_sub_f32 v57, v57, v64// 00000012F2C0: C88A7538 3A388139 B2A5705F
	v_add_f32_e32 v57, v57, v58                                // 00000012F2CC: 06727539
	v_cvt_i32_f32_e32 v58, v64                                 // 00000012F2D0: 7E741140
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000012F2D4: 7C3C70FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012F2DC: BF870293
	v_exp_f32_e32 v57, v57                                     // 00000012F2E0: 7E724B39
	.long 0xd71c0039                                           // 00000012F2E4: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000012F2E8: 02027539
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012F2EC: BF870121
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000012F2F0: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000012F2F4: 7C3670FF C2B17218
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v137, v59// 00000012F2FC: CA4672FF 38387789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F308: BF870091
	v_add_f32_e32 v56, 1.0, v56                                // 00000012F30C: 067070F2
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000012F310: D6FC7C3A 04E67138
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012F318: BF870291
	v_rcp_f32_e32 v59, v58                                     // 00000012F31C: 7E76553A
	v_fma_f32 v64, -v58, v59, 1.0                              // 00000012F320: D6130040 23CA773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012F328: BF8700A1
	v_fmac_f32_e32 v59, v64, v59                               // 00000012F32C: 56767740
	v_div_scale_f32 v64, vcc_lo, v57, v56, v57                 // 00000012F330: D6FC6A40 04E67139
	v_mul_f32_e32 v65, v64, v59                                // 00000012F338: 10827740
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F33C: BF870091
	v_fma_f32 v66, -v58, v65, v64                              // 00000012F340: D6130042 2502833A
	v_fmac_f32_e32 v65, v66, v59                               // 00000012F348: 56827742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F34C: BF870091
	v_fma_f32 v58, -v58, v65, v64                              // 00000012F350: D613003A 2502833A
	v_div_fmas_f32 v58, v58, v59, v65                          // 00000012F358: D637003A 0506773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012F360: BF870121
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000012F364: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v122, v[128:129]     // 00000012F36C: D6FF7C38 0602F4FF 00003000
	v_bfe_u32 v59, v58, 16, 1                                  // 00000012F378: D610003B 0205213A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012F380: BF870001
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000012F384: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000012F390: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012F398: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012F39C: BE882004
	s_cbranch_execz 60966                                      // 00000012F3A0: BFA5EE26 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x373c>
	v_mad_i64_i32 v[56:57], null, 0x6000, v123, v[130:131]     // 00000012F3A4: D6FF7C38 060AF6FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000012F3B0: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000012F3B8: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000012F3BC: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F3C0: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000012F3C4: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000012F3CC: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000012F3D8: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012F3DC: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000012F3E0: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000012F3E4: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000012F3EC: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012F3F4: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000012F3F8: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000012F3FC: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000012F400: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F404: BF870095
	.long 0xd71c0039                                           // 00000012F408: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000012F40C: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000012F410: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000012F414: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F41C: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v134, v60// 00000012F420: CA4672FF 38387986 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000012F42C: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F430: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000012F434: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 00000012F43C: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F440: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000012F444: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000012F44C: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 00000012F450: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F458: BF870091
	v_mul_f32_e32 v64, v60, v59                                // 00000012F45C: 1080773C
	v_fma_f32 v65, -v58, v64, v60                              // 00000012F460: D6130041 24F2813A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F468: BF870091
	v_fmac_f32_e32 v64, v65, v59                               // 00000012F46C: 56807741
	v_fma_f32 v58, -v58, v64, v60                              // 00000012F470: D613003A 24F2813A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F478: BF870091
	v_div_fmas_f32 v58, v58, v59, v64                          // 00000012F47C: D637003A 0502773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000012F484: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v123, v[128:129]     // 00000012F48C: D6FF7C38 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F498: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 00000012F49C: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000012F4A4: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000012F4B0: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012F4B8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012F4BC: BE882005
	s_cbranch_execz 60897                                      // 00000012F4C0: BFA5EDE1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3748>
	v_mad_i64_i32 v[56:57], null, 0x6000, v124, v[130:131]     // 00000012F4C4: D6FF7C38 060AF8FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000012F4D0: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000012F4D8: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000012F4DC: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F4E0: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000012F4E4: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000012F4EC: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000012F4F8: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012F4FC: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000012F500: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000012F504: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000012F50C: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012F514: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000012F518: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000012F51C: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000012F520: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F524: BF870095
	.long 0xd71c0039                                           // 00000012F528: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000012F52C: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000012F530: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000012F534: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F53C: BF870092
	v_cndmask_b32_e32 v56, 0x7f800000, v57, vcc_lo             // 00000012F540: 027072FF 7F800000
	v_dual_mul_f32 v57, v135, v61 :: v_dual_add_f32 v56, 1.0, v56// 00000012F548: C8C87B87 393870F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F550: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000012F554: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 00000012F55C: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F560: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000012F564: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000012F56C: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 00000012F570: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F578: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 00000012F57C: 107A773C
	v_fma_f32 v64, -v58, v61, v60                              // 00000012F580: D6130040 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F588: BF870091
	v_fmac_f32_e32 v61, v64, v59                               // 00000012F58C: 567A7740
	v_fma_f32 v58, -v58, v61, v60                              // 00000012F590: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F598: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 00000012F59C: D637003A 04F6773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000012F5A4: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v124, v[128:129]     // 00000012F5AC: D6FF7C38 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F5B8: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 00000012F5BC: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000012F5C4: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000012F5D0: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012F5D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012F5DC: BE882006
	s_cbranch_execz 60828                                      // 00000012F5E0: BFA5ED9C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3754>
	v_mad_i64_i32 v[56:57], null, 0x6000, v125, v[130:131]     // 00000012F5E4: D6FF7C38 060AFAFF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000012F5F0: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000012F5F8: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000012F5FC: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F600: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000012F604: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000012F60C: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000012F618: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012F61C: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000012F620: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000012F624: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000012F62C: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012F634: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000012F638: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000012F63C: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000012F640: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F644: BF870095
	.long 0xd71c0039                                           // 00000012F648: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000012F64C: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000012F650: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000012F654: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F65C: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v132, v62// 00000012F660: CA4672FF 38387D84 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000012F66C: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F670: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000012F674: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 00000012F67C: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F680: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000012F684: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000012F68C: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 00000012F690: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F698: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 00000012F69C: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 00000012F6A0: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F6A8: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 00000012F6AC: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 00000012F6B0: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F6B8: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 00000012F6BC: D637003A 04F6773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000012F6C4: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v125, v[128:129]     // 00000012F6CC: D6FF7C38 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F6D8: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 00000012F6DC: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000012F6E4: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000012F6F0: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012F6F8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012F6FC: BE882007
	s_cbranch_execz 60759                                      // 00000012F700: BFA5ED57 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3760>
	v_mad_i64_i32 v[56:57], null, 0x6000, v126, v[130:131]     // 00000012F704: D6FF7C38 060AFCFF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000012F710: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000012F718: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000012F71C: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F720: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000012F724: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000012F72C: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000012F738: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012F73C: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000012F740: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000012F744: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000012F74C: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012F754: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000012F758: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000012F75C: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000012F760: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F764: BF870095
	.long 0xd71c0039                                           // 00000012F768: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000012F76C: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000012F770: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000012F774: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F77C: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v133, v63// 00000012F780: CA4672FF 38387F85 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000012F78C: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F790: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000012F794: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 00000012F79C: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F7A0: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000012F7A4: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000012F7AC: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 00000012F7B0: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F7B8: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 00000012F7BC: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 00000012F7C0: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F7C8: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 00000012F7CC: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 00000012F7D0: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F7D8: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 00000012F7DC: D637003A 04F6773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000012F7E4: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v126, v[128:129]     // 00000012F7EC: D6FF7C38 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F7F8: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 00000012F7FC: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000012F804: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000012F810: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012F818: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000012F81C: BE882000
	s_cbranch_execz 60690                                      // 00000012F820: BFA5ED12 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x376c>
	v_mad_i64_i32 v[56:57], null, 0x6000, v140, v[130:131]     // 00000012F824: D6FF7C38 060B18FF 00006000
	v_mul_f32_e32 v48, v138, v48                               // 00000012F830: 1060618A
	global_load_u16 v56, v[56:57], off offset:800              // 00000012F834: DC4A0320 387C0038
	s_waitcnt vmcnt(0)                                         // 00000012F83C: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000012F840: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F844: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000012F848: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000012F850: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000012F85C: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012F860: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000012F864: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000012F868: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000012F870: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012F878: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000012F87C: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000012F880: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000012F884: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F888: BF870095
	.long 0xd71c0039                                           // 00000012F88C: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000012F890: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000012F894: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000012F898: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F8A0: BF870092
	v_cndmask_b32_e32 v56, 0x7f800000, v57, vcc_lo             // 00000012F8A4: 027072FF 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000012F8AC: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F8B0: BF870091
	v_div_scale_f32 v57, null, v56, v56, v48                   // 00000012F8B4: D6FC7C39 04C27138
	v_rcp_f32_e32 v58, v57                                     // 00000012F8BC: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F8C0: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 00000012F8C4: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 00000012F8CC: 5674753B
	v_div_scale_f32 v59, vcc_lo, v48, v56, v48                 // 00000012F8D0: D6FC6A3B 04C27130
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F8D8: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 00000012F8DC: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 00000012F8E0: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F8E8: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 00000012F8EC: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 00000012F8F0: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F8F8: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 00000012F8FC: D6370039 04F27539
	v_div_fixup_f32 v48, v57, v56, v48                         // 00000012F904: D6270030 04C27139
	v_mad_i64_i32 v[56:57], null, 0x3000, v140, v[128:129]     // 00000012F90C: D6FF7C38 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F918: BF870092
	v_bfe_u32 v58, v48, 16, 1                                  // 00000012F91C: D610003A 02052130
	v_add3_u32 v48, v48, v58, 0x7fff                           // 00000012F924: D6550030 03FE7530 00007FFF
	global_store_d16_hi_b16 v[56:57], v48, off offset:288      // 00000012F930: DC960120 007C3038
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012F938: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000012F93C: BE882001
	s_cbranch_execz 60621                                      // 00000012F940: BFA5ECCD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3778>
	v_mad_i64_i32 v[56:57], null, 0x6000, v120, v[130:131]     // 00000012F944: D6FF7C38 060AF0FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 00000012F950: 1062638B
	global_load_u16 v48, v[56:57], off offset:800              // 00000012F954: DC4A0320 307C0038
	s_waitcnt vmcnt(0)                                         // 00000012F95C: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000012F960: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012F964: BF870121
	v_mul_f32_e32 v56, 0xbfb8aa3b, v48                         // 00000012F968: 107060FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000012F970: 7C3C60FF 42CE8ED0
	v_fma_f32 v57, 0xbfb8aa3b, v48, -v56                       // 00000012F978: D6130039 84E260FF BFB8AA3B
	v_rndne_f32_e32 v58, v56                                   // 00000012F984: 7E744738
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000012F988: BF870112
	v_fmamk_f32 v57, v48, 0xb2a5705f, v57                      // 00000012F98C: 58727330 B2A5705F
	v_sub_f32_e32 v56, v56, v58                                // 00000012F994: 08707538
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012F998: BF870121
	v_add_f32_e32 v56, v56, v57                                // 00000012F99C: 06707338
	v_cvt_i32_f32_e32 v57, v58                                 // 00000012F9A0: 7E72113A
	v_exp_f32_e32 v56, v56                                     // 00000012F9A4: 7E704B38
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F9A8: BF870095
	.long 0xd71c0038                                           // 00000012F9AC: D71C0038
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                     // 00000012F9B0: 02027338
	v_cndmask_b32_e32 v56, 0, v56, vcc_lo                      // 00000012F9B4: 02707080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000012F9B8: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F9C0: BF870092
	v_cndmask_b32_e32 v48, 0x7f800000, v56, vcc_lo             // 00000012F9C4: 026070FF 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000012F9CC: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F9D0: BF870091
	v_div_scale_f32 v56, null, v48, v48, v49                   // 00000012F9D4: D6FC7C38 04C66130
	v_rcp_f32_e32 v57, v56                                     // 00000012F9DC: 7E725538
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F9E0: BF870095
	v_fma_f32 v58, -v56, v57, 1.0                              // 00000012F9E4: D613003A 23CA7338
	v_fmac_f32_e32 v57, v58, v57                               // 00000012F9EC: 5672733A
	v_div_scale_f32 v58, vcc_lo, v49, v48, v49                 // 00000012F9F0: D6FC6A3A 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012F9F8: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 00000012F9FC: 1076733A
	v_fma_f32 v60, -v56, v59, v58                              // 00000012FA00: D613003C 24EA7738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FA08: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 00000012FA0C: 5676733C
	v_fma_f32 v56, -v56, v59, v58                              // 00000012FA10: D6130038 24EA7738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FA18: BF870091
	v_div_fmas_f32 v56, v56, v57, v59                          // 00000012FA1C: D6370038 04EE7338
	v_div_fixup_f32 v56, v56, v48, v49                         // 00000012FA24: D6270038 04C66138
	v_mad_i64_i32 v[48:49], null, 0x3000, v120, v[128:129]     // 00000012FA2C: D6FF7C30 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FA38: BF870092
	v_bfe_u32 v57, v56, 16, 1                                  // 00000012FA3C: D6100039 02052138
	v_add3_u32 v56, v56, v57, 0x7fff                           // 00000012FA44: D6550038 03FE7338 00007FFF
	global_store_d16_hi_b16 v[48:49], v56, off offset:288      // 00000012FA50: DC960120 007C3830
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012FA58: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000012FA5C: BE882002
	s_cbranch_execz 60552                                      // 00000012FA60: BFA5EC88 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3784>
	v_mad_i64_i32 v[48:49], null, 0x6000, v121, v[130:131]     // 00000012FA64: D6FF7C30 060AF2FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000012FA70: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000012FA78: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000012FA7C: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FA80: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000012FA84: 106260FF BFB8AA3B
	v_fma_f32 v56, 0xbfb8aa3b, v48, -v49                       // 00000012FA8C: D6130038 84C660FF BFB8AA3B
	v_rndne_f32_e32 v57, v49                                   // 00000012FA98: 7E724731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012FA9C: BF870221
	v_sub_f32_e32 v49, v49, v57                                // 00000012FAA0: 08627331
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000012FAA4: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v56, v48, 0xb2a5705f, v56                      // 00000012FAAC: 58707130 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012FAB4: BF870121
	v_add_f32_e32 v49, v49, v56                                // 00000012FAB8: 06627131
	v_cvt_i32_f32_e32 v56, v57                                 // 00000012FABC: 7E701139
	v_exp_f32_e32 v49, v49                                     // 00000012FAC0: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FAC4: BF870095
	.long 0xd71c0031                                           // 00000012FAC8: D71C0031
	v_cndmask_b32_e32 v1, v49, v56, vcc_lo                     // 00000012FACC: 02027131
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000012FAD0: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000012FAD4: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FADC: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v136, v50// 00000012FAE0: CA4662FF 30306588 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000012FAEC: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FAF0: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000012FAF4: D6FC7C32 04C66130
	v_rcp_f32_e32 v56, v50                                     // 00000012FAFC: 7E705532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FB00: BF870095
	v_fma_f32 v57, -v50, v56, 1.0                              // 00000012FB04: D6130039 23CA7132
	v_fmac_f32_e32 v56, v57, v56                               // 00000012FB0C: 56707139
	v_div_scale_f32 v57, vcc_lo, v49, v48, v49                 // 00000012FB10: D6FC6A39 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FB18: BF870091
	v_mul_f32_e32 v58, v57, v56                                // 00000012FB1C: 10747139
	v_fma_f32 v59, -v50, v58, v57                              // 00000012FB20: D613003B 24E67532
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FB28: BF870091
	v_fmac_f32_e32 v58, v59, v56                               // 00000012FB2C: 5674713B
	v_fma_f32 v50, -v50, v58, v57                              // 00000012FB30: D6130032 24E67532
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FB38: BF870091
	v_div_fmas_f32 v50, v50, v56, v58                          // 00000012FB3C: D6370032 04EA7132
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000012FB44: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v121, v[128:129]     // 00000012FB4C: D6FF7C30 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FB58: BF870092
	v_bfe_u32 v56, v50, 16, 1                                  // 00000012FB5C: D6100038 02052132
	v_add3_u32 v50, v50, v56, 0x7fff                           // 00000012FB64: D6550032 03FE7132 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000012FB70: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012FB78: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000012FB7C: BE882003
	s_cbranch_execz 60483                                      // 00000012FB80: BFA5EC43 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3790>
	v_mad_i64_i32 v[48:49], null, 0x6000, v122, v[130:131]     // 00000012FB84: D6FF7C30 060AF4FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000012FB90: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000012FB98: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000012FB9C: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FBA0: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000012FBA4: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000012FBAC: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v56, v49                                   // 00000012FBB8: 7E704731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FBBC: BF870091
	v_dual_fmamk_f32 v50, v48, 0xb2a5705f, v50 :: v_dual_sub_f32 v49, v49, v56// 00000012FBC0: C88A6530 32307131 B2A5705F
	v_add_f32_e32 v49, v49, v50                                // 00000012FBCC: 06626531
	v_cvt_i32_f32_e32 v50, v56                                 // 00000012FBD0: 7E641138
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000012FBD4: 7C3C60FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012FBDC: BF870293
	v_exp_f32_e32 v49, v49                                     // 00000012FBE0: 7E624B31
	.long 0xd71c0031                                           // 00000012FBE4: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000012FBE8: 02026531
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012FBEC: BF870121
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000012FBF0: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000012FBF4: 7C3660FF C2B17218
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v137, v51// 00000012FBFC: CA4662FF 30306789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FC08: BF870091
	v_add_f32_e32 v48, 1.0, v48                                // 00000012FC0C: 066060F2
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000012FC10: D6FC7C32 04C66130
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000012FC18: BF870291
	v_rcp_f32_e32 v51, v50                                     // 00000012FC1C: 7E665532
	v_fma_f32 v56, -v50, v51, 1.0                              // 00000012FC20: D6130038 23CA6732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000012FC28: BF8700A1
	v_fmac_f32_e32 v51, v56, v51                               // 00000012FC2C: 56666738
	v_div_scale_f32 v56, vcc_lo, v49, v48, v49                 // 00000012FC30: D6FC6A38 04C66131
	v_mul_f32_e32 v57, v56, v51                                // 00000012FC38: 10726738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FC3C: BF870091
	v_fma_f32 v58, -v50, v57, v56                              // 00000012FC40: D613003A 24E27332
	v_fmac_f32_e32 v57, v58, v51                               // 00000012FC48: 5672673A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FC4C: BF870091
	v_fma_f32 v50, -v50, v57, v56                              // 00000012FC50: D6130032 24E27332
	v_div_fmas_f32 v50, v50, v51, v57                          // 00000012FC58: D6370032 04E66732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012FC60: BF870121
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000012FC64: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v122, v[128:129]     // 00000012FC6C: D6FF7C30 0602F4FF 00003000
	v_bfe_u32 v51, v50, 16, 1                                  // 00000012FC78: D6100033 02052132
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012FC80: BF870001
	v_add3_u32 v50, v50, v51, 0x7fff                           // 00000012FC84: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000012FC90: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012FC98: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000012FC9C: BE882004
	s_cbranch_execz 60414                                      // 00000012FCA0: BFA5EBFE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x379c>
	v_mad_i64_i32 v[48:49], null, 0x6000, v123, v[130:131]     // 00000012FCA4: D6FF7C30 060AF6FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000012FCB0: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000012FCB8: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000012FCBC: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FCC0: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000012FCC4: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000012FCCC: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000012FCD8: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012FCDC: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 00000012FCE0: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000012FCE4: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 00000012FCEC: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012FCF4: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000012FCF8: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000012FCFC: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000012FD00: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FD04: BF870095
	.long 0xd71c0031                                           // 00000012FD08: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000012FD0C: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000012FD10: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000012FD14: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FD1C: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v134, v52// 00000012FD20: CA4662FF 30306986 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000012FD2C: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FD30: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000012FD34: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 00000012FD3C: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FD40: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000012FD44: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000012FD4C: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 00000012FD50: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FD58: BF870091
	v_mul_f32_e32 v56, v52, v51                                // 00000012FD5C: 10706734
	v_fma_f32 v57, -v50, v56, v52                              // 00000012FD60: D6130039 24D27132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FD68: BF870091
	v_fmac_f32_e32 v56, v57, v51                               // 00000012FD6C: 56706739
	v_fma_f32 v50, -v50, v56, v52                              // 00000012FD70: D6130032 24D27132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FD78: BF870091
	v_div_fmas_f32 v50, v50, v51, v56                          // 00000012FD7C: D6370032 04E26732
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000012FD84: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v123, v[128:129]     // 00000012FD8C: D6FF7C30 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FD98: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 00000012FD9C: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 00000012FDA4: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000012FDB0: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012FDB8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000012FDBC: BE882005
	s_cbranch_execz 60345                                      // 00000012FDC0: BFA5EBB9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37a8>
	v_mad_i64_i32 v[48:49], null, 0x6000, v124, v[130:131]     // 00000012FDC4: D6FF7C30 060AF8FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000012FDD0: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000012FDD8: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000012FDDC: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FDE0: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000012FDE4: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000012FDEC: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000012FDF8: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012FDFC: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 00000012FE00: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000012FE04: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 00000012FE0C: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012FE14: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000012FE18: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000012FE1C: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000012FE20: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FE24: BF870095
	.long 0xd71c0031                                           // 00000012FE28: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000012FE2C: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000012FE30: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000012FE34: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FE3C: BF870092
	v_cndmask_b32_e32 v48, 0x7f800000, v49, vcc_lo             // 00000012FE40: 026062FF 7F800000
	v_dual_mul_f32 v49, v135, v53 :: v_dual_add_f32 v48, 1.0, v48// 00000012FE48: C8C86B87 313060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FE50: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000012FE54: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 00000012FE5C: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FE60: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000012FE64: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000012FE6C: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 00000012FE70: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FE78: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 00000012FE7C: 106A6734
	v_fma_f32 v56, -v50, v53, v52                              // 00000012FE80: D6130038 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FE88: BF870091
	v_fmac_f32_e32 v53, v56, v51                               // 00000012FE8C: 566A6738
	v_fma_f32 v50, -v50, v53, v52                              // 00000012FE90: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FE98: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 00000012FE9C: D6370032 04D66732
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000012FEA4: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v124, v[128:129]     // 00000012FEAC: D6FF7C30 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FEB8: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 00000012FEBC: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 00000012FEC4: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000012FED0: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012FED8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000012FEDC: BE882006
	s_cbranch_execz 60276                                      // 00000012FEE0: BFA5EB74 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37b4>
	v_mad_i64_i32 v[48:49], null, 0x6000, v125, v[130:131]     // 00000012FEE4: D6FF7C30 060AFAFF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000012FEF0: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000012FEF8: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000012FEFC: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FF00: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000012FF04: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000012FF0C: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000012FF18: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000012FF1C: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 00000012FF20: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000012FF24: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 00000012FF2C: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000012FF34: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000012FF38: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000012FF3C: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000012FF40: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FF44: BF870095
	.long 0xd71c0031                                           // 00000012FF48: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000012FF4C: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000012FF50: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000012FF54: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FF5C: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v132, v54// 00000012FF60: CA4662FF 30306D84 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000012FF6C: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FF70: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000012FF74: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 00000012FF7C: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FF80: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000012FF84: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000012FF8C: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 00000012FF90: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FF98: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 00000012FF9C: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 00000012FFA0: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FFA8: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 00000012FFAC: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 00000012FFB0: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FFB8: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 00000012FFBC: D6370032 04D66732
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000012FFC4: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v125, v[128:129]     // 00000012FFCC: D6FF7C30 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000012FFD8: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 00000012FFDC: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 00000012FFE4: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000012FFF0: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000012FFF8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000012FFFC: BE882007
	s_cbranch_execz 60207                                      // 000000130000: BFA5EB2F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37c0>
	v_mad_i64_i32 v[48:49], null, 0x6000, v126, v[130:131]     // 000000130004: D6FF7C30 060AFCFF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 000000130010: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 000000130018: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000013001C: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130020: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 000000130024: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000013002C: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 000000130038: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013003C: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 000000130040: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 000000130044: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 00000013004C: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130054: BF870121
	v_add_f32_e32 v49, v49, v50                                // 000000130058: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000013005C: 7E641133
	v_exp_f32_e32 v49, v49                                     // 000000130060: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130064: BF870095
	.long 0xd71c0031                                           // 000000130068: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000013006C: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 000000130070: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 000000130074: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013007C: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v133, v55// 000000130080: CA4662FF 30306F85 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000013008C: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130090: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 000000130094: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 00000013009C: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001300A0: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 0000001300A4: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 0000001300AC: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 0000001300B0: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001300B8: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 0000001300BC: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 0000001300C0: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001300C8: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 0000001300CC: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 0000001300D0: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001300D8: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 0000001300DC: D6370032 04D66732
	v_div_fixup_f32 v50, v50, v48, v49                         // 0000001300E4: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v126, v[128:129]     // 0000001300EC: D6FF7C30 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001300F8: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 0000001300FC: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 000000130104: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 000000130110: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 000000130118: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000013011C: BE882000
	s_cbranch_execz 60138                                      // 000000130120: BFA5EAEA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37cc>
	v_mad_i64_i32 v[48:49], null, 0x6000, v140, v[130:131]     // 000000130124: D6FF7C30 060B18FF 00006000
	v_mul_f32_e32 v40, v138, v40                               // 000000130130: 1050518A
	global_load_u16 v48, v[48:49], off offset:832              // 000000130134: DC4A0340 307C0030
	s_waitcnt vmcnt(0)                                         // 00000013013C: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 000000130140: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130144: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 000000130148: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 000000130150: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000013015C: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000130160: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 000000130164: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 000000130168: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 000000130170: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130178: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000013017C: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 000000130180: 7E641133
	v_exp_f32_e32 v49, v49                                     // 000000130184: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130188: BF870095
	.long 0xd71c0031                                           // 00000013018C: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 000000130190: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 000000130194: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 000000130198: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001301A0: BF870092
	v_cndmask_b32_e32 v48, 0x7f800000, v49, vcc_lo             // 0000001301A4: 026062FF 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 0000001301AC: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001301B0: BF870091
	v_div_scale_f32 v49, null, v48, v48, v40                   // 0000001301B4: D6FC7C31 04A26130
	v_rcp_f32_e32 v50, v49                                     // 0000001301BC: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001301C0: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 0000001301C4: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 0000001301CC: 56646533
	v_div_scale_f32 v51, vcc_lo, v40, v48, v40                 // 0000001301D0: D6FC6A33 04A26128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001301D8: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 0000001301DC: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 0000001301E0: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001301E8: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 0000001301EC: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 0000001301F0: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001301F8: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 0000001301FC: D6370031 04D26531
	v_div_fixup_f32 v40, v49, v48, v40                         // 000000130204: D6270028 04A26131
	v_mad_i64_i32 v[48:49], null, 0x3000, v140, v[128:129]     // 00000013020C: D6FF7C30 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130218: BF870092
	v_bfe_u32 v50, v40, 16, 1                                  // 00000013021C: D6100032 02052128
	v_add3_u32 v40, v40, v50, 0x7fff                           // 000000130224: D6550028 03FE6528 00007FFF
	global_store_d16_hi_b16 v[48:49], v40, off offset:320      // 000000130230: DC960140 007C2830
	s_or_b32 exec_lo, exec_lo, s8                              // 000000130238: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000013023C: BE882001
	s_cbranch_execz 60069                                      // 000000130240: BFA5EAA5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37d8>
	v_mad_i64_i32 v[48:49], null, 0x6000, v120, v[130:131]     // 000000130244: D6FF7C30 060AF0FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 000000130250: 1052538B
	global_load_u16 v40, v[48:49], off offset:832              // 000000130254: DC4A0340 287C0030
	s_waitcnt vmcnt(0)                                         // 00000013025C: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 000000130260: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130264: BF870121
	v_mul_f32_e32 v48, 0xbfb8aa3b, v40                         // 000000130268: 106050FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 000000130270: 7C3C50FF 42CE8ED0
	v_fma_f32 v49, 0xbfb8aa3b, v40, -v48                       // 000000130278: D6130031 84C250FF BFB8AA3B
	v_rndne_f32_e32 v50, v48                                   // 000000130284: 7E644730
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000130288: BF870112
	v_fmamk_f32 v49, v40, 0xb2a5705f, v49                      // 00000013028C: 58626328 B2A5705F
	v_sub_f32_e32 v48, v48, v50                                // 000000130294: 08606530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130298: BF870121
	v_add_f32_e32 v48, v48, v49                                // 00000013029C: 06606330
	v_cvt_i32_f32_e32 v49, v50                                 // 0000001302A0: 7E621132
	v_exp_f32_e32 v48, v48                                     // 0000001302A4: 7E604B30
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001302A8: BF870095
	.long 0xd71c0030                                           // 0000001302AC: D71C0030
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                     // 0000001302B0: 02026330
	v_cndmask_b32_e32 v48, 0, v48, vcc_lo                      // 0000001302B4: 02606080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 0000001302B8: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001302C0: BF870092
	v_cndmask_b32_e32 v40, 0x7f800000, v48, vcc_lo             // 0000001302C4: 025060FF 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 0000001302CC: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001302D0: BF870091
	v_div_scale_f32 v48, null, v40, v40, v41                   // 0000001302D4: D6FC7C30 04A65128
	v_rcp_f32_e32 v49, v48                                     // 0000001302DC: 7E625530
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001302E0: BF870095
	v_fma_f32 v50, -v48, v49, 1.0                              // 0000001302E4: D6130032 23CA6330
	v_fmac_f32_e32 v49, v50, v49                               // 0000001302EC: 56626332
	v_div_scale_f32 v50, vcc_lo, v41, v40, v41                 // 0000001302F0: D6FC6A32 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001302F8: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 0000001302FC: 10666332
	v_fma_f32 v52, -v48, v51, v50                              // 000000130300: D6130034 24CA6730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130308: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 00000013030C: 56666334
	v_fma_f32 v48, -v48, v51, v50                              // 000000130310: D6130030 24CA6730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130318: BF870091
	v_div_fmas_f32 v48, v48, v49, v51                          // 00000013031C: D6370030 04CE6330
	v_div_fixup_f32 v48, v48, v40, v41                         // 000000130324: D6270030 04A65130
	v_mad_i64_i32 v[40:41], null, 0x3000, v120, v[128:129]     // 00000013032C: D6FF7C28 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130338: BF870092
	v_bfe_u32 v49, v48, 16, 1                                  // 00000013033C: D6100031 02052130
	v_add3_u32 v48, v48, v49, 0x7fff                           // 000000130344: D6550030 03FE6330 00007FFF
	global_store_d16_hi_b16 v[40:41], v48, off offset:320      // 000000130350: DC960140 007C3028
	s_or_b32 exec_lo, exec_lo, s8                              // 000000130358: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000013035C: BE882002
	s_cbranch_execz 60000                                      // 000000130360: BFA5EA60 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37e4>
	v_mad_i64_i32 v[40:41], null, 0x6000, v121, v[130:131]     // 000000130364: D6FF7C28 060AF2FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 000000130370: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 000000130378: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000013037C: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130380: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 000000130384: 105250FF BFB8AA3B
	v_fma_f32 v48, 0xbfb8aa3b, v40, -v41                       // 00000013038C: D6130030 84A650FF BFB8AA3B
	v_rndne_f32_e32 v49, v41                                   // 000000130398: 7E624729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013039C: BF870221
	v_sub_f32_e32 v41, v41, v49                                // 0000001303A0: 08526329
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 0000001303A4: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v48, v40, 0xb2a5705f, v48                      // 0000001303AC: 58606128 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001303B4: BF870121
	v_add_f32_e32 v41, v41, v48                                // 0000001303B8: 06526129
	v_cvt_i32_f32_e32 v48, v49                                 // 0000001303BC: 7E601131
	v_exp_f32_e32 v41, v41                                     // 0000001303C0: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001303C4: BF870095
	.long 0xd71c0029                                           // 0000001303C8: D71C0029
	v_cndmask_b32_e32 v1, v41, v48, vcc_lo                     // 0000001303CC: 02026129
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000001303D0: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 0000001303D4: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001303DC: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v136, v42// 0000001303E0: CA4652FF 28285588 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 0000001303EC: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001303F0: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 0000001303F4: D6FC7C2A 04A65128
	v_rcp_f32_e32 v48, v42                                     // 0000001303FC: 7E60552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130400: BF870095
	v_fma_f32 v49, -v42, v48, 1.0                              // 000000130404: D6130031 23CA612A
	v_fmac_f32_e32 v48, v49, v48                               // 00000013040C: 56606131
	v_div_scale_f32 v49, vcc_lo, v41, v40, v41                 // 000000130410: D6FC6A31 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130418: BF870091
	v_mul_f32_e32 v50, v49, v48                                // 00000013041C: 10646131
	v_fma_f32 v51, -v42, v50, v49                              // 000000130420: D6130033 24C6652A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130428: BF870091
	v_fmac_f32_e32 v50, v51, v48                               // 00000013042C: 56646133
	v_fma_f32 v42, -v42, v50, v49                              // 000000130430: D613002A 24C6652A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130438: BF870091
	v_div_fmas_f32 v42, v42, v48, v50                          // 00000013043C: D637002A 04CA612A
	v_div_fixup_f32 v42, v42, v40, v41                         // 000000130444: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v121, v[128:129]     // 00000013044C: D6FF7C28 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130458: BF870092
	v_bfe_u32 v48, v42, 16, 1                                  // 00000013045C: D6100030 0205212A
	v_add3_u32 v42, v42, v48, 0x7fff                           // 000000130464: D655002A 03FE612A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 000000130470: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 000000130478: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013047C: BE882003
	s_cbranch_execz 59931                                      // 000000130480: BFA5EA1B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37f0>
	v_mad_i64_i32 v[40:41], null, 0x6000, v122, v[130:131]     // 000000130484: D6FF7C28 060AF4FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 000000130490: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 000000130498: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000013049C: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001304A0: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 0000001304A4: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 0000001304AC: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v48, v41                                   // 0000001304B8: 7E604729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001304BC: BF870091
	v_dual_fmamk_f32 v42, v40, 0xb2a5705f, v42 :: v_dual_sub_f32 v41, v41, v48// 0000001304C0: C88A5528 2A286129 B2A5705F
	v_add_f32_e32 v41, v41, v42                                // 0000001304CC: 06525529
	v_cvt_i32_f32_e32 v42, v48                                 // 0000001304D0: 7E541130
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 0000001304D4: 7C3C50FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001304DC: BF870293
	v_exp_f32_e32 v41, v41                                     // 0000001304E0: 7E524B29
	.long 0xd71c0029                                           // 0000001304E4: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 0000001304E8: 02025529
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001304EC: BF870121
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 0000001304F0: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 0000001304F4: 7C3650FF C2B17218
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v137, v43// 0000001304FC: CA4652FF 28285789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130508: BF870091
	v_add_f32_e32 v40, 1.0, v40                                // 00000013050C: 065050F2
	v_div_scale_f32 v42, null, v40, v40, v41                   // 000000130510: D6FC7C2A 04A65128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000130518: BF870291
	v_rcp_f32_e32 v43, v42                                     // 00000013051C: 7E56552A
	v_fma_f32 v48, -v42, v43, 1.0                              // 000000130520: D6130030 23CA572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000130528: BF8700A1
	v_fmac_f32_e32 v43, v48, v43                               // 00000013052C: 56565730
	v_div_scale_f32 v48, vcc_lo, v41, v40, v41                 // 000000130530: D6FC6A30 04A65129
	v_mul_f32_e32 v49, v48, v43                                // 000000130538: 10625730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013053C: BF870091
	v_fma_f32 v50, -v42, v49, v48                              // 000000130540: D6130032 24C2632A
	v_fmac_f32_e32 v49, v50, v43                               // 000000130548: 56625732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013054C: BF870091
	v_fma_f32 v42, -v42, v49, v48                              // 000000130550: D613002A 24C2632A
	v_div_fmas_f32 v42, v42, v43, v49                          // 000000130558: D637002A 04C6572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130560: BF870121
	v_div_fixup_f32 v42, v42, v40, v41                         // 000000130564: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v122, v[128:129]     // 00000013056C: D6FF7C28 0602F4FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 000000130578: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000130580: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 000000130584: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 000000130590: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 000000130598: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000013059C: BE882004
	s_cbranch_execz 59862                                      // 0000001305A0: BFA5E9D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x37fc>
	v_mad_i64_i32 v[40:41], null, 0x6000, v123, v[130:131]     // 0000001305A4: D6FF7C28 060AF6FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 0000001305B0: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 0000001305B8: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 0000001305BC: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001305C0: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 0000001305C4: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 0000001305CC: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000001305D8: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001305DC: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 0000001305E0: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 0000001305E4: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 0000001305EC: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001305F4: BF870121
	v_add_f32_e32 v41, v41, v42                                // 0000001305F8: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 0000001305FC: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 000000130600: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130604: BF870095
	.long 0xd71c0029                                           // 000000130608: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000013060C: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 000000130610: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 000000130614: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013061C: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v134, v44// 000000130620: CA4652FF 28285986 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000013062C: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130630: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 000000130634: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 00000013063C: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130640: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 000000130644: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000013064C: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 000000130650: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130658: BF870091
	v_mul_f32_e32 v48, v44, v43                                // 00000013065C: 1060572C
	v_fma_f32 v49, -v42, v48, v44                              // 000000130660: D6130031 24B2612A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130668: BF870091
	v_fmac_f32_e32 v48, v49, v43                               // 00000013066C: 56605731
	v_fma_f32 v42, -v42, v48, v44                              // 000000130670: D613002A 24B2612A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130678: BF870091
	v_div_fmas_f32 v42, v42, v43, v48                          // 00000013067C: D637002A 04C2572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 000000130684: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v123, v[128:129]     // 00000013068C: D6FF7C28 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130698: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 00000013069C: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000001306A4: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 0000001306B0: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001306B8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001306BC: BE882005
	s_cbranch_execz 59793                                      // 0000001306C0: BFA5E991 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3808>
	v_mad_i64_i32 v[40:41], null, 0x6000, v124, v[130:131]     // 0000001306C4: D6FF7C28 060AF8FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 0000001306D0: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 0000001306D8: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 0000001306DC: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001306E0: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 0000001306E4: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 0000001306EC: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 0000001306F8: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001306FC: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 000000130700: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 000000130704: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 00000013070C: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130714: BF870121
	v_add_f32_e32 v41, v41, v42                                // 000000130718: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000013071C: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 000000130720: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130724: BF870095
	.long 0xd71c0029                                           // 000000130728: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000013072C: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 000000130730: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 000000130734: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013073C: BF870092
	v_cndmask_b32_e32 v40, 0x7f800000, v41, vcc_lo             // 000000130740: 025052FF 7F800000
	v_dual_mul_f32 v41, v135, v45 :: v_dual_add_f32 v40, 1.0, v40// 000000130748: C8C85B87 292850F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130750: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 000000130754: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 00000013075C: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130760: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 000000130764: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000013076C: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 000000130770: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130778: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 00000013077C: 105A572C
	v_fma_f32 v48, -v42, v45, v44                              // 000000130780: D6130030 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130788: BF870091
	v_fmac_f32_e32 v45, v48, v43                               // 00000013078C: 565A5730
	v_fma_f32 v42, -v42, v45, v44                              // 000000130790: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130798: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 00000013079C: D637002A 04B6572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 0000001307A4: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v124, v[128:129]     // 0000001307AC: D6FF7C28 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001307B8: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 0000001307BC: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000001307C4: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 0000001307D0: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001307D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001307DC: BE882006
	s_cbranch_execz 59724                                      // 0000001307E0: BFA5E94C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3814>
	v_mad_i64_i32 v[40:41], null, 0x6000, v125, v[130:131]     // 0000001307E4: D6FF7C28 060AFAFF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 0000001307F0: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 0000001307F8: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 0000001307FC: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130800: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 000000130804: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 00000013080C: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 000000130818: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013081C: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 000000130820: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 000000130824: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 00000013082C: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130834: BF870121
	v_add_f32_e32 v41, v41, v42                                // 000000130838: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000013083C: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 000000130840: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130844: BF870095
	.long 0xd71c0029                                           // 000000130848: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000013084C: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 000000130850: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 000000130854: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013085C: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v132, v46// 000000130860: CA4652FF 28285D84 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000013086C: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130870: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 000000130874: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 00000013087C: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130880: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 000000130884: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000013088C: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 000000130890: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130898: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 00000013089C: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 0000001308A0: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001308A8: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 0000001308AC: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 0000001308B0: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001308B8: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 0000001308BC: D637002A 04B6572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 0000001308C4: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v125, v[128:129]     // 0000001308CC: D6FF7C28 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001308D8: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 0000001308DC: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 0000001308E4: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 0000001308F0: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001308F8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001308FC: BE882007
	s_cbranch_execz 59655                                      // 000000130900: BFA5E907 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3820>
	v_mad_i64_i32 v[40:41], null, 0x6000, v126, v[130:131]     // 000000130904: D6FF7C28 060AFCFF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 000000130910: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 000000130918: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000013091C: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130920: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 000000130924: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 00000013092C: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 000000130938: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013093C: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 000000130940: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 000000130944: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 00000013094C: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130954: BF870121
	v_add_f32_e32 v41, v41, v42                                // 000000130958: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000013095C: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 000000130960: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130964: BF870095
	.long 0xd71c0029                                           // 000000130968: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000013096C: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 000000130970: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 000000130974: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013097C: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v133, v47// 000000130980: CA4652FF 28285F85 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000013098C: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130990: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 000000130994: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 00000013099C: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001309A0: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000001309A4: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 0000001309AC: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 0000001309B0: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001309B8: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 0000001309BC: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 0000001309C0: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001309C8: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 0000001309CC: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 0000001309D0: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001309D8: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 0000001309DC: D637002A 04B6572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 0000001309E4: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v126, v[128:129]     // 0000001309EC: D6FF7C28 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001309F8: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 0000001309FC: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 000000130A04: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 000000130A10: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 000000130A18: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000130A1C: BE882000
	s_cbranch_execz 59586                                      // 000000130A20: BFA5E8C2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x382c>
	v_mad_i64_i32 v[40:41], null, 0x6000, v140, v[130:131]     // 000000130A24: D6FF7C28 060B18FF 00006000
	v_mul_f32_e32 v32, v138, v32                               // 000000130A30: 1040418A
	global_load_u16 v40, v[40:41], off offset:864              // 000000130A34: DC4A0360 287C0028
	s_waitcnt vmcnt(0)                                         // 000000130A3C: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 000000130A40: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130A44: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 000000130A48: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 000000130A50: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 000000130A5C: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000130A60: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 000000130A64: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 000000130A68: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 000000130A70: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130A78: BF870121
	v_add_f32_e32 v41, v41, v42                                // 000000130A7C: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 000000130A80: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 000000130A84: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130A88: BF870095
	.long 0xd71c0029                                           // 000000130A8C: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 000000130A90: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 000000130A94: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 000000130A98: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130AA0: BF870092
	v_cndmask_b32_e32 v40, 0x7f800000, v41, vcc_lo             // 000000130AA4: 025052FF 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 000000130AAC: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130AB0: BF870091
	v_div_scale_f32 v41, null, v40, v40, v32                   // 000000130AB4: D6FC7C29 04825128
	v_rcp_f32_e32 v42, v41                                     // 000000130ABC: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130AC0: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 000000130AC4: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 000000130ACC: 5654552B
	v_div_scale_f32 v43, vcc_lo, v32, v40, v32                 // 000000130AD0: D6FC6A2B 04825120
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130AD8: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 000000130ADC: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 000000130AE0: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130AE8: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 000000130AEC: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 000000130AF0: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130AF8: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 000000130AFC: D6370029 04B25529
	v_div_fixup_f32 v32, v41, v40, v32                         // 000000130B04: D6270020 04825129
	v_mad_i64_i32 v[40:41], null, 0x3000, v140, v[128:129]     // 000000130B0C: D6FF7C28 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130B18: BF870092
	v_bfe_u32 v42, v32, 16, 1                                  // 000000130B1C: D610002A 02052120
	v_add3_u32 v32, v32, v42, 0x7fff                           // 000000130B24: D6550020 03FE5520 00007FFF
	global_store_d16_hi_b16 v[40:41], v32, off offset:352      // 000000130B30: DC960160 007C2028
	s_or_b32 exec_lo, exec_lo, s8                              // 000000130B38: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000130B3C: BE882001
	s_cbranch_execz 59517                                      // 000000130B40: BFA5E87D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3838>
	v_mad_i64_i32 v[40:41], null, 0x6000, v120, v[130:131]     // 000000130B44: D6FF7C28 060AF0FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 000000130B50: 1042438B
	global_load_u16 v32, v[40:41], off offset:864              // 000000130B54: DC4A0360 207C0028
	s_waitcnt vmcnt(0)                                         // 000000130B5C: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 000000130B60: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130B64: BF870121
	v_mul_f32_e32 v40, 0xbfb8aa3b, v32                         // 000000130B68: 105040FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 000000130B70: 7C3C40FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v32, -v40                       // 000000130B78: D6130029 84A240FF BFB8AA3B
	v_rndne_f32_e32 v42, v40                                   // 000000130B84: 7E544728
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000130B88: BF870112
	v_fmamk_f32 v41, v32, 0xb2a5705f, v41                      // 000000130B8C: 58525320 B2A5705F
	v_sub_f32_e32 v40, v40, v42                                // 000000130B94: 08505528
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130B98: BF870121
	v_add_f32_e32 v40, v40, v41                                // 000000130B9C: 06505328
	v_cvt_i32_f32_e32 v41, v42                                 // 000000130BA0: 7E52112A
	v_exp_f32_e32 v40, v40                                     // 000000130BA4: 7E504B28
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130BA8: BF870095
	.long 0xd71c0028                                           // 000000130BAC: D71C0028
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                     // 000000130BB0: 02025328
	v_cndmask_b32_e32 v40, 0, v40, vcc_lo                      // 000000130BB4: 02505080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 000000130BB8: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130BC0: BF870092
	v_cndmask_b32_e32 v32, 0x7f800000, v40, vcc_lo             // 000000130BC4: 024050FF 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 000000130BCC: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130BD0: BF870091
	v_div_scale_f32 v40, null, v32, v32, v33                   // 000000130BD4: D6FC7C28 04864120
	v_rcp_f32_e32 v41, v40                                     // 000000130BDC: 7E525528
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130BE0: BF870095
	v_fma_f32 v42, -v40, v41, 1.0                              // 000000130BE4: D613002A 23CA5328
	v_fmac_f32_e32 v41, v42, v41                               // 000000130BEC: 5652532A
	v_div_scale_f32 v42, vcc_lo, v33, v32, v33                 // 000000130BF0: D6FC6A2A 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130BF8: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 000000130BFC: 1056532A
	v_fma_f32 v44, -v40, v43, v42                              // 000000130C00: D613002C 24AA5728
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130C08: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 000000130C0C: 5656532C
	v_fma_f32 v40, -v40, v43, v42                              // 000000130C10: D6130028 24AA5728
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130C18: BF870091
	v_div_fmas_f32 v40, v40, v41, v43                          // 000000130C1C: D6370028 04AE5328
	v_div_fixup_f32 v40, v40, v32, v33                         // 000000130C24: D6270028 04864128
	v_mad_i64_i32 v[32:33], null, 0x3000, v120, v[128:129]     // 000000130C2C: D6FF7C20 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130C38: BF870092
	v_bfe_u32 v41, v40, 16, 1                                  // 000000130C3C: D6100029 02052128
	v_add3_u32 v40, v40, v41, 0x7fff                           // 000000130C44: D6550028 03FE5328 00007FFF
	global_store_d16_hi_b16 v[32:33], v40, off offset:352      // 000000130C50: DC960160 007C2820
	s_or_b32 exec_lo, exec_lo, s8                              // 000000130C58: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000130C5C: BE882002
	s_cbranch_execz 59448                                      // 000000130C60: BFA5E838 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3844>
	v_mad_i64_i32 v[32:33], null, 0x6000, v121, v[130:131]     // 000000130C64: D6FF7C20 060AF2FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 000000130C70: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 000000130C78: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 000000130C7C: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130C80: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 000000130C84: 104240FF BFB8AA3B
	v_fma_f32 v40, 0xbfb8aa3b, v32, -v33                       // 000000130C8C: D6130028 848640FF BFB8AA3B
	v_rndne_f32_e32 v41, v33                                   // 000000130C98: 7E524721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000130C9C: BF870221
	v_sub_f32_e32 v33, v33, v41                                // 000000130CA0: 08425321
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 000000130CA4: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v40, v32, 0xb2a5705f, v40                      // 000000130CAC: 58505120 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130CB4: BF870121
	v_add_f32_e32 v33, v33, v40                                // 000000130CB8: 06425121
	v_cvt_i32_f32_e32 v40, v41                                 // 000000130CBC: 7E501129
	v_exp_f32_e32 v33, v33                                     // 000000130CC0: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130CC4: BF870095
	.long 0xd71c0021                                           // 000000130CC8: D71C0021
	v_cndmask_b32_e32 v1, v33, v40, vcc_lo                     // 000000130CCC: 02025121
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 000000130CD0: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 000000130CD4: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130CDC: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v136, v34// 000000130CE0: CA4642FF 20204588 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 000000130CEC: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130CF0: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 000000130CF4: D6FC7C22 04864120
	v_rcp_f32_e32 v40, v34                                     // 000000130CFC: 7E505522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130D00: BF870095
	v_fma_f32 v41, -v34, v40, 1.0                              // 000000130D04: D6130029 23CA5122
	v_fmac_f32_e32 v40, v41, v40                               // 000000130D0C: 56505129
	v_div_scale_f32 v41, vcc_lo, v33, v32, v33                 // 000000130D10: D6FC6A29 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130D18: BF870091
	v_mul_f32_e32 v42, v41, v40                                // 000000130D1C: 10545129
	v_fma_f32 v43, -v34, v42, v41                              // 000000130D20: D613002B 24A65522
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130D28: BF870091
	v_fmac_f32_e32 v42, v43, v40                               // 000000130D2C: 5654512B
	v_fma_f32 v34, -v34, v42, v41                              // 000000130D30: D6130022 24A65522
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130D38: BF870091
	v_div_fmas_f32 v34, v34, v40, v42                          // 000000130D3C: D6370022 04AA5122
	v_div_fixup_f32 v34, v34, v32, v33                         // 000000130D44: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v121, v[128:129]     // 000000130D4C: D6FF7C20 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130D58: BF870092
	v_bfe_u32 v40, v34, 16, 1                                  // 000000130D5C: D6100028 02052122
	v_add3_u32 v34, v34, v40, 0x7fff                           // 000000130D64: D6550022 03FE5122 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 000000130D70: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 000000130D78: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000130D7C: BE882003
	s_cbranch_execz 59379                                      // 000000130D80: BFA5E7F3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3850>
	v_mad_i64_i32 v[32:33], null, 0x6000, v122, v[130:131]     // 000000130D84: D6FF7C20 060AF4FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 000000130D90: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 000000130D98: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 000000130D9C: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130DA0: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 000000130DA4: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 000000130DAC: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v40, v33                                   // 000000130DB8: 7E504721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130DBC: BF870091
	v_dual_fmamk_f32 v34, v32, 0xb2a5705f, v34 :: v_dual_sub_f32 v33, v33, v40// 000000130DC0: C88A4520 22205121 B2A5705F
	v_add_f32_e32 v33, v33, v34                                // 000000130DCC: 06424521
	v_cvt_i32_f32_e32 v34, v40                                 // 000000130DD0: 7E441128
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 000000130DD4: 7C3C40FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000130DDC: BF870293
	v_exp_f32_e32 v33, v33                                     // 000000130DE0: 7E424B21
	.long 0xd71c0021                                           // 000000130DE4: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 000000130DE8: 02024521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130DEC: BF870121
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 000000130DF0: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 000000130DF4: 7C3640FF C2B17218
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v137, v35// 000000130DFC: CA4642FF 20204789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130E08: BF870091
	v_add_f32_e32 v32, 1.0, v32                                // 000000130E0C: 064040F2
	v_div_scale_f32 v34, null, v32, v32, v33                   // 000000130E10: D6FC7C22 04864120
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000130E18: BF870291
	v_rcp_f32_e32 v35, v34                                     // 000000130E1C: 7E465522
	v_fma_f32 v40, -v34, v35, 1.0                              // 000000130E20: D6130028 23CA4722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000130E28: BF8700A1
	v_fmac_f32_e32 v35, v40, v35                               // 000000130E2C: 56464728
	v_div_scale_f32 v40, vcc_lo, v33, v32, v33                 // 000000130E30: D6FC6A28 04864121
	v_mul_f32_e32 v41, v40, v35                                // 000000130E38: 10524728
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130E3C: BF870091
	v_fma_f32 v42, -v34, v41, v40                              // 000000130E40: D613002A 24A25322
	v_fmac_f32_e32 v41, v42, v35                               // 000000130E48: 5652472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130E4C: BF870091
	v_fma_f32 v34, -v34, v41, v40                              // 000000130E50: D6130022 24A25322
	v_div_fmas_f32 v34, v34, v35, v41                          // 000000130E58: D6370022 04A64722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130E60: BF870121
	v_div_fixup_f32 v34, v34, v32, v33                         // 000000130E64: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v122, v[128:129]     // 000000130E6C: D6FF7C20 0602F4FF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 000000130E78: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 000000130E80: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 000000130E84: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 000000130E90: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 000000130E98: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000130E9C: BE882004
	s_cbranch_execz 59310                                      // 000000130EA0: BFA5E7AE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x385c>
	v_mad_i64_i32 v[32:33], null, 0x6000, v123, v[130:131]     // 000000130EA4: D6FF7C20 060AF6FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 000000130EB0: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 000000130EB8: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 000000130EBC: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130EC0: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 000000130EC4: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 000000130ECC: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 000000130ED8: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000130EDC: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 000000130EE0: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 000000130EE4: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 000000130EEC: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000130EF4: BF870121
	v_add_f32_e32 v33, v33, v34                                // 000000130EF8: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 000000130EFC: 7E441123
	v_exp_f32_e32 v33, v33                                     // 000000130F00: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130F04: BF870095
	.long 0xd71c0021                                           // 000000130F08: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 000000130F0C: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 000000130F10: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 000000130F14: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130F1C: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v134, v36// 000000130F20: CA4642FF 20204986 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 000000130F2C: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130F30: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 000000130F34: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 000000130F3C: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130F40: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 000000130F44: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 000000130F4C: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 000000130F50: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130F58: BF870091
	v_mul_f32_e32 v40, v36, v35                                // 000000130F5C: 10504724
	v_fma_f32 v41, -v34, v40, v36                              // 000000130F60: D6130029 24925122
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130F68: BF870091
	v_fmac_f32_e32 v40, v41, v35                               // 000000130F6C: 56504729
	v_fma_f32 v34, -v34, v40, v36                              // 000000130F70: D6130022 24925122
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130F78: BF870091
	v_div_fmas_f32 v34, v34, v35, v40                          // 000000130F7C: D6370022 04A24722
	v_div_fixup_f32 v34, v34, v32, v33                         // 000000130F84: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v123, v[128:129]     // 000000130F8C: D6FF7C20 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130F98: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 000000130F9C: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 000000130FA4: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 000000130FB0: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 000000130FB8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000130FBC: BE882005
	s_cbranch_execz 59241                                      // 000000130FC0: BFA5E769 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3868>
	v_mad_i64_i32 v[32:33], null, 0x6000, v124, v[130:131]     // 000000130FC4: D6FF7C20 060AF8FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 000000130FD0: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 000000130FD8: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 000000130FDC: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000130FE0: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 000000130FE4: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 000000130FEC: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 000000130FF8: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000130FFC: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 000000131000: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 000000131004: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 00000013100C: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131014: BF870121
	v_add_f32_e32 v33, v33, v34                                // 000000131018: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000013101C: 7E441123
	v_exp_f32_e32 v33, v33                                     // 000000131020: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131024: BF870095
	.long 0xd71c0021                                           // 000000131028: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000013102C: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 000000131030: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 000000131034: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013103C: BF870092
	v_cndmask_b32_e32 v32, 0x7f800000, v33, vcc_lo             // 000000131040: 024042FF 7F800000
	v_dual_mul_f32 v33, v135, v37 :: v_dual_add_f32 v32, 1.0, v32// 000000131048: C8C84B87 212040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131050: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 000000131054: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 00000013105C: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131060: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 000000131064: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 00000013106C: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 000000131070: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131078: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 00000013107C: 104A4724
	v_fma_f32 v40, -v34, v37, v36                              // 000000131080: D6130028 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131088: BF870091
	v_fmac_f32_e32 v37, v40, v35                               // 00000013108C: 564A4728
	v_fma_f32 v34, -v34, v37, v36                              // 000000131090: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131098: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 00000013109C: D6370022 04964722
	v_div_fixup_f32 v34, v34, v32, v33                         // 0000001310A4: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v124, v[128:129]     // 0000001310AC: D6FF7C20 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001310B8: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 0000001310BC: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 0000001310C4: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 0000001310D0: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001310D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001310DC: BE882006
	s_cbranch_execz 59172                                      // 0000001310E0: BFA5E724 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3874>
	v_mad_i64_i32 v[32:33], null, 0x6000, v125, v[130:131]     // 0000001310E4: D6FF7C20 060AFAFF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 0000001310F0: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 0000001310F8: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 0000001310FC: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131100: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 000000131104: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 00000013110C: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 000000131118: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013111C: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 000000131120: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 000000131124: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 00000013112C: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131134: BF870121
	v_add_f32_e32 v33, v33, v34                                // 000000131138: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000013113C: 7E441123
	v_exp_f32_e32 v33, v33                                     // 000000131140: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131144: BF870095
	.long 0xd71c0021                                           // 000000131148: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000013114C: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 000000131150: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 000000131154: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013115C: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v132, v38// 000000131160: CA4642FF 20204D84 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 00000013116C: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131170: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 000000131174: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 00000013117C: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131180: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 000000131184: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 00000013118C: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 000000131190: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131198: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 00000013119C: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 0000001311A0: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001311A8: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 0000001311AC: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 0000001311B0: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001311B8: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 0000001311BC: D6370022 04964722
	v_div_fixup_f32 v34, v34, v32, v33                         // 0000001311C4: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v125, v[128:129]     // 0000001311CC: D6FF7C20 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001311D8: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 0000001311DC: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 0000001311E4: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 0000001311F0: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001311F8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001311FC: BE882007
	s_cbranch_execz 59103                                      // 000000131200: BFA5E6DF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3880>
	v_mad_i64_i32 v[32:33], null, 0x6000, v126, v[130:131]     // 000000131204: D6FF7C20 060AFCFF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 000000131210: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 000000131218: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000013121C: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131220: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 000000131224: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 00000013122C: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 000000131238: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013123C: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 000000131240: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 000000131244: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 00000013124C: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131254: BF870121
	v_add_f32_e32 v33, v33, v34                                // 000000131258: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000013125C: 7E441123
	v_exp_f32_e32 v33, v33                                     // 000000131260: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131264: BF870095
	.long 0xd71c0021                                           // 000000131268: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000013126C: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 000000131270: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 000000131274: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013127C: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v133, v39// 000000131280: CA4642FF 20204F85 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 00000013128C: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131290: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 000000131294: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 00000013129C: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001312A0: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000001312A4: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 0000001312AC: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 0000001312B0: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001312B8: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 0000001312BC: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 0000001312C0: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001312C8: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 0000001312CC: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 0000001312D0: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001312D8: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 0000001312DC: D6370022 04964722
	v_div_fixup_f32 v34, v34, v32, v33                         // 0000001312E4: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v126, v[128:129]     // 0000001312EC: D6FF7C20 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001312F8: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 0000001312FC: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 000000131304: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 000000131310: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 000000131318: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000013131C: BE882000
	s_cbranch_execz 59034                                      // 000000131320: BFA5E69A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x388c>
	v_mad_i64_i32 v[32:33], null, 0x6000, v140, v[130:131]     // 000000131324: D6FF7C20 060B18FF 00006000
	v_mul_f32_e32 v24, v138, v24                               // 000000131330: 1030318A
	global_load_u16 v32, v[32:33], off offset:896              // 000000131334: DC4A0380 207C0020
	s_waitcnt vmcnt(0)                                         // 00000013133C: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 000000131340: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131344: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 000000131348: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 000000131350: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000013135C: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000131360: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 000000131364: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 000000131368: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 000000131370: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131378: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000013137C: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 000000131380: 7E441123
	v_exp_f32_e32 v33, v33                                     // 000000131384: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131388: BF870095
	.long 0xd71c0021                                           // 00000013138C: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 000000131390: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 000000131394: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 000000131398: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001313A0: BF870092
	v_cndmask_b32_e32 v32, 0x7f800000, v33, vcc_lo             // 0000001313A4: 024042FF 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 0000001313AC: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001313B0: BF870091
	v_div_scale_f32 v33, null, v32, v32, v24                   // 0000001313B4: D6FC7C21 04624120
	v_rcp_f32_e32 v34, v33                                     // 0000001313BC: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001313C0: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 0000001313C4: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 0000001313CC: 56444523
	v_div_scale_f32 v35, vcc_lo, v24, v32, v24                 // 0000001313D0: D6FC6A23 04624118
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001313D8: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 0000001313DC: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 0000001313E0: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001313E8: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 0000001313EC: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 0000001313F0: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001313F8: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 0000001313FC: D6370021 04924521
	v_div_fixup_f32 v24, v33, v32, v24                         // 000000131404: D6270018 04624121
	v_mad_i64_i32 v[32:33], null, 0x3000, v140, v[128:129]     // 00000013140C: D6FF7C20 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131418: BF870092
	v_bfe_u32 v34, v24, 16, 1                                  // 00000013141C: D6100022 02052118
	v_add3_u32 v24, v24, v34, 0x7fff                           // 000000131424: D6550018 03FE4518 00007FFF
	global_store_d16_hi_b16 v[32:33], v24, off offset:384      // 000000131430: DC960180 007C1820
	s_or_b32 exec_lo, exec_lo, s8                              // 000000131438: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000013143C: BE882001
	s_cbranch_execz 58965                                      // 000000131440: BFA5E655 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3898>
	v_mad_i64_i32 v[32:33], null, 0x6000, v120, v[130:131]     // 000000131444: D6FF7C20 060AF0FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 000000131450: 1032338B
	global_load_u16 v24, v[32:33], off offset:896              // 000000131454: DC4A0380 187C0020
	s_waitcnt vmcnt(0)                                         // 00000013145C: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 000000131460: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131464: BF870121
	v_mul_f32_e32 v32, 0xbfb8aa3b, v24                         // 000000131468: 104030FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 000000131470: 7C3C30FF 42CE8ED0
	v_fma_f32 v33, 0xbfb8aa3b, v24, -v32                       // 000000131478: D6130021 848230FF BFB8AA3B
	v_rndne_f32_e32 v34, v32                                   // 000000131484: 7E444720
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000131488: BF870112
	v_fmamk_f32 v33, v24, 0xb2a5705f, v33                      // 00000013148C: 58424318 B2A5705F
	v_sub_f32_e32 v32, v32, v34                                // 000000131494: 08404520
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131498: BF870121
	v_add_f32_e32 v32, v32, v33                                // 00000013149C: 06404320
	v_cvt_i32_f32_e32 v33, v34                                 // 0000001314A0: 7E421122
	v_exp_f32_e32 v32, v32                                     // 0000001314A4: 7E404B20
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001314A8: BF870095
	.long 0xd71c0020                                           // 0000001314AC: D71C0020
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                     // 0000001314B0: 02024320
	v_cndmask_b32_e32 v32, 0, v32, vcc_lo                      // 0000001314B4: 02404080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000001314B8: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001314C0: BF870092
	v_cndmask_b32_e32 v24, 0x7f800000, v32, vcc_lo             // 0000001314C4: 023040FF 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 0000001314CC: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001314D0: BF870091
	v_div_scale_f32 v32, null, v24, v24, v25                   // 0000001314D4: D6FC7C20 04663118
	v_rcp_f32_e32 v33, v32                                     // 0000001314DC: 7E425520
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001314E0: BF870095
	v_fma_f32 v34, -v32, v33, 1.0                              // 0000001314E4: D6130022 23CA4320
	v_fmac_f32_e32 v33, v34, v33                               // 0000001314EC: 56424322
	v_div_scale_f32 v34, vcc_lo, v25, v24, v25                 // 0000001314F0: D6FC6A22 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001314F8: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 0000001314FC: 10464322
	v_fma_f32 v36, -v32, v35, v34                              // 000000131500: D6130024 248A4720
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131508: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 00000013150C: 56464324
	v_fma_f32 v32, -v32, v35, v34                              // 000000131510: D6130020 248A4720
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131518: BF870091
	v_div_fmas_f32 v32, v32, v33, v35                          // 00000013151C: D6370020 048E4320
	v_div_fixup_f32 v32, v32, v24, v25                         // 000000131524: D6270020 04663120
	v_mad_i64_i32 v[24:25], null, 0x3000, v120, v[128:129]     // 00000013152C: D6FF7C18 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131538: BF870092
	v_bfe_u32 v33, v32, 16, 1                                  // 00000013153C: D6100021 02052120
	v_add3_u32 v32, v32, v33, 0x7fff                           // 000000131544: D6550020 03FE4320 00007FFF
	global_store_d16_hi_b16 v[24:25], v32, off offset:384      // 000000131550: DC960180 007C2018
	s_or_b32 exec_lo, exec_lo, s8                              // 000000131558: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000013155C: BE882002
	s_cbranch_execz 58896                                      // 000000131560: BFA5E610 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38a4>
	v_mad_i64_i32 v[24:25], null, 0x6000, v121, v[130:131]     // 000000131564: D6FF7C18 060AF2FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 000000131570: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 000000131578: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000013157C: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131580: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 000000131584: 103230FF BFB8AA3B
	v_fma_f32 v32, 0xbfb8aa3b, v24, -v25                       // 00000013158C: D6130020 846630FF BFB8AA3B
	v_rndne_f32_e32 v33, v25                                   // 000000131598: 7E424719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013159C: BF870221
	v_sub_f32_e32 v25, v25, v33                                // 0000001315A0: 08324319
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 0000001315A4: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v32, v24, 0xb2a5705f, v32                      // 0000001315AC: 58404118 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001315B4: BF870121
	v_add_f32_e32 v25, v25, v32                                // 0000001315B8: 06324119
	v_cvt_i32_f32_e32 v32, v33                                 // 0000001315BC: 7E401121
	v_exp_f32_e32 v25, v25                                     // 0000001315C0: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001315C4: BF870095
	.long 0xd71c0019                                           // 0000001315C8: D71C0019
	v_cndmask_b32_e32 v1, v25, v32, vcc_lo                     // 0000001315CC: 02024119
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000001315D0: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000001315D4: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001315DC: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v136, v26// 0000001315E0: CA4632FF 18183588 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 0000001315EC: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001315F0: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 0000001315F4: D6FC7C1A 04663118
	v_rcp_f32_e32 v32, v26                                     // 0000001315FC: 7E40551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131600: BF870095
	v_fma_f32 v33, -v26, v32, 1.0                              // 000000131604: D6130021 23CA411A
	v_fmac_f32_e32 v32, v33, v32                               // 00000013160C: 56404121
	v_div_scale_f32 v33, vcc_lo, v25, v24, v25                 // 000000131610: D6FC6A21 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131618: BF870091
	v_mul_f32_e32 v34, v33, v32                                // 00000013161C: 10444121
	v_fma_f32 v35, -v26, v34, v33                              // 000000131620: D6130023 2486451A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131628: BF870091
	v_fmac_f32_e32 v34, v35, v32                               // 00000013162C: 56444123
	v_fma_f32 v26, -v26, v34, v33                              // 000000131630: D613001A 2486451A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131638: BF870091
	v_div_fmas_f32 v26, v26, v32, v34                          // 00000013163C: D637001A 048A411A
	v_div_fixup_f32 v26, v26, v24, v25                         // 000000131644: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v121, v[128:129]     // 00000013164C: D6FF7C18 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131658: BF870092
	v_bfe_u32 v32, v26, 16, 1                                  // 00000013165C: D6100020 0205211A
	v_add3_u32 v26, v26, v32, 0x7fff                           // 000000131664: D655001A 03FE411A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 000000131670: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 000000131678: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013167C: BE882003
	s_cbranch_execz 58827                                      // 000000131680: BFA5E5CB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38b0>
	v_mad_i64_i32 v[24:25], null, 0x6000, v122, v[130:131]     // 000000131684: D6FF7C18 060AF4FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 000000131690: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 000000131698: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000013169C: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001316A0: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 0000001316A4: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 0000001316AC: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v32, v25                                   // 0000001316B8: 7E404719
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001316BC: BF870091
	v_dual_fmamk_f32 v26, v24, 0xb2a5705f, v26 :: v_dual_sub_f32 v25, v25, v32// 0000001316C0: C88A3518 1A184119 B2A5705F
	v_add_f32_e32 v25, v25, v26                                // 0000001316CC: 06323519
	v_cvt_i32_f32_e32 v26, v32                                 // 0000001316D0: 7E341120
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 0000001316D4: 7C3C30FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001316DC: BF870293
	v_exp_f32_e32 v25, v25                                     // 0000001316E0: 7E324B19
	.long 0xd71c0019                                           // 0000001316E4: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 0000001316E8: 02023519
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001316EC: BF870121
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000001316F0: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 0000001316F4: 7C3630FF C2B17218
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v137, v27// 0000001316FC: CA4632FF 18183789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131708: BF870091
	v_add_f32_e32 v24, 1.0, v24                                // 00000013170C: 063030F2
	v_div_scale_f32 v26, null, v24, v24, v25                   // 000000131710: D6FC7C1A 04663118
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000131718: BF870291
	v_rcp_f32_e32 v27, v26                                     // 00000013171C: 7E36551A
	v_fma_f32 v32, -v26, v27, 1.0                              // 000000131720: D6130020 23CA371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000131728: BF8700A1
	v_fmac_f32_e32 v27, v32, v27                               // 00000013172C: 56363720
	v_div_scale_f32 v32, vcc_lo, v25, v24, v25                 // 000000131730: D6FC6A20 04663119
	v_mul_f32_e32 v33, v32, v27                                // 000000131738: 10423720
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013173C: BF870091
	v_fma_f32 v34, -v26, v33, v32                              // 000000131740: D6130022 2482431A
	v_fmac_f32_e32 v33, v34, v27                               // 000000131748: 56423722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013174C: BF870091
	v_fma_f32 v26, -v26, v33, v32                              // 000000131750: D613001A 2482431A
	v_div_fmas_f32 v26, v26, v27, v33                          // 000000131758: D637001A 0486371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131760: BF870121
	v_div_fixup_f32 v26, v26, v24, v25                         // 000000131764: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v122, v[128:129]     // 00000013176C: D6FF7C18 0602F4FF 00003000
	v_bfe_u32 v27, v26, 16, 1                                  // 000000131778: D610001B 0205211A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000131780: BF870001
	v_add3_u32 v26, v26, v27, 0x7fff                           // 000000131784: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 000000131790: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 000000131798: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000013179C: BE882004
	s_cbranch_execz 58758                                      // 0000001317A0: BFA5E586 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38bc>
	v_mad_i64_i32 v[24:25], null, 0x6000, v123, v[130:131]     // 0000001317A4: D6FF7C18 060AF6FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 0000001317B0: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 0000001317B8: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 0000001317BC: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001317C0: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 0000001317C4: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 0000001317CC: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 0000001317D8: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001317DC: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 0000001317E0: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 0000001317E4: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 0000001317EC: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001317F4: BF870121
	v_add_f32_e32 v25, v25, v26                                // 0000001317F8: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 0000001317FC: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 000000131800: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131804: BF870095
	.long 0xd71c0019                                           // 000000131808: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000013180C: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000131810: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 000000131814: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013181C: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v134, v28// 000000131820: CA4632FF 18183986 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 00000013182C: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131830: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 000000131834: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 00000013183C: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131840: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 000000131844: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 00000013184C: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 000000131850: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131858: BF870091
	v_mul_f32_e32 v32, v28, v27                                // 00000013185C: 1040371C
	v_fma_f32 v33, -v26, v32, v28                              // 000000131860: D6130021 2472411A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131868: BF870091
	v_fmac_f32_e32 v32, v33, v27                               // 00000013186C: 56403721
	v_fma_f32 v26, -v26, v32, v28                              // 000000131870: D613001A 2472411A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131878: BF870091
	v_div_fmas_f32 v26, v26, v27, v32                          // 00000013187C: D637001A 0482371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 000000131884: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v123, v[128:129]     // 00000013188C: D6FF7C18 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131898: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 00000013189C: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 0000001318A4: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 0000001318B0: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001318B8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001318BC: BE882005
	s_cbranch_execz 58689                                      // 0000001318C0: BFA5E541 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38c8>
	v_mad_i64_i32 v[24:25], null, 0x6000, v124, v[130:131]     // 0000001318C4: D6FF7C18 060AF8FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 0000001318D0: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 0000001318D8: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 0000001318DC: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001318E0: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 0000001318E4: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 0000001318EC: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 0000001318F8: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001318FC: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 000000131900: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 000000131904: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 00000013190C: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131914: BF870121
	v_add_f32_e32 v25, v25, v26                                // 000000131918: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000013191C: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 000000131920: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131924: BF870095
	.long 0xd71c0019                                           // 000000131928: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000013192C: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000131930: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 000000131934: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013193C: BF870092
	v_cndmask_b32_e32 v24, 0x7f800000, v25, vcc_lo             // 000000131940: 023032FF 7F800000
	v_dual_mul_f32 v25, v135, v29 :: v_dual_add_f32 v24, 1.0, v24// 000000131948: C8C83B87 191830F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131950: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 000000131954: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 00000013195C: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131960: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 000000131964: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 00000013196C: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 000000131970: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131978: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 00000013197C: 103A371C
	v_fma_f32 v32, -v26, v29, v28                              // 000000131980: D6130020 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131988: BF870091
	v_fmac_f32_e32 v29, v32, v27                               // 00000013198C: 563A3720
	v_fma_f32 v26, -v26, v29, v28                              // 000000131990: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131998: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 00000013199C: D637001A 0476371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 0000001319A4: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v124, v[128:129]     // 0000001319AC: D6FF7C18 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001319B8: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 0000001319BC: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 0000001319C4: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 0000001319D0: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001319D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001319DC: BE882006
	s_cbranch_execz 58620                                      // 0000001319E0: BFA5E4FC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38d4>
	v_mad_i64_i32 v[24:25], null, 0x6000, v125, v[130:131]     // 0000001319E4: D6FF7C18 060AFAFF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 0000001319F0: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 0000001319F8: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 0000001319FC: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131A00: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 000000131A04: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 000000131A0C: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 000000131A18: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000131A1C: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 000000131A20: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 000000131A24: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 000000131A2C: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131A34: BF870121
	v_add_f32_e32 v25, v25, v26                                // 000000131A38: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 000000131A3C: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 000000131A40: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131A44: BF870095
	.long 0xd71c0019                                           // 000000131A48: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000131A4C: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000131A50: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 000000131A54: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131A5C: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v132, v30// 000000131A60: CA4632FF 18183D84 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 000000131A6C: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131A70: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 000000131A74: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 000000131A7C: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131A80: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 000000131A84: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 000000131A8C: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 000000131A90: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131A98: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 000000131A9C: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 000000131AA0: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131AA8: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 000000131AAC: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 000000131AB0: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131AB8: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 000000131ABC: D637001A 0476371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 000000131AC4: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v125, v[128:129]     // 000000131ACC: D6FF7C18 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131AD8: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 000000131ADC: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 000000131AE4: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 000000131AF0: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 000000131AF8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000131AFC: BE882007
	s_cbranch_execz 58551                                      // 000000131B00: BFA5E4B7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38e0>
	v_mad_i64_i32 v[24:25], null, 0x6000, v126, v[130:131]     // 000000131B04: D6FF7C18 060AFCFF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 000000131B10: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 000000131B18: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 000000131B1C: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131B20: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 000000131B24: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 000000131B2C: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 000000131B38: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000131B3C: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 000000131B40: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 000000131B44: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 000000131B4C: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131B54: BF870121
	v_add_f32_e32 v25, v25, v26                                // 000000131B58: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 000000131B5C: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 000000131B60: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131B64: BF870095
	.long 0xd71c0019                                           // 000000131B68: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000131B6C: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000131B70: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 000000131B74: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131B7C: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v133, v31// 000000131B80: CA4632FF 18183F85 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 000000131B8C: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131B90: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 000000131B94: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 000000131B9C: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131BA0: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 000000131BA4: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 000000131BAC: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 000000131BB0: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131BB8: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 000000131BBC: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 000000131BC0: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131BC8: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 000000131BCC: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 000000131BD0: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131BD8: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 000000131BDC: D637001A 0476371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 000000131BE4: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v126, v[128:129]     // 000000131BEC: D6FF7C18 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131BF8: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 000000131BFC: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 000000131C04: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 000000131C10: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 000000131C18: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000131C1C: BE882000
	s_cbranch_execz 58482                                      // 000000131C20: BFA5E472 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38ec>
	v_mad_i64_i32 v[24:25], null, 0x6000, v140, v[130:131]     // 000000131C24: D6FF7C18 060B18FF 00006000
	v_mul_f32_e32 v16, v138, v16                               // 000000131C30: 1020218A
	global_load_u16 v24, v[24:25], off offset:928              // 000000131C34: DC4A03A0 187C0018
	s_waitcnt vmcnt(0)                                         // 000000131C3C: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 000000131C40: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131C44: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 000000131C48: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 000000131C50: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 000000131C5C: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000131C60: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 000000131C64: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 000000131C68: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 000000131C70: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131C78: BF870121
	v_add_f32_e32 v25, v25, v26                                // 000000131C7C: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 000000131C80: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 000000131C84: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131C88: BF870095
	.long 0xd71c0019                                           // 000000131C8C: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 000000131C90: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 000000131C94: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 000000131C98: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131CA0: BF870092
	v_cndmask_b32_e32 v24, 0x7f800000, v25, vcc_lo             // 000000131CA4: 023032FF 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 000000131CAC: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131CB0: BF870091
	v_div_scale_f32 v25, null, v24, v24, v16                   // 000000131CB4: D6FC7C19 04423118
	v_rcp_f32_e32 v26, v25                                     // 000000131CBC: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131CC0: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 000000131CC4: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 000000131CCC: 5634351B
	v_div_scale_f32 v27, vcc_lo, v16, v24, v16                 // 000000131CD0: D6FC6A1B 04423110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131CD8: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 000000131CDC: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 000000131CE0: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131CE8: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 000000131CEC: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 000000131CF0: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131CF8: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 000000131CFC: D6370019 04723519
	v_div_fixup_f32 v16, v25, v24, v16                         // 000000131D04: D6270010 04423119
	v_mad_i64_i32 v[24:25], null, 0x3000, v140, v[128:129]     // 000000131D0C: D6FF7C18 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131D18: BF870092
	v_bfe_u32 v26, v16, 16, 1                                  // 000000131D1C: D610001A 02052110
	v_add3_u32 v16, v16, v26, 0x7fff                           // 000000131D24: D6550010 03FE3510 00007FFF
	global_store_d16_hi_b16 v[24:25], v16, off offset:416      // 000000131D30: DC9601A0 007C1018
	s_or_b32 exec_lo, exec_lo, s8                              // 000000131D38: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000131D3C: BE882001
	s_cbranch_execz 58413                                      // 000000131D40: BFA5E42D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x38f8>
	v_mad_i64_i32 v[24:25], null, 0x6000, v120, v[130:131]     // 000000131D44: D6FF7C18 060AF0FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 000000131D50: 1022238B
	global_load_u16 v16, v[24:25], off offset:928              // 000000131D54: DC4A03A0 107C0018
	s_waitcnt vmcnt(0)                                         // 000000131D5C: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000131D60: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131D64: BF870121
	v_mul_f32_e32 v24, 0xbfb8aa3b, v16                         // 000000131D68: 103020FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 000000131D70: 7C3C20FF 42CE8ED0
	v_fma_f32 v25, 0xbfb8aa3b, v16, -v24                       // 000000131D78: D6130019 846220FF BFB8AA3B
	v_rndne_f32_e32 v26, v24                                   // 000000131D84: 7E344718
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000131D88: BF870112
	v_fmamk_f32 v25, v16, 0xb2a5705f, v25                      // 000000131D8C: 58323310 B2A5705F
	v_sub_f32_e32 v24, v24, v26                                // 000000131D94: 08303518
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131D98: BF870121
	v_add_f32_e32 v24, v24, v25                                // 000000131D9C: 06303318
	v_cvt_i32_f32_e32 v25, v26                                 // 000000131DA0: 7E32111A
	v_exp_f32_e32 v24, v24                                     // 000000131DA4: 7E304B18
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131DA8: BF870095
	.long 0xd71c0018                                           // 000000131DAC: D71C0018
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 000000131DB0: 02023318
	v_cndmask_b32_e32 v24, 0, v24, vcc_lo                      // 000000131DB4: 02303080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 000000131DB8: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131DC0: BF870092
	v_cndmask_b32_e32 v16, 0x7f800000, v24, vcc_lo             // 000000131DC4: 022030FF 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 000000131DCC: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131DD0: BF870091
	v_div_scale_f32 v24, null, v16, v16, v17                   // 000000131DD4: D6FC7C18 04462110
	v_rcp_f32_e32 v25, v24                                     // 000000131DDC: 7E325518
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131DE0: BF870095
	v_fma_f32 v26, -v24, v25, 1.0                              // 000000131DE4: D613001A 23CA3318
	v_fmac_f32_e32 v25, v26, v25                               // 000000131DEC: 5632331A
	v_div_scale_f32 v26, vcc_lo, v17, v16, v17                 // 000000131DF0: D6FC6A1A 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131DF8: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 000000131DFC: 1036331A
	v_fma_f32 v28, -v24, v27, v26                              // 000000131E00: D613001C 246A3718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131E08: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 000000131E0C: 5636331C
	v_fma_f32 v24, -v24, v27, v26                              // 000000131E10: D6130018 246A3718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131E18: BF870091
	v_div_fmas_f32 v24, v24, v25, v27                          // 000000131E1C: D6370018 046E3318
	v_div_fixup_f32 v24, v24, v16, v17                         // 000000131E24: D6270018 04462118
	v_mad_i64_i32 v[16:17], null, 0x3000, v120, v[128:129]     // 000000131E2C: D6FF7C10 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131E38: BF870092
	v_bfe_u32 v25, v24, 16, 1                                  // 000000131E3C: D6100019 02052118
	v_add3_u32 v24, v24, v25, 0x7fff                           // 000000131E44: D6550018 03FE3318 00007FFF
	global_store_d16_hi_b16 v[16:17], v24, off offset:416      // 000000131E50: DC9601A0 007C1810
	s_or_b32 exec_lo, exec_lo, s8                              // 000000131E58: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000131E5C: BE882002
	s_cbranch_execz 58344                                      // 000000131E60: BFA5E3E8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3904>
	v_mad_i64_i32 v[16:17], null, 0x6000, v121, v[130:131]     // 000000131E64: D6FF7C10 060AF2FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 000000131E70: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 000000131E78: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000131E7C: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131E80: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 000000131E84: 102220FF BFB8AA3B
	v_fma_f32 v24, 0xbfb8aa3b, v16, -v17                       // 000000131E8C: D6130018 844620FF BFB8AA3B
	v_rndne_f32_e32 v25, v17                                   // 000000131E98: 7E324711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000131E9C: BF870221
	v_sub_f32_e32 v17, v17, v25                                // 000000131EA0: 08223311
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 000000131EA4: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v24, v16, 0xb2a5705f, v24                      // 000000131EAC: 58303110 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131EB4: BF870121
	v_add_f32_e32 v17, v17, v24                                // 000000131EB8: 06223111
	v_cvt_i32_f32_e32 v24, v25                                 // 000000131EBC: 7E301119
	v_exp_f32_e32 v17, v17                                     // 000000131EC0: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131EC4: BF870095
	.long 0xd71c0011                                           // 000000131EC8: D71C0011
	v_cndmask_b32_e32 v1, v17, v24, vcc_lo                     // 000000131ECC: 02023111
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000131ED0: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 000000131ED4: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131EDC: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v136, v18// 000000131EE0: CA4622FF 10102588 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 000000131EEC: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131EF0: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 000000131EF4: D6FC7C12 04462110
	v_rcp_f32_e32 v24, v18                                     // 000000131EFC: 7E305512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131F00: BF870095
	v_fma_f32 v25, -v18, v24, 1.0                              // 000000131F04: D6130019 23CA3112
	v_fmac_f32_e32 v24, v25, v24                               // 000000131F0C: 56303119
	v_div_scale_f32 v25, vcc_lo, v17, v16, v17                 // 000000131F10: D6FC6A19 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131F18: BF870091
	v_mul_f32_e32 v26, v25, v24                                // 000000131F1C: 10343119
	v_fma_f32 v27, -v18, v26, v25                              // 000000131F20: D613001B 24663512
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131F28: BF870091
	v_fmac_f32_e32 v26, v27, v24                               // 000000131F2C: 5634311B
	v_fma_f32 v18, -v18, v26, v25                              // 000000131F30: D6130012 24663512
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131F38: BF870091
	v_div_fmas_f32 v18, v18, v24, v26                          // 000000131F3C: D6370012 046A3112
	v_div_fixup_f32 v18, v18, v16, v17                         // 000000131F44: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v121, v[128:129]     // 000000131F4C: D6FF7C10 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131F58: BF870092
	v_bfe_u32 v24, v18, 16, 1                                  // 000000131F5C: D6100018 02052112
	v_add3_u32 v18, v18, v24, 0x7fff                           // 000000131F64: D6550012 03FE3112 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 000000131F70: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 000000131F78: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000131F7C: BE882003
	s_cbranch_execz 58275                                      // 000000131F80: BFA5E3A3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3910>
	v_mad_i64_i32 v[16:17], null, 0x6000, v122, v[130:131]     // 000000131F84: D6FF7C10 060AF4FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 000000131F90: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 000000131F98: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000131F9C: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131FA0: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 000000131FA4: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 000000131FAC: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v24, v17                                   // 000000131FB8: 7E304711
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000131FBC: BF870091
	v_dual_fmamk_f32 v18, v16, 0xb2a5705f, v18 :: v_dual_sub_f32 v17, v17, v24// 000000131FC0: C88A2510 12103111 B2A5705F
	v_add_f32_e32 v17, v17, v18                                // 000000131FCC: 06222511
	v_cvt_i32_f32_e32 v18, v24                                 // 000000131FD0: 7E241118
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 000000131FD4: 7C3C20FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000131FDC: BF870293
	v_exp_f32_e32 v17, v17                                     // 000000131FE0: 7E224B11
	.long 0xd71c0011                                           // 000000131FE4: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000131FE8: 02022511
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000131FEC: BF870121
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000131FF0: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 000000131FF4: 7C3620FF C2B17218
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v137, v19// 000000131FFC: CA4622FF 10102789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132008: BF870091
	v_add_f32_e32 v16, 1.0, v16                                // 00000013200C: 062020F2
	v_div_scale_f32 v18, null, v16, v16, v17                   // 000000132010: D6FC7C12 04462110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000132018: BF870291
	v_rcp_f32_e32 v19, v18                                     // 00000013201C: 7E265512
	v_fma_f32 v24, -v18, v19, 1.0                              // 000000132020: D6130018 23CA2712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132028: BF8700A1
	v_fmac_f32_e32 v19, v24, v19                               // 00000013202C: 56262718
	v_div_scale_f32 v24, vcc_lo, v17, v16, v17                 // 000000132030: D6FC6A18 04462111
	v_mul_f32_e32 v25, v24, v19                                // 000000132038: 10322718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013203C: BF870091
	v_fma_f32 v26, -v18, v25, v24                              // 000000132040: D613001A 24623312
	v_fmac_f32_e32 v25, v26, v19                               // 000000132048: 5632271A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013204C: BF870091
	v_fma_f32 v18, -v18, v25, v24                              // 000000132050: D6130012 24623312
	v_div_fmas_f32 v18, v18, v19, v25                          // 000000132058: D6370012 04662712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132060: BF870121
	v_div_fixup_f32 v18, v18, v16, v17                         // 000000132064: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v122, v[128:129]     // 00000013206C: D6FF7C10 0602F4FF 00003000
	v_bfe_u32 v19, v18, 16, 1                                  // 000000132078: D6100013 02052112
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132080: BF870001
	v_add3_u32 v18, v18, v19, 0x7fff                           // 000000132084: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 000000132090: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 000000132098: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000013209C: BE882004
	s_cbranch_execz 58206                                      // 0000001320A0: BFA5E35E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x391c>
	v_mad_i64_i32 v[16:17], null, 0x6000, v123, v[130:131]     // 0000001320A4: D6FF7C10 060AF6FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 0000001320B0: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 0000001320B8: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 0000001320BC: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001320C0: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 0000001320C4: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 0000001320CC: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 0000001320D8: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001320DC: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 0000001320E0: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 0000001320E4: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 0000001320EC: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001320F4: BF870121
	v_add_f32_e32 v17, v17, v18                                // 0000001320F8: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 0000001320FC: 7E241113
	v_exp_f32_e32 v17, v17                                     // 000000132100: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132104: BF870095
	.long 0xd71c0011                                           // 000000132108: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000013210C: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000132110: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 000000132114: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013211C: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v134, v20// 000000132120: CA4622FF 10102986 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000013212C: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132130: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 000000132134: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000013213C: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132140: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 000000132144: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000013214C: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 000000132150: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132158: BF870091
	v_mul_f32_e32 v24, v20, v19                                // 00000013215C: 10302714
	v_fma_f32 v25, -v18, v24, v20                              // 000000132160: D6130019 24523112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132168: BF870091
	v_fmac_f32_e32 v24, v25, v19                               // 00000013216C: 56302719
	v_fma_f32 v18, -v18, v24, v20                              // 000000132170: D6130012 24523112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132178: BF870091
	v_div_fmas_f32 v18, v18, v19, v24                          // 00000013217C: D6370012 04622712
	v_div_fixup_f32 v18, v18, v16, v17                         // 000000132184: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v123, v[128:129]     // 00000013218C: D6FF7C10 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132198: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 00000013219C: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 0000001321A4: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 0000001321B0: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001321B8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 0000001321BC: BE882005
	s_cbranch_execz 58137                                      // 0000001321C0: BFA5E319 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3928>
	v_mad_i64_i32 v[16:17], null, 0x6000, v124, v[130:131]     // 0000001321C4: D6FF7C10 060AF8FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 0000001321D0: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 0000001321D8: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 0000001321DC: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001321E0: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 0000001321E4: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 0000001321EC: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 0000001321F8: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001321FC: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 000000132200: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 000000132204: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000013220C: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132214: BF870121
	v_add_f32_e32 v17, v17, v18                                // 000000132218: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000013221C: 7E241113
	v_exp_f32_e32 v17, v17                                     // 000000132220: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132224: BF870095
	.long 0xd71c0011                                           // 000000132228: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000013222C: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000132230: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 000000132234: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013223C: BF870092
	v_cndmask_b32_e32 v16, 0x7f800000, v17, vcc_lo             // 000000132240: 022022FF 7F800000
	v_dual_mul_f32 v17, v135, v21 :: v_dual_add_f32 v16, 1.0, v16// 000000132248: C8C82B87 111020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132250: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 000000132254: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000013225C: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132260: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 000000132264: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000013226C: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 000000132270: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132278: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 00000013227C: 102A2714
	v_fma_f32 v24, -v18, v21, v20                              // 000000132280: D6130018 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132288: BF870091
	v_fmac_f32_e32 v21, v24, v19                               // 00000013228C: 562A2718
	v_fma_f32 v18, -v18, v21, v20                              // 000000132290: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132298: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 00000013229C: D6370012 04562712
	v_div_fixup_f32 v18, v18, v16, v17                         // 0000001322A4: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v124, v[128:129]     // 0000001322AC: D6FF7C10 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001322B8: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 0000001322BC: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 0000001322C4: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 0000001322D0: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001322D8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001322DC: BE882006
	s_cbranch_execz 58068                                      // 0000001322E0: BFA5E2D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3934>
	v_mad_i64_i32 v[16:17], null, 0x6000, v125, v[130:131]     // 0000001322E4: D6FF7C10 060AFAFF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 0000001322F0: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 0000001322F8: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 0000001322FC: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132300: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 000000132304: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000013230C: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 000000132318: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013231C: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 000000132320: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 000000132324: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000013232C: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132334: BF870121
	v_add_f32_e32 v17, v17, v18                                // 000000132338: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000013233C: 7E241113
	v_exp_f32_e32 v17, v17                                     // 000000132340: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132344: BF870095
	.long 0xd71c0011                                           // 000000132348: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000013234C: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000132350: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 000000132354: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013235C: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v132, v22// 000000132360: CA4622FF 10102D84 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000013236C: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132370: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 000000132374: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000013237C: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132380: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 000000132384: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000013238C: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 000000132390: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132398: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 00000013239C: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 0000001323A0: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001323A8: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 0000001323AC: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 0000001323B0: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001323B8: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 0000001323BC: D6370012 04562712
	v_div_fixup_f32 v18, v18, v16, v17                         // 0000001323C4: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v125, v[128:129]     // 0000001323CC: D6FF7C10 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001323D8: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 0000001323DC: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 0000001323E4: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 0000001323F0: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001323F8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001323FC: BE882007
	s_cbranch_execz 57999                                      // 000000132400: BFA5E28F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3940>
	v_mad_i64_i32 v[16:17], null, 0x6000, v126, v[130:131]     // 000000132404: D6FF7C10 060AFCFF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 000000132410: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 000000132418: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000013241C: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132420: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 000000132424: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000013242C: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 000000132438: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013243C: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 000000132440: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 000000132444: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000013244C: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132454: BF870121
	v_add_f32_e32 v17, v17, v18                                // 000000132458: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000013245C: 7E241113
	v_exp_f32_e32 v17, v17                                     // 000000132460: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132464: BF870095
	.long 0xd71c0011                                           // 000000132468: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000013246C: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000132470: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 000000132474: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013247C: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v133, v23// 000000132480: CA4622FF 10102F85 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000013248C: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132490: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 000000132494: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000013249C: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001324A0: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000001324A4: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 0000001324AC: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 0000001324B0: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001324B8: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 0000001324BC: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 0000001324C0: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001324C8: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 0000001324CC: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 0000001324D0: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001324D8: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 0000001324DC: D6370012 04562712
	v_div_fixup_f32 v18, v18, v16, v17                         // 0000001324E4: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v126, v[128:129]     // 0000001324EC: D6FF7C10 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001324F8: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 0000001324FC: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 000000132504: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 000000132510: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 000000132518: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000013251C: BE882000
	s_cbranch_execz 57930                                      // 000000132520: BFA5E24A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x394c>
	v_mad_i64_i32 v[16:17], null, 0x6000, v140, v[130:131]     // 000000132524: D6FF7C10 060B18FF 00006000
	v_mul_f32_e32 v8, v138, v8                                 // 000000132530: 1010118A
	global_load_u16 v16, v[16:17], off offset:960              // 000000132534: DC4A03C0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000013253C: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 000000132540: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132544: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 000000132548: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 000000132550: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000013255C: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000132560: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 000000132564: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 000000132568: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 000000132570: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132578: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000013257C: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 000000132580: 7E241113
	v_exp_f32_e32 v17, v17                                     // 000000132584: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132588: BF870095
	.long 0xd71c0011                                           // 00000013258C: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 000000132590: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 000000132594: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 000000132598: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001325A0: BF870092
	v_cndmask_b32_e32 v16, 0x7f800000, v17, vcc_lo             // 0000001325A4: 022022FF 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 0000001325AC: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001325B0: BF870091
	v_div_scale_f32 v17, null, v16, v16, v8                    // 0000001325B4: D6FC7C11 04222110
	v_rcp_f32_e32 v18, v17                                     // 0000001325BC: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001325C0: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 0000001325C4: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 0000001325CC: 56242513
	v_div_scale_f32 v19, vcc_lo, v8, v16, v8                   // 0000001325D0: D6FC6A13 04222108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001325D8: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 0000001325DC: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 0000001325E0: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001325E8: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 0000001325EC: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 0000001325F0: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001325F8: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 0000001325FC: D6370011 04522511
	v_div_fixup_f32 v8, v17, v16, v8                           // 000000132604: D6270008 04222111
	v_mad_i64_i32 v[16:17], null, 0x3000, v140, v[128:129]     // 00000013260C: D6FF7C10 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132618: BF870092
	v_bfe_u32 v18, v8, 16, 1                                   // 00000013261C: D6100012 02052108
	v_add3_u32 v8, v8, v18, 0x7fff                             // 000000132624: D6550008 03FE2508 00007FFF
	global_store_d16_hi_b16 v[16:17], v8, off offset:448       // 000000132630: DC9601C0 007C0810
	s_or_b32 exec_lo, exec_lo, s8                              // 000000132638: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000013263C: BE882001
	s_cbranch_execz 57861                                      // 000000132640: BFA5E205 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3958>
	v_mad_i64_i32 v[16:17], null, 0x6000, v120, v[130:131]     // 000000132644: D6FF7C10 060AF0FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 000000132650: 1012138B
	global_load_u16 v8, v[16:17], off offset:960               // 000000132654: DC4A03C0 087C0010
	s_waitcnt vmcnt(0)                                         // 00000013265C: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 000000132660: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132664: BF870121
	v_mul_f32_e32 v16, 0xbfb8aa3b, v8                          // 000000132668: 102010FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 000000132670: 7C3C10FF 42CE8ED0
	v_fma_f32 v17, 0xbfb8aa3b, v8, -v16                        // 000000132678: D6130011 844210FF BFB8AA3B
	v_rndne_f32_e32 v18, v16                                   // 000000132684: 7E244710
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000132688: BF870112
	v_fmamk_f32 v17, v8, 0xb2a5705f, v17                       // 00000013268C: 58222308 B2A5705F
	v_sub_f32_e32 v16, v16, v18                                // 000000132694: 08202510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132698: BF870121
	v_add_f32_e32 v16, v16, v17                                // 00000013269C: 06202310
	v_cvt_i32_f32_e32 v17, v18                                 // 0000001326A0: 7E221112
	v_exp_f32_e32 v16, v16                                     // 0000001326A4: 7E204B10
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001326A8: BF870095
	.long 0xd71c0010                                           // 0000001326AC: D71C0010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                     // 0000001326B0: 02022310
	v_cndmask_b32_e32 v16, 0, v16, vcc_lo                      // 0000001326B4: 02202080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 0000001326B8: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001326C0: BF870092
	v_cndmask_b32_e32 v8, 0x7f800000, v16, vcc_lo              // 0000001326C4: 021020FF 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 0000001326CC: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001326D0: BF870091
	v_div_scale_f32 v16, null, v8, v8, v9                      // 0000001326D4: D6FC7C10 04261108
	v_rcp_f32_e32 v17, v16                                     // 0000001326DC: 7E225510
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001326E0: BF870095
	v_fma_f32 v18, -v16, v17, 1.0                              // 0000001326E4: D6130012 23CA2310
	v_fmac_f32_e32 v17, v18, v17                               // 0000001326EC: 56222312
	v_div_scale_f32 v18, vcc_lo, v9, v8, v9                    // 0000001326F0: D6FC6A12 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001326F8: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 0000001326FC: 10262312
	v_fma_f32 v20, -v16, v19, v18                              // 000000132700: D6130014 244A2710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132708: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 00000013270C: 56262314
	v_fma_f32 v16, -v16, v19, v18                              // 000000132710: D6130010 244A2710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132718: BF870091
	v_div_fmas_f32 v16, v16, v17, v19                          // 00000013271C: D6370010 044E2310
	v_div_fixup_f32 v16, v16, v8, v9                           // 000000132724: D6270010 04261110
	v_mad_i64_i32 v[8:9], null, 0x3000, v120, v[128:129]       // 00000013272C: D6FF7C08 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132738: BF870092
	v_bfe_u32 v17, v16, 16, 1                                  // 00000013273C: D6100011 02052110
	v_add3_u32 v16, v16, v17, 0x7fff                           // 000000132744: D6550010 03FE2310 00007FFF
	global_store_d16_hi_b16 v[8:9], v16, off offset:448        // 000000132750: DC9601C0 007C1008
	s_or_b32 exec_lo, exec_lo, s8                              // 000000132758: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000013275C: BE882002
	s_cbranch_execz 57792                                      // 000000132760: BFA5E1C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3964>
	v_mad_i64_i32 v[8:9], null, 0x6000, v121, v[130:131]       // 000000132764: D6FF7C08 060AF2FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 000000132770: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 000000132778: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000013277C: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132780: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 000000132784: 101210FF BFB8AA3B
	v_fma_f32 v16, 0xbfb8aa3b, v8, -v9                         // 00000013278C: D6130010 842610FF BFB8AA3B
	v_rndne_f32_e32 v17, v9                                    // 000000132798: 7E224709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013279C: BF870221
	v_sub_f32_e32 v9, v9, v17                                  // 0000001327A0: 08122309
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 0000001327A4: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v16, v8, 0xb2a5705f, v16                       // 0000001327AC: 58202108 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001327B4: BF870121
	v_add_f32_e32 v9, v9, v16                                  // 0000001327B8: 06122109
	v_cvt_i32_f32_e32 v16, v17                                 // 0000001327BC: 7E201111
	v_exp_f32_e32 v9, v9                                       // 0000001327C0: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001327C4: BF870095
	.long 0xd71c0009                                           // 0000001327C8: D71C0009
	v_cndmask_b32_e32 v1, v9, v16, vcc_lo                      // 0000001327CC: 02022109
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 0000001327D0: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 0000001327D4: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001327DC: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v136, v10// 0000001327E0: CA4612FF 08081588 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 0000001327EC: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001327F0: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 0000001327F4: D6FC7C0A 04261108
	v_rcp_f32_e32 v16, v10                                     // 0000001327FC: 7E20550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132800: BF870095
	v_fma_f32 v17, -v10, v16, 1.0                              // 000000132804: D6130011 23CA210A
	v_fmac_f32_e32 v16, v17, v16                               // 00000013280C: 56202111
	v_div_scale_f32 v17, vcc_lo, v9, v8, v9                    // 000000132810: D6FC6A11 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132818: BF870091
	v_mul_f32_e32 v18, v17, v16                                // 00000013281C: 10242111
	v_fma_f32 v19, -v10, v18, v17                              // 000000132820: D6130013 2446250A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132828: BF870091
	v_fmac_f32_e32 v18, v19, v16                               // 00000013282C: 56242113
	v_fma_f32 v10, -v10, v18, v17                              // 000000132830: D613000A 2446250A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132838: BF870091
	v_div_fmas_f32 v10, v10, v16, v18                          // 00000013283C: D637000A 044A210A
	v_div_fixup_f32 v10, v10, v8, v9                           // 000000132844: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v121, v[128:129]       // 00000013284C: D6FF7C08 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132858: BF870092
	v_bfe_u32 v16, v10, 16, 1                                  // 00000013285C: D6100010 0205210A
	v_add3_u32 v10, v10, v16, 0x7fff                           // 000000132864: D655000A 03FE210A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 000000132870: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 000000132878: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000013287C: BE882003
	s_cbranch_execz 57723                                      // 000000132880: BFA5E17B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3970>
	v_mad_i64_i32 v[8:9], null, 0x6000, v122, v[130:131]       // 000000132884: D6FF7C08 060AF4FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 000000132890: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 000000132898: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000013289C: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001328A0: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 0000001328A4: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 0000001328AC: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v16, v9                                    // 0000001328B8: 7E204709
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001328BC: BF870091
	v_dual_fmamk_f32 v10, v8, 0xb2a5705f, v10 :: v_dual_sub_f32 v9, v9, v16// 0000001328C0: C88A1508 0A082109 B2A5705F
	v_add_f32_e32 v9, v9, v10                                  // 0000001328CC: 06121509
	v_cvt_i32_f32_e32 v10, v16                                 // 0000001328D0: 7E141110
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 0000001328D4: 7C3C10FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001328DC: BF870293
	v_exp_f32_e32 v9, v9                                       // 0000001328E0: 7E124B09
	.long 0xd71c0009                                           // 0000001328E4: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 0000001328E8: 02021509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001328EC: BF870121
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 0000001328F0: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 0000001328F4: 7C3610FF C2B17218
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v137, v11// 0000001328FC: CA4612FF 08081789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132908: BF870091
	v_add_f32_e32 v8, 1.0, v8                                  // 00000013290C: 061010F2
	v_div_scale_f32 v10, null, v8, v8, v9                      // 000000132910: D6FC7C0A 04261108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000132918: BF870291
	v_rcp_f32_e32 v11, v10                                     // 00000013291C: 7E16550A
	v_fma_f32 v16, -v10, v11, 1.0                              // 000000132920: D6130010 23CA170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000132928: BF8700A1
	v_fmac_f32_e32 v11, v16, v11                               // 00000013292C: 56161710
	v_div_scale_f32 v16, vcc_lo, v9, v8, v9                    // 000000132930: D6FC6A10 04261109
	v_mul_f32_e32 v17, v16, v11                                // 000000132938: 10221710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013293C: BF870091
	v_fma_f32 v18, -v10, v17, v16                              // 000000132940: D6130012 2442230A
	v_fmac_f32_e32 v17, v18, v11                               // 000000132948: 56221712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013294C: BF870091
	v_fma_f32 v10, -v10, v17, v16                              // 000000132950: D613000A 2442230A
	v_div_fmas_f32 v10, v10, v11, v17                          // 000000132958: D637000A 0446170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132960: BF870121
	v_div_fixup_f32 v10, v10, v8, v9                           // 000000132964: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v122, v[128:129]       // 00000013296C: D6FF7C08 0602F4FF 00003000
	v_bfe_u32 v11, v10, 16, 1                                  // 000000132978: D610000B 0205210A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000132980: BF870001
	v_add3_u32 v10, v10, v11, 0x7fff                           // 000000132984: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 000000132990: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 000000132998: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000013299C: BE882004
	s_cbranch_execz 57654                                      // 0000001329A0: BFA5E136 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x397c>
	v_mad_i64_i32 v[8:9], null, 0x6000, v123, v[130:131]       // 0000001329A4: D6FF7C08 060AF6FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 0000001329B0: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 0000001329B8: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 0000001329BC: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001329C0: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 0000001329C4: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 0000001329CC: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 0000001329D8: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001329DC: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 0000001329E0: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 0000001329E4: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 0000001329EC: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001329F4: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 0000001329F8: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 0000001329FC: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 000000132A00: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132A04: BF870095
	.long 0xd71c0009                                           // 000000132A08: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000132A0C: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 000000132A10: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 000000132A14: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132A1C: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v134, v12// 000000132A20: CA4612FF 08081986 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 000000132A2C: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132A30: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 000000132A34: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 000000132A3C: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132A40: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 000000132A44: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 000000132A4C: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 000000132A50: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132A58: BF870091
	v_mul_f32_e32 v16, v12, v11                                // 000000132A5C: 1020170C
	v_fma_f32 v17, -v10, v16, v12                              // 000000132A60: D6130011 2432210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132A68: BF870091
	v_fmac_f32_e32 v16, v17, v11                               // 000000132A6C: 56201711
	v_fma_f32 v10, -v10, v16, v12                              // 000000132A70: D613000A 2432210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132A78: BF870091
	v_div_fmas_f32 v10, v10, v11, v16                          // 000000132A7C: D637000A 0442170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 000000132A84: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v123, v[128:129]       // 000000132A8C: D6FF7C08 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132A98: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 000000132A9C: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 000000132AA4: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 000000132AB0: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 000000132AB8: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000132ABC: BE882005
	s_cbranch_execz 57585                                      // 000000132AC0: BFA5E0F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3988>
	v_mad_i64_i32 v[8:9], null, 0x6000, v124, v[130:131]       // 000000132AC4: D6FF7C08 060AF8FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 000000132AD0: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 000000132AD8: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 000000132ADC: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132AE0: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 000000132AE4: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 000000132AEC: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 000000132AF8: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000132AFC: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 000000132B00: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 000000132B04: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 000000132B0C: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132B14: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 000000132B18: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 000000132B1C: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 000000132B20: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132B24: BF870095
	.long 0xd71c0009                                           // 000000132B28: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000132B2C: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 000000132B30: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 000000132B34: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132B3C: BF870092
	v_cndmask_b32_e32 v8, 0x7f800000, v9, vcc_lo               // 000000132B40: 021012FF 7F800000
	v_dual_mul_f32 v9, v135, v13 :: v_dual_add_f32 v8, 1.0, v8 // 000000132B48: C8C81B87 090810F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132B50: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 000000132B54: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 000000132B5C: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132B60: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 000000132B64: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 000000132B6C: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 000000132B70: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132B78: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 000000132B7C: 101A170C
	v_fma_f32 v16, -v10, v13, v12                              // 000000132B80: D6130010 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132B88: BF870091
	v_fmac_f32_e32 v13, v16, v11                               // 000000132B8C: 561A1710
	v_fma_f32 v10, -v10, v13, v12                              // 000000132B90: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132B98: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 000000132B9C: D637000A 0436170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 000000132BA4: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v124, v[128:129]       // 000000132BAC: D6FF7C08 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132BB8: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 000000132BBC: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 000000132BC4: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 000000132BD0: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 000000132BD8: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000132BDC: BE882006
	s_cbranch_execz 57516                                      // 000000132BE0: BFA5E0AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3994>
	v_mad_i64_i32 v[8:9], null, 0x6000, v125, v[130:131]       // 000000132BE4: D6FF7C08 060AFAFF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 000000132BF0: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 000000132BF8: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 000000132BFC: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132C00: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 000000132C04: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 000000132C0C: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 000000132C18: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000132C1C: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 000000132C20: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 000000132C24: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 000000132C2C: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132C34: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 000000132C38: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 000000132C3C: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 000000132C40: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132C44: BF870095
	.long 0xd71c0009                                           // 000000132C48: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000132C4C: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 000000132C50: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 000000132C54: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132C5C: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v132, v14// 000000132C60: CA4612FF 08081D84 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 000000132C6C: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132C70: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 000000132C74: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 000000132C7C: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132C80: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 000000132C84: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 000000132C8C: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 000000132C90: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132C98: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 000000132C9C: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 000000132CA0: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132CA8: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 000000132CAC: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 000000132CB0: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132CB8: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 000000132CBC: D637000A 0436170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 000000132CC4: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v125, v[128:129]       // 000000132CCC: D6FF7C08 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132CD8: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 000000132CDC: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 000000132CE4: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 000000132CF0: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 000000132CF8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000132CFC: BE882007
	s_cbranch_execz 57447                                      // 000000132D00: BFA5E067 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39a0>
	v_mad_i64_i32 v[8:9], null, 0x6000, v126, v[130:131]       // 000000132D04: D6FF7C08 060AFCFF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 000000132D10: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 000000132D18: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 000000132D1C: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132D20: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 000000132D24: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 000000132D2C: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 000000132D38: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000132D3C: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 000000132D40: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 000000132D44: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 000000132D4C: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132D54: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 000000132D58: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 000000132D5C: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 000000132D60: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132D64: BF870095
	.long 0xd71c0009                                           // 000000132D68: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000132D6C: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 000000132D70: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 000000132D74: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132D7C: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v133, v15// 000000132D80: CA4612FF 08081F85 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 000000132D8C: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132D90: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 000000132D94: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 000000132D9C: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132DA0: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 000000132DA4: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 000000132DAC: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 000000132DB0: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132DB8: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 000000132DBC: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 000000132DC0: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132DC8: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 000000132DCC: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 000000132DD0: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132DD8: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 000000132DDC: D637000A 0436170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 000000132DE4: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v126, v[128:129]       // 000000132DEC: D6FF7C08 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132DF8: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 000000132DFC: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 000000132E04: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 000000132E10: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 000000132E18: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000132E1C: BE882000
	s_cbranch_execz 57378                                      // 000000132E20: BFA5E022 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39ac>
	v_mad_i64_i32 v[8:9], null, 0x6000, v140, v[130:131]       // 000000132E24: D6FF7C08 060B18FF 00006000
	v_mul_f32_e32 v0, v138, v0                                 // 000000132E30: 1000018A
	global_load_u16 v8, v[8:9], off offset:992                 // 000000132E34: DC4A03E0 087C0008
	s_waitcnt vmcnt(0)                                         // 000000132E3C: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 000000132E40: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132E44: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 000000132E48: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 000000132E50: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 000000132E5C: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000132E60: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 000000132E64: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 000000132E68: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 000000132E70: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132E78: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 000000132E7C: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 000000132E80: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 000000132E84: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132E88: BF870095
	.long 0xd71c0009                                           // 000000132E8C: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 000000132E90: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 000000132E94: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 000000132E98: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132EA0: BF870092
	v_cndmask_b32_e32 v8, 0x7f800000, v9, vcc_lo               // 000000132EA4: 021012FF 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 000000132EAC: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132EB0: BF870091
	v_div_scale_f32 v9, null, v8, v8, v0                       // 000000132EB4: D6FC7C09 04021108
	v_rcp_f32_e32 v10, v9                                      // 000000132EBC: 7E145509
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132EC0: BF870095
	v_fma_f32 v11, -v9, v10, 1.0                               // 000000132EC4: D613000B 23CA1509
	v_fmac_f32_e32 v10, v11, v10                               // 000000132ECC: 5614150B
	v_div_scale_f32 v11, vcc_lo, v0, v8, v0                    // 000000132ED0: D6FC6A0B 04021100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132ED8: BF870091
	v_mul_f32_e32 v12, v11, v10                                // 000000132EDC: 1018150B
	v_fma_f32 v13, -v9, v12, v11                               // 000000132EE0: D613000D 242E1909
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132EE8: BF870091
	v_fmac_f32_e32 v12, v13, v10                               // 000000132EEC: 5618150D
	v_fma_f32 v9, -v9, v12, v11                                // 000000132EF0: D6130009 242E1909
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132EF8: BF870091
	v_div_fmas_f32 v9, v9, v10, v12                            // 000000132EFC: D6370009 04321509
	v_div_fixup_f32 v0, v9, v8, v0                             // 000000132F04: D6270000 04021109
	v_mad_i64_i32 v[8:9], null, 0x3000, v140, v[128:129]       // 000000132F0C: D6FF7C08 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132F18: BF870092
	v_bfe_u32 v10, v0, 16, 1                                   // 000000132F1C: D610000A 02052100
	v_add3_u32 v0, v0, v10, 0x7fff                             // 000000132F24: D6550000 03FE1500 00007FFF
	global_store_d16_hi_b16 v[8:9], v0, off offset:480         // 000000132F30: DC9601E0 007C0008
	s_or_b32 exec_lo, exec_lo, s8                              // 000000132F38: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000132F3C: BE802001
	s_cbranch_execz 57309                                      // 000000132F40: BFA5DFDD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39b8>
	v_mad_i64_i32 v[8:9], null, 0x6000, v120, v[130:131]       // 000000132F44: D6FF7C08 060AF0FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 000000132F50: 1002038B
	global_load_u16 v0, v[8:9], off offset:992                 // 000000132F54: DC4A03E0 007C0008
	s_waitcnt vmcnt(0)                                         // 000000132F5C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 000000132F60: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132F64: BF870121
	v_mul_f32_e32 v8, 0xbfb8aa3b, v0                           // 000000132F68: 101000FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000132F70: 7C3C00FF 42CE8ED0
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v8                          // 000000132F78: D6130009 842200FF BFB8AA3B
	v_rndne_f32_e32 v10, v8                                    // 000000132F84: 7E144708
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000132F88: BF870112
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 000000132F8C: 58121300 B2A5705F
	v_sub_f32_e32 v8, v8, v10                                  // 000000132F94: 08101508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000132F98: BF870121
	v_add_f32_e32 v8, v8, v9                                   // 000000132F9C: 06101308
	v_cvt_i32_f32_e32 v9, v10                                  // 000000132FA0: 7E12110A
	v_exp_f32_e32 v8, v8                                       // 000000132FA4: 7E104B08
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132FA8: BF870095
	.long 0xd71c0008                                           // 000000132FAC: D71C0008
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 000000132FB0: 02021308
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo                        // 000000132FB4: 02101080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000132FB8: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132FC0: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v8, vcc_lo               // 000000132FC4: 020010FF 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 000000132FCC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132FD0: BF870091
	v_div_scale_f32 v8, null, v0, v0, v1                       // 000000132FD4: D6FC7C08 04060100
	v_rcp_f32_e32 v9, v8                                       // 000000132FDC: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132FE0: BF870095
	v_fma_f32 v10, -v8, v9, 1.0                                // 000000132FE4: D613000A 23CA1308
	v_fmac_f32_e32 v9, v10, v9                                 // 000000132FEC: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 000000132FF0: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000132FF8: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 000000132FFC: 1016130A
	v_fma_f32 v12, -v8, v11, v10                               // 000000133000: D613000C 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133008: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 00000013300C: 5616130C
	v_fma_f32 v8, -v8, v11, v10                                // 000000133010: D6130008 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133018: BF870091
	v_div_fmas_f32 v8, v8, v9, v11                             // 00000013301C: D6370008 042E1308
	v_div_fixup_f32 v8, v8, v0, v1                             // 000000133024: D6270008 04060108
	v_mad_i64_i32 v[0:1], null, 0x3000, v120, v[128:129]       // 00000013302C: D6FF7C00 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133038: BF870092
	v_bfe_u32 v9, v8, 16, 1                                    // 00000013303C: D6100009 02052108
	v_add3_u32 v8, v8, v9, 0x7fff                              // 000000133044: D6550008 03FE1308 00007FFF
	global_store_d16_hi_b16 v[0:1], v8, off offset:480         // 000000133050: DC9601E0 007C0800
	s_or_b32 exec_lo, exec_lo, s0                              // 000000133058: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000013305C: BE802002
	s_cbranch_execz 57240                                      // 000000133060: BFA5DF98 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39c4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[130:131]       // 000000133064: D6FF7C00 060AF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000133070: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000133078: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000013307C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133080: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000133084: 100200FF BFB8AA3B
	v_fma_f32 v8, 0xbfb8aa3b, v0, -v1                          // 00000013308C: D6130008 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 000000133098: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013309C: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 0000001330A0: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000001330A4: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v8, v0, 0xb2a5705f, v8                         // 0000001330AC: 58101100 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001330B4: BF870121
	v_add_f32_e32 v1, v1, v8                                   // 0000001330B8: 06021101
	v_cvt_i32_f32_e32 v8, v9                                   // 0000001330BC: 7E101109
	v_exp_f32_e32 v1, v1                                       // 0000001330C0: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001330C4: BF870095
	.long 0xd71c0001                                           // 0000001330C8: D71C0001
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 0000001330CC: 02021101
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000001330D0: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000001330D4: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001330DC: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v2// 0000001330E0: CA4602FF 00000588 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 0000001330EC: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001330F0: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 0000001330F4: D6FC7C02 04060100
	v_rcp_f32_e32 v8, v2                                       // 0000001330FC: 7E105502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133100: BF870095
	v_fma_f32 v9, -v2, v8, 1.0                                 // 000000133104: D6130009 23CA1102
	v_fmac_f32_e32 v8, v9, v8                                  // 00000013310C: 56101109
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 000000133110: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133118: BF870091
	v_mul_f32_e32 v10, v9, v8                                  // 00000013311C: 10141109
	v_fma_f32 v11, -v2, v10, v9                                // 000000133120: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133128: BF870091
	v_fmac_f32_e32 v10, v11, v8                                // 00000013312C: 5614110B
	v_fma_f32 v2, -v2, v10, v9                                 // 000000133130: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133138: BF870091
	v_div_fmas_f32 v2, v2, v8, v10                             // 00000013313C: D6370002 042A1102
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000133144: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[128:129]       // 00000013314C: D6FF7C00 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133158: BF870092
	v_bfe_u32 v8, v2, 16, 1                                    // 00000013315C: D6100008 02052102
	v_add3_u32 v2, v2, v8, 0x7fff                              // 000000133164: D6550002 03FE1102 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000133170: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000133178: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000013317C: BE802003
	s_cbranch_execz 57171                                      // 000000133180: BFA5DF53 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39d0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[130:131]       // 000000133184: D6FF7C00 060AF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000133190: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000133198: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000013319C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001331A0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000001331A4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000001331AC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v8, v1                                     // 0000001331B8: 7E104701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001331BC: BF870091
	v_dual_fmamk_f32 v2, v0, 0xb2a5705f, v2 :: v_dual_sub_f32 v1, v1, v8// 0000001331C0: C88A0500 02001101 B2A5705F
	v_add_f32_e32 v1, v1, v2                                   // 0000001331CC: 06020501
	v_cvt_i32_f32_e32 v2, v8                                   // 0000001331D0: 7E041108
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000001331D4: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001331DC: BF870293
	v_exp_f32_e32 v1, v1                                       // 0000001331E0: 7E024B01
	.long 0xd71c0001                                           // 0000001331E4: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 0000001331E8: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001331EC: BF870121
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000001331F0: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 0000001331F4: 7C3600FF C2B17218
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 0000001331FC: CA4602FF 00000789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133208: BF870091
	v_add_f32_e32 v0, 1.0, v0                                  // 00000013320C: 060000F2
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000133210: D6FC7C02 04060100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000133218: BF870291
	v_rcp_f32_e32 v3, v2                                       // 00000013321C: 7E065502
	v_fma_f32 v8, -v2, v3, 1.0                                 // 000000133220: D6130008 23CA0702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000133228: BF8700A1
	v_fmac_f32_e32 v3, v8, v3                                  // 00000013322C: 56060708
	v_div_scale_f32 v8, vcc_lo, v1, v0, v1                     // 000000133230: D6FC6A08 04060101
	v_mul_f32_e32 v9, v8, v3                                   // 000000133238: 10120708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013323C: BF870091
	v_fma_f32 v10, -v2, v9, v8                                 // 000000133240: D613000A 24221302
	v_fmac_f32_e32 v9, v10, v3                                 // 000000133248: 5612070A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013324C: BF870091
	v_fma_f32 v2, -v2, v9, v8                                  // 000000133250: D6130002 24221302
	v_div_fmas_f32 v2, v2, v3, v9                              // 000000133258: D6370002 04260702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000133260: BF870121
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000133264: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[128:129]       // 00000013326C: D6FF7C00 0602F4FF 00003000
	v_bfe_u32 v3, v2, 16, 1                                    // 000000133278: D6100003 02052102
	s_delay_alu instid0(VALU_DEP_1)                            // 000000133280: BF870001
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000133284: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000133290: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 000000133298: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000013329C: BE802004
	s_cbranch_execz 57102                                      // 0000001332A0: BFA5DF0E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39dc>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[130:131]       // 0000001332A4: D6FF7C00 060AF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000001332B0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000001332B8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000001332BC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001332C0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000001332C4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000001332CC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000001332D8: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001332DC: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 0000001332E0: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 0000001332E4: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 0000001332EC: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001332F4: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 0000001332F8: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 0000001332FC: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000133300: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133304: BF870095
	.long 0xd71c0001                                           // 000000133308: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000013330C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000133310: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000133314: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013331C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v4// 000000133320: CA4602FF 00000986 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000013332C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133330: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000133334: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000013333C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133340: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000133344: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000013334C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000133350: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133358: BF870091
	v_mul_f32_e32 v8, v4, v3                                   // 00000013335C: 10100704
	v_fma_f32 v9, -v2, v8, v4                                  // 000000133360: D6130009 24121102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133368: BF870091
	v_fmac_f32_e32 v8, v9, v3                                  // 00000013336C: 56100709
	v_fma_f32 v2, -v2, v8, v4                                  // 000000133370: D6130002 24121102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133378: BF870091
	v_div_fmas_f32 v2, v2, v3, v8                              // 00000013337C: D6370002 04220702
	v_div_fixup_f32 v2, v2, v0, v1                             // 000000133384: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[128:129]       // 00000013338C: D6FF7C00 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133398: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000013339C: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000001333A4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001333B0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001333B8: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000001333BC: BE802005
	s_cbranch_execz 57033                                      // 0000001333C0: BFA5DEC9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39e8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[130:131]       // 0000001333C4: D6FF7C00 060AF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000001333D0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000001333D8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000001333DC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001333E0: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 0000001333E4: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 0000001333EC: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 0000001333F8: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001333FC: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000133400: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000133404: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000013340C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000133414: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000133418: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000013341C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000133420: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133424: BF870095
	.long 0xd71c0001                                           // 000000133428: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000013342C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000133430: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000133434: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013343C: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 000000133440: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 000000133448: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133450: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000133454: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000013345C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133460: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000133464: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000013346C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000133470: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133478: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000013347C: 100A0704
	v_fma_f32 v8, -v2, v5, v4                                  // 000000133480: D6130008 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133488: BF870091
	v_fmac_f32_e32 v5, v8, v3                                  // 00000013348C: 560A0708
	v_fma_f32 v2, -v2, v5, v4                                  // 000000133490: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133498: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000013349C: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000001334A4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[128:129]       // 0000001334AC: D6FF7C00 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001334B8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000001334BC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000001334C4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001334D0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001334D8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000001334DC: BE802006
	s_cbranch_execz 56964                                      // 0000001334E0: BFA5DE84 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x39f4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[130:131]       // 0000001334E4: D6FF7C00 060AFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 0000001334F0: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 0000001334F8: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 0000001334FC: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133500: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000133504: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000013350C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000133518: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013351C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000133520: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000133524: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000013352C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000133534: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000133538: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000013353C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000133540: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133544: BF870095
	.long 0xd71c0001                                           // 000000133548: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000013354C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000133550: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000133554: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013355C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v132, v6// 000000133560: CA4602FF 00000D84 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000013356C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133570: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000133574: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000013357C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133580: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 000000133584: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000013358C: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 000000133590: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133598: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000013359C: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000001335A0: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001335A8: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000001335AC: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000001335B0: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001335B8: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000001335BC: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000001335C4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[128:129]       // 0000001335CC: D6FF7C00 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001335D8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000001335DC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 0000001335E4: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 0000001335F0: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001335F8: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001335FC: BE802007
	s_cbranch_execz 56895                                      // 000000133600: BFA5DE3F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi6ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a00>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[130:131]       // 000000133604: D6FF7C00 060AFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 000000133610: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 000000133618: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000013361C: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133620: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 000000133624: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000013362C: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 000000133638: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000013363C: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 000000133640: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 000000133644: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000013364C: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000133654: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 000000133658: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000013365C: 7E041103
	v_exp_f32_e32 v1, v1                                       // 000000133660: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133664: BF870095
	.long 0xd71c0001                                           // 000000133668: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000013366C: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 000000133670: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 000000133674: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013367C: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 000000133680: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000013368C: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000133690: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 000000133694: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000013369C: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001336A0: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 0000001336A4: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 0000001336AC: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 0000001336B0: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001336B8: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 0000001336BC: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 0000001336C0: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001336C8: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 0000001336CC: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 0000001336D0: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001336D8: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 0000001336DC: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 0000001336E4: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[128:129]       // 0000001336EC: D6FF7C00 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001336F8: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 0000001336FC: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 000000133704: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 000000133710: DC9601E0 007C0200
	s_endpgm                                                   // 000000133718: BFB00000
		...

