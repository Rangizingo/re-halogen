000000000017e800 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i():
	s_load_b256 s[4:11], s[0:1], 0x20                          // 00000017E800: F40C0100 F8000020
	s_mov_b32 s20, s3                                          // 00000017E808: BE940003
	s_ashr_i32 s3, s2, 31                                      // 00000017E80C: 86039F02
	s_mov_b32 s23, exec_lo                                     // 00000017E810: BE97007E
	s_waitcnt lgkmcnt(0)                                       // 00000017E814: BF89FC07
	s_load_b32 s21, s[8:9], null                               // 00000017E818: F4000544 F8000000
	s_load_b128 s[16:19], s[0:1], 0x40                         // 00000017E820: F4080400 F8000040
	s_lshl_b64 s[8:9], s[2:3], 2                               // 00000017E828: 84888202
	s_waitcnt lgkmcnt(0)                                       // 00000017E82C: BF89FC07
	s_add_i32 s21, s21, s2                                     // 00000017E830: 81150215
	s_add_u32 s8, s18, s8                                      // 00000017E834: 80080812
	s_addc_u32 s9, s19, s9                                     // 00000017E838: 82090913
	s_add_i32 s18, s21, 1                                      // 00000017E83C: 81128115
	s_load_b32 s3, s[8:9], null                                // 00000017E840: F40000C4 F8000000
	s_load_b256 s[8:15], s[0:1], null                          // 00000017E848: F40C0200 F8000000
	s_ashr_i32 s19, s18, 31                                    // 00000017E850: 86139F12
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000017E854: BF870499
	s_lshr_b32 s19, s19, 30                                    // 00000017E858: 85139E13
	s_add_i32 s22, s18, s19                                    // 00000017E85C: 81161312
	s_waitcnt lgkmcnt(0)                                       // 00000017E860: BF89FC07
	s_lshl_b32 s19, s3, 2                                      // 00000017E864: 84138203
	s_and_b32 s3, s22, -4                                      // 00000017E868: 8B03C416
	s_add_i32 s18, s18, s19                                    // 00000017E86C: 81121312
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000017E870: BF870499
	s_sub_i32 s18, s18, s3                                     // 00000017E874: 81920312
	s_add_i32 s22, s18, 16                                     // 00000017E878: 81169012
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017E87C: BF870009
	.long 0xd4c4007e                                           // 00000017E880: D4C4007E
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 00000017E884: 02020016
	s_cbranch_execz 62                                         // 00000017E888: BFA5003E <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x184>
	s_load_b32 s25, s[0:1], 0x50                               // 00000017E88C: F4000640 F8000050
	v_and_b32_e32 v1, 0x7c, v0                                 // 00000017E894: 360200FF 0000007C
	s_sub_i32 s24, s3, s19                                     // 00000017E89C: 81981303
	v_and_b32_e32 v3, 3, v0                                    // 00000017E8A0: 36060083
	v_dual_mov_b32 v5, v0 :: v_dual_lshlrev_b32 v4, 2, v0      // 00000017E8A4: CA220100 05040082
	s_waitcnt lgkmcnt(0)                                       // 00000017E8AC: BF89FC07
	s_mul_hi_i32 s27, s2, s25                                  // 00000017E8B0: 971B1902
	s_mul_i32 s26, s2, s25                                     // 00000017E8B4: 961A1902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000017E8B8: BF870499
	s_lshl_b64 s[26:27], s[26:27], 2                           // 00000017E8BC: 849A821A
	s_add_u32 s3, s16, s26                                     // 00000017E8C0: 80031A10
	s_addc_u32 s16, s17, s27                                   // 00000017E8C4: 82101B11
	.long 0xd7000301                                           // 00000017E8C8: D7000301
	v_cndmask_b32_e32 v1, s3, v1, vcc_lo                       // 00000017E8CC: 02020203
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017E8D0: BF870001
	v_add_co_ci_u32_e64 v2, null, s16, 0, s3                   // 00000017E8D4: D5207C02 000D0010
	s_mov_b32 s16, 0                                           // 00000017E8DC: BE900080
	s_set_inst_prefetch_distance 0x1                           // 00000017E8E0: BF840001
	s_branch 23                                                // 00000017E8E4: BFA00017 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x144>
	s_nop 0                                                    // 00000017E8E8: BF800000
	s_nop 0                                                    // 00000017E8EC: BF800000
	s_nop 0                                                    // 00000017E8F0: BF800000
	s_nop 0                                                    // 00000017E8F4: BF800000
	s_nop 0                                                    // 00000017E8F8: BF800000
	s_nop 0                                                    // 00000017E8FC: BF800000
	s_or_b32 exec_lo, exec_lo, s3                              // 00000017E900: 8C7E037E
	v_add_nc_u32_e32 v5, 0x80, v5                              // 00000017E904: 4A0A0AFF 00000080
	.long 0xd7000301                                           // 00000017E90C: D7000301
	v_cndmask_b32_e32 v1, 0x80, v1, vcc_lo                     // 00000017E910: 020202FF 00000080
	ds_store_b32 v4, v6 offset:51200                           // 00000017E918: D834C800 00000604
	v_add_co_ci_u32_e64 v2, null, 0, v2, s3                    // 00000017E920: D5207C02 000E0480
	v_cmp_le_i32_e32 vcc_lo, s22, v5                           // 00000017E928: 7C860A16
	v_add_nc_u32_e32 v4, 0x200, v4                             // 00000017E92C: 4A0808FF 00000200
	s_or_b32 s16, vcc_lo, s16                                  // 00000017E934: 8C10106A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017E938: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s16                       // 00000017E93C: 917E107E
	s_cbranch_execz 16                                         // 00000017E940: BFA50010 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x184>
	s_mov_b32 s3, exec_lo                                      // 00000017E944: BE83007E
	.long 0xd4c3007e                                           // 00000017E948: D4C3007E
	v_cndmask_b32_e32 v1, s19, v5, vcc_lo                      // 00000017E94C: 02020A13
	s_xor_b32 s3, exec_lo, s3                                  // 00000017E950: 8D03037E
	v_add_nc_u32_e32 v6, s24, v5                               // 00000017E954: 4A0C0A18
	v_cmp_gt_i32_e32 vcc_lo, s18, v5                           // 00000017E958: 7C880A12
	s_delay_alu instid0(VALU_DEP_2)                            // 00000017E95C: BF870002
	v_cndmask_b32_e32 v6, s21, v6, vcc_lo                      // 00000017E960: 020C0C15
	s_and_not1_saveexec_b32 s3, s3                             // 00000017E964: BE833003
	s_cbranch_execz 65509                                      // 00000017E968: BFA5FFE5 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x100>
	global_load_b32 v6, v[1:2], off                            // 00000017E96C: DC520000 067C0001
	s_waitcnt vmcnt(0)                                         // 00000017E974: BF8903F7
	v_lshl_or_b32 v6, v6, 2, v3                                // 00000017E978: D6560006 040D0506
	s_branch 65503                                             // 00000017E980: BFA0FFDF <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x100>
	s_set_inst_prefetch_distance 0x2                           // 00000017E984: BF840002
	s_or_b32 exec_lo, exec_lo, s23                             // 00000017E988: 8C7E177E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017E98C: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000017E990: BE83007E
	v_cmpx_eq_u32_e32 0, v0                                    // 00000017E994: 7D940080
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, s18             // 00000017E998: CA100080 01020012
	ds_store_b32 v1, v2 offset:64336                           // 00000017E9A0: D834FB50 00000201
	s_or_b32 exec_lo, exec_lo, s3                              // 00000017E9A8: 8C7E037E
	v_dual_mov_b32 v6, 0 :: v_dual_and_b32 v15, 31, v0         // 00000017E9AC: CA240080 060E009F
	s_waitcnt lgkmcnt(0)                                       // 00000017E9B4: BF89FC07
	s_barrier                                                  // 00000017E9B8: BFBD0000
	buffer_gl0_inv                                             // 00000017E9BC: E0AC0000 00000000
	ds_load_b32 v7, v6 offset:64336                            // 00000017E9C4: D8D8FB50 07000006
	v_lshrrev_b32_e32 v160, 5, v0                              // 00000017E9CC: 33400085
	v_dual_mov_b32 v255, 0xf149f2ca :: v_dual_and_b32 v8, 15, v0// 00000017E9D0: CA2400FF FF08008F F149F2CA
	v_bfe_u32 v137, v0, 4, 1                                   // 00000017E9DC: D6100089 02050900
	v_mov_b32_e32 v5, v6                                       // 00000017E9E4: 7E0A0306
	v_mov_b32_e32 v4, v6                                       // 00000017E9E8: 7E080306
	v_mov_b32_e32 v3, v6                                       // 00000017E9EC: 7E060306
	v_mov_b32_e32 v2, v6                                       // 00000017E9F0: 7E040306
	v_mov_b32_e32 v1, v6                                       // 00000017E9F4: 7E020306
	v_mov_b32_e32 v14, v6                                      // 00000017E9F8: 7E1C0306
	v_mov_b32_e32 v13, v6                                      // 00000017E9FC: 7E1A0306
	v_mov_b32_e32 v12, v6                                      // 00000017EA00: 7E180306
	v_mov_b32_e32 v11, v6                                      // 00000017EA04: 7E160306
	v_mov_b32_e32 v10, v6                                      // 00000017EA08: 7E140306
	v_mov_b32_e32 v9, v6                                       // 00000017EA0C: 7E120306
	v_mov_b32_e32 v30, v6                                      // 00000017EA10: 7E3C0306
	v_mov_b32_e32 v29, v6                                      // 00000017EA14: 7E3A0306
	v_mov_b32_e32 v28, v6                                      // 00000017EA18: 7E380306
	v_mov_b32_e32 v27, v6                                      // 00000017EA1C: 7E360306
	s_waitcnt lgkmcnt(0)                                       // 00000017EA20: BF89FC07
	v_readfirstlane_b32 s3, v7                                 // 00000017EA24: 7E060507
	v_mov_b32_e32 v26, v6                                      // 00000017EA28: 7E340306
	v_mov_b32_e32 v25, v6                                      // 00000017EA2C: 7E320306
	v_mov_b32_e32 v22, v6                                      // 00000017EA30: 7E2C0306
	v_mov_b32_e32 v21, v6                                      // 00000017EA34: 7E2A0306
	s_add_i32 s3, s3, 15                                       // 00000017EA38: 81038F03
	v_mov_b32_e32 v20, v6                                      // 00000017EA3C: 7E280306
	s_ashr_i32 s16, s3, 31                                     // 00000017EA40: 86109F03
	v_mov_b32_e32 v19, v6                                      // 00000017EA44: 7E260306
	s_lshr_b32 s16, s16, 28                                    // 00000017EA48: 85109C10
	v_mov_b32_e32 v18, v6                                      // 00000017EA4C: 7E240306
	s_add_i32 s3, s3, s16                                      // 00000017EA50: 81031003
	v_mov_b32_e32 v17, v6                                      // 00000017EA54: 7E220306
	s_ashr_i32 s19, s3, 4                                      // 00000017EA58: 86138403
	v_mov_b32_e32 v46, v6                                      // 00000017EA5C: 7E5C0306
	v_cmp_gt_i32_e32 vcc_lo, s19, v160                         // 00000017EA60: 7C894013
	v_mov_b32_e32 v45, v6                                      // 00000017EA64: 7E5A0306
	v_mov_b32_e32 v44, v6                                      // 00000017EA68: 7E580306
	v_mov_b32_e32 v43, v6                                      // 00000017EA6C: 7E560306
	v_mov_b32_e32 v42, v6                                      // 00000017EA70: 7E540306
	v_mov_b32_e32 v41, v6                                      // 00000017EA74: 7E520306
	v_mov_b32_e32 v38, v6                                      // 00000017EA78: 7E4C0306
	v_mov_b32_e32 v37, v6                                      // 00000017EA7C: 7E4A0306
	v_mov_b32_e32 v36, v6                                      // 00000017EA80: 7E480306
	v_mov_b32_e32 v35, v6                                      // 00000017EA84: 7E460306
	v_mov_b32_e32 v34, v6                                      // 00000017EA88: 7E440306
	v_mov_b32_e32 v33, v6                                      // 00000017EA8C: 7E420306
	v_mov_b32_e32 v70, v6                                      // 00000017EA90: 7E8C0306
	v_mov_b32_e32 v69, v6                                      // 00000017EA94: 7E8A0306
	v_mov_b32_e32 v68, v6                                      // 00000017EA98: 7E880306
	v_mov_b32_e32 v67, v6                                      // 00000017EA9C: 7E860306
	v_mov_b32_e32 v66, v6                                      // 00000017EAA0: 7E840306
	v_mov_b32_e32 v65, v6                                      // 00000017EAA4: 7E820306
	v_mov_b32_e32 v54, v6                                      // 00000017EAA8: 7E6C0306
	v_mov_b32_e32 v53, v6                                      // 00000017EAAC: 7E6A0306
	v_mov_b32_e32 v52, v6                                      // 00000017EAB0: 7E680306
	v_mov_b32_e32 v51, v6                                      // 00000017EAB4: 7E660306
	v_mov_b32_e32 v50, v6                                      // 00000017EAB8: 7E640306
	v_mov_b32_e32 v49, v6                                      // 00000017EABC: 7E620306
	v_mov_b32_e32 v86, v6                                      // 00000017EAC0: 7EAC0306
	v_mov_b32_e32 v85, v6                                      // 00000017EAC4: 7EAA0306
	v_mov_b32_e32 v84, v6                                      // 00000017EAC8: 7EA80306
	v_mov_b32_e32 v83, v6                                      // 00000017EACC: 7EA60306
	v_mov_b32_e32 v82, v6                                      // 00000017EAD0: 7EA40306
	v_mov_b32_e32 v81, v6                                      // 00000017EAD4: 7EA20306
	v_mov_b32_e32 v62, v6                                      // 00000017EAD8: 7E7C0306
	v_mov_b32_e32 v61, v6                                      // 00000017EADC: 7E7A0306
	v_mov_b32_e32 v60, v6                                      // 00000017EAE0: 7E780306
	v_mov_b32_e32 v59, v6                                      // 00000017EAE4: 7E760306
	v_mov_b32_e32 v58, v6                                      // 00000017EAE8: 7E740306
	v_mov_b32_e32 v57, v6                                      // 00000017EAEC: 7E720306
	v_mov_b32_e32 v102, v6                                     // 00000017EAF0: 7ECC0306
	v_mov_b32_e32 v101, v6                                     // 00000017EAF4: 7ECA0306
	v_mov_b32_e32 v100, v6                                     // 00000017EAF8: 7EC80306
	v_mov_b32_e32 v99, v6                                      // 00000017EAFC: 7EC60306
	v_mov_b32_e32 v98, v6                                      // 00000017EB00: 7EC40306
	v_mov_b32_e32 v97, v6                                      // 00000017EB04: 7EC20306
	v_mov_b32_e32 v78, v6                                      // 00000017EB08: 7E9C0306
	v_mov_b32_e32 v77, v6                                      // 00000017EB0C: 7E9A0306
	v_mov_b32_e32 v76, v6                                      // 00000017EB10: 7E980306
	v_mov_b32_e32 v75, v6                                      // 00000017EB14: 7E960306
	v_mov_b32_e32 v74, v6                                      // 00000017EB18: 7E940306
	v_mov_b32_e32 v73, v6                                      // 00000017EB1C: 7E920306
	v_mov_b32_e32 v118, v6                                     // 00000017EB20: 7EEC0306
	v_mov_b32_e32 v117, v6                                     // 00000017EB24: 7EEA0306
	v_mov_b32_e32 v116, v6                                     // 00000017EB28: 7EE80306
	v_mov_b32_e32 v115, v6                                     // 00000017EB2C: 7EE60306
	v_mov_b32_e32 v114, v6                                     // 00000017EB30: 7EE40306
	v_mov_b32_e32 v113, v6                                     // 00000017EB34: 7EE20306
	v_mov_b32_e32 v94, v6                                      // 00000017EB38: 7EBC0306
	v_mov_b32_e32 v93, v6                                      // 00000017EB3C: 7EBA0306
	v_mov_b32_e32 v92, v6                                      // 00000017EB40: 7EB80306
	v_mov_b32_e32 v91, v6                                      // 00000017EB44: 7EB60306
	v_mov_b32_e32 v90, v6                                      // 00000017EB48: 7EB40306
	v_mov_b32_e32 v89, v6                                      // 00000017EB4C: 7EB20306
	v_mov_b32_e32 v126, v6                                     // 00000017EB50: 7EFC0306
	v_mov_b32_e32 v125, v6                                     // 00000017EB54: 7EFA0306
	v_mov_b32_e32 v124, v6                                     // 00000017EB58: 7EF80306
	v_mov_b32_e32 v123, v6                                     // 00000017EB5C: 7EF60306
	v_mov_b32_e32 v122, v6                                     // 00000017EB60: 7EF40306
	v_mov_b32_e32 v121, v6                                     // 00000017EB64: 7EF20306
	v_mov_b32_e32 v110, v6                                     // 00000017EB68: 7EDC0306
	v_mov_b32_e32 v109, v6                                     // 00000017EB6C: 7EDA0306
	v_mov_b32_e32 v108, v6                                     // 00000017EB70: 7ED80306
	v_mov_b32_e32 v107, v6                                     // 00000017EB74: 7ED60306
	v_mov_b32_e32 v106, v6                                     // 00000017EB78: 7ED40306
	v_mov_b32_e32 v105, v6                                     // 00000017EB7C: 7ED20306
	v_mov_b32_e32 v252, v6                                     // 00000017EB80: 7FF80306
	s_mul_i32 s3, s20, 12                                      // 00000017EB84: 96038C14
	s_mul_hi_i32 s17, s2, 0x1800                               // 00000017EB88: 9711FF02 00001800
	s_mul_i32 s16, s2, 0x1800                                  // 00000017EB90: 9610FF02 00001800
	s_and_saveexec_b32 s18, vcc_lo                             // 00000017EB98: BE92206A
	s_cbranch_execz 2024                                       // 00000017EB9C: BFA507E8 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x2340>
	v_cmp_gt_u32_e32 vcc_lo, 12, v8                            // 00000017EBA0: 7C98108C
	v_dual_mov_b32 v169, 0 :: v_dual_mov_b32 v252, 0           // 00000017EBA4: CA100080 A9FC0080
	s_lshl_b64 s[22:23], s[16:17], 1                           // 00000017EBAC: 84968110
	v_mul_u32_u24_e32 v4, 0x44, v137                           // 00000017EBB0: 160912FF 00000044
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000017EBB8: BF8700C2
	v_dual_cndmask_b32 v1, 0, v8 :: v_dual_mov_b32 v106, v169  // 00000017EBBC: CA501080 016A01A9
	s_add_u32 s2, s8, s22                                      // 00000017EBC4: 80021608
	s_addc_u32 s8, s9, s23                                     // 00000017EBC8: 82081709
	s_ashr_i32 s21, s20, 31                                    // 00000017EBCC: 86159F14
	v_add_lshl_u32 v1, v1, s3, 8                               // 00000017EBD0: D6470001 02200701
	v_mov_b32_e32 v78, v169                                    // 00000017EBD8: 7E9C03A9
	v_mov_b32_e32 v107, v169                                   // 00000017EBDC: 7ED603A9
	v_mov_b32_e32 v109, v169                                   // 00000017EBE0: 7EDA03A9
	v_mov_b32_e32 v111, v169                                   // 00000017EBE4: 7EDE03A9
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000017EBE8: 3404029F
	v_dual_mov_b32 v112, v169 :: v_dual_mov_b32 v121, 0        // 00000017EBEC: CA1001A9 70780080
	v_dual_mov_b32 v122, v169 :: v_dual_mov_b32 v89, 0         // 00000017EBF4: CA1001A9 7A580080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000017EBFC: BF870003
	.long 0xd73c0001                                           // 00000017EC00: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 00000017EC04: 02020281
	v_mov_b32_e32 v123, v169                                   // 00000017EC08: 7EF603A9
	v_dual_mov_b32 v124, v169 :: v_dual_mov_b32 v113, 0        // 00000017EC0C: CA1001A9 7C700080
	v_mov_b32_e32 v125, v169                                   // 00000017EC14: 7EFA03A9
	v_dual_mov_b32 v126, v169 :: v_dual_mov_b32 v73, 0         // 00000017EC18: CA1001A9 7E480080
	.long 0xd7006a01                                           // 00000017EC20: D7006A01
	v_cndmask_b32_e32 v1, s2, v1, vcc_lo                       // 00000017EC24: 02020202
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017EC28: BF870001
	v_add_co_ci_u32_e64 v2, null, s8, v2, vcc_lo               // 00000017EC2C: D5207C02 01AA0408
	s_load_b32 s2, s[0:1], 0x3c                                // 00000017EC34: F4000080 F800003C
	s_movk_i32 s0, 0x440                                       // 00000017EC3C: B0000440
	s_clause 0x1                                               // 00000017EC40: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:16           // 00000017EC44: DC5E0010 147C0001
	global_load_b128 v[16:19], v[1:2], off                     // 00000017EC4C: DC5E0000 107C0001
	v_mad_u32_u24 v3, v160, s0, 0xe850                         // 00000017EC54: D60B0003 03FC01A0 0000E850
	s_lshl_b64 s[0:1], s[20:21], 9                             // 00000017EC60: 84808914
	v_cmp_lt_u32_e32 vcc_lo, 11, v15                           // 00000017EC64: 7C921E8B
	v_mov_b32_e32 v127, v169                                   // 00000017EC68: 7EFE03A9
	v_dual_mov_b32 v128, v169 :: v_dual_mov_b32 v97, 0         // 00000017EC6C: CA1001A9 80600080
	v_mad_u32_u24 v253, 0x44, v15, v3                          // 00000017EC74: D60B00FD 040E1EFF 00000044
	v_dual_mov_b32 v90, v169 :: v_dual_mov_b32 v57, 0          // 00000017EC80: CA1001A9 5A380080
	v_mov_b32_e32 v91, v169                                    // 00000017EC88: 7EB603A9
	v_dual_mov_b32 v92, v169 :: v_dual_mov_b32 v81, 0          // 00000017EC8C: CA1001A9 5C500080
	v_mov_b32_e32 v93, v169                                    // 00000017EC94: 7EBA03A9
	v_dual_mov_b32 v94, v169 :: v_dual_mov_b32 v49, 0          // 00000017EC98: CA1001A9 5E300080
	v_mov_b32_e32 v95, v169                                    // 00000017ECA0: 7EBE03A9
	s_waitcnt lgkmcnt(0)                                       // 00000017ECA4: BF89FC07
	s_add_i32 s20, s2, -1                                      // 00000017ECA8: 8114C102
	s_add_u32 s2, s12, s0                                      // 00000017ECAC: 8002000C
	s_addc_u32 s9, s13, s1                                     // 00000017ECB0: 8209010D
	s_add_u32 s12, s10, s0                                     // 00000017ECB4: 800C000A
	s_addc_u32 s13, s11, s1                                    // 00000017ECB8: 820D010B
	.long 0xd44c0000                                           // 00000017ECBC: D44C0000
	v_cndmask_b32_e32 v1, 16, v15, vcc_lo                      // 00000017ECC0: 02021E90
	v_dual_mov_b32 v96, v169 :: v_dual_mov_b32 v65, 0          // 00000017ECC4: CA1001A9 60400080
	v_dual_mov_b32 v114, v169 :: v_dual_mov_b32 v33, 0         // 00000017ECCC: CA1001A9 72200080
	v_mov_b32_e32 v115, v169                                   // 00000017ECD4: 7EE603A9
	v_dual_mov_b32 v116, v169 :: v_dual_mov_b32 v41, 0         // 00000017ECD8: CA1001A9 74280080
	v_mov_b32_e32 v117, v169                                   // 00000017ECE0: 7EEA03A9
	v_mov_b32_e32 v118, v169                                   // 00000017ECE4: 7EEC03A9
	v_mov_b32_e32 v119, v169                                   // 00000017ECE8: 7EEE03A9
	v_dual_mov_b32 v120, v169 :: v_dual_mov_b32 v25, 0         // 00000017ECEC: CA1001A9 78180080
	v_dual_mov_b32 v74, v169 :: v_dual_mov_b32 v9, 0           // 00000017ECF4: CA1001A9 4A080080
	v_mov_b32_e32 v75, v169                                    // 00000017ECFC: 7E9603A9
	v_mov_b32_e32 v76, v169                                    // 00000017ED00: 7E9803A9
	v_mov_b32_e32 v77, v169                                    // 00000017ED04: 7E9A03A9
	v_mov_b32_e32 v79, v169                                    // 00000017ED08: 7E9E03A9
	v_dual_mov_b32 v80, v169 :: v_dual_mov_b32 v255, 0xf149f2ca// 00000017ED0C: CA1001A9 50FE00FF F149F2CA
	v_mov_b32_e32 v98, v169                                    // 00000017ED18: 7EC403A9
	v_mov_b32_e32 v99, v169                                    // 00000017ED1C: 7EC603A9
	v_mov_b32_e32 v100, v169                                   // 00000017ED20: 7EC803A9
	v_mov_b32_e32 v101, v169                                   // 00000017ED24: 7ECA03A9
	v_mov_b32_e32 v102, v169                                   // 00000017ED28: 7ECC03A9
	v_mov_b32_e32 v103, v169                                   // 00000017ED2C: 7ECE03A9
	v_mov_b32_e32 v104, v169                                   // 00000017ED30: 7ED003A9
	v_mov_b32_e32 v58, v169                                    // 00000017ED34: 7E7403A9
	v_mov_b32_e32 v59, v169                                    // 00000017ED38: 7E7603A9
	v_mov_b32_e32 v60, v169                                    // 00000017ED3C: 7E7803A9
	v_mov_b32_e32 v61, v169                                    // 00000017ED40: 7E7A03A9
	v_mov_b32_e32 v62, v169                                    // 00000017ED44: 7E7C03A9
	v_mov_b32_e32 v63, v169                                    // 00000017ED48: 7E7E03A9
	v_mov_b32_e32 v64, v169                                    // 00000017ED4C: 7E8003A9
	v_mov_b32_e32 v82, v169                                    // 00000017ED50: 7EA403A9
	v_mov_b32_e32 v83, v169                                    // 00000017ED54: 7EA603A9
	v_mov_b32_e32 v84, v169                                    // 00000017ED58: 7EA803A9
	v_mov_b32_e32 v85, v169                                    // 00000017ED5C: 7EAA03A9
	v_mov_b32_e32 v86, v169                                    // 00000017ED60: 7EAC03A9
	v_mov_b32_e32 v87, v169                                    // 00000017ED64: 7EAE03A9
	v_mov_b32_e32 v88, v169                                    // 00000017ED68: 7EB003A9
	v_mov_b32_e32 v50, v169                                    // 00000017ED6C: 7E6403A9
	v_mov_b32_e32 v51, v169                                    // 00000017ED70: 7E6603A9
	v_mov_b32_e32 v52, v169                                    // 00000017ED74: 7E6803A9
	v_mov_b32_e32 v53, v169                                    // 00000017ED78: 7E6A03A9
	v_mov_b32_e32 v54, v169                                    // 00000017ED7C: 7E6C03A9
	v_mov_b32_e32 v55, v169                                    // 00000017ED80: 7E6E03A9
	v_mov_b32_e32 v56, v169                                    // 00000017ED84: 7E7003A9
	v_mov_b32_e32 v66, v169                                    // 00000017ED88: 7E8403A9
	v_mov_b32_e32 v67, v169                                    // 00000017ED8C: 7E8603A9
	v_mov_b32_e32 v68, v169                                    // 00000017ED90: 7E8803A9
	v_mov_b32_e32 v69, v169                                    // 00000017ED94: 7E8A03A9
	v_mov_b32_e32 v70, v169                                    // 00000017ED98: 7E8C03A9
	v_mov_b32_e32 v71, v169                                    // 00000017ED9C: 7E8E03A9
	v_mov_b32_e32 v72, v169                                    // 00000017EDA0: 7E9003A9
	v_mov_b32_e32 v34, v169                                    // 00000017EDA4: 7E4403A9
	v_mov_b32_e32 v35, v169                                    // 00000017EDA8: 7E4603A9
	v_mov_b32_e32 v36, v169                                    // 00000017EDAC: 7E4803A9
	v_mov_b32_e32 v37, v169                                    // 00000017EDB0: 7E4A03A9
	v_mov_b32_e32 v38, v169                                    // 00000017EDB4: 7E4C03A9
	v_mov_b32_e32 v39, v169                                    // 00000017EDB8: 7E4E03A9
	v_mov_b32_e32 v40, v169                                    // 00000017EDBC: 7E5003A9
	v_mov_b32_e32 v42, v169                                    // 00000017EDC0: 7E5403A9
	v_mov_b32_e32 v43, v169                                    // 00000017EDC4: 7E5603A9
	v_mov_b32_e32 v44, v169                                    // 00000017EDC8: 7E5803A9
	v_mov_b32_e32 v45, v169                                    // 00000017EDCC: 7E5A03A9
	v_mov_b32_e32 v46, v169                                    // 00000017EDD0: 7E5C03A9
	v_mov_b32_e32 v47, v169                                    // 00000017EDD4: 7E5E03A9
	v_mov_b32_e32 v48, v169                                    // 00000017EDD8: 7E6003A9
	v_mov_b32_e32 v24, v169                                    // 00000017EDDC: 7E3003A9
	v_mov_b32_e32 v26, v169                                    // 00000017EDE0: 7E3403A9
	v_mov_b32_e32 v27, v169                                    // 00000017EDE4: 7E3603A9
	v_mov_b32_e32 v28, v169                                    // 00000017EDE8: 7E3803A9
	v_mov_b32_e32 v29, v169                                    // 00000017EDEC: 7E3A03A9
	v_mov_b32_e32 v30, v169                                    // 00000017EDF0: 7E3C03A9
	v_mov_b32_e32 v31, v169                                    // 00000017EDF4: 7E3E03A9
	v_mov_b32_e32 v32, v169                                    // 00000017EDF8: 7E4003A9
	v_mov_b32_e32 v10, v169                                    // 00000017EDFC: 7E1403A9
	v_mov_b32_e32 v11, v169                                    // 00000017EE00: 7E1603A9
	v_mov_b32_e32 v12, v169                                    // 00000017EE04: 7E1803A9
	v_mov_b32_e32 v13, v169                                    // 00000017EE08: 7E1A03A9
	v_mov_b32_e32 v14, v169                                    // 00000017EE0C: 7E1C03A9
	v_mov_b32_e32 v5, v169                                     // 00000017EE10: 7E0A03A9
	v_mov_b32_e32 v6, v169                                     // 00000017EE14: 7E0C03A9
	s_mov_b32 s8, 0                                            // 00000017EE18: BE880080
	s_mov_b32 s21, 0                                           // 00000017EE1C: BE950080
	s_waitcnt vmcnt(0)                                         // 00000017EE20: BF8903F7
	s_clause 0x1                                               // 00000017EE24: BF850001
	scratch_store_b128 off, v[16:19], off                      // 00000017EE28: DC750000 007C1000
	scratch_store_b128 off, v[20:23], off offset:16            // 00000017EE30: DC750010 007C1400
	s_clause 0x1                                               // 00000017EE38: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:48           // 00000017EE3C: DC5E0030 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:32           // 00000017EE44: DC5E0020 107C0001
	s_waitcnt vmcnt(0)                                         // 00000017EE4C: BF8903F7
	s_clause 0x1                                               // 00000017EE50: BF850001
	scratch_store_b128 off, v[16:19], off offset:32            // 00000017EE54: DC750020 007C1000
	scratch_store_b128 off, v[20:23], off offset:48            // 00000017EE5C: DC750030 007C1400
	s_clause 0x1                                               // 00000017EE64: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:80           // 00000017EE68: DC5E0050 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:64           // 00000017EE70: DC5E0040 107C0001
	s_waitcnt vmcnt(0)                                         // 00000017EE78: BF8903F7
	s_clause 0x1                                               // 00000017EE7C: BF850001
	scratch_store_b128 off, v[16:19], off offset:64            // 00000017EE80: DC750040 007C1000
	scratch_store_b128 off, v[20:23], off offset:80            // 00000017EE88: DC750050 007C1400
	s_clause 0x1                                               // 00000017EE90: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:112          // 00000017EE94: DC5E0070 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:96           // 00000017EE9C: DC5E0060 107C0001
	s_waitcnt vmcnt(0)                                         // 00000017EEA4: BF8903F7
	s_clause 0x1                                               // 00000017EEA8: BF850001
	scratch_store_b128 off, v[16:19], off offset:96            // 00000017EEAC: DC750060 007C1000
	scratch_store_b128 off, v[20:23], off offset:112           // 00000017EEB4: DC750070 007C1400
	s_clause 0x1                                               // 00000017EEBC: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:144          // 00000017EEC0: DC5E0090 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:128          // 00000017EEC8: DC5E0080 107C0001
	s_waitcnt vmcnt(0)                                         // 00000017EED0: BF8903F7
	s_clause 0x1                                               // 00000017EED4: BF850001
	scratch_store_b128 off, v[16:19], off offset:128           // 00000017EED8: DC750080 007C1000
	scratch_store_b128 off, v[20:23], off offset:144           // 00000017EEE0: DC750090 007C1400
	s_clause 0x1                                               // 00000017EEE8: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:176          // 00000017EEEC: DC5E00B0 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:160          // 00000017EEF4: DC5E00A0 107C0001
	s_waitcnt vmcnt(0)                                         // 00000017EEFC: BF8903F7
	s_clause 0x1                                               // 00000017EF00: BF850001
	scratch_store_b128 off, v[16:19], off offset:160           // 00000017EF04: DC7500A0 007C1000
	scratch_store_b128 off, v[20:23], off offset:176           // 00000017EF0C: DC7500B0 007C1400
	s_clause 0x1                                               // 00000017EF14: BF850001
	global_load_b128 v[20:23], v[1:2], off offset:208          // 00000017EF18: DC5E00D0 147C0001
	global_load_b128 v[16:19], v[1:2], off offset:192          // 00000017EF20: DC5E00C0 107C0001
	s_waitcnt vmcnt(0)                                         // 00000017EF28: BF8903F7
	s_clause 0x1                                               // 00000017EF2C: BF850001
	scratch_store_b128 off, v[16:19], off offset:192           // 00000017EF30: DC7500C0 007C1000
	scratch_store_b128 off, v[20:23], off offset:208           // 00000017EF38: DC7500D0 007C1400
	s_clause 0x11                                              // 00000017EF40: BF850011
	global_load_b128 v[189:192], v[1:2], off offset:240        // 00000017EF44: DC5E00F0 BD7C0001
	global_load_b128 v[185:188], v[1:2], off offset:224        // 00000017EF4C: DC5E00E0 B97C0001
	global_load_b128 v[197:200], v[1:2], off offset:272        // 00000017EF54: DC5E0110 C57C0001
	global_load_b128 v[193:196], v[1:2], off offset:256        // 00000017EF5C: DC5E0100 C17C0001
	global_load_b128 v[205:208], v[1:2], off offset:304        // 00000017EF64: DC5E0130 CD7C0001
	global_load_b128 v[201:204], v[1:2], off offset:288        // 00000017EF6C: DC5E0120 C97C0001
	global_load_b128 v[213:216], v[1:2], off offset:336        // 00000017EF74: DC5E0150 D57C0001
	global_load_b128 v[209:212], v[1:2], off offset:320        // 00000017EF7C: DC5E0140 D17C0001
	global_load_b128 v[221:224], v[1:2], off offset:368        // 00000017EF84: DC5E0170 DD7C0001
	global_load_b128 v[217:220], v[1:2], off offset:352        // 00000017EF8C: DC5E0160 D97C0001
	global_load_b128 v[229:232], v[1:2], off offset:400        // 00000017EF94: DC5E0190 E57C0001
	global_load_b128 v[225:228], v[1:2], off offset:384        // 00000017EF9C: DC5E0180 E17C0001
	global_load_b128 v[237:240], v[1:2], off offset:432        // 00000017EFA4: DC5E01B0 ED7C0001
	global_load_b128 v[233:236], v[1:2], off offset:416        // 00000017EFAC: DC5E01A0 E97C0001
	global_load_b128 v[245:248], v[1:2], off offset:464        // 00000017EFB4: DC5E01D0 F57C0001
	global_load_b128 v[241:244], v[1:2], off offset:448        // 00000017EFBC: DC5E01C0 F17C0001
	global_load_b128 v[133:136], v[1:2], off offset:496        // 00000017EFC4: DC5E01F0 857C0001
	global_load_b128 v[129:132], v[1:2], off offset:480        // 00000017EFCC: DC5E01E0 817C0001
	v_mul_u32_u24_e32 v1, 0x3000, v160                         // 00000017EFD4: 160340FF 00003000
	v_dual_mov_b32 v105, 0 :: v_dual_lshlrev_b32 v2, 2, v8     // 00000017EFDC: CA220080 69021082
	scratch_store_b32 off, v7, off offset:224                  // 00000017EFE4: DC6900E0 007C0700
	v_mov_b32_e32 v17, 0                                       // 00000017EFEC: 7E220280
	v_or_b32_e32 v1, 0x800, v1                                 // 00000017EFF0: 380202FF 00000800
	v_add3_u32 v251, v3, v4, v2                                // 00000017EFF8: D65500FB 040A0903
	v_or_b32_e32 v178, 0xc800, v2                              // 00000017F000: 396404FF 0000C800
	v_mul_u32_u24_e32 v2, 48, v8                               // 00000017F008: 160410B0
	v_mov_b32_e32 v18, v169                                    // 00000017F00C: 7E2403A9
	v_mov_b32_e32 v19, v169                                    // 00000017F010: 7E2603A9
	v_mov_b32_e32 v20, v169                                    // 00000017F014: 7E2803A9
	v_mov_b32_e32 v21, v169                                    // 00000017F018: 7E2A03A9
	v_or_b32_e32 v152, v1, v2                                  // 00000017F01C: 39300501
	v_mad_u32_u24 v1, 0x1800, v137, v1                         // 00000017F020: D60B0001 040712FF 00001800
	v_mov_b32_e32 v22, v169                                    // 00000017F02C: 7E2C03A9
	v_mov_b32_e32 v23, v169                                    // 00000017F030: 7E2E03A9
	v_mov_b32_e32 v16, v169                                    // 00000017F034: 7E2003A9
	v_mov_b32_e32 v108, v169                                   // 00000017F038: 7ED803A9
	v_lshl_or_b32 v254, v8, 1, v1                              // 00000017F03C: D65600FE 04050308
	v_lshl_add_u32 v1, v160, 6, 0xfa50                         // 00000017F044: D6460001 03FD0DA0 0000FA50
	v_mov_b32_e32 v2, v169                                     // 00000017F050: 7E0403A9
	v_mov_b32_e32 v3, v169                                     // 00000017F054: 7E0603A9
	v_mov_b32_e32 v110, v169                                   // 00000017F058: 7EDC03A9
	v_mov_b32_e32 v4, v169                                     // 00000017F05C: 7E0803A9
	v_lshl_add_u32 v179, v15, 2, v1                            // 00000017F060: D64600B3 0405050F
	v_lshl_or_b32 v153, v137, 2, v1                            // 00000017F068: D6560099 04050589
	v_lshlrev_b32_e32 v1, 9, v160                              // 00000017F070: 30034089
	v_lshlrev_b32_e32 v137, 8, v137                            // 00000017F074: 31131288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000017F078: BF870232
	v_lshl_add_u32 v154, v15, 5, v1                            // 00000017F07C: D646009A 04050B0F
	v_lshl_or_b32 v155, v8, 5, v1                              // 00000017F084: D656009B 04050B08
	v_lshlrev_b32_e32 v1, 4, v160                              // 00000017F08C: 30034084
	.long 0xd700019e                                           // 00000017F090: D700019E
	v_cndmask_b32_e32 v1, s2, v137, vcc_lo                     // 00000017F094: 02031202
	v_mov_b32_e32 v8, v169                                     // 00000017F098: 7E1003A9
	v_add_co_ci_u32_e64 v159, null, s9, 0, s1                  // 00000017F09C: D5207C9F 00050009
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000017F0A4: BF8701C4
	v_sub_nc_u32_e32 v156, v7, v1                              // 00000017F0A8: 4D380307
	v_mul_u32_u24_e32 v1, 0x44, v15                            // 00000017F0AC: 16021EFF 00000044
	v_mov_b32_e32 v15, v169                                    // 00000017F0B4: 7E1E03A9
	v_mov_b32_e32 v7, v169                                     // 00000017F0B8: 7E0E03A9
	v_mad_u32_u24 v180, 0x440, v160, v1                        // 00000017F0BC: D60B00B4 040740FF 00000440
	v_mov_b32_e32 v1, 0                                        // 00000017F0C8: 7E020280
	s_branch 265                                               // 00000017F0CC: BFA00109 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0xcf4>
	s_or_b32 exec_lo, exec_lo, s1                              // 00000017F0D0: 8C7E017E
	ds_load_b128 v[138:141], v155                              // 00000017F0D4: DBFC0000 8A00009B
	ds_load_b128 v[142:145], v155 offset:16                    // 00000017F0DC: DBFC0010 8E00009B
	ds_load_b128 v[161:164], v152                              // 00000017F0E4: DBFC0000 A1000098
	ds_load_b128 v[165:168], v152 offset:16                    // 00000017F0EC: DBFC0010 A5000098
	ds_load_2addr_b32 v[146:147], v153 offset1:2               // 00000017F0F4: D8DC0200 92000099
	ds_load_2addr_b32 v[148:149], v153 offset0:4 offset1:6     // 00000017F0FC: D8DC0604 94000099
	ds_load_2addr_b32 v[150:151], v153 offset0:8 offset1:10    // 00000017F104: D8DC0A08 96000099
	ds_load_2addr_b32 v[249:250], v153 offset0:12 offset1:14   // 00000017F10C: D8DC0E0C F9000099
	v_add_nc_u32_e32 v160, 4, v160                             // 00000017F114: 4B414084
	v_subrev_nc_u32_e32 v156, 64, v156                         // 00000017F118: 4F3938C0
	s_delay_alu instid0(VALU_DEP_2)                            // 00000017F11C: BF870002
	.long 0xd4430001                                           // 00000017F120: D4430001
	v_cndmask_b32_e32 v1, s19, v160, vcc_lo                    // 00000017F124: 02034013
	s_or_b32 s21, s1, s21                                      // 00000017F128: 8C151501
	s_waitcnt lgkmcnt(3)                                       // 00000017F12C: BF89FC37
	v_dual_mul_f32 v105, v146, v105 :: v_dual_mul_f32 v106, v147, v106// 00000017F130: C8C6D392 696AD593
	s_waitcnt lgkmcnt(2)                                       // 00000017F138: BF89FC27
	v_dual_mul_f32 v107, v148, v107 :: v_dual_mul_f32 v108, v149, v108// 00000017F13C: C8C6D794 6B6CD995
	s_waitcnt lgkmcnt(1)                                       // 00000017F144: BF89FC17
	v_dual_mul_f32 v109, v150, v109 :: v_dual_mul_f32 v110, v151, v110// 00000017F148: C8C6DB96 6D6EDD97
	s_waitcnt lgkmcnt(0)                                       // 00000017F150: BF89FC07
	v_dual_mul_f32 v111, v249, v111 :: v_dual_mul_f32 v112, v250, v112// 00000017F154: C8C6DFF9 6F70E1FA
	v_dual_mul_f32 v121, v146, v121 :: v_dual_mul_f32 v122, v147, v122// 00000017F15C: C8C6F392 797AF593
	v_dual_mul_f32 v123, v148, v123 :: v_dual_mul_f32 v124, v149, v124// 00000017F164: C8C6F794 7B7CF995
	s_delay_alu instid0(VALU_DEP_3)                            // 00000017F16C: BF870003
	v_wmma_f32_16x16x16_bf16 v[105:112], v[138:145], v[161:168], v[105:112]// 00000017F170: CC414069 1DA7438A
	ds_load_b128 v[165:168], v152 offset:784                   // 00000017F178: DBFC0310 A5000098
	ds_load_b128 v[161:164], v152 offset:768                   // 00000017F180: DBFC0300 A1000098
	v_dual_mul_f32 v125, v150, v125 :: v_dual_mul_f32 v126, v151, v126// 00000017F188: C8C6FB96 7D7EFD97
	v_dual_mul_f32 v127, v249, v127 :: v_dual_mul_f32 v128, v250, v128// 00000017F190: C8C6FFF9 7F8101FA
	v_dual_mul_f32 v89, v146, v89 :: v_dual_mul_f32 v90, v147, v90// 00000017F198: C8C6B392 595AB593
	v_dual_mul_f32 v91, v148, v91 :: v_dual_mul_f32 v92, v149, v92// 00000017F1A0: C8C6B794 5B5CB995
	v_dual_mul_f32 v93, v150, v93 :: v_dual_mul_f32 v94, v151, v94// 00000017F1A8: C8C6BB96 5D5EBD97
	v_dual_mul_f32 v95, v249, v95 :: v_dual_mul_f32 v96, v250, v96// 00000017F1B0: C8C6BFF9 5F60C1FA
	v_dual_mul_f32 v113, v146, v113 :: v_dual_mul_f32 v114, v147, v114// 00000017F1B8: C8C6E392 7172E593
	v_dual_mul_f32 v115, v148, v115 :: v_dual_mul_f32 v116, v149, v116// 00000017F1C0: C8C6E794 7374E995
	v_dual_mul_f32 v117, v150, v117 :: v_dual_mul_f32 v118, v151, v118// 00000017F1C8: C8C6EB96 7576ED97
	v_dual_mul_f32 v119, v249, v119 :: v_dual_mul_f32 v120, v250, v120// 00000017F1D0: C8C6EFF9 7778F1FA
	s_waitcnt lgkmcnt(0)                                       // 00000017F1D8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[121:128], v[138:145], v[161:168], v[121:128]// 00000017F1DC: CC414079 1DE7438A
	ds_load_b128 v[165:168], v152 offset:1552                  // 00000017F1E4: DBFC0610 A5000098
	ds_load_b128 v[161:164], v152 offset:1536                  // 00000017F1EC: DBFC0600 A1000098
	v_dual_mul_f32 v73, v146, v73 :: v_dual_mul_f32 v74, v147, v74// 00000017F1F4: C8C69392 494A9593
	v_dual_mul_f32 v75, v148, v75 :: v_dual_mul_f32 v76, v149, v76// 00000017F1FC: C8C69794 4B4C9995
	v_dual_mul_f32 v77, v150, v77 :: v_dual_mul_f32 v78, v151, v78// 00000017F204: C8C69B96 4D4E9D97
	v_dual_mul_f32 v79, v249, v79 :: v_dual_mul_f32 v80, v250, v80// 00000017F20C: C8C69FF9 4F50A1FA
	v_dual_mul_f32 v97, v146, v97 :: v_dual_mul_f32 v98, v147, v98// 00000017F214: C8C6C392 6162C593
	v_dual_mul_f32 v99, v148, v99 :: v_dual_mul_f32 v100, v149, v100// 00000017F21C: C8C6C794 6364C995
	v_dual_mul_f32 v101, v150, v101 :: v_dual_mul_f32 v102, v151, v102// 00000017F224: C8C6CB96 6566CD97
	v_dual_mul_f32 v103, v249, v103 :: v_dual_mul_f32 v104, v250, v104// 00000017F22C: C8C6CFF9 6768D1FA
	v_dual_mul_f32 v57, v146, v57 :: v_dual_mul_f32 v58, v147, v58// 00000017F234: C8C67392 393A7593
	v_dual_mul_f32 v59, v148, v59 :: v_dual_mul_f32 v60, v149, v60// 00000017F23C: C8C67794 3B3C7995
	s_waitcnt lgkmcnt(0)                                       // 00000017F244: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[138:145], v[161:168], v[89:96]// 00000017F248: CC414059 1D67438A
	ds_load_b128 v[165:168], v152 offset:2320                  // 00000017F250: DBFC0910 A5000098
	ds_load_b128 v[161:164], v152 offset:2304                  // 00000017F258: DBFC0900 A1000098
	v_dual_mul_f32 v61, v150, v61 :: v_dual_mul_f32 v62, v151, v62// 00000017F260: C8C67B96 3D3E7D97
	v_dual_mul_f32 v63, v249, v63 :: v_dual_mul_f32 v64, v250, v64// 00000017F268: C8C67FF9 3F4081FA
	v_dual_mul_f32 v81, v146, v81 :: v_dual_mul_f32 v82, v147, v82// 00000017F270: C8C6A392 5152A593
	v_dual_mul_f32 v83, v148, v83 :: v_dual_mul_f32 v84, v149, v84// 00000017F278: C8C6A794 5354A995
	v_dual_mul_f32 v85, v150, v85 :: v_dual_mul_f32 v86, v151, v86// 00000017F280: C8C6AB96 5556AD97
	v_dual_mul_f32 v87, v249, v87 :: v_dual_mul_f32 v88, v250, v88// 00000017F288: C8C6AFF9 5758B1FA
	v_dual_mul_f32 v49, v146, v49 :: v_dual_mul_f32 v50, v147, v50// 00000017F290: C8C66392 31326593
	v_dual_mul_f32 v51, v148, v51 :: v_dual_mul_f32 v52, v149, v52// 00000017F298: C8C66794 33346995
	v_dual_mul_f32 v53, v150, v53 :: v_dual_mul_f32 v54, v151, v54// 00000017F2A0: C8C66B96 35366D97
	v_dual_mul_f32 v55, v249, v55 :: v_dual_mul_f32 v56, v250, v56// 00000017F2A8: C8C66FF9 373871FA
	s_waitcnt lgkmcnt(0)                                       // 00000017F2B0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[113:120], v[138:145], v[161:168], v[113:120]// 00000017F2B4: CC414071 1DC7438A
	ds_load_b128 v[165:168], v152 offset:3088                  // 00000017F2BC: DBFC0C10 A5000098
	ds_load_b128 v[161:164], v152 offset:3072                  // 00000017F2C4: DBFC0C00 A1000098
	v_dual_mul_f32 v65, v146, v65 :: v_dual_mul_f32 v66, v147, v66// 00000017F2CC: C8C68392 41428593
	v_dual_mul_f32 v67, v148, v67 :: v_dual_mul_f32 v68, v149, v68// 00000017F2D4: C8C68794 43448995
	v_dual_mul_f32 v69, v150, v69 :: v_dual_mul_f32 v70, v151, v70// 00000017F2DC: C8C68B96 45468D97
	v_dual_mul_f32 v71, v249, v71 :: v_dual_mul_f32 v72, v250, v72// 00000017F2E4: C8C68FF9 474891FA
	v_dual_mul_f32 v33, v146, v33 :: v_dual_mul_f32 v34, v147, v34// 00000017F2EC: C8C64392 21224593
	v_dual_mul_f32 v35, v148, v35 :: v_dual_mul_f32 v36, v149, v36// 00000017F2F4: C8C64794 23244995
	v_dual_mul_f32 v37, v150, v37 :: v_dual_mul_f32 v38, v151, v38// 00000017F2FC: C8C64B96 25264D97
	v_dual_mul_f32 v39, v249, v39 :: v_dual_mul_f32 v40, v250, v40// 00000017F304: C8C64FF9 272851FA
	v_dual_mul_f32 v41, v146, v41 :: v_dual_mul_f32 v42, v147, v42// 00000017F30C: C8C65392 292A5593
	v_dual_mul_f32 v43, v148, v43 :: v_dual_mul_f32 v44, v149, v44// 00000017F314: C8C65794 2B2C5995
	s_waitcnt lgkmcnt(0)                                       // 00000017F31C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[138:145], v[161:168], v[73:80]// 00000017F320: CC414049 1D27438A
	ds_load_b128 v[165:168], v152 offset:3856                  // 00000017F328: DBFC0F10 A5000098
	ds_load_b128 v[161:164], v152 offset:3840                  // 00000017F330: DBFC0F00 A1000098
	v_dual_mul_f32 v45, v150, v45 :: v_dual_mul_f32 v46, v151, v46// 00000017F338: C8C65B96 2D2E5D97
	v_dual_mul_f32 v47, v249, v47 :: v_dual_mul_f32 v48, v250, v48// 00000017F340: C8C65FF9 2F3061FA
	v_dual_mul_f32 v17, v146, v17 :: v_dual_mul_f32 v18, v147, v18// 00000017F348: C8C62392 11122593
	v_dual_mul_f32 v19, v148, v19 :: v_dual_mul_f32 v20, v149, v20// 00000017F350: C8C62794 13142995
	v_dual_mul_f32 v21, v150, v21 :: v_dual_mul_f32 v22, v151, v22// 00000017F358: C8C62B96 15162D97
	v_dual_mul_f32 v23, v249, v23 :: v_dual_mul_f32 v24, v250, v24// 00000017F360: C8C62FF9 171831FA
	v_dual_mul_f32 v25, v146, v25 :: v_dual_mul_f32 v26, v147, v26// 00000017F368: C8C63392 191A3593
	v_dual_mul_f32 v27, v148, v27 :: v_dual_mul_f32 v28, v149, v28// 00000017F370: C8C63794 1B1C3995
	v_dual_mul_f32 v29, v150, v29 :: v_dual_mul_f32 v30, v151, v30// 00000017F378: C8C63B96 1D1E3D97
	v_dual_mul_f32 v31, v249, v31 :: v_dual_mul_f32 v32, v250, v32// 00000017F380: C8C63FF9 1F2041FA
	s_waitcnt lgkmcnt(0)                                       // 00000017F388: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[97:104], v[138:145], v[161:168], v[97:104]// 00000017F38C: CC414061 1D87438A
	ds_load_b128 v[165:168], v152 offset:4624                  // 00000017F394: DBFC1210 A5000098
	ds_load_b128 v[161:164], v152 offset:4608                  // 00000017F39C: DBFC1200 A1000098
	v_dual_mul_f32 v9, v146, v9 :: v_dual_mul_f32 v10, v147, v10// 00000017F3A4: C8C61392 090A1593
	v_dual_mul_f32 v11, v148, v11 :: v_dual_mul_f32 v12, v149, v12// 00000017F3AC: C8C61794 0B0C1995
	v_dual_mul_f32 v13, v150, v13 :: v_dual_mul_f32 v14, v151, v14// 00000017F3B4: C8C61B96 0D0E1D97
	v_dual_mul_f32 v15, v249, v15 :: v_dual_mul_f32 v16, v250, v16// 00000017F3BC: C8C61FF9 0F1021FA
	v_dual_mul_f32 v1, v146, v1 :: v_dual_mul_f32 v2, v147, v2 // 00000017F3C4: C8C60392 01020593
	v_dual_mul_f32 v3, v148, v3 :: v_dual_mul_f32 v4, v149, v4 // 00000017F3CC: C8C60794 03040995
	v_dual_mul_f32 v5, v150, v5 :: v_dual_mul_f32 v6, v151, v6 // 00000017F3D4: C8C60B96 05060D97
	v_dual_mul_f32 v7, v249, v7 :: v_dual_mul_f32 v8, v250, v8 // 00000017F3DC: C8C60FF9 070811FA
	s_waitcnt lgkmcnt(0)                                       // 00000017F3E4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[138:145], v[161:168], v[57:64]// 00000017F3E8: CC414039 1CE7438A
	ds_load_b128 v[165:168], v152 offset:5392                  // 00000017F3F0: DBFC1510 A5000098
	ds_load_b128 v[161:164], v152 offset:5376                  // 00000017F3F8: DBFC1500 A1000098
	s_waitcnt lgkmcnt(0)                                       // 00000017F400: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[138:145], v[161:168], v[81:88]// 00000017F404: CC414051 1D47438A
	ds_load_b128 v[165:168], v152 offset:6160                  // 00000017F40C: DBFC1810 A5000098
	ds_load_b128 v[161:164], v152 offset:6144                  // 00000017F414: DBFC1800 A1000098
	s_waitcnt lgkmcnt(0)                                       // 00000017F41C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[49:56], v[138:145], v[161:168], v[49:56]// 00000017F420: CC414031 1CC7438A
	ds_load_b128 v[165:168], v152 offset:6928                  // 00000017F428: DBFC1B10 A5000098
	ds_load_b128 v[161:164], v152 offset:6912                  // 00000017F430: DBFC1B00 A1000098
	s_waitcnt lgkmcnt(0)                                       // 00000017F438: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[138:145], v[161:168], v[65:72]// 00000017F43C: CC414041 1D07438A
	ds_load_b128 v[165:168], v152 offset:7696                  // 00000017F444: DBFC1E10 A5000098
	ds_load_b128 v[161:164], v152 offset:7680                  // 00000017F44C: DBFC1E00 A1000098
	s_waitcnt lgkmcnt(0)                                       // 00000017F454: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[33:40], v[138:145], v[161:168], v[33:40]// 00000017F458: CC414021 1C87438A
	ds_load_b128 v[165:168], v152 offset:8464                  // 00000017F460: DBFC2110 A5000098
	ds_load_b128 v[161:164], v152 offset:8448                  // 00000017F468: DBFC2100 A1000098
	s_waitcnt lgkmcnt(0)                                       // 00000017F470: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[41:48], v[138:145], v[161:168], v[41:48]// 00000017F474: CC414029 1CA7438A
	ds_load_b128 v[165:168], v152 offset:9232                  // 00000017F47C: DBFC2410 A5000098
	ds_load_b128 v[161:164], v152 offset:9216                  // 00000017F484: DBFC2400 A1000098
	s_waitcnt lgkmcnt(0)                                       // 00000017F48C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[138:145], v[161:168], v[17:24]// 00000017F490: CC414011 1C47438A
	ds_load_b128 v[165:168], v152 offset:10000                 // 00000017F498: DBFC2710 A5000098
	ds_load_b128 v[161:164], v152 offset:9984                  // 00000017F4A0: DBFC2700 A1000098
	s_waitcnt lgkmcnt(0)                                       // 00000017F4A8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[25:32], v[138:145], v[161:168], v[25:32]// 00000017F4AC: CC414019 1C67438A
	ds_load_b128 v[165:168], v152 offset:10768                 // 00000017F4B4: DBFC2A10 A5000098
	ds_load_b128 v[161:164], v152 offset:10752                 // 00000017F4BC: DBFC2A00 A1000098
	s_waitcnt lgkmcnt(0)                                       // 00000017F4C4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[138:145], v[161:168], v[9:16]// 00000017F4C8: CC414009 1C27438A
	ds_load_b128 v[165:168], v152 offset:11536                 // 00000017F4D0: DBFC2D10 A5000098
	ds_load_b128 v[161:164], v152 offset:11520                 // 00000017F4D8: DBFC2D00 A1000098
	s_waitcnt lgkmcnt(0)                                       // 00000017F4E0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[1:8], v[138:145], v[161:168], v[1:8]// 00000017F4E4: CC414001 1C07438A
	s_and_not1_b32 exec_lo, exec_lo, s21                       // 00000017F4EC: 917E157E
	s_cbranch_execz 1421                                       // 00000017F4F0: BFA5058D <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x2328>
	v_lshl_add_u32 v137, v160, 6, v178                         // 00000017F4F4: D6460089 06C90DA0
	v_mov_b32_e32 v170, v169                                   // 00000017F4FC: 7F5403A9
	v_mov_b32_e32 v171, v169                                   // 00000017F500: 7F5603A9
	v_mov_b32_e32 v172, v169                                   // 00000017F504: 7F5803A9
	v_mov_b32_e32 v173, v169                                   // 00000017F508: 7F5A03A9
	ds_load_b32 v137, v137                                     // 00000017F50C: D8D80000 89000089
	v_mov_b32_e32 v174, v169                                   // 00000017F514: 7F5C03A9
	v_mov_b32_e32 v175, v169                                   // 00000017F518: 7F5E03A9
	v_mov_b32_e32 v176, v169                                   // 00000017F51C: 7F6003A9
	s_mov_b32 s9, 0                                            // 00000017F520: BE890080
	s_waitcnt lgkmcnt(0)                                       // 00000017F524: BF89FC07
	v_min_i32_e32 v137, s20, v137                              // 00000017F528: 23131214
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017F52C: BF870121
	v_ashrrev_i32_e32 v138, 31, v137                           // 00000017F530: 3515129F
	.long 0xd72c008c                                           // 00000017F534: D72C008C
	v_cndmask_b32_e32 v1, s15, v137, vcc_lo                    // 00000017F538: 0203120F
	.long 0xd72c008b                                           // 00000017F53C: D72C008B
	v_cndmask_b32_e32 v1, s14, v138, vcc_lo                    // 00000017F540: 0203140E
	v_mad_u64_u32 v[137:138], null, s14, v137, 0               // 00000017F544: D6FE7C89 0203120E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017F54C: BF870091
	v_add3_u32 v138, v138, v139, v140                          // 00000017F550: D655008A 0633178A
	.long 0xd73c0091                                           // 00000017F558: D73C0091
	v_cndmask_b32_e32 v1, 1, v137, vcc_lo                      // 00000017F55C: 02031281
	v_dual_mov_b32 v137, v169 :: v_dual_mov_b32 v138, v170     // 00000017F560: CA1001A9 898A01AA
	v_dual_mov_b32 v139, v171 :: v_dual_mov_b32 v140, v172     // 00000017F568: CA1001AB 8B8C01AC
	v_dual_mov_b32 v141, v173 :: v_dual_mov_b32 v142, v174     // 00000017F570: CA1001AD 8D8E01AE
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017F578: BF870094
	.long 0xd7000193                                           // 00000017F57C: D7000193
	v_cndmask_b32_e32 v1, s12, v145, vcc_lo                    // 00000017F580: 0203220C
	v_add_co_ci_u32_e64 v148, null, s13, v146, s1              // 00000017F584: D5207C94 0007240D
	v_dual_mov_b32 v143, v175 :: v_dual_mov_b32 v144, v176     // 00000017F58C: CA1001AF 8F9001B0
	s_clause 0x1                                               // 00000017F594: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:16     // 00000017F598: DC5E0010 A57C0093
	global_load_b128 v[161:164], v[147:148], off               // 00000017F5A0: DC5E0000 A17C0093
	s_clause 0x1                                               // 00000017F5A8: BF850001
	scratch_load_b128 v[170:173], off, off                     // 00000017F5AC: DC5D0000 AA7C0000
	scratch_load_b128 v[174:177], off, off offset:16           // 00000017F5B4: DC5D0010 AE7C0000
	s_waitcnt vmcnt(0)                                         // 00000017F5BC: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[170:177], v[161:168], v[137:144]// 00000017F5C0: CC414089 1E2743AA
	s_clause 0x1                                               // 00000017F5C8: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:48     // 00000017F5CC: DC5E0030 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:32     // 00000017F5D4: DC5E0020 A17C0093
	s_clause 0x1                                               // 00000017F5DC: BF850001
	scratch_load_b128 v[170:173], off, off offset:32           // 00000017F5E0: DC5D0020 AA7C0000
	scratch_load_b128 v[174:177], off, off offset:48           // 00000017F5E8: DC5D0030 AE7C0000
	s_waitcnt vmcnt(0)                                         // 00000017F5F0: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[170:177], v[161:168], v[137:144]// 00000017F5F4: CC414089 1E2743AA
	s_clause 0x1                                               // 00000017F5FC: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:80     // 00000017F600: DC5E0050 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:64     // 00000017F608: DC5E0040 A17C0093
	s_clause 0x1                                               // 00000017F610: BF850001
	scratch_load_b128 v[170:173], off, off offset:64           // 00000017F614: DC5D0040 AA7C0000
	scratch_load_b128 v[174:177], off, off offset:80           // 00000017F61C: DC5D0050 AE7C0000
	s_waitcnt vmcnt(0)                                         // 00000017F624: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[170:177], v[161:168], v[137:144]// 00000017F628: CC414089 1E2743AA
	s_clause 0x1                                               // 00000017F630: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:112    // 00000017F634: DC5E0070 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:96     // 00000017F63C: DC5E0060 A17C0093
	s_clause 0x1                                               // 00000017F644: BF850001
	scratch_load_b128 v[170:173], off, off offset:96           // 00000017F648: DC5D0060 AA7C0000
	scratch_load_b128 v[174:177], off, off offset:112          // 00000017F650: DC5D0070 AE7C0000
	s_waitcnt vmcnt(0)                                         // 00000017F658: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[170:177], v[161:168], v[137:144]// 00000017F65C: CC414089 1E2743AA
	s_clause 0x1                                               // 00000017F664: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:144    // 00000017F668: DC5E0090 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:128    // 00000017F670: DC5E0080 A17C0093
	s_clause 0x1                                               // 00000017F678: BF850001
	scratch_load_b128 v[170:173], off, off offset:128          // 00000017F67C: DC5D0080 AA7C0000
	scratch_load_b128 v[174:177], off, off offset:144          // 00000017F684: DC5D0090 AE7C0000
	s_waitcnt vmcnt(0)                                         // 00000017F68C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[170:177], v[161:168], v[137:144]// 00000017F690: CC414089 1E2743AA
	s_clause 0x1                                               // 00000017F698: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:176    // 00000017F69C: DC5E00B0 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:160    // 00000017F6A4: DC5E00A0 A17C0093
	s_clause 0x1                                               // 00000017F6AC: BF850001
	scratch_load_b128 v[170:173], off, off offset:160          // 00000017F6B0: DC5D00A0 AA7C0000
	scratch_load_b128 v[174:177], off, off offset:176          // 00000017F6B8: DC5D00B0 AE7C0000
	s_waitcnt vmcnt(0)                                         // 00000017F6C0: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[170:177], v[161:168], v[137:144]// 00000017F6C4: CC414089 1E2743AA
	s_clause 0x1                                               // 00000017F6CC: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:208    // 00000017F6D0: DC5E00D0 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:192    // 00000017F6D8: DC5E00C0 A17C0093
	s_clause 0x1                                               // 00000017F6E0: BF850001
	scratch_load_b128 v[170:173], off, off offset:192          // 00000017F6E4: DC5D00C0 AA7C0000
	scratch_load_b128 v[174:177], off, off offset:208          // 00000017F6EC: DC5D00D0 AE7C0000
	s_waitcnt vmcnt(0)                                         // 00000017F6F4: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[170:177], v[161:168], v[137:144]// 00000017F6F8: CC414089 1E2743AA
	s_clause 0x1                                               // 00000017F700: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:240    // 00000017F704: DC5E00F0 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:224    // 00000017F70C: DC5E00E0 A17C0093
	s_waitcnt vmcnt(0)                                         // 00000017F714: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[185:192], v[161:168], v[137:144]// 00000017F718: CC414089 1E2743B9
	s_clause 0x1                                               // 00000017F720: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:272    // 00000017F724: DC5E0110 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:256    // 00000017F72C: DC5E0100 A17C0093
	s_waitcnt vmcnt(0)                                         // 00000017F734: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[193:200], v[161:168], v[137:144]// 00000017F738: CC414089 1E2743C1
	s_clause 0x1                                               // 00000017F740: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:304    // 00000017F744: DC5E0130 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:288    // 00000017F74C: DC5E0120 A17C0093
	s_waitcnt vmcnt(0)                                         // 00000017F754: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[201:208], v[161:168], v[137:144]// 00000017F758: CC414089 1E2743C9
	s_clause 0x1                                               // 00000017F760: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:336    // 00000017F764: DC5E0150 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:320    // 00000017F76C: DC5E0140 A17C0093
	s_waitcnt vmcnt(0)                                         // 00000017F774: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[209:216], v[161:168], v[137:144]// 00000017F778: CC414089 1E2743D1
	s_clause 0x1                                               // 00000017F780: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:368    // 00000017F784: DC5E0170 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:352    // 00000017F78C: DC5E0160 A17C0093
	s_waitcnt vmcnt(0)                                         // 00000017F794: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[217:224], v[161:168], v[137:144]// 00000017F798: CC414089 1E2743D9
	s_clause 0x1                                               // 00000017F7A0: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:400    // 00000017F7A4: DC5E0190 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:384    // 00000017F7AC: DC5E0180 A17C0093
	s_waitcnt vmcnt(0)                                         // 00000017F7B4: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[225:232], v[161:168], v[137:144]// 00000017F7B8: CC414089 1E2743E1
	s_clause 0x1                                               // 00000017F7C0: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:432    // 00000017F7C4: DC5E01B0 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:416    // 00000017F7CC: DC5E01A0 A17C0093
	s_waitcnt vmcnt(0)                                         // 00000017F7D4: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[233:240], v[161:168], v[137:144]// 00000017F7D8: CC414089 1E2743E9
	s_clause 0x1                                               // 00000017F7E0: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:464    // 00000017F7E4: DC5E01D0 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:448    // 00000017F7EC: DC5E01C0 A17C0093
	s_waitcnt vmcnt(0)                                         // 00000017F7F4: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[241:248], v[161:168], v[137:144]// 00000017F7F8: CC414089 1E2743F1
	s_clause 0x1                                               // 00000017F800: BF850001
	global_load_b128 v[165:168], v[147:148], off offset:496    // 00000017F804: DC5E01F0 A57C0093
	global_load_b128 v[161:164], v[147:148], off offset:480    // 00000017F80C: DC5E01E0 A17C0093
	s_waitcnt vmcnt(0)                                         // 00000017F814: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[129:136], v[161:168], v[137:144]// 00000017F818: CC414089 1E274381
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000017F820: BF8701A1
	v_mul_f32_e32 v151, 0x3d800000, v141                       // 00000017F824: 112F1AFF 3D800000
	.long 0xd700018d                                           // 00000017F82C: D700018D
	v_cndmask_b32_e32 v1, v158, v145, vcc_lo                   // 00000017F830: 0203239E
	v_mul_f32_e32 v157, 0x3d800000, v142                       // 00000017F834: 113B1CFF 3D800000
	v_add_co_ci_u32_e64 v142, null, v159, v146, s1             // 00000017F83C: D5207C8E 0007259F
	v_dual_mul_f32 v147, 0x3d800000, v137 :: v_dual_mul_f32 v148, 0x3d800000, v138// 00000017F844: C8C712FF 939514FF 3D800000
	v_dual_mul_f32 v149, 0x3d800000, v139 :: v_dual_mul_f32 v150, 0x3d800000, v140// 00000017F850: C8C716FF 959718FF 3D800000
	global_load_b128 v[137:140], v[141:142], off               // 00000017F85C: DC5E0000 897C008D
	v_dual_mul_f32 v143, 0x3d800000, v143 :: v_dual_mul_f32 v144, 0x3d800000, v144// 00000017F864: C8C71EFF 8F9120FF 3D800000
	s_waitcnt vmcnt(0)                                         // 00000017F870: BF8903F7
	ds_store_b16 v254, v137                                    // 00000017F874: D87C0000 000089FE
	ds_store_b16_d16_hi v254, v137 offset:48                   // 00000017F87C: DA840030 000089FE
	ds_store_b16 v254, v138 offset:96                          // 00000017F884: D87C0060 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:144                  // 00000017F88C: DA840090 00008AFE
	ds_store_b16 v254, v139 offset:192                         // 00000017F894: D87C00C0 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:240                  // 00000017F89C: DA8400F0 00008BFE
	ds_store_b16 v254, v140 offset:288                         // 00000017F8A4: D87C0120 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:336                  // 00000017F8AC: DA840150 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:16     // 00000017F8B4: DC5E0010 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017F8BC: BF8903F7
	ds_store_b16 v254, v137 offset:384                         // 00000017F8C0: D87C0180 000089FE
	ds_store_b16_d16_hi v254, v137 offset:432                  // 00000017F8C8: DA8401B0 000089FE
	ds_store_b16 v254, v138 offset:480                         // 00000017F8D0: D87C01E0 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:528                  // 00000017F8D8: DA840210 00008AFE
	ds_store_b16 v254, v139 offset:576                         // 00000017F8E0: D87C0240 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:624                  // 00000017F8E8: DA840270 00008BFE
	ds_store_b16 v254, v140 offset:672                         // 00000017F8F0: D87C02A0 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:720                  // 00000017F8F8: DA8402D0 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:32     // 00000017F900: DC5E0020 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017F908: BF8903F7
	ds_store_b16 v254, v137 offset:768                         // 00000017F90C: D87C0300 000089FE
	ds_store_b16_d16_hi v254, v137 offset:816                  // 00000017F914: DA840330 000089FE
	ds_store_b16 v254, v138 offset:864                         // 00000017F91C: D87C0360 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:912                  // 00000017F924: DA840390 00008AFE
	ds_store_b16 v254, v139 offset:960                         // 00000017F92C: D87C03C0 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:1008                 // 00000017F934: DA8403F0 00008BFE
	ds_store_b16 v254, v140 offset:1056                        // 00000017F93C: D87C0420 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:1104                 // 00000017F944: DA840450 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:48     // 00000017F94C: DC5E0030 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017F954: BF8903F7
	ds_store_b16 v254, v137 offset:1152                        // 00000017F958: D87C0480 000089FE
	ds_store_b16_d16_hi v254, v137 offset:1200                 // 00000017F960: DA8404B0 000089FE
	ds_store_b16 v254, v138 offset:1248                        // 00000017F968: D87C04E0 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:1296                 // 00000017F970: DA840510 00008AFE
	ds_store_b16 v254, v139 offset:1344                        // 00000017F978: D87C0540 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:1392                 // 00000017F980: DA840570 00008BFE
	ds_store_b16 v254, v140 offset:1440                        // 00000017F988: D87C05A0 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:1488                 // 00000017F990: DA8405D0 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:64     // 00000017F998: DC5E0040 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017F9A0: BF8903F7
	ds_store_b16 v254, v137 offset:1536                        // 00000017F9A4: D87C0600 000089FE
	ds_store_b16_d16_hi v254, v137 offset:1584                 // 00000017F9AC: DA840630 000089FE
	ds_store_b16 v254, v138 offset:1632                        // 00000017F9B4: D87C0660 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:1680                 // 00000017F9BC: DA840690 00008AFE
	ds_store_b16 v254, v139 offset:1728                        // 00000017F9C4: D87C06C0 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:1776                 // 00000017F9CC: DA8406F0 00008BFE
	ds_store_b16 v254, v140 offset:1824                        // 00000017F9D4: D87C0720 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:1872                 // 00000017F9DC: DA840750 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:80     // 00000017F9E4: DC5E0050 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017F9EC: BF8903F7
	ds_store_b16 v254, v137 offset:1920                        // 00000017F9F0: D87C0780 000089FE
	ds_store_b16_d16_hi v254, v137 offset:1968                 // 00000017F9F8: DA8407B0 000089FE
	ds_store_b16 v254, v138 offset:2016                        // 00000017FA00: D87C07E0 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:2064                 // 00000017FA08: DA840810 00008AFE
	ds_store_b16 v254, v139 offset:2112                        // 00000017FA10: D87C0840 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:2160                 // 00000017FA18: DA840870 00008BFE
	ds_store_b16 v254, v140 offset:2208                        // 00000017FA20: D87C08A0 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:2256                 // 00000017FA28: DA8408D0 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:96     // 00000017FA30: DC5E0060 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017FA38: BF8903F7
	ds_store_b16 v254, v137 offset:2304                        // 00000017FA3C: D87C0900 000089FE
	ds_store_b16_d16_hi v254, v137 offset:2352                 // 00000017FA44: DA840930 000089FE
	ds_store_b16 v254, v138 offset:2400                        // 00000017FA4C: D87C0960 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:2448                 // 00000017FA54: DA840990 00008AFE
	ds_store_b16 v254, v139 offset:2496                        // 00000017FA5C: D87C09C0 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:2544                 // 00000017FA64: DA8409F0 00008BFE
	ds_store_b16 v254, v140 offset:2592                        // 00000017FA6C: D87C0A20 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:2640                 // 00000017FA74: DA840A50 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:112    // 00000017FA7C: DC5E0070 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017FA84: BF8903F7
	ds_store_b16 v254, v137 offset:2688                        // 00000017FA88: D87C0A80 000089FE
	ds_store_b16_d16_hi v254, v137 offset:2736                 // 00000017FA90: DA840AB0 000089FE
	ds_store_b16 v254, v138 offset:2784                        // 00000017FA98: D87C0AE0 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:2832                 // 00000017FAA0: DA840B10 00008AFE
	ds_store_b16 v254, v139 offset:2880                        // 00000017FAA8: D87C0B40 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:2928                 // 00000017FAB0: DA840B70 00008BFE
	ds_store_b16 v254, v140 offset:2976                        // 00000017FAB8: D87C0BA0 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:3024                 // 00000017FAC0: DA840BD0 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:128    // 00000017FAC8: DC5E0080 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017FAD0: BF8903F7
	ds_store_b16 v254, v137 offset:3072                        // 00000017FAD4: D87C0C00 000089FE
	ds_store_b16_d16_hi v254, v137 offset:3120                 // 00000017FADC: DA840C30 000089FE
	ds_store_b16 v254, v138 offset:3168                        // 00000017FAE4: D87C0C60 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:3216                 // 00000017FAEC: DA840C90 00008AFE
	ds_store_b16 v254, v139 offset:3264                        // 00000017FAF4: D87C0CC0 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:3312                 // 00000017FAFC: DA840CF0 00008BFE
	ds_store_b16 v254, v140 offset:3360                        // 00000017FB04: D87C0D20 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:3408                 // 00000017FB0C: DA840D50 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:144    // 00000017FB14: DC5E0090 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017FB1C: BF8903F7
	ds_store_b16 v254, v137 offset:3456                        // 00000017FB20: D87C0D80 000089FE
	ds_store_b16_d16_hi v254, v137 offset:3504                 // 00000017FB28: DA840DB0 000089FE
	ds_store_b16 v254, v138 offset:3552                        // 00000017FB30: D87C0DE0 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:3600                 // 00000017FB38: DA840E10 00008AFE
	ds_store_b16 v254, v139 offset:3648                        // 00000017FB40: D87C0E40 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:3696                 // 00000017FB48: DA840E70 00008BFE
	ds_store_b16 v254, v140 offset:3744                        // 00000017FB50: D87C0EA0 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:3792                 // 00000017FB58: DA840ED0 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:160    // 00000017FB60: DC5E00A0 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017FB68: BF8903F7
	ds_store_b16 v254, v137 offset:3840                        // 00000017FB6C: D87C0F00 000089FE
	ds_store_b16_d16_hi v254, v137 offset:3888                 // 00000017FB74: DA840F30 000089FE
	ds_store_b16 v254, v138 offset:3936                        // 00000017FB7C: D87C0F60 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:3984                 // 00000017FB84: DA840F90 00008AFE
	ds_store_b16 v254, v139 offset:4032                        // 00000017FB8C: D87C0FC0 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:4080                 // 00000017FB94: DA840FF0 00008BFE
	ds_store_b16 v254, v140 offset:4128                        // 00000017FB9C: D87C1020 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:4176                 // 00000017FBA4: DA841050 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:176    // 00000017FBAC: DC5E00B0 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017FBB4: BF8903F7
	ds_store_b16 v254, v137 offset:4224                        // 00000017FBB8: D87C1080 000089FE
	ds_store_b16_d16_hi v254, v137 offset:4272                 // 00000017FBC0: DA8410B0 000089FE
	ds_store_b16 v254, v138 offset:4320                        // 00000017FBC8: D87C10E0 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:4368                 // 00000017FBD0: DA841110 00008AFE
	ds_store_b16 v254, v139 offset:4416                        // 00000017FBD8: D87C1140 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:4464                 // 00000017FBE0: DA841170 00008BFE
	ds_store_b16 v254, v140 offset:4512                        // 00000017FBE8: D87C11A0 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:4560                 // 00000017FBF0: DA8411D0 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:192    // 00000017FBF8: DC5E00C0 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017FC00: BF8903F7
	ds_store_b16 v254, v137 offset:4608                        // 00000017FC04: D87C1200 000089FE
	ds_store_b16_d16_hi v254, v137 offset:4656                 // 00000017FC0C: DA841230 000089FE
	ds_store_b16 v254, v138 offset:4704                        // 00000017FC14: D87C1260 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:4752                 // 00000017FC1C: DA841290 00008AFE
	ds_store_b16 v254, v139 offset:4800                        // 00000017FC24: D87C12C0 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:4848                 // 00000017FC2C: DA8412F0 00008BFE
	ds_store_b16 v254, v140 offset:4896                        // 00000017FC34: D87C1320 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:4944                 // 00000017FC3C: DA841350 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:208    // 00000017FC44: DC5E00D0 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017FC4C: BF8903F7
	ds_store_b16 v254, v137 offset:4992                        // 00000017FC50: D87C1380 000089FE
	ds_store_b16_d16_hi v254, v137 offset:5040                 // 00000017FC58: DA8413B0 000089FE
	ds_store_b16 v254, v138 offset:5088                        // 00000017FC60: D87C13E0 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:5136                 // 00000017FC68: DA841410 00008AFE
	ds_store_b16 v254, v139 offset:5184                        // 00000017FC70: D87C1440 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:5232                 // 00000017FC78: DA841470 00008BFE
	ds_store_b16 v254, v140 offset:5280                        // 00000017FC80: D87C14A0 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:5328                 // 00000017FC88: DA8414D0 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:224    // 00000017FC90: DC5E00E0 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017FC98: BF8903F7
	ds_store_b16 v254, v137 offset:5376                        // 00000017FC9C: D87C1500 000089FE
	ds_store_b16_d16_hi v254, v137 offset:5424                 // 00000017FCA4: DA841530 000089FE
	ds_store_b16 v254, v138 offset:5472                        // 00000017FCAC: D87C1560 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:5520                 // 00000017FCB4: DA841590 00008AFE
	ds_store_b16 v254, v139 offset:5568                        // 00000017FCBC: D87C15C0 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:5616                 // 00000017FCC4: DA8415F0 00008BFE
	ds_store_b16 v254, v140 offset:5664                        // 00000017FCCC: D87C1620 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:5712                 // 00000017FCD4: DA841650 00008CFE
	global_load_b128 v[137:140], v[141:142], off offset:240    // 00000017FCDC: DC5E00F0 897C008D
	s_waitcnt vmcnt(0)                                         // 00000017FCE4: BF8903F7
	ds_store_b16 v254, v137 offset:5760                        // 00000017FCE8: D87C1680 000089FE
	ds_store_b16_d16_hi v254, v137 offset:5808                 // 00000017FCF0: DA8416B0 000089FE
	ds_store_b16 v254, v138 offset:5856                        // 00000017FCF8: D87C16E0 00008AFE
	ds_store_b16_d16_hi v254, v138 offset:5904                 // 00000017FD00: DA841710 00008AFE
	ds_store_b16 v254, v139 offset:5952                        // 00000017FD08: D87C1740 00008BFE
	ds_store_b16_d16_hi v254, v139 offset:6000                 // 00000017FD10: DA841770 00008BFE
	ds_store_b16 v254, v140 offset:6048                        // 00000017FD18: D87C17A0 00008CFE
	ds_store_b16_d16_hi v254, v140 offset:6096                 // 00000017FD20: DA8417D0 00008CFE
	ds_store_2addr_b32 v251, v147, v148 offset1:34             // 00000017FD28: D8382200 009493FB
	ds_store_2addr_b32 v251, v149, v150 offset0:68 offset1:102 // 00000017FD30: D8386644 009695FB
	ds_store_2addr_b32 v251, v151, v157 offset0:136 offset1:170// 00000017FD38: D838AA88 009D97FB
	ds_store_2addr_b32 v251, v143, v144 offset0:204 offset1:238// 00000017FD40: D838EECC 00908FFB
	s_and_saveexec_b32 s1, vcc_lo                              // 00000017FD48: BE81206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017FD4C: BF870009
	s_xor_b32 s1, exec_lo, s1                                  // 00000017FD50: 8D01017E
	s_cbranch_execnz 8                                         // 00000017FD54: BFA60008 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1578>
	s_or_saveexec_b32 s10, s1                                  // 00000017FD58: BE8A2201
	v_mov_b32_e32 v139, 1.0                                    // 00000017FD5C: 7F1602F2
	s_xor_b32 exec_lo, exec_lo, s10                            // 00000017FD60: 8D7E0A7E
	s_cbranch_execnz 29                                        // 00000017FD64: BFA6001D <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x15dc>
	s_or_b32 exec_lo, exec_lo, s10                             // 00000017FD68: 8C7E0A7E
	s_and_saveexec_b32 s1, s9                                  // 00000017FD6C: BE812009
	s_cbranch_execz 64727                                      // 00000017FD70: BFA5FCD7 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x8d0>
	s_branch 873                                               // 00000017FD74: BFA00369 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x231c>
	s_mov_b32 s2, 0                                            // 00000017FD78: BE820080
	s_and_saveexec_b32 s9, s0                                  // 00000017FD7C: BE892000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017FD80: BF870009
	s_xor_b32 s22, exec_lo, s9                                 // 00000017FD84: 8D16097E
	s_cbranch_execz 13                                         // 00000017FD88: BFA5000D <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x15c0>
	s_mov_b32 s11, s8                                          // 00000017FD8C: BE8B0008
	s_mov_b32 s9, s8                                           // 00000017FD90: BE890008
	s_mov_b32 s10, s8                                          // 00000017FD94: BE8A0008
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017FD98: BF870009
	v_dual_mov_b32 v140, s11 :: v_dual_mov_b32 v139, s10       // 00000017FD9C: CA10000B 8C8A000A
	v_dual_mov_b32 v138, s9 :: v_dual_mov_b32 v137, s8         // 00000017FDA4: CA100009 8A880008
	s_mov_b32 s2, exec_lo                                      // 00000017FDAC: BE82007E
	ds_store_b128 v154, v[137:140]                             // 00000017FDB0: DB7C0000 0000899A
	ds_store_b128 v154, v[137:140] offset:16                   // 00000017FDB8: DB7C0010 0000899A
	s_or_b32 exec_lo, exec_lo, s22                             // 00000017FDC0: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017FDC4: BF870009
	s_and_b32 s9, s2, exec_lo                                  // 00000017FDC8: 8B097E02
	s_or_saveexec_b32 s10, s1                                  // 00000017FDCC: BE8A2201
	v_mov_b32_e32 v139, 1.0                                    // 00000017FDD0: 7F1602F2
	s_xor_b32 exec_lo, exec_lo, s10                            // 00000017FDD4: 8D7E0A7E
	s_cbranch_execz 65507                                      // 00000017FDD8: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1568>
	scratch_load_b32 v138, off, off offset:224                 // 00000017FDDC: DC5100E0 8A7C0000
	v_lshlrev_b32_e32 v137, 4, v160                            // 00000017FDE4: 31134084
	s_waitcnt vmcnt(0)                                         // 00000017FDE8: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017FDEC: BF870121
	v_sub_nc_u32_e32 v139, v138, v137                          // 00000017FDF0: 4D17138A
	v_mov_b32_e32 v138, v255                                   // 00000017FDF4: 7F1403FF
	.long 0xd4410001                                           // 00000017FDF8: D4410001
	v_cndmask_b32_e32 v1, 0, v139, vcc_lo                      // 00000017FDFC: 02031680
	s_and_saveexec_b32 s11, s1                                 // 00000017FE00: BE8B2001
	s_cbranch_execz 22                                         // 00000017FE04: BFA50016 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1660>
	v_med3_i32 v137, v156, 1, 16                               // 00000017FE08: D6200089 0241039C
	v_mov_b32_e32 v140, v180                                   // 00000017FE10: 7F1803B4
	v_mov_b32_e32 v138, v255                                   // 00000017FE14: 7F1403FF
	s_mov_b32 s22, 0                                           // 00000017FE18: BE960080
	s_delay_alu instid0(VALU_DEP_3)                            // 00000017FE1C: BF870003
	v_lshlrev_b32_e32 v141, 2, v137                            // 00000017FE20: 311B1282
	ds_load_b32 v137, v140 offset:59472                        // 00000017FE24: D8D8E850 8900008C
	v_dual_max_f32 v138, v138, v138 :: v_dual_add_nc_u32 v141, -4, v141// 00000017FE2C: CAA1158A 8A8D1AC4
	v_add_nc_u32_e32 v140, 4, v140                             // 00000017FE34: 4B191884
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000017FE38: BF8700C2
	.long 0xd44a0002                                           // 00000017FE3C: D44A0002
	v_cndmask_b32_e32 v1, 0, v141, vcc_lo                      // 00000017FE40: 02031A80
	s_or_b32 s22, s2, s22                                      // 00000017FE44: 8C161602
	s_waitcnt lgkmcnt(0)                                       // 00000017FE48: BF89FC07
	v_max_f32_e32 v137, v137, v137                             // 00000017FE4C: 21131389
	v_max_f32_e32 v138, v138, v137                             // 00000017FE50: 2115138A
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 00000017FE54: 917E167E
	s_cbranch_execnz 65522                                     // 00000017FE58: BFA6FFF2 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1624>
	s_or_b32 exec_lo, exec_lo, s22                             // 00000017FE5C: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000017FE60: BF870009
	s_or_b32 exec_lo, exec_lo, s11                             // 00000017FE64: 8C7E0B7E
	v_dual_mov_b32 v140, 0 :: v_dual_mov_b32 v141, 0           // 00000017FE68: CA100080 8C8C0080
	s_and_saveexec_b32 s2, s1                                  // 00000017FE70: BE822001
	s_cbranch_execz 33                                         // 00000017FE74: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x16fc>
	ds_load_b32 v137, v253                                     // 00000017FE78: D8D80000 890000FD
	s_waitcnt lgkmcnt(0)                                       // 00000017FE80: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000017FE84: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017FE88: BF870121
	v_mul_f32_e32 v141, 0x3fb8aa3b, v137                       // 00000017FE8C: 111B12FF 3FB8AA3B
	.long 0xd41b0001                                           // 00000017FE94: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000017FE98: 020312FF C2CE8ED0
	v_fma_f32 v142, 0x3fb8aa3b, v137, -v141                    // 00000017FEA0: D613008E 863712FF 3FB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 00000017FEAC: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017FEB0: BF870091
	v_dual_fmac_f32 v142, 0x32a5705f, v137 :: v_dual_sub_f32 v141, v141, v143// 00000017FEB4: C80B12FF 8E8D1F8D 32A5705F
	v_add_f32_e32 v141, v141, v142                             // 00000017FEC0: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 00000017FEC4: 7F1C118F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000017FEC8: BF870292
	v_exp_f32_e32 v141, v141                                   // 00000017FECC: 7F1A4B8D
	.long 0xd71c008d                                           // 00000017FED0: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 00000017FED4: 02031D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017FED8: BF8700A1
	v_cndmask_b32_e64 v141, 0, v141, s1                        // 00000017FEDC: D501008D 00071A80
	.long 0xd41e0001                                           // 00000017FEE4: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000017FEE8: 020312FF 42B17218
	v_cndmask_b32_e64 v141, 0x7f800000, v141, s1               // 00000017FEF0: D501008D 00071AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017FEFC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000017FF00: BF8700A1
	v_bfe_u32 v137, v141, 16, 1                                // 00000017FF04: D6100089 0205218D
	s_mov_b32 s2, exec_lo                                      // 00000017FF0C: BE82007E
	v_add3_u32 v137, v141, v137, 0x7fff                        // 00000017FF10: D6550089 03FF138D 00007FFF
	ds_store_b16_d16_hi v154, v137                             // 00000017FF1C: DA840000 0000899A
	v_cmpx_lt_i32_e32 1, v139                                  // 00000017FF24: 7D831681
	s_cbranch_execz 34                                         // 00000017FF28: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x17b4>
	ds_load_b32 v137, v253 offset:4                            // 00000017FF2C: D8D80004 890000FD
	s_waitcnt lgkmcnt(0)                                       // 00000017FF34: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000017FF38: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017FF3C: BF870091
	v_mul_f32_e32 v140, 0x3fb8aa3b, v137                       // 00000017FF40: 111912FF 3FB8AA3B
	v_fma_f32 v142, 0x3fb8aa3b, v137, -v140                    // 00000017FF48: D613008E 863312FF 3FB8AA3B
	v_rndne_f32_e32 v143, v140                                 // 00000017FF54: 7F1E478C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000017FF58: BF870191
	v_sub_f32_e32 v140, v140, v143                             // 00000017FF5C: 09191F8C
	v_fmac_f32_e32 v142, 0x32a5705f, v137                      // 00000017FF60: 571D12FF 32A5705F
	.long 0xd41b0001                                           // 00000017FF68: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000017FF6C: 020312FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017FF74: BF870122
	v_add_f32_e32 v140, v140, v142                             // 00000017FF78: 07191D8C
	v_cvt_i32_f32_e32 v142, v143                               // 00000017FF7C: 7F1C118F
	v_exp_f32_e32 v140, v140                                   // 00000017FF80: 7F184B8C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000017FF84: BF870095
	.long 0xd71c008c                                           // 00000017FF88: D71C008C
	v_cndmask_b32_e32 v1, v140, v142, vcc_lo                   // 00000017FF8C: 02031D8C
	v_cndmask_b32_e64 v140, 0, v140, s1                        // 00000017FF90: D501008C 00071880
	.long 0xd41e0001                                           // 00000017FF98: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000017FF9C: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000017FFA4: BF870001
	v_cndmask_b32_e64 v140, 0x7f800000, v140, s1               // 00000017FFA8: D501008C 000718FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000017FFB4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000017FFB8: BF870131
	v_bfe_u32 v137, v140, 16, 1                                // 00000017FFBC: D6100089 0205218C
	v_dual_mov_b32 v142, 0 :: v_dual_mov_b32 v143, 0           // 00000017FFC4: CA100080 8E8E0080
	s_mov_b32 s2, exec_lo                                      // 00000017FFCC: BE82007E
	v_add3_u32 v137, v140, v137, 0x7fff                        // 00000017FFD0: D6550089 03FF138C 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:2                    // 00000017FFDC: DA840002 0000899A
	v_cmpx_lt_i32_e32 2, v139                                  // 00000017FFE4: 7D831682
	s_cbranch_execz 34                                         // 00000017FFE8: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1874>
	ds_load_b32 v137, v253 offset:8                            // 00000017FFEC: D8D80008 890000FD
	s_waitcnt lgkmcnt(0)                                       // 00000017FFF4: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000017FFF8: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000017FFFC: BF870121
	v_mul_f32_e32 v143, 0x3fb8aa3b, v137                       // 000000180000: 111F12FF 3FB8AA3B
	.long 0xd41b0001                                           // 000000180008: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000018000C: 020312FF C2CE8ED0
	v_fma_f32 v144, 0x3fb8aa3b, v137, -v143                    // 000000180014: D6130090 863F12FF 3FB8AA3B
	v_rndne_f32_e32 v145, v143                                 // 000000180020: 7F22478F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000180024: BF870112
	v_fmac_f32_e32 v144, 0x32a5705f, v137                      // 000000180028: 572112FF 32A5705F
	v_sub_f32_e32 v143, v143, v145                             // 000000180030: 091F238F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000180034: BF870121
	v_add_f32_e32 v143, v143, v144                             // 000000180038: 071F218F
	v_cvt_i32_f32_e32 v144, v145                               // 00000018003C: 7F201191
	v_exp_f32_e32 v143, v143                                   // 000000180040: 7F1E4B8F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180044: BF870095
	.long 0xd71c008f                                           // 000000180048: D71C008F
	v_cndmask_b32_e32 v1, v143, v144, vcc_lo                   // 00000018004C: 0203218F
	v_cndmask_b32_e64 v143, 0, v143, s1                        // 000000180050: D501008F 00071E80
	.long 0xd41e0001                                           // 000000180058: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 00000018005C: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000180064: BF870001
	v_cndmask_b32_e64 v143, 0x7f800000, v143, s1               // 000000180068: D501008F 00071EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000180074: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000180078: BF8700A1
	v_bfe_u32 v137, v143, 16, 1                                // 00000018007C: D6100089 0205218F
	s_mov_b32 s2, exec_lo                                      // 000000180084: BE82007E
	v_add3_u32 v137, v143, v137, 0x7fff                        // 000000180088: D6550089 03FF138F 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:4                    // 000000180094: DA840004 0000899A
	v_cmpx_lt_i32_e32 3, v139                                  // 00000018009C: 7D831683
	s_cbranch_execz 34                                         // 0000001800A0: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x192c>
	ds_load_b32 v137, v253 offset:12                           // 0000001800A4: D8D8000C 890000FD
	s_waitcnt lgkmcnt(0)                                       // 0000001800AC: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 0000001800B0: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001800B4: BF870091
	v_mul_f32_e32 v142, 0x3fb8aa3b, v137                       // 0000001800B8: 111D12FF 3FB8AA3B
	v_fma_f32 v144, 0x3fb8aa3b, v137, -v142                    // 0000001800C0: D6130090 863B12FF 3FB8AA3B
	v_rndne_f32_e32 v145, v142                                 // 0000001800CC: 7F22478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001800D0: BF870191
	v_sub_f32_e32 v142, v142, v145                             // 0000001800D4: 091D238E
	v_fmac_f32_e32 v144, 0x32a5705f, v137                      // 0000001800D8: 572112FF 32A5705F
	.long 0xd41b0001                                           // 0000001800E0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 0000001800E4: 020312FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001800EC: BF870122
	v_add_f32_e32 v142, v142, v144                             // 0000001800F0: 071D218E
	v_cvt_i32_f32_e32 v144, v145                               // 0000001800F4: 7F201191
	v_exp_f32_e32 v142, v142                                   // 0000001800F8: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001800FC: BF870095
	.long 0xd71c008e                                           // 000000180100: D71C008E
	v_cndmask_b32_e32 v1, v142, v144, vcc_lo                   // 000000180104: 0203218E
	v_cndmask_b32_e64 v142, 0, v142, s1                        // 000000180108: D501008E 00071C80
	.long 0xd41e0001                                           // 000000180110: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 000000180114: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018011C: BF870001
	v_cndmask_b32_e64 v142, 0x7f800000, v142, s1               // 000000180120: D501008E 00071CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000018012C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000180130: BF870131
	v_bfe_u32 v137, v142, 16, 1                                // 000000180134: D6100089 0205218E
	v_dual_mov_b32 v144, 0 :: v_dual_mov_b32 v145, 0           // 00000018013C: CA100080 90900080
	s_mov_b32 s2, exec_lo                                      // 000000180144: BE82007E
	v_add3_u32 v137, v142, v137, 0x7fff                        // 000000180148: D6550089 03FF138E 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:6                    // 000000180154: DA840006 0000899A
	v_cmpx_lt_i32_e32 4, v139                                  // 00000018015C: 7D831684
	s_cbranch_execz 33                                         // 000000180160: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x19e8>
	ds_load_b32 v137, v253 offset:16                           // 000000180164: D8D80010 890000FD
	s_waitcnt lgkmcnt(0)                                       // 00000018016C: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 000000180170: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000180174: BF870121
	v_mul_f32_e32 v145, 0x3fb8aa3b, v137                       // 000000180178: 112312FF 3FB8AA3B
	.long 0xd41b0001                                           // 000000180180: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 000000180184: 020312FF C2CE8ED0
	v_fma_f32 v146, 0x3fb8aa3b, v137, -v145                    // 00000018018C: D6130092 864712FF 3FB8AA3B
	v_rndne_f32_e32 v147, v145                                 // 000000180198: 7F264791
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018019C: BF870091
	v_dual_fmac_f32 v146, 0x32a5705f, v137 :: v_dual_sub_f32 v145, v145, v147// 0000001801A0: C80B12FF 92912791 32A5705F
	v_add_f32_e32 v145, v145, v146                             // 0000001801AC: 07232591
	v_cvt_i32_f32_e32 v146, v147                               // 0000001801B0: 7F241193
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001801B4: BF870292
	v_exp_f32_e32 v145, v145                                   // 0000001801B8: 7F224B91
	.long 0xd71c0091                                           // 0000001801BC: D71C0091
	v_cndmask_b32_e32 v1, v145, v146, vcc_lo                   // 0000001801C0: 02032591
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001801C4: BF8700A1
	v_cndmask_b32_e64 v145, 0, v145, s1                        // 0000001801C8: D5010091 00072280
	.long 0xd41e0001                                           // 0000001801D0: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 0000001801D4: 020312FF 42B17218
	v_cndmask_b32_e64 v145, 0x7f800000, v145, s1               // 0000001801DC: D5010091 000722FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001801E8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001801EC: BF8700A1
	v_bfe_u32 v137, v145, 16, 1                                // 0000001801F0: D6100089 02052191
	s_mov_b32 s2, exec_lo                                      // 0000001801F8: BE82007E
	v_add3_u32 v137, v145, v137, 0x7fff                        // 0000001801FC: D6550089 03FF1391 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:8                    // 000000180208: DA840008 0000899A
	v_cmpx_lt_i32_e32 5, v139                                  // 000000180210: 7D831685
	s_cbranch_execz 34                                         // 000000180214: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1aa0>
	ds_load_b32 v137, v253 offset:20                           // 000000180218: D8D80014 890000FD
	s_waitcnt lgkmcnt(0)                                       // 000000180220: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 000000180224: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180228: BF870091
	v_mul_f32_e32 v144, 0x3fb8aa3b, v137                       // 00000018022C: 112112FF 3FB8AA3B
	v_fma_f32 v146, 0x3fb8aa3b, v137, -v144                    // 000000180234: D6130092 864312FF 3FB8AA3B
	v_rndne_f32_e32 v147, v144                                 // 000000180240: 7F264790
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000180244: BF870191
	v_sub_f32_e32 v144, v144, v147                             // 000000180248: 09212790
	v_fmac_f32_e32 v146, 0x32a5705f, v137                      // 00000018024C: 572512FF 32A5705F
	.long 0xd41b0001                                           // 000000180254: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 000000180258: 020312FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000180260: BF870122
	v_add_f32_e32 v144, v144, v146                             // 000000180264: 07212590
	v_cvt_i32_f32_e32 v146, v147                               // 000000180268: 7F241193
	v_exp_f32_e32 v144, v144                                   // 00000018026C: 7F204B90
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180270: BF870095
	.long 0xd71c0090                                           // 000000180274: D71C0090
	v_cndmask_b32_e32 v1, v144, v146, vcc_lo                   // 000000180278: 02032590
	v_cndmask_b32_e64 v144, 0, v144, s1                        // 00000018027C: D5010090 00072080
	.long 0xd41e0001                                           // 000000180284: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 000000180288: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000180290: BF870001
	v_cndmask_b32_e64 v144, 0x7f800000, v144, s1               // 000000180294: D5010090 000720FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001802A0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001802A4: BF870131
	v_bfe_u32 v137, v144, 16, 1                                // 0000001802A8: D6100089 02052190
	v_dual_mov_b32 v146, 0 :: v_dual_mov_b32 v147, 0           // 0000001802B0: CA100080 92920080
	s_mov_b32 s2, exec_lo                                      // 0000001802B8: BE82007E
	v_add3_u32 v137, v144, v137, 0x7fff                        // 0000001802BC: D6550089 03FF1390 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:10                   // 0000001802C8: DA84000A 0000899A
	v_cmpx_lt_i32_e32 6, v139                                  // 0000001802D0: 7D831686
	s_cbranch_execz 34                                         // 0000001802D4: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1b60>
	ds_load_b32 v137, v253 offset:24                           // 0000001802D8: D8D80018 890000FD
	s_waitcnt lgkmcnt(0)                                       // 0000001802E0: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 0000001802E4: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001802E8: BF870121
	v_mul_f32_e32 v147, 0x3fb8aa3b, v137                       // 0000001802EC: 112712FF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001802F4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 0000001802F8: 020312FF C2CE8ED0
	v_fma_f32 v148, 0x3fb8aa3b, v137, -v147                    // 000000180300: D6130094 864F12FF 3FB8AA3B
	v_rndne_f32_e32 v149, v147                                 // 00000018030C: 7F2A4793
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000180310: BF870112
	v_fmac_f32_e32 v148, 0x32a5705f, v137                      // 000000180314: 572912FF 32A5705F
	v_sub_f32_e32 v147, v147, v149                             // 00000018031C: 09272B93
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000180320: BF870121
	v_add_f32_e32 v147, v147, v148                             // 000000180324: 07272993
	v_cvt_i32_f32_e32 v148, v149                               // 000000180328: 7F281195
	v_exp_f32_e32 v147, v147                                   // 00000018032C: 7F264B93
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180330: BF870095
	.long 0xd71c0093                                           // 000000180334: D71C0093
	v_cndmask_b32_e32 v1, v147, v148, vcc_lo                   // 000000180338: 02032993
	v_cndmask_b32_e64 v147, 0, v147, s1                        // 00000018033C: D5010093 00072680
	.long 0xd41e0001                                           // 000000180344: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 000000180348: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000180350: BF870001
	v_cndmask_b32_e64 v147, 0x7f800000, v147, s1               // 000000180354: D5010093 000726FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000180360: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000180364: BF8700A1
	v_bfe_u32 v137, v147, 16, 1                                // 000000180368: D6100089 02052193
	s_mov_b32 s2, exec_lo                                      // 000000180370: BE82007E
	v_add3_u32 v137, v147, v137, 0x7fff                        // 000000180374: D6550089 03FF1393 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:12                   // 000000180380: DA84000C 0000899A
	v_cmpx_lt_i32_e32 7, v139                                  // 000000180388: 7D831687
	s_cbranch_execz 34                                         // 00000018038C: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1c18>
	ds_load_b32 v137, v253 offset:28                           // 000000180390: D8D8001C 890000FD
	s_waitcnt lgkmcnt(0)                                       // 000000180398: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000018039C: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001803A0: BF870091
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 0000001803A4: 112512FF 3FB8AA3B
	v_fma_f32 v148, 0x3fb8aa3b, v137, -v146                    // 0000001803AC: D6130094 864B12FF 3FB8AA3B
	v_rndne_f32_e32 v149, v146                                 // 0000001803B8: 7F2A4792
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001803BC: BF870191
	v_sub_f32_e32 v146, v146, v149                             // 0000001803C0: 09252B92
	v_fmac_f32_e32 v148, 0x32a5705f, v137                      // 0000001803C4: 572912FF 32A5705F
	.long 0xd41b0001                                           // 0000001803CC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 0000001803D0: 020312FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001803D8: BF870122
	v_add_f32_e32 v146, v146, v148                             // 0000001803DC: 07252992
	v_cvt_i32_f32_e32 v148, v149                               // 0000001803E0: 7F281195
	v_exp_f32_e32 v146, v146                                   // 0000001803E4: 7F244B92
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001803E8: BF870095
	.long 0xd71c0092                                           // 0000001803EC: D71C0092
	v_cndmask_b32_e32 v1, v146, v148, vcc_lo                   // 0000001803F0: 02032992
	v_cndmask_b32_e64 v146, 0, v146, s1                        // 0000001803F4: D5010092 00072480
	.long 0xd41e0001                                           // 0000001803FC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 000000180400: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 000000180408: BF870001
	v_cndmask_b32_e64 v146, 0x7f800000, v146, s1               // 00000018040C: D5010092 000724FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000180418: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000018041C: BF870131
	v_bfe_u32 v137, v146, 16, 1                                // 000000180420: D6100089 02052192
	v_dual_mov_b32 v148, 0 :: v_dual_mov_b32 v149, 0           // 000000180428: CA100080 94940080
	s_mov_b32 s2, exec_lo                                      // 000000180430: BE82007E
	v_add3_u32 v137, v146, v137, 0x7fff                        // 000000180434: D6550089 03FF1392 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:14                   // 000000180440: DA84000E 0000899A
	v_cmpx_lt_i32_e32 8, v139                                  // 000000180448: 7D831688
	s_cbranch_execz 33                                         // 00000018044C: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1cd4>
	ds_load_b32 v137, v253 offset:32                           // 000000180450: D8D80020 890000FD
	s_waitcnt lgkmcnt(0)                                       // 000000180458: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 00000018045C: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000180460: BF870121
	v_mul_f32_e32 v149, 0x3fb8aa3b, v137                       // 000000180464: 112B12FF 3FB8AA3B
	.long 0xd41b0001                                           // 00000018046C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 000000180470: 020312FF C2CE8ED0
	v_fma_f32 v150, 0x3fb8aa3b, v137, -v149                    // 000000180478: D6130096 865712FF 3FB8AA3B
	v_rndne_f32_e32 v151, v149                                 // 000000180484: 7F2E4795
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180488: BF870091
	v_dual_fmac_f32 v150, 0x32a5705f, v137 :: v_dual_sub_f32 v149, v149, v151// 00000018048C: C80B12FF 96952F95 32A5705F
	v_add_f32_e32 v149, v149, v150                             // 000000180498: 072B2D95
	v_cvt_i32_f32_e32 v150, v151                               // 00000018049C: 7F2C1197
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001804A0: BF870292
	v_exp_f32_e32 v149, v149                                   // 0000001804A4: 7F2A4B95
	.long 0xd71c0095                                           // 0000001804A8: D71C0095
	v_cndmask_b32_e32 v1, v149, v150, vcc_lo                   // 0000001804AC: 02032D95
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001804B0: BF8700A1
	v_cndmask_b32_e64 v149, 0, v149, s1                        // 0000001804B4: D5010095 00072A80
	.long 0xd41e0001                                           // 0000001804BC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 0000001804C0: 020312FF 42B17218
	v_cndmask_b32_e64 v149, 0x7f800000, v149, s1               // 0000001804C8: D5010095 00072AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001804D4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001804D8: BF8700A1
	v_bfe_u32 v137, v149, 16, 1                                // 0000001804DC: D6100089 02052195
	s_mov_b32 s2, exec_lo                                      // 0000001804E4: BE82007E
	v_add3_u32 v137, v149, v137, 0x7fff                        // 0000001804E8: D6550089 03FF1395 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:16                   // 0000001804F4: DA840010 0000899A
	v_cmpx_lt_i32_e32 9, v139                                  // 0000001804FC: 7D831689
	s_cbranch_execz 34                                         // 000000180500: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1d8c>
	ds_load_b32 v137, v253 offset:36                           // 000000180504: D8D80024 890000FD
	s_waitcnt lgkmcnt(0)                                       // 00000018050C: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 000000180510: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180514: BF870091
	v_mul_f32_e32 v148, 0x3fb8aa3b, v137                       // 000000180518: 112912FF 3FB8AA3B
	v_fma_f32 v150, 0x3fb8aa3b, v137, -v148                    // 000000180520: D6130096 865312FF 3FB8AA3B
	v_rndne_f32_e32 v151, v148                                 // 00000018052C: 7F2E4794
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000180530: BF870191
	v_sub_f32_e32 v148, v148, v151                             // 000000180534: 09292F94
	v_fmac_f32_e32 v150, 0x32a5705f, v137                      // 000000180538: 572D12FF 32A5705F
	.long 0xd41b0001                                           // 000000180540: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 000000180544: 020312FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018054C: BF870122
	v_add_f32_e32 v148, v148, v150                             // 000000180550: 07292D94
	v_cvt_i32_f32_e32 v150, v151                               // 000000180554: 7F2C1197
	v_exp_f32_e32 v148, v148                                   // 000000180558: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018055C: BF870095
	.long 0xd71c0094                                           // 000000180560: D71C0094
	v_cndmask_b32_e32 v1, v148, v150, vcc_lo                   // 000000180564: 02032D94
	v_cndmask_b32_e64 v148, 0, v148, s1                        // 000000180568: D5010094 00072880
	.long 0xd41e0001                                           // 000000180570: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 000000180574: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018057C: BF870001
	v_cndmask_b32_e64 v148, 0x7f800000, v148, s1               // 000000180580: D5010094 000728FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000018058C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000180590: BF870131
	v_bfe_u32 v137, v148, 16, 1                                // 000000180594: D6100089 02052194
	v_dual_mov_b32 v150, 0 :: v_dual_mov_b32 v151, 0           // 00000018059C: CA100080 96960080
	s_mov_b32 s2, exec_lo                                      // 0000001805A4: BE82007E
	v_add3_u32 v137, v148, v137, 0x7fff                        // 0000001805A8: D6550089 03FF1394 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:18                   // 0000001805B4: DA840012 0000899A
	v_cmpx_lt_i32_e32 10, v139                                 // 0000001805BC: 7D83168A
	s_cbranch_execz 34                                         // 0000001805C0: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1e4c>
	ds_load_b32 v137, v253 offset:40                           // 0000001805C4: D8D80028 890000FD
	s_waitcnt lgkmcnt(0)                                       // 0000001805CC: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 0000001805D0: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001805D4: BF870121
	v_mul_f32_e32 v151, 0x3fb8aa3b, v137                       // 0000001805D8: 112F12FF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001805E0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 0000001805E4: 020312FF C2CE8ED0
	v_fma_f32 v157, 0x3fb8aa3b, v137, -v151                    // 0000001805EC: D613009D 865F12FF 3FB8AA3B
	v_rndne_f32_e32 v161, v151                                 // 0000001805F8: 7F424797
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001805FC: BF870112
	v_fmac_f32_e32 v157, 0x32a5705f, v137                      // 000000180600: 573B12FF 32A5705F
	v_sub_f32_e32 v151, v151, v161                             // 000000180608: 092F4397
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018060C: BF870121
	v_add_f32_e32 v151, v151, v157                             // 000000180610: 072F3B97
	v_cvt_i32_f32_e32 v157, v161                               // 000000180614: 7F3A11A1
	v_exp_f32_e32 v151, v151                                   // 000000180618: 7F2E4B97
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018061C: BF870095
	.long 0xd71c0097                                           // 000000180620: D71C0097
	v_cndmask_b32_e32 v1, v151, v157, vcc_lo                   // 000000180624: 02033B97
	v_cndmask_b32_e64 v151, 0, v151, s1                        // 000000180628: D5010097 00072E80
	.long 0xd41e0001                                           // 000000180630: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 000000180634: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018063C: BF870001
	v_cndmask_b32_e64 v151, 0x7f800000, v151, s1               // 000000180640: D5010097 00072EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000018064C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000180650: BF8700A1
	v_bfe_u32 v137, v151, 16, 1                                // 000000180654: D6100089 02052197
	s_mov_b32 s2, exec_lo                                      // 00000018065C: BE82007E
	v_add3_u32 v137, v151, v137, 0x7fff                        // 000000180660: D6550089 03FF1397 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:20                   // 00000018066C: DA840014 0000899A
	v_cmpx_lt_i32_e32 11, v139                                 // 000000180674: 7D83168B
	s_cbranch_execz 34                                         // 000000180678: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1f04>
	ds_load_b32 v137, v253 offset:44                           // 00000018067C: D8D8002C 890000FD
	s_waitcnt lgkmcnt(0)                                       // 000000180684: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 000000180688: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018068C: BF870091
	v_mul_f32_e32 v150, 0x3fb8aa3b, v137                       // 000000180690: 112D12FF 3FB8AA3B
	v_fma_f32 v157, 0x3fb8aa3b, v137, -v150                    // 000000180698: D613009D 865B12FF 3FB8AA3B
	v_rndne_f32_e32 v161, v150                                 // 0000001806A4: 7F424796
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001806A8: BF870191
	v_sub_f32_e32 v150, v150, v161                             // 0000001806AC: 092D4396
	v_fmac_f32_e32 v157, 0x32a5705f, v137                      // 0000001806B0: 573B12FF 32A5705F
	.long 0xd41b0001                                           // 0000001806B8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 0000001806BC: 020312FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001806C4: BF870122
	v_add_f32_e32 v150, v150, v157                             // 0000001806C8: 072D3B96
	v_cvt_i32_f32_e32 v157, v161                               // 0000001806CC: 7F3A11A1
	v_exp_f32_e32 v150, v150                                   // 0000001806D0: 7F2C4B96
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001806D4: BF870095
	.long 0xd71c0096                                           // 0000001806D8: D71C0096
	v_cndmask_b32_e32 v1, v150, v157, vcc_lo                   // 0000001806DC: 02033B96
	v_cndmask_b32_e64 v150, 0, v150, s1                        // 0000001806E0: D5010096 00072C80
	.long 0xd41e0001                                           // 0000001806E8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 0000001806EC: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001806F4: BF870001
	v_cndmask_b32_e64 v150, 0x7f800000, v150, s1               // 0000001806F8: D5010096 00072CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000180704: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000180708: BF870131
	v_bfe_u32 v137, v150, 16, 1                                // 00000018070C: D6100089 02052196
	v_dual_mov_b32 v249, 0 :: v_dual_mov_b32 v250, 0           // 000000180714: CA100080 F9FA0080
	s_mov_b32 s2, exec_lo                                      // 00000018071C: BE82007E
	v_add3_u32 v137, v150, v137, 0x7fff                        // 000000180720: D6550089 03FF1396 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:22                   // 00000018072C: DA840016 0000899A
	v_cmpx_lt_i32_e32 12, v139                                 // 000000180734: 7D83168C
	s_cbranch_execz 34                                         // 000000180738: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x1fc4>
	ds_load_b32 v137, v253 offset:48                           // 00000018073C: D8D80030 890000FD
	s_waitcnt lgkmcnt(0)                                       // 000000180744: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 000000180748: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018074C: BF870121
	v_mul_f32_e32 v157, 0x3fb8aa3b, v137                       // 000000180750: 113B12FF 3FB8AA3B
	.long 0xd41b0001                                           // 000000180758: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 00000018075C: 020312FF C2CE8ED0
	v_fma_f32 v161, 0x3fb8aa3b, v137, -v157                    // 000000180764: D61300A1 867712FF 3FB8AA3B
	v_rndne_f32_e32 v162, v157                                 // 000000180770: 7F44479D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000180774: BF870112
	v_fmac_f32_e32 v161, 0x32a5705f, v137                      // 000000180778: 574312FF 32A5705F
	v_sub_f32_e32 v157, v157, v162                             // 000000180780: 093B459D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000180784: BF870121
	v_add_f32_e32 v157, v157, v161                             // 000000180788: 073B439D
	v_cvt_i32_f32_e32 v161, v162                               // 00000018078C: 7F4211A2
	v_exp_f32_e32 v157, v157                                   // 000000180790: 7F3A4B9D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180794: BF870095
	.long 0xd71c009d                                           // 000000180798: D71C009D
	v_cndmask_b32_e32 v1, v157, v161, vcc_lo                   // 00000018079C: 0203439D
	v_cndmask_b32_e64 v157, 0, v157, s1                        // 0000001807A0: D501009D 00073A80
	.long 0xd41e0001                                           // 0000001807A8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 0000001807AC: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001807B4: BF870001
	v_cndmask_b32_e64 v250, 0x7f800000, v157, s1               // 0000001807B8: D50100FA 00073AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001807C4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001807C8: BF8700A1
	v_bfe_u32 v137, v250, 16, 1                                // 0000001807CC: D6100089 020521FA
	s_mov_b32 s2, exec_lo                                      // 0000001807D4: BE82007E
	v_add3_u32 v137, v250, v137, 0x7fff                        // 0000001807D8: D6550089 03FF13FA 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:24                   // 0000001807E4: DA840018 0000899A
	v_cmpx_lt_i32_e32 13, v139                                 // 0000001807EC: 7D83168D
	s_cbranch_execz 34                                         // 0000001807F0: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x207c>
	ds_load_b32 v137, v253 offset:52                           // 0000001807F4: D8D80034 890000FD
	s_waitcnt lgkmcnt(0)                                       // 0000001807FC: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 000000180800: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000180804: BF870121
	v_mul_f32_e32 v157, 0x3fb8aa3b, v137                       // 000000180808: 113B12FF 3FB8AA3B
	.long 0xd41b0001                                           // 000000180810: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 000000180814: 020312FF C2CE8ED0
	v_fma_f32 v161, 0x3fb8aa3b, v137, -v157                    // 00000018081C: D61300A1 867712FF 3FB8AA3B
	v_rndne_f32_e32 v162, v157                                 // 000000180828: 7F44479D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000018082C: BF870112
	v_fmac_f32_e32 v161, 0x32a5705f, v137                      // 000000180830: 574312FF 32A5705F
	v_sub_f32_e32 v157, v157, v162                             // 000000180838: 093B459D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000018083C: BF870121
	v_add_f32_e32 v157, v157, v161                             // 000000180840: 073B439D
	v_cvt_i32_f32_e32 v161, v162                               // 000000180844: 7F4211A2
	v_exp_f32_e32 v157, v157                                   // 000000180848: 7F3A4B9D
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018084C: BF870095
	.long 0xd71c009d                                           // 000000180850: D71C009D
	v_cndmask_b32_e32 v1, v157, v161, vcc_lo                   // 000000180854: 0203439D
	v_cndmask_b32_e64 v157, 0, v157, s1                        // 000000180858: D501009D 00073A80
	.long 0xd41e0001                                           // 000000180860: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 000000180864: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000018086C: BF870001
	v_cndmask_b32_e64 v249, 0x7f800000, v157, s1               // 000000180870: D50100F9 00073AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000018087C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000180880: BF8701C1
	v_bfe_u32 v137, v249, 16, 1                                // 000000180884: D6100089 020521F9
	v_mov_b32_e32 v157, 0                                      // 00000018088C: 7F3A0280
	v_mov_b32_e32 v161, 0                                      // 000000180890: 7F420280
	s_mov_b32 s2, exec_lo                                      // 000000180894: BE82007E
	v_add3_u32 v137, v249, v137, 0x7fff                        // 000000180898: D6550089 03FF13F9 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:26                   // 0000001808A4: DA84001A 0000899A
	v_cmpx_lt_i32_e32 14, v139                                 // 0000001808AC: 7D83168E
	s_cbranch_execz 33                                         // 0000001808B0: BFA50021 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x2138>
	ds_load_b32 v137, v253 offset:56                           // 0000001808B4: D8D80038 890000FD
	s_waitcnt lgkmcnt(0)                                       // 0000001808BC: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 0000001808C0: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001808C4: BF870121
	v_mul_f32_e32 v161, 0x3fb8aa3b, v137                       // 0000001808C8: 114312FF 3FB8AA3B
	.long 0xd41b0001                                           // 0000001808D0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 0000001808D4: 020312FF C2CE8ED0
	v_fma_f32 v162, 0x3fb8aa3b, v137, -v161                    // 0000001808DC: D61300A2 868712FF 3FB8AA3B
	v_rndne_f32_e32 v163, v161                                 // 0000001808E8: 7F4647A1
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001808EC: BF870091
	v_dual_fmac_f32 v162, 0x32a5705f, v137 :: v_dual_sub_f32 v161, v161, v163// 0000001808F0: C80B12FF A2A147A1 32A5705F
	v_add_f32_e32 v161, v161, v162                             // 0000001808FC: 074345A1
	v_cvt_i32_f32_e32 v162, v163                               // 000000180900: 7F4411A3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000180904: BF870292
	v_exp_f32_e32 v161, v161                                   // 000000180908: 7F424BA1
	.long 0xd71c00a1                                           // 00000018090C: D71C00A1
	v_cndmask_b32_e32 v1, v161, v162, vcc_lo                   // 000000180910: 020345A1
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000180914: BF8700A1
	v_cndmask_b32_e64 v161, 0, v161, s1                        // 000000180918: D50100A1 00074280
	.long 0xd41e0001                                           // 000000180920: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 000000180924: 020312FF 42B17218
	v_cndmask_b32_e64 v161, 0x7f800000, v161, s1               // 00000018092C: D50100A1 000742FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000180938: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000018093C: BF8700A1
	v_bfe_u32 v137, v161, 16, 1                                // 000000180940: D6100089 020521A1
	s_mov_b32 s2, exec_lo                                      // 000000180948: BE82007E
	v_add3_u32 v137, v161, v137, 0x7fff                        // 00000018094C: D6550089 03FF13A1 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:28                   // 000000180958: DA84001C 0000899A
	v_cmpx_lt_i32_e32 15, v139                                 // 000000180960: 7D83168F
	s_cbranch_execz 34                                         // 000000180964: BFA50022 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x21f0>
	ds_load_b32 v137, v253 offset:60                           // 000000180968: D8D8003C 890000FD
	s_waitcnt lgkmcnt(0)                                       // 000000180970: BF89FC07
	v_sub_f32_e32 v137, v137, v138                             // 000000180974: 09131589
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000180978: BF870121
	v_mul_f32_e32 v139, 0x3fb8aa3b, v137                       // 00000018097C: 111712FF 3FB8AA3B
	.long 0xd41b0001                                           // 000000180984: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 000000180988: 020312FF C2CE8ED0
	v_fma_f32 v157, 0x3fb8aa3b, v137, -v139                    // 000000180990: D613009D 862F12FF 3FB8AA3B
	v_rndne_f32_e32 v162, v139                                 // 00000018099C: 7F44478B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001809A0: BF870112
	v_fmac_f32_e32 v157, 0x32a5705f, v137                      // 0000001809A4: 573B12FF 32A5705F
	v_sub_f32_e32 v139, v139, v162                             // 0000001809AC: 0917458B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001809B0: BF870121
	v_add_f32_e32 v139, v139, v157                             // 0000001809B4: 07173B8B
	v_cvt_i32_f32_e32 v157, v162                               // 0000001809B8: 7F3A11A2
	v_exp_f32_e32 v139, v139                                   // 0000001809BC: 7F164B8B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001809C0: BF870095
	.long 0xd71c008b                                           // 0000001809C4: D71C008B
	v_cndmask_b32_e32 v1, v139, v157, vcc_lo                   // 0000001809C8: 02033B8B
	v_cndmask_b32_e64 v139, 0, v139, s1                        // 0000001809CC: D501008B 00071680
	.long 0xd41e0001                                           // 0000001809D4: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 0000001809D8: 020312FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001809E0: BF870001
	v_cndmask_b32_e64 v157, 0x7f800000, v139, s1               // 0000001809E4: D501009D 000716FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001809F0: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001809F4: BF870131
	v_bfe_u32 v137, v157, 16, 1                                // 0000001809F8: D6100089 0205219D
	v_mov_b32_e32 v139, 0                                      // 000000180A00: 7F160280
	s_mov_b32 s2, exec_lo                                      // 000000180A04: BE82007E
	v_add3_u32 v137, v157, v137, 0x7fff                        // 000000180A08: D6550089 03FF139D 00007FFF
	ds_store_b16_d16_hi v154, v137 offset:30                   // 000000180A14: DA84001E 0000899A
	v_cmpx_lt_f32_e32 0xefa18f08, v255                         // 000000180A1C: 7D23FEFF EFA18F08
	s_cbranch_execz 30                                         // 000000180A24: BFA5001E <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x22a0>
	v_sub_f32_e32 v137, v255, v138                             // 000000180A28: 091315FF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000180A2C: BF870121
	v_mul_f32_e32 v139, 0x3fb8aa3b, v137                       // 000000180A30: 111712FF 3FB8AA3B
	.long 0xd41b0001                                           // 000000180A38: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 000000180A3C: 020312FF C2CE8ED0
	v_fma_f32 v162, 0x3fb8aa3b, v137, -v139                    // 000000180A44: D61300A2 862F12FF 3FB8AA3B
	v_rndne_f32_e32 v163, v139                                 // 000000180A50: 7F46478B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180A54: BF870091
	v_dual_fmac_f32 v162, 0x32a5705f, v137 :: v_dual_sub_f32 v139, v139, v163// 000000180A58: C80B12FF A28B478B 32A5705F
	v_add_f32_e32 v139, v139, v162                             // 000000180A64: 0717458B
	v_cvt_i32_f32_e32 v162, v163                               // 000000180A68: 7F4411A3
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000180A6C: BF870292
	v_exp_f32_e32 v139, v139                                   // 000000180A70: 7F164B8B
	.long 0xd71c008b                                           // 000000180A74: D71C008B
	v_cndmask_b32_e32 v1, v139, v162, vcc_lo                   // 000000180A78: 0203458B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000180A7C: BF8700A1
	v_cndmask_b32_e64 v139, 0, v139, s1                        // 000000180A80: D501008B 00071680
	.long 0xd41e0001                                           // 000000180A88: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 000000180A8C: 020312FF 42B17218
	v_cndmask_b32_e64 v139, 0x7f800000, v139, s1               // 000000180A94: D501008B 000716FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000180AA0: 8C7E027E
	v_add_f32_e32 v137, v141, v140                             // 000000180AA4: 0713198D
	s_or_b32 s9, s9, exec_lo                                   // 000000180AA8: 8C097E09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180AAC: BF870091
	v_add_f32_e32 v137, v137, v143                             // 000000180AB0: 07131F89
	v_add_f32_e32 v137, v137, v142                             // 000000180AB4: 07131D89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180AB8: BF870091
	v_add_f32_e32 v137, v137, v145                             // 000000180ABC: 07132389
	v_add_f32_e32 v137, v137, v144                             // 000000180AC0: 07132189
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180AC4: BF870091
	v_add_f32_e32 v137, v137, v147                             // 000000180AC8: 07132789
	v_add_f32_e32 v137, v137, v146                             // 000000180ACC: 07132589
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180AD0: BF870091
	v_add_f32_e32 v137, v137, v149                             // 000000180AD4: 07132B89
	v_add_f32_e32 v137, v137, v148                             // 000000180AD8: 07132989
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180ADC: BF870091
	v_add_f32_e32 v137, v137, v151                             // 000000180AE0: 07132F89
	v_add_f32_e32 v137, v137, v150                             // 000000180AE4: 07132D89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180AE8: BF870091
	v_add_f32_e32 v137, v137, v250                             // 000000180AEC: 0713F589
	v_add_f32_e32 v137, v137, v249                             // 000000180AF0: 0713F389
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180AF4: BF870091
	v_add_f32_e32 v137, v137, v161                             // 000000180AF8: 07134389
	v_add_f32_e32 v137, v137, v157                             // 000000180AFC: 07133B89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180B00: BF870091
	v_fmac_f32_e32 v137, v252, v139                            // 000000180B04: 571317FC
	v_dual_mov_b32 v255, v138 :: v_dual_mov_b32 v252, v137     // 000000180B08: CA10018A FFFC0189
	s_or_b32 exec_lo, exec_lo, s10                             // 000000180B10: 8C7E0A7E
	s_and_saveexec_b32 s1, s9                                  // 000000180B14: BE812009
	s_cbranch_execz 63853                                      // 000000180B18: BFA5F96D <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x8d0>
	ds_store_b32 v179, v139                                    // 000000180B1C: D8340000 00008BB3
	s_branch 63850                                             // 000000180B24: BFA0F96A <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x8d0>
	s_or_b32 exec_lo, exec_lo, s21                             // 000000180B28: 8C7E157E
	v_lshrrev_b32_e32 v160, 5, v0                              // 000000180B2C: 33400085
	v_and_b32_e32 v8, 15, v0                                   // 000000180B30: 3610008F
	v_bfe_u32 v137, v0, 4, 1                                   // 000000180B34: D6100089 02050900
	v_and_b32_e32 v15, 31, v0                                  // 000000180B3C: 361E009F
	s_or_b32 exec_lo, exec_lo, s18                             // 000000180B40: 8C7E127E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000180B44: BF870009
	s_mov_b32 s0, exec_lo                                      // 000000180B48: BE80007E
	s_waitcnt_vscnt null, 0x0                                  // 000000180B4C: BC7C0000
	s_barrier                                                  // 000000180B50: BFBD0000
	buffer_gl0_inv                                             // 000000180B54: E0AC0000 00000000
	v_cmpx_gt_u32_e32 12, v15                                  // 000000180B5C: 7D981E8C
	s_cbranch_execz 8                                          // 000000180B60: BFA50008 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x2384>
	v_lshlrev_b32_e32 v7, 6, v160                              // 000000180B64: 300F4086
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180B68: BF870091
	v_lshl_add_u32 v7, v15, 2, v7                              // 000000180B6C: D6460007 041D050F
	v_add_nc_u32_e32 v7, 0x50, v7                              // 000000180B74: 4A0E0EFF 00000050
	ds_store_2addr_stride64_b32 v7, v252, v255 offset0:249 offset1:250// 000000180B7C: D83CFAF9 00FFFC07
	s_or_b32 exec_lo, exec_lo, s0                              // 000000180B84: 8C7E007E
	v_mul_u32_u24_e32 v7, 12, v160                             // 000000180B88: 160F408C
	s_mov_b32 s1, 0                                            // 000000180B8C: BE810080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180B90: BF870091
	v_or_b32_e32 v7, v7, v137                                  // 000000180B94: 380F1307
	v_lshlrev_b32_e32 v7, 10, v7                               // 000000180B98: 300E0E8A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180B9C: BF870091
	v_lshl_or_b32 v7, v8, 2, v7                                // 000000180BA0: D6560007 041D0508
	v_add_nc_u32_e32 v8, 0x800, v7                             // 000000180BA8: 4A100EFF 00000800
	v_add_nc_u32_e32 v15, 0x1000, v7                           // 000000180BB0: 4A1E0EFF 00001000
	v_add_nc_u32_e32 v16, 0x1800, v7                           // 000000180BB8: 4A200EFF 00001800
	v_add_nc_u32_e32 v23, 0x2000, v7                           // 000000180BC0: 4A2E0EFF 00002000
	v_add_nc_u32_e32 v24, 0x2800, v7                           // 000000180BC8: 4A300EFF 00002800
	v_add_nc_u32_e32 v7, 0x3000, v7                            // 000000180BD0: 4A0E0EFF 00003000
	ds_store_2addr_b32 v8, v105, v121 offset1:16               // 000000180BD8: D8381000 00796908
	ds_store_2addr_b32 v15, v106, v122 offset1:16              // 000000180BE0: D8381000 007A6A0F
	ds_store_2addr_b32 v16, v107, v123 offset1:16              // 000000180BE8: D8381000 007B6B10
	ds_store_2addr_b32 v23, v108, v124 offset1:16              // 000000180BF0: D8381000 007C6C17
	ds_store_2addr_b32 v24, v109, v125 offset1:16              // 000000180BF8: D8381000 007D6D18
	ds_store_2addr_b32 v7, v110, v126 offset1:16               // 000000180C00: D8381000 007E6E07
	ds_store_2addr_b32 v8, v89, v113 offset0:32 offset1:48     // 000000180C08: D8383020 00715908
	ds_store_2addr_b32 v15, v90, v114 offset0:32 offset1:48    // 000000180C10: D8383020 00725A0F
	ds_store_2addr_b32 v16, v91, v115 offset0:32 offset1:48    // 000000180C18: D8383020 00735B10
	ds_store_2addr_b32 v23, v92, v116 offset0:32 offset1:48    // 000000180C20: D8383020 00745C17
	ds_store_2addr_b32 v24, v93, v117 offset0:32 offset1:48    // 000000180C28: D8383020 00755D18
	ds_store_2addr_b32 v7, v94, v118 offset0:32 offset1:48     // 000000180C30: D8383020 00765E07
	ds_store_2addr_b32 v8, v73, v97 offset0:64 offset1:80      // 000000180C38: D8385040 00614908
	ds_store_2addr_b32 v15, v74, v98 offset0:64 offset1:80     // 000000180C40: D8385040 00624A0F
	ds_store_2addr_b32 v16, v75, v99 offset0:64 offset1:80     // 000000180C48: D8385040 00634B10
	ds_store_2addr_b32 v23, v76, v100 offset0:64 offset1:80    // 000000180C50: D8385040 00644C17
	ds_store_2addr_b32 v24, v77, v101 offset0:64 offset1:80    // 000000180C58: D8385040 00654D18
	ds_store_2addr_b32 v7, v78, v102 offset0:64 offset1:80     // 000000180C60: D8385040 00664E07
	ds_store_2addr_b32 v8, v57, v81 offset0:96 offset1:112     // 000000180C68: D8387060 00513908
	ds_store_2addr_b32 v15, v58, v82 offset0:96 offset1:112    // 000000180C70: D8387060 00523A0F
	ds_store_2addr_b32 v16, v59, v83 offset0:96 offset1:112    // 000000180C78: D8387060 00533B10
	ds_store_2addr_b32 v23, v60, v84 offset0:96 offset1:112    // 000000180C80: D8387060 00543C17
	ds_store_2addr_b32 v24, v61, v85 offset0:96 offset1:112    // 000000180C88: D8387060 00553D18
	ds_store_2addr_b32 v7, v62, v86 offset0:96 offset1:112     // 000000180C90: D8387060 00563E07
	ds_store_2addr_b32 v8, v49, v65 offset0:128 offset1:144    // 000000180C98: D8389080 00413108
	ds_store_2addr_b32 v15, v50, v66 offset0:128 offset1:144   // 000000180CA0: D8389080 0042320F
	ds_store_2addr_b32 v16, v51, v67 offset0:128 offset1:144   // 000000180CA8: D8389080 00433310
	ds_store_2addr_b32 v23, v52, v68 offset0:128 offset1:144   // 000000180CB0: D8389080 00443417
	ds_store_2addr_b32 v24, v53, v69 offset0:128 offset1:144   // 000000180CB8: D8389080 00453518
	ds_store_2addr_b32 v7, v54, v70 offset0:128 offset1:144    // 000000180CC0: D8389080 00463607
	ds_store_2addr_b32 v8, v33, v41 offset0:160 offset1:176    // 000000180CC8: D838B0A0 00292108
	ds_store_2addr_b32 v15, v34, v42 offset0:160 offset1:176   // 000000180CD0: D838B0A0 002A220F
	ds_store_2addr_b32 v16, v35, v43 offset0:160 offset1:176   // 000000180CD8: D838B0A0 002B2310
	ds_store_2addr_b32 v23, v36, v44 offset0:160 offset1:176   // 000000180CE0: D838B0A0 002C2417
	ds_store_2addr_b32 v24, v37, v45 offset0:160 offset1:176   // 000000180CE8: D838B0A0 002D2518
	ds_store_2addr_b32 v7, v38, v46 offset0:160 offset1:176    // 000000180CF0: D838B0A0 002E2607
	ds_store_2addr_b32 v8, v17, v25 offset0:192 offset1:208    // 000000180CF8: D838D0C0 00191108
	ds_store_2addr_b32 v15, v18, v26 offset0:192 offset1:208   // 000000180D00: D838D0C0 001A120F
	ds_store_2addr_b32 v16, v19, v27 offset0:192 offset1:208   // 000000180D08: D838D0C0 001B1310
	ds_store_2addr_b32 v23, v20, v28 offset0:192 offset1:208   // 000000180D10: D838D0C0 001C1417
	ds_store_2addr_b32 v24, v21, v29 offset0:192 offset1:208   // 000000180D18: D838D0C0 001D1518
	ds_store_2addr_b32 v7, v22, v30 offset0:192 offset1:208    // 000000180D20: D838D0C0 001E1607
	ds_store_2addr_b32 v8, v9, v1 offset0:224 offset1:240      // 000000180D28: D838F0E0 00010908
	ds_store_2addr_b32 v15, v10, v2 offset0:224 offset1:240    // 000000180D30: D838F0E0 00020A0F
	ds_store_2addr_b32 v16, v11, v3 offset0:224 offset1:240    // 000000180D38: D838F0E0 00030B10
	ds_store_2addr_b32 v23, v12, v4 offset0:224 offset1:240    // 000000180D40: D838F0E0 00040C17
	ds_store_2addr_b32 v24, v13, v5 offset0:224 offset1:240    // 000000180D48: D838F0E0 00050D18
	ds_store_2addr_b32 v7, v14, v6 offset0:224 offset1:240     // 000000180D50: D838F0E0 00060E07
	s_waitcnt lgkmcnt(0)                                       // 000000180D58: BF89FC07
	s_barrier                                                  // 000000180D5C: BFBD0000
	buffer_gl0_inv                                             // 000000180D60: E0AC0000 00000000
	s_branch 135                                               // 000000180D68: BFA00087 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x2788>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000180D6C: 8C7E007E
	v_add_lshl_u32 v2, v5, s3, 8                               // 000000180D70: D6470002 02200705
	s_waitcnt lgkmcnt(5)                                       // 000000180D78: BF89FC57
	v_fma_f32 v7, v6, v7, 0                                    // 000000180D7C: D6130007 02020F06
	s_waitcnt lgkmcnt(4)                                       // 000000180D84: BF89FC47
	v_fma_f32 v6, v6, v8, 0                                    // 000000180D88: D6130006 02021106
	v_ashrrev_i32_e32 v5, 31, v2                               // 000000180D90: 340A049F
	.long 0xd7006a02                                           // 000000180D94: D7006A02
	v_cndmask_b32_e32 v1, s16, v2, vcc_lo                      // 000000180D98: 02020410
	s_waitcnt lgkmcnt(2)                                       // 000000180D9C: BF89FC27
	s_delay_alu instid0(VALU_DEP_3)                            // 000000180DA0: BF870003
	v_fmac_f32_e32 v6, v13, v14                                // 000000180DA4: 560C1D0D
	v_fmac_f32_e32 v7, v13, v4                                 // 000000180DA8: 560E090D
	v_add_co_ci_u32_e64 v11, null, s17, v5, vcc_lo             // 000000180DAC: D5207C0B 01AA0A11
	v_or_b32_e32 v10, v2, v10                                  // 000000180DB4: 38141502
	ds_load_b32 v3, v3 offset:192                              // 000000180DB8: D8D800C0 03000003
	ds_load_b32 v5, v9 offset:36864                            // 000000180DC0: D8D89000 05000009
	s_waitcnt lgkmcnt(2)                                       // 000000180DC8: BF89FC27
	v_fmac_f32_e32 v6, v12, v15                                // 000000180DCC: 560C1F0C
	v_fmac_f32_e32 v7, v12, v1                                 // 000000180DD0: 560E030C
	.long 0xd73c000a                                           // 000000180DD4: D73C000A
	v_cndmask_b32_e32 v1, 1, v10, vcc_lo                       // 000000180DD8: 02021481
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180DDC: BF870091
	.long 0xd7006a11                                           // 000000180DE0: D7006A11
	v_cndmask_b32_e32 v1, s4, v10, vcc_lo                      // 000000180DE4: 02021404
	v_add_co_ci_u32_e64 v18, null, s5, v11, vcc_lo             // 000000180DE8: D5207C12 01AA1605
	global_load_u16 v2, v[17:18], off                          // 000000180DF0: DC4A0000 027C0011
	s_waitcnt vmcnt(0) lgkmcnt(1)                              // 000000180DF8: BF890017
	v_dual_fmac_f32 v7, v16, v3 :: v_dual_lshlrev_b32 v2, 16, v2// 000000180DFC: C8220710 07020490
	s_waitcnt lgkmcnt(0)                                       // 000000180E04: BF89FC07
	v_fmac_f32_e32 v6, v16, v5                                 // 000000180E08: 560C0B10
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000180E0C: BF870122
	v_mul_f32_e32 v4, 0xbfb8aa3b, v2                           // 000000180E10: 100804FF BFB8AA3B
	.long 0xd41e0000                                           // 000000180E18: D41E0000
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v2, vcc_lo               // 000000180E1C: 020204FF 42CE8ED0
	v_fma_f32 v5, 0xbfb8aa3b, v2, -v4                          // 000000180E24: D6130005 841204FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000180E30: BF870131
	v_fmac_f32_e32 v5, 0xb2a5705f, v2                          // 000000180E34: 560A04FF B2A5705F
	v_div_scale_f32 v1, null, v7, v7, v6                       // 000000180E3C: D6FC7C01 041A0F07
	v_div_scale_f32 v12, vcc_lo, v6, v7, v6                    // 000000180E44: D6FC6A0C 041A0F06
	v_rcp_f32_e32 v3, v1                                       // 000000180E4C: 7E065501
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180E50: BF870095
	v_fma_f32 v9, -v1, v3, 1.0                                 // 000000180E54: D6130009 23CA0701
	v_fmac_f32_e32 v3, v9, v3                                  // 000000180E5C: 56060709
	v_rndne_f32_e32 v8, v4                                     // 000000180E60: 7E104704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000180E64: BF870121
	v_sub_f32_e32 v4, v4, v8                                   // 000000180E68: 08081104
	v_cvt_i32_f32_e32 v8, v8                                   // 000000180E6C: 7E101108
	v_add_f32_e32 v4, v4, v5                                   // 000000180E70: 06080B04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000180E74: BF870291
	v_exp_f32_e32 v4, v4                                       // 000000180E78: 7E084B04
	.long 0xd71c0004                                           // 000000180E7C: D71C0004
	v_cndmask_b32_e32 v1, v4, v8, vcc_lo                       // 000000180E80: 02021104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000180E84: BF8700A1
	v_cndmask_b32_e64 v4, 0, v4, s0                            // 000000180E88: D5010004 00020880
	v_mul_f32_e32 v5, v12, v3                                  // 000000180E90: 100A070C
	v_fma_f32 v9, -v1, v5, v12                                 // 000000180E94: D6130009 24320B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180E9C: BF870091
	v_fmac_f32_e32 v5, v9, v3                                  // 000000180EA0: 560A0709
	v_fma_f32 v1, -v1, v5, v12                                 // 000000180EA4: D6130001 24320B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000180EAC: BF870121
	v_div_fmas_f32 v1, v1, v3, v5                              // 000000180EB0: D6370001 04160701
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v2                   // 000000180EB8: 7C3604FF C2B17218
	v_div_fixup_f32 v1, v1, v7, v6                             // 000000180EC0: D6270001 041A0F01
	v_cndmask_b32_e32 v2, 0x7f800000, v4, vcc_lo               // 000000180EC8: 020408FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180ED0: BF870091
	v_add_f32_e32 v2, 1.0, v2                                  // 000000180ED4: 060404F2
	v_div_scale_f32 v3, null, v2, v2, v1                       // 000000180ED8: D6FC7C03 04060502
	v_div_scale_f32 v6, vcc_lo, v1, v2, v1                     // 000000180EE0: D6FC6A06 04060501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000180EE8: BF870292
	v_rcp_f32_e32 v4, v3                                       // 000000180EEC: 7E085503
	v_fma_f32 v5, -v3, v4, 1.0                                 // 000000180EF0: D6130005 23CA0903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180EF8: BF870091
	v_fmac_f32_e32 v4, v5, v4                                  // 000000180EFC: 56080905
	v_mul_f32_e32 v5, v6, v4                                   // 000000180F00: 100A0906
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180F04: BF870091
	v_fma_f32 v7, -v3, v5, v6                                  // 000000180F08: D6130007 241A0B03
	v_fmac_f32_e32 v5, v7, v4                                  // 000000180F10: 560A0907
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180F14: BF870091
	v_fma_f32 v3, -v3, v5, v6                                  // 000000180F18: D6130003 241A0B03
	v_div_fmas_f32 v3, v3, v4, v5                              // 000000180F20: D6370003 04160903
	v_cmp_lt_u32_e32 vcc_lo, 0xb7f, v0                         // 000000180F28: 7C9200FF 00000B7F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000180F30: BF870132
	v_div_fixup_f32 v1, v3, v2, v1                             // 000000180F34: D6270001 04060503
	v_add_nc_u32_e32 v3, 0x80, v0                              // 000000180F3C: 4A0600FF 00000080
	s_or_b32 s1, vcc_lo, s1                                    // 000000180F44: 8C01016A
	v_bfe_u32 v2, v1, 16, 1                                    // 000000180F48: D6100002 02052101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000180F50: BF870112
	v_mov_b32_e32 v0, v3                                       // 000000180F54: 7E000303
	v_add3_u32 v4, v1, v2, 0x7fff                              // 000000180F58: D6550004 03FE0501 00007FFF
	.long 0xd7000001                                           // 000000180F64: D7000001
	v_cndmask_b32_e32 v1, s6, v10, vcc_lo                      // 000000180F68: 02021406
	s_delay_alu instid0(VALU_DEP_1)                            // 000000180F6C: BF870001
	v_add_co_ci_u32_e64 v2, null, s7, v11, s0                  // 000000180F70: D5207C02 00021607
	global_store_d16_hi_b16 v[1:2], v4, off                    // 000000180F78: DC960000 007C0401
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000180F80: 917E017E
	s_cbranch_execz 173                                        // 000000180F84: BFA500AD <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x2a3c>
	v_lshrrev_b32_e32 v5, 8, v0                                // 000000180F88: 320A0088
	s_mov_b32 s0, exec_lo                                      // 000000180F8C: BE80007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180F90: BF870091
	v_lshlrev_b32_e32 v7, 2, v5                                // 000000180F94: 300E0A82
	v_add_nc_u32_e32 v1, 0xf800, v7                            // 000000180F98: 4A020EFF 0000F800
	ds_load_2addr_b32 v[3:4], v1 offset0:148 offset1:164       // 000000180FA0: D8DCA494 03000001
	ds_load_2addr_b32 v[1:2], v1 offset0:180 offset1:196       // 000000180FA8: D8DCC4B4 01000001
	s_waitcnt lgkmcnt(1)                                       // 000000180FB0: BF89FC17
	v_max3_f32 v6, v3, 0xf149f2ca, v4                          // 000000180FB4: D61C0006 0411FF03 F149F2CA
	s_waitcnt lgkmcnt(0)                                       // 000000180FC0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000180FC4: BF870001
	v_max3_f32 v11, v6, v1, v2                                 // 000000180FC8: D61C000B 040A0306
	v_mov_b32_e32 v6, 0                                        // 000000180FD0: 7E0C0280
	v_cmpx_lt_f32_e32 0xefa18f08, v3                           // 000000180FD4: 7D2206FF EFA18F08
	s_cbranch_execz 27                                         // 000000180FDC: BFA5001B <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x284c>
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000180FE0: BF870093
	v_sub_f32_e32 v3, v3, v11                                  // 000000180FE4: 08061703
	v_mul_f32_e32 v6, 0x3fb8aa3b, v3                           // 000000180FE8: 100C06FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000180FF0: BF8700A1
	v_fma_f32 v8, 0x3fb8aa3b, v3, -v6                          // 000000180FF4: D6130008 841A06FF 3FB8AA3B
	v_rndne_f32_e32 v9, v6                                     // 000000181000: 7E124706
	v_sub_f32_e32 v6, v6, v9                                   // 000000181004: 080C1306
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000181008: BF870123
	v_fmac_f32_e32 v8, 0x32a5705f, v3                          // 00000018100C: 561006FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000181014: 7C3606FF C2CE8ED0
	v_add_f32_e32 v6, v6, v8                                   // 00000018101C: 060C1106
	v_cvt_i32_f32_e32 v8, v9                                   // 000000181020: 7E101109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000181024: BF870292
	v_exp_f32_e32 v6, v6                                       // 000000181028: 7E0C4B06
	.long 0xd71c0006                                           // 00000018102C: D71C0006
	v_cndmask_b32_e32 v1, v6, v8, vcc_lo                       // 000000181030: 02021106
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000181034: BF870121
	v_cndmask_b32_e32 v6, 0, v6, vcc_lo                        // 000000181038: 020C0C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000018103C: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v6, 0x7f800000, v6, vcc_lo               // 000000181044: 020C0CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 00000018104C: 8C7E007E
	v_dual_mov_b32 v13, 0 :: v_dual_and_b32 v10, 0xff, v0      // 000000181050: CA240080 0D0A00FF 000000FF
	v_dual_mov_b32 v12, 0 :: v_dual_add_nc_u32 v3, 0xfa50, v7  // 00000018105C: CA200080 0C020EFF 0000FA50
	v_lshlrev_b32_e32 v8, 10, v5                               // 000000181068: 30100A8A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000018106C: BF8701A3
	v_lshl_or_b32 v7, v10, 2, 0x800                            // 000000181070: D6560007 03FD050A 00000800
	s_mov_b32 s0, exec_lo                                      // 00000018107C: BE80007E
	v_add_nc_u32_e32 v3, 0xffffff00, v3                        // 000000181080: 4A0606FF FFFFFF00
	s_delay_alu instid0(VALU_DEP_2)                            // 000000181088: BF870002
	v_add_nc_u32_e32 v9, v7, v8                                // 00000018108C: 4A121107
	ds_load_b32 v7, v3                                         // 000000181090: D8D80000 07000003
	ds_load_b32 v8, v9                                         // 000000181098: D8D80000 08000009
	v_cmpx_lt_f32_e32 0xefa18f08, v4                           // 0000001810A0: 7D2208FF EFA18F08
	s_cbranch_execz 26                                         // 0000001810A8: BFA5001A <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x2914>
	v_sub_f32_e32 v4, v4, v11                                  // 0000001810AC: 08081704
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001810B0: BF870091
	v_mul_f32_e32 v13, 0x3fb8aa3b, v4                          // 0000001810B4: 101A08FF 3FB8AA3B
	v_fma_f32 v14, 0x3fb8aa3b, v4, -v13                        // 0000001810BC: D613000E 843608FF 3FB8AA3B
	v_rndne_f32_e32 v15, v13                                   // 0000001810C8: 7E1E470D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001810CC: BF870091
	v_dual_fmac_f32 v14, 0x32a5705f, v4 :: v_dual_sub_f32 v13, v13, v15// 0000001810D0: C80A08FF 0E0C1F0D 32A5705F
	v_add_f32_e32 v13, v13, v14                                // 0000001810DC: 061A1D0D
	v_cvt_i32_f32_e32 v14, v15                                 // 0000001810E0: 7E1C110F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 0000001810E4: 7C3608FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001810EC: BF870293
	v_exp_f32_e32 v13, v13                                     // 0000001810F0: 7E1A4B0D
	.long 0xd71c000d                                           // 0000001810F4: D71C000D
	v_cndmask_b32_e32 v1, v13, v14, vcc_lo                     // 0000001810F8: 02021D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001810FC: BF870121
	v_cndmask_b32_e32 v13, 0, v13, vcc_lo                      // 000000181100: 021A1A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 000000181104: 7C3C08FF 42B17218
	v_cndmask_b32_e32 v13, 0x7f800000, v13, vcc_lo             // 00000018110C: 021A1AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 000000181114: 8C7E007E
	ds_load_b32 v4, v3 offset:64                               // 000000181118: D8D80040 04000003
	ds_load_b32 v14, v9 offset:12288                           // 000000181120: D8D83000 0E000009
	s_mov_b32 s0, exec_lo                                      // 000000181128: BE80007E
	v_cmpx_lt_f32_e32 0xefa18f08, v1                           // 00000018112C: 7D2202FF EFA18F08
	s_cbranch_execz 27                                         // 000000181134: BFA5001B <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x29a4>
	v_sub_f32_e32 v1, v1, v11                                  // 000000181138: 08021701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000018113C: BF870091
	v_mul_f32_e32 v12, 0x3fb8aa3b, v1                          // 000000181140: 101802FF 3FB8AA3B
	v_fma_f32 v15, 0x3fb8aa3b, v1, -v12                        // 000000181148: D613000F 843202FF 3FB8AA3B
	v_rndne_f32_e32 v16, v12                                   // 000000181154: 7E20470C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000181158: BF870221
	v_sub_f32_e32 v12, v12, v16                                // 00000018115C: 0818210C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 000000181160: 7C3602FF C2CE8ED0
	v_fmac_f32_e32 v15, 0x32a5705f, v1                         // 000000181168: 561E02FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000181170: BF870121
	v_add_f32_e32 v12, v12, v15                                // 000000181174: 06181F0C
	v_cvt_i32_f32_e32 v15, v16                                 // 000000181178: 7E1E1110
	v_exp_f32_e32 v12, v12                                     // 00000018117C: 7E184B0C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000181180: BF870095
	.long 0xd71c000c                                           // 000000181184: D71C000C
	v_cndmask_b32_e32 v1, v12, v15, vcc_lo                     // 000000181188: 02021F0C
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 00000018118C: 02181880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 000000181190: 7C3C02FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000181198: BF870002
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 00000018119C: 021818FF 7F800000
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001811A4: 8C7E007E
	ds_load_b32 v1, v3 offset:128                              // 0000001811A8: D8D80080 01000003
	ds_load_b32 v15, v9 offset:24576                           // 0000001811B0: D8D86000 0F000009
	v_mov_b32_e32 v16, 0                                       // 0000001811B8: 7E200280
	s_mov_b32 s0, exec_lo                                      // 0000001811BC: BE80007E
	v_cmpx_lt_f32_e32 0xefa18f08, v2                           // 0000001811C0: 7D2204FF EFA18F08
	s_cbranch_execz 65256                                      // 0000001811C8: BFA5FEE8 <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x256c>
	v_sub_f32_e32 v2, v2, v11                                  // 0000001811CC: 08041702
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001811D0: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v2                          // 0000001811D4: 101604FF 3FB8AA3B
	v_fma_f32 v16, 0x3fb8aa3b, v2, -v11                        // 0000001811DC: D6130010 842E04FF 3FB8AA3B
	v_rndne_f32_e32 v17, v11                                   // 0000001811E8: 7E22470B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001811EC: BF870221
	v_sub_f32_e32 v11, v11, v17                                // 0000001811F0: 0816230B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2                   // 0000001811F4: 7C3604FF C2CE8ED0
	v_fmac_f32_e32 v16, 0x32a5705f, v2                         // 0000001811FC: 562004FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000181204: BF870121
	v_add_f32_e32 v11, v11, v16                                // 000000181208: 0616210B
	v_cvt_i32_f32_e32 v16, v17                                 // 00000018120C: 7E201111
	v_exp_f32_e32 v11, v11                                     // 000000181210: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000181214: BF870095
	.long 0xd71c000b                                           // 000000181218: D71C000B
	v_cndmask_b32_e32 v1, v11, v16, vcc_lo                     // 00000018121C: 0202210B
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000181220: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2                   // 000000181224: 7C3C04FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000018122C: BF870002
	v_cndmask_b32_e32 v16, 0x7f800000, v11, vcc_lo             // 000000181230: 022016FF 7F800000
	s_branch 65228                                             // 000000181238: BFA0FECC <_ZN7halogen12_GLOBAL__N_19k_attn_qsILi0ELi0EEEvPKtS3_S3_lS3_PtPKiiiS6_S6_i+0x256c>
	s_nop 0                                                    // 00000018123C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000181240: BFB60003
	s_endpgm                                                   // 000000181244: BFB00000
		...

