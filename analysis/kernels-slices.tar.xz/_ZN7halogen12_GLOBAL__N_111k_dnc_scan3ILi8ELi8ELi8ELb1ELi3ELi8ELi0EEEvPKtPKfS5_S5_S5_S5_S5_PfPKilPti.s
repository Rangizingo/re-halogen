000000000008d000 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 00000008D000: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 00000008D004: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000008D00C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 00000008D014: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 00000008D018: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000008D01C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 00000008D020: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000008D028: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000008D02C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 00000008D030: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 00000008D034: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000008D03C: 84928214
	s_add_u32 s25, s16, s18                                    // 00000008D040: 80191210
	s_addc_u32 s28, s17, s19                                   // 00000008D044: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 00000008D048: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000008D04C: BF870009
	s_add_u32 s25, s25, s20                                    // 00000008D050: 80191419
	s_addc_u32 s30, s28, s21                                   // 00000008D054: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 00000008D058: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000008D05C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 00000008D064: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000008D06C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 00000008D070: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 00000008D074: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000008D078: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000008D07C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 00000008D080: 821E191E
	.long 0xd7001f02                                           // 00000008D084: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 00000008D088: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000008D08C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 00000008D094: BE9E0080
	s_nop 0                                                    // 00000008D098: BF800000
	s_nop 0                                                    // 00000008D09C: BF800000
	s_nop 0                                                    // 00000008D0A0: BF800000
	s_nop 0                                                    // 00000008D0A4: BF800000
	s_nop 0                                                    // 00000008D0A8: BF800000
	s_nop 0                                                    // 00000008D0AC: BF800000
	s_nop 0                                                    // 00000008D0B0: BF800000
	s_nop 0                                                    // 00000008D0B4: BF800000
	s_nop 0                                                    // 00000008D0B8: BF800000
	s_nop 0                                                    // 00000008D0BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 00000008D0C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 00000008D0C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D0CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 00000008D0D0: 300C1089
	.long 0xd7006a06                                           // 00000008D0D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000008D0D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008D0DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 00000008D0E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000008D0E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 00000008D0F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 00000008D0F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 00000008D0FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 00000008D108: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000008D10C: BF8903F7
	ds_store_b32 v6, v9                                        // 00000008D110: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 00000008D118: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000008D11C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 00000008D120: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 00000008D124: F4000780 F8000058
	v_or_b32_e32 v23, 0xffffff80, v0                           // 00000008D12C: 382E00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 00000008D134: 32040084
	s_mov_b32 s0, 0                                            // 00000008D138: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000008D13C: BF89FC07
	s_barrier                                                  // 00000008D140: BFBD0000
	buffer_gl0_inv                                             // 00000008D144: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000008D14C: BF02801E
	s_cbranch_scc1 12                                          // 00000008D150: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 00000008D154: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000008D15C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000008D164: BF870002
	v_lshl_add_u32 v22, v5, 2, v3                              // 00000008D168: D6460016 040D0505
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v24, 2, v5      // 00000008D170: CA220080 03180A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000008D178: 916A007E
	s_cbranch_vccz 2                                           // 00000008D17C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 1930                                              // 00000008D180: BFA0078A <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fac>
	v_lshlrev_b32_e32 v24, 2, v5                               // 00000008D184: 30300A82
	s_add_i32 s0, s30, 63                                      // 00000008D188: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000008D18C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 00000008D194: 85218600
	s_add_u32 s34, s10, s24                                    // 00000008D198: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000008D19C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 00000008D1A0: 84008702
	v_lshlrev_b32_e32 v25, 2, v0                               // 00000008D1A4: 30320082
	s_ashr_i32 s1, s0, 31                                      // 00000008D1A8: 86019F00
	v_lshlrev_b32_e32 v6, 1, v5                                // 00000008D1AC: 300C0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000008D1B0: 84808100
	v_lshlrev_b32_e32 v12, 8, v2                               // 00000008D1B4: 30180488
	s_add_u32 s22, s22, s0                                     // 00000008D1B8: 80160016
	s_addc_u32 s1, s23, s1                                     // 00000008D1BC: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 00000008D1C0: 848A811A
	v_mad_u32_u24 v22, 0x44, v2, v24                           // 00000008D1C4: D60B0016 046204FF 00000044
	s_add_u32 s22, s22, s10                                    // 00000008D1D0: 80160A16
	s_addc_u32 s1, s1, s11                                     // 00000008D1D4: 82010B01
	s_movk_i32 s10, 0x204                                      // 00000008D1D8: B00A0204
	.long 0xd7000b1d                                           // 00000008D1DC: D7000B1D
	v_cndmask_b32_e32 v1, s34, v24, vcc_lo                     // 00000008D1E0: 02023022
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000008D1E4: BF8704B1
	v_add_co_ci_u32_e64 v30, null, s35, 0, s11                 // 00000008D1E8: D5207C1E 002D0023
	v_mad_u32_u24 v31, v2, s10, 0x3300                         // 00000008D1F0: D60B001F 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 00000008D1FC: 848A8902
	v_dual_mov_b32 v15, s11 :: v_dual_add_nc_u32 v28, 1, v2    // 00000008D200: CA20000B 0F1C0481
	v_or_b32_e32 v14, s10, v25                                 // 00000008D208: 381C320A
	.long 0xd7000a06                                           // 00000008D20C: D7000A06
	v_cndmask_b32_e32 v1, s22, v6, vcc_lo                      // 00000008D210: 02020C16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000008D214: BF870191
	v_add_co_ci_u32_e64 v7, null, s1, 0, s10                   // 00000008D218: D5207C07 00290001
	.long 0xd7000108                                           // 00000008D220: D7000108
	v_cndmask_b32_e32 v1, s12, v14, vcc_lo                     // 00000008D224: 02021C0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000008D228: BF8700B1
	v_add_co_ci_u32_e64 v9, null, s13, v15, s1                 // 00000008D22C: D5207C09 00061E0D
	s_lshl_b64 s[10:11], s[2:3], 14                            // 00000008D234: 848A8E02
	.long 0xd700010a                                           // 00000008D238: D700010A
	v_cndmask_b32_e32 v1, s4, v14, vcc_lo                      // 00000008D23C: 02021C04
	v_add_co_ci_u32_e64 v11, null, s5, v15, s1                 // 00000008D240: D5207C0B 00061E05
	s_add_u32 s1, s14, s10                                     // 00000008D248: 80010A0E
	s_addc_u32 s4, s15, s11                                    // 00000008D24C: 82040B0F
	.long 0xd700010c                                           // 00000008D250: D700010C
	v_cndmask_b32_e32 v1, s1, v12, vcc_lo                      // 00000008D254: 02021801
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008D258: BF870001
	v_add_co_ci_u32_e64 v13, null, s4, 0, s1                   // 00000008D25C: D5207C0D 00050004
	.long 0xd700010e                                           // 00000008D264: D700010E
	v_cndmask_b32_e32 v1, s6, v14, vcc_lo                      // 00000008D268: 02021C06
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v26, 0x4320, v25 // 00000008D26C: CA200080 031A32FF 00004320
	v_add_nc_u32_e32 v27, 0x4420, v25                          // 00000008D278: 4A3632FF 00004420
	.long 0xd44c0000                                           // 00000008D280: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000008D284: 020200FF 00000080
	v_add_nc_u32_e32 v4, 0x2200, v22                           // 00000008D28C: 4A082CFF 00002200
	v_or_b32_e32 v5, 0x2200, v1                                // 00000008D294: 380A02FF 00002200
	v_add_co_ci_u32_e64 v15, null, s7, v15, s1                 // 00000008D29C: D5207C0F 00061E07
	v_add_nc_u32_e32 v32, 0x400, v1                            // 00000008D2A4: 4A4002FF 00000400
	v_add_nc_u32_e32 v33, 0x600, v1                            // 00000008D2AC: 4A4202FF 00000600
	v_add_nc_u32_e32 v34, 0x800, v1                            // 00000008D2B4: 4A4402FF 00000800
	v_add_nc_u32_e32 v35, 0xc00, v1                            // 00000008D2BC: 4A4602FF 00000C00
	v_add_nc_u32_e32 v36, 0xe00, v1                            // 00000008D2C4: 4A4802FF 00000E00
	v_add_nc_u32_e32 v37, 0x1000, v1                           // 00000008D2CC: 4A4A02FF 00001000
	v_add_nc_u32_e32 v38, 0x1400, v1                           // 00000008D2D4: 4A4C02FF 00001400
	v_add_nc_u32_e32 v39, 0x1600, v1                           // 00000008D2DC: 4A4E02FF 00001600
	v_add_nc_u32_e32 v40, 0x1800, v1                           // 00000008D2E4: 4A5002FF 00001800
	v_add_nc_u32_e32 v41, 0x1c00, v1                           // 00000008D2EC: 4A5202FF 00001C00
	v_add_nc_u32_e32 v42, 0x1e00, v1                           // 00000008D2F4: 4A5402FF 00001E00
	v_add_nc_u32_e32 v43, 0x2000, v1                           // 00000008D2FC: 4A5602FF 00002000
	s_mov_b32 s5, 0                                            // 00000008D304: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000008D308: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 00000008D30C: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000008D314: BF870499
	s_add_i32 s6, s31, s1                                      // 00000008D318: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 00000008D31C: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000008D320: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 00000008D324: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 00000008D328: 84078605
	s_add_u32 s10, s8, s10                                     // 00000008D32C: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 00000008D330: 820B0B09
	global_load_b32 v16, v3, s[10:11]                          // 00000008D334: DC520000 100A0003
	s_waitcnt vmcnt(0)                                         // 00000008D33C: BF8903F7
	v_readfirstlane_b32 s6, v16                                // 00000008D340: 7E0C0510
	s_and_saveexec_b32 s4, vcc_lo                              // 00000008D344: BE84206A
	s_cbranch_execz 77                                         // 00000008D348: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x480>
	v_or_b32_e32 v16, s7, v0                                   // 00000008D34C: 38200007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D350: BF870091
	v_mad_u64_u32 v[16:17], null, v16, 48, s[2:3]              // 00000008D354: D6FE7C10 00096110
	v_ashrrev_i32_e32 v17, 31, v16                             // 00000008D35C: 3422209F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D360: BF870091
	.long 0xd73c0010                                           // 00000008D364: D73C0010
	v_cndmask_b32_e32 v1, 2, v16, vcc_lo                       // 00000008D368: 02022082
	.long 0xd7000110                                           // 00000008D36C: D7000110
	v_cndmask_b32_e32 v1, s8, v16, vcc_lo                      // 00000008D370: 02022008
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000008D374: BF8700C1
	v_add_co_ci_u32_e64 v17, null, s9, v17, s1                 // 00000008D378: D5207C11 00062209
	global_load_b32 v16, v[16:17], off                         // 00000008D380: DC520000 107C0010
	s_waitcnt vmcnt(0)                                         // 00000008D388: BF8903F7
	v_sub_f32_e32 v17, s6, v16                                 // 00000008D38C: 08222006
	v_dual_mul_f32 v19, 0x3fb8aa3b, v16 :: v_dual_mul_f32 v18, 0x3fb8aa3b, v17// 00000008D390: C8C620FF 131222FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000008D39C: BF8701A1
	v_fma_f32 v44, 0x3fb8aa3b, v16, -v19                       // 00000008D3A0: D613002C 844E20FF 3FB8AA3B
	v_rndne_f32_e32 v45, v19                                   // 00000008D3AC: 7E5A4713
	v_fma_f32 v20, 0x3fb8aa3b, v17, -v18                       // 00000008D3B0: D6130014 844A22FF 3FB8AA3B
	v_rndne_f32_e32 v21, v18                                   // 00000008D3BC: 7E2A4712
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000008D3C0: BF870113
	v_dual_fmac_f32 v44, 0x32a5705f, v16 :: v_dual_sub_f32 v19, v19, v45// 00000008D3C4: C80A20FF 2C125B13 32A5705F
	v_sub_f32_e32 v18, v18, v21                                // 00000008D3D0: 08242B12
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008D3D4: BF870122
	v_dual_fmac_f32 v20, 0x32a5705f, v17 :: v_dual_add_f32 v19, v19, v44// 00000008D3D8: C80822FF 14125913 32A5705F
	.long 0xd41b0001                                           // 00000008D3E4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v17, vcc_lo              // 00000008D3E8: 020222FF C2CE8ED0
	v_add_f32_e32 v18, v18, v20                                // 00000008D3F0: 06242912
	v_cvt_i32_f32_e32 v20, v21                                 // 00000008D3F4: 7E281115
	v_cvt_i32_f32_e32 v21, v45                                 // 00000008D3F8: 7E2A112D
	v_exp_f32_e32 v19, v19                                     // 00000008D3FC: 7E264B13
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 00000008D400: BF870313
	v_exp_f32_e32 v18, v18                                     // 00000008D404: 7E244B12
	.long 0xd71c0013                                           // 00000008D408: D71C0013
	v_cndmask_b32_e32 v1, v19, v21, vcc_lo                     // 00000008D40C: 02022B13
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D410: BF870095
	.long 0xd71c0012                                           // 00000008D414: D71C0012
	v_cndmask_b32_e32 v1, v18, v20, vcc_lo                     // 00000008D418: 02022912
	v_cndmask_b32_e64 v18, 0, v18, s1                          // 00000008D41C: D5010012 00062480
	.long 0xd41b0001                                           // 00000008D424: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v16, vcc_lo              // 00000008D428: 020220FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008D430: BF8700A1
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 00000008D434: D5010013 00062680
	.long 0xd41e0001                                           // 00000008D43C: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v17, vcc_lo              // 00000008D440: 020222FF 42B17218
	v_cndmask_b32_e64 v17, 0x7f800000, v18, s1                 // 00000008D448: D5010011 000624FF 7F800000
	.long 0xd41e0001                                           // 00000008D454: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v16, vcc_lo              // 00000008D458: 020220FF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008D460: BF870001
	v_cndmask_b32_e64 v16, 0x7f800000, v19, s1                 // 00000008D464: D5010010 000626FF 7F800000
	ds_store_b32 v26, v17                                      // 00000008D470: D8340000 0000111A
	ds_store_b32 v27, v16                                      // 00000008D478: D8340000 0000101B
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008D480: 8C7E047E
	v_dual_mov_b32 v17, v9 :: v_dual_mov_b32 v16, v8           // 00000008D484: CA100109 11100108
	s_mov_b32 s10, 0                                           // 00000008D48C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000008D490: BF89FC07
	s_barrier                                                  // 00000008D494: BFBD0000
	buffer_gl0_inv                                             // 00000008D498: E0AC0000 00000000
	s_branch 15                                                // 00000008D4A0: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4e0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008D4A4: 8C7E047E
	.long 0xd7000110                                           // 00000008D4A8: D7000110
	v_cndmask_b32_e32 v1, 0x30000, v16, vcc_lo                 // 00000008D4AC: 020220FF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008D4B4: BF870001
	v_add_co_ci_u32_e64 v17, null, 0, v17, s1                  // 00000008D4B8: D5207C11 00062280
	s_add_i32 s1, s10, 8                                       // 00000008D4C0: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000008D4C4: BF08B70A
	s_mov_b32 s10, s1                                          // 00000008D4C8: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 00000008D4CC: BF89FC07
	s_barrier                                                  // 00000008D4D0: BFBD0000
	buffer_gl0_inv                                             // 00000008D4D4: E0AC0000 00000000
	s_cbranch_scc1 694                                         // 00000008D4DC: BFA202B6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfb8>
	v_dual_mov_b32 v19, v17 :: v_dual_mov_b32 v18, v16         // 00000008D4E0: CA100111 13120110
	v_dual_mov_b32 v20, v25 :: v_dual_mov_b32 v21, v23         // 00000008D4E8: CA100119 14140117
	s_mov_b32 s11, 0                                           // 00000008D4F0: BE8B0080
	s_nop 0                                                    // 00000008D4F4: BF800000
	s_nop 0                                                    // 00000008D4F8: BF800000
	s_nop 0                                                    // 00000008D4FC: BF800000
	global_load_b32 v44, v[18:19], off                         // 00000008D500: DC520000 2C7C0012
	v_add_nc_u32_e32 v21, 0x80, v21                            // 00000008D508: 4A2A2AFF 00000080
	.long 0xd7000112                                           // 00000008D510: D7000112
	v_cndmask_b32_e32 v1, 0x6000, v18, vcc_lo                  // 00000008D514: 020224FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000008D51C: BF870191
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 00000008D520: D5207C13 00062680
	.long 0xd4490004                                           // 00000008D528: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v21, vcc_lo                   // 00000008D52C: 02022AFF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000008D534: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000008D538: BF8903F7
	ds_store_b32 v20, v44 offset:13056                         // 00000008D53C: D8343300 00002C14
	v_add_nc_u32_e32 v20, 0x204, v20                           // 00000008D544: 4A2828FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000008D54C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000008D550: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x500>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000008D554: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000008D558: BF89FC07
	s_barrier                                                  // 00000008D55C: BFBD0000
	buffer_gl0_inv                                             // 00000008D560: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000008D568: BE842000
	s_cbranch_execz 65485                                      // 00000008D56C: BFA5FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4a4>
	ds_load_2addr_b32 v[18:19], v31 offset1:1                  // 00000008D570: D8DC0100 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:2 offset1:3        // 00000008D578: D8DC0302 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:4 offset1:5        // 00000008D580: D8DC0504 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:6 offset1:7        // 00000008D588: D8DC0706 2E00001F
	ds_load_2addr_b32 v[48:49], v1 offset1:17                  // 00000008D590: D8DC1100 30000001
	ds_load_2addr_b32 v[50:51], v1 offset0:34 offset1:51       // 00000008D598: D8DC3322 32000001
	ds_load_2addr_b32 v[52:53], v1 offset0:68 offset1:85       // 00000008D5A0: D8DC5544 34000001
	ds_load_2addr_b32 v[54:55], v1 offset0:102 offset1:119     // 00000008D5A8: D8DC7766 36000001
	ds_load_2addr_b32 v[58:59], v31 offset0:14 offset1:15      // 00000008D5B0: D8DC0F0E 3A00001F
	ds_load_2addr_b32 v[60:61], v1 offset0:136 offset1:153     // 00000008D5B8: D8DC9988 3C000001
	ds_load_2addr_b32 v[62:63], v1 offset0:170 offset1:187     // 00000008D5C0: D8DCBBAA 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:204 offset1:221     // 00000008D5C8: D8DCDDCC 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:238 offset1:255     // 00000008D5D0: D8DCFFEE 42000001
	v_or3_b32 v56, s10, s7, v2                                 // 00000008D5D8: D6580038 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D5E0: BF870091
	v_mad_u64_u32 v[56:57], null, v56, 48, s[2:3]              // 00000008D5E4: D6FE7C38 00096138
	.long 0xd73c0038                                           // 00000008D5EC: D73C0038
	v_cndmask_b32_e32 v1, 9, v56, vcc_lo                       // 00000008D5F0: 02027089
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D5F4: BF870091
	.long 0xd7000138                                           // 00000008D5F8: D7000138
	v_cndmask_b32_e32 v1, v29, v56, vcc_lo                     // 00000008D5FC: 0202711D
	v_add_co_ci_u32_e64 v57, null, v30, v57, s1                // 00000008D600: D5207C39 0006731E
	global_load_b32 v56, v[56:57], off                         // 00000008D608: DC520000 387C0038
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 00000008D610: BF890087
	v_fma_f32 v18, -v18, v48, v56                              // 00000008D614: D6130012 24E26112
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008D61C: BF8700A1
	v_fma_f32 v18, -v19, v49, v18                              // 00000008D620: D6130012 244A6313
	s_waitcnt lgkmcnt(7)                                       // 00000008D628: BF89FC77
	v_fma_f32 v20, -v20, v50, v18                              // 00000008D62C: D6130014 244A6514
	ds_load_2addr_b32 v[18:19], v31 offset0:8 offset1:9        // 00000008D634: D8DC0908 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:10 offset1:11      // 00000008D63C: D8DC0B0A 3000001F
	ds_load_2addr_b32 v[56:57], v31 offset0:12 offset1:13      // 00000008D644: D8DC0D0C 3800001F
	v_fma_f32 v20, -v21, v51, v20                              // 00000008D64C: D6130014 24526715
	s_waitcnt lgkmcnt(9)                                       // 00000008D654: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D658: BF870091
	v_fma_f32 v20, -v44, v52, v20                              // 00000008D65C: D6130014 2452692C
	v_fma_f32 v20, -v45, v53, v20                              // 00000008D664: D6130014 24526B2D
	s_waitcnt lgkmcnt(8)                                       // 00000008D66C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D670: BF870091
	v_fma_f32 v20, -v46, v54, v20                              // 00000008D674: D6130014 24526D2E
	v_fma_f32 v20, -v47, v55, v20                              // 00000008D67C: D6130014 24526F2F
	s_waitcnt lgkmcnt(2)                                       // 00000008D684: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D688: BF870091
	v_fma_f32 v18, -v18, v60, v20                              // 00000008D68C: D6130012 24527912
	v_fma_f32 v18, -v19, v61, v18                              // 00000008D694: D6130012 244A7B13
	s_waitcnt lgkmcnt(1)                                       // 00000008D69C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008D6A0: BF870001
	v_fma_f32 v48, -v48, v62, v18                              // 00000008D6A4: D6130030 244A7D30
	ds_load_2addr_b32 v[18:19], v31 offset0:16 offset1:17      // 00000008D6AC: D8DC1110 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:18 offset1:19      // 00000008D6B4: D8DC1312 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:20 offset1:21      // 00000008D6BC: D8DC1514 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:22 offset1:23      // 00000008D6C4: D8DC1716 2E00001F
	ds_load_2addr_b32 v[50:51], v32 offset0:16 offset1:33      // 00000008D6CC: D8DC2110 32000020
	ds_load_2addr_b32 v[52:53], v32 offset0:50 offset1:67      // 00000008D6D4: D8DC4332 34000020
	ds_load_2addr_b32 v[54:55], v32 offset0:84 offset1:101     // 00000008D6DC: D8DC6554 36000020
	ds_load_2addr_b32 v[60:61], v32 offset0:118 offset1:135    // 00000008D6E4: D8DC8776 3C000020
	v_fma_f32 v48, -v49, v63, v48                              // 00000008D6EC: D6130030 24C27F31
	s_waitcnt lgkmcnt(8)                                       // 00000008D6F4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D6F8: BF870091
	v_fma_f32 v48, -v56, v64, v48                              // 00000008D6FC: D6130030 24C28138
	v_fma_f32 v48, -v57, v65, v48                              // 00000008D704: D6130030 24C28339
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D70C: BF870091
	v_fma_f32 v48, -v58, v66, v48                              // 00000008D710: D6130030 24C2853A
	v_fma_f32 v48, -v59, v67, v48                              // 00000008D718: D6130030 24C2873B
	s_waitcnt lgkmcnt(3)                                       // 00000008D720: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D724: BF870091
	v_fma_f32 v18, -v18, v50, v48                              // 00000008D728: D6130012 24C26512
	v_fma_f32 v18, -v19, v51, v18                              // 00000008D730: D6130012 244A6713
	s_waitcnt lgkmcnt(2)                                       // 00000008D738: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008D73C: BF870001
	v_fma_f32 v20, -v20, v52, v18                              // 00000008D740: D6130014 244A6914
	ds_load_2addr_b32 v[18:19], v31 offset0:24 offset1:25      // 00000008D748: D8DC1918 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:26 offset1:27      // 00000008D750: D8DC1B1A 3000001F
	ds_load_2addr_b32 v[50:51], v31 offset0:28 offset1:29      // 00000008D758: D8DC1D1C 3200001F
	ds_load_2addr_b32 v[56:57], v31 offset0:30 offset1:31      // 00000008D760: D8DC1F1E 3800001F
	ds_load_2addr_b32 v[58:59], v32 offset0:152 offset1:169    // 00000008D768: D8DCA998 3A000020
	ds_load_2addr_b32 v[62:63], v32 offset0:186 offset1:203    // 00000008D770: D8DCCBBA 3E000020
	ds_load_2addr_b32 v[64:65], v32 offset0:220 offset1:237    // 00000008D778: D8DCEDDC 40000020
	ds_load_2addr_b32 v[66:67], v33 offset0:126 offset1:143    // 00000008D780: D8DC8F7E 42000021
	v_fma_f32 v20, -v21, v53, v20                              // 00000008D788: D6130014 24526B15
	s_waitcnt lgkmcnt(9)                                       // 00000008D790: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D794: BF870091
	v_fma_f32 v20, -v44, v54, v20                              // 00000008D798: D6130014 24526D2C
	v_fma_f32 v20, -v45, v55, v20                              // 00000008D7A0: D6130014 24526F2D
	s_waitcnt lgkmcnt(8)                                       // 00000008D7A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D7AC: BF870091
	v_fma_f32 v20, -v46, v60, v20                              // 00000008D7B0: D6130014 2452792E
	v_fma_f32 v20, -v47, v61, v20                              // 00000008D7B8: D6130014 24527B2F
	s_waitcnt lgkmcnt(3)                                       // 00000008D7C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D7C4: BF870091
	v_fma_f32 v18, -v18, v58, v20                              // 00000008D7C8: D6130012 24527512
	v_fma_f32 v18, -v19, v59, v18                              // 00000008D7D0: D6130012 244A7713
	s_waitcnt lgkmcnt(2)                                       // 00000008D7D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008D7DC: BF870001
	v_fma_f32 v48, -v48, v62, v18                              // 00000008D7E0: D6130030 244A7D30
	ds_load_2addr_b32 v[18:19], v31 offset0:32 offset1:33      // 00000008D7E8: D8DC2120 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:34 offset1:35      // 00000008D7F0: D8DC2322 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:36 offset1:37      // 00000008D7F8: D8DC2524 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:38 offset1:39      // 00000008D800: D8DC2726 2E00001F
	ds_load_2addr_b32 v[52:53], v34 offset0:32 offset1:49      // 00000008D808: D8DC3120 34000022
	ds_load_2addr_b32 v[54:55], v34 offset0:66 offset1:83      // 00000008D810: D8DC5342 36000022
	ds_load_2addr_b32 v[58:59], v34 offset0:100 offset1:117    // 00000008D818: D8DC7564 3A000022
	ds_load_2addr_b32 v[60:61], v34 offset0:134 offset1:151    // 00000008D820: D8DC9786 3C000022
	v_fma_f32 v48, -v49, v63, v48                              // 00000008D828: D6130030 24C27F31
	s_waitcnt lgkmcnt(9)                                       // 00000008D830: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D834: BF870091
	v_fma_f32 v48, -v50, v64, v48                              // 00000008D838: D6130030 24C28132
	v_fma_f32 v48, -v51, v65, v48                              // 00000008D840: D6130030 24C28333
	s_waitcnt lgkmcnt(8)                                       // 00000008D848: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D84C: BF870091
	v_fma_f32 v48, -v56, v66, v48                              // 00000008D850: D6130030 24C28538
	v_fma_f32 v48, -v57, v67, v48                              // 00000008D858: D6130030 24C28739
	s_waitcnt lgkmcnt(3)                                       // 00000008D860: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D864: BF870091
	v_fma_f32 v18, -v18, v52, v48                              // 00000008D868: D6130012 24C26912
	v_fma_f32 v18, -v19, v53, v18                              // 00000008D870: D6130012 244A6B13
	s_waitcnt lgkmcnt(2)                                       // 00000008D878: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008D87C: BF870001
	v_fma_f32 v20, -v20, v54, v18                              // 00000008D880: D6130014 244A6D14
	ds_load_2addr_b32 v[18:19], v31 offset0:40 offset1:41      // 00000008D888: D8DC2928 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:42 offset1:43      // 00000008D890: D8DC2B2A 3000001F
	ds_load_2addr_b32 v[50:51], v31 offset0:44 offset1:45      // 00000008D898: D8DC2D2C 3200001F
	ds_load_2addr_b32 v[52:53], v31 offset0:46 offset1:47      // 00000008D8A0: D8DC2F2E 3400001F
	ds_load_2addr_b32 v[56:57], v34 offset0:168 offset1:185    // 00000008D8A8: D8DCB9A8 38000022
	ds_load_2addr_b32 v[62:63], v34 offset0:202 offset1:219    // 00000008D8B0: D8DCDBCA 3E000022
	ds_load_2addr_b32 v[64:65], v34 offset0:236 offset1:253    // 00000008D8B8: D8DCFDEC 40000022
	ds_load_2addr_b32 v[66:67], v35 offset0:14 offset1:31      // 00000008D8C0: D8DC1F0E 42000023
	v_fma_f32 v20, -v21, v55, v20                              // 00000008D8C8: D6130014 24526F15
	s_waitcnt lgkmcnt(9)                                       // 00000008D8D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D8D4: BF870091
	v_fma_f32 v20, -v44, v58, v20                              // 00000008D8D8: D6130014 2452752C
	v_fma_f32 v20, -v45, v59, v20                              // 00000008D8E0: D6130014 2452772D
	s_waitcnt lgkmcnt(8)                                       // 00000008D8E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D8EC: BF870091
	v_fma_f32 v20, -v46, v60, v20                              // 00000008D8F0: D6130014 2452792E
	v_fma_f32 v20, -v47, v61, v20                              // 00000008D8F8: D6130014 24527B2F
	s_waitcnt lgkmcnt(3)                                       // 00000008D900: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D904: BF870091
	v_fma_f32 v18, -v18, v56, v20                              // 00000008D908: D6130012 24527112
	v_fma_f32 v18, -v19, v57, v18                              // 00000008D910: D6130012 244A7313
	s_waitcnt lgkmcnt(2)                                       // 00000008D918: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008D91C: BF870001
	v_fma_f32 v48, -v48, v62, v18                              // 00000008D920: D6130030 244A7D30
	ds_load_2addr_b32 v[18:19], v31 offset0:48 offset1:49      // 00000008D928: D8DC3130 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:50 offset1:51      // 00000008D930: D8DC3332 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:52 offset1:53      // 00000008D938: D8DC3534 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:54 offset1:55      // 00000008D940: D8DC3736 2E00001F
	ds_load_2addr_b32 v[54:55], v35 offset0:48 offset1:65      // 00000008D948: D8DC4130 36000023
	ds_load_2addr_b32 v[56:57], v35 offset0:82 offset1:99      // 00000008D950: D8DC6352 38000023
	ds_load_2addr_b32 v[58:59], v35 offset0:116 offset1:133    // 00000008D958: D8DC8574 3A000023
	ds_load_2addr_b32 v[60:61], v35 offset0:150 offset1:167    // 00000008D960: D8DCA796 3C000023
	v_fma_f32 v48, -v49, v63, v48                              // 00000008D968: D6130030 24C27F31
	s_waitcnt lgkmcnt(9)                                       // 00000008D970: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D974: BF870091
	v_fma_f32 v48, -v50, v64, v48                              // 00000008D978: D6130030 24C28132
	v_fma_f32 v48, -v51, v65, v48                              // 00000008D980: D6130030 24C28333
	s_waitcnt lgkmcnt(8)                                       // 00000008D988: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D98C: BF870091
	v_fma_f32 v48, -v52, v66, v48                              // 00000008D990: D6130030 24C28534
	v_fma_f32 v48, -v53, v67, v48                              // 00000008D998: D6130030 24C28735
	s_waitcnt lgkmcnt(3)                                       // 00000008D9A0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008D9A4: BF870091
	v_fma_f32 v18, -v18, v54, v48                              // 00000008D9A8: D6130012 24C26D12
	v_fma_f32 v18, -v19, v55, v18                              // 00000008D9B0: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 00000008D9B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008D9BC: BF870001
	v_fma_f32 v20, -v20, v56, v18                              // 00000008D9C0: D6130014 244A7114
	ds_load_2addr_b32 v[18:19], v31 offset0:56 offset1:57      // 00000008D9C8: D8DC3938 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:58 offset1:59      // 00000008D9D0: D8DC3B3A 3000001F
	ds_load_2addr_b32 v[50:51], v31 offset0:60 offset1:61      // 00000008D9D8: D8DC3D3C 3200001F
	ds_load_2addr_b32 v[52:53], v31 offset0:62 offset1:63      // 00000008D9E0: D8DC3F3E 3400001F
	ds_load_2addr_b32 v[54:55], v35 offset0:184 offset1:201    // 00000008D9E8: D8DCC9B8 36000023
	ds_load_2addr_b32 v[62:63], v35 offset0:218 offset1:235    // 00000008D9F0: D8DCEBDA 3E000023
	ds_load_2addr_b32 v[64:65], v36 offset0:124 offset1:141    // 00000008D9F8: D8DC8D7C 40000024
	ds_load_2addr_b32 v[66:67], v37 offset0:30 offset1:47      // 00000008DA00: D8DC2F1E 42000025
	v_fma_f32 v20, -v21, v57, v20                              // 00000008DA08: D6130014 24527315
	s_waitcnt lgkmcnt(9)                                       // 00000008DA10: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DA14: BF870091
	v_fma_f32 v20, -v44, v58, v20                              // 00000008DA18: D6130014 2452752C
	v_fma_f32 v20, -v45, v59, v20                              // 00000008DA20: D6130014 2452772D
	s_waitcnt lgkmcnt(8)                                       // 00000008DA28: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DA2C: BF870091
	v_fma_f32 v20, -v46, v60, v20                              // 00000008DA30: D6130014 2452792E
	v_fma_f32 v20, -v47, v61, v20                              // 00000008DA38: D6130014 24527B2F
	s_waitcnt lgkmcnt(3)                                       // 00000008DA40: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DA44: BF870091
	v_fma_f32 v18, -v18, v54, v20                              // 00000008DA48: D6130012 24526D12
	v_fma_f32 v18, -v19, v55, v18                              // 00000008DA50: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 00000008DA58: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008DA5C: BF870001
	v_fma_f32 v48, -v48, v62, v18                              // 00000008DA60: D6130030 244A7D30
	ds_load_2addr_b32 v[18:19], v31 offset0:64 offset1:65      // 00000008DA68: D8DC4140 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:66 offset1:67      // 00000008DA70: D8DC4342 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:68 offset1:69      // 00000008DA78: D8DC4544 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:70 offset1:71      // 00000008DA80: D8DC4746 2E00001F
	ds_load_2addr_b32 v[54:55], v37 offset0:64 offset1:81      // 00000008DA88: D8DC5140 36000025
	ds_load_2addr_b32 v[56:57], v37 offset0:98 offset1:115     // 00000008DA90: D8DC7362 38000025
	ds_load_2addr_b32 v[58:59], v37 offset0:132 offset1:149    // 00000008DA98: D8DC9584 3A000025
	ds_load_2addr_b32 v[60:61], v37 offset0:166 offset1:183    // 00000008DAA0: D8DCB7A6 3C000025
	v_fma_f32 v48, -v49, v63, v48                              // 00000008DAA8: D6130030 24C27F31
	s_waitcnt lgkmcnt(9)                                       // 00000008DAB0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DAB4: BF870091
	v_fma_f32 v48, -v50, v64, v48                              // 00000008DAB8: D6130030 24C28132
	v_fma_f32 v48, -v51, v65, v48                              // 00000008DAC0: D6130030 24C28333
	s_waitcnt lgkmcnt(8)                                       // 00000008DAC8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DACC: BF870091
	v_fma_f32 v48, -v52, v66, v48                              // 00000008DAD0: D6130030 24C28534
	v_fma_f32 v48, -v53, v67, v48                              // 00000008DAD8: D6130030 24C28735
	s_waitcnt lgkmcnt(3)                                       // 00000008DAE0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DAE4: BF870091
	v_fma_f32 v18, -v18, v54, v48                              // 00000008DAE8: D6130012 24C26D12
	v_fma_f32 v18, -v19, v55, v18                              // 00000008DAF0: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 00000008DAF8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008DAFC: BF870001
	v_fma_f32 v20, -v20, v56, v18                              // 00000008DB00: D6130014 244A7114
	ds_load_2addr_b32 v[18:19], v31 offset0:72 offset1:73      // 00000008DB08: D8DC4948 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:74 offset1:75      // 00000008DB10: D8DC4B4A 3000001F
	ds_load_2addr_b32 v[50:51], v31 offset0:76 offset1:77      // 00000008DB18: D8DC4D4C 3200001F
	ds_load_2addr_b32 v[52:53], v31 offset0:78 offset1:79      // 00000008DB20: D8DC4F4E 3400001F
	ds_load_2addr_b32 v[54:55], v37 offset0:200 offset1:217    // 00000008DB28: D8DCD9C8 36000025
	ds_load_2addr_b32 v[62:63], v37 offset0:234 offset1:251    // 00000008DB30: D8DCFBEA 3E000025
	ds_load_2addr_b32 v[64:65], v38 offset0:12 offset1:29      // 00000008DB38: D8DC1D0C 40000026
	ds_load_2addr_b32 v[66:67], v38 offset0:46 offset1:63      // 00000008DB40: D8DC3F2E 42000026
	v_fma_f32 v20, -v21, v57, v20                              // 00000008DB48: D6130014 24527315
	s_waitcnt lgkmcnt(9)                                       // 00000008DB50: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DB54: BF870091
	v_fma_f32 v20, -v44, v58, v20                              // 00000008DB58: D6130014 2452752C
	v_fma_f32 v20, -v45, v59, v20                              // 00000008DB60: D6130014 2452772D
	s_waitcnt lgkmcnt(8)                                       // 00000008DB68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DB6C: BF870091
	v_fma_f32 v20, -v46, v60, v20                              // 00000008DB70: D6130014 2452792E
	v_fma_f32 v20, -v47, v61, v20                              // 00000008DB78: D6130014 24527B2F
	s_waitcnt lgkmcnt(3)                                       // 00000008DB80: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DB84: BF870091
	v_fma_f32 v18, -v18, v54, v20                              // 00000008DB88: D6130012 24526D12
	v_fma_f32 v18, -v19, v55, v18                              // 00000008DB90: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 00000008DB98: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008DB9C: BF870001
	v_fma_f32 v48, -v48, v62, v18                              // 00000008DBA0: D6130030 244A7D30
	ds_load_2addr_b32 v[18:19], v31 offset0:80 offset1:81      // 00000008DBA8: D8DC5150 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:82 offset1:83      // 00000008DBB0: D8DC5352 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:84 offset1:85      // 00000008DBB8: D8DC5554 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:86 offset1:87      // 00000008DBC0: D8DC5756 2E00001F
	ds_load_2addr_b32 v[54:55], v38 offset0:80 offset1:97      // 00000008DBC8: D8DC6150 36000026
	ds_load_2addr_b32 v[56:57], v38 offset0:114 offset1:131    // 00000008DBD0: D8DC8372 38000026
	ds_load_2addr_b32 v[58:59], v38 offset0:148 offset1:165    // 00000008DBD8: D8DCA594 3A000026
	ds_load_2addr_b32 v[60:61], v38 offset0:182 offset1:199    // 00000008DBE0: D8DCC7B6 3C000026
	v_fma_f32 v48, -v49, v63, v48                              // 00000008DBE8: D6130030 24C27F31
	s_waitcnt lgkmcnt(9)                                       // 00000008DBF0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DBF4: BF870091
	v_fma_f32 v48, -v50, v64, v48                              // 00000008DBF8: D6130030 24C28132
	v_fma_f32 v48, -v51, v65, v48                              // 00000008DC00: D6130030 24C28333
	s_waitcnt lgkmcnt(8)                                       // 00000008DC08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DC0C: BF870091
	v_fma_f32 v48, -v52, v66, v48                              // 00000008DC10: D6130030 24C28534
	v_fma_f32 v48, -v53, v67, v48                              // 00000008DC18: D6130030 24C28735
	s_waitcnt lgkmcnt(3)                                       // 00000008DC20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DC24: BF870091
	v_fma_f32 v18, -v18, v54, v48                              // 00000008DC28: D6130012 24C26D12
	v_fma_f32 v18, -v19, v55, v18                              // 00000008DC30: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 00000008DC38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008DC3C: BF870001
	v_fma_f32 v20, -v20, v56, v18                              // 00000008DC40: D6130014 244A7114
	ds_load_2addr_b32 v[18:19], v31 offset0:88 offset1:89      // 00000008DC48: D8DC5958 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:90 offset1:91      // 00000008DC50: D8DC5B5A 3000001F
	ds_load_2addr_b32 v[50:51], v31 offset0:92 offset1:93      // 00000008DC58: D8DC5D5C 3200001F
	ds_load_2addr_b32 v[52:53], v31 offset0:94 offset1:95      // 00000008DC60: D8DC5F5E 3400001F
	ds_load_2addr_b32 v[54:55], v38 offset0:216 offset1:233    // 00000008DC68: D8DCE9D8 36000026
	ds_load_2addr_b32 v[62:63], v39 offset0:122 offset1:139    // 00000008DC70: D8DC8B7A 3E000027
	ds_load_2addr_b32 v[64:65], v40 offset0:28 offset1:45      // 00000008DC78: D8DC2D1C 40000028
	ds_load_2addr_b32 v[66:67], v40 offset0:62 offset1:79      // 00000008DC80: D8DC4F3E 42000028
	v_fma_f32 v20, -v21, v57, v20                              // 00000008DC88: D6130014 24527315
	s_waitcnt lgkmcnt(9)                                       // 00000008DC90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DC94: BF870091
	v_fma_f32 v20, -v44, v58, v20                              // 00000008DC98: D6130014 2452752C
	v_fma_f32 v20, -v45, v59, v20                              // 00000008DCA0: D6130014 2452772D
	s_waitcnt lgkmcnt(8)                                       // 00000008DCA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DCAC: BF870091
	v_fma_f32 v20, -v46, v60, v20                              // 00000008DCB0: D6130014 2452792E
	v_fma_f32 v20, -v47, v61, v20                              // 00000008DCB8: D6130014 24527B2F
	s_waitcnt lgkmcnt(3)                                       // 00000008DCC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DCC4: BF870091
	v_fma_f32 v18, -v18, v54, v20                              // 00000008DCC8: D6130012 24526D12
	v_fma_f32 v18, -v19, v55, v18                              // 00000008DCD0: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 00000008DCD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008DCDC: BF870001
	v_fma_f32 v48, -v48, v62, v18                              // 00000008DCE0: D6130030 244A7D30
	ds_load_2addr_b32 v[18:19], v31 offset0:96 offset1:97      // 00000008DCE8: D8DC6160 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:98 offset1:99      // 00000008DCF0: D8DC6362 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:100 offset1:101    // 00000008DCF8: D8DC6564 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:102 offset1:103    // 00000008DD00: D8DC6766 2E00001F
	ds_load_2addr_b32 v[54:55], v40 offset0:96 offset1:113     // 00000008DD08: D8DC7160 36000028
	ds_load_2addr_b32 v[56:57], v40 offset0:130 offset1:147    // 00000008DD10: D8DC9382 38000028
	ds_load_2addr_b32 v[58:59], v40 offset0:164 offset1:181    // 00000008DD18: D8DCB5A4 3A000028
	ds_load_2addr_b32 v[60:61], v40 offset0:198 offset1:215    // 00000008DD20: D8DCD7C6 3C000028
	v_fma_f32 v48, -v49, v63, v48                              // 00000008DD28: D6130030 24C27F31
	s_waitcnt lgkmcnt(9)                                       // 00000008DD30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DD34: BF870091
	v_fma_f32 v48, -v50, v64, v48                              // 00000008DD38: D6130030 24C28132
	v_fma_f32 v48, -v51, v65, v48                              // 00000008DD40: D6130030 24C28333
	s_waitcnt lgkmcnt(8)                                       // 00000008DD48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DD4C: BF870091
	v_fma_f32 v48, -v52, v66, v48                              // 00000008DD50: D6130030 24C28534
	v_fma_f32 v48, -v53, v67, v48                              // 00000008DD58: D6130030 24C28735
	s_waitcnt lgkmcnt(3)                                       // 00000008DD60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DD64: BF870091
	v_fma_f32 v18, -v18, v54, v48                              // 00000008DD68: D6130012 24C26D12
	v_fma_f32 v18, -v19, v55, v18                              // 00000008DD70: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 00000008DD78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008DD7C: BF870001
	v_fma_f32 v20, -v20, v56, v18                              // 00000008DD80: D6130014 244A7114
	ds_load_2addr_b32 v[18:19], v31 offset0:104 offset1:105    // 00000008DD88: D8DC6968 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:106 offset1:107    // 00000008DD90: D8DC6B6A 3000001F
	ds_load_2addr_b32 v[50:51], v31 offset0:108 offset1:109    // 00000008DD98: D8DC6D6C 3200001F
	ds_load_2addr_b32 v[52:53], v31 offset0:110 offset1:111    // 00000008DDA0: D8DC6F6E 3400001F
	ds_load_2addr_b32 v[54:55], v40 offset0:232 offset1:249    // 00000008DDA8: D8DCF9E8 36000028
	ds_load_2addr_b32 v[62:63], v41 offset0:10 offset1:27      // 00000008DDB0: D8DC1B0A 3E000029
	ds_load_2addr_b32 v[64:65], v41 offset0:44 offset1:61      // 00000008DDB8: D8DC3D2C 40000029
	ds_load_2addr_b32 v[66:67], v41 offset0:78 offset1:95      // 00000008DDC0: D8DC5F4E 42000029
	v_fma_f32 v20, -v21, v57, v20                              // 00000008DDC8: D6130014 24527315
	s_waitcnt lgkmcnt(9)                                       // 00000008DDD0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DDD4: BF870091
	v_fma_f32 v20, -v44, v58, v20                              // 00000008DDD8: D6130014 2452752C
	v_fma_f32 v20, -v45, v59, v20                              // 00000008DDE0: D6130014 2452772D
	s_waitcnt lgkmcnt(8)                                       // 00000008DDE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DDEC: BF870091
	v_fma_f32 v20, -v46, v60, v20                              // 00000008DDF0: D6130014 2452792E
	v_fma_f32 v20, -v47, v61, v20                              // 00000008DDF8: D6130014 24527B2F
	s_waitcnt lgkmcnt(3)                                       // 00000008DE00: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DE04: BF870091
	v_fma_f32 v18, -v18, v54, v20                              // 00000008DE08: D6130012 24526D12
	v_fma_f32 v18, -v19, v55, v18                              // 00000008DE10: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 00000008DE18: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008DE1C: BF870001
	v_fma_f32 v48, -v48, v62, v18                              // 00000008DE20: D6130030 244A7D30
	ds_load_2addr_b32 v[18:19], v31 offset0:112 offset1:113    // 00000008DE28: D8DC7170 1200001F
	ds_load_2addr_b32 v[20:21], v31 offset0:114 offset1:115    // 00000008DE30: D8DC7372 1400001F
	ds_load_2addr_b32 v[44:45], v31 offset0:116 offset1:117    // 00000008DE38: D8DC7574 2C00001F
	ds_load_2addr_b32 v[46:47], v31 offset0:118 offset1:119    // 00000008DE40: D8DC7776 2E00001F
	ds_load_2addr_b32 v[54:55], v41 offset0:112 offset1:129    // 00000008DE48: D8DC8170 36000029
	ds_load_2addr_b32 v[56:57], v41 offset0:146 offset1:163    // 00000008DE50: D8DCA392 38000029
	ds_load_2addr_b32 v[58:59], v41 offset0:180 offset1:197    // 00000008DE58: D8DCC5B4 3A000029
	ds_load_2addr_b32 v[60:61], v41 offset0:214 offset1:231    // 00000008DE60: D8DCE7D6 3C000029
	v_fma_f32 v48, -v49, v63, v48                              // 00000008DE68: D6130030 24C27F31
	s_waitcnt lgkmcnt(9)                                       // 00000008DE70: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DE74: BF870091
	v_fma_f32 v48, -v50, v64, v48                              // 00000008DE78: D6130030 24C28132
	v_fma_f32 v48, -v51, v65, v48                              // 00000008DE80: D6130030 24C28333
	s_waitcnt lgkmcnt(8)                                       // 00000008DE88: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DE8C: BF870091
	v_fma_f32 v48, -v52, v66, v48                              // 00000008DE90: D6130030 24C28534
	v_fma_f32 v48, -v53, v67, v48                              // 00000008DE98: D6130030 24C28735
	s_waitcnt lgkmcnt(3)                                       // 00000008DEA0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DEA4: BF870091
	v_fma_f32 v18, -v18, v54, v48                              // 00000008DEA8: D6130012 24C26D12
	v_fma_f32 v18, -v19, v55, v18                              // 00000008DEB0: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 00000008DEB8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008DEBC: BF870001
	v_fma_f32 v20, -v20, v56, v18                              // 00000008DEC0: D6130014 244A7114
	ds_load_2addr_b32 v[18:19], v31 offset0:120 offset1:121    // 00000008DEC8: D8DC7978 1200001F
	ds_load_2addr_b32 v[48:49], v31 offset0:122 offset1:123    // 00000008DED0: D8DC7B7A 3000001F
	ds_load_2addr_b32 v[50:51], v31 offset0:124 offset1:125    // 00000008DED8: D8DC7D7C 3200001F
	ds_load_2addr_b32 v[52:53], v31 offset0:126 offset1:127    // 00000008DEE0: D8DC7F7E 3400001F
	ds_load_2addr_b32 v[54:55], v42 offset0:120 offset1:137    // 00000008DEE8: D8DC8978 3600002A
	ds_load_2addr_b32 v[62:63], v43 offset0:26 offset1:43      // 00000008DEF0: D8DC2B1A 3E00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:60 offset1:77      // 00000008DEF8: D8DC4D3C 4000002B
	ds_load_2addr_b32 v[66:67], v43 offset0:94 offset1:111     // 00000008DF00: D8DC6F5E 4200002B
	v_fma_f32 v20, -v21, v57, v20                              // 00000008DF08: D6130014 24527315
	s_waitcnt lgkmcnt(9)                                       // 00000008DF10: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DF14: BF870091
	v_fma_f32 v20, -v44, v58, v20                              // 00000008DF18: D6130014 2452752C
	v_fma_f32 v20, -v45, v59, v20                              // 00000008DF20: D6130014 2452772D
	s_waitcnt lgkmcnt(8)                                       // 00000008DF28: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DF2C: BF870091
	v_fma_f32 v20, -v46, v60, v20                              // 00000008DF30: D6130014 2452792E
	v_fma_f32 v20, -v47, v61, v20                              // 00000008DF38: D6130014 24527B2F
	s_waitcnt lgkmcnt(3)                                       // 00000008DF40: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DF44: BF870091
	v_fma_f32 v18, -v18, v54, v20                              // 00000008DF48: D6130012 24526D12
	v_fma_f32 v18, -v19, v55, v18                              // 00000008DF50: D6130012 244A6F13
	s_waitcnt lgkmcnt(2)                                       // 00000008DF58: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DF5C: BF870091
	v_fma_f32 v18, -v48, v62, v18                              // 00000008DF60: D6130012 244A7D30
	v_fma_f32 v18, -v49, v63, v18                              // 00000008DF68: D6130012 244A7F31
	s_waitcnt lgkmcnt(1)                                       // 00000008DF70: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008DF74: BF870091
	v_fma_f32 v18, -v50, v64, v18                              // 00000008DF78: D6130012 244A8132
	v_fma_f32 v18, -v51, v65, v18                              // 00000008DF80: D6130012 244A8333
	s_waitcnt lgkmcnt(0)                                       // 00000008DF88: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008DF8C: BF870121
	v_fma_f32 v20, -v52, v66, v18                              // 00000008DF90: D6130014 244A8534
	v_mad_u64_u32 v[18:19], null, 0x44, s10, v[4:5]            // 00000008DF98: D6FE7C12 041014FF 00000044
	v_fma_f32 v19, -v53, v67, v20                              // 00000008DFA4: D6130013 24528735
	ds_store_b32 v18, v19                                      // 00000008DFAC: D8340000 00001312
	s_branch 64827                                             // 00000008DFB4: BFA0FD3B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4a4>
	v_mov_b32_e32 v17, v13                                     // 00000008DFB8: 7E22030D
	v_dual_mov_b32 v19, v11 :: v_dual_mov_b32 v16, v12         // 00000008DFBC: CA10010B 1310010C
	v_mov_b32_e32 v18, v10                                     // 00000008DFC4: 7E24030A
	v_mov_b32_e32 v44, v28                                     // 00000008DFC8: 7E58031C
	s_mov_b32 s10, 0                                           // 00000008DFCC: BE8A0080
	s_branch 21                                                // 00000008DFD0: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1028>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000008DFD4: 8C7E0B7E
	.long 0xd7000112                                           // 00000008DFD8: D7000112
	v_cndmask_b32_e32 v1, 0x30000, v18, vcc_lo                 // 00000008DFDC: 020224FF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008DFE4: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 00000008DFE8: D5207C13 00062680
	.long 0xd7000110                                           // 00000008DFF0: D7000110
	v_cndmask_b32_e32 v1, 0x800, v16, vcc_lo                   // 00000008DFF4: 020220FF 00000800
	v_add_nc_u32_e32 v44, 8, v44                               // 00000008DFFC: 4A585888
	v_add_co_ci_u32_e64 v17, null, 0, v17, s1                  // 00000008E000: D5207C11 00062280
	s_add_i32 s1, s10, 8                                       // 00000008E008: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000008E00C: BF08B70A
	s_mov_b32 s10, s1                                          // 00000008E010: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 00000008E014: BC7C0000
	s_barrier                                                  // 00000008E018: BFBD0000
	buffer_gl0_inv                                             // 00000008E01C: E0AC0000 00000000
	s_cbranch_scc1 598                                         // 00000008E024: BFA20256 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1980>
	s_delay_alu instid0(VALU_DEP_2)                            // 00000008E028: BF870002
	v_dual_mov_b32 v21, v19 :: v_dual_mov_b32 v20, v18         // 00000008E02C: CA100113 15140112
	v_dual_mov_b32 v45, v25 :: v_dual_mov_b32 v46, v23         // 00000008E034: CA100119 2D2E0117
	s_mov_b32 s11, 0                                           // 00000008E03C: BE8B0080
	global_load_b32 v47, v[20:21], off                         // 00000008E040: DC520000 2F7C0014
	v_add_nc_u32_e32 v46, 0x80, v46                            // 00000008E048: 4A5C5CFF 00000080
	.long 0xd7000114                                           // 00000008E050: D7000114
	v_cndmask_b32_e32 v1, 0x6000, v20, vcc_lo                  // 00000008E054: 020228FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000008E05C: BF870191
	v_add_co_ci_u32_e64 v21, null, 0, v21, s1                  // 00000008E060: D5207C15 00062A80
	.long 0xd4490004                                           // 00000008E068: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 00000008E06C: 02025CFF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000008E074: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000008E078: BF8903F7
	ds_store_b32 v45, v47 offset:13056                         // 00000008E07C: D8343300 00002F2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 00000008E084: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000008E08C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000008E090: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1040>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000008E094: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000008E098: BF89FC07
	s_barrier                                                  // 00000008E09C: BFBD0000
	buffer_gl0_inv                                             // 00000008E0A0: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 00000008E0A8: BE8B2000
	s_cbranch_execz 65481                                      // 00000008E0AC: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfd4>
	v_or_b32_e32 v20, s10, v2                                  // 00000008E0B0: 3828040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008E0B4: BF870091
	v_or_b32_e32 v45, s7, v20                                  // 00000008E0B8: 385A2807
	.long 0xd4440001                                           // 00000008E0BC: D4440001
	v_cndmask_b32_e32 v1, s30, v45, vcc_lo                     // 00000008E0C0: 02025A1E
	s_and_b32 exec_lo, exec_lo, s1                             // 00000008E0C4: 8B7E017E
	s_cbranch_execz 65474                                      // 00000008E0C8: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfd4>
	ds_load_2addr_b32 v[46:47], v31 offset1:1                  // 00000008E0CC: D8DC0100 2E00001F
	ds_load_2addr_b32 v[48:49], v1 offset1:17                  // 00000008E0D4: D8DC1100 30000001
	ds_load_2addr_b32 v[50:51], v31 offset0:2 offset1:3        // 00000008E0DC: D8DC0302 3200001F
	ds_load_2addr_b32 v[52:53], v1 offset0:34 offset1:51       // 00000008E0E4: D8DC3322 34000001
	ds_load_2addr_b32 v[54:55], v31 offset0:4 offset1:5        // 00000008E0EC: D8DC0504 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:6 offset1:7        // 00000008E0F4: D8DC0706 3800001F
	ds_load_2addr_b32 v[58:59], v1 offset0:68 offset1:85       // 00000008E0FC: D8DC5544 3A000001
	ds_load_2addr_b32 v[60:61], v1 offset0:102 offset1:119     // 00000008E104: D8DC7766 3C000001
	s_mov_b32 s12, 0                                           // 00000008E10C: BE8C0080
	s_waitcnt lgkmcnt(6)                                       // 00000008E110: BF89FC67
	v_fma_f32 v62, v46, v48, 0                                 // 00000008E114: D613003E 0202612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E11C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E120: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E124: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E128: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E12C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E130: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E134: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E138: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E13C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E140: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E144: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E148: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E14C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E150: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:8 offset1:9        // 00000008E154: D8DC0908 2E00001F
	ds_load_2addr_b32 v[48:49], v1 offset0:136 offset1:153     // 00000008E15C: D8DC9988 30000001
	ds_load_2addr_b32 v[50:51], v31 offset0:10 offset1:11      // 00000008E164: D8DC0B0A 3200001F
	ds_load_2addr_b32 v[52:53], v1 offset0:170 offset1:187     // 00000008E16C: D8DCBBAA 34000001
	ds_load_2addr_b32 v[54:55], v31 offset0:12 offset1:13      // 00000008E174: D8DC0D0C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:14 offset1:15      // 00000008E17C: D8DC0F0E 3800001F
	ds_load_2addr_b32 v[58:59], v1 offset0:204 offset1:221     // 00000008E184: D8DCDDCC 3A000001
	ds_load_2addr_b32 v[60:61], v1 offset0:238 offset1:255     // 00000008E18C: D8DCFFEE 3C000001
	s_waitcnt lgkmcnt(6)                                       // 00000008E194: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E198: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E19C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E1A0: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E1A4: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E1A8: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E1AC: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E1B0: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E1B4: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E1B8: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E1BC: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E1C0: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E1C4: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E1C8: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E1CC: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E1D0: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:16 offset1:17      // 00000008E1D4: D8DC1110 2E00001F
	ds_load_2addr_b32 v[48:49], v32 offset0:16 offset1:33      // 00000008E1DC: D8DC2110 30000020
	ds_load_2addr_b32 v[50:51], v31 offset0:18 offset1:19      // 00000008E1E4: D8DC1312 3200001F
	ds_load_2addr_b32 v[52:53], v32 offset0:50 offset1:67      // 00000008E1EC: D8DC4332 34000020
	ds_load_2addr_b32 v[54:55], v31 offset0:20 offset1:21      // 00000008E1F4: D8DC1514 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:22 offset1:23      // 00000008E1FC: D8DC1716 3800001F
	ds_load_2addr_b32 v[58:59], v32 offset0:84 offset1:101     // 00000008E204: D8DC6554 3A000020
	ds_load_2addr_b32 v[60:61], v32 offset0:118 offset1:135    // 00000008E20C: D8DC8776 3C000020
	s_waitcnt lgkmcnt(6)                                       // 00000008E214: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E218: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E21C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E220: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E224: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E228: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E22C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E230: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E234: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E238: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E23C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E240: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E244: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E248: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E24C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E250: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:24 offset1:25      // 00000008E254: D8DC1918 2E00001F
	ds_load_2addr_b32 v[48:49], v32 offset0:152 offset1:169    // 00000008E25C: D8DCA998 30000020
	ds_load_2addr_b32 v[50:51], v31 offset0:26 offset1:27      // 00000008E264: D8DC1B1A 3200001F
	ds_load_2addr_b32 v[52:53], v32 offset0:186 offset1:203    // 00000008E26C: D8DCCBBA 34000020
	ds_load_2addr_b32 v[54:55], v31 offset0:28 offset1:29      // 00000008E274: D8DC1D1C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:30 offset1:31      // 00000008E27C: D8DC1F1E 3800001F
	ds_load_2addr_b32 v[58:59], v32 offset0:220 offset1:237    // 00000008E284: D8DCEDDC 3A000020
	ds_load_2addr_b32 v[60:61], v33 offset0:126 offset1:143    // 00000008E28C: D8DC8F7E 3C000021
	s_waitcnt lgkmcnt(6)                                       // 00000008E294: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E298: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E29C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E2A0: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E2A4: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E2A8: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E2AC: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E2B0: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E2B4: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E2B8: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E2BC: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E2C0: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E2C4: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E2C8: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E2CC: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E2D0: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:32 offset1:33      // 00000008E2D4: D8DC2120 2E00001F
	ds_load_2addr_b32 v[48:49], v34 offset0:32 offset1:49      // 00000008E2DC: D8DC3120 30000022
	ds_load_2addr_b32 v[50:51], v31 offset0:34 offset1:35      // 00000008E2E4: D8DC2322 3200001F
	ds_load_2addr_b32 v[52:53], v34 offset0:66 offset1:83      // 00000008E2EC: D8DC5342 34000022
	ds_load_2addr_b32 v[54:55], v31 offset0:36 offset1:37      // 00000008E2F4: D8DC2524 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:38 offset1:39      // 00000008E2FC: D8DC2726 3800001F
	ds_load_2addr_b32 v[58:59], v34 offset0:100 offset1:117    // 00000008E304: D8DC7564 3A000022
	ds_load_2addr_b32 v[60:61], v34 offset0:134 offset1:151    // 00000008E30C: D8DC9786 3C000022
	s_waitcnt lgkmcnt(6)                                       // 00000008E314: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E318: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E31C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E320: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E324: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E328: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E32C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E330: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E334: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E338: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E33C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E340: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E344: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E348: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E34C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E350: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:40 offset1:41      // 00000008E354: D8DC2928 2E00001F
	ds_load_2addr_b32 v[48:49], v34 offset0:168 offset1:185    // 00000008E35C: D8DCB9A8 30000022
	ds_load_2addr_b32 v[50:51], v31 offset0:42 offset1:43      // 00000008E364: D8DC2B2A 3200001F
	ds_load_2addr_b32 v[52:53], v34 offset0:202 offset1:219    // 00000008E36C: D8DCDBCA 34000022
	ds_load_2addr_b32 v[54:55], v31 offset0:44 offset1:45      // 00000008E374: D8DC2D2C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:46 offset1:47      // 00000008E37C: D8DC2F2E 3800001F
	ds_load_2addr_b32 v[58:59], v34 offset0:236 offset1:253    // 00000008E384: D8DCFDEC 3A000022
	ds_load_2addr_b32 v[60:61], v35 offset0:14 offset1:31      // 00000008E38C: D8DC1F0E 3C000023
	s_waitcnt lgkmcnt(6)                                       // 00000008E394: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E398: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E39C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E3A0: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E3A4: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E3A8: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E3AC: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E3B0: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E3B4: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E3B8: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E3BC: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E3C0: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E3C4: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E3C8: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E3CC: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E3D0: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:48 offset1:49      // 00000008E3D4: D8DC3130 2E00001F
	ds_load_2addr_b32 v[48:49], v35 offset0:48 offset1:65      // 00000008E3DC: D8DC4130 30000023
	ds_load_2addr_b32 v[50:51], v31 offset0:50 offset1:51      // 00000008E3E4: D8DC3332 3200001F
	ds_load_2addr_b32 v[52:53], v35 offset0:82 offset1:99      // 00000008E3EC: D8DC6352 34000023
	ds_load_2addr_b32 v[54:55], v31 offset0:52 offset1:53      // 00000008E3F4: D8DC3534 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:54 offset1:55      // 00000008E3FC: D8DC3736 3800001F
	ds_load_2addr_b32 v[58:59], v35 offset0:116 offset1:133    // 00000008E404: D8DC8574 3A000023
	ds_load_2addr_b32 v[60:61], v35 offset0:150 offset1:167    // 00000008E40C: D8DCA796 3C000023
	s_waitcnt lgkmcnt(6)                                       // 00000008E414: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E418: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E41C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E420: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E424: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E428: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E42C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E430: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E434: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E438: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E43C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E440: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E444: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E448: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E44C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E450: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:56 offset1:57      // 00000008E454: D8DC3938 2E00001F
	ds_load_2addr_b32 v[48:49], v35 offset0:184 offset1:201    // 00000008E45C: D8DCC9B8 30000023
	ds_load_2addr_b32 v[50:51], v31 offset0:58 offset1:59      // 00000008E464: D8DC3B3A 3200001F
	ds_load_2addr_b32 v[52:53], v35 offset0:218 offset1:235    // 00000008E46C: D8DCEBDA 34000023
	ds_load_2addr_b32 v[54:55], v31 offset0:60 offset1:61      // 00000008E474: D8DC3D3C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:62 offset1:63      // 00000008E47C: D8DC3F3E 3800001F
	ds_load_2addr_b32 v[58:59], v36 offset0:124 offset1:141    // 00000008E484: D8DC8D7C 3A000024
	ds_load_2addr_b32 v[60:61], v37 offset0:30 offset1:47      // 00000008E48C: D8DC2F1E 3C000025
	s_waitcnt lgkmcnt(6)                                       // 00000008E494: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E498: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E49C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E4A0: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E4A4: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E4A8: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E4AC: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E4B0: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E4B4: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E4B8: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E4BC: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E4C0: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E4C4: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E4C8: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E4CC: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E4D0: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:64 offset1:65      // 00000008E4D4: D8DC4140 2E00001F
	ds_load_2addr_b32 v[48:49], v37 offset0:64 offset1:81      // 00000008E4DC: D8DC5140 30000025
	ds_load_2addr_b32 v[50:51], v31 offset0:66 offset1:67      // 00000008E4E4: D8DC4342 3200001F
	ds_load_2addr_b32 v[52:53], v37 offset0:98 offset1:115     // 00000008E4EC: D8DC7362 34000025
	ds_load_2addr_b32 v[54:55], v31 offset0:68 offset1:69      // 00000008E4F4: D8DC4544 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:70 offset1:71      // 00000008E4FC: D8DC4746 3800001F
	ds_load_2addr_b32 v[58:59], v37 offset0:132 offset1:149    // 00000008E504: D8DC9584 3A000025
	ds_load_2addr_b32 v[60:61], v37 offset0:166 offset1:183    // 00000008E50C: D8DCB7A6 3C000025
	s_waitcnt lgkmcnt(6)                                       // 00000008E514: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E518: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E51C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E520: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E524: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E528: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E52C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E530: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E534: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E538: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E53C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E540: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E544: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E548: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E54C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E550: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:72 offset1:73      // 00000008E554: D8DC4948 2E00001F
	ds_load_2addr_b32 v[48:49], v37 offset0:200 offset1:217    // 00000008E55C: D8DCD9C8 30000025
	ds_load_2addr_b32 v[50:51], v31 offset0:74 offset1:75      // 00000008E564: D8DC4B4A 3200001F
	ds_load_2addr_b32 v[52:53], v37 offset0:234 offset1:251    // 00000008E56C: D8DCFBEA 34000025
	ds_load_2addr_b32 v[54:55], v31 offset0:76 offset1:77      // 00000008E574: D8DC4D4C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:78 offset1:79      // 00000008E57C: D8DC4F4E 3800001F
	ds_load_2addr_b32 v[58:59], v38 offset0:12 offset1:29      // 00000008E584: D8DC1D0C 3A000026
	ds_load_2addr_b32 v[60:61], v38 offset0:46 offset1:63      // 00000008E58C: D8DC3F2E 3C000026
	s_waitcnt lgkmcnt(6)                                       // 00000008E594: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E598: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E59C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E5A0: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E5A4: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E5A8: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E5AC: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E5B0: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E5B4: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E5B8: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E5BC: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E5C0: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E5C4: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E5C8: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E5CC: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E5D0: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:80 offset1:81      // 00000008E5D4: D8DC5150 2E00001F
	ds_load_2addr_b32 v[48:49], v38 offset0:80 offset1:97      // 00000008E5DC: D8DC6150 30000026
	ds_load_2addr_b32 v[50:51], v31 offset0:82 offset1:83      // 00000008E5E4: D8DC5352 3200001F
	ds_load_2addr_b32 v[52:53], v38 offset0:114 offset1:131    // 00000008E5EC: D8DC8372 34000026
	ds_load_2addr_b32 v[54:55], v31 offset0:84 offset1:85      // 00000008E5F4: D8DC5554 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:86 offset1:87      // 00000008E5FC: D8DC5756 3800001F
	ds_load_2addr_b32 v[58:59], v38 offset0:148 offset1:165    // 00000008E604: D8DCA594 3A000026
	ds_load_2addr_b32 v[60:61], v38 offset0:182 offset1:199    // 00000008E60C: D8DCC7B6 3C000026
	s_waitcnt lgkmcnt(6)                                       // 00000008E614: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E618: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E61C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E620: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E624: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E628: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E62C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E630: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E634: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E638: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E63C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E640: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E644: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E648: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E64C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E650: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:88 offset1:89      // 00000008E654: D8DC5958 2E00001F
	ds_load_2addr_b32 v[48:49], v38 offset0:216 offset1:233    // 00000008E65C: D8DCE9D8 30000026
	ds_load_2addr_b32 v[50:51], v31 offset0:90 offset1:91      // 00000008E664: D8DC5B5A 3200001F
	ds_load_2addr_b32 v[52:53], v39 offset0:122 offset1:139    // 00000008E66C: D8DC8B7A 34000027
	ds_load_2addr_b32 v[54:55], v31 offset0:92 offset1:93      // 00000008E674: D8DC5D5C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:94 offset1:95      // 00000008E67C: D8DC5F5E 3800001F
	ds_load_2addr_b32 v[58:59], v40 offset0:28 offset1:45      // 00000008E684: D8DC2D1C 3A000028
	ds_load_2addr_b32 v[60:61], v40 offset0:62 offset1:79      // 00000008E68C: D8DC4F3E 3C000028
	s_waitcnt lgkmcnt(6)                                       // 00000008E694: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E698: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E69C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E6A0: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E6A4: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E6A8: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E6AC: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E6B0: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E6B4: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E6B8: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E6BC: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E6C0: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E6C4: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E6C8: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E6CC: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E6D0: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:96 offset1:97      // 00000008E6D4: D8DC6160 2E00001F
	ds_load_2addr_b32 v[48:49], v40 offset0:96 offset1:113     // 00000008E6DC: D8DC7160 30000028
	ds_load_2addr_b32 v[50:51], v31 offset0:98 offset1:99      // 00000008E6E4: D8DC6362 3200001F
	ds_load_2addr_b32 v[52:53], v40 offset0:130 offset1:147    // 00000008E6EC: D8DC9382 34000028
	ds_load_2addr_b32 v[54:55], v31 offset0:100 offset1:101    // 00000008E6F4: D8DC6564 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:102 offset1:103    // 00000008E6FC: D8DC6766 3800001F
	ds_load_2addr_b32 v[58:59], v40 offset0:164 offset1:181    // 00000008E704: D8DCB5A4 3A000028
	ds_load_2addr_b32 v[60:61], v40 offset0:198 offset1:215    // 00000008E70C: D8DCD7C6 3C000028
	s_waitcnt lgkmcnt(6)                                       // 00000008E714: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E718: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E71C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E720: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E724: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E728: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E72C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E730: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E734: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E738: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E73C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E740: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E744: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E748: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E74C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E750: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:104 offset1:105    // 00000008E754: D8DC6968 2E00001F
	ds_load_2addr_b32 v[48:49], v40 offset0:232 offset1:249    // 00000008E75C: D8DCF9E8 30000028
	ds_load_2addr_b32 v[50:51], v31 offset0:106 offset1:107    // 00000008E764: D8DC6B6A 3200001F
	ds_load_2addr_b32 v[52:53], v41 offset0:10 offset1:27      // 00000008E76C: D8DC1B0A 34000029
	ds_load_2addr_b32 v[54:55], v31 offset0:108 offset1:109    // 00000008E774: D8DC6D6C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:110 offset1:111    // 00000008E77C: D8DC6F6E 3800001F
	ds_load_2addr_b32 v[58:59], v41 offset0:44 offset1:61      // 00000008E784: D8DC3D2C 3A000029
	ds_load_2addr_b32 v[60:61], v41 offset0:78 offset1:95      // 00000008E78C: D8DC5F4E 3C000029
	s_waitcnt lgkmcnt(6)                                       // 00000008E794: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E798: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E79C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E7A0: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E7A4: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E7A8: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E7AC: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E7B0: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E7B4: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E7B8: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E7BC: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E7C0: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E7C4: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E7C8: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E7CC: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E7D0: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:112 offset1:113    // 00000008E7D4: D8DC7170 2E00001F
	ds_load_2addr_b32 v[48:49], v41 offset0:112 offset1:129    // 00000008E7DC: D8DC8170 30000029
	ds_load_2addr_b32 v[50:51], v31 offset0:114 offset1:115    // 00000008E7E4: D8DC7372 3200001F
	ds_load_2addr_b32 v[52:53], v41 offset0:146 offset1:163    // 00000008E7EC: D8DCA392 34000029
	ds_load_2addr_b32 v[54:55], v31 offset0:116 offset1:117    // 00000008E7F4: D8DC7574 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:118 offset1:119    // 00000008E7FC: D8DC7776 3800001F
	ds_load_2addr_b32 v[58:59], v41 offset0:180 offset1:197    // 00000008E804: D8DCC5B4 3A000029
	ds_load_2addr_b32 v[60:61], v41 offset0:214 offset1:231    // 00000008E80C: D8DCE7D6 3C000029
	s_waitcnt lgkmcnt(6)                                       // 00000008E814: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E818: 567C612E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E81C: BF8700A1
	v_fmac_f32_e32 v62, v47, v49                               // 00000008E820: 567C632F
	s_waitcnt lgkmcnt(4)                                       // 00000008E824: BF89FC47
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E828: 567C6932
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E82C: BF8700A1
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E830: 567C6B33
	s_waitcnt lgkmcnt(1)                                       // 00000008E834: BF89FC17
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E838: 567C7536
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008E83C: BF8700A1
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E840: 567C7737
	s_waitcnt lgkmcnt(0)                                       // 00000008E844: BF89FC07
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E848: 567C7938
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E84C: BF870001
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E850: 567C7B39
	ds_load_2addr_b32 v[46:47], v31 offset0:120 offset1:121    // 00000008E854: D8DC7978 2E00001F
	ds_load_2addr_b32 v[48:49], v42 offset0:120 offset1:137    // 00000008E85C: D8DC8978 3000002A
	ds_load_2addr_b32 v[50:51], v31 offset0:122 offset1:123    // 00000008E864: D8DC7B7A 3200001F
	ds_load_2addr_b32 v[52:53], v43 offset0:26 offset1:43      // 00000008E86C: D8DC2B1A 3400002B
	ds_load_2addr_b32 v[54:55], v31 offset0:124 offset1:125    // 00000008E874: D8DC7D7C 3600001F
	ds_load_2addr_b32 v[56:57], v31 offset0:126 offset1:127    // 00000008E87C: D8DC7F7E 3800001F
	ds_load_2addr_b32 v[58:59], v43 offset0:60 offset1:77      // 00000008E884: D8DC4D3C 3A00002B
	ds_load_2addr_b32 v[60:61], v43 offset0:94 offset1:111     // 00000008E88C: D8DC6F5E 3C00002B
	v_lshlrev_b32_e32 v20, 2, v20                              // 00000008E894: 30282882
	s_waitcnt lgkmcnt(6)                                       // 00000008E898: BF89FC67
	v_fmac_f32_e32 v62, v46, v48                               // 00000008E89C: 567C612E
	ds_load_b32 v46, v20 offset:17440                          // 00000008E8A0: D8D84420 2E000014
	v_dual_mov_b32 v21, v17 :: v_dual_mov_b32 v20, v16         // 00000008E8A8: CA100111 15140110
	v_mov_b32_e32 v48, v44                                     // 00000008E8B0: 7E60032C
	v_dual_fmac_f32 v62, v47, v49 :: v_dual_mov_b32 v47, v1    // 00000008E8B4: C810632F 3E2E0101
	s_waitcnt lgkmcnt(5)                                       // 00000008E8BC: BF89FC57
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008E8C0: BF870091
	v_fmac_f32_e32 v62, v50, v52                               // 00000008E8C4: 567C6932
	v_fmac_f32_e32 v62, v51, v53                               // 00000008E8C8: 567C6B33
	s_waitcnt lgkmcnt(2)                                       // 00000008E8CC: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008E8D0: BF870091
	v_fmac_f32_e32 v62, v54, v58                               // 00000008E8D4: 567C7536
	v_fmac_f32_e32 v62, v55, v59                               // 00000008E8D8: 567C7737
	s_waitcnt lgkmcnt(1)                                       // 00000008E8DC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008E8E0: BF870091
	v_fmac_f32_e32 v62, v56, v60                               // 00000008E8E4: 567C7938
	v_fmac_f32_e32 v62, v57, v61                               // 00000008E8E8: 567C7B39
	s_waitcnt lgkmcnt(0)                                       // 00000008E8EC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008E8F0: BF870001
	v_mul_f32_e32 v46, v62, v46                                // 00000008E8F4: 105C5D3E
	s_nop 0                                                    // 00000008E8F8: BF800000
	s_nop 0                                                    // 00000008E8FC: BF800000
	global_load_b32 v49, v[20:21], off                         // 00000008E900: DC520000 317C0014
	ds_load_b32 v50, v47 offset:8704                           // 00000008E908: D8D82200 3200002F
	v_add_nc_u32_e32 v48, -1, v48                              // 00000008E910: 4A6060C1
	.long 0xd7000114                                           // 00000008E914: D7000114
	v_cndmask_b32_e32 v0, v20, v132, vcc_lo                    // 00000008E918: 02010914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000008E91C: BF870191
	v_add_co_ci_u32_e64 v21, null, 0, v21, s1                  // 00000008E920: D5207C15 00062A80
	.long 0xd44a0004                                           // 00000008E928: D44A0004
	v_cndmask_b32_e32 v1, 0, v48, vcc_lo                       // 00000008E92C: 02026080
	v_add_nc_u32_e32 v47, 0x44, v47                            // 00000008E930: 4A5E5EFF 00000044
	s_or_b32 s12, s4, s12                                      // 00000008E938: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000008E93C: BF890007
	v_fmac_f32_e32 v46, v49, v50                               // 00000008E940: 565C6531
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 00000008E944: 917E0C7E
	s_cbranch_execnz 65517                                     // 00000008E948: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1900>
	s_or_b32 exec_lo, exec_lo, s12                             // 00000008E94C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008E950: BF870121
	v_bfe_u32 v47, v46, 16, 1                                  // 00000008E954: D610002F 0205212E
	v_mad_u64_u32 v[20:21], null, 0x3000, v45, v[6:7]          // 00000008E95C: D6FE7C14 041A5AFF 00003000
	v_add3_u32 v45, v46, v47, 0x7fff                           // 00000008E968: D655002D 03FE5F2E 00007FFF
	global_store_d16_hi_b16 v[20:21], v45, off                 // 00000008E974: DC960000 007C2D14
	s_branch 64917                                             // 00000008E97C: BFA0FD95 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfd4>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 00000008E980: A201FF06 3FB8AA3B
	v_mov_b32_e32 v18, v23                                     // 00000008E988: 7E240317
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000008E98C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 00000008E990: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 00000008E998: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 00000008E99C: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 00000008E9A4: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 00000008E9AC: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 00000008E9B0: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 00000008E9B4: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 00000008E9BC: A0010401
	s_mov_b32 s4, 0                                            // 00000008E9C0: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 00000008E9C4: BF87000A
	v_exp_f32_e32 v16, s1                                      // 00000008E9C8: 7E204A01
	s_cvt_i32_f32 s1, s7                                       // 00000008E9CC: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000008E9D0: BF870585
	.long 0xd71c0010                                           // 00000008E9D4: D71C0010
	v_cndmask_b32_e32 v0, v16, v1, vcc_lo                      // 00000008E9D8: 02000310
	s_cselect_b32 s1, -1, 0                                    // 00000008E9DC: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 00000008E9E0: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000008E9E8: BF870131
	v_cndmask_b32_e64 v17, 0, v16, s1                          // 00000008E9EC: D5010011 00062080
	s_cselect_b32 s1, -1, 0                                    // 00000008E9F4: 980180C1
	v_mov_b32_e32 v16, v22                                     // 00000008E9F8: 7E200316
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 00000008E9FC: D5010011 000622FF 7F800000
	ds_load_b32 v19, v16                                       // 00000008EA08: D8D80000 13000010
	v_add_nc_u32_e32 v18, 0x80, v18                            // 00000008EA10: 4A2424FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008EA18: BF870001
	.long 0xd4490001                                           // 00000008EA1C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v18, vcc_lo                   // 00000008EA20: 020224FF 0000077F
	s_or_b32 s4, s1, s4                                        // 00000008EA28: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 00000008EA2C: BF89FC07
	v_mul_f32_e32 v19, v17, v19                                // 00000008EA30: 10262711
	ds_store_b32 v16, v19                                      // 00000008EA34: D8340000 00001310
	v_add_nc_u32_e32 v16, 0x220, v16                           // 00000008EA3C: 4A2020FF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000008EA44: 917E047E
	s_cbranch_execnz 65519                                     // 00000008EA48: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a08>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008EA4C: 8C7E047E
	v_dual_mov_b32 v17, v15 :: v_dual_mov_b32 v16, v14         // 00000008EA50: CA10010F 1110010E
	v_mov_b32_e32 v20, 0                                       // 00000008EA58: 7E280280
	s_mov_b32 s6, 0                                            // 00000008EA5C: BE860080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000008EA60: BF870112
	v_dual_mov_b32 v19, v17 :: v_dual_mov_b32 v18, v16         // 00000008EA64: CA100111 13120110
	v_dual_mov_b32 v21, v20 :: v_dual_mov_b32 v44, v25         // 00000008EA6C: CA100114 152C0119
	v_mov_b32_e32 v45, v23                                     // 00000008EA74: 7E5A0317
	s_mov_b32 s7, 0                                            // 00000008EA78: BE870080
	s_waitcnt lgkmcnt(0)                                       // 00000008EA7C: BF89FC07
	s_barrier                                                  // 00000008EA80: BFBD0000
	buffer_gl0_inv                                             // 00000008EA84: E0AC0000 00000000
	s_nop 0                                                    // 00000008EA8C: BF800000
	s_nop 0                                                    // 00000008EA90: BF800000
	s_nop 0                                                    // 00000008EA94: BF800000
	s_nop 0                                                    // 00000008EA98: BF800000
	s_nop 0                                                    // 00000008EA9C: BF800000
	s_nop 0                                                    // 00000008EAA0: BF800000
	s_nop 0                                                    // 00000008EAA4: BF800000
	s_nop 0                                                    // 00000008EAA8: BF800000
	s_nop 0                                                    // 00000008EAAC: BF800000
	s_nop 0                                                    // 00000008EAB0: BF800000
	s_nop 0                                                    // 00000008EAB4: BF800000
	s_nop 0                                                    // 00000008EAB8: BF800000
	s_nop 0                                                    // 00000008EABC: BF800000
	global_load_b32 v46, v[18:19], off                         // 00000008EAC0: DC520000 2E7C0012
	ds_load_b32 v47, v21 offset:17184                          // 00000008EAC8: D8D84320 2F000015
	v_add_nc_u32_e32 v45, 0x80, v45                            // 00000008EAD0: 4A5A5AFF 00000080
	.long 0xd7000112                                           // 00000008EAD8: D7000112
	v_cndmask_b32_e32 v1, 0x6000, v18, vcc_lo                  // 00000008EADC: 020224FF 00006000
	v_add_nc_u32_e32 v21, 4, v21                               // 00000008EAE4: 4A2A2A84
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 00000008EAE8: D5207C13 00062680
	s_delay_alu instid0(VALU_DEP_4)                            // 00000008EAF0: BF870004
	.long 0xd4490004                                           // 00000008EAF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000008EAF8: 02025AFF 0000037F
	s_or_b32 s7, s4, s7                                        // 00000008EB00: 8C070704
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000008EB04: BF890007
	v_mul_f32_e32 v46, v46, v47                                // 00000008EB08: 105C5F2E
	ds_store_b32 v44, v46 offset:13056                         // 00000008EB0C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 00000008EB14: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s7                        // 00000008EB1C: 917E077E
	s_cbranch_execnz 65511                                     // 00000008EB20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ac0>
	s_or_b32 exec_lo, exec_lo, s7                              // 00000008EB24: 8C7E077E
	v_mad_u64_u32 v[18:19], null, 0x44, s6, v[5:6]             // 00000008EB28: D6FE7C12 04140CFF 00000044
	s_waitcnt lgkmcnt(0)                                       // 00000008EB34: BF89FC07
	s_barrier                                                  // 00000008EB38: BFBD0000
	buffer_gl0_inv                                             // 00000008EB3C: E0AC0000 00000000
	ds_load_2addr_b32 v[44:45], v18 offset1:17                 // 00000008EB44: D8DC1100 2C000012
	ds_load_2addr_b32 v[47:48], v18 offset0:34 offset1:51      // 00000008EB4C: D8DC3322 2F000012
	ds_load_2addr_b32 v[49:50], v18 offset0:68 offset1:85      // 00000008EB54: D8DC5544 31000012
	ds_load_2addr_b32 v[51:52], v18 offset0:102 offset1:119    // 00000008EB5C: D8DC7766 33000012
	s_waitcnt lgkmcnt(3)                                       // 00000008EB64: BF89FC37
	v_cvt_f16_f32_e32 v18, v44                                 // 00000008EB68: 7E24152C
	.long 0x7f24152d                                           // 00000008EB6C: 7F24152D
	.long 0xd4130201                                           // 00000008EB70: D4130201
	v_cndmask_b32_e32 v1, 0x38800006, v44, vcc_lo              // 00000008EB74: 020258FF 38800006
	.long 0xd4160204                                           // 00000008EB7C: D4160204
	v_cndmask_b32_e32 v1, 0x477fe000, v44, vcc_lo              // 00000008EB80: 020258FF 477FE000
	s_waitcnt lgkmcnt(2)                                       // 00000008EB88: BF89FC27
	v_cvt_f16_f32_e32 v19, v47                                 // 00000008EB8C: 7E26152F
	.long 0xd4130207                                           // 00000008EB90: D4130207
	v_cndmask_b32_e32 v1, 0x38800006, v45, vcc_lo              // 00000008EB94: 02025AFF 38800006
	.long 0xd416020a                                           // 00000008EB9C: D416020A
	v_cndmask_b32_e32 v1, 0x477fe000, v45, vcc_lo              // 00000008EBA0: 02025AFF 477FE000
	v_cvt_f32_f16_e32 v53, v18                                 // 00000008EBA8: 7E6A1712
	.long 0x7f261530                                           // 00000008EBAC: 7F261530
	.long 0xd413020b                                           // 00000008EBB0: D413020B
	v_cndmask_b32_e32 v1, 0x38800006, v47, vcc_lo              // 00000008EBB4: 02025EFF 38800006
	.long 0xd416020c                                           // 00000008EBBC: D416020C
	v_cndmask_b32_e32 v1, 0x477fe000, v47, vcc_lo              // 00000008EBC0: 02025EFF 477FE000
	v_cvt_f32_f16_e32 v54, v146/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000008EBC8: 7E6C1792
	s_waitcnt lgkmcnt(1)                                       // 00000008EBCC: BF89FC17
	v_cvt_f16_f32_e32 v21, v49                                 // 00000008EBD0: 7E2A1531
	s_and_b32 s1, s1, s4                                       // 00000008EBD4: 8B010401
	.long 0xd413020d                                           // 00000008EBD8: D413020D
	v_cndmask_b32_e32 v1, 0x38800006, v48, vcc_lo              // 00000008EBDC: 020260FF 38800006
	.long 0xd416020e                                           // 00000008EBE4: D416020E
	v_cndmask_b32_e32 v1, 0x477fe000, v48, vcc_lo              // 00000008EBE8: 020260FF 477FE000
	v_cvt_f32_f16_e32 v55, v19                                 // 00000008EBF0: 7E6E1713
	v_cndmask_b32_e64 v18, v44, v53, s1                        // 00000008EBF4: D5010012 00066B2C
	s_and_b32 s1, s7, s10                                      // 00000008EBFC: 8B010A07
	.long 0xd413020f                                           // 00000008EC00: D413020F
	v_cndmask_b32_e32 v1, 0x38800006, v49, vcc_lo              // 00000008EC04: 020262FF 38800006
	.long 0xd4160216                                           // 00000008EC0C: D4160216
	v_cndmask_b32_e32 v1, 0x477fe000, v49, vcc_lo              // 00000008EC10: 020262FF 477FE000
	v_cvt_f32_f16_e32 v56, v147/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000008EC18: 7E701793
	v_cndmask_b32_e64 v19, v45, v54, s1                        // 00000008EC1C: D5010013 00066D2D
	s_and_b32 s1, s11, s12                                     // 00000008EC24: 8B010C0B
	v_cvt_f32_f16_e32 v57, v21                                 // 00000008EC28: 7E721715
	v_cvt_f16_f32_e32 v46, v50                                 // 00000008EC2C: 7E5C1532
	v_cndmask_b32_e64 v21, v47, v55, s1                        // 00000008EC30: D5010015 00066F2F
	s_and_b32 s1, s13, s14                                     // 00000008EC38: 8B010E0D
	s_waitcnt lgkmcnt(0)                                       // 00000008EC3C: BF89FC07
	.long 0x7f5c1533                                           // 00000008EC40: 7F5C1533
	v_cndmask_b32_e64 v44, v48, v56, s1                        // 00000008EC44: D501002C 00067130
	s_and_b32 s1, s15, s22                                     // 00000008EC4C: 8B01160F
	.long 0xd4160204                                           // 00000008EC50: D4160204
	v_cndmask_b32_e32 v1, 0x477fe000, v50, vcc_lo              // 00000008EC54: 020264FF 477FE000
	v_cndmask_b32_e64 v45, v49, v57, s1                        // 00000008EC5C: D501002D 00067331
	.long 0xd4130201                                           // 00000008EC64: D4130201
	v_cndmask_b32_e32 v1, 0x38800006, v50, vcc_lo              // 00000008EC68: 020264FF 38800006
	v_cvt_f32_f16_e32 v47, v46                                 // 00000008EC70: 7E5E172E
	v_cvt_f16_f32_e32 v46, v52                                 // 00000008EC74: 7E5C1534
	.long 0xd4130207                                           // 00000008EC78: D4130207
	v_cndmask_b32_e32 v1, 0x38800006, v51, vcc_lo              // 00000008EC7C: 020266FF 38800006
	.long 0xd416020a                                           // 00000008EC84: D416020A
	v_cndmask_b32_e32 v1, 0x477fe000, v51, vcc_lo              // 00000008EC88: 020266FF 477FE000
	v_cvt_f32_f16_e32 v48, v174/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000008EC90: 7E6017AE
	.long 0xd413020b                                           // 00000008EC94: D413020B
	v_cndmask_b32_e32 v1, 0x38800006, v52, vcc_lo              // 00000008EC98: 020268FF 38800006
	.long 0xd416020c                                           // 00000008ECA0: D416020C
	v_cndmask_b32_e32 v1, 0x477fe000, v52, vcc_lo              // 00000008ECA4: 020268FF 477FE000
	s_and_b32 s1, s1, s4                                       // 00000008ECAC: 8B010401
	v_cvt_f32_f16_e32 v49, v46                                 // 00000008ECB0: 7E62172E
	v_cndmask_b32_e64 v46, v50, v47, s1                        // 00000008ECB4: D501002E 00065F32
	s_and_b32 s1, s7, s10                                      // 00000008ECBC: 8B010A07
	s_mov_b32 s4, 0                                            // 00000008ECC0: BE840080
	v_cndmask_b32_e64 v47, v51, v48, s1                        // 00000008ECC4: D501002F 00066133
	s_and_b32 s1, s11, s12                                     // 00000008ECCC: 8B010C0B
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000008ECD0: BF870009
	v_cndmask_b32_e64 v48, v52, v49, s1                        // 00000008ECD4: D5010030 00066334
	v_mov_b32_e32 v49, v0                                      // 00000008ECDC: 7E620300
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008ECE0: BF870091
	v_lshrrev_b32_e32 v50, 4, v49                              // 00000008ECE4: 32646284
	v_lshlrev_b32_e32 v51, 2, v50                              // 00000008ECE8: 30666482
	v_mad_u64_u32 v[53:54], null, 0x44, v50, v[1:2]            // 00000008ECEC: D6FE7C35 040664FF 00000044
	s_delay_alu instid0(VALU_DEP_2)                            // 00000008ECF8: BF870002
	v_add_nc_u32_e32 v50, 0x3200, v51                          // 00000008ECFC: 4A6466FF 00003200
	v_add_nc_u32_e32 v52, 0x3600, v51                          // 00000008ED04: 4A6866FF 00003600
	v_add_nc_u32_e32 v58, 0x3a00, v51                          // 00000008ED0C: 4A7466FF 00003A00
	v_add_nc_u32_e32 v51, 0x3e00, v51                          // 00000008ED14: 4A6666FF 00003E00
	ds_load_b32 v62, v53                                       // 00000008ED1C: D8D80000 3E000035
	ds_load_2addr_b32 v[54:55], v50 offset0:64 offset1:193     // 00000008ED24: D8DCC140 36000032
	ds_load_2addr_b32 v[56:57], v52 offset0:66 offset1:195     // 00000008ED2C: D8DCC342 38000034
	ds_load_2addr_b32 v[58:59], v58 offset0:68 offset1:197     // 00000008ED34: D8DCC544 3A00003A
	ds_load_2addr_b32 v[60:61], v51 offset0:70 offset1:199     // 00000008ED3C: D8DCC746 3C000033
	s_waitcnt lgkmcnt(3)                                       // 00000008ED44: BF89FC37
	v_cvt_f16_f32_e32 v50, v54                                 // 00000008ED48: 7E641536
	.long 0xd4130201                                           // 00000008ED4C: D4130201
	v_cndmask_b32_e32 v1, 0x38800006, v54, vcc_lo              // 00000008ED50: 02026CFF 38800006
	.long 0xd4160207                                           // 00000008ED58: D4160207
	v_cndmask_b32_e32 v1, 0x477fe000, v54, vcc_lo              // 00000008ED5C: 02026CFF 477FE000
	.long 0x7f641537                                           // 00000008ED64: 7F641537
	.long 0xd413020a                                           // 00000008ED68: D413020A
	v_cndmask_b32_e32 v1, 0x38800006, v55, vcc_lo              // 00000008ED6C: 02026EFF 38800006
	v_cvt_f32_f16_e32 v63, v50                                 // 00000008ED74: 7E7E1732
	.long 0xd416020b                                           // 00000008ED78: D416020B
	v_cndmask_b32_e32 v1, 0x477fe000, v55, vcc_lo              // 00000008ED7C: 02026EFF 477FE000
	s_and_b32 s1, s1, s7                                       // 00000008ED84: 8B010701
	s_waitcnt lgkmcnt(2)                                       // 00000008ED88: BF89FC27
	v_cvt_f16_f32_e32 v51, v56                                 // 00000008ED8C: 7E661538
	v_cvt_f32_f16_e32 v64, v178/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000008ED90: 7E8017B2
	v_cndmask_b32_e64 v54, v54, v63, s1                        // 00000008ED94: D5010036 00067F36
	.long 0xd413020c                                           // 00000008ED9C: D413020C
	v_cndmask_b32_e32 v1, 0x38800006, v56, vcc_lo              // 00000008EDA0: 020270FF 38800006
	.long 0xd416020d                                           // 00000008EDA8: D416020D
	v_cndmask_b32_e32 v1, 0x477fe000, v56, vcc_lo              // 00000008EDAC: 020270FF 477FE000
	s_and_b32 s1, s10, s11                                     // 00000008EDB4: 8B010B0A
	.long 0x7f661539                                           // 00000008EDB8: 7F661539
	v_cvt_f32_f16_e32 v63, v51                                 // 00000008EDBC: 7E7E1733
	v_cndmask_b32_e64 v55, v55, v64, s1                        // 00000008EDC0: D5010037 00068137
	v_fmac_f32_e32 v62, v54, v18                               // 00000008EDC8: 567C2536
	.long 0xd413020e                                           // 00000008EDCC: D413020E
	v_cndmask_b32_e32 v1, 0x38800006, v57, vcc_lo              // 00000008EDD0: 020272FF 38800006
	.long 0xd416020f                                           // 00000008EDD8: D416020F
	v_cndmask_b32_e32 v1, 0x477fe000, v57, vcc_lo              // 00000008EDDC: 020272FF 477FE000
	s_and_b32 s1, s12, s13                                     // 00000008EDE4: 8B010D0C
	s_waitcnt lgkmcnt(1)                                       // 00000008EDE8: BF89FC17
	v_cvt_f16_f32_e32 v52, v58                                 // 00000008EDEC: 7E68153A
	v_cvt_f32_f16_e32 v51, v179/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000008EDF0: 7E6617B3
	v_cndmask_b32_e64 v54, v56, v63, s1                        // 00000008EDF4: D5010036 00067F38
	v_fmac_f32_e32 v62, v55, v19                               // 00000008EDFC: 567C2737
	.long 0xd4130216                                           // 00000008EE00: D4130216
	v_cndmask_b32_e32 v1, 0x38800006, v58, vcc_lo              // 00000008EE04: 020274FF 38800006
	.long 0xd4160217                                           // 00000008EE0C: D4160217
	v_cndmask_b32_e32 v1, 0x477fe000, v58, vcc_lo              // 00000008EE10: 020274FF 477FE000
	s_and_b32 s1, s14, s15                                     // 00000008EE18: 8B010F0E
	v_cvt_f16_f32_e32 v50, v59                                 // 00000008EE1C: 7E64153B
	v_cvt_f32_f16_e32 v52, v52                                 // 00000008EE20: 7E681734
	v_cndmask_b32_e64 v51, v57, v51, s1                        // 00000008EE24: D5010033 00066739
	v_fmac_f32_e32 v62, v54, v21                               // 00000008EE2C: 567C2B36
	.long 0xd413021a                                           // 00000008EE30: D413021A
	v_cndmask_b32_e32 v1, 0x38800006, v59, vcc_lo              // 00000008EE34: 020276FF 38800006
	.long 0xd416021b                                           // 00000008EE3C: D416021B
	v_cndmask_b32_e32 v1, 0x477fe000, v59, vcc_lo              // 00000008EE40: 020276FF 477FE000
	s_and_b32 s1, s22, s23                                     // 00000008EE48: 8B011716
	s_waitcnt lgkmcnt(0)                                       // 00000008EE4C: BF89FC07
	.long 0x7f64153c                                           // 00000008EE50: 7F64153C
	v_cvt_f32_f16_e32 v54, v50                                 // 00000008EE54: 7E6C1732
	v_cndmask_b32_e64 v52, v58, v52, s1                        // 00000008EE58: D5010034 0006693A
	v_fmac_f32_e32 v62, v51, v44                               // 00000008EE60: 567C5933
	.long 0xd4130207                                           // 00000008EE64: D4130207
	v_cndmask_b32_e32 v1, 0x38800006, v60, vcc_lo              // 00000008EE68: 020278FF 38800006
	.long 0xd416020a                                           // 00000008EE70: D416020A
	v_cndmask_b32_e32 v1, 0x477fe000, v60, vcc_lo              // 00000008EE74: 020278FF 477FE000
	s_and_b32 s1, s26, s27                                     // 00000008EE7C: 8B011B1A
	v_cvt_f16_f32_e32 v50, v61                                 // 00000008EE80: 7E64153D
	v_cvt_f32_f16_e32 v51, v178/*Invalid register, operand has 'VS_32_Lo128' register class*/// 00000008EE84: 7E6617B2
	v_cndmask_b32_e64 v54, v59, v54, s1                        // 00000008EE88: D5010036 00066D3B
	v_fmac_f32_e32 v62, v52, v45                               // 00000008EE90: 567C5B34
	.long 0xd413020b                                           // 00000008EE94: D413020B
	v_cndmask_b32_e32 v1, 0x38800006, v61, vcc_lo              // 00000008EE98: 02027AFF 38800006
	.long 0xd416020c                                           // 00000008EEA0: D416020C
	v_cndmask_b32_e32 v1, 0x477fe000, v61, vcc_lo              // 00000008EEA4: 02027AFF 477FE000
	s_and_b32 s1, s7, s10                                      // 00000008EEAC: 8B010A07
	v_cvt_f32_f16_e32 v50, v50                                 // 00000008EEB0: 7E641732
	v_cndmask_b32_e64 v51, v60, v51, s1                        // 00000008EEB4: D5010033 0006673C
	v_fmac_f32_e32 v62, v54, v46                               // 00000008EEBC: 567C5D36
	s_and_b32 s1, s11, s12                                     // 00000008EEC0: 8B010C0B
	s_delay_alu instid0(VALU_DEP_3) | instid1(SALU_CYCLE_1)    // 00000008EEC4: BF870483
	v_cndmask_b32_e64 v50, v61, v50, s1                        // 00000008EEC8: D5010032 0006653D
	.long 0xd4490001                                           // 00000008EED0: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v49, vcc_lo                   // 00000008EED4: 020262FF 0000077F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008EEDC: BF8700A3
	v_dual_fmac_f32 v62, v51, v47 :: v_dual_add_nc_u32 v51, 0x80, v49// 00000008EEE0: C8205F33 3E3262FF 00000080
	s_or_b32 s4, s1, s4                                        // 00000008EEEC: 8C040401
	v_dual_fmac_f32 v62, v50, v48 :: v_dual_mov_b32 v49, v51   // 00000008EEF0: C8106132 3E300133
	ds_store_b32 v53, v62                                      // 00000008EEF8: D8340000 00003E35
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000008EF00: 917E047E
	s_cbranch_execnz 65398                                     // 00000008EF04: BFA6FF76 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ce0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008EF08: 8C7E047E
	.long 0xd7000110                                           // 00000008EF0C: D7000110
	v_cndmask_b32_e32 v1, 0x30000, v16, vcc_lo                 // 00000008EF10: 020220FF 00030000
	v_add_nc_u32_e32 v20, 32, v20                              // 00000008EF18: 4A2828A0
	v_add_co_ci_u32_e64 v17, null, 0, v17, s1                  // 00000008EF1C: D5207C11 00062280
	s_add_i32 s1, s6, 8                                        // 00000008EF24: 81018806
	s_cmp_gt_u32 s6, 55                                        // 00000008EF28: BF08B706
	s_mov_b32 s6, s1                                           // 00000008EF2C: BE860001
	s_cbranch_scc0 65227                                       // 00000008EF30: BFA1FECB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a60>
	.long 0xd7000108                                           // 00000008EF34: D7000108
	v_cndmask_b32_e32 v1, 0x180000, v8, vcc_lo                 // 00000008EF38: 020210FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008EF40: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v9, s1                    // 00000008EF44: D5207C09 00061280
	.long 0xd700010a                                           // 00000008EF4C: D700010A
	v_cndmask_b32_e32 v1, 0x180000, v10, vcc_lo                // 00000008EF50: 020214FF 00180000
	v_add_co_ci_u32_e64 v11, null, 0, v11, s1                  // 00000008EF58: D5207C0B 00061680
	.long 0xd700010c                                           // 00000008EF60: D700010C
	v_cndmask_b32_e32 v1, 0xc0000, v12, vcc_lo                 // 00000008EF64: 020218FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008EF6C: BF8700A1
	v_add_co_ci_u32_e64 v13, null, 0, v13, s1                  // 00000008EF70: D5207C0D 00061A80
	.long 0xd700010e                                           // 00000008EF78: D700010E
	v_cndmask_b32_e32 v1, 0x180000, v14, vcc_lo                // 00000008EF7C: 02021CFF 00180000
	v_add_co_ci_u32_e64 v15, null, 0, v15, s1                  // 00000008EF84: D5207C0F 00061E80
	s_add_i32 s5, s5, 1                                        // 00000008EF8C: 81058105
	s_waitcnt lgkmcnt(0)                                       // 00000008EF90: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 00000008EF94: BF062105
	s_barrier                                                  // 00000008EF98: BFBD0000
	buffer_gl0_inv                                             // 00000008EF9C: E0AC0000 00000000
	s_cbranch_scc0 63705                                       // 00000008EFA4: BFA1F8D9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x30c>
	v_mov_b32_e32 v4, v23                                      // 00000008EFA8: 7E080317
	s_add_u32 s0, s28, s20                                     // 00000008EFAC: 8000141C
	.long 0xd73c0000                                           // 00000008EFB0: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000008EFB4: 02020489
	s_addc_u32 s1, s29, s21                                    // 00000008EFB8: 8201151D
	s_add_u32 s2, s24, s18                                     // 00000008EFBC: 80021218
	s_addc_u32 s3, s25, s19                                    // 00000008EFC0: 82031319
	s_add_u32 s0, s2, s0                                       // 00000008EFC4: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000008EFC8: 82010103
	.long 0xd7006a00                                           // 00000008EFCC: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000008EFD0: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000008EFD4: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000008EFD8: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000008EFE0: BE810080
	.long 0xd7006a00                                           // 00000008EFE4: D7006A00
	v_cndmask_b32_e32 v1, v0, v24, vcc_lo                      // 00000008EFE8: 02023100
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000008EFEC: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008EFF4: BF870092
	.long 0xd7006a00                                           // 00000008EFF8: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 00000008EFFC: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 00000008F000: D5207C01 01AA0211
	s_nop 0                                                    // 00000008F008: BF800000
	s_nop 0                                                    // 00000008F00C: BF800000
	s_nop 0                                                    // 00000008F010: BF800000
	s_nop 0                                                    // 00000008F014: BF800000
	s_nop 0                                                    // 00000008F018: BF800000
	s_nop 0                                                    // 00000008F01C: BF800000
	s_nop 0                                                    // 00000008F020: BF800000
	s_nop 0                                                    // 00000008F024: BF800000
	s_nop 0                                                    // 00000008F028: BF800000
	s_nop 0                                                    // 00000008F02C: BF800000
	s_nop 0                                                    // 00000008F030: BF800000
	s_nop 0                                                    // 00000008F034: BF800000
	s_nop 0                                                    // 00000008F038: BF800000
	s_nop 0                                                    // 00000008F03C: BF800000
	ds_load_b32 v2, v22                                        // 00000008F040: D8D80000 02000016
	v_add_nc_u32_e32 v4, 0x80, v4                              // 00000008F048: 4A0808FF 00000080
	v_add_nc_u32_e32 v22, 0x220, v22                           // 00000008F050: 4A2C2CFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000008F058: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000008F05C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 00000008F064: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000008F068: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 00000008F06C: DC6A0000 007C0200
	.long 0xd7000000                                           // 00000008F074: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000008F078: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000008F080: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000008F088: 917E017E
	s_cbranch_execnz 65516                                     // 00000008F08C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi8ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_endpgm                                                   // 00000008F090: BFB00000
		...

