0000000000217800 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_>:
; _ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_():
	.long 0xd44a0004                                           // 000000217800: D44A0004
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 000000217804: 02020080
	s_mov_b32 s7, s3                                           // 000000217808: BE870003
	s_and_saveexec_b32 s3, s4                                  // 00000021780C: BE832004
	v_mov_b32_e32 v1, 0                                        // 000000217810: 7E020280
	ds_store_b32 v1, v1 offset:512                             // 000000217814: D8340200 00000101
	s_or_b32 exec_lo, exec_lo, s3                              // 00000021781C: 8C7E037E
	s_clause 0x3                                               // 000000217820: BF850003
	s_load_b64 s[24:25], s[0:1], 0x30                          // 000000217824: F4040600 F8000030
	s_load_b64 s[16:17], s[0:1], 0x20                          // 00000021782C: F4040400 F8000020
	s_load_b32 s20, s[0:1], 0x28                               // 000000217834: F4000500 F8000028
	s_load_b256 s[8:15], s[0:1], null                          // 00000021783C: F40C0200 F8000000
	s_mul_hi_i32 s0, s2, 0x55555556                            // 000000217844: 9700FF02 55555556
	s_lshl_b32 s21, s7, 6                                      // 00000021784C: 84158607
	s_lshr_b32 s5, s0, 31                                      // 000000217850: 85059F00
	s_ashr_i32 s3, s2, 31                                      // 000000217854: 86039F02
	s_add_i32 s0, s0, s5                                       // 000000217858: 81000500
	s_mul_i32 s1, s7, 0xc00                                    // 00000021785C: 9601FF07 00000C00
	s_mul_i32 s6, s7, 0x60000                                  // 000000217864: 9606FF07 00060000
	s_mul_hi_i32 s5, s21, 0x1800                               // 00000021786C: 9705FF15 00001800
	s_mul_i32 s7, s7, 0x140000                                 // 000000217874: 9607FF07 00140000
	v_dual_mov_b32 v5, 0 :: v_dual_lshlrev_b32 v6, 2, v0       // 00000021787C: CA220080 05060082
	s_mul_hi_i32 s19, s21, 0x5000                              // 000000217884: 9713FF15 00005000
	v_rsq_f32_e32 v7, 0x43000000                               // 00000021788C: 7E0E5CFF 43000000
	s_waitcnt lgkmcnt(0)                                       // 000000217894: BF89FC07
	s_barrier                                                  // 000000217898: BFBD0000
	buffer_gl0_inv                                             // 00000021789C: E0AC0000 00000000
	s_cmp_lg_u64 s[24:25], 0                                   // 0000002178A4: BF118018
	s_cselect_b32 s22, -1, 0                                   // 0000002178A8: 981680C1
	s_lshl_b32 s26, s0, 7                                      // 0000002178AC: 841A8700
	s_add_i32 s18, s2, s1                                      // 0000002178B0: 81120102
	s_lshl_b64 s[0:1], s[2:3], 7                               // 0000002178B4: 84808702
	s_ashr_i32 s27, s26, 31                                    // 0000002178B8: 861B9F1A
	s_add_u32 s0, s6, s0                                       // 0000002178BC: 80000006
	s_addc_u32 s1, s5, s1                                      // 0000002178C0: 82010105
	.long 0xd7000001                                           // 0000002178C4: D7000001
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000002178C8: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000002178CC: BF870241
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000002178D0: D5207C02 00010001
	.long 0xd44c0000                                           // 0000002178D8: D44C0000
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 0000002178DC: 020200C0
	.long 0xd44c0001                                           // 0000002178E0: D44C0001
	v_cndmask_b32_e32 v1, 32, v0, vcc_lo                       // 0000002178E4: 020200A0
	.long 0xd44c0002                                           // 0000002178E8: D44C0002
	v_cndmask_b32_e32 v1, 16, v0, vcc_lo                       // 0000002178EC: 02020090
	.long 0xd73c0003                                           // 0000002178F0: D73C0003
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000002178F4: 02020282
	.long 0xd44c0003                                           // 0000002178F8: D44C0003
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 0000002178FC: 02020088
	.long 0xd44c0005                                           // 000000217900: D44C0005
	v_cndmask_b32_e32 v1, 4, v0, vcc_lo                        // 000000217904: 02020084
	.long 0xd44c0006                                           // 000000217908: D44C0006
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000021790C: 02020082
	.long 0xd73c0001                                           // 000000217910: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 000000217914: 02020281
	v_lshlrev_b32_e32 v0, 1, v0                                // 000000217918: 30000081
	.long 0xd7006a08                                           // 00000021791C: D7006A08
	v_cndmask_b32_e32 v1, s12, v3, vcc_lo                      // 000000217920: 0202060C
	s_delay_alu instid0(VALU_DEP_1)                            // 000000217924: BF870001
	v_add_co_ci_u32_e64 v9, null, s13, v4, vcc_lo              // 000000217928: D5207C09 01AA080D
	s_lshl_b64 s[12:13], s[26:27], 1                           // 000000217930: 848C811A
	.long 0xd7006a01                                           // 000000217934: D7006A01
	v_cndmask_b32_e32 v1, s24, v1, vcc_lo                      // 000000217938: 02020218
	s_add_u32 s7, s7, s12                                      // 00000021793C: 80070C07
	s_addc_u32 s12, s19, s13                                   // 000000217940: 820C0D13
	s_add_u32 s7, s8, s7                                       // 000000217944: 80070708
	s_addc_u32 s8, s9, s12                                     // 000000217948: 82080C09
	.long 0xd700070b                                           // 00000021794C: D700070B
	v_cndmask_b32_e32 v1, s7, v0, vcc_lo                       // 000000217950: 02020007
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000217954: BF8700B1
	v_add_co_ci_u32_e64 v12, null, s8, 0, s7                   // 000000217958: D5207C0C 001D0008
	v_add_co_ci_u32_e64 v2, null, s25, v2, vcc_lo              // 000000217960: D5207C02 01AA0419
	.long 0xd7006a00                                           // 000000217968: D7006A00
	v_cndmask_b32_e32 v1, s14, v3, vcc_lo                      // 00000021796C: 0202060E
	v_add_co_ci_u32_e64 v10, null, s15, v4, vcc_lo             // 000000217970: D5207C0A 01AA080F
	.long 0xd7006a03                                           // 000000217978: D7006A03
	v_cndmask_b32_e32 v1, 0x1000, v11, vcc_lo                  // 00000021797C: 020216FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000217984: BF870001
	v_add_co_ci_u32_e64 v4, null, 0, v12, vcc_lo               // 000000217988: D5207C04 01AA1880
	s_mov_b64 s[8:9], 0                                        // 000000217990: BE880180
	s_mov_b32 s7, 0x41800000                                   // 000000217994: BE8700FF 41800000
	s_branch 37                                                // 00000021799C: BFA00025 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x234>
	ds_load_b32 v11, v5 offset:512                             // 0000002179A0: D8D80200 0B000005
	s_lshl_b64 s[14:15], s[18:19], 2                           // 0000002179A8: 848E8212
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000002179AC: BF870009
	s_add_u32 s14, s16, s14                                    // 0000002179B0: 800E0E10
	s_addc_u32 s15, s17, s15                                   // 0000002179B4: 820F0F11
	s_waitcnt lgkmcnt(0)                                       // 0000002179B8: BF89FC07
	v_add_f32_e32 v11, s13, v11                                // 0000002179BC: 0616160D
	ds_store_b32 v5, v11 offset:512                            // 0000002179C0: D8340200 00000B05
	global_store_b32 v5, v11, s[14:15]                         // 0000002179C8: DC6A0000 000E0B05
	s_or_b32 exec_lo, exec_lo, s12                             // 0000002179D0: 8C7E0C7E
	.long 0xd7006a01                                           // 0000002179D4: D7006A01
	v_cndmask_b32_e32 v1, 0x3000, v1, vcc_lo                   // 0000002179D8: 020202FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000002179E0: BF8700A1
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000002179E4: D5207C02 01AA0480
	.long 0xd7006a03                                           // 0000002179EC: D7006A03
	v_cndmask_b32_e32 v1, 0x5000, v3, vcc_lo                   // 0000002179F0: 020206FF 00005000
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 0000002179F8: D5207C04 01AA0880
	s_add_u32 s8, s8, 0x6000                                   // 000000217A00: 8008FF08 00006000
	s_addc_u32 s9, s9, 0                                       // 000000217A08: 82098009
	s_add_i32 s18, s18, 48                                     // 000000217A0C: 8112B012
	s_add_i32 s21, s21, 1                                      // 000000217A10: 81158115
	s_cmp_eq_u32 s8, 0x180000                                  // 000000217A14: BF06FF08 00180000
	s_waitcnt lgkmcnt(0)                                       // 000000217A1C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 000000217A20: BC7C0000
	s_barrier                                                  // 000000217A24: BFBD0000
	buffer_gl0_inv                                             // 000000217A28: E0AC0000 00000000
	s_cbranch_scc1 294                                         // 000000217A30: BFA20126 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x6cc>
	v_mov_b32_e32 v13, 0                                       // 000000217A34: 7E1A0280
	s_cmp_lt_i32 s21, s20                                      // 000000217A38: BF041415
	s_cselect_b32 s12, -1, 0                                   // 000000217A3C: 980C80C1
	s_cmp_ge_i32 s21, s20                                      // 000000217A40: BF031415
	s_cbranch_scc1 4                                           // 000000217A44: BFA20004 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x258>
	global_load_u16 v11, v[3:4], off offset:-4096              // 000000217A48: DC4A1000 0B7C0003
	s_waitcnt vmcnt(0)                                         // 000000217A50: BF8903F7
	v_lshlrev_b32_e32 v13, 16, v11                             // 000000217A54: 301A1690
	v_cndmask_b32_e64 v11, 0, 1, s12                           // 000000217A58: D501000B 00310280
	v_mov_b32_e32 v12, 0                                       // 000000217A60: 7E180280
	s_and_not1_b32 vcc_lo, exec_lo, s12                        // 000000217A64: 916A0C7E
	s_cbranch_vccnz 4                                          // 000000217A68: BFA40004 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x27c>
	global_load_u16 v12, v[3:4], off                           // 000000217A6C: DC4A0000 0C7C0003
	s_waitcnt vmcnt(0)                                         // 000000217A74: BF8903F7
	v_lshlrev_b32_e32 v12, 16, v12                             // 000000217A78: 30181890
	v_mul_f32_e32 v14, v13, v13                                // 000000217A7C: 101C1B0D
	s_barrier                                                  // 000000217A80: BFBD0000
	buffer_gl0_inv                                             // 000000217A84: E0AC0000 00000000
	ds_store_b32 v6, v14                                       // 000000217A8C: D8340000 00000E06
	s_waitcnt lgkmcnt(0)                                       // 000000217A94: BF89FC07
	s_barrier                                                  // 000000217A98: BFBD0000
	buffer_gl0_inv                                             // 000000217A9C: E0AC0000 00000000
	s_and_saveexec_b32 s12, s0                                 // 000000217AA4: BE8C2000
	s_cbranch_execz 6                                          // 000000217AA8: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x2c4>
	ds_load_2addr_stride64_b32 v[14:15], v6 offset1:1          // 000000217AAC: D8E00100 0E000006
	s_waitcnt lgkmcnt(0)                                       // 000000217AB4: BF89FC07
	v_add_f32_e32 v14, v15, v14                                // 000000217AB8: 061C1D0F
	ds_store_b32 v6, v14                                       // 000000217ABC: D8340000 00000E06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000217AC4: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000217AC8: BF89FC07
	s_barrier                                                  // 000000217ACC: BFBD0000
	buffer_gl0_inv                                             // 000000217AD0: E0AC0000 00000000
	s_and_saveexec_b32 s12, s1                                 // 000000217AD8: BE8C2001
	s_cbranch_execz 6                                          // 000000217ADC: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x2f8>
	ds_load_2addr_b32 v[14:15], v6 offset1:32                  // 000000217AE0: D8DC2000 0E000006
	s_waitcnt lgkmcnt(0)                                       // 000000217AE8: BF89FC07
	v_add_f32_e32 v14, v15, v14                                // 000000217AEC: 061C1D0F
	ds_store_b32 v6, v14                                       // 000000217AF0: D8340000 00000E06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000217AF8: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000217AFC: BF89FC07
	s_barrier                                                  // 000000217B00: BFBD0000
	buffer_gl0_inv                                             // 000000217B04: E0AC0000 00000000
	s_and_saveexec_b32 s12, s2                                 // 000000217B0C: BE8C2002
	s_cbranch_execz 6                                          // 000000217B10: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x32c>
	ds_load_2addr_b32 v[14:15], v6 offset1:16                  // 000000217B14: D8DC1000 0E000006
	s_waitcnt lgkmcnt(0)                                       // 000000217B1C: BF89FC07
	v_add_f32_e32 v14, v15, v14                                // 000000217B20: 061C1D0F
	ds_store_b32 v6, v14                                       // 000000217B24: D8340000 00000E06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000217B2C: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000217B30: BF89FC07
	s_barrier                                                  // 000000217B34: BFBD0000
	buffer_gl0_inv                                             // 000000217B38: E0AC0000 00000000
	s_and_saveexec_b32 s12, s3                                 // 000000217B40: BE8C2003
	s_cbranch_execz 6                                          // 000000217B44: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x360>
	ds_load_2addr_b32 v[14:15], v6 offset1:8                   // 000000217B48: D8DC0800 0E000006
	s_waitcnt lgkmcnt(0)                                       // 000000217B50: BF89FC07
	v_add_f32_e32 v14, v15, v14                                // 000000217B54: 061C1D0F
	ds_store_b32 v6, v14                                       // 000000217B58: D8340000 00000E06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000217B60: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000217B64: BF89FC07
	s_barrier                                                  // 000000217B68: BFBD0000
	buffer_gl0_inv                                             // 000000217B6C: E0AC0000 00000000
	s_and_saveexec_b32 s12, s5                                 // 000000217B74: BE8C2005
	s_cbranch_execz 6                                          // 000000217B78: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x394>
	ds_load_2addr_b32 v[14:15], v6 offset1:4                   // 000000217B7C: D8DC0400 0E000006
	s_waitcnt lgkmcnt(0)                                       // 000000217B84: BF89FC07
	v_add_f32_e32 v14, v15, v14                                // 000000217B88: 061C1D0F
	ds_store_b32 v6, v14                                       // 000000217B8C: D8340000 00000E06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000217B94: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000217B98: BF89FC07
	s_barrier                                                  // 000000217B9C: BFBD0000
	buffer_gl0_inv                                             // 000000217BA0: E0AC0000 00000000
	s_and_saveexec_b32 s12, s6                                 // 000000217BA8: BE8C2006
	s_cbranch_execz 6                                          // 000000217BAC: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x3c8>
	ds_load_2addr_b32 v[14:15], v6 offset1:2                   // 000000217BB0: D8DC0200 0E000006
	s_waitcnt lgkmcnt(0)                                       // 000000217BB8: BF89FC07
	v_add_f32_e32 v14, v15, v14                                // 000000217BBC: 061C1D0F
	ds_store_b32 v6, v14                                       // 000000217BC0: D8340000 00000E06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000217BC8: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000217BCC: BF89FC07
	s_barrier                                                  // 000000217BD0: BFBD0000
	buffer_gl0_inv                                             // 000000217BD4: E0AC0000 00000000
	s_and_saveexec_b32 s12, s4                                 // 000000217BDC: BE8C2004
	s_cbranch_execz 8                                          // 000000217BE0: BFA50008 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x404>
	ds_load_b32 v14, v5 offset:4                               // 000000217BE4: D8D80004 0E000005
	ds_load_b32 v15, v6                                        // 000000217BEC: D8D80000 0F000006
	s_waitcnt lgkmcnt(0)                                       // 000000217BF4: BF89FC07
	v_add_f32_e32 v14, v14, v15                                // 000000217BF8: 061C1F0E
	ds_store_b32 v6, v14                                       // 000000217BFC: D8340000 00000E06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000217C04: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000217C08: BF89FC07
	s_barrier                                                  // 000000217C0C: BFBD0000
	buffer_gl0_inv                                             // 000000217C10: E0AC0000 00000000
	ds_load_b32 v14, v5                                        // 000000217C18: D8D80000 0E000005
	s_waitcnt lgkmcnt(0)                                       // 000000217C20: BF89FC07
	v_dual_mul_f32 v15, v12, v12 :: v_dual_add_f32 v14, 0x358637bd, v14// 000000217C24: C8C8190C 0F0E1CFF 358637BD
	s_delay_alu instid0(VALU_DEP_1)                            // 000000217C30: BF870001
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v14                     // 000000217C34: 7C281CFF 00800000
	s_barrier                                                  // 000000217C3C: BFBD0000
	buffer_gl0_inv                                             // 000000217C40: E0AC0000 00000000
	ds_store_b32 v6, v15                                       // 000000217C48: D8340000 00000F06
	s_waitcnt lgkmcnt(0)                                       // 000000217C50: BF89FC07
	s_barrier                                                  // 000000217C54: BFBD0000
	buffer_gl0_inv                                             // 000000217C58: E0AC0000 00000000
	s_and_saveexec_b32 s12, s0                                 // 000000217C60: BE8C2000
	s_cbranch_execz 6                                          // 000000217C64: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x480>
	ds_load_2addr_stride64_b32 v[15:16], v6 offset1:1          // 000000217C68: D8E00100 0F000006
	s_waitcnt lgkmcnt(0)                                       // 000000217C70: BF89FC07
	v_add_f32_e32 v15, v16, v15                                // 000000217C74: 061E1F10
	ds_store_b32 v6, v15                                       // 000000217C78: D8340000 00000F06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000217C80: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000217C84: BF89FC07
	s_barrier                                                  // 000000217C88: BFBD0000
	buffer_gl0_inv                                             // 000000217C8C: E0AC0000 00000000
	s_and_saveexec_b32 s12, s1                                 // 000000217C94: BE8C2001
	s_cbranch_execz 6                                          // 000000217C98: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x4b4>
	ds_load_2addr_b32 v[15:16], v6 offset1:32                  // 000000217C9C: D8DC2000 0F000006
	s_waitcnt lgkmcnt(0)                                       // 000000217CA4: BF89FC07
	v_add_f32_e32 v15, v16, v15                                // 000000217CA8: 061E1F10
	ds_store_b32 v6, v15                                       // 000000217CAC: D8340000 00000F06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000217CB4: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000217CB8: BF89FC07
	s_barrier                                                  // 000000217CBC: BFBD0000
	buffer_gl0_inv                                             // 000000217CC0: E0AC0000 00000000
	s_and_saveexec_b32 s12, s2                                 // 000000217CC8: BE8C2002
	s_cbranch_execz 6                                          // 000000217CCC: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x4e8>
	ds_load_2addr_b32 v[15:16], v6 offset1:16                  // 000000217CD0: D8DC1000 0F000006
	s_waitcnt lgkmcnt(0)                                       // 000000217CD8: BF89FC07
	v_add_f32_e32 v15, v16, v15                                // 000000217CDC: 061E1F10
	ds_store_b32 v6, v15                                       // 000000217CE0: D8340000 00000F06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000217CE8: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000217CEC: BF89FC07
	s_barrier                                                  // 000000217CF0: BFBD0000
	buffer_gl0_inv                                             // 000000217CF4: E0AC0000 00000000
	s_and_saveexec_b32 s12, s3                                 // 000000217CFC: BE8C2003
	s_cbranch_execz 6                                          // 000000217D00: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x51c>
	ds_load_2addr_b32 v[15:16], v6 offset1:8                   // 000000217D04: D8DC0800 0F000006
	s_waitcnt lgkmcnt(0)                                       // 000000217D0C: BF89FC07
	v_add_f32_e32 v15, v16, v15                                // 000000217D10: 061E1F10
	ds_store_b32 v6, v15                                       // 000000217D14: D8340000 00000F06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000217D1C: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000217D20: BF89FC07
	s_barrier                                                  // 000000217D24: BFBD0000
	buffer_gl0_inv                                             // 000000217D28: E0AC0000 00000000
	s_and_saveexec_b32 s12, s5                                 // 000000217D30: BE8C2005
	s_cbranch_execz 6                                          // 000000217D34: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x550>
	ds_load_2addr_b32 v[15:16], v6 offset1:4                   // 000000217D38: D8DC0400 0F000006
	s_waitcnt lgkmcnt(0)                                       // 000000217D40: BF89FC07
	v_add_f32_e32 v15, v16, v15                                // 000000217D44: 061E1F10
	ds_store_b32 v6, v15                                       // 000000217D48: D8340000 00000F06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000217D50: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000217D54: BF89FC07
	s_barrier                                                  // 000000217D58: BFBD0000
	buffer_gl0_inv                                             // 000000217D5C: E0AC0000 00000000
	s_and_saveexec_b32 s12, s6                                 // 000000217D64: BE8C2006
	s_cbranch_execz 6                                          // 000000217D68: BFA50006 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x584>
	ds_load_2addr_b32 v[15:16], v6 offset1:2                   // 000000217D6C: D8DC0200 0F000006
	s_waitcnt lgkmcnt(0)                                       // 000000217D74: BF89FC07
	v_add_f32_e32 v15, v16, v15                                // 000000217D78: 061E1F10
	ds_store_b32 v6, v15                                       // 000000217D7C: D8340000 00000F06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000217D84: 8C7E0C7E
	s_waitcnt lgkmcnt(0)                                       // 000000217D88: BF89FC07
	s_barrier                                                  // 000000217D8C: BFBD0000
	buffer_gl0_inv                                             // 000000217D90: E0AC0000 00000000
	s_and_saveexec_b32 s12, s4                                 // 000000217D98: BE8C2004
	s_cbranch_execz 8                                          // 000000217D9C: BFA50008 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x5c0>
	ds_load_b32 v15, v5 offset:4                               // 000000217DA0: D8D80004 0F000005
	ds_load_b32 v16, v6                                        // 000000217DA8: D8D80000 10000006
	s_waitcnt lgkmcnt(0)                                       // 000000217DB0: BF89FC07
	v_add_f32_e32 v15, v15, v16                                // 000000217DB4: 061E210F
	ds_store_b32 v6, v15                                       // 000000217DB8: D8340000 00000F06
	s_or_b32 exec_lo, exec_lo, s12                             // 000000217DC0: 8C7E0C7E
	v_mul_f32_e32 v15, 0x4b800000, v14                         // 000000217DC4: 101E1CFF 4B800000
	s_waitcnt lgkmcnt(0)                                       // 000000217DCC: BF89FC07
	s_barrier                                                  // 000000217DD0: BFBD0000
	buffer_gl0_inv                                             // 000000217DD4: E0AC0000 00000000
	v_cndmask_b32_e32 v14, v14, v15, vcc_lo                    // 000000217DDC: 021C1F0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000217DE0: BF8700B1
	v_rsq_f32_e32 v15, v14                                     // 000000217DE4: 7E1E5D0E
	ds_load_b32 v14, v5                                        // 000000217DE8: D8D80000 0E000005
	v_mul_f32_e32 v16, 0x45800000, v15                         // 000000217DF0: 10201EFF 45800000
	v_cndmask_b32_e32 v15, v15, v16, vcc_lo                    // 000000217DF8: 021E210F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000217DFC: BF870091
	v_mul_f32_e32 v15, v7, v15                                 // 000000217E00: 101E1F07
	v_mul_f32_e32 v13, v13, v15                                // 000000217E04: 101A1F0D
	.long 0xd7006a0f                                           // 000000217E08: D7006A0F
	v_cndmask_b32_e32 v0, v8, v8, vcc_lo                       // 000000217E0C: 02001108
	s_delay_alu instid0(VALU_DEP_1)                            // 000000217E10: BF870001
	v_add_co_ci_u32_e64 v16, null, s9, v9, vcc_lo              // 000000217E14: D5207C10 01AA1209
	s_and_not1_b32 vcc_lo, exec_lo, s22                        // 000000217E1C: 916A167E
	global_store_b32 v[15:16], v13, off                        // 000000217E20: DC6A0000 007C0D0F
	s_cbranch_vccnz 4                                          // 000000217E28: BFA40004 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x63c>
	v_fma_mixlo_f16 v13, v13, s7, 0                            // 000000217E2C: CC21000D 02000F0D
	global_store_b16 v[1:2], v13, off                          // 000000217E34: DC660000 007C0D01
	s_waitcnt lgkmcnt(0)                                       // 000000217E3C: BF89FC07
	v_add_f32_e32 v13, 0x358637bd, v14                         // 000000217E40: 061A1CFF 358637BD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000217E48: BF870121
	v_mul_f32_e32 v14, 0x4b800000, v13                         // 000000217E4C: 101C1AFF 4B800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v13                     // 000000217E54: 7C281AFF 00800000
	v_cndmask_b32_e32 v13, v13, v14, vcc_lo                    // 000000217E5C: 021A1D0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000217E60: BF870291
	v_rsq_f32_e32 v13, v13                                     // 000000217E64: 7E1A5D0D
	v_mul_f32_e32 v14, 0x45800000, v13                         // 000000217E68: 101C1AFF 45800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000217E70: BF870091
	v_cndmask_b32_e32 v13, v13, v14, vcc_lo                    // 000000217E74: 021A1D0D
	v_mul_f32_e32 v14, v12, v13                                // 000000217E78: 101C1B0C
	.long 0xd7006a0c                                           // 000000217E7C: D7006A0C
	v_cndmask_b32_e32 v0, v0, v8, vcc_lo                       // 000000217E80: 02001100
	s_delay_alu instid0(VALU_DEP_1)                            // 000000217E84: BF870001
	v_add_co_ci_u32_e64 v13, null, s9, v10, vcc_lo             // 000000217E88: D5207C0D 01AA1409
	global_store_b32 v[12:13], v14, off                        // 000000217E90: DC6A0000 007C0E0C
	s_and_saveexec_b32 s12, s4                                 // 000000217E98: BE8C2004
	s_cbranch_execz 65228                                      // 000000217E9C: BFA5FECC <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x1d0>
	v_cmp_ne_u32_e32 vcc_lo, 1, v11                            // 000000217EA0: 7C9A1681
	s_ashr_i32 s19, s18, 31                                    // 000000217EA4: 86139F12
	s_mov_b32 s13, 0                                           // 000000217EA8: BE8D0080
	s_cbranch_vccnz 65212                                      // 000000217EAC: BFA4FEBC <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x1a0>
	s_lshl_b64 s[14:15], s[18:19], 2                           // 000000217EB0: 848E8212
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000217EB4: BF870009
	s_add_u32 s14, s10, s14                                    // 000000217EB8: 800E0E0A
	s_addc_u32 s15, s11, s15                                   // 000000217EBC: 820F0F0B
	s_load_b32 s13, s[14:15], null                             // 000000217EC0: F4000347 F8000000
	s_branch 65205                                             // 000000217EC8: BFA0FEB5 <_ZN7halogen12_GLOBAL__N_110k_dnc_prepILb0ELb1ELb0EEEvPKtPKfPfS6_S6_iPtS6_S6_+0x1a0>
	s_endpgm                                                   // 000000217ECC: BFB00000
		...

