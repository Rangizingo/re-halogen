000000000002d900 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii>:
; _ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii():
	s_clause 0x1                                               // 00000002D900: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 00000002D904: F4080300 F8000020
	s_load_b256 s[4:11], s[0:1], null                          // 00000002D90C: F40C0100 F8000000
	s_lshl_b32 s3, s3, 4                                       // 00000002D914: 84038403
	s_lshl_b32 s2, s2, 6                                       // 00000002D918: 84028602
	s_waitcnt lgkmcnt(0)                                       // 00000002D91C: BF89FC07
	s_add_i32 s1, s13, s12                                     // 00000002D920: 81010C0D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000002D924: BF870499
	s_add_i32 s0, s3, s1                                       // 00000002D928: 81000103
	s_add_i32 s0, s0, 16                                       // 00000002D92C: 81009000
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000002D930: BF870499
	s_ashr_i32 s13, s0, 31                                     // 00000002D934: 860D9F00
	s_lshr_b32 s13, s13, 30                                    // 00000002D938: 850D9E0D
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000002D93C: BF870499
	s_add_i32 s0, s0, s13                                      // 00000002D940: 81000D00
	s_ashr_i32 s0, s0, 2                                       // 00000002D944: 86008200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002D948: BF870009
	s_cmp_lt_i32 s2, s0                                        // 00000002D94C: BF040002
	s_mov_b32 s0, -1                                           // 00000002D950: BE8000C1
	s_cbranch_scc1 65                                          // 00000002D954: BFA20041 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0x15c>
	v_and_or_b32 v2, v0, 63, s2                                // 00000002D958: D6570002 00097F00
	v_lshrrev_b32_e32 v5, 6, v0                                // 00000002D960: 320A0086
	v_or_b32_e32 v1, 0xffffff80, v0                            // 00000002D964: 380200FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002D96C: BF870123
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000002D970: 3406049F
	v_cmp_le_i32_e32 vcc_lo, s15, v2                           // 00000002D974: 7C86040F
	.long 0xd73c0003                                           // 00000002D978: D73C0003
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 00000002D97C: 02020482
	v_dual_mov_b32 v5, 0 :: v_dual_add_nc_u32 v2, s3, v5       // 00000002D980: CA200080 05020A03
	s_xor_b32 s13, vcc_lo, -1                                  // 00000002D988: 8D0DC16A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002D98C: BF870092
	.long 0xd7000003                                           // 00000002D990: D7000003
	v_cndmask_b32_e32 v1, s8, v3, vcc_lo                       // 00000002D994: 02020608
	v_add_co_ci_u32_e64 v4, null, s9, v4, s0                   // 00000002D998: D5207C04 00020809
	s_mov_b32 s0, 0                                            // 00000002D9A0: BE800080
	s_set_inst_prefetch_distance 0x1                           // 00000002D9A4: BF840001
	s_branch 15                                                // 00000002D9A8: BFA0000F <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0xe8>
	s_nop 0                                                    // 00000002D9AC: BF800000
	s_nop 0                                                    // 00000002D9B0: BF800000
	s_nop 0                                                    // 00000002D9B4: BF800000
	s_nop 0                                                    // 00000002D9B8: BF800000
	s_nop 0                                                    // 00000002D9BC: BF800000
	s_or_b32 exec_lo, exec_lo, s16                             // 00000002D9C0: 8C7E107E
	v_add_nc_u32_e32 v1, 0x80, v1                              // 00000002D9C4: 4A0202FF 00000080
	v_add_nc_u32_e32 v2, 2, v2                                 // 00000002D9CC: 4A040482
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002D9D0: BF8704A2
	v_cmp_lt_u32_e32 vcc_lo, 0x37f, v1                         // 00000002D9D4: 7C9202FF 0000037F
	s_or_b32 s0, vcc_lo, s0                                    // 00000002D9DC: 8C00006A
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 00000002D9E0: 917E007E
	s_cbranch_execz 26                                         // 00000002D9E4: BFA5001A <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0x150>
	v_cmp_gt_i32_e32 vcc_lo, s14, v2                           // 00000002D9E8: 7C88040E
	s_and_b32 s17, vcc_lo, s13                                 // 00000002D9EC: 8B110D6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002D9F0: BF870009
	s_and_saveexec_b32 s16, s17                                // 00000002D9F4: BE902011
	s_cbranch_execz 65521                                      // 00000002D9F8: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0xc0>
	v_ashrrev_i32_e32 v8, 31, v2                               // 00000002D9FC: 3410049F
	.long 0xd72c0009                                           // 00000002DA00: D72C0009
	v_cndmask_b32_e32 v1, s11, v2, vcc_lo                      // 00000002DA04: 0202040B
	v_mad_u64_u32 v[6:7], null, s10, v2, 0                     // 00000002DA08: D6FE7C06 0202040A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002DA10: BF870093
	.long 0xd72c0008                                           // 00000002DA14: D72C0008
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 00000002DA18: 0202100A
	v_add3_u32 v7, v7, v8, v9                                  // 00000002DA1C: D6550007 04261107
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002DA24: BF870091
	.long 0xd73c0006                                           // 00000002DA28: D73C0006
	v_cndmask_b32_e32 v1, 2, v6, vcc_lo                        // 00000002DA2C: 02020C82
	.long 0xd7006a06                                           // 00000002DA30: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000002DA34: 02020D03
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002DA38: BF870001
	v_add_co_ci_u32_e64 v7, null, v4, v7, vcc_lo               // 00000002DA3C: D5207C07 01AA0F04
	global_store_b32 v[6:7], v5, off                           // 00000002DA44: DC6A0000 007C0506
	s_branch 65500                                             // 00000002DA4C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0xc0>
	s_set_inst_prefetch_distance 0x2                           // 00000002DA50: BF840002
	s_or_b32 exec_lo, exec_lo, s0                              // 00000002DA54: 8C7E007E
	s_mov_b32 s0, 0                                            // 00000002DA58: BE800080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002DA5C: BF870009
	s_and_b32 vcc_lo, exec_lo, s0                              // 00000002DA60: 8B6A007E
	s_cbranch_vccz 806                                         // 00000002DA64: BFA30326 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0xe00>
	v_lshlrev_b32_e32 v1, 4, v0                                // 00000002DA68: 30020084
	v_bfe_u32 v2, v0, 6, 23                                    // 00000002DA6C: D6100002 025D0D00
	v_and_b32_e32 v3, 63, v0                                   // 00000002DA74: 360600BF
	v_lshl_or_b32 v5, v0, 3, 0xfffffc00                        // 00000002DA78: D6560005 03FD0700 FFFFFC00
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002DA84: BF870214
	v_and_b32_e32 v1, 0x3f0, v1                                // 00000002DA88: 360202FF 000003F0
	v_mul_u32_u24_e32 v4, 0x410, v2                            // 00000002DA90: 160804FF 00000410
	v_add_nc_u32_e32 v9, s3, v2                                // 00000002DA98: 4A120403
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002DA9C: BF870093
	.long 0xd7000006                                           // 00000002DAA0: D7000006
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000002DAA4: 02020204
	v_add_co_ci_u32_e64 v7, null, s5, 0, s0                    // 00000002DAA8: D5207C07 00010005
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002DAB0: BF870004
	v_lshl_add_u32 v8, v3, 4, v4                               // 00000002DAB4: D6460008 04110903
	s_mov_b32 s0, 0                                            // 00000002DABC: BE800080
	s_set_inst_prefetch_distance 0x1                           // 00000002DAC0: BF840001
	s_branch 29                                                // 00000002DAC4: BFA0001D <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0x23c>
	s_nop 0                                                    // 00000002DAC8: BF800000
	s_nop 0                                                    // 00000002DACC: BF800000
	s_nop 0                                                    // 00000002DAD0: BF800000
	s_nop 0                                                    // 00000002DAD4: BF800000
	s_nop 0                                                    // 00000002DAD8: BF800000
	s_nop 0                                                    // 00000002DADC: BF800000
	s_nop 0                                                    // 00000002DAE0: BF800000
	s_nop 0                                                    // 00000002DAE4: BF800000
	s_nop 0                                                    // 00000002DAE8: BF800000
	s_nop 0                                                    // 00000002DAEC: BF800000
	s_nop 0                                                    // 00000002DAF0: BF800000
	s_nop 0                                                    // 00000002DAF4: BF800000
	s_nop 0                                                    // 00000002DAF8: BF800000
	s_nop 0                                                    // 00000002DAFC: BF800000
	s_or_b32 exec_lo, exec_lo, s4                              // 00000002DB00: 8C7E047E
	v_add_nc_u32_e32 v5, 0x400, v5                             // 00000002DB04: 4A0A0AFF 00000400
	s_waitcnt vmcnt(0)                                         // 00000002DB0C: BF8903F7
	ds_store_b128 v8, v[1:4]                                   // 00000002DB10: DB7C0000 00000108
	v_add_nc_u32_e32 v8, 0x820, v8                             // 00000002DB18: 4A1010FF 00000820
	v_add_nc_u32_e32 v9, 2, v9                                 // 00000002DB20: 4A121282
	v_cmp_lt_u32_e32 vcc_lo, 0x1bff, v5                        // 00000002DB24: 7C920AFF 00001BFF
	s_or_b32 s0, vcc_lo, s0                                    // 00000002DB2C: 8C00006A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002DB30: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s0                        // 00000002DB34: 917E007E
	s_cbranch_execz 21                                         // 00000002DB38: BFA50015 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0x290>
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, 0               // 00000002DB3C: CA100080 01020080
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v4, 0               // 00000002DB44: CA100080 03040080
	s_mov_b32 s4, exec_lo                                      // 00000002DB4C: BE84007E
	.long 0xd4c4007e                                           // 00000002DB50: D4C4007E
	v_cndmask_b32_e32 v1, s14, v9, vcc_lo                      // 00000002DB54: 0202120E
	s_cbranch_execz 65513                                      // 00000002DB58: BFA5FFE9 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0x200>
	v_add_nc_u32_e32 v1, s12, v9                               // 00000002DB5C: 4A02120C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002DB60: BF870091
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000002DB64: 3404029F
	.long 0xd73c0001                                           // 00000002DB68: D73C0001
	v_cndmask_b32_e32 v1, 10, v1, vcc_lo                       // 00000002DB6C: 0202028A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002DB70: BF870091
	.long 0xd7006a01                                           // 00000002DB74: D7006A01
	v_cndmask_b32_e32 v1, v6, v1, vcc_lo                       // 00000002DB78: 02020306
	v_add_co_ci_u32_e64 v2, null, v7, v2, vcc_lo               // 00000002DB7C: D5207C02 01AA0507
	global_load_b128 v[1:4], v[1:2], off                       // 00000002DB84: DC5E0000 017C0001
	s_branch 65500                                             // 00000002DB8C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0x200>
	s_set_inst_prefetch_distance 0x2                           // 00000002DB90: BF840002
	s_or_b32 exec_lo, exec_lo, s0                              // 00000002DB94: 8C7E007E
	v_lshrrev_b32_e32 v1, 1, v0                                // 00000002DB98: 32020081
	s_waitcnt lgkmcnt(0)                                       // 00000002DB9C: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000002DBA0: BC7C0000
	s_barrier                                                  // 00000002DBA4: BFBD0000
	buffer_gl0_inv                                             // 00000002DBA8: E0AC0000 00000000
	s_mov_b32 s0, exec_lo                                      // 00000002DBB0: BE80007E
	v_and_b32_e32 v1, 48, v1                                   // 00000002DBB4: 360202B0
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002DBB8: BF870091
	v_add_nc_u32_e32 v1, s2, v1                                // 00000002DBBC: 4A020202
	.long 0xd4c4007e                                           // 00000002DBC0: D4C4007E
	v_cndmask_b32_e32 v1, s15, v1, vcc_lo                      // 00000002DBC4: 0202020F
	s_cbranch_execz 717                                        // 00000002DBC8: BFA502CD <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0xe00>
	s_mov_b32 s16, 0                                           // 00000002DBCC: BE900080
	s_add_i32 s0, s15, -1                                      // 00000002DBD0: 8100C10F
	s_mov_b32 s17, s16                                         // 00000002DBD4: BE910010
	s_mov_b32 s18, s16                                         // 00000002DBD8: BE920010
	s_mov_b32 s19, s16                                         // 00000002DBDC: BE930010
	s_mov_b32 s20, s16                                         // 00000002DBE0: BE940010
	s_mov_b32 s21, s16                                         // 00000002DBE4: BE950010
	s_mov_b32 s22, s16                                         // 00000002DBE8: BE960010
	s_mov_b32 s23, s16                                         // 00000002DBEC: BE970010
	v_and_b32_e32 v3, 15, v0                                   // 00000002DBF0: 3606008F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002DBF4: BF870001
	v_or_b32_e32 v49, v1, v3                                   // 00000002DBF8: 38620701
	v_mul_u32_u24_e32 v218, 0x410, v3                          // 00000002DBFC: 17B406FF 00000410
	ds_load_b128 v[9:12], v218                                 // 00000002DC04: DBFC0000 090000DA
	ds_load_b128 v[13:16], v218 offset:16                      // 00000002DC0C: DBFC0010 0D0000DA
	ds_load_b128 v[98:101], v218 offset:32                     // 00000002DC14: DBFC0020 620000DA
	ds_load_b128 v[102:105], v218 offset:48                    // 00000002DC1C: DBFC0030 660000DA
	ds_load_b128 v[110:113], v218 offset:80                    // 00000002DC24: DBFC0050 6E0000DA
	ds_load_b128 v[106:109], v218 offset:64                    // 00000002DC2C: DBFC0040 6A0000DA
	ds_load_b128 v[118:121], v218 offset:112                   // 00000002DC34: DBFC0070 760000DA
	ds_load_b128 v[114:117], v218 offset:96                    // 00000002DC3C: DBFC0060 720000DA
	ds_load_b128 v[126:129], v218 offset:144                   // 00000002DC44: DBFC0090 7E0000DA
	ds_load_b128 v[122:125], v218 offset:128                   // 00000002DC4C: DBFC0080 7A0000DA
	ds_load_b128 v[134:137], v218 offset:176                   // 00000002DC54: DBFC00B0 860000DA
	ds_load_b128 v[130:133], v218 offset:160                   // 00000002DC5C: DBFC00A0 820000DA
	ds_load_b128 v[142:145], v218 offset:208                   // 00000002DC64: DBFC00D0 8E0000DA
	ds_load_b128 v[150:153], v218 offset:272                   // 00000002DC6C: DBFC0110 960000DA
	ds_load_b128 v[146:149], v218 offset:256                   // 00000002DC74: DBFC0100 920000DA
	ds_load_b128 v[158:161], v218 offset:528                   // 00000002DC7C: DBFC0210 9E0000DA
	ds_load_b128 v[154:157], v218 offset:512                   // 00000002DC84: DBFC0200 9A0000DA
	ds_load_b128 v[166:169], v218 offset:784                   // 00000002DC8C: DBFC0310 A60000DA
	ds_load_b128 v[162:165], v218 offset:768                   // 00000002DC94: DBFC0300 A20000DA
	ds_load_b128 v[138:141], v218 offset:192                   // 00000002DC9C: DBFC00C0 8A0000DA
	ds_load_b128 v[174:177], v218 offset:240                   // 00000002DCA4: DBFC00F0 AE0000DA
	ds_load_b128 v[170:173], v218 offset:224                   // 00000002DCAC: DBFC00E0 AA0000DA
	ds_load_b128 v[182:185], v218 offset:304                   // 00000002DCB4: DBFC0130 B60000DA
	ds_load_b128 v[178:181], v218 offset:288                   // 00000002DCBC: DBFC0120 B20000DA
	ds_load_b128 v[190:193], v218 offset:336                   // 00000002DCC4: DBFC0150 BE0000DA
	ds_load_b128 v[186:189], v218 offset:320                   // 00000002DCCC: DBFC0140 BA0000DA
	ds_load_b128 v[198:201], v218 offset:368                   // 00000002DCD4: DBFC0170 C60000DA
	ds_load_b128 v[194:197], v218 offset:352                   // 00000002DCDC: DBFC0160 C20000DA
	ds_load_b128 v[206:209], v218 offset:560                   // 00000002DCE4: DBFC0230 CE0000DA
	ds_load_b128 v[202:205], v218 offset:544                   // 00000002DCEC: DBFC0220 CA0000DA
	ds_load_b128 v[214:217], v218 offset:816                   // 00000002DCF4: DBFC0330 D60000DA
	ds_load_b128 v[210:213], v218 offset:800                   // 00000002DCFC: DBFC0320 D20000DA
	v_min_i32_e32 v1, s0, v49                                  // 00000002DD04: 22026200
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002DD08: BF870091
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000002DD0C: 3404029F
	.long 0xd73c0001                                           // 00000002DD10: D73C0001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 00000002DD14: 02020288
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002DD18: BF870091
	.long 0xd7006a01                                           // 00000002DD1C: D7006A01
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 00000002DD20: 02020206
	v_add_co_ci_u32_e64 v2, null, s7, v2, vcc_lo               // 00000002DD24: D5207C02 01AA0407
	s_clause 0xf                                               // 00000002DD2C: BF85000F
	global_load_b128 v[54:57], v[1:2], off offset:16           // 00000002DD30: DC5E0010 367C0001
	global_load_b128 v[50:53], v[1:2], off                     // 00000002DD38: DC5E0000 327C0001
	global_load_b128 v[62:65], v[1:2], off offset:48           // 00000002DD40: DC5E0030 3E7C0001
	global_load_b128 v[58:61], v[1:2], off offset:32           // 00000002DD48: DC5E0020 3A7C0001
	global_load_b128 v[70:73], v[1:2], off offset:80           // 00000002DD50: DC5E0050 467C0001
	global_load_b128 v[66:69], v[1:2], off offset:64           // 00000002DD58: DC5E0040 427C0001
	global_load_b128 v[37:40], v[1:2], off offset:112          // 00000002DD60: DC5E0070 257C0001
	global_load_b128 v[33:36], v[1:2], off offset:96           // 00000002DD68: DC5E0060 217C0001
	global_load_b128 v[45:48], v[1:2], off offset:144          // 00000002DD70: DC5E0090 2D7C0001
	global_load_b128 v[41:44], v[1:2], off offset:128          // 00000002DD78: DC5E0080 297C0001
	global_load_b128 v[78:81], v[1:2], off offset:176          // 00000002DD80: DC5E00B0 4E7C0001
	global_load_b128 v[74:77], v[1:2], off offset:160          // 00000002DD88: DC5E00A0 4A7C0001
	global_load_b128 v[86:89], v[1:2], off offset:208          // 00000002DD90: DC5E00D0 567C0001
	global_load_b128 v[82:85], v[1:2], off offset:192          // 00000002DD98: DC5E00C0 527C0001
	global_load_b128 v[94:97], v[1:2], off offset:240          // 00000002DDA0: DC5E00F0 5E7C0001
	global_load_b128 v[90:93], v[1:2], off offset:224          // 00000002DDA8: DC5E00E0 5A7C0001
	v_dual_mov_b32 v1, s16 :: v_dual_mov_b32 v4, s19           // 00000002DDB0: CA100010 01040013
	v_dual_mov_b32 v2, s17 :: v_dual_mov_b32 v3, s18           // 00000002DDB8: CA100011 02020012
	v_dual_mov_b32 v6, s21 :: v_dual_mov_b32 v5, s20           // 00000002DDC0: CA100015 06040014
	v_dual_mov_b32 v8, s23 :: v_dual_mov_b32 v7, s22           // 00000002DDC8: CA100017 08060016
	v_cmp_gt_i32_e32 vcc_lo, s15, v49                          // 00000002DDD0: 7C88620F
	s_waitcnt vmcnt(14) lgkmcnt(30)                            // 00000002DDD4: BF8939E7
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002DDD8: BF870002
	v_wmma_f32_16x16x16_bf16 v[25:32], v[9:16], v[50:57], v[1:8]// 00000002DDDC: CC414019 1C066509
	s_waitcnt lgkmcnt(17)                                      // 00000002DDE4: BF89FD17
	v_wmma_f32_16x16x16_bf16 v[17:24], v[146:153], v[50:57], v[1:8]// 00000002DDE8: CC414011 1C066592
	s_waitcnt lgkmcnt(15)                                      // 00000002DDF0: BF89FCF7
	v_wmma_f32_16x16x16_bf16 v[9:16], v[154:161], v[50:57], v[1:8]// 00000002DDF4: CC414009 1C06659A
	s_waitcnt lgkmcnt(13)                                      // 00000002DDFC: BF89FCD7
	v_wmma_f32_16x16x16_bf16 v[1:8], v[162:169], v[50:57], v[1:8]// 00000002DE00: CC414001 1C0665A2
	ds_load_b128 v[54:57], v218 offset:400                     // 00000002DE08: DBFC0190 360000DA
	ds_load_b128 v[50:53], v218 offset:384                     // 00000002DE10: DBFC0180 320000DA
	ds_load_b128 v[150:153], v218 offset:592                   // 00000002DE18: DBFC0250 960000DA
	ds_load_b128 v[146:149], v218 offset:576                   // 00000002DE20: DBFC0240 920000DA
	s_waitcnt vmcnt(12)                                        // 00000002DE28: BF8933F7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[98:105], v[58:65], v[25:32]// 00000002DE2C: CC414019 1C667562
	ds_load_b128 v[102:105], v218 offset:848                   // 00000002DE34: DBFC0350 660000DA
	ds_load_b128 v[98:101], v218 offset:832                    // 00000002DE3C: DBFC0340 620000DA
	s_waitcnt lgkmcnt(14)                                      // 00000002DE44: BF89FCE7
	v_wmma_f32_16x16x16_bf16 v[17:24], v[178:185], v[58:65], v[17:24]// 00000002DE48: CC414011 1C4675B2
	s_waitcnt lgkmcnt(8)                                       // 00000002DE50: BF89FC87
	v_wmma_f32_16x16x16_bf16 v[9:16], v[202:209], v[58:65], v[9:16]// 00000002DE54: CC414009 1C2675CA
	s_waitcnt lgkmcnt(6)                                       // 00000002DE5C: BF89FC67
	v_wmma_f32_16x16x16_bf16 v[1:8], v[210:217], v[58:65], v[1:8]// 00000002DE60: CC414001 1C0675D2
	ds_load_b128 v[62:65], v218 offset:496                     // 00000002DE68: DBFC01F0 3E0000DA
	ds_load_b128 v[58:61], v218 offset:480                     // 00000002DE70: DBFC01E0 3A0000DA
	ds_load_b128 v[182:185], v218 offset:624                   // 00000002DE78: DBFC0270 B60000DA
	ds_load_b128 v[178:181], v218 offset:608                   // 00000002DE80: DBFC0260 B20000DA
	s_waitcnt vmcnt(10)                                        // 00000002DE88: BF892BF7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[106:113], v[66:73], v[25:32]// 00000002DE8C: CC414019 1C66856A
	ds_load_b128 v[110:113], v218 offset:880                   // 00000002DE94: DBFC0370 6E0000DA
	ds_load_b128 v[106:109], v218 offset:864                   // 00000002DE9C: DBFC0360 6A0000DA
	v_wmma_f32_16x16x16_bf16 v[17:24], v[186:193], v[66:73], v[17:24]// 00000002DEA4: CC414011 1C4685BA
	ds_load_b128 v[190:193], v218 offset:656                   // 00000002DEAC: DBFC0290 BE0000DA
	ds_load_b128 v[186:189], v218 offset:640                   // 00000002DEB4: DBFC0280 BA0000DA
	ds_load_b128 v[158:161], v218 offset:432                   // 00000002DEBC: DBFC01B0 9E0000DA
	ds_load_b128 v[154:157], v218 offset:416                   // 00000002DEC4: DBFC01A0 9A0000DA
	s_waitcnt vmcnt(8)                                         // 00000002DECC: BF8923F7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[114:121], v[33:40], v[25:32]// 00000002DED0: CC414019 1C664372
	ds_load_b128 v[166:169], v218 offset:464                   // 00000002DED8: DBFC01D0 A60000DA
	ds_load_b128 v[162:165], v218 offset:448                   // 00000002DEE0: DBFC01C0 A20000DA
	v_wmma_f32_16x16x16_bf16 v[17:24], v[194:201], v[33:40], v[17:24]// 00000002DEE8: CC414011 1C4643C2
	ds_load_b128 v[198:201], v218 offset:976                   // 00000002DEF0: DBFC03D0 C60000DA
	ds_load_b128 v[194:197], v218 offset:960                   // 00000002DEF8: DBFC03C0 C20000DA
	s_waitcnt vmcnt(6)                                         // 00000002DF00: BF891BF7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[122:129], v[41:48], v[25:32]// 00000002DF04: CC414019 1C66537A
	s_waitcnt lgkmcnt(18)                                      // 00000002DF0C: BF89FD27
	v_wmma_f32_16x16x16_bf16 v[17:24], v[50:57], v[41:48], v[17:24]// 00000002DF10: CC414011 1C465332
	s_waitcnt lgkmcnt(16)                                      // 00000002DF18: BF89FD07
	v_wmma_f32_16x16x16_bf16 v[9:16], v[146:153], v[66:73], v[9:16]// 00000002DF1C: CC414009 1C268592
	ds_load_b128 v[150:153], v218 offset:688                   // 00000002DF24: DBFC02B0 960000DA
	s_waitcnt lgkmcnt(15)                                      // 00000002DF2C: BF89FCF7
	v_wmma_f32_16x16x16_bf16 v[1:8], v[98:105], v[66:73], v[1:8]// 00000002DF30: CC414001 1C068562
	ds_load_b128 v[70:73], v218 offset:912                     // 00000002DF38: DBFC0390 460000DA
	ds_load_b128 v[66:69], v218 offset:896                     // 00000002DF40: DBFC0380 420000DA
	ds_load_b128 v[146:149], v218 offset:672                   // 00000002DF48: DBFC02A0 920000DA
	ds_load_b128 v[102:105], v218 offset:720                   // 00000002DF50: DBFC02D0 660000DA
	ds_load_b128 v[118:121], v218 offset:944                   // 00000002DF58: DBFC03B0 760000DA
	ds_load_b128 v[114:117], v218 offset:928                   // 00000002DF60: DBFC03A0 720000DA
	ds_load_b128 v[98:101], v218 offset:704                    // 00000002DF68: DBFC02C0 620000DA
	s_waitcnt vmcnt(4)                                         // 00000002DF70: BF8913F7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[130:137], v[74:81], v[25:32]// 00000002DF74: CC414019 1C669582
	s_waitcnt lgkmcnt(18)                                      // 00000002DF7C: BF89FD27
	v_wmma_f32_16x16x16_bf16 v[9:16], v[178:185], v[33:40], v[9:16]// 00000002DF80: CC414009 1C2643B2
	ds_load_b128 v[182:185], v218 offset:752                   // 00000002DF88: DBFC02F0 B60000DA
	ds_load_b128 v[178:181], v218 offset:736                   // 00000002DF90: DBFC02E0 B20000DA
	s_waitcnt lgkmcnt(18)                                      // 00000002DF98: BF89FD27
	v_wmma_f32_16x16x16_bf16 v[1:8], v[106:113], v[33:40], v[1:8]// 00000002DF9C: CC414001 1C06436A
	ds_load_b128 v[37:40], v218 offset:1008                    // 00000002DFA4: DBFC03F0 250000DA
	ds_load_b128 v[33:36], v218 offset:992                     // 00000002DFAC: DBFC03E0 210000DA
	s_waitcnt vmcnt(2)                                         // 00000002DFB4: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[138:145], v[82:89], v[25:32]// 00000002DFB8: CC414019 1C66A58A
	s_waitcnt lgkmcnt(18)                                      // 00000002DFC0: BF89FD27
	v_wmma_f32_16x16x16_bf16 v[9:16], v[186:193], v[41:48], v[9:16]// 00000002DFC4: CC414009 1C2653BA
	s_waitcnt lgkmcnt(16)                                      // 00000002DFCC: BF89FD07
	v_wmma_f32_16x16x16_bf16 v[17:24], v[154:161], v[74:81], v[17:24]// 00000002DFD0: CC414011 1C46959A
	s_waitcnt vmcnt(0)                                         // 00000002DFD8: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[170:177], v[90:97], v[25:32]// 00000002DFDC: CC414019 1C66B5AA
	s_waitcnt lgkmcnt(14)                                      // 00000002DFE4: BF89FCE7
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002DFE8: BF870002
	v_wmma_f32_16x16x16_bf16 v[17:24], v[162:169], v[82:89], v[17:24]// 00000002DFEC: CC414011 1C46A5A2
	s_waitcnt lgkmcnt(9)                                       // 00000002DFF4: BF89FC97
	v_wmma_f32_16x16x16_bf16 v[1:8], v[66:73], v[41:48], v[1:8]// 00000002DFF8: CC414001 1C065342
	s_waitcnt lgkmcnt(8)                                       // 00000002E000: BF89FC87
	v_wmma_f32_16x16x16_bf16 v[9:16], v[146:153], v[74:81], v[9:16]// 00000002E004: CC414009 1C269592
	v_wmma_f32_16x16x16_bf16 v[17:24], v[58:65], v[90:97], v[17:24]// 00000002E00C: CC414011 1C46B53A
	s_waitcnt lgkmcnt(5)                                       // 00000002E014: BF89FC57
	v_wmma_f32_16x16x16_bf16 v[1:8], v[114:121], v[74:81], v[1:8]// 00000002E018: CC414001 1C069572
	s_waitcnt lgkmcnt(4)                                       // 00000002E020: BF89FC47
	v_wmma_f32_16x16x16_bf16 v[9:16], v[98:105], v[82:89], v[9:16]// 00000002E024: CC414009 1C26A562
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002E02C: BF870122
	v_wmma_f32_16x16x16_bf16 v[1:8], v[194:201], v[82:89], v[1:8]// 00000002E030: CC414001 1C06A5C2
	s_waitcnt lgkmcnt(2)                                       // 00000002E038: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[9:16], v[178:185], v[90:97], v[9:16]// 00000002E03C: CC414009 1C26B5B2
	s_waitcnt lgkmcnt(0)                                       // 00000002E044: BF89FC07
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002E048: BF870002
	v_wmma_f32_16x16x16_bf16 v[1:8], v[33:40], v[90:97], v[1:8]// 00000002E04C: CC414001 1C06B521
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 00000002E054: 8B7E6A7E
	s_cbranch_execz 425                                        // 00000002E058: BFA501A9 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0xe00>
	v_ashrrev_i32_e32 v50, 31, v49                             // 00000002E05C: 3464629F
	v_lshrrev_b32_e32 v0, 4, v0                                // 00000002E060: 32000084
	v_rsq_f32_e32 v34, 0x43000000                              // 00000002E064: 7E445CFF 43000000
	s_add_i32 s1, s1, 1                                        // 00000002E06C: 81018101
	s_mov_b32 s0, exec_lo                                      // 00000002E070: BE80007E
	.long 0xd73c0024                                           // 00000002E074: D73C0024
	v_cndmask_b32_e32 v1, 2, v49, vcc_lo                       // 00000002E078: 02026282
	v_and_or_b32 v35, v0, 1, s3                                // 00000002E07C: D6570023 000D0300
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E084: BF870092
	.long 0xd7006a00                                           // 00000002E088: D7006A00
	v_cndmask_b32_e32 v1, s8, v36, vcc_lo                      // 00000002E08C: 02024808
	v_add_co_ci_u32_e64 v33, null, s9, v37, vcc_lo             // 00000002E090: D5207C21 01AA4A09
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002E098: BF870003
	.long 0xd4c4007e                                           // 00000002E09C: D4C4007E
	v_cndmask_b32_e32 v1, s14, v35, vcc_lo                     // 00000002E0A0: 0202460E
	s_cbranch_execz 44                                         // 00000002E0A4: BFA5002C <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0x858>
	v_dual_max_f32 v25, v25, v25 :: v_dual_add_nc_u32 v38, s1, v35// 00000002E0A8: CAA03319 19264601
	v_max_f32_e32 v17, v17, v17                                // 00000002E0B0: 20222311
	v_max_f32_e32 v9, v9, v9                                   // 00000002E0B4: 20121309
	v_ashrrev_i32_e32 v39, 31, v35                             // 00000002E0B8: 344E469F
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002E0BC: BF870004
	v_max_f32_e32 v25, 0, v25                                  // 00000002E0C0: 20323280
	v_ashrrev_i32_e32 v41, 31, v38                             // 00000002E0C4: 34524C9F
	v_max_f32_e32 v17, 0, v17                                  // 00000002E0C8: 20222280
	v_max_f32_e32 v1, v1, v1                                   // 00000002E0CC: 20020301
	v_max_f32_e32 v9, 0, v9                                    // 00000002E0D0: 20121280
	v_add_f32_e32 v25, 0, v25                                  // 00000002E0D4: 06323280
	.long 0xd72c0028                                           // 00000002E0D8: D72C0028
	v_cndmask_b32_e32 v1, s11, v35, vcc_lo                     // 00000002E0DC: 0202460B
	v_mad_u64_u32 v[36:37], null, s10, v35, 0                  // 00000002E0E0: D6FE7C24 0202460A
	v_max_f32_e32 v1, 0, v1                                    // 00000002E0E8: 20020280
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002E0EC: BF8701B4
	v_add_f32_e32 v17, v25, v17                                // 00000002E0F0: 06222319
	.long 0xd72c0019                                           // 00000002E0F4: D72C0019
	v_cndmask_b32_e32 v1, s10, v39, vcc_lo                     // 00000002E0F8: 02024E0A
	v_lshrrev_b32_e32 v39, 30, v41                             // 00000002E0FC: 324E529E
	v_add_f32_e32 v9, v17, v9                                  // 00000002E100: 06121311
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E104: BF870212
	v_add_nc_u32_e32 v17, v38, v39                             // 00000002E108: 4A224F26
	v_add3_u32 v37, v37, v25, v40                              // 00000002E10C: D6550025 04A23325
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E114: BF870193
	v_add_f32_e32 v1, v9, v1                                   // 00000002E118: 06020309
	v_ashrrev_i32_e32 v9, 2, v17                               // 00000002E11C: 34122282
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E120: BF870193
	.long 0xd73c0024                                           // 00000002E124: D73C0024
	v_cndmask_b32_e32 v1, 2, v36, vcc_lo                       // 00000002E128: 02024882
	v_mul_f32_e32 v1, v34, v1                                  // 00000002E12C: 10020322
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E130: BF870113
	v_cmp_lt_i32_e32 vcc_lo, v49, v9                           // 00000002E134: 7C821331
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000002E138: 02020280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E13C: BF870094
	.long 0xd7006a24                                           // 00000002E140: D7006A24
	v_cndmask_b32_e32 v1, v0, v36, vcc_lo                      // 00000002E144: 02024900
	v_add_co_ci_u32_e64 v37, null, v33, v37, vcc_lo            // 00000002E148: D5207C25 01AA4B21
	global_store_b32 v[36:37], v1, off                         // 00000002E150: DC6A0000 007C0124
	s_or_b32 exec_lo, exec_lo, s0                              // 00000002E158: 8C7E007E
	v_or_b32_e32 v1, 2, v35                                    // 00000002E15C: 38024682
	s_mov_b32 s0, exec_lo                                      // 00000002E160: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002E164: BF870001
	.long 0xd4c4007e                                           // 00000002E168: D4C4007E
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000002E16C: 0202020E
	s_cbranch_execz 46                                         // 00000002E170: BFA5002E <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0x92c>
	v_dual_max_f32 v10, v10, v10 :: v_dual_add_nc_u32 v25, s1, v1// 00000002E174: CAA0150A 0A180201
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E17C: BF870111
	v_ashrrev_i32_e32 v36, 31, v25                             // 00000002E180: 3448329F
	v_max_f32_e32 v10, 0, v10                                  // 00000002E184: 20141480
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000002E188: BF870252
	v_lshrrev_b32_e32 v36, 30, v36                             // 00000002E18C: 3248489E
	v_max_f32_e32 v17, v18, v18                                // 00000002E190: 20222512
	v_max_f32_e32 v9, v26, v26                                 // 00000002E194: 2012351A
	v_max_f32_e32 v18, v2, v2                                  // 00000002E198: 20240502
	.long 0xd72c001a                                           // 00000002E19C: D72C001A
	v_cndmask_b32_e32 v1, s11, v1, vcc_lo                      // 00000002E1A0: 0202020B
	v_max_f32_e32 v2, 0, v17                                   // 00000002E1A4: 20042280
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002E1A8: BF870124
	v_max_f32_e32 v9, 0, v9                                    // 00000002E1AC: 20121280
	v_ashrrev_i32_e32 v17, 31, v1                              // 00000002E1B0: 3422029F
	v_add_f32_e32 v9, 0, v9                                    // 00000002E1B4: 06121280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002E1B8: BF8701A2
	.long 0xd72c0011                                           // 00000002E1BC: D72C0011
	v_cndmask_b32_e32 v1, s10, v17, vcc_lo                     // 00000002E1C0: 0202220A
	v_max_f32_e32 v18, 0, v18                                  // 00000002E1C4: 20242480
	v_add_f32_e32 v9, v9, v2                                   // 00000002E1C8: 06120509
	v_mad_u64_u32 v[1:2], null, s10, v1, 0                     // 00000002E1CC: D6FE7C01 0202020A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002E1D4: BF8701A2
	v_add_f32_e32 v9, v9, v10                                  // 00000002E1D8: 06121509
	v_add_nc_u32_e32 v10, v25, v36                             // 00000002E1DC: 4A144919
	v_add3_u32 v2, v2, v17, v26                                // 00000002E1E0: D6550002 046A2302
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E1E8: BF870193
	v_add_f32_e32 v9, v9, v18                                  // 00000002E1EC: 06122509
	v_ashrrev_i32_e32 v10, 2, v10                              // 00000002E1F0: 34141482
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E1F4: BF870193
	.long 0xd73c0001                                           // 00000002E1F8: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000002E1FC: 02020282
	v_mul_f32_e32 v9, v34, v9                                  // 00000002E200: 10121322
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E204: BF870113
	v_cmp_lt_i32_e32 vcc_lo, v49, v10                          // 00000002E208: 7C821531
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000002E20C: 02121280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E210: BF870094
	.long 0xd7006a01                                           // 00000002E214: D7006A01
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000002E218: 02020300
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000002E21C: D5207C02 01AA0521
	global_store_b32 v[1:2], v9, off                           // 00000002E224: DC6A0000 007C0901
	s_or_b32 exec_lo, exec_lo, s0                              // 00000002E22C: 8C7E007E
	v_or_b32_e32 v1, 4, v35                                    // 00000002E230: 38024684
	s_mov_b32 s0, exec_lo                                      // 00000002E234: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002E238: BF870001
	.long 0xd4c4007e                                           // 00000002E23C: D4C4007E
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000002E240: 0202020E
	s_cbranch_execz 44                                         // 00000002E244: BFA5002C <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0x9f8>
	v_max_f32_e32 v2, v27, v27                                 // 00000002E248: 2004371B
	v_dual_max_f32 v10, v11, v11 :: v_dual_add_nc_u32 v11, s1, v1// 00000002E24C: CAA0170B 0A0A0201
	v_max_f32_e32 v9, v19, v19                                 // 00000002E254: 20122713
	v_ashrrev_i32_e32 v17, 31, v1                              // 00000002E258: 3422029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E25C: BF870214
	v_dual_max_f32 v2, 0, v2 :: v_dual_max_f32 v3, v3, v3      // 00000002E260: CA940480 02020703
	v_ashrrev_i32_e32 v19, 31, v11                             // 00000002E268: 3426169F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002E26C: BF870224
	v_max_f32_e32 v9, 0, v9                                    // 00000002E270: 20121280
	.long 0xd72c0012                                           // 00000002E274: D72C0012
	v_cndmask_b32_e32 v1, s11, v1, vcc_lo                      // 00000002E278: 0202020B
	v_add_f32_e32 v2, 0, v2                                    // 00000002E27C: 06040480
	v_max_f32_e32 v10, 0, v10                                  // 00000002E280: 20141480
	v_lshrrev_b32_e32 v19, 30, v19                             // 00000002E284: 3226269E
	.long 0xd72c0011                                           // 00000002E288: D72C0011
	v_cndmask_b32_e32 v1, s10, v17, vcc_lo                     // 00000002E28C: 0202220A
	v_max_f32_e32 v3, 0, v3                                    // 00000002E290: 20060680
	v_add_f32_e32 v9, v2, v9                                   // 00000002E294: 06121302
	v_mad_u64_u32 v[1:2], null, s10, v1, 0                     // 00000002E298: D6FE7C01 0202020A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E2A0: BF870112
	v_dual_add_f32 v9, v9, v10 :: v_dual_add_nc_u32 v10, v11, v19// 00000002E2A4: C9201509 090A270B
	v_add3_u32 v2, v2, v17, v18                                // 00000002E2AC: D6550002 044A2302
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E2B4: BF870192
	v_add_f32_e32 v3, v9, v3                                   // 00000002E2B8: 06060709
	v_ashrrev_i32_e32 v9, 2, v10                               // 00000002E2BC: 34121482
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E2C0: BF870193
	.long 0xd73c0001                                           // 00000002E2C4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000002E2C8: 02020282
	v_mul_f32_e32 v3, v34, v3                                  // 00000002E2CC: 10060722
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E2D0: BF870113
	v_cmp_lt_i32_e32 vcc_lo, v49, v9                           // 00000002E2D4: 7C821331
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 00000002E2D8: 02060680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E2DC: BF870094
	.long 0xd7006a01                                           // 00000002E2E0: D7006A01
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000002E2E4: 02020300
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000002E2E8: D5207C02 01AA0521
	global_store_b32 v[1:2], v3, off                           // 00000002E2F0: DC6A0000 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 00000002E2F8: 8C7E007E
	v_or_b32_e32 v1, 6, v35                                    // 00000002E2FC: 38024686
	s_mov_b32 s0, exec_lo                                      // 00000002E300: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002E304: BF870001
	.long 0xd4c4007e                                           // 00000002E308: D4C4007E
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000002E30C: 0202020E
	s_cbranch_execz 45                                         // 00000002E310: BFA5002D <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0xac8>
	v_max_f32_e32 v3, v20, v20                                 // 00000002E314: 20062914
	v_max_f32_e32 v2, v28, v28                                 // 00000002E318: 2004391C
	v_dual_max_f32 v9, v12, v12 :: v_dual_add_nc_u32 v10, s1, v1// 00000002E31C: CAA0190C 090A0201
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E324: BF870113
	v_dual_max_f32 v4, v4, v4 :: v_dual_max_f32 v3, 0, v3      // 00000002E328: CA940904 04020680
	v_dual_max_f32 v2, 0, v2 :: v_dual_max_f32 v9, 0, v9       // 00000002E330: CA940480 02081280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000002E338: BF870233
	v_ashrrev_i32_e32 v17, 31, v10                             // 00000002E33C: 3422149F
	v_ashrrev_i32_e32 v11, 31, v1                              // 00000002E340: 3416029F
	.long 0xd72c000c                                           // 00000002E344: D72C000C
	v_cndmask_b32_e32 v1, s11, v1, vcc_lo                      // 00000002E348: 0202020B
	v_add_f32_e32 v2, 0, v2                                    // 00000002E34C: 06040480
	v_max_f32_e32 v4, 0, v4                                    // 00000002E350: 20080880
	v_lshrrev_b32_e32 v17, 30, v17                             // 00000002E354: 3222229E
	.long 0xd72c000b                                           // 00000002E358: D72C000B
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 00000002E35C: 0202160A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002E360: BF870124
	v_add_f32_e32 v3, v2, v3                                   // 00000002E364: 06060702
	v_mad_u64_u32 v[1:2], null, s10, v1, 0                     // 00000002E368: D6FE7C01 0202020A
	v_add_f32_e32 v3, v3, v9                                   // 00000002E370: 06061303
	v_add_nc_u32_e32 v9, v10, v17                              // 00000002E374: 4A12230A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E378: BF870193
	v_add3_u32 v2, v2, v11, v12                                // 00000002E37C: D6550002 04321702
	v_add_f32_e32 v3, v3, v4                                   // 00000002E384: 06060903
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E388: BF870193
	v_ashrrev_i32_e32 v4, 2, v9                                // 00000002E38C: 34081282
	.long 0xd73c0001                                           // 00000002E390: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000002E394: 02020282
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E398: BF870193
	v_mul_f32_e32 v3, v34, v3                                  // 00000002E39C: 10060722
	v_cmp_lt_i32_e32 vcc_lo, v49, v4                           // 00000002E3A0: 7C820931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E3A4: BF870212
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 00000002E3A8: 02060680
	.long 0xd7006a01                                           // 00000002E3AC: D7006A01
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000002E3B0: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002E3B4: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000002E3B8: D5207C02 01AA0521
	global_store_b32 v[1:2], v3, off                           // 00000002E3C0: DC6A0000 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 00000002E3C8: 8C7E007E
	v_or_b32_e32 v1, 8, v35                                    // 00000002E3CC: 38024688
	s_mov_b32 s0, exec_lo                                      // 00000002E3D0: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002E3D4: BF870001
	.long 0xd4c4007e                                           // 00000002E3D8: D4C4007E
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000002E3DC: 0202020E
	s_cbranch_execz 45                                         // 00000002E3E0: BFA5002D <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0xb98>
	v_max_f32_e32 v3, v21, v21                                 // 00000002E3E4: 20062B15
	v_max_f32_e32 v2, v29, v29                                 // 00000002E3E8: 20043B1D
	v_ashrrev_i32_e32 v10, 31, v1                              // 00000002E3EC: 3414029F
	.long 0xd72c000b                                           // 00000002E3F0: D72C000B
	v_cndmask_b32_e32 v1, s11, v1, vcc_lo                      // 00000002E3F4: 0202020B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002E3F8: BF870223
	v_dual_max_f32 v3, 0, v3 :: v_dual_max_f32 v2, 0, v2       // 00000002E3FC: CA940680 03020480
	v_max_f32_e32 v5, v5, v5                                   // 00000002E404: 200A0B05
	.long 0xd72c000a                                           // 00000002E408: D72C000A
	v_cndmask_b32_e32 v1, s10, v10, vcc_lo                     // 00000002E40C: 0202140A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E410: BF870093
	v_add_f32_e32 v2, 0, v2                                    // 00000002E414: 06040480
	v_dual_max_f32 v4, v13, v13 :: v_dual_add_f32 v3, v2, v3   // 00000002E418: CA881B0D 04020702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002E420: BF870121
	v_dual_max_f32 v4, 0, v4 :: v_dual_add_nc_u32 v9, s1, v1   // 00000002E424: CAA00880 04080201
	v_mad_u64_u32 v[1:2], null, s10, v1, 0                     // 00000002E42C: D6FE7C01 0202020A
	v_ashrrev_i32_e32 v12, 31, v9                              // 00000002E434: 3418129F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E438: BF870193
	v_add_f32_e32 v3, v3, v4                                   // 00000002E43C: 06060903
	v_add3_u32 v2, v2, v10, v11                                // 00000002E440: D6550002 042E1502
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002E448: BF8701A3
	v_lshrrev_b32_e32 v12, 30, v12                             // 00000002E44C: 3218189E
	v_max_f32_e32 v5, 0, v5                                    // 00000002E450: 200A0A80
	.long 0xd73c0001                                           // 00000002E454: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000002E458: 02020282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E45C: BF870092
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_nc_u32 v4, v9, v12 // 00000002E460: C9200B03 03041909
	v_ashrrev_i32_e32 v4, 2, v4                                // 00000002E468: 34080882
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E46C: BF870112
	v_mul_f32_e32 v3, v34, v3                                  // 00000002E470: 10060722
	v_cmp_lt_i32_e32 vcc_lo, v49, v4                           // 00000002E474: 7C820931
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002E478: BF8700A2
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 00000002E47C: 02060680
	.long 0xd7006a01                                           // 00000002E480: D7006A01
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000002E484: 02020300
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000002E488: D5207C02 01AA0521
	global_store_b32 v[1:2], v3, off                           // 00000002E490: DC6A0000 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 00000002E498: 8C7E007E
	v_or_b32_e32 v1, 10, v35                                   // 00000002E49C: 3802468A
	s_mov_b32 s0, exec_lo                                      // 00000002E4A0: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002E4A4: BF870001
	.long 0xd4c4007e                                           // 00000002E4A8: D4C4007E
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000002E4AC: 0202020E
	s_cbranch_execz 45                                         // 00000002E4B0: BFA5002D <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0xc68>
	v_max_f32_e32 v3, v22, v22                                 // 00000002E4B4: 20062D16
	v_dual_max_f32 v5, v6, v6 :: v_dual_add_nc_u32 v6, s1, v1  // 00000002E4B8: CAA00D06 05060201
	v_max_f32_e32 v2, v30, v30                                 // 00000002E4C0: 20043D1E
	v_ashrrev_i32_e32 v9, 31, v1                               // 00000002E4C4: 3412029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E4C8: BF870214
	v_max_f32_e32 v3, 0, v3                                    // 00000002E4CC: 20060680
	v_dual_max_f32 v5, 0, v5 :: v_dual_max_f32 v4, v14, v14    // 00000002E4D0: CA940A80 05041D0E
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002E4D8: BF870004
	v_max_f32_e32 v2, 0, v2                                    // 00000002E4DC: 20040480
	v_ashrrev_i32_e32 v11, 31, v6                              // 00000002E4E0: 34160C9F
	.long 0xd72c000a                                           // 00000002E4E4: D72C000A
	v_cndmask_b32_e32 v1, s11, v1, vcc_lo                      // 00000002E4E8: 0202020B
	.long 0xd72c0009                                           // 00000002E4EC: D72C0009
	v_cndmask_b32_e32 v1, s10, v9, vcc_lo                      // 00000002E4F0: 0202120A
	v_max_f32_e32 v4, 0, v4                                    // 00000002E4F4: 20080880
	v_add_f32_e32 v2, 0, v2                                    // 00000002E4F8: 06040480
	v_lshrrev_b32_e32 v11, 30, v11                             // 00000002E4FC: 3216169E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002E500: BF870122
	v_add_f32_e32 v3, v2, v3                                   // 00000002E504: 06060702
	v_mad_u64_u32 v[1:2], null, s10, v1, 0                     // 00000002E508: D6FE7C01 0202020A
	v_dual_add_f32 v3, v3, v4 :: v_dual_add_nc_u32 v4, v6, v11 // 00000002E510: C9200903 03041706
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E518: BF870112
	v_add3_u32 v2, v2, v9, v10                                 // 00000002E51C: D6550002 042A1302
	v_add_f32_e32 v3, v3, v5                                   // 00000002E524: 06060B03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E528: BF870193
	v_ashrrev_i32_e32 v4, 2, v4                                // 00000002E52C: 34080882
	.long 0xd73c0001                                           // 00000002E530: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000002E534: 02020282
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E538: BF870193
	v_mul_f32_e32 v3, v34, v3                                  // 00000002E53C: 10060722
	v_cmp_lt_i32_e32 vcc_lo, v49, v4                           // 00000002E540: 7C820931
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E544: BF870212
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 00000002E548: 02060680
	.long 0xd7006a01                                           // 00000002E54C: D7006A01
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000002E550: 02020300
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002E554: BF870001
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000002E558: D5207C02 01AA0521
	global_store_b32 v[1:2], v3, off                           // 00000002E560: DC6A0000 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 00000002E568: 8C7E007E
	v_or_b32_e32 v1, 12, v35                                   // 00000002E56C: 3802468C
	s_mov_b32 s0, exec_lo                                      // 00000002E570: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002E574: BF870001
	.long 0xd4c4007e                                           // 00000002E578: D4C4007E
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000002E57C: 0202020E
	s_cbranch_execz 44                                         // 00000002E580: BFA5002C <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0xd34>
	v_dual_max_f32 v5, v7, v7 :: v_dual_add_nc_u32 v6, s1, v1  // 00000002E584: CAA00F07 05060201
	v_max_f32_e32 v2, v31, v31                                 // 00000002E58C: 20043F1F
	v_max_f32_e32 v4, v15, v15                                 // 00000002E590: 20081F0F
	v_ashrrev_i32_e32 v7, 31, v1                               // 00000002E594: 340E029F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E598: BF870214
	v_max_f32_e32 v5, 0, v5                                    // 00000002E59C: 200A0A80
	v_dual_max_f32 v3, v23, v23 :: v_dual_max_f32 v2, 0, v2    // 00000002E5A0: CA942F17 03020480
	v_ashrrev_i32_e32 v10, 31, v6                              // 00000002E5A8: 34140C9F
	.long 0xd72c0009                                           // 00000002E5AC: D72C0009
	v_cndmask_b32_e32 v1, s11, v1, vcc_lo                      // 00000002E5B0: 0202020B
	.long 0xd72c0007                                           // 00000002E5B4: D72C0007
	v_cndmask_b32_e32 v1, s10, v7, vcc_lo                      // 00000002E5B8: 02020E0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002E5BC: BF8701B4
	v_dual_max_f32 v3, 0, v3 :: v_dual_add_f32 v2, 0, v2       // 00000002E5C0: CA880680 03020480
	v_max_f32_e32 v4, 0, v4                                    // 00000002E5C8: 20080880
	v_lshrrev_b32_e32 v10, 30, v10                             // 00000002E5CC: 3214149E
	v_add_f32_e32 v3, v2, v3                                   // 00000002E5D0: 06060702
	v_mad_u64_u32 v[1:2], null, s10, v1, 0                     // 00000002E5D4: D6FE7C01 0202020A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E5DC: BF870112
	v_dual_add_f32 v3, v3, v4 :: v_dual_add_nc_u32 v4, v6, v10 // 00000002E5E0: C9200903 03041506
	v_add3_u32 v2, v2, v7, v9                                  // 00000002E5E8: D6550002 04260F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E5F0: BF870192
	v_add_f32_e32 v3, v3, v5                                   // 00000002E5F4: 06060B03
	v_ashrrev_i32_e32 v4, 2, v4                                // 00000002E5F8: 34080882
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E5FC: BF870193
	.long 0xd73c0001                                           // 00000002E600: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000002E604: 02020282
	v_mul_f32_e32 v3, v34, v3                                  // 00000002E608: 10060722
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E60C: BF870113
	v_cmp_lt_i32_e32 vcc_lo, v49, v4                           // 00000002E610: 7C820931
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 00000002E614: 02060680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E618: BF870094
	.long 0xd7006a01                                           // 00000002E61C: D7006A01
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000002E620: 02020300
	v_add_co_ci_u32_e64 v2, null, v33, v2, vcc_lo              // 00000002E624: D5207C02 01AA0521
	global_store_b32 v[1:2], v3, off                           // 00000002E62C: DC6A0000 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 00000002E634: 8C7E007E
	v_or_b32_e32 v1, 14, v35                                   // 00000002E638: 3802468E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002E63C: BF870001
	v_cmp_gt_i32_e32 vcc_lo, s14, v1                           // 00000002E640: 7C88020E
	s_and_b32 exec_lo, exec_lo, vcc_lo                         // 00000002E644: 8B7E6A7E
	s_cbranch_execz 45                                         // 00000002E648: BFA5002D <_ZN7halogen12_GLOBAL__N_116k_ix_scores_wmmaEPKtS2_Pfliiii+0xe00>
	v_max_f32_e32 v3, v24, v24                                 // 00000002E64C: 20063118
	v_max_f32_e32 v2, v32, v32                                 // 00000002E650: 20044120
	v_dual_max_f32 v5, v8, v8 :: v_dual_add_nc_u32 v6, s1, v1  // 00000002E654: CAA01108 05060201
	v_ashrrev_i32_e32 v7, 31, v1                               // 00000002E65C: 340E029F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002E660: BF870223
	v_dual_max_f32 v3, 0, v3 :: v_dual_max_f32 v2, 0, v2       // 00000002E664: CA940680 03020480
	.long 0xd72c0008                                           // 00000002E66C: D72C0008
	v_cndmask_b32_e32 v1, s11, v1, vcc_lo                      // 00000002E670: 0202020B
	v_ashrrev_i32_e32 v9, 31, v6                               // 00000002E674: 34120C9F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002E678: BF870214
	.long 0xd72c0007                                           // 00000002E67C: D72C0007
	v_cndmask_b32_e32 v1, s10, v7, vcc_lo                      // 00000002E680: 02020E0A
	v_dual_max_f32 v5, 0, v5 :: v_dual_add_f32 v2, 0, v2       // 00000002E684: CA880A80 05020480
	v_max_f32_e32 v4, v16, v16                                 // 00000002E68C: 20082110
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E690: BF870114
	v_lshrrev_b32_e32 v9, 30, v9                               // 00000002E694: 3212129E
	v_dual_add_f32 v3, v2, v3 :: v_dual_max_f32 v4, 0, v4      // 00000002E698: C9140702 03040880
	v_mad_u64_u32 v[1:2], null, s10, v1, 0                     // 00000002E6A0: D6FE7C01 0202020A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E6A8: BF870112
	v_dual_add_f32 v3, v3, v4 :: v_dual_add_nc_u32 v4, v6, v9  // 00000002E6AC: C9200903 03041306
	v_add3_u32 v2, v2, v7, v8                                  // 00000002E6B4: D6550002 04220F02
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E6BC: BF870192
	v_add_f32_e32 v3, v3, v5                                   // 00000002E6C0: 06060B03
	v_ashrrev_i32_e32 v4, 2, v4                                // 00000002E6C4: 34080882
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002E6C8: BF870193
	.long 0xd73c0001                                           // 00000002E6CC: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 00000002E6D0: 02020282
	v_mul_f32_e32 v3, v34, v3                                  // 00000002E6D4: 10060722
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E6D8: BF870113
	v_cmp_lt_i32_e32 vcc_lo, v49, v4                           // 00000002E6DC: 7C820931
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 00000002E6E0: 02060680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E6E4: BF870094
	.long 0xd7006a00                                           // 00000002E6E8: D7006A00
	v_cndmask_b32_e32 v1, v0, v1, vcc_lo                       // 00000002E6EC: 02020300
	v_add_co_ci_u32_e64 v1, null, v33, v2, vcc_lo              // 00000002E6F0: D5207C01 01AA0521
	global_store_b32 v[0:1], v3, off                           // 00000002E6F8: DC6A0000 007C0300
	s_nop 0                                                    // 00000002E700: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000002E704: BFB60003
	s_endpgm                                                   // 00000002E708: BFB00000
		...

