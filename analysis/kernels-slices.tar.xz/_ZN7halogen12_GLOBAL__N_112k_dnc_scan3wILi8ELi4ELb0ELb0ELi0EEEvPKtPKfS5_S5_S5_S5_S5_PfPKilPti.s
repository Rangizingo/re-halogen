000000000013ad00 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 00000013AD00: BF850001
	s_load_b512 s[12:27], s[0:1], 0x8                          // 00000013AD04: F4100300 F8000008
	s_load_b128 s[4:7], s[0:1], 0x48                           // 00000013AD0C: F4080100 F8000048
	s_lshl_b32 s8, s3, 4                                       // 00000013AD14: 84088403
	s_ashr_i32 s3, s2, 31                                      // 00000013AD18: 86039F02
	s_ashr_i32 s9, s8, 31                                      // 00000013AD1C: 86099F08
	v_dual_mov_b32 v3, v0 :: v_dual_and_b32 v56, 15, v0        // 00000013AD20: CA240100 0338008F
	s_movk_i32 s11, 0x210                                      // 00000013AD28: B00B0210
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000013AD2C: BF8704D1
	v_lshlrev_b32_e32 v1, 2, v56                               // 00000013AD30: 30027082
	v_mad_u32_u24 v57, v56, s11, 0x3200                        // 00000013AD34: D60B0039 03FC1738 00003200
	s_waitcnt lgkmcnt(0)                                       // 00000013AD40: BF89FC07
	s_load_b32 s10, s[26:27], null                             // 00000013AD44: F400028D F8000000
	s_lshl_b64 s[26:27], s[4:5], 2                             // 00000013AD4C: 849A8204
	s_add_u32 s4, s24, s26                                     // 00000013AD50: 80041A18
	s_addc_u32 s5, s25, s27                                    // 00000013AD54: 82051B19
	s_lshl_b64 s[28:29], s[2:3], 16                            // 00000013AD58: 849C9002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000013AD5C: BF870009
	s_add_u32 s4, s4, s28                                      // 00000013AD60: 80041C04
	s_addc_u32 s5, s5, s29                                     // 00000013AD64: 82051D05
	s_waitcnt lgkmcnt(0)                                       // 00000013AD68: BF89FC07
	s_mul_i32 s33, s10, 0x9000000                              // 00000013AD6C: 9621FF0A 09000000
	s_mul_hi_i32 s34, s10, 0x9000000                           // 00000013AD74: 9722FF0A 09000000
	s_add_u32 s4, s4, s33                                      // 00000013AD7C: 80042104
	s_addc_u32 s5, s5, s34                                     // 00000013AD80: 82052205
	s_lshl_b64 s[30:31], s[8:9], 2                             // 00000013AD84: 849E8208
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000013AD88: BF8700B9
	s_add_u32 s4, s4, s30                                      // 00000013AD8C: 80041E04
	s_addc_u32 s5, s5, s31                                     // 00000013AD90: 82051F05
	.long 0xd7000401                                           // 00000013AD94: D7000401
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 00000013AD98: 02020204
	v_add_co_ci_u32_e64 v2, null, s5, 0, s4                    // 00000013AD9C: D5207C02 00110005
	s_mov_b32 s4, 0                                            // 00000013ADA4: BE840080
	s_nop 0                                                    // 00000013ADA8: BF800000
	s_nop 0                                                    // 00000013ADAC: BF800000
	s_nop 0                                                    // 00000013ADB0: BF800000
	s_nop 0                                                    // 00000013ADB4: BF800000
	s_nop 0                                                    // 00000013ADB8: BF800000
	s_nop 0                                                    // 00000013ADBC: BF800000
	v_lshrrev_b32_e32 v6, 4, v3                                // 00000013ADC0: 320C0684
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013ADC4: BF870121
	v_lshlrev_b32_e32 v4, 9, v6                                // 00000013ADC8: 30080C89
	v_lshl_add_u32 v6, v6, 2, v57                              // 00000013ADCC: D6460006 04E50506
	.long 0xd7006a04                                           // 00000013ADD4: D7006A04
	v_cndmask_b32_e32 v1, v1, v4, vcc_lo                       // 00000013ADD8: 02020901
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000013ADDC: BF8700D1
	v_add_co_ci_u32_e64 v5, null, 0, v2, vcc_lo                // 00000013ADE0: D5207C05 01AA0480
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v3                         // 00000013ADE8: 7C9206FF 0000077F
	global_load_b32 v4, v[4:5], off                            // 00000013ADF0: DC520000 047C0004
	v_add_nc_u32_e32 v5, 0x80, v3                              // 00000013ADF8: 4A0A06FF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 00000013AE00: 8C04046A
	v_mov_b32_e32 v3, v5                                       // 00000013AE04: 7E060305
	s_waitcnt vmcnt(0)                                         // 00000013AE08: BF8903F7
	ds_store_b32 v6, v4                                        // 00000013AE0C: D8340000 00000406
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000013AE14: 917E047E
	s_cbranch_execnz 65513                                     // 00000013AE18: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000013AE1C: 8C7E047E
	s_load_b32 s35, s[0:1], 0x58                               // 00000013AE20: F40008C0 F8000058
	v_or_b32_e32 v59, 0xffffff80, v0                           // 00000013AE28: 387600FF FFFFFF80
	v_lshrrev_b32_e32 v58, 4, v0                               // 00000013AE30: 32740084
	s_mov_b32 s0, 0                                            // 00000013AE34: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000013AE38: BF89FC07
	s_barrier                                                  // 00000013AE3C: BFBD0000
	buffer_gl0_inv                                             // 00000013AE40: E0AC0000 00000000
	s_cmp_gt_i32 s35, 0                                        // 00000013AE48: BF028023
	s_cbranch_scc1 8                                           // 00000013AE4C: BFA20008 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x170>
	v_or_b32_e32 v2, 0xffffff80, v0                            // 00000013AE50: 380400FF FFFFFF80
	v_mov_b32_e32 v1, 0                                        // 00000013AE58: 7E020280
	v_lshrrev_b32_e32 v3, 4, v0                                // 00000013AE5C: 32060084
	v_lshlrev_b32_e32 v60, 2, v56                              // 00000013AE60: 30787082
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000013AE64: 916A007E
	s_cbranch_vccz 2                                           // 00000013AE68: BFA30002 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x174>
	s_branch 4272                                              // 00000013AE6C: BFA010B0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4430>
	v_lshlrev_b32_e32 v60, 2, v56                              // 00000013AE70: 30787082
	v_lshrrev_b32_e32 v61, 5, v0                               // 00000013AE74: 327A0085
	v_bfe_u32 v4, v0, 4, 1                                     // 00000013AE78: D6100004 02050900
	v_dual_mov_b32 v9, 0 :: v_dual_lshlrev_b32 v6, 1, v56      // 00000013AE80: CA220080 09067081
	v_lshrrev_b32_e32 v8, 6, v0                                // 00000013AE88: 32100086
	s_delay_alu instid0(VALU_DEP_4)                            // 00000013AE8C: BF870004
	v_lshlrev_b32_e32 v1, 4, v61                               // 00000013AE90: 30027A84
	v_lshl_add_u32 v7, v61, 6, v57                             // 00000013AE94: D6460007 04E50D3D
	v_and_b32_e32 v71, 63, v0                                  // 00000013AE9C: 368E00BF
	s_add_i32 s0, s35, 63                                      // 00000013AEA0: 8100BF23
	s_add_i32 s36, s2, 0xbd0                                   // 00000013AEA4: 8124FF02 00000BD0
	v_or_b32_e32 v65, v1, v4                                   // 00000013AEAC: 38820901
	v_lshl_add_u32 v73, v4, 2, v7                              // 00000013AEB0: D6460049 041D0504
	v_mul_u32_u24_e32 v4, 0xa0, v8                             // 00000013AEB8: 160810FF 000000A0
	s_lshr_b32 s37, s0, 6                                      // 00000013AEC0: 85258600
	s_movk_i32 s0, 0xa0                                        // 00000013AEC4: B00000A0
	s_add_u32 s4, s18, s30                                     // 00000013AEC8: 80041E12
	v_mad_u32_u24 v66, v56, s0, 0x2800                         // 00000013AECC: D60B0042 03FC0138 00002800
	v_lshl_add_u32 v77, v71, 1, v4                             // 00000013AED8: D646004D 04110347
	v_mov_b32_e32 v4, v9                                       // 00000013AEE0: 7E080309
	v_or_b32_e32 v64, v1, v56                                  // 00000013AEE4: 38807101
	v_lshlrev_b32_e32 v1, 8, v0                                // 00000013AEE8: 30020088
	s_addc_u32 s5, s19, s31                                    // 00000013AEEC: 82051F13
	s_lshl_b32 s0, s2, 7                                       // 00000013AEF0: 84008702
	.long 0xd7000443                                           // 00000013AEF4: D7000443
	v_cndmask_b32_e32 v1, s4, v60, vcc_lo                      // 00000013AEF8: 02027804
	s_delay_alu instid0(VALU_DEP_2)                            // 00000013AEFC: BF870002
	v_and_b32_e32 v1, 0xf00, v1                                // 00000013AF00: 360202FF 00000F00
	s_ashr_i32 s1, s0, 31                                      // 00000013AF08: 86019F00
	v_add_co_ci_u32_e64 v68, null, s5, 0, s4                   // 00000013AF0C: D5207C44 00110005
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000013AF14: 84808100
	v_lshl_or_b32 v1, v61, 12, v1                              // 00000013AF18: D6560001 0405193D
	s_add_u32 s4, s6, s0                                       // 00000013AF20: 80040006
	s_addc_u32 s5, s7, s1                                      // 00000013AF24: 82050107
	s_lshl_b64 s[0:1], s[8:9], 1                               // 00000013AF28: 84808108
	v_lshlrev_b32_e32 v3, 2, v0                                // 00000013AF2C: 30060082
	s_add_u32 s4, s4, s0                                       // 00000013AF30: 80040004
	s_addc_u32 s5, s5, s1                                      // 00000013AF34: 82050105
	s_lshl_b64 s[0:1], s[2:3], 9                               // 00000013AF38: 84808902
	.long 0xd7000645                                           // 00000013AF3C: D7000645
	v_cndmask_b32_e32 v1, s22, v1, vcc_lo                      // 00000013AF40: 02020216
	v_mad_u64_u32 v[1:2], null, 0x6000, v71, s[0:1]            // 00000013AF44: D6FE7C01 00028EFF 00006000
	.long 0xd7000032                                           // 00000013AF50: D7000032
	v_cndmask_b32_e32 v1, s4, v6, vcc_lo                       // 00000013AF54: 02020C04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 00000013AF58: BF870251
	v_add_co_ci_u32_e64 v51, null, s5, 0, s0                   // 00000013AF5C: D5207C33 00010005
	v_mul_u32_u24_e32 v5, 0xa0, v56                            // 00000013AF64: 160A70FF 000000A0
	v_add_co_ci_u32_e64 v70, null, s23, 0, s6                  // 00000013AF6C: D5207C46 00190017
	v_lshl_or_b32 v1, v8, 2, v1                                // 00000013AF74: D6560001 04050508
	v_lshl_add_u32 v74, v65, 1, v66                            // 00000013AF7C: D646004A 05090341
	v_mad_u32_u24 v72, 0xa00, v61, v5                          // 00000013AF84: D60B0048 04167AFF 00000A00
	v_lshl_or_b32 v75, v65, 2, 0x5400                          // 00000013AF90: D656004B 03FD0541 00005400
	v_mov_b32_e32 v5, v9                                       // 00000013AF9C: 7E0A0309
	.long 0xd7000034                                           // 00000013AFA0: D7000034
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000013AFA4: 0202020E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000013AFA8: BF8701A1
	v_add_co_ci_u32_e64 v53, null, s15, v2, s0                 // 00000013AFAC: D5207C35 0002040F
	v_mov_b32_e32 v1, v9                                       // 00000013AFB4: 7E020309
	.long 0xd7000036                                           // 00000013AFB8: D7000036
	v_cndmask_b32_e32 v1, 0x100, v52, vcc_lo                   // 00000013AFBC: 020268FF 00000100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013AFC4: BF870001
	v_add_co_ci_u32_e64 v55, null, 0, v53, s0                  // 00000013AFC8: D5207C37 00026A80
	v_mov_b32_e32 v2, 0                                        // 00000013AFD0: 7E040280
	v_add_nc_u32_e32 v62, 0x5300, v3                           // 00000013AFD4: 4A7C06FF 00005300
	v_or_b32_e32 v63, 0x5400, v3                               // 00000013AFDC: 387E06FF 00005400
	v_or_b32_e32 v76, 0x5300, v3                               // 00000013AFE4: 389806FF 00005300
	v_mov_b32_e32 v3, v9                                       // 00000013AFEC: 7E060309
	v_mov_b32_e32 v6, v9                                       // 00000013AFF0: 7E0C0309
	v_mov_b32_e32 v7, v9                                       // 00000013AFF4: 7E0E0309
	v_mov_b32_e32 v8, v9                                       // 00000013AFF8: 7E100309
	s_mov_b32 s15, 0                                           // 00000013AFFC: BE8F0080
	s_mov_b32 s18, 0x41800000                                  // 00000013B000: BE9200FF 41800000
	s_mov_b32 s19, 0                                           // 00000013B008: BE930080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000013B00C: 7C9800C0
	s_branch 121                                               // 00000013B010: BFA00079 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f8>
	s_set_inst_prefetch_distance 0x2                           // 00000013B014: BF840002
	s_or_b32 exec_lo, exec_lo, s5                              // 00000013B018: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 00000013B01C: BF89FC07
	s_barrier                                                  // 00000013B020: BFBD0000
	buffer_gl0_inv                                             // 00000013B024: E0AC0000 00000000
	ds_load_b128 v[18:21], v72                                 // 00000013B02C: DBFC0000 12000048
	ds_load_b128 v[22:25], v72 offset:16                       // 00000013B034: DBFC0010 16000048
	ds_load_b128 v[26:29], v72 offset:32                       // 00000013B03C: DBFC0020 1A000048
	ds_load_b128 v[30:33], v72 offset:48                       // 00000013B044: DBFC0030 1E000048
	ds_load_b128 v[34:37], v66                                 // 00000013B04C: DBFC0000 22000042
	ds_load_b128 v[38:41], v66 offset:16                       // 00000013B054: DBFC0010 26000042
	ds_load_b128 v[42:45], v66 offset:32                       // 00000013B05C: DBFC0020 2A000042
	ds_load_b128 v[46:49], v66 offset:48                       // 00000013B064: DBFC0030 2E000042
	ds_load_b128 v[82:85], v72 offset:80                       // 00000013B06C: DBFC0050 52000048
	ds_load_b128 v[78:81], v72 offset:64                       // 00000013B074: DBFC0040 4E000048
	ds_load_b128 v[90:93], v66 offset:80                       // 00000013B07C: DBFC0050 5A000042
	ds_load_b128 v[86:89], v66 offset:64                       // 00000013B084: DBFC0040 56000042
	ds_load_b128 v[98:101], v72 offset:112                     // 00000013B08C: DBFC0070 62000048
	ds_load_b128 v[94:97], v72 offset:96                       // 00000013B094: DBFC0060 5E000048
	ds_load_b128 v[106:109], v66 offset:112                    // 00000013B09C: DBFC0070 6A000042
	ds_load_b128 v[102:105], v66 offset:96                     // 00000013B0A4: DBFC0060 66000042
	ds_load_2addr_b32 v[118:119], v73 offset0:64 offset1:66    // 00000013B0AC: D8DC4240 76000049
	ds_load_2addr_b32 v[120:121], v73 offset0:68 offset1:70    // 00000013B0B4: D8DC4644 78000049
	ds_load_2addr_b32 v[122:123], v73 offset0:72 offset1:74    // 00000013B0BC: D8DC4A48 7A000049
	ds_load_2addr_b32 v[124:125], v73 offset0:76 offset1:78    // 00000013B0C4: D8DC4E4C 7C000049
	v_mov_b32_e32 v16, v9                                      // 00000013B0CC: 7E200309
	v_mov_b32_e32 v10, v9                                      // 00000013B0D0: 7E140309
	v_mov_b32_e32 v11, v9                                      // 00000013B0D4: 7E160309
	v_mov_b32_e32 v12, v9                                      // 00000013B0D8: 7E180309
	v_mov_b32_e32 v13, v9                                      // 00000013B0DC: 7E1A0309
	v_mov_b32_e32 v14, v9                                      // 00000013B0E0: 7E1C0309
	v_mov_b32_e32 v15, v9                                      // 00000013B0E4: 7E1E0309
	v_mov_b32_e32 v117, v16                                    // 00000013B0E8: 7EEA0310
	v_dual_mov_b32 v113, v12 :: v_dual_mov_b32 v112, v11       // 00000013B0EC: CA10010C 7170010B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000013B0F4: BF870214
	v_dual_mov_b32 v115, v14 :: v_dual_mov_b32 v114, v13       // 00000013B0F8: CA10010E 7372010D
	v_dual_mov_b32 v116, v15 :: v_dual_mov_b32 v111, v10       // 00000013B100: CA10010F 746E010A
	v_mov_b32_e32 v110, v9                                     // 00000013B108: 7EDC0309
	.long 0xd7000034                                           // 00000013B10C: D7000034
	v_cndmask_b32_e32 v1, 0x180000, v52, vcc_lo                // 00000013B110: 020268FF 00180000
	s_waitcnt lgkmcnt(3)                                       // 00000013B118: BF89FC37
	v_mul_f32_e32 v10, v17, v118                               // 00000013B11C: 1014ED11
	s_waitcnt lgkmcnt(2)                                       // 00000013B120: BF89FC27
	v_mul_f32_e32 v12, v17, v120                               // 00000013B124: 1018F111
	v_wmma_f32_16x16x16_f16 v[110:117], v[18:25], v[34:41], v[110:117]// 00000013B128: CC40406E 1DBA4512
	s_waitcnt lgkmcnt(0)                                       // 00000013B130: BF89FC07
	v_mul_f32_e32 v16, v17, v124                               // 00000013B134: 1020F911
	v_mul_f32_e32 v13, v17, v121                               // 00000013B138: 101AF311
	v_mul_f32_e32 v14, v17, v122                               // 00000013B13C: 101CF511
	v_mul_f32_e32 v15, v17, v123                               // 00000013B140: 101EF711
	v_wmma_f32_16x16x16_f16 v[110:117], v[26:33], v[42:49], v[110:117]// 00000013B144: CC40406E 1DBA551A
	v_add_co_ci_u32_e64 v53, null, 0, v53, s0                  // 00000013B14C: D5207C35 00026A80
	.long 0xd7000036                                           // 00000013B154: D7000036
	v_cndmask_b32_e32 v1, 0x180000, v54, vcc_lo                // 00000013B158: 02026CFF 00180000
	s_delay_alu instid0(VALU_DEP_3)                            // 00000013B160: BF870003
	v_wmma_f32_16x16x16_f16 v[110:117], v[78:85], v[86:93], v[110:117]// 00000013B164: CC40406E 1DBAAD4E
	v_add_co_ci_u32_e64 v55, null, 0, v55, s0                  // 00000013B16C: D5207C37 00026E80
	s_add_i32 s19, s19, 1                                      // 00000013B174: 81138113
	v_wmma_f32_16x16x16_f16 v[110:117], v[94:101], v[102:109], v[110:117]// 00000013B178: CC40406E 1DBACD5E
	v_mul_f32_e32 v11, v17, v119                               // 00000013B180: 1016EF11
	v_mul_f32_e32 v17, v17, v125                               // 00000013B184: 1022FB11
	s_cmp_eq_u32 s19, s37                                      // 00000013B188: BF062513
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013B18C: BF870193
	v_fmac_f32_e32 v10, 0x3b800000, v110                       // 00000013B190: 5614DCFF 3B800000
	v_dual_fmac_f32 v16, 0x3b800000, v116 :: v_dual_fmac_f32 v11, 0x3b800000, v111// 00000013B198: C800E8FF 100ADEFF 3B800000
	v_dual_fmac_f32 v12, 0x3b800000, v112 :: v_dual_fmac_f32 v13, 0x3b800000, v113// 00000013B1A4: C800E0FF 0C0CE2FF 3B800000
	v_dual_fmac_f32 v14, 0x3b800000, v114 :: v_dual_fmac_f32 v15, 0x3b800000, v115// 00000013B1B0: C800E4FF 0E0EE6FF 3B800000
	v_fmac_f32_e32 v17, 0x3b800000, v117                       // 00000013B1BC: 5622EAFF 3B800000
	ds_store_2addr_b32 v73, v10, v11 offset0:64 offset1:66     // 00000013B1C4: D8384240 000B0A49
	ds_store_2addr_b32 v73, v12, v13 offset0:68 offset1:70     // 00000013B1CC: D8384644 000D0C49
	ds_store_2addr_b32 v73, v14, v15 offset0:72 offset1:74     // 00000013B1D4: D8384A48 000F0E49
	ds_store_2addr_b32 v73, v16, v17 offset0:76 offset1:78     // 00000013B1DC: D8384E4C 00111049
	s_waitcnt lgkmcnt(0)                                       // 00000013B1E4: BF89FC07
	s_barrier                                                  // 00000013B1E8: BFBD0000
	buffer_gl0_inv                                             // 00000013B1EC: E0AC0000 00000000
	s_cbranch_scc1 4044                                        // 00000013B1F4: BFA20FCC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4428>
	s_mul_i32 s0, s19, 0xc00                                   // 00000013B1F8: 9600FF13 00000C00
	s_lshl_b32 s22, s19, 6                                     // 00000013B200: 84168613
	s_add_i32 s0, s36, s0                                      // 00000013B204: 81000024
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000013B208: BF870499
	s_ashr_i32 s1, s0, 31                                      // 00000013B20C: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000013B210: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000013B214: BF870009
	s_add_u32 s0, s16, s0                                      // 00000013B218: 80000010
	s_addc_u32 s1, s17, s1                                     // 00000013B21C: 82010111
	s_load_b32 s23, s[0:1], null                               // 00000013B220: F40005C0 F8000000
	s_and_saveexec_b32 s1, vcc_lo                              // 00000013B228: BE81206A
	s_cbranch_execz 77                                         // 00000013B22C: BFA5004D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x664>
	v_or_b32_e32 v10, s22, v0                                  // 00000013B230: 38140016
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B234: BF870091
	v_mad_u64_u32 v[10:11], null, v10, 48, s[2:3]              // 00000013B238: D6FE7C0A 0009610A
	v_ashrrev_i32_e32 v11, 31, v10                             // 00000013B240: 3416149F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B244: BF870091
	.long 0xd73c000a                                           // 00000013B248: D73C000A
	v_cndmask_b32_e32 v1, 2, v10, vcc_lo                       // 00000013B24C: 02021482
	.long 0xd700000a                                           // 00000013B250: D700000A
	v_cndmask_b32_e32 v1, s16, v10, vcc_lo                     // 00000013B254: 02021410
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013B258: BF8700C1
	v_add_co_ci_u32_e64 v11, null, s17, v11, s0                // 00000013B25C: D5207C0B 00021611
	global_load_b32 v10, v[10:11], off                         // 00000013B264: DC520000 0A7C000A
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000013B26C: BF890007
	v_sub_f32_e32 v11, s23, v10                                // 00000013B270: 08161417
	v_dual_mul_f32 v13, 0x3fb8aa3b, v10 :: v_dual_mul_f32 v12, 0x3fb8aa3b, v11// 00000013B274: C8C614FF 0D0C16FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000013B280: BF8701A1
	v_fma_f32 v16, 0x3fb8aa3b, v10, -v13                       // 00000013B284: D6130010 843614FF 3FB8AA3B
	v_rndne_f32_e32 v17, v13                                   // 00000013B290: 7E22470D
	v_fma_f32 v14, 0x3fb8aa3b, v11, -v12                       // 00000013B294: D613000E 843216FF 3FB8AA3B
	v_rndne_f32_e32 v15, v12                                   // 00000013B2A0: 7E1E470C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013B2A4: BF870113
	v_dual_fmac_f32 v16, 0x32a5705f, v10 :: v_dual_sub_f32 v13, v13, v17// 00000013B2A8: C80A14FF 100C230D 32A5705F
	v_sub_f32_e32 v12, v12, v15                                // 00000013B2B4: 08181F0C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013B2B8: BF870124
	v_fmac_f32_e32 v14, 0x32a5705f, v11                        // 00000013B2BC: 561C16FF 32A5705F
	.long 0xd41b0000                                           // 00000013B2C4: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v11, vcc_lo              // 00000013B2C8: 020216FF C2CE8ED0
	v_dual_add_f32 v13, v13, v16 :: v_dual_add_f32 v12, v12, v14// 00000013B2D0: C908210D 0D0C1D0C
	v_cvt_i32_f32_e32 v14, v15                                 // 00000013B2D8: 7E1C110F
	v_cvt_i32_f32_e32 v15, v17                                 // 00000013B2DC: 7E1E1111
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013B2E0: BF870193
	v_exp_f32_e32 v13, v13                                     // 00000013B2E4: 7E1A4B0D
	v_exp_f32_e32 v12, v12                                     // 00000013B2E8: 7E184B0C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000013B2EC: BF870296
	.long 0xd71c000d                                           // 00000013B2F0: D71C000D
	v_cndmask_b32_e32 v1, v13, v15, vcc_lo                     // 00000013B2F4: 02021F0D
	.long 0xd71c000c                                           // 00000013B2F8: D71C000C
	v_cndmask_b32_e32 v1, v12, v14, vcc_lo                     // 00000013B2FC: 02021D0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013B300: BF8700A1
	v_cndmask_b32_e64 v12, 0, v12, s0                          // 00000013B304: D501000C 00021880
	.long 0xd41b0000                                           // 00000013B30C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v10, vcc_lo              // 00000013B310: 020214FF C2CE8ED0
	v_cndmask_b32_e64 v13, 0, v13, s0                          // 00000013B318: D501000D 00021A80
	.long 0xd41e0000                                           // 00000013B320: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v11, vcc_lo              // 00000013B324: 020216FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000013B32C: BF8700A1
	v_cndmask_b32_e64 v11, 0x7f800000, v12, s0                 // 00000013B330: D501000B 000218FF 7F800000
	.long 0xd41e0000                                           // 00000013B33C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v10, vcc_lo              // 00000013B340: 020214FF 42B17218
	v_cndmask_b32_e64 v10, 0x7f800000, v13, s0                 // 00000013B348: D501000A 00021AFF 7F800000
	ds_store_b32 v62, v11                                      // 00000013B354: D8340000 00000B3E
	ds_store_b32 v63, v10                                      // 00000013B35C: D8340000 00000A3F
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B364: 8C7E017E
	v_add_nc_u32_e32 v12, s22, v64                             // 00000013B368: 4A188016
	.long 0x7f243880                                           // 00000013B36C: 7F243880
	s_waitcnt lgkmcnt(0)                                       // 00000013B370: BF89FC07
	s_barrier                                                  // 00000013B374: BFBD0000
	buffer_gl0_inv                                             // 00000013B378: E0AC0000 00000000
	v_mad_u64_u32 v[10:11], null, v12, 48, s[2:3]              // 00000013B380: D6FE7C0A 0009610C
	.long 0xd4440000                                           // 00000013B388: D4440000
	v_cndmask_b32_e32 v1, s35, v12, vcc_lo                     // 00000013B38C: 02021823
	.long 0x7e243992                                           // 00000013B390: 7E243992
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013B394: BF870093
	.long 0xd73c0022                                           // 00000013B398: D73C0022
	v_cndmask_b32_e32 v1, 9, v10, vcc_lo                       // 00000013B39C: 02021489
	.long 0xd7000124                                           // 00000013B3A0: D7000124
	v_cndmask_b32_e32 v1, s20, v34, vcc_lo                     // 00000013B3A4: 02024414
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B3A8: BF870001
	v_add_co_ci_u32_e64 v37, null, s21, v35, s1                // 00000013B3AC: D5207C25 00064615
	s_and_saveexec_b32 s1, s0                                  // 00000013B3B4: BE812000
	s_cbranch_execz 5                                          // 00000013B3B8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6d0>
	global_load_b32 v10, v[36:37], off                         // 00000013B3BC: DC520000 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B3C4: BF8903F7
	v_fma_mixlo_f16 v18, v10, s18, 0                           // 00000013B3C8: CC210012 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B3D0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B3D4: BE812000
	s_cbranch_execz 5                                          // 00000013B3D8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6f0>
	global_load_b32 v10, v[36:37], off offset:4                // 00000013B3DC: DC520004 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B3E4: BF8903F7
	v_fma_mixhi_f16 v18, v10, s18, 0                           // 00000013B3E8: CC220012 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B3F0: 8C7E017E
	.long 0x7f263880                                           // 00000013B3F4: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B3F8: BF870001
	.long 0x7e263993                                           // 00000013B3FC: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000013B400: BE812000
	s_cbranch_execz 5                                          // 00000013B404: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x71c>
	global_load_b32 v10, v[36:37], off offset:8                // 00000013B408: DC520008 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B410: BF8903F7
	v_fma_mixlo_f16 v19, v10, s18, 0                           // 00000013B414: CC210013 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B41C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B420: BE812000
	s_cbranch_execz 5                                          // 00000013B424: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x73c>
	global_load_b32 v10, v[36:37], off offset:12               // 00000013B428: DC52000C 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B430: BF8903F7
	v_fma_mixhi_f16 v19, v10, s18, 0                           // 00000013B434: CC220013 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B43C: 8C7E017E
	.long 0x7f283880                                           // 00000013B440: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B444: BF870001
	.long 0x7e283994                                           // 00000013B448: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000013B44C: BE812000
	s_cbranch_execz 5                                          // 00000013B450: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x768>
	global_load_b32 v10, v[36:37], off offset:16               // 00000013B454: DC520010 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B45C: BF8903F7
	v_fma_mixlo_f16 v20, v10, s18, 0                           // 00000013B460: CC210014 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B468: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B46C: BE812000
	s_cbranch_execz 5                                          // 00000013B470: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x788>
	global_load_b32 v10, v[36:37], off offset:20               // 00000013B474: DC520014 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B47C: BF8903F7
	v_fma_mixhi_f16 v20, v10, s18, 0                           // 00000013B480: CC220014 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B488: 8C7E017E
	.long 0x7f2a3880                                           // 00000013B48C: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B490: BF870001
	.long 0x7e2a3995                                           // 00000013B494: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000013B498: BE812000
	s_cbranch_execz 5                                          // 00000013B49C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x7b4>
	global_load_b32 v10, v[36:37], off offset:24               // 00000013B4A0: DC520018 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B4A8: BF8903F7
	v_fma_mixlo_f16 v21, v10, s18, 0                           // 00000013B4AC: CC210015 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B4B4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B4B8: BE812000
	s_cbranch_execz 5                                          // 00000013B4BC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x7d4>
	global_load_b32 v10, v[36:37], off offset:28               // 00000013B4C0: DC52001C 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B4C8: BF8903F7
	v_fma_mixhi_f16 v21, v10, s18, 0                           // 00000013B4CC: CC220015 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B4D4: 8C7E017E
	.long 0x7f2c3880                                           // 00000013B4D8: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B4DC: BF870001
	.long 0x7e2c3996                                           // 00000013B4E0: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000013B4E4: BE812000
	s_cbranch_execz 5                                          // 00000013B4E8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x800>
	global_load_b32 v10, v[36:37], off offset:32               // 00000013B4EC: DC520020 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B4F4: BF8903F7
	v_fma_mixlo_f16 v22, v10, s18, 0                           // 00000013B4F8: CC210016 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B500: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B504: BE812000
	s_cbranch_execz 5                                          // 00000013B508: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x820>
	global_load_b32 v10, v[36:37], off offset:36               // 00000013B50C: DC520024 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B514: BF8903F7
	v_fma_mixhi_f16 v22, v10, s18, 0                           // 00000013B518: CC220016 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B520: 8C7E017E
	.long 0x7f2e3880                                           // 00000013B524: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B528: BF870001
	.long 0x7e2e3997                                           // 00000013B52C: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000013B530: BE812000
	s_cbranch_execz 5                                          // 00000013B534: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x84c>
	global_load_b32 v10, v[36:37], off offset:40               // 00000013B538: DC520028 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B540: BF8903F7
	v_fma_mixlo_f16 v23, v10, s18, 0                           // 00000013B544: CC210017 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B54C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B550: BE812000
	s_cbranch_execz 5                                          // 00000013B554: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x86c>
	global_load_b32 v10, v[36:37], off offset:44               // 00000013B558: DC52002C 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B560: BF8903F7
	v_fma_mixhi_f16 v23, v10, s18, 0                           // 00000013B564: CC220017 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B56C: 8C7E017E
	.long 0x7f303880                                           // 00000013B570: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B574: BF870001
	.long 0x7e303998                                           // 00000013B578: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000013B57C: BE812000
	s_cbranch_execz 5                                          // 00000013B580: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x898>
	global_load_b32 v10, v[36:37], off offset:48               // 00000013B584: DC520030 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B58C: BF8903F7
	v_fma_mixlo_f16 v24, v10, s18, 0                           // 00000013B590: CC210018 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B598: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B59C: BE812000
	s_cbranch_execz 5                                          // 00000013B5A0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8b8>
	global_load_b32 v10, v[36:37], off offset:52               // 00000013B5A4: DC520034 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B5AC: BF8903F7
	v_fma_mixhi_f16 v24, v10, s18, 0                           // 00000013B5B0: CC220018 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B5B8: 8C7E017E
	.long 0x7f323880                                           // 00000013B5BC: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B5C0: BF870001
	.long 0x7e323999                                           // 00000013B5C4: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000013B5C8: BE812000
	s_cbranch_execz 5                                          // 00000013B5CC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8e4>
	global_load_b32 v10, v[36:37], off offset:56               // 00000013B5D0: DC520038 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B5D8: BF8903F7
	v_fma_mixlo_f16 v25, v10, s18, 0                           // 00000013B5DC: CC210019 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B5E4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B5E8: BE812000
	s_cbranch_execz 5                                          // 00000013B5EC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x904>
	global_load_b32 v10, v[36:37], off offset:60               // 00000013B5F0: DC52003C 0A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013B5F8: BF8903F7
	v_fma_mixhi_f16 v25, v10, s18, 0                           // 00000013B5FC: CC220019 0200250A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B604: 8C7E017E
	ds_load_b128 v[10:13], v57                                 // 00000013B608: DBFC0000 0A000039
	ds_load_b128 v[14:17], v57 offset:16                       // 00000013B610: DBFC0010 0E000039
	ds_load_b128 v[26:29], v57 offset:32                       // 00000013B618: DBFC0020 1A000039
	ds_load_b128 v[30:33], v57 offset:48                       // 00000013B620: DBFC0030 1E000039
	s_waitcnt lgkmcnt(3)                                       // 00000013B628: BF89FC37
	v_fma_mixlo_f16 v38, v10, s18, 0                           // 00000013B62C: CC210026 0200250A
	v_fma_mixhi_f16 v38, v11, s18, 0                           // 00000013B634: CC220026 0200250B
	v_fma_mixlo_f16 v39, v12, s18, 0                           // 00000013B63C: CC210027 0200250C
	v_fma_mixhi_f16 v39, v13, s18, 0                           // 00000013B644: CC220027 0200250D
	s_waitcnt lgkmcnt(2)                                       // 00000013B64C: BF89FC27
	v_fma_mixlo_f16 v40, v14, s18, 0                           // 00000013B650: CC210028 0200250E
	v_fma_mixhi_f16 v40, v15, s18, 0                           // 00000013B658: CC220028 0200250F
	v_fma_mixlo_f16 v41, v16, s18, 0                           // 00000013B660: CC210029 02002510
	v_fma_mixhi_f16 v41, v17, s18, 0                           // 00000013B668: CC220029 02002511
	s_waitcnt lgkmcnt(1)                                       // 00000013B670: BF89FC17
	v_fma_mixlo_f16 v42, v26, s18, 0                           // 00000013B674: CC21002A 0200251A
	v_fma_mixhi_f16 v42, v27, s18, 0                           // 00000013B67C: CC22002A 0200251B
	v_fma_mixlo_f16 v43, v28, s18, 0                           // 00000013B684: CC21002B 0200251C
	v_fma_mixhi_f16 v43, v29, s18, 0                           // 00000013B68C: CC22002B 0200251D
	s_waitcnt lgkmcnt(0)                                       // 00000013B694: BF89FC07
	v_fma_mixlo_f16 v44, v30, s18, 0                           // 00000013B698: CC21002C 0200251E
	v_fma_mixhi_f16 v44, v31, s18, 0                           // 00000013B6A0: CC22002C 0200251F
	v_fma_mixlo_f16 v45, v32, s18, 0                           // 00000013B6A8: CC21002D 02002520
	v_fma_mixhi_f16 v45, v33, s18, 0                           // 00000013B6B0: CC22002D 02002521
	.long 0x7f343880                                           // 00000013B6B8: 7F343880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013B6BC: BF870112
	v_wmma_f32_16x16x16_f16 v[10:17], v[18:25], v[38:45], v[2:9]// 00000013B6C0: CC40400A 1C0A4D12
	.long 0x7e34399a                                           // 00000013B6C8: 7E34399A
	s_and_saveexec_b32 s1, s0                                  // 00000013B6CC: BE812000
	s_cbranch_execz 5                                          // 00000013B6D0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x9e8>
	global_load_b32 v18, v[36:37], off offset:64               // 00000013B6D4: DC520040 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B6DC: BF8903F7
	v_fma_mixlo_f16 v26, v18, s18, 0                           // 00000013B6E0: CC21001A 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B6E8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B6EC: BE812000
	s_cbranch_execz 5                                          // 00000013B6F0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa08>
	global_load_b32 v18, v[36:37], off offset:68               // 00000013B6F4: DC520044 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B6FC: BF8903F7
	v_fma_mixhi_f16 v26, v18, s18, 0                           // 00000013B700: CC22001A 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B708: 8C7E017E
	.long 0x7f363880                                           // 00000013B70C: 7F363880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B710: BF870001
	.long 0x7e36399b                                           // 00000013B714: 7E36399B
	s_and_saveexec_b32 s1, s0                                  // 00000013B718: BE812000
	s_cbranch_execz 5                                          // 00000013B71C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa34>
	global_load_b32 v18, v[36:37], off offset:72               // 00000013B720: DC520048 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B728: BF8903F7
	v_fma_mixlo_f16 v27, v18, s18, 0                           // 00000013B72C: CC21001B 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B734: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B738: BE812000
	s_cbranch_execz 5                                          // 00000013B73C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa54>
	global_load_b32 v18, v[36:37], off offset:76               // 00000013B740: DC52004C 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B748: BF8903F7
	v_fma_mixhi_f16 v27, v18, s18, 0                           // 00000013B74C: CC22001B 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B754: 8C7E017E
	.long 0x7f383880                                           // 00000013B758: 7F383880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B75C: BF870001
	.long 0x7e38399c                                           // 00000013B760: 7E38399C
	s_and_saveexec_b32 s1, s0                                  // 00000013B764: BE812000
	s_cbranch_execz 5                                          // 00000013B768: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xa80>
	global_load_b32 v18, v[36:37], off offset:80               // 00000013B76C: DC520050 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B774: BF8903F7
	v_fma_mixlo_f16 v28, v18, s18, 0                           // 00000013B778: CC21001C 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B780: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B784: BE812000
	s_cbranch_execz 5                                          // 00000013B788: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xaa0>
	global_load_b32 v18, v[36:37], off offset:84               // 00000013B78C: DC520054 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B794: BF8903F7
	v_fma_mixhi_f16 v28, v18, s18, 0                           // 00000013B798: CC22001C 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B7A0: 8C7E017E
	.long 0x7f3a3880                                           // 00000013B7A4: 7F3A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B7A8: BF870001
	.long 0x7e3a399d                                           // 00000013B7AC: 7E3A399D
	s_and_saveexec_b32 s1, s0                                  // 00000013B7B0: BE812000
	s_cbranch_execz 5                                          // 00000013B7B4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xacc>
	global_load_b32 v18, v[36:37], off offset:88               // 00000013B7B8: DC520058 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B7C0: BF8903F7
	v_fma_mixlo_f16 v29, v18, s18, 0                           // 00000013B7C4: CC21001D 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B7CC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B7D0: BE812000
	s_cbranch_execz 5                                          // 00000013B7D4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xaec>
	global_load_b32 v18, v[36:37], off offset:92               // 00000013B7D8: DC52005C 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B7E0: BF8903F7
	v_fma_mixhi_f16 v29, v18, s18, 0                           // 00000013B7E4: CC22001D 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B7EC: 8C7E017E
	.long 0x7f3c3880                                           // 00000013B7F0: 7F3C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B7F4: BF870001
	.long 0x7e3c399e                                           // 00000013B7F8: 7E3C399E
	s_and_saveexec_b32 s1, s0                                  // 00000013B7FC: BE812000
	s_cbranch_execz 5                                          // 00000013B800: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb18>
	global_load_b32 v18, v[36:37], off offset:96               // 00000013B804: DC520060 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B80C: BF8903F7
	v_fma_mixlo_f16 v30, v18, s18, 0                           // 00000013B810: CC21001E 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B818: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B81C: BE812000
	s_cbranch_execz 5                                          // 00000013B820: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb38>
	global_load_b32 v18, v[36:37], off offset:100              // 00000013B824: DC520064 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B82C: BF8903F7
	v_fma_mixhi_f16 v30, v18, s18, 0                           // 00000013B830: CC22001E 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B838: 8C7E017E
	.long 0x7f3e3880                                           // 00000013B83C: 7F3E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B840: BF870001
	.long 0x7e3e399f                                           // 00000013B844: 7E3E399F
	s_and_saveexec_b32 s1, s0                                  // 00000013B848: BE812000
	s_cbranch_execz 5                                          // 00000013B84C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb64>
	global_load_b32 v18, v[36:37], off offset:104              // 00000013B850: DC520068 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B858: BF8903F7
	v_fma_mixlo_f16 v31, v18, s18, 0                           // 00000013B85C: CC21001F 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B864: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B868: BE812000
	s_cbranch_execz 5                                          // 00000013B86C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb84>
	global_load_b32 v18, v[36:37], off offset:108              // 00000013B870: DC52006C 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B878: BF8903F7
	v_fma_mixhi_f16 v31, v18, s18, 0                           // 00000013B87C: CC22001F 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B884: 8C7E017E
	.long 0x7f403880                                           // 00000013B888: 7F403880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B88C: BF870001
	.long 0x7e4039a0                                           // 00000013B890: 7E4039A0
	s_and_saveexec_b32 s1, s0                                  // 00000013B894: BE812000
	s_cbranch_execz 5                                          // 00000013B898: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xbb0>
	global_load_b32 v18, v[36:37], off offset:112              // 00000013B89C: DC520070 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B8A4: BF8903F7
	v_fma_mixlo_f16 v32, v18, s18, 0                           // 00000013B8A8: CC210020 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B8B0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B8B4: BE812000
	s_cbranch_execz 5                                          // 00000013B8B8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xbd0>
	global_load_b32 v18, v[36:37], off offset:116              // 00000013B8BC: DC520074 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B8C4: BF8903F7
	v_fma_mixhi_f16 v32, v18, s18, 0                           // 00000013B8C8: CC220020 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B8D0: 8C7E017E
	.long 0x7f423880                                           // 00000013B8D4: 7F423880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013B8D8: BF870001
	.long 0x7e4239a1                                           // 00000013B8DC: 7E4239A1
	s_and_saveexec_b32 s1, s0                                  // 00000013B8E0: BE812000
	s_cbranch_execz 5                                          // 00000013B8E4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xbfc>
	global_load_b32 v18, v[36:37], off offset:120              // 00000013B8E8: DC520078 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B8F0: BF8903F7
	v_fma_mixlo_f16 v33, v18, s18, 0                           // 00000013B8F4: CC210021 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B8FC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013B900: BE812000
	s_cbranch_execz 5                                          // 00000013B904: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc1c>
	global_load_b32 v18, v[36:37], off offset:124              // 00000013B908: DC52007C 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013B910: BF8903F7
	v_fma_mixhi_f16 v33, v18, s18, 0                           // 00000013B914: CC220021 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013B91C: 8C7E017E
	ds_load_b128 v[18:21], v57 offset:64                       // 00000013B920: DBFC0040 12000039
	ds_load_b128 v[22:25], v57 offset:80                       // 00000013B928: DBFC0050 16000039
	ds_load_b128 v[42:45], v57 offset:96                       // 00000013B930: DBFC0060 2A000039
	ds_load_b128 v[46:49], v57 offset:112                      // 00000013B938: DBFC0070 2E000039
	s_waitcnt lgkmcnt(3)                                       // 00000013B940: BF89FC37
	v_fma_mixlo_f16 v38, v18, s18, 0                           // 00000013B944: CC210026 02002512
	v_fma_mixhi_f16 v38, v19, s18, 0                           // 00000013B94C: CC220026 02002513
	v_fma_mixlo_f16 v39, v20, s18, 0                           // 00000013B954: CC210027 02002514
	v_fma_mixhi_f16 v39, v21, s18, 0                           // 00000013B95C: CC220027 02002515
	s_waitcnt lgkmcnt(2)                                       // 00000013B964: BF89FC27
	v_fma_mixlo_f16 v40, v22, s18, 0                           // 00000013B968: CC210028 02002516
	v_fma_mixhi_f16 v40, v23, s18, 0                           // 00000013B970: CC220028 02002517
	v_fma_mixlo_f16 v41, v24, s18, 0                           // 00000013B978: CC210029 02002518
	v_fma_mixhi_f16 v41, v25, s18, 0                           // 00000013B980: CC220029 02002519
	s_waitcnt lgkmcnt(1)                                       // 00000013B988: BF89FC17
	v_fma_mixlo_f16 v42, v42, s18, 0                           // 00000013B98C: CC21002A 0200252A
	v_fma_mixhi_f16 v42, v43, s18, 0                           // 00000013B994: CC22002A 0200252B
	v_fma_mixlo_f16 v43, v44, s18, 0                           // 00000013B99C: CC21002B 0200252C
	v_fma_mixhi_f16 v43, v45, s18, 0                           // 00000013B9A4: CC22002B 0200252D
	s_waitcnt lgkmcnt(0)                                       // 00000013B9AC: BF89FC07
	v_fma_mixlo_f16 v44, v46, s18, 0                           // 00000013B9B0: CC21002C 0200252E
	v_fma_mixhi_f16 v44, v47, s18, 0                           // 00000013B9B8: CC22002C 0200252F
	v_fma_mixlo_f16 v45, v48, s18, 0                           // 00000013B9C0: CC21002D 02002530
	v_fma_mixhi_f16 v45, v49, s18, 0                           // 00000013B9C8: CC22002D 02002531
	.long 0x7f243880                                           // 00000013B9D0: 7F243880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013B9D4: BF870112
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[38:45], v[10:17]// 00000013B9D8: CC40400A 1C2A4D1A
	.long 0x7e243992                                           // 00000013B9E0: 7E243992
	s_and_saveexec_b32 s1, s0                                  // 00000013B9E4: BE812000
	s_cbranch_execz 5                                          // 00000013B9E8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd00>
	global_load_b32 v19, v[36:37], off offset:128              // 00000013B9EC: DC520080 137C0024
	s_waitcnt vmcnt(0)                                         // 00000013B9F4: BF8903F7
	v_fma_mixlo_f16 v18, v19, s18, 0                           // 00000013B9F8: CC210012 02002513
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BA00: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BA04: BE812000
	s_cbranch_execz 5                                          // 00000013BA08: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd20>
	global_load_b32 v19, v[36:37], off offset:132              // 00000013BA0C: DC520084 137C0024
	s_waitcnt vmcnt(0)                                         // 00000013BA14: BF8903F7
	v_fma_mixhi_f16 v18, v19, s18, 0                           // 00000013BA18: CC220012 02002513
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BA20: 8C7E017E
	.long 0x7f263880                                           // 00000013BA24: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013BA28: BF870001
	.long 0x7e263993                                           // 00000013BA2C: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000013BA30: BE812000
	s_cbranch_execz 5                                          // 00000013BA34: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd4c>
	global_load_b32 v20, v[36:37], off offset:136              // 00000013BA38: DC520088 147C0024
	s_waitcnt vmcnt(0)                                         // 00000013BA40: BF8903F7
	v_fma_mixlo_f16 v19, v20, s18, 0                           // 00000013BA44: CC210013 02002514
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BA4C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BA50: BE812000
	s_cbranch_execz 5                                          // 00000013BA54: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd6c>
	global_load_b32 v20, v[36:37], off offset:140              // 00000013BA58: DC52008C 147C0024
	s_waitcnt vmcnt(0)                                         // 00000013BA60: BF8903F7
	v_fma_mixhi_f16 v19, v20, s18, 0                           // 00000013BA64: CC220013 02002514
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BA6C: 8C7E017E
	.long 0x7f283880                                           // 00000013BA70: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013BA74: BF870001
	.long 0x7e283994                                           // 00000013BA78: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000013BA7C: BE812000
	s_cbranch_execz 5                                          // 00000013BA80: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd98>
	global_load_b32 v21, v[36:37], off offset:144              // 00000013BA84: DC520090 157C0024
	s_waitcnt vmcnt(0)                                         // 00000013BA8C: BF8903F7
	v_fma_mixlo_f16 v20, v21, s18, 0                           // 00000013BA90: CC210014 02002515
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BA98: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BA9C: BE812000
	s_cbranch_execz 5                                          // 00000013BAA0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xdb8>
	global_load_b32 v21, v[36:37], off offset:148              // 00000013BAA4: DC520094 157C0024
	s_waitcnt vmcnt(0)                                         // 00000013BAAC: BF8903F7
	v_fma_mixhi_f16 v20, v21, s18, 0                           // 00000013BAB0: CC220014 02002515
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BAB8: 8C7E017E
	.long 0x7f2a3880                                           // 00000013BABC: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013BAC0: BF870001
	.long 0x7e2a3995                                           // 00000013BAC4: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000013BAC8: BE812000
	s_cbranch_execz 5                                          // 00000013BACC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xde4>
	global_load_b32 v22, v[36:37], off offset:152              // 00000013BAD0: DC520098 167C0024
	s_waitcnt vmcnt(0)                                         // 00000013BAD8: BF8903F7
	v_fma_mixlo_f16 v21, v22, s18, 0                           // 00000013BADC: CC210015 02002516
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BAE4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BAE8: BE812000
	s_cbranch_execz 5                                          // 00000013BAEC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe04>
	global_load_b32 v22, v[36:37], off offset:156              // 00000013BAF0: DC52009C 167C0024
	s_waitcnt vmcnt(0)                                         // 00000013BAF8: BF8903F7
	v_fma_mixhi_f16 v21, v22, s18, 0                           // 00000013BAFC: CC220015 02002516
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BB04: 8C7E017E
	.long 0x7f2c3880                                           // 00000013BB08: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013BB0C: BF870001
	.long 0x7e2c3996                                           // 00000013BB10: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000013BB14: BE812000
	s_cbranch_execz 5                                          // 00000013BB18: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe30>
	global_load_b32 v23, v[36:37], off offset:160              // 00000013BB1C: DC5200A0 177C0024
	s_waitcnt vmcnt(0)                                         // 00000013BB24: BF8903F7
	v_fma_mixlo_f16 v22, v23, s18, 0                           // 00000013BB28: CC210016 02002517
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BB30: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BB34: BE812000
	s_cbranch_execz 5                                          // 00000013BB38: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe50>
	global_load_b32 v23, v[36:37], off offset:164              // 00000013BB3C: DC5200A4 177C0024
	s_waitcnt vmcnt(0)                                         // 00000013BB44: BF8903F7
	v_fma_mixhi_f16 v22, v23, s18, 0                           // 00000013BB48: CC220016 02002517
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BB50: 8C7E017E
	.long 0x7f2e3880                                           // 00000013BB54: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013BB58: BF870001
	.long 0x7e2e3997                                           // 00000013BB5C: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000013BB60: BE812000
	s_cbranch_execz 5                                          // 00000013BB64: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe7c>
	global_load_b32 v24, v[36:37], off offset:168              // 00000013BB68: DC5200A8 187C0024
	s_waitcnt vmcnt(0)                                         // 00000013BB70: BF8903F7
	v_fma_mixlo_f16 v23, v24, s18, 0                           // 00000013BB74: CC210017 02002518
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BB7C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BB80: BE812000
	s_cbranch_execz 5                                          // 00000013BB84: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe9c>
	global_load_b32 v24, v[36:37], off offset:172              // 00000013BB88: DC5200AC 187C0024
	s_waitcnt vmcnt(0)                                         // 00000013BB90: BF8903F7
	v_fma_mixhi_f16 v23, v24, s18, 0                           // 00000013BB94: CC220017 02002518
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BB9C: 8C7E017E
	.long 0x7f303880                                           // 00000013BBA0: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013BBA4: BF870001
	.long 0x7e303998                                           // 00000013BBA8: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000013BBAC: BE812000
	s_cbranch_execz 5                                          // 00000013BBB0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xec8>
	global_load_b32 v25, v[36:37], off offset:176              // 00000013BBB4: DC5200B0 197C0024
	s_waitcnt vmcnt(0)                                         // 00000013BBBC: BF8903F7
	v_fma_mixlo_f16 v24, v25, s18, 0                           // 00000013BBC0: CC210018 02002519
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BBC8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BBCC: BE812000
	s_cbranch_execz 5                                          // 00000013BBD0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xee8>
	global_load_b32 v25, v[36:37], off offset:180              // 00000013BBD4: DC5200B4 197C0024
	s_waitcnt vmcnt(0)                                         // 00000013BBDC: BF8903F7
	v_fma_mixhi_f16 v24, v25, s18, 0                           // 00000013BBE0: CC220018 02002519
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BBE8: 8C7E017E
	.long 0x7f323880                                           // 00000013BBEC: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013BBF0: BF870001
	.long 0x7e323999                                           // 00000013BBF4: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000013BBF8: BE812000
	s_cbranch_execz 5                                          // 00000013BBFC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xf14>
	global_load_b32 v26, v[36:37], off offset:184              // 00000013BC00: DC5200B8 1A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013BC08: BF8903F7
	v_fma_mixlo_f16 v25, v26, s18, 0                           // 00000013BC0C: CC210019 0200251A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BC14: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BC18: BE812000
	s_cbranch_execz 5                                          // 00000013BC1C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xf34>
	global_load_b32 v26, v[36:37], off offset:188              // 00000013BC20: DC5200BC 1A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013BC28: BF8903F7
	v_fma_mixhi_f16 v25, v26, s18, 0                           // 00000013BC2C: CC220019 0200251A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BC34: 8C7E017E
	ds_load_b128 v[26:29], v57 offset:128                      // 00000013BC38: DBFC0080 1A000039
	ds_load_b128 v[30:33], v57 offset:144                      // 00000013BC40: DBFC0090 1E000039
	ds_load_b128 v[42:45], v57 offset:160                      // 00000013BC48: DBFC00A0 2A000039
	ds_load_b128 v[46:49], v57 offset:176                      // 00000013BC50: DBFC00B0 2E000039
	s_waitcnt lgkmcnt(3)                                       // 00000013BC58: BF89FC37
	v_fma_mixlo_f16 v38, v26, s18, 0                           // 00000013BC5C: CC210026 0200251A
	v_fma_mixhi_f16 v38, v27, s18, 0                           // 00000013BC64: CC220026 0200251B
	v_fma_mixlo_f16 v39, v28, s18, 0                           // 00000013BC6C: CC210027 0200251C
	v_fma_mixhi_f16 v39, v29, s18, 0                           // 00000013BC74: CC220027 0200251D
	s_waitcnt lgkmcnt(2)                                       // 00000013BC7C: BF89FC27
	v_fma_mixlo_f16 v40, v30, s18, 0                           // 00000013BC80: CC210028 0200251E
	v_fma_mixhi_f16 v40, v31, s18, 0                           // 00000013BC88: CC220028 0200251F
	v_fma_mixlo_f16 v41, v32, s18, 0                           // 00000013BC90: CC210029 02002520
	v_fma_mixhi_f16 v41, v33, s18, 0                           // 00000013BC98: CC220029 02002521
	s_waitcnt lgkmcnt(1)                                       // 00000013BCA0: BF89FC17
	v_fma_mixlo_f16 v42, v42, s18, 0                           // 00000013BCA4: CC21002A 0200252A
	v_fma_mixhi_f16 v42, v43, s18, 0                           // 00000013BCAC: CC22002A 0200252B
	v_fma_mixlo_f16 v43, v44, s18, 0                           // 00000013BCB4: CC21002B 0200252C
	v_fma_mixhi_f16 v43, v45, s18, 0                           // 00000013BCBC: CC22002B 0200252D
	s_waitcnt lgkmcnt(0)                                       // 00000013BCC4: BF89FC07
	v_fma_mixlo_f16 v44, v46, s18, 0                           // 00000013BCC8: CC21002C 0200252E
	v_fma_mixhi_f16 v44, v47, s18, 0                           // 00000013BCD0: CC22002C 0200252F
	v_fma_mixlo_f16 v45, v48, s18, 0                           // 00000013BCD8: CC21002D 02002530
	v_fma_mixhi_f16 v45, v49, s18, 0                           // 00000013BCE0: CC22002D 02002531
	.long 0x7f343880                                           // 00000013BCE8: 7F343880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013BCEC: BF870112
	v_wmma_f32_16x16x16_f16 v[10:17], v[18:25], v[38:45], v[10:17]// 00000013BCF0: CC40400A 1C2A4D12
	.long 0x7e34399a                                           // 00000013BCF8: 7E34399A
	s_and_saveexec_b32 s1, s0                                  // 00000013BCFC: BE812000
	s_cbranch_execz 5                                          // 00000013BD00: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1018>
	global_load_b32 v18, v[36:37], off offset:192              // 00000013BD04: DC5200C0 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BD0C: BF8903F7
	v_fma_mixlo_f16 v26, v18, s18, 0                           // 00000013BD10: CC21001A 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BD18: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BD1C: BE812000
	s_cbranch_execz 5                                          // 00000013BD20: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1038>
	global_load_b32 v18, v[36:37], off offset:196              // 00000013BD24: DC5200C4 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BD2C: BF8903F7
	v_fma_mixhi_f16 v26, v18, s18, 0                           // 00000013BD30: CC22001A 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BD38: 8C7E017E
	.long 0x7f363880                                           // 00000013BD3C: 7F363880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013BD40: BF870001
	.long 0x7e36399b                                           // 00000013BD44: 7E36399B
	s_and_saveexec_b32 s1, s0                                  // 00000013BD48: BE812000
	s_cbranch_execz 5                                          // 00000013BD4C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1064>
	global_load_b32 v18, v[36:37], off offset:200              // 00000013BD50: DC5200C8 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BD58: BF8903F7
	v_fma_mixlo_f16 v27, v18, s18, 0                           // 00000013BD5C: CC21001B 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BD64: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BD68: BE812000
	s_cbranch_execz 5                                          // 00000013BD6C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1084>
	global_load_b32 v18, v[36:37], off offset:204              // 00000013BD70: DC5200CC 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BD78: BF8903F7
	v_fma_mixhi_f16 v27, v18, s18, 0                           // 00000013BD7C: CC22001B 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BD84: 8C7E017E
	.long 0x7f383880                                           // 00000013BD88: 7F383880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013BD8C: BF870001
	.long 0x7e38399c                                           // 00000013BD90: 7E38399C
	s_and_saveexec_b32 s1, s0                                  // 00000013BD94: BE812000
	s_cbranch_execz 5                                          // 00000013BD98: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10b0>
	global_load_b32 v18, v[36:37], off offset:208              // 00000013BD9C: DC5200D0 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BDA4: BF8903F7
	v_fma_mixlo_f16 v28, v18, s18, 0                           // 00000013BDA8: CC21001C 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BDB0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BDB4: BE812000
	s_cbranch_execz 5                                          // 00000013BDB8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10d0>
	global_load_b32 v18, v[36:37], off offset:212              // 00000013BDBC: DC5200D4 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BDC4: BF8903F7
	v_fma_mixhi_f16 v28, v18, s18, 0                           // 00000013BDC8: CC22001C 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BDD0: 8C7E017E
	.long 0x7f3a3880                                           // 00000013BDD4: 7F3A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013BDD8: BF870001
	.long 0x7e3a399d                                           // 00000013BDDC: 7E3A399D
	s_and_saveexec_b32 s1, s0                                  // 00000013BDE0: BE812000
	s_cbranch_execz 5                                          // 00000013BDE4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10fc>
	global_load_b32 v18, v[36:37], off offset:216              // 00000013BDE8: DC5200D8 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BDF0: BF8903F7
	v_fma_mixlo_f16 v29, v18, s18, 0                           // 00000013BDF4: CC21001D 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BDFC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BE00: BE812000
	s_cbranch_execz 5                                          // 00000013BE04: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x111c>
	global_load_b32 v18, v[36:37], off offset:220              // 00000013BE08: DC5200DC 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BE10: BF8903F7
	v_fma_mixhi_f16 v29, v18, s18, 0                           // 00000013BE14: CC22001D 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BE1C: 8C7E017E
	.long 0x7f3c3880                                           // 00000013BE20: 7F3C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013BE24: BF870001
	.long 0x7e3c399e                                           // 00000013BE28: 7E3C399E
	s_and_saveexec_b32 s1, s0                                  // 00000013BE2C: BE812000
	s_cbranch_execz 5                                          // 00000013BE30: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1148>
	global_load_b32 v18, v[36:37], off offset:224              // 00000013BE34: DC5200E0 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BE3C: BF8903F7
	v_fma_mixlo_f16 v30, v18, s18, 0                           // 00000013BE40: CC21001E 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BE48: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BE4C: BE812000
	s_cbranch_execz 5                                          // 00000013BE50: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1168>
	global_load_b32 v18, v[36:37], off offset:228              // 00000013BE54: DC5200E4 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BE5C: BF8903F7
	v_fma_mixhi_f16 v30, v18, s18, 0                           // 00000013BE60: CC22001E 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BE68: 8C7E017E
	.long 0x7f3e3880                                           // 00000013BE6C: 7F3E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013BE70: BF870001
	.long 0x7e3e399f                                           // 00000013BE74: 7E3E399F
	s_and_saveexec_b32 s1, s0                                  // 00000013BE78: BE812000
	s_cbranch_execz 5                                          // 00000013BE7C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1194>
	global_load_b32 v18, v[36:37], off offset:232              // 00000013BE80: DC5200E8 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BE88: BF8903F7
	v_fma_mixlo_f16 v31, v18, s18, 0                           // 00000013BE8C: CC21001F 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BE94: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BE98: BE812000
	s_cbranch_execz 5                                          // 00000013BE9C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11b4>
	global_load_b32 v18, v[36:37], off offset:236              // 00000013BEA0: DC5200EC 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BEA8: BF8903F7
	v_fma_mixhi_f16 v31, v18, s18, 0                           // 00000013BEAC: CC22001F 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BEB4: 8C7E017E
	.long 0x7f403880                                           // 00000013BEB8: 7F403880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013BEBC: BF870001
	.long 0x7e4039a0                                           // 00000013BEC0: 7E4039A0
	s_and_saveexec_b32 s1, s0                                  // 00000013BEC4: BE812000
	s_cbranch_execz 5                                          // 00000013BEC8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11e0>
	global_load_b32 v18, v[36:37], off offset:240              // 00000013BECC: DC5200F0 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BED4: BF8903F7
	v_fma_mixlo_f16 v32, v18, s18, 0                           // 00000013BED8: CC210020 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BEE0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BEE4: BE812000
	s_cbranch_execz 5                                          // 00000013BEE8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1200>
	global_load_b32 v18, v[36:37], off offset:244              // 00000013BEEC: DC5200F4 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BEF4: BF8903F7
	v_fma_mixhi_f16 v32, v18, s18, 0                           // 00000013BEF8: CC220020 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BF00: 8C7E017E
	.long 0x7f423880                                           // 00000013BF04: 7F423880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013BF08: BF870001
	.long 0x7e4239a1                                           // 00000013BF0C: 7E4239A1
	s_and_saveexec_b32 s1, s0                                  // 00000013BF10: BE812000
	s_cbranch_execz 5                                          // 00000013BF14: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x122c>
	global_load_b32 v18, v[36:37], off offset:248              // 00000013BF18: DC5200F8 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BF20: BF8903F7
	v_fma_mixlo_f16 v33, v18, s18, 0                           // 00000013BF24: CC210021 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BF2C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013BF30: BE812000
	s_cbranch_execz 5                                          // 00000013BF34: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x124c>
	global_load_b32 v18, v[36:37], off offset:252              // 00000013BF38: DC5200FC 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013BF40: BF8903F7
	v_fma_mixhi_f16 v33, v18, s18, 0                           // 00000013BF44: CC220021 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013BF4C: 8C7E017E
	ds_load_b128 v[18:21], v57 offset:192                      // 00000013BF50: DBFC00C0 12000039
	ds_load_b128 v[22:25], v57 offset:208                      // 00000013BF58: DBFC00D0 16000039
	ds_load_b128 v[42:45], v57 offset:224                      // 00000013BF60: DBFC00E0 2A000039
	ds_load_b128 v[46:49], v57 offset:240                      // 00000013BF68: DBFC00F0 2E000039
	s_waitcnt lgkmcnt(3)                                       // 00000013BF70: BF89FC37
	v_fma_mixlo_f16 v38, v18, s18, 0                           // 00000013BF74: CC210026 02002512
	v_fma_mixhi_f16 v38, v19, s18, 0                           // 00000013BF7C: CC220026 02002513
	v_fma_mixlo_f16 v39, v20, s18, 0                           // 00000013BF84: CC210027 02002514
	v_fma_mixhi_f16 v39, v21, s18, 0                           // 00000013BF8C: CC220027 02002515
	s_waitcnt lgkmcnt(2)                                       // 00000013BF94: BF89FC27
	v_fma_mixlo_f16 v40, v22, s18, 0                           // 00000013BF98: CC210028 02002516
	v_fma_mixhi_f16 v40, v23, s18, 0                           // 00000013BFA0: CC220028 02002517
	v_fma_mixlo_f16 v41, v24, s18, 0                           // 00000013BFA8: CC210029 02002518
	v_fma_mixhi_f16 v41, v25, s18, 0                           // 00000013BFB0: CC220029 02002519
	s_waitcnt lgkmcnt(1)                                       // 00000013BFB8: BF89FC17
	v_fma_mixlo_f16 v42, v42, s18, 0                           // 00000013BFBC: CC21002A 0200252A
	v_fma_mixhi_f16 v42, v43, s18, 0                           // 00000013BFC4: CC22002A 0200252B
	v_fma_mixlo_f16 v43, v44, s18, 0                           // 00000013BFCC: CC21002B 0200252C
	v_fma_mixhi_f16 v43, v45, s18, 0                           // 00000013BFD4: CC22002B 0200252D
	s_waitcnt lgkmcnt(0)                                       // 00000013BFDC: BF89FC07
	v_fma_mixlo_f16 v44, v46, s18, 0                           // 00000013BFE0: CC21002C 0200252E
	v_fma_mixhi_f16 v44, v47, s18, 0                           // 00000013BFE8: CC22002C 0200252F
	v_fma_mixlo_f16 v45, v48, s18, 0                           // 00000013BFF0: CC21002D 02002530
	v_fma_mixhi_f16 v45, v49, s18, 0                           // 00000013BFF8: CC22002D 02002531
	.long 0x7f243880                                           // 00000013C000: 7F243880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013C004: BF870112
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[38:45], v[10:17]// 00000013C008: CC40400A 1C2A4D1A
	.long 0x7e243992                                           // 00000013C010: 7E243992
	s_and_saveexec_b32 s1, s0                                  // 00000013C014: BE812000
	s_cbranch_execz 5                                          // 00000013C018: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1330>
	global_load_b32 v19, v[36:37], off offset:256              // 00000013C01C: DC520100 137C0024
	s_waitcnt vmcnt(0)                                         // 00000013C024: BF8903F7
	v_fma_mixlo_f16 v18, v19, s18, 0                           // 00000013C028: CC210012 02002513
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C030: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C034: BE812000
	s_cbranch_execz 5                                          // 00000013C038: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1350>
	global_load_b32 v19, v[36:37], off offset:260              // 00000013C03C: DC520104 137C0024
	s_waitcnt vmcnt(0)                                         // 00000013C044: BF8903F7
	v_fma_mixhi_f16 v18, v19, s18, 0                           // 00000013C048: CC220012 02002513
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C050: 8C7E017E
	.long 0x7f263880                                           // 00000013C054: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C058: BF870001
	.long 0x7e263993                                           // 00000013C05C: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000013C060: BE812000
	s_cbranch_execz 5                                          // 00000013C064: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x137c>
	global_load_b32 v20, v[36:37], off offset:264              // 00000013C068: DC520108 147C0024
	s_waitcnt vmcnt(0)                                         // 00000013C070: BF8903F7
	v_fma_mixlo_f16 v19, v20, s18, 0                           // 00000013C074: CC210013 02002514
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C07C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C080: BE812000
	s_cbranch_execz 5                                          // 00000013C084: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x139c>
	global_load_b32 v20, v[36:37], off offset:268              // 00000013C088: DC52010C 147C0024
	s_waitcnt vmcnt(0)                                         // 00000013C090: BF8903F7
	v_fma_mixhi_f16 v19, v20, s18, 0                           // 00000013C094: CC220013 02002514
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C09C: 8C7E017E
	.long 0x7f283880                                           // 00000013C0A0: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C0A4: BF870001
	.long 0x7e283994                                           // 00000013C0A8: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000013C0AC: BE812000
	s_cbranch_execz 5                                          // 00000013C0B0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13c8>
	global_load_b32 v21, v[36:37], off offset:272              // 00000013C0B4: DC520110 157C0024
	s_waitcnt vmcnt(0)                                         // 00000013C0BC: BF8903F7
	v_fma_mixlo_f16 v20, v21, s18, 0                           // 00000013C0C0: CC210014 02002515
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C0C8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C0CC: BE812000
	s_cbranch_execz 5                                          // 00000013C0D0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13e8>
	global_load_b32 v21, v[36:37], off offset:276              // 00000013C0D4: DC520114 157C0024
	s_waitcnt vmcnt(0)                                         // 00000013C0DC: BF8903F7
	v_fma_mixhi_f16 v20, v21, s18, 0                           // 00000013C0E0: CC220014 02002515
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C0E8: 8C7E017E
	.long 0x7f2a3880                                           // 00000013C0EC: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C0F0: BF870001
	.long 0x7e2a3995                                           // 00000013C0F4: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000013C0F8: BE812000
	s_cbranch_execz 5                                          // 00000013C0FC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1414>
	global_load_b32 v22, v[36:37], off offset:280              // 00000013C100: DC520118 167C0024
	s_waitcnt vmcnt(0)                                         // 00000013C108: BF8903F7
	v_fma_mixlo_f16 v21, v22, s18, 0                           // 00000013C10C: CC210015 02002516
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C114: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C118: BE812000
	s_cbranch_execz 5                                          // 00000013C11C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1434>
	global_load_b32 v22, v[36:37], off offset:284              // 00000013C120: DC52011C 167C0024
	s_waitcnt vmcnt(0)                                         // 00000013C128: BF8903F7
	v_fma_mixhi_f16 v21, v22, s18, 0                           // 00000013C12C: CC220015 02002516
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C134: 8C7E017E
	.long 0x7f2c3880                                           // 00000013C138: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C13C: BF870001
	.long 0x7e2c3996                                           // 00000013C140: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000013C144: BE812000
	s_cbranch_execz 5                                          // 00000013C148: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1460>
	global_load_b32 v23, v[36:37], off offset:288              // 00000013C14C: DC520120 177C0024
	s_waitcnt vmcnt(0)                                         // 00000013C154: BF8903F7
	v_fma_mixlo_f16 v22, v23, s18, 0                           // 00000013C158: CC210016 02002517
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C160: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C164: BE812000
	s_cbranch_execz 5                                          // 00000013C168: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1480>
	global_load_b32 v23, v[36:37], off offset:292              // 00000013C16C: DC520124 177C0024
	s_waitcnt vmcnt(0)                                         // 00000013C174: BF8903F7
	v_fma_mixhi_f16 v22, v23, s18, 0                           // 00000013C178: CC220016 02002517
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C180: 8C7E017E
	.long 0x7f2e3880                                           // 00000013C184: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C188: BF870001
	.long 0x7e2e3997                                           // 00000013C18C: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000013C190: BE812000
	s_cbranch_execz 5                                          // 00000013C194: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14ac>
	global_load_b32 v24, v[36:37], off offset:296              // 00000013C198: DC520128 187C0024
	s_waitcnt vmcnt(0)                                         // 00000013C1A0: BF8903F7
	v_fma_mixlo_f16 v23, v24, s18, 0                           // 00000013C1A4: CC210017 02002518
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C1AC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C1B0: BE812000
	s_cbranch_execz 5                                          // 00000013C1B4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14cc>
	global_load_b32 v24, v[36:37], off offset:300              // 00000013C1B8: DC52012C 187C0024
	s_waitcnt vmcnt(0)                                         // 00000013C1C0: BF8903F7
	v_fma_mixhi_f16 v23, v24, s18, 0                           // 00000013C1C4: CC220017 02002518
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C1CC: 8C7E017E
	.long 0x7f303880                                           // 00000013C1D0: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C1D4: BF870001
	.long 0x7e303998                                           // 00000013C1D8: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000013C1DC: BE812000
	s_cbranch_execz 5                                          // 00000013C1E0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14f8>
	global_load_b32 v25, v[36:37], off offset:304              // 00000013C1E4: DC520130 197C0024
	s_waitcnt vmcnt(0)                                         // 00000013C1EC: BF8903F7
	v_fma_mixlo_f16 v24, v25, s18, 0                           // 00000013C1F0: CC210018 02002519
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C1F8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C1FC: BE812000
	s_cbranch_execz 5                                          // 00000013C200: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1518>
	global_load_b32 v25, v[36:37], off offset:308              // 00000013C204: DC520134 197C0024
	s_waitcnt vmcnt(0)                                         // 00000013C20C: BF8903F7
	v_fma_mixhi_f16 v24, v25, s18, 0                           // 00000013C210: CC220018 02002519
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C218: 8C7E017E
	.long 0x7f323880                                           // 00000013C21C: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C220: BF870001
	.long 0x7e323999                                           // 00000013C224: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000013C228: BE812000
	s_cbranch_execz 5                                          // 00000013C22C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1544>
	global_load_b32 v26, v[36:37], off offset:312              // 00000013C230: DC520138 1A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013C238: BF8903F7
	v_fma_mixlo_f16 v25, v26, s18, 0                           // 00000013C23C: CC210019 0200251A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C244: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C248: BE812000
	s_cbranch_execz 5                                          // 00000013C24C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1564>
	global_load_b32 v26, v[36:37], off offset:316              // 00000013C250: DC52013C 1A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013C258: BF8903F7
	v_fma_mixhi_f16 v25, v26, s18, 0                           // 00000013C25C: CC220019 0200251A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C264: 8C7E017E
	ds_load_b128 v[26:29], v57 offset:256                      // 00000013C268: DBFC0100 1A000039
	ds_load_b128 v[30:33], v57 offset:272                      // 00000013C270: DBFC0110 1E000039
	ds_load_b128 v[42:45], v57 offset:288                      // 00000013C278: DBFC0120 2A000039
	ds_load_b128 v[46:49], v57 offset:304                      // 00000013C280: DBFC0130 2E000039
	s_waitcnt lgkmcnt(3)                                       // 00000013C288: BF89FC37
	v_fma_mixlo_f16 v38, v26, s18, 0                           // 00000013C28C: CC210026 0200251A
	v_fma_mixhi_f16 v38, v27, s18, 0                           // 00000013C294: CC220026 0200251B
	v_fma_mixlo_f16 v39, v28, s18, 0                           // 00000013C29C: CC210027 0200251C
	v_fma_mixhi_f16 v39, v29, s18, 0                           // 00000013C2A4: CC220027 0200251D
	s_waitcnt lgkmcnt(2)                                       // 00000013C2AC: BF89FC27
	v_fma_mixlo_f16 v40, v30, s18, 0                           // 00000013C2B0: CC210028 0200251E
	v_fma_mixhi_f16 v40, v31, s18, 0                           // 00000013C2B8: CC220028 0200251F
	v_fma_mixlo_f16 v41, v32, s18, 0                           // 00000013C2C0: CC210029 02002520
	v_fma_mixhi_f16 v41, v33, s18, 0                           // 00000013C2C8: CC220029 02002521
	s_waitcnt lgkmcnt(1)                                       // 00000013C2D0: BF89FC17
	v_fma_mixlo_f16 v42, v42, s18, 0                           // 00000013C2D4: CC21002A 0200252A
	v_fma_mixhi_f16 v42, v43, s18, 0                           // 00000013C2DC: CC22002A 0200252B
	v_fma_mixlo_f16 v43, v44, s18, 0                           // 00000013C2E4: CC21002B 0200252C
	v_fma_mixhi_f16 v43, v45, s18, 0                           // 00000013C2EC: CC22002B 0200252D
	s_waitcnt lgkmcnt(0)                                       // 00000013C2F4: BF89FC07
	v_fma_mixlo_f16 v44, v46, s18, 0                           // 00000013C2F8: CC21002C 0200252E
	v_fma_mixhi_f16 v44, v47, s18, 0                           // 00000013C300: CC22002C 0200252F
	v_fma_mixlo_f16 v45, v48, s18, 0                           // 00000013C308: CC21002D 02002530
	v_fma_mixhi_f16 v45, v49, s18, 0                           // 00000013C310: CC22002D 02002531
	.long 0x7f343880                                           // 00000013C318: 7F343880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013C31C: BF870112
	v_wmma_f32_16x16x16_f16 v[10:17], v[18:25], v[38:45], v[10:17]// 00000013C320: CC40400A 1C2A4D12
	.long 0x7e34399a                                           // 00000013C328: 7E34399A
	s_and_saveexec_b32 s1, s0                                  // 00000013C32C: BE812000
	s_cbranch_execz 5                                          // 00000013C330: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1648>
	global_load_b32 v18, v[36:37], off offset:320              // 00000013C334: DC520140 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C33C: BF8903F7
	v_fma_mixlo_f16 v26, v18, s18, 0                           // 00000013C340: CC21001A 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C348: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C34C: BE812000
	s_cbranch_execz 5                                          // 00000013C350: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1668>
	global_load_b32 v18, v[36:37], off offset:324              // 00000013C354: DC520144 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C35C: BF8903F7
	v_fma_mixhi_f16 v26, v18, s18, 0                           // 00000013C360: CC22001A 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C368: 8C7E017E
	.long 0x7f363880                                           // 00000013C36C: 7F363880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C370: BF870001
	.long 0x7e36399b                                           // 00000013C374: 7E36399B
	s_and_saveexec_b32 s1, s0                                  // 00000013C378: BE812000
	s_cbranch_execz 5                                          // 00000013C37C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1694>
	global_load_b32 v18, v[36:37], off offset:328              // 00000013C380: DC520148 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C388: BF8903F7
	v_fma_mixlo_f16 v27, v18, s18, 0                           // 00000013C38C: CC21001B 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C394: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C398: BE812000
	s_cbranch_execz 5                                          // 00000013C39C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16b4>
	global_load_b32 v18, v[36:37], off offset:332              // 00000013C3A0: DC52014C 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C3A8: BF8903F7
	v_fma_mixhi_f16 v27, v18, s18, 0                           // 00000013C3AC: CC22001B 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C3B4: 8C7E017E
	.long 0x7f383880                                           // 00000013C3B8: 7F383880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C3BC: BF870001
	.long 0x7e38399c                                           // 00000013C3C0: 7E38399C
	s_and_saveexec_b32 s1, s0                                  // 00000013C3C4: BE812000
	s_cbranch_execz 5                                          // 00000013C3C8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16e0>
	global_load_b32 v18, v[36:37], off offset:336              // 00000013C3CC: DC520150 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C3D4: BF8903F7
	v_fma_mixlo_f16 v28, v18, s18, 0                           // 00000013C3D8: CC21001C 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C3E0: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C3E4: BE812000
	s_cbranch_execz 5                                          // 00000013C3E8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1700>
	global_load_b32 v18, v[36:37], off offset:340              // 00000013C3EC: DC520154 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C3F4: BF8903F7
	v_fma_mixhi_f16 v28, v18, s18, 0                           // 00000013C3F8: CC22001C 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C400: 8C7E017E
	.long 0x7f3a3880                                           // 00000013C404: 7F3A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C408: BF870001
	.long 0x7e3a399d                                           // 00000013C40C: 7E3A399D
	s_and_saveexec_b32 s1, s0                                  // 00000013C410: BE812000
	s_cbranch_execz 5                                          // 00000013C414: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x172c>
	global_load_b32 v18, v[36:37], off offset:344              // 00000013C418: DC520158 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C420: BF8903F7
	v_fma_mixlo_f16 v29, v18, s18, 0                           // 00000013C424: CC21001D 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C42C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C430: BE812000
	s_cbranch_execz 5                                          // 00000013C434: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x174c>
	global_load_b32 v18, v[36:37], off offset:348              // 00000013C438: DC52015C 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C440: BF8903F7
	v_fma_mixhi_f16 v29, v18, s18, 0                           // 00000013C444: CC22001D 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C44C: 8C7E017E
	.long 0x7f3c3880                                           // 00000013C450: 7F3C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C454: BF870001
	.long 0x7e3c399e                                           // 00000013C458: 7E3C399E
	s_and_saveexec_b32 s1, s0                                  // 00000013C45C: BE812000
	s_cbranch_execz 5                                          // 00000013C460: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1778>
	global_load_b32 v18, v[36:37], off offset:352              // 00000013C464: DC520160 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C46C: BF8903F7
	v_fma_mixlo_f16 v30, v18, s18, 0                           // 00000013C470: CC21001E 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C478: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C47C: BE812000
	s_cbranch_execz 5                                          // 00000013C480: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1798>
	global_load_b32 v18, v[36:37], off offset:356              // 00000013C484: DC520164 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C48C: BF8903F7
	v_fma_mixhi_f16 v30, v18, s18, 0                           // 00000013C490: CC22001E 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C498: 8C7E017E
	.long 0x7f3e3880                                           // 00000013C49C: 7F3E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C4A0: BF870001
	.long 0x7e3e399f                                           // 00000013C4A4: 7E3E399F
	s_and_saveexec_b32 s1, s0                                  // 00000013C4A8: BE812000
	s_cbranch_execz 5                                          // 00000013C4AC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17c4>
	global_load_b32 v18, v[36:37], off offset:360              // 00000013C4B0: DC520168 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C4B8: BF8903F7
	v_fma_mixlo_f16 v31, v18, s18, 0                           // 00000013C4BC: CC21001F 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C4C4: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C4C8: BE812000
	s_cbranch_execz 5                                          // 00000013C4CC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17e4>
	global_load_b32 v18, v[36:37], off offset:364              // 00000013C4D0: DC52016C 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C4D8: BF8903F7
	v_fma_mixhi_f16 v31, v18, s18, 0                           // 00000013C4DC: CC22001F 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C4E4: 8C7E017E
	.long 0x7f403880                                           // 00000013C4E8: 7F403880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C4EC: BF870001
	.long 0x7e4039a0                                           // 00000013C4F0: 7E4039A0
	s_and_saveexec_b32 s1, s0                                  // 00000013C4F4: BE812000
	s_cbranch_execz 5                                          // 00000013C4F8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1810>
	global_load_b32 v18, v[36:37], off offset:368              // 00000013C4FC: DC520170 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C504: BF8903F7
	v_fma_mixlo_f16 v32, v18, s18, 0                           // 00000013C508: CC210020 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C510: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C514: BE812000
	s_cbranch_execz 5                                          // 00000013C518: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1830>
	global_load_b32 v18, v[36:37], off offset:372              // 00000013C51C: DC520174 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C524: BF8903F7
	v_fma_mixhi_f16 v32, v18, s18, 0                           // 00000013C528: CC220020 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C530: 8C7E017E
	.long 0x7f423880                                           // 00000013C534: 7F423880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C538: BF870001
	.long 0x7e4239a1                                           // 00000013C53C: 7E4239A1
	s_and_saveexec_b32 s1, s0                                  // 00000013C540: BE812000
	s_cbranch_execz 5                                          // 00000013C544: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x185c>
	global_load_b32 v18, v[36:37], off offset:376              // 00000013C548: DC520178 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C550: BF8903F7
	v_fma_mixlo_f16 v33, v18, s18, 0                           // 00000013C554: CC210021 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C55C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C560: BE812000
	s_cbranch_execz 5                                          // 00000013C564: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x187c>
	global_load_b32 v18, v[36:37], off offset:380              // 00000013C568: DC52017C 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C570: BF8903F7
	v_fma_mixhi_f16 v33, v18, s18, 0                           // 00000013C574: CC220021 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C57C: 8C7E017E
	ds_load_b128 v[18:21], v57 offset:320                      // 00000013C580: DBFC0140 12000039
	ds_load_b128 v[22:25], v57 offset:336                      // 00000013C588: DBFC0150 16000039
	ds_load_b128 v[42:45], v57 offset:352                      // 00000013C590: DBFC0160 2A000039
	ds_load_b128 v[46:49], v57 offset:368                      // 00000013C598: DBFC0170 2E000039
	s_waitcnt lgkmcnt(3)                                       // 00000013C5A0: BF89FC37
	v_fma_mixlo_f16 v38, v18, s18, 0                           // 00000013C5A4: CC210026 02002512
	v_fma_mixhi_f16 v38, v19, s18, 0                           // 00000013C5AC: CC220026 02002513
	v_fma_mixlo_f16 v39, v20, s18, 0                           // 00000013C5B4: CC210027 02002514
	v_fma_mixhi_f16 v39, v21, s18, 0                           // 00000013C5BC: CC220027 02002515
	s_waitcnt lgkmcnt(2)                                       // 00000013C5C4: BF89FC27
	v_fma_mixlo_f16 v40, v22, s18, 0                           // 00000013C5C8: CC210028 02002516
	v_fma_mixhi_f16 v40, v23, s18, 0                           // 00000013C5D0: CC220028 02002517
	v_fma_mixlo_f16 v41, v24, s18, 0                           // 00000013C5D8: CC210029 02002518
	v_fma_mixhi_f16 v41, v25, s18, 0                           // 00000013C5E0: CC220029 02002519
	s_waitcnt lgkmcnt(1)                                       // 00000013C5E8: BF89FC17
	v_fma_mixlo_f16 v42, v42, s18, 0                           // 00000013C5EC: CC21002A 0200252A
	v_fma_mixhi_f16 v42, v43, s18, 0                           // 00000013C5F4: CC22002A 0200252B
	v_fma_mixlo_f16 v43, v44, s18, 0                           // 00000013C5FC: CC21002B 0200252C
	v_fma_mixhi_f16 v43, v45, s18, 0                           // 00000013C604: CC22002B 0200252D
	s_waitcnt lgkmcnt(0)                                       // 00000013C60C: BF89FC07
	v_fma_mixlo_f16 v44, v46, s18, 0                           // 00000013C610: CC21002C 0200252E
	v_fma_mixhi_f16 v44, v47, s18, 0                           // 00000013C618: CC22002C 0200252F
	v_fma_mixlo_f16 v45, v48, s18, 0                           // 00000013C620: CC21002D 02002530
	v_fma_mixhi_f16 v45, v49, s18, 0                           // 00000013C628: CC22002D 02002531
	.long 0x7f263880                                           // 00000013C630: 7F263880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013C634: BF870112
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[38:45], v[10:17]// 00000013C638: CC40400A 1C2A4D1A
	.long 0x7e263993                                           // 00000013C640: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000013C644: BE812000
	s_cbranch_execz 5                                          // 00000013C648: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1960>
	global_load_b32 v18, v[36:37], off offset:384              // 00000013C64C: DC520180 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C654: BF8903F7
	v_fma_mixlo_f16 v19, v18, s18, 0                           // 00000013C658: CC210013 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C660: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C664: BE812000
	s_cbranch_execz 5                                          // 00000013C668: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1980>
	global_load_b32 v18, v[36:37], off offset:388              // 00000013C66C: DC520184 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C674: BF8903F7
	v_fma_mixhi_f16 v19, v18, s18, 0                           // 00000013C678: CC220013 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C680: 8C7E017E
	.long 0x7f283880                                           // 00000013C684: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C688: BF870001
	.long 0x7e283994                                           // 00000013C68C: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000013C690: BE812000
	s_cbranch_execz 5                                          // 00000013C694: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19ac>
	global_load_b32 v18, v[36:37], off offset:392              // 00000013C698: DC520188 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C6A0: BF8903F7
	v_fma_mixlo_f16 v20, v18, s18, 0                           // 00000013C6A4: CC210014 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C6AC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C6B0: BE812000
	s_cbranch_execz 5                                          // 00000013C6B4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19cc>
	global_load_b32 v18, v[36:37], off offset:396              // 00000013C6B8: DC52018C 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C6C0: BF8903F7
	v_fma_mixhi_f16 v20, v18, s18, 0                           // 00000013C6C4: CC220014 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C6CC: 8C7E017E
	.long 0x7f2a3880                                           // 00000013C6D0: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C6D4: BF870001
	.long 0x7e2a3995                                           // 00000013C6D8: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000013C6DC: BE812000
	s_cbranch_execz 5                                          // 00000013C6E0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x19f8>
	global_load_b32 v18, v[36:37], off offset:400              // 00000013C6E4: DC520190 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C6EC: BF8903F7
	v_fma_mixlo_f16 v21, v18, s18, 0                           // 00000013C6F0: CC210015 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C6F8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C6FC: BE812000
	s_cbranch_execz 5                                          // 00000013C700: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a18>
	global_load_b32 v18, v[36:37], off offset:404              // 00000013C704: DC520194 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C70C: BF8903F7
	v_fma_mixhi_f16 v21, v18, s18, 0                           // 00000013C710: CC220015 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C718: 8C7E017E
	.long 0x7f2c3880                                           // 00000013C71C: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C720: BF870001
	.long 0x7e2c3996                                           // 00000013C724: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000013C728: BE812000
	s_cbranch_execz 5                                          // 00000013C72C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a44>
	global_load_b32 v18, v[36:37], off offset:408              // 00000013C730: DC520198 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C738: BF8903F7
	v_fma_mixlo_f16 v22, v18, s18, 0                           // 00000013C73C: CC210016 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C744: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C748: BE812000
	s_cbranch_execz 5                                          // 00000013C74C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a64>
	global_load_b32 v18, v[36:37], off offset:412              // 00000013C750: DC52019C 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C758: BF8903F7
	v_fma_mixhi_f16 v22, v18, s18, 0                           // 00000013C75C: CC220016 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C764: 8C7E017E
	.long 0x7f2e3880                                           // 00000013C768: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C76C: BF870001
	.long 0x7e2e3997                                           // 00000013C770: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000013C774: BE812000
	s_cbranch_execz 5                                          // 00000013C778: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a90>
	global_load_b32 v18, v[36:37], off offset:416              // 00000013C77C: DC5201A0 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C784: BF8903F7
	v_fma_mixlo_f16 v23, v18, s18, 0                           // 00000013C788: CC210017 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C790: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C794: BE812000
	s_cbranch_execz 5                                          // 00000013C798: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ab0>
	global_load_b32 v18, v[36:37], off offset:420              // 00000013C79C: DC5201A4 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C7A4: BF8903F7
	v_fma_mixhi_f16 v23, v18, s18, 0                           // 00000013C7A8: CC220017 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C7B0: 8C7E017E
	.long 0x7f303880                                           // 00000013C7B4: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C7B8: BF870001
	.long 0x7e303998                                           // 00000013C7BC: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000013C7C0: BE812000
	s_cbranch_execz 5                                          // 00000013C7C4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1adc>
	global_load_b32 v18, v[36:37], off offset:424              // 00000013C7C8: DC5201A8 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C7D0: BF8903F7
	v_fma_mixlo_f16 v24, v18, s18, 0                           // 00000013C7D4: CC210018 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C7DC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C7E0: BE812000
	s_cbranch_execz 5                                          // 00000013C7E4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1afc>
	global_load_b32 v18, v[36:37], off offset:428              // 00000013C7E8: DC5201AC 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C7F0: BF8903F7
	v_fma_mixhi_f16 v24, v18, s18, 0                           // 00000013C7F4: CC220018 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C7FC: 8C7E017E
	.long 0x7f323880                                           // 00000013C800: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C804: BF870001
	.long 0x7e323999                                           // 00000013C808: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000013C80C: BE812000
	s_cbranch_execz 5                                          // 00000013C810: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b28>
	global_load_b32 v18, v[36:37], off offset:432              // 00000013C814: DC5201B0 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C81C: BF8903F7
	v_fma_mixlo_f16 v25, v18, s18, 0                           // 00000013C820: CC210019 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C828: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C82C: BE812000
	s_cbranch_execz 5                                          // 00000013C830: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b48>
	global_load_b32 v18, v[36:37], off offset:436              // 00000013C834: DC5201B4 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C83C: BF8903F7
	v_fma_mixhi_f16 v25, v18, s18, 0                           // 00000013C840: CC220019 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C848: 8C7E017E
	.long 0x7f343880                                           // 00000013C84C: 7F343880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C850: BF870001
	.long 0x7e34399a                                           // 00000013C854: 7E34399A
	s_and_saveexec_b32 s1, s0                                  // 00000013C858: BE812000
	s_cbranch_execz 5                                          // 00000013C85C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b74>
	global_load_b32 v18, v[36:37], off offset:440              // 00000013C860: DC5201B8 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C868: BF8903F7
	v_fma_mixlo_f16 v26, v18, s18, 0                           // 00000013C86C: CC21001A 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C874: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C878: BE812000
	s_cbranch_execz 5                                          // 00000013C87C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b94>
	global_load_b32 v18, v[36:37], off offset:444              // 00000013C880: DC5201BC 127C0024
	s_waitcnt vmcnt(0)                                         // 00000013C888: BF8903F7
	v_fma_mixhi_f16 v26, v18, s18, 0                           // 00000013C88C: CC22001A 02002512
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C894: 8C7E017E
	ds_load_b128 v[27:30], v57 offset:384                      // 00000013C898: DBFC0180 1B000039
	ds_load_b128 v[40:43], v57 offset:400                      // 00000013C8A0: DBFC0190 28000039
	ds_load_b128 v[44:47], v57 offset:416                      // 00000013C8A8: DBFC01A0 2C000039
	ds_load_b128 v[78:81], v57 offset:432                      // 00000013C8B0: DBFC01B0 4E000039
	.long 0x7f243880                                           // 00000013C8B8: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C8BC: BF870001
	.long 0x7e243992                                           // 00000013C8C0: 7E243992
	s_waitcnt lgkmcnt(3)                                       // 00000013C8C4: BF89FC37
	v_fma_mixlo_f16 v38, v27, s18, 0                           // 00000013C8C8: CC210026 0200251B
	v_fma_mixhi_f16 v38, v28, s18, 0                           // 00000013C8D0: CC220026 0200251C
	v_fma_mixlo_f16 v39, v29, s18, 0                           // 00000013C8D8: CC210027 0200251D
	v_fma_mixhi_f16 v39, v30, s18, 0                           // 00000013C8E0: CC220027 0200251E
	s_waitcnt lgkmcnt(2)                                       // 00000013C8E8: BF89FC27
	v_fma_mixlo_f16 v40, v40, s18, 0                           // 00000013C8EC: CC210028 02002528
	v_fma_mixhi_f16 v40, v41, s18, 0                           // 00000013C8F4: CC220028 02002529
	v_fma_mixlo_f16 v41, v42, s18, 0                           // 00000013C8FC: CC210029 0200252A
	v_fma_mixhi_f16 v41, v43, s18, 0                           // 00000013C904: CC220029 0200252B
	s_waitcnt lgkmcnt(1)                                       // 00000013C90C: BF89FC17
	v_fma_mixlo_f16 v42, v44, s18, 0                           // 00000013C910: CC21002A 0200252C
	v_fma_mixhi_f16 v42, v45, s18, 0                           // 00000013C918: CC22002A 0200252D
	v_fma_mixlo_f16 v43, v46, s18, 0                           // 00000013C920: CC21002B 0200252E
	v_fma_mixhi_f16 v43, v47, s18, 0                           // 00000013C928: CC22002B 0200252F
	s_waitcnt lgkmcnt(0)                                       // 00000013C930: BF89FC07
	v_fma_mixlo_f16 v44, v78, s18, 0                           // 00000013C934: CC21002C 0200254E
	v_fma_mixhi_f16 v44, v79, s18, 0                           // 00000013C93C: CC22002C 0200254F
	v_fma_mixlo_f16 v45, v80, s18, 0                           // 00000013C944: CC21002D 02002550
	v_fma_mixhi_f16 v45, v81, s18, 0                           // 00000013C94C: CC22002D 02002551
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C954: BF870001
	v_wmma_f32_16x16x16_f16 v[10:17], v[19:26], v[38:45], v[10:17]// 00000013C958: CC40400A 1C2A4D13
	s_and_saveexec_b32 s1, s0                                  // 00000013C960: BE812000
	s_cbranch_execz 5                                          // 00000013C964: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c7c>
	global_load_b32 v19, v[36:37], off offset:448              // 00000013C968: DC5201C0 137C0024
	s_waitcnt vmcnt(0)                                         // 00000013C970: BF8903F7
	v_fma_mixlo_f16 v18, v19, s18, 0                           // 00000013C974: CC210012 02002513
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C97C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C980: BE812000
	s_cbranch_execz 5                                          // 00000013C984: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c9c>
	global_load_b32 v19, v[36:37], off offset:452              // 00000013C988: DC5201C4 137C0024
	s_waitcnt vmcnt(0)                                         // 00000013C990: BF8903F7
	v_fma_mixhi_f16 v18, v19, s18, 0                           // 00000013C994: CC220012 02002513
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C99C: 8C7E017E
	.long 0x7f263880                                           // 00000013C9A0: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C9A4: BF870001
	.long 0x7e263993                                           // 00000013C9A8: 7E263993
	s_and_saveexec_b32 s1, s0                                  // 00000013C9AC: BE812000
	s_cbranch_execz 5                                          // 00000013C9B0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc8>
	global_load_b32 v20, v[36:37], off offset:456              // 00000013C9B4: DC5201C8 147C0024
	s_waitcnt vmcnt(0)                                         // 00000013C9BC: BF8903F7
	v_fma_mixlo_f16 v19, v20, s18, 0                           // 00000013C9C0: CC210013 02002514
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C9C8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013C9CC: BE812000
	s_cbranch_execz 5                                          // 00000013C9D0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ce8>
	global_load_b32 v20, v[36:37], off offset:460              // 00000013C9D4: DC5201CC 147C0024
	s_waitcnt vmcnt(0)                                         // 00000013C9DC: BF8903F7
	v_fma_mixhi_f16 v19, v20, s18, 0                           // 00000013C9E0: CC220013 02002514
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013C9E8: 8C7E017E
	.long 0x7f283880                                           // 00000013C9EC: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013C9F0: BF870001
	.long 0x7e283994                                           // 00000013C9F4: 7E283994
	s_and_saveexec_b32 s1, s0                                  // 00000013C9F8: BE812000
	s_cbranch_execz 5                                          // 00000013C9FC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d14>
	global_load_b32 v21, v[36:37], off offset:464              // 00000013CA00: DC5201D0 157C0024
	s_waitcnt vmcnt(0)                                         // 00000013CA08: BF8903F7
	v_fma_mixlo_f16 v20, v21, s18, 0                           // 00000013CA0C: CC210014 02002515
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013CA14: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013CA18: BE812000
	s_cbranch_execz 5                                          // 00000013CA1C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d34>
	global_load_b32 v21, v[36:37], off offset:468              // 00000013CA20: DC5201D4 157C0024
	s_waitcnt vmcnt(0)                                         // 00000013CA28: BF8903F7
	v_fma_mixhi_f16 v20, v21, s18, 0                           // 00000013CA2C: CC220014 02002515
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013CA34: 8C7E017E
	.long 0x7f2a3880                                           // 00000013CA38: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013CA3C: BF870001
	.long 0x7e2a3995                                           // 00000013CA40: 7E2A3995
	s_and_saveexec_b32 s1, s0                                  // 00000013CA44: BE812000
	s_cbranch_execz 5                                          // 00000013CA48: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d60>
	global_load_b32 v22, v[36:37], off offset:472              // 00000013CA4C: DC5201D8 167C0024
	s_waitcnt vmcnt(0)                                         // 00000013CA54: BF8903F7
	v_fma_mixlo_f16 v21, v22, s18, 0                           // 00000013CA58: CC210015 02002516
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013CA60: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013CA64: BE812000
	s_cbranch_execz 5                                          // 00000013CA68: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d80>
	global_load_b32 v22, v[36:37], off offset:476              // 00000013CA6C: DC5201DC 167C0024
	s_waitcnt vmcnt(0)                                         // 00000013CA74: BF8903F7
	v_fma_mixhi_f16 v21, v22, s18, 0                           // 00000013CA78: CC220015 02002516
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013CA80: 8C7E017E
	.long 0x7f2c3880                                           // 00000013CA84: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013CA88: BF870001
	.long 0x7e2c3996                                           // 00000013CA8C: 7E2C3996
	s_and_saveexec_b32 s1, s0                                  // 00000013CA90: BE812000
	s_cbranch_execz 5                                          // 00000013CA94: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dac>
	global_load_b32 v23, v[36:37], off offset:480              // 00000013CA98: DC5201E0 177C0024
	s_waitcnt vmcnt(0)                                         // 00000013CAA0: BF8903F7
	v_fma_mixlo_f16 v22, v23, s18, 0                           // 00000013CAA4: CC210016 02002517
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013CAAC: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013CAB0: BE812000
	s_cbranch_execz 5                                          // 00000013CAB4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dcc>
	global_load_b32 v23, v[36:37], off offset:484              // 00000013CAB8: DC5201E4 177C0024
	s_waitcnt vmcnt(0)                                         // 00000013CAC0: BF8903F7
	v_fma_mixhi_f16 v22, v23, s18, 0                           // 00000013CAC4: CC220016 02002517
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013CACC: 8C7E017E
	.long 0x7f2e3880                                           // 00000013CAD0: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013CAD4: BF870001
	.long 0x7e2e3997                                           // 00000013CAD8: 7E2E3997
	s_and_saveexec_b32 s1, s0                                  // 00000013CADC: BE812000
	s_cbranch_execz 5                                          // 00000013CAE0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1df8>
	global_load_b32 v24, v[36:37], off offset:488              // 00000013CAE4: DC5201E8 187C0024
	s_waitcnt vmcnt(0)                                         // 00000013CAEC: BF8903F7
	v_fma_mixlo_f16 v23, v24, s18, 0                           // 00000013CAF0: CC210017 02002518
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013CAF8: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013CAFC: BE812000
	s_cbranch_execz 5                                          // 00000013CB00: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e18>
	global_load_b32 v24, v[36:37], off offset:492              // 00000013CB04: DC5201EC 187C0024
	s_waitcnt vmcnt(0)                                         // 00000013CB0C: BF8903F7
	v_fma_mixhi_f16 v23, v24, s18, 0                           // 00000013CB10: CC220017 02002518
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013CB18: 8C7E017E
	.long 0x7f303880                                           // 00000013CB1C: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013CB20: BF870001
	.long 0x7e303998                                           // 00000013CB24: 7E303998
	s_and_saveexec_b32 s1, s0                                  // 00000013CB28: BE812000
	s_cbranch_execz 5                                          // 00000013CB2C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e44>
	global_load_b32 v25, v[36:37], off offset:496              // 00000013CB30: DC5201F0 197C0024
	s_waitcnt vmcnt(0)                                         // 00000013CB38: BF8903F7
	v_fma_mixlo_f16 v24, v25, s18, 0                           // 00000013CB3C: CC210018 02002519
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013CB44: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013CB48: BE812000
	s_cbranch_execz 5                                          // 00000013CB4C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e64>
	global_load_b32 v25, v[36:37], off offset:500              // 00000013CB50: DC5201F4 197C0024
	s_waitcnt vmcnt(0)                                         // 00000013CB58: BF8903F7
	v_fma_mixhi_f16 v24, v25, s18, 0                           // 00000013CB5C: CC220018 02002519
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013CB64: 8C7E017E
	.long 0x7f323880                                           // 00000013CB68: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013CB6C: BF870001
	.long 0x7e323999                                           // 00000013CB70: 7E323999
	s_and_saveexec_b32 s1, s0                                  // 00000013CB74: BE812000
	s_cbranch_execz 5                                          // 00000013CB78: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e90>
	global_load_b32 v26, v[36:37], off offset:504              // 00000013CB7C: DC5201F8 1A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013CB84: BF8903F7
	v_fma_mixlo_f16 v25, v26, s18, 0                           // 00000013CB88: CC210019 0200251A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013CB90: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 00000013CB94: BE812000
	s_cbranch_execz 5                                          // 00000013CB98: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1eb0>
	global_load_b32 v26, v[36:37], off offset:508              // 00000013CB9C: DC5201FC 1A7C0024
	s_waitcnt vmcnt(0)                                         // 00000013CBA4: BF8903F7
	v_fma_mixhi_f16 v25, v26, s18, 0                           // 00000013CBA8: CC220019 0200251A
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013CBB0: 8C7E017E
	ds_load_b128 v[26:29], v57 offset:448                      // 00000013CBB4: DBFC01C0 1A000039
	ds_load_b128 v[30:33], v57 offset:464                      // 00000013CBBC: DBFC01D0 1E000039
	ds_load_b128 v[40:43], v57 offset:480                      // 00000013CBC4: DBFC01E0 28000039
	ds_load_b128 v[44:47], v57 offset:496                      // 00000013CBCC: DBFC01F0 2C000039
	v_add_nc_u32_e32 v78, s22, v65                             // 00000013CBD4: 4A9C8216
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013CBD8: BF870001
	.long 0xd4440001                                           // 00000013CBDC: D4440001
	v_cndmask_b32_e32 v1, s35, v78, vcc_lo                     // 00000013CBE0: 02029C23
	s_waitcnt lgkmcnt(3)                                       // 00000013CBE4: BF89FC37
	v_fma_mixlo_f16 v36, v26, s18, 0                           // 00000013CBE8: CC210024 0200251A
	v_fma_mixhi_f16 v36, v27, s18, 0                           // 00000013CBF0: CC220024 0200251B
	v_fma_mixlo_f16 v37, v28, s18, 0                           // 00000013CBF8: CC210025 0200251C
	v_fma_mixhi_f16 v37, v29, s18, 0                           // 00000013CC00: CC220025 0200251D
	s_waitcnt lgkmcnt(2)                                       // 00000013CC08: BF89FC27
	v_fma_mixlo_f16 v38, v30, s18, 0                           // 00000013CC0C: CC210026 0200251E
	v_fma_mixhi_f16 v38, v31, s18, 0                           // 00000013CC14: CC220026 0200251F
	v_fma_mixlo_f16 v39, v32, s18, 0                           // 00000013CC1C: CC210027 02002520
	v_fma_mixhi_f16 v39, v33, s18, 0                           // 00000013CC24: CC220027 02002521
	s_waitcnt lgkmcnt(1)                                       // 00000013CC2C: BF89FC17
	v_fma_mixlo_f16 v40, v40, s18, 0                           // 00000013CC30: CC210028 02002528
	v_fma_mixhi_f16 v40, v41, s18, 0                           // 00000013CC38: CC220028 02002529
	v_fma_mixlo_f16 v41, v42, s18, 0                           // 00000013CC40: CC210029 0200252A
	v_fma_mixhi_f16 v41, v43, s18, 0                           // 00000013CC48: CC220029 0200252B
	s_waitcnt lgkmcnt(0)                                       // 00000013CC50: BF89FC07
	v_fma_mixlo_f16 v42, v44, s18, 0                           // 00000013CC54: CC21002A 0200252C
	v_fma_mixhi_f16 v42, v45, s18, 0                           // 00000013CC5C: CC22002A 0200252D
	v_fma_mixlo_f16 v43, v46, s18, 0                           // 00000013CC64: CC21002B 0200252E
	v_fma_mixhi_f16 v43, v47, s18, 0                           // 00000013CC6C: CC22002B 0200252F
	.long 0x7e343880                                           // 00000013CC74: 7E343880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013CC78: BF870112
	v_wmma_f32_16x16x16_f16 v[10:17], v[18:25], v[36:43], v[10:17]// 00000013CC7C: CC40400A 1C2A4912
	.long 0x7e24391a                                           // 00000013CC84: 7E24391A
	s_and_saveexec_b32 s5, s1                                  // 00000013CC88: BE852001
	s_cbranch_execz 17                                         // 00000013CC8C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fd4>
	v_mad_u64_u32 v[18:19], null, v78, 48, s[2:3]              // 00000013CC90: D6FE7C12 0009614E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CC98: BF870091
	.long 0xd73c0012                                           // 00000013CC9C: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 00000013CCA0: 02022489
	.long 0xd7000412                                           // 00000013CCA4: D7000412
	v_cndmask_b32_e32 v1, v67, v18, vcc_lo                     // 00000013CCA8: 02022543
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013CCAC: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v68, v19, s4                // 00000013CCB0: D5207C13 00122744
	global_load_b32 v18, v[18:19], off                         // 00000013CCB8: DC520000 127C0012
	s_waitcnt vmcnt(0)                                         // 00000013CCC0: BF8903F7
	v_fmac_f32_e32 v18, 0xbb800000, v10                        // 00000013CCC4: 562414FF BB800000
	v_fma_mixlo_f16 v18, v18, s18, 0                           // 00000013CCCC: CC210012 02002512
	s_or_b32 exec_lo, exec_lo, s5                              // 00000013CCD4: 8C7E057E
	v_add_nc_u32_e32 v79, 2, v78                               // 00000013CCD8: 4A9E9C82
	ds_store_b16 v74, v18                                      // 00000013CCDC: D87C0000 0000124A
	.long 0xd4440004                                           // 00000013CCE4: D4440004
	v_cndmask_b32_e32 v1, s35, v79, vcc_lo                     // 00000013CCE8: 02029E23
	s_and_saveexec_b32 s6, s4                                  // 00000013CCEC: BE862004
	s_cbranch_execz 17                                         // 00000013CCF0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2038>
	v_mad_u64_u32 v[18:19], null, v79, 48, s[2:3]              // 00000013CCF4: D6FE7C12 0009614F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CCFC: BF870091
	.long 0xd73c0012                                           // 00000013CD00: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 00000013CD04: 02022489
	.long 0xd7000512                                           // 00000013CD08: D7000512
	v_cndmask_b32_e32 v1, v67, v18, vcc_lo                     // 00000013CD0C: 02022543
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013CD10: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v68, v19, s5                // 00000013CD14: D5207C13 00162744
	global_load_b32 v10, v[18:19], off                         // 00000013CD1C: DC520000 0A7C0012
	s_waitcnt vmcnt(0)                                         // 00000013CD24: BF8903F7
	v_fmac_f32_e32 v10, 0xbb800000, v11                        // 00000013CD28: 561416FF BB800000
	v_fma_mixlo_f16 v26, v10, s18, 0                           // 00000013CD30: CC21001A 0200250A
	s_or_b32 exec_lo, exec_lo, s6                              // 00000013CD38: 8C7E067E
	v_add_nc_u32_e32 v80, 4, v78                               // 00000013CD3C: 4AA09C84
	.long 0x7e143880                                           // 00000013CD40: 7E143880
	ds_store_b16 v74, v26 offset:4                             // 00000013CD44: D87C0004 00001A4A
	.long 0xd4440005                                           // 00000013CD4C: D4440005
	v_cndmask_b32_e32 v1, s35, v80, vcc_lo                     // 00000013CD50: 0202A023
	.long 0x7f14390a                                           // 00000013CD54: 7F14390A
	s_and_saveexec_b32 s7, s5                                  // 00000013CD58: BE872005
	s_cbranch_execz 17                                         // 00000013CD5C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x20a4>
	v_mad_u64_u32 v[18:19], null, v80, 48, s[2:3]              // 00000013CD60: D6FE7C12 00096150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CD68: BF870091
	.long 0xd73c0012                                           // 00000013CD6C: D73C0012
	v_cndmask_b32_e32 v1, 9, v18, vcc_lo                       // 00000013CD70: 02022489
	.long 0xd7000612                                           // 00000013CD74: D7000612
	v_cndmask_b32_e32 v1, v67, v18, vcc_lo                     // 00000013CD78: 02022543
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013CD7C: BF8700C1
	v_add_co_ci_u32_e64 v19, null, v68, v19, s6                // 00000013CD80: D5207C13 001A2744
	global_load_b32 v11, v[18:19], off                         // 00000013CD88: DC520000 0B7C0012
	s_waitcnt vmcnt(0)                                         // 00000013CD90: BF8903F7
	v_fmac_f32_e32 v11, 0xbb800000, v12                        // 00000013CD94: 561618FF BB800000
	v_fma_mixhi_f16 v10, v11, s18, 0                           // 00000013CD9C: CC22000A 0200250B
	s_or_b32 exec_lo, exec_lo, s7                              // 00000013CDA4: 8C7E077E
	v_add_nc_u32_e32 v81, 6, v78                               // 00000013CDA8: 4AA29C86
	ds_store_b16_d16_hi v74, v10 offset:8                      // 00000013CDAC: DA840008 00000A4A
	.long 0xd4440006                                           // 00000013CDB4: D4440006
	v_cndmask_b32_e32 v1, s35, v81, vcc_lo                     // 00000013CDB8: 0202A223
	s_and_saveexec_b32 s8, s6                                  // 00000013CDBC: BE882006
	s_cbranch_execz 17                                         // 00000013CDC0: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2108>
	v_mad_u64_u32 v[10:11], null, v81, 48, s[2:3]              // 00000013CDC4: D6FE7C0A 00096151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CDCC: BF870091
	.long 0xd73c000a                                           // 00000013CDD0: D73C000A
	v_cndmask_b32_e32 v1, 9, v10, vcc_lo                       // 00000013CDD4: 02021489
	.long 0xd700070a                                           // 00000013CDD8: D700070A
	v_cndmask_b32_e32 v1, v67, v10, vcc_lo                     // 00000013CDDC: 02021543
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013CDE0: BF8700C1
	v_add_co_ci_u32_e64 v11, null, v68, v11, s7                // 00000013CDE4: D5207C0B 001E1744
	global_load_b32 v10, v[10:11], off                         // 00000013CDEC: DC520000 0A7C000A
	s_waitcnt vmcnt(0)                                         // 00000013CDF4: BF8903F7
	v_fmac_f32_e32 v10, 0xbb800000, v13                        // 00000013CDF8: 56141AFF BB800000
	v_fma_mixlo_f16 v10, v10, s18, 0                           // 00000013CE00: CC21000A 0200250A
	s_or_b32 exec_lo, exec_lo, s8                              // 00000013CE08: 8C7E087E
	v_add_nc_u32_e32 v82, 8, v78                               // 00000013CE0C: 4AA49C88
	.long 0x7f143880                                           // 00000013CE10: 7F143880
	ds_store_b16 v74, v10 offset:12                            // 00000013CE14: D87C000C 00000A4A
	.long 0xd4440007                                           // 00000013CE1C: D4440007
	v_cndmask_b32_e32 v1, s35, v82, vcc_lo                     // 00000013CE20: 0202A423
	.long 0x7e16398a                                           // 00000013CE24: 7E16398A
	s_and_saveexec_b32 s9, s7                                  // 00000013CE28: BE892007
	s_cbranch_execz 17                                         // 00000013CE2C: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2174>
	v_mad_u64_u32 v[11:12], null, v82, 48, s[2:3]              // 00000013CE30: D6FE7C0B 00096152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CE38: BF870091
	.long 0xd73c000b                                           // 00000013CE3C: D73C000B
	v_cndmask_b32_e32 v1, 9, v11, vcc_lo                       // 00000013CE40: 02021689
	.long 0xd700080b                                           // 00000013CE44: D700080B
	v_cndmask_b32_e32 v1, v67, v11, vcc_lo                     // 00000013CE48: 02021743
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013CE4C: BF8700C1
	v_add_co_ci_u32_e64 v12, null, v68, v12, s8                // 00000013CE50: D5207C0C 00221944
	global_load_b32 v11, v[11:12], off                         // 00000013CE58: DC520000 0B7C000B
	s_waitcnt vmcnt(0)                                         // 00000013CE60: BF8903F7
	v_fmac_f32_e32 v11, 0xbb800000, v14                        // 00000013CE64: 56161CFF BB800000
	v_fma_mixlo_f16 v11, v11, s18, 0                           // 00000013CE6C: CC21000B 0200250B
	s_or_b32 exec_lo, exec_lo, s9                              // 00000013CE74: 8C7E097E
	v_add_nc_u32_e32 v83, 10, v78                              // 00000013CE78: 4AA69C8A
	ds_store_b16 v74, v11 offset:16                            // 00000013CE7C: D87C0010 00000B4A
	.long 0xd4440008                                           // 00000013CE84: D4440008
	v_cndmask_b32_e32 v1, s35, v83, vcc_lo                     // 00000013CE88: 0202A623
	s_and_saveexec_b32 s10, s8                                 // 00000013CE8C: BE8A2008
	s_cbranch_execz 17                                         // 00000013CE90: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x21d8>
	v_mad_u64_u32 v[10:11], null, v83, 48, s[2:3]              // 00000013CE94: D6FE7C0A 00096153
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CE9C: BF870091
	.long 0xd73c000a                                           // 00000013CEA0: D73C000A
	v_cndmask_b32_e32 v1, 9, v10, vcc_lo                       // 00000013CEA4: 02021489
	.long 0xd700090a                                           // 00000013CEA8: D700090A
	v_cndmask_b32_e32 v1, v67, v10, vcc_lo                     // 00000013CEAC: 02021543
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013CEB0: BF8700C1
	v_add_co_ci_u32_e64 v11, null, v68, v11, s9                // 00000013CEB4: D5207C0B 00261744
	global_load_b32 v10, v[10:11], off                         // 00000013CEBC: DC520000 0A7C000A
	s_waitcnt vmcnt(0)                                         // 00000013CEC4: BF8903F7
	v_fmac_f32_e32 v10, 0xbb800000, v15                        // 00000013CEC8: 56141EFF BB800000
	v_fma_mixhi_f16 v10, v10, s18, 0                           // 00000013CED0: CC22000A 0200250A
	s_or_b32 exec_lo, exec_lo, s10                             // 00000013CED8: 8C7E0A7E
	v_add_nc_u32_e32 v84, 12, v78                              // 00000013CEDC: 4AA89C8C
	.long 0x7e143880                                           // 00000013CEE0: 7E143880
	ds_store_b16_d16_hi v74, v10 offset:20                     // 00000013CEE4: DA840014 00000A4A
	.long 0xd4440009                                           // 00000013CEEC: D4440009
	v_cndmask_b32_e32 v1, s35, v84, vcc_lo                     // 00000013CEF0: 0202A823
	.long 0x7e16390a                                           // 00000013CEF4: 7E16390A
	s_and_saveexec_b32 s11, s9                                 // 00000013CEF8: BE8B2009
	s_cbranch_execz 17                                         // 00000013CEFC: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2244>
	v_mad_u64_u32 v[11:12], null, v84, 48, s[2:3]              // 00000013CF00: D6FE7C0B 00096154
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CF08: BF870091
	.long 0xd73c000b                                           // 00000013CF0C: D73C000B
	v_cndmask_b32_e32 v1, 9, v11, vcc_lo                       // 00000013CF10: 02021689
	.long 0xd7000a0b                                           // 00000013CF14: D7000A0B
	v_cndmask_b32_e32 v1, v67, v11, vcc_lo                     // 00000013CF18: 02021743
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013CF1C: BF8700C1
	v_add_co_ci_u32_e64 v12, null, v68, v12, s10               // 00000013CF20: D5207C0C 002A1944
	global_load_b32 v11, v[11:12], off                         // 00000013CF28: DC520000 0B7C000B
	s_waitcnt vmcnt(0)                                         // 00000013CF30: BF8903F7
	v_fmac_f32_e32 v11, 0xbb800000, v16                        // 00000013CF34: 561620FF BB800000
	v_fma_mixlo_f16 v11, v11, s18, 0                           // 00000013CF3C: CC21000B 0200250B
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013CF44: 8C7E0B7E
	v_add_nc_u32_e32 v85, 14, v78                              // 00000013CF48: 4AAA9C8E
	ds_store_b16 v74, v11 offset:24                            // 00000013CF4C: D87C0018 00000B4A
	.long 0xd444000a                                           // 00000013CF54: D444000A
	v_cndmask_b32_e32 v1, s35, v85, vcc_lo                     // 00000013CF58: 0202AA23
	s_and_saveexec_b32 s14, s10                                // 00000013CF5C: BE8E200A
	s_cbranch_execz 17                                         // 00000013CF60: BFA50011 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x22a8>
	v_mad_u64_u32 v[10:11], null, v85, 48, s[2:3]              // 00000013CF64: D6FE7C0A 00096155
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013CF6C: BF870091
	.long 0xd73c000a                                           // 00000013CF70: D73C000A
	v_cndmask_b32_e32 v1, 9, v10, vcc_lo                       // 00000013CF74: 02021489
	.long 0xd7000b0a                                           // 00000013CF78: D7000B0A
	v_cndmask_b32_e32 v1, v67, v10, vcc_lo                     // 00000013CF7C: 02021543
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000013CF80: BF8700C1
	v_add_co_ci_u32_e64 v11, null, v68, v11, s11               // 00000013CF84: D5207C0B 002E1744
	global_load_b32 v10, v[10:11], off                         // 00000013CF8C: DC520000 0A7C000A
	s_waitcnt vmcnt(0)                                         // 00000013CF94: BF8903F7
	v_fmac_f32_e32 v10, 0xbb800000, v17                        // 00000013CF98: 561422FF BB800000
	v_fma_mixlo_f16 v10, v10, s18, 0                           // 00000013CFA0: CC21000A 0200250A
	s_or_b32 exec_lo, exec_lo, s14                             // 00000013CFA8: 8C7E0E7E
	.long 0x7f243880                                           // 00000013CFAC: 7F243880
	.long 0xd7000b22                                           // 00000013CFB0: D7000B22
	v_cndmask_b32_e32 v1, s12, v34, vcc_lo                     // 00000013CFB4: 0202440C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013CFB8: BF870191
	v_add_co_ci_u32_e64 v35, null, s13, v35, s11               // 00000013CFBC: D5207C23 002E460D
	.long 0x7e243992                                           // 00000013CFC4: 7E243992
	ds_store_b16 v74, v10 offset:28                            // 00000013CFC8: D87C001C 00000A4A
	s_waitcnt lgkmcnt(0)                                       // 00000013CFD0: BF89FC07
	s_barrier                                                  // 00000013CFD4: BFBD0000
	buffer_gl0_inv                                             // 00000013CFD8: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 00000013CFE0: BE8B2000
	s_cbranch_execz 5                                          // 00000013CFE4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x22fc>
	global_load_b32 v10, v[34:35], off                         // 00000013CFE8: DC520000 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013CFF0: BF8903F7
	v_fma_mixlo_f16 v18, v10, s18, 0                           // 00000013CFF4: CC210012 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013CFFC: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D000: BE8B2000
	s_cbranch_execz 5                                          // 00000013D004: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x231c>
	global_load_b32 v10, v[34:35], off offset:4                // 00000013D008: DC520004 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D010: BF8903F7
	v_fma_mixhi_f16 v18, v10, s18, 0                           // 00000013D014: CC220012 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D01C: 8C7E0B7E
	.long 0x7f263880                                           // 00000013D020: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D024: BF870001
	.long 0x7e263993                                           // 00000013D028: 7E263993
	s_and_saveexec_b32 s11, s0                                 // 00000013D02C: BE8B2000
	s_cbranch_execz 5                                          // 00000013D030: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2348>
	global_load_b32 v10, v[34:35], off offset:8                // 00000013D034: DC520008 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D03C: BF8903F7
	v_fma_mixlo_f16 v19, v10, s18, 0                           // 00000013D040: CC210013 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D048: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D04C: BE8B2000
	s_cbranch_execz 5                                          // 00000013D050: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2368>
	global_load_b32 v10, v[34:35], off offset:12               // 00000013D054: DC52000C 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D05C: BF8903F7
	v_fma_mixhi_f16 v19, v10, s18, 0                           // 00000013D060: CC220013 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D068: 8C7E0B7E
	.long 0x7f283880                                           // 00000013D06C: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D070: BF870001
	.long 0x7e283994                                           // 00000013D074: 7E283994
	s_and_saveexec_b32 s11, s0                                 // 00000013D078: BE8B2000
	s_cbranch_execz 5                                          // 00000013D07C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2394>
	global_load_b32 v10, v[34:35], off offset:16               // 00000013D080: DC520010 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D088: BF8903F7
	v_fma_mixlo_f16 v20, v10, s18, 0                           // 00000013D08C: CC210014 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D094: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D098: BE8B2000
	s_cbranch_execz 5                                          // 00000013D09C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23b4>
	global_load_b32 v10, v[34:35], off offset:20               // 00000013D0A0: DC520014 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D0A8: BF8903F7
	v_fma_mixhi_f16 v20, v10, s18, 0                           // 00000013D0AC: CC220014 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D0B4: 8C7E0B7E
	.long 0x7f2a3880                                           // 00000013D0B8: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D0BC: BF870001
	.long 0x7e2a3995                                           // 00000013D0C0: 7E2A3995
	s_and_saveexec_b32 s11, s0                                 // 00000013D0C4: BE8B2000
	s_cbranch_execz 5                                          // 00000013D0C8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23e0>
	global_load_b32 v10, v[34:35], off offset:24               // 00000013D0CC: DC520018 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D0D4: BF8903F7
	v_fma_mixlo_f16 v21, v10, s18, 0                           // 00000013D0D8: CC210015 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D0E0: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D0E4: BE8B2000
	s_cbranch_execz 5                                          // 00000013D0E8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2400>
	global_load_b32 v10, v[34:35], off offset:28               // 00000013D0EC: DC52001C 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D0F4: BF8903F7
	v_fma_mixhi_f16 v21, v10, s18, 0                           // 00000013D0F8: CC220015 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D100: 8C7E0B7E
	.long 0x7f2c3880                                           // 00000013D104: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D108: BF870001
	.long 0x7e2c3996                                           // 00000013D10C: 7E2C3996
	s_and_saveexec_b32 s11, s0                                 // 00000013D110: BE8B2000
	s_cbranch_execz 5                                          // 00000013D114: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x242c>
	global_load_b32 v10, v[34:35], off offset:32               // 00000013D118: DC520020 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D120: BF8903F7
	v_fma_mixlo_f16 v22, v10, s18, 0                           // 00000013D124: CC210016 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D12C: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D130: BE8B2000
	s_cbranch_execz 5                                          // 00000013D134: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x244c>
	global_load_b32 v10, v[34:35], off offset:36               // 00000013D138: DC520024 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D140: BF8903F7
	v_fma_mixhi_f16 v22, v10, s18, 0                           // 00000013D144: CC220016 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D14C: 8C7E0B7E
	.long 0x7f2e3880                                           // 00000013D150: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D154: BF870001
	.long 0x7e2e3997                                           // 00000013D158: 7E2E3997
	s_and_saveexec_b32 s11, s0                                 // 00000013D15C: BE8B2000
	s_cbranch_execz 5                                          // 00000013D160: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2478>
	global_load_b32 v10, v[34:35], off offset:40               // 00000013D164: DC520028 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D16C: BF8903F7
	v_fma_mixlo_f16 v23, v10, s18, 0                           // 00000013D170: CC210017 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D178: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D17C: BE8B2000
	s_cbranch_execz 5                                          // 00000013D180: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2498>
	global_load_b32 v10, v[34:35], off offset:44               // 00000013D184: DC52002C 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D18C: BF8903F7
	v_fma_mixhi_f16 v23, v10, s18, 0                           // 00000013D190: CC220017 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D198: 8C7E0B7E
	.long 0x7f303880                                           // 00000013D19C: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D1A0: BF870001
	.long 0x7e303998                                           // 00000013D1A4: 7E303998
	s_and_saveexec_b32 s11, s0                                 // 00000013D1A8: BE8B2000
	s_cbranch_execz 5                                          // 00000013D1AC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x24c4>
	global_load_b32 v10, v[34:35], off offset:48               // 00000013D1B0: DC520030 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D1B8: BF8903F7
	v_fma_mixlo_f16 v24, v10, s18, 0                           // 00000013D1BC: CC210018 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D1C4: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D1C8: BE8B2000
	s_cbranch_execz 5                                          // 00000013D1CC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x24e4>
	global_load_b32 v10, v[34:35], off offset:52               // 00000013D1D0: DC520034 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D1D8: BF8903F7
	v_fma_mixhi_f16 v24, v10, s18, 0                           // 00000013D1DC: CC220018 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D1E4: 8C7E0B7E
	.long 0x7f323880                                           // 00000013D1E8: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D1EC: BF870001
	.long 0x7e323999                                           // 00000013D1F0: 7E323999
	s_and_saveexec_b32 s11, s0                                 // 00000013D1F4: BE8B2000
	s_cbranch_execz 5                                          // 00000013D1F8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2510>
	global_load_b32 v10, v[34:35], off offset:56               // 00000013D1FC: DC520038 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D204: BF8903F7
	v_fma_mixlo_f16 v25, v10, s18, 0                           // 00000013D208: CC210019 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D210: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D214: BE8B2000
	s_cbranch_execz 5                                          // 00000013D218: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2530>
	global_load_b32 v10, v[34:35], off offset:60               // 00000013D21C: DC52003C 0A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D224: BF8903F7
	v_fma_mixhi_f16 v25, v10, s18, 0                           // 00000013D228: CC220019 0200250A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D230: 8C7E0B7E
	ds_load_b128 v[26:29], v57                                 // 00000013D234: DBFC0000 1A000039
	ds_load_b128 v[30:33], v57 offset:16                       // 00000013D23C: DBFC0010 1E000039
	ds_load_b128 v[40:43], v57 offset:32                       // 00000013D244: DBFC0020 28000039
	ds_load_b128 v[44:47], v57 offset:48                       // 00000013D24C: DBFC0030 2C000039
	v_mov_b32_e32 v16, v9                                      // 00000013D254: 7E200309
	v_mov_b32_e32 v10, v9                                      // 00000013D258: 7E140309
	v_mov_b32_e32 v11, v9                                      // 00000013D25C: 7E160309
	v_mov_b32_e32 v12, v9                                      // 00000013D260: 7E180309
	v_mov_b32_e32 v13, v9                                      // 00000013D264: 7E1A0309
	v_mov_b32_e32 v14, v9                                      // 00000013D268: 7E1C0309
	v_mov_b32_e32 v15, v9                                      // 00000013D26C: 7E1E0309
	v_mov_b32_e32 v17, v16                                     // 00000013D270: 7E220310
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000013D274: BF870212
	v_mov_b32_e32 v16, v15                                     // 00000013D278: 7E20030F
	v_mov_b32_e32 v15, v14                                     // 00000013D27C: 7E1E030E
	v_mov_b32_e32 v14, v13                                     // 00000013D280: 7E1C030D
	v_mov_b32_e32 v13, v12                                     // 00000013D284: 7E1A030C
	v_mov_b32_e32 v12, v11                                     // 00000013D288: 7E18030B
	v_mov_b32_e32 v11, v10                                     // 00000013D28C: 7E16030A
	v_mov_b32_e32 v10, v9                                      // 00000013D290: 7E140309
	s_waitcnt lgkmcnt(3)                                       // 00000013D294: BF89FC37
	v_fma_mixlo_f16 v36, v26, s18, 0                           // 00000013D298: CC210024 0200251A
	v_fma_mixhi_f16 v36, v27, s18, 0                           // 00000013D2A0: CC220024 0200251B
	v_fma_mixlo_f16 v37, v28, s18, 0                           // 00000013D2A8: CC210025 0200251C
	v_fma_mixhi_f16 v37, v29, s18, 0                           // 00000013D2B0: CC220025 0200251D
	s_waitcnt lgkmcnt(2)                                       // 00000013D2B8: BF89FC27
	v_fma_mixlo_f16 v38, v30, s18, 0                           // 00000013D2BC: CC210026 0200251E
	v_fma_mixhi_f16 v38, v31, s18, 0                           // 00000013D2C4: CC220026 0200251F
	v_fma_mixlo_f16 v39, v32, s18, 0                           // 00000013D2CC: CC210027 02002520
	v_fma_mixhi_f16 v39, v33, s18, 0                           // 00000013D2D4: CC220027 02002521
	s_waitcnt lgkmcnt(1)                                       // 00000013D2DC: BF89FC17
	v_fma_mixlo_f16 v40, v40, s18, 0                           // 00000013D2E0: CC210028 02002528
	v_fma_mixhi_f16 v40, v41, s18, 0                           // 00000013D2E8: CC220028 02002529
	v_fma_mixlo_f16 v41, v42, s18, 0                           // 00000013D2F0: CC210029 0200252A
	v_fma_mixhi_f16 v41, v43, s18, 0                           // 00000013D2F8: CC220029 0200252B
	s_waitcnt lgkmcnt(0)                                       // 00000013D300: BF89FC07
	v_fma_mixlo_f16 v42, v44, s18, 0                           // 00000013D304: CC21002A 0200252C
	v_fma_mixhi_f16 v42, v45, s18, 0                           // 00000013D30C: CC22002A 0200252D
	v_fma_mixlo_f16 v43, v46, s18, 0                           // 00000013D314: CC21002B 0200252E
	v_fma_mixhi_f16 v43, v47, s18, 0                           // 00000013D31C: CC22002B 0200252F
	.long 0x7f343880                                           // 00000013D324: 7F343880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013D328: BF870112
	v_wmma_f32_16x16x16_f16 v[10:17], v[18:25], v[36:43], v[10:17]// 00000013D32C: CC40400A 1C2A4912
	.long 0x7e34399a                                           // 00000013D334: 7E34399A
	s_and_saveexec_b32 s11, s0                                 // 00000013D338: BE8B2000
	s_cbranch_execz 5                                          // 00000013D33C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2654>
	global_load_b32 v18, v[34:35], off offset:64               // 00000013D340: DC520040 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D348: BF8903F7
	v_fma_mixlo_f16 v26, v18, s18, 0                           // 00000013D34C: CC21001A 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D354: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D358: BE8B2000
	s_cbranch_execz 5                                          // 00000013D35C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2674>
	global_load_b32 v18, v[34:35], off offset:68               // 00000013D360: DC520044 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D368: BF8903F7
	v_fma_mixhi_f16 v26, v18, s18, 0                           // 00000013D36C: CC22001A 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D374: 8C7E0B7E
	.long 0x7f363880                                           // 00000013D378: 7F363880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D37C: BF870001
	.long 0x7e36399b                                           // 00000013D380: 7E36399B
	s_and_saveexec_b32 s11, s0                                 // 00000013D384: BE8B2000
	s_cbranch_execz 5                                          // 00000013D388: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26a0>
	global_load_b32 v18, v[34:35], off offset:72               // 00000013D38C: DC520048 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D394: BF8903F7
	v_fma_mixlo_f16 v27, v18, s18, 0                           // 00000013D398: CC21001B 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D3A0: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D3A4: BE8B2000
	s_cbranch_execz 5                                          // 00000013D3A8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26c0>
	global_load_b32 v18, v[34:35], off offset:76               // 00000013D3AC: DC52004C 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D3B4: BF8903F7
	v_fma_mixhi_f16 v27, v18, s18, 0                           // 00000013D3B8: CC22001B 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D3C0: 8C7E0B7E
	.long 0x7f383880                                           // 00000013D3C4: 7F383880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D3C8: BF870001
	.long 0x7e38399c                                           // 00000013D3CC: 7E38399C
	s_and_saveexec_b32 s11, s0                                 // 00000013D3D0: BE8B2000
	s_cbranch_execz 5                                          // 00000013D3D4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26ec>
	global_load_b32 v18, v[34:35], off offset:80               // 00000013D3D8: DC520050 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D3E0: BF8903F7
	v_fma_mixlo_f16 v28, v18, s18, 0                           // 00000013D3E4: CC21001C 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D3EC: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D3F0: BE8B2000
	s_cbranch_execz 5                                          // 00000013D3F4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x270c>
	global_load_b32 v18, v[34:35], off offset:84               // 00000013D3F8: DC520054 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D400: BF8903F7
	v_fma_mixhi_f16 v28, v18, s18, 0                           // 00000013D404: CC22001C 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D40C: 8C7E0B7E
	.long 0x7f3a3880                                           // 00000013D410: 7F3A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D414: BF870001
	.long 0x7e3a399d                                           // 00000013D418: 7E3A399D
	s_and_saveexec_b32 s11, s0                                 // 00000013D41C: BE8B2000
	s_cbranch_execz 5                                          // 00000013D420: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2738>
	global_load_b32 v18, v[34:35], off offset:88               // 00000013D424: DC520058 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D42C: BF8903F7
	v_fma_mixlo_f16 v29, v18, s18, 0                           // 00000013D430: CC21001D 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D438: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D43C: BE8B2000
	s_cbranch_execz 5                                          // 00000013D440: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2758>
	global_load_b32 v18, v[34:35], off offset:92               // 00000013D444: DC52005C 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D44C: BF8903F7
	v_fma_mixhi_f16 v29, v18, s18, 0                           // 00000013D450: CC22001D 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D458: 8C7E0B7E
	.long 0x7f3c3880                                           // 00000013D45C: 7F3C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D460: BF870001
	.long 0x7e3c399e                                           // 00000013D464: 7E3C399E
	s_and_saveexec_b32 s11, s0                                 // 00000013D468: BE8B2000
	s_cbranch_execz 5                                          // 00000013D46C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2784>
	global_load_b32 v18, v[34:35], off offset:96               // 00000013D470: DC520060 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D478: BF8903F7
	v_fma_mixlo_f16 v30, v18, s18, 0                           // 00000013D47C: CC21001E 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D484: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D488: BE8B2000
	s_cbranch_execz 5                                          // 00000013D48C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27a4>
	global_load_b32 v18, v[34:35], off offset:100              // 00000013D490: DC520064 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D498: BF8903F7
	v_fma_mixhi_f16 v30, v18, s18, 0                           // 00000013D49C: CC22001E 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D4A4: 8C7E0B7E
	.long 0x7f3e3880                                           // 00000013D4A8: 7F3E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D4AC: BF870001
	.long 0x7e3e399f                                           // 00000013D4B0: 7E3E399F
	s_and_saveexec_b32 s11, s0                                 // 00000013D4B4: BE8B2000
	s_cbranch_execz 5                                          // 00000013D4B8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27d0>
	global_load_b32 v18, v[34:35], off offset:104              // 00000013D4BC: DC520068 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D4C4: BF8903F7
	v_fma_mixlo_f16 v31, v18, s18, 0                           // 00000013D4C8: CC21001F 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D4D0: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D4D4: BE8B2000
	s_cbranch_execz 5                                          // 00000013D4D8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27f0>
	global_load_b32 v18, v[34:35], off offset:108              // 00000013D4DC: DC52006C 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D4E4: BF8903F7
	v_fma_mixhi_f16 v31, v18, s18, 0                           // 00000013D4E8: CC22001F 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D4F0: 8C7E0B7E
	.long 0x7f403880                                           // 00000013D4F4: 7F403880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D4F8: BF870001
	.long 0x7e4039a0                                           // 00000013D4FC: 7E4039A0
	s_and_saveexec_b32 s11, s0                                 // 00000013D500: BE8B2000
	s_cbranch_execz 5                                          // 00000013D504: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x281c>
	global_load_b32 v18, v[34:35], off offset:112              // 00000013D508: DC520070 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D510: BF8903F7
	v_fma_mixlo_f16 v32, v18, s18, 0                           // 00000013D514: CC210020 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D51C: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D520: BE8B2000
	s_cbranch_execz 5                                          // 00000013D524: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x283c>
	global_load_b32 v18, v[34:35], off offset:116              // 00000013D528: DC520074 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D530: BF8903F7
	v_fma_mixhi_f16 v32, v18, s18, 0                           // 00000013D534: CC220020 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D53C: 8C7E0B7E
	.long 0x7f423880                                           // 00000013D540: 7F423880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D544: BF870001
	.long 0x7e4239a1                                           // 00000013D548: 7E4239A1
	s_and_saveexec_b32 s11, s0                                 // 00000013D54C: BE8B2000
	s_cbranch_execz 5                                          // 00000013D550: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2868>
	global_load_b32 v18, v[34:35], off offset:120              // 00000013D554: DC520078 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D55C: BF8903F7
	v_fma_mixlo_f16 v33, v18, s18, 0                           // 00000013D560: CC210021 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D568: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D56C: BE8B2000
	s_cbranch_execz 5                                          // 00000013D570: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2888>
	global_load_b32 v18, v[34:35], off offset:124              // 00000013D574: DC52007C 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D57C: BF8903F7
	v_fma_mixhi_f16 v33, v18, s18, 0                           // 00000013D580: CC220021 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D588: 8C7E0B7E
	ds_load_b128 v[18:21], v57 offset:64                       // 00000013D58C: DBFC0040 12000039
	ds_load_b128 v[22:25], v57 offset:80                       // 00000013D594: DBFC0050 16000039
	ds_load_b128 v[40:43], v57 offset:96                       // 00000013D59C: DBFC0060 28000039
	ds_load_b128 v[44:47], v57 offset:112                      // 00000013D5A4: DBFC0070 2C000039
	s_waitcnt lgkmcnt(3)                                       // 00000013D5AC: BF89FC37
	v_fma_mixlo_f16 v36, v18, s18, 0                           // 00000013D5B0: CC210024 02002512
	v_fma_mixhi_f16 v36, v19, s18, 0                           // 00000013D5B8: CC220024 02002513
	v_fma_mixlo_f16 v37, v20, s18, 0                           // 00000013D5C0: CC210025 02002514
	v_fma_mixhi_f16 v37, v21, s18, 0                           // 00000013D5C8: CC220025 02002515
	s_waitcnt lgkmcnt(2)                                       // 00000013D5D0: BF89FC27
	v_fma_mixlo_f16 v38, v22, s18, 0                           // 00000013D5D4: CC210026 02002516
	v_fma_mixhi_f16 v38, v23, s18, 0                           // 00000013D5DC: CC220026 02002517
	v_fma_mixlo_f16 v39, v24, s18, 0                           // 00000013D5E4: CC210027 02002518
	v_fma_mixhi_f16 v39, v25, s18, 0                           // 00000013D5EC: CC220027 02002519
	s_waitcnt lgkmcnt(1)                                       // 00000013D5F4: BF89FC17
	v_fma_mixlo_f16 v40, v40, s18, 0                           // 00000013D5F8: CC210028 02002528
	v_fma_mixhi_f16 v40, v41, s18, 0                           // 00000013D600: CC220028 02002529
	v_fma_mixlo_f16 v41, v42, s18, 0                           // 00000013D608: CC210029 0200252A
	v_fma_mixhi_f16 v41, v43, s18, 0                           // 00000013D610: CC220029 0200252B
	s_waitcnt lgkmcnt(0)                                       // 00000013D618: BF89FC07
	v_fma_mixlo_f16 v42, v44, s18, 0                           // 00000013D61C: CC21002A 0200252C
	v_fma_mixhi_f16 v42, v45, s18, 0                           // 00000013D624: CC22002A 0200252D
	v_fma_mixlo_f16 v43, v46, s18, 0                           // 00000013D62C: CC21002B 0200252E
	v_fma_mixhi_f16 v43, v47, s18, 0                           // 00000013D634: CC22002B 0200252F
	.long 0x7f243880                                           // 00000013D63C: 7F243880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013D640: BF870112
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[36:43], v[10:17]// 00000013D644: CC40400A 1C2A491A
	.long 0x7e243992                                           // 00000013D64C: 7E243992
	s_and_saveexec_b32 s11, s0                                 // 00000013D650: BE8B2000
	s_cbranch_execz 5                                          // 00000013D654: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x296c>
	global_load_b32 v19, v[34:35], off offset:128              // 00000013D658: DC520080 137C0022
	s_waitcnt vmcnt(0)                                         // 00000013D660: BF8903F7
	v_fma_mixlo_f16 v18, v19, s18, 0                           // 00000013D664: CC210012 02002513
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D66C: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D670: BE8B2000
	s_cbranch_execz 5                                          // 00000013D674: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x298c>
	global_load_b32 v19, v[34:35], off offset:132              // 00000013D678: DC520084 137C0022
	s_waitcnt vmcnt(0)                                         // 00000013D680: BF8903F7
	v_fma_mixhi_f16 v18, v19, s18, 0                           // 00000013D684: CC220012 02002513
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D68C: 8C7E0B7E
	.long 0x7f263880                                           // 00000013D690: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D694: BF870001
	.long 0x7e263993                                           // 00000013D698: 7E263993
	s_and_saveexec_b32 s11, s0                                 // 00000013D69C: BE8B2000
	s_cbranch_execz 5                                          // 00000013D6A0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29b8>
	global_load_b32 v20, v[34:35], off offset:136              // 00000013D6A4: DC520088 147C0022
	s_waitcnt vmcnt(0)                                         // 00000013D6AC: BF8903F7
	v_fma_mixlo_f16 v19, v20, s18, 0                           // 00000013D6B0: CC210013 02002514
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D6B8: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D6BC: BE8B2000
	s_cbranch_execz 5                                          // 00000013D6C0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29d8>
	global_load_b32 v20, v[34:35], off offset:140              // 00000013D6C4: DC52008C 147C0022
	s_waitcnt vmcnt(0)                                         // 00000013D6CC: BF8903F7
	v_fma_mixhi_f16 v19, v20, s18, 0                           // 00000013D6D0: CC220013 02002514
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D6D8: 8C7E0B7E
	.long 0x7f283880                                           // 00000013D6DC: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D6E0: BF870001
	.long 0x7e283994                                           // 00000013D6E4: 7E283994
	s_and_saveexec_b32 s11, s0                                 // 00000013D6E8: BE8B2000
	s_cbranch_execz 5                                          // 00000013D6EC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a04>
	global_load_b32 v21, v[34:35], off offset:144              // 00000013D6F0: DC520090 157C0022
	s_waitcnt vmcnt(0)                                         // 00000013D6F8: BF8903F7
	v_fma_mixlo_f16 v20, v21, s18, 0                           // 00000013D6FC: CC210014 02002515
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D704: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D708: BE8B2000
	s_cbranch_execz 5                                          // 00000013D70C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a24>
	global_load_b32 v21, v[34:35], off offset:148              // 00000013D710: DC520094 157C0022
	s_waitcnt vmcnt(0)                                         // 00000013D718: BF8903F7
	v_fma_mixhi_f16 v20, v21, s18, 0                           // 00000013D71C: CC220014 02002515
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D724: 8C7E0B7E
	.long 0x7f2a3880                                           // 00000013D728: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D72C: BF870001
	.long 0x7e2a3995                                           // 00000013D730: 7E2A3995
	s_and_saveexec_b32 s11, s0                                 // 00000013D734: BE8B2000
	s_cbranch_execz 5                                          // 00000013D738: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a50>
	global_load_b32 v22, v[34:35], off offset:152              // 00000013D73C: DC520098 167C0022
	s_waitcnt vmcnt(0)                                         // 00000013D744: BF8903F7
	v_fma_mixlo_f16 v21, v22, s18, 0                           // 00000013D748: CC210015 02002516
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D750: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D754: BE8B2000
	s_cbranch_execz 5                                          // 00000013D758: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a70>
	global_load_b32 v22, v[34:35], off offset:156              // 00000013D75C: DC52009C 167C0022
	s_waitcnt vmcnt(0)                                         // 00000013D764: BF8903F7
	v_fma_mixhi_f16 v21, v22, s18, 0                           // 00000013D768: CC220015 02002516
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D770: 8C7E0B7E
	.long 0x7f2c3880                                           // 00000013D774: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D778: BF870001
	.long 0x7e2c3996                                           // 00000013D77C: 7E2C3996
	s_and_saveexec_b32 s11, s0                                 // 00000013D780: BE8B2000
	s_cbranch_execz 5                                          // 00000013D784: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a9c>
	global_load_b32 v23, v[34:35], off offset:160              // 00000013D788: DC5200A0 177C0022
	s_waitcnt vmcnt(0)                                         // 00000013D790: BF8903F7
	v_fma_mixlo_f16 v22, v23, s18, 0                           // 00000013D794: CC210016 02002517
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D79C: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D7A0: BE8B2000
	s_cbranch_execz 5                                          // 00000013D7A4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2abc>
	global_load_b32 v23, v[34:35], off offset:164              // 00000013D7A8: DC5200A4 177C0022
	s_waitcnt vmcnt(0)                                         // 00000013D7B0: BF8903F7
	v_fma_mixhi_f16 v22, v23, s18, 0                           // 00000013D7B4: CC220016 02002517
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D7BC: 8C7E0B7E
	.long 0x7f2e3880                                           // 00000013D7C0: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D7C4: BF870001
	.long 0x7e2e3997                                           // 00000013D7C8: 7E2E3997
	s_and_saveexec_b32 s11, s0                                 // 00000013D7CC: BE8B2000
	s_cbranch_execz 5                                          // 00000013D7D0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ae8>
	global_load_b32 v24, v[34:35], off offset:168              // 00000013D7D4: DC5200A8 187C0022
	s_waitcnt vmcnt(0)                                         // 00000013D7DC: BF8903F7
	v_fma_mixlo_f16 v23, v24, s18, 0                           // 00000013D7E0: CC210017 02002518
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D7E8: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D7EC: BE8B2000
	s_cbranch_execz 5                                          // 00000013D7F0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b08>
	global_load_b32 v24, v[34:35], off offset:172              // 00000013D7F4: DC5200AC 187C0022
	s_waitcnt vmcnt(0)                                         // 00000013D7FC: BF8903F7
	v_fma_mixhi_f16 v23, v24, s18, 0                           // 00000013D800: CC220017 02002518
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D808: 8C7E0B7E
	.long 0x7f303880                                           // 00000013D80C: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D810: BF870001
	.long 0x7e303998                                           // 00000013D814: 7E303998
	s_and_saveexec_b32 s11, s0                                 // 00000013D818: BE8B2000
	s_cbranch_execz 5                                          // 00000013D81C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b34>
	global_load_b32 v25, v[34:35], off offset:176              // 00000013D820: DC5200B0 197C0022
	s_waitcnt vmcnt(0)                                         // 00000013D828: BF8903F7
	v_fma_mixlo_f16 v24, v25, s18, 0                           // 00000013D82C: CC210018 02002519
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D834: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D838: BE8B2000
	s_cbranch_execz 5                                          // 00000013D83C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b54>
	global_load_b32 v25, v[34:35], off offset:180              // 00000013D840: DC5200B4 197C0022
	s_waitcnt vmcnt(0)                                         // 00000013D848: BF8903F7
	v_fma_mixhi_f16 v24, v25, s18, 0                           // 00000013D84C: CC220018 02002519
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D854: 8C7E0B7E
	.long 0x7f323880                                           // 00000013D858: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D85C: BF870001
	.long 0x7e323999                                           // 00000013D860: 7E323999
	s_and_saveexec_b32 s11, s0                                 // 00000013D864: BE8B2000
	s_cbranch_execz 5                                          // 00000013D868: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b80>
	global_load_b32 v26, v[34:35], off offset:184              // 00000013D86C: DC5200B8 1A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D874: BF8903F7
	v_fma_mixlo_f16 v25, v26, s18, 0                           // 00000013D878: CC210019 0200251A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D880: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D884: BE8B2000
	s_cbranch_execz 5                                          // 00000013D888: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ba0>
	global_load_b32 v26, v[34:35], off offset:188              // 00000013D88C: DC5200BC 1A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013D894: BF8903F7
	v_fma_mixhi_f16 v25, v26, s18, 0                           // 00000013D898: CC220019 0200251A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D8A0: 8C7E0B7E
	ds_load_b128 v[26:29], v57 offset:128                      // 00000013D8A4: DBFC0080 1A000039
	ds_load_b128 v[30:33], v57 offset:144                      // 00000013D8AC: DBFC0090 1E000039
	ds_load_b128 v[40:43], v57 offset:160                      // 00000013D8B4: DBFC00A0 28000039
	ds_load_b128 v[44:47], v57 offset:176                      // 00000013D8BC: DBFC00B0 2C000039
	s_waitcnt lgkmcnt(3)                                       // 00000013D8C4: BF89FC37
	v_fma_mixlo_f16 v36, v26, s18, 0                           // 00000013D8C8: CC210024 0200251A
	v_fma_mixhi_f16 v36, v27, s18, 0                           // 00000013D8D0: CC220024 0200251B
	v_fma_mixlo_f16 v37, v28, s18, 0                           // 00000013D8D8: CC210025 0200251C
	v_fma_mixhi_f16 v37, v29, s18, 0                           // 00000013D8E0: CC220025 0200251D
	s_waitcnt lgkmcnt(2)                                       // 00000013D8E8: BF89FC27
	v_fma_mixlo_f16 v38, v30, s18, 0                           // 00000013D8EC: CC210026 0200251E
	v_fma_mixhi_f16 v38, v31, s18, 0                           // 00000013D8F4: CC220026 0200251F
	v_fma_mixlo_f16 v39, v32, s18, 0                           // 00000013D8FC: CC210027 02002520
	v_fma_mixhi_f16 v39, v33, s18, 0                           // 00000013D904: CC220027 02002521
	s_waitcnt lgkmcnt(1)                                       // 00000013D90C: BF89FC17
	v_fma_mixlo_f16 v40, v40, s18, 0                           // 00000013D910: CC210028 02002528
	v_fma_mixhi_f16 v40, v41, s18, 0                           // 00000013D918: CC220028 02002529
	v_fma_mixlo_f16 v41, v42, s18, 0                           // 00000013D920: CC210029 0200252A
	v_fma_mixhi_f16 v41, v43, s18, 0                           // 00000013D928: CC220029 0200252B
	s_waitcnt lgkmcnt(0)                                       // 00000013D930: BF89FC07
	v_fma_mixlo_f16 v42, v44, s18, 0                           // 00000013D934: CC21002A 0200252C
	v_fma_mixhi_f16 v42, v45, s18, 0                           // 00000013D93C: CC22002A 0200252D
	v_fma_mixlo_f16 v43, v46, s18, 0                           // 00000013D944: CC21002B 0200252E
	v_fma_mixhi_f16 v43, v47, s18, 0                           // 00000013D94C: CC22002B 0200252F
	.long 0x7f343880                                           // 00000013D954: 7F343880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013D958: BF870112
	v_wmma_f32_16x16x16_f16 v[10:17], v[18:25], v[36:43], v[10:17]// 00000013D95C: CC40400A 1C2A4912
	.long 0x7e34399a                                           // 00000013D964: 7E34399A
	s_and_saveexec_b32 s11, s0                                 // 00000013D968: BE8B2000
	s_cbranch_execz 5                                          // 00000013D96C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c84>
	global_load_b32 v18, v[34:35], off offset:192              // 00000013D970: DC5200C0 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D978: BF8903F7
	v_fma_mixlo_f16 v26, v18, s18, 0                           // 00000013D97C: CC21001A 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D984: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D988: BE8B2000
	s_cbranch_execz 5                                          // 00000013D98C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ca4>
	global_load_b32 v18, v[34:35], off offset:196              // 00000013D990: DC5200C4 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D998: BF8903F7
	v_fma_mixhi_f16 v26, v18, s18, 0                           // 00000013D99C: CC22001A 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D9A4: 8C7E0B7E
	.long 0x7f363880                                           // 00000013D9A8: 7F363880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D9AC: BF870001
	.long 0x7e36399b                                           // 00000013D9B0: 7E36399B
	s_and_saveexec_b32 s11, s0                                 // 00000013D9B4: BE8B2000
	s_cbranch_execz 5                                          // 00000013D9B8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2cd0>
	global_load_b32 v18, v[34:35], off offset:200              // 00000013D9BC: DC5200C8 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D9C4: BF8903F7
	v_fma_mixlo_f16 v27, v18, s18, 0                           // 00000013D9C8: CC21001B 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D9D0: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013D9D4: BE8B2000
	s_cbranch_execz 5                                          // 00000013D9D8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2cf0>
	global_load_b32 v18, v[34:35], off offset:204              // 00000013D9DC: DC5200CC 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013D9E4: BF8903F7
	v_fma_mixhi_f16 v27, v18, s18, 0                           // 00000013D9E8: CC22001B 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013D9F0: 8C7E0B7E
	.long 0x7f383880                                           // 00000013D9F4: 7F383880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013D9F8: BF870001
	.long 0x7e38399c                                           // 00000013D9FC: 7E38399C
	s_and_saveexec_b32 s11, s0                                 // 00000013DA00: BE8B2000
	s_cbranch_execz 5                                          // 00000013DA04: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d1c>
	global_load_b32 v18, v[34:35], off offset:208              // 00000013DA08: DC5200D0 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DA10: BF8903F7
	v_fma_mixlo_f16 v28, v18, s18, 0                           // 00000013DA14: CC21001C 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DA1C: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DA20: BE8B2000
	s_cbranch_execz 5                                          // 00000013DA24: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d3c>
	global_load_b32 v18, v[34:35], off offset:212              // 00000013DA28: DC5200D4 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DA30: BF8903F7
	v_fma_mixhi_f16 v28, v18, s18, 0                           // 00000013DA34: CC22001C 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DA3C: 8C7E0B7E
	.long 0x7f3a3880                                           // 00000013DA40: 7F3A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013DA44: BF870001
	.long 0x7e3a399d                                           // 00000013DA48: 7E3A399D
	s_and_saveexec_b32 s11, s0                                 // 00000013DA4C: BE8B2000
	s_cbranch_execz 5                                          // 00000013DA50: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d68>
	global_load_b32 v18, v[34:35], off offset:216              // 00000013DA54: DC5200D8 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DA5C: BF8903F7
	v_fma_mixlo_f16 v29, v18, s18, 0                           // 00000013DA60: CC21001D 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DA68: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DA6C: BE8B2000
	s_cbranch_execz 5                                          // 00000013DA70: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d88>
	global_load_b32 v18, v[34:35], off offset:220              // 00000013DA74: DC5200DC 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DA7C: BF8903F7
	v_fma_mixhi_f16 v29, v18, s18, 0                           // 00000013DA80: CC22001D 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DA88: 8C7E0B7E
	.long 0x7f3c3880                                           // 00000013DA8C: 7F3C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013DA90: BF870001
	.long 0x7e3c399e                                           // 00000013DA94: 7E3C399E
	s_and_saveexec_b32 s11, s0                                 // 00000013DA98: BE8B2000
	s_cbranch_execz 5                                          // 00000013DA9C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2db4>
	global_load_b32 v18, v[34:35], off offset:224              // 00000013DAA0: DC5200E0 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DAA8: BF8903F7
	v_fma_mixlo_f16 v30, v18, s18, 0                           // 00000013DAAC: CC21001E 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DAB4: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DAB8: BE8B2000
	s_cbranch_execz 5                                          // 00000013DABC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2dd4>
	global_load_b32 v18, v[34:35], off offset:228              // 00000013DAC0: DC5200E4 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DAC8: BF8903F7
	v_fma_mixhi_f16 v30, v18, s18, 0                           // 00000013DACC: CC22001E 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DAD4: 8C7E0B7E
	.long 0x7f3e3880                                           // 00000013DAD8: 7F3E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013DADC: BF870001
	.long 0x7e3e399f                                           // 00000013DAE0: 7E3E399F
	s_and_saveexec_b32 s11, s0                                 // 00000013DAE4: BE8B2000
	s_cbranch_execz 5                                          // 00000013DAE8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e00>
	global_load_b32 v18, v[34:35], off offset:232              // 00000013DAEC: DC5200E8 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DAF4: BF8903F7
	v_fma_mixlo_f16 v31, v18, s18, 0                           // 00000013DAF8: CC21001F 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DB00: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DB04: BE8B2000
	s_cbranch_execz 5                                          // 00000013DB08: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e20>
	global_load_b32 v18, v[34:35], off offset:236              // 00000013DB0C: DC5200EC 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DB14: BF8903F7
	v_fma_mixhi_f16 v31, v18, s18, 0                           // 00000013DB18: CC22001F 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DB20: 8C7E0B7E
	.long 0x7f403880                                           // 00000013DB24: 7F403880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013DB28: BF870001
	.long 0x7e4039a0                                           // 00000013DB2C: 7E4039A0
	s_and_saveexec_b32 s11, s0                                 // 00000013DB30: BE8B2000
	s_cbranch_execz 5                                          // 00000013DB34: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e4c>
	global_load_b32 v18, v[34:35], off offset:240              // 00000013DB38: DC5200F0 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DB40: BF8903F7
	v_fma_mixlo_f16 v32, v18, s18, 0                           // 00000013DB44: CC210020 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DB4C: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DB50: BE8B2000
	s_cbranch_execz 5                                          // 00000013DB54: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e6c>
	global_load_b32 v18, v[34:35], off offset:244              // 00000013DB58: DC5200F4 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DB60: BF8903F7
	v_fma_mixhi_f16 v32, v18, s18, 0                           // 00000013DB64: CC220020 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DB6C: 8C7E0B7E
	.long 0x7f423880                                           // 00000013DB70: 7F423880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013DB74: BF870001
	.long 0x7e4239a1                                           // 00000013DB78: 7E4239A1
	s_and_saveexec_b32 s11, s0                                 // 00000013DB7C: BE8B2000
	s_cbranch_execz 5                                          // 00000013DB80: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e98>
	global_load_b32 v18, v[34:35], off offset:248              // 00000013DB84: DC5200F8 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DB8C: BF8903F7
	v_fma_mixlo_f16 v33, v18, s18, 0                           // 00000013DB90: CC210021 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DB98: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DB9C: BE8B2000
	s_cbranch_execz 5                                          // 00000013DBA0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2eb8>
	global_load_b32 v18, v[34:35], off offset:252              // 00000013DBA4: DC5200FC 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DBAC: BF8903F7
	v_fma_mixhi_f16 v33, v18, s18, 0                           // 00000013DBB0: CC220021 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DBB8: 8C7E0B7E
	ds_load_b128 v[18:21], v57 offset:192                      // 00000013DBBC: DBFC00C0 12000039
	ds_load_b128 v[22:25], v57 offset:208                      // 00000013DBC4: DBFC00D0 16000039
	ds_load_b128 v[40:43], v57 offset:224                      // 00000013DBCC: DBFC00E0 28000039
	ds_load_b128 v[44:47], v57 offset:240                      // 00000013DBD4: DBFC00F0 2C000039
	s_waitcnt lgkmcnt(3)                                       // 00000013DBDC: BF89FC37
	v_fma_mixlo_f16 v36, v18, s18, 0                           // 00000013DBE0: CC210024 02002512
	v_fma_mixhi_f16 v36, v19, s18, 0                           // 00000013DBE8: CC220024 02002513
	v_fma_mixlo_f16 v37, v20, s18, 0                           // 00000013DBF0: CC210025 02002514
	v_fma_mixhi_f16 v37, v21, s18, 0                           // 00000013DBF8: CC220025 02002515
	s_waitcnt lgkmcnt(2)                                       // 00000013DC00: BF89FC27
	v_fma_mixlo_f16 v38, v22, s18, 0                           // 00000013DC04: CC210026 02002516
	v_fma_mixhi_f16 v38, v23, s18, 0                           // 00000013DC0C: CC220026 02002517
	v_fma_mixlo_f16 v39, v24, s18, 0                           // 00000013DC14: CC210027 02002518
	v_fma_mixhi_f16 v39, v25, s18, 0                           // 00000013DC1C: CC220027 02002519
	s_waitcnt lgkmcnt(1)                                       // 00000013DC24: BF89FC17
	v_fma_mixlo_f16 v40, v40, s18, 0                           // 00000013DC28: CC210028 02002528
	v_fma_mixhi_f16 v40, v41, s18, 0                           // 00000013DC30: CC220028 02002529
	v_fma_mixlo_f16 v41, v42, s18, 0                           // 00000013DC38: CC210029 0200252A
	v_fma_mixhi_f16 v41, v43, s18, 0                           // 00000013DC40: CC220029 0200252B
	s_waitcnt lgkmcnt(0)                                       // 00000013DC48: BF89FC07
	v_fma_mixlo_f16 v42, v44, s18, 0                           // 00000013DC4C: CC21002A 0200252C
	v_fma_mixhi_f16 v42, v45, s18, 0                           // 00000013DC54: CC22002A 0200252D
	v_fma_mixlo_f16 v43, v46, s18, 0                           // 00000013DC5C: CC21002B 0200252E
	v_fma_mixhi_f16 v43, v47, s18, 0                           // 00000013DC64: CC22002B 0200252F
	.long 0x7f243880                                           // 00000013DC6C: 7F243880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013DC70: BF870112
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[36:43], v[10:17]// 00000013DC74: CC40400A 1C2A491A
	.long 0x7e243992                                           // 00000013DC7C: 7E243992
	s_and_saveexec_b32 s11, s0                                 // 00000013DC80: BE8B2000
	s_cbranch_execz 5                                          // 00000013DC84: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2f9c>
	global_load_b32 v19, v[34:35], off offset:256              // 00000013DC88: DC520100 137C0022
	s_waitcnt vmcnt(0)                                         // 00000013DC90: BF8903F7
	v_fma_mixlo_f16 v18, v19, s18, 0                           // 00000013DC94: CC210012 02002513
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DC9C: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DCA0: BE8B2000
	s_cbranch_execz 5                                          // 00000013DCA4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2fbc>
	global_load_b32 v19, v[34:35], off offset:260              // 00000013DCA8: DC520104 137C0022
	s_waitcnt vmcnt(0)                                         // 00000013DCB0: BF8903F7
	v_fma_mixhi_f16 v18, v19, s18, 0                           // 00000013DCB4: CC220012 02002513
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DCBC: 8C7E0B7E
	.long 0x7f263880                                           // 00000013DCC0: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013DCC4: BF870001
	.long 0x7e263993                                           // 00000013DCC8: 7E263993
	s_and_saveexec_b32 s11, s0                                 // 00000013DCCC: BE8B2000
	s_cbranch_execz 5                                          // 00000013DCD0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2fe8>
	global_load_b32 v20, v[34:35], off offset:264              // 00000013DCD4: DC520108 147C0022
	s_waitcnt vmcnt(0)                                         // 00000013DCDC: BF8903F7
	v_fma_mixlo_f16 v19, v20, s18, 0                           // 00000013DCE0: CC210013 02002514
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DCE8: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DCEC: BE8B2000
	s_cbranch_execz 5                                          // 00000013DCF0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3008>
	global_load_b32 v20, v[34:35], off offset:268              // 00000013DCF4: DC52010C 147C0022
	s_waitcnt vmcnt(0)                                         // 00000013DCFC: BF8903F7
	v_fma_mixhi_f16 v19, v20, s18, 0                           // 00000013DD00: CC220013 02002514
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DD08: 8C7E0B7E
	.long 0x7f283880                                           // 00000013DD0C: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013DD10: BF870001
	.long 0x7e283994                                           // 00000013DD14: 7E283994
	s_and_saveexec_b32 s11, s0                                 // 00000013DD18: BE8B2000
	s_cbranch_execz 5                                          // 00000013DD1C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3034>
	global_load_b32 v21, v[34:35], off offset:272              // 00000013DD20: DC520110 157C0022
	s_waitcnt vmcnt(0)                                         // 00000013DD28: BF8903F7
	v_fma_mixlo_f16 v20, v21, s18, 0                           // 00000013DD2C: CC210014 02002515
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DD34: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DD38: BE8B2000
	s_cbranch_execz 5                                          // 00000013DD3C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3054>
	global_load_b32 v21, v[34:35], off offset:276              // 00000013DD40: DC520114 157C0022
	s_waitcnt vmcnt(0)                                         // 00000013DD48: BF8903F7
	v_fma_mixhi_f16 v20, v21, s18, 0                           // 00000013DD4C: CC220014 02002515
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DD54: 8C7E0B7E
	.long 0x7f2a3880                                           // 00000013DD58: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013DD5C: BF870001
	.long 0x7e2a3995                                           // 00000013DD60: 7E2A3995
	s_and_saveexec_b32 s11, s0                                 // 00000013DD64: BE8B2000
	s_cbranch_execz 5                                          // 00000013DD68: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3080>
	global_load_b32 v22, v[34:35], off offset:280              // 00000013DD6C: DC520118 167C0022
	s_waitcnt vmcnt(0)                                         // 00000013DD74: BF8903F7
	v_fma_mixlo_f16 v21, v22, s18, 0                           // 00000013DD78: CC210015 02002516
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DD80: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DD84: BE8B2000
	s_cbranch_execz 5                                          // 00000013DD88: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x30a0>
	global_load_b32 v22, v[34:35], off offset:284              // 00000013DD8C: DC52011C 167C0022
	s_waitcnt vmcnt(0)                                         // 00000013DD94: BF8903F7
	v_fma_mixhi_f16 v21, v22, s18, 0                           // 00000013DD98: CC220015 02002516
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DDA0: 8C7E0B7E
	.long 0x7f2c3880                                           // 00000013DDA4: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013DDA8: BF870001
	.long 0x7e2c3996                                           // 00000013DDAC: 7E2C3996
	s_and_saveexec_b32 s11, s0                                 // 00000013DDB0: BE8B2000
	s_cbranch_execz 5                                          // 00000013DDB4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x30cc>
	global_load_b32 v23, v[34:35], off offset:288              // 00000013DDB8: DC520120 177C0022
	s_waitcnt vmcnt(0)                                         // 00000013DDC0: BF8903F7
	v_fma_mixlo_f16 v22, v23, s18, 0                           // 00000013DDC4: CC210016 02002517
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DDCC: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DDD0: BE8B2000
	s_cbranch_execz 5                                          // 00000013DDD4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x30ec>
	global_load_b32 v23, v[34:35], off offset:292              // 00000013DDD8: DC520124 177C0022
	s_waitcnt vmcnt(0)                                         // 00000013DDE0: BF8903F7
	v_fma_mixhi_f16 v22, v23, s18, 0                           // 00000013DDE4: CC220016 02002517
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DDEC: 8C7E0B7E
	.long 0x7f2e3880                                           // 00000013DDF0: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013DDF4: BF870001
	.long 0x7e2e3997                                           // 00000013DDF8: 7E2E3997
	s_and_saveexec_b32 s11, s0                                 // 00000013DDFC: BE8B2000
	s_cbranch_execz 5                                          // 00000013DE00: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3118>
	global_load_b32 v24, v[34:35], off offset:296              // 00000013DE04: DC520128 187C0022
	s_waitcnt vmcnt(0)                                         // 00000013DE0C: BF8903F7
	v_fma_mixlo_f16 v23, v24, s18, 0                           // 00000013DE10: CC210017 02002518
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DE18: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DE1C: BE8B2000
	s_cbranch_execz 5                                          // 00000013DE20: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3138>
	global_load_b32 v24, v[34:35], off offset:300              // 00000013DE24: DC52012C 187C0022
	s_waitcnt vmcnt(0)                                         // 00000013DE2C: BF8903F7
	v_fma_mixhi_f16 v23, v24, s18, 0                           // 00000013DE30: CC220017 02002518
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DE38: 8C7E0B7E
	.long 0x7f303880                                           // 00000013DE3C: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013DE40: BF870001
	.long 0x7e303998                                           // 00000013DE44: 7E303998
	s_and_saveexec_b32 s11, s0                                 // 00000013DE48: BE8B2000
	s_cbranch_execz 5                                          // 00000013DE4C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3164>
	global_load_b32 v25, v[34:35], off offset:304              // 00000013DE50: DC520130 197C0022
	s_waitcnt vmcnt(0)                                         // 00000013DE58: BF8903F7
	v_fma_mixlo_f16 v24, v25, s18, 0                           // 00000013DE5C: CC210018 02002519
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DE64: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DE68: BE8B2000
	s_cbranch_execz 5                                          // 00000013DE6C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3184>
	global_load_b32 v25, v[34:35], off offset:308              // 00000013DE70: DC520134 197C0022
	s_waitcnt vmcnt(0)                                         // 00000013DE78: BF8903F7
	v_fma_mixhi_f16 v24, v25, s18, 0                           // 00000013DE7C: CC220018 02002519
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DE84: 8C7E0B7E
	.long 0x7f323880                                           // 00000013DE88: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013DE8C: BF870001
	.long 0x7e323999                                           // 00000013DE90: 7E323999
	s_and_saveexec_b32 s11, s0                                 // 00000013DE94: BE8B2000
	s_cbranch_execz 5                                          // 00000013DE98: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x31b0>
	global_load_b32 v26, v[34:35], off offset:312              // 00000013DE9C: DC520138 1A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013DEA4: BF8903F7
	v_fma_mixlo_f16 v25, v26, s18, 0                           // 00000013DEA8: CC210019 0200251A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DEB0: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DEB4: BE8B2000
	s_cbranch_execz 5                                          // 00000013DEB8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x31d0>
	global_load_b32 v26, v[34:35], off offset:316              // 00000013DEBC: DC52013C 1A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013DEC4: BF8903F7
	v_fma_mixhi_f16 v25, v26, s18, 0                           // 00000013DEC8: CC220019 0200251A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DED0: 8C7E0B7E
	ds_load_b128 v[26:29], v57 offset:256                      // 00000013DED4: DBFC0100 1A000039
	ds_load_b128 v[30:33], v57 offset:272                      // 00000013DEDC: DBFC0110 1E000039
	ds_load_b128 v[40:43], v57 offset:288                      // 00000013DEE4: DBFC0120 28000039
	ds_load_b128 v[44:47], v57 offset:304                      // 00000013DEEC: DBFC0130 2C000039
	s_waitcnt lgkmcnt(3)                                       // 00000013DEF4: BF89FC37
	v_fma_mixlo_f16 v36, v26, s18, 0                           // 00000013DEF8: CC210024 0200251A
	v_fma_mixhi_f16 v36, v27, s18, 0                           // 00000013DF00: CC220024 0200251B
	v_fma_mixlo_f16 v37, v28, s18, 0                           // 00000013DF08: CC210025 0200251C
	v_fma_mixhi_f16 v37, v29, s18, 0                           // 00000013DF10: CC220025 0200251D
	s_waitcnt lgkmcnt(2)                                       // 00000013DF18: BF89FC27
	v_fma_mixlo_f16 v38, v30, s18, 0                           // 00000013DF1C: CC210026 0200251E
	v_fma_mixhi_f16 v38, v31, s18, 0                           // 00000013DF24: CC220026 0200251F
	v_fma_mixlo_f16 v39, v32, s18, 0                           // 00000013DF2C: CC210027 02002520
	v_fma_mixhi_f16 v39, v33, s18, 0                           // 00000013DF34: CC220027 02002521
	s_waitcnt lgkmcnt(1)                                       // 00000013DF3C: BF89FC17
	v_fma_mixlo_f16 v40, v40, s18, 0                           // 00000013DF40: CC210028 02002528
	v_fma_mixhi_f16 v40, v41, s18, 0                           // 00000013DF48: CC220028 02002529
	v_fma_mixlo_f16 v41, v42, s18, 0                           // 00000013DF50: CC210029 0200252A
	v_fma_mixhi_f16 v41, v43, s18, 0                           // 00000013DF58: CC220029 0200252B
	s_waitcnt lgkmcnt(0)                                       // 00000013DF60: BF89FC07
	v_fma_mixlo_f16 v42, v44, s18, 0                           // 00000013DF64: CC21002A 0200252C
	v_fma_mixhi_f16 v42, v45, s18, 0                           // 00000013DF6C: CC22002A 0200252D
	v_fma_mixlo_f16 v43, v46, s18, 0                           // 00000013DF74: CC21002B 0200252E
	v_fma_mixhi_f16 v43, v47, s18, 0                           // 00000013DF7C: CC22002B 0200252F
	.long 0x7f343880                                           // 00000013DF84: 7F343880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013DF88: BF870112
	v_wmma_f32_16x16x16_f16 v[10:17], v[18:25], v[36:43], v[10:17]// 00000013DF8C: CC40400A 1C2A4912
	.long 0x7e34399a                                           // 00000013DF94: 7E34399A
	s_and_saveexec_b32 s11, s0                                 // 00000013DF98: BE8B2000
	s_cbranch_execz 5                                          // 00000013DF9C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x32b4>
	global_load_b32 v18, v[34:35], off offset:320              // 00000013DFA0: DC520140 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DFA8: BF8903F7
	v_fma_mixlo_f16 v26, v18, s18, 0                           // 00000013DFAC: CC21001A 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DFB4: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013DFB8: BE8B2000
	s_cbranch_execz 5                                          // 00000013DFBC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x32d4>
	global_load_b32 v18, v[34:35], off offset:324              // 00000013DFC0: DC520144 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DFC8: BF8903F7
	v_fma_mixhi_f16 v26, v18, s18, 0                           // 00000013DFCC: CC22001A 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013DFD4: 8C7E0B7E
	.long 0x7f363880                                           // 00000013DFD8: 7F363880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013DFDC: BF870001
	.long 0x7e36399b                                           // 00000013DFE0: 7E36399B
	s_and_saveexec_b32 s11, s0                                 // 00000013DFE4: BE8B2000
	s_cbranch_execz 5                                          // 00000013DFE8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3300>
	global_load_b32 v18, v[34:35], off offset:328              // 00000013DFEC: DC520148 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013DFF4: BF8903F7
	v_fma_mixlo_f16 v27, v18, s18, 0                           // 00000013DFF8: CC21001B 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E000: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E004: BE8B2000
	s_cbranch_execz 5                                          // 00000013E008: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3320>
	global_load_b32 v18, v[34:35], off offset:332              // 00000013E00C: DC52014C 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E014: BF8903F7
	v_fma_mixhi_f16 v27, v18, s18, 0                           // 00000013E018: CC22001B 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E020: 8C7E0B7E
	.long 0x7f383880                                           // 00000013E024: 7F383880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E028: BF870001
	.long 0x7e38399c                                           // 00000013E02C: 7E38399C
	s_and_saveexec_b32 s11, s0                                 // 00000013E030: BE8B2000
	s_cbranch_execz 5                                          // 00000013E034: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x334c>
	global_load_b32 v18, v[34:35], off offset:336              // 00000013E038: DC520150 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E040: BF8903F7
	v_fma_mixlo_f16 v28, v18, s18, 0                           // 00000013E044: CC21001C 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E04C: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E050: BE8B2000
	s_cbranch_execz 5                                          // 00000013E054: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x336c>
	global_load_b32 v18, v[34:35], off offset:340              // 00000013E058: DC520154 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E060: BF8903F7
	v_fma_mixhi_f16 v28, v18, s18, 0                           // 00000013E064: CC22001C 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E06C: 8C7E0B7E
	.long 0x7f3a3880                                           // 00000013E070: 7F3A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E074: BF870001
	.long 0x7e3a399d                                           // 00000013E078: 7E3A399D
	s_and_saveexec_b32 s11, s0                                 // 00000013E07C: BE8B2000
	s_cbranch_execz 5                                          // 00000013E080: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3398>
	global_load_b32 v18, v[34:35], off offset:344              // 00000013E084: DC520158 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E08C: BF8903F7
	v_fma_mixlo_f16 v29, v18, s18, 0                           // 00000013E090: CC21001D 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E098: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E09C: BE8B2000
	s_cbranch_execz 5                                          // 00000013E0A0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33b8>
	global_load_b32 v18, v[34:35], off offset:348              // 00000013E0A4: DC52015C 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E0AC: BF8903F7
	v_fma_mixhi_f16 v29, v18, s18, 0                           // 00000013E0B0: CC22001D 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E0B8: 8C7E0B7E
	.long 0x7f3c3880                                           // 00000013E0BC: 7F3C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E0C0: BF870001
	.long 0x7e3c399e                                           // 00000013E0C4: 7E3C399E
	s_and_saveexec_b32 s11, s0                                 // 00000013E0C8: BE8B2000
	s_cbranch_execz 5                                          // 00000013E0CC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x33e4>
	global_load_b32 v18, v[34:35], off offset:352              // 00000013E0D0: DC520160 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E0D8: BF8903F7
	v_fma_mixlo_f16 v30, v18, s18, 0                           // 00000013E0DC: CC21001E 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E0E4: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E0E8: BE8B2000
	s_cbranch_execz 5                                          // 00000013E0EC: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3404>
	global_load_b32 v18, v[34:35], off offset:356              // 00000013E0F0: DC520164 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E0F8: BF8903F7
	v_fma_mixhi_f16 v30, v18, s18, 0                           // 00000013E0FC: CC22001E 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E104: 8C7E0B7E
	.long 0x7f3e3880                                           // 00000013E108: 7F3E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E10C: BF870001
	.long 0x7e3e399f                                           // 00000013E110: 7E3E399F
	s_and_saveexec_b32 s11, s0                                 // 00000013E114: BE8B2000
	s_cbranch_execz 5                                          // 00000013E118: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3430>
	global_load_b32 v18, v[34:35], off offset:360              // 00000013E11C: DC520168 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E124: BF8903F7
	v_fma_mixlo_f16 v31, v18, s18, 0                           // 00000013E128: CC21001F 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E130: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E134: BE8B2000
	s_cbranch_execz 5                                          // 00000013E138: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3450>
	global_load_b32 v18, v[34:35], off offset:364              // 00000013E13C: DC52016C 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E144: BF8903F7
	v_fma_mixhi_f16 v31, v18, s18, 0                           // 00000013E148: CC22001F 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E150: 8C7E0B7E
	.long 0x7f403880                                           // 00000013E154: 7F403880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E158: BF870001
	.long 0x7e4039a0                                           // 00000013E15C: 7E4039A0
	s_and_saveexec_b32 s11, s0                                 // 00000013E160: BE8B2000
	s_cbranch_execz 5                                          // 00000013E164: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x347c>
	global_load_b32 v18, v[34:35], off offset:368              // 00000013E168: DC520170 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E170: BF8903F7
	v_fma_mixlo_f16 v32, v18, s18, 0                           // 00000013E174: CC210020 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E17C: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E180: BE8B2000
	s_cbranch_execz 5                                          // 00000013E184: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x349c>
	global_load_b32 v18, v[34:35], off offset:372              // 00000013E188: DC520174 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E190: BF8903F7
	v_fma_mixhi_f16 v32, v18, s18, 0                           // 00000013E194: CC220020 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E19C: 8C7E0B7E
	.long 0x7f423880                                           // 00000013E1A0: 7F423880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E1A4: BF870001
	.long 0x7e4239a1                                           // 00000013E1A8: 7E4239A1
	s_and_saveexec_b32 s11, s0                                 // 00000013E1AC: BE8B2000
	s_cbranch_execz 5                                          // 00000013E1B0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x34c8>
	global_load_b32 v18, v[34:35], off offset:376              // 00000013E1B4: DC520178 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E1BC: BF8903F7
	v_fma_mixlo_f16 v33, v18, s18, 0                           // 00000013E1C0: CC210021 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E1C8: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E1CC: BE8B2000
	s_cbranch_execz 5                                          // 00000013E1D0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x34e8>
	global_load_b32 v18, v[34:35], off offset:380              // 00000013E1D4: DC52017C 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E1DC: BF8903F7
	v_fma_mixhi_f16 v33, v18, s18, 0                           // 00000013E1E0: CC220021 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E1E8: 8C7E0B7E
	ds_load_b128 v[18:21], v57 offset:320                      // 00000013E1EC: DBFC0140 12000039
	ds_load_b128 v[22:25], v57 offset:336                      // 00000013E1F4: DBFC0150 16000039
	ds_load_b128 v[40:43], v57 offset:352                      // 00000013E1FC: DBFC0160 28000039
	ds_load_b128 v[44:47], v57 offset:368                      // 00000013E204: DBFC0170 2C000039
	s_waitcnt lgkmcnt(3)                                       // 00000013E20C: BF89FC37
	v_fma_mixlo_f16 v36, v18, s18, 0                           // 00000013E210: CC210024 02002512
	v_fma_mixhi_f16 v36, v19, s18, 0                           // 00000013E218: CC220024 02002513
	v_fma_mixlo_f16 v37, v20, s18, 0                           // 00000013E220: CC210025 02002514
	v_fma_mixhi_f16 v37, v21, s18, 0                           // 00000013E228: CC220025 02002515
	s_waitcnt lgkmcnt(2)                                       // 00000013E230: BF89FC27
	v_fma_mixlo_f16 v38, v22, s18, 0                           // 00000013E234: CC210026 02002516
	v_fma_mixhi_f16 v38, v23, s18, 0                           // 00000013E23C: CC220026 02002517
	v_fma_mixlo_f16 v39, v24, s18, 0                           // 00000013E244: CC210027 02002518
	v_fma_mixhi_f16 v39, v25, s18, 0                           // 00000013E24C: CC220027 02002519
	s_waitcnt lgkmcnt(1)                                       // 00000013E254: BF89FC17
	v_fma_mixlo_f16 v40, v40, s18, 0                           // 00000013E258: CC210028 02002528
	v_fma_mixhi_f16 v40, v41, s18, 0                           // 00000013E260: CC220028 02002529
	v_fma_mixlo_f16 v41, v42, s18, 0                           // 00000013E268: CC210029 0200252A
	v_fma_mixhi_f16 v41, v43, s18, 0                           // 00000013E270: CC220029 0200252B
	s_waitcnt lgkmcnt(0)                                       // 00000013E278: BF89FC07
	v_fma_mixlo_f16 v42, v44, s18, 0                           // 00000013E27C: CC21002A 0200252C
	v_fma_mixhi_f16 v42, v45, s18, 0                           // 00000013E284: CC22002A 0200252D
	v_fma_mixlo_f16 v43, v46, s18, 0                           // 00000013E28C: CC21002B 0200252E
	v_fma_mixhi_f16 v43, v47, s18, 0                           // 00000013E294: CC22002B 0200252F
	.long 0x7f263880                                           // 00000013E29C: 7F263880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000013E2A0: BF870112
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[36:43], v[10:17]// 00000013E2A4: CC40400A 1C2A491A
	.long 0x7e263993                                           // 00000013E2AC: 7E263993
	s_and_saveexec_b32 s11, s0                                 // 00000013E2B0: BE8B2000
	s_cbranch_execz 5                                          // 00000013E2B4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x35cc>
	global_load_b32 v18, v[34:35], off offset:384              // 00000013E2B8: DC520180 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E2C0: BF8903F7
	v_fma_mixlo_f16 v19, v18, s18, 0                           // 00000013E2C4: CC210013 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E2CC: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E2D0: BE8B2000
	s_cbranch_execz 5                                          // 00000013E2D4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x35ec>
	global_load_b32 v18, v[34:35], off offset:388              // 00000013E2D8: DC520184 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E2E0: BF8903F7
	v_fma_mixhi_f16 v19, v18, s18, 0                           // 00000013E2E4: CC220013 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E2EC: 8C7E0B7E
	.long 0x7f283880                                           // 00000013E2F0: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E2F4: BF870001
	.long 0x7e283994                                           // 00000013E2F8: 7E283994
	s_and_saveexec_b32 s11, s0                                 // 00000013E2FC: BE8B2000
	s_cbranch_execz 5                                          // 00000013E300: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3618>
	global_load_b32 v18, v[34:35], off offset:392              // 00000013E304: DC520188 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E30C: BF8903F7
	v_fma_mixlo_f16 v20, v18, s18, 0                           // 00000013E310: CC210014 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E318: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E31C: BE8B2000
	s_cbranch_execz 5                                          // 00000013E320: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3638>
	global_load_b32 v18, v[34:35], off offset:396              // 00000013E324: DC52018C 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E32C: BF8903F7
	v_fma_mixhi_f16 v20, v18, s18, 0                           // 00000013E330: CC220014 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E338: 8C7E0B7E
	.long 0x7f2a3880                                           // 00000013E33C: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E340: BF870001
	.long 0x7e2a3995                                           // 00000013E344: 7E2A3995
	s_and_saveexec_b32 s11, s0                                 // 00000013E348: BE8B2000
	s_cbranch_execz 5                                          // 00000013E34C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3664>
	global_load_b32 v18, v[34:35], off offset:400              // 00000013E350: DC520190 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E358: BF8903F7
	v_fma_mixlo_f16 v21, v18, s18, 0                           // 00000013E35C: CC210015 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E364: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E368: BE8B2000
	s_cbranch_execz 5                                          // 00000013E36C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3684>
	global_load_b32 v18, v[34:35], off offset:404              // 00000013E370: DC520194 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E378: BF8903F7
	v_fma_mixhi_f16 v21, v18, s18, 0                           // 00000013E37C: CC220015 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E384: 8C7E0B7E
	.long 0x7f2c3880                                           // 00000013E388: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E38C: BF870001
	.long 0x7e2c3996                                           // 00000013E390: 7E2C3996
	s_and_saveexec_b32 s11, s0                                 // 00000013E394: BE8B2000
	s_cbranch_execz 5                                          // 00000013E398: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x36b0>
	global_load_b32 v18, v[34:35], off offset:408              // 00000013E39C: DC520198 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E3A4: BF8903F7
	v_fma_mixlo_f16 v22, v18, s18, 0                           // 00000013E3A8: CC210016 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E3B0: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E3B4: BE8B2000
	s_cbranch_execz 5                                          // 00000013E3B8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x36d0>
	global_load_b32 v18, v[34:35], off offset:412              // 00000013E3BC: DC52019C 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E3C4: BF8903F7
	v_fma_mixhi_f16 v22, v18, s18, 0                           // 00000013E3C8: CC220016 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E3D0: 8C7E0B7E
	.long 0x7f2e3880                                           // 00000013E3D4: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E3D8: BF870001
	.long 0x7e2e3997                                           // 00000013E3DC: 7E2E3997
	s_and_saveexec_b32 s11, s0                                 // 00000013E3E0: BE8B2000
	s_cbranch_execz 5                                          // 00000013E3E4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x36fc>
	global_load_b32 v18, v[34:35], off offset:416              // 00000013E3E8: DC5201A0 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E3F0: BF8903F7
	v_fma_mixlo_f16 v23, v18, s18, 0                           // 00000013E3F4: CC210017 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E3FC: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E400: BE8B2000
	s_cbranch_execz 5                                          // 00000013E404: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x371c>
	global_load_b32 v18, v[34:35], off offset:420              // 00000013E408: DC5201A4 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E410: BF8903F7
	v_fma_mixhi_f16 v23, v18, s18, 0                           // 00000013E414: CC220017 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E41C: 8C7E0B7E
	.long 0x7f303880                                           // 00000013E420: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E424: BF870001
	.long 0x7e303998                                           // 00000013E428: 7E303998
	s_and_saveexec_b32 s11, s0                                 // 00000013E42C: BE8B2000
	s_cbranch_execz 5                                          // 00000013E430: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3748>
	global_load_b32 v18, v[34:35], off offset:424              // 00000013E434: DC5201A8 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E43C: BF8903F7
	v_fma_mixlo_f16 v24, v18, s18, 0                           // 00000013E440: CC210018 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E448: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E44C: BE8B2000
	s_cbranch_execz 5                                          // 00000013E450: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3768>
	global_load_b32 v18, v[34:35], off offset:428              // 00000013E454: DC5201AC 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E45C: BF8903F7
	v_fma_mixhi_f16 v24, v18, s18, 0                           // 00000013E460: CC220018 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E468: 8C7E0B7E
	.long 0x7f323880                                           // 00000013E46C: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E470: BF870001
	.long 0x7e323999                                           // 00000013E474: 7E323999
	s_and_saveexec_b32 s11, s0                                 // 00000013E478: BE8B2000
	s_cbranch_execz 5                                          // 00000013E47C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3794>
	global_load_b32 v18, v[34:35], off offset:432              // 00000013E480: DC5201B0 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E488: BF8903F7
	v_fma_mixlo_f16 v25, v18, s18, 0                           // 00000013E48C: CC210019 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E494: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E498: BE8B2000
	s_cbranch_execz 5                                          // 00000013E49C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x37b4>
	global_load_b32 v18, v[34:35], off offset:436              // 00000013E4A0: DC5201B4 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E4A8: BF8903F7
	v_fma_mixhi_f16 v25, v18, s18, 0                           // 00000013E4AC: CC220019 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E4B4: 8C7E0B7E
	.long 0x7f343880                                           // 00000013E4B8: 7F343880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E4BC: BF870001
	.long 0x7e34399a                                           // 00000013E4C0: 7E34399A
	s_and_saveexec_b32 s11, s0                                 // 00000013E4C4: BE8B2000
	s_cbranch_execz 5                                          // 00000013E4C8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x37e0>
	global_load_b32 v18, v[34:35], off offset:440              // 00000013E4CC: DC5201B8 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E4D4: BF8903F7
	v_fma_mixlo_f16 v26, v18, s18, 0                           // 00000013E4D8: CC21001A 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E4E0: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E4E4: BE8B2000
	s_cbranch_execz 5                                          // 00000013E4E8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3800>
	global_load_b32 v18, v[34:35], off offset:444              // 00000013E4EC: DC5201BC 127C0022
	s_waitcnt vmcnt(0)                                         // 00000013E4F4: BF8903F7
	v_fma_mixhi_f16 v26, v18, s18, 0                           // 00000013E4F8: CC22001A 02002512
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E500: 8C7E0B7E
	ds_load_b128 v[27:30], v57 offset:384                      // 00000013E504: DBFC0180 1B000039
	ds_load_b128 v[38:41], v57 offset:400                      // 00000013E50C: DBFC0190 26000039
	ds_load_b128 v[42:45], v57 offset:416                      // 00000013E514: DBFC01A0 2A000039
	ds_load_b128 v[46:49], v57 offset:432                      // 00000013E51C: DBFC01B0 2E000039
	.long 0x7f243880                                           // 00000013E524: 7F243880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E528: BF870001
	.long 0x7e243992                                           // 00000013E52C: 7E243992
	s_waitcnt lgkmcnt(3)                                       // 00000013E530: BF89FC37
	v_fma_mixlo_f16 v36, v27, s18, 0                           // 00000013E534: CC210024 0200251B
	v_fma_mixhi_f16 v36, v28, s18, 0                           // 00000013E53C: CC220024 0200251C
	v_fma_mixlo_f16 v37, v29, s18, 0                           // 00000013E544: CC210025 0200251D
	v_fma_mixhi_f16 v37, v30, s18, 0                           // 00000013E54C: CC220025 0200251E
	s_waitcnt lgkmcnt(2)                                       // 00000013E554: BF89FC27
	v_fma_mixlo_f16 v38, v38, s18, 0                           // 00000013E558: CC210026 02002526
	v_fma_mixhi_f16 v38, v39, s18, 0                           // 00000013E560: CC220026 02002527
	v_fma_mixlo_f16 v39, v40, s18, 0                           // 00000013E568: CC210027 02002528
	v_fma_mixhi_f16 v39, v41, s18, 0                           // 00000013E570: CC220027 02002529
	s_waitcnt lgkmcnt(1)                                       // 00000013E578: BF89FC17
	v_fma_mixlo_f16 v40, v42, s18, 0                           // 00000013E57C: CC210028 0200252A
	v_fma_mixhi_f16 v40, v43, s18, 0                           // 00000013E584: CC220028 0200252B
	v_fma_mixlo_f16 v41, v44, s18, 0                           // 00000013E58C: CC210029 0200252C
	v_fma_mixhi_f16 v41, v45, s18, 0                           // 00000013E594: CC220029 0200252D
	s_waitcnt lgkmcnt(0)                                       // 00000013E59C: BF89FC07
	v_fma_mixlo_f16 v42, v46, s18, 0                           // 00000013E5A0: CC21002A 0200252E
	v_fma_mixhi_f16 v42, v47, s18, 0                           // 00000013E5A8: CC22002A 0200252F
	v_fma_mixlo_f16 v43, v48, s18, 0                           // 00000013E5B0: CC21002B 02002530
	v_fma_mixhi_f16 v43, v49, s18, 0                           // 00000013E5B8: CC22002B 02002531
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E5C0: BF870001
	v_wmma_f32_16x16x16_f16 v[10:17], v[19:26], v[36:43], v[10:17]// 00000013E5C4: CC40400A 1C2A4913
	s_and_saveexec_b32 s11, s0                                 // 00000013E5CC: BE8B2000
	s_cbranch_execz 5                                          // 00000013E5D0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x38e8>
	global_load_b32 v19, v[34:35], off offset:448              // 00000013E5D4: DC5201C0 137C0022
	s_waitcnt vmcnt(0)                                         // 00000013E5DC: BF8903F7
	v_fma_mixlo_f16 v18, v19, s18, 0                           // 00000013E5E0: CC210012 02002513
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E5E8: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E5EC: BE8B2000
	s_cbranch_execz 5                                          // 00000013E5F0: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3908>
	global_load_b32 v19, v[34:35], off offset:452              // 00000013E5F4: DC5201C4 137C0022
	s_waitcnt vmcnt(0)                                         // 00000013E5FC: BF8903F7
	v_fma_mixhi_f16 v18, v19, s18, 0                           // 00000013E600: CC220012 02002513
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E608: 8C7E0B7E
	.long 0x7f263880                                           // 00000013E60C: 7F263880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E610: BF870001
	.long 0x7e263993                                           // 00000013E614: 7E263993
	s_and_saveexec_b32 s11, s0                                 // 00000013E618: BE8B2000
	s_cbranch_execz 5                                          // 00000013E61C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3934>
	global_load_b32 v20, v[34:35], off offset:456              // 00000013E620: DC5201C8 147C0022
	s_waitcnt vmcnt(0)                                         // 00000013E628: BF8903F7
	v_fma_mixlo_f16 v19, v20, s18, 0                           // 00000013E62C: CC210013 02002514
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E634: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E638: BE8B2000
	s_cbranch_execz 5                                          // 00000013E63C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3954>
	global_load_b32 v20, v[34:35], off offset:460              // 00000013E640: DC5201CC 147C0022
	s_waitcnt vmcnt(0)                                         // 00000013E648: BF8903F7
	v_fma_mixhi_f16 v19, v20, s18, 0                           // 00000013E64C: CC220013 02002514
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E654: 8C7E0B7E
	.long 0x7f283880                                           // 00000013E658: 7F283880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E65C: BF870001
	.long 0x7e283994                                           // 00000013E660: 7E283994
	s_and_saveexec_b32 s11, s0                                 // 00000013E664: BE8B2000
	s_cbranch_execz 5                                          // 00000013E668: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3980>
	global_load_b32 v21, v[34:35], off offset:464              // 00000013E66C: DC5201D0 157C0022
	s_waitcnt vmcnt(0)                                         // 00000013E674: BF8903F7
	v_fma_mixlo_f16 v20, v21, s18, 0                           // 00000013E678: CC210014 02002515
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E680: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E684: BE8B2000
	s_cbranch_execz 5                                          // 00000013E688: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x39a0>
	global_load_b32 v21, v[34:35], off offset:468              // 00000013E68C: DC5201D4 157C0022
	s_waitcnt vmcnt(0)                                         // 00000013E694: BF8903F7
	v_fma_mixhi_f16 v20, v21, s18, 0                           // 00000013E698: CC220014 02002515
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E6A0: 8C7E0B7E
	.long 0x7f2a3880                                           // 00000013E6A4: 7F2A3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E6A8: BF870001
	.long 0x7e2a3995                                           // 00000013E6AC: 7E2A3995
	s_and_saveexec_b32 s11, s0                                 // 00000013E6B0: BE8B2000
	s_cbranch_execz 5                                          // 00000013E6B4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x39cc>
	global_load_b32 v22, v[34:35], off offset:472              // 00000013E6B8: DC5201D8 167C0022
	s_waitcnt vmcnt(0)                                         // 00000013E6C0: BF8903F7
	v_fma_mixlo_f16 v21, v22, s18, 0                           // 00000013E6C4: CC210015 02002516
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E6CC: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E6D0: BE8B2000
	s_cbranch_execz 5                                          // 00000013E6D4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x39ec>
	global_load_b32 v22, v[34:35], off offset:476              // 00000013E6D8: DC5201DC 167C0022
	s_waitcnt vmcnt(0)                                         // 00000013E6E0: BF8903F7
	v_fma_mixhi_f16 v21, v22, s18, 0                           // 00000013E6E4: CC220015 02002516
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E6EC: 8C7E0B7E
	.long 0x7f2c3880                                           // 00000013E6F0: 7F2C3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E6F4: BF870001
	.long 0x7e2c3996                                           // 00000013E6F8: 7E2C3996
	s_and_saveexec_b32 s11, s0                                 // 00000013E6FC: BE8B2000
	s_cbranch_execz 5                                          // 00000013E700: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a18>
	global_load_b32 v23, v[34:35], off offset:480              // 00000013E704: DC5201E0 177C0022
	s_waitcnt vmcnt(0)                                         // 00000013E70C: BF8903F7
	v_fma_mixlo_f16 v22, v23, s18, 0                           // 00000013E710: CC210016 02002517
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E718: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E71C: BE8B2000
	s_cbranch_execz 5                                          // 00000013E720: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a38>
	global_load_b32 v23, v[34:35], off offset:484              // 00000013E724: DC5201E4 177C0022
	s_waitcnt vmcnt(0)                                         // 00000013E72C: BF8903F7
	v_fma_mixhi_f16 v22, v23, s18, 0                           // 00000013E730: CC220016 02002517
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E738: 8C7E0B7E
	.long 0x7f2e3880                                           // 00000013E73C: 7F2E3880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E740: BF870001
	.long 0x7e2e3997                                           // 00000013E744: 7E2E3997
	s_and_saveexec_b32 s11, s0                                 // 00000013E748: BE8B2000
	s_cbranch_execz 5                                          // 00000013E74C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a64>
	global_load_b32 v24, v[34:35], off offset:488              // 00000013E750: DC5201E8 187C0022
	s_waitcnt vmcnt(0)                                         // 00000013E758: BF8903F7
	v_fma_mixlo_f16 v23, v24, s18, 0                           // 00000013E75C: CC210017 02002518
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E764: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E768: BE8B2000
	s_cbranch_execz 5                                          // 00000013E76C: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a84>
	global_load_b32 v24, v[34:35], off offset:492              // 00000013E770: DC5201EC 187C0022
	s_waitcnt vmcnt(0)                                         // 00000013E778: BF8903F7
	v_fma_mixhi_f16 v23, v24, s18, 0                           // 00000013E77C: CC220017 02002518
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E784: 8C7E0B7E
	.long 0x7f303880                                           // 00000013E788: 7F303880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E78C: BF870001
	.long 0x7e303998                                           // 00000013E790: 7E303998
	s_and_saveexec_b32 s11, s0                                 // 00000013E794: BE8B2000
	s_cbranch_execz 5                                          // 00000013E798: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ab0>
	global_load_b32 v25, v[34:35], off offset:496              // 00000013E79C: DC5201F0 197C0022
	s_waitcnt vmcnt(0)                                         // 00000013E7A4: BF8903F7
	v_fma_mixlo_f16 v24, v25, s18, 0                           // 00000013E7A8: CC210018 02002519
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E7B0: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E7B4: BE8B2000
	s_cbranch_execz 5                                          // 00000013E7B8: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ad0>
	global_load_b32 v25, v[34:35], off offset:500              // 00000013E7BC: DC5201F4 197C0022
	s_waitcnt vmcnt(0)                                         // 00000013E7C4: BF8903F7
	v_fma_mixhi_f16 v24, v25, s18, 0                           // 00000013E7C8: CC220018 02002519
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E7D0: 8C7E0B7E
	.long 0x7f323880                                           // 00000013E7D4: 7F323880
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E7D8: BF870001
	.long 0x7e323999                                           // 00000013E7DC: 7E323999
	s_and_saveexec_b32 s11, s0                                 // 00000013E7E0: BE8B2000
	s_cbranch_execz 5                                          // 00000013E7E4: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3afc>
	global_load_b32 v26, v[34:35], off offset:504              // 00000013E7E8: DC5201F8 1A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013E7F0: BF8903F7
	v_fma_mixlo_f16 v25, v26, s18, 0                           // 00000013E7F4: CC210019 0200251A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E7FC: 8C7E0B7E
	s_and_saveexec_b32 s11, s0                                 // 00000013E800: BE8B2000
	s_cbranch_execz 5                                          // 00000013E804: BFA50005 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b1c>
	global_load_b32 v26, v[34:35], off offset:508              // 00000013E808: DC5201FC 1A7C0022
	s_waitcnt vmcnt(0)                                         // 00000013E810: BF8903F7
	v_fma_mixhi_f16 v25, v26, s18, 0                           // 00000013E814: CC220019 0200251A
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E81C: 8C7E0B7E
	ds_load_b128 v[46:49], v57 offset:448                      // 00000013E820: DBFC01C0 2E000039
	ds_load_b128 v[42:45], v57 offset:464                      // 00000013E828: DBFC01D0 2A000039
	ds_load_b128 v[38:41], v57 offset:480                      // 00000013E830: DBFC01E0 26000039
	ds_load_b128 v[34:37], v57 offset:496                      // 00000013E838: DBFC01F0 22000039
	s_mul_i32 s0, s19, 48                                      // 00000013E840: 9600B013
	s_mul_hi_u32 s11, s19, 48                                  // 00000013E844: 968BB013
	s_add_u32 s38, s0, s2                                      // 00000013E848: 80260200
	s_addc_u32 s39, s11, s3                                    // 00000013E84C: 8227030B
	v_mov_b32_e32 v26, 0                                       // 00000013E850: 7E340280
	s_lshl_b64 s[38:39], s[38:39], 14                          // 00000013E854: 84A68E26
	s_mov_b32 s11, 0                                           // 00000013E858: BE8B0080
	.long 0xd7000056                                           // 00000013E85C: D7000056
	v_cndmask_b32_e32 v0, v69, v38, vcc_lo                     // 00000013E860: 02004D45
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E864: BF870001
	v_add_co_ci_u32_e64 v87, null, s39, v70, s0                // 00000013E868: D5207C57 00028C27
	v_mov_b32_e32 v27, v26                                     // 00000013E870: 7E36031A
	v_mov_b32_e32 v28, v26                                     // 00000013E874: 7E38031A
	v_mov_b32_e32 v29, v26                                     // 00000013E878: 7E3A031A
	v_mov_b32_e32 v30, v26                                     // 00000013E87C: 7E3C031A
	v_mov_b32_e32 v31, v26                                     // 00000013E880: 7E3E031A
	v_mov_b32_e32 v32, v26                                     // 00000013E884: 7E40031A
	v_mov_b32_e32 v33, v26                                     // 00000013E888: 7E42031A
	s_mov_b32 s38, 0                                           // 00000013E88C: BEA60080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000013E890: BF8704B9
	s_lshl_b32 s14, s38, 4                                     // 00000013E894: 840E8426
	v_lshl_add_u32 v92, s38, 5, v66                            // 00000013E898: D646005C 05090A26
	s_lshl_b64 s[40:41], s[14:15], 2                           // 00000013E8A0: 84A8820E
	.long 0xd7000058                                           // 00000013E8A4: D7000058
	v_cndmask_b32_e32 v0, v86, v40, vcc_lo                     // 00000013E8A8: 02005156
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E8AC: BF870001
	v_add_co_ci_u32_e64 v89, null, s41, v87, s0                // 00000013E8B0: D5207C59 0002AE29
	.long 0xd44a0000                                           // 00000013E8B8: D44A0000
	v_cndmask_b32_e32 v1, s38, v61, vcc_lo                     // 00000013E8BC: 02027A26
	s_add_i32 s38, s38, 1                                      // 00000013E8C0: 81268126
	s_clause 0x3                                               // 00000013E8C4: BF850003
	global_load_b128 v[96:99], v[88:89], off                   // 00000013E8C8: DC5E0000 607C0058
	global_load_b128 v[100:103], v[88:89], off offset:16       // 00000013E8D0: DC5E0010 647C0058
	global_load_b128 v[104:107], v[88:89], off offset:32       // 00000013E8D8: DC5E0020 687C0058
	global_load_b128 v[108:111], v[88:89], off offset:48       // 00000013E8E0: DC5E0030 6C7C0058
	ds_load_b128 v[88:91], v92                                 // 00000013E8E8: DBFC0000 5800005C
	ds_load_b128 v[92:95], v92 offset:16                       // 00000013E8F0: DBFC0010 5C00005C
	s_or_b32 s11, s0, s11                                      // 00000013E8F8: 8C0B0B00
	s_waitcnt vmcnt(3)                                         // 00000013E8FC: BF890FF7
	v_fma_mixlo_f16 v96, v96, s18, 0                           // 00000013E900: CC210060 02002560
	v_fma_mixhi_f16 v96, v97, s18, 0                           // 00000013E908: CC220060 02002561
	v_fma_mixlo_f16 v97, v98, s18, 0                           // 00000013E910: CC210061 02002562
	v_fma_mixhi_f16 v97, v99, s18, 0                           // 00000013E918: CC220061 02002563
	s_waitcnt vmcnt(2)                                         // 00000013E920: BF890BF7
	v_fma_mixlo_f16 v98, v100, s18, 0                          // 00000013E924: CC210062 02002564
	v_fma_mixhi_f16 v98, v101, s18, 0                          // 00000013E92C: CC220062 02002565
	v_fma_mixlo_f16 v99, v102, s18, 0                          // 00000013E934: CC210063 02002566
	v_fma_mixhi_f16 v99, v103, s18, 0                          // 00000013E93C: CC220063 02002567
	s_waitcnt vmcnt(1)                                         // 00000013E944: BF8907F7
	v_fma_mixlo_f16 v100, v104, s18, 0                         // 00000013E948: CC210064 02002568
	v_fma_mixhi_f16 v100, v105, s18, 0                         // 00000013E950: CC220064 02002569
	v_fma_mixlo_f16 v101, v106, s18, 0                         // 00000013E958: CC210065 0200256A
	v_fma_mixhi_f16 v101, v107, s18, 0                         // 00000013E960: CC220065 0200256B
	s_waitcnt vmcnt(0)                                         // 00000013E968: BF8903F7
	v_fma_mixlo_f16 v102, v108, s18, 0                         // 00000013E96C: CC210066 0200256C
	v_fma_mixhi_f16 v102, v109, s18, 0                         // 00000013E974: CC220066 0200256D
	v_fma_mixlo_f16 v103, v110, s18, 0                         // 00000013E97C: CC210067 0200256E
	v_fma_mixhi_f16 v103, v111, s18, 0                         // 00000013E984: CC220067 0200256F
	s_waitcnt lgkmcnt(0)                                       // 00000013E98C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013E990: BF870001
	v_wmma_f32_16x16x16_f16 v[26:33], v[96:103], v[88:95], v[26:33]// 00000013E994: CC40401A 1C6AB160
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000013E99C: 917E0B7E
	s_cbranch_execnz 65467                                     // 00000013E9A0: BFA6FFBB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b90>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000013E9A4: 8C7E0B7E
	v_fma_mixlo_f16 v86, v46, s18, 0                           // 00000013E9A8: CC210056 0200252E
	v_fma_mixhi_f16 v86, v47, s18, 0                           // 00000013E9B0: CC220056 0200252F
	v_fma_mixlo_f16 v87, v48, s18, 0                           // 00000013E9B8: CC210057 02002530
	v_fma_mixhi_f16 v87, v49, s18, 0                           // 00000013E9C0: CC220057 02002531
	v_fma_mixlo_f16 v88, v42, s18, 0                           // 00000013E9C8: CC210058 0200252A
	v_fma_mixhi_f16 v88, v43, s18, 0                           // 00000013E9D0: CC220058 0200252B
	v_fma_mixlo_f16 v89, v44, s18, 0                           // 00000013E9D8: CC210059 0200252C
	v_fma_mixhi_f16 v89, v45, s18, 0                           // 00000013E9E0: CC220059 0200252D
	v_fma_mixlo_f16 v90, v38, s18, 0                           // 00000013E9E8: CC21005A 02002526
	v_fma_mixhi_f16 v90, v39, s18, 0                           // 00000013E9F0: CC22005A 02002527
	v_fma_mixlo_f16 v91, v40, s18, 0                           // 00000013E9F8: CC21005B 02002528
	v_fma_mixhi_f16 v91, v41, s18, 0                           // 00000013EA00: CC22005B 02002529
	v_fma_mixlo_f16 v92, v34, s18, 0                           // 00000013EA08: CC21005C 02002522
	v_fma_mixhi_f16 v92, v35, s18, 0                           // 00000013EA10: CC22005C 02002523
	v_fma_mixlo_f16 v93, v36, s18, 0                           // 00000013EA18: CC21005D 02002524
	v_fma_mixhi_f16 v93, v37, s18, 0                           // 00000013EA20: CC22005D 02002525
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013EA28: BF870001
	v_wmma_f32_16x16x16_f16 v[10:17], v[18:25], v[86:93], v[10:17]// 00000013EA2C: CC40400A 1C2AAD12
	s_and_saveexec_b32 s0, s1                                  // 00000013EA34: BE802001
	s_cbranch_execnz 288                                       // 00000013EA38: BFA60120 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x41bc>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013EA3C: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000013EA40: BE802004
	s_cbranch_execnz 307                                       // 00000013EA44: BFA60133 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4214>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013EA48: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000013EA4C: BE802005
	s_cbranch_execnz 326                                       // 00000013EA50: BFA60146 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x426c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013EA54: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000013EA58: BE802006
	s_cbranch_execnz 345                                       // 00000013EA5C: BFA60159 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x42c4>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013EA60: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000013EA64: BE802007
	s_cbranch_execnz 364                                       // 00000013EA68: BFA6016C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x431c>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013EA6C: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000013EA70: BE802008
	s_cbranch_execnz 383                                       // 00000013EA74: BFA6017F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4374>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013EA78: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000013EA7C: BE802009
	s_cbranch_execnz 402                                       // 00000013EA80: BFA60192 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x43cc>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013EA84: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000013EA88: BE80200A
	s_cbranch_execz 18                                         // 00000013EA8C: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3dd8>
	ds_load_b32 v10, v75 offset:56                             // 00000013EA90: D8D80038 0A00004B
	s_waitcnt lgkmcnt(0)                                       // 00000013EA98: BF89FC07
	v_fmac_f32_e32 v33, v17, v10                               // 00000013EA9C: 56421511
	v_mad_u64_u32 v[10:11], null, 0x3000, v85, v[50:51]        // 00000013EAA0: D6FE7C0A 04CAAAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EAAC: BF870092
	v_mul_f32_e32 v12, 0x3b800000, v33                         // 00000013EAB0: 101842FF 3B800000
	v_bfe_u32 v13, v12, 16, 1                                  // 00000013EAB8: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013EAC0: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 00000013EAC4: D655000C 03FE1B0C 00007FFF
	global_store_d16_hi_b16 v[10:11], v12, off                 // 00000013EAD0: DC960000 007C0C0A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013EAD8: 8C7E007E
	s_mul_f32 s0, s23, 0x3fb8aa3b                              // 00000013EADC: A200FF17 3FB8AA3B
	v_or_b32_e32 v14, s22, v71                                 // 00000013EAE4: 381C8E16
	v_dual_mov_b32 v11, v52 :: v_dual_mov_b32 v12, v53         // 00000013EAE8: CA100134 0B0C0135
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000013EAF0: BF870009
	s_xor_b32 s1, s0, 0x80000000                               // 00000013EAF4: 8D01FF00 80000000
	s_rndne_f32 s4, s0                                         // 00000013EAFC: BE846300
	s_fmamk_f32 s1, s23, 0x3fb8aa3b, s1                        // 00000013EB00: A3010117 3FB8AA3B
	s_cmp_nlt_f32 s23, 0xc2ce8ed0                              // 00000013EB08: BF4EFF17 C2CE8ED0
	v_mov_b32_e32 v13, v77                                     // 00000013EB10: 7E1A034D
	s_sub_f32 s0, s0, s4                                       // 00000013EB14: A0800400
	s_fmamk_f32 s1, s23, 0x32a5705f, s1                        // 00000013EB18: A3010117 32A5705F
	s_mov_b32 s5, 0                                            // 00000013EB20: BE850080
	s_waitcnt_vscnt null, 0x0                                  // 00000013EB24: BC7C0000
	s_barrier                                                  // 00000013EB28: BFBD0000
	s_add_f32 s0, s0, s1                                       // 00000013EB2C: A0000100
	buffer_gl0_inv                                             // 00000013EB30: E0AC0000 00000000
	v_exp_f32_e32 v10, s0                                      // 00000013EB38: 7E144A00
	s_cvt_i32_f32 s0, s4                                       // 00000013EB3C: BE806604
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000013EB40: BF870585
	.long 0xd71c000a                                           // 00000013EB44: D71C000A
	v_cndmask_b32_e32 v0, v10, v0, vcc_lo                      // 00000013EB48: 0200010A
	s_cselect_b32 s0, -1, 0                                    // 00000013EB4C: 980080C1
	s_cmp_ngt_f32 s23, 0x42b17218                              // 00000013EB50: BF4BFF17 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000013EB58: BF8701C1
	v_cndmask_b32_e64 v10, 0, v10, s0                          // 00000013EB5C: D501000A 00021480
	s_cselect_b32 s1, -1, 0                                    // 00000013EB64: 980180C1
	.long 0xd4440000                                           // 00000013EB68: D4440000
	v_cndmask_b32_e32 v1, s35, v14, vcc_lo                     // 00000013EB6C: 02021C23
	v_mov_b32_e32 v14, v59                                     // 00000013EB70: 7E1C033B
	v_cndmask_b32_e64 v17, 0x7f800000, v10, s1                 // 00000013EB74: D5010011 000614FF 7F800000
	s_set_inst_prefetch_distance 0x1                           // 00000013EB80: BF840001
	s_branch 32                                                // 00000013EB84: BFA00020 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3f08>
	s_nop 0                                                    // 00000013EB88: BF800000
	s_nop 0                                                    // 00000013EB8C: BF800000
	s_nop 0                                                    // 00000013EB90: BF800000
	s_nop 0                                                    // 00000013EB94: BF800000
	s_nop 0                                                    // 00000013EB98: BF800000
	s_nop 0                                                    // 00000013EB9C: BF800000
	s_nop 0                                                    // 00000013EBA0: BF800000
	s_nop 0                                                    // 00000013EBA4: BF800000
	s_nop 0                                                    // 00000013EBA8: BF800000
	s_nop 0                                                    // 00000013EBAC: BF800000
	s_nop 0                                                    // 00000013EBB0: BF800000
	s_nop 0                                                    // 00000013EBB4: BF800000
	s_nop 0                                                    // 00000013EBB8: BF800000
	s_nop 0                                                    // 00000013EBBC: BF800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013EBC0: 8C7E017E
	v_add_nc_u32_e32 v14, 0x80, v14                            // 00000013EBC4: 4A1C1CFF 00000080
	.long 0xd700040b                                           // 00000013EBCC: D700040B
	v_cndmask_b32_e32 v0, v11, v136, vcc_lo                    // 00000013EBD0: 0201110B
	ds_store_b16 v13, v10                                      // 00000013EBD4: D87C0000 00000A0D
	v_add_nc_u32_e32 v13, 0x140, v13                           // 00000013EBDC: 4A1A1AFF 00000140
	.long 0xd4490001                                           // 00000013EBE4: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v14, vcc_lo                   // 00000013EBE8: 02021CFF 00000F7F
	v_add_co_ci_u32_e64 v12, null, 0, v12, s4                  // 00000013EBF0: D5207C0C 00121880
	s_or_b32 s5, s1, s5                                        // 00000013EBF8: 8C050501
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000013EBFC: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000013EC00: 917E057E
	s_cbranch_execz 13                                         // 00000013EC04: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3f3c>
	.long 0x7e143880                                           // 00000013EC08: 7E143880
	s_and_saveexec_b32 s1, s0                                  // 00000013EC0C: BE812000
	s_cbranch_execz 65515                                      // 00000013EC10: BFA5FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ec0>
	global_load_b32 v10, v[11:12], off                         // 00000013EC14: DC520000 0A7C000B
	ds_load_b32 v15, v76                                       // 00000013EC1C: D8D80000 0F00004C
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000013EC24: BF890007
	v_mul_f32_e32 v10, v10, v15                                // 00000013EC28: 10141F0A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013EC2C: BF870001
	v_fma_mixlo_f16 v10, v10, s18, 0                           // 00000013EC30: CC21000A 0200250A
	s_branch 65505                                             // 00000013EC38: BFA0FFE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3ec0>
	s_set_inst_prefetch_distance 0x2                           // 00000013EC3C: BF840002
	s_or_b32 exec_lo, exec_lo, s5                              // 00000013EC40: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 00000013EC44: BF89FC07
	s_barrier                                                  // 00000013EC48: BFBD0000
	buffer_gl0_inv                                             // 00000013EC4C: E0AC0000 00000000
	ds_load_b128 v[18:21], v72                                 // 00000013EC54: DBFC0000 12000048
	ds_load_b128 v[22:25], v72 offset:16                       // 00000013EC5C: DBFC0010 16000048
	ds_load_b128 v[26:29], v72 offset:32                       // 00000013EC64: DBFC0020 1A000048
	ds_load_b128 v[30:33], v72 offset:48                       // 00000013EC6C: DBFC0030 1E000048
	ds_load_b128 v[34:37], v66                                 // 00000013EC74: DBFC0000 22000042
	ds_load_b128 v[38:41], v66 offset:16                       // 00000013EC7C: DBFC0010 26000042
	ds_load_b128 v[42:45], v66 offset:32                       // 00000013EC84: DBFC0020 2A000042
	ds_load_b128 v[46:49], v66 offset:48                       // 00000013EC8C: DBFC0030 2E000042
	ds_load_b128 v[82:85], v72 offset:80                       // 00000013EC94: DBFC0050 52000048
	ds_load_b128 v[78:81], v72 offset:64                       // 00000013EC9C: DBFC0040 4E000048
	ds_load_b128 v[90:93], v66 offset:80                       // 00000013ECA4: DBFC0050 5A000042
	ds_load_b128 v[86:89], v66 offset:64                       // 00000013ECAC: DBFC0040 56000042
	ds_load_b128 v[98:101], v72 offset:112                     // 00000013ECB4: DBFC0070 62000048
	ds_load_b128 v[94:97], v72 offset:96                       // 00000013ECBC: DBFC0060 5E000048
	ds_load_b128 v[106:109], v66 offset:112                    // 00000013ECC4: DBFC0070 6A000042
	ds_load_b128 v[102:105], v66 offset:96                     // 00000013ECCC: DBFC0060 66000042
	ds_load_2addr_b32 v[118:119], v73 offset1:2                // 00000013ECD4: D8DC0200 76000049
	ds_load_2addr_b32 v[120:121], v73 offset0:4 offset1:6      // 00000013ECDC: D8DC0604 78000049
	ds_load_2addr_b32 v[122:123], v73 offset0:8 offset1:10     // 00000013ECE4: D8DC0A08 7A000049
	ds_load_2addr_b32 v[124:125], v73 offset0:12 offset1:14    // 00000013ECEC: D8DC0E0C 7C000049
	v_mov_b32_e32 v16, v9                                      // 00000013ECF4: 7E200309
	v_mov_b32_e32 v10, v9                                      // 00000013ECF8: 7E140309
	v_mov_b32_e32 v11, v9                                      // 00000013ECFC: 7E160309
	v_mov_b32_e32 v12, v9                                      // 00000013ED00: 7E180309
	v_mov_b32_e32 v13, v9                                      // 00000013ED04: 7E1A0309
	v_mov_b32_e32 v14, v9                                      // 00000013ED08: 7E1C0309
	v_mov_b32_e32 v15, v9                                      // 00000013ED0C: 7E1E0309
	v_mov_b32_e32 v117, v16                                    // 00000013ED10: 7EEA0310
	v_dual_mov_b32 v113, v12 :: v_dual_mov_b32 v112, v11       // 00000013ED14: CA10010C 7170010B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000013ED1C: BF870214
	v_dual_mov_b32 v115, v14 :: v_dual_mov_b32 v114, v13       // 00000013ED20: CA10010E 7372010D
	v_dual_mov_b32 v116, v15 :: v_dual_mov_b32 v111, v10       // 00000013ED28: CA10010F 746E010A
	v_dual_mov_b32 v110, v9 :: v_dual_mov_b32 v11, v54         // 00000013ED30: CA100109 6E0A0136
	s_waitcnt lgkmcnt(3)                                       // 00000013ED38: BF89FC37
	v_mul_f32_e32 v10, v17, v118                               // 00000013ED3C: 1014ED11
	s_waitcnt lgkmcnt(2)                                       // 00000013ED40: BF89FC27
	v_mul_f32_e32 v16, v17, v120                               // 00000013ED44: 1020F111
	v_mov_b32_e32 v12, v55                                     // 00000013ED48: 7E180337
	v_wmma_f32_16x16x16_f16 v[110:117], v[18:25], v[34:41], v[110:117]// 00000013ED4C: CC40406E 1DBA4512
	s_waitcnt lgkmcnt(0)                                       // 00000013ED54: BF89FC07
	v_mul_f32_e32 v22, v17, v125                               // 00000013ED58: 102CFB11
	v_mul_f32_e32 v18, v17, v121                               // 00000013ED5C: 1024F311
	v_mul_f32_e32 v20, v17, v123                               // 00000013ED60: 1028F711
	v_dual_mul_f32 v21, v17, v124 :: v_dual_mov_b32 v14, v59   // 00000013ED64: C8D0F911 150E013B
	v_wmma_f32_16x16x16_f16 v[110:117], v[26:33], v[42:49], v[110:117]// 00000013ED6C: CC40406E 1DBA551A
	s_mov_b32 s5, 0                                            // 00000013ED74: BE850080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013ED78: BF870091
	v_wmma_f32_16x16x16_f16 v[110:117], v[78:85], v[86:93], v[110:117]// 00000013ED7C: CC40406E 1DBAAD4E
	v_wmma_f32_16x16x16_f16 v[110:117], v[94:101], v[102:109], v[110:117]// 00000013ED84: CC40406E 1DBACD5E
	v_mul_f32_e32 v15, v17, v119                               // 00000013ED8C: 101EEF11
	v_mul_f32_e32 v19, v17, v122                               // 00000013ED90: 1026F511
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000013ED94: BF870213
	v_dual_mov_b32 v13, v77 :: v_dual_fmac_f32 v18, 0x3b800000, v113// 00000013ED98: CA00014D 0D12E2FF 3B800000
	v_fmac_f32_e32 v10, 0x3b800000, v110                       // 00000013EDA4: 5614DCFF 3B800000
	s_delay_alu instid0(VALU_DEP_4)                            // 00000013EDAC: BF870004
	v_dual_fmac_f32 v22, 0x3b800000, v117 :: v_dual_fmac_f32 v15, 0x3b800000, v111// 00000013EDB0: C800EAFF 160EDEFF 3B800000
	v_fmac_f32_e32 v16, 0x3b800000, v112                       // 00000013EDBC: 5620E0FF 3B800000
	v_dual_fmac_f32 v20, 0x3b800000, v115 :: v_dual_fmac_f32 v19, 0x3b800000, v114// 00000013EDC4: C800E6FF 1412E4FF 3B800000
	v_fmac_f32_e32 v21, 0x3b800000, v116                       // 00000013EDD0: 562AE8FF 3B800000
	ds_store_2addr_b32 v73, v10, v15 offset1:2                 // 00000013EDD8: D8380200 000F0A49
	ds_store_2addr_b32 v73, v16, v18 offset0:4 offset1:6       // 00000013EDE0: D8380604 00121049
	ds_store_2addr_b32 v73, v19, v20 offset0:8 offset1:10      // 00000013EDE8: D8380A08 00141349
	ds_store_2addr_b32 v73, v21, v22 offset0:12 offset1:14     // 00000013EDF0: D8380E0C 00161549
	s_waitcnt lgkmcnt(0)                                       // 00000013EDF8: BF89FC07
	s_barrier                                                  // 00000013EDFC: BFBD0000
	buffer_gl0_inv                                             // 00000013EE00: E0AC0000 00000000
	s_set_inst_prefetch_distance 0x1                           // 00000013EE08: BF840001
	s_branch 30                                                // 00000013EE0C: BFA0001E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4188>
	s_nop 0                                                    // 00000013EE10: BF800000
	s_nop 0                                                    // 00000013EE14: BF800000
	s_nop 0                                                    // 00000013EE18: BF800000
	s_nop 0                                                    // 00000013EE1C: BF800000
	s_nop 0                                                    // 00000013EE20: BF800000
	s_nop 0                                                    // 00000013EE24: BF800000
	s_nop 0                                                    // 00000013EE28: BF800000
	s_nop 0                                                    // 00000013EE2C: BF800000
	s_nop 0                                                    // 00000013EE30: BF800000
	s_nop 0                                                    // 00000013EE34: BF800000
	s_nop 0                                                    // 00000013EE38: BF800000
	s_nop 0                                                    // 00000013EE3C: BF800000
	s_or_b32 exec_lo, exec_lo, s1                              // 00000013EE40: 8C7E017E
	v_add_nc_u32_e32 v14, 0x80, v14                            // 00000013EE44: 4A1C1CFF 00000080
	.long 0xd700040b                                           // 00000013EE4C: D700040B
	v_cndmask_b32_e32 v0, v11, v136, vcc_lo                    // 00000013EE50: 0201110B
	ds_store_b16 v13, v10                                      // 00000013EE54: D87C0000 00000A0D
	v_add_nc_u32_e32 v13, 0x140, v13                           // 00000013EE5C: 4A1A1AFF 00000140
	.long 0xd4490001                                           // 00000013EE64: D4490001
	v_cndmask_b32_e32 v1, 0xf7f, v14, vcc_lo                   // 00000013EE68: 02021CFF 00000F7F
	v_add_co_ci_u32_e64 v12, null, 0, v12, s4                  // 00000013EE70: D5207C0C 00121880
	s_or_b32 s5, s1, s5                                        // 00000013EE78: 8C050501
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000013EE7C: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000013EE80: 917E057E
	s_cbranch_execz 61539                                      // 00000013EE84: BFA5F063 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x314>
	.long 0x7e143880                                           // 00000013EE88: 7E143880
	s_and_saveexec_b32 s1, s0                                  // 00000013EE8C: BE812000
	s_cbranch_execz 65515                                      // 00000013EE90: BFA5FFEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4140>
	global_load_b32 v10, v[11:12], off                         // 00000013EE94: DC520000 0A7C000B
	ds_load_b32 v15, v76                                       // 00000013EE9C: D8D80000 0F00004C
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000013EEA4: BF890007
	v_mul_f32_e32 v10, v10, v15                                // 00000013EEA8: 10141F0A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013EEAC: BF870001
	v_fma_mixlo_f16 v10, v10, s18, 0                           // 00000013EEB0: CC21000A 0200250A
	s_branch 65505                                             // 00000013EEB8: BFA0FFE1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4140>
	ds_load_b32 v18, v75                                       // 00000013EEBC: D8D80000 1200004B
	s_waitcnt lgkmcnt(0)                                       // 00000013EEC4: BF89FC07
	v_fma_f32 v10, v10, v18, v26                               // 00000013EEC8: D613000A 046A250A
	v_mad_u64_u32 v[18:19], null, 0x3000, v78, v[50:51]        // 00000013EED0: D6FE7C12 04CA9CFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013EEDC: BF870092
	v_mul_f32_e32 v10, 0x3b800000, v10                         // 00000013EEE0: 101414FF 3B800000
	v_bfe_u32 v20, v10, 16, 1                                  // 00000013EEE8: D6100014 0205210A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013EEF0: BF870001
	v_add3_u32 v10, v10, v20, 0x7fff                           // 00000013EEF4: D655000A 03FE290A 00007FFF
	global_store_d16_hi_b16 v[18:19], v10, off                 // 00000013EF00: DC960000 007C0A12
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013EF08: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000013EF0C: BE802004
	s_cbranch_execz 65229                                      // 00000013EF10: BFA5FECD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d48>
	ds_load_b32 v10, v75 offset:8                              // 00000013EF14: D8D80008 0A00004B
	s_waitcnt lgkmcnt(0)                                       // 00000013EF1C: BF89FC07
	v_fma_f32 v10, v11, v10, v27                               // 00000013EF20: D613000A 046E150B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013EF28: BF870121
	v_mul_f32_e32 v18, 0x3b800000, v10                         // 00000013EF2C: 102414FF 3B800000
	v_mad_u64_u32 v[10:11], null, 0x3000, v79, v[50:51]        // 00000013EF34: D6FE7C0A 04CA9EFF 00003000
	v_bfe_u32 v19, v18, 16, 1                                  // 00000013EF40: D6100013 02052112
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013EF48: BF870001
	v_add3_u32 v18, v18, v19, 0x7fff                           // 00000013EF4C: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[10:11], v18, off                 // 00000013EF58: DC960000 007C120A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013EF60: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000013EF64: BE802005
	s_cbranch_execz 65210                                      // 00000013EF68: BFA5FEBA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d54>
	ds_load_b32 v10, v75 offset:16                             // 00000013EF6C: D8D80010 0A00004B
	s_waitcnt lgkmcnt(0)                                       // 00000013EF74: BF89FC07
	v_fma_f32 v10, v12, v10, v28                               // 00000013EF78: D613000A 0472150C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013EF80: BF870121
	v_mul_f32_e32 v12, 0x3b800000, v10                         // 00000013EF84: 101814FF 3B800000
	v_mad_u64_u32 v[10:11], null, 0x3000, v80, v[50:51]        // 00000013EF8C: D6FE7C0A 04CAA0FF 00003000
	v_bfe_u32 v18, v12, 16, 1                                  // 00000013EF98: D6100012 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013EFA0: BF870001
	v_add3_u32 v12, v12, v18, 0x7fff                           // 00000013EFA4: D655000C 03FE250C 00007FFF
	global_store_d16_hi_b16 v[10:11], v12, off                 // 00000013EFB0: DC960000 007C0C0A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013EFB8: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000013EFBC: BE802006
	s_cbranch_execz 65191                                      // 00000013EFC0: BFA5FEA7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d60>
	ds_load_b32 v10, v75 offset:24                             // 00000013EFC4: D8D80018 0A00004B
	s_waitcnt lgkmcnt(0)                                       // 00000013EFCC: BF89FC07
	v_fma_f32 v10, v13, v10, v29                               // 00000013EFD0: D613000A 0476150D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013EFD8: BF870121
	v_mul_f32_e32 v12, 0x3b800000, v10                         // 00000013EFDC: 101814FF 3B800000
	v_mad_u64_u32 v[10:11], null, 0x3000, v81, v[50:51]        // 00000013EFE4: D6FE7C0A 04CAA2FF 00003000
	v_bfe_u32 v13, v12, 16, 1                                  // 00000013EFF0: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013EFF8: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 00000013EFFC: D655000C 03FE1B0C 00007FFF
	global_store_d16_hi_b16 v[10:11], v12, off                 // 00000013F008: DC960000 007C0C0A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013F010: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000013F014: BE802007
	s_cbranch_execz 65172                                      // 00000013F018: BFA5FE94 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d6c>
	ds_load_b32 v10, v75 offset:32                             // 00000013F01C: D8D80020 0A00004B
	s_waitcnt lgkmcnt(0)                                       // 00000013F024: BF89FC07
	v_fma_f32 v10, v14, v10, v30                               // 00000013F028: D613000A 047A150E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013F030: BF870121
	v_mul_f32_e32 v12, 0x3b800000, v10                         // 00000013F034: 101814FF 3B800000
	v_mad_u64_u32 v[10:11], null, 0x3000, v82, v[50:51]        // 00000013F03C: D6FE7C0A 04CAA4FF 00003000
	v_bfe_u32 v13, v12, 16, 1                                  // 00000013F048: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013F050: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 00000013F054: D655000C 03FE1B0C 00007FFF
	global_store_d16_hi_b16 v[10:11], v12, off                 // 00000013F060: DC960000 007C0C0A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013F068: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 00000013F06C: BE802008
	s_cbranch_execz 65153                                      // 00000013F070: BFA5FE81 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d78>
	ds_load_b32 v10, v75 offset:40                             // 00000013F074: D8D80028 0A00004B
	s_waitcnt lgkmcnt(0)                                       // 00000013F07C: BF89FC07
	v_fma_f32 v10, v15, v10, v31                               // 00000013F080: D613000A 047E150F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013F088: BF870121
	v_mul_f32_e32 v12, 0x3b800000, v10                         // 00000013F08C: 101814FF 3B800000
	v_mad_u64_u32 v[10:11], null, 0x3000, v83, v[50:51]        // 00000013F094: D6FE7C0A 04CAA6FF 00003000
	v_bfe_u32 v13, v12, 16, 1                                  // 00000013F0A0: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013F0A8: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 00000013F0AC: D655000C 03FE1B0C 00007FFF
	global_store_d16_hi_b16 v[10:11], v12, off                 // 00000013F0B8: DC960000 007C0C0A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013F0C0: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 00000013F0C4: BE802009
	s_cbranch_execz 65134                                      // 00000013F0C8: BFA5FE6E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d84>
	ds_load_b32 v10, v75 offset:48                             // 00000013F0CC: D8D80030 0A00004B
	s_waitcnt lgkmcnt(0)                                       // 00000013F0D4: BF89FC07
	v_fma_f32 v10, v16, v10, v32                               // 00000013F0D8: D613000A 04821510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000013F0E0: BF870121
	v_mul_f32_e32 v12, 0x3b800000, v10                         // 00000013F0E4: 101814FF 3B800000
	v_mad_u64_u32 v[10:11], null, 0x3000, v84, v[50:51]        // 00000013F0EC: D6FE7C0A 04CAA8FF 00003000
	v_bfe_u32 v13, v12, 16, 1                                  // 00000013F0F8: D610000D 0205210C
	s_delay_alu instid0(VALU_DEP_1)                            // 00000013F100: BF870001
	v_add3_u32 v12, v12, v13, 0x7fff                           // 00000013F104: D655000C 03FE1B0C 00007FFF
	global_store_d16_hi_b16 v[10:11], v12, off                 // 00000013F110: DC960000 007C0C0A
	s_or_b32 exec_lo, exec_lo, s0                              // 00000013F118: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 00000013F11C: BE80200A
	s_cbranch_execnz 65115                                     // 00000013F120: BFA6FE5B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3d90>
	s_branch 65132                                             // 00000013F124: BFA0FE6C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3dd8>
	v_dual_mov_b32 v2, v59 :: v_dual_mov_b32 v3, v58           // 00000013F128: CA10013B 0202013A
	.long 0xd73c0000                                           // 00000013F130: D73C0000
	v_cndmask_b32_e32 v1, 5, v0, vcc_lo                        // 00000013F134: 02020085
	s_add_u32 s0, s33, s28                                     // 00000013F138: 80001C21
	s_addc_u32 s1, s34, s29                                    // 00000013F13C: 82011D22
	s_add_u32 s2, s30, s26                                     // 00000013F140: 80021A1E
	s_addc_u32 s3, s31, s27                                    // 00000013F144: 82031B1F
	s_add_u32 s0, s2, s0                                       // 00000013F148: 80000002
	v_and_b32_e32 v0, 0xfffffe00, v0                           // 00000013F14C: 360000FF FFFFFE00
	s_addc_u32 s1, s3, s1                                      // 00000013F154: 82010103
	v_mul_u32_u24_e32 v4, 0x210, v56                           // 00000013F158: 160870FF 00000210
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000013F160: BF870092
	.long 0xd7006a00                                           // 00000013F164: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000013F168: 02020000
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000013F16C: D5207C01 01AA0201
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000013F174: BF870193
	v_lshl_add_u32 v3, v3, 2, v4                               // 00000013F178: D6460003 04110503
	.long 0xd7006a00                                           // 00000013F180: D7006A00
	v_cndmask_b32_e32 v1, v0, v60, vcc_lo                      // 00000013F184: 02027900
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000013F188: BF8700B1
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000013F18C: D5207C01 01AA0280
	s_mov_b32 s1, 0                                            // 00000013F194: BE810080
	.long 0xd7006a00                                           // 00000013F198: D7006A00
	v_cndmask_b32_e32 v1, s24, v0, vcc_lo                      // 00000013F19C: 02020018
	v_add_co_ci_u32_e64 v1, null, s25, v1, vcc_lo              // 00000013F1A0: D5207C01 01AA0219
	s_nop 0                                                    // 00000013F1A8: BF800000
	s_nop 0                                                    // 00000013F1AC: BF800000
	s_nop 0                                                    // 00000013F1B0: BF800000
	s_nop 0                                                    // 00000013F1B4: BF800000
	s_nop 0                                                    // 00000013F1B8: BF800000
	s_nop 0                                                    // 00000013F1BC: BF800000
	ds_load_b32 v4, v3 offset:12800                            // 00000013F1C0: D8D83200 04000003
	v_add_nc_u32_e32 v2, 0x80, v2                              // 00000013F1C8: 4A0404FF 00000080
	v_add_nc_u32_e32 v3, 32, v3                                // 00000013F1D0: 4A0606A0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000013F1D4: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v2                         // 00000013F1D8: 7C9204FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 00000013F1E0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000013F1E4: BF89FC07
	global_store_b32 v[0:1], v4, off                           // 00000013F1E8: DC6A0000 007C0400
	.long 0xd7000000                                           // 00000013F1F0: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000013F1F4: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000013F1FC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000013F204: 917E017E
	s_cbranch_execnz 65517                                     // 00000013F208: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3wILi8ELi4ELb0ELb0ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x44c0>
	s_nop 0                                                    // 00000013F20C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000013F210: BFB60003
	s_endpgm                                                   // 00000013F214: BFB00000
		...

