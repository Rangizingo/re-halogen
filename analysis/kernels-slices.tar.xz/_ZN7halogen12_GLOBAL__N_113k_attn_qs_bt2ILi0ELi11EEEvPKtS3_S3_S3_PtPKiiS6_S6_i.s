00000000001cd900 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi11EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi11EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 0000001CD900: BF850001
	s_load_b128 s[44:47], s[0:1], 0x20                         // 0000001CD904: F4080B00 F8000020
	s_load_b128 s[4:7], s[0:1], 0x38                           // 0000001CD90C: F4080100 F8000038
	s_mov_b32 s34, s3                                          // 0000001CD914: BEA20003
	s_ashr_i32 s3, s2, 31                                      // 0000001CD918: 86039F02
	s_load_b256 s[36:43], s[0:1], null                         // 0000001CD91C: F40C0900 F8000000
	s_lshl_b64 s[8:9], s[2:3], 2                               // 0000001CD924: 84888202
	s_waitcnt lgkmcnt(0)                                       // 0000001CD928: BF89FC07
	s_load_b32 s10, s[46:47], null                             // 0000001CD92C: F4000297 F8000000
	s_load_b32 s55, s[0:1], 0x48                               // 0000001CD934: F4000DC0 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000001CD93C: BF89FC07
	s_add_i32 s3, s10, s2                                      // 0000001CD940: 8103020A
	s_add_u32 s6, s6, s8                                       // 0000001CD944: 80060806
	s_addc_u32 s7, s7, s9                                      // 0000001CD948: 82070907
	s_add_i32 s8, s3, 1                                        // 0000001CD94C: 81088103
	s_load_b32 s52, s[6:7], null                               // 0000001CD950: F4000D03 F8000000
	s_ashr_i32 s0, s8, 31                                      // 0000001CD958: 86009F08
	s_mul_hi_i32 s7, s55, s2                                   // 0000001CD95C: 97070237
	s_lshr_b32 s0, s0, 30                                      // 0000001CD960: 85009E00
	s_mul_i32 s6, s55, s2                                      // 0000001CD964: 96060237
	s_add_i32 s8, s8, s0                                       // 0000001CD968: 81080008
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001CD96C: BF870009
	s_and_b32 s0, s8, -4                                       // 0000001CD970: 8B00C408
	s_ashr_i32 s53, s8, 2                                      // 0000001CD974: 86358208
	s_sub_i32 s1, s3, s0                                       // 0000001CD978: 81810003
	s_mov_b32 s54, s53                                         // 0000001CD97C: BEB60035
	s_cmp_gt_i32 s1, -1                                        // 0000001CD980: BF02C101
	s_cselect_b32 s3, -1, 0                                    // 0000001CD984: 980380C1
	s_lshl_b64 s[6:7], s[6:7], 2                               // 0000001CD988: 84868206
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001CD98C: BF870009
	s_add_u32 s46, s4, s6                                      // 0000001CD990: 802E0604
	s_addc_u32 s47, s5, s7                                     // 0000001CD994: 822F0705
	s_and_b32 vcc_lo, exec_lo, s3                              // 0000001CD998: 8B6A037E
	s_cbranch_vccnz 11                                         // 0000001CD99C: BFA4000B <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi11EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xcc>
	s_waitcnt lgkmcnt(0)                                       // 0000001CD9A0: BF89FC07
	s_max_i32 s4, s52, 1                                       // 0000001CD9A4: 8A048134
	s_mov_b32 s5, 0                                            // 0000001CD9A8: BE850080
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001CD9AC: BF870499
	s_lshl_b64 s[4:5], s[4:5], 2                               // 0000001CD9B0: 84848204
	s_add_u32 s0, s46, s4                                      // 0000001CD9B4: 8000042E
	s_addc_u32 s5, s47, s5                                     // 0000001CD9B8: 8205052F
	s_add_u32 s4, s0, -4                                       // 0000001CD9BC: 8004C400
	s_addc_u32 s5, s5, -1                                      // 0000001CD9C0: 8205C105
	s_load_b32 s54, s[4:5], null                               // 0000001CD9C4: F4000D82 F8000000
	v_lshrrev_b32_e32 v7, 5, v0                                // 0000001CD9CC: 320E0085
	s_mov_b32 s4, exec_lo                                      // 0000001CD9D0: BE84007E
	v_cmpx_gt_u32_e32 0x180, v0                                // 0000001CD9D4: 7D9800FF 00000180
	s_cbranch_execz 61                                         // 0000001CD9DC: BFA5003D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi11EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1d4>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001CD9E0: BF870002
	v_mul_u32_u24_e32 v1, 0x210, v7                            // 0000001CD9E4: 16020EFF 00000210
	v_and_b32_e32 v2, 31, v0                                   // 0000001CD9EC: 3604009F
	s_mul_i32 s6, s34, 0xc00                                   // 0000001CD9F0: 9606FF22 00000C00
	s_mul_i32 s5, s2, 0x3000                                   // 0000001CD9F8: 9605FF02 00003000
	s_ashr_i32 s7, s6, 31                                      // 0000001CDA00: 86079F06
	s_mul_hi_i32 s0, s2, 0x3000                                // 0000001CDA04: 9700FF02 00003000
	s_lshl_b64 s[6:7], s[6:7], 1                               // 0000001CDA0C: 84868106
	v_lshl_add_u32 v4, v2, 4, v1                               // 0000001CDA10: D6460004 04050902
	v_lshlrev_b32_e32 v1, 4, v0                                // 0000001CDA18: 30020084
	s_add_u32 s6, s36, s6                                      // 0000001CDA1C: 80060624
	s_addc_u32 s7, s37, s7                                     // 0000001CDA20: 82070725
	s_add_u32 s5, s6, s5                                       // 0000001CDA24: 80050506
	s_addc_u32 s0, s7, s0                                      // 0000001CDA28: 82000007
	.long 0xd7000501                                           // 0000001CDA2C: D7000501
	v_cndmask_b32_e32 v1, s5, v1, vcc_lo                       // 0000001CDA30: 02020205
	v_lshl_or_b32 v3, v0, 3, 0xfffffe00                        // 0000001CDA34: D6560003 03FD0700 FFFFFE00
	v_add_co_ci_u32_e64 v2, null, s0, 0, s5                    // 0000001CDA40: D5207C02 00150000
	s_mov_b32 s5, 0                                            // 0000001CDA48: BE850080
	s_nop 0                                                    // 0000001CDA4C: BF800000
	s_nop 0                                                    // 0000001CDA50: BF800000
	s_nop 0                                                    // 0000001CDA54: BF800000
	s_nop 0                                                    // 0000001CDA58: BF800000
	s_nop 0                                                    // 0000001CDA5C: BF800000
	s_nop 0                                                    // 0000001CDA60: BF800000
	s_nop 0                                                    // 0000001CDA64: BF800000
	s_nop 0                                                    // 0000001CDA68: BF800000
	s_nop 0                                                    // 0000001CDA6C: BF800000
	s_nop 0                                                    // 0000001CDA70: BF800000
	s_nop 0                                                    // 0000001CDA74: BF800000
	s_nop 0                                                    // 0000001CDA78: BF800000
	s_nop 0                                                    // 0000001CDA7C: BF800000
	global_load_b128 v[8:11], v[1:2], off                      // 0000001CDA80: DC5E0000 087C0001
	v_add_nc_u32_e32 v3, 0x200, v3                             // 0000001CDA88: 4A0606FF 00000200
	.long 0xd7006a01                                           // 0000001CDA90: D7006A01
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001CDA94: 020202FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CDA9C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000001CDAA0: D5207C02 01AA0480
	.long 0xd4490000                                           // 0000001CDAA8: D4490000
	v_cndmask_b32_e32 v1, 0x9ff, v3, vcc_lo                    // 0000001CDAAC: 020206FF 000009FF
	s_or_b32 s5, s0, s5                                        // 0000001CDAB4: 8C050500
	s_waitcnt vmcnt(0)                                         // 0000001CDAB8: BF8903F7
	ds_store_b128 v4, v[8:11] offset:1024                      // 0000001CDABC: DB7C0400 00000804
	v_add_nc_u32_e32 v4, 0x420, v4                             // 0000001CDAC4: 4A0808FF 00000420
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000001CDACC: 917E057E
	s_cbranch_execnz 65515                                     // 0000001CDAD0: BFA6FFEB <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi11EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x180>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001CDAD4: 8C7E047E
	v_cndmask_b32_e64 v1, 0, 1, s3                             // 0000001CDAD8: D5010001 000D0280
	v_lshlrev_b32_e32 v158, 7, v7                              // 0000001CDAE0: 313C0E87
	s_waitcnt lgkmcnt(0)                                       // 0000001CDAE4: BF89FC07
	s_barrier                                                  // 0000001CDAE8: BFBD0000
	buffer_gl0_inv                                             // 0000001CDAEC: E0AC0000 00000000
	v_readfirstlane_b32 s0, v1                                 // 0000001CDAF4: 7E000501
	s_add_i32 s36, s52, s0                                     // 0000001CDAF8: 81240034
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001CDAFC: BF870499
	s_add_i32 s0, s36, 3                                       // 0000001CDB00: 81008324
	s_ashr_i32 s37, s0, 2                                      // 0000001CDB04: 86258200
	s_mov_b32 s0, 0                                            // 0000001CDB08: BE800080
	s_cmp_gt_i32 s37, 0                                        // 0000001CDB0C: BF028025
	s_cbranch_scc1 2                                           // 0000001CDB10: BFA20002 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi11EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x21c>
	v_lshlrev_b32_e32 v8, 7, v7                                // 0000001CDB14: 30100E87
	s_branch 1                                                 // 0000001CDB18: BFA00001 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi11EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x220>
	s_mov_b32 s0, -1                                           // 0000001CDB1C: BE8000C1
	v_mov_b32_e32 v38, 0                                       // 0000001CDB20: 7E4C0280
	v_and_b32_e32 v156, 15, v0                                 // 0000001CDB24: 3738008F
	v_bfe_u32 v157, v0, 4, 1                                   // 0000001CDB28: D610009D 02050900
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000001CDB30: 916A007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CDB34: BF870003
	v_mov_b32_e32 v37, v38                                     // 0000001CDB38: 7E4A0326
	v_mov_b32_e32 v36, v38                                     // 0000001CDB3C: 7E480326
	v_mov_b32_e32 v35, v38                                     // 0000001CDB40: 7E460326
	v_mov_b32_e32 v34, v38                                     // 0000001CDB44: 7E440326
	v_mov_b32_e32 v33, v38                                     // 0000001CDB48: 7E420326
	v_mov_b32_e32 v46, v38                                     // 0000001CDB4C: 7E5C0326
	v_mov_b32_e32 v45, v38                                     // 0000001CDB50: 7E5A0326
	v_mov_b32_e32 v44, v38                                     // 0000001CDB54: 7E580326
	v_mov_b32_e32 v43, v38                                     // 0000001CDB58: 7E560326
	v_mov_b32_e32 v42, v38                                     // 0000001CDB5C: 7E540326
	v_mov_b32_e32 v41, v38                                     // 0000001CDB60: 7E520326
	v_mov_b32_e32 v54, v38                                     // 0000001CDB64: 7E6C0326
	v_mov_b32_e32 v53, v38                                     // 0000001CDB68: 7E6A0326
	v_mov_b32_e32 v52, v38                                     // 0000001CDB6C: 7E680326
	v_mov_b32_e32 v51, v38                                     // 0000001CDB70: 7E660326
	v_mov_b32_e32 v50, v38                                     // 0000001CDB74: 7E640326
	v_mov_b32_e32 v49, v38                                     // 0000001CDB78: 7E620326
	v_mov_b32_e32 v62, v38                                     // 0000001CDB7C: 7E7C0326
	v_mov_b32_e32 v61, v38                                     // 0000001CDB80: 7E7A0326
	v_mov_b32_e32 v60, v38                                     // 0000001CDB84: 7E780326
	v_mov_b32_e32 v59, v38                                     // 0000001CDB88: 7E760326
	v_mov_b32_e32 v58, v38                                     // 0000001CDB8C: 7E740326
	v_mov_b32_e32 v57, v38                                     // 0000001CDB90: 7E720326
	v_mov_b32_e32 v30, v38                                     // 0000001CDB94: 7E3C0326
	v_mov_b32_e32 v29, v38                                     // 0000001CDB98: 7E3A0326
	v_mov_b32_e32 v28, v38                                     // 0000001CDB9C: 7E380326
	v_mov_b32_e32 v27, v38                                     // 0000001CDBA0: 7E360326
	v_mov_b32_e32 v26, v38                                     // 0000001CDBA4: 7E340326
	v_mov_b32_e32 v25, v38                                     // 0000001CDBA8: 7E320326
	v_mov_b32_e32 v22, v38                                     // 0000001CDBAC: 7E2C0326
	v_mov_b32_e32 v21, v38                                     // 0000001CDBB0: 7E2A0326
	v_mov_b32_e32 v20, v38                                     // 0000001CDBB4: 7E280326
	v_mov_b32_e32 v19, v38                                     // 0000001CDBB8: 7E260326
	v_mov_b32_e32 v18, v38                                     // 0000001CDBBC: 7E240326
	v_mov_b32_e32 v17, v38                                     // 0000001CDBC0: 7E220326
	v_mov_b32_e32 v14, v38                                     // 0000001CDBC4: 7E1C0326
	v_mov_b32_e32 v13, v38                                     // 0000001CDBC8: 7E1A0326
	v_mov_b32_e32 v12, v38                                     // 0000001CDBCC: 7E180326
	v_mov_b32_e32 v11, v38                                     // 0000001CDBD0: 7E160326
	v_mov_b32_e32 v10, v38                                     // 0000001CDBD4: 7E140326
	v_mov_b32_e32 v9, v38                                      // 0000001CDBD8: 7E120326
	v_mov_b32_e32 v6, v38                                      // 0000001CDBDC: 7E0C0326
	v_mov_b32_e32 v5, v38                                      // 0000001CDBE0: 7E0A0326
	v_mov_b32_e32 v4, v38                                      // 0000001CDBE4: 7E080326
	v_mov_b32_e32 v3, v38                                      // 0000001CDBE8: 7E060326
	v_mov_b32_e32 v2, v38                                      // 0000001CDBEC: 7E040326
	v_mov_b32_e32 v1, v38                                      // 0000001CDBF0: 7E020326
	v_mov_b32_e32 v139, v38                                    // 0000001CDBF4: 7F160326
	v_mov_b32_e32 v154, v38                                    // 0000001CDBF8: 7F340326
	v_mov_b32_e32 v138, v38                                    // 0000001CDBFC: 7F140326
	v_mov_b32_e32 v155, v38                                    // 0000001CDC00: 7F360326
	v_mov_b32_e32 v137, v38                                    // 0000001CDC04: 7F120326
	v_mov_b32_e32 v153, v38                                    // 0000001CDC08: 7F320326
	s_cbranch_vccnz 1232                                       // 0000001CDC0C: BFA404D0 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi11EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1650>
	s_lshl2_add_u32 s0, s52, s1                                // 0000001CDC10: 87800134
	s_ashr_i32 s35, s34, 31                                    // 0000001CDC14: 86239F22
	v_dual_mov_b32 v153, 0 :: v_dual_lshlrev_b32 v0, 5, v0     // 0000001CDC18: CA220080 99000085
	v_dual_mov_b32 v168, 0xf149f2ca :: v_dual_lshlrev_b32 v3, 10, v7// 0000001CDC20: CA2200FF A8020E8A F149F2CA
	s_add_i32 s56, s0, 1                                       // 0000001CDC2C: 81388100
	s_lshl_b64 s[0:1], s[34:35], 11                            // 0000001CDC30: 84808B22
	v_cmp_gt_u32_e32 vcc_lo, 12, v156                          // 0000001CDC34: 7C99388C
	s_add_i32 s55, s55, -4                                     // 0000001CDC38: 8137C437
	s_add_u32 s0, s38, s0                                      // 0000001CDC3C: 80000026
	s_addc_u32 s1, s39, s1                                     // 0000001CDC40: 82010127
	v_dual_mov_b32 v65, 0 :: v_dual_lshlrev_b32 v4, 9, v7      // 0000001CDC44: CA220080 41040E89
	v_and_b32_e32 v0, 0x60, v0                                 // 0000001CDC4C: 360000FF 00000060
	.long 0xd7000005                                           // 0000001CDC54: D7000005
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000001CDC58: 02020600
	v_cndmask_b32_e32 v2, 0, v156, vcc_lo                      // 0000001CDC5C: 02053880
	v_add_co_ci_u32_e64 v6, null, s1, 0, s0                    // 0000001CDC60: D5207C06 00010001
	s_movk_i32 s1, 0x210                                       // 0000001CDC68: B0010210
	v_mov_b32_e32 v67, v65                                     // 0000001CDC6C: 7E860341
	.long 0xd7000000                                           // 0000001CDC70: D7000000
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000001CDC74: 02020105
	s_load_b128 s[48:51], s[46:47], null                       // 0000001CDC78: F4080C17 F8000000
	v_add_co_ci_u32_e64 v160, null, 0, v6, s0                  // 0000001CDC80: D5207CA0 00020C80
	v_mad_u32_u24 v2, v2, s1, 0x400                            // 0000001CDC88: D60B0002 03FC0302 00000400
	s_lshl_b64 s[0:1], s[34:35], 8                             // 0000001CDC94: 84808822
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001CDC98: BF8701B9
	v_dual_mov_b32 v166, s1 :: v_dual_lshlrev_b32 v1, 2, v156  // 0000001CDC9C: CA220001 A6013882
	v_xor_b32_e32 v5, 1, v7                                    // 0000001CDCA4: 3A0A0E81
	v_dual_mov_b32 v69, v65 :: v_dual_lshlrev_b32 v6, 5, v157  // 0000001CDCA8: CA220141 45073A85
	v_lshl_or_b32 v1, v157, 6, v1                              // 0000001CDCB0: D6560001 04050D9D
	v_dual_mov_b32 v71, v65 :: v_dual_lshlrev_b32 v8, 1, v156  // 0000001CDCB8: CA220141 47093881
	v_dual_mov_b32 v66, v65 :: v_dual_lshlrev_b32 v7, 8, v7    // 0000001CDCC0: CA220141 42060E88
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CDCC8: BF870223
	v_add_nc_u32_e32 v1, 0x1cc0, v1                            // 0000001CDCCC: 4A0202FF 00001CC0
	v_lshrrev_b32_e32 v159, 2, v156                            // 0000001CDCD4: 333F3882
	v_or3_b32 v163, v4, v6, v8                                 // 0000001CDCD8: D65800A3 04220D04
	v_lshl_or_b32 v164, v156, 5, v4                            // 0000001CDCE0: D65600A4 04110B9C
	v_or3_b32 v165, s0, v156, v158                             // 0000001CDCE8: D65800A5 067B3800
	v_dual_mov_b32 v170, 0xf149f2ca :: v_dual_add_nc_u32 v161, v1, v3// 0000001CDCF0: CA2000FF AAA00701 F149F2CA
	v_lshl_add_u32 v162, v5, 10, v1                            // 0000001CDCFC: D64600A2 04051505
	v_dual_mov_b32 v68, v65 :: v_dual_add_nc_u32 v167, v2, v7  // 0000001CDD04: CA200141 44A60F02
	v_dual_mov_b32 v70, v65 :: v_dual_mov_b32 v169, 0xf149f2ca // 0000001CDD0C: CA100141 46A800FF F149F2CA
	v_dual_mov_b32 v72, v65 :: v_dual_mov_b32 v171, 0xf149f2ca // 0000001CDD18: CA100141 48AA00FF F149F2CA
	v_dual_mov_b32 v172, 0xf149f2ca :: v_dual_mov_b32 v173, 0xf149f2ca// 0000001CDD24: CA1000FF ACAC00FF F149F2CA
	v_dual_mov_b32 v174, 0xf149f2ca :: v_dual_mov_b32 v137, 0  // 0000001CDD30: CA1000FF AE880080 F149F2CA
	v_dual_mov_b32 v176, 0xf149f2ca :: v_dual_mov_b32 v155, 0  // 0000001CDD3C: CA1000FF B09A0080 F149F2CA
	v_dual_mov_b32 v138, 0 :: v_dual_mov_b32 v139, 0           // 0000001CDD48: CA100080 8A8A0080
	v_dual_mov_b32 v154, 0 :: v_dual_mov_b32 v175, 0           // 0000001CDD50: CA100080 9AAE0080
	v_dual_mov_b32 v177, 0 :: v_dual_mov_b32 v2, v153          // 0000001CDD58: CA100080 B1020199
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v4, v153            // 0000001CDD60: CA100080 01040199
	v_mov_b32_e32 v3, v153                                     // 0000001CDD68: 7E060399
	v_mov_b32_e32 v5, v153                                     // 0000001CDD6C: 7E0A0399
	v_dual_mov_b32 v6, v153 :: v_dual_mov_b32 v9, 0            // 0000001CDD70: CA100199 06080080
	v_mov_b32_e32 v7, v153                                     // 0000001CDD78: 7E0E0399
	v_dual_mov_b32 v8, v153 :: v_dual_mov_b32 v17, 0           // 0000001CDD7C: CA100199 08100080
	v_dual_mov_b32 v10, v153 :: v_dual_mov_b32 v25, 0          // 0000001CDD84: CA100199 0A180080
	v_mov_b32_e32 v11, v153                                    // 0000001CDD8C: 7E160399
	v_dual_mov_b32 v12, v153 :: v_dual_mov_b32 v57, 0          // 0000001CDD90: CA100199 0C380080
	v_mov_b32_e32 v13, v153                                    // 0000001CDD98: 7E1A0399
	v_dual_mov_b32 v14, v153 :: v_dual_mov_b32 v49, 0          // 0000001CDD9C: CA100199 0E300080
	v_mov_b32_e32 v15, v153                                    // 0000001CDDA4: 7E1E0399
	v_dual_mov_b32 v16, v153 :: v_dual_mov_b32 v41, 0          // 0000001CDDA8: CA100199 10280080
	v_dual_mov_b32 v18, v153 :: v_dual_mov_b32 v33, 0          // 0000001CDDB0: CA100199 12200080
	v_mov_b32_e32 v19, v153                                    // 0000001CDDB8: 7E260399
	v_mov_b32_e32 v20, v153                                    // 0000001CDDBC: 7E280399
	v_mov_b32_e32 v21, v153                                    // 0000001CDDC0: 7E2A0399
	v_mov_b32_e32 v22, v153                                    // 0000001CDDC4: 7E2C0399
	v_mov_b32_e32 v23, v153                                    // 0000001CDDC8: 7E2E0399
	v_mov_b32_e32 v24, v153                                    // 0000001CDDCC: 7E300399
	v_mov_b32_e32 v26, v153                                    // 0000001CDDD0: 7E340399
	v_mov_b32_e32 v27, v153                                    // 0000001CDDD4: 7E360399
	v_mov_b32_e32 v28, v153                                    // 0000001CDDD8: 7E380399
	v_mov_b32_e32 v29, v153                                    // 0000001CDDDC: 7E3A0399
	v_mov_b32_e32 v30, v153                                    // 0000001CDDE0: 7E3C0399
	v_mov_b32_e32 v31, v153                                    // 0000001CDDE4: 7E3E0399
	v_mov_b32_e32 v32, v153                                    // 0000001CDDE8: 7E400399
	v_mov_b32_e32 v58, v153                                    // 0000001CDDEC: 7E740399
	v_mov_b32_e32 v59, v153                                    // 0000001CDDF0: 7E760399
	v_mov_b32_e32 v60, v153                                    // 0000001CDDF4: 7E780399
	v_mov_b32_e32 v61, v153                                    // 0000001CDDF8: 7E7A0399
	v_mov_b32_e32 v62, v153                                    // 0000001CDDFC: 7E7C0399
	v_mov_b32_e32 v63, v153                                    // 0000001CDE00: 7E7E0399
	v_mov_b32_e32 v64, v153                                    // 0000001CDE04: 7E800399
	v_mov_b32_e32 v50, v153                                    // 0000001CDE08: 7E640399
	v_mov_b32_e32 v51, v153                                    // 0000001CDE0C: 7E660399
	v_mov_b32_e32 v52, v153                                    // 0000001CDE10: 7E680399
	v_mov_b32_e32 v53, v153                                    // 0000001CDE14: 7E6A0399
	v_mov_b32_e32 v54, v153                                    // 0000001CDE18: 7E6C0399
	v_mov_b32_e32 v55, v153                                    // 0000001CDE1C: 7E6E0399
	v_mov_b32_e32 v56, v153                                    // 0000001CDE20: 7E700399
	v_mov_b32_e32 v42, v153                                    // 0000001CDE24: 7E540399
	v_mov_b32_e32 v43, v153                                    // 0000001CDE28: 7E560399
	v_mov_b32_e32 v44, v153                                    // 0000001CDE2C: 7E580399
	v_mov_b32_e32 v45, v153                                    // 0000001CDE30: 7E5A0399
	v_mov_b32_e32 v46, v153                                    // 0000001CDE34: 7E5C0399
	v_mov_b32_e32 v47, v153                                    // 0000001CDE38: 7E5E0399
	v_mov_b32_e32 v48, v153                                    // 0000001CDE3C: 7E600399
	v_mov_b32_e32 v34, v153                                    // 0000001CDE40: 7E440399
	v_mov_b32_e32 v35, v153                                    // 0000001CDE44: 7E460399
	v_mov_b32_e32 v36, v153                                    // 0000001CDE48: 7E480399
	v_mov_b32_e32 v37, v153                                    // 0000001CDE4C: 7E4A0399
	v_mov_b32_e32 v38, v153                                    // 0000001CDE50: 7E4C0399
	v_mov_b32_e32 v39, v153                                    // 0000001CDE54: 7E4E0399
	v_mov_b32_e32 v40, v153                                    // 0000001CDE58: 7E500399
	s_mov_b32 s35, 0                                           // 0000001CDE5C: BEA30080
	v_cmp_eq_u32_e32 vcc_lo, 2, v159                           // 0000001CDE60: 7C953E82
	s_branch 1030                                              // 0000001CDE64: BFA00406 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi11EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1580>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CDE68: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CDE6C: BF870099
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001CDE70: 8C7E017E
	v_ashrrev_i32_e32 v74, 31, v73                             // 0000001CDE74: 3494929F
	ds_load_b128 v[181:184], v167                              // 0000001CDE78: DBFC0000 B50000A7
	ds_load_b128 v[185:188], v167 offset:16                    // 0000001CDE80: DBFC0010 B90000A7
	ds_load_b128 v[189:192], v167 offset:32                    // 0000001CDE88: DBFC0020 BD0000A7
	ds_load_b128 v[193:196], v167 offset:48                    // 0000001CDE90: DBFC0030 C10000A7
	ds_load_b128 v[201:204], v167 offset:80                    // 0000001CDE98: DBFC0050 C90000A7
	ds_load_b128 v[197:200], v167 offset:64                    // 0000001CDEA0: DBFC0040 C50000A7
	ds_load_b128 v[209:212], v167 offset:112                   // 0000001CDEA8: DBFC0070 D10000A7
	ds_load_b128 v[205:208], v167 offset:96                    // 0000001CDEB0: DBFC0060 CD0000A7
	ds_load_b128 v[217:220], v167 offset:144                   // 0000001CDEB8: DBFC0090 D90000A7
	ds_load_b128 v[213:216], v167 offset:128                   // 0000001CDEC0: DBFC0080 D50000A7
	s_ashr_i32 s5, s4, 31                                      // 0000001CDEC8: 86059F04
	s_ashr_i32 s15, s14, 31                                    // 0000001CDECC: 860F9F0E
	s_ashr_i32 s7, s6, 31                                      // 0000001CDED0: 86079F06
	.long 0xd73c0049                                           // 0000001CDED4: D73C0049
	v_cndmask_b32_e32 v1, 12, v73, vcc_lo                      // 0000001CDED8: 0202928C
	s_lshl_b64 s[4:5], s[4:5], 9                               // 0000001CDEDC: 84848904
	s_lshl_b64 s[14:15], s[14:15], 9                           // 0000001CDEE0: 848E890E
	s_lshl_b64 s[6:7], s[6:7], 9                               // 0000001CDEE4: 84868906
	s_ashr_i32 s13, s12, 31                                    // 0000001CDEE8: 860D9F0C
	ds_load_b128 v[221:224], v167 offset:224                   // 0000001CDEEC: DBFC00E0 DD0000A7
	.long 0xd7000079                                           // 0000001CDEF4: D7000079
	v_cndmask_b32_e32 v1, v0, v73, vcc_lo                      // 0000001CDEF8: 02029300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CDEFC: BF870001
	v_add_co_ci_u32_e64 v122, null, v160, v74, s0              // 0000001CDF00: D5207C7A 000295A0
	s_lshl_b64 s[12:13], s[12:13], 9                           // 0000001CDF08: 848C890C
	s_mov_b32 s50, s10                                         // 0000001CDF0C: BEB2000A
	s_mov_b32 s49, s9                                          // 0000001CDF10: BEB10009
	s_clause 0xf                                               // 0000001CDF14: BF85000F
	global_load_b128 v[77:80], v[121:122], off offset:16       // 0000001CDF18: DC5E0010 4D7C0079
	global_load_b128 v[73:76], v[121:122], off                 // 0000001CDF20: DC5E0000 497C0079
	global_load_b128 v[85:88], v[121:122], off offset:144      // 0000001CDF28: DC5E0090 557C0079
	global_load_b128 v[81:84], v[121:122], off offset:128      // 0000001CDF30: DC5E0080 517C0079
	global_load_b128 v[93:96], v[121:122], off offset:272      // 0000001CDF38: DC5E0110 5D7C0079
	global_load_b128 v[89:92], v[121:122], off offset:256      // 0000001CDF40: DC5E0100 597C0079
	global_load_b128 v[101:104], v[121:122], off offset:400    // 0000001CDF48: DC5E0190 657C0079
	global_load_b128 v[97:100], v[121:122], off offset:384     // 0000001CDF50: DC5E0180 617C0079
	global_load_b128 v[109:112], v[121:122], off offset:528    // 0000001CDF58: DC5E0210 6D7C0079
	global_load_b128 v[105:108], v[121:122], off offset:512    // 0000001CDF60: DC5E0200 697C0079
	global_load_b128 v[117:120], v[121:122], off offset:656    // 0000001CDF68: DC5E0290 757C0079
	global_load_b128 v[113:116], v[121:122], off offset:640    // 0000001CDF70: DC5E0280 717C0079
	global_load_b128 v[127:130], v[121:122], off offset:784    // 0000001CDF78: DC5E0310 7F7C0079
	global_load_b128 v[123:126], v[121:122], off offset:768    // 0000001CDF80: DC5E0300 7B7C0079
	global_load_b128 v[149:152], v[121:122], off offset:912    // 0000001CDF88: DC5E0390 957C0079
	global_load_b128 v[145:148], v[121:122], off offset:896    // 0000001CDF90: DC5E0380 917C0079
	s_mov_b32 s48, s8                                          // 0000001CDF98: BEB00008
	s_mov_b32 s51, s11                                         // 0000001CDF9C: BEB3000B
	s_add_i32 s37, s37, -1                                     // 0000001CDFA0: 8125C125
	s_waitcnt vmcnt(14) lgkmcnt(9)                             // 0000001CDFA4: BF893897
	v_wmma_f32_16x16x16_bf16 v[137:144], v[181:188], v[73:80], v[65:72]// 0000001CDFA8: CC414089 1D0693B5
	ds_load_b128 v[185:188], v167 offset:176                   // 0000001CDFB0: DBFC00B0 B90000A7
	ds_load_b128 v[181:184], v167 offset:160                   // 0000001CDFB8: DBFC00A0 B50000A7
	.long 0xd7000049                                           // 0000001CDFC0: D7000049
	v_cndmask_b32_e32 v1, s4, v165, vcc_lo                     // 0000001CDFC4: 02034A04
	s_waitcnt vmcnt(12) lgkmcnt(9)                             // 0000001CDFC8: BF893097
	v_wmma_f32_16x16x16_bf16 v[137:144], v[189:196], v[81:88], v[137:144]// 0000001CDFCC: CC414089 1E26A3BD
	.long 0xd700044f                                           // 0000001CDFD4: D700044F
	v_cndmask_b32_e32 v1, s14, v165, vcc_lo                    // 0000001CDFD8: 02034A0E
	ds_load_b128 v[193:196], v167 offset:208                   // 0000001CDFDC: DBFC00D0 C10000A7
	ds_load_b128 v[189:192], v167 offset:192                   // 0000001CDFE4: DBFC00C0 BD0000A7
	ds_load_b128 v[225:228], v167 offset:240                   // 0000001CDFEC: DBFC00F0 E10000A7
	.long 0xd700014b                                           // 0000001CDFF4: D700014B
	v_cndmask_b32_e32 v1, s6, v165, vcc_lo                     // 0000001CDFF8: 02034A06
	s_waitcnt vmcnt(10) lgkmcnt(10)                            // 0000001CDFFC: BF8928A7
	v_wmma_f32_16x16x16_bf16 v[137:144], v[197:204], v[89:96], v[137:144]// 0000001CE000: CC414089 1E26B3C5
	v_add_co_ci_u32_e64 v74, null, s5, v166, s0                // 0000001CE008: D5207C4A 00034C05
	v_add_co_ci_u32_e64 v80, null, s15, v166, s4               // 0000001CE010: D5207C50 00134C0F
	v_add_co_ci_u32_e64 v76, null, s7, v166, s1                // 0000001CE018: D5207C4C 00074C07
	.long 0xd700034d                                           // 0000001CE020: D700034D
	v_cndmask_b32_e32 v1, s12, v165, vcc_lo                    // 0000001CE024: 02034A0C
	s_waitcnt vmcnt(8) lgkmcnt(8)                              // 0000001CE028: BF892087
	v_wmma_f32_16x16x16_bf16 v[137:144], v[205:212], v[97:104], v[137:144]// 0000001CE02C: CC414089 1E26C3CD
	v_add_co_ci_u32_e64 v78, null, s13, v166, s3               // 0000001CE034: D5207C4E 000F4C0D
	.long 0xd73c0049                                           // 0000001CE03C: D73C0049
	v_cndmask_b32_e32 v1, 3, v73, vcc_lo                       // 0000001CE040: 02029283
	.long 0xd73c004f                                           // 0000001CE044: D73C004F
	v_cndmask_b32_e32 v1, 3, v79, vcc_lo                       // 0000001CE048: 02029E83
	.long 0xd73c004b                                           // 0000001CE04C: D73C004B
	v_cndmask_b32_e32 v1, 3, v75, vcc_lo                       // 0000001CE050: 02029683
	s_waitcnt vmcnt(6) lgkmcnt(6)                              // 0000001CE054: BF891867
	v_wmma_f32_16x16x16_bf16 v[137:144], v[213:220], v[105:112], v[137:144]// 0000001CE058: CC414089 1E26D3D5
	.long 0xd73c004d                                           // 0000001CE060: D73C004D
	v_cndmask_b32_e32 v1, 3, v77, vcc_lo                       // 0000001CE064: 02029A83
	.long 0xd7000083                                           // 0000001CE068: D7000083
	v_cndmask_b32_e32 v1, s40, v73, vcc_lo                     // 0000001CE06C: 02029228
	.long 0xd70004c5                                           // 0000001CE070: D70004C5
	v_cndmask_b32_e32 v1, s40, v79, vcc_lo                     // 0000001CE074: 02029E28
	.long 0xd7000185                                           // 0000001CE078: D7000185
	v_cndmask_b32_e32 v1, s40, v75, vcc_lo                     // 0000001CE07C: 02029628
	v_add_co_ci_u32_e64 v132, null, s41, v74, s0               // 0000001CE080: D5207C84 00029429
	v_add_co_ci_u32_e64 v198, null, s41, v80, s4               // 0000001CE088: D5207CC6 0012A029
	s_waitcnt vmcnt(4) lgkmcnt(3)                              // 0000001CE090: BF891037
	v_wmma_f32_16x16x16_bf16 v[137:144], v[181:188], v[113:120], v[137:144]// 0000001CE094: CC414089 1E26E3B5
	v_add_co_ci_u32_e64 v134, null, s41, v76, s1               // 0000001CE09C: D5207C86 00069829
	.long 0xd7000387                                           // 0000001CE0A4: D7000387
	v_cndmask_b32_e32 v1, s40, v77, vcc_lo                     // 0000001CE0A8: 02029A28
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CE0AC: BF870001
	v_add_co_ci_u32_e64 v136, null, s41, v78, s3               // 0000001CE0B0: D5207C88 000E9C29
	s_clause 0x12                                              // 0000001CE0B8: BF850012
	global_load_b64 v[73:74], v[131:132], off                  // 0000001CE0BC: DC560000 497C0083
	global_load_b64 v[81:82], v[131:132], off offset:128       // 0000001CE0C4: DC560080 517C0083
	global_load_b64 v[89:90], v[131:132], off offset:256       // 0000001CE0CC: DC560100 597C0083
	global_load_b64 v[97:98], v[131:132], off offset:384       // 0000001CE0D4: DC560180 617C0083
	global_load_b64 v[75:76], v[133:134], off                  // 0000001CE0DC: DC560000 4B7C0085
	global_load_b64 v[83:84], v[133:134], off offset:128       // 0000001CE0E4: DC560080 537C0085
	global_load_b64 v[91:92], v[133:134], off offset:256       // 0000001CE0EC: DC560100 5B7C0085
	global_load_b64 v[99:100], v[133:134], off offset:384      // 0000001CE0F4: DC560180 637C0085
	global_load_b64 v[77:78], v[135:136], off                  // 0000001CE0FC: DC560000 4D7C0087
	global_load_b64 v[85:86], v[135:136], off offset:128       // 0000001CE104: DC560080 557C0087
	global_load_b64 v[93:94], v[135:136], off offset:256       // 0000001CE10C: DC560100 5D7C0087
	global_load_b64 v[101:102], v[135:136], off offset:384     // 0000001CE114: DC560180 657C0087
	global_load_b64 v[79:80], v[197:198], off                  // 0000001CE11C: DC560000 4F7C00C5
	global_load_b64 v[87:88], v[197:198], off offset:128       // 0000001CE124: DC560080 577C00C5
	global_load_b64 v[95:96], v[197:198], off offset:256       // 0000001CE12C: DC560100 5F7C00C5
	global_load_b64 v[103:104], v[197:198], off offset:384     // 0000001CE134: DC560180 677C00C5
	global_load_b64 v[105:106], v[131:132], off offset:512     // 0000001CE13C: DC560200 697C0083
	global_load_b64 v[113:114], v[131:132], off offset:640     // 0000001CE144: DC560280 717C0083
	global_load_b64 v[121:122], v[131:132], off offset:768     // 0000001CE14C: DC560300 797C0083
	s_waitcnt vmcnt(21) lgkmcnt(1)                             // 0000001CE154: BF895417
	v_wmma_f32_16x16x16_bf16 v[137:144], v[189:196], v[123:130], v[137:144]// 0000001CE158: CC414089 1E26F7BD
	s_clause 0xc                                               // 0000001CE160: BF85000C
	global_load_b64 v[129:130], v[131:132], off offset:896     // 0000001CE164: DC560380 817C0083
	global_load_b64 v[107:108], v[133:134], off offset:512     // 0000001CE16C: DC560200 6B7C0085
	global_load_b64 v[115:116], v[133:134], off offset:640     // 0000001CE174: DC560280 737C0085
	global_load_b64 v[123:124], v[133:134], off offset:768     // 0000001CE17C: DC560300 7B7C0085
	global_load_b64 v[131:132], v[133:134], off offset:896     // 0000001CE184: DC560380 837C0085
	global_load_b64 v[109:110], v[135:136], off offset:512     // 0000001CE18C: DC560200 6D7C0087
	global_load_b64 v[117:118], v[135:136], off offset:640     // 0000001CE194: DC560280 757C0087
	global_load_b64 v[125:126], v[135:136], off offset:768     // 0000001CE19C: DC560300 7D7C0087
	global_load_b64 v[133:134], v[135:136], off offset:896     // 0000001CE1A4: DC560380 857C0087
	global_load_b64 v[111:112], v[197:198], off offset:512     // 0000001CE1AC: DC560200 6F7C00C5
	global_load_b64 v[119:120], v[197:198], off offset:640     // 0000001CE1B4: DC560280 777C00C5
	global_load_b64 v[127:128], v[197:198], off offset:768     // 0000001CE1BC: DC560300 7F7C00C5
	global_load_b64 v[135:136], v[197:198], off offset:896     // 0000001CE1C4: DC560380 877C00C5
	.long 0xd4440000                                           // 0000001CE1CC: D4440000
	v_cndmask_b32_e32 v1, s56, v156, vcc_lo                    // 0000001CE1D0: 02033838
	.long 0xd59c40b5                                           // 0000001CE1D4: D59C40B5
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 0000001CE1D8: 02010080
	s_waitcnt vmcnt(32) lgkmcnt(0)                             // 0000001CE1DC: BF898007
	v_wmma_f32_16x16x16_bf16 v[137:144], v[221:228], v[145:152], v[137:144]// 0000001CE1E0: CC414089 1E2723DD
	ds_store_2addr_b32 v161, v137, v138 offset1:32             // 0000001CE1E8: D8382000 008A89A1
	ds_store_2addr_b32 v161, v139, v140 offset0:64 offset1:96  // 0000001CE1F0: D8386040 008C8BA1
	ds_store_2addr_b32 v161, v141, v142 offset0:128 offset1:160// 0000001CE1F8: D838A080 008E8DA1
	ds_store_2addr_b32 v161, v143, v144 offset0:192 offset1:224// 0000001CE200: D838E0C0 00908FA1
	.long 0xd59c48b6                                           // 0000001CE208: D59C48B6
	v_cndmask_b32_e32 v0, v181, v128, vcc_lo                   // 0000001CE20C: 020101B5
	.long 0xd59c48b7                                           // 0000001CE210: D59C48B7
	v_cndmask_b32_e32 v0, v181, v128, vcc_lo                   // 0000001CE214: 020101B5
	.long 0xd59c48b8                                           // 0000001CE218: D59C48B8
	v_cndmask_b32_e32 v0, v181, v128, vcc_lo                   // 0000001CE21C: 020101B5
	.long 0xd59c48b9                                           // 0000001CE220: D59C48B9
	v_cndmask_b32_e32 v0, v181, v128, vcc_lo                   // 0000001CE224: 020101B5
	s_add_i32 s56, s56, -16                                    // 0000001CE228: 8138D038
	s_cmp_lg_u32 s37, 0                                        // 0000001CE22C: BF078025
	s_waitcnt lgkmcnt(0)                                       // 0000001CE230: BF89FC07
	s_barrier                                                  // 0000001CE234: BFBD0000
	ds_load_2addr_b32 v[151:152], v162 offset1:32              // 0000001CE238: D8DC2000 970000A2
	ds_load_2addr_b32 v[149:150], v162 offset0:64 offset1:96   // 0000001CE240: D8DC6040 950000A2
	ds_load_2addr_b32 v[147:148], v162 offset0:128 offset1:160 // 0000001CE248: D8DCA080 930000A2
	ds_load_2addr_b32 v[145:146], v162 offset0:192 offset1:224 // 0000001CE250: D8DCE0C0 910000A2
	s_waitcnt lgkmcnt(3)                                       // 0000001CE258: BF89FC37
	v_dual_add_f32 v138, v138, v152 :: v_dual_add_f32 v137, v137, v151// 0000001CE25C: C909318A 8A892F89
	s_waitcnt lgkmcnt(1)                                       // 0000001CE264: BF89FC17
	v_dual_add_f32 v142, v142, v148 :: v_dual_add_f32 v141, v141, v147// 0000001CE268: C909298E 8E8D278D
	v_dual_add_f32 v140, v140, v150 :: v_dual_add_f32 v139, v139, v149// 0000001CE270: C9092D8C 8C8B2B8B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001CE278: BF8701C3
	v_dual_mul_f32 v138, 0x3d800000, v138 :: v_dual_mul_f32 v137, 0x3d800000, v137// 0000001CE27C: C8C714FF 8A8912FF 3D800000
	s_waitcnt lgkmcnt(0)                                       // 0000001CE288: BF89FC07
	v_dual_add_f32 v144, v144, v146 :: v_dual_add_f32 v143, v143, v145// 0000001CE28C: C9092590 908F238F
	v_dual_mul_f32 v142, 0x3d800000, v142 :: v_dual_mul_f32 v141, 0x3d800000, v141// 0000001CE294: C8C71CFF 8E8D1AFF 3D800000
	v_cndmask_b32_e64 v137, 0xf149f2ca, v137, s0               // 0000001CE2A0: D5010089 000312FF F149F2CA
	v_dual_mul_f32 v140, 0x3d800000, v140 :: v_dual_mul_f32 v139, 0x3d800000, v139// 0000001CE2AC: C8C718FF 8C8B16FF 3D800000
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CE2B8: BF870004
	v_dual_mul_f32 v144, 0x3d800000, v144 :: v_dual_mul_f32 v143, 0x3d800000, v143// 0000001CE2BC: C8C720FF 908F1EFF 3D800000
	v_cndmask_b32_e64 v138, 0xf149f2ca, v138, s0               // 0000001CE2C8: D501008A 000314FF F149F2CA
	v_cndmask_b32_e64 v142, 0xf149f2ca, v142, s0               // 0000001CE2D4: D501008E 00031CFF F149F2CA
	v_cndmask_b32_e64 v141, 0xf149f2ca, v141, s0               // 0000001CE2E0: D501008D 00031AFF F149F2CA
	v_mov_b32_dpp v145, v137 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE2EC: 7F2202FA FF096189
	v_cndmask_b32_e64 v139, 0xf149f2ca, v139, s0               // 0000001CE2F4: D501008B 000316FF F149F2CA
	v_cndmask_b32_e64 v143, 0xf149f2ca, v143, s0               // 0000001CE300: D501008F 00031EFF F149F2CA
	v_mov_b32_dpp v146, v138 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE30C: 7F2402FA FF09618A
	v_mov_b32_dpp v149, v141 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE314: 7F2A02FA FF09618D
	v_mov_b32_dpp v150, v142 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE31C: 7F2C02FA FF09618E
	v_max_f32_e32 v145, v145, v145                             // 0000001CE324: 21232391
	v_cndmask_b32_e64 v140, 0xf149f2ca, v140, s0               // 0000001CE328: D501008C 000318FF F149F2CA
	v_cndmask_b32_e64 v144, 0xf149f2ca, v144, s0               // 0000001CE334: D5010090 000320FF F149F2CA
	v_mov_b32_dpp v147, v139 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE340: 7F2602FA FF09618B
	v_mov_b32_dpp v151, v143 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE348: 7F2E02FA FF09618F
	v_dual_max_f32 v146, v146, v146 :: v_dual_max_f32 v149, v149, v149// 0000001CE350: CA952592 92952B95
	v_dual_max_f32 v150, v150, v150 :: v_dual_max_f32 v145, v137, v145// 0000001CE358: CA952D96 96912389
	v_mov_b32_dpp v148, v140 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE360: 7F2802FA FF09618C
	v_mov_b32_dpp v152, v144 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE368: 7F3002FA FF096190
	v_max_f32_e32 v147, v147, v147                             // 0000001CE370: 21272793
	v_dual_max_f32 v151, v151, v151 :: v_dual_max_f32 v146, v138, v146// 0000001CE374: CA952F97 9793258A
	v_dual_max_f32 v149, v141, v149 :: v_dual_max_f32 v150, v142, v150// 0000001CE37C: CA952B8D 95972D8E
	v_mov_b32_dpp v186, v145 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE384: 7F7402FA FF096291
	v_max_f32_e32 v148, v148, v148                             // 0000001CE38C: 21292994
	v_dual_max_f32 v152, v152, v152 :: v_dual_max_f32 v147, v139, v147// 0000001CE390: CA953198 9893278B
	v_max_f32_e32 v151, v143, v151                             // 0000001CE398: 212F2F8F
	v_mov_b32_dpp v187, v146 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE39C: 7F7602FA FF096292
	v_mov_b32_dpp v190, v149 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE3A4: 7F7C02FA FF096295
	v_mov_b32_dpp v191, v150 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE3AC: 7F7E02FA FF096296
	v_max_f32_e32 v186, v186, v186                             // 0000001CE3B4: 217575BA
	v_max_f32_e32 v148, v140, v148                             // 0000001CE3B8: 2129298C
	v_max_f32_e32 v152, v144, v152                             // 0000001CE3BC: 21313190
	v_mov_b32_dpp v188, v147 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE3C0: 7F7802FA FF096293
	v_mov_b32_dpp v192, v151 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE3C8: 7F8002FA FF096297
	v_dual_max_f32 v187, v187, v187 :: v_dual_max_f32 v190, v190, v190// 0000001CE3D0: CA9577BB BBBF7DBE
	v_max_f32_e32 v191, v191, v191                             // 0000001CE3D8: 217F7FBF
	v_max_f32_e32 v145, v145, v186                             // 0000001CE3DC: 21237591
	v_mov_b32_dpp v189, v148 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE3E0: 7F7A02FA FF096294
	v_mov_b32_dpp v193, v152 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE3E8: 7F8202FA FF096298
	v_max_f32_e32 v188, v188, v188                             // 0000001CE3F0: 217979BC
	v_max_f32_e32 v192, v192, v192                             // 0000001CE3F4: 218181C0
	v_dual_max_f32 v146, v146, v187 :: v_dual_max_f32 v149, v149, v190// 0000001CE3F8: CA957792 92957D95
	v_max_f32_e32 v150, v150, v191                             // 0000001CE400: 212D7F96
	v_mov_b32_dpp v186, v145 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE404: 7F7402FA FF096491
	v_max_f32_e32 v189, v189, v189                             // 0000001CE40C: 217B7BBD
	v_max_f32_e32 v193, v193, v193                             // 0000001CE410: 218383C1
	v_max_f32_e32 v147, v147, v188                             // 0000001CE414: 21277993
	v_max_f32_e32 v151, v151, v192                             // 0000001CE418: 212F8197
	v_mov_b32_dpp v187, v146 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE41C: 7F7602FA FF096492
	v_mov_b32_dpp v190, v149 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE424: 7F7C02FA FF096495
	v_mov_b32_dpp v191, v150 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE42C: 7F7E02FA FF096496
	v_max_f32_e32 v186, v186, v186                             // 0000001CE434: 217575BA
	v_max_f32_e32 v148, v148, v189                             // 0000001CE438: 21297B94
	v_max_f32_e32 v152, v152, v193                             // 0000001CE43C: 21318398
	v_mov_b32_dpp v188, v147 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE440: 7F7802FA FF096493
	v_mov_b32_dpp v192, v151 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE448: 7F8002FA FF096497
	v_dual_max_f32 v187, v187, v187 :: v_dual_max_f32 v190, v190, v190// 0000001CE450: CA9577BB BBBF7DBE
	v_max_f32_e32 v191, v191, v191                             // 0000001CE458: 217F7FBF
	v_max_f32_e32 v145, v145, v186                             // 0000001CE45C: 21237591
	v_mov_b32_dpp v189, v148 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE460: 7F7A02FA FF096494
	v_mov_b32_dpp v193, v152 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE468: 7F8202FA FF096498
	v_max_f32_e32 v188, v188, v188                             // 0000001CE470: 217979BC
	v_max_f32_e32 v192, v192, v192                             // 0000001CE474: 218181C0
	v_dual_max_f32 v146, v146, v187 :: v_dual_max_f32 v149, v149, v190// 0000001CE478: CA957792 92957D95
	v_max_f32_e32 v150, v150, v191                             // 0000001CE480: 212D7F96
	v_mov_b32_dpp v186, v145 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE484: 7F7402FA FF096891
	v_max_f32_e32 v189, v189, v189                             // 0000001CE48C: 217B7BBD
	v_max_f32_e32 v193, v193, v193                             // 0000001CE490: 218383C1
	v_max_f32_e32 v147, v147, v188                             // 0000001CE494: 21277993
	v_max_f32_e32 v151, v151, v192                             // 0000001CE498: 212F8197
	v_mov_b32_dpp v187, v146 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE49C: 7F7602FA FF096892
	v_mov_b32_dpp v190, v149 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE4A4: 7F7C02FA FF096895
	v_mov_b32_dpp v191, v150 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE4AC: 7F7E02FA FF096896
	v_max3_f32 v145, v168, v145, v186                          // 0000001CE4B4: D61C0091 06EB23A8
	v_max_f32_e32 v148, v148, v189                             // 0000001CE4BC: 21297B94
	v_max_f32_e32 v152, v152, v193                             // 0000001CE4C0: 21318398
	v_mov_b32_dpp v188, v147 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE4C4: 7F7802FA FF096893
	v_mov_b32_dpp v192, v151 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE4CC: 7F8002FA FF096897
	v_max3_f32 v146, v169, v146, v187                          // 0000001CE4D4: D61C0092 06EF25A9
	v_max3_f32 v149, v172, v149, v190                          // 0000001CE4DC: D61C0095 06FB2BAC
	v_max3_f32 v150, v173, v150, v191                          // 0000001CE4E4: D61C0096 06FF2DAD
	v_sub_f32_e32 v137, v137, v145                             // 0000001CE4EC: 09132389
	v_mov_b32_dpp v189, v148 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE4F0: 7F7A02FA FF096894
	v_mov_b32_dpp v193, v152 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CE4F8: 7F8202FA FF096898
	v_max3_f32 v147, v170, v147, v188                          // 0000001CE500: D61C0093 06F327AA
	v_max3_f32 v151, v174, v151, v192                          // 0000001CE508: D61C0097 07032FAE
	v_dual_sub_f32 v138, v138, v146 :: v_dual_sub_f32 v141, v141, v149// 0000001CE510: C94B258A 8A8D2B8D
	v_sub_f32_e32 v142, v142, v150                             // 0000001CE518: 091D2D8E
	v_dual_sub_f32 v186, v168, v145 :: v_dual_sub_f32 v187, v169, v146// 0000001CE51C: C94B23A8 BABB25A9
	v_dual_mov_b32 v168, v145 :: v_dual_mov_b32 v169, v146     // 0000001CE524: CA100191 A8A80192
	v_mul_f32_e32 v146, 0x3fb8aa3b, v137                       // 0000001CE52C: 112512FF 3FB8AA3B
	v_max3_f32 v148, v171, v148, v189                          // 0000001CE534: D61C0094 06F729AB
	v_max3_f32 v152, v176, v152, v193                          // 0000001CE53C: D61C0098 070731B0
	v_sub_f32_e32 v139, v139, v147                             // 0000001CE544: 0917278B
	v_dual_sub_f32 v143, v143, v151 :: v_dual_sub_f32 v190, v172, v149// 0000001CE548: C94B2F8F 8FBF2BAC
	v_dual_sub_f32 v191, v173, v150 :: v_dual_sub_f32 v192, v174, v151// 0000001CE550: C94B2DAD BFC12FAE
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CE558: BF870004
	v_dual_sub_f32 v193, v176, v152 :: v_dual_mov_b32 v172, v149// 0000001CE55C: C95131B0 C1AC0195
	v_dual_mov_b32 v173, v150 :: v_dual_mov_b32 v174, v151     // 0000001CE564: CA100196 ADAE0197
	v_mul_f32_e32 v145, 0x3fb8aa3b, v138                       // 0000001CE56C: 112314FF 3FB8AA3B
	v_mul_f32_e32 v149, 0x3fb8aa3b, v142                       // 0000001CE574: 112B1CFF 3FB8AA3B
	v_fma_f32 v204, 0x3fb8aa3b, v137, -v146                    // 0000001CE57C: D61300CC 864B12FF 3FB8AA3B
	v_sub_f32_e32 v140, v140, v148                             // 0000001CE588: 0919298C
	v_sub_f32_e32 v144, v144, v152                             // 0000001CE58C: 09213190
	v_dual_sub_f32 v188, v170, v147 :: v_dual_sub_f32 v189, v171, v148// 0000001CE590: C94B27AA BCBD29AB
	v_dual_mov_b32 v170, v147 :: v_dual_mov_b32 v171, v148     // 0000001CE598: CA100193 AAAA0194
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CE5A0: BF870214
	v_dual_mov_b32 v176, v152 :: v_dual_mul_f32 v147, 0x3fb8aa3b, v140// 0000001CE5A4: CA060198 B09318FF 3FB8AA3B
	v_dual_mul_f32 v148, 0x3fb8aa3b, v139 :: v_dual_mul_f32 v151, 0x3fb8aa3b, v144// 0000001CE5B0: C8C716FF 949720FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CE5BC: BF870004
	v_dual_mul_f32 v152, 0x3fb8aa3b, v143 :: v_dual_mul_f32 v197, 0x3fb8aa3b, v189// 0000001CE5C0: C8C71EFF 98C57AFF 3FB8AA3B
	.long 0xd41b000a                                           // 0000001CE5CC: D41B000A
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v137, vcc_lo             // 0000001CE5D0: 020312FF C2CE8ED0
	.long 0xd41e0001                                           // 0000001CE5D8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v137, vcc_lo             // 0000001CE5DC: 020312FF 42B17218
	v_fma_f32 v202, 0x3fb8aa3b, v138, -v145                    // 0000001CE5E4: D61300CA 864714FF 3FB8AA3B
	v_fmac_f32_e32 v204, 0x32a5705f, v137                      // 0000001CE5F0: 579912FF 32A5705F
	v_fma_f32 v137, 0x3fb8aa3b, v142, -v149                    // 0000001CE5F8: D6130089 86571CFF 3FB8AA3B
	.long 0xd41b0009                                           // 0000001CE604: D41B0009
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v138, vcc_lo             // 0000001CE608: 020314FF C2CE8ED0
	.long 0xd41b000d                                           // 0000001CE610: D41B000D
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v142, vcc_lo             // 0000001CE614: 02031CFF C2CE8ED0
	.long 0xd41e0000                                           // 0000001CE61C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v138, vcc_lo             // 0000001CE620: 020314FF 42B17218
	.long 0xd41e0005                                           // 0000001CE628: D41E0005
	v_cndmask_b32_e32 v1, 0x42b17218, v142, vcc_lo             // 0000001CE62C: 02031CFF 42B17218
	v_dual_mul_f32 v196, 0x3fb8aa3b, v188 :: v_dual_mul_f32 v201, 0x3fb8aa3b, v193// 0000001CE634: C8C778FF C4C982FF 3FB8AA3B
	v_fmac_f32_e32 v202, 0x32a5705f, v138                      // 0000001CE640: 579514FF 32A5705F
	v_fma_f32 v138, 0x3fb8aa3b, v139, -v148                    // 0000001CE648: D613008A 865316FF 3FB8AA3B
	v_fmac_f32_e32 v137, 0x32a5705f, v142                      // 0000001CE654: 57131CFF 32A5705F
	v_fma_f32 v142, 0x3fb8aa3b, v143, -v152                    // 0000001CE65C: D613008E 86631EFF 3FB8AA3B
	v_dual_mul_f32 v150, 0x3fb8aa3b, v141 :: v_dual_mul_f32 v195, 0x3fb8aa3b, v187// 0000001CE668: C8C71AFF 96C376FF 3FB8AA3B
	.long 0xd41b000c                                           // 0000001CE674: D41B000C
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v139, vcc_lo             // 0000001CE678: 020316FF C2CE8ED0
	.long 0xd41b0010                                           // 0000001CE680: D41B0010
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v143, vcc_lo             // 0000001CE684: 02031EFF C2CE8ED0
	.long 0xd41e0004                                           // 0000001CE68C: D41E0004
	v_cndmask_b32_e32 v1, 0x42b17218, v139, vcc_lo             // 0000001CE690: 020316FF 42B17218
	.long 0xd41e0008                                           // 0000001CE698: D41E0008
	v_cndmask_b32_e32 v1, 0x42b17218, v143, vcc_lo             // 0000001CE69C: 02031EFF 42B17218
	v_dual_mul_f32 v194, 0x3fb8aa3b, v186 :: v_dual_mul_f32 v199, 0x3fb8aa3b, v191// 0000001CE6A4: C8C774FF C2C77EFF 3FB8AA3B
	v_fma_f32 v206, 0x3fb8aa3b, v140, -v147                    // 0000001CE6B0: D61300CE 864F18FF 3FB8AA3B
	v_fmac_f32_e32 v142, 0x32a5705f, v143                      // 0000001CE6BC: 571D1EFF 32A5705F
	v_fma_f32 v143, 0x3fb8aa3b, v188, -v196                    // 0000001CE6C4: D613008F 871378FF 3FB8AA3B
	v_fmac_f32_e32 v138, 0x32a5705f, v139                      // 0000001CE6D0: 571516FF 32A5705F
	v_fma_f32 v139, 0x3fb8aa3b, v144, -v151                    // 0000001CE6D8: D613008B 865F20FF 3FB8AA3B
	.long 0xd41b000b                                           // 0000001CE6E4: D41B000B
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v140, vcc_lo             // 0000001CE6E8: 020318FF C2CE8ED0
	.long 0xd41b000f                                           // 0000001CE6F0: D41B000F
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v144, vcc_lo             // 0000001CE6F4: 020320FF C2CE8ED0
	.long 0xd41e0003                                           // 0000001CE6FC: D41E0003
	v_cndmask_b32_e32 v1, 0x42b17218, v140, vcc_lo             // 0000001CE700: 020318FF 42B17218
	.long 0xd41e0007                                           // 0000001CE708: D41E0007
	v_cndmask_b32_e32 v1, 0x42b17218, v144, vcc_lo             // 0000001CE70C: 020320FF 42B17218
	.long 0xd41b0013                                           // 0000001CE714: D41B0013
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v188, vcc_lo             // 0000001CE718: 020378FF C2CE8ED0
	.long 0xd41e001b                                           // 0000001CE720: D41E001B
	v_cndmask_b32_e32 v1, 0x42b17218, v188, vcc_lo             // 0000001CE724: 020378FF 42B17218
	v_rndne_f32_e32 v203, v145                                 // 0000001CE72C: 7F964791
	v_mul_f32_e32 v198, 0x3fb8aa3b, v190                       // 0000001CE730: 118D7CFF 3FB8AA3B
	v_fmac_f32_e32 v206, 0x32a5705f, v140                      // 0000001CE738: 579D18FF 32A5705F
	v_fma_f32 v140, 0x3fb8aa3b, v141, -v150                    // 0000001CE740: D613008C 865B1AFF 3FB8AA3B
	v_fmac_f32_e32 v139, 0x32a5705f, v144                      // 0000001CE74C: 571720FF 32A5705F
	v_fma_f32 v144, 0x3fb8aa3b, v187, -v195                    // 0000001CE754: D6130090 870F76FF 3FB8AA3B
	v_fmac_f32_e32 v143, 0x32a5705f, v188                      // 0000001CE760: 571F78FF 32A5705F
	v_fma_f32 v188, 0x3fb8aa3b, v191, -v199                    // 0000001CE768: D61300BC 871F7EFF 3FB8AA3B
	.long 0xd41b000e                                           // 0000001CE774: D41B000E
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v141, vcc_lo             // 0000001CE778: 02031AFF C2CE8ED0
	.long 0xd41e0006                                           // 0000001CE780: D41E0006
	v_cndmask_b32_e32 v1, 0x42b17218, v141, vcc_lo             // 0000001CE784: 02031AFF 42B17218
	.long 0xd41b0012                                           // 0000001CE78C: D41B0012
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v187, vcc_lo             // 0000001CE790: 020376FF C2CE8ED0
	.long 0xd41b0016                                           // 0000001CE798: D41B0016
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v191, vcc_lo             // 0000001CE79C: 02037EFF C2CE8ED0
	.long 0xd41e001a                                           // 0000001CE7A4: D41E001A
	v_cndmask_b32_e32 v1, 0x42b17218, v187, vcc_lo             // 0000001CE7A8: 020376FF 42B17218
	.long 0xd41e001e                                           // 0000001CE7B0: D41E001E
	v_cndmask_b32_e32 v1, 0x42b17218, v191, vcc_lo             // 0000001CE7B4: 02037EFF 42B17218
	v_fmac_f32_e32 v188, 0x32a5705f, v191                      // 0000001CE7BC: 57797EFF 32A5705F
	v_fma_f32 v191, 0x3fb8aa3b, v193, -v201                    // 0000001CE7C4: D61300BF 872782FF 3FB8AA3B
	v_fmac_f32_e32 v144, 0x32a5705f, v187                      // 0000001CE7D0: 572176FF 32A5705F
	v_sub_f32_e32 v145, v145, v203                             // 0000001CE7D8: 09239791
	v_fma_f32 v187, 0x3fb8aa3b, v190, -v198                    // 0000001CE7DC: D61300BB 871B7CFF 3FB8AA3B
	v_fmac_f32_e32 v140, 0x32a5705f, v141                      // 0000001CE7E8: 57191AFF 32A5705F
	v_fma_f32 v141, 0x3fb8aa3b, v186, -v194                    // 0000001CE7F0: D613008D 870B74FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CE7FC: BF870004
	v_dual_mul_f32 v200, 0x3fb8aa3b, v192 :: v_dual_add_f32 v145, v145, v202// 0000001CE800: C8C980FF C8919591 3FB8AA3B
	.long 0xd41b0011                                           // 0000001CE80C: D41B0011
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v186, vcc_lo             // 0000001CE810: 020374FF C2CE8ED0
	.long 0xd41e0019                                           // 0000001CE818: D41E0019
	v_cndmask_b32_e32 v1, 0x42b17218, v186, vcc_lo             // 0000001CE81C: 020374FF 42B17218
	v_rndne_f32_e32 v207, v147                                 // 0000001CE824: 7F9E4793
	v_fmac_f32_e32 v141, 0x32a5705f, v186                      // 0000001CE828: 571B74FF 32A5705F
	v_fma_f32 v186, 0x3fb8aa3b, v189, -v197                    // 0000001CE830: D61300BA 87177AFF 3FB8AA3B
	.long 0xd41b0014                                           // 0000001CE83C: D41B0014
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v189, vcc_lo             // 0000001CE840: 02037AFF C2CE8ED0
	.long 0xd41e001c                                           // 0000001CE848: D41E001C
	v_cndmask_b32_e32 v1, 0x42b17218, v189, vcc_lo             // 0000001CE84C: 02037AFF 42B17218
	v_rndne_f32_e32 v205, v146                                 // 0000001CE854: 7F9A4792
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001CE858: BF870244
	v_dual_sub_f32 v147, v147, v207 :: v_dual_fmac_f32 v186, 0x32a5705f, v189// 0000001CE85C: C9419F93 93BB7AFF 32A5705F
	v_fma_f32 v189, 0x3fb8aa3b, v192, -v200                    // 0000001CE868: D61300BD 872380FF 3FB8AA3B
	.long 0xd41b0017                                           // 0000001CE874: D41B0017
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v192, vcc_lo             // 0000001CE878: 020380FF C2CE8ED0
	.long 0xd41e001f                                           // 0000001CE880: D41E001F
	v_cndmask_b32_e32 v1, 0x42b17218, v192, vcc_lo             // 0000001CE884: 020380FF 42B17218
	v_dual_sub_f32 v146, v146, v205 :: v_dual_add_f32 v147, v147, v206// 0000001CE88C: C9499B92 92939D93
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CE894: BF870004
	v_fmac_f32_e32 v189, 0x32a5705f, v192                      // 0000001CE898: 577B80FF 32A5705F
	v_rndne_f32_e32 v192, v149                                 // 0000001CE8A0: 7F804795
	v_rndne_f32_e32 v206, v194                                 // 0000001CE8A4: 7F9C47C2
	.long 0xd41b0015                                           // 0000001CE8A8: D41B0015
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v190, vcc_lo             // 0000001CE8AC: 02037CFF C2CE8ED0
	.long 0xd41b0018                                           // 0000001CE8B4: D41B0018
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v193, vcc_lo             // 0000001CE8B8: 020382FF C2CE8ED0
	.long 0xd41e001d                                           // 0000001CE8C0: D41E001D
	v_cndmask_b32_e32 v1, 0x42b17218, v190, vcc_lo             // 0000001CE8C4: 02037CFF 42B17218
	.long 0xd41e0021                                           // 0000001CE8CC: D41E0021
	v_cndmask_b32_e32 v1, 0x42b17218, v193, vcc_lo             // 0000001CE8D0: 020382FF 42B17218
	v_fmac_f32_e32 v187, 0x32a5705f, v190                      // 0000001CE8D8: 57777CFF 32A5705F
	v_rndne_f32_e32 v190, v148                                 // 0000001CE8E0: 7F7C4794
	v_fmac_f32_e32 v191, 0x32a5705f, v193                      // 0000001CE8E4: 577F82FF 32A5705F
	v_rndne_f32_e32 v193, v150                                 // 0000001CE8EC: 7F824796
	v_rndne_f32_e32 v202, v151                                 // 0000001CE8F0: 7F944797
	v_sub_f32_e32 v149, v149, v192                             // 0000001CE8F4: 092B8195
	v_add_f32_e32 v146, v146, v204                             // 0000001CE8F8: 07259992
	v_rndne_f32_e32 v204, v152                                 // 0000001CE8FC: 7F984798
	v_sub_f32_e32 v194, v194, v206                             // 0000001CE900: 09859DC2
	v_dual_sub_f32 v150, v150, v193 :: v_dual_sub_f32 v151, v151, v202// 0000001CE904: C94B8396 96979597
	v_sub_f32_e32 v148, v148, v190                             // 0000001CE90C: 09297D94
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CE910: BF870003
	v_dual_sub_f32 v152, v152, v204 :: v_dual_add_f32 v141, v194, v141// 0000001CE914: C9499998 988D1BC2
	v_rndne_f32_e32 v194, v200                                 // 0000001CE91C: 7F8447C8
	v_add_f32_e32 v137, v149, v137                             // 0000001CE920: 07131395
	v_rndne_f32_e32 v149, v196                                 // 0000001CE924: 7F2A47C4
	v_dual_add_f32 v139, v151, v139 :: v_dual_add_f32 v138, v148, v138// 0000001CE928: C9091797 8B8B1594
	v_rndne_f32_e32 v148, v195                                 // 0000001CE930: 7F2847C3
	v_rndne_f32_e32 v151, v198                                 // 0000001CE934: 7F2E47C6
	v_sub_f32_e32 v200, v200, v194                             // 0000001CE938: 099185C8
	v_add_f32_e32 v140, v150, v140                             // 0000001CE93C: 07191996
	v_rndne_f32_e32 v150, v197                                 // 0000001CE940: 7F2C47C5
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CE944: BF870214
	v_dual_sub_f32 v195, v195, v148 :: v_dual_sub_f32 v198, v198, v151// 0000001CE948: C94B29C3 C3C72FC6
	v_add_f32_e32 v189, v200, v189                             // 0000001CE950: 077B7BC8
	v_sub_f32_e32 v196, v196, v149                             // 0000001CE954: 09892BC4
	v_cvt_i32_f32_e32 v149, v149                               // 0000001CE958: 7F2A1195
	v_sub_f32_e32 v197, v197, v150                             // 0000001CE95C: 098B2DC5
	v_dual_add_f32 v187, v198, v187 :: v_dual_add_f32 v144, v195, v144// 0000001CE960: C90977C6 BB9121C3
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CE968: BF870004
	v_add_f32_e32 v143, v196, v143                             // 0000001CE96C: 071F1FC4
	v_rndne_f32_e32 v195, v201                                 // 0000001CE970: 7F8647C9
	v_add_f32_e32 v142, v152, v142                             // 0000001CE974: 071D1D98
	v_rndne_f32_e32 v152, v199                                 // 0000001CE978: 7F3047C7
	v_exp_f32_e32 v187, v187                                   // 0000001CE97C: 7F764BBB
	v_exp_f32_e32 v143, v143                                   // 0000001CE980: 7F1E4B8F
	v_exp_f32_e32 v189, v189                                   // 0000001CE984: 7F7A4BBD
	v_cvt_i32_f32_e32 v151, v151                               // 0000001CE988: 7F2E1197
	v_sub_f32_e32 v199, v199, v152                             // 0000001CE98C: 098F31C7
	v_sub_f32_e32 v201, v201, v195                             // 0000001CE990: 099387C9
	v_cvt_i32_f32_e32 v194, v194                               // 0000001CE994: 7F8411C2
	v_exp_f32_e32 v145, v145                                   // 0000001CE998: 7F224B91
	v_cvt_i32_f32_e32 v203, v203                               // 0000001CE99C: 7F9611CB
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_3)// 0000001CE9A0: BF870393
	v_dual_add_f32 v188, v199, v188 :: v_dual_add_f32 v191, v201, v191// 0000001CE9A4: C90979C7 BCBF7FC9
	.long 0xd71c008f                                           // 0000001CE9AC: D71C008F
	v_cndmask_b32_e32 v1, v143, v149, vcc_lo                   // 0000001CE9B0: 02032B8F
	.long 0xd71c0095                                           // 0000001CE9B4: D71C0095
	v_cndmask_b32_e32 v1, v187, v151, vcc_lo                   // 0000001CE9B8: 02032FBB
	.long 0xd71c0097                                           // 0000001CE9BC: D71C0097
	v_cndmask_b32_e32 v1, v189, v194, vcc_lo                   // 0000001CE9C0: 020385BD
	v_exp_f32_e32 v146, v146                                   // 0000001CE9C4: 7F244B92
	v_exp_f32_e32 v147, v147                                   // 0000001CE9C8: 7F264B93
	v_cndmask_b32_e64 v143, 0, v143, s19                       // 0000001CE9CC: D501008F 004F1E80
	v_exp_f32_e32 v137, v137                                   // 0000001CE9D4: 7F124B89
	v_exp_f32_e32 v144, v144                                   // 0000001CE9D8: 7F204B90
	v_exp_f32_e32 v188, v188                                   // 0000001CE9DC: 7F784BBC
	v_exp_f32_e32 v191, v191                                   // 0000001CE9E0: 7F7E4BBF
	v_cndmask_b32_e64 v189, 0x7f800000, v143, s27              // 0000001CE9E4: D50100BD 006F1EFF 7F800000
	v_add_f32_e32 v186, v197, v186                             // 0000001CE9F0: 077575C5
	v_cvt_i32_f32_e32 v205, v205                               // 0000001CE9F4: 7F9A11CD
	v_cvt_i32_f32_e32 v207, v207                               // 0000001CE9F8: 7F9E11CF
	v_cvt_i32_f32_e32 v192, v192                               // 0000001CE9FC: 7F8011C0
	v_mul_f32_e32 v59, v59, v189                               // 0000001CEA00: 10777B3B
	v_exp_f32_e32 v186, v186                                   // 0000001CEA04: 7F744BBA
	v_cvt_i32_f32_e32 v148, v148                               // 0000001CEA08: 7F281194
	v_cvt_i32_f32_e32 v150, v150                               // 0000001CEA0C: 7F2C1196
	v_cvt_i32_f32_e32 v152, v152                               // 0000001CEA10: 7F301198
	v_cvt_i32_f32_e32 v195, v195                               // 0000001CEA14: 7F8611C3
	v_exp_f32_e32 v138, v138                                   // 0000001CEA18: 7F144B8A
	v_exp_f32_e32 v141, v141                                   // 0000001CEA1C: 7F1A4B8D
	.long 0xd71c0091                                           // 0000001CEA20: D71C0091
	v_cndmask_b32_e32 v1, v145, v203, vcc_lo                   // 0000001CEA24: 02039791
	v_exp_f32_e32 v140, v140                                   // 0000001CEA28: 7F184B8C
	v_exp_f32_e32 v142, v142                                   // 0000001CEA2C: 7F1C4B8E
	v_cvt_i32_f32_e32 v190, v190                               // 0000001CEA30: 7F7C11BE
	v_cvt_i32_f32_e32 v206, v206                               // 0000001CEA34: 7F9C11CE
	v_exp_f32_e32 v139, v139                                   // 0000001CEA38: 7F164B8B
	.long 0xd71c0092                                           // 0000001CEA3C: D71C0092
	v_cndmask_b32_e32 v1, v146, v205, vcc_lo                   // 0000001CEA40: 02039B92
	.long 0xd71c0093                                           // 0000001CEA44: D71C0093
	v_cndmask_b32_e32 v1, v147, v207, vcc_lo                   // 0000001CEA48: 02039F93
	.long 0xd71c0089                                           // 0000001CEA4C: D71C0089
	v_cndmask_b32_e32 v1, v137, v192, vcc_lo                   // 0000001CEA50: 02038189
	.long 0xd71c0090                                           // 0000001CEA54: D71C0090
	v_cndmask_b32_e32 v1, v144, v148, vcc_lo                   // 0000001CEA58: 02032990
	.long 0xd71c0094                                           // 0000001CEA5C: D71C0094
	v_cndmask_b32_e32 v1, v186, v150, vcc_lo                   // 0000001CEA60: 02032DBA
	.long 0xd71c0096                                           // 0000001CEA64: D71C0096
	v_cndmask_b32_e32 v1, v188, v152, vcc_lo                   // 0000001CEA68: 020331BC
	.long 0xd71c0098                                           // 0000001CEA6C: D71C0098
	v_cndmask_b32_e32 v1, v191, v195, vcc_lo                   // 0000001CEA70: 020387BF
	v_cndmask_b32_e64 v145, 0, v145, s9                        // 0000001CEA74: D5010091 00272280
	v_cvt_i32_f32_e32 v193, v193                               // 0000001CEA7C: 7F8211C1
	v_cvt_i32_f32_e32 v204, v204                               // 0000001CEA80: 7F9811CC
	v_cvt_i32_f32_e32 v202, v202                               // 0000001CEA84: 7F9411CA
	.long 0xd71c008a                                           // 0000001CEA88: D71C008A
	v_cndmask_b32_e32 v1, v138, v190, vcc_lo                   // 0000001CEA8C: 02037D8A
	.long 0xd71c008d                                           // 0000001CEA90: D71C008D
	v_cndmask_b32_e32 v1, v141, v206, vcc_lo                   // 0000001CEA94: 02039D8D
	v_cndmask_b32_e64 v146, 0, v146, s10                       // 0000001CEA98: D5010092 002B2480
	v_cndmask_b32_e64 v147, 0, v147, s11                       // 0000001CEAA0: D5010093 002F2680
	v_cndmask_b32_e64 v187, 0, v137, s13                       // 0000001CEAA8: D50100BB 00371280
	v_cndmask_b32_e64 v152, 0, v152, s24                       // 0000001CEAB0: D5010098 00633080
	v_cndmask_b32_e64 v137, 0x7f800000, v145, s0               // 0000001CEAB8: D5010089 000322FF 7F800000
	.long 0xd71c008c                                           // 0000001CEAC4: D71C008C
	v_cndmask_b32_e32 v1, v140, v193, vcc_lo                   // 0000001CEAC8: 0203838C
	.long 0xd71c008e                                           // 0000001CEACC: D71C008E
	v_cndmask_b32_e32 v1, v142, v204, vcc_lo                   // 0000001CEAD0: 0203998E
	.long 0xd71c008b                                           // 0000001CEAD4: D71C008B
	v_cndmask_b32_e32 v1, v139, v202, vcc_lo                   // 0000001CEAD8: 0203958B
	v_cndmask_b32_e64 v186, 0, v138, s12                       // 0000001CEADC: D50100BA 00331480
	v_cndmask_b32_e64 v141, 0, v141, s17                       // 0000001CEAE4: D501008D 00471A80
	v_cndmask_b32_e64 v148, 0, v148, s20                       // 0000001CEAEC: D5010094 00532880
	v_cndmask_b32_e64 v145, 0x7f800000, v146, s1               // 0000001CEAF4: D5010091 000724FF 7F800000
	v_cndmask_b32_e64 v138, 0x7f800000, v147, s3               // 0000001CEB00: D501008A 000F26FF 7F800000
	v_cndmask_b32_e64 v152, 0x7f800000, v152, s33              // 0000001CEB0C: D5010098 008730FF 7F800000
	.long 0xd59c08b5                                           // 0000001CEB18: D59C08B5
	v_cndmask_b32_e32 v0, v137, v128, vcc_lo                   // 0000001CEB1C: 02010189
	v_cndmask_b32_e64 v140, 0, v140, s14                       // 0000001CEB20: D501008C 003B1880
	v_cndmask_b32_e64 v142, 0, v142, s16                       // 0000001CEB28: D501008E 00431C80
	v_cndmask_b32_e64 v188, 0, v139, s15                       // 0000001CEB30: D50100BC 003F1680
	v_cndmask_b32_e64 v150, 0, v150, s22                       // 0000001CEB38: D5010096 005B2C80
	v_cndmask_b32_e64 v146, 0x7f800000, v186, s4               // 0000001CEB40: D5010092 001374FF 7F800000
	v_cndmask_b32_e64 v139, 0x7f800000, v187, s5               // 0000001CEB4C: D501008B 001776FF 7F800000
	v_cndmask_b32_e64 v187, 0x7f800000, v141, s25              // 0000001CEB58: D50100BB 00671AFF 7F800000
	v_cndmask_b32_e64 v148, 0x7f800000, v148, s28              // 0000001CEB64: D5010094 007328FF 7F800000
	.long 0xd59c08b6                                           // 0000001CEB70: D59C08B6
	v_cndmask_b32_e32 v0, v145, v128, vcc_lo                   // 0000001CEB74: 02010191
	v_dual_mul_f32 v56, v56, v152 :: v_dual_and_b32 v141, 1, v181// 0000001CEB78: C8E53138 388D6A81
	.long 0xd59c08b5                                           // 0000001CEB80: D59C08B5
	v_cndmask_b32_e32 v0, v138, v128, vcc_lo                   // 0000001CEB84: 0201018A
	v_cndmask_b32_e64 v140, 0x7f800000, v140, s6               // 0000001CEB88: D501008C 001B18FF 7F800000
	v_cndmask_b32_e64 v142, 0x7f800000, v142, s8               // 0000001CEB94: D501008E 00231CFF 7F800000
	v_cndmask_b32_e64 v144, 0, v144, s18                       // 0000001CEBA0: D5010090 004B2080
	v_cndmask_b32_e64 v149, 0, v149, s21                       // 0000001CEBA8: D5010095 00572A80
	v_cndmask_b32_e64 v186, 0x7f800000, v188, s7               // 0000001CEBB0: D50100BA 001F78FF 7F800000
	v_cndmask_b32_e64 v150, 0x7f800000, v150, s30              // 0000001CEBBC: D5010096 007B2CFF 7F800000
	.long 0xd59c08b7                                           // 0000001CEBC8: D59C08B7
	v_cndmask_b32_e32 v0, v146, v128, vcc_lo                   // 0000001CEBCC: 02010192
	v_dual_mul_f32 v44, v44, v148 :: v_dual_and_b32 v143, 1, v182// 0000001CEBD0: C8E5292C 2C8F6C81
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CEBD8: BF870003
	v_dual_mul_f32 v46, v46, v150 :: v_dual_and_b32 v147, 1, v181// 0000001CEBDC: C8E52D2E 2E936A81
	.long 0xd59c08b5                                           // 0000001CEBE4: D59C08B5
	v_cndmask_b32_e32 v0, v139, v128, vcc_lo                   // 0000001CEBE8: 0201018B
	v_cndmask_b32_e64 v151, 0, v151, s23                       // 0000001CEBEC: D5010097 005F2E80
	.long 0xd59c08b8                                           // 0000001CEBF4: D59C08B8
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                   // 0000001CEBF8: 0201018C
	.long 0xd59c08b9                                           // 0000001CEBFC: D59C08B9
	v_cndmask_b32_e32 v0, v142, v128, vcc_lo                   // 0000001CEC00: 0201018E
	v_cndmask_b32_e64 v188, 0x7f800000, v144, s26              // 0000001CEC04: D50100BC 006B20FF 7F800000
	v_cndmask_b32_e64 v149, 0x7f800000, v149, s29              // 0000001CEC10: D5010095 00772AFF 7F800000
	v_fma_f32 v153, v153, v187, v145                           // 0000001CEC1C: D6130099 06477799
	v_and_b32_e32 v144, 1, v183                                // 0000001CEC24: 37216E81
	v_add3_u32 v143, v145, v143, 0x7fff                        // 0000001CEC28: D655008F 03FF1F91 00007FFF
	v_dual_mul_f32 v34, v34, v188 :: v_dual_and_b32 v145, 1, v181// 0000001CEC34: C8E57922 22916A81
	.long 0xd59c08b5                                           // 0000001CEC3C: D59C08B5
	v_cndmask_b32_e32 v0, v186, v128, vcc_lo                   // 0000001CEC40: 020101BA
	v_cndmask_b32_e64 v151, 0x7f800000, v151, s31              // 0000001CEC44: D5010097 007F2EFF 7F800000
	v_and_b32_e32 v182, 1, v184                                // 0000001CEC50: 376D7081
	v_dual_mul_f32 v48, v48, v152 :: v_dual_and_b32 v183, 1, v185// 0000001CEC54: C8E53130 30B77281
	v_fma_f32 v155, v155, v189, v146                           // 0000001CEC5C: D613009B 064B7B9B
	v_add3_u32 v141, v137, v141, 0x7fff                        // 0000001CEC64: D655008D 03FF1B89 00007FFF
	v_mul_f32_e32 v45, v45, v149                               // 0000001CEC70: 105B2B2D
	v_add3_u32 v144, v146, v144, 0x7fff                        // 0000001CEC74: D6550090 03FF2192 00007FFF
	v_add3_u32 v146, v138, v147, 0x7fff                        // 0000001CEC80: D6550092 03FF278A 00007FFF
	v_dual_mul_f32 v36, v36, v148 :: v_dual_and_b32 v147, 1, v181// 0000001CEC8C: C8E52924 24936A81
	v_fma_f32 v154, v154, v149, v140                           // 0000001CEC94: D613009A 06332B9A
	v_mul_f32_e32 v47, v47, v151                               // 0000001CEC9C: 105F2F2F
	v_add3_u32 v140, v140, v182, 0x7fff                        // 0000001CECA0: D655008C 03FF6D8C 00007FFF
	v_fma_f32 v175, v175, v151, v142                           // 0000001CECAC: D61300AF 063B2FAF
	v_add3_u32 v142, v142, v183, 0x7fff                        // 0000001CECB4: D655008E 03FF6F8E 00007FFF
	ds_store_b16_d16_hi v163, v143                             // 0000001CECC0: DA840000 00008FA3
	ds_store_b16_d16_hi v163, v141 offset:64                   // 0000001CECC8: DA840040 00008DA3
	ds_store_b16_d16_hi v163, v144 offset:128                  // 0000001CECD0: DA840080 000090A3
	v_add3_u32 v141, v139, v145, 0x7fff                        // 0000001CECD8: D655008D 03FF238B 00007FFF
	v_add3_u32 v143, v186, v147, 0x7fff                        // 0000001CECE4: D655008F 03FF27BA 00007FFF
	ds_store_b16_d16_hi v163, v140 offset:256                  // 0000001CECF0: DA840100 00008CA3
	ds_store_b16_d16_hi v163, v142 offset:384                  // 0000001CECF8: DA840180 00008EA3
	ds_store_b16_d16_hi v163, v146 offset:192                  // 0000001CED00: DA8400C0 000092A3
	ds_store_b16_d16_hi v163, v141 offset:320                  // 0000001CED08: DA840140 00008DA3
	ds_store_b16_d16_hi v163, v143 offset:448                  // 0000001CED10: DA8401C0 00008FA3
	ds_load_b128 v[140:143], v164                              // 0000001CED18: DBFC0000 8C0000A4
	ds_load_b128 v[144:147], v164 offset:16                    // 0000001CED20: DBFC0010 900000A4
	v_dual_mul_f32 v57, v57, v187 :: v_dual_mul_f32 v58, v58, v188// 0000001CED28: C8C77739 393B793A
	v_dual_mul_f32 v61, v61, v149 :: v_dual_mul_f32 v60, v60, v148// 0000001CED30: C8C72B3D 3D3D293C
	v_dual_mul_f32 v63, v63, v151 :: v_dual_mul_f32 v62, v62, v150// 0000001CED38: C8C72F3F 3F3F2D3E
	v_dual_mul_f32 v49, v49, v187 :: v_dual_mul_f32 v64, v64, v152// 0000001CED40: C8C77731 31413140
	v_dual_mul_f32 v51, v51, v189 :: v_dual_mul_f32 v50, v50, v188// 0000001CED48: C8C77B33 33337932
	v_dual_mul_f32 v53, v53, v149 :: v_dual_mul_f32 v52, v52, v148// 0000001CED50: C8C72B35 35352934
	v_dual_mul_f32 v55, v55, v151 :: v_dual_mul_f32 v54, v54, v150// 0000001CED58: C8C72F37 37372D36
	v_dual_mul_f32 v41, v41, v187 :: v_dual_mul_f32 v42, v42, v188// 0000001CED60: C8C77729 292B792A
	v_mul_f32_e32 v43, v43, v189                               // 0000001CED68: 10577B2B
	v_dual_mul_f32 v33, v33, v187 :: v_dual_mul_f32 v38, v38, v150// 0000001CED6C: C8C77721 21272D26
	v_dual_mul_f32 v35, v35, v189 :: v_dual_mul_f32 v40, v40, v152// 0000001CED74: C8C77B23 23293128
	v_dual_mul_f32 v37, v37, v149 :: v_dual_mul_f32 v26, v26, v188// 0000001CED7C: C8C72B25 251B791A
	v_dual_mul_f32 v39, v39, v151 :: v_dual_mul_f32 v28, v28, v148// 0000001CED84: C8C72F27 271D291C
	v_dual_mul_f32 v25, v25, v187 :: v_dual_mul_f32 v30, v30, v150// 0000001CED8C: C8C77719 191F2D1E
	v_dual_mul_f32 v27, v27, v189 :: v_dual_mul_f32 v32, v32, v152// 0000001CED94: C8C77B1B 1B213120
	v_dual_mul_f32 v29, v29, v149 :: v_dual_mul_f32 v18, v18, v188// 0000001CED9C: C8C72B1D 1D137912
	v_dual_mul_f32 v31, v31, v151 :: v_dual_mul_f32 v20, v20, v148// 0000001CEDA4: C8C72F1F 1F152914
	v_dual_mul_f32 v17, v17, v187 :: v_dual_mul_f32 v22, v22, v150// 0000001CEDAC: C8C77711 11172D16
	v_dual_mul_f32 v19, v19, v189 :: v_dual_mul_f32 v24, v24, v152// 0000001CEDB4: C8C77B13 13193118
	v_dual_mul_f32 v21, v21, v149 :: v_dual_mul_f32 v10, v10, v188// 0000001CEDBC: C8C72B15 150B790A
	v_dual_mul_f32 v23, v23, v151 :: v_dual_mul_f32 v12, v12, v148// 0000001CEDC4: C8C72F17 170D290C
	v_dual_mul_f32 v9, v9, v187 :: v_dual_mul_f32 v14, v14, v150// 0000001CEDCC: C8C77709 090F2D0E
	v_dual_mul_f32 v11, v11, v189 :: v_dual_mul_f32 v16, v16, v152// 0000001CEDD4: C8C77B0B 0B113110
	v_dual_mul_f32 v13, v13, v149 :: v_dual_mul_f32 v2, v2, v188// 0000001CEDDC: C8C72B0D 0D037902
	v_dual_mul_f32 v15, v15, v151 :: v_dual_mul_f32 v4, v4, v148// 0000001CEDE4: C8C72F0F 0F052904
	v_dual_mul_f32 v1, v1, v187 :: v_dual_mul_f32 v6, v6, v150 // 0000001CEDEC: C8C77701 01072D06
	v_dual_mul_f32 v3, v3, v189 :: v_dual_fmac_f32 v186, v177, v152// 0000001CEDF4: C8C17B03 03BB31B1
	v_dual_mul_f32 v5, v5, v149 :: v_dual_mul_f32 v8, v8, v152 // 0000001CEDFC: C8C72B05 05093108
	v_mul_f32_e32 v7, v7, v151                                 // 0000001CEE04: 100F2F07
	v_fmac_f32_e32 v137, v180, v188                            // 0000001CEE08: 571379B4
	v_dual_fmac_f32 v138, v179, v148 :: v_dual_fmac_f32 v139, v178, v150// 0000001CEE0C: C80129B3 8A8B2DB2
	v_mov_b32_e32 v177, v186                                   // 0000001CEE14: 7F6203BA
	s_waitcnt vmcnt(19) lgkmcnt(0)                             // 0000001CEE18: BF894C07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[140:147], v[73:80], v[57:64]// 0000001CEE1C: CC414039 1CE6938C
	s_waitcnt vmcnt(18)                                        // 0000001CEE24: BF894BF7
	v_wmma_f32_16x16x16_bf16 v[49:56], v[140:147], v[81:88], v[49:56]// 0000001CEE28: CC414031 1CC6A38C
	s_waitcnt vmcnt(17)                                        // 0000001CEE30: BF8947F7
	v_wmma_f32_16x16x16_bf16 v[41:48], v[140:147], v[89:96], v[41:48]// 0000001CEE34: CC414029 1CA6B38C
	s_waitcnt vmcnt(16)                                        // 0000001CEE3C: BF8943F7
	v_wmma_f32_16x16x16_bf16 v[33:40], v[140:147], v[97:104], v[33:40]// 0000001CEE40: CC414021 1C86C38C
	s_waitcnt vmcnt(3)                                         // 0000001CEE48: BF890FF7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[140:147], v[105:112], v[25:32]// 0000001CEE4C: CC414019 1C66D38C
	s_waitcnt vmcnt(2)                                         // 0000001CEE54: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[17:24], v[140:147], v[113:120], v[17:24]// 0000001CEE58: CC414011 1C46E38C
	s_waitcnt vmcnt(1)                                         // 0000001CEE60: BF8907F7
	v_wmma_f32_16x16x16_bf16 v[9:16], v[140:147], v[121:128], v[9:16]// 0000001CEE64: CC414009 1C26F38C
	s_waitcnt vmcnt(0)                                         // 0000001CEE6C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[1:8], v[140:147], v[129:136], v[1:8]// 0000001CEE70: CC414001 1C07038C
	s_barrier                                                  // 0000001CEE78: BFBD0000
	s_cbranch_scc0 51                                          // 0000001CEE7C: BFA10033 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi11EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x164c>
	s_mov_b32 s0, s35                                          // 0000001CEE80: BE800023
	s_add_i32 s35, s35, 4                                      // 0000001CEE84: 81238423
	v_dual_mov_b32 v178, v139 :: v_dual_mov_b32 v179, v138     // 0000001CEE88: CA10018B B2B2018A
	s_min_i32 s4, s35, s55                                     // 0000001CEE90: 89043723
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001CEE94: BF870499
	s_ashr_i32 s5, s4, 31                                      // 0000001CEE98: 86059F04
	s_lshl_b64 s[4:5], s[4:5], 2                               // 0000001CEE9C: 84848204
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001CEEA0: BF870009
	s_add_u32 s6, s46, s4                                      // 0000001CEEA4: 8006042E
	s_addc_u32 s7, s47, s5                                     // 0000001CEEA8: 8207052F
	s_cmp_lt_i32 s0, s36                                       // 0000001CEEAC: BF042400
	s_load_b128 s[8:11], s[6:7], null                          // 0000001CEEB0: F4080203 F8000000
	s_cselect_b32 s1, s53, s54                                 // 0000001CEEB8: 98013635
	s_cmp_lt_i32 s0, s52                                       // 0000001CEEBC: BF043400
	s_waitcnt lgkmcnt(0)                                       // 0000001CEEC0: BF89FC07
	s_cselect_b32 s4, s48, s1                                  // 0000001CEEC4: 98040130
	s_add_i32 s1, s0, 1                                        // 0000001CEEC8: 81018100
	v_dual_mov_b32 v180, v137 :: v_dual_mov_b32 v73, s4        // 0000001CEECC: CA100189 B4480004
	s_cmp_lt_i32 s1, s36                                       // 0000001CEED4: BF042401
	s_cselect_b32 s3, s53, s54                                 // 0000001CEED8: 98033635
	s_cmp_lt_i32 s1, s52                                       // 0000001CEEDC: BF043401
	s_cselect_b32 s6, s49, s3                                  // 0000001CEEE0: 98060331
	s_add_i32 s1, s0, 2                                        // 0000001CEEE4: 81018200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001CEEE8: BF8704D9
	s_cmp_lt_i32 s1, s36                                       // 0000001CEEEC: BF042401
	s_cselect_b32 s3, s53, s54                                 // 0000001CEEF0: 98033635
	s_cmp_lt_i32 s1, s52                                       // 0000001CEEF4: BF043401
	s_cselect_b32 s12, s50, s3                                 // 0000001CEEF8: 980C0332
	s_add_i32 s1, s0, 3                                        // 0000001CEEFC: 81018300
	s_cmp_lt_i32 s1, s36                                       // 0000001CEF00: BF042401
	s_cselect_b32 s3, s53, s54                                 // 0000001CEF04: 98033635
	s_cmp_lt_i32 s1, s52                                       // 0000001CEF08: BF043401
	s_mov_b32 s1, exec_lo                                      // 0000001CEF0C: BE81007E
	s_cselect_b32 s14, s51, s3                                 // 0000001CEF10: 980E0333
	v_cmpx_lt_i32_e32 0, v159                                  // 0000001CEF14: 7D833E80
	s_cbranch_execz 64468                                      // 0000001CEF18: BFA5FBD4 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi11EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x56c>
	.long 0xd44d0000                                           // 0000001CEF1C: D44D0000
	v_cndmask_b32_e32 v1, 1, v159, vcc_lo                      // 0000001CEF20: 02033E81
	s_and_saveexec_b32 s3, s0                                  // 0000001CEF24: BE832000
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001CEF28: BF870009
	s_xor_b32 s0, exec_lo, s3                                  // 0000001CEF2C: 8D00037E
	v_mov_b32_e32 v73, s12                                     // 0000001CEF30: 7E92020C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CEF34: BF870001
	v_cndmask_b32_e32 v73, s14, v73, vcc_lo                    // 0000001CEF38: 0292920E
	s_and_not1_saveexec_b32 s0, s0                             // 0000001CEF3C: BE803000
	s_cbranch_execz 64457                                      // 0000001CEF40: BFA5FBC9 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi11EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x568>
	v_mov_b32_e32 v73, s6                                      // 0000001CEF44: 7E920206
	s_branch 64455                                             // 0000001CEF48: BFA0FBC7 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi11EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x568>
	v_mov_b32_e32 v8, v158                                     // 0000001CEF4C: 7E10039E
	s_mul_i32 s0, s34, 12                                      // 0000001CEF50: 96008C22
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CEF54: BF870001
	v_or_b32_e32 v7, v8, v156                                  // 0000001CEF58: 380F3908
	v_or_b32_e32 v0, s0, v157                                  // 0000001CEF5C: 38013A00
	v_mov_b32_dpp v78, v139 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CEF60: 7E9C02FA FF09618B
	v_mov_b32_dpp v75, v138 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CEF68: 7E9602FA FF09618A
	v_mov_b32_dpp v74, v155 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CEF70: 7E9402FA FF09619B
	v_mov_b32_dpp v76, v154 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CEF78: 7E9802FA FF09619A
	v_lshlrev_b32_e32 v0, 8, v0                                // 0000001CEF80: 30000088
	v_mov_b32_e32 v8, 0                                        // 0000001CEF84: 7E100280
	v_dual_add_f32 v78, v139, v78 :: v_dual_add_f32 v81, v138, v75// 0000001CEF88: C9089D8B 4E50978A
	v_add_f32_e32 v83, v155, v74                               // 0000001CEF90: 06A6959B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CEF94: BF870214
	v_add_nc_u32_e32 v23, 0x400, v0                            // 0000001CEF98: 4A2E00FF 00000400
	v_mad_i64_i32 v[7:8], null, 0x1800, s2, v[7:8]             // 0000001CEFA0: D6FF7C07 041C04FF 00001800
	v_ashrrev_i32_e32 v16, 31, v0                              // 0000001CEFAC: 3420009F
	v_add_nc_u32_e32 v31, 0x600, v0                            // 0000001CEFB0: 4A3E00FF 00000600
	v_add_nc_u32_e32 v39, 0x800, v0                            // 0000001CEFB8: 4A4E00FF 00000800
	v_ashrrev_i32_e32 v24, 31, v23                             // 0000001CEFC0: 34302E9F
	v_or_b32_e32 v65, 0x200, v0                                // 0000001CEFC4: 388200FF 00000200
	v_add_f32_dpp v81, v81, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CEFCC: 06A2A2FA FF096251
	v_ashrrev_i32_e32 v32, 31, v31                             // 0000001CEFD4: 34403E9F
	.long 0xd7006a0f                                           // 0000001CEFD8: D7006A0F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000001CEFDC: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CEFE0: BF8700A1
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 0000001CEFE4: D5207C10 01AA2108
	.long 0xd7006a17                                           // 0000001CEFEC: D7006A17
	v_cndmask_b32_e32 v1, v7, v23, vcc_lo                      // 0000001CEFF0: 02022F07
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 0000001CEFF4: D5207C18 01AA3108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CEFFC: BF870233
	.long 0xd73c000f                                           // 0000001CF000: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000001CF004: 02021E81
	v_add_nc_u32_e32 v0, 0xa00, v0                             // 0000001CF008: 4A0000FF 00000A00
	v_ashrrev_i32_e32 v40, 31, v39                             // 0000001CF010: 34504E9F
	.long 0xd73c0017                                           // 0000001CF014: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000001CF018: 02022E81
	v_ashrrev_i32_e32 v66, 31, v65                             // 0000001CF01C: 3484829F
	v_add_f32_dpp v78, v78, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF020: 069C9CFA FF09624E
	.long 0xd7006a45                                           // 0000001CF028: D7006A45
	v_cndmask_b32_e32 v1, s42, v15, vcc_lo                     // 0000001CF02C: 02021E2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CF030: BF8700A1
	v_add_co_ci_u32_e64 v70, null, s43, v16, vcc_lo            // 0000001CF034: D5207C46 01AA202B
	.long 0xd7006a1f                                           // 0000001CF03C: D7006A1F
	v_cndmask_b32_e32 v1, v7, v31, vcc_lo                      // 0000001CF040: 02023F07
	v_add_co_ci_u32_e64 v32, null, v8, v32, vcc_lo             // 0000001CF044: D5207C20 01AA4108
	.long 0xd7006a37                                           // 0000001CF04C: D7006A37
	v_cndmask_b32_e32 v1, s42, v23, vcc_lo                     // 0000001CF050: 02022E2A
	v_ashrrev_i32_e32 v48, 31, v0                              // 0000001CF054: 3460009F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001CF058: BF8700B3
	.long 0xd73c001f                                           // 0000001CF05C: D73C001F
	v_cndmask_b32_e32 v1, 1, v31, vcc_lo                       // 0000001CF060: 02023E81
	v_add_co_ci_u32_e64 v56, null, s43, v24, vcc_lo            // 0000001CF064: D5207C38 01AA302B
	.long 0xd7006a27                                           // 0000001CF06C: D7006A27
	v_cndmask_b32_e32 v1, v7, v39, vcc_lo                      // 0000001CF070: 02024F07
	v_add_co_ci_u32_e64 v40, null, v8, v40, vcc_lo             // 0000001CF074: D5207C28 01AA5108
	.long 0xd7006a2f                                           // 0000001CF07C: D7006A2F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000001CF080: 02020107
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CF084: BF870001
	v_add_co_ci_u32_e64 v48, null, v8, v48, vcc_lo             // 0000001CF088: D5207C30 01AA6108
	.long 0xd7006a3f                                           // 0000001CF090: D7006A3F
	v_cndmask_b32_e32 v1, s42, v31, vcc_lo                     // 0000001CF094: 02023E2A
	global_load_u16 v73, v[69:70], off offset:1024             // 0000001CF098: DC4A0400 497C0045
	v_add_co_ci_u32_e64 v64, null, s43, v32, vcc_lo            // 0000001CF0A0: D5207C40 01AA402B
	.long 0xd7006a07                                           // 0000001CF0A8: D7006A07
	v_cndmask_b32_e32 v1, v7, v65, vcc_lo                      // 0000001CF0AC: 02028307
	s_clause 0x2                                               // 0000001CF0B0: BF850002
	global_load_u16 v80, v[69:70], off                         // 0000001CF0B4: DC4A0000 507C0045
	global_load_u16 v82, v[69:70], off offset:32               // 0000001CF0BC: DC4A0020 527C0045
	global_load_u16 v103, v[69:70], off offset:64              // 0000001CF0C4: DC4A0040 677C0045
	v_add_co_ci_u32_e64 v8, null, v8, v66, vcc_lo              // 0000001CF0CC: D5207C08 01AA8508
	.long 0xd73c0027                                           // 0000001CF0D4: D73C0027
	v_cndmask_b32_e32 v1, 1, v39, vcc_lo                       // 0000001CF0D8: 02024E81
	.long 0xd73c002f                                           // 0000001CF0DC: D73C002F
	v_cndmask_b32_e32 v1, 1, v47, vcc_lo                       // 0000001CF0E0: 02025E81
	v_add_f32_dpp v83, v83, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF0E4: 06A6A6FA FF096253
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001CF0EC: BF8700C4
	.long 0xd73c0056                                           // 0000001CF0F0: D73C0056
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000001CF0F4: 02020E81
	v_mov_b32_dpp v8, v137 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF0F8: 7E1002FA FF096189
	v_mov_b32_dpp v7, v153 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF100: 7E0E02FA FF096199
	.long 0xd7006a43                                           // 0000001CF108: D7006A43
	v_cndmask_b32_e32 v1, s42, v39, vcc_lo                     // 0000001CF10C: 02024E2A
	v_add_co_ci_u32_e64 v68, null, s43, v40, vcc_lo            // 0000001CF110: D5207C44 01AA502B
	.long 0xd7006a41                                           // 0000001CF118: D7006A41
	v_cndmask_b32_e32 v1, s42, v47, vcc_lo                     // 0000001CF11C: 02025E2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CF120: BF8700A1
	v_add_co_ci_u32_e64 v66, null, s43, v48, vcc_lo            // 0000001CF124: D5207C42 01AA602B
	.long 0xd7006a47                                           // 0000001CF12C: D7006A47
	v_cndmask_b32_e32 v1, s42, v86, vcc_lo                     // 0000001CF130: 0202AC2A
	v_add_co_ci_u32_e64 v72, null, s43, v87, vcc_lo            // 0000001CF134: D5207C48 01AAAE2B
	s_clause 0x9                                               // 0000001CF13C: BF850009
	global_load_u16 v99, v[63:64], off                         // 0000001CF140: DC4A0000 637C003F
	global_load_u16 v98, v[55:56], off                         // 0000001CF148: DC4A0000 627C0037
	global_load_u16 v101, v[65:66], off                        // 0000001CF150: DC4A0000 657C0041
	global_load_u16 v100, v[67:68], off                        // 0000001CF158: DC4A0000 647C0043
	global_load_u16 v102, v[71:72], off offset:32              // 0000001CF160: DC4A0020 667C0047
	global_load_u16 v94, v[63:64], off offset:32               // 0000001CF168: DC4A0020 5E7C003F
	global_load_u16 v93, v[55:56], off offset:32               // 0000001CF170: DC4A0020 5D7C0037
	global_load_u16 v96, v[65:66], off offset:32               // 0000001CF178: DC4A0020 607C0041
	global_load_u16 v95, v[67:68], off offset:32               // 0000001CF180: DC4A0020 5F7C0043
	global_load_u16 v97, v[71:72], off offset:64               // 0000001CF188: DC4A0040 617C0047
	v_add_f32_e32 v8, v137, v8                                 // 0000001CF190: 06101189
	v_add_f32_e32 v7, v153, v7                                 // 0000001CF194: 060E0F99
	v_add_f32_dpp v83, v83, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF198: 06A6A6FA FF096453
	v_add_f32_dpp v81, v81, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF1A0: 06A2A2FA FF096451
	v_add_f32_dpp v78, v78, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF1A8: 069C9CFA FF09644E
	v_add_f32_dpp v8, v8, v8 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF1B0: 061010FA FF096208
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF1B8: 060E0EFA FF096207
	v_add_f32_dpp v89, v83, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF1C0: 06B2A6FA FF096853
	v_add_f32_dpp v88, v81, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF1C8: 06B0A2FA FF096851
	v_add_f32_dpp v81, v78, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF1D0: 06A29CFA FF09684E
	v_add_f32_dpp v8, v8, v8 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF1D8: 061010FA FF096408
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF1E0: 060E0EFA FF096407
	v_div_scale_f32 v109, null, v89, v89, 1.0                  // 0000001CF1E8: D6FC7C6D 03CAB359
	v_div_scale_f32 v110, null, v88, v88, 1.0                  // 0000001CF1F0: D6FC7C6E 03CAB158
	v_div_scale_f32 v115, null, v81, v81, 1.0                  // 0000001CF1F8: D6FC7C73 03CAA351
	v_add_f32_dpp v107, v8, v8 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF200: 06D610FA FF096808
	v_add_f32_dpp v108, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF208: 06D80EFA FF096807
	.long 0xd7000507                                           // 0000001CF210: D7000507
	v_cndmask_b32_e32 v1, s44, v15, vcc_lo                     // 0000001CF214: 02021E2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001CF218: BF8700B1
	v_add_co_ci_u32_e64 v8, null, s45, v16, s5                 // 0000001CF21C: D5207C08 0016202D
	v_rcp_f32_e32 v91, v109                                    // 0000001CF224: 7EB6556D
	.long 0xd700050f                                           // 0000001CF228: D700050F
	v_cndmask_b32_e32 v1, s44, v23, vcc_lo                     // 0000001CF22C: 02022E2C
	v_add_co_ci_u32_e64 v16, null, s45, v24, s5                // 0000001CF230: D5207C10 0016302D
	.long 0xd7000517                                           // 0000001CF238: D7000517
	v_cndmask_b32_e32 v1, s44, v31, vcc_lo                     // 0000001CF23C: 02023E2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CF240: BF8700A1
	v_add_co_ci_u32_e64 v24, null, s45, v32, s5                // 0000001CF244: D5207C18 0016402D
	.long 0xd700051f                                           // 0000001CF24C: D700051F
	v_cndmask_b32_e32 v1, s44, v39, vcc_lo                     // 0000001CF250: 02024E2C
	v_add_co_ci_u32_e64 v32, null, s45, v40, s5                // 0000001CF254: D5207C20 0016502D
	.long 0xd7000527                                           // 0000001CF25C: D7000527
	v_cndmask_b32_e32 v1, s44, v47, vcc_lo                     // 0000001CF260: 02025E2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CF264: BF8700A1
	v_add_co_ci_u32_e64 v40, null, s45, v48, s5                // 0000001CF268: D5207C28 0016602D
	.long 0xd700052f                                           // 0000001CF270: D700052F
	v_cndmask_b32_e32 v1, s44, v86, vcc_lo                     // 0000001CF274: 0202AC2C
	v_add_co_ci_u32_e64 v48, null, s45, v87, s5                // 0000001CF278: D5207C30 0016AE2D
	s_clause 0x1f                                              // 0000001CF280: BF85001F
	global_load_u16 v78, v[69:70], off offset:96               // 0000001CF284: DC4A0060 4E7C0045
	global_load_u16 v86, v[69:70], off offset:128              // 0000001CF28C: DC4A0080 567C0045
	global_load_u16 v87, v[69:70], off offset:160              // 0000001CF294: DC4A00A0 577C0045
	global_load_u16 v92, v[69:70], off offset:192              // 0000001CF29C: DC4A00C0 5C7C0045
	global_load_u16 v69, v[69:70], off offset:224              // 0000001CF2A4: DC4A00E0 457C0045
	global_load_u16 v138, v[55:56], off offset:64              // 0000001CF2AC: DC4A0040 8A7C0037
	global_load_u16 v133, v[55:56], off offset:96              // 0000001CF2B4: DC4A0060 857C0037
	global_load_u16 v128, v[55:56], off offset:128             // 0000001CF2BC: DC4A0080 807C0037
	global_load_u16 v124, v[55:56], off offset:160             // 0000001CF2C4: DC4A00A0 7C7C0037
	global_load_u16 v104, v[55:56], off offset:192             // 0000001CF2CC: DC4A00C0 687C0037
	global_load_u16 v137, v[63:64], off offset:64              // 0000001CF2D4: DC4A0040 897C003F
	global_load_u16 v132, v[63:64], off offset:96              // 0000001CF2DC: DC4A0060 847C003F
	global_load_u16 v127, v[63:64], off offset:128             // 0000001CF2E4: DC4A0080 7F7C003F
	global_load_u16 v123, v[63:64], off offset:160             // 0000001CF2EC: DC4A00A0 7B7C003F
	global_load_u16 v70, v[63:64], off offset:192              // 0000001CF2F4: DC4A00C0 467C003F
	global_load_u16 v56, v[55:56], off offset:224              // 0000001CF2FC: DC4A00E0 387C0037
	global_load_u16 v140, v[67:68], off offset:64              // 0000001CF304: DC4A0040 8C7C0043
	global_load_u16 v135, v[67:68], off offset:96              // 0000001CF30C: DC4A0060 877C0043
	global_load_u16 v130, v[67:68], off offset:128             // 0000001CF314: DC4A0080 827C0043
	global_load_u16 v126, v[67:68], off offset:160             // 0000001CF31C: DC4A00A0 7E7C0043
	global_load_u16 v106, v[67:68], off offset:192             // 0000001CF324: DC4A00C0 6A7C0043
	global_load_u16 v55, v[63:64], off offset:224              // 0000001CF32C: DC4A00E0 377C003F
	global_load_u16 v139, v[65:66], off offset:64              // 0000001CF334: DC4A0040 8B7C0041
	global_load_u16 v134, v[65:66], off offset:96              // 0000001CF33C: DC4A0060 867C0041
	global_load_u16 v129, v[65:66], off offset:128             // 0000001CF344: DC4A0080 817C0041
	global_load_u16 v125, v[65:66], off offset:160             // 0000001CF34C: DC4A00A0 7D7C0041
	global_load_u16 v105, v[65:66], off offset:192             // 0000001CF354: DC4A00C0 697C0041
	global_load_u16 v63, v[67:68], off offset:224              // 0000001CF35C: DC4A00E0 3F7C0043
	global_load_u16 v141, v[71:72], off offset:96              // 0000001CF364: DC4A0060 8D7C0047
	global_load_u16 v136, v[71:72], off offset:128             // 0000001CF36C: DC4A0080 887C0047
	global_load_u16 v131, v[71:72], off offset:160             // 0000001CF374: DC4A00A0 837C0047
	global_load_u16 v68, v[71:72], off offset:192              // 0000001CF37C: DC4A00C0 447C0047
	s_clause 0x1                                               // 0000001CF384: BF850001
	global_load_u16 v67, v[71:72], off offset:224              // 0000001CF388: DC4A00E0 437C0047
	global_load_u16 v64, v[65:66], off offset:224              // 0000001CF390: DC4A00E0 407C0041
	v_fma_f32 v71, -v109, v91, 1.0                             // 0000001CF398: D6130047 23CAB76D
	v_add_f32_e32 v84, v154, v76                               // 0000001CF3A0: 06A8999A
	v_div_scale_f32 v117, null, v108, v108, 1.0                // 0000001CF3A4: D6FC7C75 03CAD96C
	v_div_scale_f32 v118, null, v107, v107, 1.0                // 0000001CF3AC: D6FC7C76 03CAD76B
	v_rcp_f32_e32 v90, v110                                    // 0000001CF3B4: 7EB4556E
	v_fmac_f32_e32 v91, v71, v91                               // 0000001CF3B8: 56B6B747
	v_add_f32_dpp v84, v84, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF3BC: 06A8A8FA FF096254
	v_rcp_f32_e32 v122, v117                                   // 0000001CF3C4: 7EF45575
	v_rcp_f32_e32 v121, v118                                   // 0000001CF3C8: 7EF25576
	v_div_scale_f32 v119, vcc_lo, 1.0, v108, 1.0               // 0000001CF3CC: D6FC6A77 03CAD8F2
	v_div_scale_f32 v120, s4, 1.0, v107, 1.0                   // 0000001CF3D4: D6FC0478 03CAD6F2
	v_add_f32_dpp v84, v84, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF3DC: 06A8A8FA FF096454
	v_div_scale_f32 v112, s2, 1.0, v89, 1.0                    // 0000001CF3E4: D6FC0270 03CAB2F2
	v_div_scale_f32 v116, s1, 1.0, v81, 1.0                    // 0000001CF3EC: D6FC0174 03CAA2F2
	v_fma_f32 v72, -v110, v90, 1.0                             // 0000001CF3F4: D6130048 23CAB56E
	v_div_scale_f32 v113, s3, 1.0, v88, 1.0                    // 0000001CF3FC: D6FC0371 03CAB0F2
	v_add_f32_dpp v83, v84, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001CF404: 06A6A8FA FF096854
	v_fma_f32 v65, -v117, v122, 1.0                            // 0000001CF40C: D6130041 23CAF575
	v_fma_f32 v66, -v118, v121, 1.0                            // 0000001CF414: D6130042 23CAF376
	v_fmac_f32_e32 v90, v72, v90                               // 0000001CF41C: 56B4B548
	v_rcp_f32_e32 v84, v115                                    // 0000001CF420: 7EA85573
	v_div_scale_f32 v111, null, v83, v83, 1.0                  // 0000001CF424: D6FC7C6F 03CAA753
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CF42C: BF870233
	v_dual_fmac_f32 v122, v65, v122 :: v_dual_fmac_f32 v121, v66, v121// 0000001CF430: C800F541 7A78F342
	v_div_scale_f32 v114, s0, 1.0, v83, 1.0                    // 0000001CF438: D6FC0072 03CAA6F2
	v_dual_mul_f32 v71, v112, v91 :: v_dual_mul_f32 v72, v113, v90// 0000001CF440: C8C6B770 4748B571
	v_rcp_f32_e32 v85, v111                                    // 0000001CF448: 7EAA556F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001CF44C: BF870313
	v_dual_mul_f32 v65, v119, v122 :: v_dual_mul_f32 v66, v120, v121// 0000001CF450: C8C6F577 4142F378
	v_fma_f32 v143, -v115, v84, 1.0                            // 0000001CF458: D613008F 23CAA973
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CF460: BF870223
	v_fma_f32 v146, -v109, v71, v112                           // 0000001CF464: D6130092 25C28F6D
	v_fma_f32 v147, -v110, v72, v113                           // 0000001CF46C: D6130093 25C6916E
	v_fma_f32 v144, -v117, v65, v119                           // 0000001CF474: D6130090 25DE8375
	v_fma_f32 v145, -v118, v66, v120                           // 0000001CF47C: D6130091 25E28576
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CF484: BF870214
	v_dual_fmac_f32 v84, v143, v84 :: v_dual_fmac_f32 v71, v146, v91// 0000001CF488: C800A98F 5446B792
	v_fmac_f32_e32 v72, v147, v90                              // 0000001CF490: 5690B593
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CF494: BF870215
	v_fma_f32 v142, -v111, v85, 1.0                            // 0000001CF498: D613008E 23CAAB6F
	v_dual_fmac_f32 v65, v144, v122 :: v_dual_fmac_f32 v66, v145, v121// 0000001CF4A0: C800F590 4142F391
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CF4A8: BF870224
	v_mul_f32_e32 v143, v116, v84                              // 0000001CF4AC: 111EA974
	v_fma_f32 v109, -v109, v71, v112                           // 0000001CF4B0: D613006D 25C28F6D
	v_fmac_f32_e32 v85, v142, v85                              // 0000001CF4B8: 56AAAB8E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CF4BC: BF870004
	v_fma_f32 v117, -v117, v65, v119                           // 0000001CF4C0: D6130075 25DE8375
	v_fma_f32 v118, -v118, v66, v120                           // 0000001CF4C8: D6130076 25E28576
	v_fma_f32 v144, -v115, v143, v116                          // 0000001CF4D0: D6130090 25D31F73
	.long 0x7f003880                                           // 0000001CF4D8: 7F003880
	v_mul_f32_e32 v142, v114, v85                              // 0000001CF4DC: 111CAB72
	v_div_fmas_f32 v65, v117, v122, v65                        // 0000001CF4E0: D6370041 0506F575
	s_mov_b32 vcc_lo, s4                                       // 0000001CF4E8: BEEA0004
	v_div_fmas_f32 v117, v118, v121, v66                       // 0000001CF4EC: D6370075 050AF376
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CF4F4: BF870193
	v_fma_f32 v148, -v111, v142, v114                          // 0000001CF4F8: D6130094 25CB1D6F
	v_div_fixup_f32 v66, v65, v108, 1.0                        // 0000001CF500: D6270042 03CAD941
	v_fma_f32 v108, -v110, v72, v113                           // 0000001CF508: D613006C 25C6916E
	.long 0x7f9e3980                                           // 0000001CF510: 7F9E3980
	v_div_fixup_f32 v65, v117, v107, 1.0                       // 0000001CF514: D6270041 03CAD775
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CF51C: BF870234
	v_dual_fmac_f32 v142, v148, v85 :: v_dual_mul_f32 v57, v57, v66// 0000001CF520: C806AB94 8E388539
	v_fmac_f32_e32 v143, v144, v84                             // 0000001CF528: 571EA990
	.long 0x7f983980                                           // 0000001CF52C: 7F983980
	v_mul_f32_e32 v58, v58, v65                                // 0000001CF530: 1074833A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CF534: BF870004
	v_fma_f32 v107, -v111, v142, v114                          // 0000001CF538: D613006B 25CB1D6F
	v_mul_f32_e32 v111, v49, v66                               // 0000001CF540: 10DE8531
	v_fma_f32 v110, -v115, v143, v116                          // 0000001CF544: D613006E 25D31F73
	.long 0x7f9a3980                                           // 0000001CF54C: 7F9A3980
	.long 0x7f963980                                           // 0000001CF550: 7F963980
	.long 0x7f943980                                           // 0000001CF554: 7F943980
	v_dual_mul_f32 v33, v33, v66 :: v_dual_mul_f32 v26, v26, v65// 0000001CF558: C8C68521 211A831A
	v_mul_f32_e32 v25, v25, v66                                // 0000001CF560: 10328519
	v_mul_f32_e32 v17, v17, v66                                // 0000001CF564: 10228511
	v_mul_f32_e32 v9, v9, v66                                  // 0000001CF568: 10128509
	v_dual_mul_f32 v1, v1, v66 :: v_dual_mul_f32 v18, v18, v65 // 0000001CF56C: C8C68501 01128312
	v_mul_f32_e32 v42, v42, v65                                // 0000001CF574: 1054832A
	v_mul_f32_e32 v34, v34, v65                                // 0000001CF578: 10448322
	v_mul_f32_e32 v10, v10, v65                                // 0000001CF57C: 1014830A
	v_mul_f32_e32 v2, v2, v65                                  // 0000001CF580: 10048302
	s_waitcnt vmcnt(47)                                        // 0000001CF584: BF89BFF7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000001CF588: 30929290
	s_waitcnt vmcnt(46)                                        // 0000001CF58C: BF89BBF7
	v_dual_mul_f32 v80, v50, v65 :: v_dual_lshlrev_b32 v49, 16, v80// 0000001CF590: C8E28332 5030A090
	s_waitcnt vmcnt(45)                                        // 0000001CF598: BF89B7F7
	v_lshlrev_b32_e32 v50, 16, v82                             // 0000001CF59C: 3064A490
	s_waitcnt vmcnt(44)                                        // 0000001CF5A0: BF89B3F7
	v_lshlrev_b32_e32 v82, 16, v103                            // 0000001CF5A4: 30A4CE90
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CF5A8: BF870001
	v_mul_f32_e32 v114, 0xbfb8aa3b, v82                        // 0000001CF5AC: 10E4A4FF BFB8AA3B
	v_mul_f32_e32 v112, 0xbfb8aa3b, v73                        // 0000001CF5B4: 10E092FF BFB8AA3B
	v_mul_f32_e32 v103, 0xbfb8aa3b, v49                        // 0000001CF5BC: 10CE62FF BFB8AA3B
	v_mul_f32_e32 v113, 0xbfb8aa3b, v50                        // 0000001CF5C4: 10E264FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001CF5CC: 7C3C62FF 42CE8ED0
	v_rndne_f32_e32 v152, v114                                 // 0000001CF5D4: 7F304772
	v_fma_f32 v117, 0xbfb8aa3b, v73, -v112                     // 0000001CF5D8: D6130075 85C292FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v49, -v103                     // 0000001CF5E4: D6130073 859E62FF BFB8AA3B
	v_rndne_f32_e32 v116, v103                                 // 0000001CF5F0: 7EE84767
	s_waitcnt vmcnt(40)                                        // 0000001CF5F4: BF89A3F7
	v_lshlrev_b32_e32 v100, 16, v100                           // 0000001CF5F8: 30C8C890
	v_lshlrev_b32_e32 v98, 16, v98                             // 0000001CF5FC: 30C4C490
	v_rndne_f32_e32 v118, v112                                 // 0000001CF600: 7EEC4770
	v_lshlrev_b32_e32 v101, 16, v101                           // 0000001CF604: 30CACA90
	v_lshlrev_b32_e32 v99, 16, v99                             // 0000001CF608: 30C6C690
	s_waitcnt vmcnt(37)                                        // 0000001CF60C: BF8997F7
	v_lshlrev_b32_e32 v93, 16, v93                             // 0000001CF610: 30BABA90
	v_dual_mul_f32 v121, 0xbfb8aa3b, v100 :: v_dual_lshlrev_b32 v102, 16, v102// 0000001CF614: C8E2C8FF 7966CC90 BFB8AA3B
	v_mul_f32_e32 v119, 0xbfb8aa3b, v98                        // 0000001CF620: 10EEC4FF BFB8AA3B
	v_fma_f32 v151, 0xbfb8aa3b, v82, -v114                     // 0000001CF628: D6130097 85CAA4FF BFB8AA3B
	v_dual_fmac_f32 v115, 0xb2a5705f, v49 :: v_dual_sub_f32 v112, v112, v118// 0000001CF634: C80A62FF 7370ED70 B2A5705F
	v_dual_fmac_f32 v117, 0xb2a5705f, v73 :: v_dual_sub_f32 v114, v114, v152// 0000001CF640: C80A92FF 75733172 B2A5705F
	v_dual_sub_f32 v103, v103, v116 :: v_dual_mul_f32 v122, 0xbfb8aa3b, v101// 0000001CF64C: C946E967 677ACAFF BFB8AA3B
	v_mul_f32_e32 v120, 0xbfb8aa3b, v99                        // 0000001CF658: 10F0C6FF BFB8AA3B
	v_fma_f32 v145, 0xbfb8aa3b, v50, -v113                     // 0000001CF660: D6130091 85C664FF BFB8AA3B
	v_rndne_f32_e32 v146, v113                                 // 0000001CF66C: 7F244771
	v_dual_mul_f32 v147, 0xbfb8aa3b, v93 :: v_dual_mul_f32 v144, 0xbfb8aa3b, v102// 0000001CF670: C8C6BAFF 9390CCFF BFB8AA3B
	v_fma_f32 v154, 0xbfb8aa3b, v98, -v119                     // 0000001CF67C: D613009A 85DEC4FF BFB8AA3B
	v_dual_add_f32 v112, v112, v117 :: v_dual_add_f32 v103, v103, v115// 0000001CF688: C908EB70 7066E767
	v_fma_f32 v156, 0xbfb8aa3b, v99, -v120                     // 0000001CF690: D613009C 85E2C6FF BFB8AA3B
	v_fma_f32 v158, 0xbfb8aa3b, v100, -v121                    // 0000001CF69C: D613009E 85E6C8FF BFB8AA3B
	v_rndne_f32_e32 v163, v144                                 // 0000001CF6A8: 7F464790
	v_fmac_f32_e32 v145, 0xb2a5705f, v50                       // 0000001CF6AC: 572264FF B2A5705F
	v_sub_f32_e32 v113, v113, v146                             // 0000001CF6B4: 08E32571
	v_fmac_f32_e32 v154, 0xb2a5705f, v98                       // 0000001CF6B8: 5734C4FF B2A5705F
	v_exp_f32_e32 v103, v103                                   // 0000001CF6C0: 7ECE4B67
	s_waitcnt vmcnt(35)                                        // 0000001CF6C4: BF898FF7
	v_lshlrev_b32_e32 v95, 16, v95                             // 0000001CF6C8: 30BEBE90
	s_waitcnt vmcnt(34)                                        // 0000001CF6CC: BF898BF7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000001CF6D0: 30C2C290
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000001CF6D4: 30C0C090
	v_cvt_i32_f32_e32 v116, v116                               // 0000001CF6D8: 7EE81174
	v_rndne_f32_e32 v155, v119                                 // 0000001CF6DC: 7F364777
	v_fma_f32 v160, 0xbfb8aa3b, v101, -v122                    // 0000001CF6E0: D61300A0 85EACAFF BFB8AA3B
	v_rndne_f32_e32 v161, v122                                 // 0000001CF6EC: 7F42477A
	v_fma_f32 v162, 0xbfb8aa3b, v102, -v144                    // 0000001CF6F0: D61300A2 8642CCFF BFB8AA3B
	v_fmac_f32_e32 v156, 0xb2a5705f, v99                       // 0000001CF6FC: 5738C6FF B2A5705F
	v_fmac_f32_e32 v158, 0xb2a5705f, v100                      // 0000001CF704: 573CC8FF B2A5705F
	v_dual_sub_f32 v144, v144, v163 :: v_dual_add_f32 v113, v113, v145// 0000001CF70C: C9494790 90712371
	v_exp_f32_e32 v112, v112                                   // 0000001CF714: 7EE04B70
	v_dual_mul_f32 v149, 0xbfb8aa3b, v95 :: v_dual_lshlrev_b32 v94, 16, v94// 0000001CF718: C8E2BEFF 955EBC90 BFB8AA3B
	v_dual_mul_f32 v153, 0xbfb8aa3b, v97 :: v_dual_mul_f32 v150, 0xbfb8aa3b, v96// 0000001CF724: C8C6C2FF 9996C0FF BFB8AA3B
	v_cvt_i32_f32_e32 v118, v118                               // 0000001CF730: 7EEC1176
	v_rndne_f32_e32 v157, v120                                 // 0000001CF734: 7F3A4778
	v_dual_fmac_f32 v151, 0xb2a5705f, v82 :: v_dual_fmac_f32 v160, 0xb2a5705f, v101// 0000001CF738: C800A4FF 97A0CAFF B2A5705F
	v_dual_sub_f32 v115, v119, v155 :: v_dual_sub_f32 v122, v122, v161// 0000001CF744: C94B3777 737B437A
	v_exp_f32_e32 v113, v113                                   // 0000001CF74C: 7EE24B71
	.long 0xd71c0067                                           // 0000001CF750: D71C0067
	v_cndmask_b32_e32 v1, v103, v116, vcc_lo                   // 0000001CF754: 0202E967
	v_mul_f32_e32 v148, 0xbfb8aa3b, v94                        // 0000001CF758: 1128BCFF BFB8AA3B
	v_rndne_f32_e32 v159, v121                                 // 0000001CF760: 7F3E4779
	v_cvt_i32_f32_e32 v146, v146                               // 0000001CF764: 7F241192
	v_fma_f32 v164, 0xbfb8aa3b, v93, -v147                     // 0000001CF768: D61300A4 864EBAFF BFB8AA3B
	v_fma_f32 v168, 0xbfb8aa3b, v95, -v149                     // 0000001CF774: D61300A8 8656BEFF BFB8AA3B
	v_fma_f32 v170, 0xbfb8aa3b, v96, -v150                     // 0000001CF780: D61300AA 865AC0FF BFB8AA3B
	v_rndne_f32_e32 v171, v150                                 // 0000001CF78C: 7F564796
	v_dual_sub_f32 v119, v120, v157 :: v_dual_fmac_f32 v162, 0xb2a5705f, v102// 0000001CF790: C9413B78 77A2CCFF B2A5705F
	v_dual_add_f32 v122, v122, v160 :: v_dual_cndmask_b32 v103, 0, v103// 0000001CF79C: C913417A 7A66CE80
	.long 0xd71c0070                                           // 0000001CF7A4: D71C0070
	v_cndmask_b32_e32 v1, v112, v118, vcc_lo                   // 0000001CF7A8: 0202ED70
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000001CF7AC: 7C3C92FF 42CE8ED0
	v_rndne_f32_e32 v165, v147                                 // 0000001CF7B4: 7F4A4793
	v_fma_f32 v166, 0xbfb8aa3b, v94, -v148                     // 0000001CF7B8: D61300A6 8652BCFF BFB8AA3B
	v_dual_sub_f32 v121, v121, v159 :: v_dual_fmac_f32 v164, 0xb2a5705f, v93// 0000001CF7C4: C9413F79 79A4BAFF B2A5705F
	v_dual_fmac_f32 v168, 0xb2a5705f, v95 :: v_dual_add_f32 v115, v115, v154// 0000001CF7D0: C808BEFF A8733573 B2A5705F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001CF7DC: BF870002
	v_dual_fmac_f32 v170, 0xb2a5705f, v96 :: v_dual_add_f32 v121, v121, v158// 0000001CF7E0: C808C0FF AA793D79 B2A5705F
	v_dual_sub_f32 v150, v150, v171 :: v_dual_add_f32 v119, v119, v156// 0000001CF7EC: C9495796 96773977
	.long 0xd71c0071                                           // 0000001CF7F4: D71C0071
	v_cndmask_b32_e32 v1, v113, v146, vcc_lo                   // 0000001CF7F8: 02032571
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 0000001CF7FC: 02E0E080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v50                  // 0000001CF800: 7C3C64FF 42CE8ED0
	v_dual_sub_f32 v145, v147, v165 :: v_dual_fmac_f32 v166, 0xb2a5705f, v94// 0000001CF808: C9414B93 91A6BCFF B2A5705F
	v_add_f32_e32 v144, v144, v162                             // 0000001CF814: 07214590
	v_dual_add_f32 v150, v150, v170 :: v_dual_cndmask_b32 v113, 0, v113// 0000001CF818: C9135596 9670E280
	v_exp_f32_e32 v115, v115                                   // 0000001CF820: 7EE64B73
	v_exp_f32_e32 v119, v119                                   // 0000001CF824: 7EEE4B77
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001CF828: 7C3662FF C2B17218
	v_cvt_i32_f32_e32 v117, v155                               // 0000001CF830: 7EEA119B
	v_cvt_i32_f32_e32 v120, v157                               // 0000001CF834: 7EF0119D
	v_add_f32_e32 v145, v145, v164                             // 0000001CF838: 07234991
	v_exp_f32_e32 v144, v144                                   // 0000001CF83C: 7F204B90
	v_cndmask_b32_e32 v49, 0x7f800000, v103, vcc_lo            // 0000001CF840: 0262CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000001CF848: 7C3692FF C2B17218
	v_cvt_i32_f32_e32 v155, v159                               // 0000001CF850: 7F36119F
	v_cvt_i32_f32_e32 v159, v163                               // 0000001CF854: 7F3E11A3
	v_exp_f32_e32 v121, v121                                   // 0000001CF858: 7EF24B79
	.long 0xd71c0073                                           // 0000001CF85C: D71C0073
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                   // 0000001CF860: 0202EB73
	.long 0xd71c0075                                           // 0000001CF864: D71C0075
	v_cndmask_b32_e32 v1, v119, v120, vcc_lo                   // 0000001CF868: 0202F177
	v_cndmask_b32_e32 v73, 0x7f800000, v112, vcc_lo            // 0000001CF86C: 0292E0FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v98                  // 0000001CF874: 7C3CC4FF 42CE8ED0
	v_exp_f32_e32 v122, v122                                   // 0000001CF87C: 7EF44B7A
	.long 0xd71c0078                                           // 0000001CF880: D71C0078
	v_cndmask_b32_e32 v1, v144, v159, vcc_lo                   // 0000001CF884: 02033F90
	v_rndne_f32_e32 v167, v148                                 // 0000001CF888: 7F4E4794
	v_cvt_i32_f32_e32 v157, v161                               // 0000001CF88C: 7F3A11A1
	v_cndmask_b32_e32 v103, 0, v115, vcc_lo                    // 0000001CF890: 02CEE680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v99                  // 0000001CF894: 7C3CC6FF 42CE8ED0
	.long 0xd71c0076                                           // 0000001CF89C: D71C0076
	v_cndmask_b32_e32 v1, v121, v155, vcc_lo                   // 0000001CF8A0: 02033779
	v_rndne_f32_e32 v169, v149                                 // 0000001CF8A4: 7F524795
	v_sub_f32_e32 v148, v148, v167                             // 0000001CF8A8: 09294F94
	v_exp_f32_e32 v145, v145                                   // 0000001CF8AC: 7F224B91
	v_cndmask_b32_e32 v112, 0, v117, vcc_lo                    // 0000001CF8B0: 02E0EA80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 0000001CF8B4: 7C3CC8FF 42CE8ED0
	.long 0xd71c0077                                           // 0000001CF8BC: D71C0077
	v_cndmask_b32_e32 v1, v122, v157, vcc_lo                   // 0000001CF8C0: 02033B7A
	v_dual_sub_f32 v149, v149, v169 :: v_dual_add_f32 v148, v148, v166// 0000001CF8C4: C9495395 95954D94
	v_cvt_i32_f32_e32 v147, v165                               // 0000001CF8CC: 7F2611A5
	v_cndmask_b32_e32 v115, 0, v118, vcc_lo                    // 0000001CF8D0: 02E6EC80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v101                 // 0000001CF8D4: 7C3CCAFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CF8DC: BF870004
	v_add_f32_e32 v149, v149, v168                             // 0000001CF8E0: 072B5195
	v_exp_f32_e32 v148, v148                                   // 0000001CF8E4: 7F284B94
	v_exp_f32_e32 v116, v150                                   // 0000001CF8E8: 7EE84B96
	v_cvt_i32_f32_e32 v161, v167                               // 0000001CF8EC: 7F4211A7
	v_cndmask_b32_e32 v117, 0, v119, vcc_lo                    // 0000001CF8F0: 02EAEE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 0000001CF8F4: 7C3CCCFF 42CE8ED0
	v_cvt_i32_f32_e32 v165, v171                               // 0000001CF8FC: 7F4A11AB
	v_exp_f32_e32 v149, v149                                   // 0000001CF900: 7F2A4B95
	.long 0xd71c0079                                           // 0000001CF904: D71C0079
	v_cndmask_b32_e32 v1, v145, v147, vcc_lo                   // 0000001CF908: 02032791
	v_cvt_i32_f32_e32 v163, v169                               // 0000001CF90C: 7F4611A9
	v_cndmask_b32_e32 v118, 0, v120, vcc_lo                    // 0000001CF910: 02ECF080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v50                  // 0000001CF914: 7C3664FF C2B17218
	.long 0xd71c007a                                           // 0000001CF91C: D71C007A
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 0000001CF920: 02034394
	.long 0xd71c0074                                           // 0000001CF924: D71C0074
	v_cndmask_b32_e32 v1, v116, v165, vcc_lo                   // 0000001CF928: 02034B74
	v_add_f32_e32 v120, 1.0, v49                               // 0000001CF92C: 06F062F2
	.long 0xd41b0005                                           // 0000001CF930: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v94, vcc_lo              // 0000001CF934: 0202BCFF C2B17218
	v_cndmask_b32_e32 v50, 0x7f800000, v113, vcc_lo            // 0000001CF93C: 0264E2FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v93                  // 0000001CF944: 7C3CBAFF 42CE8ED0
	.long 0xd71c0090                                           // 0000001CF94C: D71C0090
	v_cndmask_b32_e32 v1, v149, v163, vcc_lo                   // 0000001CF950: 02034795
	v_cndmask_b32_e32 v113, 0, v121, vcc_lo                    // 0000001CF954: 02E2F280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v94                  // 0000001CF958: 7C3CBCFF 42CE8ED0
	v_div_scale_f32 v121, null, v120, v120, v57                // 0000001CF960: D6FC7C79 04E6F178
	v_cndmask_b32_e32 v119, 0, v122, vcc_lo                    // 0000001CF968: 02EEF480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v95                  // 0000001CF96C: 7C3CBEFF 42CE8ED0
	v_cndmask_b32_e32 v49, 0, v144, vcc_lo                     // 0000001CF974: 02632080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000001CF978: 7C3CC0FF 42CE8ED0
	v_cndmask_b32_e32 v116, 0, v116, vcc_lo                    // 0000001CF980: 02E8E880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v98                  // 0000001CF984: 7C36C4FF C2B17218
	v_cndmask_b32_e32 v98, 0x7f800000, v103, vcc_lo            // 0000001CF98C: 02C4CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v99                  // 0000001CF994: 7C36C6FF C2B17218
	v_rcp_f32_e32 v103, v121                                   // 0000001CF99C: 7ECE5579
	v_cndmask_b32_e64 v94, 0x7f800000, v119, s5                // 0000001CF9A0: D501005E 0016EEFF 7F800000
	.long 0xd41b0005                                           // 0000001CF9AC: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v95, vcc_lo              // 0000001CF9B0: 0202BEFF C2B17218
	v_dual_add_f32 v98, 1.0, v98 :: v_dual_cndmask_b32 v99, 0x7f800000, v112// 0000001CF9B8: C912C4F2 6262E0FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 0000001CF9C4: 7C36C8FF C2B17218
	v_dual_add_f32 v73, 1.0, v73 :: v_dual_cndmask_b32 v100, 0x7f800000, v115// 0000001CF9CC: C91292F2 4964E6FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CF9D8: BF870121
	v_div_scale_f32 v122, null, v73, v73, v58                  // 0000001CF9DC: D6FC7C7A 04EA9349
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v101                 // 0000001CF9E4: 7C36CAFF C2B17218
	v_rcp_f32_e32 v112, v122                                   // 0000001CF9EC: 7EE0557A
	v_cndmask_b32_e32 v101, 0x7f800000, v117, vcc_lo           // 0000001CF9F0: 02CAEAFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 0000001CF9F8: 7C36CCFF C2B17218
	v_cndmask_b32_e32 v102, 0x7f800000, v118, vcc_lo           // 0000001CFA00: 02CCECFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v93                  // 0000001CFA08: 7C36BAFF C2B17218
	v_div_scale_f32 v118, s4, v58, v73, v58                    // 0000001CFA10: D6FC0476 04EA933A
	v_cndmask_b32_e64 v95, 0x7f800000, v49, s5                 // 0000001CFA18: D501005F 001662FF 7F800000
	.long 0xd41b0005                                           // 0000001CFA24: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v96, vcc_lo              // 0000001CFA28: 0202C0FF C2B17218
	v_dual_add_f32 v102, 1.0, v102 :: v_dual_cndmask_b32 v93, 0x7f800000, v113// 0000001CFA30: C912CCF2 665CE2FF 7F800000
	v_div_scale_f32 v117, vcc_lo, v57, v120, v57               // 0000001CFA3C: D6FC6A75 04E6F139
	v_add_f32_e32 v115, 1.0, v50                               // 0000001CFA44: 06E664F2
	v_fma_f32 v50, -v121, v103, 1.0                            // 0000001CFA48: D6130032 23CACF79
	v_fma_f32 v113, -v122, v112, 1.0                           // 0000001CFA50: D6130071 23CAE17A
	v_div_scale_f32 v119, null, v102, v102, v80                // 0000001CFA58: D6FC7C77 0542CD66
	v_cndmask_b32_e64 v96, 0x7f800000, v116, s5                // 0000001CFA60: D5010060 0016E8FF 7F800000
	v_dual_add_f32 v94, 1.0, v94 :: v_dual_add_f32 v95, 1.0, v95// 0000001CFA6C: C908BCF2 5E5EBEF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CFA74: BF870214
	v_dual_fmac_f32 v103, v50, v103 :: v_dual_fmac_f32 v112, v113, v112// 0000001CFA78: C800CF32 6770E171
	v_rcp_f32_e32 v146, v119                                   // 0000001CFA80: 7F245577
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CFA84: BF870111
	v_mul_f32_e32 v50, v117, v103                              // 0000001CFA88: 1064CF75
	v_mul_f32_e32 v144, v118, v112                             // 0000001CFA8C: 1120E176
	v_div_scale_f32 v113, null, v115, v115, v111               // 0000001CFA90: D6FC7C71 05BEE773
	v_div_scale_f32 v116, s5, v111, v115, v111                 // 0000001CFA98: D6FC0574 05BEE76F
	v_add_f32_e32 v93, 1.0, v93                                // 0000001CFAA0: 06BABAF2
	v_fma_f32 v49, -v121, v50, v117                            // 0000001CFAA4: D6130031 25D66579
	v_fma_f32 v147, -v122, v144, v118                          // 0000001CFAAC: D6130093 25DB217A
	v_rcp_f32_e32 v145, v113                                   // 0000001CFAB4: 7F225571
	v_add_f32_e32 v99, 1.0, v99                                // 0000001CFAB8: 06C6C6F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CFABC: BF870193
	v_fmac_f32_e32 v50, v49, v103                              // 0000001CFAC0: 5664CF31
	v_fmac_f32_e32 v144, v147, v112                            // 0000001CFAC4: 5720E193
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CFAC8: BF870112
	v_fma_f32 v117, -v121, v50, v117                           // 0000001CFACC: D6130075 25D66579
	v_fma_f32 v118, -v122, v144, v118                          // 0000001CFAD4: D6130076 25DB217A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CFADC: BF870225
	v_fma_f32 v49, -v113, v145, 1.0                            // 0000001CFAE0: D6130031 23CB2371
	v_fma_f32 v121, -v119, v146, 1.0                           // 0000001CFAE8: D6130079 23CB2577
	v_div_fmas_f32 v103, v117, v103, v50                       // 0000001CFAF0: D6370067 04CACF75
	s_mov_b32 vcc_lo, s4                                       // 0000001CFAF8: BEEA0004
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CFAFC: BF870003
	v_fmac_f32_e32 v145, v49, v145                             // 0000001CFB00: 57232331
	v_div_fmas_f32 v112, v118, v112, v144                      // 0000001CFB04: D6370070 0642E176
	s_mov_b32 vcc_lo, s2                                       // 0000001CFB0C: BEEA0002
	v_fmac_f32_e32 v146, v121, v146                            // 0000001CFB10: 57252579
	v_div_fmas_f32 v50, v109, v91, v71                         // 0000001CFB14: D6370032 051EB76D
	s_mov_b32 vcc_lo, s3                                       // 0000001CFB1C: BEEA0003
	v_div_fixup_f32 v57, v103, v120, v57                       // 0000001CFB20: D6270039 04E6F167
	v_div_fmas_f32 v71, v108, v90, v72                         // 0000001CFB28: D6370047 0522B56C
	v_div_scale_f32 v72, s2, v80, v102, v80                    // 0000001CFB30: D6FC0248 0542CD50
	v_div_fixup_f32 v50, v50, v89, 1.0                         // 0000001CFB38: D6270032 03CAB332
	v_add_f32_e32 v90, 1.0, v100                               // 0000001CFB40: 06B4C8F2
	v_add_f32_e32 v96, 1.0, v96                                // 0000001CFB44: 06C0C0F2
	v_div_fixup_f32 v49, v71, v88, 1.0                         // 0000001CFB48: D6270031 03CAB147
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001CFB50: BF870244
	v_dual_mul_f32 v88, v116, v145 :: v_dual_mul_f32 v59, v59, v50// 0000001CFB54: C8C72374 583A653B
	v_add_f32_e32 v71, 1.0, v101                               // 0000001CFB5C: 068ECAF2
	v_mul_f32_e32 v103, v51, v50                               // 0000001CFB60: 10CE6533
	.long 0x7e9e39b9                                           // 0000001CFB64: 7E9E39B9
	v_fma_f32 v91, -v113, v88, v116                            // 0000001CFB68: D613005B 25D2B171
	v_mul_f32_e32 v89, v72, v146                               // 0000001CFB70: 10B32548
	v_div_scale_f32 v100, null, v98, v98, v59                  // 0000001CFB74: D6FC7C64 04EEC562
	v_div_fixup_f32 v58, v112, v73, v58                        // 0000001CFB7C: D627003A 04EA9370
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CFB84: BF870214
	v_dual_fmac_f32 v88, v91, v145 :: v_dual_and_b32 v79, 1, v79// 0000001CFB88: C825235B 584E9E81
	v_fma_f32 v101, -v119, v89, v72                            // 0000001CFB90: D6130065 2522B377
	v_mul_f32_e32 v60, v60, v49                                // 0000001CFB98: 1078633C
	v_rcp_f32_e32 v91, v100                                    // 0000001CFB9C: 7EB65564
	.long 0x7e0039ba                                           // 0000001CFBA0: 7E0039BA
	v_fma_f32 v109, -v113, v88, v116                           // 0000001CFBA4: D613006D 25D2B171
	v_fmac_f32_e32 v89, v101, v146                             // 0000001CFBAC: 56B32565
	v_div_scale_f32 v108, null, v99, v99, v60                  // 0000001CFBB0: D6FC7C6C 04F2C763
	v_mul_f32_e32 v113, v52, v49                               // 0000001CFBB8: 10E26334
	v_div_scale_f32 v116, vcc_lo, v59, v98, v59                // 0000001CFBBC: D6FC6A74 04EEC53B
	v_div_scale_f32 v122, s4, v103, v93, v103                  // 0000001CFBC4: D6FC047A 059EBB67
	v_div_scale_f32 v117, null, v93, v93, v103                 // 0000001CFBCC: D6FC7C75 059EBB5D
	v_rcp_f32_e32 v101, v108                                   // 0000001CFBD4: 7ECA556C
	v_fma_f32 v51, -v100, v91, 1.0                             // 0000001CFBD8: D6130033 23CAB764
	v_fma_f32 v72, -v119, v89, v72                             // 0000001CFBE0: D6130048 2522B377
	v_add3_u32 v57, v57, v79, 0x7fff                           // 0000001CFBE8: D6550039 03FE9F39 00007FFF
	v_rcp_f32_e32 v112, v117                                   // 0000001CFBF4: 7EE05575
	v_dual_mul_f32 v43, v43, v50 :: v_dual_mul_f32 v44, v44, v49// 0000001CFBF8: C8C6652B 2B2C632C
	v_dual_mul_f32 v36, v36, v49 :: v_dual_mul_f32 v35, v35, v50// 0000001CFC00: C8C66324 24226523
	v_mul_f32_e32 v28, v28, v49                                // 0000001CFC08: 1038631C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001CFC0C: BF870246
	v_fma_f32 v52, -v108, v101, 1.0                            // 0000001CFC10: D6130034 23CACB6C
	v_dual_mul_f32 v20, v20, v49 :: v_dual_mul_f32 v27, v27, v50// 0000001CFC18: C8C66314 141A651B
	v_dual_mul_f32 v12, v12, v49 :: v_dual_mul_f32 v19, v19, v50// 0000001CFC20: C8C6630C 0C126513
	v_mul_f32_e32 v4, v4, v49                                  // 0000001CFC28: 10086304
	v_fmac_f32_e32 v101, v52, v101                             // 0000001CFC2C: 56CACB34
	v_fmac_f32_e32 v91, v51, v91                               // 0000001CFC30: 56B6B733
	v_div_scale_f32 v51, s3, v60, v99, v60                     // 0000001CFC34: D6FC0333 04F2C73C
	v_mul_f32_e32 v11, v11, v50                                // 0000001CFC3C: 1016650B
	v_mul_f32_e32 v3, v3, v50                                  // 0000001CFC40: 10066503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CFC44: BF870093
	v_mul_f32_e32 v118, v51, v101                              // 0000001CFC48: 10ECCB33
	v_fma_f32 v121, -v108, v118, v51                           // 0000001CFC4C: D6130079 24CEED6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CFC54: BF870121
	v_fmac_f32_e32 v118, v121, v101                            // 0000001CFC58: 56ECCB79
	v_mul_f32_e32 v52, v116, v91                               // 0000001CFC5C: 1068B774
	v_fma_f32 v51, -v108, v118, v51                            // 0000001CFC60: D6130033 24CEED6C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CFC68: BF870092
	v_fma_f32 v120, -v100, v52, v116                           // 0000001CFC6C: D6130078 25D26964
	v_fmac_f32_e32 v52, v120, v91                              // 0000001CFC74: 5668B778
	v_fma_f32 v120, -v117, v112, 1.0                           // 0000001CFC78: D6130078 23CAE175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CFC80: BF870092
	v_fma_f32 v100, -v100, v52, v116                           // 0000001CFC84: D6130064 25D26964
	v_div_fmas_f32 v91, v100, v91, v52                         // 0000001CFC8C: D637005B 04D2B764
	s_mov_b32 vcc_lo, s3                                       // 0000001CFC94: BEEA0003
	v_div_fmas_f32 v100, v51, v101, v118                       // 0000001CFC98: D6370064 05DACB33
	s_mov_b32 vcc_lo, s0                                       // 0000001CFCA0: BEEA0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001CFCA4: BF870002
	v_div_fixup_f32 v59, v91, v98, v59                         // 0000001CFCA8: D627003B 04EEC55B
	v_div_fmas_f32 v51, v107, v85, v142                        // 0000001CFCB0: D6370033 063AAB6B
	s_mov_b32 vcc_lo, s1                                       // 0000001CFCB8: BEEA0001
	v_div_fixup_f32 v60, v100, v99, v60                        // 0000001CFCBC: D627003C 04F2C764
	v_div_fmas_f32 v84, v110, v84, v143                        // 0000001CFCC4: D6370054 063EA96E
	v_and_b32_e32 v85, 1, v0                                   // 0000001CFCCC: 36AA0081
	v_div_fixup_f32 v52, v51, v83, 1.0                         // 0000001CFCD0: D6270034 03CAA733
	.long 0x7e9a39bb                                           // 0000001CFCD8: 7E9A39BB
	.long 0x7e0039bc                                           // 0000001CFCDC: 7E0039BC
	v_div_fixup_f32 v51, v84, v81, 1.0                         // 0000001CFCE0: D6270033 03CAA354
	v_add3_u32 v58, v58, v85, 0x7fff                           // 0000001CFCE8: D655003A 03FEAB3A 00007FFF
	v_mul_f32_e32 v61, v61, v52                                // 0000001CFCF4: 107A693D
	s_clause 0x1                                               // 0000001CFCF8: BF850001
	global_store_d16_hi_b16 v[7:8], v57, off                   // 0000001CFCFC: DC960000 007C3907
	global_store_d16_hi_b16 v[7:8], v58, off offset:1024       // 0000001CFD04: DC960400 007C3A07
	v_mul_f32_e32 v62, v62, v51                                // 0000001CFD0C: 107C673E
	v_div_scale_f32 v73, null, v94, v94, v113                  // 0000001CFD10: D6FC7C49 05C6BD5E
	v_div_scale_f32 v121, s6, v113, v94, v113                  // 0000001CFD18: D6FC0679 05C6BD71
	v_mul_f32_e32 v54, v54, v51                                // 0000001CFD20: 106C6736
	v_div_scale_f32 v85, null, v90, v90, v61                   // 0000001CFD24: D6FC7C55 04F6B55A
	v_mul_f32_e32 v53, v53, v52                                // 0000001CFD2C: 106A6935
	v_rcp_f32_e32 v119, v73                                    // 0000001CFD30: 7EEE5549
	v_div_scale_f32 v99, vcc_lo, v61, v90, v61                 // 0000001CFD34: D6FC6A63 04F6B53D
	v_div_scale_f32 v116, null, v96, v96, v54                  // 0000001CFD3C: D6FC7C74 04DAC160
	v_mul_f32_e32 v37, v37, v52                                // 0000001CFD44: 104A6925
	v_div_scale_f32 v100, null, v95, v95, v53                  // 0000001CFD48: D6FC7C64 04D6BF5F
	v_div_scale_f32 v110, s1, v53, v95, v53                    // 0000001CFD50: D6FC016E 04D6BF35
	v_dual_mul_f32 v22, v22, v51 :: v_dual_mul_f32 v29, v29, v52// 0000001CFD58: C8C66716 161C691D
	v_mul_f32_e32 v14, v14, v51                                // 0000001CFD60: 101C670E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001CFD64: BF870314
	v_rcp_f32_e32 v107, v100                                   // 0000001CFD68: 7ED65564
	v_fma_f32 v144, -v73, v119, 1.0                            // 0000001CFD6C: D6130090 23CAEF49
	v_mul_f32_e32 v21, v21, v52                                // 0000001CFD74: 102A6915
	v_mul_f32_e32 v13, v13, v52                                // 0000001CFD78: 101A690D
	v_dual_mul_f32 v5, v5, v52 :: v_dual_mul_f32 v6, v6, v51   // 0000001CFD7C: C8C66905 05066706
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CFD84: BF870094
	v_fmac_f32_e32 v119, v144, v119                            // 0000001CFD88: 56EEEF90
	v_dual_fmac_f32 v112, v120, v112 :: v_dual_mul_f32 v81, v121, v119// 0000001CFD8C: C806E178 7050EF79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001CFD94: BF870111
	v_mul_f32_e32 v83, v122, v112                              // 0000001CFD98: 10A6E17A
	v_fma_f32 v84, -v73, v81, v121                             // 0000001CFD9C: D6130054 25E6A349
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CFDA4: BF870092
	v_fma_f32 v79, -v117, v83, v122                            // 0000001CFDA8: D613004F 25EAA775
	v_fmac_f32_e32 v83, v79, v112                              // 0000001CFDB0: 56A6E14F
	v_div_scale_f32 v79, null, v71, v71, v62                   // 0000001CFDB4: D6FC7C4F 04FA8F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001CFDBC: BF870291
	v_rcp_f32_e32 v91, v79                                     // 0000001CFDC0: 7EB6554F
	v_fma_f32 v98, -v79, v91, 1.0                              // 0000001CFDC4: D6130062 23CAB74F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001CFDCC: BF870131
	v_dual_fmac_f32 v91, v98, v91 :: v_dual_and_b32 v98, 1, v0 // 0000001CFDD0: C824B762 5B620081
	v_fmac_f32_e32 v81, v84, v119                              // 0000001CFDD8: 56A2EF54
	v_rcp_f32_e32 v84, v85                                     // 0000001CFDDC: 7EA85555
	v_add3_u32 v60, v60, v98, 0x7fff                           // 0000001CFDE0: D655003C 03FEC53C 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001CFDEC: BF870292
	v_fma_f32 v58, -v73, v81, v121                             // 0000001CFDF0: D613003A 25E6A349
	v_fma_f32 v73, -v85, v84, 1.0                              // 0000001CFDF8: D6130049 23CAA955
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CFE00: BF8700A1
	v_fmac_f32_e32 v84, v73, v84                               // 0000001CFE04: 56A8A949
	v_div_scale_f32 v73, s0, v62, v71, v62                     // 0000001CFE08: D6FC0049 04FA8F3E
	v_dual_mul_f32 v101, v99, v84 :: v_dual_mul_f32 v108, v73, v91// 0000001CFE10: C8C6A963 656CB749
	v_fma_f32 v57, -v117, v83, v122                            // 0000001CFE18: D6130039 25EAA775
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CFE20: BF870092
	v_fma_f32 v117, -v79, v108, v73                            // 0000001CFE24: D6130075 2526D94F
	v_dual_fmac_f32 v108, v117, v91 :: v_dual_and_b32 v77, 1, v77// 0000001CFE2C: C824B775 6C4C9A81
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CFE34: BF870001
	v_add3_u32 v59, v59, v77, 0x7fff                           // 0000001CFE38: D655003B 03FE9B3B 00007FFF
	v_fma_f32 v77, -v85, v101, v99                             // 0000001CFE44: D613004D 258ECB55
	global_store_d16_hi_b16 v[15:16], v59, off                 // 0000001CFE4C: DC960000 007C3B0F
	v_fma_f32 v59, -v100, v107, 1.0                            // 0000001CFE54: D613003B 23CAD764
	global_store_d16_hi_b16 v[23:24], v60, off                 // 0000001CFE5C: DC960000 007C3C17
	v_fmac_f32_e32 v107, v59, v107                             // 0000001CFE64: 56D6D73B
	v_fmac_f32_e32 v101, v77, v84                              // 0000001CFE68: 56CAA94D
	v_fma_f32 v59, -v79, v108, v73                             // 0000001CFE6C: D613003B 2526D94F
	v_rcp_f32_e32 v77, v116                                    // 0000001CFE74: 7E9A5574
	s_waitcnt vmcnt(23)                                        // 0000001CFE78: BF895FF7
	v_lshlrev_b32_e32 v79, 16, v137                            // 0000001CFE7C: 309F1290
	v_mul_f32_e32 v41, v41, v66                                // 0000001CFE80: 10528529
	v_fma_f32 v60, -v85, v101, v99                             // 0000001CFE84: D613003C 258ECB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000001CFE8C: BF870141
	v_div_fmas_f32 v60, v60, v84, v101                         // 0000001CFE90: D637003C 0596A93C
	s_mov_b32 vcc_lo, s0                                       // 0000001CFE98: BEEA0000
	v_div_fmas_f32 v59, v59, v91, v108                         // 0000001CFE9C: D637003B 05B2B73B
	s_mov_b32 vcc_lo, s2                                       // 0000001CFEA4: BEEA0002
	v_div_fixup_f32 v60, v60, v90, v61                         // 0000001CFEA8: D627003C 04F6B53C
	v_div_fmas_f32 v72, v72, v146, v89                         // 0000001CFEB0: D6370048 05672548
	s_mov_b32 vcc_lo, s5                                       // 0000001CFEB8: BEEA0005
	v_div_fixup_f32 v59, v59, v71, v62                         // 0000001CFEBC: D627003B 04FA8F3B
	v_div_fmas_f32 v61, v109, v145, v88                        // 0000001CFEC4: D637003D 0563236D
	.long 0x7e9839bc                                           // 0000001CFECC: 7E9839BC
	v_div_fixup_f32 v62, v72, v102, v80                        // 0000001CFED0: D627003E 0542CD48
	s_mov_b32 vcc_lo, s4                                       // 0000001CFED8: BEEA0004
	.long 0x7e0039bb                                           // 0000001CFEDC: 7E0039BB
	v_div_fixup_f32 v61, v61, v115, v111                       // 0000001CFEE0: D627003D 05BEE73D
	v_and_b32_e32 v72, 1, v76                                  // 0000001CFEE8: 36909881
	.long 0x7e9639be                                           // 0000001CFEEC: 7E9639BE
	v_div_fmas_f32 v57, v57, v112, v83                         // 0000001CFEF0: D6370039 054EE139
	v_and_b32_e32 v71, 1, v0                                   // 0000001CFEF8: 368E0081
	.long 0x7e0039bd                                           // 0000001CFEFC: 7E0039BD
	v_add3_u32 v60, v60, v72, 0x7fff                           // 0000001CFF00: D655003C 03FE913C 00007FFF
	v_fma_f32 v72, 0xbfb8aa3b, v97, -v153                      // 0000001CFF0C: D6130048 8666C2FF BFB8AA3B
	s_mov_b32 vcc_lo, s6                                       // 0000001CFF18: BEEA0006
	v_add3_u32 v59, v59, v71, 0x7fff                           // 0000001CFF1C: D655003B 03FE8F3B 00007FFF
	v_div_fmas_f32 v58, v58, v119, v81                         // 0000001CFF28: D637003A 0546EF3A
	v_div_fixup_f32 v57, v57, v93, v103                        // 0000001CFF30: D6270039 059EBB39
	v_dual_fmac_f32 v72, 0xb2a5705f, v97 :: v_dual_and_b32 v73, 1, v75// 0000001CFF38: C824C2FF 48489681 B2A5705F
	v_and_b32_e32 v75, 1, v0                                   // 0000001CFF44: 36960081
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CFF48: BF870004
	v_div_fixup_f32 v58, v58, v94, v113                        // 0000001CFF4C: D627003A 05C6BD3A
	s_clause 0x1                                               // 0000001CFF54: BF850001
	global_store_d16_hi_b16 v[31:32], v60, off                 // 0000001CFF58: DC960000 007C3C1F
	global_store_d16_hi_b16 v[39:40], v59, off                 // 0000001CFF60: DC960000 007C3B27
	v_fma_f32 v60, -v116, v77, 1.0                             // 0000001CFF68: D613003C 23CA9B74
	v_add3_u32 v62, v62, v73, 0x7fff                           // 0000001CFF70: D655003E 03FE933E 00007FFF
	v_add3_u32 v61, v61, v75, 0x7fff                           // 0000001CFF7C: D655003D 03FE973D 00007FFF
	s_clause 0x1                                               // 0000001CFF88: BF850001
	global_store_d16_hi_b16 v[7:8], v61, off offset:32         // 0000001CFF8C: DC960020 007C3D07
	global_store_d16_hi_b16 v[47:48], v62, off offset:32       // 0000001CFF94: DC960020 007C3E2F
	v_add_f32_e32 v61, v114, v151                              // 0000001CFF9C: 067B2F72
	.long 0x7e0039ba                                           // 0000001CFFA0: 7E0039BA
	.long 0x7e9439b9                                           // 0000001CFFA4: 7E9439B9
	v_rndne_f32_e32 v73, v153                                  // 0000001CFFA8: 7E924799
	v_fmac_f32_e32 v77, v60, v77                               // 0000001CFFAC: 569A9B3C
	v_exp_f32_e32 v60, v61                                     // 0000001CFFB0: 7E784B3D
	v_div_scale_f32 v61, s0, v54, v96, v54                     // 0000001CFFB4: D6FC003D 04DAC136
	v_and_b32_e32 v59, 1, v0                                   // 0000001CFFBC: 36760081
	v_dual_sub_f32 v74, v153, v73 :: v_dual_and_b32 v71, 1, v74// 0000001CFFC0: C9649399 4A469481
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v82                  // 0000001CFFC8: 7C3CA4FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CFFD0: BF870004
	v_mul_f32_e32 v76, v61, v77                                // 0000001CFFD4: 10989B3D
	v_mul_f32_e32 v62, v110, v107                              // 0000001CFFD8: 107CD76E
	v_add3_u32 v58, v58, v59, 0x7fff                           // 0000001CFFDC: D655003A 03FE773A 00007FFF
	v_cvt_i32_f32_e32 v59, v152                                // 0000001CFFE8: 7E761198
	v_add_f32_e32 v72, v74, v72                                // 0000001CFFEC: 0690914A
	v_add3_u32 v57, v57, v71, 0x7fff                           // 0000001CFFF0: D6550039 03FE8F39 00007FFF
	v_fma_f32 v75, -v100, v62, v110                            // 0000001CFFFC: D613004B 25BA7D64
	v_mul_f32_e32 v80, 0xbfb8aa3b, v79                         // 0000001D0004: 10A09EFF BFB8AA3B
	.long 0xd71c003b                                           // 0000001D000C: D71C003B
	v_cndmask_b32_e32 v1, v60, v59, vcc_lo                     // 0000001D0010: 0202773C
	v_fma_f32 v60, -v116, v76, v61                             // 0000001D0014: D613003C 24F69974
	v_exp_f32_e32 v71, v72                                     // 0000001D001C: 7E8E4B48
	v_fmac_f32_e32 v62, v75, v107                              // 0000001D0020: 567CD74B
	global_store_d16_hi_b16 v[15:16], v57, off offset:32       // 0000001D0024: DC960020 007C390F
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 0000001D002C: 02767680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v82                  // 0000001D0030: 7C36A4FF C2B17218
	v_fmac_f32_e32 v76, v60, v77                               // 0000001D0038: 56989B3C
	v_fma_f32 v72, -v100, v62, v110                            // 0000001D003C: D6130048 25BA7D64
	v_cvt_i32_f32_e32 v60, v73                                 // 0000001D0044: 7E781149
	global_store_d16_hi_b16 v[23:24], v58, off offset:32       // 0000001D0048: DC960020 007C3A17
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 0000001D0050: 027676FF 7F800000
	s_mov_b32 vcc_lo, s1                                       // 0000001D0058: BEEA0001
	v_fma_f32 v61, -v116, v76, v61                             // 0000001D005C: D613003D 24F69974
	v_div_fmas_f32 v62, v72, v107, v62                         // 0000001D0064: D637003E 04FAD748
	.long 0xd71c003c                                           // 0000001D006C: D71C003C
	v_cndmask_b32_e32 v1, v71, v60, vcc_lo                     // 0000001D0070: 02027947
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001D0074: 7C3CC2FF 42CE8ED0
	.long 0x7f903980                                           // 0000001D007C: 7F903980
	v_fma_f32 v82, 0xbfb8aa3b, v79, -v80                       // 0000001D0080: D6130052 85429EFF BFB8AA3B
	v_div_fixup_f32 v53, v62, v95, v53                         // 0000001D008C: D6270035 04D6BF3E
	v_rndne_f32_e32 v83, v80                                   // 0000001D0094: 7EA64750
	v_cndmask_b32_e32 v60, 0, v60, vcc_lo                      // 0000001D0098: 02787880
	s_mov_b32 vcc_lo, s0                                       // 0000001D009C: BEEA0000
	v_div_fmas_f32 v61, v61, v77, v76                          // 0000001D00A0: D637003D 05329B3D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001D00A8: 7C36C2FF C2B17218
	.long 0x7e9039b5                                           // 0000001D00B0: 7E9039B5
	v_sub_f32_e32 v80, v80, v83                                // 0000001D00B4: 08A0A750
	v_fmac_f32_e32 v82, 0xb2a5705f, v79                        // 0000001D00B8: 56A49EFF B2A5705F
	v_div_fixup_f32 v54, v61, v96, v54                         // 0000001D00C0: D6270036 04DAC13D
	v_dual_cndmask_b32 v60, 0x7f800000, v60 :: v_dual_lshlrev_b32 v61, 16, v138// 0000001D00C8: CA6278FF 3C3D1490 7F800000
	v_and_b32_e32 v72, 1, v72                                  // 0000001D00D4: 36909081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D00D8: BF870214
	v_add_f32_e32 v80, v80, v82                                // 0000001D00DC: 06A0A550
	.long 0x7e0039b6                                           // 0000001D00E0: 7E0039B6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D00E4: BF870234
	v_add_f32_e32 v60, 1.0, v60                                // 0000001D00E8: 067878F2
	v_mul_f32_e32 v62, 0xbfb8aa3b, v61                         // 0000001D00EC: 107C7AFF BFB8AA3B
	v_add3_u32 v53, v53, v72, 0x7fff                           // 0000001D00F4: D6550035 03FE9135 00007FFF
	v_and_b32_e32 v77, 1, v0                                   // 0000001D0100: 369A0081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D0104: BF870214
	v_div_scale_f32 v58, null, v60, v60, v42                   // 0000001D0108: D6FC7C3A 04AA793C
	v_fma_f32 v75, 0xbfb8aa3b, v61, -v62                       // 0000001D0110: D613004B 84FA7AFF BFB8AA3B
	v_rndne_f32_e32 v76, v62                                   // 0000001D011C: 7E98473E
	global_store_d16_hi_b16 v[31:32], v53, off offset:32       // 0000001D0120: DC960020 007C351F
	v_add3_u32 v54, v54, v77, 0x7fff                           // 0000001D0128: D6550036 03FE9B36 00007FFF
	v_rcp_f32_e32 v74, v58                                     // 0000001D0134: 7E94553A
	v_sub_f32_e32 v62, v62, v76                                // 0000001D0138: 087C993E
	v_cvt_i32_f32_e32 v76, v76                                 // 0000001D013C: 7E98114C
	global_store_d16_hi_b16 v[39:40], v54, off offset:32       // 0000001D0140: DC960020 007C3627
	v_fma_f32 v81, -v58, v74, 1.0                              // 0000001D0148: D6130051 23CA953A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D0150: BF870091
	v_dual_add_f32 v59, 1.0, v59 :: v_dual_fmac_f32 v74, v81, v74// 0000001D0154: C90076F2 3B4A9551
	v_div_scale_f32 v71, null, v59, v59, v41                   // 0000001D015C: D6FC7C47 04A6773B
	v_div_scale_f32 v81, s0, v42, v60, v42                     // 0000001D0164: D6FC0051 04AA792A
	v_fmac_f32_e32 v75, 0xb2a5705f, v61                        // 0000001D016C: 56967AFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D0174: BF870113
	v_rcp_f32_e32 v57, v71                                     // 0000001D0178: 7E725547
	v_mul_f32_e32 v84, v81, v74                                // 0000001D017C: 10A89551
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D0180: BF8701A2
	v_add_f32_e32 v62, v62, v75                                // 0000001D0184: 067C973E
	.long 0xd41e0001                                           // 0000001D0188: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v61, vcc_lo              // 0000001D018C: 02027AFF 42CE8ED0
	v_fma_f32 v72, -v58, v84, v81                              // 0000001D0194: D6130048 2546A93A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001D019C: BF870313
	v_exp_f32_e32 v62, v62                                     // 0000001D01A0: 7E7C4B3E
	v_fma_f32 v73, -v71, v57, 1.0                              // 0000001D01A4: D6130049 23CA7347
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D01AC: BF8701A2
	v_fmac_f32_e32 v84, v72, v74                               // 0000001D01B0: 56A89548
	v_cvt_i32_f32_e32 v72, v83                                 // 0000001D01B4: 7E901153
	v_fmac_f32_e32 v57, v73, v57                               // 0000001D01B8: 56727349
	v_div_scale_f32 v73, vcc_lo, v41, v59, v41                 // 0000001D01BC: D6FC6A49 04A67729
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001D01C4: BF8701B5
	.long 0xd71c003e                                           // 0000001D01C8: D71C003E
	v_cndmask_b32_e32 v1, v62, v76, vcc_lo                     // 0000001D01CC: 0202993E
	v_exp_f32_e32 v76, v80                                     // 0000001D01D0: 7E984B50
	v_fma_f32 v58, -v58, v84, v81                              // 0000001D01D4: D613003A 2546A93A
	v_mul_f32_e32 v75, v73, v57                                // 0000001D01DC: 10967349
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D01E0: BF8701A3
	v_cndmask_b32_e64 v62, 0, v62, s1                          // 0000001D01E4: D501003E 00067C80
	.long 0xd41b0001                                           // 0000001D01EC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v61, vcc_lo              // 0000001D01F0: 02027AFF C2B17218
	v_fma_f32 v77, -v71, v75, v73                              // 0000001D01F8: D613004D 25269747
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001D0200: BF870292
	v_cndmask_b32_e64 v61, 0x7f800000, v62, s1                 // 0000001D0204: D501003D 00067CFF 7F800000
	.long 0xd71c003e                                           // 0000001D0210: D71C003E
	v_cndmask_b32_e32 v1, v76, v72, vcc_lo                     // 0000001D0214: 0202914C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D0218: BF870093
	v_fmac_f32_e32 v75, v77, v57                               // 0000001D021C: 5696734D
	v_fma_f32 v71, -v71, v75, v73                              // 0000001D0220: D6130047 25269747
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D0228: BF870121
	v_div_fmas_f32 v57, v71, v57, v75                          // 0000001D022C: D6370039 052E7347
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v79                  // 0000001D0234: 7C3C9EFF 42CE8ED0
	v_div_fixup_f32 v41, v57, v59, v41                         // 0000001D023C: D6270029 04A67739
	v_cndmask_b32_e32 v62, 0, v62, vcc_lo                      // 0000001D0244: 027C7C80
	s_mov_b32 vcc_lo, s0                                       // 0000001D0248: BEEA0000
	.long 0x7f763980                                           // 0000001D024C: 7F763980
	v_div_fmas_f32 v58, v58, v74, v84                          // 0000001D0250: D637003A 0552953A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v79                  // 0000001D0258: 7C369EFF C2B17218
	v_add_f32_e32 v61, 1.0, v61                                // 0000001D0260: 067A7AF2
	.long 0x7e7639a9                                           // 0000001D0264: 7E7639A9
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D0268: BF870224
	v_div_fixup_f32 v42, v58, v60, v42                         // 0000001D026C: D627002A 04AA793A
	v_cndmask_b32_e32 v62, 0x7f800000, v62, vcc_lo             // 0000001D0274: 027C7CFF 7F800000
	v_div_scale_f32 v71, null, v61, v61, v43                   // 0000001D027C: D6FC7C47 04AE7B3D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D0284: BF870113
	.long 0x7e0039aa                                           // 0000001D0288: 7E0039AA
	v_rcp_f32_e32 v53, v71                                     // 0000001D028C: 7E6A5547
	s_waitcnt vmcnt(17)                                        // 0000001D0290: BF8947F7
	v_lshlrev_b32_e32 v60, 16, v140                            // 0000001D0294: 30791890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D0298: BF870092
	v_dual_add_f32 v58, 1.0, v62 :: v_dual_and_b32 v75, 1, v0  // 0000001D029C: C9247CF2 3A4A0081
	v_add3_u32 v42, v42, v75, 0x7fff                           // 0000001D02A4: D655002A 03FE972A 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D02B0: BF870095
	v_fma_f32 v62, -v71, v53, 1.0                              // 0000001D02B4: D613003E 23CA6B47
	v_fmac_f32_e32 v53, v62, v53                               // 0000001D02BC: 566A6B3E
	v_mul_f32_e32 v57, 0xbfb8aa3b, v60                         // 0000001D02C0: 107278FF BFB8AA3B
	v_div_scale_f32 v54, null, v58, v58, v44                   // 0000001D02C8: D6FC7C36 04B2753A
	v_div_scale_f32 v62, vcc_lo, v43, v61, v43                 // 0000001D02D0: D6FC6A3E 04AE7B2B
	.long 0xd41e0001                                           // 0000001D02D8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v60, vcc_lo              // 0000001D02DC: 020278FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D02E4: BF870214
	v_fma_f32 v73, 0xbfb8aa3b, v60, -v57                       // 0000001D02E8: D6130049 84E678FF BFB8AA3B
	v_rcp_f32_e32 v72, v54                                     // 0000001D02F4: 7E905536
	v_rndne_f32_e32 v74, v57                                   // 0000001D02F8: 7E944739
	s_waitcnt vmcnt(11)                                        // 0000001D02FC: BF892FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D0300: BF870092
	v_dual_fmac_f32 v73, 0xb2a5705f, v60 :: v_dual_lshlrev_b32 v76, 16, v139// 0000001D0304: C82278FF 494D1690 B2A5705F
	v_mul_f32_e32 v77, 0xbfb8aa3b, v76                         // 0000001D0310: 109A98FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D0318: BF8701A5
	v_fma_f32 v79, -v54, v72, 1.0                              // 0000001D031C: D613004F 23CA9136
	v_sub_f32_e32 v57, v57, v74                                // 0000001D0324: 08729539
	v_fma_f32 v80, 0xbfb8aa3b, v76, -v77                       // 0000001D0328: D6130050 853698FF BFB8AA3B
	v_and_b32_e32 v59, 1, v59                                  // 0000001D0334: 36767681
	v_rndne_f32_e32 v81, v77                                   // 0000001D0338: 7EA2474D
	v_fmac_f32_e32 v72, v79, v72                               // 0000001D033C: 5690914F
	v_div_scale_f32 v79, s0, v44, v58, v44                     // 0000001D0340: D6FC004F 04B2752C
	v_dual_add_f32 v57, v57, v73 :: v_dual_fmac_f32 v80, 0xb2a5705f, v76// 0000001D0348: C9009339 395098FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D0354: BF870224
	v_sub_f32_e32 v77, v77, v81                                // 0000001D0358: 089AA34D
	v_add3_u32 v41, v41, v59, 0x7fff                           // 0000001D035C: D6550029 03FE7729 00007FFF
	v_mul_f32_e32 v82, v79, v72                                // 0000001D0368: 10A4914F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D036C: BF870004
	v_exp_f32_e32 v57, v57                                     // 0000001D0370: 7E724B39
	v_cvt_i32_f32_e32 v74, v74                                 // 0000001D0374: 7E94114A
	v_add_f32_e32 v77, v77, v80                                // 0000001D0378: 069AA14D
	global_store_d16_hi_b16 v[7:8], v41, off offset:64         // 0000001D037C: DC960040 007C2907
	v_fma_f32 v59, -v54, v82, v79                              // 0000001D0384: D613003B 253EA536
	v_mul_f32_e32 v73, v62, v53                                // 0000001D038C: 10926B3E
	global_store_d16_hi_b16 v[47:48], v42, off offset:64       // 0000001D0390: DC960040 007C2A2F
	v_fmac_f32_e32 v82, v59, v72                               // 0000001D0398: 56A4913B
	v_fma_f32 v75, -v71, v73, v62                              // 0000001D039C: D613004B 24FA9347
	.long 0xd71c0039                                           // 0000001D03A4: D71C0039
	v_cndmask_b32_e32 v1, v57, v74, vcc_lo                     // 0000001D03A8: 02029539
	v_exp_f32_e32 v74, v77                                     // 0000001D03AC: 7E944B4D
	v_cvt_i32_f32_e32 v59, v81                                 // 0000001D03B0: 7E761151
	v_fma_f32 v54, -v54, v82, v79                              // 0000001D03B4: D6130036 253EA536
	v_fmac_f32_e32 v73, v75, v53                               // 0000001D03BC: 56926B4B
	v_cndmask_b32_e64 v57, 0, v57, s1                          // 0000001D03C0: D5010039 00067280
	.long 0xd41b0001                                           // 0000001D03C8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v60, vcc_lo              // 0000001D03CC: 020278FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001D03D4: BF870293
	v_fma_f32 v62, -v71, v73, v62                              // 0000001D03D8: D613003E 24FA9347
	.long 0xd71c003b                                           // 0000001D03E0: D71C003B
	v_cndmask_b32_e32 v1, v74, v59, vcc_lo                     // 0000001D03E4: 0202774A
	s_waitcnt vmcnt(5)                                         // 0000001D03E8: BF8917F7
	v_lshlrev_b32_e32 v74, 16, v141                            // 0000001D03EC: 30951A90
	v_cndmask_b32_e64 v57, 0x7f800000, v57, s1                 // 0000001D03F0: D5010039 000672FF 7F800000
	v_div_fmas_f32 v53, v62, v53, v73                          // 0000001D03FC: D6370035 05266B3E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v76                  // 0000001D0404: 7C3C98FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D040C: BF870194
	v_mul_f32_e32 v75, 0xbfb8aa3b, v74                         // 0000001D0410: 109694FF BFB8AA3B
	v_div_fixup_f32 v43, v53, v61, v43                         // 0000001D0418: D627002B 04AE7B35
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 0000001D0420: 02767680
	s_mov_b32 vcc_lo, s0                                       // 0000001D0424: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001D0428: BF8701B3
	v_fma_f32 v77, 0xbfb8aa3b, v74, -v75                       // 0000001D042C: D613004D 852E94FF BFB8AA3B
	v_div_fmas_f32 v54, v54, v72, v82                          // 0000001D0438: D6370036 054A9136
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v76                  // 0000001D0440: 7C3698FF C2B17218
	v_fmac_f32_e32 v77, 0xb2a5705f, v74                        // 0000001D0448: 569A94FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D0450: BF870003
	v_div_fixup_f32 v41, v54, v58, v44                         // 0000001D0454: D6270029 04B27536
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 0000001D045C: 027676FF 7F800000
	v_mul_f32_e32 v44, v46, v51                                // 0000001D0464: 1058672E
	v_lshlrev_b32_e32 v58, 16, v78                             // 0000001D0468: 30749C90
	v_rndne_f32_e32 v78, v75                                   // 0000001D046C: 7E9C474B
	.long 0x7e0039a9                                           // 0000001D0470: 7E0039A9
	v_add_f32_e32 v54, 1.0, v59                                // 0000001D0474: 066C76F2
	.long 0x7e7639ab                                           // 0000001D0478: 7E7639AB
	v_mul_f32_e32 v53, 0xbfb8aa3b, v58                         // 0000001D047C: 106A74FF BFB8AA3B
	.long 0x7f763980                                           // 0000001D0484: 7F763980
	v_sub_f32_e32 v75, v75, v78                                // 0000001D0488: 08969D4B
	v_div_scale_f32 v42, null, v54, v54, v44                   // 0000001D048C: D6FC7C2A 04B26D36
	.long 0xd41e0001                                           // 0000001D0494: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v58, vcc_lo              // 0000001D0498: 020274FF 42CE8ED0
	v_fma_f32 v71, 0xbfb8aa3b, v58, -v53                       // 0000001D04A0: D6130047 84D674FF BFB8AA3B
	v_rndne_f32_e32 v72, v53                                   // 0000001D04AC: 7E904735
	v_and_b32_e32 v59, 1, v59                                  // 0000001D04B0: 36767681
	v_rcp_f32_e32 v62, v42                                     // 0000001D04B4: 7E7C552A
	v_add_f32_e32 v75, v75, v77                                // 0000001D04B8: 06969B4B
	v_fmac_f32_e32 v71, 0xb2a5705f, v58                        // 0000001D04BC: 568E74FF B2A5705F
	v_sub_f32_e32 v53, v53, v72                                // 0000001D04C4: 086A9135
	v_cvt_i32_f32_e32 v72, v72                                 // 0000001D04C8: 7E901148
	v_add3_u32 v43, v43, v59, 0x7fff                           // 0000001D04CC: D655002B 03FE772B 00007FFF
	v_and_b32_e32 v73, 1, v0                                   // 0000001D04D8: 36920081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001D04DC: BF870294
	v_add_f32_e32 v53, v53, v71                                // 0000001D04E0: 066A8F35
	v_fma_f32 v76, -v42, v62, 1.0                              // 0000001D04E4: D613004C 23CA7D2A
	v_mul_f32_e32 v45, v45, v52                                // 0000001D04EC: 105A692D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D04F0: BF870214
	v_add3_u32 v41, v41, v73, 0x7fff                           // 0000001D04F4: D6550029 03FE9329 00007FFF
	v_exp_f32_e32 v53, v53                                     // 0000001D0500: 7E6A4B35
	global_store_d16_hi_b16 v[15:16], v43, off offset:64       // 0000001D0504: DC960040 007C2B0F
	v_fmac_f32_e32 v62, v76, v62                               // 0000001D050C: 567C7D4C
	v_div_scale_f32 v76, s0, v44, v54, v44                     // 0000001D0510: D6FC004C 04B26D2C
	global_store_d16_hi_b16 v[23:24], v41, off offset:64       // 0000001D0518: DC960040 007C2917
	v_mul_f32_e32 v79, v76, v62                                // 0000001D0520: 109E7D4C
	.long 0xd71c0035                                           // 0000001D0524: D71C0035
	v_cndmask_b32_e32 v1, v53, v72, vcc_lo                     // 0000001D0528: 02029135
	v_exp_f32_e32 v72, v75                                     // 0000001D052C: 7E904B4B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D0530: BF870112
	v_fma_f32 v59, -v42, v79, v76                              // 0000001D0534: D613003B 25329F2A
	v_cndmask_b32_e64 v53, 0, v53, s1                          // 0000001D053C: D5010035 00066A80
	.long 0xd41b0001                                           // 0000001D0544: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v58, vcc_lo              // 0000001D0548: 020274FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D0550: BF8701A3
	v_fmac_f32_e32 v79, v59, v62                               // 0000001D0554: 569E7D3B
	v_cvt_i32_f32_e32 v59, v78                                 // 0000001D0558: 7E76114E
	v_cndmask_b32_e64 v53, 0x7f800000, v53, s1                 // 0000001D055C: D5010035 00066AFF 7F800000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D0568: BF870003
	v_fma_f32 v42, -v42, v79, v76                              // 0000001D056C: D613002A 25329F2A
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001D0574: BF870185
	.long 0xd71c003a                                           // 0000001D0578: D71C003A
	v_cndmask_b32_e32 v1, v72, v59, vcc_lo                     // 0000001D057C: 02027748
	v_dual_add_f32 v57, 1.0, v57 :: v_dual_lshlrev_b32 v72, 16, v132// 0000001D0580: C92272F2 39490890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D0588: BF870091
	v_div_scale_f32 v60, null, v57, v57, v45                   // 0000001D058C: D6FC7C3C 04B67339
	v_rcp_f32_e32 v46, v60                                     // 0000001D0594: 7E5C553C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D0598: BF870095
	v_fma_f32 v61, -v60, v46, 1.0                              // 0000001D059C: D613003D 23CA5D3C
	v_fmac_f32_e32 v46, v61, v46                               // 0000001D05A4: 565C5D3D
	v_div_scale_f32 v61, vcc_lo, v45, v57, v45                 // 0000001D05A8: D6FC6A3D 04B6732D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D05B0: BF870091
	v_mul_f32_e32 v71, v61, v46                                // 0000001D05B4: 108E5D3D
	v_fma_f32 v73, -v60, v71, v61                              // 0000001D05B8: D6130049 24F68F3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D05C0: BF870121
	v_fmac_f32_e32 v71, v73, v46                               // 0000001D05C4: 568E5D49
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000001D05C8: 109290FF BFB8AA3B
	v_fma_f32 v60, -v60, v71, v61                              // 0000001D05D0: D613003C 24F68F3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D05D8: BF8701A2
	v_fma_f32 v75, 0xbfb8aa3b, v72, -v73                       // 0000001D05DC: D613004B 852690FF BFB8AA3B
	v_rndne_f32_e32 v76, v73                                   // 0000001D05E8: 7E984749
	v_div_fmas_f32 v46, v60, v46, v71                          // 0000001D05EC: D637002E 051E5D3C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v74                  // 0000001D05F4: 7C3C94FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D05FC: BF870214
	v_fmac_f32_e32 v75, 0xb2a5705f, v72                        // 0000001D0600: 569690FF B2A5705F
	v_dual_sub_f32 v73, v73, v76 :: v_dual_cndmask_b32 v58, 0, v58// 0000001D0608: C9529949 493A7480
	s_mov_b32 vcc_lo, s0                                       // 0000001D0610: BEEA0000
	v_div_fixup_f32 v45, v46, v57, v45                         // 0000001D0614: D627002D 04B6732E
	v_div_fmas_f32 v42, v42, v62, v79                          // 0000001D061C: D637002A 053E7D2A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v74                  // 0000001D0624: 7C3694FF C2B17218
	.long 0x7f723980                                           // 0000001D062C: 7F723980
	v_add_f32_e32 v73, v73, v75                                // 0000001D0630: 06929749
	.long 0x7e7239ad                                           // 0000001D0634: 7E7239AD
	v_div_fixup_f32 v42, v42, v54, v44                         // 0000001D0638: D627002A 04B26D2A
	v_cndmask_b32_e32 v58, 0x7f800000, v58, vcc_lo             // 0000001D0640: 027474FF 7F800000
	v_lshlrev_b32_e32 v54, 16, v133                            // 0000001D0648: 306D0A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D064C: BF870214
	v_and_b32_e32 v57, 1, v57                                  // 0000001D0650: 36727281
	.long 0x7e0039aa                                           // 0000001D0654: 7E0039AA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D0658: BF870214
	v_add_f32_e32 v44, 1.0, v58                                // 0000001D065C: 065874F2
	v_mul_f32_e32 v46, 0xbfb8aa3b, v54                         // 0000001D0660: 105C6CFF BFB8AA3B
	.long 0xd41e0001                                           // 0000001D0668: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v54, vcc_lo              // 0000001D066C: 02026CFF 42CE8ED0
	v_add3_u32 v45, v45, v57, 0x7fff                           // 0000001D0674: D655002D 03FE732D 00007FFF
	v_and_b32_e32 v71, 1, v0                                   // 0000001D0680: 368E0081
	v_div_scale_f32 v41, null, v44, v44, v34                   // 0000001D0684: D6FC7C29 048A592C
	v_fma_f32 v61, 0xbfb8aa3b, v54, -v46                       // 0000001D068C: D613003D 84BA6CFF BFB8AA3B
	v_rndne_f32_e32 v62, v46                                   // 0000001D0698: 7E7C472E
	global_store_d16_hi_b16 v[31:32], v45, off offset:64       // 0000001D069C: DC960040 007C2D1F
	v_add3_u32 v42, v42, v71, 0x7fff                           // 0000001D06A4: D655002A 03FE8F2A 00007FFF
	v_rcp_f32_e32 v60, v41                                     // 0000001D06B0: 7E785529
	v_fmac_f32_e32 v61, 0xb2a5705f, v54                        // 0000001D06B4: 567A6CFF B2A5705F
	v_sub_f32_e32 v46, v46, v62                                // 0000001D06BC: 085C7D2E
	v_cvt_i32_f32_e32 v62, v62                                 // 0000001D06C0: 7E7C113E
	v_lshlrev_b32_e32 v45, 16, v135                            // 0000001D06C4: 305B0E90
	global_store_d16_hi_b16 v[39:40], v42, off offset:64       // 0000001D06C8: DC960040 007C2A27
	v_add_f32_e32 v46, v46, v61                                // 0000001D06D0: 065C7B2E
	v_fma_f32 v74, -v41, v60, 1.0                              // 0000001D06D4: D613004A 23CA7929
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D06DC: BF870092
	v_exp_f32_e32 v46, v46                                     // 0000001D06E0: 7E5C4B2E
	v_fmac_f32_e32 v60, v74, v60                               // 0000001D06E4: 5678794A
	v_div_scale_f32 v74, s0, v34, v44, v34                     // 0000001D06E8: D6FC004A 048A5922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001D06F0: BF870291
	v_mul_f32_e32 v77, v74, v60                                // 0000001D06F4: 109A794A
	.long 0xd71c002e                                           // 0000001D06F8: D71C002E
	v_cndmask_b32_e32 v1, v46, v62, vcc_lo                     // 0000001D06FC: 02027D2E
	v_exp_f32_e32 v62, v73                                     // 0000001D0700: 7E7C4B49
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D0704: BF870112
	v_fma_f32 v57, -v41, v77, v74                              // 0000001D0708: D6130039 252A9B29
	v_cndmask_b32_e64 v46, 0, v46, s1                          // 0000001D0710: D501002E 00065C80
	.long 0xd41b0001                                           // 0000001D0718: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v54, vcc_lo              // 0000001D071C: 02026CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D0724: BF8701A3
	v_fmac_f32_e32 v77, v57, v60                               // 0000001D0728: 569A7939
	v_cvt_i32_f32_e32 v57, v76                                 // 0000001D072C: 7E72114C
	v_cndmask_b32_e64 v46, 0x7f800000, v46, s1                 // 0000001D0730: D501002E 00065CFF 7F800000
	.long 0xd41e0001                                           // 0000001D073C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v45, vcc_lo              // 0000001D0740: 02025AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D0748: BF870004
	v_fma_f32 v41, -v41, v77, v74                              // 0000001D074C: D6130029 252A9B29
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 0000001D0754: BF870205
	.long 0xd71c0036                                           // 0000001D0758: D71C0036
	v_cndmask_b32_e32 v1, v62, v57, vcc_lo                     // 0000001D075C: 0202733E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D0760: BF870124
	v_dual_add_f32 v53, 1.0, v53 :: v_dual_add_f32 v46, 1.0, v46// 0000001D0764: C9086AF2 352E5CF2
	v_lshlrev_b32_e32 v62, 16, v134                            // 0000001D076C: 307D0C90
	v_div_scale_f32 v59, null, v53, v53, v33                   // 0000001D0770: D6FC7C3B 04866B35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D0778: BF870113
	v_div_scale_f32 v57, null, v46, v46, v35                   // 0000001D077C: D6FC7C39 048E5D2E
	v_rcp_f32_e32 v43, v59                                     // 0000001D0784: 7E56553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D0788: BF870095
	v_fma_f32 v58, -v59, v43, 1.0                              // 0000001D078C: D613003A 23CA573B
	v_fmac_f32_e32 v43, v58, v43                               // 0000001D0794: 5656573A
	v_div_scale_f32 v58, vcc_lo, v33, v53, v33                 // 0000001D0798: D6FC6A3A 04866B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001D07A0: BF870091
	v_mul_f32_e32 v61, v58, v43                                // 0000001D07A4: 107A573A
	v_fma_f32 v71, -v59, v61, v58                              // 0000001D07A8: D6130047 24EA7B3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D07B0: BF870121
	v_fmac_f32_e32 v61, v71, v43                               // 0000001D07B4: 567A5747
	v_mul_f32_e32 v71, 0xbfb8aa3b, v62                         // 0000001D07B8: 108E7CFF BFB8AA3B
	v_fma_f32 v58, -v59, v61, v58                              // 0000001D07C0: D613003A 24EA7B3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D07C8: BF8701A2
	v_fma_f32 v73, 0xbfb8aa3b, v62, -v71                       // 0000001D07CC: D6130049 851E7CFF BFB8AA3B
	v_rndne_f32_e32 v74, v71                                   // 0000001D07D8: 7E944747
	v_div_fmas_f32 v43, v58, v43, v61                          // 0000001D07DC: D637002B 04F6573A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000001D07E4: 7C3C90FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D07EC: BF870214
	v_fmac_f32_e32 v73, 0xb2a5705f, v62                        // 0000001D07F0: 56927CFF B2A5705F
	v_sub_f32_e32 v71, v71, v74                                // 0000001D07F8: 088E9547
	v_cndmask_b32_e32 v54, 0, v54, vcc_lo                      // 0000001D07FC: 026C6C80
	s_mov_b32 vcc_lo, s0                                       // 0000001D0800: BEEA0000
	v_div_fixup_f32 v33, v43, v53, v33                         // 0000001D0804: D6270021 04866B2B
	v_div_fmas_f32 v41, v41, v60, v77                          // 0000001D080C: D6370029 05367929
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000001D0814: 7C3690FF C2B17218
	v_mul_f32_e32 v43, 0xbfb8aa3b, v45                         // 0000001D081C: 10565AFF BFB8AA3B
	.long 0x7f6a3980                                           // 0000001D0824: 7F6A3980
	.long 0x7e6a39a1                                           // 0000001D0828: 7E6A39A1
	v_div_fixup_f32 v34, v41, v44, v34                         // 0000001D082C: D6270022 048A5929
	v_cndmask_b32_e32 v54, 0x7f800000, v54, vcc_lo             // 0000001D0834: 026C6CFF 7F800000
	v_rcp_f32_e32 v41, v57                                     // 0000001D083C: 7E525539
	v_fma_f32 v59, 0xbfb8aa3b, v45, -v43                       // 0000001D0840: D613003B 84AE5AFF BFB8AA3B
	v_rndne_f32_e32 v60, v43                                   // 0000001D084C: 7E78472B
	.long 0x7e0039a2                                           // 0000001D0850: 7E0039A2
	v_dual_add_f32 v44, 1.0, v54 :: v_dual_and_b32 v53, 1, v53 // 0000001D0854: C9246CF2 2C346A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D085C: BF870214
	v_fmac_f32_e32 v59, 0xb2a5705f, v45                        // 0000001D0860: 56765AFF B2A5705F
	v_sub_f32_e32 v43, v43, v60                                // 0000001D0868: 0856792B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D086C: BF870214
	v_and_b32_e32 v61, 1, v0                                   // 0000001D0870: 367A0081
	v_div_scale_f32 v42, null, v44, v44, v36                   // 0000001D0874: D6FC7C2A 0492592C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001D087C: BF870005
	v_fma_f32 v54, -v57, v41, 1.0                              // 0000001D0880: D6130036 23CA5339
	v_cvt_i32_f32_e32 v60, v60                                 // 0000001D0888: 7E78113C
	v_add_f32_e32 v43, v43, v59                                // 0000001D088C: 0656772B
	v_add3_u32 v34, v34, v61, 0x7fff                           // 0000001D0890: D6550022 03FE7B22 00007FFF
	v_rcp_f32_e32 v58, v42                                     // 0000001D089C: 7E74552A
	v_fmac_f32_e32 v41, v54, v41                               // 0000001D08A0: 56525336
	v_div_scale_f32 v54, vcc_lo, v35, v46, v35                 // 0000001D08A4: D6FC6A36 048E5D23
	v_exp_f32_e32 v43, v43                                     // 0000001D08AC: 7E564B2B
	v_add_f32_e32 v71, v71, v73                                // 0000001D08B0: 068E9347
	v_add3_u32 v33, v33, v53, 0x7fff                           // 0000001D08B4: D6550021 03FE6B21 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001D08C0: BF870313
	v_mul_f32_e32 v59, v54, v41                                // 0000001D08C4: 10765336
	v_fma_f32 v72, -v42, v58, 1.0                              // 0000001D08C8: D6130048 23CA752A
	global_store_d16_hi_b16 v[7:8], v33, off offset:96         // 0000001D08D0: DC960060 007C2107
	v_fma_f32 v61, -v57, v59, v54                              // 0000001D08D8: D613003D 24DA7739
	.long 0xd71c002b                                           // 0000001D08E0: D71C002B
	v_cndmask_b32_e32 v1, v43, v60, vcc_lo                     // 0000001D08E4: 0202792B
	v_exp_f32_e32 v60, v71                                     // 0000001D08E8: 7E784B47
	v_fmac_f32_e32 v58, v72, v58                               // 0000001D08EC: 56747548
	v_div_scale_f32 v72, s0, v36, v44, v36                     // 0000001D08F0: D6FC0048 04925924
	v_fmac_f32_e32 v59, v61, v41                               // 0000001D08F8: 5676533D
	v_cndmask_b32_e64 v43, 0, v43, s1                          // 0000001D08FC: D501002B 00065680
	.long 0xd41b0001                                           // 0000001D0904: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v45, vcc_lo              // 0000001D0908: 02025AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v34, off offset:96       // 0000001D0910: DC960060 007C222F
	v_mul_f32_e32 v75, v72, v58                                // 0000001D0918: 10967548
	v_fma_f32 v54, -v57, v59, v54                              // 0000001D091C: D6130036 24DA7739
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 0000001D0924: D501002B 000656FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D0930: BF870193
	v_fma_f32 v53, -v42, v75, v72                              // 0000001D0934: D6130035 2522972A
	v_div_fmas_f32 v41, v54, v41, v59                          // 0000001D093C: D6370029 04EE5336
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v62                  // 0000001D0944: 7C3C7CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D094C: BF870214
	v_add_f32_e32 v43, 1.0, v43                                // 0000001D0950: 065656F2
	v_fmac_f32_e32 v75, v53, v58                               // 0000001D0954: 56967535
	v_cvt_i32_f32_e32 v53, v74                                 // 0000001D0958: 7E6A114A
	v_div_fixup_f32 v35, v41, v46, v35                         // 0000001D095C: D6270023 048E5D29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D0964: BF870193
	v_fma_f32 v42, -v42, v75, v72                              // 0000001D0968: D613002A 2522972A
	.long 0xd71c002d                                           // 0000001D0970: D71C002D
	v_cndmask_b32_e32 v1, v60, v53, vcc_lo                     // 0000001D0974: 02026B3C
	v_div_scale_f32 v53, null, v43, v43, v37                   // 0000001D0978: D6FC7C35 0496572B
	s_waitcnt vmcnt(4)                                         // 0000001D0980: BF8913F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D0984: BF8700A2
	v_dual_cndmask_b32 v45, 0, v45 :: v_dual_lshlrev_b32 v60, 16, v136// 0000001D0988: CA625A80 2D3D1090
	s_mov_b32 vcc_lo, s0                                       // 0000001D0990: BEEA0000
	v_mul_f32_e32 v61, 0xbfb8aa3b, v60                         // 0000001D0994: 107A78FF BFB8AA3B
	v_div_fmas_f32 v42, v42, v58, v75                          // 0000001D099C: D637002A 052E752A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v62                  // 0000001D09A4: 7C367CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D09AC: BF870193
	v_fma_f32 v71, 0xbfb8aa3b, v60, -v61                       // 0000001D09B0: D6130047 84F678FF BFB8AA3B
	v_div_fixup_f32 v33, v42, v44, v36                         // 0000001D09BC: D6270021 0492592A
	v_dual_cndmask_b32 v45, 0x7f800000, v45 :: v_dual_mul_f32 v36, v38, v51// 0000001D09C4: CA465AFF 2D246726 7F800000
	v_lshlrev_b32_e32 v44, 16, v86                             // 0000001D09D0: 3058AC90
	v_rcp_f32_e32 v38, v53                                     // 0000001D09D4: 7E4C5535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D09D8: BF870193
	.long 0x7e0039a1                                           // 0000001D09DC: 7E0039A1
	v_add_f32_e32 v42, 1.0, v45                                // 0000001D09E0: 06545AF2
	v_rndne_f32_e32 v72, v61                                   // 0000001D09E4: 7E90473D
	v_mul_f32_e32 v41, 0xbfb8aa3b, v44                         // 0000001D09E8: 105258FF BFB8AA3B
	.long 0x7e5a39a3                                           // 0000001D09F0: 7E5A39A3
	.long 0x7f5a3980                                           // 0000001D09F4: 7F5A3980
	v_div_scale_f32 v34, null, v42, v42, v36                   // 0000001D09F8: D6FC7C22 0492552A
	v_and_b32_e32 v59, 1, v0                                   // 0000001D0A00: 36760081
	v_fma_f32 v57, 0xbfb8aa3b, v44, -v41                       // 0000001D0A04: D6130039 84A658FF BFB8AA3B
	v_rndne_f32_e32 v58, v41                                   // 0000001D0A10: 7E744729
	v_fma_f32 v46, -v53, v38, 1.0                              // 0000001D0A14: D613002E 23CA4D35
	v_rcp_f32_e32 v54, v34                                     // 0000001D0A1C: 7E6C5522
	v_fmac_f32_e32 v71, 0xb2a5705f, v60                        // 0000001D0A20: 568E78FF B2A5705F
	v_fmac_f32_e32 v57, 0xb2a5705f, v44                        // 0000001D0A28: 567258FF B2A5705F
	v_sub_f32_e32 v41, v41, v58                                // 0000001D0A30: 08527529
	v_fmac_f32_e32 v38, v46, v38                               // 0000001D0A34: 564C4D2E
	v_div_scale_f32 v46, vcc_lo, v37, v43, v37                 // 0000001D0A38: D6FC6A2E 04965725
	v_sub_f32_e32 v61, v61, v72                                // 0000001D0A40: 087A913D
	v_and_b32_e32 v45, 1, v45                                  // 0000001D0A44: 365A5A81
	v_add_f32_e32 v41, v41, v57                                // 0000001D0A48: 06527329
	v_add3_u32 v33, v33, v59, 0x7fff                           // 0000001D0A4C: D6550021 03FE7721 00007FFF
	v_fma_f32 v62, -v34, v54, 1.0                              // 0000001D0A58: D613003E 23CA6D22
	v_mul_f32_e32 v57, v46, v38                                // 0000001D0A60: 10724D2E
	v_cvt_i32_f32_e32 v58, v58                                 // 0000001D0A64: 7E74113A
	v_exp_f32_e32 v41, v41                                     // 0000001D0A68: 7E524B29
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001D0A6C: BF870253
	v_dual_add_f32 v61, v61, v71 :: v_dual_fmac_f32 v54, v62, v54// 0000001D0A70: C9008F3D 3D366D3E
	v_div_scale_f32 v62, s0, v36, v42, v36                     // 0000001D0A78: D6FC003E 04925524
	v_fma_f32 v59, -v53, v57, v46                              // 0000001D0A80: D613003B 24BA7335
	v_add3_u32 v35, v35, v45, 0x7fff                           // 0000001D0A88: D6550023 03FE5B23 00007FFF
	.long 0xd41e0001                                           // 0000001D0A94: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v44, vcc_lo              // 0000001D0A98: 020258FF 42CE8ED0
	v_mul_f32_e32 v73, v62, v54                                // 0000001D0AA0: 10926D3E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001D0AA4: BF870294
	v_fmac_f32_e32 v57, v59, v38                               // 0000001D0AA8: 56724D3B
	.long 0xd71c0029                                           // 0000001D0AAC: D71C0029
	v_cndmask_b32_e32 v1, v41, v58, vcc_lo                     // 0000001D0AB0: 02027529
	v_exp_f32_e32 v58, v61                                     // 0000001D0AB4: 7E744B3D
	global_store_d16_hi_b16 v[15:16], v35, off offset:96       // 0000001D0AB8: DC960060 007C230F
	v_fma_f32 v45, -v34, v73, v62                              // 0000001D0AC0: D613002D 24FA9322
	v_fma_f32 v46, -v53, v57, v46                              // 0000001D0AC8: D613002E 24BA7335
	v_cndmask_b32_e64 v41, 0, v41, s1                          // 0000001D0AD0: D5010029 00065280
	.long 0xd41b0001                                           // 0000001D0AD8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v44, vcc_lo              // 0000001D0ADC: 020258FF C2B17218
	global_store_d16_hi_b16 v[23:24], v33, off offset:96       // 0000001D0AE4: DC960060 007C2117
	v_fmac_f32_e32 v73, v45, v54                               // 0000001D0AEC: 56926D2D
	v_cvt_i32_f32_e32 v45, v72                                 // 0000001D0AF0: 7E5A1148
	v_div_fmas_f32 v38, v46, v38, v57                          // 0000001D0AF4: D6370026 04E64D2E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v60                  // 0000001D0AFC: 7C3C78FF 42CE8ED0
	v_cndmask_b32_e64 v41, 0x7f800000, v41, s1                 // 0000001D0B04: D5010029 000652FF 7F800000
	v_fma_f32 v34, -v34, v73, v62                              // 0000001D0B10: D6130022 24FA9322
	.long 0xd71c002c                                           // 0000001D0B18: D71C002C
	v_cndmask_b32_e32 v1, v58, v45, vcc_lo                     // 0000001D0B1C: 02025B3A
	v_div_fixup_f32 v37, v38, v43, v37                         // 0000001D0B20: D6270025 04965726
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D0B28: BF870224
	v_dual_add_f32 v41, 1.0, v41 :: v_dual_lshlrev_b32 v58, 16, v127// 0000001D0B2C: C92252F2 293AFE90
	.long 0x7f563980                                           // 0000001D0B34: 7F563980
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 0000001D0B38: 02585880
	s_mov_b32 vcc_lo, s0                                       // 0000001D0B3C: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D0B40: BF870003
	v_mul_f32_e32 v59, 0xbfb8aa3b, v58                         // 0000001D0B44: 107674FF BFB8AA3B
	v_div_fmas_f32 v34, v34, v54, v73                          // 0000001D0B4C: D6370022 05266D22
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v60                  // 0000001D0B54: 7C3678FF C2B17218
	v_div_scale_f32 v45, null, v41, v41, v25                   // 0000001D0B5C: D6FC7C2D 04665329
	.long 0x7e5639a5                                           // 0000001D0B64: 7E5639A5
	v_fma_f32 v61, 0xbfb8aa3b, v58, -v59                       // 0000001D0B68: D613003D 84EE74FF BFB8AA3B
	v_div_fixup_f32 v34, v34, v42, v36                         // 0000001D0B74: D6270022 04925522
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo             // 0000001D0B7C: 025858FF 7F800000
	v_lshlrev_b32_e32 v42, 16, v128                            // 0000001D0B84: 30550090
	v_rcp_f32_e32 v35, v45                                     // 0000001D0B88: 7E46552D
	v_rndne_f32_e32 v62, v59                                   // 0000001D0B8C: 7E7C473B
	.long 0x7e0039a2                                           // 0000001D0B90: 7E0039A2
	v_add_f32_e32 v36, 1.0, v44                                // 0000001D0B94: 064858F2
	v_mul_f32_e32 v38, 0xbfb8aa3b, v42                         // 0000001D0B98: 104C54FF BFB8AA3B
	v_fmac_f32_e32 v61, 0xb2a5705f, v58                        // 0000001D0BA0: 567A74FF B2A5705F
	v_sub_f32_e32 v59, v59, v62                                // 0000001D0BA8: 08767D3B
	v_and_b32_e32 v57, 1, v0                                   // 0000001D0BAC: 36720081
	v_div_scale_f32 v33, null, v36, v36, v26                   // 0000001D0BB0: D6FC7C21 046A4924
	v_fma_f32 v53, 0xbfb8aa3b, v42, -v38                       // 0000001D0BB8: D6130035 849A54FF BFB8AA3B
	v_rndne_f32_e32 v54, v38                                   // 0000001D0BC4: 7E6C4726
	v_fma_f32 v44, -v45, v35, 1.0                              // 0000001D0BC8: D613002C 23CA472D
	v_and_b32_e32 v43, 1, v43                                  // 0000001D0BD0: 36565681
	v_rcp_f32_e32 v46, v33                                     // 0000001D0BD4: 7E5C5521
	v_fmac_f32_e32 v53, 0xb2a5705f, v42                        // 0000001D0BD8: 566A54FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001D0BE0: BF870243
	v_dual_sub_f32 v38, v38, v54 :: v_dual_fmac_f32 v35, v44, v35// 0000001D0BE4: C9406D26 2622472C
	v_div_scale_f32 v44, vcc_lo, v25, v41, v25                 // 0000001D0BEC: D6FC6A2C 04665319
	v_add3_u32 v34, v34, v57, 0x7fff                           // 0000001D0BF4: D6550022 03FE7322 00007FFF
	v_cvt_i32_f32_e32 v54, v54                                 // 0000001D0C00: 7E6C1136
	v_add_f32_e32 v38, v38, v53                                // 0000001D0C04: 064C6B26
	v_add_f32_e32 v59, v59, v61                                // 0000001D0C08: 06767B3B
	v_mul_f32_e32 v53, v44, v35                                // 0000001D0C0C: 106A472C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001D0C10: BF870005
	v_fma_f32 v60, -v33, v46, 1.0                              // 0000001D0C14: D613003C 23CA5D21
	v_add3_u32 v37, v37, v43, 0x7fff                           // 0000001D0C1C: D6550025 03FE5725 00007FFF
	v_exp_f32_e32 v38, v38                                     // 0000001D0C28: 7E4C4B26
	.long 0xd41e0001                                           // 0000001D0C2C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v42, vcc_lo              // 0000001D0C30: 020254FF 42CE8ED0
	v_fma_f32 v57, -v45, v53, v44                              // 0000001D0C38: D6130039 24B26B2D
	v_fmac_f32_e32 v46, v60, v46                               // 0000001D0C40: 565C5D3C
	v_div_scale_f32 v60, s0, v26, v36, v26                     // 0000001D0C44: D6FC003C 046A491A
	global_store_d16_hi_b16 v[31:32], v37, off offset:96       // 0000001D0C4C: DC960060 007C251F
	v_lshlrev_b32_e32 v37, 16, v130                            // 0000001D0C54: 304B0490
	v_fmac_f32_e32 v53, v57, v35                               // 0000001D0C58: 566A4739
	global_store_d16_hi_b16 v[39:40], v34, off offset:96       // 0000001D0C5C: DC960060 007C2227
	v_mul_f32_e32 v71, v60, v46                                // 0000001D0C64: 108E5D3C
	.long 0xd71c0026                                           // 0000001D0C68: D71C0026
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 0000001D0C6C: 02026D26
	v_exp_f32_e32 v54, v59                                     // 0000001D0C70: 7E6C4B3B
	v_fma_f32 v44, -v45, v53, v44                              // 0000001D0C74: D613002C 24B26B2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D0C7C: BF870193
	v_fma_f32 v43, -v33, v71, v60                              // 0000001D0C80: D613002B 24F28F21
	v_cndmask_b32_e64 v38, 0, v38, s1                          // 0000001D0C88: D5010026 00064C80
	.long 0xd41b0001                                           // 0000001D0C90: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v42, vcc_lo              // 0000001D0C94: 020254FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D0C9C: BF870004
	v_div_fmas_f32 v35, v44, v35, v53                          // 0000001D0CA0: D6370023 04D6472C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v58                  // 0000001D0CA8: 7C3C74FF 42CE8ED0
	v_fmac_f32_e32 v71, v43, v46                               // 0000001D0CB0: 568E5D2B
	v_cvt_i32_f32_e32 v43, v62                                 // 0000001D0CB4: 7E56113E
	v_cndmask_b32_e64 v38, 0x7f800000, v38, s1                 // 0000001D0CB8: D5010026 00064CFF 7F800000
	v_div_fixup_f32 v25, v35, v41, v25                         // 0000001D0CC4: D6270019 04665323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v37                         // 0000001D0CCC: 10464AFF BFB8AA3B
	v_fma_f32 v33, -v33, v71, v60                              // 0000001D0CD4: D6130021 24F28F21
	.long 0xd71c002a                                           // 0000001D0CDC: D71C002A
	v_cndmask_b32_e32 v1, v54, v43, vcc_lo                     // 0000001D0CE0: 02025736
	v_add_f32_e32 v38, 1.0, v38                                // 0000001D0CE4: 064C4CF2
	v_lshlrev_b32_e32 v54, 16, v129                            // 0000001D0CE8: 306D0290
	v_fma_f32 v45, 0xbfb8aa3b, v37, -v35                       // 0000001D0CEC: D613002D 848E4AFF BFB8AA3B
	.long 0x7e523999                                           // 0000001D0CF8: 7E523999
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000001D0CFC: 02545480
	s_mov_b32 vcc_lo, s0                                       // 0000001D0D00: BEEA0000
	v_div_scale_f32 v43, null, v38, v38, v27                   // 0000001D0D04: D6FC7C2B 046E4D26
	v_div_fmas_f32 v33, v33, v46, v71                          // 0000001D0D0C: D6370021 051E5D21
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v58                  // 0000001D0D14: 7C3674FF C2B17218
	v_rndne_f32_e32 v46, v35                                   // 0000001D0D1C: 7E5C4723
	v_fmac_f32_e32 v45, 0xb2a5705f, v37                        // 0000001D0D20: 565A4AFF B2A5705F
	v_mul_f32_e32 v57, 0xbfb8aa3b, v54                         // 0000001D0D28: 10726CFF BFB8AA3B
	v_div_fixup_f32 v26, v33, v36, v26                         // 0000001D0D30: D627001A 046A4921
	v_cndmask_b32_e32 v42, 0x7f800000, v42, vcc_lo             // 0000001D0D38: 025454FF 7F800000
	v_rcp_f32_e32 v33, v43                                     // 0000001D0D40: 7E42552B
	v_sub_f32_e32 v35, v35, v46                                // 0000001D0D44: 08465D23
	v_fma_f32 v59, 0xbfb8aa3b, v54, -v57                       // 0000001D0D48: D613003B 84E66CFF BFB8AA3B
	.long 0x7e00399a                                           // 0000001D0D54: 7E00399A
	v_add_f32_e32 v36, 1.0, v42                                // 0000001D0D58: 064854F2
	v_rndne_f32_e32 v60, v57                                   // 0000001D0D5C: 7E784739
	v_add_f32_e32 v35, v35, v45                                // 0000001D0D60: 06465B23
	.long 0x7f523980                                           // 0000001D0D64: 7F523980
	v_and_b32_e32 v53, 1, v0                                   // 0000001D0D68: 366A0081
	v_div_scale_f32 v34, null, v36, v36, v28                   // 0000001D0D6C: D6FC7C22 04724924
	v_fma_f32 v42, -v43, v33, 1.0                              // 0000001D0D74: D613002A 23CA432B
	v_exp_f32_e32 v35, v35                                     // 0000001D0D7C: 7E464B23
	v_fmac_f32_e32 v59, 0xb2a5705f, v54                        // 0000001D0D80: 56766CFF B2A5705F
	v_sub_f32_e32 v57, v57, v60                                // 0000001D0D88: 08727939
	v_rcp_f32_e32 v44, v34                                     // 0000001D0D8C: 7E585522
	v_fmac_f32_e32 v33, v42, v33                               // 0000001D0D90: 5642432A
	v_div_scale_f32 v42, vcc_lo, v27, v38, v27                 // 0000001D0D94: D6FC6A2A 046E4D1B
	v_and_b32_e32 v41, 1, v41                                  // 0000001D0D9C: 36525281
	v_add3_u32 v26, v26, v53, 0x7fff                           // 0000001D0DA0: D655001A 03FE6B1A 00007FFF
	v_cvt_i32_f32_e32 v46, v46                                 // 0000001D0DAC: 7E5C112E
	v_add_f32_e32 v57, v57, v59                                // 0000001D0DB0: 06727739
	v_mul_f32_e32 v45, v42, v33                                // 0000001D0DB4: 105A432A
	v_add3_u32 v25, v25, v41, 0x7fff                           // 0000001D0DB8: D6550019 03FE5319 00007FFF
	.long 0xd41e0001                                           // 0000001D0DC4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v37, vcc_lo              // 0000001D0DC8: 02024AFF 42CE8ED0
	v_fma_f32 v58, -v34, v44, 1.0                              // 0000001D0DD0: D613003A 23CA5922
	.long 0xd71c0023                                           // 0000001D0DD8: D71C0023
	v_cndmask_b32_e32 v1, v35, v46, vcc_lo                     // 0000001D0DDC: 02025D23
	v_fma_f32 v53, -v43, v45, v42                              // 0000001D0DE0: D6130035 24AA5B2B
	v_exp_f32_e32 v46, v57                                     // 0000001D0DE8: 7E5C4B39
	global_store_d16_hi_b16 v[7:8], v25, off offset:128        // 0000001D0DEC: DC960080 007C1907
	v_fmac_f32_e32 v44, v58, v44                               // 0000001D0DF4: 5658593A
	v_div_scale_f32 v58, s0, v28, v36, v28                     // 0000001D0DF8: D6FC003A 0472491C
	v_fmac_f32_e32 v45, v53, v33                               // 0000001D0E00: 565A4335
	v_cndmask_b32_e64 v35, 0, v35, s1                          // 0000001D0E04: D5010023 00064680
	.long 0xd41b0001                                           // 0000001D0E0C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v37, vcc_lo              // 0000001D0E10: 02024AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v26, off offset:128      // 0000001D0E18: DC960080 007C1A2F
	v_mul_f32_e32 v61, v58, v44                                // 0000001D0E20: 107A593A
	v_fma_f32 v42, -v43, v45, v42                              // 0000001D0E24: D613002A 24AA5B2B
	v_cndmask_b32_e64 v35, 0x7f800000, v35, s1                 // 0000001D0E2C: D5010023 000646FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D0E38: BF870193
	v_fma_f32 v41, -v34, v61, v58                              // 0000001D0E3C: D6130029 24EA7B22
	v_div_fmas_f32 v33, v42, v33, v45                          // 0000001D0E44: D6370021 04B6432A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v54                  // 0000001D0E4C: 7C3C6CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D0E54: BF870214
	v_add_f32_e32 v35, 1.0, v35                                // 0000001D0E58: 064646F2
	v_fmac_f32_e32 v61, v41, v44                               // 0000001D0E5C: 567A5929
	v_cvt_i32_f32_e32 v41, v60                                 // 0000001D0E60: 7E52113C
	v_div_fixup_f32 v27, v33, v38, v27                         // 0000001D0E64: D627001B 046E4D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D0E6C: BF870193
	v_fma_f32 v34, -v34, v61, v58                              // 0000001D0E70: D6130022 24EA7B22
	.long 0xd71c0025                                           // 0000001D0E78: D71C0025
	v_cndmask_b32_e32 v1, v46, v41, vcc_lo                     // 0000001D0E7C: 0202532E
	v_div_scale_f32 v41, null, v35, v35, v29                   // 0000001D0E80: D6FC7C29 04764723
	s_waitcnt vmcnt(3)                                         // 0000001D0E88: BF890FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001D0E8C: BF8700A2
	v_dual_cndmask_b32 v37, 0, v37 :: v_dual_lshlrev_b32 v46, 16, v131// 0000001D0E90: CA624A80 252F0690
	s_mov_b32 vcc_lo, s0                                       // 0000001D0E98: BEEA0000
	v_mul_f32_e32 v53, 0xbfb8aa3b, v46                         // 0000001D0E9C: 106A5CFF BFB8AA3B
	v_div_fmas_f32 v34, v34, v44, v61                          // 0000001D0EA4: D6370022 04F65922
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v54                  // 0000001D0EAC: 7C366CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D0EB4: BF870193
	v_fma_f32 v57, 0xbfb8aa3b, v46, -v53                       // 0000001D0EB8: D6130039 84D65CFF BFB8AA3B
	v_div_fixup_f32 v25, v34, v36, v28                         // 0000001D0EC4: D6270019 04724922
	v_dual_cndmask_b32 v37, 0x7f800000, v37 :: v_dual_mul_f32 v28, v30, v51// 0000001D0ECC: CA464AFF 251C671E 7F800000
	v_lshlrev_b32_e32 v36, 16, v87                             // 0000001D0ED8: 3048AE90
	v_rcp_f32_e32 v30, v41                                     // 0000001D0EDC: 7E3C5529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D0EE0: BF870193
	.long 0x7e003999                                           // 0000001D0EE4: 7E003999
	v_add_f32_e32 v34, 1.0, v37                                // 0000001D0EE8: 06444AF2
	v_rndne_f32_e32 v58, v53                                   // 0000001D0EEC: 7E744735
	v_mul_f32_e32 v33, 0xbfb8aa3b, v36                         // 0000001D0EF0: 104248FF BFB8AA3B
	.long 0x7e4a399b                                           // 0000001D0EF8: 7E4A399B
	.long 0x7f4a3980                                           // 0000001D0EFC: 7F4A3980
	v_div_scale_f32 v26, null, v34, v34, v28                   // 0000001D0F00: D6FC7C1A 04724522
	v_and_b32_e32 v45, 1, v0                                   // 0000001D0F08: 365A0081
	v_fma_f32 v43, 0xbfb8aa3b, v36, -v33                       // 0000001D0F0C: D613002B 848648FF BFB8AA3B
	v_rndne_f32_e32 v44, v33                                   // 0000001D0F18: 7E584721
	v_fma_f32 v38, -v41, v30, 1.0                              // 0000001D0F1C: D6130026 23CA3D29
	v_rcp_f32_e32 v42, v26                                     // 0000001D0F24: 7E54551A
	v_fmac_f32_e32 v57, 0xb2a5705f, v46                        // 0000001D0F28: 56725CFF B2A5705F
	v_fmac_f32_e32 v43, 0xb2a5705f, v36                        // 0000001D0F30: 565648FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001D0F38: BF870243
	v_dual_sub_f32 v33, v33, v44 :: v_dual_fmac_f32 v30, v38, v30// 0000001D0F3C: C9405921 211E3D26
	v_div_scale_f32 v38, vcc_lo, v29, v35, v29                 // 0000001D0F44: D6FC6A26 0476471D
	v_sub_f32_e32 v53, v53, v58                                // 0000001D0F4C: 086A7535
	v_and_b32_e32 v37, 1, v37                                  // 0000001D0F50: 364A4A81
	v_add_f32_e32 v33, v33, v43                                // 0000001D0F54: 06425721
	v_add3_u32 v25, v25, v45, 0x7fff                           // 0000001D0F58: D6550019 03FE5B19 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001D0F64: BF8701C5
	v_fma_f32 v54, -v26, v42, 1.0                              // 0000001D0F68: D6130036 23CA551A
	v_mul_f32_e32 v43, v38, v30                                // 0000001D0F70: 10563D26
	v_cvt_i32_f32_e32 v44, v44                                 // 0000001D0F74: 7E58112C
	v_exp_f32_e32 v33, v33                                     // 0000001D0F78: 7E424B21
	v_dual_add_f32 v53, v53, v57 :: v_dual_fmac_f32 v42, v54, v42// 0000001D0F7C: C9007335 352A5536
	v_div_scale_f32 v54, s0, v28, v34, v28                     // 0000001D0F84: D6FC0036 0472451C
	v_fma_f32 v45, -v41, v43, v38                              // 0000001D0F8C: D613002D 249A5729
	v_add3_u32 v27, v27, v37, 0x7fff                           // 0000001D0F94: D655001B 03FE4B1B 00007FFF
	.long 0xd41e0001                                           // 0000001D0FA0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v36, vcc_lo              // 0000001D0FA4: 020248FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D0FAC: BF870214
	v_mul_f32_e32 v59, v54, v42                                // 0000001D0FB0: 10765536
	v_fmac_f32_e32 v43, v45, v30                               // 0000001D0FB4: 56563D2D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001D0FB8: BF870005
	.long 0xd71c0021                                           // 0000001D0FBC: D71C0021
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 0000001D0FC0: 02025921
	v_exp_f32_e32 v44, v53                                     // 0000001D0FC4: 7E584B35
	global_store_d16_hi_b16 v[15:16], v27, off offset:128      // 0000001D0FC8: DC960080 007C1B0F
	v_fma_f32 v37, -v26, v59, v54                              // 0000001D0FD0: D6130025 24DA771A
	v_fma_f32 v38, -v41, v43, v38                              // 0000001D0FD8: D6130026 249A5729
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 0000001D0FE0: D5010021 00064280
	.long 0xd41b0001                                           // 0000001D0FE8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v36, vcc_lo              // 0000001D0FEC: 020248FF C2B17218
	global_store_d16_hi_b16 v[23:24], v25, off offset:128      // 0000001D0FF4: DC960080 007C1917
	v_fmac_f32_e32 v59, v37, v42                               // 0000001D0FFC: 56765525
	v_cvt_i32_f32_e32 v37, v58                                 // 0000001D1000: 7E4A113A
	v_div_fmas_f32 v30, v38, v30, v43                          // 0000001D1004: D637001E 04AE3D26
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 0000001D100C: 7C3C5CFF 42CE8ED0
	v_cndmask_b32_e64 v33, 0x7f800000, v33, s1                 // 0000001D1014: D5010021 000642FF 7F800000
	v_fma_f32 v26, -v26, v59, v54                              // 0000001D1020: D613001A 24DA771A
	.long 0xd71c0024                                           // 0000001D1028: D71C0024
	v_cndmask_b32_e32 v1, v44, v37, vcc_lo                     // 0000001D102C: 02024B2C
	v_div_fixup_f32 v29, v30, v35, v29                         // 0000001D1030: D627001D 0476471E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D1038: BF870224
	v_dual_add_f32 v33, 1.0, v33 :: v_dual_lshlrev_b32 v44, 16, v123// 0000001D103C: C92242F2 212CF690
	.long 0x7f463980                                           // 0000001D1044: 7F463980
	v_cndmask_b32_e32 v36, 0, v36, vcc_lo                      // 0000001D1048: 02484880
	s_mov_b32 vcc_lo, s0                                       // 0000001D104C: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D1050: BF870003
	v_mul_f32_e32 v45, 0xbfb8aa3b, v44                         // 0000001D1054: 105A58FF BFB8AA3B
	v_div_fmas_f32 v26, v26, v42, v59                          // 0000001D105C: D637001A 04EE551A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 0000001D1064: 7C365CFF C2B17218
	v_div_scale_f32 v37, null, v33, v33, v17                   // 0000001D106C: D6FC7C25 04464321
	.long 0x7e46399d                                           // 0000001D1074: 7E46399D
	v_fma_f32 v53, 0xbfb8aa3b, v44, -v45                       // 0000001D1078: D6130035 84B658FF BFB8AA3B
	v_div_fixup_f32 v26, v26, v34, v28                         // 0000001D1084: D627001A 0472451A
	v_cndmask_b32_e32 v36, 0x7f800000, v36, vcc_lo             // 0000001D108C: 024848FF 7F800000
	v_lshlrev_b32_e32 v34, 16, v124                            // 0000001D1094: 3044F890
	v_rcp_f32_e32 v27, v37                                     // 0000001D1098: 7E365525
	v_rndne_f32_e32 v54, v45                                   // 0000001D109C: 7E6C472D
	.long 0x7e00399a                                           // 0000001D10A0: 7E00399A
	v_add_f32_e32 v28, 1.0, v36                                // 0000001D10A4: 063848F2
	v_mul_f32_e32 v30, 0xbfb8aa3b, v34                         // 0000001D10A8: 103C44FF BFB8AA3B
	v_fmac_f32_e32 v53, 0xb2a5705f, v44                        // 0000001D10B0: 566A58FF B2A5705F
	v_sub_f32_e32 v45, v45, v54                                // 0000001D10B8: 085A6D2D
	v_and_b32_e32 v43, 1, v0                                   // 0000001D10BC: 36560081
	v_div_scale_f32 v25, null, v28, v28, v18                   // 0000001D10C0: D6FC7C19 044A391C
	v_fma_f32 v41, 0xbfb8aa3b, v34, -v30                       // 0000001D10C8: D6130029 847A44FF BFB8AA3B
	v_rndne_f32_e32 v42, v30                                   // 0000001D10D4: 7E54471E
	v_fma_f32 v36, -v37, v27, 1.0                              // 0000001D10D8: D6130024 23CA3725
	v_and_b32_e32 v35, 1, v35                                  // 0000001D10E0: 36464681
	v_rcp_f32_e32 v38, v25                                     // 0000001D10E4: 7E4C5519
	v_fmac_f32_e32 v41, 0xb2a5705f, v34                        // 0000001D10E8: 565244FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001D10F0: BF870243
	v_dual_sub_f32 v30, v30, v42 :: v_dual_fmac_f32 v27, v36, v27// 0000001D10F4: C940551E 1E1A3724
	v_div_scale_f32 v36, vcc_lo, v17, v33, v17                 // 0000001D10FC: D6FC6A24 04464311
	v_add3_u32 v26, v26, v43, 0x7fff                           // 0000001D1104: D655001A 03FE571A 00007FFF
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001D1110: 7E54112A
	v_add_f32_e32 v30, v30, v41                                // 0000001D1114: 063C531E
	v_add_f32_e32 v45, v45, v53                                // 0000001D1118: 065A6B2D
	v_mul_f32_e32 v41, v36, v27                                // 0000001D111C: 10523724
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001D1120: BF870005
	v_fma_f32 v46, -v25, v38, 1.0                              // 0000001D1124: D613002E 23CA4D19
	v_add3_u32 v29, v29, v35, 0x7fff                           // 0000001D112C: D655001D 03FE471D 00007FFF
	v_exp_f32_e32 v30, v30                                     // 0000001D1138: 7E3C4B1E
	.long 0xd41e0001                                           // 0000001D113C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v34, vcc_lo              // 0000001D1140: 020244FF 42CE8ED0
	v_fma_f32 v43, -v37, v41, v36                              // 0000001D1148: D613002B 24925325
	v_fmac_f32_e32 v38, v46, v38                               // 0000001D1150: 564C4D2E
	v_div_scale_f32 v46, s0, v18, v28, v18                     // 0000001D1154: D6FC002E 044A3912
	s_clause 0x1                                               // 0000001D115C: BF850001
	global_store_d16_hi_b16 v[31:32], v29, off offset:128      // 0000001D1160: DC960080 007C1D1F
	global_store_d16_hi_b16 v[39:40], v26, off offset:128      // 0000001D1168: DC960080 007C1A27
	v_dual_fmac_f32 v41, v43, v27 :: v_dual_lshlrev_b32 v26, 16, v126// 0000001D1170: C822372B 291AFC90
	v_mul_f32_e32 v57, v46, v38                                // 0000001D1178: 10724D2E
	.long 0xd71c001e                                           // 0000001D117C: D71C001E
	v_cndmask_b32_e32 v1, v30, v42, vcc_lo                     // 0000001D1180: 0202551E
	v_exp_f32_e32 v42, v45                                     // 0000001D1184: 7E544B2D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D1188: BF870003
	v_fma_f32 v36, -v37, v41, v36                              // 0000001D118C: D6130024 24925325
	.long 0x7f3a3980                                           // 0000001D1194: 7F3A3980
	v_fma_f32 v35, -v25, v57, v46                              // 0000001D1198: D6130023 24BA7319
	v_cndmask_b32_e64 v30, 0, v30, s1                          // 0000001D11A0: D501001E 00063C80
	.long 0xd41b0001                                           // 0000001D11A8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v34, vcc_lo              // 0000001D11AC: 020244FF C2B17218
	v_div_fmas_f32 v27, v36, v27, v41                          // 0000001D11B4: D637001B 04A63724
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v44                  // 0000001D11BC: 7C3C58FF 42CE8ED0
	v_fmac_f32_e32 v57, v35, v38                               // 0000001D11C4: 56724D23
	v_cvt_i32_f32_e32 v35, v54                                 // 0000001D11C8: 7E461136
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000001D11CC: D501001E 00063CFF 7F800000
	v_div_fixup_f32 v17, v27, v33, v17                         // 0000001D11D8: D6270011 0446431B
	v_mul_f32_e32 v33, 0xbfb8aa3b, v26                         // 0000001D11E0: 104234FF BFB8AA3B
	v_fma_f32 v25, -v25, v57, v46                              // 0000001D11E8: D6130019 24BA7319
	.long 0xd71c0022                                           // 0000001D11F0: D71C0022
	v_cndmask_b32_e32 v1, v42, v35, vcc_lo                     // 0000001D11F4: 0202472A
	v_add_f32_e32 v30, 1.0, v30                                // 0000001D11F8: 063C3CF2
	.long 0xd41e0001                                           // 0000001D11FC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v26, vcc_lo              // 0000001D1200: 020234FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v26, -v33                       // 0000001D1208: D6130029 848634FF BFB8AA3B
	v_rndne_f32_e32 v42, v33                                   // 0000001D1214: 7E544721
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000001D1218: 02444480
	s_mov_b32 vcc_lo, s0                                       // 0000001D121C: BEEA0000
	v_div_scale_f32 v35, null, v30, v30, v19                   // 0000001D1220: D6FC7C23 044E3D1E
	v_div_fmas_f32 v25, v25, v38, v57                          // 0000001D1228: D6370019 04E64D19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v44                  // 0000001D1230: 7C3658FF C2B17218
	v_dual_fmac_f32 v41, 0xb2a5705f, v26 :: v_dual_lshlrev_b32 v38, 16, v125// 0000001D1238: C82234FF 2926FA90 B2A5705F
	v_sub_f32_e32 v33, v33, v42                                // 0000001D1244: 08425521
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D1248: BF870004
	v_div_fixup_f32 v18, v25, v28, v18                         // 0000001D124C: D6270012 044A3919
	v_cndmask_b32_e32 v34, 0x7f800000, v34, vcc_lo             // 0000001D1254: 024444FF 7F800000
	v_rcp_f32_e32 v25, v35                                     // 0000001D125C: 7E325523
	v_mul_f32_e32 v43, 0xbfb8aa3b, v38                         // 0000001D1260: 10564CFF BFB8AA3B
	v_add_f32_e32 v33, v33, v41                                // 0000001D1268: 06425321
	.long 0x7e003992                                           // 0000001D126C: 7E003992
	v_add_f32_e32 v28, 1.0, v34                                // 0000001D1270: 063844F2
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001D1274: 7E54112A
	v_fma_f32 v46, 0xbfb8aa3b, v38, -v43                       // 0000001D1278: D613002E 84AE4CFF BFB8AA3B
	v_rndne_f32_e32 v53, v43                                   // 0000001D1284: 7E6A472B
	v_exp_f32_e32 v33, v33                                     // 0000001D1288: 7E424B21
	v_div_scale_f32 v27, null, v28, v28, v20                   // 0000001D128C: D6FC7C1B 0452391C
	v_fma_f32 v34, -v35, v25, 1.0                              // 0000001D1294: D6130022 23CA3323
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D129C: BF870223
	v_dual_fmac_f32 v46, 0xb2a5705f, v38 :: v_dual_sub_f32 v43, v43, v53// 0000001D12A0: C80A4CFF 2E2A6B2B B2A5705F
	v_div_scale_f32 v41, s0, v20, v28, v20                     // 0000001D12AC: D6FC0029 04523914
	v_rcp_f32_e32 v36, v27                                     // 0000001D12B4: 7E48551B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D12B8: BF870003
	v_fmac_f32_e32 v25, v34, v25                               // 0000001D12BC: 56323322
	v_div_scale_f32 v34, vcc_lo, v19, v30, v19                 // 0000001D12C0: D6FC6A22 044E3D13
	v_and_b32_e32 v37, 1, v0                                   // 0000001D12C8: 364A0081
	v_add_f32_e32 v43, v43, v46                                // 0000001D12CC: 06565D2B
	.long 0xd71c0021                                           // 0000001D12D0: D71C0021
	v_cndmask_b32_e32 v1, v33, v42, vcc_lo                     // 0000001D12D4: 02025521
	.long 0x7e3a3991                                           // 0000001D12D8: 7E3A3991
	v_mul_f32_e32 v45, v34, v25                                // 0000001D12DC: 105A3322
	v_add3_u32 v18, v18, v37, 0x7fff                           // 0000001D12E0: D6550012 03FE4B12 00007FFF
	v_exp_f32_e32 v37, v43                                     // 0000001D12EC: 7E4A4B2B
	v_fma_f32 v44, -v27, v36, 1.0                              // 0000001D12F0: D613002C 23CA491B
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 0000001D12F8: D5010021 00064280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001D1300: BF870122
	v_dual_fmac_f32 v36, v44, v36 :: v_dual_and_b32 v29, 1, v29// 0000001D1304: C824492C 241C3A81
	v_fma_f32 v44, -v35, v45, v34                              // 0000001D130C: D613002C 248A5B23
	v_add3_u32 v17, v17, v29, 0x7fff                           // 0000001D1314: D6550011 03FE3B11 00007FFF
	v_lshlrev_b32_e32 v29, 16, v92                             // 0000001D1320: 303AB890
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D1324: BF870003
	v_dual_mul_f32 v54, v41, v36 :: v_dual_fmac_f32 v45, v44, v25// 0000001D1328: C8C04929 362C332C
	s_clause 0x1                                               // 0000001D1330: BF850001
	global_store_d16_hi_b16 v[7:8], v17, off offset:160        // 0000001D1334: DC9600A0 007C1107
	global_store_d16_hi_b16 v[47:48], v18, off offset:160      // 0000001D133C: DC9600A0 007C122F
	v_fma_f32 v44, -v27, v54, v41                              // 0000001D1344: D613002C 24A66D1B
	v_fma_f32 v34, -v35, v45, v34                              // 0000001D134C: D6130022 248A5B23
	v_cvt_i32_f32_e32 v35, v53                                 // 0000001D1354: 7E461135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D1358: BF870193
	v_fmac_f32_e32 v54, v44, v36                               // 0000001D135C: 566C492C
	v_div_fmas_f32 v25, v34, v25, v45                          // 0000001D1360: D6370019 04B63322
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v26                  // 0000001D1368: 7C3634FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D1370: BF870004
	.long 0xd71c0022                                           // 0000001D1374: D71C0022
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 0000001D1378: 02024725
	v_mul_f32_e32 v35, 0xbfb8aa3b, v29                         // 0000001D137C: 10463AFF BFB8AA3B
	v_fma_f32 v27, -v27, v54, v41                              // 0000001D1384: D613001B 24A66D1B
	v_div_fixup_f32 v17, v25, v30, v19                         // 0000001D138C: D6270011 044E3D19
	v_cndmask_b32_e32 v26, 0x7f800000, v33, vcc_lo             // 0000001D1394: 023442FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 0000001D139C: 7C3C4CFF 42CE8ED0
	.long 0x7f3c3980                                           // 0000001D13A4: 7F3C3980
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D13A8: BF870214
	.long 0x7e3c3991                                           // 0000001D13AC: 7E3C3991
	v_add_f32_e32 v26, 1.0, v26                                // 0000001D13B0: 063434F2
	v_cndmask_b32_e32 v33, 0, v34, vcc_lo                      // 0000001D13B4: 02424480
	s_mov_b32 vcc_lo, s0                                       // 0000001D13B8: BEEA0000
	v_div_fmas_f32 v27, v27, v36, v54                          // 0000001D13BC: D637001B 04DA491B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 0000001D13C4: 7C364CFF C2B17218
	v_rndne_f32_e32 v36, v35                                   // 0000001D13CC: 7E484723
	s_waitcnt vmcnt(2)                                         // 0000001D13D0: BF890BF7
	v_lshlrev_b32_e32 v38, 16, v68                             // 0000001D13D4: 304C8890
	v_and_b32_e32 v30, 1, v30                                  // 0000001D13D8: 363C3C81
	v_div_fixup_f32 v20, v27, v28, v20                         // 0000001D13DC: D6270014 0452391B
	v_cndmask_b32_e32 v33, 0x7f800000, v33, vcc_lo             // 0000001D13E4: 024242FF 7F800000
	v_div_scale_f32 v27, null, v26, v26, v21                   // 0000001D13EC: D6FC7C1B 0456351A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D13F4: BF870214
	v_add3_u32 v17, v17, v30, 0x7fff                           // 0000001D13F8: D6550011 03FE3D11 00007FFF
	.long 0x7e003994                                           // 0000001D1404: 7E003994
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D1408: BF870214
	v_add_f32_e32 v28, 1.0, v33                                // 0000001D140C: 063842F2
	v_rcp_f32_e32 v19, v27                                     // 0000001D1410: 7E26551B
	global_store_d16_hi_b16 v[15:16], v17, off offset:160      // 0000001D1414: DC9600A0 007C110F
	v_and_b32_e32 v33, 1, v0                                   // 0000001D141C: 36420081
	v_div_scale_f32 v25, null, v28, v28, v22                   // 0000001D1420: D6FC7C19 045A391C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D1428: BF870112
	v_add3_u32 v20, v20, v33, 0x7fff                           // 0000001D142C: D6550014 03FE4314 00007FFF
	v_rcp_f32_e32 v34, v25                                     // 0000001D1438: 7E445519
	v_fma_f32 v18, -v27, v19, 1.0                              // 0000001D143C: D6130012 23CA271B
	v_fma_f32 v33, 0xbfb8aa3b, v29, -v35                       // 0000001D1444: D6130021 848E3AFF BFB8AA3B
	v_sub_f32_e32 v35, v35, v36                                // 0000001D1450: 08464923
	v_cvt_i32_f32_e32 v36, v36                                 // 0000001D1454: 7E481124
	global_store_d16_hi_b16 v[23:24], v20, off offset:160      // 0000001D1458: DC9600A0 007C1417
	v_fmac_f32_e32 v19, v18, v19                               // 0000001D1460: 56262712
	v_div_scale_f32 v18, vcc_lo, v21, v26, v21                 // 0000001D1464: D6FC6A12 04563515
	v_fmac_f32_e32 v33, 0xb2a5705f, v29                        // 0000001D146C: 56423AFF B2A5705F
	v_fma_f32 v37, -v25, v34, 1.0                              // 0000001D1474: D6130025 23CA4519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D147C: BF870193
	v_mul_f32_e32 v41, v18, v19                                // 0000001D1480: 10522712
	v_add_f32_e32 v33, v35, v33                                // 0000001D1484: 06424323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v38                         // 0000001D1488: 10464CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D1490: BF870004
	v_fmac_f32_e32 v34, v37, v34                               // 0000001D1494: 56444525
	v_div_scale_f32 v37, s0, v22, v28, v22                     // 0000001D1498: D6FC0025 045A3916
	v_fma_f32 v30, -v27, v41, v18                              // 0000001D14A0: D613001E 244A531B
	v_exp_f32_e32 v33, v33                                     // 0000001D14A8: 7E424B21
	v_fma_f32 v43, 0xbfb8aa3b, v38, -v35                       // 0000001D14AC: D613002B 848E4CFF BFB8AA3B
	v_rndne_f32_e32 v44, v35                                   // 0000001D14B8: 7E584723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D14BC: BF870193
	v_dual_mul_f32 v42, v37, v34 :: v_dual_fmac_f32 v41, v30, v19// 0000001D14C0: C8C04525 2A28271E
	v_fmac_f32_e32 v43, 0xb2a5705f, v38                        // 0000001D14C8: 56564CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D14D0: BF870193
	v_sub_f32_e32 v35, v35, v44                                // 0000001D14D4: 08465923
	v_fma_f32 v30, -v25, v42, v37                              // 0000001D14D8: D613001E 24965519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001D14E0: BF870294
	v_fma_f32 v17, -v27, v41, v18                              // 0000001D14E4: D6130011 244A531B
	.long 0xd71c0012                                           // 0000001D14EC: D71C0012
	v_cndmask_b32_e32 v1, v33, v36, vcc_lo                     // 0000001D14F0: 02024921
	v_cvt_i32_f32_e32 v20, v44                                 // 0000001D14F4: 7E28112C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D14F8: BF870214
	v_dual_add_f32 v27, v35, v43 :: v_dual_fmac_f32 v42, v30, v34// 0000001D14FC: C9005723 1B2A451E
	v_div_fmas_f32 v17, v17, v19, v41                          // 0000001D1504: D6370011 04A62711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001D150C: 7C3C3AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D1514: BF870213
	v_fma_f32 v19, -v25, v42, v37                              // 0000001D1518: D6130013 24965519
	v_exp_f32_e32 v25, v27                                     // 0000001D1520: 7E324B1B
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001D1524: 02242480
	s_mov_b32 vcc_lo, s0                                       // 0000001D1528: BEEA0000
	v_div_fixup_f32 v17, v17, v26, v21                         // 0000001D152C: D6270011 04563511
	v_div_fmas_f32 v19, v19, v34, v42                          // 0000001D1534: D6370013 04AA4513
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001D153C: 7C363AFF C2B17218
	.long 0x7f2a3980                                           // 0000001D1544: 7F2A3980
	v_lshlrev_b32_e32 v34, 16, v70                             // 0000001D1548: 30448C90
	.long 0x7e2a3991                                           // 0000001D154C: 7E2A3991
	v_div_fixup_f32 v19, v19, v28, v22                         // 0000001D1550: D6270013 045A3913
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001D1558: 022424FF 7F800000
	.long 0xd71c0014                                           // 0000001D1560: D71C0014
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000001D1564: 02022919
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 0000001D1568: 7C3C4CFF 42CE8ED0
	v_lshlrev_b32_e32 v25, 16, v104                            // 0000001D1570: 3032D090
	.long 0x7e003993                                           // 0000001D1574: 7E003993
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_and_b32 v21, 1, v21 // 0000001D1578: C92424F2 12142A81
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001D1580: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 0000001D1584: 7C364CFF C2B17218
	v_mul_f32_e32 v27, 0xbfb8aa3b, v25                         // 0000001D158C: 103632FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D1594: BF870234
	v_div_scale_f32 v22, null, v18, v18, v9                    // 0000001D1598: D6FC7C16 04262512
	v_dual_mul_f32 v37, 0xbfb8aa3b, v34 :: v_dual_and_b32 v28, 1, v0// 0000001D15A0: C8E444FF 251C0081 BFB8AA3B
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 0000001D15AC: 022828FF 7F800000
	v_fma_f32 v29, 0xbfb8aa3b, v25, -v27                       // 0000001D15B4: D613001D 846E32FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001D15C0: BF8701B4
	v_rcp_f32_e32 v26, v22                                     // 0000001D15C4: 7E345516
	v_rndne_f32_e32 v30, v27                                   // 0000001D15C8: 7E3C471B
	v_add3_u32 v17, v17, v21, 0x7fff                           // 0000001D15CC: D6550011 03FE2B11 00007FFF
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_fmac_f32 v29, 0xb2a5705f, v25// 0000001D15D8: C90028F2 141C32FF B2A5705F
	v_add3_u32 v19, v19, v28, 0x7fff                           // 0000001D15E4: D6550013 03FE3913 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D15F0: BF870224
	v_sub_f32_e32 v27, v27, v30                                // 0000001D15F4: 08363D1B
	v_rndne_f32_e32 v28, v37                                   // 0000001D15F8: 7E384725
	v_div_scale_f32 v33, null, v20, v20, v10                   // 0000001D15FC: D6FC7C21 042A2914
	v_cvt_i32_f32_e32 v30, v30                                 // 0000001D1604: 7E3C111E
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001D1608: BF870005
	v_fma_f32 v35, -v22, v26, 1.0                              // 0000001D160C: D6130023 23CA3516
	v_add_f32_e32 v21, v27, v29                                // 0000001D1614: 062A3B1B
	v_fma_f32 v27, 0xbfb8aa3b, v34, -v37                       // 0000001D1618: D613001B 849644FF BFB8AA3B
	v_rcp_f32_e32 v36, v33                                     // 0000001D1624: 7E485521
	v_div_scale_f32 v29, vcc_lo, v9, v18, v9                   // 0000001D1628: D6FC6A1D 04262509
	v_fmac_f32_e32 v26, v35, v26                               // 0000001D1630: 56343523
	v_exp_f32_e32 v21, v21                                     // 0000001D1634: 7E2A4B15
	v_fmac_f32_e32 v27, 0xb2a5705f, v34                        // 0000001D1638: 563644FF B2A5705F
	v_sub_f32_e32 v37, v37, v28                                // 0000001D1640: 084A3925
	global_store_d16_hi_b16 v[31:32], v17, off offset:160      // 0000001D1644: DC9600A0 007C111F
	v_mul_f32_e32 v38, v29, v26                                // 0000001D164C: 104C351D
	.long 0xd41e0001                                           // 0000001D1650: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001D1654: 020232FF 42CE8ED0
	v_cvt_i32_f32_e32 v28, v28                                 // 0000001D165C: 7E38111C
	v_fma_f32 v35, -v33, v36, 1.0                              // 0000001D1660: D6130023 23CA4921
	v_add_f32_e32 v27, v37, v27                                // 0000001D1668: 06363725
	global_store_d16_hi_b16 v[39:40], v19, off offset:160      // 0000001D166C: DC9600A0 007C1327
	.long 0xd71c0011                                           // 0000001D1674: D71C0011
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                     // 0000001D1678: 02023D15
	v_fma_f32 v21, -v22, v38, v29                              // 0000001D167C: D6130015 24764D16
	v_fmac_f32_e32 v36, v35, v36                               // 0000001D1684: 56484923
	v_div_scale_f32 v35, s0, v10, v20, v10                     // 0000001D1688: D6FC0023 042A290A
	v_exp_f32_e32 v27, v27                                     // 0000001D1690: 7E364B1B
	v_cndmask_b32_e64 v17, 0, v17, s1                          // 0000001D1694: D5010011 00062280
	v_fmac_f32_e32 v38, v21, v26                               // 0000001D169C: 564C3515
	.long 0xd41b0001                                           // 0000001D16A0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v25, vcc_lo              // 0000001D16A4: 020232FF C2B17218
	v_dual_mul_f32 v30, v35, v36 :: v_dual_lshlrev_b32 v19, 16, v106// 0000001D16AC: C8E24923 1E12D490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D16B4: BF870193
	v_fma_f32 v22, -v22, v38, v29                              // 0000001D16B8: D6130016 24764D16
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 0000001D16C0: D5010011 000622FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D16CC: BF870213
	v_fma_f32 v21, -v33, v30, v35                              // 0000001D16D0: D6130015 248E3D21
	.long 0xd41e0001                                           // 0000001D16D8: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v19, vcc_lo              // 0000001D16DC: 020226FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D16E4: BF870224
	v_div_fmas_f32 v22, v22, v26, v38                          // 0000001D16E8: D6370016 049A3516
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 0000001D16F0: 7C3C44FF 42CE8ED0
	v_fmac_f32_e32 v30, v21, v36                               // 0000001D16F8: 563C4915
	.long 0xd71c0015                                           // 0000001D16FC: D71C0015
	v_cndmask_b32_e32 v1, v27, v28, vcc_lo                     // 0000001D1700: 0202391B
	v_add_f32_e32 v17, 1.0, v17                                // 0000001D1704: 062222F2
	v_div_fixup_f32 v9, v22, v18, v9                           // 0000001D1708: D6270009 04262516
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D1710: BF870214
	v_fma_f32 v25, -v33, v30, v35                              // 0000001D1714: D6130019 248E3D21
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 0000001D171C: 022A2A80
	s_mov_b32 vcc_lo, s0                                       // 0000001D1720: BEEA0000
	v_div_scale_f32 v26, null, v17, v17, v11                   // 0000001D1724: D6FC7C1A 042E2311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001D172C: BF870233
	v_div_fmas_f32 v25, v25, v36, v30                          // 0000001D1730: D6370019 047A4919
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 0000001D1738: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v34, 16, v105                            // 0000001D1740: 3044D290
	v_rcp_f32_e32 v27, v26                                     // 0000001D1744: 7E36551A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D1748: BF870003
	v_div_fixup_f32 v10, v25, v20, v10                         // 0000001D174C: D627000A 042A2919
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001D1754: 022A2AFF 7F800000
	v_mul_f32_e32 v25, 0xbfb8aa3b, v19                         // 0000001D175C: 103226FF BFB8AA3B
	v_div_scale_f32 v33, vcc_lo, v11, v17, v11                 // 0000001D1764: D6FC6A21 042E230B
	v_mul_f32_e32 v36, 0xbfb8aa3b, v34                         // 0000001D176C: 104844FF BFB8AA3B
	.long 0x7e00398a                                           // 0000001D1774: 7E00398A
	v_add_f32_e32 v18, 1.0, v21                                // 0000001D1778: 06242AF2
	v_fma_f32 v29, 0xbfb8aa3b, v19, -v25                       // 0000001D177C: D613001D 846626FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001D1788: BF870005
	v_fma_f32 v21, -v26, v27, 1.0                              // 0000001D178C: D6130015 23CA371A
	v_rndne_f32_e32 v30, v25                                   // 0000001D1794: 7E3C4719
	v_and_b32_e32 v28, 1, v0                                   // 0000001D1798: 36380081
	v_div_scale_f32 v22, null, v18, v18, v12                   // 0000001D179C: D6FC7C16 04322512
	v_fmac_f32_e32 v29, 0xb2a5705f, v19                        // 0000001D17A4: 563A26FF B2A5705F
	v_fmac_f32_e32 v27, v21, v27                               // 0000001D17AC: 56363715
	v_sub_f32_e32 v25, v25, v30                                // 0000001D17B0: 08323D19
	.long 0x7e283989                                           // 0000001D17B4: 7E283989
	v_rcp_f32_e32 v21, v22                                     // 0000001D17B8: 7E2A5516
	.long 0x7f283980                                           // 0000001D17BC: 7F283980
	v_mul_f32_e32 v35, v33, v27                                // 0000001D17C0: 10463721
	v_add_f32_e32 v25, v25, v29                                // 0000001D17C4: 06323B19
	v_fma_f32 v37, 0xbfb8aa3b, v34, -v36                       // 0000001D17C8: D6130025 849244FF BFB8AA3B
	v_rndne_f32_e32 v38, v36                                   // 0000001D17D4: 7E4C4724
	v_add3_u32 v10, v10, v28, 0x7fff                           // 0000001D17D8: D655000A 03FE390A 00007FFF
	v_and_b32_e32 v20, 1, v20                                  // 0000001D17E4: 36282881
	v_fma_f32 v29, -v26, v35, v33                              // 0000001D17E8: D613001D 2486471A
	v_exp_f32_e32 v25, v25                                     // 0000001D17F0: 7E324B19
	v_fma_f32 v28, -v22, v21, 1.0                              // 0000001D17F4: D613001C 23CA2B16
	v_fmac_f32_e32 v37, 0xb2a5705f, v34                        // 0000001D17FC: 564A44FF B2A5705F
	v_sub_f32_e32 v36, v36, v38                                // 0000001D1804: 08484D24
	v_add3_u32 v9, v9, v20, 0x7fff                             // 0000001D1808: D6550009 03FE2909 00007FFF
	v_cvt_i32_f32_e32 v20, v30                                 // 0000001D1814: 7E28111E
	v_fmac_f32_e32 v21, v28, v21                               // 0000001D1818: 562A2B1C
	v_div_scale_f32 v28, s0, v12, v18, v12                     // 0000001D181C: D6FC001C 0432250C
	v_dual_fmac_f32 v35, v29, v27 :: v_dual_add_f32 v30, v36, v37// 0000001D1824: C808371D 231E4B24
	global_store_d16_hi_b16 v[7:8], v9, off offset:192         // 0000001D182C: DC9600C0 007C0907
	.long 0xd71c0009                                           // 0000001D1834: D71C0009
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000001D1838: 02022919
	v_mul_f32_e32 v29, v28, v21                                // 0000001D183C: 103A2B1C
	v_fma_f32 v20, -v26, v35, v33                              // 0000001D1840: D6130014 2486471A
	v_exp_f32_e32 v26, v30                                     // 0000001D1848: 7E344B1E
	global_store_d16_hi_b16 v[47:48], v10, off offset:192      // 0000001D184C: DC9600C0 007C0A2F
	v_cndmask_b32_e64 v9, 0, v9, s1                            // 0000001D1854: D5010009 00061280
	v_fma_f32 v25, -v22, v29, v28                              // 0000001D185C: D6130019 24723B16
	v_div_fmas_f32 v20, v20, v27, v35                          // 0000001D1864: D6370014 048E3714
	v_cvt_i32_f32_e32 v27, v38                                 // 0000001D186C: 7E361126
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v19                  // 0000001D1870: 7C3626FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D1878: BF870214
	v_fmac_f32_e32 v29, v25, v21                               // 0000001D187C: 563A2B19
	v_div_fixup_f32 v11, v20, v17, v11                         // 0000001D1880: D627000B 042E2314
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D1888: BF870004
	.long 0xd71c0011                                           // 0000001D188C: D71C0011
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000001D1890: 0202371A
	v_cndmask_b32_e32 v9, 0x7f800000, v9, vcc_lo               // 0000001D1894: 021212FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 0000001D189C: 7C3C44FF 42CE8ED0
	v_fma_f32 v19, -v22, v29, v28                              // 0000001D18A4: D6130013 24723B16
	s_waitcnt vmcnt(1)                                         // 0000001D18AC: BF8907F7
	v_lshlrev_b32_e32 v25, 16, v67                             // 0000001D18B0: 30328690
	.long 0x7e2c398b                                           // 0000001D18B4: 7E2C398B
	v_add_f32_e32 v9, 1.0, v9                                  // 0000001D18B8: 061212F2
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000001D18BC: 02222280
	s_mov_b32 vcc_lo, s0                                       // 0000001D18C0: BEEA0000
	v_mul_f32_e32 v30, 0xbfb8aa3b, v25                         // 0000001D18C4: 103C32FF BFB8AA3B
	v_div_fmas_f32 v19, v19, v21, v29                          // 0000001D18CC: D6370013 04762B13
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 0000001D18D4: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v21, 16, v69                             // 0000001D18DC: 302A8A90
	v_div_scale_f32 v20, null, v9, v9, v13                     // 0000001D18E0: D6FC7C14 04361309
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v30                       // 0000001D18E8: D6130022 847A32FF BFB8AA3B
	v_div_fixup_f32 v12, v19, v18, v12                         // 0000001D18F4: D627000C 04322513
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 0000001D18FC: 022222FF 7F800000
	v_mul_f32_e32 v19, 0xbfb8aa3b, v21                         // 0000001D1904: 10262AFF BFB8AA3B
	v_rcp_f32_e32 v18, v20                                     // 0000001D190C: 7E245514
	v_rndne_f32_e32 v35, v30                                   // 0000001D1910: 7E46471E
	v_fmac_f32_e32 v34, 0xb2a5705f, v25                        // 0000001D1914: 564432FF B2A5705F
	v_add_f32_e32 v17, 1.0, v17                                // 0000001D191C: 062222F2
	v_fma_f32 v27, 0xbfb8aa3b, v21, -v19                       // 0000001D1920: D613001B 844E2AFF BFB8AA3B
	v_rndne_f32_e32 v28, v19                                   // 0000001D192C: 7E384713
	.long 0xd41e0001                                           // 0000001D1930: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v21, vcc_lo              // 0000001D1934: 02022AFF 42CE8ED0
	.long 0x7e00398c                                           // 0000001D193C: 7E00398C
	v_div_scale_f32 v26, null, v17, v17, v14                   // 0000001D1940: D6FC7C1A 043A2311
	v_fmac_f32_e32 v27, 0xb2a5705f, v21                        // 0000001D1948: 56362AFF B2A5705F
	v_sub_f32_e32 v19, v19, v28                                // 0000001D1950: 08263913
	v_fma_f32 v29, -v20, v18, 1.0                              // 0000001D1954: D613001D 23CA2514
	v_cvt_i32_f32_e32 v28, v28                                 // 0000001D195C: 7E38111C
	v_rcp_f32_e32 v33, v26                                     // 0000001D1960: 7E42551A
	.long 0x7f2c3980                                           // 0000001D1964: 7F2C3980
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001D1968: BF8701B3
	v_dual_add_f32 v19, v19, v27 :: v_dual_fmac_f32 v18, v29, v18// 0000001D196C: C9003713 1312251D
	v_div_scale_f32 v27, vcc_lo, v13, v9, v13                  // 0000001D1974: D6FC6A1B 0436130D
	v_dual_sub_f32 v29, v30, v35 :: v_dual_and_b32 v36, 1, v0  // 0000001D197C: C964471E 1D240081
	v_exp_f32_e32 v19, v19                                     // 0000001D1984: 7E264B13
	v_and_b32_e32 v22, 1, v22                                  // 0000001D1988: 362C2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001D198C: BF870313
	v_mul_f32_e32 v37, v27, v18                                // 0000001D1990: 104A251B
	v_fma_f32 v30, -v26, v33, 1.0                              // 0000001D1994: D613001E 23CA431A
	v_add_f32_e32 v29, v29, v34                                // 0000001D199C: 063A451D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D19A0: BF870214
	v_add3_u32 v10, v11, v22, 0x7fff                           // 0000001D19A4: D655000A 03FE2D0B 00007FFF
	v_fma_f32 v34, -v20, v37, v27                              // 0000001D19B0: D6130022 246E4B14
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D19B8: BF870004
	v_fmac_f32_e32 v33, v30, v33                               // 0000001D19BC: 5642431E
	v_div_scale_f32 v30, s0, v14, v17, v14                     // 0000001D19C0: D6FC001E 043A230E
	v_exp_f32_e32 v29, v29                                     // 0000001D19C8: 7E3A4B1D
	.long 0xd71c0013                                           // 0000001D19CC: D71C0013
	v_cndmask_b32_e32 v1, v19, v28, vcc_lo                     // 0000001D19D0: 02023913
	v_fmac_f32_e32 v37, v34, v18                               // 0000001D19D4: 564A2522
	v_cvt_i32_f32_e32 v34, v35                                 // 0000001D19D8: 7E441123
	v_mul_f32_e32 v28, v30, v33                                // 0000001D19DC: 1038431E
	v_add3_u32 v11, v12, v36, 0x7fff                           // 0000001D19E0: D655000B 03FE490C 00007FFF
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 0000001D19EC: D5010013 00062680
	.long 0xd41b0001                                           // 0000001D19F4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v21, vcc_lo              // 0000001D19F8: 02022AFF C2B17218
	v_fma_f32 v20, -v20, v37, v27                              // 0000001D1A00: D6130014 246E4B14
	v_fma_f32 v35, -v26, v28, v30                              // 0000001D1A08: D6130023 247A391A
	.long 0xd71c001b                                           // 0000001D1A10: D71C001B
	v_cndmask_b32_e32 v1, v29, v34, vcc_lo                     // 0000001D1A14: 0202451D
	global_store_d16_hi_b16 v[15:16], v10, off offset:192      // 0000001D1A18: DC9600C0 007C0A0F
	v_cndmask_b32_e64 v19, 0x7f800000, v19, s1                 // 0000001D1A20: D5010013 000626FF 7F800000
	.long 0xd41e0001                                           // 0000001D1A2C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001D1A30: 020232FF 42CE8ED0
	v_fmac_f32_e32 v28, v35, v33                               // 0000001D1A38: 56384323
	v_div_fmas_f32 v18, v20, v18, v37                          // 0000001D1A3C: D6370012 04962514
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001D1A44: 7C3632FF C2B17218
	v_add_f32_e32 v19, 1.0, v19                                // 0000001D1A4C: 062626F2
	v_cndmask_b32_e64 v21, 0, v27, s1                          // 0000001D1A50: D5010015 00063680
	v_fma_f32 v20, -v26, v28, v30                              // 0000001D1A58: D6130014 247A391A
	v_div_fixup_f32 v9, v18, v9, v13                           // 0000001D1A60: D6270009 04361312
	global_store_d16_hi_b16 v[23:24], v11, off offset:192      // 0000001D1A68: DC9600C0 007C0B17
	v_div_scale_f32 v26, null, v19, v19, v1                    // 0000001D1A70: D6FC7C1A 04062713
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001D1A78: 022A2AFF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001D1A80: BEEA0000
	v_lshlrev_b32_e32 v18, 16, v56                             // 0000001D1A84: 30247090
	v_div_fmas_f32 v20, v20, v33, v28                          // 0000001D1A88: D6370014 04724314
	v_rcp_f32_e32 v25, v26                                     // 0000001D1A90: 7E32551A
	v_add_f32_e32 v21, 1.0, v21                                // 0000001D1A94: 062A2AF2
	v_lshlrev_b32_e32 v29, 16, v55                             // 0000001D1A98: 303A6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D1A9C: BF870223
	v_div_fixup_f32 v12, v20, v17, v14                         // 0000001D1AA0: D627000C 043A2314
	.long 0x7e223989                                           // 0000001D1AA8: 7E223989
	v_div_scale_f32 v14, null, v21, v21, v2                    // 0000001D1AAC: D6FC7C0E 040A2B15
	.long 0x7f223980                                           // 0000001D1AB4: 7F223980
	v_mul_f32_e32 v30, 0xbfb8aa3b, v29                         // 0000001D1AB8: 103C3AFF BFB8AA3B
	.long 0x7e00398c                                           // 0000001D1AC0: 7E00398C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001D1AC4: BF8701B5
	v_fma_f32 v10, -v26, v25, 1.0                              // 0000001D1AC8: D613000A 23CA331A
	v_rcp_f32_e32 v13, v14                                     // 0000001D1AD0: 7E1A550E
	v_and_b32_e32 v17, 1, v17                                  // 0000001D1AD4: 36222281
	v_and_b32_e32 v11, 1, v0                                   // 0000001D1AD8: 36160081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D1ADC: BF870223
	v_fmac_f32_e32 v25, v10, v25                               // 0000001D1AE0: 5632330A
	v_div_scale_f32 v10, vcc_lo, v1, v19, v1                   // 0000001D1AE4: D6FC6A0A 04062701
	v_add3_u32 v9, v9, v17, 0x7fff                             // 0000001D1AEC: D6550009 03FE2309 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D1AF8: BF870224
	v_add3_u32 v11, v12, v11, 0x7fff                           // 0000001D1AFC: D655000B 03FE170C 00007FFF
	v_mul_f32_e32 v12, 0xbfb8aa3b, v18                         // 0000001D1B08: 101824FF BFB8AA3B
	v_mul_f32_e32 v20, v10, v25                                // 0000001D1B10: 1028330A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001D1B14: BF870005
	v_fma_f32 v22, -v14, v13, 1.0                              // 0000001D1B18: D6130016 23CA1B0E
	s_clause 0x1                                               // 0000001D1B20: BF850001
	global_store_d16_hi_b16 v[31:32], v9, off offset:192       // 0000001D1B24: DC9600C0 007C091F
	global_store_d16_hi_b16 v[39:40], v11, off offset:192      // 0000001D1B2C: DC9600C0 007C0B27
	v_fma_f32 v27, 0xbfb8aa3b, v18, -v12                       // 0000001D1B34: D613001B 843224FF BFB8AA3B
	v_fma_f32 v17, -v26, v20, v10                              // 0000001D1B40: D6130011 242A291A
	v_fmac_f32_e32 v13, v22, v13                               // 0000001D1B48: 561A1B16
	v_div_scale_f32 v22, s0, v2, v21, v2                       // 0000001D1B4C: D6FC0016 040A2B02
	v_rndne_f32_e32 v28, v12                                   // 0000001D1B54: 7E38470C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D1B58: BF870114
	v_dual_fmac_f32 v27, 0xb2a5705f, v18 :: v_dual_fmac_f32 v20, v17, v25// 0000001D1B5C: C80024FF 1B143311 B2A5705F
	v_dual_mul_f32 v17, v22, v13 :: v_dual_sub_f32 v12, v12, v28// 0000001D1B68: C8CA1B16 110C390C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001D1B70: BF8701A2
	v_fma_f32 v9, -v26, v20, v10                               // 0000001D1B74: D6130009 242A291A
	v_fma_f32 v26, 0xbfb8aa3b, v29, -v30                       // 0000001D1B7C: D613001A 847A3AFF BFB8AA3B
	v_fma_f32 v10, -v14, v17, v22                              // 0000001D1B88: D613000A 245A230E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001D1B90: BF870004
	v_add_f32_e32 v12, v12, v27                                // 0000001D1B94: 0618370C
	v_rndne_f32_e32 v27, v30                                   // 0000001D1B98: 7E36471E
	v_div_fmas_f32 v9, v9, v25, v20                            // 0000001D1B9C: D6370009 04523309
	v_fmac_f32_e32 v26, 0xb2a5705f, v29                        // 0000001D1BA4: 56343AFF B2A5705F
	v_fmac_f32_e32 v17, v10, v13                               // 0000001D1BAC: 56221B0A
	v_exp_f32_e32 v10, v12                                     // 0000001D1BB0: 7E144B0C
	v_sub_f32_e32 v12, v30, v27                                // 0000001D1BB4: 0818371E
	v_lshlrev_b32_e32 v20, 16, v63                             // 0000001D1BB8: 30287E90
	v_cvt_i32_f32_e32 v25, v28                                 // 0000001D1BBC: 7E32111C
	v_fma_f32 v14, -v14, v17, v22                              // 0000001D1BC0: D613000E 245A230E
	s_waitcnt vmcnt(0)                                         // 0000001D1BC8: BF8903F7
	v_lshlrev_b32_e32 v22, 16, v64                             // 0000001D1BCC: 302C8090
	v_add_f32_e32 v12, v12, v26                                // 0000001D1BD0: 0618350C
	v_mul_f32_e32 v26, 0xbfb8aa3b, v20                         // 0000001D1BD4: 103428FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v18                  // 0000001D1BDC: 7C3C24FF 42CE8ED0
	v_cvt_i32_f32_e32 v27, v27                                 // 0000001D1BE4: 7E36111B
	v_mul_f32_e32 v28, 0xbfb8aa3b, v22                         // 0000001D1BE8: 10382CFF BFB8AA3B
	.long 0xd71c000a                                           // 0000001D1BF0: D71C000A
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 0000001D1BF4: 0202330A
	v_fma_f32 v25, 0xbfb8aa3b, v20, -v26                       // 0000001D1BF8: D6130019 846A28FF BFB8AA3B
	v_rndne_f32_e32 v30, v26                                   // 0000001D1C04: 7E3C471A
	v_exp_f32_e32 v12, v12                                     // 0000001D1C08: 7E184B0C
	v_fma_f32 v33, 0xbfb8aa3b, v22, -v28                       // 0000001D1C0C: D6130021 84722CFF BFB8AA3B
	v_rndne_f32_e32 v34, v28                                   // 0000001D1C18: 7E44471C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D1C1C: BF870223
	v_dual_fmac_f32 v25, 0xb2a5705f, v20 :: v_dual_sub_f32 v26, v26, v30// 0000001D1C20: C80A28FF 191A3D1A B2A5705F
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000001D1C2C: 02141480
	v_fmac_f32_e32 v33, 0xb2a5705f, v22                        // 0000001D1C30: 56422CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 0000001D1C38: BF8702B4
	v_sub_f32_e32 v28, v28, v34                                // 0000001D1C3C: 0838451C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v18                  // 0000001D1C40: 7C3624FF C2B17218
	v_add_f32_e32 v25, v26, v25                                // 0000001D1C48: 0632331A
	.long 0xd71c000c                                           // 0000001D1C4C: D71C000C
	v_cndmask_b32_e32 v1, v12, v27, vcc_lo                     // 0000001D1C50: 0202370C
	v_cvt_i32_f32_e32 v27, v34                                 // 0000001D1C54: 7E361122
	v_add_f32_e32 v26, v28, v33                                // 0000001D1C58: 0634431C
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo             // 0000001D1C5C: 021414FF 7F800000
	v_exp_f32_e32 v18, v25                                     // 0000001D1C64: 7E244B19
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001D1C68: 7C3C3AFF 42CE8ED0
	v_div_fixup_f32 v1, v9, v19, v1                            // 0000001D1C70: D6270001 04062709
	v_exp_f32_e32 v25, v26                                     // 0000001D1C78: 7E324B1A
	v_cvt_i32_f32_e32 v26, v30                                 // 0000001D1C7C: 7E34111E
	v_add_f32_e32 v10, 1.0, v10                                // 0000001D1C80: 061414F2
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 0000001D1C84: 02181880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001D1C88: 7C363AFF C2B17218
	.long 0x7e443981                                           // 0000001D1C90: 7E443981
	.long 0x7f443980                                           // 0000001D1C94: 7F443980
	.long 0xd71c0012                                           // 0000001D1C98: D71C0012
	v_cndmask_b32_e32 v1, v18, v26, vcc_lo                     // 0000001D1C9C: 02023512
	v_div_scale_f32 v26, null, v10, v10, v3                    // 0000001D1CA0: D6FC7C1A 040E150A
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 0000001D1CA8: 021818FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v20                  // 0000001D1CB0: 7C3C28FF 42CE8ED0
	.long 0xd71c0019                                           // 0000001D1CB8: D71C0019
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 0000001D1CBC: 02023719
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D1CC0: BF870194
	v_rcp_f32_e32 v27, v26                                     // 0000001D1CC4: 7E36551A
	v_add_f32_e32 v12, 1.0, v12                                // 0000001D1CC8: 061818F2
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001D1CCC: 02242480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v22                  // 0000001D1CD0: 7C3C2CFF 42CE8ED0
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000001D1CD8: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v20                  // 0000001D1CDC: 7C3628FF C2B17218
	v_div_scale_f32 v20, null, v12, v12, v4                    // 0000001D1CE4: D6FC7C14 0412190C
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001D1CEC: 022424FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v22                  // 0000001D1CF4: 7C362CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D1CFC: BF870113
	v_rcp_f32_e32 v28, v20                                     // 0000001D1D00: 7E385514
	v_add_f32_e32 v18, 1.0, v18                                // 0000001D1D04: 062424F2
	v_cndmask_b32_e32 v22, 0x7f800000, v25, vcc_lo             // 0000001D1D08: 022C32FF 7F800000
	v_fma_f32 v25, -v26, v27, 1.0                              // 0000001D1D10: D6130019 23CA371A
	s_mov_b32 vcc_lo, s0                                       // 0000001D1D18: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D1D1C: BF870193
	v_div_scale_f32 v29, null, v18, v18, v5                    // 0000001D1D20: D6FC7C1D 04162512
	v_add_f32_e32 v22, 1.0, v22                                // 0000001D1D28: 062C2CF2
	v_div_fmas_f32 v13, v14, v13, v17                          // 0000001D1D2C: D637000D 04461B0E
	v_fmac_f32_e32 v27, v25, v27                               // 0000001D1D34: 56363719
	v_div_scale_f32 v17, vcc_lo, v3, v10, v3                   // 0000001D1D38: D6FC6A11 040E1503
	v_rcp_f32_e32 v14, v29                                     // 0000001D1D40: 7E1C551D
	v_div_scale_f32 v25, null, v22, v22, v6                    // 0000001D1D44: D6FC7C19 041A2D16
	v_fma_f32 v30, -v20, v28, 1.0                              // 0000001D1D4C: D613001E 23CA3914
	v_div_fixup_f32 v2, v13, v21, v2                           // 0000001D1D54: D6270002 040A2B0D
	v_mul_f32_e32 v11, v17, v27                                // 0000001D1D5C: 10163711
	v_div_scale_f32 v21, s0, v4, v12, v4                       // 0000001D1D60: D6FC0015 04121904
	v_rcp_f32_e32 v13, v25                                     // 0000001D1D68: 7E1A5519
	v_fmac_f32_e32 v28, v30, v28                               // 0000001D1D6C: 5638391E
	.long 0x7e003982                                           // 0000001D1D70: 7E003982
	v_fma_f32 v9, -v26, v11, v17                               // 0000001D1D74: D6130009 2446171A
	v_fma_f32 v30, -v29, v14, 1.0                              // 0000001D1D7C: D613001E 23CA1D1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D1D84: BF870114
	v_mul_f32_e32 v19, v21, v28                                // 0000001D1D88: 10263915
	v_dual_fmac_f32 v11, v9, v27 :: v_dual_fmac_f32 v14, v30, v14// 0000001D1D8C: C8003709 0B0E1D1E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D1D94: BF870225
	v_fma_f32 v33, -v25, v13, 1.0                              // 0000001D1D98: D6130021 23CA1B19
	v_div_scale_f32 v30, s1, v5, v18, v5                       // 0000001D1DA0: D6FC011E 04162505
	v_fma_f32 v9, -v20, v19, v21                               // 0000001D1DA8: D6130009 24562714
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D1DB0: BF870214
	v_fma_f32 v17, -v26, v11, v17                              // 0000001D1DB4: D6130011 2446171A
	v_fmac_f32_e32 v13, v33, v13                               // 0000001D1DBC: 561A1B21
	v_div_scale_f32 v33, s2, v6, v22, v6                       // 0000001D1DC0: D6FC0221 041A2D06
	v_mul_f32_e32 v35, v30, v14                                // 0000001D1DC8: 10461D1E
	v_fmac_f32_e32 v19, v9, v28                                // 0000001D1DCC: 56263909
	v_div_fmas_f32 v11, v17, v27, v11                          // 0000001D1DD0: D637000B 042E3711
	s_mov_b32 vcc_lo, s0                                       // 0000001D1DD8: BEEA0000
	v_mul_f32_e32 v26, v33, v13                                // 0000001D1DDC: 10341B21
	v_fma_f32 v9, -v29, v35, v30                               // 0000001D1DE0: D6130009 247A471D
	v_fma_f32 v17, -v20, v19, v21                              // 0000001D1DE8: D6130011 24562714
	v_div_fixup_f32 v3, v11, v10, v3                           // 0000001D1DF0: D6270003 040E150B
	v_and_b32_e32 v11, 1, v34                                  // 0000001D1DF8: 36164481
	v_fma_f32 v20, -v25, v26, v33                              // 0000001D1DFC: D6130014 24863519
	v_fmac_f32_e32 v35, v9, v14                                // 0000001D1E04: 56461D09
	v_div_fmas_f32 v9, v17, v28, v19                           // 0000001D1E08: D6370009 044E3911
	s_mov_b32 vcc_lo, s1                                       // 0000001D1E10: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001D1E14: BF870193
	v_dual_fmac_f32 v26, v20, v13 :: v_dual_and_b32 v17, 1, v0 // 0000001D1E18: C8241B14 1A100081
	v_fma_f32 v10, -v29, v35, v30                              // 0000001D1E20: D613000A 247A471D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001D1E28: BF870003
	v_div_fixup_f32 v4, v9, v12, v4                            // 0000001D1E2C: D6270004 04121909
	.long 0x7f183980                                           // 0000001D1E34: 7F183980
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001D1E38: D6550001 03FE1701 00007FFF
	v_fma_f32 v9, -v25, v26, v33                               // 0000001D1E44: D6130009 24863519
	v_div_fmas_f32 v10, v10, v14, v35                          // 0000001D1E4C: D637000A 048E1D0A
	s_mov_b32 vcc_lo, s2                                       // 0000001D1E54: BEEA0002
	.long 0x7e003984                                           // 0000001D1E58: 7E003984
	v_add3_u32 v2, v2, v17, 0x7fff                             // 0000001D1E5C: D6550002 03FE2302 00007FFF
	v_div_fmas_f32 v9, v9, v13, v26                            // 0000001D1E68: D6370009 046A1B09
	v_div_fixup_f32 v5, v10, v18, v5                           // 0000001D1E70: D6270005 0416250A
	.long 0x7e143983                                           // 0000001D1E78: 7E143983
	.long 0x7f143980                                           // 0000001D1E7C: 7F143980
	global_store_d16_hi_b16 v[7:8], v1, off offset:224         // 0000001D1E80: DC9600E0 007C0107
	v_div_fixup_f32 v6, v9, v22, v6                            // 0000001D1E88: D6270006 041A2D09
	.long 0x7e183985                                           // 0000001D1E90: 7E183985
	v_and_b32_e32 v9, 1, v0                                    // 0000001D1E94: 36120081
	v_and_b32_e32 v10, 1, v10                                  // 0000001D1E98: 36141481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001D1E9C: BF870214
	.long 0x7e003986                                           // 0000001D1EA0: 7E003986
	v_and_b32_e32 v11, 1, v12                                  // 0000001D1EA4: 36161881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001D1EA8: BF870223
	v_add3_u32 v1, v3, v10, 0x7fff                             // 0000001D1EAC: D6550001 03FE1503 00007FFF
	v_add3_u32 v3, v4, v9, 0x7fff                              // 0000001D1EB8: D6550003 03FE1304 00007FFF
	v_and_b32_e32 v0, 1, v0                                    // 0000001D1EC4: 36000081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001D1EC8: BF870114
	v_add3_u32 v4, v5, v11, 0x7fff                             // 0000001D1ECC: D6550004 03FE1705 00007FFF
	v_add3_u32 v0, v6, v0, 0x7fff                              // 0000001D1ED8: D6550000 03FE0106 00007FFF
	s_clause 0x4                                               // 0000001D1EE4: BF850004
	global_store_d16_hi_b16 v[47:48], v2, off offset:224       // 0000001D1EE8: DC9600E0 007C022F
	global_store_d16_hi_b16 v[15:16], v1, off offset:224       // 0000001D1EF0: DC9600E0 007C010F
	global_store_d16_hi_b16 v[23:24], v3, off offset:224       // 0000001D1EF8: DC9600E0 007C0317
	global_store_d16_hi_b16 v[31:32], v4, off offset:224       // 0000001D1F00: DC9600E0 007C041F
	global_store_d16_hi_b16 v[39:40], v0, off offset:224       // 0000001D1F08: DC9600E0 007C0027
	s_nop 0                                                    // 0000001D1F10: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001D1F14: BFB60003
	s_endpgm                                                   // 0000001D1F18: BFB00000
		...

