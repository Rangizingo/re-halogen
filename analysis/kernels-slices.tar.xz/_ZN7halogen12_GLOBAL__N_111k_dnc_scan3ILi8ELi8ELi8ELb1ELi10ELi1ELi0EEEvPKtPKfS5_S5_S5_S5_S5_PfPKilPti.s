000000000009f900 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 00000009F900: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 00000009F904: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000009F90C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 00000009F914: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 00000009F918: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000009F91C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 00000009F920: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000009F928: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000009F92C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 00000009F930: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 00000009F934: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000009F93C: 84928214
	s_add_u32 s25, s16, s18                                    // 00000009F940: 80191210
	s_addc_u32 s28, s17, s19                                   // 00000009F944: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 00000009F948: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000009F94C: BF870009
	s_add_u32 s25, s25, s20                                    // 00000009F950: 80191419
	s_addc_u32 s30, s28, s21                                   // 00000009F954: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 00000009F958: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000009F95C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 00000009F964: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000009F96C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 00000009F970: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 00000009F974: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000009F978: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000009F97C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 00000009F980: 821E191E
	.long 0xd7001f02                                           // 00000009F984: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 00000009F988: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000009F98C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 00000009F994: BE9E0080
	s_nop 0                                                    // 00000009F998: BF800000
	s_nop 0                                                    // 00000009F99C: BF800000
	s_nop 0                                                    // 00000009F9A0: BF800000
	s_nop 0                                                    // 00000009F9A4: BF800000
	s_nop 0                                                    // 00000009F9A8: BF800000
	s_nop 0                                                    // 00000009F9AC: BF800000
	s_nop 0                                                    // 00000009F9B0: BF800000
	s_nop 0                                                    // 00000009F9B4: BF800000
	s_nop 0                                                    // 00000009F9B8: BF800000
	s_nop 0                                                    // 00000009F9BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 00000009F9C0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 00000009F9C4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009F9CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 00000009F9D0: 300C1089
	.long 0xd7006a06                                           // 00000009F9D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000009F9D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000009F9DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 00000009F9E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000009F9E8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 00000009F9F0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 00000009F9F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 00000009F9FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 00000009FA08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000009FA0C: BF8903F7
	ds_store_b32 v6, v9                                        // 00000009FA10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 00000009FA18: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000009FA1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 00000009FA20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 00000009FA24: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 00000009FA2C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 00000009FA34: 32040084
	s_mov_b32 s0, 0                                            // 00000009FA38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000009FA3C: BF89FC07
	s_barrier                                                  // 00000009FA40: BFBD0000
	buffer_gl0_inv                                             // 00000009FA44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000009FA4C: BF02801E
	s_cbranch_scc1 12                                          // 00000009FA50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 00000009FA54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000009FA5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000009FA64: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 00000009FA68: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 00000009FA70: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000009FA74: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000009FA78: 916A007E
	s_cbranch_vccz 2                                           // 00000009FA7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2088                                              // 00000009FA80: BFA00828 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2224>
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000009FA84: 304E0A82
	s_add_i32 s0, s30, 63                                      // 00000009FA88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000009FA8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 00000009FA94: 85218600
	s_add_u32 s34, s10, s24                                    // 00000009FA98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000009FA9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 00000009FAA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 00000009FAA4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 00000009FAAC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 00000009FAB0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000009FAB4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 00000009FAB8: 301A0488
	s_add_u32 s22, s22, s0                                     // 00000009FABC: 80160016
	s_addc_u32 s1, s23, s1                                     // 00000009FAC0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 00000009FAC4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 00000009FAC8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 00000009FAD4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 00000009FAD8: 82010B01
	s_movk_i32 s10, 0x204                                      // 00000009FADC: B00A0204
	.long 0xd7000b2c                                           // 00000009FAE0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 00000009FAE4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000009FAE8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 00000009FAEC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 00000009FAF4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 00000009FB00: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 00000009FB04: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 00000009FB10: 3816500A
	.long 0xd7000a05                                           // 00000009FB14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 00000009FB18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000009FB1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 00000009FB20: D5207C06 00290001
	.long 0xd7000107                                           // 00000009FB28: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 00000009FB2C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000009FB30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 00000009FB34: D5207C08 0006180D
	.long 0xd7000109                                           // 00000009FB3C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 00000009FB40: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 00000009FB44: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 00000009FB4C: 84848E02
	.long 0xd700010b                                           // 00000009FB50: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 00000009FB54: 02021606
	s_add_u32 s4, s14, s4                                      // 00000009FB58: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 00000009FB5C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 00000009FB64: 8205050F
	.long 0xd700010d                                           // 00000009FB68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 00000009FB6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000009FB70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 00000009FB74: D5207C0E 00050005
	.long 0xd700010f                                           // 00000009FB7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 00000009FB80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 00000009FB88: D5207C10 00061880
	.long 0xd7000111                                           // 00000009FB90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 00000009FB94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000009FB9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 00000009FBA0: D5207C12 00061880
	.long 0xd7000113                                           // 00000009FBA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 00000009FBAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 00000009FBB4: D5207C14 00061880
	.long 0xd7000115                                           // 00000009FBBC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 00000009FBC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000009FBC8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 00000009FBCC: D5207C16 00061880
	.long 0xd7000117                                           // 00000009FBD4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 00000009FBD8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 00000009FBE0: D5207C18 00061880
	.long 0xd7000119                                           // 00000009FBE8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 00000009FBEC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000009FBF4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 00000009FBF8: D5207C1A 00061880
	.long 0xd700011b                                           // 00000009FC00: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 00000009FC04: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 00000009FC0C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 00000009FC14: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000009FC18: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 00000009FC20: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 00000009FC24: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 00000009FC2C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 00000009FC34: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 00000009FC3C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 00000009FC44: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 00000009FC4C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 00000009FC54: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 00000009FC5C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 00000009FC64: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 00000009FC6C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 00000009FC74: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 00000009FC7C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 00000009FC84: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 00000009FC8C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 00000009FC94: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 00000009FC9C: BE850080
	s_mov_b32 s6, 4.0                                          // 00000009FCA0: BE8600F6
	s_mov_b32 s7, 0x3e800000                                   // 00000009FCA4: BE8700FF 3E800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000009FCAC: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 00000009FCB0: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000009FCB8: BF870499
	s_add_i32 s10, s31, s1                                     // 00000009FCBC: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 00000009FCC0: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000009FCC4: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 00000009FCC8: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 00000009FCCC: 840B8605
	s_add_u32 s12, s8, s12                                     // 00000009FCD0: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 00000009FCD4: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 00000009FCD8: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 00000009FCE0: BE84206A
	s_cbranch_execz 77                                         // 00000009FCE4: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51c>
	v_or_b32_e32 v29, s11, v0                                  // 00000009FCE8: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009FCEC: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 00000009FCF0: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 00000009FCF8: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009FCFC: BF870091
	.long 0xd73c001d                                           // 00000009FD00: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 00000009FD04: 02023A82
	.long 0xd700011d                                           // 00000009FD08: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 00000009FD0C: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000009FD10: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 00000009FD14: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 00000009FD1C: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000009FD24: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 00000009FD28: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 00000009FD2C: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000009FD38: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 00000009FD3C: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 00000009FD48: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 00000009FD4C: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 00000009FD58: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000009FD5C: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 00000009FD60: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 00000009FD6C: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000009FD70: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 00000009FD74: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 00000009FD7C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 00000009FD80: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 00000009FD88: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 00000009FD90: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 00000009FD94: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000009FD98: BF870193
	v_exp_f32_e32 v32, v32                                     // 00000009FD9C: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 00000009FDA0: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000009FDA4: BF870296
	.long 0xd71c0020                                           // 00000009FDA8: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 00000009FDAC: 02024520
	.long 0xd71c001f                                           // 00000009FDB0: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 00000009FDB4: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000009FDB8: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 00000009FDBC: D501001F 00063E80
	.long 0xd41b0001                                           // 00000009FDC4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 00000009FDC8: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 00000009FDD0: D5010020 00064080
	.long 0xd41e0001                                           // 00000009FDD8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 00000009FDDC: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000009FDE4: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 00000009FDE8: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 00000009FDF4: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 00000009FDF8: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 00000009FE00: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 00000009FE0C: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 00000009FE14: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 00000009FE1C: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 00000009FE20: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 00000009FE28: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 00000009FE2C: BF89FC07
	s_barrier                                                  // 00000009FE30: BFBD0000
	buffer_gl0_inv                                             // 00000009FE34: E0AC0000 00000000
	s_branch 15                                                // 00000009FE3C: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x57c>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000009FE40: 8C7E047E
	.long 0xd700011d                                           // 00000009FE44: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 00000009FE48: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000009FE50: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000009FE54: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 00000009FE5C: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 00000009FE60: BF08B70C
	s_mov_b32 s12, s1                                          // 00000009FE64: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 00000009FE68: BF89FC07
	s_barrier                                                  // 00000009FE6C: BFBD0000
	buffer_gl0_inv                                             // 00000009FE70: E0AC0000 00000000
	s_cbranch_scc1 183                                         // 00000009FE78: BFA200B7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x858>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 00000009FE7C: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 00000009FE84: CA100128 21220126
	s_mov_b32 s13, 0                                           // 00000009FE8C: BE8D0080
	s_nop 0                                                    // 00000009FE90: BF800000
	s_nop 0                                                    // 00000009FE94: BF800000
	s_nop 0                                                    // 00000009FE98: BF800000
	s_nop 0                                                    // 00000009FE9C: BF800000
	s_nop 0                                                    // 00000009FEA0: BF800000
	s_nop 0                                                    // 00000009FEA4: BF800000
	s_nop 0                                                    // 00000009FEA8: BF800000
	s_nop 0                                                    // 00000009FEAC: BF800000
	s_nop 0                                                    // 00000009FEB0: BF800000
	s_nop 0                                                    // 00000009FEB4: BF800000
	s_nop 0                                                    // 00000009FEB8: BF800000
	s_nop 0                                                    // 00000009FEBC: BF800000
	global_load_b32 v35, v[31:32], off                         // 00000009FEC0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 00000009FEC8: 4A4444FF 00000080
	.long 0xd700011f                                           // 00000009FED0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 00000009FED4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000009FEDC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000009FEE0: D5207C20 00064080
	.long 0xd4490004                                           // 00000009FEE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 00000009FEEC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 00000009FEF4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 00000009FEF8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 00000009FEFC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 00000009FF04: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 00000009FF0C: 917E0D7E
	s_cbranch_execnz 65515                                     // 00000009FF10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 00000009FF14: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 00000009FF18: BF89FC07
	s_barrier                                                  // 00000009FF1C: BFBD0000
	buffer_gl0_inv                                             // 00000009FF20: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000009FF28: BE842000
	s_cbranch_execz 65476                                      // 00000009FF2C: BFA5FFC4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x540>
	v_or3_b32 v31, s12, s11, v2                                // 00000009FF30: D658001F 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009FF38: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 00000009FF3C: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 00000009FF44: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 00000009FF48: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009FF4C: BF870091
	.long 0xd700011f                                           // 00000009FF50: D700011F
	v_cndmask_b32_e32 v1, v44, v31, vcc_lo                     // 00000009FF54: 02023F2C
	v_add_co_ci_u32_e64 v32, null, v45, v32, s1                // 00000009FF58: D5207C20 0006412D
	s_mov_b32 s1, 0                                            // 00000009FF60: BE810080
	global_load_b32 v31, v[31:32], off                         // 00000009FF64: DC520000 1F7C001F
	v_mad_u64_u32 v[32:33], null, 0x44, s1, v[1:2]             // 00000009FF6C: D6FE7C20 040402FF 00000044
	s_add_i32 s13, s1, 8                                       // 00000009FF78: 810D8801
	s_cmpk_lt_u32 s1, 0x78                                     // 00000009FF7C: B6810078
	ds_load_2addr_b32 v[33:34], v32 offset1:17                 // 00000009FF80: D8DC1100 21000020
	ds_load_2addr_b32 v[35:36], v32 offset0:34 offset1:51      // 00000009FF88: D8DC3322 23000020
	ds_load_2addr_b32 v[60:61], v32 offset0:68 offset1:85      // 00000009FF90: D8DC5544 3C000020
	ds_load_2addr_b32 v[62:63], v32 offset0:102 offset1:119    // 00000009FF98: D8DC7766 3E000020
	v_lshl_add_u32 v32, s1, 2, v46                             // 00000009FFA0: D6460020 04B90401
	s_mov_b32 s1, s13                                          // 00000009FFA8: BE81000D
	ds_load_2addr_b32 v[64:65], v32 offset1:1                  // 00000009FFAC: D8DC0100 40000020
	ds_load_2addr_b32 v[66:67], v32 offset0:2 offset1:3        // 00000009FFB4: D8DC0302 42000020
	ds_load_2addr_b32 v[68:69], v32 offset0:4 offset1:5        // 00000009FFBC: D8DC0504 44000020
	ds_load_2addr_b32 v[70:71], v32 offset0:6 offset1:7        // 00000009FFC4: D8DC0706 46000020
	s_waitcnt lgkmcnt(7)                                       // 00000009FFCC: BF89FC77
	v_fma_mixlo_f16 v32, v33, s6, 0                            // 00000009FFD0: CC210020 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 00000009FFD8: CC210022 02000D22
	s_waitcnt lgkmcnt(6)                                       // 00000009FFE0: BF89FC67
	v_fma_mixlo_f16 v35, v35, s6, 0                            // 00000009FFE4: CC210023 02000D23
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000009FFEC: BF870193
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 00000009FFF0: CC200020 8A000F20
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 00000009FFF8: CC200022 8A000F22
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000A0000: BF870003
	v_fma_mix_f32 v35, v35, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A0004: CC200023 8A000F23
	s_waitcnt lgkmcnt(3)                                       // 0000000A000C: BF89FC37
	v_fma_mixlo_f16 v33, v64, s6, 0                            // 0000000A0010: CC210021 02000D40
	v_fma_mixlo_f16 v64, v65, s6, 0                            // 0000000A0018: CC210040 02000D41
	s_waitcnt lgkmcnt(2)                                       // 0000000A0020: BF89FC27
	v_fma_mixlo_f16 v65, v66, s6, 0                            // 0000000A0024: CC210041 02000D42
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A002C: BF870193
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A0030: CC200021 8A000F21
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A0038: CC200040 8A000F40
	s_waitcnt vmcnt(0)                                         // 0000000A0040: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000A0044: BF870242
	v_fma_f32 v31, -v33, v32, v31                              // 0000000A0048: D613001F 247E4121
	v_fma_mixlo_f16 v32, v36, s6, 0                            // 0000000A0050: CC210020 02000D24
	v_fma_mixlo_f16 v33, v67, s6, 0                            // 0000000A0058: CC210021 02000D43
	v_fma_mix_f32 v36, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A0060: CC200024 8A000F41
	v_fma_f32 v31, -v64, v34, v31                              // 0000000A0068: D613001F 247E4540
	v_fma_mixlo_f16 v34, v60, s6, 0                            // 0000000A0070: CC210022 02000D3C
	s_waitcnt lgkmcnt(1)                                       // 0000000A0078: BF89FC17
	v_fma_mixlo_f16 v60, v68, s6, 0                            // 0000000A007C: CC21003C 02000D44
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A0084: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A008C: CC200021 8A000F21
	v_fma_f32 v31, -v36, v35, v31                              // 0000000A0094: D613001F 247E4724
	v_fma_mixlo_f16 v35, v61, s6, 0                            // 0000000A009C: CC210023 02000D3D
	v_fma_mixlo_f16 v36, v69, s6, 0                            // 0000000A00A4: CC210024 02000D45
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A00AC: CC200022 8A000F22
	v_fma_mix_f32 v60, v60, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A00B4: CC20003C 8A000F3C
	v_fma_f32 v31, -v33, v32, v31                              // 0000000A00BC: D613001F 247E4121
	v_fma_mixlo_f16 v32, v62, s6, 0                            // 0000000A00C4: CC210020 02000D3E
	s_waitcnt lgkmcnt(0)                                       // 0000000A00CC: BF89FC07
	v_fma_mixlo_f16 v33, v70, s6, 0                            // 0000000A00D0: CC210021 02000D46
	v_fma_mix_f32 v35, v35, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A00D8: CC200023 8A000F23
	v_fma_mix_f32 v36, v36, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A00E0: CC200024 8A000F24
	v_fma_f32 v31, -v60, v34, v31                              // 0000000A00E8: D613001F 247E453C
	v_fma_mixlo_f16 v34, v63, s6, 0                            // 0000000A00F0: CC210022 02000D3F
	v_fma_mixlo_f16 v60, v71, s6, 0                            // 0000000A00F8: CC21003C 02000D47
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A0100: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A0108: CC200021 8A000F21
	v_fma_f32 v31, -v36, v35, v31                              // 0000000A0110: D613001F 247E4724
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A0118: CC200022 8A000F22
	v_fma_mix_f32 v35, v60, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A0120: CC200023 8A000F3C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0128: BF870093
	v_fma_f32 v31, -v33, v32, v31                              // 0000000A012C: D613001F 247E4121
	v_fma_f32 v31, -v35, v34, v31                              // 0000000A0134: D613001F 247E4523
	s_cbranch_scc1 65419                                       // 0000000A013C: BFA2FF8B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x66c>
	v_mad_u64_u32 v[32:33], null, 0x44, s12, v[4:5]            // 0000000A0140: D6FE7C20 041018FF 00000044
	ds_store_b32 v32, v31                                      // 0000000A014C: D8340000 00001F20
	s_branch 65338                                             // 0000000A0154: BFA0FF3A <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x540>
	v_mov_b32_e32 v30, v14                                     // 0000000A0158: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000A015C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000A0164: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 0000000A0168: 7E46032B
	s_mov_b32 s12, 0                                           // 0000000A016C: BE8C0080
	s_branch 21                                                // 0000000A0170: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8c8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000A0174: 8C7E0D7E
	.long 0xd700011f                                           // 0000000A0178: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000A017C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A0184: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000A0188: D5207C20 00064080
	.long 0xd700011d                                           // 0000000A0190: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000A0194: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000A019C: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A01A0: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000A01A8: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000A01AC: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000A01B0: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000A01B4: BC7C0000
	s_barrier                                                  // 0000000A01B8: BFBD0000
	buffer_gl0_inv                                             // 0000000A01BC: E0AC0000 00000000
	s_cbranch_scc1 606                                         // 0000000A01C4: BFA2025E <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1240>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A01C8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000A01CC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000A01D4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000A01D8: 7E780326
	s_mov_b32 s13, 0                                           // 0000000A01DC: BE8D0080
	s_nop 0                                                    // 0000000A01E0: BF800000
	s_nop 0                                                    // 0000000A01E4: BF800000
	s_nop 0                                                    // 0000000A01E8: BF800000
	s_nop 0                                                    // 0000000A01EC: BF800000
	s_nop 0                                                    // 0000000A01F0: BF800000
	s_nop 0                                                    // 0000000A01F4: BF800000
	s_nop 0                                                    // 0000000A01F8: BF800000
	s_nop 0                                                    // 0000000A01FC: BF800000
	global_load_b32 v61, v[33:34], off                         // 0000000A0200: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000A0208: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000A0210: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000A0214: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A021C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000A0220: D5207C22 00064480
	.long 0xd4490004                                           // 0000000A0228: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000A022C: 020278FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000A0234: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000A0238: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000000A023C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 0000000A0244: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000A024C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000A0250: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x900>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000A0254: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000A0258: BF89FC07
	s_barrier                                                  // 0000000A025C: BFBD0000
	buffer_gl0_inv                                             // 0000000A0260: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000A0268: BE8D2000
	s_cbranch_execz 65473                                      // 0000000A026C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x874>
	v_or_b32_e32 v33, s12, v2                                  // 0000000A0270: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0274: BF870091
	v_or_b32_e32 v36, s11, v33                                 // 0000000A0278: 3848420B
	.long 0xd4440001                                           // 0000000A027C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 0000000A0280: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000A0284: 8B7E017E
	s_cbranch_execz 65466                                      // 0000000A0288: BFA5FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x874>
	ds_load_2addr_b32 v[60:61], v46 offset1:1                  // 0000000A028C: D8DC0100 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000A0294: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 0000000A029C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 0000000A02A4: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:4 offset1:5        // 0000000A02AC: D8DC0504 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:6 offset1:7        // 0000000A02B4: D8DC0706 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:68 offset1:85       // 0000000A02BC: D8DC5544 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:102 offset1:119     // 0000000A02C4: D8DC7766 4A000001
	s_mov_b32 s14, 0                                           // 0000000A02CC: BE8E0080
	s_waitcnt lgkmcnt(6)                                       // 0000000A02D0: BF89FC67
	v_fma_f32 v76, v60, v62, 0                                 // 0000000A02D4: D613004C 02027D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A02DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A02E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A02E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A02E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A02EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A02F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A02F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A02F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A02FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0300: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0304: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0308: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A030C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0310: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:8 offset1:9        // 0000000A0314: D8DC0908 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:136 offset1:153     // 0000000A031C: D8DC9988 3E000001
	ds_load_2addr_b32 v[64:65], v46 offset0:10 offset1:11      // 0000000A0324: D8DC0B0A 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:170 offset1:187     // 0000000A032C: D8DCBBAA 42000001
	ds_load_2addr_b32 v[68:69], v46 offset0:12 offset1:13      // 0000000A0334: D8DC0D0C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:14 offset1:15      // 0000000A033C: D8DC0F0E 4600002E
	ds_load_2addr_b32 v[72:73], v1 offset0:204 offset1:221     // 0000000A0344: D8DCDDCC 48000001
	ds_load_2addr_b32 v[74:75], v1 offset0:238 offset1:255     // 0000000A034C: D8DCFFEE 4A000001
	s_waitcnt lgkmcnt(6)                                       // 0000000A0354: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A0358: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A035C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A0360: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A0364: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A0368: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A036C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A0370: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A0374: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A0378: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A037C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0380: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0384: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0388: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A038C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0390: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:16 offset1:17      // 0000000A0394: D8DC1110 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:16 offset1:33      // 0000000A039C: D8DC2110 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:18 offset1:19      // 0000000A03A4: D8DC1312 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000A03AC: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:20 offset1:21      // 0000000A03B4: D8DC1514 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:22 offset1:23      // 0000000A03BC: D8DC1716 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:84 offset1:101     // 0000000A03C4: D8DC6554 48000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000A03CC: D8DC8776 4A000030
	s_waitcnt lgkmcnt(6)                                       // 0000000A03D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A03D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A03DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A03E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A03E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A03E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A03EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A03F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A03F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A03F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A03FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0400: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0404: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0408: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A040C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0410: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 0000000A0414: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 0000000A041C: D8DCA998 3E000030
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 0000000A0424: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 0000000A042C: D8DCCBBA 42000030
	ds_load_2addr_b32 v[68:69], v46 offset0:28 offset1:29      // 0000000A0434: D8DC1D1C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000A043C: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:220 offset1:237    // 0000000A0444: D8DCEDDC 48000030
	ds_load_2addr_b32 v[74:75], v49 offset0:126 offset1:143    // 0000000A044C: D8DC8F7E 4A000031
	s_waitcnt lgkmcnt(6)                                       // 0000000A0454: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A0458: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A045C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A0460: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A0464: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A0468: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A046C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A0470: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A0474: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A0478: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A047C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0480: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0484: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0488: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A048C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0490: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:32 offset1:33      // 0000000A0494: D8DC2120 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:32 offset1:49      // 0000000A049C: D8DC3120 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:34 offset1:35      // 0000000A04A4: D8DC2322 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:66 offset1:83      // 0000000A04AC: D8DC5342 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:36 offset1:37      // 0000000A04B4: D8DC2524 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:38 offset1:39      // 0000000A04BC: D8DC2726 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000A04C4: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000A04CC: D8DC9786 4A000032
	s_waitcnt lgkmcnt(6)                                       // 0000000A04D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A04D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A04DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A04E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A04E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A04E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A04EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A04F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A04F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A04F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A04FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0500: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0504: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0508: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A050C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0510: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:40 offset1:41      // 0000000A0514: D8DC2928 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:168 offset1:185    // 0000000A051C: D8DCB9A8 3E000032
	ds_load_2addr_b32 v[64:65], v46 offset0:42 offset1:43      // 0000000A0524: D8DC2B2A 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:202 offset1:219    // 0000000A052C: D8DCDBCA 42000032
	ds_load_2addr_b32 v[68:69], v46 offset0:44 offset1:45      // 0000000A0534: D8DC2D2C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:46 offset1:47      // 0000000A053C: D8DC2F2E 4600002E
	ds_load_2addr_b32 v[72:73], v50 offset0:236 offset1:253    // 0000000A0544: D8DCFDEC 48000032
	ds_load_2addr_b32 v[74:75], v51 offset0:14 offset1:31      // 0000000A054C: D8DC1F0E 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000A0554: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A0558: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A055C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A0560: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A0564: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A0568: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A056C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A0570: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A0574: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A0578: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A057C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0580: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0584: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0588: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A058C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0590: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 0000000A0594: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 0000000A059C: D8DC4130 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 0000000A05A4: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 0000000A05AC: D8DC6352 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:52 offset1:53      // 0000000A05B4: D8DC3534 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:54 offset1:55      // 0000000A05BC: D8DC3736 4600002E
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000A05C4: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000A05CC: D8DCA796 4A000033
	s_waitcnt lgkmcnt(6)                                       // 0000000A05D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A05D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A05DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A05E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A05E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A05E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A05EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A05F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A05F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A05F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A05FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0600: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0604: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0608: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A060C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0610: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:56 offset1:57      // 0000000A0614: D8DC3938 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:184 offset1:201    // 0000000A061C: D8DCC9B8 3E000033
	ds_load_2addr_b32 v[64:65], v46 offset0:58 offset1:59      // 0000000A0624: D8DC3B3A 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:218 offset1:235    // 0000000A062C: D8DCEBDA 42000033
	ds_load_2addr_b32 v[68:69], v46 offset0:60 offset1:61      // 0000000A0634: D8DC3D3C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:62 offset1:63      // 0000000A063C: D8DC3F3E 4600002E
	ds_load_2addr_b32 v[72:73], v52 offset0:124 offset1:141    // 0000000A0644: D8DC8D7C 48000034
	ds_load_2addr_b32 v[74:75], v53 offset0:30 offset1:47      // 0000000A064C: D8DC2F1E 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000A0654: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A0658: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A065C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A0660: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A0664: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A0668: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A066C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A0670: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A0674: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A0678: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A067C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0680: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0684: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0688: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A068C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0690: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:64 offset1:65      // 0000000A0694: D8DC4140 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:64 offset1:81      // 0000000A069C: D8DC5140 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:66 offset1:67      // 0000000A06A4: D8DC4342 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:98 offset1:115     // 0000000A06AC: D8DC7362 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:68 offset1:69      // 0000000A06B4: D8DC4544 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:70 offset1:71      // 0000000A06BC: D8DC4746 4600002E
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000A06C4: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000A06CC: D8DCB7A6 4A000035
	s_waitcnt lgkmcnt(6)                                       // 0000000A06D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A06D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A06DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A06E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A06E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A06E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A06EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A06F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A06F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A06F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A06FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0700: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0704: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0708: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A070C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0710: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 0000000A0714: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 0000000A071C: D8DCD9C8 3E000035
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 0000000A0724: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 0000000A072C: D8DCFBEA 42000035
	ds_load_2addr_b32 v[68:69], v46 offset0:76 offset1:77      // 0000000A0734: D8DC4D4C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:78 offset1:79      // 0000000A073C: D8DC4F4E 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:12 offset1:29      // 0000000A0744: D8DC1D0C 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:46 offset1:63      // 0000000A074C: D8DC3F2E 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000A0754: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A0758: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A075C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A0760: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A0764: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A0768: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A076C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A0770: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A0774: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A0778: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A077C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0780: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0784: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0788: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A078C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0790: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:80 offset1:81      // 0000000A0794: D8DC5150 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:80 offset1:97      // 0000000A079C: D8DC6150 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:82 offset1:83      // 0000000A07A4: D8DC5352 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:114 offset1:131    // 0000000A07AC: D8DC8372 42000036
	ds_load_2addr_b32 v[68:69], v46 offset0:84 offset1:85      // 0000000A07B4: D8DC5554 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:86 offset1:87      // 0000000A07BC: D8DC5756 4600002E
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000A07C4: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000A07CC: D8DCC7B6 4A000036
	s_waitcnt lgkmcnt(6)                                       // 0000000A07D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A07D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A07DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A07E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A07E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A07E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A07EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A07F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A07F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A07F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A07FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0800: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0804: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0808: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A080C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0810: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:88 offset1:89      // 0000000A0814: D8DC5958 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:216 offset1:233    // 0000000A081C: D8DCE9D8 3E000036
	ds_load_2addr_b32 v[64:65], v46 offset0:90 offset1:91      // 0000000A0824: D8DC5B5A 4000002E
	ds_load_2addr_b32 v[66:67], v55 offset0:122 offset1:139    // 0000000A082C: D8DC8B7A 42000037
	ds_load_2addr_b32 v[68:69], v46 offset0:92 offset1:93      // 0000000A0834: D8DC5D5C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:94 offset1:95      // 0000000A083C: D8DC5F5E 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:28 offset1:45      // 0000000A0844: D8DC2D1C 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:62 offset1:79      // 0000000A084C: D8DC4F3E 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000A0854: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A0858: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A085C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A0860: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A0864: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A0868: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A086C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A0870: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A0874: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A0878: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A087C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0880: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0884: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0888: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A088C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0890: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 0000000A0894: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 0000000A089C: D8DC7160 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 0000000A08A4: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 0000000A08AC: D8DC9382 42000038
	ds_load_2addr_b32 v[68:69], v46 offset0:100 offset1:101    // 0000000A08B4: D8DC6564 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:102 offset1:103    // 0000000A08BC: D8DC6766 4600002E
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000A08C4: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000A08CC: D8DCD7C6 4A000038
	s_waitcnt lgkmcnt(6)                                       // 0000000A08D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A08D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A08DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A08E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A08E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A08E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A08EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A08F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A08F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A08F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A08FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0900: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0904: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0908: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A090C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0910: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:104 offset1:105    // 0000000A0914: D8DC6968 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:232 offset1:249    // 0000000A091C: D8DCF9E8 3E000038
	ds_load_2addr_b32 v[64:65], v46 offset0:106 offset1:107    // 0000000A0924: D8DC6B6A 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:10 offset1:27      // 0000000A092C: D8DC1B0A 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:108 offset1:109    // 0000000A0934: D8DC6D6C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:110 offset1:111    // 0000000A093C: D8DC6F6E 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:44 offset1:61      // 0000000A0944: D8DC3D2C 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:78 offset1:95      // 0000000A094C: D8DC5F4E 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000A0954: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A0958: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A095C: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A0960: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A0964: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A0968: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A096C: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A0970: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A0974: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A0978: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A097C: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0980: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0984: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0988: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A098C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0990: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:112 offset1:113    // 0000000A0994: D8DC7170 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:112 offset1:129    // 0000000A099C: D8DC8170 3E000039
	ds_load_2addr_b32 v[64:65], v46 offset0:114 offset1:115    // 0000000A09A4: D8DC7372 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:146 offset1:163    // 0000000A09AC: D8DCA392 42000039
	ds_load_2addr_b32 v[68:69], v46 offset0:116 offset1:117    // 0000000A09B4: D8DC7574 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:118 offset1:119    // 0000000A09BC: D8DC7776 4600002E
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000A09C4: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000A09CC: D8DCE7D6 4A000039
	s_waitcnt lgkmcnt(6)                                       // 0000000A09D4: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A09D8: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A09DC: BF8700A1
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A09E0: 56987F3D
	s_waitcnt lgkmcnt(4)                                       // 0000000A09E4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A09E8: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A09EC: BF8700A1
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A09F0: 56988741
	s_waitcnt lgkmcnt(1)                                       // 0000000A09F4: BF89FC17
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A09F8: 56989144
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A09FC: BF8700A1
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0A00: 56989345
	s_waitcnt lgkmcnt(0)                                       // 0000000A0A04: BF89FC07
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0A08: 56989546
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A0A0C: BF870001
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0A10: 56989747
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 0000000A0A14: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 0000000A0A1C: D8DC8978 3E00003A
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 0000000A0A24: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[66:67], v59 offset0:26 offset1:43      // 0000000A0A2C: D8DC2B1A 4200003B
	ds_load_2addr_b32 v[68:69], v46 offset0:124 offset1:125    // 0000000A0A34: D8DC7D7C 4400002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 0000000A0A3C: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 0000000A0A44: D8DC4D3C 4800003B
	ds_load_2addr_b32 v[74:75], v59 offset0:94 offset1:111     // 0000000A0A4C: D8DC6F5E 4A00003B
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000A0A54: 30424282
	s_waitcnt lgkmcnt(6)                                       // 0000000A0A58: BF89FC67
	v_fmac_f32_e32 v76, v60, v62                               // 0000000A0A5C: 56987D3C
	ds_load_b32 v60, v33 offset:17440                          // 0000000A0A60: D8D84420 3C000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000A0A68: CA10011E 2220011D
	v_mov_b32_e32 v62, v35                                     // 0000000A0A70: 7E7C0323
	v_fmac_f32_e32 v76, v61, v63                               // 0000000A0A74: 56987F3D
	v_mov_b32_e32 v61, v1                                      // 0000000A0A78: 7E7A0301
	s_waitcnt lgkmcnt(5)                                       // 0000000A0A7C: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0A80: BF870092
	v_fmac_f32_e32 v76, v64, v66                               // 0000000A0A84: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 0000000A0A88: 56988741
	s_waitcnt lgkmcnt(2)                                       // 0000000A0A8C: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0A90: BF870091
	v_fmac_f32_e32 v76, v68, v72                               // 0000000A0A94: 56989144
	v_fmac_f32_e32 v76, v69, v73                               // 0000000A0A98: 56989345
	s_waitcnt lgkmcnt(1)                                       // 0000000A0A9C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0AA0: BF870091
	v_fmac_f32_e32 v76, v70, v74                               // 0000000A0AA4: 56989546
	v_fmac_f32_e32 v76, v71, v75                               // 0000000A0AA8: 56989747
	s_waitcnt lgkmcnt(0)                                       // 0000000A0AAC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A0AB0: BF870001
	v_mul_f32_e32 v60, v76, v60                                // 0000000A0AB4: 1078794C
	s_nop 0                                                    // 0000000A0AB8: BF800000
	s_nop 0                                                    // 0000000A0ABC: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000A0AC0: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000A0AC8: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000A0AD0: 4A7C7CC1
	.long 0xd7000121                                           // 0000000A0AD4: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000A0AD8: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A0ADC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000A0AE0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000A0AE8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000A0AEC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000A0AF0: 4A7A7AFF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000A0AF8: 8C0E0E04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A0AFC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 0000000A0B00: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000A0B04: 917E0E7E
	s_cbranch_execnz 65517                                     // 0000000A0B08: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11c0>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000A0B0C: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A0B10: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 0000000A0B14: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 0000000A0B1C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 0000000A0B28: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 0000000A0B34: DC960000 007C2421
	s_branch 64909                                             // 0000000A0B3C: BFA0FD8D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x874>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000A0B40: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 0000000A0B48: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000A0B4C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000A0B50: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000A0B58: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000A0B5C: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000A0B64: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000A0B6C: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000A0B70: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000A0B74: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000A0B7C: A0010401
	s_mov_b32 s4, 0                                            // 0000000A0B80: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000A0B84: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000A0B88: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000A0B8C: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000A0B90: BF870585
	.long 0xd71c001d                                           // 0000000A0B94: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000A0B98: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000A0B9C: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000A0BA0: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000A0BA8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000A0BAC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000A0BB4: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000000A0BB8: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000A0BBC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000A0BC8: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000A0BD0: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A0BD8: BF870001
	.long 0xd4490001                                           // 0000000A0BDC: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000A0BE0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000A0BE8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000A0BEC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000A0BF0: 1040411E
	ds_store_b32 v29, v32                                      // 0000000A0BF4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000A0BFC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A0C04: 917E047E
	s_cbranch_execnz 65519                                     // 0000000A0C08: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x12c8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A0C0C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000A0C10: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 0000000A0C18: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 0000000A0C20: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A0C24: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A0C28: BF89FC07
	s_barrier                                                  // 0000000A0C2C: BFBD0000
	buffer_gl0_inv                                             // 0000000A0C30: E0AC0000 00000000
	s_nop 0                                                    // 0000000A0C38: BF800000
	s_nop 0                                                    // 0000000A0C3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A0C40: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 0000000A0C48: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A0C50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A0C58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A0C5C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000A0C64: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A0C68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A0C70: BF870004
	.long 0xd4490004                                           // 0000000A0C74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A0C78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A0C80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A0C84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A0C88: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 0000000A0C8C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000A0C94: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A0C9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A0CA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1340>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A0CA4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000A0CA8: BF89FC07
	s_barrier                                                  // 0000000A0CAC: BFBD0000
	buffer_gl0_inv                                             // 0000000A0CB0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000A0CB8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000000A0CC0: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000000A0CC8: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000000A0CD0: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000A0CD8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000A0CDC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A0CE0: BF840001
	s_nop 0                                                    // 0000000A0CE4: BF800000
	s_nop 0                                                    // 0000000A0CE8: BF800000
	s_nop 0                                                    // 0000000A0CEC: BF800000
	s_nop 0                                                    // 0000000A0CF0: BF800000
	s_nop 0                                                    // 0000000A0CF4: BF800000
	s_nop 0                                                    // 0000000A0CF8: BF800000
	s_nop 0                                                    // 0000000A0CFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A0D00: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000A0D04: 327A7884
	.long 0xd4490001                                           // 0000000A0D08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A0D0C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000A0D14: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000A0D18: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A0D24: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000A0D28: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000A0D30: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000A0D38: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000A0D40: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000A0D48: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000A0D50: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000A0D58: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000A0D60: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000A0D64: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A0D70: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000A0D74: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000A0D78: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000A0D80: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000A0D84: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000A0D88: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000A0D8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0D90: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000A0D94: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000A0D98: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000A0D9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0DA0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000A0DA4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000A0DB0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000A0DB8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A0DC0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A0DC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1400>
	s_set_inst_prefetch_distance 0x2                           // 0000000A0DC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A0DCC: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000000A0DD0: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A0DD8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A0DE0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A0DE4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A0DE8: BF89FC07
	s_barrier                                                  // 0000000A0DEC: BFBD0000
	buffer_gl0_inv                                             // 0000000A0DF0: E0AC0000 00000000
	s_nop 0                                                    // 0000000A0DF8: BF800000
	s_nop 0                                                    // 0000000A0DFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A0E00: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 0000000A0E08: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A0E10: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A0E18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A0E1C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A0E24: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A0E28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A0E30: BF870004
	.long 0xd4490004                                           // 0000000A0E34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A0E38: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A0E40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A0E44: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A0E48: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A0E4C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A0E54: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A0E5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A0E60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1500>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A0E64: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000A0E68: BF89FC07
	s_barrier                                                  // 0000000A0E6C: BFBD0000
	buffer_gl0_inv                                             // 0000000A0E70: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000A0E78: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000000A0E80: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000000A0E88: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000000A0E90: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000A0E98: 7E780300
	s_mov_b32 s4, 0                                            // 0000000A0E9C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A0EA0: BF840001
	s_nop 0                                                    // 0000000A0EA4: BF800000
	s_nop 0                                                    // 0000000A0EA8: BF800000
	s_nop 0                                                    // 0000000A0EAC: BF800000
	s_nop 0                                                    // 0000000A0EB0: BF800000
	s_nop 0                                                    // 0000000A0EB4: BF800000
	s_nop 0                                                    // 0000000A0EB8: BF800000
	s_nop 0                                                    // 0000000A0EBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A0EC0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000A0EC4: 327A7884
	.long 0xd4490001                                           // 0000000A0EC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A0ECC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000A0ED4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000A0ED8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A0EE4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000A0EE8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000A0EF0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000A0EF8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000A0F00: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000A0F08: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000A0F10: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000A0F18: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000A0F20: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000A0F24: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A0F30: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000A0F34: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000A0F38: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000A0F40: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000A0F44: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000A0F48: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000A0F4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0F50: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000A0F54: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000A0F58: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000A0F5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A0F60: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000A0F64: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000A0F70: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000A0F78: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A0F80: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A0F84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000A0F88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A0F8C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000000A0F90: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A0F98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A0FA0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A0FA4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A0FA8: BF89FC07
	s_barrier                                                  // 0000000A0FAC: BFBD0000
	buffer_gl0_inv                                             // 0000000A0FB0: E0AC0000 00000000
	s_nop 0                                                    // 0000000A0FB8: BF800000
	s_nop 0                                                    // 0000000A0FBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A0FC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000000A0FC8: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A0FD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A0FD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A0FDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A0FE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A0FE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A0FF0: BF870004
	.long 0xd4490004                                           // 0000000A0FF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A0FF8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A1000: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A1004: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A1008: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A100C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A1014: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A101C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A1020: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A1024: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000A1028: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000A1030: BF89FC07
	s_barrier                                                  // 0000000A1034: BFBD0000
	buffer_gl0_inv                                             // 0000000A1038: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000A1040: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 0000000A1044: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 0000000A104C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 0000000A1054: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 0000000A105C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000A1064: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A1068: BF840001
	s_nop 0                                                    // 0000000A106C: BF800000
	s_nop 0                                                    // 0000000A1070: BF800000
	s_nop 0                                                    // 0000000A1074: BF800000
	s_nop 0                                                    // 0000000A1078: BF800000
	s_nop 0                                                    // 0000000A107C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000A1080: 327C7A84
	.long 0xd4490001                                           // 0000000A1084: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000A1088: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A1090: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000A1094: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000A1098: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A10A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000A10A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000A10B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000A10B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000A10C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000A10C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000A10D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000A10D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000A10E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000A10E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A10E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000A10EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000A10F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000A1100: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000A1104: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000A1108: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000A110C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1110: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000A1114: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000A1118: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000A111C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1120: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000A1124: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000A1130: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000A1138: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A1140: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A1144: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1780>
	s_set_inst_prefetch_distance 0x2                           // 0000000A1148: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A114C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000A1150: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A1158: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A1160: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A1164: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A1168: BF89FC07
	s_barrier                                                  // 0000000A116C: BFBD0000
	buffer_gl0_inv                                             // 0000000A1170: E0AC0000 00000000
	s_nop 0                                                    // 0000000A1178: BF800000
	s_nop 0                                                    // 0000000A117C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A1180: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000000A1188: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A1190: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A1198: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A119C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A11A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A11A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A11B0: BF870004
	.long 0xd4490004                                           // 0000000A11B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A11B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A11C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A11C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A11C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A11CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A11D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A11DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A11E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1880>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A11E4: 8C7E0A7E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000A11E8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000A11F0: BF89FC07
	s_barrier                                                  // 0000000A11F4: BFBD0000
	buffer_gl0_inv                                             // 0000000A11F8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 0000000A1200: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 0000000A1208: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 0000000A1210: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 0000000A1218: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000A1220: 7E780300
	s_mov_b32 s4, 0                                            // 0000000A1224: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A1228: BF840001
	s_nop 0                                                    // 0000000A122C: BF800000
	s_nop 0                                                    // 0000000A1230: BF800000
	s_nop 0                                                    // 0000000A1234: BF800000
	s_nop 0                                                    // 0000000A1238: BF800000
	s_nop 0                                                    // 0000000A123C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1240: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000A1244: 327A7884
	.long 0xd4490001                                           // 0000000A1248: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A124C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000A1254: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000A1258: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A1264: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000A1268: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000A1270: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000A1278: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000A1280: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000A1288: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000A1290: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000A1298: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000A12A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000A12A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A12B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000A12B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000A12B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000A12C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000A12C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000A12C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000A12CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A12D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000A12D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000A12D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000A12DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A12E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000A12E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000A12F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000A12F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A1300: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A1304: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_set_inst_prefetch_distance 0x2                           // 0000000A1308: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A130C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 0000000A1310: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A1318: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A1320: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A1324: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A1328: BF89FC07
	s_barrier                                                  // 0000000A132C: BFBD0000
	buffer_gl0_inv                                             // 0000000A1330: E0AC0000 00000000
	s_nop 0                                                    // 0000000A1338: BF800000
	s_nop 0                                                    // 0000000A133C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A1340: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 0000000A1348: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A1350: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A1358: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A135C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A1364: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A1368: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A1370: BF870004
	.long 0xd4490004                                           // 0000000A1374: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A1378: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A1380: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A1384: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A1388: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A138C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A1394: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A139C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A13A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A13A4: 8C7E0A7E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000000A13A8: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000A13B0: BF89FC07
	s_barrier                                                  // 0000000A13B4: BFBD0000
	buffer_gl0_inv                                             // 0000000A13B8: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000000A13C0: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000000A13C4: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000000A13CC: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000000A13D4: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000000A13DC: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000A13E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A13E8: BF840001
	s_nop 0                                                    // 0000000A13EC: BF800000
	s_nop 0                                                    // 0000000A13F0: BF800000
	s_nop 0                                                    // 0000000A13F4: BF800000
	s_nop 0                                                    // 0000000A13F8: BF800000
	s_nop 0                                                    // 0000000A13FC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 0000000A1400: 327C7884
	.long 0xd4490001                                           // 0000000A1404: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A1408: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A1410: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000A1414: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000A1418: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A1424: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000A1428: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000A1430: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000A1438: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000A1440: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000A1448: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000A1450: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000A1458: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000A1460: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000A1464: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A1468: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000A146C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000A1478: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000A1480: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000A1484: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000A1488: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000A148C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1490: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000A1494: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000A1498: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000A149C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A14A0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000000A14A4: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 0000000A14B0: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A14B4: BF870002
	v_mov_b32_e32 v60, v63                                     // 0000000A14B8: 7E78033F
	ds_store_b32 v62, v70                                      // 0000000A14BC: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A14C4: 917E047E
	s_cbranch_execnz 65485                                     // 0000000A14C8: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_set_inst_prefetch_distance 0x2                           // 0000000A14CC: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A14D0: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000000A14D4: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A14DC: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A14E4: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A14E8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A14EC: BF89FC07
	s_barrier                                                  // 0000000A14F0: BFBD0000
	buffer_gl0_inv                                             // 0000000A14F4: E0AC0000 00000000
	s_nop 0                                                    // 0000000A14FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A1500: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 0000000A1508: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A1510: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A1518: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A151C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A1524: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A1528: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A1530: BF870004
	.long 0xd4490004                                           // 0000000A1534: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A1538: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A1540: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A1544: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A1548: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A154C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A1554: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A155C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A1560: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A1564: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000000A1568: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000A1570: BF89FC07
	s_barrier                                                  // 0000000A1574: BFBD0000
	buffer_gl0_inv                                             // 0000000A1578: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000000A1580: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000000A1588: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000000A1590: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000000A1598: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000A15A0: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000A15A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A15A8: BF840001
	s_nop 0                                                    // 0000000A15AC: BF800000
	s_nop 0                                                    // 0000000A15B0: BF800000
	s_nop 0                                                    // 0000000A15B4: BF800000
	s_nop 0                                                    // 0000000A15B8: BF800000
	s_nop 0                                                    // 0000000A15BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A15C0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000A15C4: 327C7A84
	.long 0xd4490001                                           // 0000000A15C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000A15CC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000A15D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000A15D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A15E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000A15E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000A15F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000A15F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000A1600: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000A1608: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000A1610: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000A1618: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000A1620: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000A1624: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A1628: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000A162C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000A1638: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000A1640: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000A1644: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000A1648: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000A164C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1650: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000A1654: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000A1658: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000A165C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1660: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000A1664: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000A1670: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000A1678: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A1680: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A1684: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_set_inst_prefetch_distance 0x2                           // 0000000A1688: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A168C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 0000000A1690: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A1698: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A16A0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A16A4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A16A8: BF89FC07
	s_barrier                                                  // 0000000A16AC: BFBD0000
	buffer_gl0_inv                                             // 0000000A16B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000A16B8: BF800000
	s_nop 0                                                    // 0000000A16BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A16C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000A16C8: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A16D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A16D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A16DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A16E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A16E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A16F0: BF870004
	.long 0xd4490004                                           // 0000000A16F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A16F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A1700: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A1704: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A1708: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A170C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A1714: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A171C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A1720: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A1724: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000A1728: BF89FC07
	s_barrier                                                  // 0000000A172C: BFBD0000
	buffer_gl0_inv                                             // 0000000A1730: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 0000000A1738: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 0000000A1740: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 0000000A1748: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 0000000A1750: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000A1758: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000A175C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A1760: BF840001
	s_nop 0                                                    // 0000000A1764: BF800000
	s_nop 0                                                    // 0000000A1768: BF800000
	s_nop 0                                                    // 0000000A176C: BF800000
	s_nop 0                                                    // 0000000A1770: BF800000
	s_nop 0                                                    // 0000000A1774: BF800000
	s_nop 0                                                    // 0000000A1778: BF800000
	s_nop 0                                                    // 0000000A177C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1780: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000A1784: 327C7A84
	.long 0xd4490001                                           // 0000000A1788: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000A178C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000A1794: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000A1798: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A17A4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000A17A8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000A17B0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000A17B8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000A17C0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000A17C8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000A17D0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000A17D8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000A17E0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000A17E4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A17E8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000A17EC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000A17F8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000A1800: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000A1804: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000A1808: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000A180C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1810: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000A1814: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000A1818: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000A181C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1820: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000A1824: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000A1830: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000A1838: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A1840: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A1844: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e80>
	s_set_inst_prefetch_distance 0x2                           // 0000000A1848: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A184C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000A1850: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A1858: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A1860: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A1864: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A1868: BF89FC07
	s_barrier                                                  // 0000000A186C: BFBD0000
	buffer_gl0_inv                                             // 0000000A1870: E0AC0000 00000000
	s_nop 0                                                    // 0000000A1878: BF800000
	s_nop 0                                                    // 0000000A187C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A1880: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000000A1888: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A1890: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A1898: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A189C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A18A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A18A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A18B0: BF870004
	.long 0xd4490004                                           // 0000000A18B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A18B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A18C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A18C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A18C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A18CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A18D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A18DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A18E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A18E4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000A18E8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000A18F0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000A18F8: BF89FC07
	s_barrier                                                  // 0000000A18FC: BFBD0000
	buffer_gl0_inv                                             // 0000000A1900: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 0000000A1908: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 0000000A1910: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000A1918: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 0000000A1920: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000A1928: 7E780300
	s_mov_b32 s4, 0                                            // 0000000A192C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A1930: BF840001
	s_nop 0                                                    // 0000000A1934: BF800000
	s_nop 0                                                    // 0000000A1938: BF800000
	s_nop 0                                                    // 0000000A193C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A1940: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000A1944: 327A7884
	.long 0xd4490001                                           // 0000000A1948: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A194C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000A1954: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000A1958: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A1964: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000A1968: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000A1970: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000A1978: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000A1980: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000A1988: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000A1990: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000A1998: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000A19A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000A19A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A19B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000A19B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000A19B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000A19C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000A19C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000A19C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000A19CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A19D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000A19D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000A19D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000A19DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A19E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000A19E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000A19F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000A19F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A1A00: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A1A04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_set_inst_prefetch_distance 0x2                           // 0000000A1A08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A1A0C: 8C7E047E
	.long 0xd7000107                                           // 0000000A1A10: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000A1A14: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A1A1C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000A1A20: D5207C08 00061080
	.long 0xd7000109                                           // 0000000A1A28: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000A1A2C: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000A1A34: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000A1A3C: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000A1A40: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A1A48: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000A1A4C: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000A1A54: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000A1A58: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000A1A60: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000A1A68: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000A1A6C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A1A74: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000A1A78: D5207C10 00062080
	.long 0xd7000111                                           // 0000000A1A80: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000A1A84: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000A1A8C: D5207C12 00062480
	.long 0xd7000113                                           // 0000000A1A94: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000A1A98: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A1AA0: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000A1AA4: D5207C14 00062880
	.long 0xd7000115                                           // 0000000A1AAC: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000A1AB0: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000A1AB8: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000A1AC0: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000A1AC4: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A1ACC: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000A1AD0: D5207C18 00063080
	.long 0xd7000119                                           // 0000000A1AD8: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000A1ADC: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000A1AE4: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000A1AEC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000A1AF0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A1AF8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000A1AFC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000A1B04: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000A1B08: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000A1B0C: BF062105
	s_barrier                                                  // 0000000A1B10: BFBD0000
	buffer_gl0_inv                                             // 0000000A1B14: E0AC0000 00000000
	s_cbranch_scc0 63588                                       // 0000000A1B1C: BFA1F864 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b0>
	v_mov_b32_e32 v4, v38                                      // 0000000A1B20: 7E080326
	s_add_u32 s0, s28, s20                                     // 0000000A1B24: 8000141C
	.long 0xd73c0000                                           // 0000000A1B28: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000A1B2C: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000A1B30: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000A1B34: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000A1B38: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000A1B3C: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000A1B40: 82010103
	.long 0xd7006a00                                           // 0000000A1B44: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000A1B48: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000A1B4C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000A1B50: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000A1B58: BE810080
	.long 0xd7006a00                                           // 0000000A1B5C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 0000000A1B60: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000A1B64: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1B6C: BF870092
	.long 0xd7006a00                                           // 0000000A1B70: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000A1B74: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000A1B78: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 0000000A1B80: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000A1B88: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000000A1B90: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000A1B98: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000A1B9C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000A1BA4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000A1BA8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000A1BAC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000A1BB4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000A1BB8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000A1BC0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000A1BC8: 917E017E
	s_cbranch_execnz 65516                                     // 0000000A1BCC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2280>
	s_endpgm                                                   // 0000000A1BD0: BFB00000
		...

