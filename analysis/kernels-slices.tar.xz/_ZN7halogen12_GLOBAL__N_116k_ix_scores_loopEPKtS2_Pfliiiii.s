000000000002e800 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii>:
; _ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii():
	s_clause 0x1                                               // 00000002E800: BF850001
	s_load_b128 s[20:23], s[0:1], 0x20                         // 00000002E804: F4080500 F8000020
	s_load_b32 s4, s[0:1], 0x30                                // 00000002E80C: F4000100 F8000030
	s_waitcnt lgkmcnt(0)                                       // 00000002E814: BF89FC07
	s_add_i32 s5, s22, 15                                      // 00000002E818: 81058F16
	s_mul_i32 s3, s4, s3                                       // 00000002E81C: 96030304
	s_ashr_i32 s6, s5, 31                                      // 00000002E820: 86069F05
	s_add_i32 s4, s3, s4                                       // 00000002E824: 81040403
	s_lshr_b32 s6, s6, 28                                      // 00000002E828: 85069C06
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000002E82C: BF870499
	s_add_i32 s5, s5, s6                                       // 00000002E830: 81050605
	s_ashr_i32 s5, s5, 4                                       // 00000002E834: 86058405
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000002E838: BF870499
	s_min_i32 s24, s4, s5                                      // 00000002E83C: 89180504
	s_cmp_ge_i32 s3, s24                                       // 00000002E840: BF031803
	s_cbranch_scc1 1322                                        // 00000002E844: BFA2052A <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x14f0>
	v_lshrrev_b32_e32 v1, 1, v0                                // 00000002E848: 32020081
	s_lshl_b32 s2, s2, 7                                       // 00000002E84C: 84028702
	v_dual_mov_b32 v103, 0 :: v_dual_and_b32 v68, 15, v0       // 00000002E850: CA240080 6744008F
	s_load_b256 s[4:11], s[0:1], null                          // 00000002E858: F40C0100 F8000000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000002E860: BF8701C2
	v_and_or_b32 v67, 0x70, v1, s2                             // 00000002E864: D6570043 000A02FF 00000070
	s_add_i32 s0, s23, -1                                      // 00000002E870: 8100C117
	v_lshrrev_b32_e32 v118, 6, v0                              // 00000002E874: 32EC0086
	v_dual_mov_b32 v100, 0 :: v_dual_lshlrev_b32 v69, 3, v0    // 00000002E878: CA220080 64440083
	v_or_b32_e32 v113, v67, v68                                // 00000002E880: 38E28943
	v_mov_b32_e32 v104, 0                                      // 00000002E884: 7ED00280
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002E888: BF870224
	v_dual_mov_b32 v101, 0 :: v_dual_lshlrev_b32 v70, 9, v118  // 00000002E88C: CA220080 6546EC89
	v_mov_b32_e32 v102, 0                                      // 00000002E894: 7ECC0280
	v_min_i32_e32 v1, s0, v113                                 // 00000002E898: 2202E200
	s_lshl_b32 s0, s3, 4                                       // 00000002E89C: 84008403
	s_mov_b32 s1, exec_lo                                      // 00000002E8A0: BE81007E
	v_or_b32_e32 v65, s0, v118                                 // 00000002E8A4: 3882EC00
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E8A8: BF870092
	v_ashrrev_i32_e32 v2, 31, v1                               // 00000002E8AC: 3404029F
	.long 0xd73c0001                                           // 00000002E8B0: D73C0001
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 00000002E8B4: 02020288
	s_waitcnt lgkmcnt(0)                                       // 00000002E8B8: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E8BC: BF870091
	.long 0xd7006a39                                           // 00000002E8C0: D7006A39
	v_cndmask_b32_e32 v1, s6, v1, vcc_lo                       // 00000002E8C4: 02020206
	v_add_co_ci_u32_e64 v58, null, s7, v2, vcc_lo              // 00000002E8C8: D5207C3A 01AA0407
	s_clause 0xf                                               // 00000002E8D0: BF85000F
	global_load_b128 v[5:8], v[57:58], off offset:16           // 00000002E8D4: DC5E0010 057C0039
	global_load_b128 v[1:4], v[57:58], off                     // 00000002E8DC: DC5E0000 017C0039
	global_load_b128 v[13:16], v[57:58], off offset:48         // 00000002E8E4: DC5E0030 0D7C0039
	global_load_b128 v[9:12], v[57:58], off offset:32          // 00000002E8EC: DC5E0020 097C0039
	global_load_b128 v[21:24], v[57:58], off offset:80         // 00000002E8F4: DC5E0050 157C0039
	global_load_b128 v[17:20], v[57:58], off offset:64         // 00000002E8FC: DC5E0040 117C0039
	global_load_b128 v[29:32], v[57:58], off offset:112        // 00000002E904: DC5E0070 1D7C0039
	global_load_b128 v[25:28], v[57:58], off offset:96         // 00000002E90C: DC5E0060 197C0039
	global_load_b128 v[37:40], v[57:58], off offset:144        // 00000002E914: DC5E0090 257C0039
	global_load_b128 v[33:36], v[57:58], off offset:128        // 00000002E91C: DC5E0080 217C0039
	global_load_b128 v[45:48], v[57:58], off offset:176        // 00000002E924: DC5E00B0 2D7C0039
	global_load_b128 v[41:44], v[57:58], off offset:160        // 00000002E92C: DC5E00A0 297C0039
	global_load_b128 v[53:56], v[57:58], off offset:208        // 00000002E934: DC5E00D0 357C0039
	global_load_b128 v[49:52], v[57:58], off offset:192        // 00000002E93C: DC5E00C0 317C0039
	global_load_b128 v[61:64], v[57:58], off offset:240        // 00000002E944: DC5E00F0 3D7C0039
	global_load_b128 v[57:60], v[57:58], off offset:224        // 00000002E94C: DC5E00E0 397C0039
	.long 0xd4c4007e                                           // 00000002E954: D4C4007E
	v_cndmask_b32_e32 v1, s22, v65, vcc_lo                     // 00000002E958: 02028216
	s_cbranch_execz 22                                         // 00000002E95C: BFA50016 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x1b8>
	v_add_nc_u32_e32 v65, s20, v65                             // 00000002E960: 4A828214
	v_sub_nc_u32_e32 v71, v69, v70                             // 00000002E964: 4C8E8D45
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E968: BF870112
	v_ashrrev_i32_e32 v66, 31, v65                             // 00000002E96C: 3484829F
	v_ashrrev_i32_e32 v72, 31, v71                             // 00000002E970: 34908E9F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002E974: BF870112
	.long 0xd73c0041                                           // 00000002E978: D73C0041
	v_cndmask_b32_e32 v1, 10, v65, vcc_lo                      // 00000002E97C: 0202828A
	.long 0xd73c0047                                           // 00000002E980: D73C0047
	v_cndmask_b32_e32 v1, 1, v71, vcc_lo                       // 00000002E984: 02028E81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E988: BF870092
	.long 0xd7006a41                                           // 00000002E98C: D7006A41
	v_cndmask_b32_e32 v1, s4, v65, vcc_lo                      // 00000002E990: 02028204
	v_add_co_ci_u32_e64 v66, null, s5, v66, vcc_lo             // 00000002E994: D5207C42 01AA8405
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E99C: BF870092
	.long 0xd7006a41                                           // 00000002E9A0: D7006A41
	v_cndmask_b32_e32 v1, v65, v71, vcc_lo                     // 00000002E9A4: 02028F41
	v_add_co_ci_u32_e64 v66, null, v66, v72, vcc_lo            // 00000002E9A8: D5207C42 01AA9142
	global_load_b128 v[101:104], v[65:66], off                 // 00000002E9B0: DC5E0000 657C0041
	s_or_b32 exec_lo, exec_lo, s1                              // 00000002E9B8: 8C7E017E
	v_or_b32_e32 v71, 0x800, v69                               // 00000002E9BC: 388E8AFF 00000800
	v_dual_mov_b32 v98, 0 :: v_dual_and_b32 v65, 0x1f8, v69    // 00000002E9C4: CA240080 62408AFF 000001F8
	v_mov_b32_e32 v97, 0                                       // 00000002E9D0: 7EC20280
	s_mov_b32 s1, exec_lo                                      // 00000002E9D4: BE81007E
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002E9D8: BF870093
	v_lshrrev_b32_e32 v119, 9, v71                             // 00000002E9DC: 32EE8E89
	v_dual_mov_b32 v99, 0 :: v_dual_add_nc_u32 v66, s0, v119   // 00000002E9E0: CA200080 6342EE00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002E9E8: BF870001
	.long 0xd4c4007e                                           // 00000002E9EC: D4C4007E
	v_cndmask_b32_e32 v1, s22, v66, vcc_lo                     // 00000002E9F0: 02028416
	s_cbranch_execz 21                                         // 00000002E9F4: BFA50015 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x24c>
	v_add_nc_u32_e32 v72, s20, v66                             // 00000002E9F8: 4A908414
	v_and_b32_e32 v66, 0x1f8, v69                              // 00000002E9FC: 36848AFF 000001F8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002EA04: BF870112
	v_ashrrev_i32_e32 v73, 31, v72                             // 00000002EA08: 3492909F
	v_lshlrev_b32_e32 v66, 1, v66                              // 00000002EA0C: 30848481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EA10: BF870092
	.long 0xd73c0048                                           // 00000002EA14: D73C0048
	v_cndmask_b32_e32 v1, 10, v72, vcc_lo                      // 00000002EA18: 0202908A
	.long 0xd7006a48                                           // 00000002EA1C: D7006A48
	v_cndmask_b32_e32 v1, s4, v72, vcc_lo                      // 00000002EA20: 02029004
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002EA24: BF870111
	v_add_co_ci_u32_e64 v73, null, s5, v73, vcc_lo             // 00000002EA28: D5207C49 01AA9205
	.long 0xd7006a48                                           // 00000002EA30: D7006A48
	v_cndmask_b32_e32 v1, v72, v66, vcc_lo                     // 00000002EA34: 02028548
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EA38: BF870001
	v_add_co_ci_u32_e64 v73, null, 0, v73, vcc_lo              // 00000002EA3C: D5207C49 01AA9280
	global_load_b128 v[97:100], v[72:73], off                  // 00000002EA44: DC5E0000 617C0048
	s_or_b32 exec_lo, exec_lo, s1                              // 00000002EA4C: 8C7E017E
	v_add_nc_u32_e32 v66, 0x800, v71                           // 00000002EA50: 4A848EFF 00000800
	s_mov_b32 s1, exec_lo                                      // 00000002EA58: BE81007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EA5C: BF870091
	v_lshrrev_b32_e32 v120, 9, v66                             // 00000002EA60: 32F08489
	v_add_nc_u32_e32 v72, s0, v120                             // 00000002EA64: 4A90F000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EA68: BF870001
	.long 0xd4c3007e                                           // 00000002EA6C: D4C3007E
	v_cndmask_b32_e32 v1, s22, v72, vcc_lo                     // 00000002EA70: 02029016
	s_xor_b32 s1, exec_lo, s1                                  // 00000002EA74: 8D01017E
	v_and_b32_e32 v65, 0x1f8, v69                              // 00000002EA78: 36828AFF 000001F8
	s_or_saveexec_b32 s1, s1                                   // 00000002EA80: BE812201
	v_dual_mov_b32 v66, 0 :: v_dual_mov_b32 v107, 0            // 00000002EA84: CA100080 426A0080
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v105, 0           // 00000002EA8C: CA100080 6C680080
	v_mov_b32_e32 v106, 0                                      // 00000002EA94: 7ED40280
	s_xor_b32 exec_lo, exec_lo, s1                             // 00000002EA98: 8D7E017E
	s_cbranch_execz 18                                         // 00000002EA9C: BFA50012 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x2e8>
	v_add_nc_u32_e32 v72, s20, v72                             // 00000002EAA0: 4A909014
	v_lshlrev_b32_e32 v74, 1, v65                              // 00000002EAA4: 30948281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EAA8: BF870092
	v_ashrrev_i32_e32 v73, 31, v72                             // 00000002EAAC: 3492909F
	.long 0xd73c0048                                           // 00000002EAB0: D73C0048
	v_cndmask_b32_e32 v1, 10, v72, vcc_lo                      // 00000002EAB4: 0202908A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EAB8: BF870091
	.long 0xd7006a48                                           // 00000002EABC: D7006A48
	v_cndmask_b32_e32 v1, s4, v72, vcc_lo                      // 00000002EAC0: 02029004
	v_add_co_ci_u32_e64 v73, null, s5, v73, vcc_lo             // 00000002EAC4: D5207C49 01AA9205
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EACC: BF870092
	.long 0xd7006a48                                           // 00000002EAD0: D7006A48
	v_cndmask_b32_e32 v1, v72, v74, vcc_lo                     // 00000002EAD4: 02029548
	v_add_co_ci_u32_e64 v73, null, 0, v73, vcc_lo              // 00000002EAD8: D5207C49 01AA9280
	global_load_b128 v[105:108], v[72:73], off                 // 00000002EAE0: DC5E0000 697C0048
	s_or_b32 exec_lo, exec_lo, s1                              // 00000002EAE8: 8C7E017E
	v_or_b32_e32 v71, 0x1000, v71                              // 00000002EAEC: 388E8EFF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EAF4: BF870091
	v_lshrrev_b32_e32 v121, 9, v71                             // 00000002EAF8: 32F28E89
	v_add_nc_u32_e32 v71, s0, v121                             // 00000002EAFC: 4A8EF200
	s_mov_b32 s0, exec_lo                                      // 00000002EB00: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EB04: BF870001
	.long 0xd4c3007e                                           // 00000002EB08: D4C3007E
	v_cndmask_b32_e32 v1, s22, v71, vcc_lo                     // 00000002EB0C: 02028E16
	s_xor_b32 s0, exec_lo, s0                                  // 00000002EB10: 8D00007E
	v_mov_b32_e32 v66, 0                                       // 00000002EB14: 7E840280
	s_or_saveexec_b32 s0, s0                                   // 00000002EB18: BE802200
	v_dual_mov_b32 v122, 0 :: v_dual_mov_b32 v111, 0           // 00000002EB1C: CA100080 7A6E0080
	v_dual_mov_b32 v112, 0 :: v_dual_mov_b32 v109, 0           // 00000002EB24: CA100080 706C0080
	v_mov_b32_e32 v110, 0                                      // 00000002EB2C: 7EDC0280
	s_xor_b32 exec_lo, exec_lo, s0                             // 00000002EB30: 8D7E007E
	s_cbranch_execz 19                                         // 00000002EB34: BFA50013 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x384>
	v_add_nc_u32_e32 v71, s20, v71                             // 00000002EB38: 4A8E8E14
	.long 0xd73c0049                                           // 00000002EB3C: D73C0049
	v_cndmask_b32_e32 v1, 1, v65, vcc_lo                       // 00000002EB40: 02028281
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EB44: BF870092
	v_ashrrev_i32_e32 v72, 31, v71                             // 00000002EB48: 34908E9F
	.long 0xd73c0047                                           // 00000002EB4C: D73C0047
	v_cndmask_b32_e32 v1, 10, v71, vcc_lo                      // 00000002EB50: 02028E8A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EB54: BF870091
	.long 0xd7006a47                                           // 00000002EB58: D7006A47
	v_cndmask_b32_e32 v1, s4, v71, vcc_lo                      // 00000002EB5C: 02028E04
	v_add_co_ci_u32_e64 v72, null, s5, v72, vcc_lo             // 00000002EB60: D5207C48 01AA9005
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EB68: BF870092
	.long 0xd7006a47                                           // 00000002EB6C: D7006A47
	v_cndmask_b32_e32 v1, v71, v73, vcc_lo                     // 00000002EB70: 02029347
	v_add_co_ci_u32_e64 v72, null, v72, v74, vcc_lo            // 00000002EB74: D5207C48 01AA9548
	global_load_b128 v[109:112], v[71:72], off                 // 00000002EB7C: DC5E0000 6D7C0047
	s_or_b32 exec_lo, exec_lo, s0                              // 00000002EB84: 8C7E007E
	v_sub_nc_u32_e32 v115, v69, v70                            // 00000002EB88: 4CE68D45
	v_mul_u32_u24_e32 v69, 0x410, v118                         // 00000002EB8C: 168AECFF 00000410
	v_lshlrev_b32_e32 v123, 1, v65                             // 00000002EB94: 30F68281
	v_bfe_u32 v125, v0, 4, 1                                   // 00000002EB98: D610007D 02050900
	v_ashrrev_i32_e32 v114, 31, v113                           // 00000002EBA0: 34E4E29F
	v_ashrrev_i32_e32 v116, 31, v115                           // 00000002EBA4: 34E8E69F
	v_lshl_add_u32 v69, v115, 1, v69                           // 00000002EBA8: D6460045 05150373
	v_mad_u32_u24 v0, 0x410, v119, v123                        // 00000002EBB0: D60B0000 05EEEEFF 00000410
	v_mad_u32_u24 v70, 0x410, v120, v123                       // 00000002EBBC: D60B0046 05EEF0FF 00000410
	v_mad_u32_u24 v71, 0x410, v121, v123                       // 00000002EBC8: D60B0047 05EEF2FF 00000410
	.long 0xd73c0041                                           // 00000002EBD4: D73C0041
	v_cndmask_b32_e32 v1, 1, v65, vcc_lo                       // 00000002EBD8: 02028281
	s_waitcnt vmcnt(0)                                         // 00000002EBDC: BF8903F7
	ds_store_b128 v69, v[101:104]                              // 00000002EBE0: DB7C0000 00006545
	ds_store_b128 v0, v[97:100]                                // 00000002EBE8: DB7C0000 00006100
	ds_store_b128 v70, v[105:108]                              // 00000002EBF0: DB7C0000 00006946
	ds_store_b128 v71, v[109:112]                              // 00000002EBF8: DB7C0000 00006D47
	.long 0xd73c0045                                           // 00000002EC00: D73C0045
	v_cndmask_b32_e32 v1, 1, v115, vcc_lo                      // 00000002EC04: 0202E681
	v_mul_u32_u24_e32 v0, 0x410, v68                           // 00000002EC08: 160088FF 00000410
	v_rsq_f32_e32 v124, 0x43000000                             // 00000002EC10: 7EF85CFF 43000000
	.long 0xd4440000                                           // 00000002EC18: D4440000
	v_cndmask_b32_e32 v1, s23, v113, vcc_lo                    // 00000002EC1C: 0202E217
	s_add_i32 s6, s21, s20                                     // 00000002EC20: 81061415
	s_mov_b32 s12, 0                                           // 00000002EC24: BE8C0080
	.long 0xd7006a7e                                           // 00000002EC28: D7006A7E
	v_cndmask_b32_e32 v1, s4, v69, vcc_lo                      // 00000002EC2C: 02028A04
	.long 0xd73c0044                                           // 00000002EC30: D73C0044
	v_cndmask_b32_e32 v1, 2, v113, vcc_lo                      // 00000002EC34: 0202E282
	v_add_co_ci_u32_e64 v127, null, s5, v70, vcc_lo            // 00000002EC38: D5207C7F 01AA8C05
	.long 0xd7006a72                                           // 00000002EC40: D7006A72
	v_cndmask_b32_e32 v1, s4, v65, vcc_lo                      // 00000002EC44: 02028204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000002EC48: BF8700B1
	v_add_co_ci_u32_e64 v128, null, s5, v66, vcc_lo            // 00000002EC4C: D5207C80 01AA8405
	v_cmp_gt_i32_e32 vcc_lo, s23, v67                          // 00000002EC54: 7C888617
	.long 0xd7000181                                           // 00000002EC58: D7000181
	v_cndmask_b32_e32 v1, s8, v68, vcc_lo                      // 00000002EC5C: 02028808
	v_add_co_ci_u32_e64 v130, null, s9, v69, s1                // 00000002EC60: D5207C82 00068A09
	s_add_i32 s4, s6, 16                                       // 00000002EC68: 81049006
	s_add_i32 s1, s6, 1                                        // 00000002EC6C: 81018106
	s_xor_b32 s5, vcc_lo, -1                                   // 00000002EC70: 8D05C16A
	s_mov_b32 s8, s3                                           // 00000002EC74: BE880003
	s_waitcnt lgkmcnt(0)                                       // 00000002EC78: BF89FC07
	s_barrier                                                  // 00000002EC7C: BFBD0000
	buffer_gl0_inv                                             // 00000002EC80: E0AC0000 00000000
	s_branch 3                                                 // 00000002EC88: BFA00003 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x498>
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000002EC8C: 916A077E
	s_mov_b32 s8, s6                                           // 00000002EC90: BE880006
	s_cbranch_vccz 1046                                        // 00000002EC94: BFA30416 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x14f0>
	s_add_i32 s6, s8, 1                                        // 00000002EC98: 81068108
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002EC9C: BF870009
	s_cmp_lt_i32 s6, s24                                       // 00000002ECA0: BF041806
	s_cselect_b32 s7, -1, 0                                    // 00000002ECA4: 980780C1
	s_cmp_ge_i32 s6, s24                                       // 00000002ECA8: BF031806
	s_cbranch_scc1 94                                          // 00000002ECAC: BFA2005E <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x628>
	s_lshl_b32 s9, s6, 4                                       // 00000002ECB0: 84098406
	s_waitcnt vmcnt(0)                                         // 00000002ECB4: BF8903F7
	v_dual_mov_b32 v100, 0 :: v_dual_mov_b32 v103, 0           // 00000002ECB8: CA100080 64660080
	v_or_b32_e32 v65, s9, v118                                 // 00000002ECC0: 3882EC09
	v_dual_mov_b32 v104, 0 :: v_dual_mov_b32 v101, 0           // 00000002ECC4: CA100080 68640080
	v_mov_b32_e32 v102, 0                                      // 00000002ECCC: 7ECC0280
	s_mov_b32 s13, exec_lo                                     // 00000002ECD0: BE8D007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002ECD4: BF870003
	.long 0xd4c4007e                                           // 00000002ECD8: D4C4007E
	v_cndmask_b32_e32 v1, s22, v65, vcc_lo                     // 00000002ECDC: 02028216
	s_cbranch_execz 12                                         // 00000002ECE0: BFA5000C <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x514>
	v_add_nc_u32_e32 v65, s20, v65                             // 00000002ECE4: 4A828214
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002ECE8: BF870091
	v_ashrrev_i32_e32 v66, 31, v65                             // 00000002ECEC: 3484829F
	.long 0xd73c0041                                           // 00000002ECF0: D73C0041
	v_cndmask_b32_e32 v1, 10, v65, vcc_lo                      // 00000002ECF4: 0202828A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002ECF8: BF870091
	.long 0xd7006a41                                           // 00000002ECFC: D7006A41
	v_cndmask_b32_e32 v1, v126, v65, vcc_lo                    // 00000002ED00: 0202837E
	v_add_co_ci_u32_e64 v66, null, v127, v66, vcc_lo           // 00000002ED04: D5207C42 01AA857F
	global_load_b128 v[101:104], v[65:66], off                 // 00000002ED0C: DC5E0000 657C0041
	s_or_b32 exec_lo, exec_lo, s13                             // 00000002ED14: 8C7E0D7E
	v_dual_mov_b32 v98, 0 :: v_dual_add_nc_u32 v65, s9, v119   // 00000002ED18: CA200080 6240EE09
	v_mov_b32_e32 v99, 0                                       // 00000002ED20: 7EC60280
	v_mov_b32_e32 v97, 0                                       // 00000002ED24: 7EC20280
	s_mov_b32 s13, exec_lo                                     // 00000002ED28: BE8D007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002ED2C: BF870003
	.long 0xd4c4007e                                           // 00000002ED30: D4C4007E
	v_cndmask_b32_e32 v1, s22, v65, vcc_lo                     // 00000002ED34: 02028216
	s_cbranch_execz 12                                         // 00000002ED38: BFA5000C <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x56c>
	v_add_nc_u32_e32 v65, s20, v65                             // 00000002ED3C: 4A828214
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002ED40: BF870091
	v_ashrrev_i32_e32 v66, 31, v65                             // 00000002ED44: 3484829F
	.long 0xd73c0041                                           // 00000002ED48: D73C0041
	v_cndmask_b32_e32 v1, 10, v65, vcc_lo                      // 00000002ED4C: 0202828A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002ED50: BF870091
	.long 0xd7006a41                                           // 00000002ED54: D7006A41
	v_cndmask_b32_e32 v1, v114, v65, vcc_lo                    // 00000002ED58: 02028372
	v_add_co_ci_u32_e64 v66, null, v128, v66, vcc_lo           // 00000002ED5C: D5207C42 01AA8580
	global_load_b128 v[97:100], v[65:66], off                  // 00000002ED64: DC5E0000 617C0041
	s_or_b32 exec_lo, exec_lo, s13                             // 00000002ED6C: 8C7E0D7E
	v_dual_mov_b32 v112, 0 :: v_dual_add_nc_u32 v65, s9, v120  // 00000002ED70: CA200080 7040F009
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v107, 0           // 00000002ED78: CA100080 6C6A0080
	v_dual_mov_b32 v106, 0 :: v_dual_mov_b32 v105, 0           // 00000002ED80: CA100080 6A680080
	s_mov_b32 s13, exec_lo                                     // 00000002ED88: BE8D007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002ED8C: BF870003
	.long 0xd4c4007e                                           // 00000002ED90: D4C4007E
	v_cndmask_b32_e32 v1, s22, v65, vcc_lo                     // 00000002ED94: 02028216
	s_cbranch_execz 12                                         // 00000002ED98: BFA5000C <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x5cc>
	v_add_nc_u32_e32 v65, s20, v65                             // 00000002ED9C: 4A828214
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EDA0: BF870091
	v_ashrrev_i32_e32 v66, 31, v65                             // 00000002EDA4: 3484829F
	.long 0xd73c0041                                           // 00000002EDA8: D73C0041
	v_cndmask_b32_e32 v1, 10, v65, vcc_lo                      // 00000002EDAC: 0202828A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EDB0: BF870091
	.long 0xd7006a41                                           // 00000002EDB4: D7006A41
	v_cndmask_b32_e32 v1, v114, v65, vcc_lo                    // 00000002EDB8: 02028372
	v_add_co_ci_u32_e64 v66, null, v128, v66, vcc_lo           // 00000002EDBC: D5207C42 01AA8580
	global_load_b128 v[105:108], v[65:66], off                 // 00000002EDC4: DC5E0000 697C0041
	s_or_b32 exec_lo, exec_lo, s13                             // 00000002EDCC: 8C7E0D7E
	v_dual_mov_b32 v110, 0 :: v_dual_add_nc_u32 v65, s9, v121  // 00000002EDD0: CA200080 6E40F209
	v_mov_b32_e32 v111, 0                                      // 00000002EDD8: 7EDE0280
	v_mov_b32_e32 v109, 0                                      // 00000002EDDC: 7EDA0280
	s_mov_b32 s9, exec_lo                                      // 00000002EDE0: BE89007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000002EDE4: BF870003
	.long 0xd4c4007e                                           // 00000002EDE8: D4C4007E
	v_cndmask_b32_e32 v1, s22, v65, vcc_lo                     // 00000002EDEC: 02028216
	s_cbranch_execz 12                                         // 00000002EDF0: BFA5000C <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x624>
	v_add_nc_u32_e32 v65, s20, v65                             // 00000002EDF4: 4A828214
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EDF8: BF870091
	v_ashrrev_i32_e32 v66, 31, v65                             // 00000002EDFC: 3484829F
	.long 0xd73c0041                                           // 00000002EE00: D73C0041
	v_cndmask_b32_e32 v1, 10, v65, vcc_lo                      // 00000002EE04: 0202828A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EE08: BF870091
	.long 0xd7006a41                                           // 00000002EE0C: D7006A41
	v_cndmask_b32_e32 v1, v114, v65, vcc_lo                    // 00000002EE10: 02028372
	v_add_co_ci_u32_e64 v66, null, v128, v66, vcc_lo           // 00000002EE14: D5207C42 01AA8580
	global_load_b128 v[109:112], v[65:66], off                 // 00000002EE1C: DC5E0000 6D7C0041
	s_or_b32 exec_lo, exec_lo, s9                              // 00000002EE24: 8C7E097E
	s_lshl_b32 s23, s8, 4                                      // 00000002EE28: 84178408
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000002EE2C: BF870499
	s_add_i32 s9, s4, s23                                      // 00000002EE30: 81091704
	s_ashr_i32 s13, s9, 31                                     // 00000002EE34: 860D9F09
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000002EE38: BF870499
	s_lshr_b32 s13, s13, 30                                    // 00000002EE3C: 850D9E0D
	s_add_i32 s9, s9, s13                                      // 00000002EE40: 81090D09
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000002EE44: BF870499
	s_ashr_i32 s9, s9, 2                                       // 00000002EE48: 86098209
	s_cmp_ge_i32 s2, s9                                        // 00000002EE4C: BF030902
	s_cselect_b32 s9, -1, 0                                    // 00000002EE50: 980980C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000002EE54: BF8704B9
	s_or_b32 s13, s9, s5                                       // 00000002EE58: 8C0D0509
	s_mov_b32 s9, 0                                            // 00000002EE5C: BE890080
	s_and_saveexec_b32 s14, s13                                // 00000002EE60: BE8E200D
	s_xor_b32 s13, exec_lo, s14                                // 00000002EE64: 8D0D0E7E
	s_cbranch_execz 199                                        // 00000002EE68: BFA500C7 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x988>
	s_mov_b32 s14, 0                                           // 00000002EE6C: BE8E0080
	s_and_saveexec_b32 s9, s0                                  // 00000002EE70: BE892000
	s_cbranch_execz 193                                        // 00000002EE74: BFA500C1 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x97c>
	v_or_b32_e32 v65, s23, v125                                // 00000002EE78: 3882FA17
	s_mov_b32 s14, exec_lo                                     // 00000002EE7C: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EE80: BF870001
	.long 0xd4c4007e                                           // 00000002EE84: D4C4007E
	v_cndmask_b32_e32 v1, s22, v65, vcc_lo                     // 00000002EE88: 02028216
	s_cbranch_execz 20                                         // 00000002EE8C: BFA50014 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x6e0>
	v_ashrrev_i32_e32 v68, 31, v65                             // 00000002EE90: 3488829F
	.long 0xd72c0045                                           // 00000002EE94: D72C0045
	v_cndmask_b32_e32 v1, s11, v65, vcc_lo                     // 00000002EE98: 0202820B
	v_mad_u64_u32 v[66:67], null, s10, v65, 0                  // 00000002EE9C: D6FE7C42 0202820A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EEA4: BF870093
	.long 0xd72c0044                                           // 00000002EEA8: D72C0044
	v_cndmask_b32_e32 v1, s10, v68, vcc_lo                     // 00000002EEAC: 0202880A
	v_add3_u32 v67, v67, v68, v69                              // 00000002EEB0: D6550043 05168943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EEB8: BF870091
	.long 0xd73c0042                                           // 00000002EEBC: D73C0042
	v_cndmask_b32_e32 v1, 2, v66, vcc_lo                       // 00000002EEC0: 02028482
	.long 0xd7006a42                                           // 00000002EEC4: D7006A42
	v_cndmask_b32_e32 v1, v129, v66, vcc_lo                    // 00000002EEC8: 02028581
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EECC: BF870001
	v_add_co_ci_u32_e64 v67, null, v130, v67, vcc_lo           // 00000002EED0: D5207C43 01AA8782
	global_store_b32 v[66:67], v122, off                       // 00000002EED8: DC6A0000 007C7A42
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002EEE0: 8C7E0E7E
	v_or_b32_e32 v66, 2, v65                                   // 00000002EEE4: 38848282
	s_mov_b32 s14, exec_lo                                     // 00000002EEE8: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EEEC: BF870001
	.long 0xd4c4007e                                           // 00000002EEF0: D4C4007E
	v_cndmask_b32_e32 v1, s22, v66, vcc_lo                     // 00000002EEF4: 02028416
	s_cbranch_execz 20                                         // 00000002EEF8: BFA50014 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x74c>
	v_ashrrev_i32_e32 v68, 31, v66                             // 00000002EEFC: 3488849F
	.long 0xd72c0045                                           // 00000002EF00: D72C0045
	v_cndmask_b32_e32 v1, s11, v66, vcc_lo                     // 00000002EF04: 0202840B
	v_mad_u64_u32 v[66:67], null, s10, v66, 0                  // 00000002EF08: D6FE7C42 0202840A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EF10: BF870093
	.long 0xd72c0044                                           // 00000002EF14: D72C0044
	v_cndmask_b32_e32 v1, s10, v68, vcc_lo                     // 00000002EF18: 0202880A
	v_add3_u32 v67, v67, v68, v69                              // 00000002EF1C: D6550043 05168943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EF24: BF870091
	.long 0xd73c0042                                           // 00000002EF28: D73C0042
	v_cndmask_b32_e32 v1, 2, v66, vcc_lo                       // 00000002EF2C: 02028482
	.long 0xd7006a42                                           // 00000002EF30: D7006A42
	v_cndmask_b32_e32 v1, v129, v66, vcc_lo                    // 00000002EF34: 02028581
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EF38: BF870001
	v_add_co_ci_u32_e64 v67, null, v130, v67, vcc_lo           // 00000002EF3C: D5207C43 01AA8782
	global_store_b32 v[66:67], v122, off                       // 00000002EF44: DC6A0000 007C7A42
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002EF4C: 8C7E0E7E
	v_or_b32_e32 v66, 4, v65                                   // 00000002EF50: 38848284
	s_mov_b32 s14, exec_lo                                     // 00000002EF54: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EF58: BF870001
	.long 0xd4c4007e                                           // 00000002EF5C: D4C4007E
	v_cndmask_b32_e32 v1, s22, v66, vcc_lo                     // 00000002EF60: 02028416
	s_cbranch_execz 20                                         // 00000002EF64: BFA50014 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x7b8>
	v_ashrrev_i32_e32 v68, 31, v66                             // 00000002EF68: 3488849F
	.long 0xd72c0045                                           // 00000002EF6C: D72C0045
	v_cndmask_b32_e32 v1, s11, v66, vcc_lo                     // 00000002EF70: 0202840B
	v_mad_u64_u32 v[66:67], null, s10, v66, 0                  // 00000002EF74: D6FE7C42 0202840A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EF7C: BF870093
	.long 0xd72c0044                                           // 00000002EF80: D72C0044
	v_cndmask_b32_e32 v1, s10, v68, vcc_lo                     // 00000002EF84: 0202880A
	v_add3_u32 v67, v67, v68, v69                              // 00000002EF88: D6550043 05168943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EF90: BF870091
	.long 0xd73c0042                                           // 00000002EF94: D73C0042
	v_cndmask_b32_e32 v1, 2, v66, vcc_lo                       // 00000002EF98: 02028482
	.long 0xd7006a42                                           // 00000002EF9C: D7006A42
	v_cndmask_b32_e32 v1, v129, v66, vcc_lo                    // 00000002EFA0: 02028581
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EFA4: BF870001
	v_add_co_ci_u32_e64 v67, null, v130, v67, vcc_lo           // 00000002EFA8: D5207C43 01AA8782
	global_store_b32 v[66:67], v122, off                       // 00000002EFB0: DC6A0000 007C7A42
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002EFB8: 8C7E0E7E
	v_or_b32_e32 v66, 6, v65                                   // 00000002EFBC: 38848286
	s_mov_b32 s14, exec_lo                                     // 00000002EFC0: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002EFC4: BF870001
	.long 0xd4c4007e                                           // 00000002EFC8: D4C4007E
	v_cndmask_b32_e32 v1, s22, v66, vcc_lo                     // 00000002EFCC: 02028416
	s_cbranch_execz 20                                         // 00000002EFD0: BFA50014 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x824>
	v_ashrrev_i32_e32 v68, 31, v66                             // 00000002EFD4: 3488849F
	.long 0xd72c0045                                           // 00000002EFD8: D72C0045
	v_cndmask_b32_e32 v1, s11, v66, vcc_lo                     // 00000002EFDC: 0202840B
	v_mad_u64_u32 v[66:67], null, s10, v66, 0                  // 00000002EFE0: D6FE7C42 0202840A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EFE8: BF870093
	.long 0xd72c0044                                           // 00000002EFEC: D72C0044
	v_cndmask_b32_e32 v1, s10, v68, vcc_lo                     // 00000002EFF0: 0202880A
	v_add3_u32 v67, v67, v68, v69                              // 00000002EFF4: D6550043 05168943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002EFFC: BF870091
	.long 0xd73c0042                                           // 00000002F000: D73C0042
	v_cndmask_b32_e32 v1, 2, v66, vcc_lo                       // 00000002F004: 02028482
	.long 0xd7006a42                                           // 00000002F008: D7006A42
	v_cndmask_b32_e32 v1, v129, v66, vcc_lo                    // 00000002F00C: 02028581
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F010: BF870001
	v_add_co_ci_u32_e64 v67, null, v130, v67, vcc_lo           // 00000002F014: D5207C43 01AA8782
	global_store_b32 v[66:67], v122, off                       // 00000002F01C: DC6A0000 007C7A42
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002F024: 8C7E0E7E
	v_or_b32_e32 v66, 8, v65                                   // 00000002F028: 38848288
	s_mov_b32 s14, exec_lo                                     // 00000002F02C: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F030: BF870001
	.long 0xd4c4007e                                           // 00000002F034: D4C4007E
	v_cndmask_b32_e32 v1, s22, v66, vcc_lo                     // 00000002F038: 02028416
	s_cbranch_execz 20                                         // 00000002F03C: BFA50014 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x890>
	v_ashrrev_i32_e32 v68, 31, v66                             // 00000002F040: 3488849F
	.long 0xd72c0045                                           // 00000002F044: D72C0045
	v_cndmask_b32_e32 v1, s11, v66, vcc_lo                     // 00000002F048: 0202840B
	v_mad_u64_u32 v[66:67], null, s10, v66, 0                  // 00000002F04C: D6FE7C42 0202840A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F054: BF870093
	.long 0xd72c0044                                           // 00000002F058: D72C0044
	v_cndmask_b32_e32 v1, s10, v68, vcc_lo                     // 00000002F05C: 0202880A
	v_add3_u32 v67, v67, v68, v69                              // 00000002F060: D6550043 05168943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F068: BF870091
	.long 0xd73c0042                                           // 00000002F06C: D73C0042
	v_cndmask_b32_e32 v1, 2, v66, vcc_lo                       // 00000002F070: 02028482
	.long 0xd7006a42                                           // 00000002F074: D7006A42
	v_cndmask_b32_e32 v1, v129, v66, vcc_lo                    // 00000002F078: 02028581
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F07C: BF870001
	v_add_co_ci_u32_e64 v67, null, v130, v67, vcc_lo           // 00000002F080: D5207C43 01AA8782
	global_store_b32 v[66:67], v122, off                       // 00000002F088: DC6A0000 007C7A42
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002F090: 8C7E0E7E
	v_or_b32_e32 v66, 10, v65                                  // 00000002F094: 3884828A
	s_mov_b32 s14, exec_lo                                     // 00000002F098: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F09C: BF870001
	.long 0xd4c4007e                                           // 00000002F0A0: D4C4007E
	v_cndmask_b32_e32 v1, s22, v66, vcc_lo                     // 00000002F0A4: 02028416
	s_cbranch_execz 20                                         // 00000002F0A8: BFA50014 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x8fc>
	v_ashrrev_i32_e32 v68, 31, v66                             // 00000002F0AC: 3488849F
	.long 0xd72c0045                                           // 00000002F0B0: D72C0045
	v_cndmask_b32_e32 v1, s11, v66, vcc_lo                     // 00000002F0B4: 0202840B
	v_mad_u64_u32 v[66:67], null, s10, v66, 0                  // 00000002F0B8: D6FE7C42 0202840A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F0C0: BF870093
	.long 0xd72c0044                                           // 00000002F0C4: D72C0044
	v_cndmask_b32_e32 v1, s10, v68, vcc_lo                     // 00000002F0C8: 0202880A
	v_add3_u32 v67, v67, v68, v69                              // 00000002F0CC: D6550043 05168943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F0D4: BF870091
	.long 0xd73c0042                                           // 00000002F0D8: D73C0042
	v_cndmask_b32_e32 v1, 2, v66, vcc_lo                       // 00000002F0DC: 02028482
	.long 0xd7006a42                                           // 00000002F0E0: D7006A42
	v_cndmask_b32_e32 v1, v129, v66, vcc_lo                    // 00000002F0E4: 02028581
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F0E8: BF870001
	v_add_co_ci_u32_e64 v67, null, v130, v67, vcc_lo           // 00000002F0EC: D5207C43 01AA8782
	global_store_b32 v[66:67], v122, off                       // 00000002F0F4: DC6A0000 007C7A42
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002F0FC: 8C7E0E7E
	v_or_b32_e32 v66, 12, v65                                  // 00000002F100: 3884828C
	s_mov_b32 s14, exec_lo                                     // 00000002F104: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F108: BF870001
	.long 0xd4c4007e                                           // 00000002F10C: D4C4007E
	v_cndmask_b32_e32 v1, s22, v66, vcc_lo                     // 00000002F110: 02028416
	s_cbranch_execz 20                                         // 00000002F114: BFA50014 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x968>
	v_ashrrev_i32_e32 v68, 31, v66                             // 00000002F118: 3488849F
	.long 0xd72c0045                                           // 00000002F11C: D72C0045
	v_cndmask_b32_e32 v1, s11, v66, vcc_lo                     // 00000002F120: 0202840B
	v_mad_u64_u32 v[66:67], null, s10, v66, 0                  // 00000002F124: D6FE7C42 0202840A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F12C: BF870093
	.long 0xd72c0044                                           // 00000002F130: D72C0044
	v_cndmask_b32_e32 v1, s10, v68, vcc_lo                     // 00000002F134: 0202880A
	v_add3_u32 v67, v67, v68, v69                              // 00000002F138: D6550043 05168943
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F140: BF870091
	.long 0xd73c0042                                           // 00000002F144: D73C0042
	v_cndmask_b32_e32 v1, 2, v66, vcc_lo                       // 00000002F148: 02028482
	.long 0xd7006a42                                           // 00000002F14C: D7006A42
	v_cndmask_b32_e32 v1, v129, v66, vcc_lo                    // 00000002F150: 02028581
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F154: BF870001
	v_add_co_ci_u32_e64 v67, null, v130, v67, vcc_lo           // 00000002F158: D5207C43 01AA8782
	global_store_b32 v[66:67], v122, off                       // 00000002F160: DC6A0000 007C7A42
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002F168: 8C7E0E7E
	v_or_b32_e32 v116, 14, v65                                 // 00000002F16C: 38E8828E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F170: BF870001
	v_cmp_gt_i32_e32 vcc_lo, s22, v116                         // 00000002F174: 7C88E816
	s_and_b32 s14, vcc_lo, exec_lo                             // 00000002F178: 8B0E7E6A
	s_or_b32 exec_lo, exec_lo, s9                              // 00000002F17C: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002F180: BF870009
	s_and_b32 s9, s14, exec_lo                                 // 00000002F184: 8B097E0E
	s_or_saveexec_b32 s21, s13                                 // 00000002F188: BE95220D
	v_mov_b32_e32 v117, 0                                      // 00000002F18C: 7EEA0280
	s_sub_i32 s8, s8, s3                                       // 00000002F190: 81880308
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002F194: BF870009
	s_and_b32 s8, s8, 1                                        // 00000002F198: 8B088108
	s_xor_b32 exec_lo, exec_lo, s21                            // 00000002F19C: 8D7E157E
	s_cbranch_execnz 9                                         // 00000002F1A0: BFA60009 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x9c8>
	s_or_b32 exec_lo, exec_lo, s21                             // 00000002F1A4: 8C7E157E
	s_and_saveexec_b32 s13, s9                                 // 00000002F1A8: BE8D2009
	s_cbranch_execnz 659                                       // 00000002F1AC: BFA60293 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x13fc>
	s_or_b32 exec_lo, exec_lo, s13                             // 00000002F1B0: 8C7E0D7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000002F1B4: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000002F1B8: 916A077E
	s_mov_b32 s7, -1                                           // 00000002F1BC: BE8700C1
	s_cbranch_vccnz 65202                                      // 00000002F1C0: BFA4FEB2 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x48c>
	s_branch 677                                               // 00000002F1C4: BFA002A5 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x145c>
	v_mad_u64_u32 v[116:117], null, 0x4100, s8, v[0:1]         // 00000002F1C8: D6FE7C74 040010FF 00004100
	s_mov_b32 s19, s12                                         // 00000002F1D4: BE93000C
	s_mov_b32 s13, s12                                         // 00000002F1D8: BE8D000C
	s_mov_b32 s14, s12                                         // 00000002F1DC: BE8E000C
	s_mov_b32 s15, s12                                         // 00000002F1E0: BE8F000C
	s_mov_b32 s16, s12                                         // 00000002F1E4: BE90000C
	s_mov_b32 s17, s12                                         // 00000002F1E8: BE91000C
	s_mov_b32 s18, s12                                         // 00000002F1EC: BE92000C
	ds_load_b128 v[81:84], v116                                // 00000002F1F0: DBFC0000 51000074
	ds_load_b128 v[85:88], v116 offset:16                      // 00000002F1F8: DBFC0010 55000074
	ds_load_b128 v[89:92], v116 offset:32                      // 00000002F200: DBFC0020 59000074
	ds_load_b128 v[93:96], v116 offset:48                      // 00000002F208: DBFC0030 5D000074
	v_dual_mov_b32 v72, s19 :: v_dual_mov_b32 v71, s18         // 00000002F210: CA100013 48460012
	v_dual_mov_b32 v70, s17 :: v_dual_mov_b32 v69, s16         // 00000002F218: CA100011 46440010
	v_dual_mov_b32 v68, s15 :: v_dual_mov_b32 v67, s14         // 00000002F220: CA10000F 4442000E
	v_dual_mov_b32 v66, s13 :: v_dual_mov_b32 v65, s12         // 00000002F228: CA10000D 4240000C
	s_mov_b32 s14, s9                                          // 00000002F230: BE8E0009
	s_waitcnt lgkmcnt(2)                                       // 00000002F234: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002F238: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[73:80], v[81:88], v[1:8], v[65:72]// 00000002F23C: CC414049 1D060351
	s_waitcnt lgkmcnt(0)                                       // 00000002F244: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[89:96], v[9:16], v[73:80]// 00000002F248: CC414049 1D261359
	ds_load_b128 v[93:96], v116 offset:272                     // 00000002F250: DBFC0110 5D000074
	ds_load_b128 v[89:92], v116 offset:256                     // 00000002F258: DBFC0100 59000074
	ds_load_b128 v[135:138], v116 offset:304                   // 00000002F260: DBFC0130 87000074
	ds_load_b128 v[131:134], v116 offset:288                   // 00000002F268: DBFC0120 83000074
	s_waitcnt lgkmcnt(2)                                       // 00000002F270: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[81:88], v[89:96], v[1:8], v[65:72]// 00000002F274: CC414051 1D060359
	ds_load_b128 v[93:96], v116 offset:80                      // 00000002F27C: DBFC0050 5D000074
	ds_load_b128 v[89:92], v116 offset:64                      // 00000002F284: DBFC0040 59000074
	s_waitcnt lgkmcnt(2)                                       // 00000002F28C: BF89FC27
	v_wmma_f32_16x16x16_bf16 v[81:88], v[131:138], v[9:16], v[81:88]// 00000002F290: CC414051 1D461383
	ds_load_b128 v[135:138], v116 offset:528                   // 00000002F298: DBFC0210 87000074
	ds_load_b128 v[131:134], v116 offset:512                   // 00000002F2A0: DBFC0200 83000074
	ds_load_b128 v[143:146], v116 offset:560                   // 00000002F2A8: DBFC0230 8F000074
	ds_load_b128 v[139:142], v116 offset:544                   // 00000002F2B0: DBFC0220 8B000074
	s_waitcnt lgkmcnt(4)                                       // 00000002F2B8: BF89FC47
	v_wmma_f32_16x16x16_bf16 v[73:80], v[89:96], v[17:24], v[73:80]// 00000002F2BC: CC414049 1D262359
	ds_load_b128 v[93:96], v116 offset:336                     // 00000002F2C4: DBFC0150 5D000074
	ds_load_b128 v[89:92], v116 offset:320                     // 00000002F2CC: DBFC0140 59000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F2D4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[89:96], v[17:24], v[81:88]// 00000002F2D8: CC414051 1D462359
	ds_load_b128 v[93:96], v116 offset:112                     // 00000002F2E0: DBFC0070 5D000074
	ds_load_b128 v[89:92], v116 offset:96                      // 00000002F2E8: DBFC0060 59000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F2F0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[89:96], v[25:32], v[73:80]// 00000002F2F4: CC414049 1D263359
	ds_load_b128 v[93:96], v116 offset:368                     // 00000002F2FC: DBFC0170 5D000074
	ds_load_b128 v[89:92], v116 offset:352                     // 00000002F304: DBFC0160 59000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F30C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[89:96], v[25:32], v[81:88]// 00000002F310: CC414051 1D463359
	ds_load_b128 v[93:96], v116 offset:144                     // 00000002F318: DBFC0090 5D000074
	ds_load_b128 v[89:92], v116 offset:128                     // 00000002F320: DBFC0080 59000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F328: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[89:96], v[33:40], v[73:80]// 00000002F32C: CC414049 1D264359
	ds_load_b128 v[93:96], v116 offset:400                     // 00000002F334: DBFC0190 5D000074
	ds_load_b128 v[89:92], v116 offset:384                     // 00000002F33C: DBFC0180 59000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F344: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[89:96], v[33:40], v[81:88]// 00000002F348: CC414051 1D464359
	ds_load_b128 v[93:96], v116 offset:176                     // 00000002F350: DBFC00B0 5D000074
	ds_load_b128 v[89:92], v116 offset:160                     // 00000002F358: DBFC00A0 59000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F360: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[89:96], v[41:48], v[73:80]// 00000002F364: CC414049 1D265359
	ds_load_b128 v[93:96], v116 offset:432                     // 00000002F36C: DBFC01B0 5D000074
	ds_load_b128 v[89:92], v116 offset:416                     // 00000002F374: DBFC01A0 59000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F37C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[89:96], v[41:48], v[81:88]// 00000002F380: CC414051 1D465359
	ds_load_b128 v[93:96], v116 offset:208                     // 00000002F388: DBFC00D0 5D000074
	ds_load_b128 v[89:92], v116 offset:192                     // 00000002F390: DBFC00C0 59000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F398: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[89:96], v[49:56], v[73:80]// 00000002F39C: CC414049 1D266359
	ds_load_b128 v[93:96], v116 offset:464                     // 00000002F3A4: DBFC01D0 5D000074
	ds_load_b128 v[89:92], v116 offset:448                     // 00000002F3AC: DBFC01C0 59000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F3B4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[89:96], v[49:56], v[81:88]// 00000002F3B8: CC414051 1D466359
	ds_load_b128 v[93:96], v116 offset:240                     // 00000002F3C0: DBFC00F0 5D000074
	ds_load_b128 v[89:92], v116 offset:224                     // 00000002F3C8: DBFC00E0 59000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F3D0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[73:80], v[89:96], v[57:64], v[73:80]// 00000002F3D4: CC414049 1D267359
	ds_load_b128 v[93:96], v116 offset:496                     // 00000002F3DC: DBFC01F0 5D000074
	ds_load_b128 v[89:92], v116 offset:480                     // 00000002F3E4: DBFC01E0 59000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F3EC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[81:88], v[89:96], v[57:64], v[81:88]// 00000002F3F0: CC414051 1D467359
	v_wmma_f32_16x16x16_bf16 v[89:96], v[131:138], v[1:8], v[65:72]// 00000002F3F8: CC414059 1D060383
	ds_load_b128 v[135:138], v116 offset:592                   // 00000002F400: DBFC0250 87000074
	ds_load_b128 v[131:134], v116 offset:576                   // 00000002F408: DBFC0240 83000074
	v_wmma_f32_16x16x16_bf16 v[89:96], v[139:146], v[9:16], v[89:96]// 00000002F410: CC414059 1D66138B
	s_waitcnt lgkmcnt(0)                                       // 00000002F418: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F41C: BF870001
	v_wmma_f32_16x16x16_bf16 v[89:96], v[131:138], v[17:24], v[89:96]// 00000002F420: CC414059 1D662383
	ds_load_b128 v[135:138], v116 offset:624                   // 00000002F428: DBFC0270 87000074
	ds_load_b128 v[131:134], v116 offset:608                   // 00000002F430: DBFC0260 83000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F438: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[131:138], v[25:32], v[89:96]// 00000002F43C: CC414059 1D663383
	ds_load_b128 v[135:138], v116 offset:656                   // 00000002F444: DBFC0290 87000074
	ds_load_b128 v[131:134], v116 offset:640                   // 00000002F44C: DBFC0280 83000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F454: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[131:138], v[33:40], v[89:96]// 00000002F458: CC414059 1D664383
	ds_load_b128 v[135:138], v116 offset:688                   // 00000002F460: DBFC02B0 87000074
	ds_load_b128 v[131:134], v116 offset:672                   // 00000002F468: DBFC02A0 83000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F470: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[131:138], v[41:48], v[89:96]// 00000002F474: CC414059 1D665383
	ds_load_b128 v[135:138], v116 offset:720                   // 00000002F47C: DBFC02D0 87000074
	ds_load_b128 v[131:134], v116 offset:704                   // 00000002F484: DBFC02C0 83000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F48C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[131:138], v[49:56], v[89:96]// 00000002F490: CC414059 1D666383
	ds_load_b128 v[135:138], v116 offset:752                   // 00000002F498: DBFC02F0 87000074
	ds_load_b128 v[131:134], v116 offset:736                   // 00000002F4A0: DBFC02E0 83000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F4A8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[89:96], v[131:138], v[57:64], v[89:96]// 00000002F4AC: CC414059 1D667383
	ds_load_b128 v[135:138], v116 offset:784                   // 00000002F4B4: DBFC0310 87000074
	ds_load_b128 v[131:134], v116 offset:768                   // 00000002F4BC: DBFC0300 83000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F4C4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[131:138], v[1:8], v[65:72]// 00000002F4C8: CC414041 1D060383
	ds_load_b128 v[135:138], v116 offset:816                   // 00000002F4D0: DBFC0330 87000074
	ds_load_b128 v[131:134], v116 offset:800                   // 00000002F4D8: DBFC0320 83000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F4E0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[131:138], v[9:16], v[65:72]// 00000002F4E4: CC414041 1D061383
	ds_load_b128 v[135:138], v116 offset:848                   // 00000002F4EC: DBFC0350 87000074
	ds_load_b128 v[131:134], v116 offset:832                   // 00000002F4F4: DBFC0340 83000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F4FC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[131:138], v[17:24], v[65:72]// 00000002F500: CC414041 1D062383
	ds_load_b128 v[135:138], v116 offset:880                   // 00000002F508: DBFC0370 87000074
	ds_load_b128 v[131:134], v116 offset:864                   // 00000002F510: DBFC0360 83000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F518: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[131:138], v[25:32], v[65:72]// 00000002F51C: CC414041 1D063383
	ds_load_b128 v[135:138], v116 offset:912                   // 00000002F524: DBFC0390 87000074
	ds_load_b128 v[131:134], v116 offset:896                   // 00000002F52C: DBFC0380 83000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F534: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[131:138], v[33:40], v[65:72]// 00000002F538: CC414041 1D064383
	ds_load_b128 v[135:138], v116 offset:944                   // 00000002F540: DBFC03B0 87000074
	ds_load_b128 v[131:134], v116 offset:928                   // 00000002F548: DBFC03A0 83000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F550: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[131:138], v[41:48], v[65:72]// 00000002F554: CC414041 1D065383
	ds_load_b128 v[135:138], v116 offset:976                   // 00000002F55C: DBFC03D0 87000074
	ds_load_b128 v[131:134], v116 offset:960                   // 00000002F564: DBFC03C0 83000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F56C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[131:138], v[49:56], v[65:72]// 00000002F570: CC414041 1D066383
	ds_load_b128 v[135:138], v116 offset:1008                  // 00000002F578: DBFC03F0 87000074
	ds_load_b128 v[131:134], v116 offset:992                   // 00000002F580: DBFC03E0 83000074
	s_waitcnt lgkmcnt(0)                                       // 00000002F588: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[65:72], v[131:138], v[57:64], v[65:72]// 00000002F58C: CC414041 1D067383
	s_and_saveexec_b32 s13, s0                                 // 00000002F594: BE8D2000
	s_cbranch_execz 400                                        // 00000002F598: BFA50190 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x13dc>
	v_or_b32_e32 v116, s23, v125                               // 00000002F59C: 38E8FA17
	s_mov_b32 s14, exec_lo                                     // 00000002F5A0: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F5A4: BF870001
	.long 0xd4c4007e                                           // 00000002F5A8: D4C4007E
	v_cndmask_b32_e32 v1, s22, v116, vcc_lo                    // 00000002F5AC: 0202E816
	s_cbranch_execz 43                                         // 00000002F5B0: BFA5002B <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0xe60>
	v_max_f32_e32 v73, v73, v73                                // 00000002F5B4: 20929349
	v_max_f32_e32 v81, v81, v81                                // 00000002F5B8: 20A2A351
	v_add_nc_u32_e32 v117, s1, v116                            // 00000002F5BC: 4AEAE801
	v_max_f32_e32 v89, v89, v89                                // 00000002F5C0: 20B2B359
	v_ashrrev_i32_e32 v133, 31, v116                           // 00000002F5C4: 350AE89F
	v_max_f32_e32 v73, 0, v73                                  // 00000002F5C8: 20929280
	v_max_f32_e32 v81, 0, v81                                  // 00000002F5CC: 20A2A280
	v_ashrrev_i32_e32 v135, 31, v117                           // 00000002F5D0: 350EEA9F
	v_max_f32_e32 v65, v65, v65                                // 00000002F5D4: 20828341
	v_max_f32_e32 v89, 0, v89                                  // 00000002F5D8: 20B2B280
	v_add_f32_e32 v73, 0, v73                                  // 00000002F5DC: 06929280
	.long 0xd72c0086                                           // 00000002F5E0: D72C0086
	v_cndmask_b32_e32 v1, s11, v116, vcc_lo                    // 00000002F5E4: 0202E80B
	v_mad_u64_u32 v[131:132], null, s10, v116, 0               // 00000002F5E8: D6FE7C83 0202E80A
	v_max_f32_e32 v65, 0, v65                                  // 00000002F5F0: 20828280
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002F5F4: BF8701B4
	v_add_f32_e32 v73, v73, v81                                // 00000002F5F8: 0692A349
	.long 0xd72c0051                                           // 00000002F5FC: D72C0051
	v_cndmask_b32_e32 v1, s10, v133, vcc_lo                    // 00000002F600: 02030A0A
	v_lshrrev_b32_e32 v133, 30, v135                           // 00000002F604: 330B0E9E
	v_add_f32_e32 v73, v73, v89                                // 00000002F608: 0692B349
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002F60C: BF870212
	v_add_nc_u32_e32 v89, v117, v133                           // 00000002F610: 4AB30B75
	v_add3_u32 v132, v132, v81, v134                           // 00000002F614: D6550084 061AA384
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002F61C: BF870193
	v_add_f32_e32 v65, v73, v65                                // 00000002F620: 06828349
	v_ashrrev_i32_e32 v73, 2, v89                              // 00000002F624: 3492B282
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002F628: BF870193
	.long 0xd73c0083                                           // 00000002F62C: D73C0083
	v_cndmask_b32_e32 v1, 2, v131, vcc_lo                      // 00000002F630: 02030682
	v_mul_f32_e32 v65, v124, v65                               // 00000002F634: 1082837C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002F638: BF870113
	v_cmp_lt_i32_e32 vcc_lo, v113, v73                         // 00000002F63C: 7C829371
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000002F640: 02828280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F644: BF870094
	.long 0xd7006a83                                           // 00000002F648: D7006A83
	v_cndmask_b32_e32 v1, v129, v131, vcc_lo                   // 00000002F64C: 02030781
	v_add_co_ci_u32_e64 v132, null, v130, v132, vcc_lo         // 00000002F650: D5207C84 01AB0982
	global_store_b32 v[131:132], v65, off                      // 00000002F658: DC6A0000 007C4183
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002F660: 8C7E0E7E
	v_or_b32_e32 v65, 2, v116                                  // 00000002F664: 3882E882
	s_mov_b32 s14, exec_lo                                     // 00000002F668: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F66C: BF870001
	.long 0xd4c4007e                                           // 00000002F670: D4C4007E
	v_cndmask_b32_e32 v1, s22, v65, vcc_lo                     // 00000002F674: 02028216
	s_cbranch_execz 45                                         // 00000002F678: BFA5002D <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0xf30>
	v_max_f32_e32 v73, v74, v74                                // 00000002F67C: 2092954A
	v_max_f32_e32 v74, v82, v82                                // 00000002F680: 2094A552
	v_dual_max_f32 v82, v66, v66 :: v_dual_add_nc_u32 v89, s1, v65// 00000002F684: CAA08542 52588201
	v_max_f32_e32 v81, v90, v90                                // 00000002F68C: 20A2B55A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002F690: BF870223
	v_dual_max_f32 v73, 0, v73 :: v_dual_max_f32 v66, 0, v74   // 00000002F694: CA949280 49429480
	v_ashrrev_i32_e32 v74, 31, v65                             // 00000002F69C: 3494829F
	v_ashrrev_i32_e32 v117, 31, v89                            // 00000002F6A0: 34EAB29F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002F6A4: BF870214
	v_dual_max_f32 v81, 0, v81 :: v_dual_max_f32 v82, 0, v82   // 00000002F6A8: CA94A280 5152A480
	v_add_f32_e32 v73, 0, v73                                  // 00000002F6B0: 06929280
	.long 0xd72c005a                                           // 00000002F6B4: D72C005A
	v_cndmask_b32_e32 v1, s11, v65, vcc_lo                     // 00000002F6B8: 0202820B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002F6BC: BF870224
	v_lshrrev_b32_e32 v117, 30, v117                           // 00000002F6C0: 32EAEA9E
	.long 0xd72c004a                                           // 00000002F6C4: D72C004A
	v_cndmask_b32_e32 v1, s10, v74, vcc_lo                     // 00000002F6C8: 0202940A
	v_add_f32_e32 v73, v73, v66                                // 00000002F6CC: 06928549
	v_mad_u64_u32 v[65:66], null, s10, v65, 0                  // 00000002F6D0: D6FE7C41 0202820A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002F6D8: BF8701A2
	v_add_f32_e32 v73, v73, v81                                // 00000002F6DC: 0692A349
	v_add_nc_u32_e32 v81, v89, v117                            // 00000002F6E0: 4AA2EB59
	v_add3_u32 v66, v66, v74, v90                              // 00000002F6E4: D6550042 056A9542
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002F6EC: BF870193
	v_add_f32_e32 v73, v73, v82                                // 00000002F6F0: 0692A549
	v_ashrrev_i32_e32 v74, 2, v81                              // 00000002F6F4: 3494A282
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002F6F8: BF870193
	.long 0xd73c0041                                           // 00000002F6FC: D73C0041
	v_cndmask_b32_e32 v1, 2, v65, vcc_lo                       // 00000002F700: 02028282
	v_mul_f32_e32 v73, v124, v73                               // 00000002F704: 1092937C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002F708: BF870113
	v_cmp_lt_i32_e32 vcc_lo, v113, v74                         // 00000002F70C: 7C829571
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 00000002F710: 02929280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F714: BF870094
	.long 0xd7006a41                                           // 00000002F718: D7006A41
	v_cndmask_b32_e32 v1, v129, v65, vcc_lo                    // 00000002F71C: 02028381
	v_add_co_ci_u32_e64 v66, null, v130, v66, vcc_lo           // 00000002F720: D5207C42 01AA8582
	global_store_b32 v[65:66], v73, off                        // 00000002F728: DC6A0000 007C4941
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002F730: 8C7E0E7E
	v_or_b32_e32 v65, 4, v116                                  // 00000002F734: 3882E884
	s_mov_b32 s14, exec_lo                                     // 00000002F738: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F73C: BF870001
	.long 0xd4c4007e                                           // 00000002F740: D4C4007E
	v_cndmask_b32_e32 v1, s22, v65, vcc_lo                     // 00000002F744: 02028216
	s_cbranch_execz 44                                         // 00000002F748: BFA5002C <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0xffc>
	v_dual_max_f32 v66, v75, v75 :: v_dual_add_nc_u32 v75, s1, v65// 00000002F74C: CAA0974B 424A8201
	v_max_f32_e32 v73, v83, v83                                // 00000002F754: 2092A753
	v_ashrrev_i32_e32 v81, 31, v65                             // 00000002F758: 34A2829F
	.long 0xd72c0052                                           // 00000002F75C: D72C0052
	v_cndmask_b32_e32 v1, s11, v65, vcc_lo                     // 00000002F760: 0202820B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002F764: BF870214
	v_max_f32_e32 v66, 0, v66                                  // 00000002F768: 20848480
	v_dual_max_f32 v74, v91, v91 :: v_dual_max_f32 v73, 0, v73 // 00000002F76C: CA94B75B 4A489280
	v_max_f32_e32 v67, v67, v67                                // 00000002F774: 20868743
	v_ashrrev_i32_e32 v83, 31, v75                             // 00000002F778: 34A6969F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002F77C: BF870214
	v_add_f32_e32 v66, 0, v66                                  // 00000002F780: 06848480
	v_max_f32_e32 v74, 0, v74                                  // 00000002F784: 20949480
	.long 0xd72c0051                                           // 00000002F788: D72C0051
	v_cndmask_b32_e32 v1, s10, v81, vcc_lo                     // 00000002F78C: 0202A20A
	v_max_f32_e32 v67, 0, v67                                  // 00000002F790: 20868680
	v_lshrrev_b32_e32 v83, 30, v83                             // 00000002F794: 32A6A69E
	v_add_f32_e32 v73, v66, v73                                // 00000002F798: 06929342
	v_mad_u64_u32 v[65:66], null, s10, v65, 0                  // 00000002F79C: D6FE7C41 0202820A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002F7A4: BF870112
	v_dual_add_f32 v73, v73, v74 :: v_dual_add_nc_u32 v74, v75, v83// 00000002F7A8: C9209549 494AA74B
	v_add3_u32 v66, v66, v81, v82                              // 00000002F7B0: D6550042 054AA342
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002F7B8: BF870192
	v_add_f32_e32 v67, v73, v67                                // 00000002F7BC: 06868749
	v_ashrrev_i32_e32 v73, 2, v74                              // 00000002F7C0: 34929482
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002F7C4: BF870193
	.long 0xd73c0041                                           // 00000002F7C8: D73C0041
	v_cndmask_b32_e32 v1, 2, v65, vcc_lo                       // 00000002F7CC: 02028282
	v_mul_f32_e32 v67, v124, v67                               // 00000002F7D0: 1086877C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002F7D4: BF870113
	v_cmp_lt_i32_e32 vcc_lo, v113, v73                         // 00000002F7D8: 7C829371
	v_cndmask_b32_e32 v67, 0, v67, vcc_lo                      // 00000002F7DC: 02868680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F7E0: BF870094
	.long 0xd7006a41                                           // 00000002F7E4: D7006A41
	v_cndmask_b32_e32 v1, v129, v65, vcc_lo                    // 00000002F7E8: 02028381
	v_add_co_ci_u32_e64 v66, null, v130, v66, vcc_lo           // 00000002F7EC: D5207C42 01AA8582
	global_store_b32 v[65:66], v67, off                        // 00000002F7F4: DC6A0000 007C4341
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002F7FC: 8C7E0E7E
	v_or_b32_e32 v65, 6, v116                                  // 00000002F800: 3882E886
	s_mov_b32 s14, exec_lo                                     // 00000002F804: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F808: BF870001
	.long 0xd4c4007e                                           // 00000002F80C: D4C4007E
	v_cndmask_b32_e32 v1, s22, v65, vcc_lo                     // 00000002F810: 02028216
	s_cbranch_execz 45                                         // 00000002F814: BFA5002D <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x10cc>
	v_max_f32_e32 v67, v84, v84                                // 00000002F818: 2086A954
	v_max_f32_e32 v66, v76, v76                                // 00000002F81C: 2084994C
	v_dual_max_f32 v73, v92, v92 :: v_dual_add_nc_u32 v74, s1, v65// 00000002F820: CAA0B95C 494A8201
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002F828: BF870113
	v_dual_max_f32 v68, v68, v68 :: v_dual_max_f32 v67, 0, v67 // 00000002F82C: CA948944 44428680
	v_dual_max_f32 v66, 0, v66 :: v_dual_max_f32 v73, 0, v73   // 00000002F834: CA948480 42489280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000002F83C: BF870233
	v_ashrrev_i32_e32 v81, 31, v74                             // 00000002F840: 34A2949F
	v_ashrrev_i32_e32 v75, 31, v65                             // 00000002F844: 3496829F
	.long 0xd72c004c                                           // 00000002F848: D72C004C
	v_cndmask_b32_e32 v1, s11, v65, vcc_lo                     // 00000002F84C: 0202820B
	v_add_f32_e32 v66, 0, v66                                  // 00000002F850: 06848480
	v_max_f32_e32 v68, 0, v68                                  // 00000002F854: 20888880
	v_lshrrev_b32_e32 v81, 30, v81                             // 00000002F858: 32A2A29E
	.long 0xd72c004b                                           // 00000002F85C: D72C004B
	v_cndmask_b32_e32 v1, s10, v75, vcc_lo                     // 00000002F860: 0202960A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002F864: BF870124
	v_add_f32_e32 v67, v66, v67                                // 00000002F868: 06868742
	v_mad_u64_u32 v[65:66], null, s10, v65, 0                  // 00000002F86C: D6FE7C41 0202820A
	v_add_f32_e32 v67, v67, v73                                // 00000002F874: 06869343
	v_add_nc_u32_e32 v73, v74, v81                             // 00000002F878: 4A92A34A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002F87C: BF870193
	v_add3_u32 v66, v66, v75, v76                              // 00000002F880: D6550042 05329742
	v_add_f32_e32 v67, v67, v68                                // 00000002F888: 06868943
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002F88C: BF870193
	v_ashrrev_i32_e32 v68, 2, v73                              // 00000002F890: 34889282
	.long 0xd73c0041                                           // 00000002F894: D73C0041
	v_cndmask_b32_e32 v1, 2, v65, vcc_lo                       // 00000002F898: 02028282
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002F89C: BF870193
	v_mul_f32_e32 v67, v124, v67                               // 00000002F8A0: 1086877C
	v_cmp_lt_i32_e32 vcc_lo, v113, v68                         // 00000002F8A4: 7C828971
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002F8A8: BF870212
	v_cndmask_b32_e32 v67, 0, v67, vcc_lo                      // 00000002F8AC: 02868680
	.long 0xd7006a41                                           // 00000002F8B0: D7006A41
	v_cndmask_b32_e32 v1, v129, v65, vcc_lo                    // 00000002F8B4: 02028381
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F8B8: BF870001
	v_add_co_ci_u32_e64 v66, null, v130, v66, vcc_lo           // 00000002F8BC: D5207C42 01AA8582
	global_store_b32 v[65:66], v67, off                        // 00000002F8C4: DC6A0000 007C4341
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002F8CC: 8C7E0E7E
	v_or_b32_e32 v65, 8, v116                                  // 00000002F8D0: 3882E888
	s_mov_b32 s14, exec_lo                                     // 00000002F8D4: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F8D8: BF870001
	.long 0xd4c4007e                                           // 00000002F8DC: D4C4007E
	v_cndmask_b32_e32 v1, s22, v65, vcc_lo                     // 00000002F8E0: 02028216
	s_cbranch_execz 45                                         // 00000002F8E4: BFA5002D <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x119c>
	v_max_f32_e32 v67, v85, v85                                // 00000002F8E8: 2086AB55
	v_max_f32_e32 v66, v77, v77                                // 00000002F8EC: 20849B4D
	v_ashrrev_i32_e32 v74, 31, v65                             // 00000002F8F0: 3494829F
	.long 0xd72c004b                                           // 00000002F8F4: D72C004B
	v_cndmask_b32_e32 v1, s11, v65, vcc_lo                     // 00000002F8F8: 0202820B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000002F8FC: BF870223
	v_dual_max_f32 v67, 0, v67 :: v_dual_max_f32 v66, 0, v66   // 00000002F900: CA948680 43428480
	v_max_f32_e32 v69, v69, v69                                // 00000002F908: 208A8B45
	.long 0xd72c004a                                           // 00000002F90C: D72C004A
	v_cndmask_b32_e32 v1, s10, v74, vcc_lo                     // 00000002F910: 0202940A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F914: BF870093
	v_add_f32_e32 v66, 0, v66                                  // 00000002F918: 06848480
	v_dual_max_f32 v68, v93, v93 :: v_dual_add_f32 v67, v66, v67// 00000002F91C: CA88BB5D 44428742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002F924: BF870121
	v_dual_max_f32 v68, 0, v68 :: v_dual_add_nc_u32 v73, s1, v65// 00000002F928: CAA08880 44488201
	v_mad_u64_u32 v[65:66], null, s10, v65, 0                  // 00000002F930: D6FE7C41 0202820A
	v_ashrrev_i32_e32 v76, 31, v73                             // 00000002F938: 3498929F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002F93C: BF870193
	v_add_f32_e32 v67, v67, v68                                // 00000002F940: 06868943
	v_add3_u32 v66, v66, v74, v75                              // 00000002F944: D6550042 052E9542
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000002F94C: BF8701A3
	v_lshrrev_b32_e32 v76, 30, v76                             // 00000002F950: 3298989E
	v_max_f32_e32 v69, 0, v69                                  // 00000002F954: 208A8A80
	.long 0xd73c0041                                           // 00000002F958: D73C0041
	v_cndmask_b32_e32 v1, 2, v65, vcc_lo                       // 00000002F95C: 02028282
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002F960: BF870092
	v_dual_add_f32 v67, v67, v69 :: v_dual_add_nc_u32 v68, v73, v76// 00000002F964: C9208B43 43449949
	v_ashrrev_i32_e32 v68, 2, v68                              // 00000002F96C: 34888882
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002F970: BF870112
	v_mul_f32_e32 v67, v124, v67                               // 00000002F974: 1086877C
	v_cmp_lt_i32_e32 vcc_lo, v113, v68                         // 00000002F978: 7C828971
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000002F97C: BF8700A2
	v_cndmask_b32_e32 v67, 0, v67, vcc_lo                      // 00000002F980: 02868680
	.long 0xd7006a41                                           // 00000002F984: D7006A41
	v_cndmask_b32_e32 v1, v129, v65, vcc_lo                    // 00000002F988: 02028381
	v_add_co_ci_u32_e64 v66, null, v130, v66, vcc_lo           // 00000002F98C: D5207C42 01AA8582
	global_store_b32 v[65:66], v67, off                        // 00000002F994: DC6A0000 007C4341
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002F99C: 8C7E0E7E
	v_or_b32_e32 v65, 10, v116                                 // 00000002F9A0: 3882E88A
	s_mov_b32 s14, exec_lo                                     // 00000002F9A4: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002F9A8: BF870001
	.long 0xd4c4007e                                           // 00000002F9AC: D4C4007E
	v_cndmask_b32_e32 v1, s22, v65, vcc_lo                     // 00000002F9B0: 02028216
	s_cbranch_execz 45                                         // 00000002F9B4: BFA5002D <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x126c>
	v_max_f32_e32 v67, v86, v86                                // 00000002F9B8: 2086AD56
	v_dual_max_f32 v69, v70, v70 :: v_dual_add_nc_u32 v70, s1, v65// 00000002F9BC: CAA08D46 45468201
	v_max_f32_e32 v66, v78, v78                                // 00000002F9C4: 20849D4E
	v_ashrrev_i32_e32 v73, 31, v65                             // 00000002F9C8: 3492829F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002F9CC: BF870214
	v_max_f32_e32 v67, 0, v67                                  // 00000002F9D0: 20868680
	v_dual_max_f32 v69, 0, v69 :: v_dual_max_f32 v68, v94, v94 // 00000002F9D4: CA948A80 4544BD5E
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002F9DC: BF870004
	v_max_f32_e32 v66, 0, v66                                  // 00000002F9E0: 20848480
	v_ashrrev_i32_e32 v75, 31, v70                             // 00000002F9E4: 34968C9F
	.long 0xd72c004a                                           // 00000002F9E8: D72C004A
	v_cndmask_b32_e32 v1, s11, v65, vcc_lo                     // 00000002F9EC: 0202820B
	.long 0xd72c0049                                           // 00000002F9F0: D72C0049
	v_cndmask_b32_e32 v1, s10, v73, vcc_lo                     // 00000002F9F4: 0202920A
	v_max_f32_e32 v68, 0, v68                                  // 00000002F9F8: 20888880
	v_add_f32_e32 v66, 0, v66                                  // 00000002F9FC: 06848480
	v_lshrrev_b32_e32 v75, 30, v75                             // 00000002FA00: 3296969E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000002FA04: BF870122
	v_add_f32_e32 v67, v66, v67                                // 00000002FA08: 06868742
	v_mad_u64_u32 v[65:66], null, s10, v65, 0                  // 00000002FA0C: D6FE7C41 0202820A
	v_dual_add_f32 v67, v67, v68 :: v_dual_add_nc_u32 v68, v70, v75// 00000002FA14: C9208943 43449746
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002FA1C: BF870112
	v_add3_u32 v66, v66, v73, v74                              // 00000002FA20: D6550042 052A9342
	v_add_f32_e32 v67, v67, v69                                // 00000002FA28: 06868B43
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002FA2C: BF870193
	v_ashrrev_i32_e32 v68, 2, v68                              // 00000002FA30: 34888882
	.long 0xd73c0041                                           // 00000002FA34: D73C0041
	v_cndmask_b32_e32 v1, 2, v65, vcc_lo                       // 00000002FA38: 02028282
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002FA3C: BF870193
	v_mul_f32_e32 v67, v124, v67                               // 00000002FA40: 1086877C
	v_cmp_lt_i32_e32 vcc_lo, v113, v68                         // 00000002FA44: 7C828971
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002FA48: BF870212
	v_cndmask_b32_e32 v67, 0, v67, vcc_lo                      // 00000002FA4C: 02868680
	.long 0xd7006a41                                           // 00000002FA50: D7006A41
	v_cndmask_b32_e32 v1, v129, v65, vcc_lo                    // 00000002FA54: 02028381
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002FA58: BF870001
	v_add_co_ci_u32_e64 v66, null, v130, v66, vcc_lo           // 00000002FA5C: D5207C42 01AA8582
	global_store_b32 v[65:66], v67, off                        // 00000002FA64: DC6A0000 007C4341
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002FA6C: 8C7E0E7E
	v_or_b32_e32 v65, 12, v116                                 // 00000002FA70: 3882E88C
	s_mov_b32 s14, exec_lo                                     // 00000002FA74: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002FA78: BF870001
	.long 0xd4c4007e                                           // 00000002FA7C: D4C4007E
	v_cndmask_b32_e32 v1, s22, v65, vcc_lo                     // 00000002FA80: 02028216
	s_cbranch_execz 44                                         // 00000002FA84: BFA5002C <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x1338>
	v_dual_max_f32 v69, v71, v71 :: v_dual_add_nc_u32 v70, s1, v65// 00000002FA88: CAA08F47 45468201
	v_max_f32_e32 v66, v79, v79                                // 00000002FA90: 20849F4F
	v_max_f32_e32 v68, v95, v95                                // 00000002FA94: 2088BF5F
	v_ashrrev_i32_e32 v71, 31, v65                             // 00000002FA98: 348E829F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002FA9C: BF870214
	v_max_f32_e32 v69, 0, v69                                  // 00000002FAA0: 208A8A80
	v_dual_max_f32 v67, v87, v87 :: v_dual_max_f32 v66, 0, v66 // 00000002FAA4: CA94AF57 43428480
	v_ashrrev_i32_e32 v74, 31, v70                             // 00000002FAAC: 34948C9F
	.long 0xd72c0049                                           // 00000002FAB0: D72C0049
	v_cndmask_b32_e32 v1, s11, v65, vcc_lo                     // 00000002FAB4: 0202820B
	.long 0xd72c0047                                           // 00000002FAB8: D72C0047
	v_cndmask_b32_e32 v1, s10, v71, vcc_lo                     // 00000002FABC: 02028E0A
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000002FAC0: BF8701B4
	v_dual_max_f32 v67, 0, v67 :: v_dual_add_f32 v66, 0, v66   // 00000002FAC4: CA888680 43428480
	v_max_f32_e32 v68, 0, v68                                  // 00000002FACC: 20888880
	v_lshrrev_b32_e32 v74, 30, v74                             // 00000002FAD0: 3294949E
	v_add_f32_e32 v67, v66, v67                                // 00000002FAD4: 06868742
	v_mad_u64_u32 v[65:66], null, s10, v65, 0                  // 00000002FAD8: D6FE7C41 0202820A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002FAE0: BF870112
	v_dual_add_f32 v67, v67, v68 :: v_dual_add_nc_u32 v68, v70, v74// 00000002FAE4: C9208943 43449546
	v_add3_u32 v66, v66, v71, v73                              // 00000002FAEC: D6550042 05268F42
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002FAF4: BF870192
	v_add_f32_e32 v67, v67, v69                                // 00000002FAF8: 06868B43
	v_ashrrev_i32_e32 v68, 2, v68                              // 00000002FAFC: 34888882
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002FB00: BF870193
	.long 0xd73c0041                                           // 00000002FB04: D73C0041
	v_cndmask_b32_e32 v1, 2, v65, vcc_lo                       // 00000002FB08: 02028282
	v_mul_f32_e32 v67, v124, v67                               // 00000002FB0C: 1086877C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002FB10: BF870113
	v_cmp_lt_i32_e32 vcc_lo, v113, v68                         // 00000002FB14: 7C828971
	v_cndmask_b32_e32 v67, 0, v67, vcc_lo                      // 00000002FB18: 02868680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002FB1C: BF870094
	.long 0xd7006a41                                           // 00000002FB20: D7006A41
	v_cndmask_b32_e32 v1, v129, v65, vcc_lo                    // 00000002FB24: 02028381
	v_add_co_ci_u32_e64 v66, null, v130, v66, vcc_lo           // 00000002FB28: D5207C42 01AA8582
	global_store_b32 v[65:66], v67, off                        // 00000002FB30: DC6A0000 007C4341
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002FB38: 8C7E0E7E
	v_or_b32_e32 v116, 14, v116                                // 00000002FB3C: 38E8E88E
	s_mov_b32 s15, s9                                          // 00000002FB40: BE8F0009
	s_mov_b32 s14, exec_lo                                     // 00000002FB44: BE8E007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000002FB48: BF870001
	.long 0xd4c4007e                                           // 00000002FB4C: D4C4007E
	v_cndmask_b32_e32 v1, s22, v116, vcc_lo                    // 00000002FB50: 0202E816
	s_cbranch_execz 28                                         // 00000002FB54: BFA5001C <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x13c8>
	v_max_f32_e32 v66, v88, v88                                // 00000002FB58: 2084B158
	v_max_f32_e32 v65, v80, v80                                // 00000002FB5C: 2082A150
	s_or_b32 s15, s9, exec_lo                                  // 00000002FB60: 8C0F7E09
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002FB64: BF870091
	v_dual_max_f32 v66, 0, v66 :: v_dual_max_f32 v65, 0, v65   // 00000002FB68: CA948480 42408280
	v_dual_add_f32 v65, 0, v65 :: v_dual_add_nc_u32 v68, s1, v116// 00000002FB70: C9208280 4144E801
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002FB78: BF870111
	v_ashrrev_i32_e32 v69, 31, v68                             // 00000002FB7C: 348A889F
	v_dual_add_f32 v65, v65, v66 :: v_dual_max_f32 v66, v72, v72// 00000002FB80: C9148541 41429148
	v_max_f32_e32 v67, v96, v96                                // 00000002FB88: 2086C160
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002FB8C: BF870113
	v_lshrrev_b32_e32 v69, 30, v69                             // 00000002FB90: 328A8A9E
	v_dual_max_f32 v66, 0, v66 :: v_dual_max_f32 v67, 0, v67   // 00000002FB94: CA948480 42428680
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000002FB9C: BF870191
	v_add_f32_e32 v65, v65, v67                                // 00000002FBA0: 06828741
	v_add_nc_u32_e32 v67, v68, v69                             // 00000002FBA4: 4A868B44
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002FBA8: BF870112
	v_add_f32_e32 v65, v65, v66                                // 00000002FBAC: 06828541
	v_ashrrev_i32_e32 v66, 2, v67                              // 00000002FBB0: 34848682
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000002FBB4: BF870112
	v_mul_f32_e32 v65, v124, v65                               // 00000002FBB8: 1082837C
	v_cmp_lt_i32_e32 vcc_lo, v113, v66                         // 00000002FBBC: 7C828571
	s_delay_alu instid0(VALU_DEP_2)                            // 00000002FBC0: BF870002
	v_cndmask_b32_e32 v117, 0, v65, vcc_lo                     // 00000002FBC4: 02EA8280
	s_or_b32 exec_lo, exec_lo, s14                             // 00000002FBC8: 8C7E0E7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002FBCC: BF8704A9
	s_and_not1_b32 s14, s9, exec_lo                            // 00000002FBD0: 910E7E09
	s_and_b32 s15, s15, exec_lo                                // 00000002FBD4: 8B0F7E0F
	s_or_b32 s14, s14, s15                                     // 00000002FBD8: 8C0E0F0E
	s_or_b32 exec_lo, exec_lo, s13                             // 00000002FBDC: 8C7E0D7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000002FBE0: BF8704A9
	s_and_not1_b32 s9, s9, exec_lo                             // 00000002FBE4: 91097E09
	s_and_b32 s13, s14, exec_lo                                // 00000002FBE8: 8B0D7E0E
	s_or_b32 s9, s9, s13                                       // 00000002FBEC: 8C090D09
	s_or_b32 exec_lo, exec_lo, s21                             // 00000002FBF0: 8C7E157E
	s_and_saveexec_b32 s13, s9                                 // 00000002FBF4: BE8D2009
	s_cbranch_execz 64877                                      // 00000002FBF8: BFA5FD6D <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x9b0>
	v_ashrrev_i32_e32 v67, 31, v116                            // 00000002FBFC: 3486E89F
	.long 0xd72c0044                                           // 00000002FC00: D72C0044
	v_cndmask_b32_e32 v1, s11, v116, vcc_lo                    // 00000002FC04: 0202E80B
	v_mad_u64_u32 v[65:66], null, s10, v116, 0                 // 00000002FC08: D6FE7C41 0202E80A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002FC10: BF870093
	.long 0xd72c0043                                           // 00000002FC14: D72C0043
	v_cndmask_b32_e32 v1, s10, v67, vcc_lo                     // 00000002FC18: 0202860A
	v_add3_u32 v66, v66, v67, v68                              // 00000002FC1C: D6550042 05128742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000002FC24: BF870091
	.long 0xd73c0041                                           // 00000002FC28: D73C0041
	v_cndmask_b32_e32 v1, 2, v65, vcc_lo                       // 00000002FC2C: 02028282
	.long 0xd7006a41                                           // 00000002FC30: D7006A41
	v_cndmask_b32_e32 v1, v129, v65, vcc_lo                    // 00000002FC34: 02028381
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000002FC38: BF8704B1
	v_add_co_ci_u32_e64 v66, null, v130, v66, vcc_lo           // 00000002FC3C: D5207C42 01AA8582
	global_store_b32 v[65:66], v117, off                       // 00000002FC44: DC6A0000 007C7541
	s_or_b32 exec_lo, exec_lo, s13                             // 00000002FC4C: 8C7E0D7E
	s_and_not1_b32 vcc_lo, exec_lo, s7                         // 00000002FC50: 916A077E
	s_mov_b32 s7, -1                                           // 00000002FC54: BE8700C1
	s_cbranch_vccnz 64524                                      // 00000002FC58: BFA4FC0C <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x48c>
	s_xor_b32 s7, s8, 1                                        // 00000002FC5C: 8D078108
	v_mul_u32_u24_e32 v66, 0x410, v119                         // 00000002FC60: 1684EEFF 00000410
	s_mulk_i32 s7, 0x4100                                      // 00000002FC68: B8074100
	v_mul_u32_u24_e32 v67, 0x410, v120                         // 00000002FC6C: 1686F0FF 00000410
	v_mad_u32_u24 v65, 0x410, v118, s7                         // 00000002FC74: D60B0041 001EECFF 00000410
	v_mul_u32_u24_e32 v68, 0x410, v121                         // 00000002FC80: 1688F2FF 00000410
	v_add3_u32 v66, s7, v66, v123                              // 00000002FC88: D6550042 05EE8407
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000002FC90: BF870214
	v_add3_u32 v67, s7, v67, v123                              // 00000002FC94: D6550043 05EE8607
	v_lshl_add_u32 v65, v115, 1, v65                           // 00000002FC9C: D6460041 05050373
	s_delay_alu instid0(VALU_DEP_4)                            // 00000002FCA4: BF870004
	v_add3_u32 v68, s7, v68, v123                              // 00000002FCA8: D6550044 05EE8807
	s_mov_b32 s7, 0                                            // 00000002FCB0: BE870080
	s_waitcnt vmcnt(0)                                         // 00000002FCB4: BF8903F7
	ds_store_b128 v65, v[101:104]                              // 00000002FCB8: DB7C0000 00006541
	ds_store_b128 v66, v[97:100]                               // 00000002FCC0: DB7C0000 00006142
	ds_store_b128 v67, v[105:108]                              // 00000002FCC8: DB7C0000 00006943
	ds_store_b128 v68, v[109:112]                              // 00000002FCD0: DB7C0000 00006D44
	s_waitcnt lgkmcnt(0)                                       // 00000002FCD8: BF89FC07
	s_waitcnt_vscnt null, 0x0                                  // 00000002FCDC: BC7C0000
	s_barrier                                                  // 00000002FCE0: BFBD0000
	buffer_gl0_inv                                             // 00000002FCE4: E0AC0000 00000000
	s_branch 64487                                             // 00000002FCEC: BFA0FBE7 <_ZN7halogen12_GLOBAL__N_116k_ix_scores_loopEPKtS2_Pfliiiii+0x48c>
	s_nop 0                                                    // 00000002FCF0: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 00000002FCF4: BFB60003
	s_endpgm                                                   // 00000002FCF8: BFB00000
	v_illegal                                                  // 00000002FCFC: 00000000

