0000000000061400 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE>:
; _ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE():
	s_clause 0x1                                               // 000000061400: BF850001
	s_load_b256 s[16:23], s[0:1], 0x20                         // 000000061404: F40C0400 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 00000006140C: F40C0200 F8000000
	v_readfirstlane_b32 s30, v0                                // 000000061414: 7E3C0500
	v_dual_mov_b32 v2, 0 :: v_dual_lshlrev_b32 v3, 5, v0       // 000000061418: CA220080 02020085
	s_ashr_i32 s3, s2, 31                                      // 000000061420: 86039F02
	s_mov_b64 s[24:25], 0                                      // 000000061424: BE980180
	s_lshr_b32 s6, s30, 5                                      // 000000061428: 8506851E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000006142C: BF8700B9
	s_lshl_b32 s33, s6, 4                                      // 000000061430: 84218406
	v_and_b32_e32 v3, 0x200, v3                                // 000000061434: 360606FF 00000200
	v_and_or_b32 v1, v0, 15, s33                               // 00000006143C: D6570001 00851F00
	.long 0xd73c0001                                           // 000000061444: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000061448: 02020282
	s_waitcnt lgkmcnt(0)                                       // 00000006144C: BF89FC07
	s_load_b32 s7, s[16:17], null                              // 000000061450: F40001C8 F8000000
	s_lshl_b64 s[4:5], s[18:19], 2                             // 000000061458: 84848212
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000006145C: BF8704B9
	s_add_u32 s4, s14, s4                                      // 000000061460: 8004040E
	s_addc_u32 s5, s15, s5                                     // 000000061464: 8205050F
	s_lshl_b64 s[22:23], s[2:3], 16                            // 000000061468: 84969002
	s_add_u32 s4, s4, s22                                      // 00000006146C: 80041604
	s_addc_u32 s5, s5, s23                                     // 000000061470: 82051705
	s_waitcnt lgkmcnt(0)                                       // 000000061474: BF89FC07
	s_mul_i32 s14, s7, 0x9000000                               // 000000061478: 960EFF07 09000000
	s_mul_hi_i32 s7, s7, 0x9000000                             // 000000061480: 9707FF07 09000000
	s_add_u32 s4, s4, s14                                      // 000000061488: 80040E04
	s_addc_u32 s5, s5, s7                                      // 00000006148C: 82050705
	.long 0xd7006a01                                           // 000000061490: D7006A01
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000061494: 02020204
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000061498: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s5, v2, vcc_lo               // 00000006149C: D5207C02 01AA0405
	s_cmp_eq_u32 s6, 0                                         // 0000000614A4: BF068006
	.long 0xd7006a47                                           // 0000000614A8: D7006A47
	v_cndmask_b32_e32 v1, v1, v3, vcc_lo                       // 0000000614AC: 02020701
	v_add_co_ci_u32_e64 v72, null, 0, v2, vcc_lo               // 0000000614B0: D5207C48 01AA0480
	s_cselect_b32 s4, -1, 0                                    // 0000000614B8: 980480C1
	.long 0xd7006a09                                           // 0000000614BC: D7006A09
	v_cndmask_b32_e32 v1, 0x1000, v71, vcc_lo                  // 0000000614C0: 02028EFF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000614C8: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v72, vcc_lo              // 0000000614CC: D5207C0A 01AA9080
	.long 0xd7006a38                                           // 0000000614D4: D7006A38
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 0000000614D8: 0201FF47
	.long 0x00002000                                           // 0000000614DC: 00002000
	v_add_co_ci_u32_e64 v57, null, 0, v72, vcc_lo              // 0000000614E0: D5207C39 01AA9080
	.long 0xd7006a0d                                           // 0000000614E8: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v71, vcc_lo                  // 0000000614EC: 02028EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000614F4: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v72, vcc_lo              // 0000000614F8: D5207C0E 01AA9080
	.long 0xd7006a0f                                           // 000000061500: D7006A0F
	v_cndmask_b32_e32 v1, 0x3000, v71, vcc_lo                  // 000000061504: 02028EFF 00003000
	v_add_co_ci_u32_e64 v16, null, 0, v72, vcc_lo              // 00000006150C: D5207C10 01AA9080
	.long 0xd7006a3b                                           // 000000061514: D7006A3B
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 000000061518: 0201FF47
	.long 0x00004000                                           // 00000006151C: 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000061520: BF870001
	v_add_co_ci_u32_e64 v60, null, 0, v72, vcc_lo              // 000000061524: D5207C3C 01AA9080
	.long 0xd7006a11                                           // 00000006152C: D7006A11
	v_cndmask_b32_e32 v1, 0x4000, v71, vcc_lo                  // 000000061530: 02028EFF 00004000
	s_clause 0x7                                               // 000000061538: BF850007
	global_load_b32 v5, v[71:72], off                          // 00000006153C: DC520000 057C0047
	global_load_b32 v6, v[71:72], off offset:1024              // 000000061544: DC520400 067C0047
	global_load_b32 v7, v[71:72], off offset:2048              // 00000006154C: DC520800 077C0047
	global_load_b32 v8, v[71:72], off offset:3072              // 000000061554: DC520C00 087C0047
	global_load_b32 v2, v[9:10], off offset:1024               // 00000006155C: DC520400 027C0009
	global_load_b32 v3, v[9:10], off offset:2048               // 000000061564: DC520800 037C0009
	global_load_b32 v4, v[9:10], off offset:3072               // 00000006156C: DC520C00 047C0009
	global_load_b32 v1, v[13:14], off offset:1024              // 000000061574: DC520400 017C000D
	v_add_co_ci_u32_e64 v18, null, 0, v72, vcc_lo              // 00000006157C: D5207C12 01AA9080
	s_clause 0x7                                               // 000000061584: BF850007
	global_load_b32 v12, v[13:14], off offset:2048             // 000000061588: DC520800 0C7C000D
	global_load_b32 v13, v[13:14], off offset:3072             // 000000061590: DC520C00 0D7C000D
	global_load_b32 v9, v[15:16], off offset:1024              // 000000061598: DC520400 097C000F
	global_load_b32 v10, v[15:16], off offset:2048             // 0000000615A0: DC520800 0A7C000F
	global_load_b32 v11, v[15:16], off offset:3072             // 0000000615A8: DC520C00 0B7C000F
	global_load_b32 v14, v[17:18], off offset:1024             // 0000000615B0: DC520400 0E7C0011
	global_load_b32 v15, v[17:18], off offset:2048             // 0000000615B8: DC520800 0F7C0011
	global_load_b32 v16, v[17:18], off offset:3072             // 0000000615C0: DC520C00 107C0011
	.long 0xd7006a11                                           // 0000000615C8: D7006A11
	v_cndmask_b32_e32 v1, 0x5000, v71, vcc_lo                  // 0000000615CC: 02028EFF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000615D4: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v72, vcc_lo              // 0000000615D8: D5207C12 01AA9080
	.long 0xd7006a3f                                           // 0000000615E0: D7006A3F
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 0000000615E4: 0201FF47
	.long 0x00006000                                           // 0000000615E8: 00006000
	v_add_co_ci_u32_e64 v64, null, 0, v72, vcc_lo              // 0000000615EC: D5207C40 01AA9080
	.long 0xd7006a17                                           // 0000000615F4: D7006A17
	v_cndmask_b32_e32 v1, 0x6000, v71, vcc_lo                  // 0000000615F8: 02028EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000061600: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v72, vcc_lo              // 000000061604: D5207C18 01AA9080
	.long 0xd7006a19                                           // 00000006160C: D7006A19
	v_cndmask_b32_e32 v1, 0x7000, v71, vcc_lo                  // 000000061610: 02028EFF 00007000
	v_add_co_ci_u32_e64 v26, null, 0, v72, vcc_lo              // 000000061618: D5207C1A 01AA9080
	.long 0xd7006a29                                           // 000000061620: D7006A29
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 000000061624: 0201FF47
	.long 0x00008000                                           // 000000061628: 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006162C: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v72, vcc_lo              // 000000061630: D5207C2A 01AA9080
	.long 0xd7006a20                                           // 000000061638: D7006A20
	v_cndmask_b32_e32 v1, 0x8000, v71, vcc_lo                  // 00000006163C: 02028EFF 00008000
	v_add_co_ci_u32_e64 v33, null, 0, v72, vcc_lo              // 000000061644: D5207C21 01AA9080
	.long 0xd7006a22                                           // 00000006164C: D7006A22
	v_cndmask_b32_e32 v1, 0x9000, v71, vcc_lo                  // 000000061650: 02028EFF 00009000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000061658: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v72, vcc_lo              // 00000006165C: D5207C23 01AA9080
	.long 0xd7006a2b                                           // 000000061664: D7006A2B
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 000000061668: 0201FF47
	.long 0x0000a000                                           // 00000006166C: 0000A000
	v_add_co_ci_u32_e64 v44, null, 0, v72, vcc_lo              // 000000061670: D5207C2C 01AA9080
	.long 0xd7006a25                                           // 000000061678: D7006A25
	v_cndmask_b32_e32 v1, 0xa000, v71, vcc_lo                  // 00000006167C: 02028EFF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000061684: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v72, vcc_lo              // 000000061688: D5207C26 01AA9080
	.long 0xd7006a27                                           // 000000061690: D7006A27
	v_cndmask_b32_e32 v1, 0xb000, v71, vcc_lo                  // 000000061694: 02028EFF 0000B000
	v_add_co_ci_u32_e64 v40, null, 0, v72, vcc_lo              // 00000006169C: D5207C28 01AA9080
	.long 0xd7006a2d                                           // 0000000616A4: D7006A2D
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 0000000616A8: 0201FF47
	.long 0x0000c000                                           // 0000000616AC: 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000616B0: BF8700A1
	v_add_co_ci_u32_e64 v46, null, 0, v72, vcc_lo              // 0000000616B4: D5207C2E 01AA9080
	.long 0xd7006a2f                                           // 0000000616BC: D7006A2F
	v_cndmask_b32_e32 v1, 0xc000, v71, vcc_lo                  // 0000000616C0: 02028EFF 0000C000
	v_add_co_ci_u32_e64 v48, null, 0, v72, vcc_lo              // 0000000616C8: D5207C30 01AA9080
	.long 0xd7006a34                                           // 0000000616D0: D7006A34
	v_cndmask_b32_e32 v1, 0xd000, v71, vcc_lo                  // 0000000616D4: 02028EFF 0000D000
	s_clause 0x17                                              // 0000000616DC: BF850017
	global_load_b32 v20, v[17:18], off offset:1024             // 0000000616E0: DC520400 147C0011
	global_load_b32 v21, v[17:18], off offset:2048             // 0000000616E8: DC520800 157C0011
	global_load_b32 v22, v[17:18], off offset:3072             // 0000000616F0: DC520C00 167C0011
	global_load_b32 v17, v[23:24], off offset:1024             // 0000000616F8: DC520400 117C0017
	global_load_b32 v18, v[23:24], off offset:2048             // 000000061700: DC520800 127C0017
	global_load_b32 v19, v[23:24], off offset:3072             // 000000061708: DC520C00 137C0017
	global_load_b32 v23, v[25:26], off offset:1024             // 000000061710: DC520400 177C0019
	global_load_b32 v24, v[25:26], off offset:2048             // 000000061718: DC520800 187C0019
	global_load_b32 v31, v[25:26], off offset:3072             // 000000061720: DC520C00 1F7C0019
	global_load_b32 v28, v[32:33], off offset:1024             // 000000061728: DC520400 1C7C0020
	global_load_b32 v29, v[32:33], off offset:2048             // 000000061730: DC520800 1D7C0020
	global_load_b32 v30, v[32:33], off offset:3072             // 000000061738: DC520C00 1E7C0020
	global_load_b32 v25, v[34:35], off offset:1024             // 000000061740: DC520400 197C0022
	global_load_b32 v26, v[34:35], off offset:2048             // 000000061748: DC520800 1A7C0022
	global_load_b32 v27, v[34:35], off offset:3072             // 000000061750: DC520C00 1B7C0022
	global_load_b32 v32, v[37:38], off offset:1024             // 000000061758: DC520400 207C0025
	global_load_b32 v36, v[37:38], off offset:2048             // 000000061760: DC520800 247C0025
	global_load_b32 v37, v[37:38], off offset:3072             // 000000061768: DC520C00 257C0025
	global_load_b32 v33, v[39:40], off offset:1024             // 000000061770: DC520400 217C0027
	global_load_b32 v34, v[39:40], off offset:2048             // 000000061778: DC520800 227C0027
	global_load_b32 v35, v[39:40], off offset:3072             // 000000061780: DC520C00 237C0027
	global_load_b32 v38, v[47:48], off offset:1024             // 000000061788: DC520400 267C002F
	global_load_b32 v39, v[47:48], off offset:2048             // 000000061790: DC520800 277C002F
	global_load_b32 v40, v[47:48], off offset:3072             // 000000061798: DC520C00 287C002F
	v_add_co_ci_u32_e64 v53, null, 0, v72, vcc_lo              // 0000000617A0: D5207C35 01AA9080
	.long 0xd7006a2f                                           // 0000000617A8: D7006A2F
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 0000000617AC: 0201FF47
	.long 0x0000e000                                           // 0000000617B0: 0000E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000617B4: BF8700A1
	v_add_co_ci_u32_e64 v48, null, 0, v72, vcc_lo              // 0000000617B8: D5207C30 01AA9080
	.long 0xd7006a3d                                           // 0000000617C0: D7006A3D
	v_cndmask_b32_e32 v1, 0xe000, v71, vcc_lo                  // 0000000617C4: 02028EFF 0000E000
	v_add_co_ci_u32_e64 v62, null, 0, v72, vcc_lo              // 0000000617CC: D5207C3E 01AA9080
	.long 0xd7006a41                                           // 0000000617D4: D7006A41
	v_cndmask_b32_e32 v1, 0xf000, v71, vcc_lo                  // 0000000617D8: 02028EFF 0000F000
	s_clause 0x7                                               // 0000000617E0: BF850007
	global_load_b32 v58, v[41:42], off offset:-4096            // 0000000617E4: DC521000 3A7C0029
	global_load_b32 v55, v[41:42], off                         // 0000000617EC: DC520000 377C0029
	global_load_b32 v54, v[43:44], off offset:-4096            // 0000000617F4: DC521000 367C002B
	global_load_b32 v51, v[43:44], off                         // 0000000617FC: DC520000 337C002B
	global_load_b32 v44, v[45:46], off offset:-4096            // 000000061804: DC521000 2C7C002D
	global_load_b32 v43, v[45:46], off                         // 00000006180C: DC520000 2B7C002D
	global_load_b32 v42, v[47:48], off offset:-4096            // 000000061814: DC521000 2A7C002F
	global_load_b32 v41, v[47:48], off                         // 00000006181C: DC520000 297C002F
	v_add_co_ci_u32_e64 v66, null, 0, v72, vcc_lo              // 000000061824: D5207C42 01AA9080
	s_clause 0xf                                               // 00000006182C: BF85000F
	global_load_b32 v48, v[52:53], off offset:1024             // 000000061830: DC520400 307C0034
	global_load_b32 v49, v[52:53], off offset:2048             // 000000061838: DC520800 317C0034
	global_load_b32 v50, v[52:53], off offset:3072             // 000000061840: DC520C00 327C0034
	global_load_b32 v45, v[61:62], off offset:1024             // 000000061848: DC520400 2D7C003D
	global_load_b32 v46, v[61:62], off offset:2048             // 000000061850: DC520800 2E7C003D
	global_load_b32 v47, v[61:62], off offset:3072             // 000000061858: DC520C00 2F7C003D
	global_load_b32 v52, v[65:66], off                         // 000000061860: DC520000 347C0041
	global_load_b32 v53, v[65:66], off offset:1024             // 000000061868: DC520400 357C0041
	global_load_b32 v74, v[56:57], off offset:-4096            // 000000061870: DC521000 4A7C0038
	global_load_b32 v73, v[56:57], off                         // 000000061878: DC520000 497C0038
	global_load_b32 v62, v[59:60], off offset:-4096            // 000000061880: DC521000 3E7C003B
	global_load_b32 v61, v[59:60], off                         // 000000061888: DC520000 3D7C003B
	global_load_b32 v60, v[63:64], off offset:-4096            // 000000061890: DC521000 3C7C003F
	global_load_b32 v59, v[63:64], off                         // 000000061898: DC520000 3B7C003F
	global_load_b32 v56, v[65:66], off offset:2048             // 0000000618A0: DC520800 387C0041
	global_load_b32 v57, v[65:66], off offset:3072             // 0000000618A8: DC520C00 397C0041
	s_cmp_lg_u32 s6, 0                                         // 0000000618B0: BF078006
	s_cselect_b32 s34, -1, 0                                   // 0000000618B4: 982280C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000618B8: BF870009
	s_and_b32 vcc_lo, exec_lo, s34                             // 0000000618BC: 8B6A227E
	s_cbranch_vccnz 1                                          // 0000000618C0: BFA40001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4c8>
	s_sendmsg_rtn_b64 s[24:25], sendmsg(MSG_RTN_GET_REALTIME)  // 0000000618C4: BE984D83
	s_load_b64 s[26:27], s[0:1], 0x40                          // 0000000618C8: F4040680 F8000040
	v_and_b32_e32 v64, 31, v0                                  // 0000000618D0: 3680009F
	v_lshlrev_b32_e32 v63, 3, v0                               // 0000000618D4: 307E0083
	s_getreg_b32 s14, hwreg(HW_REG_HW_ID1)                     // 0000000618D8: B88EF817
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000618DC: BF870002
	.long 0xd44a0005                                           // 0000000618E0: D44A0005
	v_cndmask_b32_e32 v1, 0, v64, vcc_lo                       // 0000000618E4: 02028080
	s_and_saveexec_b32 s7, s5                                  // 0000000618E8: BE872005
	s_cbranch_execz 13                                         // 0000000618EC: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x524>
	s_lshl_b32 s15, s2, 3                                      // 0000000618F0: 840F8302
	v_dual_mov_b32 v65, 0 :: v_dual_mov_b32 v64, s14           // 0000000618F4: CA100080 4140000E
	s_ashr_i32 s17, s15, 31                                    // 0000000618FC: 86119F0F
	s_add_u32 s16, s15, s6                                     // 000000061900: 8010060F
	s_addc_u32 s17, s17, 0                                     // 000000061904: 82118011
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000061908: BF870009
	s_lshl_b64 s[16:17], s[16:17], 3                           // 00000006190C: 84908310
	s_waitcnt lgkmcnt(0)                                       // 000000061910: BF89FC07
	s_add_u32 s14, s26, s16                                    // 000000061914: 800E101A
	s_addc_u32 s15, s27, s17                                   // 000000061918: 820F111B
	global_store_b64 v65, v[64:65], s[14:15] offset:1024       // 00000006191C: DC6E0400 000E4041
	s_or_b32 exec_lo, exec_lo, s7                              // 000000061924: 8C7E077E
	s_load_b32 s35, s[0:1], 0x38                               // 000000061928: F40008C0 F8000038
	v_lshrrev_b32_e32 v75, 4, v0                               // 000000061930: 32960084
	s_mul_hi_i32 s6, s2, 0x55555556                            // 000000061934: 9706FF02 55555556
	v_and_b32_e32 v65, 0x78, v63                               // 00000006193C: 36827EFF 00000078
	s_lshr_b32 s7, s6, 31                                      // 000000061944: 85079F06
	v_mov_b32_e32 v129, 0                                      // 000000061948: 7F020280
	s_add_i32 s6, s6, s7                                       // 00000006194C: 81060706
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000061950: BF8704B9
	s_lshl_b32 s6, s6, 7                                       // 000000061954: 84068706
	v_lshlrev_b32_e32 v65, 1, v65                              // 000000061958: 30828281
	s_ashr_i32 s7, s6, 31                                      // 00000006195C: 86079F06
	s_lshl_b64 s[14:15], s[6:7], 1                             // 000000061960: 848E8106
	s_mov_b32 s6, exec_lo                                      // 000000061964: BE86007E
	s_waitcnt lgkmcnt(0)                                       // 000000061968: BF89FC07
	s_add_i32 s36, s35, -1                                     // 00000006196C: 8124C123
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061970: BF870099
	v_min_i32_e32 v64, s36, v75                                // 000000061974: 22809624
	v_mad_i64_i32 v[63:64], null, 0x5000, v64, s[8:9]          // 000000061978: D6FF7C3F 002280FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061984: BF870091
	.long 0xd7006a3f                                           // 000000061988: D7006A3F
	v_cndmask_b32_e32 v0, v63, v14, vcc_lo                     // 00000006198C: 02001D3F
	v_add_co_ci_u32_e64 v64, null, s15, v64, vcc_lo            // 000000061990: D5207C40 01AA800F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061998: BF870092
	.long 0xd7006a3f                                           // 00000006199C: D7006A3F
	v_cndmask_b32_e32 v1, v63, v65, vcc_lo                     // 0000000619A0: 0202833F
	v_add_co_ci_u32_e64 v64, null, 0, v64, vcc_lo              // 0000000619A4: D5207C40 01AA8080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000619AC: BF870092
	.long 0xd7006a43                                           // 0000000619B0: D7006A43
	v_cndmask_b32_e32 v1, 0x1000, v63, vcc_lo                  // 0000000619B4: 02027EFF 00001000
	v_add_co_ci_u32_e64 v68, null, 0, v64, vcc_lo              // 0000000619BC: D5207C44 01AA8080
	s_clause 0x1                                               // 0000000619C4: BF850001
	global_load_b128 v[63:66], v[63:64], off                   // 0000000619C8: DC5E0000 3F7C003F
	global_load_b128 v[67:70], v[67:68], off                   // 0000000619D0: DC5E0000 437C0043
	.long 0xd4c3007e                                           // 0000000619D8: D4C3007E
	v_cndmask_b32_e32 v1, s35, v75, vcc_lo                     // 0000000619DC: 02029623
	s_cbranch_execz 11                                         // 0000000619E0: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x610>
	s_waitcnt vmcnt(1)                                         // 0000000619E4: BF8907F7
	v_mov_b32_e32 v63, 0                                       // 0000000619E8: 7E7E0280
	s_waitcnt vmcnt(0)                                         // 0000000619EC: BF8903F7
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000619F0: BF870001
	v_mov_b32_e32 v70, v63                                     // 0000000619F4: 7E8C033F
	v_mov_b32_e32 v69, v63                                     // 0000000619F8: 7E8A033F
	v_mov_b32_e32 v68, v63                                     // 0000000619FC: 7E88033F
	v_mov_b32_e32 v67, v63                                     // 000000061A00: 7E86033F
	v_mov_b32_e32 v64, v63                                     // 000000061A04: 7E80033F
	v_mov_b32_e32 v65, v63                                     // 000000061A08: 7E82033F
	v_mov_b32_e32 v66, v63                                     // 000000061A0C: 7E84033F
	s_or_b32 exec_lo, exec_lo, s6                              // 000000061A10: 8C7E067E
	v_cmp_gt_u32_e32 vcc_lo, 16, v0                            // 000000061A14: 7C980090
	.long 0xd4440006                                           // 000000061A18: D4440006
	v_cndmask_b32_e32 v1, s35, v0, vcc_lo                      // 000000061A1C: 02020023
	v_mov_b32_e32 v130, 0                                      // 000000061A20: 7F040280
	s_and_b32 s7, vcc_lo, s6                                   // 000000061A24: 8B07066A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000061A28: BF870009
	s_and_saveexec_b32 s6, s7                                  // 000000061A2C: BE862007
	s_cbranch_execz 27                                         // 000000061A30: BFA5001B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x6a0>
	v_mul_u32_u24_e32 v75, 0xc0, v0                            // 000000061A34: 169600FF 000000C0
	s_lshl_b64 s[16:17], s[2:3], 2                             // 000000061A3C: 84908202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061A40: BF870091
	.long 0xd700074c                                           // 000000061A44: D700074C
	v_cndmask_b32_e32 v1, s10, v75, vcc_lo                     // 000000061A48: 0202960A
	v_add_co_ci_u32_e64 v77, null, s11, 0, s7                  // 000000061A4C: D5207C4D 001D000B
	.long 0xd700074e                                           // 000000061A54: D700074E
	v_cndmask_b32_e32 v1, s12, v75, vcc_lo                     // 000000061A58: 0202960C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000061A5C: BF870211
	v_add_co_ci_u32_e64 v79, null, s13, 0, s7                  // 000000061A60: D5207C4F 001D000D
	.long 0xd7006a4b                                           // 000000061A68: D7006A4B
	v_cndmask_b32_e32 v0, v76, v16, vcc_lo                     // 000000061A6C: 0200214C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000061A70: BF870211
	v_add_co_ci_u32_e64 v76, null, s17, v77, vcc_lo            // 000000061A74: D5207C4C 01AA9A11
	.long 0xd7006a4d                                           // 000000061A7C: D7006A4D
	v_cndmask_b32_e32 v0, v78, v16, vcc_lo                     // 000000061A80: 0200214E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000061A84: BF870001
	v_add_co_ci_u32_e64 v78, null, s17, v79, vcc_lo            // 000000061A88: D5207C4E 01AA9E11
	global_load_b32 v130, v[75:76], off                        // 000000061A90: DC520000 827C004B
	global_load_b32 v129, v[77:78], off                        // 000000061A98: DC520000 817C004D
	s_or_b32 exec_lo, exec_lo, s6                              // 000000061AA0: 8C7E067E
	s_waitcnt vmcnt(62)                                        // 000000061AA4: BF89FBF7
	v_dual_mul_f32 v128, 0x43800000, v5 :: v_dual_mul_f32 v127, 0x43800000, v6// 000000061AA8: C8C60AFF 807E0CFF 43800000
	v_dual_mul_f32 v126, 0x43800000, v7 :: v_dual_mul_f32 v125, 0x43800000, v8// 000000061AB4: C8C60EFF 7E7C10FF 43800000
	s_waitcnt vmcnt(9)                                         // 000000061AC0: BF8927F7
	v_dual_mul_f32 v124, 0x43800000, v74 :: v_dual_mul_f32 v147, 0x43800000, v4// 000000061AC4: C8C694FF 7C9208FF 43800000
	v_dual_mul_f32 v123, 0x43800000, v2 :: v_dual_mul_f32 v122, 0x43800000, v3// 000000061AD0: C8C604FF 7B7A06FF 43800000
	s_waitcnt vmcnt(8)                                         // 000000061ADC: BF8923F7
	v_dual_mul_f32 v121, 0x43800000, v73 :: v_dual_mul_f32 v146, 0x43800000, v11// 000000061AE0: C8C692FF 799216FF 43800000
	v_dual_mul_f32 v120, 0x43800000, v1 :: v_dual_mul_f32 v119, 0x43800000, v12// 000000061AEC: C8C602FF 787618FF 43800000
	s_waitcnt vmcnt(7)                                         // 000000061AF8: BF891FF7
	v_dual_mul_f32 v118, 0x43800000, v13 :: v_dual_mul_f32 v117, 0x43800000, v62// 000000061AFC: C8C61AFF 76747CFF 43800000
	v_dual_mul_f32 v116, 0x43800000, v9 :: v_dual_mul_f32 v115, 0x43800000, v10// 000000061B08: C8C612FF 747214FF 43800000
	s_waitcnt vmcnt(6)                                         // 000000061B14: BF891BF7
	v_dual_mul_f32 v114, 0x43800000, v61 :: v_dual_mul_f32 v113, 0x43800000, v14// 000000061B18: C8C67AFF 72701CFF 43800000
	v_dual_mul_f32 v112, 0x43800000, v15 :: v_dual_mul_f32 v111, 0x43800000, v16// 000000061B24: C8C61EFF 706E20FF 43800000
	s_waitcnt vmcnt(5)                                         // 000000061B30: BF8917F7
	v_dual_mul_f32 v110, 0x43800000, v60 :: v_dual_mul_f32 v145, 0x43800000, v22// 000000061B34: C8C678FF 6E902CFF 43800000
	v_dual_mul_f32 v109, 0x43800000, v20 :: v_dual_mul_f32 v108, 0x43800000, v21// 000000061B40: C8C628FF 6D6C2AFF 43800000
	s_waitcnt vmcnt(4)                                         // 000000061B4C: BF8913F7
	v_dual_mul_f32 v107, 0x43800000, v59 :: v_dual_mul_f32 v106, 0x43800000, v17// 000000061B50: C8C676FF 6B6A22FF 43800000
	v_dual_mul_f32 v105, 0x43800000, v18 :: v_dual_mul_f32 v104, 0x43800000, v19// 000000061B5C: C8C624FF 696826FF 43800000
	v_dual_mul_f32 v103, 0x43800000, v58 :: v_dual_mul_f32 v102, 0x43800000, v23// 000000061B68: C8C674FF 67662EFF 43800000
	v_dual_mul_f32 v101, 0x43800000, v24 :: v_dual_mul_f32 v144, 0x43800000, v31// 000000061B74: C8C630FF 65903EFF 43800000
	v_dual_mul_f32 v100, 0x43800000, v55 :: v_dual_mul_f32 v99, 0x43800000, v28// 000000061B80: C8C66EFF 646238FF 43800000
	v_dual_mul_f32 v98, 0x43800000, v29 :: v_dual_mul_f32 v97, 0x43800000, v30// 000000061B8C: C8C63AFF 62603CFF 43800000
	v_dual_mul_f32 v96, 0x43800000, v54 :: v_dual_mul_f32 v95, 0x43800000, v25// 000000061B98: C8C66CFF 605E32FF 43800000
	v_dual_mul_f32 v94, 0x43800000, v26 :: v_dual_mul_f32 v143, 0x43800000, v27// 000000061BA4: C8C634FF 5E8E36FF 43800000
	v_dual_mul_f32 v93, 0x43800000, v51 :: v_dual_mul_f32 v92, 0x43800000, v32// 000000061BB0: C8C666FF 5D5C40FF 43800000
	v_dual_mul_f32 v91, 0x43800000, v36 :: v_dual_mul_f32 v90, 0x43800000, v37// 000000061BBC: C8C648FF 5B5A4AFF 43800000
	v_dual_mul_f32 v89, 0x43800000, v44 :: v_dual_mul_f32 v88, 0x43800000, v33// 000000061BC8: C8C658FF 595842FF 43800000
	v_dual_mul_f32 v87, 0x43800000, v34 :: v_dual_mul_f32 v142, 0x43800000, v35// 000000061BD4: C8C644FF 578E46FF 43800000
	v_dual_mul_f32 v86, 0x43800000, v43 :: v_dual_mul_f32 v85, 0x43800000, v38// 000000061BE0: C8C656FF 56544CFF 43800000
	v_dual_mul_f32 v84, 0x43800000, v39 :: v_dual_mul_f32 v83, 0x43800000, v40// 000000061BEC: C8C64EFF 545250FF 43800000
	v_dual_mul_f32 v82, 0x43800000, v42 :: v_dual_mul_f32 v81, 0x43800000, v48// 000000061BF8: C8C654FF 525060FF 43800000
	v_dual_mul_f32 v80, 0x43800000, v49 :: v_dual_mul_f32 v141, 0x43800000, v50// 000000061C04: C8C662FF 508C64FF 43800000
	v_dual_mul_f32 v79, 0x43800000, v41 :: v_dual_mul_f32 v76, 0x43800000, v47// 000000061C10: C8C652FF 4F4C5EFF 43800000
	v_dual_mul_f32 v78, 0x43800000, v45 :: v_dual_mul_f32 v77, 0x43800000, v46// 000000061C1C: C8C65AFF 4E4C5CFF 43800000
	v_dual_mul_f32 v75, 0x43800000, v52 :: v_dual_mul_f32 v74, 0x43800000, v53// 000000061C28: C8C668FF 4B4A6AFF 43800000
	s_waitcnt vmcnt(2)                                         // 000000061C34: BF890BF7
	v_dual_mul_f32 v73, 0x43800000, v56 :: v_dual_mul_f32 v140, 0x43800000, v57// 000000061C38: C8C670FF 498C72FF 43800000
	s_cmp_lt_i32 s35, 1                                        // 000000061C44: BF048123
	s_cbranch_scc1 4684                                        // 000000061C48: BFA2124C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x517c>
	s_add_u32 s6, s8, s14                                      // 000000061C4C: 80060E08
	s_addc_u32 s7, s9, s15                                     // 000000061C50: 82070F09
	s_lshl_b64 s[14:15], s[2:3], 2                             // 000000061C54: 848E8202
	.long 0xd71f0084                                           // 000000061C58: D71F0084
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 000000061C5C: 020100C1
	s_add_u32 s10, s10, s14                                    // 000000061C60: 800A0E0A
	s_addc_u32 s11, s11, s15                                   // 000000061C64: 820B0F0B
	s_add_u32 s28, s12, s14                                    // 000000061C68: 801C0E0C
	s_addc_u32 s29, s13, s15                                   // 000000061C6C: 821D0F0D
	s_load_b256 s[12:19], s[0:1], 0x48                         // 000000061C70: F40C0300 F8000048
	s_add_i32 s31, s35, 15                                     // 000000061C78: 811F8F23
	s_load_b64 s[0:1], s[0:1], 0x68                            // 000000061C7C: F4040000 F8000068
	s_waitcnt lgkmcnt(0)                                       // 000000061C84: BF89FC07
	s_ashr_i32 s15, s31, 31                                    // 000000061C88: 860F9F1F
	s_lshl_b32 s40, s2, 7                                      // 000000061C8C: 84288702
	s_lshr_b32 s15, s15, 28                                    // 000000061C90: 850F9C0F
	s_ashr_i32 s41, s40, 31                                    // 000000061C94: 86299F28
	s_add_i32 s31, s31, s15                                    // 000000061C98: 811F0F1F
	v_rsq_f32_e32 v131, 0x43000000                             // 000000061C9C: 7F065CFF 43000000
	s_ashr_i32 s15, s31, 4                                     // 000000061CA4: 860F841F
	s_cmp_gt_u32 s30, 63                                       // 000000061CA8: BF08BF1E
	s_movk_i32 s30, 0x5f40                                     // 000000061CAC: B01E5F40
	s_cselect_b32 s37, -1, 0                                   // 000000061CB0: 982580C1
	s_and_b32 s31, s4, exec_lo                                 // 000000061CB4: 8B1F7E04
	s_cselect_b32 s38, s30, 0x5f80                             // 000000061CB8: 9826FF1E 00005F80
	s_lshl_b64 s[30:31], s[40:41], 1                           // 000000061CC0: 849E8128
	v_dual_mov_b32 v1, 0 :: v_dual_and_b32 v2, 16, v132        // 000000061CC4: CA240080 01030890
	s_add_u32 s39, s20, s30                                    // 000000061CCC: 80271E14
	s_addc_u32 s40, s21, s31                                   // 000000061CD0: 82281F15
	s_max_i32 s41, s15, 1                                      // 000000061CD4: 8A29810F
	s_add_u32 s42, s16, s22                                    // 000000061CD8: 802A1610
	s_addc_u32 s43, s17, s23                                   // 000000061CDC: 822B1711
	s_add_u32 s44, s18, s22                                    // 000000061CE0: 802C1612
	v_dual_mov_b32 v138, 0x1000504 :: v_dual_add_nc_u32 v133, 16, v2// 000000061CE4: CA2000FF 8A840490 01000504
	v_xor_b32_e32 v134, 1, v132                                // 000000061CF0: 3B0D0881
	v_xor_b32_e32 v135, 2, v132                                // 000000061CF4: 3B0F0882
	v_xor_b32_e32 v136, 4, v132                                // 000000061CF8: 3B110884
	v_xor_b32_e32 v137, 8, v132                                // 000000061CFC: 3B130888
	v_mov_b32_e32 v139, 0x3020706                              // 000000061D00: 7F1602FF 03020706
	s_addc_u32 s45, s19, s23                                   // 000000061D08: 822D1713
	s_mov_b32 s16, 0                                           // 000000061D0C: BE900080
	s_add_u32 s46, s0, s22                                     // 000000061D10: 802E1600
	s_addc_u32 s47, s1, s23                                    // 000000061D14: 822F1701
	s_mov_b32 s48, 0x41800000                                  // 000000061D18: BEB000FF 41800000
	s_movk_i32 s49, 0x1800                                     // 000000061D20: B0311800
	s_movk_i32 s50, 0x2900                                     // 000000061D24: B0322900
	s_mov_b32 s17, s16                                         // 000000061D28: BE910010
	s_mov_b32 s18, s16                                         // 000000061D2C: BE920010
	s_mov_b32 s19, s16                                         // 000000061D30: BE930010
	s_mov_b32 s20, s16                                         // 000000061D34: BE940010
	s_mov_b32 s21, s16                                         // 000000061D38: BE950010
	s_mov_b32 s22, s16                                         // 000000061D3C: BE960010
	s_mov_b32 s23, s16                                         // 000000061D40: BE970010
	s_mov_b32 s51, 0x3d800000                                  // 000000061D44: BEB300FF 3D800000
	s_mov_b32 s52, 0x76543210                                  // 000000061D4C: BEB400FF 76543210
	s_mov_b32 s53, s16                                         // 000000061D54: BEB50010
	s_branch 10                                                // 000000061D58: BFA0000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x984>
	v_dual_mov_b32 v140, v33 :: v_dual_mov_b32 v145, v38       // 000000061D5C: CA100121 8C900126
	v_dual_mov_b32 v141, v37 :: v_dual_mov_b32 v146, v46       // 000000061D64: CA100125 8D92012E
	v_dual_mov_b32 v142, v25 :: v_dual_mov_b32 v147, v54       // 000000061D6C: CA100119 8E920136
	v_mov_b32_e32 v143, v9                                     // 000000061D74: 7F1E0309
	v_mov_b32_e32 v144, v17                                    // 000000061D78: 7F200311
	s_cmp_eq_u32 s53, s41                                      // 000000061D7C: BF062935
	s_cbranch_scc1 4614                                        // 000000061D80: BFA21206 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x519c>
	v_mov_b32_e32 v44, v0                                      // 000000061D84: 7E580300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000061D88: BF8701B1
	v_ashrrev_i32_e32 v2, 4, v44                               // 000000061D8C: 34045884
	v_and_b32_e32 v50, 15, v44                                 // 000000061D90: 3664588F
	.long 0xd4440000                                           // 000000061D94: D4440000
	v_cndmask_b32_e32 v1, 16, v44, vcc_lo                      // 000000061D98: 02025890
	.long 0xd72c0003                                           // 000000061D9C: D72C0003
	v_cndmask_b32_e32 v1, 0x110, v2, vcc_lo                    // 000000061DA0: 020204FF 00000110
	s_delay_alu instid0(VALU_DEP_1)                            // 000000061DA8: BF870001
	v_lshl_add_u32 v3, v50, 4, v3                              // 000000061DAC: D6460003 040D0932
	s_waitcnt vmcnt(1)                                         // 000000061DB4: BF8907F7
	ds_store_b128 v3, v[63:66] offset:10496                    // 000000061DB8: DB7C2900 00003F03
	s_waitcnt vmcnt(0)                                         // 000000061DC0: BF8903F7
	ds_store_b128 v3, v[67:70] offset:6144                     // 000000061DC4: DB7C1800 00004303
	s_and_saveexec_b32 s1, s0                                  // 000000061DCC: BE812000
	v_lshlrev_b32_e32 v3, 2, v44                               // 000000061DD0: 30065882
	ds_store_b32 v3, v129 offset:24064                         // 000000061DD4: D8345E00 00008103
	s_or_b32 exec_lo, exec_lo, s1                              // 000000061DDC: 8C7E017E
	v_and_b32_e32 v34, 1, v44                                  // 000000061DE0: 36445881
	s_lshl_b32 s54, s53, 4                                     // 000000061DE4: 84368435
	v_or_b32_e32 v148, s33, v50                                // 000000061DE8: 39286421
	s_mov_b32 s55, exec_lo                                     // 000000061DEC: BEB7007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000061DF0: BF870112
	v_or_b32_e32 v15, s54, v34                                 // 000000061DF4: 381E4436
	v_and_b32_e32 v6, 0x7ffffffe, v148                         // 000000061DF8: 360D28FF 7FFFFFFE
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000061E00: BF870232
	v_min_i32_e32 v3, s36, v15                                 // 000000061E04: 22061E24
	v_or_b32_e32 v5, 2, v15                                    // 000000061E08: 380A1E82
	v_or_b32_e32 v7, 4, v15                                    // 000000061E0C: 380E1E84
	v_lshlrev_b32_e32 v19, 1, v6                               // 000000061E10: 30260C81
	v_or_b32_e32 v8, 6, v15                                    // 000000061E14: 38101E86
	v_mad_i64_i32 v[3:4], null, 0x5000, v3, s[8:9]             // 000000061E18: D6FF7C03 002206FF 00005000
	v_min_i32_e32 v5, s36, v5                                  // 000000061E24: 220A0A24
	v_min_i32_e32 v7, s36, v7                                  // 000000061E28: 220E0E24
	v_or_b32_e32 v17, 12, v15                                  // 000000061E2C: 38221E8C
	v_min_i32_e32 v8, s36, v8                                  // 000000061E30: 22101024
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000061E34: BF8700A4
	v_mad_i64_i32 v[5:6], null, 0x5000, v5, s[8:9]             // 000000061E38: D6FF7C05 00220AFF 00005000
	.long 0xd7006a09                                           // 000000061E44: D7006A09
	v_cndmask_b32_e32 v0, v3, v30, vcc_lo                      // 000000061E48: 02003D03
	v_add_co_ci_u32_e64 v10, null, s31, v4, vcc_lo             // 000000061E4C: D5207C0A 01AA081F
	v_mad_i64_i32 v[3:4], null, 0x5000, v7, s[8:9]             // 000000061E54: D6FF7C03 00220EFF 00005000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061E60: BF870093
	.long 0xd7006a07                                           // 000000061E64: D7006A07
	v_cndmask_b32_e32 v1, v9, v19, vcc_lo                      // 000000061E68: 02022709
	v_add_co_ci_u32_e64 v9, null, 0, v10, vcc_lo               // 000000061E6C: D5207C09 01AA1480
	.long 0xd7006a0a                                           // 000000061E74: D7006A0A
	v_cndmask_b32_e32 v0, v5, v30, vcc_lo                      // 000000061E78: 02003D05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000061E7C: BF870211
	v_add_co_ci_u32_e64 v11, null, s31, v6, vcc_lo             // 000000061E80: D5207C0B 01AA0C1F
	.long 0xd7006a05                                           // 000000061E88: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 000000061E8C: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000061E94: BF870211
	v_add_co_ci_u32_e64 v6, null, 0, v9, vcc_lo                // 000000061E98: D5207C06 01AA1280
	.long 0xd7006a07                                           // 000000061EA0: D7006A07
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 000000061EA4: 0202270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000061EA8: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v11, vcc_lo               // 000000061EAC: D5207C09 01AA1680
	.long 0xd7006a0a                                           // 000000061EB4: D7006A0A
	v_cndmask_b32_e32 v0, v3, v30, vcc_lo                      // 000000061EB8: 02003D03
	v_add_co_ci_u32_e64 v11, null, s31, v4, vcc_lo             // 000000061EBC: D5207C0B 01AA081F
	v_mad_i64_i32 v[3:4], null, 0x5000, v8, s[8:9]             // 000000061EC4: D6FF7C03 002210FF 00005000
	.long 0xd7006a07                                           // 000000061ED0: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 000000061ED4: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000061EDC: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v9, vcc_lo                // 000000061EE0: D5207C08 01AA1280
	.long 0xd7006a09                                           // 000000061EE8: D7006A09
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 000000061EEC: 0202270A
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo              // 000000061EF0: D5207C0A 01AA1680
	v_or_b32_e32 v11, 8, v15                                   // 000000061EF8: 38161E88
	.long 0xd7006a03                                           // 000000061EFC: D7006A03
	v_cndmask_b32_e32 v0, v3, v30, vcc_lo                      // 000000061F00: 02003D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000061F04: BF870191
	v_add_co_ci_u32_e64 v4, null, s31, v4, vcc_lo              // 000000061F08: D5207C04 01AA081F
	v_min_i32_e32 v11, s36, v11                                // 000000061F10: 22161624
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061F14: BF870093
	.long 0xd7006a0c                                           // 000000061F18: D7006A0C
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000061F1C: 02022703
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 000000061F20: D5207C0D 01AA0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000061F28: BF8700A3
	v_mad_i64_i32 v[3:4], null, 0x5000, v11, s[8:9]            // 000000061F2C: D6FF7C03 002216FF 00005000
	.long 0xd7006a09                                           // 000000061F38: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v9, vcc_lo                   // 000000061F3C: 020212FF 00002000
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 000000061F44: D5207C0A 01AA1480
	.long 0xd7006a0b                                           // 000000061F4C: D7006A0B
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 000000061F50: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000061F58: BF8700B1
	v_add_co_ci_u32_e64 v12, null, 0, v13, vcc_lo              // 000000061F5C: D5207C0C 01AA1A80
	v_or_b32_e32 v13, 10, v15                                  // 000000061F64: 381A1E8A
	.long 0xd7006a03                                           // 000000061F68: D7006A03
	v_cndmask_b32_e32 v0, v3, v30, vcc_lo                      // 000000061F6C: 02003D03
	v_add_co_ci_u32_e64 v4, null, s31, v4, vcc_lo              // 000000061F70: D5207C04 01AA081F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000061F78: BF870193
	v_min_i32_e32 v13, s36, v13                                // 000000061F7C: 221A1A24
	.long 0xd7006a0e                                           // 000000061F80: D7006A0E
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000061F84: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000061F88: BF870191
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 000000061F8C: D5207C10 01AA0880
	v_mad_i64_i32 v[3:4], null, 0x5000, v13, s[8:9]            // 000000061F94: D6FF7C03 00221AFF 00005000
	v_or_b32_e32 v15, 14, v15                                  // 000000061FA0: 381E1E8E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000061FA4: BF870094
	.long 0xd7006a0d                                           // 000000061FA8: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v14, vcc_lo                  // 000000061FAC: 02021CFF 00002000
	v_add_co_ci_u32_e64 v14, null, 0, v16, vcc_lo              // 000000061FB4: D5207C0E 01AA2080
	v_min_i32_e32 v16, s36, v17                                // 000000061FBC: 22202224
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000061FC0: BF8700A4
	v_min_i32_e32 v15, s36, v15                                // 000000061FC4: 221E1E24
	.long 0xd7006a11                                           // 000000061FC8: D7006A11
	v_cndmask_b32_e32 v0, v3, v30, vcc_lo                      // 000000061FCC: 02003D03
	v_add_co_ci_u32_e64 v18, null, s31, v4, vcc_lo             // 000000061FD0: D5207C12 01AA081F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000061FD8: BF870194
	v_mad_i64_i32 v[3:4], null, 0x5000, v16, s[8:9]            // 000000061FDC: D6FF7C03 002220FF 00005000
	.long 0xd7006a11                                           // 000000061FE8: D7006A11
	v_cndmask_b32_e32 v1, v17, v19, vcc_lo                     // 000000061FEC: 02022711
	v_mad_i64_i32 v[15:16], null, 0x5000, v15, s[8:9]          // 000000061FF0: D6FF7C0F 00221EFF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000061FFC: BF870194
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 000000062000: D5207C12 01AA2480
	.long 0xd7006a11                                           // 000000062008: D7006A11
	v_cndmask_b32_e32 v1, 0x2000, v17, vcc_lo                  // 00000006200C: 020222FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000062014: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 000000062018: D5207C12 01AA2480
	.long 0xd7006a03                                           // 000000062020: D7006A03
	v_cndmask_b32_e32 v0, v3, v30, vcc_lo                      // 000000062024: 02003D03
	v_add_co_ci_u32_e64 v4, null, s31, v4, vcc_lo              // 000000062028: D5207C04 01AA081F
	.long 0xd7006a0f                                           // 000000062030: D7006A0F
	v_cndmask_b32_e32 v0, v15, v30, vcc_lo                     // 000000062034: 02003D0F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000062038: BF870211
	v_add_co_ci_u32_e64 v16, null, s31, v16, vcc_lo            // 00000006203C: D5207C10 01AA201F
	.long 0xd7006a03                                           // 000000062044: D7006A03
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 000000062048: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000006204C: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 000000062050: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 000000062058: D7006A0F
	v_cndmask_b32_e32 v1, v15, v19, vcc_lo                     // 00000006205C: 0202270F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000062060: BF870211
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000062064: D5207C10 01AA2080
	.long 0xd7006a03                                           // 00000006206C: D7006A03
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 000000062070: 020206FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000062078: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000006207C: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 000000062084: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v15, vcc_lo                  // 000000062088: 02021EFF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062090: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 000000062094: D5207C10 01AA2080
	s_clause 0x7                                               // 00000006209C: BF850007
	global_load_b32 v42, v[5:6], off                           // 0000000620A0: DC520000 2A7C0005
	global_load_b32 v41, v[7:8], off                           // 0000000620A8: DC520000 297C0007
	global_load_b32 v40, v[9:10], off                          // 0000000620B0: DC520000 287C0009
	global_load_b32 v39, v[11:12], off                         // 0000000620B8: DC520000 277C000B
	global_load_b32 v38, v[13:14], off                         // 0000000620C0: DC520000 267C000D
	global_load_b32 v37, v[17:18], off                         // 0000000620C8: DC520000 257C0011
	global_load_b32 v35, v[3:4], off                           // 0000000620D0: DC520000 237C0003
	global_load_b32 v36, v[15:16], off                         // 0000000620D8: DC520000 247C000F
	v_and_b32_e32 v4, 0xffff0000, v63                          // 0000000620E0: 36087EFF FFFF0000
	v_and_b32_e32 v8, 0xffff0000, v64                          // 0000000620E8: 361080FF FFFF0000
	v_lshlrev_b32_e32 v5, 16, v67                              // 0000000620F0: 300A8690
	v_lshlrev_b32_e32 v9, 16, v65                              // 0000000620F4: 30128290
	v_and_b32_e32 v10, 0xffff0000, v65                         // 0000000620F8: 361482FF FFFF0000
	v_mul_f32_e32 v4, v4, v4                                   // 000000062100: 10080904
	v_and_b32_e32 v6, 0xffff0000, v67                          // 000000062104: 360C86FF FFFF0000
	v_lshlrev_b32_e32 v3, 16, v63                              // 00000006210C: 30067E90
	v_mul_f32_e32 v5, v5, v5                                   // 000000062110: 100A0B05
	v_cmp_lt_u32_e32 vcc_lo, v134, v133                        // 000000062114: 7C930B86
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000062118: BF870123
	v_dual_mul_f32 v6, v6, v6 :: v_dual_mul_f32 v3, v3, v3     // 00000006211C: C8C60D06 06020703
	v_lshlrev_b32_e32 v7, 16, v64                              // 000000062124: 300E8090
	v_dual_add_f32 v3, v3, v4 :: v_dual_add_f32 v4, v5, v6     // 000000062128: C9080903 03040D05
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000062130: BF870122
	v_dual_mul_f32 v5, v7, v7 :: v_dual_mul_f32 v6, v8, v8     // 000000062134: C8C60F07 05061108
	v_lshlrev_b32_e32 v7, 16, v68                              // 00000006213C: 300E8890
	v_dual_add_f32 v5, v5, v6 :: v_dual_and_b32 v8, 0xffff0000, v68// 000000062140: C9240D05 050888FF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000006214C: BF8701B1
	v_dual_mul_f32 v6, v7, v7 :: v_dual_mul_f32 v7, v8, v8     // 000000062150: C8C60F07 06061108
	v_dual_mul_f32 v8, v9, v9 :: v_dual_mul_f32 v9, v10, v10   // 000000062158: C8C61309 0808150A
	v_and_b32_e32 v11, 0xffff0000, v66                         // 000000062160: 361684FF FFFF0000
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v6, v6, v7     // 000000062168: C9080B03 03060F06
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000062170: BF8700A3
	v_add_f32_e32 v8, v8, v9                                   // 000000062174: 06101308
	v_and_b32_e32 v13, 0xffff0000, v69                         // 000000062178: 361A8AFF FFFF0000
	v_dual_mul_f32 v13, v13, v13 :: v_dual_lshlrev_b32 v10, 16, v66// 000000062180: C8E21B0D 0D0A8490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000062188: BF870121
	v_dual_mul_f32 v9, v10, v10 :: v_dual_lshlrev_b32 v12, 16, v69// 00000006218C: C8E2150A 090C8A90
	v_dual_mul_f32 v10, v11, v11 :: v_dual_lshlrev_b32 v11, 16, v70// 000000062194: C8E2170B 0A0A8C90
	v_mul_f32_e32 v12, v12, v12                                // 00000006219C: 1018190C
	v_and_b32_e32 v14, 0xffff0000, v70                         // 0000000621A0: 361C8CFF FFFF0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000621A8: BF870193
	v_dual_add_f32 v9, v9, v10 :: v_dual_mul_f32 v10, v11, v11 // 0000000621AC: C9061509 090A170B
	v_add_f32_e32 v7, v12, v13                                 // 0000000621B4: 060E1B0C
	v_add_f32_e32 v4, v4, v6                                   // 0000000621B8: 06080D04
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000621BC: BF8701C3
	v_add_f32_e32 v5, v8, v9                                   // 0000000621C0: 060A1308
	v_cndmask_b32_e32 v9, v132, v134, vcc_lo                   // 0000000621C4: 02130D84
	v_mul_f32_e32 v11, v14, v14                                // 0000000621C8: 10161D0E
	v_cmp_lt_u32_e32 vcc_lo, v135, v133                        // 0000000621CC: 7C930B87
	v_lshlrev_b32_e32 v6, 2, v9                                // 0000000621D0: 300C1282
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000621D4: BF870093
	v_dual_add_f32 v8, v10, v11 :: v_dual_add_f32 v3, v3, v5   // 0000000621D8: C908170A 08020B03
	v_add_f32_e32 v5, v7, v8                                   // 0000000621E0: 060A1107
	v_cndmask_b32_e32 v7, v132, v135, vcc_lo                   // 0000000621E4: 020F0F84
	v_cmp_lt_u32_e32 vcc_lo, v136, v133                        // 0000000621E8: 7C930B88
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000621EC: BF870003
	v_add_f32_e32 v4, v4, v5                                   // 0000000621F0: 06080B04
	ds_bpermute_b32 v5, v6, v3                                 // 0000000621F4: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 0000000621FC: DACC0000 06000406
	s_waitcnt lgkmcnt(0)                                       // 000000062204: BF89FC07
	v_dual_add_f32 v4, v4, v6 :: v_dual_add_f32 v3, v3, v5     // 000000062208: C9080D04 04020B03
	v_lshlrev_b32_e32 v5, 2, v7                                // 000000062210: 300A0E82
	v_cndmask_b32_e32 v7, v132, v136, vcc_lo                   // 000000062214: 020F1184
	v_cmp_lt_u32_e32 vcc_lo, v137, v133                        // 000000062218: 7C930B89
	ds_bpermute_b32 v6, v5, v3                                 // 00000006221C: DACC0000 06000305
	ds_bpermute_b32 v5, v5, v4                                 // 000000062224: DACC0000 05000405
	s_waitcnt lgkmcnt(0)                                       // 00000006222C: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v5     // 000000062230: C9080D03 03040B04
	v_dual_cndmask_b32 v7, v132, v137 :: v_dual_lshlrev_b32 v6, 2, v7// 000000062238: CA631384 07060E82
	ds_bpermute_b32 v5, v6, v3                                 // 000000062240: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 000000062248: DACC0000 06000406
	v_lshlrev_b32_e32 v7, 2, v7                                // 000000062250: 300E0E82
	s_waitcnt lgkmcnt(0)                                       // 000000062254: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 000000062258: C9080B03 03040D04
	ds_bpermute_b32 v5, v7, v3                                 // 000000062260: DACC0000 05000307
	ds_bpermute_b32 v6, v7, v4                                 // 000000062268: DACC0000 06000407
	v_cmpx_eq_u32_e32 0, v50                                   // 000000062270: 7D946480
	s_cbranch_execz 38                                         // 000000062274: BFA50026 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xf10>
	s_waitcnt lgkmcnt(0)                                       // 000000062278: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000006227C: C9080B03 03040D04
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062284: BF870091
	v_dual_add_f32 v3, 0x358637bd, v3 :: v_dual_add_f32 v4, 0x358637bd, v4// 000000062288: C90806FF 030408FF 358637BD
	v_dual_mul_f32 v5, 0x4b800000, v3 :: v_dual_mul_f32 v6, 0x4b800000, v4// 000000062294: C8C606FF 050608FF 4B800000
	.long 0xd4140001                                           // 0000000622A0: D4140001
	v_cndmask_b32_e32 v1, 0x800000, v4, vcc_lo                 // 0000000622A4: 020208FF 00800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v3                      // 0000000622AC: 7C2806FF 00800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000622B4: BF870092
	v_cndmask_b32_e64 v4, v4, v6, s1                           // 0000000622B8: D5010004 00060D04
	v_rsq_f32_e32 v4, v4                                       // 0000000622C0: 7E085D04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000622C4: BF870095
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_mul_f32 v6, 0x45800000, v4// 0000000622C8: CA460B03 030608FF 45800000
	v_rsq_f32_e32 v3, v3                                       // 0000000622D4: 7E065D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000622D8: BF870291
	v_cndmask_b32_e64 v4, v4, v6, s1                           // 0000000622DC: D5010004 00060D04
	v_mul_f32_e32 v5, 0x45800000, v3                           // 0000000622E4: 100A06FF 45800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000622EC: BF870121
	v_cndmask_b32_e32 v3, v3, v5, vcc_lo                       // 0000000622F0: 02060B03
	v_lshlrev_b32_e32 v5, 2, v2                                // 0000000622F4: 300A0482
	v_mul_f32_e32 v3, v131, v3                                 // 0000000622F8: 10060783
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000622FC: BF870002
	v_add_nc_u32_e32 v5, 0x5c00, v5                            // 000000062300: 4A0A0AFF 00005C00
	ds_store_2addr_b32 v5, v4, v3 offset0:208 offset1:224      // 000000062308: D838E0D0 00030405
	s_or_b32 exec_lo, exec_lo, s55                             // 000000062310: 8C7E377E
	v_and_b32_e32 v43, 31, v44                                 // 000000062314: 3656589F
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 000000062318: 916A047E
	s_cbranch_vccnz 119                                        // 00000006231C: BFA40077 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10fc>
	.long 0xd7600046                                           // 000000062320: D7600046
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                   // 000000062324: 02010182
	.long 0xd7600045                                           // 000000062328: D7600045
	v_cndmask_b32_e32 v0, v130, v129, vcc_lo                   // 00000006232C: 02010382
	.long 0xd7600044                                           // 000000062330: D7600044
	v_cndmask_b32_e32 v0, v130, v130, vcc_lo                   // 000000062334: 02010582
	.long 0xd7600043                                           // 000000062338: D7600043
	v_cndmask_b32_e32 v0, v130, v131, vcc_lo                   // 00000006233C: 02010782
	.long 0xd7600042                                           // 000000062340: D7600042
	v_cndmask_b32_e32 v0, v130, v132, vcc_lo                   // 000000062344: 02010982
	.long 0xd7600041                                           // 000000062348: D7600041
	v_cndmask_b32_e32 v0, v130, v133, vcc_lo                   // 00000006234C: 02010B82
	.long 0xd7600040                                           // 000000062350: D7600040
	v_cndmask_b32_e32 v0, v130, v134, vcc_lo                   // 000000062354: 02010D82
	.long 0xd760003f                                           // 000000062358: D760003F
	v_cndmask_b32_e32 v0, v130, v135, vcc_lo                   // 00000006235C: 02010F82
	.long 0xd760003e                                           // 000000062360: D760003E
	v_cndmask_b32_e32 v0, v130, v136, vcc_lo                   // 000000062364: 02011182
	.long 0xd760003d                                           // 000000062368: D760003D
	v_cndmask_b32_e32 v0, v130, v137, vcc_lo                   // 00000006236C: 02011382
	.long 0xd760003c                                           // 000000062370: D760003C
	v_cndmask_b32_e32 v0, v130, v138, vcc_lo                   // 000000062374: 02011582
	.long 0xd760003b                                           // 000000062378: D760003B
	v_cndmask_b32_e32 v0, v130, v139, vcc_lo                   // 00000006237C: 02011782
	.long 0xd760003a                                           // 000000062380: D760003A
	v_cndmask_b32_e32 v0, v130, v140, vcc_lo                   // 000000062384: 02011982
	.long 0xd7600039                                           // 000000062388: D7600039
	v_cndmask_b32_e32 v0, v130, v141, vcc_lo                   // 00000006238C: 02011B82
	.long 0xd7600038                                           // 000000062390: D7600038
	v_cndmask_b32_e32 v0, v130, v142, vcc_lo                   // 000000062394: 02011D82
	.long 0xd7600037                                           // 000000062398: D7600037
	v_cndmask_b32_e32 v0, v130, v143, vcc_lo                   // 00000006239C: 02011F82
	s_mov_b32 s1, exec_lo                                      // 0000000623A0: BE81007E
	v_cmpx_gt_u32_e32 16, v43                                  // 0000000623A4: 7D985690
	s_cbranch_execz 83                                         // 0000000623A8: BFA50053 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x10f8>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 0000000623AC: 7C945680
	s_add_f32 s70, s70, 0                                      // 0000000623B0: A0468046
	v_lshlrev_b32_e32 v4, 2, v43                               // 0000000623B4: 30085682
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000623B8: BF8704BA
	s_add_f32 s69, s70, s69                                    // 0000000623BC: A0454546
	v_cndmask_b32_e64 v3, 0, s70, vcc_lo                       // 0000000623C0: D5010003 01A88C80
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 0000000623C8: 7C945681
	s_add_f32 s68, s69, s68                                    // 0000000623CC: A0444445
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000623D0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s69, vcc_lo                      // 0000000623D4: D5010003 01A88B03
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 0000000623DC: 7C945682
	s_add_f32 s67, s68, s67                                    // 0000000623E0: A0434344
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000623E4: BF8704A2
	v_cndmask_b32_e64 v3, v3, s68, vcc_lo                      // 0000000623E8: D5010003 01A88903
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 0000000623F0: 7C945683
	s_add_f32 s66, s67, s66                                    // 0000000623F4: A0424243
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000623F8: BF8704A2
	v_cndmask_b32_e64 v3, v3, s67, vcc_lo                      // 0000000623FC: D5010003 01A88703
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 000000062404: 7C945684
	s_add_f32 s65, s66, s65                                    // 000000062408: A0414142
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000006240C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s66, vcc_lo                      // 000000062410: D5010003 01A88503
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 000000062418: 7C945685
	s_add_f32 s64, s65, s64                                    // 00000006241C: A0404041
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000062420: BF8704A2
	v_cndmask_b32_e64 v3, v3, s65, vcc_lo                      // 000000062424: D5010003 01A88303
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 00000006242C: 7C945686
	s_add_f32 s63, s64, s63                                    // 000000062430: A03F3F40
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000062434: BF8704A2
	v_cndmask_b32_e64 v3, v3, s64, vcc_lo                      // 000000062438: D5010003 01A88103
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 000000062440: 7C945687
	s_add_f32 s62, s63, s62                                    // 000000062444: A03E3E3F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000062448: BF8704A2
	v_cndmask_b32_e64 v3, v3, s63, vcc_lo                      // 00000006244C: D5010003 01A87F03
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 000000062454: 7C945688
	s_add_f32 s61, s62, s61                                    // 000000062458: A03D3D3E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000006245C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s62, vcc_lo                      // 000000062460: D5010003 01A87D03
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 000000062468: 7C945689
	s_add_f32 s60, s61, s60                                    // 00000006246C: A03C3C3D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000062470: BF8704A2
	v_cndmask_b32_e64 v3, v3, s61, vcc_lo                      // 000000062474: D5010003 01A87B03
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000006247C: 7C94568A
	s_add_f32 s59, s60, s59                                    // 000000062480: A03B3B3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000062484: BF8704A2
	v_cndmask_b32_e64 v3, v3, s60, vcc_lo                      // 000000062488: D5010003 01A87903
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 000000062490: 7C94568B
	s_add_f32 s58, s59, s58                                    // 000000062494: A03A3A3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000062498: BF8704A2
	v_cndmask_b32_e64 v3, v3, s59, vcc_lo                      // 00000006249C: D5010003 01A87703
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 0000000624A4: 7C94568C
	s_add_f32 s57, s58, s57                                    // 0000000624A8: A039393A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000624AC: BF8704A2
	v_cndmask_b32_e64 v3, v3, s58, vcc_lo                      // 0000000624B0: D5010003 01A87503
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 0000000624B8: 7C94568D
	s_add_f32 s56, s57, s56                                    // 0000000624BC: A0383839
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 0000000624C0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s57, vcc_lo                      // 0000000624C4: D5010003 01A87303
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 0000000624CC: 7C94568E
	s_add_f32 s55, s56, s55                                    // 0000000624D0: A0373738
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000624D4: BF870002
	v_cndmask_b32_e64 v3, v3, s56, vcc_lo                      // 0000000624D8: D5010003 01A87103
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 0000000624E0: 7C94568F
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 0000000624E4: BF870482
	v_cndmask_b32_e64 v3, v3, s55, vcc_lo                      // 0000000624E8: D5010003 01A86F03
	ds_store_b32 v4, v3 offset:24128                           // 0000000624F0: D8345E40 00000304
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000624F8: 8C7E017E
	s_add_i32 s53, s53, 1                                      // 0000000624FC: 81358135
	s_waitcnt lgkmcnt(0)                                       // 000000062500: BF89FC07
	s_barrier                                                  // 000000062504: BFBD0000
	s_cmp_ge_i32 s53, s15                                      // 000000062508: BF030F35
	s_cbranch_scc1 67                                          // 00000006250C: BFA20043 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x121c>
	s_lshl_b32 s1, s53, 4                                      // 000000062510: 84018435
	v_lshlrev_b32_e32 v4, 4, v44                               // 000000062514: 30085884
	s_waitcnt lgkmcnt(0)                                       // 000000062518: BF89FC07
	v_add_nc_u32_e32 v6, s1, v2                                // 00000006251C: 4A0C0401
	s_mov_b32 s55, exec_lo                                     // 000000062520: BEB7007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062524: BF870112
	v_and_b32_e32 v4, 0xf0, v4                                 // 000000062528: 360808FF 000000F0
	v_min_i32_e32 v2, s36, v6                                  // 000000062530: 22040C24
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062534: BF870091
	v_mad_i64_i32 v[2:3], null, 0x5000, v2, s[6:7]             // 000000062538: D6FF7C02 001A04FF 00005000
	.long 0xd7006a02                                           // 000000062544: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 000000062548: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006254C: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000062550: D5207C03 01AA0680
	.long 0xd7006a04                                           // 000000062558: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000006255C: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062564: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000062568: D5207C05 01AA0680
	s_clause 0x1                                               // 000000062570: BF850001
	global_load_b128 v[63:66], v[2:3], off                     // 000000062574: DC5E0000 3F7C0002
	global_load_b128 v[67:70], v[4:5], off                     // 00000006257C: DC5E0000 437C0004
	.long 0xd4c3007e                                           // 000000062584: D4C3007E
	v_cndmask_b32_e32 v1, s35, v6, vcc_lo                      // 000000062588: 02020C23
	s_cbranch_execz 11                                         // 00000006258C: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11bc>
	s_waitcnt vmcnt(1)                                         // 000000062590: BF8907F7
	v_mov_b32_e32 v63, 0                                       // 000000062594: 7E7E0280
	s_waitcnt vmcnt(0)                                         // 000000062598: BF8903F7
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006259C: BF870001
	v_mov_b32_e32 v70, v63                                     // 0000000625A0: 7E8C033F
	v_mov_b32_e32 v69, v63                                     // 0000000625A4: 7E8A033F
	v_mov_b32_e32 v68, v63                                     // 0000000625A8: 7E88033F
	v_mov_b32_e32 v67, v63                                     // 0000000625AC: 7E86033F
	v_mov_b32_e32 v64, v63                                     // 0000000625B0: 7E80033F
	v_mov_b32_e32 v65, v63                                     // 0000000625B4: 7E82033F
	v_mov_b32_e32 v66, v63                                     // 0000000625B8: 7E84033F
	s_or_b32 exec_lo, exec_lo, s55                             // 0000000625BC: 8C7E377E
	s_and_saveexec_b32 s55, s0                                 // 0000000625C0: BEB72000
	s_cbranch_execz 19                                         // 0000000625C4: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1214>
	v_dual_mov_b32 v129, 0 :: v_dual_add_nc_u32 v2, s1, v44    // 0000000625C8: CA200080 81025801
	v_mov_b32_e32 v130, 0                                      // 0000000625D0: 7F040280
	s_mov_b32 s0, exec_lo                                      // 0000000625D4: BE80007E
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000625D8: BF870002
	.long 0xd4c4007e                                           // 0000000625DC: D4C4007E
	v_cndmask_b32_e32 v1, s35, v2, vcc_lo                      // 0000000625E0: 02020423
	s_cbranch_execz 10                                         // 0000000625E4: BFA5000A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1210>
	v_mad_i64_i32 v[3:4], null, 0xc0, v2, s[10:11]             // 0000000625E8: D6FF7C03 002A04FF 000000C0
	v_mad_i64_i32 v[5:6], null, 0xc0, v2, s[28:29]             // 0000000625F4: D6FF7C05 007204FF 000000C0
	global_load_b32 v130, v[3:4], off                          // 000000062600: DC520000 827C0003
	global_load_b32 v129, v[5:6], off                          // 000000062608: DC520000 817C0005
	s_or_b32 exec_lo, exec_lo, s0                              // 000000062610: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062614: BF870009
	s_or_b32 exec_lo, exec_lo, s55                             // 000000062618: 8C7E377E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006261C: BF870009
	s_and_b32 vcc_lo, exec_lo, s37                             // 000000062620: 8B6A257E
	s_mov_b32 s0, -1                                           // 000000062624: BE8000C1
	s_cbranch_vccz 81                                          // 000000062628: BFA30051 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1370>
	v_and_b32_e32 v2, -16, v44                                 // 00000006262C: 360458D0
	s_mov_b32 s0, exec_lo                                      // 000000062630: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062634: BF870001
	v_cmpx_eq_u32_e32 64, v2                                   // 000000062638: 7D9404C0
	s_cbranch_execz 74                                         // 00000006263C: BFA5004A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1368>
	v_lshlrev_b32_e32 v4, 2, v44                               // 000000062640: 30085882
	s_waitcnt lgkmcnt(1)                                       // 000000062644: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062648: BF870001
	v_add_nc_u32_e32 v5, 0x5c00, v4                            // 00000006264C: 4A0A08FF 00005C00
	ds_load_2addr_b32 v[2:3], v5 offset0:64 offset1:80         // 000000062654: D8DC5040 02000005
	s_waitcnt lgkmcnt(1)                                       // 00000006265C: BF89FC17
	ds_load_b32 v6, v1 offset:24188                            // 000000062660: D8D85E7C 06000001
	s_waitcnt lgkmcnt(1)                                       // 000000062668: BF89FC17
	v_mul_f32_e32 v7, 0x3fb8aa3b, v3                           // 00000006266C: 100E06FF 3FB8AA3B
	ds_load_b32 v8, v4 offset:24128                            // 000000062674: D8D85E40 08000004
	s_waitcnt lgkmcnt(1)                                       // 00000006267C: BF89FC17
	v_sub_f32_e32 v6, v6, v3                                   // 000000062680: 080C0706
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000062684: 7C3606FF C2CE8ED0
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v7                          // 00000006268C: D6130009 841E06FF 3FB8AA3B
	v_rndne_f32_e32 v10, v7                                    // 000000062698: 7E144707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000006269C: BF870114
	v_mul_f32_e32 v11, 0x3fb8aa3b, v6                          // 0000000626A0: 10160CFF 3FB8AA3B
	v_sub_f32_e32 v7, v7, v10                                  // 0000000626A8: 080E1507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000626AC: BF8701C2
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v11                        // 0000000626B0: D613000C 842E0CFF 3FB8AA3B
	v_fmac_f32_e32 v9, 0x32a5705f, v3                          // 0000000626BC: 561206FF 32A5705F
	v_cvt_i32_f32_e32 v10, v10                                 // 0000000626C4: 7E14110A
	v_rndne_f32_e32 v13, v11                                   // 0000000626C8: 7E1A470B
	v_dual_fmac_f32 v12, 0x32a5705f, v6 :: v_dual_add_f32 v7, v7, v9// 0000000626CC: C8080CFF 0C061307 32A5705F
	s_waitcnt lgkmcnt(0)                                       // 0000000626D8: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000626DC: BF870112
	v_dual_sub_f32 v9, v11, v13 :: v_dual_mul_f32 v2, v8, v2   // 0000000626E0: C9461B0B 09020508
	v_exp_f32_e32 v7, v7                                       // 0000000626E8: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000626EC: BF870125
	.long 0xd71c0007                                           // 0000000626F0: D71C0007
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 0000000626F4: 02021507
	v_cvt_i32_f32_e32 v10, v13                                 // 0000000626F8: 7E14110D
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 0000000626FC: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000062700: 7C3C06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000062708: BF8701B2
	v_cndmask_b32_e32 v3, 0x7f800000, v7, vcc_lo               // 00000006270C: 02060EFF 7F800000
	v_add_f32_e32 v9, v9, v12                                  // 000000062714: 06121909
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 000000062718: 7C360CFF C2CE8ED0
	v_mul_f32_e32 v2, v3, v2                                   // 000000062720: 10040503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062724: BF870093
	v_exp_f32_e32 v9, v9                                       // 000000062728: 7E124B09
	v_mul_f32_e32 v2, 0x41800000, v2                           // 00000006272C: 100404FF 41800000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062734: BF870095
	.long 0xd71c0009                                           // 000000062738: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000006273C: 02021509
	v_cndmask_b32_e32 v7, 0, v9, vcc_lo                        // 000000062740: 020E1280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 000000062744: 7C3C0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000006274C: BF870002
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 000000062750: 020C0EFF 7F800000
	ds_store_b32 v4, v3 offset:24064                           // 000000062758: D8345E00 00000304
	ds_store_2addr_b32 v5, v6, v2 offset0:96 offset1:112       // 000000062760: D8387060 00020605
	s_or_b32 exec_lo, exec_lo, s0                              // 000000062768: 8C7E007E
	s_mov_b32 s0, 0                                            // 00000006276C: BE800080
	v_lshrrev_b32_e32 v149, 4, v43                             // 000000062770: 332A5684
	v_mul_u32_u24_e32 v52, 0x110, v50                          // 000000062774: 166864FF 00000110
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000006277C: 916A007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000062780: BF870002
	v_lshlrev_b32_e32 v51, 2, v149                             // 000000062784: 30672A82
	s_cbranch_vccnz 872                                        // 000000062788: BFA40368 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x212c>
	v_mad_u32_u24 v2, 0x110, v50, s49                          // 00000006278C: D60B0002 00C664FF 00000110
	s_and_b32 s0, s4, exec_lo                                  // 000000062798: 8B007E04
	s_cselect_b32 s0, 0, 0x1100                                // 00000006279C: 9800FF80 00001100
	v_mad_u32_u24 v3, 0x110, v50, s50                          // 0000000627A4: D60B0003 00CA64FF 00000110
	ds_load_b128 v[10:13], v52 offset:6144                     // 0000000627B0: DBFC1800 0A000034
	ds_load_b128 v[14:17], v52 offset:6160                     // 0000000627B8: DBFC1810 0E000034
	v_add_nc_u32_e32 v4, s0, v2                                // 0000000627C0: 4A080400
	v_mov_b32_e32 v8, v1                                       // 0000000627C4: 7E100301
	s_waitcnt lgkmcnt(3)                                       // 0000000627C8: BF89FC37
	v_mov_b32_e32 v5, v1                                       // 0000000627CC: 7E0A0301
	v_cndmask_b32_e64 v45, v3, v2, s4                          // 0000000627D0: D501002D 00120503
	v_mov_b32_e32 v3, v1                                       // 0000000627D8: 7E060301
	ds_load_b128 v[18:21], v4                                  // 0000000627DC: DBFC0000 12000004
	ds_load_b128 v[22:25], v4 offset:16                        // 0000000627E4: DBFC0010 16000004
	ds_load_b128 v[26:29], v52 offset:6176                     // 0000000627EC: DBFC1820 1A000034
	ds_load_b128 v[30:33], v52 offset:6192                     // 0000000627F4: DBFC1830 1E000034
	ds_load_b128 v[53:56], v45 offset:32                       // 0000000627FC: DBFC0020 3500002D
	ds_load_b128 v[57:60], v45 offset:48                       // 000000062804: DBFC0030 3900002D
	ds_load_b128 v[150:153], v45 offset:64                     // 00000006280C: DBFC0040 9600002D
	ds_load_b128 v[154:157], v45 offset:80                     // 000000062814: DBFC0050 9A00002D
	ds_load_b128 v[162:165], v52 offset:6224                   // 00000006281C: DBFC1850 A2000034
	ds_load_b128 v[158:161], v52 offset:6208                   // 000000062824: DBFC1840 9E000034
	v_mov_b32_e32 v2, v1                                       // 00000006282C: 7E040301
	v_mov_b32_e32 v4, v1                                       // 000000062830: 7E080301
	s_waitcnt lgkmcnt(12)                                      // 000000062834: BF89FCC7
	v_mov_b32_e32 v6, v1                                       // 000000062838: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000006283C: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 000000062840: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000062844: BF870212
	v_mov_b32_e32 v8, v7                                       // 000000062848: 7E100307
	v_mov_b32_e32 v7, v6                                       // 00000006284C: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 000000062850: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 000000062854: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 000000062858: 7E080303
	v_mov_b32_e32 v3, v2                                       // 00000006285C: 7E060302
	v_mov_b32_e32 v2, v1                                       // 000000062860: 7E040301
	ds_load_b128 v[170:173], v52 offset:6256                   // 000000062864: DBFC1870 AA000034
	ds_load_b128 v[166:169], v52 offset:6240                   // 00000006286C: DBFC1860 A6000034
	ds_load_b128 v[178:181], v45 offset:112                    // 000000062874: DBFC0070 B200002D
	ds_load_b128 v[174:177], v45 offset:96                     // 00000006287C: DBFC0060 AE00002D
	v_or_b32_e32 v49, 6, v149                                  // 000000062884: 38632A86
	v_or_b32_e32 v48, 8, v149                                  // 000000062888: 38612A88
	v_or_b32_e32 v47, 10, v149                                 // 00000006288C: 385F2A8A
	s_waitcnt lgkmcnt(12)                                      // 000000062890: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 000000062894: CC414002 1C0A1512
	ds_load_b128 v[14:17], v52 offset:6288                     // 00000006289C: DBFC1890 0E000034
	ds_load_b128 v[10:13], v52 offset:6272                     // 0000000628A4: DBFC1880 0A000034
	ds_load_b128 v[22:25], v45 offset:144                      // 0000000628AC: DBFC0090 1600002D
	ds_load_b128 v[18:21], v45 offset:128                      // 0000000628B4: DBFC0080 1200002D
	s_and_not1_b32 vcc_lo, exec_lo, s34                        // 0000000628BC: 916A227E
	s_mov_b32 s0, -1                                           // 0000000628C0: BE8000C1
	s_waitcnt lgkmcnt(12)                                      // 0000000628C4: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[53:60], v[26:33], v[2:9]// 0000000628C8: CC414002 1C0A3535
	ds_load_b128 v[30:33], v52 offset:6320                     // 0000000628D0: DBFC18B0 1E000034
	ds_load_b128 v[26:29], v52 offset:6304                     // 0000000628D8: DBFC18A0 1A000034
	ds_load_b128 v[59:62], v45 offset:176                      // 0000000628E0: DBFC00B0 3B00002D
	ds_load_b128 v[55:58], v45 offset:160                      // 0000000628E8: DBFC00A0 3700002D
	v_lshlrev_b32_e32 v54, 2, v50                              // 0000000628F0: 306C6482
	v_or_b32_e32 v53, 4, v149                                  // 0000000628F4: 386B2A84
	s_waitcnt lgkmcnt(12)                                      // 0000000628F8: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[150:157], v[158:165], v[2:9]// 0000000628FC: CC414002 1C0B3D96
	ds_load_b128 v[154:157], v52 offset:6352                   // 000000062904: DBFC18D0 9A000034
	ds_load_b128 v[150:153], v52 offset:6336                   // 00000006290C: DBFC18C0 96000034
	v_add_nc_u32_e32 v46, 64, v54                              // 000000062914: 4A5C6CC0
	ds_load_b128 v[162:165], v52 offset:6384                   // 000000062918: DBFC18F0 A2000034
	ds_load_b128 v[158:161], v52 offset:6368                   // 000000062920: DBFC18E0 9E000034
	s_waitcnt lgkmcnt(12)                                      // 000000062928: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[174:181], v[166:173], v[2:9]// 00000006292C: CC414002 1C0B4DAE
	ds_load_b128 v[170:173], v45 offset:208                    // 000000062934: DBFC00D0 AA00002D
	ds_load_b128 v[166:169], v45 offset:192                    // 00000006293C: DBFC00C0 A600002D
	s_waitcnt lgkmcnt(10)                                      // 000000062944: BF89FCA7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 000000062948: CC414002 1C0A1512
	v_add_nc_u32_e32 v10, 0x5c00, v51                          // 000000062950: 4A1466FF 00005C00
	v_add_nc_u32_e32 v11, s38, v51                             // 000000062958: 4A166626
	ds_load_b128 v[178:181], v45 offset:240                    // 00000006295C: DBFC00F0 B200002D
	ds_load_b128 v[174:177], v45 offset:224                    // 000000062964: DBFC00E0 AE00002D
	ds_load_2addr_stride64_b32 v[12:13], v46 offset0:94 offset1:95// 00000006296C: D8E05F5E 0C00002E
	v_or_b32_e32 v46, 12, v149                                 // 000000062974: 385D2A8C
	s_waitcnt lgkmcnt(9)                                       // 000000062978: BF89FC97
	v_wmma_f32_16x16x16_bf16 v[2:9], v[55:62], v[26:33], v[2:9]// 00000006297C: CC414002 1C0A3537
	ds_load_2addr_b32 v[28:29], v10 offset0:144 offset1:146    // 000000062984: D8DC9290 1C00000A
	ds_load_2addr_b32 v[24:25], v10 offset0:148 offset1:150    // 00000006298C: D8DC9694 1800000A
	ds_load_2addr_b32 v[20:21], v10 offset0:152 offset1:154    // 000000062994: D8DC9A98 1400000A
	ds_load_2addr_b32 v[16:17], v10 offset0:156 offset1:158    // 00000006299C: D8DC9E9C 1000000A
	ds_load_2addr_b32 v[26:27], v11 offset1:2                  // 0000000629A4: D8DC0200 1A00000B
	ds_load_2addr_b32 v[22:23], v11 offset0:4 offset1:6        // 0000000629AC: D8DC0604 1600000B
	ds_load_2addr_b32 v[18:19], v11 offset0:8 offset1:10       // 0000000629B4: D8DC0A08 1200000B
	ds_load_2addr_b32 v[14:15], v11 offset0:12 offset1:14      // 0000000629BC: D8DC0E0C 0E00000B
	v_or_b32_e32 v55, 2, v149                                  // 0000000629C4: 386F2A82
	v_or_b32_e32 v45, 14, v149                                 // 0000000629C8: 385B2A8E
	s_waitcnt lgkmcnt(11)                                      // 0000000629CC: BF89FCB7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[166:173], v[150:157], v[2:9]// 0000000629D0: CC414002 1C0B2DA6
	s_waitcnt lgkmcnt(9)                                       // 0000000629D8: BF89FC97
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000629DC: BF870001
	v_wmma_f32_16x16x16_bf16 v[2:9], v[174:181], v[158:165], v[2:9]// 0000000629E0: CC414002 1C0B3DAE
	s_cbranch_vccnz 353                                        // 0000000629E8: BFA40161 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b70>
	.long 0x7e143880                                           // 0000000629EC: 7E143880
	s_mov_b32 s0, exec_lo                                      // 0000000629F0: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000629F4: BF870001
	.long 0x7f14390a                                           // 0000000629F8: 7F14390A
	.long 0xd4cb007e                                           // 0000000629FC: D4CB007E
	v_cndmask_b32_e32 v1, v50, v149, vcc_lo                    // 000000062A00: 02032B32
	s_cbranch_execz 34                                         // 000000062A04: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1690>
	s_waitcnt lgkmcnt(7)                                       // 000000062A08: BF89FC77
	v_sub_f32_e32 v11, v28, v12                                // 000000062A0C: 0816191C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062A10: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v11                         // 000000062A14: 103C16FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v11, -v30                       // 000000062A1C: D613001F 847A16FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 000000062A28: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062A2C: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v11 :: v_dual_sub_f32 v30, v30, v32// 000000062A30: C80A16FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 000000062A3C: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 000000062A40: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000062A44: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000062A4C: BF870293
	v_exp_f32_e32 v30, v30                                     // 000000062A50: 7E3C4B1E
	.long 0xd71c001e                                           // 000000062A54: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 000000062A58: 02023F1E
	s_waitcnt lgkmcnt(3)                                       // 000000062A5C: BF89FC37
	v_mul_f32_e32 v31, v2, v26                                 // 000000062A60: 103E3502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000062A64: BF870122
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 000000062A68: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000062A6C: 7C3C16FF 42B17218
	v_dual_cndmask_b32 v11, 0x7f800000, v30 :: v_dual_mul_f32 v30, v13, v31// 000000062A74: CA463CFF 0B1E3F0D 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062A80: BF870091
	v_mul_f32_e32 v11, v11, v30                                // 000000062A84: 10163D0B
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 000000062A88: CC22000A 0200610B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000062A90: 8C7E007E
	v_mul_u32_u24_e32 v11, 48, v149                            // 000000062A94: 16172AB0
	s_mov_b32 s0, exec_lo                                      // 000000062A98: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062A9C: BF870001
	v_lshl_add_u32 v11, v50, 1, v11                            // 000000062AA0: D646000B 042D0332
	ds_store_b16_d16_hi v11, v10 offset:23296                  // 000000062AA8: DA845B00 00000A0B
	.long 0xd4cb007e                                           // 000000062AB0: D4CB007E
	v_cndmask_b32_e32 v1, v50, v55, vcc_lo                     // 000000062AB4: 02026F32
	s_cbranch_execz 34                                         // 000000062AB8: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1744>
	s_waitcnt lgkmcnt(8)                                       // 000000062ABC: BF89FC87
	v_sub_f32_e32 v10, v29, v12                                // 000000062AC0: 0814191D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062AC4: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v10                         // 000000062AC8: 103C14FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v30                       // 000000062AD0: D613001F 847A14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 000000062ADC: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062AE0: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v10 :: v_dual_sub_f32 v30, v30, v32// 000000062AE4: C80A14FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 000000062AF0: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 000000062AF4: 7E3E1120
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000062AF8: BF870292
	v_exp_f32_e32 v30, v30                                     // 000000062AFC: 7E3C4B1E
	.long 0xd71c001e                                           // 000000062B00: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 000000062B04: 02023F1E
	s_waitcnt lgkmcnt(4)                                       // 000000062B08: BF89FC47
	v_mul_f32_e32 v31, v3, v27                                 // 000000062B0C: 103E3703
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000062B10: 7C3614FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000062B18: BF870123
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 000000062B1C: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000062B20: 7C3C14FF 42B17218
	v_cndmask_b32_e32 v10, 0x7f800000, v30, vcc_lo             // 000000062B28: 02143CFF 7F800000
	v_mul_f32_e32 v30, v13, v31                                // 000000062B30: 103C3F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062B34: BF870091
	v_mul_f32_e32 v10, v10, v30                                // 000000062B38: 10143D0A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 000000062B3C: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s0                              // 000000062B44: 8C7E007E
	.long 0x7f143880                                           // 000000062B48: 7F143880
	v_or_b32_e32 v30, 0x5b00, v11                              // 000000062B4C: 383C16FF 00005B00
	s_mov_b32 s0, exec_lo                                      // 000000062B54: BE80007E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000062B58: BF870002
	.long 0x7e16398a                                           // 000000062B5C: 7E16398A
	ds_store_b16 v30, v10 offset:96                            // 000000062B60: D87C0060 00000A1E
	.long 0xd4cb007e                                           // 000000062B68: D4CB007E
	v_cndmask_b32_e32 v1, v50, v53, vcc_lo                     // 000000062B6C: 02026B32
	s_cbranch_execz 35                                         // 000000062B70: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1800>
	s_waitcnt lgkmcnt(8)                                       // 000000062B74: BF89FC87
	v_sub_f32_e32 v11, v24, v12                                // 000000062B78: 08161918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000062B7C: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000062B80: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000062B88: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000062B90: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 000000062B9C: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062BA0: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000062BA4: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000062BB0: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000062BB4: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000062BB8: BF870292
	v_exp_f32_e32 v31, v31                                     // 000000062BBC: 7E3E4B1F
	.long 0xd71c001f                                           // 000000062BC0: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000062BC4: 0202411F
	s_waitcnt lgkmcnt(4)                                       // 000000062BC8: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000062BCC: BF870121
	v_dual_mul_f32 v32, v4, v22 :: v_dual_cndmask_b32 v31, 0, v31// 000000062BD0: C8D22D04 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000062BD8: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000062BE0: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062BE8: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 000000062BEC: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 000000062BF0: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062BF4: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 000000062BF8: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000062C00: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062C04: BF870009
	s_mov_b32 s0, exec_lo                                      // 000000062C08: BE80007E
	ds_store_b16 v30, v11 offset:192                           // 000000062C0C: D87C00C0 00000B1E
	.long 0xd4cb007e                                           // 000000062C14: D4CB007E
	v_cndmask_b32_e32 v1, v50, v49, vcc_lo                     // 000000062C18: 02026332
	s_cbranch_execz 35                                         // 000000062C1C: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x18ac>
	s_waitcnt lgkmcnt(9)                                       // 000000062C20: BF89FC97
	v_sub_f32_e32 v10, v25, v12                                // 000000062C24: 08141919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062C28: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000062C2C: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000062C34: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000062C40: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062C44: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000062C48: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000062C50: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000062C54: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000062C58: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 000000062C5C: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000062C60: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000062C68: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000062C6C: BF870135
	.long 0xd71c000b                                           // 000000062C70: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000062C74: 02023F0B
	s_waitcnt lgkmcnt(5)                                       // 000000062C78: BF89FC57
	v_mul_f32_e32 v31, v5, v23                                 // 000000062C7C: 103E2F05
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000062C80: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000062C84: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000062C8C: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000062C90: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000062C98: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062C9C: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000062CA0: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 000000062CA4: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s0                              // 000000062CAC: 8C7E007E
	.long 0x7e143880                                           // 000000062CB0: 7E143880
	s_mov_b32 s0, exec_lo                                      // 000000062CB4: BE80007E
	ds_store_b16_d16_hi v30, v10 offset:288                    // 000000062CB8: DA840120 00000A1E
	.long 0x7e16390a                                           // 000000062CC0: 7E16390A
	.long 0xd4cb007e                                           // 000000062CC4: D4CB007E
	v_cndmask_b32_e32 v1, v50, v48, vcc_lo                     // 000000062CC8: 02026132
	s_cbranch_execz 34                                         // 000000062CCC: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1958>
	s_waitcnt lgkmcnt(9)                                       // 000000062CD0: BF89FC97
	v_sub_f32_e32 v11, v20, v12                                // 000000062CD4: 08161914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062CD8: BF870091
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000062CDC: 103E16FF 3FB8AA3B
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000062CE4: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 000000062CF0: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062CF4: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000062CF8: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000062D04: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000062D08: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000062D0C: BF870292
	v_exp_f32_e32 v31, v31                                     // 000000062D10: 7E3E4B1F
	.long 0xd71c001f                                           // 000000062D14: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000062D18: 0202411F
	s_waitcnt lgkmcnt(5)                                       // 000000062D1C: BF89FC57
	v_mul_f32_e32 v32, v6, v18                                 // 000000062D20: 10402506
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000062D24: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000062D2C: BF870123
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 000000062D30: 023E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000062D34: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000062D3C: 02163EFF 7F800000
	v_mul_f32_e32 v31, v13, v32                                // 000000062D44: 103E410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062D48: BF870091
	v_mul_f32_e32 v11, v11, v31                                // 000000062D4C: 10163F0B
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 000000062D50: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000062D58: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062D5C: BF870009
	s_mov_b32 s0, exec_lo                                      // 000000062D60: BE80007E
	ds_store_b16 v30, v11 offset:384                           // 000000062D64: D87C0180 00000B1E
	.long 0xd4cb007e                                           // 000000062D6C: D4CB007E
	v_cndmask_b32_e32 v1, v50, v47, vcc_lo                     // 000000062D70: 02025F32
	s_cbranch_execz 35                                         // 000000062D74: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1a04>
	s_waitcnt lgkmcnt(10)                                      // 000000062D78: BF89FCA7
	v_sub_f32_e32 v10, v21, v12                                // 000000062D7C: 08141915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062D80: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000062D84: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000062D8C: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000062D98: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062D9C: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000062DA0: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000062DA8: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000062DAC: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000062DB0: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 000000062DB4: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000062DB8: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000062DC0: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000062DC4: BF870135
	.long 0xd71c000b                                           // 000000062DC8: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000062DCC: 02023F0B
	s_waitcnt lgkmcnt(6)                                       // 000000062DD0: BF89FC67
	v_mul_f32_e32 v31, v7, v19                                 // 000000062DD4: 103E2707
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000062DD8: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000062DDC: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000062DE4: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000062DE8: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000062DF0: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062DF4: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000062DF8: 1014170A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 000000062DFC: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s0                              // 000000062E04: 8C7E007E
	.long 0x7f143880                                           // 000000062E08: 7F143880
	s_mov_b32 s0, exec_lo                                      // 000000062E0C: BE80007E
	ds_store_b16 v30, v10 offset:480                           // 000000062E10: D87C01E0 00000A1E
	.long 0x7e16398a                                           // 000000062E18: 7E16398A
	.long 0xd4cb007e                                           // 000000062E1C: D4CB007E
	v_cndmask_b32_e32 v1, v50, v46, vcc_lo                     // 000000062E20: 02025D32
	s_cbranch_execz 35                                         // 000000062E24: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1ab4>
	s_waitcnt lgkmcnt(10)                                      // 000000062E28: BF89FCA7
	v_sub_f32_e32 v11, v16, v12                                // 000000062E2C: 08161910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000062E30: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 000000062E34: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 000000062E3C: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 000000062E44: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 000000062E50: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062E54: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 000000062E58: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 000000062E64: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 000000062E68: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000062E6C: BF870292
	v_exp_f32_e32 v31, v31                                     // 000000062E70: 7E3E4B1F
	.long 0xd71c001f                                           // 000000062E74: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 000000062E78: 0202411F
	s_waitcnt lgkmcnt(6)                                       // 000000062E7C: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000062E80: BF870121
	v_dual_mul_f32 v32, v8, v14 :: v_dual_cndmask_b32 v31, 0, v31// 000000062E84: C8D21D08 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 000000062E8C: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 000000062E94: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062E9C: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 000000062EA0: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 000000062EA4: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 000000062EA8: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 000000062EAC: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s0                              // 000000062EB4: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000062EB8: BF870009
	s_mov_b32 s0, exec_lo                                      // 000000062EBC: BE80007E
	ds_store_b16 v30, v11 offset:576                           // 000000062EC0: D87C0240 00000B1E
	.long 0xd4cb007e                                           // 000000062EC8: D4CB007E
	v_cndmask_b32_e32 v1, v50, v45, vcc_lo                     // 000000062ECC: 02025B32
	s_cbranch_execz 35                                         // 000000062ED0: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b60>
	s_waitcnt lgkmcnt(11)                                      // 000000062ED4: BF89FCB7
	v_sub_f32_e32 v10, v17, v12                                // 000000062ED8: 08141911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062EDC: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 000000062EE0: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 000000062EE8: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 000000062EF4: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062EF8: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 000000062EFC: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 000000062F04: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000062F08: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 000000062F0C: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 000000062F10: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 000000062F14: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 000000062F1C: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000062F20: BF870135
	.long 0xd71c000b                                           // 000000062F24: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 000000062F28: 02023F0B
	s_waitcnt lgkmcnt(7)                                       // 000000062F2C: BF89FC77
	v_mul_f32_e32 v31, v9, v15                                 // 000000062F30: 103E1F09
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 000000062F34: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 000000062F38: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000062F40: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 000000062F44: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 000000062F4C: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000062F50: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 000000062F54: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 000000062F58: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s0                              // 000000062F60: 8C7E007E
	s_mov_b32 s0, 0                                            // 000000062F64: BE800080
	ds_store_b16_d16_hi v30, v10 offset:672                    // 000000062F68: DA8402A0 00000A1E
	s_and_b32 vcc_lo, exec_lo, s0                              // 000000062F70: 8B6A007E
	s_cbranch_vccz 365                                         // 000000062F74: BFA3016D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x212c>
	v_or_b32_e32 v10, 0x5e40, v51                              // 000000062F78: 381466FF 00005E40
	v_mov_b32_e32 v57, 0                                       // 000000062F80: 7E720280
	v_mov_b32_e32 v59, 0                                       // 000000062F84: 7E760280
	s_mov_b32 s0, exec_lo                                      // 000000062F88: BE80007E
	s_delay_alu instid0(VALU_DEP_3)                            // 000000062F8C: BF870003
	v_subrev_nc_u32_e32 v58, 64, v10                           // 000000062F90: 4E7414C0
	ds_load_2addr_b32 v[32:33], v58 offset0:2 offset1:4        // 000000062F94: D8DC0402 2000003A
	ds_load_2addr_b32 v[30:31], v58 offset0:6 offset1:8        // 000000062F9C: D8DC0806 1E00003A
	ds_load_2addr_b32 v[10:11], v58 offset0:10 offset1:12      // 000000062FA4: D8DC0C0A 0A00003A
	ds_load_b32 v56, v58 offset:56                             // 000000062FAC: D8D80038 3800003A
	.long 0xd4c9007e                                           // 000000062FB4: D4C9007E
	v_cndmask_b32_e32 v1, v50, v149, vcc_lo                    // 000000062FB8: 02032B32
	s_cbranch_execz 37                                         // 000000062FBC: BFA50025 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1c54>
	s_waitcnt lgkmcnt(11)                                      // 000000062FC0: BF89FCB7
	v_sub_f32_e32 v28, v28, v12                                // 000000062FC4: 0838191C
	ds_load_b32 v58, v58                                       // 000000062FC8: D8D80000 3A00003A
	s_waitcnt lgkmcnt(8)                                       // 000000062FD0: BF89FC87
	v_dual_mul_f32 v2, v2, v26 :: v_dual_mul_f32 v59, 0x3fb8aa3b, v28// 000000062FD4: C8C63502 023A38FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000062FE0: BF870111
	v_mul_f32_e32 v2, v13, v2                                  // 000000062FE4: 1004050D
	v_fma_f32 v60, 0x3fb8aa3b, v28, -v59                       // 000000062FE8: D613003C 84EE38FF 3FB8AA3B
	v_rndne_f32_e32 v61, v59                                   // 000000062FF4: 7E7A473B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000062FF8: BF870131
	v_dual_sub_f32 v59, v59, v61 :: v_dual_fmac_f32 v60, 0x32a5705f, v28// 000000062FFC: C9407B3B 3B3C38FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v28                  // 000000063008: 7C3638FF C2CE8ED0
	s_waitcnt lgkmcnt(0)                                       // 000000063010: BF89FC07
	v_dual_mul_f32 v2, v58, v2 :: v_dual_add_f32 v59, v59, v60 // 000000063014: C8C8053A 023A793B
	v_cvt_i32_f32_e32 v60, v61                                 // 00000006301C: 7E78113D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000063020: BF870292
	v_exp_f32_e32 v59, v59                                     // 000000063024: 7E764B3B
	.long 0xd71c003b                                           // 000000063028: D71C003B
	v_cndmask_b32_e32 v1, v59, v60, vcc_lo                     // 00000006302C: 0202793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063030: BF870121
	v_cndmask_b32_e32 v26, 0, v59, vcc_lo                      // 000000063034: 02347680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v28                  // 000000063038: 7C3C38FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 000000063040: 023434FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000063048: BF870001
	.long 0xd508003b                                           // 00000006304C: D508003B
	v_sub_co_ci_u32_e32 v1, vcc_lo, v2, v26, vcc_lo            // 000000063050: 42023502
	s_or_b32 exec_lo, exec_lo, s0                              // 000000063054: 8C7E007E
	v_or_b32_e32 v2, 0x5e40, v54                               // 000000063058: 38046CFF 00005E40
	s_waitcnt lgkmcnt(7)                                       // 000000063060: BF89FC77
	v_lshlrev_b32_e32 v26, 6, v149                             // 000000063064: 30352A86
	s_mov_b32 s0, exec_lo                                      // 000000063068: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006306C: BF870001
	v_add3_u32 v2, v2, v26, 0xfffff8c0                         // 000000063070: D6550002 03FE3502 FFFFF8C0
	ds_store_b32 v2, v59                                       // 00000006307C: D8340000 00003B02
	.long 0xd4c9007e                                           // 000000063084: D4C9007E
	v_cndmask_b32_e32 v1, v50, v55, vcc_lo                     // 000000063088: 02026F32
	s_cbranch_execz 33                                         // 00000006308C: BFA50021 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1d14>
	v_dual_sub_f32 v26, v29, v12 :: v_dual_mul_f32 v3, v3, v27 // 000000063090: C946191D 1A023703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063098: BF870121
	v_dual_mul_f32 v28, 0x3fb8aa3b, v26 :: v_dual_mul_f32 v3, v13, v3// 00000006309C: C8C634FF 1C02070D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v26                  // 0000000630A8: 7C3634FF C2CE8ED0
	v_fma_f32 v29, 0x3fb8aa3b, v26, -v28                       // 0000000630B0: D613001D 847234FF 3FB8AA3B
	v_rndne_f32_e32 v54, v28                                   // 0000000630BC: 7E6C471C
	s_waitcnt lgkmcnt(4)                                       // 0000000630C0: BF89FC47
	v_mul_f32_e32 v3, v32, v3                                  // 0000000630C4: 10060720
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000630C8: BF870193
	v_fmac_f32_e32 v29, 0x32a5705f, v26                        // 0000000630CC: 563A34FF 32A5705F
	v_sub_f32_e32 v28, v28, v54                                // 0000000630D4: 08386D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000630D8: BF870121
	v_add_f32_e32 v28, v28, v29                                // 0000000630DC: 06383B1C
	v_cvt_i32_f32_e32 v29, v54                                 // 0000000630E0: 7E3A1136
	v_exp_f32_e32 v28, v28                                     // 0000000630E4: 7E384B1C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000630E8: BF870095
	.long 0xd71c001c                                           // 0000000630EC: D71C001C
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                     // 0000000630F0: 02023B1C
	v_cndmask_b32_e32 v27, 0, v28, vcc_lo                      // 0000000630F4: 02363880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v26                  // 0000000630F8: 7C3C34FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063100: BF870092
	v_cndmask_b32_e32 v26, 0x7f800000, v27, vcc_lo             // 000000063104: 023436FF 7F800000
	.long 0xd5080039                                           // 00000006310C: D5080039
	v_sub_co_ci_u32_e32 v1, vcc_lo, v3, v26, vcc_lo            // 000000063110: 42023503
	s_or_b32 exec_lo, exec_lo, s0                              // 000000063114: 8C7E007E
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v26, 0              // 000000063118: CA100080 031A0080
	s_mov_b32 s0, exec_lo                                      // 000000063120: BE80007E
	ds_store_b32 v2, v57 offset:128                            // 000000063124: D8340080 00003902
	.long 0xd4c9007e                                           // 00000006312C: D4C9007E
	v_cndmask_b32_e32 v1, v50, v53, vcc_lo                     // 000000063130: 02026B32
	s_cbranch_execz 35                                         // 000000063134: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1dc4>
	v_sub_f32_e32 v24, v24, v12                                // 000000063138: 08301918
	s_waitcnt lgkmcnt(8)                                       // 00000006313C: BF89FC87
	v_mul_f32_e32 v4, v4, v22                                  // 000000063140: 10082D04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000063144: BF8701A2
	v_mul_f32_e32 v26, 0x3fb8aa3b, v24                         // 000000063148: 103430FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v24                  // 000000063150: 7C3630FF C2CE8ED0
	v_mul_f32_e32 v4, v13, v4                                  // 000000063158: 1008090D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000006315C: BF8701B3
	v_fma_f32 v27, 0x3fb8aa3b, v24, -v26                       // 000000063160: D613001B 846A30FF 3FB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000006316C: 7E38471A
	s_waitcnt lgkmcnt(5)                                       // 000000063170: BF89FC57
	v_mul_f32_e32 v4, v33, v4                                  // 000000063174: 10080921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000063178: BF870193
	v_fmac_f32_e32 v27, 0x32a5705f, v24                        // 00000006317C: 563630FF 32A5705F
	v_sub_f32_e32 v26, v26, v28                                // 000000063184: 0834391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063188: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000006318C: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 000000063190: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 000000063194: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063198: BF870095
	.long 0xd71c001a                                           // 00000006319C: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000000631A0: 0202371A
	v_cndmask_b32_e32 v22, 0, v26, vcc_lo                      // 0000000631A4: 022C3480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v24                  // 0000000631A8: 7C3C30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000631B0: BF870092
	v_cndmask_b32_e32 v22, 0x7f800000, v22, vcc_lo             // 0000000631B4: 022C2CFF 7F800000
	.long 0xd508001a                                           // 0000000631BC: D508001A
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v22, vcc_lo            // 0000000631C0: 42022D04
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000631C4: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000631C8: BF870009
	s_mov_b32 s0, exec_lo                                      // 0000000631CC: BE80007E
	ds_store_b32 v2, v26 offset:256                            // 0000000631D0: D8340100 00001A02
	.long 0xd4c9007e                                           // 0000000631D8: D4C9007E
	v_cndmask_b32_e32 v1, v50, v49, vcc_lo                     // 0000000631DC: 02026332
	s_cbranch_execz 34                                         // 0000000631E0: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1e6c>
	v_sub_f32_e32 v3, v25, v12                                 // 0000000631E4: 08061919
	s_waitcnt lgkmcnt(9)                                       // 0000000631E8: BF89FC97
	v_mul_f32_e32 v5, v5, v23                                  // 0000000631EC: 100A2F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000631F0: BF870091
	v_dual_mul_f32 v4, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, v13, v5// 0000000631F4: C8C606FF 04040B0D 3FB8AA3B
	v_fma_f32 v22, 0x3fb8aa3b, v3, -v4                         // 000000063200: D6130016 841206FF 3FB8AA3B
	v_rndne_f32_e32 v24, v4                                    // 00000006320C: 7E304704
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000063210: BF870112
	v_fmac_f32_e32 v22, 0x32a5705f, v3                         // 000000063214: 562C06FF 32A5705F
	v_sub_f32_e32 v4, v4, v24                                  // 00000006321C: 08083104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000063220: BF8701B1
	v_add_f32_e32 v4, v4, v22                                  // 000000063224: 06082D04
	v_cvt_i32_f32_e32 v22, v24                                 // 000000063228: 7E2C1118
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000006322C: 7C3606FF C2CE8ED0
	v_exp_f32_e32 v4, v4                                       // 000000063234: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063238: BF870095
	.long 0xd71c0004                                           // 00000006323C: D71C0004
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 000000063240: 02022D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 000000063244: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 000000063248: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(5)                                       // 000000063250: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063254: BF870092
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v30, v5// 000000063258: CA4608FF 03040B1E 7F800000
	.long 0xd5080003                                           // 000000063264: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 000000063268: 42020704
	s_or_b32 exec_lo, exec_lo, s0                              // 00000006326C: 8C7E007E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 000000063270: CA100080 04040080
	s_mov_b32 s0, exec_lo                                      // 000000063278: BE80007E
	ds_store_b32 v2, v3 offset:384                             // 00000006327C: D8340180 00000302
	.long 0xd4c9007e                                           // 000000063284: D4C9007E
	v_cndmask_b32_e32 v1, v50, v48, vcc_lo                     // 000000063288: 02026132
	s_cbranch_execz 34                                         // 00000006328C: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1f18>
	s_waitcnt lgkmcnt(9)                                       // 000000063290: BF89FC97
	v_dual_sub_f32 v3, v20, v12 :: v_dual_mul_f32 v6, v6, v18  // 000000063294: C9461914 03062506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000006329C: BF870121
	v_dual_mul_f32 v5, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v6, v13, v6// 0000000632A0: C8C606FF 05060D0D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 0000000632AC: 7C3606FF C2CE8ED0
	v_fma_f32 v20, 0x3fb8aa3b, v3, -v5                         // 0000000632B4: D6130014 841606FF 3FB8AA3B
	v_rndne_f32_e32 v22, v5                                    // 0000000632C0: 7E2C4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000632C4: BF870091
	v_dual_fmac_f32 v20, 0x32a5705f, v3 :: v_dual_sub_f32 v5, v5, v22// 0000000632C8: C80A06FF 14042D05 32A5705F
	v_add_f32_e32 v5, v5, v20                                  // 0000000632D4: 060A2905
	v_cvt_i32_f32_e32 v20, v22                                 // 0000000632D8: 7E281116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000632DC: BF870292
	v_exp_f32_e32 v5, v5                                       // 0000000632E0: 7E0A4B05
	.long 0xd71c0005                                           // 0000000632E4: D71C0005
	v_cndmask_b32_e32 v1, v5, v20, vcc_lo                      // 0000000632E8: 02022905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000632EC: BF870121
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 0000000632F0: 020A0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 0000000632F4: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v3, 0x7f800000, v5, vcc_lo               // 0000000632FC: 02060AFF 7F800000
	s_waitcnt lgkmcnt(6)                                       // 000000063304: BF89FC67
	v_mul_f32_e32 v5, v31, v6                                  // 000000063308: 100A0D1F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006330C: BF870001
	.long 0xd5080005                                           // 000000063310: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v3, vcc_lo             // 000000063314: 42020705
	s_or_b32 exec_lo, exec_lo, s0                              // 000000063318: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000006331C: BF870009
	s_mov_b32 s0, exec_lo                                      // 000000063320: BE80007E
	ds_store_b32 v2, v5 offset:512                             // 000000063324: D8340200 00000502
	.long 0xd4c9007e                                           // 00000006332C: D4C9007E
	v_cndmask_b32_e32 v1, v50, v47, vcc_lo                     // 000000063330: 02025F32
	s_cbranch_execz 35                                         // 000000063334: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1fc4>
	v_sub_f32_e32 v3, v21, v12                                 // 000000063338: 08061915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006333C: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 000000063340: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 000000063348: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 000000063354: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000063358: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000006335C: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 000000063360: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 000000063368: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063370: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 000000063374: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 000000063378: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000006337C: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000063380: BF8700A5
	.long 0xd71c0004                                           // 000000063384: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 000000063388: 02020B04
	s_waitcnt lgkmcnt(10)                                      // 00000006338C: BF89FCA7
	v_dual_mul_f32 v5, v7, v19 :: v_dual_cndmask_b32 v4, 0, v4 // 000000063390: C8D22707 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000063398: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000006339C: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 0000000633A0: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(6)                                       // 0000000633A8: BF89FC67
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v10, v5// 0000000633AC: CA4608FF 03040B0A 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000633B8: BF870001
	.long 0xd5080004                                           // 0000000633BC: D5080004
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 0000000633C0: 42020704
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000633C4: 8C7E007E
	v_mov_b32_e32 v3, 0                                        // 0000000633C8: 7E060280
	v_mov_b32_e32 v5, 0                                        // 0000000633CC: 7E0A0280
	s_mov_b32 s0, exec_lo                                      // 0000000633D0: BE80007E
	ds_store_b32 v2, v4 offset:640                             // 0000000633D4: D8340280 00000402
	.long 0xd4c9007e                                           // 0000000633DC: D4C9007E
	v_cndmask_b32_e32 v1, v50, v46, vcc_lo                     // 0000000633E0: 02025D32
	s_cbranch_execz 35                                         // 0000000633E4: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2074>
	v_sub_f32_e32 v4, v16, v12                                 // 0000000633E8: 08081910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000633EC: BF870091
	v_mul_f32_e32 v5, 0x3fb8aa3b, v4                           // 0000000633F0: 100A08FF 3FB8AA3B
	v_fma_f32 v6, 0x3fb8aa3b, v4, -v5                          // 0000000633F8: D6130006 841608FF 3FB8AA3B
	v_rndne_f32_e32 v7, v5                                     // 000000063404: 7E0E4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000063408: BF870221
	v_sub_f32_e32 v5, v5, v7                                   // 00000006340C: 080A0F05
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 000000063410: 7C3608FF C2CE8ED0
	v_fmac_f32_e32 v6, 0x32a5705f, v4                          // 000000063418: 560C08FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063420: BF870121
	v_add_f32_e32 v5, v5, v6                                   // 000000063424: 060A0D05
	v_cvt_i32_f32_e32 v6, v7                                   // 000000063428: 7E0C1107
	v_exp_f32_e32 v5, v5                                       // 00000006342C: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000063430: BF8700A5
	.long 0xd71c0005                                           // 000000063434: D71C0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 000000063438: 02020D05
	s_waitcnt lgkmcnt(10)                                      // 00000006343C: BF89FCA7
	v_dual_mul_f32 v6, v8, v14 :: v_dual_cndmask_b32 v5, 0, v5 // 000000063440: C8D21D08 06040A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000063448: BF870131
	v_mul_f32_e32 v6, v13, v6                                  // 00000006344C: 100C0D0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 000000063450: 7C3C08FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 000000063458: BF89FC77
	v_dual_cndmask_b32 v4, 0x7f800000, v5 :: v_dual_mul_f32 v5, v11, v6// 00000006345C: CA460AFF 04040D0B 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000063468: BF870001
	.long 0xd5080005                                           // 00000006346C: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v4, vcc_lo             // 000000063470: 42020905
	s_or_b32 exec_lo, exec_lo, s0                              // 000000063474: 8C7E007E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000063478: BF870009
	s_mov_b32 s0, exec_lo                                      // 00000006347C: BE80007E
	ds_store_b32 v2, v5 offset:768                             // 000000063480: D8340300 00000502
	.long 0xd4c9007e                                           // 000000063488: D4C9007E
	v_cndmask_b32_e32 v1, v50, v45, vcc_lo                     // 00000006348C: 02025B32
	s_cbranch_execz 35                                         // 000000063490: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2120>
	v_sub_f32_e32 v3, v17, v12                                 // 000000063494: 08061911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063498: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000006349C: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 0000000634A4: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 0000000634B0: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000000634B4: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 0000000634B8: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 0000000634BC: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 0000000634C4: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000634CC: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 0000000634D0: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 0000000634D4: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 0000000634D8: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000634DC: BF8700A5
	.long 0xd71c0004                                           // 0000000634E0: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 0000000634E4: 02020B04
	s_waitcnt lgkmcnt(11)                                      // 0000000634E8: BF89FCB7
	v_dual_mul_f32 v5, v9, v15 :: v_dual_cndmask_b32 v4, 0, v4 // 0000000634EC: C8D21F09 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000634F4: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 0000000634F8: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 0000000634FC: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 000000063504: BF89FC77
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v56, v5// 000000063508: CA4608FF 03040B38 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000063514: BF870001
	.long 0xd5080003                                           // 000000063518: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000006351C: 42020704
	s_or_b32 exec_lo, exec_lo, s0                              // 000000063520: 8C7E007E
	ds_store_b32 v2, v3 offset:896                             // 000000063524: D8340380 00000302
	s_waitcnt lgkmcnt(0)                                       // 00000006352C: BF89FC07
	s_barrier                                                  // 000000063530: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s34                             // 000000063534: 8B6A227E
	s_mov_b32 s0, -1                                           // 000000063538: BE8000C1
	s_cbranch_vccz 176                                         // 00000006353C: BFA300B0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2400>
	s_mov_b32 s0, exec_lo                                      // 000000063540: BE80007E
	v_cmpx_gt_i32_e32 0x120, v44                               // 000000063544: 7D8858FF 00000120
	s_cbranch_execz 170                                        // 00000006354C: BFA500AA <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x23f8>
	v_add_nc_u32_e32 v2, 0xffffff00, v44                       // 000000063550: 4A0458FF FFFFFF00
	s_mov_b32 s1, 0                                            // 000000063558: BE810080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006355C: BF870001
	v_mov_b32_e32 v3, v2                                       // 000000063560: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000063564: BF8700A1
	v_add_nc_u32_e32 v3, 0xe0, v3                              // 000000063568: 4A0606FF 000000E0
	s_waitcnt lgkmcnt(4)                                       // 000000063570: BF89FC47
	v_ashrrev_i32_e32 v16, 7, v3                               // 000000063574: 34200687
	v_and_b32_e32 v12, 0x7f, v3                                // 000000063578: 361806FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063580: BF870092
	.long 0xd72c0004                                           // 000000063584: D72C0004
	v_cndmask_b32_e32 v1, 0x880, v16, vcc_lo                   // 000000063588: 020220FF 00000880
	v_lshl_add_u32 v4, v12, 1, v4                              // 000000063590: D6460004 0411030C
	ds_load_u16 v20, v4 offset:7776                            // 000000063598: D8F01E60 14000004
	ds_load_u16 v21, v4 offset:7232                            // 0000000635A0: D8F01C40 15000004
	s_waitcnt lgkmcnt(4)                                       // 0000000635A8: BF89FC47
	ds_load_u16 v22, v4 offset:6688                            // 0000000635AC: D8F01A20 16000004
	ds_load_u16 v23, v4 offset:6144                            // 0000000635B4: D8F01800 17000004
	ds_load_u16 v24, v4 offset:6416                            // 0000000635BC: D8F01910 18000004
	s_waitcnt lgkmcnt(3)                                       // 0000000635C4: BF89FC37
	v_lshlrev_b32_e32 v21, 16, v21                             // 0000000635C8: 302A2A90
	s_waitcnt lgkmcnt(1)                                       // 0000000635CC: BF89FC17
	v_lshlrev_b32_e32 v23, 16, v23                             // 0000000635D0: 302E2E90
	v_lshlrev_b32_e32 v17, 5, v16                              // 0000000635D4: 30222085
	ds_load_u16 v25, v4 offset:6960                            // 0000000635D8: D8F01B30 19000004
	ds_load_u16 v26, v4 offset:7504                            // 0000000635E0: D8F01D50 1A000004
	ds_load_u16 v27, v4 offset:8048                            // 0000000635E8: D8F01F70 1B000004
	ds_load_b128 v[4:7], v17 offset:24384                      // 0000000635F0: DBFC5F40 04000011
	ds_load_b128 v[8:11], v17 offset:24400                     // 0000000635F8: DBFC5F50 08000011
	v_lshlrev_b32_e32 v20, 16, v20                             // 000000063600: 30282890
	s_waitcnt lgkmcnt(0)                                       // 000000063604: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063608: BF870091
	v_dual_mul_f32 v10, v10, v20 :: v_dual_lshlrev_b32 v25, 16, v25// 00000006360C: C8E2290A 0A183290
	v_dual_mul_f32 v7, v7, v25 :: v_dual_lshlrev_b32 v24, 16, v24// 000000063614: C8E23307 07183090
	v_mul_f32_e32 v8, v8, v21                                  // 00000006361C: 10102B08
	s_delay_alu instid0(VALU_DEP_2)                            // 000000063620: BF870002
	v_dual_mul_f32 v4, v4, v23 :: v_dual_mul_f32 v5, v5, v24   // 000000063624: C8C62F04 04043105
	v_mul_u32_u24_e32 v18, 48, v12                             // 00000006362C: 162418B0
	ds_load_b128 v[12:15], v17 offset:24192                    // 000000063630: DBFC5E80 0C000011
	v_lshlrev_b32_e32 v26, 16, v26                             // 000000063638: 30343490
	v_lshlrev_b32_e32 v27, 16, v27                             // 00000006363C: 30363690
	v_lshl_add_u32 v28, v16, 4, v18                            // 000000063640: D646001C 04490910
	ds_load_b128 v[16:19], v17 offset:24208                    // 000000063648: DBFC5E90 10000011
	s_waitcnt lgkmcnt(1)                                       // 000000063650: BF89FC17
	v_mul_f32_e32 v12, v12, v4                                 // 000000063654: 1018090C
	v_mul_f32_e32 v4, v13, v5                                  // 000000063658: 10080B0D
	v_dual_mul_f32 v11, v11, v27 :: v_dual_lshlrev_b32 v22, 16, v22// 00000006365C: C8E2370B 0B162C90
	v_mul_f32_e32 v5, v15, v7                                  // 000000063664: 100A0F0F
	v_mul_f32_e32 v9, v9, v26                                  // 000000063668: 10123509
	s_waitcnt lgkmcnt(0)                                       // 00000006366C: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000063670: BF870243
	v_dual_mul_f32 v7, v16, v8 :: v_dual_mul_f32 v6, v6, v22   // 000000063674: C8C61110 07062D06
	v_cmp_lt_i32_e32 vcc_lo, 31, v3                            // 00000006367C: 7C82069F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 000000063680: CC220004 02006104
	v_dual_mul_f32 v8, v17, v9 :: v_dual_mul_f32 v9, v18, v10  // 000000063688: C8C61311 08081512
	v_mul_f32_e32 v6, v14, v6                                  // 000000063690: 100C0D0E
	v_mul_f32_e32 v10, v19, v11                                // 000000063694: 10141713
	v_fma_mixlo_f16 v4, v12, s48, 0                            // 000000063698: CC210004 0200610C
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 0000000636A0: CC220005 02006105
	s_or_b32 s1, vcc_lo, s1                                    // 0000000636A8: 8C01016A
	v_fma_mixlo_f16 v5, v6, s48, 0                             // 0000000636AC: CC210005 02006106
	v_fma_mixhi_f16 v6, v8, s48, 0                             // 0000000636B4: CC220006 02006108
	v_fma_mixlo_f16 v6, v7, s48, 0                             // 0000000636BC: CC210006 02006107
	v_fma_mixhi_f16 v7, v10, s48, 0                            // 0000000636C4: CC220007 0200610A
	v_fma_mixlo_f16 v7, v9, s48, 0                             // 0000000636CC: CC210007 02006109
	ds_store_b128 v28, v[4:7]                                  // 0000000636D4: DB7C0000 0000041C
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000636DC: 917E017E
	s_cbranch_execnz 65440                                     // 0000000636E0: BFA6FFA0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2164>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000636E4: 8C7E017E
	v_lshl_add_u32 v3, v44, 3, 0xffffff00                      // 0000000636E8: D6460003 03FD072C FFFFFF00
	s_mov_b32 s1, 0                                            // 0000000636F4: BE810080
	v_add_nc_u32_e32 v2, 0xe0, v2                              // 0000000636F8: 4A0404FF 000000E0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000063700: BF8701A2
	v_and_b32_e32 v4, 0x78, v3                                 // 000000063704: 360806FF 00000078
	v_add_nc_u32_e32 v3, 0x700, v3                             // 00000006370C: 4A0606FF 00000700
	v_ashrrev_i32_e32 v5, 4, v2                                // 000000063714: 340A0484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000063718: BF870121
	.long 0xd72c0006                                           // 00000006371C: D72C0006
	v_cndmask_b32_e32 v1, 0x110, v5, vcc_lo                    // 000000063720: 02020AFF 00000110
	v_lshlrev_b32_e32 v8, 2, v5                                // 000000063728: 30100A82
	v_lshl_add_u32 v9, v4, 1, v6                               // 00000006372C: D6460009 04190304
	ds_load_b128 v[4:7], v9 offset:10496                       // 000000063734: DBFC2900 04000009
	ds_load_b32 v8, v8 offset:24448                            // 00000006373C: D8D85F80 08000008
	s_waitcnt lgkmcnt(1)                                       // 000000063744: BF89FC17
	v_and_b32_e32 v12, 0xffff0000, v6                          // 000000063748: 36180CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 000000063750: 300C0C90
	v_and_b32_e32 v13, 0xffff0000, v7                          // 000000063754: 361A0EFF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v4                          // 00000006375C: 361408FF FFFF0000
	v_lshlrev_b32_e32 v4, 16, v4                               // 000000063764: 30080890
	v_and_b32_e32 v11, 0xffff0000, v5                          // 000000063768: 36160AFF FFFF0000
	v_lshlrev_b32_e32 v5, 16, v5                               // 000000063770: 300A0A90
	s_waitcnt lgkmcnt(0)                                       // 000000063774: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000063778: BF8701A3
	v_dual_mul_f32 v14, v8, v4 :: v_dual_lshlrev_b32 v7, 16, v7// 00000006377C: C8E20908 0E060E90
	v_mul_f32_e32 v4, v8, v10                                  // 000000063784: 10081508
	v_mul_f32_e32 v10, v8, v5                                  // 000000063788: 10140B08
	v_mul_f32_e32 v5, v8, v11                                  // 00000006378C: 100A1708
	v_mul_f32_e32 v11, v8, v6                                  // 000000063790: 10160D08
	v_mul_f32_e32 v6, v8, v12                                  // 000000063794: 100C1908
	v_mul_f32_e32 v12, v8, v7                                  // 000000063798: 10180F08
	v_mul_f32_e32 v7, v8, v13                                  // 00000006379C: 100E1B08
	v_cmp_lt_i32_e32 vcc_lo, 31, v2                            // 0000000637A0: 7C82049F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 0000000637A4: CC220004 02006104
	v_fma_mixlo_f16 v4, v14, s48, 0                            // 0000000637AC: CC210004 0200610E
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 0000000637B4: CC220005 02006105
	v_fma_mixlo_f16 v5, v10, s48, 0                            // 0000000637BC: CC210005 0200610A
	v_fma_mixhi_f16 v6, v6, s48, 0                             // 0000000637C4: CC220006 02006106
	v_fma_mixlo_f16 v6, v11, s48, 0                            // 0000000637CC: CC210006 0200610B
	v_fma_mixhi_f16 v7, v7, s48, 0                             // 0000000637D4: CC220007 02006107
	v_fma_mixlo_f16 v7, v12, s48, 0                            // 0000000637DC: CC210007 0200610C
	s_or_b32 s1, vcc_lo, s1                                    // 0000000637E4: 8C01016A
	ds_store_b128 v9, v[4:7] offset:10496                      // 0000000637E8: DB7C2900 00000409
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000637F0: 917E017E
	s_cbranch_execnz 65472                                     // 0000000637F4: BFA6FFC0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x22f8>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000637F8: 8C7E007E
	s_mov_b32 s0, 0                                            // 0000000637FC: BE800080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000063800: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000063804: 916A007E
	s_cbranch_vccnz 536                                        // 000000063808: BFA40218 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c6c>
	s_mov_b32 s0, exec_lo                                      // 00000006380C: BE80007E
	v_cmpx_gt_u32_e32 16, v43                                  // 000000063810: 7D985690
	s_cbranch_execz 532                                        // 000000063814: BFA50214 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2c68>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 000000063818: 7C945680
	s_waitcnt lgkmcnt(0)                                       // 00000006381C: BF89FC07
	ds_load_b96 v[14:16], v1 offset:23280                      // 000000063820: DBF85AF0 0E000001
	ds_load_b128 v[53:56], v1 offset:23248                     // 000000063828: DBFC5AD0 35000001
	ds_load_b128 v[57:60], v1 offset:23264                     // 000000063830: DBFC5AE0 39000001
	ds_load_b128 v[10:13], v1 offset:23168                     // 000000063838: DBFC5A80 0A000001
	ds_load_b128 v[6:9], v1 offset:23184                       // 000000063840: DBFC5A90 06000001
	ds_load_b128 v[2:5], v1 offset:23200                       // 000000063848: DBFC5AA0 02000001
	ds_load_b64 v[17:18], v1 offset:23216                      // 000000063850: D9D85AB0 11000001
	v_cndmask_b32_e64 v44, 0, 1.0, vcc_lo                      // 000000063858: D501002C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 000000063860: 7C945681
	ds_load_b128 v[45:48], v1 offset:23232                     // 000000063864: DBFC5AC0 2D000001
	v_cndmask_b32_e64 v33, 0, 1.0, vcc_lo                      // 00000006386C: D5010021 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 000000063874: 7C945682
	v_cndmask_b32_e64 v32, 0, 1.0, vcc_lo                      // 000000063878: D5010020 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 000000063880: 7C945683
	v_cndmask_b32_e64 v31, 0, 1.0, vcc_lo                      // 000000063884: D501001F 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 00000006388C: 7C945684
	v_cndmask_b32_e64 v29, 0, 1.0, vcc_lo                      // 000000063890: D501001D 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 000000063898: 7C945685
	v_cndmask_b32_e64 v30, 0, 1.0, vcc_lo                      // 00000006389C: D501001E 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 0000000638A4: 7C945686
	v_cndmask_b32_e64 v28, 0, 1.0, vcc_lo                      // 0000000638A8: D501001C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 0000000638B0: 7C945687
	v_cndmask_b32_e64 v27, 0, 1.0, vcc_lo                      // 0000000638B4: D501001B 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 0000000638BC: 7C945688
	v_cndmask_b32_e64 v25, 0, 1.0, vcc_lo                      // 0000000638C0: D5010019 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 0000000638C8: 7C945689
	v_cndmask_b32_e64 v23, 0, 1.0, vcc_lo                      // 0000000638CC: D5010017 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 0000000638D4: 7C94568A
	v_cndmask_b32_e64 v26, 0, 1.0, vcc_lo                      // 0000000638D8: D501001A 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 0000000638E0: 7C94568B
	v_cndmask_b32_e64 v24, 0, 1.0, vcc_lo                      // 0000000638E4: D5010018 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 0000000638EC: 7C94568C
	v_cndmask_b32_e64 v20, 0, 1.0, vcc_lo                      // 0000000638F0: D5010014 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 0000000638F8: 7C94568D
	v_cndmask_b32_e64 v22, 0, 1.0, vcc_lo                      // 0000000638FC: D5010016 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 000000063904: 7C94568E
	v_cndmask_b32_e64 v21, 0, 1.0, vcc_lo                      // 000000063908: D5010015 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 000000063910: 7C94568F
	v_cndmask_b32_e64 v19, 0, 1.0, vcc_lo                      // 000000063914: D5010013 01A9E480
	s_waitcnt lgkmcnt(7)                                       // 00000006391C: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000063920: BF8700B1
	v_fmac_f32_e32 v22, v19, v15                               // 000000063924: 562C1F13
	v_fmac_f32_e32 v21, v19, v16                               // 000000063928: 562A2113
	s_waitcnt lgkmcnt(1)                                       // 00000006392C: BF89FC17
	v_dual_fmac_f32 v27, v19, v56 :: v_dual_fmac_f32 v22, v21, v18// 000000063930: C8007113 1B162515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000063938: BF8700D1
	v_dual_fmac_f32 v30, v19, v54 :: v_dual_fmac_f32 v27, v21, v9// 00000006393C: C8006D13 1E1A1315
	v_fmac_f32_e32 v29, v19, v53                               // 000000063944: 563A6B13
	ds_load_b32 v18, v1 offset:22880                           // 000000063948: D8D85960 12000001
	v_fmac_f32_e32 v30, v21, v7                                // 000000063950: 563C0F15
	v_dual_fmac_f32 v28, v19, v55 :: v_dual_fmac_f32 v29, v21, v6// 000000063954: C8006F13 1C1C0D15
	v_dual_fmac_f32 v25, v19, v57 :: v_dual_fmac_f32 v28, v21, v8// 00000006395C: C8007313 191C1115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063964: BF870091
	v_dual_fmac_f32 v26, v19, v59 :: v_dual_fmac_f32 v25, v21, v2// 000000063968: C8007713 1A180515
	v_dual_fmac_f32 v23, v19, v58 :: v_dual_fmac_f32 v26, v21, v4// 000000063970: C8007513 171A0915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063978: BF870091
	v_dual_fmac_f32 v24, v19, v60 :: v_dual_fmac_f32 v23, v21, v3// 00000006397C: C8007913 18160715
	v_fmac_f32_e32 v24, v21, v5                                // 000000063984: 56300B15
	ds_load_b128 v[2:5], v1 offset:23072                       // 000000063988: DBFC5A20 02000001
	s_waitcnt lgkmcnt(2)                                       // 000000063990: BF89FC27
	v_fmac_f32_e32 v31, v19, v48                               // 000000063994: 563E6113
	s_delay_alu instid0(VALU_DEP_1)                            // 000000063998: BF870001
	v_dual_fmac_f32 v32, v19, v47 :: v_dual_fmac_f32 v31, v21, v13// 00000006399C: C8005F13 201E1B15
	v_fmac_f32_e32 v20, v19, v14                               // 0000000639A4: 56281D13
	ds_load_b128 v[53:56], v1 offset:23104                     // 0000000639A8: DBFC5A40 35000001
	ds_load_b128 v[57:60], v1 offset:23136                     // 0000000639B0: DBFC5A60 39000001
	ds_load_b128 v[150:153], v1 offset:23120                   // 0000000639B8: DBFC5A50 96000001
	ds_load_b32 v14, v1 offset:23152                           // 0000000639C0: D8D85A70 0E000001
	v_dual_fmac_f32 v33, v19, v46 :: v_dual_fmac_f32 v32, v21, v12// 0000000639C8: C8005D13 21201915
	v_fmac_f32_e32 v44, v19, v45                               // 0000000639D0: 56585B13
	ds_load_b128 v[45:48], v1 offset:24064                     // 0000000639D4: DBFC5E00 2D000001
	v_fmac_f32_e32 v33, v21, v11                               // 0000000639DC: 56421715
	v_fmac_f32_e32 v44, v21, v10                               // 0000000639E0: 56581515
	ds_load_b128 v[6:9], v1 offset:23056                       // 0000000639E4: DBFC5A10 06000001
	ds_load_b128 v[10:13], v1 offset:23040                     // 0000000639EC: DBFC5A00 0A000001
	s_waitcnt lgkmcnt(6)                                       // 0000000639F4: BF89FC67
	v_fmac_f32_e32 v44, v22, v53                               // 0000000639F8: 56586B16
	v_dual_fmac_f32 v31, v22, v56 :: v_dual_fmac_f32 v20, v21, v17// 0000000639FC: C8007116 1F142315
	s_waitcnt lgkmcnt(4)                                       // 000000063A04: BF89FC47
	v_fmac_f32_e32 v29, v22, v150                              // 000000063A08: 563B2D16
	v_fmac_f32_e32 v33, v22, v54                               // 000000063A0C: 56426D16
	s_waitcnt lgkmcnt(3)                                       // 000000063A10: BF89FC37
	v_fmac_f32_e32 v20, v22, v14                               // 000000063A14: 56281D16
	ds_load_b128 v[14:17], v1 offset:22976                     // 000000063A18: DBFC59C0 0E000001
	v_fmac_f32_e32 v24, v22, v60                               // 000000063A20: 56307916
	v_fmac_f32_e32 v28, v22, v152                              // 000000063A24: 56393116
	ds_load_b64 v[60:61], v1 offset:22944                      // 000000063A28: D9D859A0 3C000001
	s_waitcnt lgkmcnt(2)                                       // 000000063A30: BF89FC27
	v_fmac_f32_e32 v33, v20, v11                               // 000000063A34: 56421714
	v_fmac_f32_e32 v24, v20, v5                                // 000000063A38: 56300B14
	s_waitcnt lgkmcnt(1)                                       // 000000063A3C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000063A40: BF8701C1
	v_fmac_f32_e32 v33, v24, v15                               // 000000063A44: 56421F18
	v_dual_fmac_f32 v32, v22, v55 :: v_dual_fmac_f32 v29, v20, v6// 000000063A48: C8006F16 201C0D14
	v_dual_fmac_f32 v27, v22, v153 :: v_dual_fmac_f32 v44, v20, v10// 000000063A50: C8013316 1B2C1514
	v_fmac_f32_e32 v30, v22, v151                              // 000000063A58: 563D2F16
	v_dual_fmac_f32 v25, v22, v57 :: v_dual_fmac_f32 v32, v20, v12// 000000063A5C: C8007316 19201914
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000063A64: BF870193
	v_dual_fmac_f32 v26, v22, v59 :: v_dual_fmac_f32 v27, v20, v9// 000000063A68: C8007716 1A1A1314
	v_dual_fmac_f32 v23, v22, v58 :: v_dual_fmac_f32 v30, v20, v7// 000000063A70: C8007516 171E0F14
	ds_load_b128 v[53:56], v1 offset:22992                     // 000000063A78: DBFC59D0 35000001
	ds_load_b96 v[57:59], v1 offset:23008                      // 000000063A80: DBF859E0 39000001
	v_fmac_f32_e32 v25, v20, v2                                // 000000063A88: 56320514
	v_fmac_f32_e32 v26, v20, v4                                // 000000063A8C: 56340914
	v_fmac_f32_e32 v31, v20, v13                               // 000000063A90: 563E1B14
	v_fmac_f32_e32 v23, v20, v3                                // 000000063A94: 562E0714
	ds_load_b128 v[2:5], v1 offset:22848                       // 000000063A98: DBFC5940 02000001
	s_waitcnt lgkmcnt(1)                                       // 000000063AA0: BF89FC17
	v_fmac_f32_e32 v26, v24, v59                               // 000000063AA4: 56347718
	v_fmac_f32_e32 v28, v20, v8                                // 000000063AA8: 56381114
	ds_load_b128 v[6:9], v1 offset:22928                       // 000000063AAC: DBFC5990 06000001
	ds_load_b128 v[10:13], v1 offset:22912                     // 000000063AB4: DBFC5980 0A000001
	v_fmac_f32_e32 v29, v24, v53                               // 000000063ABC: 563A6B18
	s_waitcnt lgkmcnt(1)                                       // 000000063AC0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000063AC4: BF870001
	v_fmac_f32_e32 v29, v26, v6                                // 000000063AC8: 563A0D1A
	v_fmac_f32_e32 v31, v24, v17                               // 000000063ACC: 563E2318
	v_fmac_f32_e32 v44, v24, v14                               // 000000063AD0: 56581D18
	v_fmac_f32_e32 v23, v24, v58                               // 000000063AD4: 562E7518
	v_fmac_f32_e32 v32, v24, v16                               // 000000063AD8: 56402118
	ds_load_b128 v[14:17], v1 offset:22864                     // 000000063ADC: DBFC5950 0E000001
	v_fmac_f32_e32 v27, v24, v56                               // 000000063AE4: 56367118
	v_fmac_f32_e32 v30, v24, v54                               // 000000063AE8: 563C6D18
	v_fmac_f32_e32 v25, v24, v57                               // 000000063AEC: 56327318
	s_waitcnt lgkmcnt(1)                                       // 000000063AF0: BF89FC17
	v_fmac_f32_e32 v33, v26, v11                               // 000000063AF4: 5642171A
	v_fmac_f32_e32 v28, v24, v55                               // 000000063AF8: 56386F18
	ds_load_b128 v[53:56], v1 offset:22800                     // 000000063AFC: DBFC5910 35000001
	v_fmac_f32_e32 v31, v26, v13                               // 000000063B04: 563E1B1A
	v_fmac_f32_e32 v23, v26, v61                               // 000000063B08: 562E7B1A
	ds_load_b96 v[57:59], v1 offset:22736                      // 000000063B0C: DBF858D0 39000001
	v_dual_fmac_f32 v31, v23, v5 :: v_dual_fmac_f32 v44, v26, v10// 000000063B14: C8000B17 1F2C151A
	v_fmac_f32_e32 v32, v26, v12                               // 000000063B1C: 5640191A
	ds_load_b128 v[10:13], v1 offset:22784                     // 000000063B20: DBFC5900 0A000001
	v_fmac_f32_e32 v25, v26, v60                               // 000000063B28: 5632791A
	v_fmac_f32_e32 v28, v26, v8                                // 000000063B2C: 5638111A
	v_fmac_f32_e32 v27, v26, v9                                // 000000063B30: 5636131A
	v_fmac_f32_e32 v30, v26, v7                                // 000000063B34: 563C0F1A
	ds_load_b128 v[6:9], v1 offset:22720                       // 000000063B38: DBFC58C0 06000001
	ds_load_b64 v[60:61], v1 offset:22672                      // 000000063B40: D9D85890 3C000001
	v_fmac_f32_e32 v25, v23, v18                               // 000000063B48: 56322517
	s_waitcnt lgkmcnt(5)                                       // 000000063B4C: BF89FC57
	v_fmac_f32_e32 v28, v23, v16                               // 000000063B50: 56382117
	v_fmac_f32_e32 v29, v23, v14                               // 000000063B54: 563A1D17
	v_fmac_f32_e32 v27, v23, v17                               // 000000063B58: 56362317
	v_fmac_f32_e32 v33, v23, v3                                // 000000063B5C: 56420717
	s_waitcnt lgkmcnt(4)                                       // 000000063B60: BF89FC47
	v_fmac_f32_e32 v28, v25, v55                               // 000000063B64: 56386F19
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 000000063B68: BF870153
	v_dual_fmac_f32 v30, v23, v15 :: v_dual_fmac_f32 v27, v25, v56// 000000063B6C: C8001F17 1E1A7119
	ds_load_b128 v[14:17], v1 offset:22528                     // 000000063B74: DBFC5800 0E000001
	v_fmac_f32_e32 v30, v25, v54                               // 000000063B7C: 563C6D19
	s_waitcnt lgkmcnt(4)                                       // 000000063B80: BF89FC47
	v_fmac_f32_e32 v28, v27, v59                               // 000000063B84: 5638771B
	v_fmac_f32_e32 v30, v27, v58                               // 000000063B88: 563C751B
	s_waitcnt lgkmcnt(1)                                       // 000000063B8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000063B90: BF870001
	v_fmac_f32_e32 v30, v28, v61                               // 000000063B94: 563C7B1C
	v_dual_fmac_f32 v44, v23, v2 :: v_dual_fmac_f32 v33, v25, v11// 000000063B98: C8000517 2C201719
	v_dual_fmac_f32 v32, v23, v4 :: v_dual_fmac_f32 v31, v25, v13// 000000063BA0: C8000917 201E1B19
	ds_load_b128 v[2:5], v1 offset:22656                       // 000000063BA8: DBFC5880 02000001
	v_fmac_f32_e32 v44, v25, v10                               // 000000063BB0: 56581519
	v_fmac_f32_e32 v29, v25, v53                               // 000000063BB4: 563A6B19
	v_fmac_f32_e32 v32, v25, v12                               // 000000063BB8: 56401919
	ds_load_b128 v[10:13], v1 offset:22592                     // 000000063BBC: DBFC5840 0A000001
	ds_load_b32 v18, v1 offset:22608                           // 000000063BC4: D8D85850 12000001
	ds_load_b64 v[53:54], v1 offset:22400                      // 000000063BCC: D9D85780 35000001
	v_fmac_f32_e32 v44, v27, v6                                // 000000063BD4: 56580D1B
	s_waitcnt lgkmcnt(3)                                       // 000000063BD8: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 000000063BDC: BF870001
	v_dual_fmac_f32 v44, v28, v2 :: v_dual_fmac_f32 v31, v27, v9// 000000063BE0: C800051C 2C1E131B
	v_fmac_f32_e32 v32, v27, v8                                // 000000063BE8: 5640111B
	v_fmac_f32_e32 v29, v27, v57                               // 000000063BEC: 563A731B
	v_fmac_f32_e32 v33, v27, v7                                // 000000063BF0: 56420F1B
	ds_load_b96 v[6:8], v1 offset:22464                        // 000000063BF4: DBF857C0 06000001
	ds_load_b32 v9, v1 offset:22336                            // 000000063BFC: D8D85740 09000001
	s_waitcnt lgkmcnt(4)                                       // 000000063C04: BF89FC47
	v_dual_fmac_f32 v31, v28, v5 :: v_dual_fmac_f32 v44, v30, v10// 000000063C08: C8000B1C 1F2C151E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000063C10: BF870001
	v_fmac_f32_e32 v31, v30, v13                               // 000000063C14: 563E1B1E
	v_fmac_f32_e32 v29, v28, v60                               // 000000063C18: 563A791C
	v_fmac_f32_e32 v33, v28, v3                                // 000000063C1C: 5642071C
	v_fmac_f32_e32 v32, v28, v4                                // 000000063C20: 5640091C
	ds_load_b128 v[2:5], v1 offset:24256                       // 000000063C24: DBFC5EC0 02000001
	ds_load_b128 v[57:60], v1 offset:24304                     // 000000063C2C: DBFC5EF0 39000001
	s_waitcnt lgkmcnt(5)                                       // 000000063C34: BF89FC57
	v_fmac_f32_e32 v29, v30, v18                               // 000000063C38: 563A251E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063C3C: BF870091
	v_dual_fmac_f32 v33, v30, v11 :: v_dual_fmac_f32 v44, v29, v14// 000000063C40: C800171E 212C1D1D
	v_dual_fmac_f32 v32, v30, v12 :: v_dual_fmac_f32 v33, v29, v15// 000000063C48: C800191E 20201F1D
	v_fmac_f32_e32 v31, v29, v17                               // 000000063C50: 563E231D
	s_waitcnt lgkmcnt(3)                                       // 000000063C54: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000063C58: BF870091
	v_dual_fmac_f32 v32, v29, v16 :: v_dual_fmac_f32 v33, v31, v7// 000000063C5C: C800211D 20200F1F
	v_fmac_f32_e32 v32, v31, v8                                // 000000063C64: 5640111F
	v_fmac_f32_e32 v44, v31, v6                                // 000000063C68: 56580D1F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000063C6C: BF870112
	v_fmac_f32_e32 v33, v32, v54                               // 000000063C70: 56426D20
	v_fmac_f32_e32 v44, v32, v53                               // 000000063C74: 56586B20
	ds_load_b128 v[53:56], v1 offset:24288                     // 000000063C78: DBFC5EE0 35000001
	s_waitcnt lgkmcnt(2)                                       // 000000063C80: BF89FC27
	v_fma_mixlo_f16 v18, v3, v33, 0                            // 000000063C84: CC210012 02024303
	v_fmac_f32_e32 v44, v33, v9                                // 000000063C8C: 56581321
	ds_load_b128 v[6:9], v1 offset:24272                       // 000000063C90: DBFC5ED0 06000001
	ds_load_b128 v[10:13], v1 offset:24112                     // 000000063C98: DBFC5E30 0A000001
	v_dual_mul_f32 v15, v3, v33 :: v_dual_mul_f32 v14, v2, v44 // 000000063CA0: C8C64303 0F0E5902
	v_fma_mixlo_f16 v2, v2, v44, 0                             // 000000063CA8: CC210002 02025902
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000063CB0: BF8701A2
	v_fma_mix_f32 v15, v18, -1.0, v15 op_sel_hi:[1,1,0]        // 000000063CB4: CC20000F 1C3DE712
	v_fma_mixlo_f16 v49, v5, v31, 0                            // 000000063CBC: CC210031 02023F05
	v_fma_mix_f32 v3, v2, -1.0, v14 op_sel_hi:[1,1,0]          // 000000063CC4: CC200003 1C39E702
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000063CCC: BF870233
	.long 0x7f1c150f                                           // 000000063CD0: 7F1C150F
	v_mul_f32_e32 v15, v4, v32                                 // 000000063CD4: 101E4104
	.long 0x7f043912                                           // 000000063CD8: 7F043912
	v_cvt_f16_f32_e32 v14, v3                                  // 000000063CDC: 7E1C1503
	v_fma_mixlo_f16 v3, v4, v32, 0                             // 000000063CE0: CC210003 02024104
	v_mul_f32_e32 v4, v5, v31                                  // 000000063CE8: 10083F05
	s_waitcnt lgkmcnt(2)                                       // 000000063CEC: BF89FC27
	v_fma_mixlo_f16 v150, v54, v23, 0                          // 000000063CF0: CC210096 02022F36
	s_waitcnt lgkmcnt(1)                                       // 000000063CF8: BF89FC17
	v_dual_mul_f32 v5, v6, v29 :: v_dual_mul_f32 v16, v7, v30  // 000000063CFC: C8C63B06 05103D07
	v_fma_mixlo_f16 v61, v7, v30, 0                            // 000000063D04: CC21003D 02023D07
	v_fma_mix_f32 v17, v49, -1.0, v4 op_sel_hi:[1,1,0]         // 000000063D0C: CC200011 1C11E731
	v_fma_mixlo_f16 v4, v6, v29, 0                             // 000000063D14: CC210004 02023B06
	v_fma_mix_f32 v7, v3, -1.0, v15 op_sel_hi:[1,1,0]          // 000000063D1C: CC200007 1C3DE703
	v_fma_mixlo_f16 v62, v9, v27, 0                            // 000000063D24: CC21003E 02023709
	v_fma_mix_f32 v6, v61, -1.0, v16 op_sel_hi:[1,1,0]         // 000000063D2C: CC200006 1C41E73D
	.long 0x7f1e1511                                           // 000000063D34: 7F1E1511
	v_fma_mix_f32 v5, v4, -1.0, v5 op_sel_hi:[1,1,0]           // 000000063D38: CC200005 1C15E704
	v_cvt_f16_f32_e32 v15, v7                                  // 000000063D40: 7E1E1507
	v_mul_f32_e32 v7, v8, v28                                  // 000000063D44: 100E3908
	.long 0x7f201506                                           // 000000063D48: 7F201506
	v_fma_mixlo_f16 v6, v53, v25, 0                            // 000000063D4C: CC210006 02023335
	v_cvt_f16_f32_e32 v16, v5                                  // 000000063D54: 7E201505
	v_fma_mixlo_f16 v5, v8, v28, 0                             // 000000063D58: CC210005 02023908
	v_mul_f32_e32 v8, v9, v27                                  // 000000063D60: 10103709
	v_mul_f32_e32 v9, v53, v25                                 // 000000063D64: 10123335
	v_dual_mul_f32 v53, v54, v23 :: v_dual_mul_f32 v54, v55, v26// 000000063D68: C8C62F36 35363537
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000063D70: BF870214
	v_fma_mix_f32 v7, v5, -1.0, v7 op_sel_hi:[1,1,0]           // 000000063D74: CC200007 1C1DE705
	v_fma_mix_f32 v8, v62, -1.0, v8 op_sel_hi:[1,1,0]          // 000000063D7C: CC200008 1C21E73E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000063D84: BF870214
	v_fma_mix_f32 v9, v6, -1.0, v9 op_sel_hi:[1,1,0]           // 000000063D88: CC200009 1C25E706
	v_fma_mix_f32 v151, v150, -1.0, v53 op_sel_hi:[1,1,0]      // 000000063D90: CC200097 1CD5E796
	v_mul_f32_e32 v153, v59, v21                               // 000000063D98: 11322B3B
	v_cvt_f16_f32_e32 v17, v7                                  // 000000063D9C: 7E221507
	v_fma_mixlo_f16 v7, v55, v26, 0                            // 000000063DA0: CC210007 02023537
	.long 0x7f221508                                           // 000000063DA8: 7F221508
	v_cvt_f16_f32_e32 v53, v9                                  // 000000063DAC: 7E6A1509
	.long 0xd58a4035                                           // 000000063DB0: D58A4035
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 000000063DB4: 02010197
	v_mul_f32_e32 v9, v56, v24                                 // 000000063DB8: 10123138
	v_fma_mix_f32 v8, v7, -1.0, v54 op_sel_hi:[1,1,0]          // 000000063DBC: CC200008 1CD9E707
	v_fma_mixlo_f16 v151, v56, v24, 0                          // 000000063DC4: CC210097 02023138
	v_dual_mul_f32 v55, v57, v20 :: v_dual_mul_f32 v56, v58, v22// 000000063DCC: C8C62939 37382D3A
	v_fma_mixlo_f16 v58, v58, v22, 0                           // 000000063DD4: CC21003A 02022D3A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000063DDC: BF870214
	v_cvt_f16_f32_e32 v54, v8                                  // 000000063DE0: 7E6C1508
	v_fma_mix_f32 v152, v151, -1.0, v9 op_sel_hi:[1,1,0]       // 000000063DE4: CC200098 1C25E797
	v_fma_mixlo_f16 v8, v57, v20, 0                            // 000000063DEC: CC210008 02022939
	v_fma_mixlo_f16 v9, v59, v21, 0                            // 000000063DF4: CC210009 02022B3B
	v_fma_mix_f32 v56, v58, -1.0, v56 op_sel_hi:[1,1,0]        // 000000063DFC: CC200038 1CE1E73A
	v_mul_f32_e32 v59, v60, v19                                // 000000063E04: 1076273C
	v_fma_mixlo_f16 v60, v60, v19, 0                           // 000000063E08: CC21003C 0202273C
	v_fma_mix_f32 v55, v8, -1.0, v55 op_sel_hi:[1,1,0]         // 000000063E10: CC200037 1CDDE708
	v_fma_mix_f32 v57, v9, -1.0, v153 op_sel_hi:[1,1,0]        // 000000063E18: CC200039 1E65E709
	.long 0xd58a4036                                           // 000000063E20: D58A4036
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 000000063E24: 02010198
	.long 0x7f10393a                                           // 000000063E28: 7F10393A
	v_fma_mix_f32 v152, v60, -1.0, v59 op_sel_hi:[1,1,0]       // 000000063E2C: CC200098 1CEDE73C
	v_cvt_f16_f32_e32 v55, v55                                 // 000000063E34: 7E6E1537
	.long 0x7f6e1538                                           // 000000063E38: 7F6E1538
	v_cvt_f16_f32_e32 v56, v57                                 // 000000063E3C: 7E701539
	.long 0x7f12393c                                           // 000000063E40: 7F12393C
	ds_load_b128 v[57:60], v1 offset:24080                     // 000000063E44: DBFC5E10 39000001
	v_mul_u32_u24_e32 v153, 48, v43                            // 000000063E4C: 173256B0
	.long 0xd59c4006                                           // 000000063E50: D59C4006
	v_cndmask_b32_e32 v0, v150, v128, vcc_lo                   // 000000063E54: 02010196
	.long 0xd59c4007                                           // 000000063E58: D59C4007
	v_cndmask_b32_e32 v0, v151, v128, vcc_lo                   // 000000063E5C: 02010197
	.long 0x7f063931                                           // 000000063E60: 7F063931
	.long 0x7f08393d                                           // 000000063E64: 7F08393D
	.long 0x7f0a393e                                           // 000000063E68: 7F0A393E
	v_mul_f32_e32 v18, v45, v44                                // 000000063E6C: 1024592D
	v_fma_mixlo_f16 v43, v45, v44, 0                           // 000000063E70: CC21002B 0202592D
	v_mul_f32_e32 v44, v46, v33                                // 000000063E78: 1058432E
	v_fma_mixlo_f16 v33, v46, v33, 0                           // 000000063E7C: CC210021 0202432E
	ds_store_b128 v153, v[6:9] offset:19216                    // 000000063E84: DB7C4B10 00000699
	ds_store_b128 v153, v[2:5] offset:19200                    // 000000063E8C: DB7C4B00 00000299
	ds_load_b128 v[2:5], v1 offset:24096                       // 000000063E94: DBFC5E20 02000001
	v_fma_mix_f32 v18, v43, -1.0, v18 op_sel_hi:[1,1,0]        // 000000063E9C: CC200012 1C49E72B
	v_dual_mul_f32 v7, v47, v32 :: v_dual_mul_f32 v8, v48, v31 // 000000063EA4: C8C6412F 07083F30
	v_fma_mix_f32 v44, v33, -1.0, v44 op_sel_hi:[1,1,0]        // 000000063EAC: CC20002C 1CB1E721
	.long 0xd58a4038                                           // 000000063EB4: D58A4038
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 000000063EB8: 02010198
	s_delay_alu instid0(VALU_DEP_4)                            // 000000063EBC: BF870004
	v_cvt_f16_f32_e32 v6, v18                                  // 000000063EC0: 7E0C1512
	v_fma_mixlo_f16 v18, v48, v31, 0                           // 000000063EC4: CC210012 02023F30
	s_waitcnt lgkmcnt(3)                                       // 000000063ECC: BF89FC37
	v_mul_f32_e32 v9, v57, v29                                 // 000000063ED0: 10123B39
	.long 0x7f0c152c                                           // 000000063ED4: 7F0C152C
	v_fma_mixlo_f16 v44, v47, v32, 0                           // 000000063ED8: CC21002C 0202412F
	v_mul_f32_e32 v31, v58, v30                                // 000000063EE0: 103E3D3A
	v_fma_mixlo_f16 v30, v58, v30, 0                           // 000000063EE4: CC21001E 02023D3A
	v_fma_mixlo_f16 v45, v57, v29, 0                           // 000000063EEC: CC21002D 02023B39
	v_fma_mix_f32 v8, v18, -1.0, v8 op_sel_hi:[1,1,0]          // 000000063EF4: CC200008 1C21E712
	v_fma_mix_f32 v7, v44, -1.0, v7 op_sel_hi:[1,1,0]          // 000000063EFC: CC200007 1C1DE72C
	v_fma_mixlo_f16 v46, v59, v28, 0                           // 000000063F04: CC21002E 0202393B
	v_fma_mix_f32 v29, v30, -1.0, v31 op_sel_hi:[1,1,0]        // 000000063F0C: CC20001D 1C7DE71E
	v_dual_mul_f32 v31, v59, v28 :: v_dual_mul_f32 v28, v60, v27// 000000063F14: C8C6393B 1F1C373C
	v_fma_mix_f32 v9, v45, -1.0, v9 op_sel_hi:[1,1,0]          // 000000063F1C: CC200009 1C25E72D
	v_fma_mixlo_f16 v27, v60, v27, 0                           // 000000063F24: CC21001B 0202373C
	v_cvt_f16_f32_e32 v7, v7                                   // 000000063F2C: 7E0E1507
	.long 0x7f0e1508                                           // 000000063F30: 7F0E1508
	.long 0x7f10151d                                           // 000000063F34: 7F10151D
	v_cvt_f16_f32_e32 v8, v9                                   // 000000063F38: 7E101509
	v_fma_mix_f32 v9, v46, -1.0, v31 op_sel_hi:[1,1,0]         // 000000063F3C: CC200009 1C7DE72E
	s_waitcnt lgkmcnt(0)                                       // 000000063F44: BF89FC07
	v_mul_f32_e32 v29, v2, v25                                 // 000000063F48: 103A3302
	v_fma_mixlo_f16 v2, v2, v25, 0                             // 000000063F4C: CC210002 02023302
	v_mul_f32_e32 v25, v3, v23                                 // 000000063F54: 10322F03
	v_fma_mixlo_f16 v31, v3, v23, 0                            // 000000063F58: CC21001F 02022F03
	v_fma_mix_f32 v3, v27, -1.0, v28 op_sel_hi:[1,1,0]         // 000000063F60: CC200003 1C71E71B
	v_cvt_f16_f32_e32 v9, v9                                   // 000000063F68: 7E121509
	v_mul_f32_e32 v23, v4, v26                                 // 000000063F6C: 102E3504
	.long 0x7f563921                                           // 000000063F70: 7F563921
	v_fma_mix_f32 v25, v31, -1.0, v25 op_sel_hi:[1,1,0]        // 000000063F74: CC200019 1C65E71F
	.long 0x7f121503                                           // 000000063F7C: 7F121503
	v_fma_mixlo_f16 v3, v4, v26, 0                             // 000000063F80: CC210003 02023504
	v_mul_f32_e32 v26, v11, v22                                // 000000063F88: 10342D0B
	v_fma_mix_f32 v28, v2, -1.0, v29 op_sel_hi:[1,1,0]         // 000000063F8C: CC20001C 1C75E702
	v_fma_mixlo_f16 v11, v11, v22, 0                           // 000000063F94: CC21000B 02022D0B
	.long 0x7f04391f                                           // 000000063F9C: 7F04391F
	v_fma_mix_f32 v4, v3, -1.0, v23 op_sel_hi:[1,1,0]          // 000000063FA0: CC200004 1C5DE703
	.long 0x7f2e1519                                           // 000000063FA8: 7F2E1519
	v_cvt_f16_f32_e32 v23, v28                                 // 000000063FAC: 7E2E151C
	v_mul_f32_e32 v25, v5, v24                                 // 000000063FB0: 10323105
	v_fma_mixlo_f16 v28, v5, v24, 0                            // 000000063FB4: CC21001C 02023105
	v_cvt_f16_f32_e32 v24, v4                                  // 000000063FBC: 7E301504
	v_mul_f32_e32 v5, v10, v20                                 // 000000063FC0: 100A290A
	v_fma_mixlo_f16 v4, v10, v20, 0                            // 000000063FC4: CC210004 0202290A
	v_fma_mix_f32 v20, v11, -1.0, v26 op_sel_hi:[1,1,0]        // 000000063FCC: CC200014 1C69E70B
	v_fma_mix_f32 v22, v28, -1.0, v25 op_sel_hi:[1,1,0]        // 000000063FD4: CC200016 1C65E71C
	v_mul_f32_e32 v25, v12, v21                                // 000000063FDC: 10322B0C
	.long 0x7f06391c                                           // 000000063FE0: 7F06391C
	v_fma_mix_f32 v10, v4, -1.0, v5 op_sel_hi:[1,1,0]          // 000000063FE4: CC20000A 1C15E704
	v_fma_mixlo_f16 v5, v12, v21, 0                            // 000000063FEC: CC210005 02022B0C
	v_mul_f32_e32 v21, v13, v19                                // 000000063FF4: 102A270D
	v_fma_mixlo_f16 v13, v13, v19, 0                           // 000000063FF8: CC21000D 0202270D
	.long 0x7f08390b                                           // 000000064000: 7F08390B
	.long 0x7f583912                                           // 000000064004: 7F583912
	v_fma_mix_f32 v12, v5, -1.0, v25 op_sel_hi:[1,1,0]         // 000000064008: CC20000C 1C65E705
	v_cvt_f16_f32_e32 v25, v10                                 // 000000064010: 7E32150A
	v_fma_mix_f32 v10, v13, -1.0, v21 op_sel_hi:[1,1,0]        // 000000064014: CC20000A 1C55E70D
	.long 0x7f0a390d                                           // 00000006401C: 7F0A390D
	.long 0x7f5a391e                                           // 000000064020: 7F5A391E
	.long 0x7f5c391b                                           // 000000064024: 7F5C391B
	.long 0x7f301516                                           // 000000064028: 7F301516
	.long 0x7f321514                                           // 00000006402C: 7F321514
	v_cvt_f16_f32_e32 v26, v12                                 // 000000064030: 7E34150C
	.long 0x7f34150a                                           // 000000064034: 7F34150A
	ds_store_b128 v153, v[53:56] offset:19984                  // 000000064038: DB7C4E10 00003599
	ds_store_b128 v153, v[14:17] offset:19968                  // 000000064040: DB7C4E00 00000E99
	ds_store_b128 v153, v[2:5] offset:20752                    // 000000064048: DB7C5110 00000299
	ds_store_b128 v153, v[43:46] offset:20736                  // 000000064050: DB7C5100 00002B99
	ds_store_b128 v153, v[23:26] offset:21520                  // 000000064058: DB7C5410 00001799
	ds_store_b128 v153, v[6:9] offset:21504                    // 000000064060: DB7C5400 00000699
	s_or_b32 exec_lo, exec_lo, s0                              // 000000064068: 8C7E007E
	v_lshlrev_b32_e32 v53, 1, v148                             // 00000006406C: 306B2881
	s_waitcnt lgkmcnt(0)                                       // 000000064070: BF89FC07
	s_barrier                                                  // 000000064074: BFBD0000
	v_cmp_eq_u32_e32 vcc_lo, 0, v34                            // 000000064078: 7C944480
	v_mul_u32_u24_e32 v54, 48, v50                             // 00000006407C: 166C64B0
	s_cmp_lt_i32 s54, s35                                      // 000000064080: BF042336
	ds_load_u16 v2, v53 offset:6416                            // 000000064084: D8F01910 02000035
	ds_load_u16 v3, v53 offset:7776                            // 00000006408C: D8F01E60 03000035
	ds_load_u16 v4, v53 offset:7232                            // 000000064094: D8F01C40 04000035
	s_waitcnt lgkmcnt(4)                                       // 00000006409C: BF89FC47
	ds_load_u16 v5, v53 offset:6688                            // 0000000640A0: D8F01A20 05000035
	s_waitcnt lgkmcnt(4)                                       // 0000000640A8: BF89FC47
	ds_load_u16 v6, v53 offset:6144                            // 0000000640AC: D8F01800 06000035
	ds_load_b128 v[22:25], v54 offset:19984                    // 0000000640B4: DBFC4E10 16000036
	ds_load_b128 v[18:21], v54 offset:19968                    // 0000000640BC: DBFC4E00 12000036
	ds_load_b128 v[26:29], v54 offset:19200                    // 0000000640C4: DBFC4B00 1A000036
	ds_load_b128 v[30:33], v54 offset:19216                    // 0000000640CC: DBFC4B10 1E000036
	s_cselect_b32 s0, -1, 0                                    // 0000000640D4: 980080C1
	s_or_b32 s1, s54, 1                                        // 0000000640D8: 8C018136
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000640DC: BF870009
	s_cmp_lt_i32 s1, s35                                       // 0000000640E0: BF042301
	s_cselect_b32 s1, -1, 0                                    // 0000000640E4: 980180C1
	s_waitcnt lgkmcnt(8)                                       // 0000000640E8: BF89FC87
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000640EC: 30040490
	s_waitcnt lgkmcnt(4)                                       // 0000000640F0: BF89FC47
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000000640F4: 300C0C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000640F8: BF8700D2
	.long 0x7f141502                                           // 0000000640FC: 7F141502
	ds_load_u16 v2, v53 offset:6960                            // 000000064100: D8F01B30 02000035
	v_cvt_f16_f32_e32 v10, v6                                  // 000000064108: 7E141506
	s_waitcnt lgkmcnt(0)                                       // 00000006410C: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000064110: 30040490
	.long 0x7f161502                                           // 000000064114: 7F161502
	v_lshlrev_b32_e32 v2, 16, v5                               // 000000064118: 30040A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000006411C: BF8700C1
	v_cvt_f16_f32_e32 v11, v2                                  // 000000064120: 7E161502
	ds_load_u16 v2, v53 offset:7504                            // 000000064124: D8F01D50 02000035
	s_waitcnt lgkmcnt(0)                                       // 00000006412C: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000064130: 30040490
	.long 0x7f181502                                           // 000000064134: 7F181502
	v_lshlrev_b32_e32 v2, 16, v4                               // 000000064138: 30040890
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000006413C: BF8700C1
	v_cvt_f16_f32_e32 v12, v2                                  // 000000064140: 7E181502
	ds_load_u16 v2, v53 offset:8048                            // 000000064144: D8F01F70 02000035
	s_waitcnt lgkmcnt(0)                                       // 00000006414C: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000064150: 30040490
	.long 0x7f1a1502                                           // 000000064154: 7F1A1502
	v_lshlrev_b32_e32 v2, 16, v3                               // 000000064158: 30040690
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006415C: BF870001
	v_cvt_f16_f32_e32 v13, v2                                  // 000000064160: 7E1A1502
	ds_load_u16 v2, v53 offset:8592                            // 000000064164: D8F02190 02000035
	ds_load_u16 v3, v53 offset:9952                            // 00000006416C: D8F026E0 03000035
	ds_load_u16 v4, v53 offset:9408                            // 000000064174: D8F024C0 04000035
	ds_load_u16 v5, v53 offset:8864                            // 00000006417C: D8F022A0 05000035
	ds_load_u16 v6, v53 offset:8320                            // 000000064184: D8F02080 06000035
	s_waitcnt lgkmcnt(4)                                       // 00000006418C: BF89FC47
	v_lshlrev_b32_e32 v2, 16, v2                               // 000000064190: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000064194: BF8700B1
	.long 0x7f1c1502                                           // 000000064198: 7F1C1502
	s_waitcnt lgkmcnt(0)                                       // 00000006419C: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v6                               // 0000000641A0: 30040C90
	v_cvt_f16_f32_e32 v14, v2                                  // 0000000641A4: 7E1C1502
	ds_load_u16 v2, v53 offset:9136                            // 0000000641A8: D8F023B0 02000035
	s_waitcnt lgkmcnt(0)                                       // 0000000641B0: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000641B4: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000641B8: BF8700A1
	.long 0x7f1e1502                                           // 0000000641BC: 7F1E1502
	v_lshlrev_b32_e32 v2, 16, v5                               // 0000000641C0: 30040A90
	v_cvt_f16_f32_e32 v15, v2                                  // 0000000641C4: 7E1E1502
	ds_load_u16 v2, v53 offset:9680                            // 0000000641C8: D8F025D0 02000035
	s_waitcnt lgkmcnt(0)                                       // 0000000641D0: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000641D4: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000641D8: BF8700A1
	.long 0x7f201502                                           // 0000000641DC: 7F201502
	v_lshlrev_b32_e32 v2, 16, v4                               // 0000000641E0: 30040890
	v_cvt_f16_f32_e32 v16, v2                                  // 0000000641E4: 7E201502
	ds_load_u16 v2, v53 offset:10224                           // 0000000641E8: D8F027F0 02000035
	s_waitcnt lgkmcnt(0)                                       // 0000000641F0: BF89FC07
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000000641F4: 30040490
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000641F8: BF8700A1
	.long 0x7f221502                                           // 0000000641FC: 7F221502
	v_lshlrev_b32_e32 v2, 16, v3                               // 000000064200: 30040690
	v_cvt_f16_f32_e32 v17, v2                                  // 000000064204: 7E221502
	v_dual_mov_b32 v2, s16 :: v_dual_mov_b32 v3, s17           // 000000064208: CA100010 02020011
	v_dual_mov_b32 v4, s18 :: v_dual_mov_b32 v5, s19           // 000000064210: CA100012 04040013
	v_dual_mov_b32 v6, s20 :: v_dual_mov_b32 v7, s21           // 000000064218: CA100014 06060015
	v_dual_mov_b32 v8, s22 :: v_dual_mov_b32 v9, s23           // 000000064220: CA100016 08080017
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000064228: BF870121
	v_wmma_f32_16x16x16_f16 v[55:62], v[18:25], v[10:17], v[2:9]// 00000006422C: CC404037 1C0A1512
	v_mov_b32_e32 v18, 0                                       // 000000064234: 7E240280
	v_wmma_f32_16x16x16_f16 v[55:62], v[26:33], v[10:17], v[55:62]// 000000064238: CC404037 1CDE151A
	v_dual_mov_b32 v10, 0 :: v_dual_cndmask_b32 v11, 0x7060302, v138// 000000064240: CA120080 0A0B14FF 07060302
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v13, 0             // 00000006424C: CA100080 0C0C0080
	v_mov_b32_e32 v14, 0                                       // 000000064254: 7E1C0280
	s_waitcnt vmcnt(7)                                         // 000000064258: BF891FF7
	s_delay_alu instid0(VALU_DEP_3)                            // 00000006425C: BF870003
	v_mov_b32_dpp v10, v42 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000064260: 7E1402FA FF00B12A
	v_dual_mov_b32 v15, 0 :: v_dual_mov_b32 v16, 0             // 000000064268: CA100080 0F100080
	v_mov_b32_e32 v17, 0                                       // 000000064270: 7E220280
	s_waitcnt vmcnt(6)                                         // 000000064274: BF891BF7
	v_mov_b32_dpp v12, v41 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000064278: 7E1802FA FF00B129
	v_perm_b32 v10, v42, v10, v11                              // 000000064280: D644000A 042E152A
	s_waitcnt vmcnt(5)                                         // 000000064288: BF8917F7
	v_mov_b32_dpp v13, v40 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000006428C: 7E1A02FA FF00B128
	s_waitcnt vmcnt(4)                                         // 000000064294: BF8913F7
	v_mov_b32_dpp v14, v39 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 000000064298: 7E1C02FA FF00B127
	s_waitcnt vmcnt(3)                                         // 0000000642A0: BF890FF7
	v_mov_b32_dpp v15, v38 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000642A4: 7E1E02FA FF00B126
	s_waitcnt vmcnt(2)                                         // 0000000642AC: BF890BF7
	v_mov_b32_dpp v16, v37 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000642B0: 7E2002FA FF00B125
	s_waitcnt vmcnt(1)                                         // 0000000642B8: BF8907F7
	v_mov_b32_dpp v17, v35 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000642BC: 7E2202FA FF00B123
	s_waitcnt vmcnt(0)                                         // 0000000642C4: BF8903F7
	v_mov_b32_dpp v18, v36 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 0000000642C8: 7E2402FA FF00B124
	v_perm_b32 v12, v41, v12, v11                              // 0000000642D0: D644000C 042E1929
	v_perm_b32 v13, v40, v13, v11                              // 0000000642D8: D644000D 042E1B28
	v_perm_b32 v14, v39, v14, v11                              // 0000000642E0: D644000E 042E1D27
	v_perm_b32 v15, v38, v15, v11                              // 0000000642E8: D644000F 042E1F26
	v_perm_b32 v16, v37, v16, v11                              // 0000000642F0: D6440010 042E2125
	v_perm_b32 v17, v35, v17, v11                              // 0000000642F8: D6440011 042E2323
	v_perm_b32 v11, v36, v18, v11                              // 000000064300: D644000B 042E2524
	v_lshlrev_b32_e32 v18, 16, v10                             // 000000064308: 30241490
	v_and_b32_e32 v19, 0xffff0000, v10                         // 00000006430C: 362614FF FFFF0000
	ds_load_b128 v[30:33], v54 offset:21520                    // 000000064314: DBFC5410 1E000036
	ds_load_b128 v[26:29], v54 offset:21504                    // 00000006431C: DBFC5400 1A000036
	ds_load_b128 v[38:41], v54 offset:20752                    // 000000064324: DBFC5110 26000036
	ds_load_b128 v[34:37], v54 offset:20736                    // 00000006432C: DBFC5100 22000036
	v_cmp_eq_u32_e32 vcc_lo, 0, v149                           // 000000064334: 7C952A80
	v_cvt_f16_f32_e32 v10, v18                                 // 000000064338: 7E141512
	.long 0x7f141513                                           // 00000006433C: 7F141513
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000064340: BF870112
	v_cndmask_b16 v18, 0, v10, s0                              // 000000064344: D65D0012 00021480
	v_cndmask_b16 v18, 0, v10, s1                              // 00000006434C: D65D5012 00061480
	v_lshlrev_b32_e32 v10, 16, v12                             // 000000064354: 30141890
	s_or_b32 s0, s54, 2                                        // 000000064358: 8C008236
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006435C: BF870099
	s_cmp_lt_i32 s0, s35                                       // 000000064360: BF042300
	v_cvt_f16_f32_e32 v10, v10                                 // 000000064364: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 000000064368: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000006436C: BF870481
	v_cndmask_b16 v19, 0, v10, s0                              // 000000064370: D65D0013 00021480
	v_and_b32_e32 v10, 0xffff0000, v12                         // 000000064378: 361418FF FFFF0000
	s_or_b32 s0, s54, 3                                        // 000000064380: 8C008336
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064384: BF870099
	s_cmp_lt_i32 s0, s35                                       // 000000064388: BF042300
	v_cvt_f16_f32_e32 v10, v10                                 // 00000006438C: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 000000064390: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000064394: BF870481
	v_cndmask_b16 v19, 0, v10, s0                              // 000000064398: D65D4013 00021480
	v_lshlrev_b32_e32 v10, 16, v13                             // 0000000643A0: 30141A90
	s_or_b32 s0, s54, 4                                        // 0000000643A4: 8C008436
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000643A8: BF870099
	s_cmp_lt_i32 s0, s35                                       // 0000000643AC: BF042300
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000643B0: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 0000000643B4: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000643B8: BF870481
	v_cndmask_b16 v20, 0, v10, s0                              // 0000000643BC: D65D0014 00021480
	v_and_b32_e32 v10, 0xffff0000, v13                         // 0000000643C4: 36141AFF FFFF0000
	s_or_b32 s0, s54, 5                                        // 0000000643CC: 8C008536
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000643D0: BF870099
	s_cmp_lt_i32 s0, s35                                       // 0000000643D4: BF042300
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000643D8: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 0000000643DC: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000643E0: BF870481
	v_cndmask_b16 v20, 0, v10, s0                              // 0000000643E4: D65D4014 00021480
	v_lshlrev_b32_e32 v10, 16, v14                             // 0000000643EC: 30141C90
	s_or_b32 s0, s54, 6                                        // 0000000643F0: 8C008636
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000643F4: BF870099
	s_cmp_lt_i32 s0, s35                                       // 0000000643F8: BF042300
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000643FC: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 000000064400: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000064404: BF870481
	v_cndmask_b16 v21, 0, v10, s0                              // 000000064408: D65D0015 00021480
	v_and_b32_e32 v10, 0xffff0000, v14                         // 000000064410: 36141CFF FFFF0000
	s_or_b32 s0, s54, 7                                        // 000000064418: 8C008736
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006441C: BF870099
	s_cmp_lt_i32 s0, s35                                       // 000000064420: BF042300
	v_cvt_f16_f32_e32 v10, v10                                 // 000000064424: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 000000064428: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000006442C: BF870481
	v_cndmask_b16 v21, 0, v10, s0                              // 000000064430: D65D4015 00021480
	v_lshlrev_b32_e32 v10, 16, v15                             // 000000064438: 30141E90
	s_or_b32 s0, s54, 8                                        // 00000006443C: 8C008836
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064440: BF870099
	s_cmp_lt_i32 s0, s35                                       // 000000064444: BF042300
	v_cvt_f16_f32_e32 v10, v10                                 // 000000064448: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000006444C: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000064450: BF870481
	v_cndmask_b16 v22, 0, v10, s0                              // 000000064454: D65D0016 00021480
	v_and_b32_e32 v10, 0xffff0000, v15                         // 00000006445C: 36141EFF FFFF0000
	s_or_b32 s0, s54, 9                                        // 000000064464: 8C008936
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064468: BF870099
	s_cmp_lt_i32 s0, s35                                       // 00000006446C: BF042300
	v_cvt_f16_f32_e32 v10, v10                                 // 000000064470: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 000000064474: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000064478: BF870481
	v_cndmask_b16 v22, 0, v10, s0                              // 00000006447C: D65D4016 00021480
	v_lshlrev_b32_e32 v10, 16, v16                             // 000000064484: 30142090
	s_or_b32 s0, s54, 10                                       // 000000064488: 8C008A36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006448C: BF870099
	s_cmp_lt_i32 s0, s35                                       // 000000064490: BF042300
	v_cvt_f16_f32_e32 v10, v10                                 // 000000064494: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 000000064498: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000006449C: BF870481
	v_cndmask_b16 v23, 0, v10, s0                              // 0000000644A0: D65D0017 00021480
	v_and_b32_e32 v10, 0xffff0000, v16                         // 0000000644A8: 361420FF FFFF0000
	s_or_b32 s0, s54, 11                                       // 0000000644B0: 8C008B36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000644B4: BF870099
	s_cmp_lt_i32 s0, s35                                       // 0000000644B8: BF042300
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000644BC: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 0000000644C0: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000644C4: BF870481
	v_cndmask_b16 v23, 0, v10, s0                              // 0000000644C8: D65D4017 00021480
	v_lshlrev_b32_e32 v10, 16, v17                             // 0000000644D0: 30142290
	s_or_b32 s0, s54, 12                                       // 0000000644D4: 8C008C36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000644D8: BF870099
	s_cmp_lt_i32 s0, s35                                       // 0000000644DC: BF042300
	v_cvt_f16_f32_e32 v10, v10                                 // 0000000644E0: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 0000000644E4: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 0000000644E8: BF870481
	v_cndmask_b16 v24, 0, v10, s0                              // 0000000644EC: D65D0018 00021480
	v_and_b32_e32 v10, 0xffff0000, v17                         // 0000000644F4: 361422FF FFFF0000
	s_or_b32 s0, s54, 13                                       // 0000000644FC: 8C008D36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064500: BF870099
	s_cmp_lt_i32 s0, s35                                       // 000000064504: BF042300
	v_cvt_f16_f32_e32 v10, v10                                 // 000000064508: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 00000006450C: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000064510: BF870481
	v_cndmask_b16 v24, 0, v10, s0                              // 000000064514: D65D4018 00021480
	v_lshlrev_b32_e32 v10, 16, v11                             // 00000006451C: 30141690
	s_or_b32 s0, s54, 14                                       // 000000064520: 8C008E36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064524: BF870099
	s_cmp_lt_i32 s0, s35                                       // 000000064528: BF042300
	v_cvt_f16_f32_e32 v10, v10                                 // 00000006452C: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 000000064530: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 000000064534: BF870481
	v_cndmask_b16 v25, 0, v10, s0                              // 000000064538: D65D0019 00021480
	v_and_b32_e32 v10, 0xffff0000, v11                         // 000000064540: 361416FF FFFF0000
	s_or_b32 s0, s54, 15                                       // 000000064548: 8C008F36
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006454C: BF870099
	s_cmp_lt_i32 s0, s35                                       // 000000064550: BF042300
	v_cvt_f16_f32_e32 v10, v10                                 // 000000064554: 7E14150A
	s_cselect_b32 s0, -1, 0                                    // 000000064558: 980080C1
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_1)    // 00000006455C: BF870481
	v_cndmask_b16 v25, 0, v10, s0                              // 000000064560: D65D4019 00021480
	s_waitcnt lgkmcnt(2)                                       // 000000064568: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006456C: BF8700A1
	v_wmma_f32_16x16x16_f16 v[10:17], v[26:33], v[18:25], v[2:9]// 000000064570: CC40400A 1C0A251A
	s_waitcnt lgkmcnt(0)                                       // 000000064578: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[34:41], v[18:25], v[10:17]// 00000006457C: CC40400A 1C2A2522
	v_cvt_f16_f32_e32 v18, v55                                 // 000000064584: 7E241537
	v_mad_u32_u24 v22, 0x110, v149, v53                        // 000000064588: D60B0016 04D72AFF 00000110
	.long 0x7f241538                                           // 000000064594: 7F241538
	v_cvt_f16_f32_e32 v19, v57                                 // 000000064598: 7E261539
	.long 0x7f26153a                                           // 00000006459C: 7F26153A
	v_cvt_f16_f32_e32 v20, v59                                 // 0000000645A0: 7E28153B
	.long 0x7f28153c                                           // 0000000645A4: 7F28153C
	v_cvt_f16_f32_e32 v21, v61                                 // 0000000645A8: 7E2A153D
	.long 0x7f2a153e                                           // 0000000645AC: 7F2A153E
	ds_store_b16 v22, v18 offset:14848                         // 0000000645B0: D87C3A00 00001216
	ds_store_b16_d16_hi v22, v18 offset:15392                  // 0000000645B8: DA843C20 00001216
	ds_store_b16 v22, v19 offset:15936                         // 0000000645C0: D87C3E40 00001316
	ds_store_b16_d16_hi v22, v19 offset:16480                  // 0000000645C8: DA844060 00001316
	ds_store_b16 v22, v20 offset:17024                         // 0000000645D0: D87C4280 00001416
	ds_store_b16_d16_hi v22, v20 offset:17568                  // 0000000645D8: DA8444A0 00001416
	ds_store_b16 v22, v21 offset:18112                         // 0000000645E0: D87C46C0 00001516
	ds_store_b16_d16_hi v22, v21 offset:18656                  // 0000000645E8: DA8448E0 00001516
	v_fma_mixlo_f16 v18, v128, s51, 0                          // 0000000645F0: CC210012 02006780
	v_fma_mixhi_f16 v18, v127, s51, 0                          // 0000000645F8: CC220012 0200677F
	v_cndmask_b32_e32 v61, 0x5040100, v138, vcc_lo             // 000000064600: 027B14FF 05040100
	v_cndmask_b32_e32 v62, 0x7060302, v139, vcc_lo             // 000000064608: 027D16FF 07060302
	s_waitcnt lgkmcnt(0)                                       // 000000064610: BF89FC07
	s_barrier                                                  // 000000064614: BFBD0000
	ds_load_b128 v[46:49], v52 offset:14864                    // 000000064618: DBFC3A10 2E000034
	ds_load_b128 v[42:45], v52 offset:14848                    // 000000064620: DBFC3A00 2A000034
	ds_load_b128 v[154:157], v52 offset:14896                  // 000000064628: DBFC3A30 9A000034
	ds_load_b128 v[150:153], v52 offset:14880                  // 000000064630: DBFC3A20 96000034
	v_mov_b32_e32 v19, v18                                     // 000000064638: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006463C: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000064640: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v26, v18, v19, v61                              // 00000006464C: D644001A 04F62712
	v_perm_b32 v27, v18, v19, v62                              // 000000064654: D644001B 04FA2712
	v_fma_mixlo_f16 v18, v126, s51, 0                          // 00000006465C: CC210012 0200677E
	v_fma_mixhi_f16 v18, v125, s51, 0                          // 000000064664: CC220012 0200677D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006466C: BF870091
	v_mov_b32_e32 v19, v18                                     // 000000064670: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000064674: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000064680: BF8700C1
	v_perm_b32 v28, v18, v19, v61                              // 000000064684: D644001C 04F62712
	v_perm_b32 v29, v18, v19, v62                              // 00000006468C: D644001D 04FA2712
	v_fma_mixlo_f16 v18, v124, s51, 0                          // 000000064694: CC210012 0200677C
	v_fma_mixhi_f16 v18, v123, s51, 0                          // 00000006469C: CC220012 0200677B
	v_mov_b32_e32 v19, v18                                     // 0000000646A4: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000646A8: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 0000000646AC: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v30, v18, v19, v61                              // 0000000646B8: D644001E 04F62712
	v_perm_b32 v31, v18, v19, v62                              // 0000000646C0: D644001F 04FA2712
	v_fma_mixlo_f16 v18, v122, s51, 0                          // 0000000646C8: CC210012 0200677A
	v_fma_mixhi_f16 v18, v147, s51, 0                          // 0000000646D0: CC220012 02006793
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000646D8: BF870091
	v_mov_b32_e32 v19, v18                                     // 0000000646DC: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 0000000646E0: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000646EC: BF8700C1
	v_perm_b32 v32, v18, v19, v61                              // 0000000646F0: D6440020 04F62712
	v_perm_b32 v33, v18, v19, v62                              // 0000000646F8: D6440021 04FA2712
	v_fma_mixlo_f16 v18, v121, s51, 0                          // 000000064700: CC210012 02006779
	v_fma_mixhi_f16 v18, v120, s51, 0                          // 000000064708: CC220012 02006778
	v_mov_b32_e32 v19, v18                                     // 000000064710: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064714: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000064718: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v34, v18, v19, v61                              // 000000064724: D6440022 04F62712
	v_perm_b32 v35, v18, v19, v62                              // 00000006472C: D6440023 04FA2712
	v_fma_mixlo_f16 v18, v119, s51, 0                          // 000000064734: CC210012 02006777
	v_fma_mixhi_f16 v18, v118, s51, 0                          // 00000006473C: CC220012 02006776
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064744: BF870091
	v_mov_b32_e32 v19, v18                                     // 000000064748: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 00000006474C: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000064758: BF8700C1
	v_perm_b32 v36, v18, v19, v61                              // 00000006475C: D6440024 04F62712
	v_perm_b32 v37, v18, v19, v62                              // 000000064764: D6440025 04FA2712
	v_fma_mixlo_f16 v18, v117, s51, 0                          // 00000006476C: CC210012 02006775
	v_fma_mixhi_f16 v18, v116, s51, 0                          // 000000064774: CC220012 02006774
	v_mov_b32_e32 v19, v18                                     // 00000006477C: 7E260312
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064780: BF870091
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 000000064784: D65C0013 03FC6913 FEDCBA98
	v_perm_b32 v38, v18, v19, v61                              // 000000064790: D6440026 04F62712
	v_perm_b32 v39, v18, v19, v62                              // 000000064798: D6440027 04FA2712
	v_fma_mixlo_f16 v18, v115, s51, 0                          // 0000000647A0: CC210012 02006773
	v_fma_mixhi_f16 v18, v146, s51, 0                          // 0000000647A8: CC220012 02006792
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000647B0: BF870091
	v_mov_b32_e32 v19, v18                                     // 0000000647B4: 7E260312
	v_permlanex16_b32 v19, v19, s52, 0xfedcba98                // 0000000647B8: D65C0013 03FC6913 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000647C4: BF8700D1
	v_perm_b32 v40, v18, v19, v61                              // 0000000647C8: D6440028 04F62712
	v_perm_b32 v41, v18, v19, v62                              // 0000000647D0: D6440029 04FA2712
	s_waitcnt lgkmcnt(2)                                       // 0000000647D8: BF89FC27
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[26:33], v[2:9]// 0000000647DC: CC404012 1C0A352A
	s_waitcnt lgkmcnt(0)                                       // 0000000647E4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[150:157], v[34:41], v[18:25]// 0000000647E8: CC404012 1C4A4596
	ds_load_b128 v[150:153], v52 offset:10496                  // 0000000647F0: DBFC2900 96000034
	ds_load_b128 v[154:157], v52 offset:10512                  // 0000000647F8: DBFC2910 9A000034
	s_waitcnt lgkmcnt(0)                                       // 000000064800: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[150:157], v[26:33], v[2:9]// 000000064804: CC40402A 1C0A3596
	ds_load_b128 v[26:29], v52 offset:10528                    // 00000006480C: DBFC2920 1A000034
	ds_load_b128 v[30:33], v52 offset:10544                    // 000000064814: DBFC2930 1E000034
	s_waitcnt lgkmcnt(0)                                       // 00000006481C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[26:33], v[34:41], v[42:49]// 000000064820: CC40402A 1CAA451A
	v_fma_mixlo_f16 v27, v114, s51, 0                          // 000000064828: CC21001B 02006772
	v_fma_mixhi_f16 v27, v113, s51, 0                          // 000000064830: CC22001B 02006771
	v_fma_mixlo_f16 v29, v112, s51, 0                          // 000000064838: CC21001D 02006770
	v_fma_mixhi_f16 v29, v111, s51, 0                          // 000000064840: CC22001D 0200676F
	v_fma_mixlo_f16 v31, v110, s51, 0                          // 000000064848: CC21001F 0200676E
	v_fma_mixhi_f16 v31, v109, s51, 0                          // 000000064850: CC22001F 0200676D
	v_fma_mixlo_f16 v33, v108, s51, 0                          // 000000064858: CC210021 0200676C
	v_fma_mixhi_f16 v33, v145, s51, 0                          // 000000064860: CC220021 02006791
	v_mov_b32_e32 v28, v27                                     // 000000064868: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000006486C: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000064870: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064874: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000064878: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000006487C: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064888: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000006488C: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000064898: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000648A4: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000648A8: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000648B4: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000648BC: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000648C4: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 0000000648CC: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 0000000648D4: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 0000000648DC: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 0000000648E4: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 0000000648EC: D6440021 04FA4521
	ds_load_b128 v[38:41], v52 offset:14928                    // 0000000648F4: DBFC3A50 26000034
	ds_load_b128 v[34:37], v52 offset:14912                    // 0000000648FC: DBFC3A40 22000034
	s_waitcnt lgkmcnt(0)                                       // 000000064904: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000064908: CC404012 1C4A3522
	ds_load_b128 v[38:41], v52 offset:10576                    // 000000064910: DBFC2950 26000034
	ds_load_b128 v[34:37], v52 offset:10560                    // 000000064918: DBFC2940 22000034
	s_waitcnt lgkmcnt(0)                                       // 000000064920: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000064924: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v107, s51, 0                          // 00000006492C: CC21001B 0200676B
	v_fma_mixhi_f16 v27, v106, s51, 0                          // 000000064934: CC22001B 0200676A
	v_fma_mixlo_f16 v29, v105, s51, 0                          // 00000006493C: CC21001D 02006769
	v_fma_mixhi_f16 v29, v104, s51, 0                          // 000000064944: CC22001D 02006768
	v_fma_mixlo_f16 v31, v103, s51, 0                          // 00000006494C: CC21001F 02006767
	v_fma_mixhi_f16 v31, v102, s51, 0                          // 000000064954: CC22001F 02006766
	v_fma_mixlo_f16 v33, v101, s51, 0                          // 00000006495C: CC210021 02006765
	v_fma_mixhi_f16 v33, v144, s51, 0                          // 000000064964: CC220021 02006790
	v_mov_b32_e32 v28, v27                                     // 00000006496C: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000064970: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000064974: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064978: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000006497C: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000064980: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000006498C: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000064990: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000006499C: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000649A8: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 0000000649AC: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 0000000649B8: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 0000000649C0: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 0000000649C8: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 0000000649D0: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 0000000649D8: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 0000000649E0: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 0000000649E8: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 0000000649F0: D6440021 04FA4521
	ds_load_b128 v[38:41], v52 offset:14960                    // 0000000649F8: DBFC3A70 26000034
	ds_load_b128 v[34:37], v52 offset:14944                    // 000000064A00: DBFC3A60 22000034
	s_waitcnt lgkmcnt(0)                                       // 000000064A08: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000064A0C: CC404012 1C4A3522
	ds_load_b128 v[38:41], v52 offset:10608                    // 000000064A14: DBFC2970 26000034
	ds_load_b128 v[34:37], v52 offset:10592                    // 000000064A1C: DBFC2960 22000034
	s_waitcnt lgkmcnt(0)                                       // 000000064A24: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000064A28: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v100, s51, 0                          // 000000064A30: CC21001B 02006764
	v_fma_mixhi_f16 v27, v99, s51, 0                           // 000000064A38: CC22001B 02006763
	v_fma_mixlo_f16 v29, v98, s51, 0                           // 000000064A40: CC21001D 02006762
	v_fma_mixhi_f16 v29, v97, s51, 0                           // 000000064A48: CC22001D 02006761
	v_fma_mixlo_f16 v31, v96, s51, 0                           // 000000064A50: CC21001F 02006760
	v_fma_mixhi_f16 v31, v95, s51, 0                           // 000000064A58: CC22001F 0200675F
	v_fma_mixlo_f16 v33, v94, s51, 0                           // 000000064A60: CC210021 0200675E
	v_fma_mixhi_f16 v33, v143, s51, 0                          // 000000064A68: CC220021 0200678F
	v_mov_b32_e32 v28, v27                                     // 000000064A70: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000064A74: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000064A78: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064A7C: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000064A80: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000064A84: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064A90: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000064A94: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000064AA0: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064AAC: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000064AB0: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 000000064ABC: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 000000064AC4: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000064ACC: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000064AD4: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000064ADC: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000064AE4: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000064AEC: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000064AF4: D6440021 04FA4521
	ds_load_b128 v[38:41], v52 offset:14992                    // 000000064AFC: DBFC3A90 26000034
	ds_load_b128 v[34:37], v52 offset:14976                    // 000000064B04: DBFC3A80 22000034
	s_waitcnt lgkmcnt(0)                                       // 000000064B0C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000064B10: CC404012 1C4A3522
	ds_load_b128 v[38:41], v52 offset:10640                    // 000000064B18: DBFC2990 26000034
	ds_load_b128 v[34:37], v52 offset:10624                    // 000000064B20: DBFC2980 22000034
	s_waitcnt lgkmcnt(0)                                       // 000000064B28: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000064B2C: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v93, s51, 0                           // 000000064B34: CC21001B 0200675D
	v_fma_mixhi_f16 v27, v92, s51, 0                           // 000000064B3C: CC22001B 0200675C
	v_fma_mixlo_f16 v29, v91, s51, 0                           // 000000064B44: CC21001D 0200675B
	v_fma_mixhi_f16 v29, v90, s51, 0                           // 000000064B4C: CC22001D 0200675A
	v_fma_mixlo_f16 v31, v89, s51, 0                           // 000000064B54: CC21001F 02006759
	v_fma_mixhi_f16 v31, v88, s51, 0                           // 000000064B5C: CC22001F 02006758
	v_fma_mixlo_f16 v33, v87, s51, 0                           // 000000064B64: CC210021 02006757
	v_fma_mixhi_f16 v33, v142, s51, 0                          // 000000064B6C: CC220021 0200678E
	v_mov_b32_e32 v28, v27                                     // 000000064B74: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000064B78: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000064B7C: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064B80: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000064B84: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000064B88: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064B94: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000064B98: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000064BA4: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064BB0: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000064BB4: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 000000064BC0: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 000000064BC8: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000064BD0: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000064BD8: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000064BE0: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000064BE8: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000064BF0: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000064BF8: D6440021 04FA4521
	ds_load_b128 v[38:41], v52 offset:15024                    // 000000064C00: DBFC3AB0 26000034
	ds_load_b128 v[34:37], v52 offset:15008                    // 000000064C08: DBFC3AA0 22000034
	s_waitcnt lgkmcnt(0)                                       // 000000064C10: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000064C14: CC404012 1C4A3522
	ds_load_b128 v[38:41], v52 offset:10672                    // 000000064C1C: DBFC29B0 26000034
	ds_load_b128 v[34:37], v52 offset:10656                    // 000000064C24: DBFC29A0 22000034
	s_waitcnt lgkmcnt(0)                                       // 000000064C2C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000064C30: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v86, s51, 0                           // 000000064C38: CC21001B 02006756
	v_fma_mixhi_f16 v27, v85, s51, 0                           // 000000064C40: CC22001B 02006755
	v_fma_mixlo_f16 v29, v84, s51, 0                           // 000000064C48: CC21001D 02006754
	v_fma_mixhi_f16 v29, v83, s51, 0                           // 000000064C50: CC22001D 02006753
	v_fma_mixlo_f16 v31, v82, s51, 0                           // 000000064C58: CC21001F 02006752
	v_fma_mixhi_f16 v31, v81, s51, 0                           // 000000064C60: CC22001F 02006751
	v_fma_mixlo_f16 v33, v80, s51, 0                           // 000000064C68: CC210021 02006750
	v_fma_mixhi_f16 v33, v141, s51, 0                          // 000000064C70: CC220021 0200678D
	v_mov_b32_e32 v28, v27                                     // 000000064C78: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000064C7C: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000064C80: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064C84: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000064C88: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000064C8C: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064C98: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000064C9C: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000064CA8: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064CB4: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000064CB8: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 000000064CC4: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 000000064CCC: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000064CD4: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000064CDC: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000064CE4: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000064CEC: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000064CF4: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000064CFC: D6440021 04FA4521
	ds_load_b128 v[38:41], v52 offset:15056                    // 000000064D04: DBFC3AD0 26000034
	ds_load_b128 v[34:37], v52 offset:15040                    // 000000064D0C: DBFC3AC0 22000034
	s_waitcnt lgkmcnt(0)                                       // 000000064D14: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000064D18: CC404012 1C4A3522
	ds_load_b128 v[38:41], v52 offset:10704                    // 000000064D20: DBFC29D0 26000034
	ds_load_b128 v[34:37], v52 offset:10688                    // 000000064D28: DBFC29C0 22000034
	s_waitcnt lgkmcnt(0)                                       // 000000064D30: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000064D34: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v79, s51, 0                           // 000000064D3C: CC21001B 0200674F
	v_fma_mixhi_f16 v27, v78, s51, 0                           // 000000064D44: CC22001B 0200674E
	v_fma_mixlo_f16 v29, v77, s51, 0                           // 000000064D4C: CC21001D 0200674D
	v_fma_mixhi_f16 v29, v76, s51, 0                           // 000000064D54: CC22001D 0200674C
	v_fma_mixlo_f16 v31, v75, s51, 0                           // 000000064D5C: CC21001F 0200674B
	v_fma_mixhi_f16 v31, v74, s51, 0                           // 000000064D64: CC22001F 0200674A
	v_fma_mixlo_f16 v33, v73, s51, 0                           // 000000064D6C: CC210021 02006749
	v_fma_mixhi_f16 v33, v140, s51, 0                          // 000000064D74: CC220021 0200678C
	v_mov_b32_e32 v28, v27                                     // 000000064D7C: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 000000064D80: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 000000064D84: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064D88: BF870214
	v_mov_b32_e32 v34, v33                                     // 000000064D8C: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 000000064D90: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064D9C: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 000000064DA0: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 000000064DAC: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064DB8: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 000000064DBC: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v61                              // 000000064DC8: D644001A 04F6391B
	v_perm_b32 v27, v27, v28, v62                              // 000000064DD0: D644001B 04FA391B
	v_perm_b32 v28, v29, v30, v61                              // 000000064DD8: D644001C 04F63D1D
	v_perm_b32 v29, v29, v30, v62                              // 000000064DE0: D644001D 04FA3D1D
	v_perm_b32 v30, v31, v32, v61                              // 000000064DE8: D644001E 04F6411F
	v_perm_b32 v31, v31, v32, v62                              // 000000064DF0: D644001F 04FA411F
	v_perm_b32 v32, v33, v34, v61                              // 000000064DF8: D6440020 04F64521
	v_perm_b32 v33, v33, v34, v62                              // 000000064E00: D6440021 04FA4521
	ds_load_b128 v[38:41], v52 offset:15088                    // 000000064E08: DBFC3AF0 26000034
	ds_load_b128 v[34:37], v52 offset:15072                    // 000000064E10: DBFC3AE0 22000034
	s_waitcnt lgkmcnt(0)                                       // 000000064E18: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 000000064E1C: CC404012 1C4A3522
	ds_load_b128 v[38:41], v52 offset:10736                    // 000000064E24: DBFC29F0 26000034
	ds_load_b128 v[34:37], v52 offset:10720                    // 000000064E2C: DBFC29E0 22000034
	v_dual_mul_f32 v18, 0x3b800000, v18 :: v_dual_mul_f32 v19, 0x3b800000, v19// 000000064E34: C8C624FF 121226FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v20 :: v_dual_mul_f32 v21, 0x3b800000, v21// 000000064E40: C8C628FF 14142AFF 3B800000
	v_mul_f32_e32 v22, 0x3b800000, v22                         // 000000064E4C: 102C2CFF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000064E54: BF870223
	v_sub_f32_e32 v10, v10, v18                                // 000000064E58: 0814250A
	v_or_b32_e32 v18, s54, v149                                // 000000064E5C: 38252A36
	v_dual_sub_f32 v11, v11, v19 :: v_dual_sub_f32 v12, v12, v20// 000000064E60: C94A270B 0B0C290C
	v_sub_f32_e32 v13, v13, v21                                // 000000064E68: 081A2B0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064E6C: BF870214
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 000000064E70: CC21000A 0200610A
	v_or_b32_e32 v19, 2, v18                                   // 000000064E78: 38262482
	.long 0xd4440000                                           // 000000064E7C: D4440000
	v_cndmask_b32_e32 v1, s35, v18, vcc_lo                     // 000000064E80: 02022423
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 000000064E84: CC22000A 0200610B
	v_dual_mul_f32 v23, 0x3b800000, v23 :: v_dual_sub_f32 v14, v14, v22// 000000064E8C: C8CA2EFF 170E2D0E 3B800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000064E98: BF870214
	v_cmp_gt_i32_e32 vcc_lo, s35, v19                          // 000000064E9C: 7C882623
	v_cndmask_b16 v10, 0, v10, s0                              // 000000064EA0: D65D000A 00021480
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 000000064EA8: BF8701D3
	v_dual_mul_f32 v24, 0x3b800000, v24 :: v_dual_sub_f32 v15, v15, v23// 000000064EAC: C8CA30FF 180E2F0F 3B800000
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 000000064EB8: 103232FF 3B800000
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000064EC0: D65D500A 01AA1480
	s_waitcnt lgkmcnt(0)                                       // 000000064EC8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 000000064ECC: CC40402A 1CAA3522
	v_dual_sub_f32 v16, v16, v24 :: v_dual_sub_f32 v17, v17, v25// 000000064ED4: C94A3110 10103311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000064EDC: BF8700C3
	v_mov_b32_e32 v11, v10                                     // 000000064EE0: 7E16030A
	ds_load_b128 v[19:22], v54 offset:23296                    // 000000064EE4: DBFC5B00 13000036
	ds_load_b128 v[23:26], v54 offset:23312                    // 000000064EEC: DBFC5B10 17000036
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000064EF4: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v55, v10, v11, v61                              // 000000064F00: D6440037 04F6170A
	v_perm_b32 v56, v10, v11, v62                              // 000000064F08: D6440038 04FA170A
	v_or_b32_e32 v10, 4, v18                                   // 000000064F10: 38142484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000064F14: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s35, v10                          // 000000064F18: 7C881423
	v_or_b32_e32 v10, 6, v18                                   // 000000064F1C: 38142486
	.long 0xd4440001                                           // 000000064F20: D4440001
	v_cndmask_b32_e32 v1, s35, v10, vcc_lo                     // 000000064F24: 02021423
	v_fma_mixlo_f16 v10, v12, s48, 0                           // 000000064F28: CC21000A 0200610C
	v_fma_mixhi_f16 v10, v13, s48, 0                           // 000000064F30: CC22000A 0200610D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000064F38: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000064F3C: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s1                              // 000000064F44: D65D500A 00061480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064F4C: BF870091
	v_mov_b32_e32 v11, v10                                     // 000000064F50: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000064F54: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000064F60: BF8700B1
	v_perm_b32 v57, v10, v11, v61                              // 000000064F64: D6440039 04F6170A
	v_perm_b32 v58, v10, v11, v62                              // 000000064F6C: D644003A 04FA170A
	v_or_b32_e32 v10, 8, v18                                   // 000000064F74: 38142488
	v_cmp_gt_i32_e32 vcc_lo, s35, v10                          // 000000064F78: 7C881423
	v_or_b32_e32 v10, 10, v18                                  // 000000064F7C: 3814248A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000064F80: BF870131
	.long 0xd4440001                                           // 000000064F84: D4440001
	v_cndmask_b32_e32 v1, s35, v10, vcc_lo                     // 000000064F88: 02021423
	v_fma_mixlo_f16 v10, v14, s48, 0                           // 000000064F8C: CC21000A 0200610E
	v_fma_mixhi_f16 v10, v15, s48, 0                           // 000000064F94: CC22000A 0200610F
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000064F9C: D65D000A 01AA1480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064FA4: BF870092
	v_cndmask_b16 v10, 0, v10, s1                              // 000000064FA8: D65D500A 00061480
	v_mov_b32_e32 v11, v10                                     // 000000064FB0: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000064FB4: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000064FB8: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v59, v10, v11, v61                              // 000000064FC4: D644003B 04F6170A
	v_perm_b32 v60, v10, v11, v62                              // 000000064FCC: D644003C 04FA170A
	v_or_b32_e32 v10, 12, v18                                  // 000000064FD4: 3814248C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000064FD8: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s35, v10                          // 000000064FDC: 7C881423
	v_or_b32_e32 v10, 14, v18                                  // 000000064FE0: 3814248E
	.long 0xd4440001                                           // 000000064FE4: D4440001
	v_cndmask_b32_e32 v1, s35, v10, vcc_lo                     // 000000064FE8: 02021423
	v_fma_mixlo_f16 v10, v16, s48, 0                           // 000000064FEC: CC21000A 02006110
	v_fma_mixhi_f16 v10, v17, s48, 0                           // 000000064FF4: CC22000A 02006111
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000064FFC: BF870112
	v_cndmask_b16 v10, 0, v10, vcc_lo                          // 000000065000: D65D000A 01AA1480
	v_cndmask_b16 v10, 0, v10, s1                              // 000000065008: D65D500A 00061480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065010: BF870091
	v_mov_b32_e32 v11, v10                                     // 000000065014: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 000000065018: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000065024: BF8700B1
	v_perm_b32 v61, v10, v11, v61                              // 000000065028: D644003D 04F6170A
	v_perm_b32 v62, v10, v11, v62                              // 000000065030: D644003E 04FA170A
	s_waitcnt lgkmcnt(0)                                       // 000000065038: BF89FC07
	v_wmma_f32_16x16x16_f16 v[10:17], v[19:26], v[55:62], v[2:9]// 00000006503C: CC40400A 1C0A6F13
	.long 0xd7000102                                           // 000000065044: D7000102
	v_cndmask_b32_e32 v1, s39, v53, vcc_lo                     // 000000065048: 02026A27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006504C: BF870001
	v_add_co_ci_u32_e64 v3, null, s40, 0, s1                   // 000000065050: D5207C03 00050028
	s_and_saveexec_b32 s1, s0                                  // 000000065058: BE812000
	s_cbranch_execz 19                                         // 00000006505C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3cac>
	ds_load_b32 v4, v51 offset:24320                           // 000000065060: D8D85F00 04000033
	s_waitcnt lgkmcnt(0)                                       // 000000065068: BF89FC07
	v_mul_f32_e32 v4, v42, v4                                  // 00000006506C: 1008092A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065070: BF870091
	v_add_f32_e32 v4, v10, v4                                  // 000000065074: 0608090A
	v_mul_f32_e32 v6, 0x3b800000, v4                           // 000000065078: 100C08FF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v18, v[2:3]            // 000000065080: D6FE7C04 040A24FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006508C: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000065090: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000065098: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000000650A4: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s1                              // 0000000650AC: 8C7E017E
	v_or3_b32 v4, v149, s54, 2                                 // 0000000650B0: D6580004 02086D95
	s_mov_b32 s0, exec_lo                                      // 0000000650B8: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000650BC: BF870001
	.long 0xd4c4007e                                           // 0000000650C0: D4C4007E
	v_cndmask_b32_e32 v1, s35, v4, vcc_lo                      // 0000000650C4: 02020823
	s_cbranch_execz 19                                         // 0000000650C8: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d18>
	ds_load_b32 v5, v51 offset:24328                           // 0000000650CC: D8D85F08 05000033
	s_waitcnt lgkmcnt(0)                                       // 0000000650D4: BF89FC07
	v_mul_f32_e32 v5, v43, v5                                  // 0000000650D8: 100A0B2B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000650DC: BF870091
	v_add_f32_e32 v5, v11, v5                                  // 0000000650E0: 060A0B0B
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 0000000650E4: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 0000000650EC: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000650F8: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 0000000650FC: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000065104: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000065110: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s0                              // 000000065118: 8C7E007E
	v_or3_b32 v4, v149, s54, 4                                 // 00000006511C: D6580004 02106D95
	s_mov_b32 s0, exec_lo                                      // 000000065124: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000065128: BF870001
	.long 0xd4c4007e                                           // 00000006512C: D4C4007E
	v_cndmask_b32_e32 v1, s35, v4, vcc_lo                      // 000000065130: 02020823
	s_cbranch_execz 19                                         // 000000065134: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d84>
	ds_load_b32 v5, v51 offset:24336                           // 000000065138: D8D85F10 05000033
	s_waitcnt lgkmcnt(0)                                       // 000000065140: BF89FC07
	v_mul_f32_e32 v5, v44, v5                                  // 000000065144: 100A0B2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065148: BF870091
	v_add_f32_e32 v5, v12, v5                                  // 00000006514C: 060A0B0C
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000065150: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000065158: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065164: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000065168: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000065170: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000006517C: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s0                              // 000000065184: 8C7E007E
	v_or3_b32 v4, v149, s54, 6                                 // 000000065188: D6580004 02186D95
	s_mov_b32 s0, exec_lo                                      // 000000065190: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000065194: BF870001
	.long 0xd4c4007e                                           // 000000065198: D4C4007E
	v_cndmask_b32_e32 v1, s35, v4, vcc_lo                      // 00000006519C: 02020823
	s_cbranch_execz 19                                         // 0000000651A0: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3df0>
	ds_load_b32 v5, v51 offset:24344                           // 0000000651A4: D8D85F18 05000033
	s_waitcnt lgkmcnt(0)                                       // 0000000651AC: BF89FC07
	v_mul_f32_e32 v5, v45, v5                                  // 0000000651B0: 100A0B2D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000651B4: BF870091
	v_add_f32_e32 v5, v13, v5                                  // 0000000651B8: 060A0B0D
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 0000000651BC: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 0000000651C4: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000651D0: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 0000000651D4: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000000651DC: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000000651E8: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000651F0: 8C7E007E
	v_or3_b32 v4, v149, s54, 8                                 // 0000000651F4: D6580004 02206D95
	s_mov_b32 s0, exec_lo                                      // 0000000651FC: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000065200: BF870001
	.long 0xd4c4007e                                           // 000000065204: D4C4007E
	v_cndmask_b32_e32 v1, s35, v4, vcc_lo                      // 000000065208: 02020823
	s_cbranch_execz 19                                         // 00000006520C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3e5c>
	ds_load_b32 v5, v51 offset:24352                           // 000000065210: D8D85F20 05000033
	s_waitcnt lgkmcnt(0)                                       // 000000065218: BF89FC07
	v_mul_f32_e32 v5, v46, v5                                  // 00000006521C: 100A0B2E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065220: BF870091
	v_add_f32_e32 v5, v14, v5                                  // 000000065224: 060A0B0E
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000065228: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000065230: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006523C: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000065240: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000065248: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 000000065254: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s0                              // 00000006525C: 8C7E007E
	v_or3_b32 v4, v149, s54, 10                                // 000000065260: D6580004 02286D95
	s_mov_b32 s0, exec_lo                                      // 000000065268: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006526C: BF870001
	.long 0xd4c4007e                                           // 000000065270: D4C4007E
	v_cndmask_b32_e32 v1, s35, v4, vcc_lo                      // 000000065274: 02020823
	s_cbranch_execz 19                                         // 000000065278: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3ec8>
	ds_load_b32 v5, v51 offset:24360                           // 00000006527C: D8D85F28 05000033
	s_waitcnt lgkmcnt(0)                                       // 000000065284: BF89FC07
	v_mul_f32_e32 v5, v47, v5                                  // 000000065288: 100A0B2F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000006528C: BF870091
	v_add_f32_e32 v5, v15, v5                                  // 000000065290: 060A0B0F
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000065294: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 00000006529C: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000652A8: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 0000000652AC: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 0000000652B4: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 0000000652C0: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000652C8: 8C7E007E
	v_or3_b32 v4, v149, s54, 12                                // 0000000652CC: D6580004 02306D95
	s_mov_b32 s0, exec_lo                                      // 0000000652D4: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000652D8: BF870001
	.long 0xd4c4007e                                           // 0000000652DC: D4C4007E
	v_cndmask_b32_e32 v1, s35, v4, vcc_lo                      // 0000000652E0: 02020823
	s_cbranch_execz 19                                         // 0000000652E4: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3f34>
	ds_load_b32 v5, v51 offset:24368                           // 0000000652E8: D8D85F30 05000033
	s_waitcnt lgkmcnt(0)                                       // 0000000652F0: BF89FC07
	v_mul_f32_e32 v5, v48, v5                                  // 0000000652F4: 100A0B30
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000652F8: BF870091
	v_add_f32_e32 v5, v16, v5                                  // 0000000652FC: 060A0B10
	v_mul_f32_e32 v6, 0x3b800000, v5                           // 000000065300: 100C0AFF 3B800000
	v_mad_u64_u32 v[4:5], null, 0x3000, v4, v[2:3]             // 000000065308: D6FE7C04 040A08FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065314: BF870092
	v_bfe_u32 v7, v6, 16, 1                                    // 000000065318: D6100007 02052106
	v_add3_u32 v6, v6, v7, 0x7fff                              // 000000065320: D6550006 03FE0F06 00007FFF
	global_store_d16_hi_b16 v[4:5], v6, off                    // 00000006532C: DC960000 007C0604
	s_or_b32 exec_lo, exec_lo, s0                              // 000000065334: 8C7E007E
	v_or3_b32 v4, v149, s54, 14                                // 000000065338: D6580004 02386D95
	s_mov_b32 s0, exec_lo                                      // 000000065340: BE80007E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000065344: BF870001
	.long 0xd4c4007e                                           // 000000065348: D4C4007E
	v_cndmask_b32_e32 v1, s35, v4, vcc_lo                      // 00000006534C: 02020823
	s_cbranch_execz 19                                         // 000000065350: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3fa0>
	ds_load_b32 v5, v51 offset:24376                           // 000000065354: D8D85F38 05000033
	v_mad_u64_u32 v[2:3], null, 0x3000, v4, v[2:3]             // 00000006535C: D6FE7C02 040A08FF 00003000
	s_waitcnt lgkmcnt(0)                                       // 000000065368: BF89FC07
	v_mul_f32_e32 v5, v49, v5                                  // 00000006536C: 100A0B31
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065370: BF870091
	v_add_f32_e32 v5, v17, v5                                  // 000000065374: 060A0B11
	v_mul_f32_e32 v5, 0x3b800000, v5                           // 000000065378: 100A0AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065380: BF870091
	v_bfe_u32 v6, v5, 16, 1                                    // 000000065384: D6100006 02052105
	v_add3_u32 v4, v5, v6, 0x7fff                              // 00000006538C: D6550004 03FE0D05 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 000000065398: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s0                              // 0000000653A0: 8C7E007E
	ds_load_b32 v26, v1 offset:24188                           // 0000000653A4: D8D85E7C 1A000001
	v_mad_u32_u24 v2, v50, 48, 0x4b00                          // 0000000653AC: D60B0002 03FD6132 00004B00
	v_dual_mov_b32 v173, s23 :: v_dual_mov_b32 v170, s20       // 0000000653B8: CA100017 ADAA0014
	v_dual_mov_b32 v168, s18 :: v_dual_mov_b32 v167, s17       // 0000000653C0: CA100012 A8A60011
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000653C8: BF870003
	v_dual_mov_b32 v172, s22 :: v_dual_add_nc_u32 v27, 0xffffb500, v2// 0000000653CC: CA200016 AC1A04FF FFFFB500
	v_mov_b32_e32 v166, s16                                    // 0000000653D8: 7F4C0210
	s_add_i32 s54, s54, 16                                     // 0000000653DC: 81369036
	ds_load_b128 v[154:157], v27 offset:2320                   // 0000000653E0: DBFC0910 9A00001B
	ds_load_b128 v[150:153], v27 offset:2304                   // 0000000653E8: DBFC0900 9600001B
	ds_load_b128 v[162:165], v27 offset:3088                   // 0000000653F0: DBFC0C10 A200001B
	ds_load_b128 v[158:161], v27 offset:3072                   // 0000000653F8: DBFC0C00 9E00001B
	ds_load_b128 v[2:5], v27                                   // 000000065400: DBFC0000 0200001B
	ds_load_b128 v[6:9], v27 offset:16                         // 000000065408: DBFC0010 0600001B
	ds_load_b128 v[182:185], v27 offset:4608                   // 000000065410: DBFC1200 B600001B
	ds_load_b128 v[186:189], v27 offset:4624                   // 000000065418: DBFC1210 BA00001B
	ds_load_b128 v[178:181], v27 offset:3856                   // 000000065420: DBFC0F10 B200001B
	ds_load_b128 v[174:177], v27 offset:3840                   // 000000065428: DBFC0F00 AE00001B
	v_mov_b32_e32 v171, s21                                    // 000000065430: 7F560215
	v_mov_b32_e32 v169, s19                                    // 000000065434: 7F520213
	s_waitcnt lgkmcnt(10)                                      // 000000065438: BF89FCA7
	v_readfirstlane_b32 s0, v26                                // 00000006543C: 7E00051A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v26                  // 000000065440: 7C3634FF C2CE8ED0
	s_mul_f32 s0, s0, 0x3fb8aa3b                               // 000000065448: A200FF00 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 000000065450: BF87000B
	s_xor_b32 s1, s0, 0x80000000                               // 000000065454: 8D01FF00 80000000
	s_cmp_lg_u32 s12, s54                                      // 00000006545C: BF07360C
	v_fma_f32 v10, 0x3fb8aa3b, v26, s1                         // 000000065460: D613000A 000634FF 3FB8AA3B
	s_rndne_f32 s1, s0                                         // 00000006546C: BE816300
	s_waitcnt lgkmcnt(4)                                       // 000000065470: BF89FC47
	v_wmma_f32_16x16x16_f16 v[47:54], v[2:9], v[55:62], v[166:173]// 000000065474: CC40402F 1E9A6F02
	s_delay_alu instid0(VALU_DEP_2)                            // 00000006547C: BF870002
	v_fmac_f32_e32 v10, 0x32a5705f, v26                        // 000000065480: 561434FF 32A5705F
	s_sub_f32 s0, s0, s1                                       // 000000065488: A0800100
	s_delay_alu instid0(VALU_DEP_1) | instid1(SALU_CYCLE_3)    // 00000006548C: BF870581
	v_add_f32_e32 v28, s0, v10                                 // 000000065490: 06381400
	ds_load_b128 v[14:17], v27 offset:784                      // 000000065494: DBFC0310 0E00001B
	ds_load_b128 v[10:13], v27 offset:768                      // 00000006549C: DBFC0300 0A00001B
	ds_load_b128 v[22:25], v27 offset:1552                     // 0000000654A4: DBFC0610 1600001B
	ds_load_b128 v[18:21], v27 offset:1536                     // 0000000654AC: DBFC0600 1200001B
	s_cvt_i32_f32 s0, s1                                       // 0000000654B4: BE806601
	v_exp_f32_e32 v28, v28                                     // 0000000654B8: 7E384B1C
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_2) // 0000000654BC: BF870505
	.long 0xd71c001c                                           // 0000000654C0: D71C001C
	v_cndmask_b32_e32 v0, v28, v0, vcc_lo                      // 0000000654C4: 0200011C
	s_waitcnt lgkmcnt(2)                                       // 0000000654C8: BF89FC27
	v_wmma_f32_16x16x16_f16 v[39:46], v[10:17], v[55:62], v[166:173]// 0000000654CC: CC404027 1E9A6F0A
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000654D4: BF870002
	v_cndmask_b32_e32 v2, 0, v28, vcc_lo                       // 0000000654D8: 02043880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v26                  // 0000000654DC: 7C3C34FF 42B17218
	v_wmma_f32_16x16x16_f16 v[10:17], v[150:157], v[55:62], v[166:173]// 0000000654E4: CC40400A 1E9A6F96
	ds_load_b128 v[154:157], v27 offset:5392                   // 0000000654EC: DBFC1510 9A00001B
	ds_load_b128 v[150:153], v27 offset:5376                   // 0000000654F4: DBFC1500 9600001B
	s_waitcnt lgkmcnt(0)                                       // 0000000654FC: BF89FC07
	s_barrier                                                  // 000000065500: BFBD0000
	v_cndmask_b32_e32 v190, 0x7f800000, v2, vcc_lo             // 000000065504: 037C04FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000006550C: BF8701D1
	v_fmac_f32_e32 v17, v144, v190                             // 000000065510: 56237D90
	s_waitcnt lgkmcnt(2)                                       // 000000065514: BF89FC27
	v_wmma_f32_16x16x16_f16 v[31:38], v[18:25], v[55:62], v[166:173]// 000000065518: CC40401F 1E9A6F12
	v_wmma_f32_16x16x16_f16 v[2:9], v[158:165], v[55:62], v[166:173]// 000000065520: CC404002 1E9A6F9E
	v_wmma_f32_16x16x16_f16 v[18:25], v[174:181], v[55:62], v[166:173]// 000000065528: CC404012 1E9A6FAE
	v_fma_f32 v114, v114, v190, v31                            // 000000065530: D6130072 047F7D72
	s_delay_alu instid0(VALU_DEP_4)                            // 000000065538: BF870004
	v_fma_f32 v113, v113, v190, v32                            // 00000006553C: D6130071 04837D71
	v_fma_f32 v112, v112, v190, v33                            // 000000065544: D6130070 04877D70
	v_fma_f32 v111, v111, v190, v34                            // 00000006554C: D613006F 048B7D6F
	v_fma_f32 v110, v110, v190, v35                            // 000000065554: D613006E 048F7D6E
	v_fma_f32 v109, v109, v190, v36                            // 00000006555C: D613006D 04937D6D
	v_fma_f32 v108, v108, v190, v37                            // 000000065564: D613006C 04977D6C
	v_wmma_f32_16x16x16_f16 v[30:37], v[182:189], v[55:62], v[166:173]// 00000006556C: CC40401E 1E9A6FB6
	v_fma_f32 v128, v128, v190, v47                            // 000000065574: D6130080 04BF7D80
	v_fma_f32 v127, v127, v190, v48                            // 00000006557C: D613007F 04C37D7F
	v_fma_f32 v126, v126, v190, v49                            // 000000065584: D613007E 04C77D7E
	s_delay_alu instid0(VALU_DEP_4)                            // 00000006558C: BF870004
	v_fma_f32 v86, v86, v190, v30                              // 000000065590: D6130056 047B7D56
	v_fma_f32 v85, v85, v190, v31                              // 000000065598: D6130055 047F7D55
	v_fma_f32 v84, v84, v190, v32                              // 0000000655A0: D6130054 04837D54
	v_fma_f32 v83, v83, v190, v33                              // 0000000655A8: D6130053 04877D53
	s_waitcnt lgkmcnt(0)                                       // 0000000655B0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[26:33], v[150:157], v[55:62], v[166:173]// 0000000655B4: CC40401A 1E9A6F96
	v_fma_f32 v125, v125, v190, v50                            // 0000000655BC: D613007D 04CB7D7D
	v_fma_f32 v124, v124, v190, v51                            // 0000000655C4: D613007C 04CF7D7C
	v_fma_f32 v123, v123, v190, v52                            // 0000000655CC: D613007B 04D37D7B
	v_fma_f32 v122, v122, v190, v53                            // 0000000655D4: D613007A 04D77D7A
	v_dual_fmac_f32 v54, v147, v190 :: v_dual_mul_f32 v147, 0x3b800000, v127// 0000000655DC: C8077D93 3692FEFF 3B800000
	v_fma_f32 v121, v121, v190, v39                            // 0000000655E8: D6130079 049F7D79
	v_fma_f32 v120, v120, v190, v40                            // 0000000655F0: D6130078 04A37D78
	v_fma_f32 v119, v119, v190, v41                            // 0000000655F8: D6130077 04A77D77
	v_fma_f32 v118, v118, v190, v42                            // 000000065600: D6130076 04AB7D76
	v_fma_f32 v117, v117, v190, v43                            // 000000065608: D6130075 04AF7D75
	v_fma_f32 v116, v116, v190, v44                            // 000000065610: D6130074 04B37D74
	v_fma_f32 v115, v115, v190, v45                            // 000000065618: D6130073 04B77D73
	v_fmac_f32_e32 v46, v146, v190                             // 000000065620: 565D7D92
	v_fmac_f32_e32 v38, v145, v190                             // 000000065624: 564D7D91
	v_fma_f32 v107, v107, v190, v10                            // 000000065628: D613006B 042B7D6B
	v_fma_f32 v106, v106, v190, v11                            // 000000065630: D613006A 042F7D6A
	v_fma_f32 v105, v105, v190, v12                            // 000000065638: D6130069 04337D69
	v_fma_f32 v104, v104, v190, v13                            // 000000065640: D6130068 04377D68
	v_fma_f32 v103, v103, v190, v14                            // 000000065648: D6130067 043B7D67
	v_fma_f32 v102, v102, v190, v15                            // 000000065650: D6130066 043F7D66
	v_fma_f32 v101, v101, v190, v16                            // 000000065658: D6130065 04437D65
	v_fma_f32 v100, v100, v190, v2                             // 000000065660: D6130064 040B7D64
	v_fma_f32 v99, v99, v190, v3                               // 000000065668: D6130063 040F7D63
	v_fma_f32 v98, v98, v190, v4                               // 000000065670: D6130062 04137D62
	v_fma_f32 v97, v97, v190, v5                               // 000000065678: D6130061 04177D61
	v_fma_f32 v96, v96, v190, v6                               // 000000065680: D6130060 041B7D60
	v_fma_f32 v95, v95, v190, v7                               // 000000065688: D613005F 041F7D5F
	v_fma_f32 v94, v94, v190, v8                               // 000000065690: D613005E 04237D5E
	v_fmac_f32_e32 v9, v143, v190                              // 000000065698: 56137D8F
	v_fma_f32 v93, v93, v190, v18                              // 00000006569C: D613005D 044B7D5D
	v_fma_f32 v92, v92, v190, v19                              // 0000000656A4: D613005C 044F7D5C
	v_fma_f32 v91, v91, v190, v20                              // 0000000656AC: D613005B 04537D5B
	v_fma_f32 v90, v90, v190, v21                              // 0000000656B4: D613005A 04577D5A
	v_fma_f32 v89, v89, v190, v22                              // 0000000656BC: D6130059 045B7D59
	v_fma_f32 v88, v88, v190, v23                              // 0000000656C4: D6130058 045F7D58
	v_fma_f32 v87, v87, v190, v24                              // 0000000656CC: D6130057 04637D57
	v_dual_fmac_f32 v25, v142, v190 :: v_dual_mul_f32 v146, 0x3b800000, v128// 0000000656D4: C8077D8E 199300FF 3B800000
	v_fma_f32 v82, v82, v190, v34                              // 0000000656E0: D6130052 048B7D52
	v_fma_f32 v81, v81, v190, v35                              // 0000000656E8: D6130051 048F7D51
	v_fma_f32 v80, v80, v190, v36                              // 0000000656F0: D6130050 04937D50
	v_dual_fmac_f32 v37, v141, v190 :: v_dual_mul_f32 v4, 0x3b800000, v124// 0000000656F8: C8077D8D 2504F8FF 3B800000
	v_fma_f32 v79, v79, v190, v26                              // 000000065704: D613004F 046B7D4F
	v_fma_f32 v78, v78, v190, v27                              // 00000006570C: D613004E 046F7D4E
	v_fma_f32 v77, v77, v190, v28                              // 000000065714: D613004D 04737D4D
	v_fma_f32 v76, v76, v190, v29                              // 00000006571C: D613004C 04777D4C
	v_fma_f32 v75, v75, v190, v30                              // 000000065724: D613004B 047B7D4B
	v_fma_f32 v74, v74, v190, v31                              // 00000006572C: D613004A 047F7D4A
	v_fma_f32 v73, v73, v190, v32                              // 000000065734: D6130049 04837D49
	v_dual_fmac_f32 v33, v140, v190 :: v_dual_mul_f32 v150, 0x3b800000, v123// 00000006573C: C8077D8C 2196F6FF 3B800000
	v_lshl_add_u32 v2, v149, 7, v148                           // 000000065748: D6460002 06510F95
	v_dual_mul_f32 v148, 0x3b800000, v126 :: v_dual_mul_f32 v145, 0x3b800000, v120// 000000065750: C8C6FCFF 9490F0FF 3B800000
	v_mul_f32_e32 v149, 0x3b800000, v125                       // 00000006575C: 112AFAFF 3B800000
	v_dual_mul_f32 v151, 0x3b800000, v122 :: v_dual_mul_f32 v140, 0x3b800000, v119// 000000065764: C8C6F4FF 978CEEFF 3B800000
	v_dual_mul_f32 v152, 0x3b800000, v54 :: v_dual_mul_f32 v143, 0x3b800000, v115// 000000065770: C8C66CFF 988EE6FF 3B800000
	v_mul_f32_e32 v5, 0x3b800000, v121                         // 00000006577C: 100AF2FF 3B800000
	v_dual_mul_f32 v141, 0x3b800000, v118 :: v_dual_mul_f32 v6, 0x3b800000, v117// 000000065784: C8C6ECFF 8D06EAFF 3B800000
	v_dual_mul_f32 v142, 0x3b800000, v116 :: v_dual_mul_f32 v7, 0x3b800000, v114// 000000065790: C8C6E8FF 8E06E4FF 3B800000
	v_dual_mul_f32 v144, 0x3b800000, v46 :: v_dual_mul_f32 v61, 0x3b800000, v112// 00000006579C: C8C65CFF 903CE0FF 3B800000
	v_dual_mul_f32 v60, 0x3b800000, v113 :: v_dual_mul_f32 v55, 0x3b800000, v108// 0000000657A8: C8C6E2FF 3C36D8FF 3B800000
	v_dual_mul_f32 v62, 0x3b800000, v111 :: v_dual_mul_f32 v53, 0x3b800000, v109// 0000000657B4: C8C6DEFF 3E34DAFF 3B800000
	v_dual_mul_f32 v8, 0x3b800000, v110 :: v_dual_mul_f32 v59, 0x3b800000, v104// 0000000657C0: C8C6DCFF 083AD0FF 3B800000
	v_dual_mul_f32 v56, 0x3b800000, v38 :: v_dual_mul_f32 v11, 0x3b800000, v103// 0000000657CC: C8C64CFF 380ACEFF 3B800000
	v_dual_mul_f32 v10, 0x3b800000, v107 :: v_dual_mul_f32 v57, 0x3b800000, v106// 0000000657D8: C8C6D6FF 0A38D4FF 3B800000
	v_dual_mul_f32 v58, 0x3b800000, v105 :: v_dual_mul_f32 v51, 0x3b800000, v102// 0000000657E4: C8C6D2FF 3A32CCFF 3B800000
	v_dual_mul_f32 v52, 0x3b800000, v101 :: v_dual_mul_f32 v45, 0x3b800000, v98// 0000000657F0: C8C6CAFF 342CC4FF 3B800000
	v_dual_mul_f32 v42, 0x3b800000, v17 :: v_dual_mul_f32 v49, 0x3b800000, v94// 0000000657FC: C8C622FF 2A30BCFF 3B800000
	v_dual_mul_f32 v12, 0x3b800000, v100 :: v_dual_mul_f32 v47, 0x3b800000, v97// 000000065808: C8C6C8FF 0C2EC2FF 3B800000
	v_dual_mul_f32 v44, 0x3b800000, v99 :: v_dual_mul_f32 v15, 0x3b800000, v93// 000000065814: C8C6C6FF 2C0EBAFF 3B800000
	v_dual_mul_f32 v14, 0x3b800000, v96 :: v_dual_mul_f32 v35, 0x3b800000, v91// 000000065820: C8C6C0FF 0E22B6FF 3B800000
	v_dual_mul_f32 v48, 0x3b800000, v95 :: v_dual_mul_f32 v43, 0x3b800000, v92// 00000006582C: C8C6BEFF 302AB8FF 3B800000
	v_dual_mul_f32 v50, 0x3b800000, v9 :: v_dual_mul_f32 v39, 0x3b800000, v88// 000000065838: C8C612FF 3226B0FF 3B800000
	v_dual_mul_f32 v36, 0x3b800000, v90 :: v_dual_mul_f32 v27, 0x3b800000, v89// 000000065844: C8C6B4FF 241AB2FF 3B800000
	v_dual_mul_f32 v40, 0x3b800000, v87 :: v_dual_mul_f32 v41, 0x3b800000, v25// 000000065850: C8C6AEFF 282832FF 3B800000
	v_dual_mul_f32 v28, 0x3b800000, v86 :: v_dual_mul_f32 v31, 0x3b800000, v85// 00000006585C: C8C6ACFF 1C1EAAFF 3B800000
	v_dual_mul_f32 v32, 0x3b800000, v84 :: v_dual_mul_f32 v29, 0x3b800000, v82// 000000065868: C8C6A8FF 201CA4FF 3B800000
	v_dual_mul_f32 v34, 0x3b800000, v83 :: v_dual_mul_f32 v21, 0x3b800000, v80// 000000065874: C8C6A6FF 2214A0FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v81 :: v_dual_mul_f32 v23, 0x3b800000, v78// 000000065880: C8C6A2FF 14169CFF 3B800000
	v_mul_f32_e32 v22, 0x3b800000, v37                         // 00000006588C: 102C4AFF 3B800000
	v_dual_mul_f32 v30, 0x3b800000, v79 :: v_dual_mul_f32 v19, 0x3b800000, v73// 000000065894: C8C69EFF 1E1292FF 3B800000
	v_mul_f32_e32 v24, 0x3b800000, v77                         // 0000000658A0: 10309AFF 3B800000
	v_dual_mul_f32 v26, 0x3b800000, v76 :: v_dual_mul_f32 v13, 0x3b800000, v33// 0000000658A8: C8C698FF 1A0C42FF 3B800000
	v_mul_f32_e32 v16, 0x3b800000, v75                         // 0000000658B4: 102096FF 3B800000
	v_mul_f32_e32 v18, 0x3b800000, v74                         // 0000000658BC: 102494FF 3B800000
	s_cbranch_scc0 5                                           // 0000000658C4: BFA10005 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44dc>
	s_cmp_lg_u32 s13, s54                                      // 0000000658C8: BF07360D
	s_cbranch_scc0 273                                         // 0000000658CC: BFA10111 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4914>
	s_cmp_lg_u32 s14, s54                                      // 0000000658D0: BF07360E
	s_cbranch_scc1 61729                                       // 0000000658D4: BFA2F121 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x95c>
	s_branch 540                                               // 0000000658D8: BFA0021C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4d4c>
	v_mov_b32_e32 v153, v2                                     // 0000000658DC: 7F320302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000658E0: BF870091
	v_ashrrev_i32_e32 v154, 31, v153                           // 0000000658E4: 3535329F
	.long 0xd73c0099                                           // 0000000658E8: D73C0099
	v_cndmask_b32_e32 v1, 2, v153, vcc_lo                      // 0000000658EC: 02033282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000658F0: BF870091
	.long 0xd7006a99                                           // 0000000658F4: D7006A99
	v_cndmask_b32_e32 v1, s42, v153, vcc_lo                    // 0000000658F8: 0203322A
	v_add_co_ci_u32_e64 v154, null, s43, v154, vcc_lo          // 0000000658FC: D5207C9A 01AB342B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065904: BF870092
	.long 0xd7006a9b                                           // 000000065908: D7006A9B
	v_cndmask_b32_e32 v1, 0x1000, v153, vcc_lo                 // 00000006590C: 020332FF 00001000
	v_add_co_ci_u32_e64 v156, null, 0, v154, vcc_lo            // 000000065914: D5207C9C 01AB3480
	.long 0xd7006a9d                                           // 00000006591C: D7006A9D
	v_cndmask_b32_e32 v0, v153, v255, vcc_lo                   // 000000065920: 0201FF99
	.long 0x00002000                                           // 000000065924: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065928: BF8700A1
	v_add_co_ci_u32_e64 v158, null, 0, v154, vcc_lo            // 00000006592C: D5207C9E 01AB3480
	.long 0xd7006a9f                                           // 000000065934: D7006A9F
	v_cndmask_b32_e32 v1, 0x2000, v153, vcc_lo                 // 000000065938: 020332FF 00002000
	v_add_co_ci_u32_e64 v160, null, 0, v154, vcc_lo            // 000000065940: D5207CA0 01AB3480
	s_clause 0x7                                               // 000000065948: BF850007
	global_store_b32 v[153:154], v146, off                     // 00000006594C: DC6A0000 007C9299
	global_store_b32 v[153:154], v147, off offset:1024         // 000000065954: DC6A0400 007C9399
	global_store_b32 v[153:154], v148, off offset:2048         // 00000006595C: DC6A0800 007C9499
	global_store_b32 v[153:154], v149, off offset:3072         // 000000065964: DC6A0C00 007C9599
	global_store_b32 v[155:156], v150, off offset:1024         // 00000006596C: DC6A0400 007C969B
	global_store_b32 v[155:156], v151, off offset:2048         // 000000065974: DC6A0800 007C979B
	global_store_b32 v[155:156], v152, off offset:3072         // 00000006597C: DC6A0C00 007C989B
	global_store_b32 v[159:160], v145, off offset:1024         // 000000065984: DC6A0400 007C919F
	.long 0xd7006a9b                                           // 00000006598C: D7006A9B
	v_cndmask_b32_e32 v1, 0x3000, v153, vcc_lo                 // 000000065990: 020332FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065998: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v154, vcc_lo            // 00000006599C: D5207C9C 01AB3480
	.long 0xd7006aa1                                           // 0000000659A4: D7006AA1
	v_cndmask_b32_e32 v0, v153, v255, vcc_lo                   // 0000000659A8: 0201FF99
	.long 0x00004000                                           // 0000000659AC: 00004000
	v_add_co_ci_u32_e64 v162, null, 0, v154, vcc_lo            // 0000000659B0: D5207CA2 01AB3480
	.long 0xd7006aa3                                           // 0000000659B8: D7006AA3
	v_cndmask_b32_e32 v1, 0x4000, v153, vcc_lo                 // 0000000659BC: 020332FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000659C4: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v154, vcc_lo            // 0000000659C8: D5207CA4 01AB3480
	s_clause 0x7                                               // 0000000659D0: BF850007
	global_store_b32 v[159:160], v140, off offset:2048         // 0000000659D4: DC6A0800 007C8C9F
	global_store_b32 v[159:160], v141, off offset:3072         // 0000000659DC: DC6A0C00 007C8D9F
	global_store_b32 v[155:156], v142, off offset:1024         // 0000000659E4: DC6A0400 007C8E9B
	global_store_b32 v[155:156], v143, off offset:2048         // 0000000659EC: DC6A0800 007C8F9B
	global_store_b32 v[155:156], v144, off offset:3072         // 0000000659F4: DC6A0C00 007C909B
	global_store_b32 v[163:164], v60, off offset:1024          // 0000000659FC: DC6A0400 007C3CA3
	global_store_b32 v[163:164], v61, off offset:2048          // 000000065A04: DC6A0800 007C3DA3
	global_store_b32 v[163:164], v62, off offset:3072          // 000000065A0C: DC6A0C00 007C3EA3
	.long 0xd7006a9b                                           // 000000065A14: D7006A9B
	v_cndmask_b32_e32 v1, 0x5000, v153, vcc_lo                 // 000000065A18: 020332FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065A20: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v154, vcc_lo            // 000000065A24: D5207C9C 01AB3480
	.long 0xd7006a9f                                           // 000000065A2C: D7006A9F
	v_cndmask_b32_e32 v0, v153, v255, vcc_lo                   // 000000065A30: 0201FF99
	.long 0x00006000                                           // 000000065A34: 00006000
	v_add_co_ci_u32_e64 v160, null, 0, v154, vcc_lo            // 000000065A38: D5207CA0 01AB3480
	.long 0xd7006aa3                                           // 000000065A40: D7006AA3
	v_cndmask_b32_e32 v1, 0x6000, v153, vcc_lo                 // 000000065A44: 020332FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065A4C: BF8700A1
	v_add_co_ci_u32_e64 v164, null, 0, v154, vcc_lo            // 000000065A50: D5207CA4 01AB3480
	.long 0xd7006aa5                                           // 000000065A58: D7006AA5
	v_cndmask_b32_e32 v1, 0x7000, v153, vcc_lo                 // 000000065A5C: 020332FF 00007000
	v_add_co_ci_u32_e64 v166, null, 0, v154, vcc_lo            // 000000065A64: D5207CA6 01AB3480
	.long 0xd7006aa7                                           // 000000065A6C: D7006AA7
	v_cndmask_b32_e32 v0, v153, v255, vcc_lo                   // 000000065A70: 0201FF99
	.long 0x00008000                                           // 000000065A74: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000065A78: BF870001
	v_add_co_ci_u32_e64 v168, null, 0, v154, vcc_lo            // 000000065A7C: D5207CA8 01AB3480
	s_clause 0x7                                               // 000000065A84: BF850007
	global_store_b32 v[155:156], v53, off offset:1024          // 000000065A88: DC6A0400 007C359B
	global_store_b32 v[155:156], v55, off offset:2048          // 000000065A90: DC6A0800 007C379B
	global_store_b32 v[155:156], v56, off offset:3072          // 000000065A98: DC6A0C00 007C389B
	global_store_b32 v[163:164], v57, off offset:1024          // 000000065AA0: DC6A0400 007C39A3
	global_store_b32 v[163:164], v58, off offset:2048          // 000000065AA8: DC6A0800 007C3AA3
	global_store_b32 v[163:164], v59, off offset:3072          // 000000065AB0: DC6A0C00 007C3BA3
	global_store_b32 v[165:166], v51, off offset:1024          // 000000065AB8: DC6A0400 007C33A5
	global_store_b32 v[165:166], v52, off offset:2048          // 000000065AC0: DC6A0800 007C34A5
	.long 0xd7006a9b                                           // 000000065AC8: D7006A9B
	v_cndmask_b32_e32 v1, 0x8000, v153, vcc_lo                 // 000000065ACC: 020332FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065AD4: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v154, vcc_lo            // 000000065AD8: D5207C9C 01AB3480
	.long 0xd7006aa3                                           // 000000065AE0: D7006AA3
	v_cndmask_b32_e32 v1, 0x9000, v153, vcc_lo                 // 000000065AE4: 020332FF 00009000
	v_add_co_ci_u32_e64 v164, null, 0, v154, vcc_lo            // 000000065AEC: D5207CA4 01AB3480
	.long 0xd7006aa9                                           // 000000065AF4: D7006AA9
	v_cndmask_b32_e32 v0, v153, v255, vcc_lo                   // 000000065AF8: 0201FF99
	.long 0x0000a000                                           // 000000065AFC: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065B00: BF8700A1
	v_add_co_ci_u32_e64 v170, null, 0, v154, vcc_lo            // 000000065B04: D5207CAA 01AB3480
	.long 0xd7006aab                                           // 000000065B0C: D7006AAB
	v_cndmask_b32_e32 v1, 0xa000, v153, vcc_lo                 // 000000065B10: 020332FF 0000A000
	v_add_co_ci_u32_e64 v172, null, 0, v154, vcc_lo            // 000000065B18: D5207CAC 01AB3480
	s_clause 0x7                                               // 000000065B20: BF850007
	global_store_b32 v[165:166], v42, off offset:3072          // 000000065B24: DC6A0C00 007C2AA5
	global_store_b32 v[155:156], v44, off offset:1024          // 000000065B2C: DC6A0400 007C2C9B
	global_store_b32 v[155:156], v45, off offset:2048          // 000000065B34: DC6A0800 007C2D9B
	global_store_b32 v[155:156], v47, off offset:3072          // 000000065B3C: DC6A0C00 007C2F9B
	global_store_b32 v[163:164], v48, off offset:1024          // 000000065B44: DC6A0400 007C30A3
	global_store_b32 v[163:164], v49, off offset:2048          // 000000065B4C: DC6A0800 007C31A3
	global_store_b32 v[163:164], v50, off offset:3072          // 000000065B54: DC6A0C00 007C32A3
	global_store_b32 v[171:172], v43, off offset:1024          // 000000065B5C: DC6A0400 007C2BAB
	.long 0xd7006a9b                                           // 000000065B64: D7006A9B
	v_cndmask_b32_e32 v1, 0xb000, v153, vcc_lo                 // 000000065B68: 020332FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065B70: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v154, vcc_lo            // 000000065B74: D5207C9C 01AB3480
	.long 0xd7006aa3                                           // 000000065B7C: D7006AA3
	v_cndmask_b32_e32 v0, v153, v255, vcc_lo                   // 000000065B80: 0201FF99
	.long 0x0000c000                                           // 000000065B84: 0000C000
	v_add_co_ci_u32_e64 v164, null, 0, v154, vcc_lo            // 000000065B88: D5207CA4 01AB3480
	.long 0xd7006aa5                                           // 000000065B90: D7006AA5
	v_cndmask_b32_e32 v1, 0xc000, v153, vcc_lo                 // 000000065B94: 020332FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000065B9C: BF870001
	v_add_co_ci_u32_e64 v166, null, 0, v154, vcc_lo            // 000000065BA0: D5207CA6 01AB3480
	s_clause 0x7                                               // 000000065BA8: BF850007
	global_store_b32 v[171:172], v35, off offset:2048          // 000000065BAC: DC6A0800 007C23AB
	global_store_b32 v[171:172], v36, off offset:3072          // 000000065BB4: DC6A0C00 007C24AB
	global_store_b32 v[155:156], v39, off offset:1024          // 000000065BBC: DC6A0400 007C279B
	global_store_b32 v[155:156], v40, off offset:2048          // 000000065BC4: DC6A0800 007C289B
	global_store_b32 v[155:156], v41, off offset:3072          // 000000065BCC: DC6A0C00 007C299B
	global_store_b32 v[165:166], v31, off offset:1024          // 000000065BD4: DC6A0400 007C1FA5
	global_store_b32 v[165:166], v32, off offset:2048          // 000000065BDC: DC6A0800 007C20A5
	global_store_b32 v[165:166], v34, off offset:3072          // 000000065BE4: DC6A0C00 007C22A5
	.long 0xd7006a9b                                           // 000000065BEC: D7006A9B
	v_cndmask_b32_e32 v1, 0xd000, v153, vcc_lo                 // 000000065BF0: 020332FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065BF8: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v154, vcc_lo            // 000000065BFC: D5207C9C 01AB3480
	.long 0xd7006aa5                                           // 000000065C04: D7006AA5
	v_cndmask_b32_e32 v0, v153, v255, vcc_lo                   // 000000065C08: 0201FF99
	.long 0x0000e000                                           // 000000065C0C: 0000E000
	v_add_co_ci_u32_e64 v166, null, 0, v154, vcc_lo            // 000000065C10: D5207CA6 01AB3480
	.long 0xd7006aab                                           // 000000065C18: D7006AAB
	v_cndmask_b32_e32 v1, 0xe000, v153, vcc_lo                 // 000000065C1C: 020332FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000065C24: BF870001
	v_add_co_ci_u32_e64 v172, null, 0, v154, vcc_lo            // 000000065C28: D5207CAC 01AB3480
	.long 0xd7006a99                                           // 000000065C30: D7006A99
	v_cndmask_b32_e32 v1, 0xf000, v153, vcc_lo                 // 000000065C34: 020332FF 0000F000
	s_clause 0x7                                               // 000000065C3C: BF850007
	global_store_b32 v[167:168], v11, off offset:-4096         // 000000065C40: DC6A1000 007C0BA7
	global_store_b32 v[167:168], v12, off                      // 000000065C48: DC6A0000 007C0CA7
	global_store_b32 v[169:170], v14, off offset:-4096         // 000000065C50: DC6A1000 007C0EA9
	global_store_b32 v[169:170], v15, off                      // 000000065C58: DC6A0000 007C0FA9
	global_store_b32 v[163:164], v27, off offset:-4096         // 000000065C60: DC6A1000 007C1BA3
	global_store_b32 v[163:164], v28, off                      // 000000065C68: DC6A0000 007C1CA3
	global_store_b32 v[165:166], v29, off offset:-4096         // 000000065C70: DC6A1000 007C1DA5
	global_store_b32 v[165:166], v30, off                      // 000000065C78: DC6A0000 007C1EA5
	v_add_co_ci_u32_e64 v154, null, 0, v154, vcc_lo            // 000000065C80: D5207C9A 01AB3480
	s_clause 0xf                                               // 000000065C88: BF85000F
	global_store_b32 v[155:156], v20, off offset:1024          // 000000065C8C: DC6A0400 007C149B
	global_store_b32 v[155:156], v21, off offset:2048          // 000000065C94: DC6A0800 007C159B
	global_store_b32 v[155:156], v22, off offset:3072          // 000000065C9C: DC6A0C00 007C169B
	global_store_b32 v[171:172], v23, off offset:1024          // 000000065CA4: DC6A0400 007C17AB
	global_store_b32 v[171:172], v24, off offset:2048          // 000000065CAC: DC6A0800 007C18AB
	global_store_b32 v[171:172], v26, off offset:3072          // 000000065CB4: DC6A0C00 007C1AAB
	global_store_b32 v[153:154], v16, off                      // 000000065CBC: DC6A0000 007C1099
	global_store_b32 v[153:154], v18, off offset:1024          // 000000065CC4: DC6A0400 007C1299
	global_store_b32 v[153:154], v19, off offset:2048          // 000000065CCC: DC6A0800 007C1399
	global_store_b32 v[157:158], v4, off offset:-4096          // 000000065CD4: DC6A1000 007C049D
	global_store_b32 v[157:158], v5, off                       // 000000065CDC: DC6A0000 007C059D
	global_store_b32 v[161:162], v6, off offset:-4096          // 000000065CE4: DC6A1000 007C06A1
	global_store_b32 v[161:162], v7, off                       // 000000065CEC: DC6A0000 007C07A1
	global_store_b32 v[159:160], v8, off offset:-4096          // 000000065CF4: DC6A1000 007C089F
	global_store_b32 v[159:160], v10, off                      // 000000065CFC: DC6A0000 007C0A9F
	global_store_b32 v[153:154], v13, off offset:3072          // 000000065D04: DC6A0C00 007C0D99
	s_cmp_lg_u32 s13, s54                                      // 000000065D0C: BF07360D
	s_cbranch_scc1 65263                                       // 000000065D10: BFA2FEEF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44d0>
	v_mov_b32_e32 v153, v2                                     // 000000065D14: 7F320302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065D18: BF870091
	v_ashrrev_i32_e32 v154, 31, v153                           // 000000065D1C: 3535329F
	.long 0xd73c0099                                           // 000000065D20: D73C0099
	v_cndmask_b32_e32 v1, 2, v153, vcc_lo                      // 000000065D24: 02033282
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065D28: BF870091
	.long 0xd7006a99                                           // 000000065D2C: D7006A99
	v_cndmask_b32_e32 v1, s44, v153, vcc_lo                    // 000000065D30: 0203322C
	v_add_co_ci_u32_e64 v154, null, s45, v154, vcc_lo          // 000000065D34: D5207C9A 01AB342D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000065D3C: BF870092
	.long 0xd7006a9b                                           // 000000065D40: D7006A9B
	v_cndmask_b32_e32 v1, 0x1000, v153, vcc_lo                 // 000000065D44: 020332FF 00001000
	v_add_co_ci_u32_e64 v156, null, 0, v154, vcc_lo            // 000000065D4C: D5207C9C 01AB3480
	.long 0xd7006a9d                                           // 000000065D54: D7006A9D
	v_cndmask_b32_e32 v0, v153, v255, vcc_lo                   // 000000065D58: 0201FF99
	.long 0x00002000                                           // 000000065D5C: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065D60: BF8700A1
	v_add_co_ci_u32_e64 v158, null, 0, v154, vcc_lo            // 000000065D64: D5207C9E 01AB3480
	.long 0xd7006a9f                                           // 000000065D6C: D7006A9F
	v_cndmask_b32_e32 v1, 0x2000, v153, vcc_lo                 // 000000065D70: 020332FF 00002000
	v_add_co_ci_u32_e64 v160, null, 0, v154, vcc_lo            // 000000065D78: D5207CA0 01AB3480
	s_clause 0x7                                               // 000000065D80: BF850007
	global_store_b32 v[153:154], v146, off                     // 000000065D84: DC6A0000 007C9299
	global_store_b32 v[153:154], v147, off offset:1024         // 000000065D8C: DC6A0400 007C9399
	global_store_b32 v[153:154], v148, off offset:2048         // 000000065D94: DC6A0800 007C9499
	global_store_b32 v[153:154], v149, off offset:3072         // 000000065D9C: DC6A0C00 007C9599
	global_store_b32 v[155:156], v150, off offset:1024         // 000000065DA4: DC6A0400 007C969B
	global_store_b32 v[155:156], v151, off offset:2048         // 000000065DAC: DC6A0800 007C979B
	global_store_b32 v[155:156], v152, off offset:3072         // 000000065DB4: DC6A0C00 007C989B
	global_store_b32 v[159:160], v145, off offset:1024         // 000000065DBC: DC6A0400 007C919F
	.long 0xd7006a9b                                           // 000000065DC4: D7006A9B
	v_cndmask_b32_e32 v1, 0x3000, v153, vcc_lo                 // 000000065DC8: 020332FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065DD0: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v154, vcc_lo            // 000000065DD4: D5207C9C 01AB3480
	.long 0xd7006aa1                                           // 000000065DDC: D7006AA1
	v_cndmask_b32_e32 v0, v153, v255, vcc_lo                   // 000000065DE0: 0201FF99
	.long 0x00004000                                           // 000000065DE4: 00004000
	v_add_co_ci_u32_e64 v162, null, 0, v154, vcc_lo            // 000000065DE8: D5207CA2 01AB3480
	.long 0xd7006aa3                                           // 000000065DF0: D7006AA3
	v_cndmask_b32_e32 v1, 0x4000, v153, vcc_lo                 // 000000065DF4: 020332FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000065DFC: BF870001
	v_add_co_ci_u32_e64 v164, null, 0, v154, vcc_lo            // 000000065E00: D5207CA4 01AB3480
	s_clause 0x7                                               // 000000065E08: BF850007
	global_store_b32 v[159:160], v140, off offset:2048         // 000000065E0C: DC6A0800 007C8C9F
	global_store_b32 v[159:160], v141, off offset:3072         // 000000065E14: DC6A0C00 007C8D9F
	global_store_b32 v[155:156], v142, off offset:1024         // 000000065E1C: DC6A0400 007C8E9B
	global_store_b32 v[155:156], v143, off offset:2048         // 000000065E24: DC6A0800 007C8F9B
	global_store_b32 v[155:156], v144, off offset:3072         // 000000065E2C: DC6A0C00 007C909B
	global_store_b32 v[163:164], v60, off offset:1024          // 000000065E34: DC6A0400 007C3CA3
	global_store_b32 v[163:164], v61, off offset:2048          // 000000065E3C: DC6A0800 007C3DA3
	global_store_b32 v[163:164], v62, off offset:3072          // 000000065E44: DC6A0C00 007C3EA3
	.long 0xd7006a9b                                           // 000000065E4C: D7006A9B
	v_cndmask_b32_e32 v1, 0x5000, v153, vcc_lo                 // 000000065E50: 020332FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065E58: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v154, vcc_lo            // 000000065E5C: D5207C9C 01AB3480
	.long 0xd7006a9f                                           // 000000065E64: D7006A9F
	v_cndmask_b32_e32 v0, v153, v255, vcc_lo                   // 000000065E68: 0201FF99
	.long 0x00006000                                           // 000000065E6C: 00006000
	v_add_co_ci_u32_e64 v160, null, 0, v154, vcc_lo            // 000000065E70: D5207CA0 01AB3480
	.long 0xd7006aa3                                           // 000000065E78: D7006AA3
	v_cndmask_b32_e32 v1, 0x6000, v153, vcc_lo                 // 000000065E7C: 020332FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065E84: BF8700A1
	v_add_co_ci_u32_e64 v164, null, 0, v154, vcc_lo            // 000000065E88: D5207CA4 01AB3480
	.long 0xd7006aa5                                           // 000000065E90: D7006AA5
	v_cndmask_b32_e32 v1, 0x7000, v153, vcc_lo                 // 000000065E94: 020332FF 00007000
	v_add_co_ci_u32_e64 v166, null, 0, v154, vcc_lo            // 000000065E9C: D5207CA6 01AB3480
	.long 0xd7006aa7                                           // 000000065EA4: D7006AA7
	v_cndmask_b32_e32 v0, v153, v255, vcc_lo                   // 000000065EA8: 0201FF99
	.long 0x00008000                                           // 000000065EAC: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000065EB0: BF870001
	v_add_co_ci_u32_e64 v168, null, 0, v154, vcc_lo            // 000000065EB4: D5207CA8 01AB3480
	s_clause 0x7                                               // 000000065EBC: BF850007
	global_store_b32 v[155:156], v53, off offset:1024          // 000000065EC0: DC6A0400 007C359B
	global_store_b32 v[155:156], v55, off offset:2048          // 000000065EC8: DC6A0800 007C379B
	global_store_b32 v[155:156], v56, off offset:3072          // 000000065ED0: DC6A0C00 007C389B
	global_store_b32 v[163:164], v57, off offset:1024          // 000000065ED8: DC6A0400 007C39A3
	global_store_b32 v[163:164], v58, off offset:2048          // 000000065EE0: DC6A0800 007C3AA3
	global_store_b32 v[163:164], v59, off offset:3072          // 000000065EE8: DC6A0C00 007C3BA3
	global_store_b32 v[165:166], v51, off offset:1024          // 000000065EF0: DC6A0400 007C33A5
	global_store_b32 v[165:166], v52, off offset:2048          // 000000065EF8: DC6A0800 007C34A5
	.long 0xd7006a9b                                           // 000000065F00: D7006A9B
	v_cndmask_b32_e32 v1, 0x8000, v153, vcc_lo                 // 000000065F04: 020332FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065F0C: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v154, vcc_lo            // 000000065F10: D5207C9C 01AB3480
	.long 0xd7006aa3                                           // 000000065F18: D7006AA3
	v_cndmask_b32_e32 v1, 0x9000, v153, vcc_lo                 // 000000065F1C: 020332FF 00009000
	v_add_co_ci_u32_e64 v164, null, 0, v154, vcc_lo            // 000000065F24: D5207CA4 01AB3480
	.long 0xd7006aa9                                           // 000000065F2C: D7006AA9
	v_cndmask_b32_e32 v0, v153, v255, vcc_lo                   // 000000065F30: 0201FF99
	.long 0x0000a000                                           // 000000065F34: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065F38: BF8700A1
	v_add_co_ci_u32_e64 v170, null, 0, v154, vcc_lo            // 000000065F3C: D5207CAA 01AB3480
	.long 0xd7006aab                                           // 000000065F44: D7006AAB
	v_cndmask_b32_e32 v1, 0xa000, v153, vcc_lo                 // 000000065F48: 020332FF 0000A000
	v_add_co_ci_u32_e64 v172, null, 0, v154, vcc_lo            // 000000065F50: D5207CAC 01AB3480
	s_clause 0x7                                               // 000000065F58: BF850007
	global_store_b32 v[165:166], v42, off offset:3072          // 000000065F5C: DC6A0C00 007C2AA5
	global_store_b32 v[155:156], v44, off offset:1024          // 000000065F64: DC6A0400 007C2C9B
	global_store_b32 v[155:156], v45, off offset:2048          // 000000065F6C: DC6A0800 007C2D9B
	global_store_b32 v[155:156], v47, off offset:3072          // 000000065F74: DC6A0C00 007C2F9B
	global_store_b32 v[163:164], v48, off offset:1024          // 000000065F7C: DC6A0400 007C30A3
	global_store_b32 v[163:164], v49, off offset:2048          // 000000065F84: DC6A0800 007C31A3
	global_store_b32 v[163:164], v50, off offset:3072          // 000000065F8C: DC6A0C00 007C32A3
	global_store_b32 v[171:172], v43, off offset:1024          // 000000065F94: DC6A0400 007C2BAB
	.long 0xd7006a9b                                           // 000000065F9C: D7006A9B
	v_cndmask_b32_e32 v1, 0xb000, v153, vcc_lo                 // 000000065FA0: 020332FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000065FA8: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v154, vcc_lo            // 000000065FAC: D5207C9C 01AB3480
	.long 0xd7006aa3                                           // 000000065FB4: D7006AA3
	v_cndmask_b32_e32 v0, v153, v255, vcc_lo                   // 000000065FB8: 0201FF99
	.long 0x0000c000                                           // 000000065FBC: 0000C000
	v_add_co_ci_u32_e64 v164, null, 0, v154, vcc_lo            // 000000065FC0: D5207CA4 01AB3480
	.long 0xd7006aa5                                           // 000000065FC8: D7006AA5
	v_cndmask_b32_e32 v1, 0xc000, v153, vcc_lo                 // 000000065FCC: 020332FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000065FD4: BF870001
	v_add_co_ci_u32_e64 v166, null, 0, v154, vcc_lo            // 000000065FD8: D5207CA6 01AB3480
	s_clause 0x7                                               // 000000065FE0: BF850007
	global_store_b32 v[171:172], v35, off offset:2048          // 000000065FE4: DC6A0800 007C23AB
	global_store_b32 v[171:172], v36, off offset:3072          // 000000065FEC: DC6A0C00 007C24AB
	global_store_b32 v[155:156], v39, off offset:1024          // 000000065FF4: DC6A0400 007C279B
	global_store_b32 v[155:156], v40, off offset:2048          // 000000065FFC: DC6A0800 007C289B
	global_store_b32 v[155:156], v41, off offset:3072          // 000000066004: DC6A0C00 007C299B
	global_store_b32 v[165:166], v31, off offset:1024          // 00000006600C: DC6A0400 007C1FA5
	global_store_b32 v[165:166], v32, off offset:2048          // 000000066014: DC6A0800 007C20A5
	global_store_b32 v[165:166], v34, off offset:3072          // 00000006601C: DC6A0C00 007C22A5
	.long 0xd7006a9b                                           // 000000066024: D7006A9B
	v_cndmask_b32_e32 v1, 0xd000, v153, vcc_lo                 // 000000066028: 020332FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000066030: BF8700A1
	v_add_co_ci_u32_e64 v156, null, 0, v154, vcc_lo            // 000000066034: D5207C9C 01AB3480
	.long 0xd7006aa5                                           // 00000006603C: D7006AA5
	v_cndmask_b32_e32 v0, v153, v255, vcc_lo                   // 000000066040: 0201FF99
	.long 0x0000e000                                           // 000000066044: 0000E000
	v_add_co_ci_u32_e64 v166, null, 0, v154, vcc_lo            // 000000066048: D5207CA6 01AB3480
	.long 0xd7006aab                                           // 000000066050: D7006AAB
	v_cndmask_b32_e32 v1, 0xe000, v153, vcc_lo                 // 000000066054: 020332FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006605C: BF870001
	v_add_co_ci_u32_e64 v172, null, 0, v154, vcc_lo            // 000000066060: D5207CAC 01AB3480
	.long 0xd7006a99                                           // 000000066068: D7006A99
	v_cndmask_b32_e32 v1, 0xf000, v153, vcc_lo                 // 00000006606C: 020332FF 0000F000
	s_clause 0x7                                               // 000000066074: BF850007
	global_store_b32 v[167:168], v11, off offset:-4096         // 000000066078: DC6A1000 007C0BA7
	global_store_b32 v[167:168], v12, off                      // 000000066080: DC6A0000 007C0CA7
	global_store_b32 v[169:170], v14, off offset:-4096         // 000000066088: DC6A1000 007C0EA9
	global_store_b32 v[169:170], v15, off                      // 000000066090: DC6A0000 007C0FA9
	global_store_b32 v[163:164], v27, off offset:-4096         // 000000066098: DC6A1000 007C1BA3
	global_store_b32 v[163:164], v28, off                      // 0000000660A0: DC6A0000 007C1CA3
	global_store_b32 v[165:166], v29, off offset:-4096         // 0000000660A8: DC6A1000 007C1DA5
	global_store_b32 v[165:166], v30, off                      // 0000000660B0: DC6A0000 007C1EA5
	v_add_co_ci_u32_e64 v154, null, 0, v154, vcc_lo            // 0000000660B8: D5207C9A 01AB3480
	s_clause 0xf                                               // 0000000660C0: BF85000F
	global_store_b32 v[155:156], v20, off offset:1024          // 0000000660C4: DC6A0400 007C149B
	global_store_b32 v[155:156], v21, off offset:2048          // 0000000660CC: DC6A0800 007C159B
	global_store_b32 v[155:156], v22, off offset:3072          // 0000000660D4: DC6A0C00 007C169B
	global_store_b32 v[171:172], v23, off offset:1024          // 0000000660DC: DC6A0400 007C17AB
	global_store_b32 v[171:172], v24, off offset:2048          // 0000000660E4: DC6A0800 007C18AB
	global_store_b32 v[171:172], v26, off offset:3072          // 0000000660EC: DC6A0C00 007C1AAB
	global_store_b32 v[153:154], v16, off                      // 0000000660F4: DC6A0000 007C1099
	global_store_b32 v[153:154], v18, off offset:1024          // 0000000660FC: DC6A0400 007C1299
	global_store_b32 v[153:154], v19, off offset:2048          // 000000066104: DC6A0800 007C1399
	global_store_b32 v[157:158], v4, off offset:-4096          // 00000006610C: DC6A1000 007C049D
	global_store_b32 v[157:158], v5, off                       // 000000066114: DC6A0000 007C059D
	global_store_b32 v[161:162], v6, off offset:-4096          // 00000006611C: DC6A1000 007C06A1
	global_store_b32 v[161:162], v7, off                       // 000000066124: DC6A0000 007C07A1
	global_store_b32 v[159:160], v8, off offset:-4096          // 00000006612C: DC6A1000 007C089F
	global_store_b32 v[159:160], v10, off                      // 000000066134: DC6A0000 007C0A9F
	global_store_b32 v[153:154], v13, off offset:3072          // 00000006613C: DC6A0C00 007C0D99
	s_cmp_lg_u32 s14, s54                                      // 000000066144: BF07360E
	s_cbranch_scc1 61188                                       // 000000066148: BFA2EF04 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x95c>
	v_ashrrev_i32_e32 v3, 31, v2                               // 00000006614C: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000066150: BF870091
	.long 0xd73c0002                                           // 000000066154: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000066158: 02020482
	.long 0xd7006a02                                           // 00000006615C: D7006A02
	v_cndmask_b32_e32 v1, s46, v2, vcc_lo                      // 000000066160: 0202042E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000066164: BF870111
	v_add_co_ci_u32_e64 v3, null, s47, v3, vcc_lo              // 000000066168: D5207C03 01AA062F
	.long 0xd7006a99                                           // 000000066170: D7006A99
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 000000066174: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006617C: BF8700A1
	v_add_co_ci_u32_e64 v154, null, 0, v3, vcc_lo              // 000000066180: D5207C9A 01AA0680
	.long 0xd7006a9b                                           // 000000066188: D7006A9B
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000006618C: 0201FF02
	.long 0x00002000                                           // 000000066190: 00002000
	v_add_co_ci_u32_e64 v156, null, 0, v3, vcc_lo              // 000000066194: D5207C9C 01AA0680
	.long 0xd7006a9d                                           // 00000006619C: D7006A9D
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 0000000661A0: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000661A8: BF870001
	v_add_co_ci_u32_e64 v158, null, 0, v3, vcc_lo              // 0000000661AC: D5207C9E 01AA0680
	s_clause 0x7                                               // 0000000661B4: BF850007
	global_store_b32 v[2:3], v146, off                         // 0000000661B8: DC6A0000 007C9202
	global_store_b32 v[2:3], v147, off offset:1024             // 0000000661C0: DC6A0400 007C9302
	global_store_b32 v[2:3], v148, off offset:2048             // 0000000661C8: DC6A0800 007C9402
	global_store_b32 v[2:3], v149, off offset:3072             // 0000000661D0: DC6A0C00 007C9502
	global_store_b32 v[153:154], v150, off offset:1024         // 0000000661D8: DC6A0400 007C9699
	global_store_b32 v[153:154], v151, off offset:2048         // 0000000661E0: DC6A0800 007C9799
	global_store_b32 v[153:154], v152, off offset:3072         // 0000000661E8: DC6A0C00 007C9899
	global_store_b32 v[157:158], v145, off offset:1024         // 0000000661F0: DC6A0400 007C919D
	.long 0xd7006a91                                           // 0000000661F8: D7006A91
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 0000000661FC: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000066204: BF8700A1
	v_add_co_ci_u32_e64 v146, null, 0, v3, vcc_lo              // 000000066208: D5207C92 01AA0680
	.long 0xd7006a93                                           // 000000066210: D7006A93
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000066214: 0201FF02
	.long 0x00004000                                           // 000000066218: 00004000
	v_add_co_ci_u32_e64 v148, null, 0, v3, vcc_lo              // 00000006621C: D5207C94 01AA0680
	.long 0xd7006a95                                           // 000000066224: D7006A95
	v_cndmask_b32_e32 v1, 0x4000, v2, vcc_lo                   // 000000066228: 020204FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000066230: BF870001
	v_add_co_ci_u32_e64 v150, null, 0, v3, vcc_lo              // 000000066234: D5207C96 01AA0680
	s_clause 0x7                                               // 00000006623C: BF850007
	global_store_b32 v[157:158], v140, off offset:2048         // 000000066240: DC6A0800 007C8C9D
	global_store_b32 v[157:158], v141, off offset:3072         // 000000066248: DC6A0C00 007C8D9D
	global_store_b32 v[145:146], v142, off offset:1024         // 000000066250: DC6A0400 007C8E91
	global_store_b32 v[145:146], v143, off offset:2048         // 000000066258: DC6A0800 007C8F91
	global_store_b32 v[145:146], v144, off offset:3072         // 000000066260: DC6A0C00 007C9091
	global_store_b32 v[149:150], v60, off offset:1024          // 000000066268: DC6A0400 007C3C95
	global_store_b32 v[149:150], v61, off offset:2048          // 000000066270: DC6A0800 007C3D95
	global_store_b32 v[149:150], v62, off offset:3072          // 000000066278: DC6A0C00 007C3E95
	.long 0xd7006a3c                                           // 000000066280: D7006A3C
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 000000066284: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006628C: BF8700A1
	v_add_co_ci_u32_e64 v61, null, 0, v3, vcc_lo               // 000000066290: D5207C3D 01AA0680
	.long 0xd7006a8c                                           // 000000066298: D7006A8C
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 00000006629C: 0201FF02
	.long 0x00006000                                           // 0000000662A0: 00006000
	v_add_co_ci_u32_e64 v141, null, 0, v3, vcc_lo              // 0000000662A4: D5207C8D 01AA0680
	.long 0xd7006a8e                                           // 0000000662AC: D7006A8E
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 0000000662B0: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000662B8: BF8700A1
	v_add_co_ci_u32_e64 v143, null, 0, v3, vcc_lo              // 0000000662BC: D5207C8F 01AA0680
	.long 0xd7006a90                                           // 0000000662C4: D7006A90
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 0000000662C8: 020204FF 00007000
	v_add_co_ci_u32_e64 v145, null, 0, v3, vcc_lo              // 0000000662D0: D5207C91 01AA0680
	.long 0xd7006a95                                           // 0000000662D8: D7006A95
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 0000000662DC: 0201FF02
	.long 0x00008000                                           // 0000000662E0: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000662E4: BF870001
	v_add_co_ci_u32_e64 v150, null, 0, v3, vcc_lo              // 0000000662E8: D5207C96 01AA0680
	s_clause 0x7                                               // 0000000662F0: BF850007
	global_store_b32 v[60:61], v53, off offset:1024            // 0000000662F4: DC6A0400 007C353C
	global_store_b32 v[60:61], v55, off offset:2048            // 0000000662FC: DC6A0800 007C373C
	global_store_b32 v[60:61], v56, off offset:3072            // 000000066304: DC6A0C00 007C383C
	global_store_b32 v[142:143], v57, off offset:1024          // 00000006630C: DC6A0400 007C398E
	global_store_b32 v[142:143], v58, off offset:2048          // 000000066314: DC6A0800 007C3A8E
	global_store_b32 v[142:143], v59, off offset:3072          // 00000006631C: DC6A0C00 007C3B8E
	global_store_b32 v[144:145], v51, off offset:1024          // 000000066324: DC6A0400 007C3390
	global_store_b32 v[144:145], v52, off offset:2048          // 00000006632C: DC6A0800 007C3490
	.long 0xd7006a33                                           // 000000066334: D7006A33
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 000000066338: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000066340: BF8700A1
	v_add_co_ci_u32_e64 v52, null, 0, v3, vcc_lo               // 000000066344: D5207C34 01AA0680
	.long 0xd7006a37                                           // 00000006634C: D7006A37
	v_cndmask_b32_e32 v1, 0x9000, v2, vcc_lo                   // 000000066350: 020204FF 00009000
	v_add_co_ci_u32_e64 v56, null, 0, v3, vcc_lo               // 000000066358: D5207C38 01AA0680
	.long 0xd7006a39                                           // 000000066360: D7006A39
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000066364: 0201FF02
	.long 0x0000a000                                           // 000000066368: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006636C: BF8700A1
	v_add_co_ci_u32_e64 v58, null, 0, v3, vcc_lo               // 000000066370: D5207C3A 01AA0680
	.long 0xd7006a3b                                           // 000000066378: D7006A3B
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 00000006637C: 020204FF 0000A000
	v_add_co_ci_u32_e64 v60, null, 0, v3, vcc_lo               // 000000066384: D5207C3C 01AA0680
	s_clause 0x7                                               // 00000006638C: BF850007
	global_store_b32 v[144:145], v42, off offset:3072          // 000000066390: DC6A0C00 007C2A90
	global_store_b32 v[51:52], v44, off offset:1024            // 000000066398: DC6A0400 007C2C33
	global_store_b32 v[51:52], v45, off offset:2048            // 0000000663A0: DC6A0800 007C2D33
	global_store_b32 v[51:52], v47, off offset:3072            // 0000000663A8: DC6A0C00 007C2F33
	global_store_b32 v[55:56], v48, off offset:1024            // 0000000663B0: DC6A0400 007C3037
	global_store_b32 v[55:56], v49, off offset:2048            // 0000000663B8: DC6A0800 007C3137
	global_store_b32 v[55:56], v50, off offset:3072            // 0000000663C0: DC6A0C00 007C3237
	global_store_b32 v[59:60], v43, off offset:1024            // 0000000663C8: DC6A0400 007C2B3B
	.long 0xd7006a2a                                           // 0000000663D0: D7006A2A
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 0000000663D4: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000663DC: BF8700A1
	v_add_co_ci_u32_e64 v43, null, 0, v3, vcc_lo               // 0000000663E0: D5207C2B 01AA0680
	.long 0xd7006a2c                                           // 0000000663E8: D7006A2C
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 0000000663EC: 0201FF02
	.long 0x0000c000                                           // 0000000663F0: 0000C000
	v_add_co_ci_u32_e64 v45, null, 0, v3, vcc_lo               // 0000000663F4: D5207C2D 01AA0680
	.long 0xd7006a2f                                           // 0000000663FC: D7006A2F
	v_cndmask_b32_e32 v1, 0xc000, v2, vcc_lo                   // 000000066400: 020204FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000066408: BF870001
	v_add_co_ci_u32_e64 v48, null, 0, v3, vcc_lo               // 00000006640C: D5207C30 01AA0680
	s_clause 0x7                                               // 000000066414: BF850007
	global_store_b32 v[59:60], v35, off offset:2048            // 000000066418: DC6A0800 007C233B
	global_store_b32 v[59:60], v36, off offset:3072            // 000000066420: DC6A0C00 007C243B
	global_store_b32 v[42:43], v39, off offset:1024            // 000000066428: DC6A0400 007C272A
	global_store_b32 v[42:43], v40, off offset:2048            // 000000066430: DC6A0800 007C282A
	global_store_b32 v[42:43], v41, off offset:3072            // 000000066438: DC6A0C00 007C292A
	global_store_b32 v[47:48], v31, off offset:1024            // 000000066440: DC6A0400 007C1F2F
	global_store_b32 v[47:48], v32, off offset:2048            // 000000066448: DC6A0800 007C202F
	global_store_b32 v[47:48], v34, off offset:3072            // 000000066450: DC6A0C00 007C222F
	.long 0xd7006a1f                                           // 000000066458: D7006A1F
	v_cndmask_b32_e32 v1, 0xd000, v2, vcc_lo                   // 00000006645C: 020204FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000066464: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v3, vcc_lo               // 000000066468: D5207C20 01AA0680
	.long 0xd7006a22                                           // 000000066470: D7006A22
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000066474: 0201FF02
	.long 0x0000e000                                           // 000000066478: 0000E000
	v_add_co_ci_u32_e64 v35, null, 0, v3, vcc_lo               // 00000006647C: D5207C23 01AA0680
	.long 0xd7006a27                                           // 000000066484: D7006A27
	v_cndmask_b32_e32 v1, 0xe000, v2, vcc_lo                   // 000000066488: 020204FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000066490: BF870001
	v_add_co_ci_u32_e64 v40, null, 0, v3, vcc_lo               // 000000066494: D5207C28 01AA0680
	.long 0xd7006a02                                           // 00000006649C: D7006A02
	v_cndmask_b32_e32 v1, 0xf000, v2, vcc_lo                   // 0000000664A0: 020204FF 0000F000
	s_clause 0x7                                               // 0000000664A8: BF850007
	global_store_b32 v[149:150], v11, off offset:-4096         // 0000000664AC: DC6A1000 007C0B95
	global_store_b32 v[149:150], v12, off                      // 0000000664B4: DC6A0000 007C0C95
	global_store_b32 v[57:58], v14, off offset:-4096           // 0000000664BC: DC6A1000 007C0E39
	global_store_b32 v[57:58], v15, off                        // 0000000664C4: DC6A0000 007C0F39
	global_store_b32 v[44:45], v27, off offset:-4096           // 0000000664CC: DC6A1000 007C1B2C
	global_store_b32 v[44:45], v28, off                        // 0000000664D4: DC6A0000 007C1C2C
	global_store_b32 v[34:35], v29, off offset:-4096           // 0000000664DC: DC6A1000 007C1D22
	global_store_b32 v[34:35], v30, off                        // 0000000664E4: DC6A0000 007C1E22
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 0000000664EC: D5207C03 01AA0680
	s_clause 0xf                                               // 0000000664F4: BF85000F
	global_store_b32 v[31:32], v20, off offset:1024            // 0000000664F8: DC6A0400 007C141F
	global_store_b32 v[31:32], v21, off offset:2048            // 000000066500: DC6A0800 007C151F
	global_store_b32 v[31:32], v22, off offset:3072            // 000000066508: DC6A0C00 007C161F
	global_store_b32 v[39:40], v23, off offset:1024            // 000000066510: DC6A0400 007C1727
	global_store_b32 v[39:40], v24, off offset:2048            // 000000066518: DC6A0800 007C1827
	global_store_b32 v[39:40], v26, off offset:3072            // 000000066520: DC6A0C00 007C1A27
	global_store_b32 v[2:3], v16, off                          // 000000066528: DC6A0000 007C1002
	global_store_b32 v[2:3], v18, off offset:1024              // 000000066530: DC6A0400 007C1202
	global_store_b32 v[2:3], v19, off offset:2048              // 000000066538: DC6A0800 007C1302
	global_store_b32 v[155:156], v4, off offset:-4096          // 000000066540: DC6A1000 007C049B
	global_store_b32 v[155:156], v5, off                       // 000000066548: DC6A0000 007C059B
	global_store_b32 v[147:148], v6, off offset:-4096          // 000000066550: DC6A1000 007C0693
	global_store_b32 v[147:148], v7, off                       // 000000066558: DC6A0000 007C0793
	global_store_b32 v[140:141], v8, off offset:-4096          // 000000066560: DC6A1000 007C088C
	global_store_b32 v[140:141], v10, off                      // 000000066568: DC6A0000 007C0A8C
	global_store_b32 v[2:3], v13, off offset:3072              // 000000066570: DC6A0C00 007C0D02
	s_branch 60920                                             // 000000066578: BFA0EDF8 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x95c>
	v_dual_mov_b32 v54, v147 :: v_dual_mov_b32 v17, v144       // 00000006657C: CA100193 36100190
	v_dual_mov_b32 v46, v146 :: v_dual_mov_b32 v9, v143        // 000000066584: CA100192 2E08018F
	v_dual_mov_b32 v38, v145 :: v_dual_mov_b32 v25, v142       // 00000006658C: CA100191 2618018E
	v_mov_b32_e32 v37, v141                                    // 000000066594: 7E4A038D
	v_mov_b32_e32 v33, v140                                    // 000000066598: 7E42038C
	v_dual_mul_f32 v2, 0x3b800000, v128 :: v_dual_mul_f32 v3, 0x3b800000, v127// 00000006659C: C8C700FF 0202FEFF 3B800000
	v_dual_mul_f32 v4, 0x3b800000, v126 :: v_dual_mul_f32 v5, 0x3b800000, v125// 0000000665A8: C8C6FCFF 0404FAFF 3B800000
	.long 0xd7006a00                                           // 0000000665B4: D7006A00
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 0000000665B8: 0201FF47
	.long 0x00002000                                           // 0000000665BC: 00002000
	v_dual_mul_f32 v6, 0x3b800000, v124 :: v_dual_mul_f32 v7, 0x3b800000, v123// 0000000665C0: C8C6F8FF 0606F6FF 3B800000
	v_add_co_ci_u32_e64 v1, null, 0, v72, vcc_lo               // 0000000665CC: D5207C01 01AA9080
	v_mul_f32_e32 v8, 0x3b800000, v122                         // 0000000665D4: 1010F4FF 3B800000
	v_dual_mul_f32 v10, 0x3b800000, v54 :: v_dual_mul_f32 v11, 0x3b800000, v115// 0000000665DC: C8C66CFF 0A0AE6FF 3B800000
	s_clause 0x7                                               // 0000000665E8: BF850007
	global_store_b32 v[71:72], v2, off                         // 0000000665EC: DC6A0000 007C0247
	global_store_b32 v[71:72], v3, off offset:1024             // 0000000665F4: DC6A0400 007C0347
	global_store_b32 v[71:72], v4, off offset:2048             // 0000000665FC: DC6A0800 007C0447
	global_store_b32 v[71:72], v5, off offset:3072             // 000000066604: DC6A0C00 007C0547
	global_store_b32 v[0:1], v6, off offset:-4096              // 00000006660C: DC6A1000 007C0600
	global_store_b32 v[0:1], v7, off offset:-3072              // 000000066614: DC6A1400 007C0700
	global_store_b32 v[0:1], v8, off offset:-2048              // 00000006661C: DC6A1800 007C0800
	global_store_b32 v[0:1], v10, off offset:-1024             // 000000066624: DC6A1C00 007C0A00
	v_dual_mul_f32 v4, 0x3b800000, v121 :: v_dual_mul_f32 v7, 0x3b800000, v118// 00000006662C: C8C6F2FF 0406ECFF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v120 :: v_dual_mul_f32 v6, 0x3b800000, v119// 000000066638: C8C6F0FF 0506EEFF 3B800000
	.long 0xd7006a02                                           // 000000066644: D7006A02
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 000000066648: 0201FF47
	.long 0x00004000                                           // 00000006664C: 00004000
	v_mul_f32_e32 v8, 0x3b800000, v117                         // 000000066650: 1010EAFF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v72, vcc_lo               // 000000066658: D5207C03 01AA9080
	v_mul_f32_e32 v10, 0x3b800000, v116                        // 000000066660: 1014E8FF 3B800000
	v_mul_f32_e32 v12, 0x3b800000, v46                         // 000000066668: 10185CFF 3B800000
	s_clause 0x7                                               // 000000066670: BF850007
	global_store_b32 v[0:1], v4, off                           // 000000066674: DC6A0000 007C0400
	global_store_b32 v[0:1], v5, off offset:1024               // 00000006667C: DC6A0400 007C0500
	global_store_b32 v[0:1], v6, off offset:2048               // 000000066684: DC6A0800 007C0600
	global_store_b32 v[0:1], v7, off offset:3072               // 00000006668C: DC6A0C00 007C0700
	global_store_b32 v[2:3], v8, off offset:-4096              // 000000066694: DC6A1000 007C0802
	global_store_b32 v[2:3], v10, off offset:-3072             // 00000006669C: DC6A1400 007C0A02
	global_store_b32 v[2:3], v11, off offset:-2048             // 0000000666A4: DC6A1800 007C0B02
	global_store_b32 v[2:3], v12, off offset:-1024             // 0000000666AC: DC6A1C00 007C0C02
	v_dual_mul_f32 v4, 0x3b800000, v114 :: v_dual_mul_f32 v5, 0x3b800000, v113// 0000000666B4: C8C6E4FF 0404E2FF 3B800000
	v_mul_f32_e32 v6, 0x3b800000, v112                         // 0000000666C0: 100CE0FF 3B800000
	.long 0xd7006a00                                           // 0000000666C8: D7006A00
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 0000000666CC: 0201FF47
	.long 0x00006000                                           // 0000000666D0: 00006000
	v_dual_mul_f32 v7, 0x3b800000, v111 :: v_dual_mul_f32 v8, 0x3b800000, v110// 0000000666D4: C8C6DEFF 0708DCFF 3B800000
	v_add_co_ci_u32_e64 v1, null, 0, v72, vcc_lo               // 0000000666E0: D5207C01 01AA9080
	v_dual_mul_f32 v10, 0x3b800000, v109 :: v_dual_mul_f32 v11, 0x3b800000, v108// 0000000666E8: C8C6DAFF 0A0AD8FF 3B800000
	v_mul_f32_e32 v12, 0x3b800000, v38                         // 0000000666F4: 10184CFF 3B800000
	s_clause 0x7                                               // 0000000666FC: BF850007
	global_store_b32 v[2:3], v4, off                           // 000000066700: DC6A0000 007C0402
	global_store_b32 v[2:3], v5, off offset:1024               // 000000066708: DC6A0400 007C0502
	global_store_b32 v[2:3], v6, off offset:2048               // 000000066710: DC6A0800 007C0602
	global_store_b32 v[2:3], v7, off offset:3072               // 000000066718: DC6A0C00 007C0702
	global_store_b32 v[0:1], v8, off offset:-4096              // 000000066720: DC6A1000 007C0800
	global_store_b32 v[0:1], v10, off offset:-3072             // 000000066728: DC6A1400 007C0A00
	global_store_b32 v[0:1], v11, off offset:-2048             // 000000066730: DC6A1800 007C0B00
	global_store_b32 v[0:1], v12, off offset:-1024             // 000000066738: DC6A1C00 007C0C00
	v_dual_mul_f32 v4, 0x3b800000, v107 :: v_dual_mul_f32 v9, 0x3b800000, v9// 000000066740: C8C6D6FF 040812FF 3B800000
	v_dual_mul_f32 v5, 0x3b800000, v106 :: v_dual_mul_f32 v6, 0x3b800000, v105// 00000006674C: C8C6D4FF 0506D2FF 3B800000
	.long 0xd7006a02                                           // 000000066758: D7006A02
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 00000006675C: 0201FF47
	.long 0x00008000                                           // 000000066760: 00008000
	v_dual_mul_f32 v7, 0x3b800000, v104 :: v_dual_mul_f32 v8, 0x3b800000, v103// 000000066764: C8C6D0FF 0708CEFF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v72, vcc_lo               // 000000066770: D5207C03 01AA9080
	v_dual_mul_f32 v10, 0x3b800000, v102 :: v_dual_mul_f32 v11, 0x3b800000, v101// 000000066778: C8C6CCFF 0A0ACAFF 3B800000
	v_mul_f32_e32 v12, 0x3b800000, v17                         // 000000066784: 101822FF 3B800000
	s_clause 0x7                                               // 00000006678C: BF850007
	global_store_b32 v[0:1], v4, off                           // 000000066790: DC6A0000 007C0400
	global_store_b32 v[0:1], v5, off offset:1024               // 000000066798: DC6A0400 007C0500
	global_store_b32 v[0:1], v6, off offset:2048               // 0000000667A0: DC6A0800 007C0600
	global_store_b32 v[0:1], v7, off offset:3072               // 0000000667A8: DC6A0C00 007C0700
	global_store_b32 v[2:3], v8, off offset:-4096              // 0000000667B0: DC6A1000 007C0802
	global_store_b32 v[2:3], v10, off offset:-3072             // 0000000667B8: DC6A1400 007C0A02
	global_store_b32 v[2:3], v11, off offset:-2048             // 0000000667C0: DC6A1800 007C0B02
	global_store_b32 v[2:3], v12, off offset:-1024             // 0000000667C8: DC6A1C00 007C0C02
	v_dual_mul_f32 v4, 0x3b800000, v100 :: v_dual_mul_f32 v5, 0x3b800000, v99// 0000000667D0: C8C6C8FF 0404C6FF 3B800000
	v_mul_f32_e32 v6, 0x3b800000, v98                          // 0000000667DC: 100CC4FF 3B800000
	.long 0xd7006a00                                           // 0000000667E4: D7006A00
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 0000000667E8: 0201FF47
	.long 0x0000a000                                           // 0000000667EC: 0000A000
	v_dual_mul_f32 v7, 0x3b800000, v97 :: v_dual_mul_f32 v8, 0x3b800000, v96// 0000000667F0: C8C6C2FF 0708C0FF 3B800000
	v_add_co_ci_u32_e64 v1, null, 0, v72, vcc_lo               // 0000000667FC: D5207C01 01AA9080
	v_dual_mul_f32 v10, 0x3b800000, v95 :: v_dual_mul_f32 v11, 0x3b800000, v94// 000000066804: C8C6BEFF 0A0ABCFF 3B800000
	s_clause 0x7                                               // 000000066810: BF850007
	global_store_b32 v[2:3], v4, off                           // 000000066814: DC6A0000 007C0402
	global_store_b32 v[2:3], v5, off offset:1024               // 00000006681C: DC6A0400 007C0502
	global_store_b32 v[2:3], v6, off offset:2048               // 000000066824: DC6A0800 007C0602
	global_store_b32 v[2:3], v7, off offset:3072               // 00000006682C: DC6A0C00 007C0702
	global_store_b32 v[0:1], v8, off offset:-4096              // 000000066834: DC6A1000 007C0800
	global_store_b32 v[0:1], v10, off offset:-3072             // 00000006683C: DC6A1400 007C0A00
	global_store_b32 v[0:1], v11, off offset:-2048             // 000000066844: DC6A1800 007C0B00
	global_store_b32 v[0:1], v9, off offset:-1024              // 00000006684C: DC6A1C00 007C0900
	v_dual_mul_f32 v4, 0x3b800000, v93 :: v_dual_mul_f32 v5, 0x3b800000, v92// 000000066854: C8C6BAFF 0404B8FF 3B800000
	v_mul_f32_e32 v6, 0x3b800000, v91                          // 000000066860: 100CB6FF 3B800000
	.long 0xd7006a02                                           // 000000066868: D7006A02
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 00000006686C: 0201FF47
	.long 0x0000c000                                           // 000000066870: 0000C000
	v_dual_mul_f32 v7, 0x3b800000, v90 :: v_dual_mul_f32 v8, 0x3b800000, v89// 000000066874: C8C6B4FF 0708B2FF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v72, vcc_lo               // 000000066880: D5207C03 01AA9080
	v_dual_mul_f32 v9, 0x3b800000, v88 :: v_dual_mul_f32 v10, 0x3b800000, v87// 000000066888: C8C6B0FF 090AAEFF 3B800000
	v_mul_f32_e32 v11, 0x3b800000, v25                         // 000000066894: 101632FF 3B800000
	s_clause 0x7                                               // 00000006689C: BF850007
	global_store_b32 v[0:1], v4, off                           // 0000000668A0: DC6A0000 007C0400
	global_store_b32 v[0:1], v5, off offset:1024               // 0000000668A8: DC6A0400 007C0500
	global_store_b32 v[0:1], v6, off offset:2048               // 0000000668B0: DC6A0800 007C0600
	global_store_b32 v[0:1], v7, off offset:3072               // 0000000668B8: DC6A0C00 007C0700
	global_store_b32 v[2:3], v8, off offset:-4096              // 0000000668C0: DC6A1000 007C0802
	global_store_b32 v[2:3], v9, off offset:-3072              // 0000000668C8: DC6A1400 007C0902
	global_store_b32 v[2:3], v10, off offset:-2048             // 0000000668D0: DC6A1800 007C0A02
	global_store_b32 v[2:3], v11, off offset:-1024             // 0000000668D8: DC6A1C00 007C0B02
	v_dual_mul_f32 v4, 0x3b800000, v86 :: v_dual_mul_f32 v5, 0x3b800000, v85// 0000000668E0: C8C6ACFF 0404AAFF 3B800000
	v_mul_f32_e32 v6, 0x3b800000, v84                          // 0000000668EC: 100CA8FF 3B800000
	.long 0xd7006a00                                           // 0000000668F4: D7006A00
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 0000000668F8: 0201FF47
	.long 0x0000e000                                           // 0000000668FC: 0000E000
	v_dual_mul_f32 v7, 0x3b800000, v83 :: v_dual_mul_f32 v8, 0x3b800000, v82// 000000066900: C8C6A6FF 0708A4FF 3B800000
	v_add_co_ci_u32_e64 v1, null, 0, v72, vcc_lo               // 00000006690C: D5207C01 01AA9080
	v_dual_mul_f32 v9, 0x3b800000, v81 :: v_dual_mul_f32 v10, 0x3b800000, v80// 000000066914: C8C6A2FF 090AA0FF 3B800000
	v_mul_f32_e32 v11, 0x3b800000, v37                         // 000000066920: 10164AFF 3B800000
	s_clause 0x7                                               // 000000066928: BF850007
	global_store_b32 v[2:3], v4, off                           // 00000006692C: DC6A0000 007C0402
	global_store_b32 v[2:3], v5, off offset:1024               // 000000066934: DC6A0400 007C0502
	global_store_b32 v[2:3], v6, off offset:2048               // 00000006693C: DC6A0800 007C0602
	global_store_b32 v[2:3], v7, off offset:3072               // 000000066944: DC6A0C00 007C0702
	global_store_b32 v[0:1], v8, off offset:-4096              // 00000006694C: DC6A1000 007C0800
	global_store_b32 v[0:1], v9, off offset:-3072              // 000000066954: DC6A1400 007C0900
	global_store_b32 v[0:1], v10, off offset:-2048             // 00000006695C: DC6A1800 007C0A00
	global_store_b32 v[0:1], v11, off offset:-1024             // 000000066964: DC6A1C00 007C0B00
	v_dual_mul_f32 v4, 0x3b800000, v79 :: v_dual_mul_f32 v5, 0x3b800000, v78// 00000006696C: C8C69EFF 04049CFF 3B800000
	.long 0xd7006a02                                           // 000000066978: D7006A02
	v_cndmask_b32_e32 v0, v71, v255, vcc_lo                    // 00000006697C: 0201FF47
	.long 0x0000fc00                                           // 000000066980: 0000FC00
	v_dual_mul_f32 v6, 0x3b800000, v77 :: v_dual_mul_f32 v7, 0x3b800000, v76// 000000066984: C8C69AFF 060698FF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v72, vcc_lo               // 000000066990: D5207C03 01AA9080
	s_and_b32 vcc_lo, exec_lo, s4                              // 000000066998: 8B6A047E
	v_dual_mul_f32 v8, 0x3b800000, v75 :: v_dual_mul_f32 v9, 0x3b800000, v74// 00000006699C: C8C696FF 080894FF 3B800000
	v_mul_f32_e32 v10, 0x3b800000, v73                         // 0000000669A8: 101492FF 3B800000
	v_mul_f32_e32 v11, 0x3b800000, v33                         // 0000000669B0: 101642FF 3B800000
	s_clause 0x7                                               // 0000000669B8: BF850007
	global_store_b32 v[0:1], v4, off                           // 0000000669BC: DC6A0000 007C0400
	global_store_b32 v[0:1], v5, off offset:1024               // 0000000669C4: DC6A0400 007C0500
	global_store_b32 v[0:1], v6, off offset:2048               // 0000000669CC: DC6A0800 007C0600
	global_store_b32 v[0:1], v7, off offset:3072               // 0000000669D4: DC6A0C00 007C0700
	global_store_b32 v[2:3], v8, off offset:-3072              // 0000000669DC: DC6A1400 007C0802
	global_store_b32 v[2:3], v9, off offset:-2048              // 0000000669E4: DC6A1800 007C0902
	global_store_b32 v[2:3], v10, off offset:-1024             // 0000000669EC: DC6A1C00 007C0A02
	global_store_b32 v[2:3], v11, off                          // 0000000669F4: DC6A0000 007C0B02
	s_cbranch_vccnz 3                                          // 0000000669FC: BFA40003 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x560c>
	s_nop 0                                                    // 000000066A00: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000066A04: BFB60003
	s_endpgm                                                   // 000000066A08: BFB00000
	s_sendmsg_rtn_b64 s[0:1], sendmsg(MSG_RTN_GET_REALTIME)    // 000000066A0C: BE804D83
	s_and_saveexec_b32 s4, s5                                  // 000000066A10: BE842005
	s_cbranch_execz 65530                                      // 000000066A14: BFA5FFFA <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi12ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5600>
	s_lshl_b64 s[2:3], s[2:3], 3                               // 000000066A18: 84828302
	v_mov_b32_e32 v2, s24                                      // 000000066A1C: 7E040218
	s_add_u32 s2, s26, s2                                      // 000000066A20: 8002021A
	s_addc_u32 s3, s27, s3                                     // 000000066A24: 8203031B
	s_waitcnt lgkmcnt(0)                                       // 000000066A28: BF89FC07
	s_sub_u32 s0, s0, s24                                      // 000000066A2C: 80801800
	s_subb_u32 s1, s1, s25                                     // 000000066A30: 82811901
	v_dual_mov_b32 v0, s0 :: v_dual_mov_b32 v3, s25            // 000000066A34: CA100000 00020019
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v1, s1              // 000000066A3C: CA100080 04000001
	s_clause 0x1                                               // 000000066A44: BF850001
	global_store_b64 v4, v[0:1], s[2:3] offset:128             // 000000066A48: DC6E0080 00020004
	global_store_b64 v4, v[2:3], s[2:3] offset:512             // 000000066A50: DC6E0200 00020204
	s_nop 0                                                    // 000000066A58: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000066A5C: BFB60003
	s_endpgm                                                   // 000000066A60: BFB00000
