000000000005be00 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE>:
; _ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE():
	s_clause 0x1                                               // 00000005BE00: BF850001
	s_load_b256 s[20:27], s[0:1], 0x20                         // 00000005BE04: F40C0500 F8000020
	s_load_b256 s[8:15], s[0:1], null                          // 00000005BE0C: F40C0200 F8000000
	v_mov_b32_e32 v71, v0                                      // 00000005BE14: 7E8E0300
	v_mov_b32_e32 v1, 0                                        // 00000005BE18: 7E020280
	s_ashr_i32 s3, s2, 31                                      // 00000005BE1C: 86039F02
	s_mov_b32 s28, 0                                           // 00000005BE20: BE9C0080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005BE24: BF870092
	v_lshlrev_b32_e32 v2, 5, v71                               // 00000005BE28: 30048E85
	v_and_b32_e32 v2, 0x200, v2                                // 00000005BE2C: 360404FF 00000200
	s_waitcnt lgkmcnt(0)                                       // 00000005BE34: BF89FC07
	s_load_b32 s16, s[20:21], null                             // 00000005BE38: F400040A F8000000
	v_readfirstlane_b32 s20, v71                               // 00000005BE40: 7E280547
	s_lshl_b64 s[4:5], s[22:23], 2                             // 00000005BE44: 84848216
	s_lshr_b32 s21, s20, 5                                     // 00000005BE48: 85158514
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 00000005BE4C: BF8704D9
	s_lshl_b32 s33, s21, 4                                     // 00000005BE50: 84218415
	s_add_u32 s4, s14, s4                                      // 00000005BE54: 8004040E
	v_and_or_b32 v0, v71, 15, s33                              // 00000005BE58: D6570000 00851F47
	s_addc_u32 s5, s15, s5                                     // 00000005BE60: 8205050F
	s_lshl_b64 s[6:7], s[2:3], 16                              // 00000005BE64: 84869002
	s_add_u32 s4, s4, s6                                       // 00000005BE68: 80040604
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005BE6C: BF870001
	.long 0xd73c0000                                           // 00000005BE70: D73C0000
	v_cndmask_b32_e32 v1, 2, v0, vcc_lo                        // 00000005BE74: 02020082
	s_addc_u32 s5, s5, s7                                      // 00000005BE78: 82050705
	s_waitcnt lgkmcnt(0)                                       // 00000005BE7C: BF89FC07
	s_mul_i32 s14, s16, 0x9000000                              // 00000005BE80: 960EFF10 09000000
	s_mul_hi_i32 s15, s16, 0x9000000                           // 00000005BE88: 970FFF10 09000000
	s_add_u32 s4, s4, s14                                      // 00000005BE90: 80040E04
	s_addc_u32 s5, s5, s15                                     // 00000005BE94: 82050F05
	.long 0xd7006a00                                           // 00000005BE98: D7006A00
	v_cndmask_b32_e32 v1, s4, v0, vcc_lo                       // 00000005BE9C: 02020004
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000005BEA0: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s5, v1, vcc_lo               // 00000005BEA4: D5207C01 01AA0205
	s_or_b32 s5, s21, s2                                       // 00000005BEAC: 8C050215
	.long 0xd7006ab9                                           // 00000005BEB0: D7006AB9
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 00000005BEB4: 02020500
	v_add_co_ci_u32_e64 v186, null, 0, v1, vcc_lo              // 00000005BEB8: D5207CBA 01AA0280
	s_cselect_b32 s38, 0, -1                                   // 00000005BEC0: 9826C180
	.long 0xd7006a00                                           // 00000005BEC4: D7006A00
	v_cndmask_b32_e32 v1, 0x1000, v185, vcc_lo                 // 00000005BEC8: 020372FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005BED0: BF8700A1
	v_add_co_ci_u32_e64 v1, null, 0, v186, vcc_lo              // 00000005BED4: D5207C01 01AB7480
	.long 0xd7006a38                                           // 00000005BEDC: D7006A38
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 00000005BEE0: 0201FFB9
	.long 0x00002000                                           // 00000005BEE4: 00002000
	v_add_co_ci_u32_e64 v57, null, 0, v186, vcc_lo             // 00000005BEE8: D5207C39 01AB7480
	.long 0xd7006a09                                           // 00000005BEF0: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v185, vcc_lo                 // 00000005BEF4: 020372FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005BEFC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v186, vcc_lo             // 00000005BF00: D5207C0A 01AB7480
	.long 0xd7006a0e                                           // 00000005BF08: D7006A0E
	v_cndmask_b32_e32 v1, 0x3000, v185, vcc_lo                 // 00000005BF0C: 020372FF 00003000
	v_add_co_ci_u32_e64 v15, null, 0, v186, vcc_lo             // 00000005BF14: D5207C0F 01AB7480
	.long 0xd7006a3b                                           // 00000005BF1C: D7006A3B
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 00000005BF20: 0201FFB9
	.long 0x00004000                                           // 00000005BF24: 00004000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005BF28: BF8700A1
	v_add_co_ci_u32_e64 v60, null, 0, v186, vcc_lo             // 00000005BF2C: D5207C3C 01AB7480
	.long 0xd7006a10                                           // 00000005BF34: D7006A10
	v_cndmask_b32_e32 v1, 0x4000, v185, vcc_lo                 // 00000005BF38: 020372FF 00004000
	v_add_co_ci_u32_e64 v17, null, 0, v186, vcc_lo             // 00000005BF40: D5207C11 01AB7480
	s_clause 0xf                                               // 00000005BF48: BF85000F
	global_load_b32 v5, v[185:186], off                        // 00000005BF4C: DC520000 057C00B9
	global_load_b32 v6, v[185:186], off offset:1024            // 00000005BF54: DC520400 067C00B9
	global_load_b32 v7, v[185:186], off offset:2048            // 00000005BF5C: DC520800 077C00B9
	global_load_b32 v8, v[185:186], off offset:3072            // 00000005BF64: DC520C00 087C00B9
	global_load_b32 v2, v[0:1], off offset:1024                // 00000005BF6C: DC520400 027C0000
	global_load_b32 v3, v[0:1], off offset:2048                // 00000005BF74: DC520800 037C0000
	global_load_b32 v4, v[0:1], off offset:3072                // 00000005BF7C: DC520C00 047C0000
	global_load_b32 v1, v[9:10], off offset:1024               // 00000005BF84: DC520400 017C0009
	global_load_b32 v12, v[9:10], off offset:2048              // 00000005BF8C: DC520800 0C7C0009
	global_load_b32 v13, v[9:10], off offset:3072              // 00000005BF94: DC520C00 0D7C0009
	global_load_b32 v9, v[14:15], off offset:1024              // 00000005BF9C: DC520400 097C000E
	global_load_b32 v10, v[14:15], off offset:2048             // 00000005BFA4: DC520800 0A7C000E
	global_load_b32 v11, v[14:15], off offset:3072             // 00000005BFAC: DC520C00 0B7C000E
	global_load_b32 v14, v[16:17], off offset:1024             // 00000005BFB4: DC520400 0E7C0010
	global_load_b32 v15, v[16:17], off offset:2048             // 00000005BFBC: DC520800 0F7C0010
	global_load_b32 v16, v[16:17], off offset:3072             // 00000005BFC4: DC520C00 107C0010
	.long 0xd7006a11                                           // 00000005BFCC: D7006A11
	v_cndmask_b32_e32 v1, 0x5000, v185, vcc_lo                 // 00000005BFD0: 020372FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005BFD8: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v186, vcc_lo             // 00000005BFDC: D5207C12 01AB7480
	.long 0xd7006a41                                           // 00000005BFE4: D7006A41
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 00000005BFE8: 0201FFB9
	.long 0x00006000                                           // 00000005BFEC: 00006000
	v_add_co_ci_u32_e64 v66, null, 0, v186, vcc_lo             // 00000005BFF0: D5207C42 01AB7480
	.long 0xd7006a17                                           // 00000005BFF8: D7006A17
	v_cndmask_b32_e32 v1, 0x6000, v185, vcc_lo                 // 00000005BFFC: 020372FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005C004: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v186, vcc_lo             // 00000005C008: D5207C18 01AB7480
	.long 0xd7006a19                                           // 00000005C010: D7006A19
	v_cndmask_b32_e32 v1, 0x7000, v185, vcc_lo                 // 00000005C014: 020372FF 00007000
	v_add_co_ci_u32_e64 v26, null, 0, v186, vcc_lo             // 00000005C01C: D5207C1A 01AB7480
	.long 0xd7006a29                                           // 00000005C024: D7006A29
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 00000005C028: 0201FFB9
	.long 0x00008000                                           // 00000005C02C: 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005C030: BF8700A1
	v_add_co_ci_u32_e64 v42, null, 0, v186, vcc_lo             // 00000005C034: D5207C2A 01AB7480
	.long 0xd7006a20                                           // 00000005C03C: D7006A20
	v_cndmask_b32_e32 v1, 0x8000, v185, vcc_lo                 // 00000005C040: 020372FF 00008000
	v_add_co_ci_u32_e64 v33, null, 0, v186, vcc_lo             // 00000005C048: D5207C21 01AB7480
	.long 0xd7006a22                                           // 00000005C050: D7006A22
	v_cndmask_b32_e32 v1, 0x9000, v185, vcc_lo                 // 00000005C054: 020372FF 00009000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005C05C: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v186, vcc_lo             // 00000005C060: D5207C23 01AB7480
	.long 0xd7006a2b                                           // 00000005C068: D7006A2B
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 00000005C06C: 0201FFB9
	.long 0x0000a000                                           // 00000005C070: 0000A000
	v_add_co_ci_u32_e64 v44, null, 0, v186, vcc_lo             // 00000005C074: D5207C2C 01AB7480
	.long 0xd7006a25                                           // 00000005C07C: D7006A25
	v_cndmask_b32_e32 v1, 0xa000, v185, vcc_lo                 // 00000005C080: 020372FF 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005C088: BF8700A1
	v_add_co_ci_u32_e64 v38, null, 0, v186, vcc_lo             // 00000005C08C: D5207C26 01AB7480
	.long 0xd7006a27                                           // 00000005C094: D7006A27
	v_cndmask_b32_e32 v1, 0xb000, v185, vcc_lo                 // 00000005C098: 020372FF 0000B000
	v_add_co_ci_u32_e64 v40, null, 0, v186, vcc_lo             // 00000005C0A0: D5207C28 01AB7480
	.long 0xd7006a2d                                           // 00000005C0A8: D7006A2D
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 00000005C0AC: 0201FFB9
	.long 0x0000c000                                           // 00000005C0B0: 0000C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005C0B4: BF8700A1
	v_add_co_ci_u32_e64 v46, null, 0, v186, vcc_lo             // 00000005C0B8: D5207C2E 01AB7480
	.long 0xd7006a2f                                           // 00000005C0C0: D7006A2F
	v_cndmask_b32_e32 v1, 0xc000, v185, vcc_lo                 // 00000005C0C4: 020372FF 0000C000
	v_add_co_ci_u32_e64 v48, null, 0, v186, vcc_lo             // 00000005C0CC: D5207C30 01AB7480
	.long 0xd7006a34                                           // 00000005C0D4: D7006A34
	v_cndmask_b32_e32 v1, 0xd000, v185, vcc_lo                 // 00000005C0D8: 020372FF 0000D000
	s_clause 0x17                                              // 00000005C0E0: BF850017
	global_load_b32 v20, v[17:18], off offset:1024             // 00000005C0E4: DC520400 147C0011
	global_load_b32 v21, v[17:18], off offset:2048             // 00000005C0EC: DC520800 157C0011
	global_load_b32 v22, v[17:18], off offset:3072             // 00000005C0F4: DC520C00 167C0011
	global_load_b32 v17, v[23:24], off offset:1024             // 00000005C0FC: DC520400 117C0017
	global_load_b32 v18, v[23:24], off offset:2048             // 00000005C104: DC520800 127C0017
	global_load_b32 v19, v[23:24], off offset:3072             // 00000005C10C: DC520C00 137C0017
	global_load_b32 v23, v[25:26], off offset:1024             // 00000005C114: DC520400 177C0019
	global_load_b32 v24, v[25:26], off offset:2048             // 00000005C11C: DC520800 187C0019
	global_load_b32 v31, v[25:26], off offset:3072             // 00000005C124: DC520C00 1F7C0019
	global_load_b32 v28, v[32:33], off offset:1024             // 00000005C12C: DC520400 1C7C0020
	global_load_b32 v29, v[32:33], off offset:2048             // 00000005C134: DC520800 1D7C0020
	global_load_b32 v30, v[32:33], off offset:3072             // 00000005C13C: DC520C00 1E7C0020
	global_load_b32 v25, v[34:35], off offset:1024             // 00000005C144: DC520400 197C0022
	global_load_b32 v26, v[34:35], off offset:2048             // 00000005C14C: DC520800 1A7C0022
	global_load_b32 v27, v[34:35], off offset:3072             // 00000005C154: DC520C00 1B7C0022
	global_load_b32 v32, v[37:38], off offset:1024             // 00000005C15C: DC520400 207C0025
	global_load_b32 v36, v[37:38], off offset:2048             // 00000005C164: DC520800 247C0025
	global_load_b32 v37, v[37:38], off offset:3072             // 00000005C16C: DC520C00 257C0025
	global_load_b32 v33, v[39:40], off offset:1024             // 00000005C174: DC520400 217C0027
	global_load_b32 v34, v[39:40], off offset:2048             // 00000005C17C: DC520800 227C0027
	global_load_b32 v35, v[39:40], off offset:3072             // 00000005C184: DC520C00 237C0027
	global_load_b32 v38, v[47:48], off offset:1024             // 00000005C18C: DC520400 267C002F
	global_load_b32 v39, v[47:48], off offset:2048             // 00000005C194: DC520800 277C002F
	global_load_b32 v40, v[47:48], off offset:3072             // 00000005C19C: DC520C00 287C002F
	v_add_co_ci_u32_e64 v53, null, 0, v186, vcc_lo             // 00000005C1A4: D5207C35 01AB7480
	.long 0xd7006a2f                                           // 00000005C1AC: D7006A2F
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 00000005C1B0: 0201FFB9
	.long 0x0000e000                                           // 00000005C1B4: 0000E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005C1B8: BF8700A1
	v_add_co_ci_u32_e64 v48, null, 0, v186, vcc_lo             // 00000005C1BC: D5207C30 01AB7480
	.long 0xd7006a3d                                           // 00000005C1C4: D7006A3D
	v_cndmask_b32_e32 v1, 0xe000, v185, vcc_lo                 // 00000005C1C8: 020372FF 0000E000
	v_add_co_ci_u32_e64 v62, null, 0, v186, vcc_lo             // 00000005C1D0: D5207C3E 01AB7480
	.long 0xd7006a43                                           // 00000005C1D8: D7006A43
	v_cndmask_b32_e32 v1, 0xf000, v185, vcc_lo                 // 00000005C1DC: 020372FF 0000F000
	s_clause 0x7                                               // 00000005C1E4: BF850007
	global_load_b32 v58, v[41:42], off offset:-4096            // 00000005C1E8: DC521000 3A7C0029
	global_load_b32 v55, v[41:42], off                         // 00000005C1F0: DC520000 377C0029
	global_load_b32 v54, v[43:44], off offset:-4096            // 00000005C1F8: DC521000 367C002B
	global_load_b32 v51, v[43:44], off                         // 00000005C200: DC520000 337C002B
	global_load_b32 v44, v[45:46], off offset:-4096            // 00000005C208: DC521000 2C7C002D
	global_load_b32 v43, v[45:46], off                         // 00000005C210: DC520000 2B7C002D
	global_load_b32 v42, v[47:48], off offset:-4096            // 00000005C218: DC521000 2A7C002F
	global_load_b32 v41, v[47:48], off                         // 00000005C220: DC520000 297C002F
	v_add_co_ci_u32_e64 v68, null, 0, v186, vcc_lo             // 00000005C228: D5207C44 01AB7480
	s_clause 0xf                                               // 00000005C230: BF85000F
	global_load_b32 v48, v[52:53], off offset:1024             // 00000005C234: DC520400 307C0034
	global_load_b32 v49, v[52:53], off offset:2048             // 00000005C23C: DC520800 317C0034
	global_load_b32 v50, v[52:53], off offset:3072             // 00000005C244: DC520C00 327C0034
	global_load_b32 v45, v[61:62], off offset:1024             // 00000005C24C: DC520400 2D7C003D
	global_load_b32 v46, v[61:62], off offset:2048             // 00000005C254: DC520800 2E7C003D
	global_load_b32 v47, v[61:62], off offset:3072             // 00000005C25C: DC520C00 2F7C003D
	global_load_b32 v52, v[67:68], off                         // 00000005C264: DC520000 347C0043
	global_load_b32 v53, v[67:68], off offset:1024             // 00000005C26C: DC520400 357C0043
	global_load_b32 v64, v[56:57], off offset:-4096            // 00000005C274: DC521000 407C0038
	global_load_b32 v63, v[56:57], off                         // 00000005C27C: DC520000 3F7C0038
	global_load_b32 v62, v[59:60], off offset:-4096            // 00000005C284: DC521000 3E7C003B
	global_load_b32 v61, v[59:60], off                         // 00000005C28C: DC520000 3D7C003B
	global_load_b32 v60, v[65:66], off offset:-4096            // 00000005C294: DC521000 3C7C0041
	global_load_b32 v59, v[65:66], off                         // 00000005C29C: DC520000 3B7C0041
	global_load_b32 v56, v[67:68], off offset:2048             // 00000005C2A4: DC520800 387C0043
	global_load_b32 v57, v[67:68], off offset:3072             // 00000005C2AC: DC520C00 397C0043
	v_lshlrev_b32_e32 v65, 3, v71                              // 00000005C2B4: 30828E83
	s_cbranch_scc1 1                                           // 00000005C2B8: BFA20001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4c0>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 00000005C2BC: BE9C4D83
	s_load_b32 s39, s[0:1], 0x38                               // 00000005C2C0: F40009C0 F8000038
	v_lshrrev_b32_e32 v0, 4, v71                               // 00000005C2C8: 32008E84
	s_mul_hi_i32 s4, s2, 0x55555556                            // 00000005C2CC: 9704FF02 55555556
	v_and_b32_e32 v67, 0x78, v65                               // 00000005C2D4: 368682FF 00000078
	s_lshr_b32 s14, s4, 31                                     // 00000005C2DC: 850E9F04
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000005C2E0: BF870499
	s_add_i32 s4, s4, s14                                      // 00000005C2E4: 81040E04
	s_lshl_b32 s14, s4, 7                                      // 00000005C2E8: 840E8704
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005C2EC: BF870001
	v_lshlrev_b32_e32 v67, 1, v67                              // 00000005C2F0: 30868681
	s_ashr_i32 s15, s14, 31                                    // 00000005C2F4: 860F9F0E
	s_mov_b32 s4, exec_lo                                      // 00000005C2F8: BE84007E
	s_lshl_b64 s[14:15], s[14:15], 1                           // 00000005C2FC: 848E810E
	s_waitcnt lgkmcnt(0)                                       // 00000005C300: BF89FC07
	s_add_i32 s40, s39, -1                                     // 00000005C304: 8128C127
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C308: BF870099
	v_min_i32_e32 v66, s40, v0                                 // 00000005C30C: 22840028
	v_mad_i64_i32 v[65:66], null, 0x5000, v66, s[8:9]          // 00000005C310: D6FF7C41 002284FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C31C: BF870091
	.long 0xd7006a41                                           // 00000005C320: D7006A41
	v_cndmask_b32_e32 v0, v65, v14, vcc_lo                     // 00000005C324: 02001D41
	v_add_co_ci_u32_e64 v66, null, s15, v66, vcc_lo            // 00000005C328: D5207C42 01AA840F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C330: BF870092
	.long 0xd7006a41                                           // 00000005C334: D7006A41
	v_cndmask_b32_e32 v1, v65, v67, vcc_lo                     // 00000005C338: 02028741
	v_add_co_ci_u32_e64 v66, null, 0, v66, vcc_lo              // 00000005C33C: D5207C42 01AA8480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C344: BF870092
	.long 0xd7006a43                                           // 00000005C348: D7006A43
	v_cndmask_b32_e32 v1, 0x1000, v65, vcc_lo                  // 00000005C34C: 020282FF 00001000
	v_add_co_ci_u32_e64 v68, null, 0, v66, vcc_lo              // 00000005C354: D5207C44 01AA8480
	s_clause 0x1                                               // 00000005C35C: BF850001
	global_load_b128 v[74:77], v[65:66], off                   // 00000005C360: DC5E0000 4A7C0041
	global_load_b128 v[78:81], v[67:68], off                   // 00000005C368: DC5E0000 4E7C0043
	.long 0xd4c3007e                                           // 00000005C370: D4C3007E
	v_cndmask_b32_e32 v1, s39, v0, vcc_lo                      // 00000005C374: 02020027
	s_cbranch_execz 11                                         // 00000005C378: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5a8>
	s_waitcnt vmcnt(1)                                         // 00000005C37C: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 00000005C380: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005C384: BF870001
	v_mov_b32_e32 v75, v76                                     // 00000005C388: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 00000005C38C: 7E94034C
	s_waitcnt vmcnt(0)                                         // 00000005C390: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 00000005C394: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 00000005C398: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 00000005C39C: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 00000005C3A0: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 00000005C3A4: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000005C3A8: 8C7E047E
	v_cmp_gt_u32_e32 vcc_lo, 16, v71                           // 00000005C3AC: 7C988E90
	.long 0xd4440004                                           // 00000005C3B0: D4440004
	v_cndmask_b32_e32 v1, s39, v71, vcc_lo                     // 00000005C3B4: 02028E27
	v_mov_b32_e32 v0, 0                                        // 00000005C3B8: 7E000280
	v_mov_b32_e32 v140, 0                                      // 00000005C3BC: 7F180280
	s_and_b32 s16, vcc_lo, s4                                  // 00000005C3C0: 8B10046A
	scratch_store_b32 off, v0, off offset:16                   // 00000005C3C4: DC690010 007C0000
	s_and_saveexec_b32 s4, s16                                 // 00000005C3CC: BE842010
	s_cbranch_execz 30                                         // 00000005C3D0: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x64c>
	v_mul_u32_u24_e32 v0, 0xc0, v71                            // 00000005C3D4: 16008EFF 000000C0
	s_lshl_b64 s[16:17], s[2:3], 2                             // 00000005C3DC: 84908202
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C3E0: BF870091
	.long 0xd7001241                                           // 00000005C3E4: D7001241
	v_cndmask_b32_e32 v1, s10, v0, vcc_lo                      // 00000005C3E8: 0202000A
	v_add_co_ci_u32_e64 v66, null, s11, 0, s18                 // 00000005C3EC: D5207C42 0049000B
	.long 0xd7001200                                           // 00000005C3F4: D7001200
	v_cndmask_b32_e32 v1, s12, v0, vcc_lo                      // 00000005C3F8: 0202000C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005C3FC: BF870211
	v_add_co_ci_u32_e64 v68, null, s13, 0, s18                 // 00000005C400: D5207C44 0049000D
	.long 0xd7006a41                                           // 00000005C408: D7006A41
	v_cndmask_b32_e32 v0, v65, v16, vcc_lo                     // 00000005C40C: 02002141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005C410: BF870211
	v_add_co_ci_u32_e64 v66, null, s17, v66, vcc_lo            // 00000005C414: D5207C42 01AA8411
	.long 0xd7006a43                                           // 00000005C41C: D7006A43
	v_cndmask_b32_e32 v0, v0, v16, vcc_lo                      // 00000005C420: 02002100
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005C424: BF870001
	v_add_co_ci_u32_e64 v68, null, s17, v68, vcc_lo            // 00000005C428: D5207C44 01AA8811
	global_load_b32 v140, v[65:66], off                        // 00000005C430: DC520000 8C7C0041
	global_load_b32 v0, v[67:68], off                          // 00000005C438: DC520000 007C0043
	s_waitcnt vmcnt(0)                                         // 00000005C440: BF8903F7
	scratch_store_b32 off, v0, off offset:16                   // 00000005C444: DC690010 007C0000
	s_or_b32 exec_lo, exec_lo, s4                              // 00000005C44C: 8C7E047E
	s_waitcnt vmcnt(62)                                        // 00000005C450: BF89FBF7
	v_dual_mul_f32 v139, 0x43800000, v5 :: v_dual_mul_f32 v138, 0x43800000, v6// 00000005C454: C8C60AFF 8B8A0CFF 43800000
	v_dual_mul_f32 v137, 0x43800000, v7 :: v_dual_mul_f32 v136, 0x43800000, v8// 00000005C460: C8C60EFF 898810FF 43800000
	s_waitcnt vmcnt(9)                                         // 00000005C46C: BF8927F7
	v_dual_mul_f32 v135, 0x43800000, v64 :: v_dual_mul_f32 v134, 0x43800000, v2// 00000005C470: C8C680FF 878604FF 43800000
	v_dual_mul_f32 v133, 0x43800000, v3 :: v_dual_mul_f32 v158, 0x43800000, v4// 00000005C47C: C8C606FF 859E08FF 43800000
	s_waitcnt vmcnt(8)                                         // 00000005C488: BF8923F7
	v_dual_mul_f32 v132, 0x43800000, v63 :: v_dual_mul_f32 v131, 0x43800000, v1// 00000005C48C: C8C67EFF 848202FF 43800000
	v_dual_mul_f32 v130, 0x43800000, v12 :: v_dual_mul_f32 v129, 0x43800000, v13// 00000005C498: C8C618FF 82801AFF 43800000
	s_waitcnt vmcnt(7)                                         // 00000005C4A4: BF891FF7
	v_dual_mul_f32 v128, 0x43800000, v62 :: v_dual_mul_f32 v127, 0x43800000, v9// 00000005C4A8: C8C67CFF 807E12FF 43800000
	v_dual_mul_f32 v126, 0x43800000, v10 :: v_dual_mul_f32 v157, 0x43800000, v11// 00000005C4B4: C8C614FF 7E9C16FF 43800000
	s_waitcnt vmcnt(6)                                         // 00000005C4C0: BF891BF7
	v_dual_mul_f32 v125, 0x43800000, v61 :: v_dual_mul_f32 v124, 0x43800000, v14// 00000005C4C4: C8C67AFF 7D7C1CFF 43800000
	v_dual_mul_f32 v123, 0x43800000, v15 :: v_dual_mul_f32 v122, 0x43800000, v16// 00000005C4D0: C8C61EFF 7B7A20FF 43800000
	s_waitcnt vmcnt(5)                                         // 00000005C4DC: BF8917F7
	v_dual_mul_f32 v121, 0x43800000, v60 :: v_dual_mul_f32 v156, 0x43800000, v22// 00000005C4E0: C8C678FF 799C2CFF 43800000
	v_dual_mul_f32 v120, 0x43800000, v20 :: v_dual_mul_f32 v119, 0x43800000, v21// 00000005C4EC: C8C628FF 78762AFF 43800000
	s_waitcnt vmcnt(4)                                         // 00000005C4F8: BF8913F7
	v_dual_mul_f32 v118, 0x43800000, v59 :: v_dual_mul_f32 v117, 0x43800000, v17// 00000005C4FC: C8C676FF 767422FF 43800000
	v_dual_mul_f32 v116, 0x43800000, v18 :: v_dual_mul_f32 v115, 0x43800000, v19// 00000005C508: C8C624FF 747226FF 43800000
	v_dual_mul_f32 v114, 0x43800000, v58 :: v_dual_mul_f32 v113, 0x43800000, v23// 00000005C514: C8C674FF 72702EFF 43800000
	v_dual_mul_f32 v112, 0x43800000, v24 :: v_dual_mul_f32 v155, 0x43800000, v31// 00000005C520: C8C630FF 709A3EFF 43800000
	v_dual_mul_f32 v111, 0x43800000, v55 :: v_dual_mul_f32 v110, 0x43800000, v28// 00000005C52C: C8C66EFF 6F6E38FF 43800000
	v_dual_mul_f32 v109, 0x43800000, v29 :: v_dual_mul_f32 v108, 0x43800000, v30// 00000005C538: C8C63AFF 6D6C3CFF 43800000
	v_dual_mul_f32 v107, 0x43800000, v54 :: v_dual_mul_f32 v106, 0x43800000, v25// 00000005C544: C8C66CFF 6B6A32FF 43800000
	v_dual_mul_f32 v105, 0x43800000, v26 :: v_dual_mul_f32 v154, 0x43800000, v27// 00000005C550: C8C634FF 699A36FF 43800000
	v_dual_mul_f32 v104, 0x43800000, v51 :: v_dual_mul_f32 v103, 0x43800000, v32// 00000005C55C: C8C666FF 686640FF 43800000
	v_dual_mul_f32 v102, 0x43800000, v36 :: v_dual_mul_f32 v101, 0x43800000, v37// 00000005C568: C8C648FF 66644AFF 43800000
	v_dual_mul_f32 v100, 0x43800000, v44 :: v_dual_mul_f32 v99, 0x43800000, v33// 00000005C574: C8C658FF 646242FF 43800000
	v_dual_mul_f32 v98, 0x43800000, v34 :: v_dual_mul_f32 v153, 0x43800000, v35// 00000005C580: C8C644FF 629846FF 43800000
	v_dual_mul_f32 v143, 0x43800000, v43 :: v_dual_mul_f32 v146, 0x43800000, v42// 00000005C58C: C8C656FF 8F9254FF 43800000
	v_dual_mul_f32 v149, 0x43800000, v38 :: v_dual_mul_f32 v148, 0x43800000, v39// 00000005C598: C8C64CFF 95944EFF 43800000
	v_dual_mul_f32 v147, 0x43800000, v40 :: v_dual_mul_f32 v152, 0x43800000, v50// 00000005C5A4: C8C650FF 939864FF 43800000
	v_dual_mul_f32 v145, 0x43800000, v48 :: v_dual_mul_f32 v150, 0x43800000, v41// 00000005C5B0: C8C660FF 919652FF 43800000
	v_dual_mul_f32 v141, 0x43800000, v49 :: v_dual_mul_f32 v190, 0x43800000, v47// 00000005C5BC: C8C662FF 8DBE5EFF 43800000
	v_dual_mul_f32 v142, 0x43800000, v45 :: v_dual_mul_f32 v191, 0x43800000, v46// 00000005C5C8: C8C65AFF 8EBE5CFF 43800000
	v_mul_f32_e32 v189, 0x43800000, v52                        // 00000005C5D4: 117A68FF 43800000
	s_waitcnt vmcnt(3)                                         // 00000005C5DC: BF890FF7
	v_dual_mul_f32 v187, 0x43800000, v53 :: v_dual_mul_f32 v188, 0x43800000, v56// 00000005C5E0: C8C66AFF BBBC70FF 43800000
	s_waitcnt vmcnt(2)                                         // 00000005C5EC: BF890BF7
	v_mul_f32_e32 v151, 0x43800000, v57                        // 00000005C5F0: 112E72FF 43800000
	s_cmp_lt_i32 s39, 1                                        // 00000005C5F8: BF048127
	s_cbranch_scc1 4699                                        // 00000005C5FC: BFA2125B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x516c>
	s_add_u32 s30, s8, s14                                     // 00000005C600: 801E0E08
	s_addc_u32 s31, s9, s15                                    // 00000005C604: 821F0F09
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000005C608: 848E8202
	.long 0xd71f0000                                           // 00000005C60C: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000005C610: 020100C1
	s_add_u32 s10, s10, s14                                    // 00000005C614: 800A0E0A
	s_addc_u32 s11, s11, s15                                   // 00000005C618: 820B0F0B
	s_add_u32 s34, s12, s14                                    // 00000005C61C: 80220E0C
	s_addc_u32 s35, s13, s15                                   // 00000005C620: 82230F0D
	s_add_i32 s3, s39, 15                                      // 00000005C624: 81038F27
	s_load_b256 s[12:19], s[0:1], 0x48                         // 00000005C628: F40C0300 F8000048
	s_ashr_i32 s4, s3, 31                                      // 00000005C630: 86049F03
	s_load_b64 s[26:27], s[0:1], 0x68                          // 00000005C634: F4040680 F8000068
	s_lshr_b32 s4, s4, 28                                      // 00000005C63C: 85049C04
	v_dual_mov_b32 v1, 0 :: v_dual_and_b32 v2, 16, v0          // 00000005C640: CA240080 01020090
	s_add_i32 s3, s3, s4                                       // 00000005C648: 81030403
	v_mov_b32_e32 v72, 0x1000504                               // 00000005C64C: 7E9002FF 01000504
	s_waitcnt lgkmcnt(0)                                       // 00000005C654: BF89FC07
	s_ashr_i32 s15, s3, 4                                      // 00000005C658: 860F8403
	s_cmp_lg_u32 s21, 0                                        // 00000005C65C: BF078015
	v_add_nc_u32_e32 v144, 16, v2                              // 00000005C660: 4B200490
	s_cselect_b32 s41, -1, 0                                   // 00000005C664: 982980C1
	s_lshl_b32 s22, s2, 7                                      // 00000005C668: 84168702
	v_xor_b32_e32 v2, 1, v0                                    // 00000005C66C: 3A040081
	s_ashr_i32 s23, s22, 31                                    // 00000005C670: 86179F16
	s_cmp_gt_u32 s20, 63                                       // 00000005C674: BF08BF14
	s_movk_i32 s3, 0x5f40                                      // 00000005C678: B0035F40
	s_cselect_b32 s42, -1, 0                                   // 00000005C67C: 982A80C1
	s_cmp_eq_u32 s21, 0                                        // 00000005C680: BF068015
	scratch_store_b32 off, v2, off                             // 00000005C684: DC690000 007C0200
	s_cselect_b32 s2, -1, 0                                    // 00000005C68C: 980280C1
	v_xor_b32_e32 v2, 2, v0                                    // 00000005C690: 3A040082
	s_and_b32 s4, s2, exec_lo                                  // 00000005C694: 8B047E02
	s_cselect_b32 s43, s3, 0x5f80                              // 00000005C698: 982BFF03 00005F80
	s_lshl_b64 s[36:37], s[22:23], 1                           // 00000005C6A0: 84A48116
	s_mov_b32 s20, 0                                           // 00000005C6A4: BE940080
	s_add_u32 s44, s24, s36                                    // 00000005C6A8: 802C2418
	s_addc_u32 s45, s25, s37                                   // 00000005C6AC: 822D2519
	s_max_i32 s46, s15, 1                                      // 00000005C6B0: 8A2E810F
	s_add_u32 s16, s16, s6                                     // 00000005C6B4: 80100610
	s_addc_u32 s17, s17, s7                                    // 00000005C6B8: 82110711
	s_add_u32 s18, s18, s6                                     // 00000005C6BC: 80120612
	scratch_store_b32 off, v2, off offset:4                    // 00000005C6C0: DC690004 007C0200
	v_xor_b32_e32 v2, 4, v0                                    // 00000005C6C8: 3A040084
	v_xor_b32_e32 v0, 8, v0                                    // 00000005C6CC: 3A000088
	s_addc_u32 s19, s19, s7                                    // 00000005C6D0: 82130713
	s_add_u32 s47, s26, s6                                     // 00000005C6D4: 802F061A
	s_addc_u32 s7, s27, s7                                     // 00000005C6D8: 8207071B
	s_mov_b32 s48, 0x41800000                                  // 00000005C6DC: BEB000FF 41800000
	s_movk_i32 s49, 0x1800                                     // 00000005C6E4: B0311800
	s_movk_i32 s50, 0x2900                                     // 00000005C6E8: B0322900
	s_mov_b32 s21, s20                                         // 00000005C6EC: BE950014
	s_mov_b32 s22, s20                                         // 00000005C6F0: BE960014
	s_mov_b32 s23, s20                                         // 00000005C6F4: BE970014
	s_mov_b32 s24, s20                                         // 00000005C6F8: BE980014
	s_mov_b32 s25, s20                                         // 00000005C6FC: BE990014
	s_mov_b32 s26, s20                                         // 00000005C700: BE9A0014
	s_mov_b32 s27, s20                                         // 00000005C704: BE9B0014
	s_mov_b32 s51, 0x3d800000                                  // 00000005C708: BEB300FF 3D800000
	s_mov_b32 s52, 0x76543210                                  // 00000005C710: BEB400FF 76543210
	s_mov_b32 s53, s20                                         // 00000005C718: BEB50014
	s_mov_b32 s6, s20                                          // 00000005C71C: BE860014
	s_clause 0x1                                               // 00000005C720: BF850001
	scratch_store_b32 off, v2, off offset:8                    // 00000005C724: DC690008 007C0200
	scratch_store_b32 off, v0, off offset:12                   // 00000005C72C: DC69000C 007C0000
	s_branch 13                                                // 00000005C734: BFA0000D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x96c>
	v_dual_mov_b32 v151, v9 :: v_dual_mov_b32 v72, 0x1000504   // 00000005C738: CA100109 974800FF 01000504
	v_dual_mov_b32 v152, v25 :: v_dual_mov_b32 v71, v0         // 00000005C744: CA100119 98460100
	v_mov_b32_e32 v153, v17                                    // 00000005C74C: 7F320311
	v_mov_b32_e32 v154, v33                                    // 00000005C750: 7F340321
	v_mov_b32_e32 v155, v41                                    // 00000005C754: 7F360329
	v_mov_b32_e32 v156, v49                                    // 00000005C758: 7F380331
	v_mov_b32_e32 v157, v57                                    // 00000005C75C: 7F3A0339
	v_mov_b32_e32 v158, v65                                    // 00000005C760: 7F3C0341
	s_cmp_eq_u32 s53, s46                                      // 00000005C764: BF062E35
	s_cbranch_scc1 4598                                        // 00000005C768: BFA211F6 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5144>
	v_mov_b32_e32 v44, v71                                     // 00000005C76C: 7E580347
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000005C770: BF8701B1
	v_ashrrev_i32_e32 v2, 4, v44                               // 00000005C774: 34045884
	v_and_b32_e32 v50, 15, v44                                 // 00000005C778: 3664588F
	.long 0xd4440003                                           // 00000005C77C: D4440003
	v_cndmask_b32_e32 v1, 16, v44, vcc_lo                      // 00000005C780: 02025890
	.long 0xd72c0003                                           // 00000005C784: D72C0003
	v_cndmask_b32_e32 v1, 0x110, v2, vcc_lo                    // 00000005C788: 020204FF 00000110
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005C790: BF870001
	v_lshl_add_u32 v3, v50, 4, v3                              // 00000005C794: D6460003 040D0932
	s_waitcnt vmcnt(1)                                         // 00000005C79C: BF8907F7
	ds_store_b128 v3, v[74:77] offset:10496                    // 00000005C7A0: DB7C2900 00004A03
	s_waitcnt vmcnt(0)                                         // 00000005C7A8: BF8903F7
	ds_store_b128 v3, v[78:81] offset:6144                     // 00000005C7AC: DB7C1800 00004E03
	s_and_saveexec_b32 s4, s3                                  // 00000005C7B4: BE842003
	s_cbranch_execz 6                                          // 00000005C7B8: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x9d4>
	scratch_load_b32 v0, off, off offset:16                    // 00000005C7BC: DC510010 007C0000
	v_lshlrev_b32_e32 v3, 2, v44                               // 00000005C7C4: 30065882
	s_waitcnt vmcnt(0)                                         // 00000005C7C8: BF8903F7
	ds_store_b32 v3, v0 offset:24064                           // 00000005C7CC: D8345E00 00000003
	s_or_b32 exec_lo, exec_lo, s4                              // 00000005C7D4: 8C7E047E
	v_and_b32_e32 v34, 1, v44                                  // 00000005C7D8: 36445881
	s_lshl_b32 s54, s53, 4                                     // 00000005C7DC: 84368435
	v_or_b32_e32 v159, s33, v50                                // 00000005C7E0: 393E6421
	.long 0xd71f0000                                           // 00000005C7E4: D71F0000
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000005C7E8: 020100C1
	s_mov_b32 s29, exec_lo                                     // 00000005C7EC: BE9D007E
	v_or_b32_e32 v15, s54, v34                                 // 00000005C7F0: 381E4436
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005C7F4: BF870113
	v_and_b32_e32 v6, 0x7ffffffe, v159                         // 00000005C7F8: 360D3EFF 7FFFFFFE
	v_min_i32_e32 v3, s40, v15                                 // 00000005C800: 22061E28
	v_or_b32_e32 v5, 2, v15                                    // 00000005C804: 380A1E82
	v_or_b32_e32 v7, 4, v15                                    // 00000005C808: 380E1E84
	s_delay_alu instid0(VALU_DEP_4)                            // 00000005C80C: BF870004
	v_lshlrev_b32_e32 v19, 1, v6                               // 00000005C810: 30260C81
	v_or_b32_e32 v8, 6, v15                                    // 00000005C814: 38101E86
	v_mad_i64_i32 v[3:4], null, 0x5000, v3, s[8:9]             // 00000005C818: D6FF7C03 002206FF 00005000
	v_min_i32_e32 v5, s40, v5                                  // 00000005C824: 220A0A28
	v_min_i32_e32 v7, s40, v7                                  // 00000005C828: 220E0E28
	v_or_b32_e32 v17, 12, v15                                  // 00000005C82C: 38221E8C
	v_min_i32_e32 v8, s40, v8                                  // 00000005C830: 22101028
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005C834: BF8700A4
	v_mad_i64_i32 v[5:6], null, 0x5000, v5, s[8:9]             // 00000005C838: D6FF7C05 00220AFF 00005000
	.long 0xd7006a09                                           // 00000005C844: D7006A09
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000005C848: 02004903
	v_add_co_ci_u32_e64 v10, null, s37, v4, vcc_lo             // 00000005C84C: D5207C0A 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v7, s[8:9]             // 00000005C854: D6FF7C03 00220EFF 00005000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C860: BF870093
	.long 0xd7006a07                                           // 00000005C864: D7006A07
	v_cndmask_b32_e32 v1, v9, v19, vcc_lo                      // 00000005C868: 02022709
	v_add_co_ci_u32_e64 v9, null, 0, v10, vcc_lo               // 00000005C86C: D5207C09 01AA1480
	.long 0xd7006a0a                                           // 00000005C874: D7006A0A
	v_cndmask_b32_e32 v0, v5, v36, vcc_lo                      // 00000005C878: 02004905
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005C87C: BF870211
	v_add_co_ci_u32_e64 v11, null, s37, v6, vcc_lo             // 00000005C880: D5207C0B 01AA0C25
	.long 0xd7006a05                                           // 00000005C888: D7006A05
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 00000005C88C: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005C894: BF870211
	v_add_co_ci_u32_e64 v6, null, 0, v9, vcc_lo                // 00000005C898: D5207C06 01AA1280
	.long 0xd7006a07                                           // 00000005C8A0: D7006A07
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 00000005C8A4: 0202270A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005C8A8: BF8700A1
	v_add_co_ci_u32_e64 v9, null, 0, v11, vcc_lo               // 00000005C8AC: D5207C09 01AA1680
	.long 0xd7006a0a                                           // 00000005C8B4: D7006A0A
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000005C8B8: 02004903
	v_add_co_ci_u32_e64 v11, null, s37, v4, vcc_lo             // 00000005C8BC: D5207C0B 01AA0825
	v_mad_i64_i32 v[3:4], null, 0x5000, v8, s[8:9]             // 00000005C8C4: D6FF7C03 002210FF 00005000
	.long 0xd7006a07                                           // 00000005C8D0: D7006A07
	v_cndmask_b32_e32 v1, 0x2000, v7, vcc_lo                   // 00000005C8D4: 02020EFF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005C8DC: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v9, vcc_lo                // 00000005C8E0: D5207C08 01AA1280
	.long 0xd7006a09                                           // 00000005C8E8: D7006A09
	v_cndmask_b32_e32 v1, v10, v19, vcc_lo                     // 00000005C8EC: 0202270A
	v_add_co_ci_u32_e64 v10, null, 0, v11, vcc_lo              // 00000005C8F0: D5207C0A 01AA1680
	v_or_b32_e32 v11, 8, v15                                   // 00000005C8F8: 38161E88
	.long 0xd7006a03                                           // 00000005C8FC: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000005C900: 02004903
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000005C904: BF870191
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 00000005C908: D5207C04 01AA0825
	v_min_i32_e32 v11, s40, v11                                // 00000005C910: 22161628
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C914: BF870093
	.long 0xd7006a0c                                           // 00000005C918: D7006A0C
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000005C91C: 02022703
	v_add_co_ci_u32_e64 v13, null, 0, v4, vcc_lo               // 00000005C920: D5207C0D 01AA0880
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005C928: BF8700A3
	v_mad_i64_i32 v[3:4], null, 0x5000, v11, s[8:9]            // 00000005C92C: D6FF7C03 002216FF 00005000
	.long 0xd7006a09                                           // 00000005C938: D7006A09
	v_cndmask_b32_e32 v1, 0x2000, v9, vcc_lo                   // 00000005C93C: 020212FF 00002000
	v_add_co_ci_u32_e64 v10, null, 0, v10, vcc_lo              // 00000005C944: D5207C0A 01AA1480
	.long 0xd7006a0b                                           // 00000005C94C: D7006A0B
	v_cndmask_b32_e32 v1, 0x2000, v12, vcc_lo                  // 00000005C950: 020218FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000005C958: BF8700B1
	v_add_co_ci_u32_e64 v12, null, 0, v13, vcc_lo              // 00000005C95C: D5207C0C 01AA1A80
	v_or_b32_e32 v13, 10, v15                                  // 00000005C964: 381A1E8A
	.long 0xd7006a03                                           // 00000005C968: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000005C96C: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 00000005C970: D5207C04 01AA0825
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000005C978: BF870193
	v_min_i32_e32 v13, s40, v13                                // 00000005C97C: 221A1A28
	.long 0xd7006a0e                                           // 00000005C980: D7006A0E
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000005C984: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000005C988: BF870191
	v_add_co_ci_u32_e64 v16, null, 0, v4, vcc_lo               // 00000005C98C: D5207C10 01AA0880
	v_mad_i64_i32 v[3:4], null, 0x5000, v13, s[8:9]            // 00000005C994: D6FF7C03 00221AFF 00005000
	v_or_b32_e32 v15, 14, v15                                  // 00000005C9A0: 381E1E8E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005C9A4: BF870094
	.long 0xd7006a0d                                           // 00000005C9A8: D7006A0D
	v_cndmask_b32_e32 v1, 0x2000, v14, vcc_lo                  // 00000005C9AC: 02021CFF 00002000
	v_add_co_ci_u32_e64 v14, null, 0, v16, vcc_lo              // 00000005C9B4: D5207C0E 01AA2080
	v_min_i32_e32 v16, s40, v17                                // 00000005C9BC: 22202228
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005C9C0: BF8700A4
	v_min_i32_e32 v15, s40, v15                                // 00000005C9C4: 221E1E28
	.long 0xd7006a11                                           // 00000005C9C8: D7006A11
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000005C9CC: 02004903
	v_add_co_ci_u32_e64 v18, null, s37, v4, vcc_lo             // 00000005C9D0: D5207C12 01AA0825
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000005C9D8: BF870194
	v_mad_i64_i32 v[3:4], null, 0x5000, v16, s[8:9]            // 00000005C9DC: D6FF7C03 002220FF 00005000
	.long 0xd7006a11                                           // 00000005C9E8: D7006A11
	v_cndmask_b32_e32 v1, v17, v19, vcc_lo                     // 00000005C9EC: 02022711
	v_mad_i64_i32 v[15:16], null, 0x5000, v15, s[8:9]          // 00000005C9F0: D6FF7C0F 00221EFF 00005000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000005C9FC: BF870194
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 00000005CA00: D5207C12 01AA2480
	.long 0xd7006a11                                           // 00000005CA08: D7006A11
	v_cndmask_b32_e32 v1, 0x2000, v17, vcc_lo                  // 00000005CA0C: 020222FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005CA14: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v18, vcc_lo              // 00000005CA18: D5207C12 01AA2480
	.long 0xd7006a03                                           // 00000005CA20: D7006A03
	v_cndmask_b32_e32 v0, v3, v36, vcc_lo                      // 00000005CA24: 02004903
	v_add_co_ci_u32_e64 v4, null, s37, v4, vcc_lo              // 00000005CA28: D5207C04 01AA0825
	.long 0xd7006a0f                                           // 00000005CA30: D7006A0F
	v_cndmask_b32_e32 v0, v15, v36, vcc_lo                     // 00000005CA34: 0200490F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005CA38: BF870211
	v_add_co_ci_u32_e64 v16, null, s37, v16, vcc_lo            // 00000005CA3C: D5207C10 01AA2025
	.long 0xd7006a03                                           // 00000005CA44: D7006A03
	v_cndmask_b32_e32 v1, v3, v19, vcc_lo                      // 00000005CA48: 02022703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005CA4C: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000005CA50: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 00000005CA58: D7006A0F
	v_cndmask_b32_e32 v1, v15, v19, vcc_lo                     // 00000005CA5C: 0202270F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005CA60: BF870211
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 00000005CA64: D5207C10 01AA2080
	.long 0xd7006a03                                           // 00000005CA6C: D7006A03
	v_cndmask_b32_e32 v1, 0x2000, v3, vcc_lo                   // 00000005CA70: 020206FF 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005CA78: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000005CA7C: D5207C04 01AA0880
	.long 0xd7006a0f                                           // 00000005CA84: D7006A0F
	v_cndmask_b32_e32 v1, 0x2000, v15, vcc_lo                  // 00000005CA88: 02021EFF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005CA90: BF870001
	v_add_co_ci_u32_e64 v16, null, 0, v16, vcc_lo              // 00000005CA94: D5207C10 01AA2080
	s_clause 0x7                                               // 00000005CA9C: BF850007
	global_load_b32 v42, v[5:6], off                           // 00000005CAA0: DC520000 2A7C0005
	global_load_b32 v41, v[7:8], off                           // 00000005CAA8: DC520000 297C0007
	global_load_b32 v40, v[9:10], off                          // 00000005CAB0: DC520000 287C0009
	global_load_b32 v39, v[11:12], off                         // 00000005CAB8: DC520000 277C000B
	global_load_b32 v38, v[13:14], off                         // 00000005CAC0: DC520000 267C000D
	global_load_b32 v37, v[17:18], off                         // 00000005CAC8: DC520000 257C0011
	global_load_b32 v35, v[3:4], off                           // 00000005CAD0: DC520000 237C0003
	global_load_b32 v36, v[15:16], off                         // 00000005CAD8: DC520000 247C000F
	v_lshlrev_b32_e32 v5, 16, v78                              // 00000005CAE0: 300A9C90
	v_and_b32_e32 v8, 0xffff0000, v75                          // 00000005CAE4: 361096FF FFFF0000
	v_lshlrev_b32_e32 v3, 16, v74                              // 00000005CAEC: 30069490
	v_lshlrev_b32_e32 v12, 16, v80                             // 00000005CAF0: 3018A090
	v_and_b32_e32 v13, 0xffff0000, v80                         // 00000005CAF4: 361AA0FF FFFF0000
	v_mul_f32_e32 v5, v5, v5                                   // 00000005CAFC: 100A0B05
	v_lshlrev_b32_e32 v7, 16, v75                              // 00000005CB00: 300E9690
	v_dual_mul_f32 v3, v3, v3 :: v_dual_and_b32 v4, 0xffff0000, v74// 00000005CB04: C8E40703 030494FF FFFF0000
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000005CB10: BF8701A4
	v_dual_mul_f32 v13, v13, v13 :: v_dual_and_b32 v10, 0xffff0000, v76// 00000005CB14: C8E41B0D 0D0A98FF FFFF0000
	v_dual_mul_f32 v12, v12, v12 :: v_dual_and_b32 v11, 0xffff0000, v77// 00000005CB20: C8E4190C 0C0A9AFF FFFF0000
	v_mul_f32_e32 v4, v4, v4                                   // 00000005CB2C: 10080904
	v_and_b32_e32 v6, 0xffff0000, v78                          // 00000005CB30: 360C9CFF FFFF0000
	v_lshlrev_b32_e32 v9, 16, v76                              // 00000005CB38: 30129890
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000005CB3C: BF870193
	v_dual_add_f32 v3, v3, v4 :: v_dual_and_b32 v14, 0xffff0000, v81// 00000005CB40: C9240903 030EA2FF FFFF0000
	v_mul_f32_e32 v6, v6, v6                                   // 00000005CB4C: 100C0D06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005CB50: BF8700A1
	v_dual_add_f32 v4, v5, v6 :: v_dual_mul_f32 v5, v7, v7     // 00000005CB54: C9060D05 04040F07
	v_dual_mul_f32 v6, v8, v8 :: v_dual_lshlrev_b32 v7, 16, v79// 00000005CB5C: C8E21108 06069E90
	v_dual_add_f32 v5, v5, v6 :: v_dual_and_b32 v8, 0xffff0000, v79// 00000005CB64: C9240D05 05089EFF FFFF0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000005CB70: BF8701B1
	v_dual_mul_f32 v6, v7, v7 :: v_dual_mul_f32 v7, v8, v8     // 00000005CB74: C8C60F07 06061108
	v_dual_mul_f32 v8, v9, v9 :: v_dual_mul_f32 v9, v10, v10   // 00000005CB7C: C8C61309 0808150A
	v_lshlrev_b32_e32 v10, 16, v77                             // 00000005CB84: 30149A90
	v_dual_add_f32 v6, v6, v7 :: v_dual_add_f32 v7, v12, v13   // 00000005CB88: C9080F06 06061B0C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000005CB90: BF8701A2
	v_dual_add_f32 v8, v8, v9 :: v_dual_mul_f32 v9, v10, v10   // 00000005CB94: C9061308 0808150A
	v_dual_mul_f32 v10, v11, v11 :: v_dual_lshlrev_b32 v11, 16, v81// 00000005CB9C: C8E2170B 0A0AA290
	v_add_f32_e32 v4, v4, v6                                   // 00000005CBA4: 06080D04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000005CBA8: BF8701B2
	v_dual_add_f32 v9, v9, v10 :: v_dual_mul_f32 v10, v11, v11 // 00000005CBAC: C9061509 090A170B
	v_mul_f32_e32 v11, v14, v14                                // 00000005CBB4: 10161D0E
	v_add_f32_e32 v3, v3, v5                                   // 00000005CBB8: 06060B03
	v_add_f32_e32 v5, v8, v9                                   // 00000005CBBC: 060A1308
	scratch_load_b32 v9, off, off                              // 00000005CBC0: DC510000 097C0000
	v_dual_add_f32 v8, v10, v11 :: v_dual_add_f32 v3, v3, v5   // 00000005CBC8: C908170A 08020B03
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005CBD0: BF870001
	v_add_f32_e32 v5, v7, v8                                   // 00000005CBD4: 060A1107
	scratch_load_b32 v7, off, off offset:4                     // 00000005CBD8: DC510004 077C0000
	s_waitcnt vmcnt(1)                                         // 00000005CBE0: BF8907F7
	v_cmp_lt_u32_e32 vcc_lo, v9, v144                          // 00000005CBE4: 7C932109
	v_cndmask_b32_e32 v9, v0, v9, vcc_lo                       // 00000005CBE8: 02121300
	s_waitcnt vmcnt(0)                                         // 00000005CBEC: BF8903F7
	v_cmp_lt_u32_e32 vcc_lo, v7, v144                          // 00000005CBF0: 7C932107
	s_delay_alu instid0(VALU_DEP_2)                            // 00000005CBF4: BF870002
	v_dual_cndmask_b32 v7, v0, v7 :: v_dual_lshlrev_b32 v6, 2, v9// 00000005CBF8: CA620F00 07061282
	v_add_f32_e32 v4, v4, v5                                   // 00000005CC00: 06080B04
	ds_bpermute_b32 v5, v6, v3                                 // 00000005CC04: DACC0000 05000306
	s_waitcnt lgkmcnt(0)                                       // 00000005CC0C: BF89FC07
	v_add_f32_e32 v3, v3, v5                                   // 00000005CC10: 06060B03
	v_lshlrev_b32_e32 v5, 2, v7                                // 00000005CC14: 300A0E82
	scratch_load_b32 v7, off, off offset:8                     // 00000005CC18: DC510008 077C0000
	ds_bpermute_b32 v6, v6, v4                                 // 00000005CC20: DACC0000 06000406
	s_waitcnt lgkmcnt(0)                                       // 00000005CC28: BF89FC07
	v_add_f32_e32 v4, v4, v6                                   // 00000005CC2C: 06080D04
	ds_bpermute_b32 v6, v5, v3                                 // 00000005CC30: DACC0000 06000305
	ds_bpermute_b32 v5, v5, v4                                 // 00000005CC38: DACC0000 05000405
	s_waitcnt lgkmcnt(0)                                       // 00000005CC40: BF89FC07
	v_dual_add_f32 v3, v3, v6 :: v_dual_add_f32 v4, v4, v5     // 00000005CC44: C9080D03 03040B04
	s_waitcnt vmcnt(0)                                         // 00000005CC4C: BF8903F7
	v_cmp_lt_u32_e32 vcc_lo, v7, v144                          // 00000005CC50: 7C932107
	v_cndmask_b32_e32 v7, v0, v7, vcc_lo                       // 00000005CC54: 020E0F00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005CC58: BF870001
	v_lshlrev_b32_e32 v6, 2, v7                                // 00000005CC5C: 300C0E82
	scratch_load_b32 v7, off, off offset:12                    // 00000005CC60: DC51000C 077C0000
	ds_bpermute_b32 v5, v6, v3                                 // 00000005CC68: DACC0000 05000306
	ds_bpermute_b32 v6, v6, v4                                 // 00000005CC70: DACC0000 06000406
	s_waitcnt lgkmcnt(0)                                       // 00000005CC78: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000005CC7C: C9080B03 03040D04
	s_waitcnt vmcnt(0)                                         // 00000005CC84: BF8903F7
	v_cmp_lt_u32_e32 vcc_lo, v7, v144                          // 00000005CC88: 7C932107
	v_cndmask_b32_e32 v7, v0, v7, vcc_lo                       // 00000005CC8C: 020E0F00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005CC90: BF870001
	v_lshlrev_b32_e32 v7, 2, v7                                // 00000005CC94: 300E0E82
	ds_bpermute_b32 v5, v7, v3                                 // 00000005CC98: DACC0000 05000307
	ds_bpermute_b32 v6, v7, v4                                 // 00000005CCA0: DACC0000 06000407
	v_cmpx_eq_u32_e32 0, v50                                   // 00000005CCA8: 7D946480
	s_cbranch_execz 40                                         // 00000005CCAC: BFA50028 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0xf50>
	s_waitcnt lgkmcnt(0)                                       // 00000005CCB0: BF89FC07
	v_dual_add_f32 v3, v3, v5 :: v_dual_add_f32 v4, v4, v6     // 00000005CCB4: C9080B03 03040D04
	v_rsq_f32_e32 v0, 0x43000000                               // 00000005CCBC: 7E005CFF 43000000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CCC4: BF870091
	v_dual_add_f32 v3, 0x358637bd, v3 :: v_dual_add_f32 v4, 0x358637bd, v4// 00000005CCC8: C90806FF 030408FF 358637BD
	v_dual_mul_f32 v5, 0x4b800000, v3 :: v_dual_mul_f32 v6, 0x4b800000, v4// 00000005CCD4: C8C606FF 050608FF 4B800000
	.long 0xd4140004                                           // 00000005CCE0: D4140004
	v_cndmask_b32_e32 v1, 0x800000, v4, vcc_lo                 // 00000005CCE4: 020208FF 00800000
	v_cmp_gt_f32_e32 vcc_lo, 0x800000, v3                      // 00000005CCEC: 7C2806FF 00800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CCF4: BF870092
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 00000005CCF8: D5010004 00120D04
	v_rsq_f32_e32 v4, v4                                       // 00000005CD00: 7E085D04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CD04: BF870095
	v_dual_cndmask_b32 v3, v3, v5 :: v_dual_mul_f32 v6, 0x45800000, v4// 00000005CD08: CA460B03 030608FF 45800000
	v_rsq_f32_e32 v3, v3                                       // 00000005CD14: 7E065D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005CD18: BF870291
	v_cndmask_b32_e64 v4, v4, v6, s4                           // 00000005CD1C: D5010004 00120D04
	v_mul_f32_e32 v5, 0x45800000, v3                           // 00000005CD24: 100A06FF 45800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005CD2C: BF870121
	v_cndmask_b32_e32 v3, v3, v5, vcc_lo                       // 00000005CD30: 02060B03
	v_lshlrev_b32_e32 v5, 2, v2                                // 00000005CD34: 300A0482
	v_mul_f32_e32 v3, v0, v3                                   // 00000005CD38: 10060700
	s_delay_alu instid0(VALU_DEP_2)                            // 00000005CD3C: BF870002
	v_add_nc_u32_e32 v5, 0x5c00, v5                            // 00000005CD40: 4A0A0AFF 00005C00
	ds_store_2addr_b32 v5, v4, v3 offset0:208 offset1:224      // 00000005CD48: D838E0D0 00030405
	s_or_b32 exec_lo, exec_lo, s29                             // 00000005CD50: 8C7E1D7E
	v_and_b32_e32 v43, 31, v44                                 // 00000005CD54: 3656589F
	s_and_not1_b32 vcc_lo, exec_lo, s2                         // 00000005CD58: 916A027E
	s_cbranch_vccnz 119                                        // 00000005CD5C: BFA40077 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x113c>
	.long 0xd7600045                                           // 00000005CD60: D7600045
	v_cndmask_b32_e32 v0, v140, v128, vcc_lo                   // 00000005CD64: 0201018C
	.long 0xd7600044                                           // 00000005CD68: D7600044
	v_cndmask_b32_e32 v0, v140, v129, vcc_lo                   // 00000005CD6C: 0201038C
	.long 0xd7600043                                           // 00000005CD70: D7600043
	v_cndmask_b32_e32 v0, v140, v130, vcc_lo                   // 00000005CD74: 0201058C
	.long 0xd7600042                                           // 00000005CD78: D7600042
	v_cndmask_b32_e32 v0, v140, v131, vcc_lo                   // 00000005CD7C: 0201078C
	.long 0xd7600041                                           // 00000005CD80: D7600041
	v_cndmask_b32_e32 v0, v140, v132, vcc_lo                   // 00000005CD84: 0201098C
	.long 0xd7600040                                           // 00000005CD88: D7600040
	v_cndmask_b32_e32 v0, v140, v133, vcc_lo                   // 00000005CD8C: 02010B8C
	.long 0xd760003f                                           // 00000005CD90: D760003F
	v_cndmask_b32_e32 v0, v140, v134, vcc_lo                   // 00000005CD94: 02010D8C
	.long 0xd760003e                                           // 00000005CD98: D760003E
	v_cndmask_b32_e32 v0, v140, v135, vcc_lo                   // 00000005CD9C: 02010F8C
	.long 0xd760003d                                           // 00000005CDA0: D760003D
	v_cndmask_b32_e32 v0, v140, v136, vcc_lo                   // 00000005CDA4: 0201118C
	.long 0xd760003c                                           // 00000005CDA8: D760003C
	v_cndmask_b32_e32 v0, v140, v137, vcc_lo                   // 00000005CDAC: 0201138C
	.long 0xd760003b                                           // 00000005CDB0: D760003B
	v_cndmask_b32_e32 v0, v140, v138, vcc_lo                   // 00000005CDB4: 0201158C
	.long 0xd760003a                                           // 00000005CDB8: D760003A
	v_cndmask_b32_e32 v0, v140, v139, vcc_lo                   // 00000005CDBC: 0201178C
	.long 0xd7600039                                           // 00000005CDC0: D7600039
	v_cndmask_b32_e32 v0, v140, v140, vcc_lo                   // 00000005CDC4: 0201198C
	.long 0xd7600038                                           // 00000005CDC8: D7600038
	v_cndmask_b32_e32 v0, v140, v141, vcc_lo                   // 00000005CDCC: 02011B8C
	.long 0xd7600037                                           // 00000005CDD0: D7600037
	v_cndmask_b32_e32 v0, v140, v142, vcc_lo                   // 00000005CDD4: 02011D8C
	.long 0xd760001d                                           // 00000005CDD8: D760001D
	v_cndmask_b32_e32 v0, v140, v143, vcc_lo                   // 00000005CDDC: 02011F8C
	s_mov_b32 s4, exec_lo                                      // 00000005CDE0: BE84007E
	v_cmpx_gt_u32_e32 16, v43                                  // 00000005CDE4: 7D985690
	s_cbranch_execz 83                                         // 00000005CDE8: BFA50053 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1138>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000005CDEC: 7C945680
	s_add_f32 s69, s69, 0                                      // 00000005CDF0: A0458045
	v_lshlrev_b32_e32 v4, 2, v43                               // 00000005CDF4: 30085682
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000005CDF8: BF8704BA
	s_add_f32 s68, s69, s68                                    // 00000005CDFC: A0444445
	v_cndmask_b32_e64 v3, 0, s69, vcc_lo                       // 00000005CE00: D5010003 01A88A80
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 00000005CE08: 7C945681
	s_add_f32 s67, s68, s67                                    // 00000005CE0C: A0434344
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005CE10: BF8704A2
	v_cndmask_b32_e64 v3, v3, s68, vcc_lo                      // 00000005CE14: D5010003 01A88903
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 00000005CE1C: 7C945682
	s_add_f32 s66, s67, s66                                    // 00000005CE20: A0424243
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005CE24: BF8704A2
	v_cndmask_b32_e64 v3, v3, s67, vcc_lo                      // 00000005CE28: D5010003 01A88703
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 00000005CE30: 7C945683
	s_add_f32 s65, s66, s65                                    // 00000005CE34: A0414142
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005CE38: BF8704A2
	v_cndmask_b32_e64 v3, v3, s66, vcc_lo                      // 00000005CE3C: D5010003 01A88503
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 00000005CE44: 7C945684
	s_add_f32 s64, s65, s64                                    // 00000005CE48: A0404041
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005CE4C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s65, vcc_lo                      // 00000005CE50: D5010003 01A88303
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 00000005CE58: 7C945685
	s_add_f32 s63, s64, s63                                    // 00000005CE5C: A03F3F40
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005CE60: BF8704A2
	v_cndmask_b32_e64 v3, v3, s64, vcc_lo                      // 00000005CE64: D5010003 01A88103
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 00000005CE6C: 7C945686
	s_add_f32 s62, s63, s62                                    // 00000005CE70: A03E3E3F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005CE74: BF8704A2
	v_cndmask_b32_e64 v3, v3, s63, vcc_lo                      // 00000005CE78: D5010003 01A87F03
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 00000005CE80: 7C945687
	s_add_f32 s61, s62, s61                                    // 00000005CE84: A03D3D3E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005CE88: BF8704A2
	v_cndmask_b32_e64 v3, v3, s62, vcc_lo                      // 00000005CE8C: D5010003 01A87D03
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 00000005CE94: 7C945688
	s_add_f32 s60, s61, s60                                    // 00000005CE98: A03C3C3D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005CE9C: BF8704A2
	v_cndmask_b32_e64 v3, v3, s61, vcc_lo                      // 00000005CEA0: D5010003 01A87B03
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 00000005CEA8: 7C945689
	s_add_f32 s59, s60, s59                                    // 00000005CEAC: A03B3B3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005CEB0: BF8704A2
	v_cndmask_b32_e64 v3, v3, s60, vcc_lo                      // 00000005CEB4: D5010003 01A87903
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000005CEBC: 7C94568A
	s_add_f32 s58, s59, s58                                    // 00000005CEC0: A03A3A3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005CEC4: BF8704A2
	v_cndmask_b32_e64 v3, v3, s59, vcc_lo                      // 00000005CEC8: D5010003 01A87703
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 00000005CED0: 7C94568B
	s_add_f32 s57, s58, s57                                    // 00000005CED4: A039393A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005CED8: BF8704A2
	v_cndmask_b32_e64 v3, v3, s58, vcc_lo                      // 00000005CEDC: D5010003 01A87503
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 00000005CEE4: 7C94568C
	s_add_f32 s56, s57, s56                                    // 00000005CEE8: A0383839
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005CEEC: BF8704A2
	v_cndmask_b32_e64 v3, v3, s57, vcc_lo                      // 00000005CEF0: D5010003 01A87303
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 00000005CEF8: 7C94568D
	s_add_f32 s55, s56, s55                                    // 00000005CEFC: A0373738
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000005CF00: BF8704A2
	v_cndmask_b32_e64 v3, v3, s56, vcc_lo                      // 00000005CF04: D5010003 01A87103
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 00000005CF0C: 7C94568E
	s_add_f32 s29, s55, s29                                    // 00000005CF10: A01D1D37
	s_delay_alu instid0(VALU_DEP_2)                            // 00000005CF14: BF870002
	v_cndmask_b32_e64 v3, v3, s55, vcc_lo                      // 00000005CF18: D5010003 01A86F03
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 00000005CF20: 7C94568F
	s_delay_alu instid0(VALU_DEP_2) | instid1(SALU_CYCLE_1)    // 00000005CF24: BF870482
	v_cndmask_b32_e64 v3, v3, s29, vcc_lo                      // 00000005CF28: D5010003 01A83B03
	ds_store_b32 v4, v3 offset:24128                           // 00000005CF30: D8345E40 00000304
	s_or_b32 exec_lo, exec_lo, s4                              // 00000005CF38: 8C7E047E
	s_add_i32 s53, s53, 1                                      // 00000005CF3C: 81358135
	s_waitcnt lgkmcnt(0)                                       // 00000005CF40: BF89FC07
	s_barrier                                                  // 00000005CF44: BFBD0000
	s_cmp_ge_i32 s53, s15                                      // 00000005CF48: BF030F35
	s_cbranch_scc1 71                                          // 00000005CF4C: BFA20047 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x126c>
	s_lshl_b32 s4, s53, 4                                      // 00000005CF50: 84048435
	v_lshlrev_b32_e32 v4, 4, v44                               // 00000005CF54: 30085884
	s_waitcnt lgkmcnt(0)                                       // 00000005CF58: BF89FC07
	v_add_nc_u32_e32 v6, s4, v2                                // 00000005CF5C: 4A0C0404
	s_mov_b32 s29, exec_lo                                     // 00000005CF60: BE9D007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005CF64: BF870112
	v_and_b32_e32 v4, 0xf0, v4                                 // 00000005CF68: 360808FF 000000F0
	v_min_i32_e32 v2, s40, v6                                  // 00000005CF70: 22040C28
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005CF74: BF870091
	v_mad_i64_i32 v[2:3], null, 0x5000, v2, s[30:31]           // 00000005CF78: D6FF7C02 007A04FF 00005000
	.long 0xd7006a02                                           // 00000005CF84: D7006A02
	v_cndmask_b32_e32 v1, v2, v4, vcc_lo                       // 00000005CF88: 02020902
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005CF8C: BF870111
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 00000005CF90: D5207C03 01AA0680
	.long 0xd7006a04                                           // 00000005CF98: D7006A04
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 00000005CF9C: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005CFA4: BF870001
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 00000005CFA8: D5207C05 01AA0680
	s_clause 0x1                                               // 00000005CFB0: BF850001
	global_load_b128 v[74:77], v[2:3], off                     // 00000005CFB4: DC5E0000 4A7C0002
	global_load_b128 v[78:81], v[4:5], off                     // 00000005CFBC: DC5E0000 4E7C0004
	.long 0xd4c3007e                                           // 00000005CFC4: D4C3007E
	v_cndmask_b32_e32 v1, s39, v6, vcc_lo                      // 00000005CFC8: 02020C27
	s_cbranch_execz 11                                         // 00000005CFCC: BFA5000B <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x11fc>
	s_waitcnt vmcnt(1)                                         // 00000005CFD0: BF8907F7
	v_mov_b32_e32 v76, 0                                       // 00000005CFD4: 7E980280
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005CFD8: BF870001
	v_mov_b32_e32 v75, v76                                     // 00000005CFDC: 7E96034C
	v_mov_b32_e32 v74, v76                                     // 00000005CFE0: 7E94034C
	s_waitcnt vmcnt(0)                                         // 00000005CFE4: BF8903F7
	v_mov_b32_e32 v81, v76                                     // 00000005CFE8: 7EA2034C
	v_mov_b32_e32 v80, v76                                     // 00000005CFEC: 7EA0034C
	v_mov_b32_e32 v79, v76                                     // 00000005CFF0: 7E9E034C
	v_mov_b32_e32 v78, v76                                     // 00000005CFF4: 7E9C034C
	v_mov_b32_e32 v77, v76                                     // 00000005CFF8: 7E9A034C
	s_or_b32 exec_lo, exec_lo, s29                             // 00000005CFFC: 8C7E1D7E
	s_and_saveexec_b32 s29, s3                                 // 00000005D000: BE9D2003
	s_cbranch_execz 23                                         // 00000005D004: BFA50017 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1264>
	v_add_nc_u32_e32 v2, s4, v44                               // 00000005D008: 4A045804
	v_mov_b32_e32 v140, 0                                      // 00000005D00C: 7F180280
	v_mov_b32_e32 v0, 0                                        // 00000005D010: 7E000280
	s_mov_b32 s3, exec_lo                                      // 00000005D014: BE83007E
	scratch_store_b32 off, v0, off offset:16                   // 00000005D018: DC690010 007C0000
	.long 0xd4c4007e                                           // 00000005D020: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005D024: 02020427
	s_cbranch_execz 13                                         // 00000005D028: BFA5000D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1260>
	v_mad_i64_i32 v[3:4], null, 0xc0, v2, s[10:11]             // 00000005D02C: D6FF7C03 002A04FF 000000C0
	v_mad_i64_i32 v[5:6], null, 0xc0, v2, s[34:35]             // 00000005D038: D6FF7C05 008A04FF 000000C0
	global_load_b32 v140, v[3:4], off                          // 00000005D044: DC520000 8C7C0003
	global_load_b32 v0, v[5:6], off                            // 00000005D04C: DC520000 007C0005
	s_waitcnt vmcnt(0)                                         // 00000005D054: BF8903F7
	scratch_store_b32 off, v0, off offset:16                   // 00000005D058: DC690010 007C0000
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005D060: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005D064: BF870009
	s_or_b32 exec_lo, exec_lo, s29                             // 00000005D068: 8C7E1D7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005D06C: BF870009
	s_and_b32 vcc_lo, exec_lo, s42                             // 00000005D070: 8B6A2A7E
	s_mov_b32 s3, -1                                           // 00000005D074: BE8300C1
	s_cbranch_vccz 81                                          // 00000005D078: BFA30051 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x13c0>
	v_and_b32_e32 v2, -16, v44                                 // 00000005D07C: 360458D0
	s_mov_b32 s3, exec_lo                                      // 00000005D080: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005D084: BF870001
	v_cmpx_eq_u32_e32 64, v2                                   // 00000005D088: 7D9404C0
	s_cbranch_execz 74                                         // 00000005D08C: BFA5004A <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x13b8>
	v_lshlrev_b32_e32 v4, 2, v44                               // 00000005D090: 30085882
	s_waitcnt lgkmcnt(1)                                       // 00000005D094: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005D098: BF870001
	v_add_nc_u32_e32 v5, 0x5c00, v4                            // 00000005D09C: 4A0A08FF 00005C00
	ds_load_2addr_b32 v[2:3], v5 offset0:64 offset1:80         // 00000005D0A4: D8DC5040 02000005
	s_waitcnt lgkmcnt(1)                                       // 00000005D0AC: BF89FC17
	ds_load_b32 v6, v1 offset:24188                            // 00000005D0B0: D8D85E7C 06000001
	s_waitcnt lgkmcnt(1)                                       // 00000005D0B8: BF89FC17
	v_mul_f32_e32 v7, 0x3fb8aa3b, v3                           // 00000005D0BC: 100E06FF 3FB8AA3B
	ds_load_b32 v8, v4 offset:24128                            // 00000005D0C4: D8D85E40 08000004
	s_waitcnt lgkmcnt(1)                                       // 00000005D0CC: BF89FC17
	v_sub_f32_e32 v6, v6, v3                                   // 00000005D0D0: 080C0706
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000005D0D4: 7C3606FF C2CE8ED0
	v_fma_f32 v9, 0x3fb8aa3b, v3, -v7                          // 00000005D0DC: D6130009 841E06FF 3FB8AA3B
	v_rndne_f32_e32 v10, v7                                    // 00000005D0E8: 7E144707
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005D0EC: BF870114
	v_mul_f32_e32 v11, 0x3fb8aa3b, v6                          // 00000005D0F0: 10160CFF 3FB8AA3B
	v_sub_f32_e32 v7, v7, v10                                  // 00000005D0F8: 080E1507
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000005D0FC: BF8701C2
	v_fma_f32 v12, 0x3fb8aa3b, v6, -v11                        // 00000005D100: D613000C 842E0CFF 3FB8AA3B
	v_fmac_f32_e32 v9, 0x32a5705f, v3                          // 00000005D10C: 561206FF 32A5705F
	v_cvt_i32_f32_e32 v10, v10                                 // 00000005D114: 7E14110A
	v_rndne_f32_e32 v13, v11                                   // 00000005D118: 7E1A470B
	v_dual_fmac_f32 v12, 0x32a5705f, v6 :: v_dual_add_f32 v7, v7, v9// 00000005D11C: C8080CFF 0C061307 32A5705F
	s_waitcnt lgkmcnt(0)                                       // 00000005D128: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005D12C: BF870112
	v_dual_sub_f32 v9, v11, v13 :: v_dual_mul_f32 v2, v8, v2   // 00000005D130: C9461B0B 09020508
	v_exp_f32_e32 v7, v7                                       // 00000005D138: 7E0E4B07
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D13C: BF870125
	.long 0xd71c0007                                           // 00000005D140: D71C0007
	v_cndmask_b32_e32 v1, v7, v10, vcc_lo                      // 00000005D144: 02021507
	v_cvt_i32_f32_e32 v10, v13                                 // 00000005D148: 7E14110D
	v_cndmask_b32_e32 v7, 0, v7, vcc_lo                        // 00000005D14C: 020E0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000005D150: 7C3C06FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000005D158: BF8701B2
	v_cndmask_b32_e32 v3, 0x7f800000, v7, vcc_lo               // 00000005D15C: 02060EFF 7F800000
	v_add_f32_e32 v9, v9, v12                                  // 00000005D164: 06121909
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v6                   // 00000005D168: 7C360CFF C2CE8ED0
	v_mul_f32_e32 v2, v3, v2                                   // 00000005D170: 10040503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D174: BF870093
	v_exp_f32_e32 v9, v9                                       // 00000005D178: 7E124B09
	v_mul_f32_e32 v2, 0x41800000, v2                           // 00000005D17C: 100404FF 41800000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D184: BF870095
	.long 0xd71c0009                                           // 00000005D188: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000005D18C: 02021509
	v_cndmask_b32_e32 v7, 0, v9, vcc_lo                        // 00000005D190: 020E1280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v6                   // 00000005D194: 7C3C0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000005D19C: BF870002
	v_cndmask_b32_e32 v6, 0x7f800000, v7, vcc_lo               // 00000005D1A0: 020C0EFF 7F800000
	ds_store_b32 v4, v3 offset:24064                           // 00000005D1A8: D8345E00 00000304
	ds_store_2addr_b32 v5, v6, v2 offset0:96 offset1:112       // 00000005D1B0: D8387060 00020605
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005D1B8: 8C7E037E
	s_mov_b32 s3, 0                                            // 00000005D1BC: BE830080
	v_lshrrev_b32_e32 v160, 4, v43                             // 00000005D1C0: 33405684
	v_mul_u32_u24_e32 v52, 0x110, v50                          // 00000005D1C4: 166864FF 00000110
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 00000005D1CC: 916A037E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000005D1D0: BF870002
	v_lshlrev_b32_e32 v51, 2, v160                             // 00000005D1D4: 30674082
	s_cbranch_vccnz 873                                        // 00000005D1D8: BFA40369 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2180>
	v_mad_u32_u24 v2, 0x110, v50, s49                          // 00000005D1DC: D60B0002 00C664FF 00000110
	s_and_b32 s3, s2, exec_lo                                  // 00000005D1E8: 8B037E02
	s_cselect_b32 s3, 0, 0x1100                                // 00000005D1EC: 9803FF80 00001100
	v_mad_u32_u24 v3, 0x110, v50, s50                          // 00000005D1F4: D60B0003 00CA64FF 00000110
	ds_load_b128 v[10:13], v52 offset:6144                     // 00000005D200: DBFC1800 0A000034
	ds_load_b128 v[14:17], v52 offset:6160                     // 00000005D208: DBFC1810 0E000034
	v_add_nc_u32_e32 v4, s3, v2                                // 00000005D210: 4A080403
	v_mov_b32_e32 v8, v1                                       // 00000005D214: 7E100301
	s_waitcnt lgkmcnt(3)                                       // 00000005D218: BF89FC37
	v_mov_b32_e32 v5, v1                                       // 00000005D21C: 7E0A0301
	v_cndmask_b32_e64 v45, v3, v2, s2                          // 00000005D220: D501002D 000A0503
	v_mov_b32_e32 v3, v1                                       // 00000005D228: 7E060301
	ds_load_b128 v[18:21], v4                                  // 00000005D22C: DBFC0000 12000004
	ds_load_b128 v[22:25], v4 offset:16                        // 00000005D234: DBFC0010 16000004
	ds_load_b128 v[26:29], v52 offset:6176                     // 00000005D23C: DBFC1820 1A000034
	ds_load_b128 v[30:33], v52 offset:6192                     // 00000005D244: DBFC1830 1E000034
	ds_load_b128 v[53:56], v45 offset:32                       // 00000005D24C: DBFC0020 3500002D
	ds_load_b128 v[57:60], v45 offset:48                       // 00000005D254: DBFC0030 3900002D
	ds_load_b128 v[61:64], v45 offset:64                       // 00000005D25C: DBFC0040 3D00002D
	ds_load_b128 v[65:68], v45 offset:80                       // 00000005D264: DBFC0050 4100002D
	ds_load_b128 v[165:168], v52 offset:6224                   // 00000005D26C: DBFC1850 A5000034
	ds_load_b128 v[161:164], v52 offset:6208                   // 00000005D274: DBFC1840 A1000034
	v_mov_b32_e32 v2, v1                                       // 00000005D27C: 7E040301
	v_mov_b32_e32 v4, v1                                       // 00000005D280: 7E080301
	s_waitcnt lgkmcnt(12)                                      // 00000005D284: BF89FCC7
	v_mov_b32_e32 v6, v1                                       // 00000005D288: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 00000005D28C: 7E0E0301
	v_mov_b32_e32 v9, v8                                       // 00000005D290: 7E120308
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005D294: BF870212
	v_mov_b32_e32 v8, v7                                       // 00000005D298: 7E100307
	v_mov_b32_e32 v7, v6                                       // 00000005D29C: 7E0E0306
	v_mov_b32_e32 v6, v5                                       // 00000005D2A0: 7E0C0305
	v_mov_b32_e32 v5, v4                                       // 00000005D2A4: 7E0A0304
	v_mov_b32_e32 v4, v3                                       // 00000005D2A8: 7E080303
	v_mov_b32_e32 v3, v2                                       // 00000005D2AC: 7E060302
	v_mov_b32_e32 v2, v1                                       // 00000005D2B0: 7E040301
	ds_load_b128 v[173:176], v52 offset:6256                   // 00000005D2B4: DBFC1870 AD000034
	ds_load_b128 v[169:172], v52 offset:6240                   // 00000005D2BC: DBFC1860 A9000034
	ds_load_b128 v[181:184], v45 offset:112                    // 00000005D2C4: DBFC0070 B500002D
	ds_load_b128 v[177:180], v45 offset:96                     // 00000005D2CC: DBFC0060 B100002D
	v_or_b32_e32 v49, 6, v160                                  // 00000005D2D4: 38634086
	v_or_b32_e32 v48, 8, v160                                  // 00000005D2D8: 38614088
	v_or_b32_e32 v47, 10, v160                                 // 00000005D2DC: 385F408A
	s_waitcnt lgkmcnt(12)                                      // 00000005D2E0: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 00000005D2E4: CC414002 1C0A1512
	ds_load_b128 v[14:17], v52 offset:6288                     // 00000005D2EC: DBFC1890 0E000034
	ds_load_b128 v[10:13], v52 offset:6272                     // 00000005D2F4: DBFC1880 0A000034
	ds_load_b128 v[22:25], v45 offset:144                      // 00000005D2FC: DBFC0090 1600002D
	ds_load_b128 v[18:21], v45 offset:128                      // 00000005D304: DBFC0080 1200002D
	s_and_not1_b32 vcc_lo, exec_lo, s41                        // 00000005D30C: 916A297E
	s_mov_b32 s3, -1                                           // 00000005D310: BE8300C1
	s_waitcnt lgkmcnt(12)                                      // 00000005D314: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[53:60], v[26:33], v[2:9]// 00000005D318: CC414002 1C0A3535
	ds_load_b128 v[30:33], v52 offset:6320                     // 00000005D320: DBFC18B0 1E000034
	ds_load_b128 v[26:29], v52 offset:6304                     // 00000005D328: DBFC18A0 1A000034
	ds_load_b128 v[86:89], v45 offset:176                      // 00000005D330: DBFC00B0 5600002D
	ds_load_b128 v[82:85], v45 offset:160                      // 00000005D338: DBFC00A0 5200002D
	v_lshlrev_b32_e32 v54, 2, v50                              // 00000005D340: 306C6482
	v_or_b32_e32 v53, 4, v160                                  // 00000005D344: 386B4084
	s_waitcnt lgkmcnt(12)                                      // 00000005D348: BF89FCC7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[61:68], v[161:168], v[2:9]// 00000005D34C: CC414002 1C0B433D
	ds_load_b128 v[59:62], v52 offset:6352                     // 00000005D354: DBFC18D0 3B000034
	ds_load_b128 v[55:58], v52 offset:6336                     // 00000005D35C: DBFC18C0 37000034
	ds_load_b128 v[165:168], v45 offset:208                    // 00000005D364: DBFC00D0 A500002D
	ds_load_b128 v[161:164], v45 offset:192                    // 00000005D36C: DBFC00C0 A100002D
	v_add_nc_u32_e32 v46, 64, v54                              // 00000005D374: 4A5C6CC0
	ds_load_b128 v[67:70], v52 offset:6384                     // 00000005D378: DBFC18F0 43000034
	ds_load_b128 v[63:66], v52 offset:6368                     // 00000005D380: DBFC18E0 3F000034
	s_waitcnt lgkmcnt(14)                                      // 00000005D388: BF89FCE7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[177:184], v[169:176], v[2:9]// 00000005D38C: CC414002 1C0B53B1
	s_waitcnt lgkmcnt(10)                                      // 00000005D394: BF89FCA7
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005D398: BF870001
	v_wmma_f32_16x16x16_bf16 v[2:9], v[18:25], v[10:17], v[2:9]// 00000005D39C: CC414002 1C0A1512
	v_add_nc_u32_e32 v10, 0x5c00, v51                          // 00000005D3A4: 4A1466FF 00005C00
	v_add_nc_u32_e32 v11, s43, v51                             // 00000005D3AC: 4A16662B
	ds_load_b128 v[173:176], v45 offset:240                    // 00000005D3B0: DBFC00F0 AD00002D
	ds_load_b128 v[169:172], v45 offset:224                    // 00000005D3B8: DBFC00E0 A900002D
	ds_load_2addr_stride64_b32 v[12:13], v46 offset0:94 offset1:95// 00000005D3C0: D8E05F5E 0C00002E
	v_or_b32_e32 v46, 12, v160                                 // 00000005D3C8: 385D408C
	s_waitcnt lgkmcnt(9)                                       // 00000005D3CC: BF89FC97
	v_wmma_f32_16x16x16_bf16 v[2:9], v[82:89], v[26:33], v[2:9]// 00000005D3D0: CC414002 1C0A3552
	ds_load_2addr_b32 v[28:29], v10 offset0:144 offset1:146    // 00000005D3D8: D8DC9290 1C00000A
	ds_load_2addr_b32 v[24:25], v10 offset0:148 offset1:150    // 00000005D3E0: D8DC9694 1800000A
	ds_load_2addr_b32 v[20:21], v10 offset0:152 offset1:154    // 00000005D3E8: D8DC9A98 1400000A
	ds_load_2addr_b32 v[16:17], v10 offset0:156 offset1:158    // 00000005D3F0: D8DC9E9C 1000000A
	ds_load_2addr_b32 v[26:27], v11 offset1:2                  // 00000005D3F8: D8DC0200 1A00000B
	ds_load_2addr_b32 v[22:23], v11 offset0:4 offset1:6        // 00000005D400: D8DC0604 1600000B
	ds_load_2addr_b32 v[18:19], v11 offset0:8 offset1:10       // 00000005D408: D8DC0A08 1200000B
	ds_load_2addr_b32 v[14:15], v11 offset0:12 offset1:14      // 00000005D410: D8DC0E0C 0E00000B
	v_or_b32_e32 v45, 14, v160                                 // 00000005D418: 385B408E
	s_waitcnt lgkmcnt(13)                                      // 00000005D41C: BF89FCD7
	v_wmma_f32_16x16x16_bf16 v[2:9], v[161:168], v[55:62], v[2:9]// 00000005D420: CC414002 1C0A6FA1
	v_or_b32_e32 v55, 2, v160                                  // 00000005D428: 386F4082
	s_waitcnt lgkmcnt(9)                                       // 00000005D42C: BF89FC97
	s_delay_alu instid0(VALU_DEP_2)                            // 00000005D430: BF870002
	v_wmma_f32_16x16x16_bf16 v[2:9], v[169:176], v[63:70], v[2:9]// 00000005D434: CC414002 1C0A7FA9
	s_cbranch_vccnz 353                                        // 00000005D43C: BFA40161 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1bc4>
	.long 0x7e143880                                           // 00000005D440: 7E143880
	s_mov_b32 s3, exec_lo                                      // 00000005D444: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005D448: BF870001
	.long 0x7f14390a                                           // 00000005D44C: 7F14390A
	.long 0xd4cb007e                                           // 00000005D450: D4CB007E
	v_cndmask_b32_e32 v1, v50, v160, vcc_lo                    // 00000005D454: 02034132
	s_cbranch_execz 34                                         // 00000005D458: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x16e4>
	s_waitcnt lgkmcnt(7)                                       // 00000005D45C: BF89FC77
	v_sub_f32_e32 v11, v28, v12                                // 00000005D460: 0816191C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D464: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v11                         // 00000005D468: 103C16FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v11, -v30                       // 00000005D470: D613001F 847A16FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 00000005D47C: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D480: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v11 :: v_dual_sub_f32 v30, v30, v32// 00000005D484: C80A16FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 00000005D490: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 00000005D494: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000005D498: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005D4A0: BF870293
	v_exp_f32_e32 v30, v30                                     // 00000005D4A4: 7E3C4B1E
	.long 0xd71c001e                                           // 00000005D4A8: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 00000005D4AC: 02023F1E
	s_waitcnt lgkmcnt(3)                                       // 00000005D4B0: BF89FC37
	v_mul_f32_e32 v31, v2, v26                                 // 00000005D4B4: 103E3502
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D4B8: BF870122
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 00000005D4BC: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000005D4C0: 7C3C16FF 42B17218
	v_dual_cndmask_b32 v11, 0x7f800000, v30 :: v_dual_mul_f32 v30, v13, v31// 00000005D4C8: CA463CFF 0B1E3F0D 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D4D4: BF870091
	v_mul_f32_e32 v11, v11, v30                                // 00000005D4D8: 10163D0B
	v_fma_mixhi_f16 v10, v11, s48, 0                           // 00000005D4DC: CC22000A 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005D4E4: 8C7E037E
	v_mul_u32_u24_e32 v11, 48, v160                            // 00000005D4E8: 161740B0
	s_mov_b32 s3, exec_lo                                      // 00000005D4EC: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005D4F0: BF870001
	v_lshl_add_u32 v11, v50, 1, v11                            // 00000005D4F4: D646000B 042D0332
	ds_store_b16_d16_hi v11, v10 offset:23296                  // 00000005D4FC: DA845B00 00000A0B
	.long 0xd4cb007e                                           // 00000005D504: D4CB007E
	v_cndmask_b32_e32 v1, v50, v55, vcc_lo                     // 00000005D508: 02026F32
	s_cbranch_execz 34                                         // 00000005D50C: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1798>
	s_waitcnt lgkmcnt(8)                                       // 00000005D510: BF89FC87
	v_sub_f32_e32 v10, v29, v12                                // 00000005D514: 0814191D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D518: BF870091
	v_mul_f32_e32 v30, 0x3fb8aa3b, v10                         // 00000005D51C: 103C14FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v30                       // 00000005D524: D613001F 847A14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v30                                   // 00000005D530: 7E40471E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D534: BF870091
	v_dual_fmac_f32 v31, 0x32a5705f, v10 :: v_dual_sub_f32 v30, v30, v32// 00000005D538: C80A14FF 1F1E411E 32A5705F
	v_add_f32_e32 v30, v30, v31                                // 00000005D544: 063C3F1E
	v_cvt_i32_f32_e32 v31, v32                                 // 00000005D548: 7E3E1120
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005D54C: BF870292
	v_exp_f32_e32 v30, v30                                     // 00000005D550: 7E3C4B1E
	.long 0xd71c001e                                           // 00000005D554: D71C001E
	v_cndmask_b32_e32 v1, v30, v31, vcc_lo                     // 00000005D558: 02023F1E
	s_waitcnt lgkmcnt(4)                                       // 00000005D55C: BF89FC47
	v_mul_f32_e32 v31, v3, v27                                 // 00000005D560: 103E3703
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000005D564: 7C3614FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D56C: BF870123
	v_cndmask_b32_e32 v30, 0, v30, vcc_lo                      // 00000005D570: 023C3C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000005D574: 7C3C14FF 42B17218
	v_cndmask_b32_e32 v10, 0x7f800000, v30, vcc_lo             // 00000005D57C: 02143CFF 7F800000
	v_mul_f32_e32 v30, v13, v31                                // 00000005D584: 103C3F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D588: BF870091
	v_mul_f32_e32 v10, v10, v30                                // 00000005D58C: 10143D0A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 00000005D590: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005D598: 8C7E037E
	.long 0x7f143880                                           // 00000005D59C: 7F143880
	v_or_b32_e32 v30, 0x5b00, v11                              // 00000005D5A0: 383C16FF 00005B00
	s_mov_b32 s3, exec_lo                                      // 00000005D5A8: BE83007E
	s_delay_alu instid0(VALU_DEP_2)                            // 00000005D5AC: BF870002
	.long 0x7e16398a                                           // 00000005D5B0: 7E16398A
	ds_store_b16 v30, v10 offset:96                            // 00000005D5B4: D87C0060 00000A1E
	.long 0xd4cb007e                                           // 00000005D5BC: D4CB007E
	v_cndmask_b32_e32 v1, v50, v53, vcc_lo                     // 00000005D5C0: 02026B32
	s_cbranch_execz 35                                         // 00000005D5C4: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1854>
	s_waitcnt lgkmcnt(8)                                       // 00000005D5C8: BF89FC87
	v_sub_f32_e32 v11, v24, v12                                // 00000005D5CC: 08161918
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D5D0: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000005D5D4: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000005D5DC: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000005D5E4: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000005D5F0: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D5F4: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000005D5F8: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000005D604: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000005D608: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005D60C: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000005D610: 7E3E4B1F
	.long 0xd71c001f                                           // 00000005D614: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000005D618: 0202411F
	s_waitcnt lgkmcnt(4)                                       // 00000005D61C: BF89FC47
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D620: BF870121
	v_dual_mul_f32 v32, v4, v22 :: v_dual_cndmask_b32 v31, 0, v31// 00000005D624: C8D22D04 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000005D62C: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000005D634: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D63C: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 00000005D640: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 00000005D644: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005D648: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000005D64C: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005D654: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005D658: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000005D65C: BE83007E
	ds_store_b16 v30, v11 offset:192                           // 00000005D660: D87C00C0 00000B1E
	.long 0xd4cb007e                                           // 00000005D668: D4CB007E
	v_cndmask_b32_e32 v1, v50, v49, vcc_lo                     // 00000005D66C: 02026332
	s_cbranch_execz 35                                         // 00000005D670: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1900>
	s_waitcnt lgkmcnt(9)                                       // 00000005D674: BF89FC97
	v_sub_f32_e32 v10, v25, v12                                // 00000005D678: 08141919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D67C: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000005D680: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000005D688: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000005D694: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005D698: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000005D69C: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000005D6A4: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000005D6A8: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000005D6AC: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000005D6B0: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000005D6B4: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000005D6BC: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000005D6C0: BF870135
	.long 0xd71c000b                                           // 00000005D6C4: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000005D6C8: 02023F0B
	s_waitcnt lgkmcnt(5)                                       // 00000005D6CC: BF89FC57
	v_mul_f32_e32 v31, v5, v23                                 // 00000005D6D0: 103E2F05
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000005D6D4: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000005D6D8: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005D6E0: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000005D6E4: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000005D6EC: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D6F0: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000005D6F4: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 00000005D6F8: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005D700: 8C7E037E
	.long 0x7e143880                                           // 00000005D704: 7E143880
	s_mov_b32 s3, exec_lo                                      // 00000005D708: BE83007E
	ds_store_b16_d16_hi v30, v10 offset:288                    // 00000005D70C: DA840120 00000A1E
	.long 0x7e16390a                                           // 00000005D714: 7E16390A
	.long 0xd4cb007e                                           // 00000005D718: D4CB007E
	v_cndmask_b32_e32 v1, v50, v48, vcc_lo                     // 00000005D71C: 02026132
	s_cbranch_execz 34                                         // 00000005D720: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x19ac>
	s_waitcnt lgkmcnt(9)                                       // 00000005D724: BF89FC97
	v_sub_f32_e32 v11, v20, v12                                // 00000005D728: 08161914
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D72C: BF870091
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000005D730: 103E16FF 3FB8AA3B
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000005D738: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000005D744: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D748: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000005D74C: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000005D758: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000005D75C: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005D760: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000005D764: 7E3E4B1F
	.long 0xd71c001f                                           // 00000005D768: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000005D76C: 0202411F
	s_waitcnt lgkmcnt(5)                                       // 00000005D770: BF89FC57
	v_mul_f32_e32 v32, v6, v18                                 // 00000005D774: 10402506
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000005D778: 7C3616FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D780: BF870123
	v_cndmask_b32_e32 v31, 0, v31, vcc_lo                      // 00000005D784: 023E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000005D788: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000005D790: 02163EFF 7F800000
	v_mul_f32_e32 v31, v13, v32                                // 00000005D798: 103E410D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D79C: BF870091
	v_mul_f32_e32 v11, v11, v31                                // 00000005D7A0: 10163F0B
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000005D7A4: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005D7AC: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005D7B0: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000005D7B4: BE83007E
	ds_store_b16 v30, v11 offset:384                           // 00000005D7B8: D87C0180 00000B1E
	.long 0xd4cb007e                                           // 00000005D7C0: D4CB007E
	v_cndmask_b32_e32 v1, v50, v47, vcc_lo                     // 00000005D7C4: 02025F32
	s_cbranch_execz 35                                         // 00000005D7C8: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1a58>
	s_waitcnt lgkmcnt(10)                                      // 00000005D7CC: BF89FCA7
	v_sub_f32_e32 v10, v21, v12                                // 00000005D7D0: 08141915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D7D4: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000005D7D8: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000005D7E0: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000005D7EC: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005D7F0: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000005D7F4: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000005D7FC: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000005D800: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000005D804: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000005D808: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000005D80C: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000005D814: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000005D818: BF870135
	.long 0xd71c000b                                           // 00000005D81C: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000005D820: 02023F0B
	s_waitcnt lgkmcnt(6)                                       // 00000005D824: BF89FC67
	v_mul_f32_e32 v31, v7, v19                                 // 00000005D828: 103E2707
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000005D82C: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000005D830: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005D838: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000005D83C: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000005D844: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D848: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000005D84C: 1014170A
	v_fma_mixlo_f16 v10, v10, s48, 0                           // 00000005D850: CC21000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005D858: 8C7E037E
	.long 0x7f143880                                           // 00000005D85C: 7F143880
	s_mov_b32 s3, exec_lo                                      // 00000005D860: BE83007E
	ds_store_b16 v30, v10 offset:480                           // 00000005D864: D87C01E0 00000A1E
	.long 0x7e16398a                                           // 00000005D86C: 7E16398A
	.long 0xd4cb007e                                           // 00000005D870: D4CB007E
	v_cndmask_b32_e32 v1, v50, v46, vcc_lo                     // 00000005D874: 02025D32
	s_cbranch_execz 35                                         // 00000005D878: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1b08>
	s_waitcnt lgkmcnt(10)                                      // 00000005D87C: BF89FCA7
	v_sub_f32_e32 v11, v16, v12                                // 00000005D880: 08161910
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D884: BF870121
	v_mul_f32_e32 v31, 0x3fb8aa3b, v11                         // 00000005D888: 103E16FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v11                  // 00000005D890: 7C3616FF C2CE8ED0
	v_fma_f32 v32, 0x3fb8aa3b, v11, -v31                       // 00000005D898: D6130020 847E16FF 3FB8AA3B
	v_rndne_f32_e32 v33, v31                                   // 00000005D8A4: 7E42471F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D8A8: BF870091
	v_dual_fmac_f32 v32, 0x32a5705f, v11 :: v_dual_sub_f32 v31, v31, v33// 00000005D8AC: C80A16FF 201E431F 32A5705F
	v_add_f32_e32 v31, v31, v32                                // 00000005D8B8: 063E411F
	v_cvt_i32_f32_e32 v32, v33                                 // 00000005D8BC: 7E401121
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005D8C0: BF870292
	v_exp_f32_e32 v31, v31                                     // 00000005D8C4: 7E3E4B1F
	.long 0xd71c001f                                           // 00000005D8C8: D71C001F
	v_cndmask_b32_e32 v1, v31, v32, vcc_lo                     // 00000005D8CC: 0202411F
	s_waitcnt lgkmcnt(6)                                       // 00000005D8D0: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005D8D4: BF870121
	v_dual_mul_f32 v32, v8, v14 :: v_dual_cndmask_b32 v31, 0, v31// 00000005D8D8: C8D21D08 201E3E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v11                  // 00000005D8E0: 7C3C16FF 42B17218
	v_cndmask_b32_e32 v11, 0x7f800000, v31, vcc_lo             // 00000005D8E8: 02163EFF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D8F0: BF870093
	v_mul_f32_e32 v31, v13, v32                                // 00000005D8F4: 103E410D
	v_mul_f32_e32 v11, v11, v31                                // 00000005D8F8: 10163F0B
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005D8FC: BF870001
	v_fma_mixlo_f16 v11, v11, s48, 0                           // 00000005D900: CC21000B 0200610B
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005D908: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005D90C: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000005D910: BE83007E
	ds_store_b16 v30, v11 offset:576                           // 00000005D914: D87C0240 00000B1E
	.long 0xd4cb007e                                           // 00000005D91C: D4CB007E
	v_cndmask_b32_e32 v1, v50, v45, vcc_lo                     // 00000005D920: 02025B32
	s_cbranch_execz 35                                         // 00000005D924: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1bb4>
	s_waitcnt lgkmcnt(11)                                      // 00000005D928: BF89FCB7
	v_sub_f32_e32 v10, v17, v12                                // 00000005D92C: 08141911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D930: BF870091
	v_mul_f32_e32 v11, 0x3fb8aa3b, v10                         // 00000005D934: 101614FF 3FB8AA3B
	v_fma_f32 v31, 0x3fb8aa3b, v10, -v11                       // 00000005D93C: D613001F 842E14FF 3FB8AA3B
	v_rndne_f32_e32 v32, v11                                   // 00000005D948: 7E40470B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005D94C: BF870112
	v_fmac_f32_e32 v31, 0x32a5705f, v10                        // 00000005D950: 563E14FF 32A5705F
	v_sub_f32_e32 v11, v11, v32                                // 00000005D958: 0816410B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000005D95C: BF8701B1
	v_add_f32_e32 v11, v11, v31                                // 00000005D960: 06163F0B
	v_cvt_i32_f32_e32 v31, v32                                 // 00000005D964: 7E3E1120
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v10                  // 00000005D968: 7C3614FF C2CE8ED0
	v_exp_f32_e32 v11, v11                                     // 00000005D970: 7E164B0B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000005D974: BF870135
	.long 0xd71c000b                                           // 00000005D978: D71C000B
	v_cndmask_b32_e32 v1, v11, v31, vcc_lo                     // 00000005D97C: 02023F0B
	s_waitcnt lgkmcnt(7)                                       // 00000005D980: BF89FC77
	v_mul_f32_e32 v31, v9, v15                                 // 00000005D984: 103E1F09
	v_cndmask_b32_e32 v11, 0, v11, vcc_lo                      // 00000005D988: 02161680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v10                  // 00000005D98C: 7C3C14FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005D994: BF870212
	v_cndmask_b32_e32 v10, 0x7f800000, v11, vcc_lo             // 00000005D998: 021416FF 7F800000
	v_mul_f32_e32 v11, v13, v31                                // 00000005D9A0: 10163F0D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005D9A4: BF870091
	v_mul_f32_e32 v10, v10, v11                                // 00000005D9A8: 1014170A
	v_fma_mixhi_f16 v10, v10, s48, 0                           // 00000005D9AC: CC22000A 0200610A
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005D9B4: 8C7E037E
	s_mov_b32 s3, 0                                            // 00000005D9B8: BE830080
	ds_store_b16_d16_hi v30, v10 offset:672                    // 00000005D9BC: DA8402A0 00000A1E
	s_and_b32 vcc_lo, exec_lo, s3                              // 00000005D9C4: 8B6A037E
	s_cbranch_vccz 365                                         // 00000005D9C8: BFA3016D <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2180>
	v_or_b32_e32 v10, 0x5e40, v51                              // 00000005D9CC: 381466FF 00005E40
	v_mov_b32_e32 v57, 0                                       // 00000005D9D4: 7E720280
	v_mov_b32_e32 v59, 0                                       // 00000005D9D8: 7E760280
	s_mov_b32 s3, exec_lo                                      // 00000005D9DC: BE83007E
	s_delay_alu instid0(VALU_DEP_3)                            // 00000005D9E0: BF870003
	v_subrev_nc_u32_e32 v58, 64, v10                           // 00000005D9E4: 4E7414C0
	ds_load_2addr_b32 v[32:33], v58 offset0:2 offset1:4        // 00000005D9E8: D8DC0402 2000003A
	ds_load_2addr_b32 v[30:31], v58 offset0:6 offset1:8        // 00000005D9F0: D8DC0806 1E00003A
	ds_load_2addr_b32 v[10:11], v58 offset0:10 offset1:12      // 00000005D9F8: D8DC0C0A 0A00003A
	ds_load_b32 v56, v58 offset:56                             // 00000005DA00: D8D80038 3800003A
	.long 0xd4c9007e                                           // 00000005DA08: D4C9007E
	v_cndmask_b32_e32 v1, v50, v160, vcc_lo                    // 00000005DA0C: 02034132
	s_cbranch_execz 37                                         // 00000005DA10: BFA50025 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1ca8>
	s_waitcnt lgkmcnt(11)                                      // 00000005DA14: BF89FCB7
	v_sub_f32_e32 v28, v28, v12                                // 00000005DA18: 0838191C
	ds_load_b32 v58, v58                                       // 00000005DA1C: D8D80000 3A00003A
	s_waitcnt lgkmcnt(8)                                       // 00000005DA24: BF89FC87
	v_dual_mul_f32 v2, v2, v26 :: v_dual_mul_f32 v59, 0x3fb8aa3b, v28// 00000005DA28: C8C63502 023A38FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005DA34: BF870111
	v_mul_f32_e32 v2, v13, v2                                  // 00000005DA38: 1004050D
	v_fma_f32 v60, 0x3fb8aa3b, v28, -v59                       // 00000005DA3C: D613003C 84EE38FF 3FB8AA3B
	v_rndne_f32_e32 v61, v59                                   // 00000005DA48: 7E7A473B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000005DA4C: BF870131
	v_dual_sub_f32 v59, v59, v61 :: v_dual_fmac_f32 v60, 0x32a5705f, v28// 00000005DA50: C9407B3B 3B3C38FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v28                  // 00000005DA5C: 7C3638FF C2CE8ED0
	s_waitcnt lgkmcnt(0)                                       // 00000005DA64: BF89FC07
	v_dual_mul_f32 v2, v58, v2 :: v_dual_add_f32 v59, v59, v60 // 00000005DA68: C8C8053A 023A793B
	v_cvt_i32_f32_e32 v60, v61                                 // 00000005DA70: 7E78113D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005DA74: BF870292
	v_exp_f32_e32 v59, v59                                     // 00000005DA78: 7E764B3B
	.long 0xd71c003b                                           // 00000005DA7C: D71C003B
	v_cndmask_b32_e32 v1, v59, v60, vcc_lo                     // 00000005DA80: 0202793B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DA84: BF870121
	v_cndmask_b32_e32 v26, 0, v59, vcc_lo                      // 00000005DA88: 02347680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v28                  // 00000005DA8C: 7C3C38FF 42B17218
	v_cndmask_b32_e32 v26, 0x7f800000, v26, vcc_lo             // 00000005DA94: 023434FF 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005DA9C: BF870001
	.long 0xd508003b                                           // 00000005DAA0: D508003B
	v_sub_co_ci_u32_e32 v1, vcc_lo, v2, v26, vcc_lo            // 00000005DAA4: 42023502
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005DAA8: 8C7E037E
	v_or_b32_e32 v2, 0x5e40, v54                               // 00000005DAAC: 38046CFF 00005E40
	s_waitcnt lgkmcnt(7)                                       // 00000005DAB4: BF89FC77
	v_lshlrev_b32_e32 v26, 6, v160                             // 00000005DAB8: 30354086
	s_mov_b32 s3, exec_lo                                      // 00000005DABC: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005DAC0: BF870001
	v_add3_u32 v2, v2, v26, 0xfffff8c0                         // 00000005DAC4: D6550002 03FE3502 FFFFF8C0
	ds_store_b32 v2, v59                                       // 00000005DAD0: D8340000 00003B02
	.long 0xd4c9007e                                           // 00000005DAD8: D4C9007E
	v_cndmask_b32_e32 v1, v50, v55, vcc_lo                     // 00000005DADC: 02026F32
	s_cbranch_execz 33                                         // 00000005DAE0: BFA50021 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1d68>
	v_dual_sub_f32 v26, v29, v12 :: v_dual_mul_f32 v3, v3, v27 // 00000005DAE4: C946191D 1A023703
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DAEC: BF870121
	v_dual_mul_f32 v28, 0x3fb8aa3b, v26 :: v_dual_mul_f32 v3, v13, v3// 00000005DAF0: C8C634FF 1C02070D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v26                  // 00000005DAFC: 7C3634FF C2CE8ED0
	v_fma_f32 v29, 0x3fb8aa3b, v26, -v28                       // 00000005DB04: D613001D 847234FF 3FB8AA3B
	v_rndne_f32_e32 v54, v28                                   // 00000005DB10: 7E6C471C
	s_waitcnt lgkmcnt(4)                                       // 00000005DB14: BF89FC47
	v_mul_f32_e32 v3, v32, v3                                  // 00000005DB18: 10060720
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000005DB1C: BF870193
	v_fmac_f32_e32 v29, 0x32a5705f, v26                        // 00000005DB20: 563A34FF 32A5705F
	v_sub_f32_e32 v28, v28, v54                                // 00000005DB28: 08386D1C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DB2C: BF870121
	v_add_f32_e32 v28, v28, v29                                // 00000005DB30: 06383B1C
	v_cvt_i32_f32_e32 v29, v54                                 // 00000005DB34: 7E3A1136
	v_exp_f32_e32 v28, v28                                     // 00000005DB38: 7E384B1C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DB3C: BF870095
	.long 0xd71c001c                                           // 00000005DB40: D71C001C
	v_cndmask_b32_e32 v1, v28, v29, vcc_lo                     // 00000005DB44: 02023B1C
	v_cndmask_b32_e32 v27, 0, v28, vcc_lo                      // 00000005DB48: 02363880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v26                  // 00000005DB4C: 7C3C34FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DB54: BF870092
	v_cndmask_b32_e32 v26, 0x7f800000, v27, vcc_lo             // 00000005DB58: 023436FF 7F800000
	.long 0xd5080039                                           // 00000005DB60: D5080039
	v_sub_co_ci_u32_e32 v1, vcc_lo, v3, v26, vcc_lo            // 00000005DB64: 42023503
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005DB68: 8C7E037E
	v_dual_mov_b32 v3, 0 :: v_dual_mov_b32 v26, 0              // 00000005DB6C: CA100080 031A0080
	s_mov_b32 s3, exec_lo                                      // 00000005DB74: BE83007E
	ds_store_b32 v2, v57 offset:128                            // 00000005DB78: D8340080 00003902
	.long 0xd4c9007e                                           // 00000005DB80: D4C9007E
	v_cndmask_b32_e32 v1, v50, v53, vcc_lo                     // 00000005DB84: 02026B32
	s_cbranch_execz 35                                         // 00000005DB88: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1e18>
	v_sub_f32_e32 v24, v24, v12                                // 00000005DB8C: 08301918
	s_waitcnt lgkmcnt(8)                                       // 00000005DB90: BF89FC87
	v_mul_f32_e32 v4, v4, v22                                  // 00000005DB94: 10082D04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000005DB98: BF8701A2
	v_mul_f32_e32 v26, 0x3fb8aa3b, v24                         // 00000005DB9C: 103430FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v24                  // 00000005DBA4: 7C3630FF C2CE8ED0
	v_mul_f32_e32 v4, v13, v4                                  // 00000005DBAC: 1008090D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000005DBB0: BF8701B3
	v_fma_f32 v27, 0x3fb8aa3b, v24, -v26                       // 00000005DBB4: D613001B 846A30FF 3FB8AA3B
	v_rndne_f32_e32 v28, v26                                   // 00000005DBC0: 7E38471A
	s_waitcnt lgkmcnt(5)                                       // 00000005DBC4: BF89FC57
	v_mul_f32_e32 v4, v33, v4                                  // 00000005DBC8: 10080921
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000005DBCC: BF870193
	v_fmac_f32_e32 v27, 0x32a5705f, v24                        // 00000005DBD0: 563630FF 32A5705F
	v_sub_f32_e32 v26, v26, v28                                // 00000005DBD8: 0834391A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DBDC: BF870121
	v_add_f32_e32 v26, v26, v27                                // 00000005DBE0: 0634371A
	v_cvt_i32_f32_e32 v27, v28                                 // 00000005DBE4: 7E36111C
	v_exp_f32_e32 v26, v26                                     // 00000005DBE8: 7E344B1A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DBEC: BF870095
	.long 0xd71c001a                                           // 00000005DBF0: D71C001A
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 00000005DBF4: 0202371A
	v_cndmask_b32_e32 v22, 0, v26, vcc_lo                      // 00000005DBF8: 022C3480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v24                  // 00000005DBFC: 7C3C30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DC04: BF870092
	v_cndmask_b32_e32 v22, 0x7f800000, v22, vcc_lo             // 00000005DC08: 022C2CFF 7F800000
	.long 0xd508001a                                           // 00000005DC10: D508001A
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v22, vcc_lo            // 00000005DC14: 42022D04
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005DC18: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005DC1C: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000005DC20: BE83007E
	ds_store_b32 v2, v26 offset:256                            // 00000005DC24: D8340100 00001A02
	.long 0xd4c9007e                                           // 00000005DC2C: D4C9007E
	v_cndmask_b32_e32 v1, v50, v49, vcc_lo                     // 00000005DC30: 02026332
	s_cbranch_execz 34                                         // 00000005DC34: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1ec0>
	v_sub_f32_e32 v3, v25, v12                                 // 00000005DC38: 08061919
	s_waitcnt lgkmcnt(9)                                       // 00000005DC3C: BF89FC97
	v_mul_f32_e32 v5, v5, v23                                  // 00000005DC40: 100A2F05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DC44: BF870091
	v_dual_mul_f32 v4, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v5, v13, v5// 00000005DC48: C8C606FF 04040B0D 3FB8AA3B
	v_fma_f32 v22, 0x3fb8aa3b, v3, -v4                         // 00000005DC54: D6130016 841206FF 3FB8AA3B
	v_rndne_f32_e32 v24, v4                                    // 00000005DC60: 7E304704
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005DC64: BF870112
	v_fmac_f32_e32 v22, 0x32a5705f, v3                         // 00000005DC68: 562C06FF 32A5705F
	v_sub_f32_e32 v4, v4, v24                                  // 00000005DC70: 08083104
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000005DC74: BF8701B1
	v_add_f32_e32 v4, v4, v22                                  // 00000005DC78: 06082D04
	v_cvt_i32_f32_e32 v22, v24                                 // 00000005DC7C: 7E2C1118
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000005DC80: 7C3606FF C2CE8ED0
	v_exp_f32_e32 v4, v4                                       // 00000005DC88: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DC8C: BF870095
	.long 0xd71c0004                                           // 00000005DC90: D71C0004
	v_cndmask_b32_e32 v1, v4, v22, vcc_lo                      // 00000005DC94: 02022D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 00000005DC98: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000005DC9C: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(5)                                       // 00000005DCA4: BF89FC57
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DCA8: BF870092
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v30, v5// 00000005DCAC: CA4608FF 03040B1E 7F800000
	.long 0xd5080003                                           // 00000005DCB8: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000005DCBC: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005DCC0: 8C7E037E
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v5, 0               // 00000005DCC4: CA100080 04040080
	s_mov_b32 s3, exec_lo                                      // 00000005DCCC: BE83007E
	ds_store_b32 v2, v3 offset:384                             // 00000005DCD0: D8340180 00000302
	.long 0xd4c9007e                                           // 00000005DCD8: D4C9007E
	v_cndmask_b32_e32 v1, v50, v48, vcc_lo                     // 00000005DCDC: 02026132
	s_cbranch_execz 34                                         // 00000005DCE0: BFA50022 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x1f6c>
	s_waitcnt lgkmcnt(9)                                       // 00000005DCE4: BF89FC97
	v_dual_sub_f32 v3, v20, v12 :: v_dual_mul_f32 v6, v6, v18  // 00000005DCE8: C9461914 03062506
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DCF0: BF870121
	v_dual_mul_f32 v5, 0x3fb8aa3b, v3 :: v_dual_mul_f32 v6, v13, v6// 00000005DCF4: C8C606FF 05060D0D 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000005DD00: 7C3606FF C2CE8ED0
	v_fma_f32 v20, 0x3fb8aa3b, v3, -v5                         // 00000005DD08: D6130014 841606FF 3FB8AA3B
	v_rndne_f32_e32 v22, v5                                    // 00000005DD14: 7E2C4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DD18: BF870091
	v_dual_fmac_f32 v20, 0x32a5705f, v3 :: v_dual_sub_f32 v5, v5, v22// 00000005DD1C: C80A06FF 14042D05 32A5705F
	v_add_f32_e32 v5, v5, v20                                  // 00000005DD28: 060A2905
	v_cvt_i32_f32_e32 v20, v22                                 // 00000005DD2C: 7E281116
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000005DD30: BF870292
	v_exp_f32_e32 v5, v5                                       // 00000005DD34: 7E0A4B05
	.long 0xd71c0005                                           // 00000005DD38: D71C0005
	v_cndmask_b32_e32 v1, v5, v20, vcc_lo                      // 00000005DD3C: 02022905
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DD40: BF870121
	v_cndmask_b32_e32 v5, 0, v5, vcc_lo                        // 00000005DD44: 020A0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000005DD48: 7C3C06FF 42B17218
	v_cndmask_b32_e32 v3, 0x7f800000, v5, vcc_lo               // 00000005DD50: 02060AFF 7F800000
	s_waitcnt lgkmcnt(6)                                       // 00000005DD58: BF89FC67
	v_mul_f32_e32 v5, v31, v6                                  // 00000005DD5C: 100A0D1F
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005DD60: BF870001
	.long 0xd5080005                                           // 00000005DD64: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v3, vcc_lo             // 00000005DD68: 42020705
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005DD6C: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005DD70: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000005DD74: BE83007E
	ds_store_b32 v2, v5 offset:512                             // 00000005DD78: D8340200 00000502
	.long 0xd4c9007e                                           // 00000005DD80: D4C9007E
	v_cndmask_b32_e32 v1, v50, v47, vcc_lo                     // 00000005DD84: 02025F32
	s_cbranch_execz 35                                         // 00000005DD88: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2018>
	v_sub_f32_e32 v3, v21, v12                                 // 00000005DD8C: 08061915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DD90: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000005DD94: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 00000005DD9C: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 00000005DDA8: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005DDAC: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000005DDB0: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000005DDB4: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 00000005DDBC: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DDC4: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 00000005DDC8: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 00000005DDCC: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000005DDD0: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005DDD4: BF8700A5
	.long 0xd71c0004                                           // 00000005DDD8: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000005DDDC: 02020B04
	s_waitcnt lgkmcnt(10)                                      // 00000005DDE0: BF89FCA7
	v_dual_mul_f32 v5, v7, v19 :: v_dual_cndmask_b32 v4, 0, v4 // 00000005DDE4: C8D22707 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000005DDEC: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000005DDF0: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000005DDF4: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(6)                                       // 00000005DDFC: BF89FC67
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v10, v5// 00000005DE00: CA4608FF 03040B0A 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005DE0C: BF870001
	.long 0xd5080004                                           // 00000005DE10: D5080004
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000005DE14: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005DE18: 8C7E037E
	v_mov_b32_e32 v3, 0                                        // 00000005DE1C: 7E060280
	v_mov_b32_e32 v5, 0                                        // 00000005DE20: 7E0A0280
	s_mov_b32 s3, exec_lo                                      // 00000005DE24: BE83007E
	ds_store_b32 v2, v4 offset:640                             // 00000005DE28: D8340280 00000402
	.long 0xd4c9007e                                           // 00000005DE30: D4C9007E
	v_cndmask_b32_e32 v1, v50, v46, vcc_lo                     // 00000005DE34: 02025D32
	s_cbranch_execz 35                                         // 00000005DE38: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x20c8>
	v_sub_f32_e32 v4, v16, v12                                 // 00000005DE3C: 08081910
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DE40: BF870091
	v_mul_f32_e32 v5, 0x3fb8aa3b, v4                           // 00000005DE44: 100A08FF 3FB8AA3B
	v_fma_f32 v6, 0x3fb8aa3b, v4, -v5                          // 00000005DE4C: D6130006 841608FF 3FB8AA3B
	v_rndne_f32_e32 v7, v5                                     // 00000005DE58: 7E0E4705
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005DE5C: BF870221
	v_sub_f32_e32 v5, v5, v7                                   // 00000005DE60: 080A0F05
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v4                   // 00000005DE64: 7C3608FF C2CE8ED0
	v_fmac_f32_e32 v6, 0x32a5705f, v4                          // 00000005DE6C: 560C08FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DE74: BF870121
	v_add_f32_e32 v5, v5, v6                                   // 00000005DE78: 060A0D05
	v_cvt_i32_f32_e32 v6, v7                                   // 00000005DE7C: 7E0C1107
	v_exp_f32_e32 v5, v5                                       // 00000005DE80: 7E0A4B05
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005DE84: BF8700A5
	.long 0xd71c0005                                           // 00000005DE88: D71C0005
	v_cndmask_b32_e32 v1, v5, v6, vcc_lo                       // 00000005DE8C: 02020D05
	s_waitcnt lgkmcnt(10)                                      // 00000005DE90: BF89FCA7
	v_dual_mul_f32 v6, v8, v14 :: v_dual_cndmask_b32 v5, 0, v5 // 00000005DE94: C8D21D08 06040A80
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000005DE9C: BF870131
	v_mul_f32_e32 v6, v13, v6                                  // 00000005DEA0: 100C0D0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v4                   // 00000005DEA4: 7C3C08FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 00000005DEAC: BF89FC77
	v_dual_cndmask_b32 v4, 0x7f800000, v5 :: v_dual_mul_f32 v5, v11, v6// 00000005DEB0: CA460AFF 04040D0B 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005DEBC: BF870001
	.long 0xd5080005                                           // 00000005DEC0: D5080005
	v_sub_co_ci_u32_e32 v1, vcc_lo, v5, v4, vcc_lo             // 00000005DEC4: 42020905
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005DEC8: 8C7E037E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005DECC: BF870009
	s_mov_b32 s3, exec_lo                                      // 00000005DED0: BE83007E
	ds_store_b32 v2, v5 offset:768                             // 00000005DED4: D8340300 00000502
	.long 0xd4c9007e                                           // 00000005DEDC: D4C9007E
	v_cndmask_b32_e32 v1, v50, v45, vcc_lo                     // 00000005DEE0: 02025B32
	s_cbranch_execz 35                                         // 00000005DEE4: BFA50023 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2174>
	v_sub_f32_e32 v3, v17, v12                                 // 00000005DEE8: 08061911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DEEC: BF870091
	v_mul_f32_e32 v4, 0x3fb8aa3b, v3                           // 00000005DEF0: 100806FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v3, -v4                          // 00000005DEF8: D6130005 841206FF 3FB8AA3B
	v_rndne_f32_e32 v6, v4                                     // 00000005DF04: 7E0C4704
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005DF08: BF870221
	v_sub_f32_e32 v4, v4, v6                                   // 00000005DF0C: 08080D04
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v3                   // 00000005DF10: 7C3606FF C2CE8ED0
	v_fmac_f32_e32 v5, 0x32a5705f, v3                          // 00000005DF18: 560A06FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005DF20: BF870121
	v_add_f32_e32 v4, v4, v5                                   // 00000005DF24: 06080B04
	v_cvt_i32_f32_e32 v5, v6                                   // 00000005DF28: 7E0A1106
	v_exp_f32_e32 v4, v4                                       // 00000005DF2C: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005DF30: BF8700A5
	.long 0xd71c0004                                           // 00000005DF34: D71C0004
	v_cndmask_b32_e32 v1, v4, v5, vcc_lo                       // 00000005DF38: 02020B04
	s_waitcnt lgkmcnt(11)                                      // 00000005DF3C: BF89FCB7
	v_dual_mul_f32 v5, v9, v15 :: v_dual_cndmask_b32 v4, 0, v4 // 00000005DF40: C8D21F09 05040880
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000005DF48: BF870131
	v_mul_f32_e32 v5, v13, v5                                  // 00000005DF4C: 100A0B0D
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v3                   // 00000005DF50: 7C3C06FF 42B17218
	s_waitcnt lgkmcnt(7)                                       // 00000005DF58: BF89FC77
	v_dual_cndmask_b32 v3, 0x7f800000, v4 :: v_dual_mul_f32 v4, v56, v5// 00000005DF5C: CA4608FF 03040B38 7F800000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005DF68: BF870001
	.long 0xd5080003                                           // 00000005DF6C: D5080003
	v_sub_co_ci_u32_e32 v1, vcc_lo, v4, v3, vcc_lo             // 00000005DF70: 42020704
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005DF74: 8C7E037E
	ds_store_b32 v2, v3 offset:896                             // 00000005DF78: D8340380 00000302
	s_waitcnt lgkmcnt(0)                                       // 00000005DF80: BF89FC07
	s_barrier                                                  // 00000005DF84: BFBD0000
	s_and_b32 vcc_lo, exec_lo, s41                             // 00000005DF88: 8B6A297E
	s_mov_b32 s3, -1                                           // 00000005DF8C: BE8300C1
	s_cbranch_vccz 176                                         // 00000005DF90: BFA300B0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2454>
	s_mov_b32 s3, exec_lo                                      // 00000005DF94: BE83007E
	v_cmpx_gt_i32_e32 0x120, v44                               // 00000005DF98: 7D8858FF 00000120
	s_cbranch_execz 170                                        // 00000005DFA0: BFA500AA <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x244c>
	v_add_nc_u32_e32 v2, 0xffffff00, v44                       // 00000005DFA4: 4A0458FF FFFFFF00
	s_mov_b32 s4, 0                                            // 00000005DFAC: BE840080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005DFB0: BF870001
	v_mov_b32_e32 v3, v2                                       // 00000005DFB4: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005DFB8: BF8700A1
	v_add_nc_u32_e32 v3, 0xe0, v3                              // 00000005DFBC: 4A0606FF 000000E0
	s_waitcnt lgkmcnt(4)                                       // 00000005DFC4: BF89FC47
	v_ashrrev_i32_e32 v16, 7, v3                               // 00000005DFC8: 34200687
	v_and_b32_e32 v12, 0x7f, v3                                // 00000005DFCC: 361806FF 0000007F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005DFD4: BF870092
	.long 0xd72c0004                                           // 00000005DFD8: D72C0004
	v_cndmask_b32_e32 v1, 0x880, v16, vcc_lo                   // 00000005DFDC: 020220FF 00000880
	v_lshl_add_u32 v4, v12, 1, v4                              // 00000005DFE4: D6460004 0411030C
	ds_load_u16 v20, v4 offset:7776                            // 00000005DFEC: D8F01E60 14000004
	ds_load_u16 v21, v4 offset:7232                            // 00000005DFF4: D8F01C40 15000004
	s_waitcnt lgkmcnt(4)                                       // 00000005DFFC: BF89FC47
	ds_load_u16 v22, v4 offset:6688                            // 00000005E000: D8F01A20 16000004
	ds_load_u16 v23, v4 offset:6144                            // 00000005E008: D8F01800 17000004
	ds_load_u16 v24, v4 offset:6416                            // 00000005E010: D8F01910 18000004
	s_waitcnt lgkmcnt(3)                                       // 00000005E018: BF89FC37
	v_lshlrev_b32_e32 v21, 16, v21                             // 00000005E01C: 302A2A90
	s_waitcnt lgkmcnt(1)                                       // 00000005E020: BF89FC17
	v_lshlrev_b32_e32 v23, 16, v23                             // 00000005E024: 302E2E90
	v_lshlrev_b32_e32 v17, 5, v16                              // 00000005E028: 30222085
	ds_load_u16 v25, v4 offset:6960                            // 00000005E02C: D8F01B30 19000004
	ds_load_u16 v26, v4 offset:7504                            // 00000005E034: D8F01D50 1A000004
	ds_load_u16 v27, v4 offset:8048                            // 00000005E03C: D8F01F70 1B000004
	ds_load_b128 v[4:7], v17 offset:24384                      // 00000005E044: DBFC5F40 04000011
	ds_load_b128 v[8:11], v17 offset:24400                     // 00000005E04C: DBFC5F50 08000011
	v_lshlrev_b32_e32 v20, 16, v20                             // 00000005E054: 30282890
	s_waitcnt lgkmcnt(0)                                       // 00000005E058: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E05C: BF870091
	v_dual_mul_f32 v10, v10, v20 :: v_dual_lshlrev_b32 v25, 16, v25// 00000005E060: C8E2290A 0A183290
	v_dual_mul_f32 v7, v7, v25 :: v_dual_lshlrev_b32 v24, 16, v24// 00000005E068: C8E23307 07183090
	v_mul_f32_e32 v8, v8, v21                                  // 00000005E070: 10102B08
	s_delay_alu instid0(VALU_DEP_2)                            // 00000005E074: BF870002
	v_dual_mul_f32 v4, v4, v23 :: v_dual_mul_f32 v5, v5, v24   // 00000005E078: C8C62F04 04043105
	v_mul_u32_u24_e32 v18, 48, v12                             // 00000005E080: 162418B0
	ds_load_b128 v[12:15], v17 offset:24192                    // 00000005E084: DBFC5E80 0C000011
	v_lshlrev_b32_e32 v26, 16, v26                             // 00000005E08C: 30343490
	v_lshlrev_b32_e32 v27, 16, v27                             // 00000005E090: 30363690
	v_lshl_add_u32 v28, v16, 4, v18                            // 00000005E094: D646001C 04490910
	ds_load_b128 v[16:19], v17 offset:24208                    // 00000005E09C: DBFC5E90 10000011
	s_waitcnt lgkmcnt(1)                                       // 00000005E0A4: BF89FC17
	v_mul_f32_e32 v12, v12, v4                                 // 00000005E0A8: 1018090C
	v_mul_f32_e32 v4, v13, v5                                  // 00000005E0AC: 10080B0D
	v_dual_mul_f32 v11, v11, v27 :: v_dual_lshlrev_b32 v22, 16, v22// 00000005E0B0: C8E2370B 0B162C90
	v_mul_f32_e32 v5, v15, v7                                  // 00000005E0B8: 100A0F0F
	v_mul_f32_e32 v9, v9, v26                                  // 00000005E0BC: 10123509
	s_waitcnt lgkmcnt(0)                                       // 00000005E0C0: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 00000005E0C4: BF870243
	v_dual_mul_f32 v7, v16, v8 :: v_dual_mul_f32 v6, v6, v22   // 00000005E0C8: C8C61110 07062D06
	v_cmp_lt_i32_e32 vcc_lo, 31, v3                            // 00000005E0D0: 7C82069F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 00000005E0D4: CC220004 02006104
	v_dual_mul_f32 v8, v17, v9 :: v_dual_mul_f32 v9, v18, v10  // 00000005E0DC: C8C61311 08081512
	v_mul_f32_e32 v6, v14, v6                                  // 00000005E0E4: 100C0D0E
	v_mul_f32_e32 v10, v19, v11                                // 00000005E0E8: 10141713
	v_fma_mixlo_f16 v4, v12, s48, 0                            // 00000005E0EC: CC210004 0200610C
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 00000005E0F4: CC220005 02006105
	s_or_b32 s4, vcc_lo, s4                                    // 00000005E0FC: 8C04046A
	v_fma_mixlo_f16 v5, v6, s48, 0                             // 00000005E100: CC210005 02006106
	v_fma_mixhi_f16 v6, v8, s48, 0                             // 00000005E108: CC220006 02006108
	v_fma_mixlo_f16 v6, v7, s48, 0                             // 00000005E110: CC210006 02006107
	v_fma_mixhi_f16 v7, v10, s48, 0                            // 00000005E118: CC220007 0200610A
	v_fma_mixlo_f16 v7, v9, s48, 0                             // 00000005E120: CC210007 02006109
	ds_store_b128 v28, v[4:7]                                  // 00000005E128: DB7C0000 0000041C
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000005E130: 917E047E
	s_cbranch_execnz 65440                                     // 00000005E134: BFA6FFA0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x21b8>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000005E138: 8C7E047E
	v_lshl_add_u32 v3, v44, 3, 0xffffff00                      // 00000005E13C: D6460003 03FD072C FFFFFF00
	s_mov_b32 s4, 0                                            // 00000005E148: BE840080
	v_add_nc_u32_e32 v2, 0xe0, v2                              // 00000005E14C: 4A0404FF 000000E0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000005E154: BF8701A2
	v_and_b32_e32 v4, 0x78, v3                                 // 00000005E158: 360806FF 00000078
	v_add_nc_u32_e32 v3, 0x700, v3                             // 00000005E160: 4A0606FF 00000700
	v_ashrrev_i32_e32 v5, 4, v2                                // 00000005E168: 340A0484
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005E16C: BF870121
	.long 0xd72c0006                                           // 00000005E170: D72C0006
	v_cndmask_b32_e32 v1, 0x110, v5, vcc_lo                    // 00000005E174: 02020AFF 00000110
	v_lshlrev_b32_e32 v8, 2, v5                                // 00000005E17C: 30100A82
	v_lshl_add_u32 v9, v4, 1, v6                               // 00000005E180: D6460009 04190304
	ds_load_b128 v[4:7], v9 offset:10496                       // 00000005E188: DBFC2900 04000009
	ds_load_b32 v8, v8 offset:24448                            // 00000005E190: D8D85F80 08000008
	s_waitcnt lgkmcnt(1)                                       // 00000005E198: BF89FC17
	v_and_b32_e32 v12, 0xffff0000, v6                          // 00000005E19C: 36180CFF FFFF0000
	v_lshlrev_b32_e32 v6, 16, v6                               // 00000005E1A4: 300C0C90
	v_and_b32_e32 v13, 0xffff0000, v7                          // 00000005E1A8: 361A0EFF FFFF0000
	v_and_b32_e32 v10, 0xffff0000, v4                          // 00000005E1B0: 361408FF FFFF0000
	v_lshlrev_b32_e32 v4, 16, v4                               // 00000005E1B8: 30080890
	v_and_b32_e32 v11, 0xffff0000, v5                          // 00000005E1BC: 36160AFF FFFF0000
	v_lshlrev_b32_e32 v5, 16, v5                               // 00000005E1C4: 300A0A90
	s_waitcnt lgkmcnt(0)                                       // 00000005E1C8: BF89FC07
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000005E1CC: BF8701A3
	v_dual_mul_f32 v14, v8, v4 :: v_dual_lshlrev_b32 v7, 16, v7// 00000005E1D0: C8E20908 0E060E90
	v_mul_f32_e32 v4, v8, v10                                  // 00000005E1D8: 10081508
	v_mul_f32_e32 v10, v8, v5                                  // 00000005E1DC: 10140B08
	v_mul_f32_e32 v5, v8, v11                                  // 00000005E1E0: 100A1708
	v_mul_f32_e32 v11, v8, v6                                  // 00000005E1E4: 10160D08
	v_mul_f32_e32 v6, v8, v12                                  // 00000005E1E8: 100C1908
	v_mul_f32_e32 v12, v8, v7                                  // 00000005E1EC: 10180F08
	v_mul_f32_e32 v7, v8, v13                                  // 00000005E1F0: 100E1B08
	v_cmp_lt_i32_e32 vcc_lo, 31, v2                            // 00000005E1F4: 7C82049F
	v_fma_mixhi_f16 v4, v4, s48, 0                             // 00000005E1F8: CC220004 02006104
	v_fma_mixlo_f16 v4, v14, s48, 0                            // 00000005E200: CC210004 0200610E
	v_fma_mixhi_f16 v5, v5, s48, 0                             // 00000005E208: CC220005 02006105
	v_fma_mixlo_f16 v5, v10, s48, 0                            // 00000005E210: CC210005 0200610A
	v_fma_mixhi_f16 v6, v6, s48, 0                             // 00000005E218: CC220006 02006106
	v_fma_mixlo_f16 v6, v11, s48, 0                            // 00000005E220: CC210006 0200610B
	v_fma_mixhi_f16 v7, v7, s48, 0                             // 00000005E228: CC220007 02006107
	v_fma_mixlo_f16 v7, v12, s48, 0                            // 00000005E230: CC210007 0200610C
	s_or_b32 s4, vcc_lo, s4                                    // 00000005E238: 8C04046A
	ds_store_b128 v9, v[4:7] offset:10496                      // 00000005E23C: DB7C2900 00000409
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000005E244: 917E047E
	s_cbranch_execnz 65472                                     // 00000005E248: BFA6FFC0 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x234c>
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005E24C: 8C7E037E
	s_mov_b32 s3, 0                                            // 00000005E250: BE830080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000005E254: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s3                         // 00000005E258: 916A037E
	s_cbranch_vccnz 530                                        // 00000005E25C: BFA40212 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2ca8>
	s_mov_b32 s3, exec_lo                                      // 00000005E260: BE83007E
	v_cmpx_gt_u32_e32 16, v43                                  // 00000005E264: 7D985690
	s_cbranch_execz 526                                        // 00000005E268: BFA5020E <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x2ca4>
	v_cmp_eq_u32_e32 vcc_lo, 0, v43                            // 00000005E26C: 7C945680
	s_waitcnt lgkmcnt(0)                                       // 00000005E270: BF89FC07
	ds_load_b96 v[14:16], v1 offset:23280                      // 00000005E274: DBF85AF0 0E000001
	ds_load_b128 v[53:56], v1 offset:23248                     // 00000005E27C: DBFC5AD0 35000001
	ds_load_b128 v[57:60], v1 offset:23264                     // 00000005E284: DBFC5AE0 39000001
	ds_load_b128 v[10:13], v1 offset:23168                     // 00000005E28C: DBFC5A80 0A000001
	ds_load_b128 v[6:9], v1 offset:23184                       // 00000005E294: DBFC5A90 06000001
	ds_load_b128 v[2:5], v1 offset:23200                       // 00000005E29C: DBFC5AA0 02000001
	ds_load_b64 v[17:18], v1 offset:23216                      // 00000005E2A4: D9D85AB0 11000001
	v_cndmask_b32_e64 v44, 0, 1.0, vcc_lo                      // 00000005E2AC: D501002C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 1, v43                            // 00000005E2B4: 7C945681
	ds_load_b128 v[45:48], v1 offset:23232                     // 00000005E2B8: DBFC5AC0 2D000001
	v_cndmask_b32_e64 v33, 0, 1.0, vcc_lo                      // 00000005E2C0: D5010021 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 2, v43                            // 00000005E2C8: 7C945682
	v_cndmask_b32_e64 v32, 0, 1.0, vcc_lo                      // 00000005E2CC: D5010020 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 3, v43                            // 00000005E2D4: 7C945683
	v_cndmask_b32_e64 v31, 0, 1.0, vcc_lo                      // 00000005E2D8: D501001F 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 4, v43                            // 00000005E2E0: 7C945684
	v_cndmask_b32_e64 v29, 0, 1.0, vcc_lo                      // 00000005E2E4: D501001D 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 5, v43                            // 00000005E2EC: 7C945685
	v_cndmask_b32_e64 v30, 0, 1.0, vcc_lo                      // 00000005E2F0: D501001E 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 6, v43                            // 00000005E2F8: 7C945686
	v_cndmask_b32_e64 v28, 0, 1.0, vcc_lo                      // 00000005E2FC: D501001C 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 7, v43                            // 00000005E304: 7C945687
	v_cndmask_b32_e64 v27, 0, 1.0, vcc_lo                      // 00000005E308: D501001B 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 8, v43                            // 00000005E310: 7C945688
	v_cndmask_b32_e64 v25, 0, 1.0, vcc_lo                      // 00000005E314: D5010019 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 9, v43                            // 00000005E31C: 7C945689
	v_cndmask_b32_e64 v23, 0, 1.0, vcc_lo                      // 00000005E320: D5010017 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 10, v43                           // 00000005E328: 7C94568A
	v_cndmask_b32_e64 v26, 0, 1.0, vcc_lo                      // 00000005E32C: D501001A 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 11, v43                           // 00000005E334: 7C94568B
	v_cndmask_b32_e64 v24, 0, 1.0, vcc_lo                      // 00000005E338: D5010018 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 12, v43                           // 00000005E340: 7C94568C
	v_cndmask_b32_e64 v20, 0, 1.0, vcc_lo                      // 00000005E344: D5010014 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 13, v43                           // 00000005E34C: 7C94568D
	v_cndmask_b32_e64 v22, 0, 1.0, vcc_lo                      // 00000005E350: D5010016 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 14, v43                           // 00000005E358: 7C94568E
	v_cndmask_b32_e64 v21, 0, 1.0, vcc_lo                      // 00000005E35C: D5010015 01A9E480
	v_cmp_eq_u32_e32 vcc_lo, 15, v43                           // 00000005E364: 7C94568F
	v_cndmask_b32_e64 v19, 0, 1.0, vcc_lo                      // 00000005E368: D5010013 01A9E480
	s_waitcnt lgkmcnt(7)                                       // 00000005E370: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000005E374: BF8700B1
	v_fmac_f32_e32 v22, v19, v15                               // 00000005E378: 562C1F13
	v_fmac_f32_e32 v21, v19, v16                               // 00000005E37C: 562A2113
	s_waitcnt lgkmcnt(1)                                       // 00000005E380: BF89FC17
	v_dual_fmac_f32 v27, v19, v56 :: v_dual_fmac_f32 v22, v21, v18// 00000005E384: C8007113 1B162515
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000005E38C: BF8700D1
	v_dual_fmac_f32 v30, v19, v54 :: v_dual_fmac_f32 v27, v21, v9// 00000005E390: C8006D13 1E1A1315
	v_fmac_f32_e32 v29, v19, v53                               // 00000005E398: 563A6B13
	ds_load_b32 v18, v1 offset:22880                           // 00000005E39C: D8D85960 12000001
	v_fmac_f32_e32 v30, v21, v7                                // 00000005E3A4: 563C0F15
	v_dual_fmac_f32 v28, v19, v55 :: v_dual_fmac_f32 v29, v21, v6// 00000005E3A8: C8006F13 1C1C0D15
	v_dual_fmac_f32 v25, v19, v57 :: v_dual_fmac_f32 v28, v21, v8// 00000005E3B0: C8007313 191C1115
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E3B8: BF870091
	v_dual_fmac_f32 v26, v19, v59 :: v_dual_fmac_f32 v25, v21, v2// 00000005E3BC: C8007713 1A180515
	v_dual_fmac_f32 v23, v19, v58 :: v_dual_fmac_f32 v26, v21, v4// 00000005E3C4: C8007513 171A0915
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E3CC: BF870091
	v_dual_fmac_f32 v24, v19, v60 :: v_dual_fmac_f32 v23, v21, v3// 00000005E3D0: C8007913 18160715
	v_fmac_f32_e32 v24, v21, v5                                // 00000005E3D8: 56300B15
	ds_load_b128 v[2:5], v1 offset:23072                       // 00000005E3DC: DBFC5A20 02000001
	s_waitcnt lgkmcnt(2)                                       // 00000005E3E4: BF89FC27
	v_fmac_f32_e32 v31, v19, v48                               // 00000005E3E8: 563E6113
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005E3EC: BF870001
	v_dual_fmac_f32 v32, v19, v47 :: v_dual_fmac_f32 v31, v21, v13// 00000005E3F0: C8005F13 201E1B15
	v_fmac_f32_e32 v20, v19, v14                               // 00000005E3F8: 56281D13
	ds_load_b128 v[53:56], v1 offset:23104                     // 00000005E3FC: DBFC5A40 35000001
	ds_load_b128 v[57:60], v1 offset:23136                     // 00000005E404: DBFC5A60 39000001
	ds_load_b128 v[61:64], v1 offset:23120                     // 00000005E40C: DBFC5A50 3D000001
	ds_load_b32 v14, v1 offset:23152                           // 00000005E414: D8D85A70 0E000001
	v_dual_fmac_f32 v33, v19, v46 :: v_dual_fmac_f32 v32, v21, v12// 00000005E41C: C8005D13 21201915
	v_fmac_f32_e32 v44, v19, v45                               // 00000005E424: 56585B13
	ds_load_b128 v[45:48], v1 offset:24064                     // 00000005E428: DBFC5E00 2D000001
	v_fmac_f32_e32 v33, v21, v11                               // 00000005E430: 56421715
	v_fmac_f32_e32 v44, v21, v10                               // 00000005E434: 56581515
	ds_load_b128 v[6:9], v1 offset:23056                       // 00000005E438: DBFC5A10 06000001
	ds_load_b128 v[10:13], v1 offset:23040                     // 00000005E440: DBFC5A00 0A000001
	s_waitcnt lgkmcnt(6)                                       // 00000005E448: BF89FC67
	v_fmac_f32_e32 v44, v22, v53                               // 00000005E44C: 56586B16
	v_dual_fmac_f32 v31, v22, v56 :: v_dual_fmac_f32 v20, v21, v17// 00000005E450: C8007116 1F142315
	s_waitcnt lgkmcnt(4)                                       // 00000005E458: BF89FC47
	v_fmac_f32_e32 v27, v22, v64                               // 00000005E45C: 56368116
	v_fmac_f32_e32 v33, v22, v54                               // 00000005E460: 56426D16
	s_waitcnt lgkmcnt(3)                                       // 00000005E464: BF89FC37
	v_fmac_f32_e32 v20, v22, v14                               // 00000005E468: 56281D16
	ds_load_b128 v[14:17], v1 offset:22976                     // 00000005E46C: DBFC59C0 0E000001
	v_fmac_f32_e32 v24, v22, v60                               // 00000005E474: 56307916
	v_fmac_f32_e32 v30, v22, v62                               // 00000005E478: 563C7D16
	v_fmac_f32_e32 v29, v22, v61                               // 00000005E47C: 563A7B16
	s_waitcnt lgkmcnt(1)                                       // 00000005E480: BF89FC17
	v_fmac_f32_e32 v33, v20, v11                               // 00000005E484: 56421714
	ds_load_b64 v[60:61], v1 offset:22944                      // 00000005E488: D9D859A0 3C000001
	v_fmac_f32_e32 v24, v20, v5                                // 00000005E490: 56300B14
	s_waitcnt lgkmcnt(1)                                       // 00000005E494: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000005E498: BF8701D1
	v_fmac_f32_e32 v33, v24, v15                               // 00000005E49C: 56421F18
	v_fmac_f32_e32 v44, v20, v10                               // 00000005E4A0: 56581514
	v_dual_fmac_f32 v32, v22, v55 :: v_dual_fmac_f32 v29, v20, v6// 00000005E4A4: C8006F16 201C0D14
	v_fmac_f32_e32 v25, v22, v57                               // 00000005E4AC: 56327316
	v_dual_fmac_f32 v23, v22, v58 :: v_dual_fmac_f32 v30, v20, v7// 00000005E4B0: C8007516 171E0F14
	v_fmac_f32_e32 v32, v20, v12                               // 00000005E4B8: 56401914
	s_delay_alu instid0(VALU_DEP_3)                            // 00000005E4BC: BF870003
	v_dual_fmac_f32 v26, v22, v59 :: v_dual_fmac_f32 v25, v20, v2// 00000005E4C0: C8007716 1A180514
	ds_load_b128 v[53:56], v1 offset:22992                     // 00000005E4C8: DBFC59D0 35000001
	ds_load_b96 v[57:59], v1 offset:23008                      // 00000005E4D0: DBF859E0 39000001
	v_dual_fmac_f32 v28, v22, v63 :: v_dual_fmac_f32 v27, v20, v9// 00000005E4D8: C8007F16 1C1A1314
	v_fmac_f32_e32 v26, v20, v4                                // 00000005E4E0: 56340914
	v_fmac_f32_e32 v31, v20, v13                               // 00000005E4E4: 563E1B14
	v_fmac_f32_e32 v23, v20, v3                                // 00000005E4E8: 562E0714
	ds_load_b128 v[2:5], v1 offset:22848                       // 00000005E4EC: DBFC5940 02000001
	s_waitcnt lgkmcnt(1)                                       // 00000005E4F4: BF89FC17
	v_fmac_f32_e32 v26, v24, v59                               // 00000005E4F8: 56347718
	v_fmac_f32_e32 v28, v20, v8                                // 00000005E4FC: 56381114
	ds_load_b128 v[6:9], v1 offset:22928                       // 00000005E500: DBFC5990 06000001
	ds_load_b128 v[10:13], v1 offset:22912                     // 00000005E508: DBFC5980 0A000001
	v_fmac_f32_e32 v29, v24, v53                               // 00000005E510: 563A6B18
	s_waitcnt lgkmcnt(1)                                       // 00000005E514: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005E518: BF870001
	v_fmac_f32_e32 v29, v26, v6                                // 00000005E51C: 563A0D1A
	v_fmac_f32_e32 v31, v24, v17                               // 00000005E520: 563E2318
	v_fmac_f32_e32 v44, v24, v14                               // 00000005E524: 56581D18
	v_fmac_f32_e32 v23, v24, v58                               // 00000005E528: 562E7518
	v_fmac_f32_e32 v32, v24, v16                               // 00000005E52C: 56402118
	ds_load_b128 v[14:17], v1 offset:22864                     // 00000005E530: DBFC5950 0E000001
	v_fmac_f32_e32 v27, v24, v56                               // 00000005E538: 56367118
	v_fmac_f32_e32 v30, v24, v54                               // 00000005E53C: 563C6D18
	v_fmac_f32_e32 v25, v24, v57                               // 00000005E540: 56327318
	s_waitcnt lgkmcnt(1)                                       // 00000005E544: BF89FC17
	v_fmac_f32_e32 v33, v26, v11                               // 00000005E548: 5642171A
	v_fmac_f32_e32 v28, v24, v55                               // 00000005E54C: 56386F18
	ds_load_b128 v[53:56], v1 offset:22800                     // 00000005E550: DBFC5910 35000001
	v_fmac_f32_e32 v31, v26, v13                               // 00000005E558: 563E1B1A
	v_fmac_f32_e32 v23, v26, v61                               // 00000005E55C: 562E7B1A
	ds_load_b96 v[57:59], v1 offset:22736                      // 00000005E560: DBF858D0 39000001
	v_dual_fmac_f32 v31, v23, v5 :: v_dual_fmac_f32 v44, v26, v10// 00000005E568: C8000B17 1F2C151A
	v_fmac_f32_e32 v32, v26, v12                               // 00000005E570: 5640191A
	ds_load_b128 v[10:13], v1 offset:22784                     // 00000005E574: DBFC5900 0A000001
	v_fmac_f32_e32 v25, v26, v60                               // 00000005E57C: 5632791A
	v_fmac_f32_e32 v28, v26, v8                                // 00000005E580: 5638111A
	v_fmac_f32_e32 v27, v26, v9                                // 00000005E584: 5636131A
	v_fmac_f32_e32 v30, v26, v7                                // 00000005E588: 563C0F1A
	ds_load_b128 v[6:9], v1 offset:22720                       // 00000005E58C: DBFC58C0 06000001
	ds_load_b64 v[60:61], v1 offset:22672                      // 00000005E594: D9D85890 3C000001
	v_fmac_f32_e32 v25, v23, v18                               // 00000005E59C: 56322517
	s_waitcnt lgkmcnt(5)                                       // 00000005E5A0: BF89FC57
	v_fmac_f32_e32 v28, v23, v16                               // 00000005E5A4: 56382117
	v_fmac_f32_e32 v29, v23, v14                               // 00000005E5A8: 563A1D17
	v_fmac_f32_e32 v27, v23, v17                               // 00000005E5AC: 56362317
	v_fmac_f32_e32 v33, v23, v3                                // 00000005E5B0: 56420717
	s_waitcnt lgkmcnt(4)                                       // 00000005E5B4: BF89FC47
	v_fmac_f32_e32 v28, v25, v55                               // 00000005E5B8: 56386F19
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000005E5BC: BF870153
	v_dual_fmac_f32 v30, v23, v15 :: v_dual_fmac_f32 v27, v25, v56// 00000005E5C0: C8001F17 1E1A7119
	ds_load_b128 v[14:17], v1 offset:22528                     // 00000005E5C8: DBFC5800 0E000001
	v_fmac_f32_e32 v30, v25, v54                               // 00000005E5D0: 563C6D19
	s_waitcnt lgkmcnt(4)                                       // 00000005E5D4: BF89FC47
	v_fmac_f32_e32 v28, v27, v59                               // 00000005E5D8: 5638771B
	v_fmac_f32_e32 v30, v27, v58                               // 00000005E5DC: 563C751B
	s_waitcnt lgkmcnt(1)                                       // 00000005E5E0: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005E5E4: BF870001
	v_fmac_f32_e32 v30, v28, v61                               // 00000005E5E8: 563C7B1C
	v_dual_fmac_f32 v44, v23, v2 :: v_dual_fmac_f32 v33, v25, v11// 00000005E5EC: C8000517 2C201719
	v_dual_fmac_f32 v32, v23, v4 :: v_dual_fmac_f32 v31, v25, v13// 00000005E5F4: C8000917 201E1B19
	ds_load_b128 v[2:5], v1 offset:22656                       // 00000005E5FC: DBFC5880 02000001
	v_fmac_f32_e32 v44, v25, v10                               // 00000005E604: 56581519
	v_fmac_f32_e32 v29, v25, v53                               // 00000005E608: 563A6B19
	v_fmac_f32_e32 v32, v25, v12                               // 00000005E60C: 56401919
	ds_load_b128 v[10:13], v1 offset:22592                     // 00000005E610: DBFC5840 0A000001
	ds_load_b32 v18, v1 offset:22608                           // 00000005E618: D8D85850 12000001
	ds_load_b64 v[53:54], v1 offset:22400                      // 00000005E620: D9D85780 35000001
	v_fmac_f32_e32 v44, v27, v6                                // 00000005E628: 56580D1B
	s_waitcnt lgkmcnt(3)                                       // 00000005E62C: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005E630: BF870001
	v_dual_fmac_f32 v44, v28, v2 :: v_dual_fmac_f32 v31, v27, v9// 00000005E634: C800051C 2C1E131B
	v_fmac_f32_e32 v32, v27, v8                                // 00000005E63C: 5640111B
	v_fmac_f32_e32 v29, v27, v57                               // 00000005E640: 563A731B
	v_fmac_f32_e32 v33, v27, v7                                // 00000005E644: 56420F1B
	ds_load_b96 v[6:8], v1 offset:22464                        // 00000005E648: DBF857C0 06000001
	ds_load_b32 v9, v1 offset:22336                            // 00000005E650: D8D85740 09000001
	s_waitcnt lgkmcnt(4)                                       // 00000005E658: BF89FC47
	v_dual_fmac_f32 v31, v28, v5 :: v_dual_fmac_f32 v44, v30, v10// 00000005E65C: C8000B1C 1F2C151E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005E664: BF870001
	v_fmac_f32_e32 v31, v30, v13                               // 00000005E668: 563E1B1E
	v_fmac_f32_e32 v29, v28, v60                               // 00000005E66C: 563A791C
	v_fmac_f32_e32 v33, v28, v3                                // 00000005E670: 5642071C
	v_fmac_f32_e32 v32, v28, v4                                // 00000005E674: 5640091C
	ds_load_b128 v[2:5], v1 offset:24256                       // 00000005E678: DBFC5EC0 02000001
	ds_load_b128 v[57:60], v1 offset:24304                     // 00000005E680: DBFC5EF0 39000001
	s_waitcnt lgkmcnt(5)                                       // 00000005E688: BF89FC57
	v_fmac_f32_e32 v29, v30, v18                               // 00000005E68C: 563A251E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E690: BF870091
	v_dual_fmac_f32 v33, v30, v11 :: v_dual_fmac_f32 v44, v29, v14// 00000005E694: C800171E 212C1D1D
	v_dual_fmac_f32 v32, v30, v12 :: v_dual_fmac_f32 v33, v29, v15// 00000005E69C: C800191E 20201F1D
	v_fmac_f32_e32 v31, v29, v17                               // 00000005E6A4: 563E231D
	s_waitcnt lgkmcnt(3)                                       // 00000005E6A8: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005E6AC: BF870091
	v_dual_fmac_f32 v32, v29, v16 :: v_dual_fmac_f32 v33, v31, v7// 00000005E6B0: C800211D 20200F1F
	v_fmac_f32_e32 v32, v31, v8                                // 00000005E6B8: 5640111F
	v_fmac_f32_e32 v44, v31, v6                                // 00000005E6BC: 56580D1F
	s_waitcnt lgkmcnt(0)                                       // 00000005E6C0: BF89FC07
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005E6C4: BF870112
	v_dual_mul_f32 v66, v59, v21 :: v_dual_fmac_f32 v33, v32, v54// 00000005E6C8: C8C02B3B 42206D20
	v_fmac_f32_e32 v44, v32, v53                               // 00000005E6D0: 56586B20
	ds_load_b128 v[53:56], v1 offset:24288                     // 00000005E6D4: DBFC5EE0 35000001
	v_fma_mixlo_f16 v18, v3, v33, 0                            // 00000005E6DC: CC210012 02024303
	v_fmac_f32_e32 v44, v33, v9                                // 00000005E6E4: 56581321
	ds_load_b128 v[6:9], v1 offset:24272                       // 00000005E6E8: DBFC5ED0 06000001
	ds_load_b128 v[10:13], v1 offset:24112                     // 00000005E6F0: DBFC5E30 0A000001
	v_dual_mul_f32 v15, v3, v33 :: v_dual_mul_f32 v14, v2, v44 // 00000005E6F8: C8C64303 0F0E5902
	v_fma_mixlo_f16 v2, v2, v44, 0                             // 00000005E700: CC210002 02025902
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000005E708: BF8701A2
	v_fma_mix_f32 v15, v18, -1.0, v15 op_sel_hi:[1,1,0]        // 00000005E70C: CC20000F 1C3DE712
	v_fma_mixlo_f16 v49, v5, v31, 0                            // 00000005E714: CC210031 02023F05
	v_fma_mix_f32 v3, v2, -1.0, v14 op_sel_hi:[1,1,0]          // 00000005E71C: CC200003 1C39E702
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 00000005E724: BF870233
	.long 0x7f1c150f                                           // 00000005E728: 7F1C150F
	v_mul_f32_e32 v15, v4, v32                                 // 00000005E72C: 101E4104
	.long 0x7f043912                                           // 00000005E730: 7F043912
	v_cvt_f16_f32_e32 v14, v3                                  // 00000005E734: 7E1C1503
	v_fma_mixlo_f16 v3, v4, v32, 0                             // 00000005E738: CC210003 02024104
	v_mul_f32_e32 v4, v5, v31                                  // 00000005E740: 10083F05
	s_waitcnt lgkmcnt(2)                                       // 00000005E744: BF89FC27
	v_fma_mixlo_f16 v63, v54, v23, 0                           // 00000005E748: CC21003F 02022F36
	s_waitcnt lgkmcnt(1)                                       // 00000005E750: BF89FC17
	v_dual_mul_f32 v5, v6, v29 :: v_dual_mul_f32 v16, v7, v30  // 00000005E754: C8C63B06 05103D07
	v_fma_mixlo_f16 v61, v7, v30, 0                            // 00000005E75C: CC21003D 02023D07
	v_fma_mix_f32 v17, v49, -1.0, v4 op_sel_hi:[1,1,0]         // 00000005E764: CC200011 1C11E731
	v_fma_mixlo_f16 v4, v6, v29, 0                             // 00000005E76C: CC210004 02023B06
	v_fma_mix_f32 v7, v3, -1.0, v15 op_sel_hi:[1,1,0]          // 00000005E774: CC200007 1C3DE703
	v_fma_mixlo_f16 v62, v9, v27, 0                            // 00000005E77C: CC21003E 02023709
	v_fma_mix_f32 v6, v61, -1.0, v16 op_sel_hi:[1,1,0]         // 00000005E784: CC200006 1C41E73D
	.long 0x7f1e1511                                           // 00000005E78C: 7F1E1511
	v_fma_mix_f32 v5, v4, -1.0, v5 op_sel_hi:[1,1,0]           // 00000005E790: CC200005 1C15E704
	v_cvt_f16_f32_e32 v15, v7                                  // 00000005E798: 7E1E1507
	v_mul_f32_e32 v7, v8, v28                                  // 00000005E79C: 100E3908
	.long 0x7f201506                                           // 00000005E7A0: 7F201506
	v_fma_mixlo_f16 v6, v53, v25, 0                            // 00000005E7A4: CC210006 02023335
	v_cvt_f16_f32_e32 v16, v5                                  // 00000005E7AC: 7E201505
	v_fma_mixlo_f16 v5, v8, v28, 0                             // 00000005E7B0: CC210005 02023908
	v_mul_f32_e32 v8, v9, v27                                  // 00000005E7B8: 10103709
	v_mul_f32_e32 v9, v53, v25                                 // 00000005E7BC: 10123335
	v_dual_mul_f32 v53, v54, v23 :: v_dual_mul_f32 v54, v55, v26// 00000005E7C0: C8C62F36 35363537
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005E7C8: BF870214
	v_fma_mix_f32 v7, v5, -1.0, v7 op_sel_hi:[1,1,0]           // 00000005E7CC: CC200007 1C1DE705
	v_fma_mix_f32 v8, v62, -1.0, v8 op_sel_hi:[1,1,0]          // 00000005E7D4: CC200008 1C21E73E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005E7DC: BF870214
	v_fma_mix_f32 v9, v6, -1.0, v9 op_sel_hi:[1,1,0]           // 00000005E7E0: CC200009 1C25E706
	v_fma_mix_f32 v64, v63, -1.0, v53 op_sel_hi:[1,1,0]        // 00000005E7E8: CC200040 1CD5E73F
	.long 0x7f0c393f                                           // 00000005E7F0: 7F0C393F
	v_cvt_f16_f32_e32 v17, v7                                  // 00000005E7F4: 7E221507
	v_fma_mixlo_f16 v7, v55, v26, 0                            // 00000005E7F8: CC210007 02023537
	.long 0x7f221508                                           // 00000005E800: 7F221508
	v_cvt_f16_f32_e32 v53, v9                                  // 00000005E804: 7E6A1509
	.long 0x7f6a1540                                           // 00000005E808: 7F6A1540
	v_mul_f32_e32 v9, v56, v24                                 // 00000005E80C: 10123138
	v_fma_mix_f32 v8, v7, -1.0, v54 op_sel_hi:[1,1,0]          // 00000005E810: CC200008 1CD9E707
	v_fma_mixlo_f16 v64, v56, v24, 0                           // 00000005E818: CC210040 02023138
	v_dual_mul_f32 v55, v57, v20 :: v_dual_mul_f32 v56, v58, v22// 00000005E820: C8C62939 37382D3A
	v_fma_mixlo_f16 v58, v58, v22, 0                           // 00000005E828: CC21003A 02022D3A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005E830: BF870214
	v_cvt_f16_f32_e32 v54, v8                                  // 00000005E834: 7E6C1508
	v_fma_mix_f32 v65, v64, -1.0, v9 op_sel_hi:[1,1,0]         // 00000005E838: CC200041 1C25E740
	v_fma_mixlo_f16 v8, v57, v20, 0                            // 00000005E840: CC210008 02022939
	v_fma_mixlo_f16 v9, v59, v21, 0                            // 00000005E848: CC210009 02022B3B
	v_fma_mix_f32 v56, v58, -1.0, v56 op_sel_hi:[1,1,0]        // 00000005E850: CC200038 1CE1E73A
	v_mul_f32_e32 v59, v60, v19                                // 00000005E858: 1076273C
	v_fma_mixlo_f16 v60, v60, v19, 0                           // 00000005E85C: CC21003C 0202273C
	v_fma_mix_f32 v55, v8, -1.0, v55 op_sel_hi:[1,1,0]         // 00000005E864: CC200037 1CDDE708
	v_fma_mix_f32 v57, v9, -1.0, v66 op_sel_hi:[1,1,0]         // 00000005E86C: CC200039 1D09E709
	.long 0x7f6c1541                                           // 00000005E874: 7F6C1541
	.long 0x7f10393a                                           // 00000005E878: 7F10393A
	v_fma_mix_f32 v65, v60, -1.0, v59 op_sel_hi:[1,1,0]        // 00000005E87C: CC200041 1CEDE73C
	v_cvt_f16_f32_e32 v55, v55                                 // 00000005E884: 7E6E1537
	.long 0x7f6e1538                                           // 00000005E888: 7F6E1538
	v_cvt_f16_f32_e32 v56, v57                                 // 00000005E88C: 7E701539
	.long 0x7f12393c                                           // 00000005E890: 7F12393C
	ds_load_b128 v[57:60], v1 offset:24080                     // 00000005E894: DBFC5E10 39000001
	v_mul_u32_u24_e32 v66, 48, v43                             // 00000005E89C: 168456B0
	.long 0x7f0e3940                                           // 00000005E8A0: 7F0E3940
	.long 0x7f063931                                           // 00000005E8A4: 7F063931
	.long 0x7f08393d                                           // 00000005E8A8: 7F08393D
	.long 0x7f0a393e                                           // 00000005E8AC: 7F0A393E
	v_mul_f32_e32 v18, v45, v44                                // 00000005E8B0: 1024592D
	v_fma_mixlo_f16 v43, v45, v44, 0                           // 00000005E8B4: CC21002B 0202592D
	v_mul_f32_e32 v44, v46, v33                                // 00000005E8BC: 1058432E
	v_fma_mixlo_f16 v33, v46, v33, 0                           // 00000005E8C0: CC210021 0202432E
	ds_store_b128 v66, v[6:9] offset:19216                     // 00000005E8C8: DB7C4B10 00000642
	ds_store_b128 v66, v[2:5] offset:19200                     // 00000005E8D0: DB7C4B00 00000242
	ds_load_b128 v[2:5], v1 offset:24096                       // 00000005E8D8: DBFC5E20 02000001
	v_fma_mix_f32 v18, v43, -1.0, v18 op_sel_hi:[1,1,0]        // 00000005E8E0: CC200012 1C49E72B
	v_mul_f32_e32 v7, v47, v32                                 // 00000005E8E8: 100E412F
	v_fma_mix_f32 v44, v33, -1.0, v44 op_sel_hi:[1,1,0]        // 00000005E8EC: CC20002C 1CB1E721
	v_mul_f32_e32 v8, v48, v31                                 // 00000005E8F4: 10103F30
	.long 0x7f701541                                           // 00000005E8F8: 7F701541
	v_cvt_f16_f32_e32 v6, v18                                  // 00000005E8FC: 7E0C1512
	v_fma_mixlo_f16 v18, v48, v31, 0                           // 00000005E900: CC210012 02023F30
	.long 0x7f0c152c                                           // 00000005E908: 7F0C152C
	v_fma_mixlo_f16 v44, v47, v32, 0                           // 00000005E90C: CC21002C 0202412F
	s_waitcnt lgkmcnt(3)                                       // 00000005E914: BF89FC37
	v_mul_f32_e32 v9, v57, v29                                 // 00000005E918: 10123B39
	v_mul_f32_e32 v31, v58, v30                                // 00000005E91C: 103E3D3A
	v_fma_mixlo_f16 v30, v58, v30, 0                           // 00000005E920: CC21001E 02023D3A
	v_fma_mixlo_f16 v45, v57, v29, 0                           // 00000005E928: CC21002D 02023B39
	v_fma_mix_f32 v7, v44, -1.0, v7 op_sel_hi:[1,1,0]          // 00000005E930: CC200007 1C1DE72C
	v_fma_mix_f32 v8, v18, -1.0, v8 op_sel_hi:[1,1,0]          // 00000005E938: CC200008 1C21E712
	v_fma_mixlo_f16 v46, v59, v28, 0                           // 00000005E940: CC21002E 0202393B
	v_fma_mix_f32 v29, v30, -1.0, v31 op_sel_hi:[1,1,0]        // 00000005E948: CC20001D 1C7DE71E
	v_fma_mix_f32 v9, v45, -1.0, v9 op_sel_hi:[1,1,0]          // 00000005E950: CC200009 1C25E72D
	v_dual_mul_f32 v31, v59, v28 :: v_dual_mul_f32 v28, v60, v27// 00000005E958: C8C6393B 1F1C373C
	v_fma_mixlo_f16 v27, v60, v27, 0                           // 00000005E960: CC21001B 0202373C
	v_cvt_f16_f32_e32 v7, v7                                   // 00000005E968: 7E0E1507
	.long 0x7f0e1508                                           // 00000005E96C: 7F0E1508
	v_cvt_f16_f32_e32 v8, v9                                   // 00000005E970: 7E101509
	.long 0x7f10151d                                           // 00000005E974: 7F10151D
	v_fma_mix_f32 v9, v46, -1.0, v31 op_sel_hi:[1,1,0]         // 00000005E978: CC200009 1C7DE72E
	s_waitcnt lgkmcnt(0)                                       // 00000005E980: BF89FC07
	v_mul_f32_e32 v29, v2, v25                                 // 00000005E984: 103A3302
	v_fma_mixlo_f16 v2, v2, v25, 0                             // 00000005E988: CC210002 02023302
	v_mul_f32_e32 v25, v3, v23                                 // 00000005E990: 10322F03
	v_fma_mixlo_f16 v31, v3, v23, 0                            // 00000005E994: CC21001F 02022F03
	v_fma_mix_f32 v3, v27, -1.0, v28 op_sel_hi:[1,1,0]         // 00000005E99C: CC200003 1C71E71B
	v_cvt_f16_f32_e32 v9, v9                                   // 00000005E9A4: 7E121509
	v_mul_f32_e32 v23, v4, v26                                 // 00000005E9A8: 102E3504
	.long 0x7f563921                                           // 00000005E9AC: 7F563921
	v_fma_mix_f32 v25, v31, -1.0, v25 op_sel_hi:[1,1,0]        // 00000005E9B0: CC200019 1C65E71F
	.long 0x7f121503                                           // 00000005E9B8: 7F121503
	v_fma_mixlo_f16 v3, v4, v26, 0                             // 00000005E9BC: CC210003 02023504
	v_mul_f32_e32 v26, v11, v22                                // 00000005E9C4: 10342D0B
	v_fma_mix_f32 v28, v2, -1.0, v29 op_sel_hi:[1,1,0]         // 00000005E9C8: CC20001C 1C75E702
	v_fma_mixlo_f16 v11, v11, v22, 0                           // 00000005E9D0: CC21000B 02022D0B
	.long 0x7f04391f                                           // 00000005E9D8: 7F04391F
	v_fma_mix_f32 v4, v3, -1.0, v23 op_sel_hi:[1,1,0]          // 00000005E9DC: CC200004 1C5DE703
	.long 0x7f2e1519                                           // 00000005E9E4: 7F2E1519
	v_cvt_f16_f32_e32 v23, v28                                 // 00000005E9E8: 7E2E151C
	v_mul_f32_e32 v25, v5, v24                                 // 00000005E9EC: 10323105
	v_fma_mixlo_f16 v28, v5, v24, 0                            // 00000005E9F0: CC21001C 02023105
	v_cvt_f16_f32_e32 v24, v4                                  // 00000005E9F8: 7E301504
	v_mul_f32_e32 v5, v10, v20                                 // 00000005E9FC: 100A290A
	v_fma_mixlo_f16 v4, v10, v20, 0                            // 00000005EA00: CC210004 0202290A
	v_fma_mix_f32 v20, v11, -1.0, v26 op_sel_hi:[1,1,0]        // 00000005EA08: CC200014 1C69E70B
	v_fma_mix_f32 v22, v28, -1.0, v25 op_sel_hi:[1,1,0]        // 00000005EA10: CC200016 1C65E71C
	v_mul_f32_e32 v25, v12, v21                                // 00000005EA18: 10322B0C
	.long 0x7f06391c                                           // 00000005EA1C: 7F06391C
	v_fma_mix_f32 v10, v4, -1.0, v5 op_sel_hi:[1,1,0]          // 00000005EA20: CC20000A 1C15E704
	v_fma_mixlo_f16 v5, v12, v21, 0                            // 00000005EA28: CC210005 02022B0C
	v_mul_f32_e32 v21, v13, v19                                // 00000005EA30: 102A270D
	v_fma_mixlo_f16 v13, v13, v19, 0                           // 00000005EA34: CC21000D 0202270D
	.long 0x7f08390b                                           // 00000005EA3C: 7F08390B
	.long 0x7f583912                                           // 00000005EA40: 7F583912
	v_fma_mix_f32 v12, v5, -1.0, v25 op_sel_hi:[1,1,0]         // 00000005EA44: CC20000C 1C65E705
	v_cvt_f16_f32_e32 v25, v10                                 // 00000005EA4C: 7E32150A
	v_fma_mix_f32 v10, v13, -1.0, v21 op_sel_hi:[1,1,0]        // 00000005EA50: CC20000A 1C55E70D
	.long 0x7f0a390d                                           // 00000005EA58: 7F0A390D
	.long 0x7f5a391e                                           // 00000005EA5C: 7F5A391E
	.long 0x7f5c391b                                           // 00000005EA60: 7F5C391B
	.long 0x7f301516                                           // 00000005EA64: 7F301516
	.long 0x7f321514                                           // 00000005EA68: 7F321514
	v_cvt_f16_f32_e32 v26, v12                                 // 00000005EA6C: 7E34150C
	.long 0x7f34150a                                           // 00000005EA70: 7F34150A
	ds_store_b128 v66, v[53:56] offset:19984                   // 00000005EA74: DB7C4E10 00003542
	ds_store_b128 v66, v[14:17] offset:19968                   // 00000005EA7C: DB7C4E00 00000E42
	ds_store_b128 v66, v[2:5] offset:20752                     // 00000005EA84: DB7C5110 00000242
	ds_store_b128 v66, v[43:46] offset:20736                   // 00000005EA8C: DB7C5100 00002B42
	ds_store_b128 v66, v[23:26] offset:21520                   // 00000005EA94: DB7C5410 00001742
	ds_store_b128 v66, v[6:9] offset:21504                     // 00000005EA9C: DB7C5400 00000642
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005EAA4: 8C7E037E
	v_cmp_eq_u32_e32 vcc_lo, 0, v34                            // 00000005EAA8: 7C944480
	v_dual_mov_b32 v0, v71 :: v_dual_mov_b32 v3, 0             // 00000005EAAC: CA100147 00020080
	v_lshlrev_b32_e32 v53, 1, v159                             // 00000005EAB4: 306B3E81
	s_waitcnt lgkmcnt(0)                                       // 00000005EAB8: BF89FC07
	s_barrier                                                  // 00000005EABC: BFBD0000
	v_dual_cndmask_b32 v2, 0x7060302, v72 :: v_dual_mov_b32 v7, 0// 00000005EAC0: CA5090FF 02060080 07060302
	s_delay_alu instid0(VALU_DEP_3)                            // 00000005EACC: BF870003
	v_mov_b32_dpp v3, v42 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000005EAD0: 7E0602FA FF00B12A
	s_waitcnt lgkmcnt(8)                                       // 00000005EAD8: BF89FC87
	ds_load_u16 v12, v53 offset:6416                           // 00000005EADC: D8F01910 0C000035
	ds_load_u16 v13, v53 offset:6960                           // 00000005EAE4: D8F01B30 0D000035
	s_waitcnt lgkmcnt(2)                                       // 00000005EAEC: BF89FC27
	ds_load_u16 v14, v53 offset:7504                           // 00000005EAF0: D8F01D50 0E000035
	ds_load_u16 v15, v53 offset:8048                           // 00000005EAF8: D8F01F70 0F000035
	ds_load_u16 v16, v53 offset:7776                           // 00000005EB00: D8F01E60 10000035
	ds_load_u16 v18, v53 offset:7232                           // 00000005EB08: D8F01C40 12000035
	ds_load_u16 v19, v53 offset:6688                           // 00000005EB10: D8F01A20 13000035
	ds_load_u16 v20, v53 offset:6144                           // 00000005EB18: D8F01800 14000035
	s_cmp_lt_i32 s54, s39                                      // 00000005EB20: BF042736
	v_mov_b32_e32 v11, 0                                       // 00000005EB24: 7E160280
	v_mov_b32_dpp v7, v40 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000005EB28: 7E0E02FA FF00B128
	v_perm_b32 v3, v42, v3, v2                                 // 00000005EB30: D6440003 040A072A
	v_mov_b32_e32 v4, 0                                        // 00000005EB38: 7E080280
	s_cselect_b32 s57, -1, 0                                   // 00000005EB3C: 983980C1
	s_or_b32 s3, s54, 1                                        // 00000005EB40: 8C038136
	v_perm_b32 v7, v40, v7, v2                                 // 00000005EB44: D6440007 040A0F28
	v_dual_mov_b32 v8, 0 :: v_dual_and_b32 v5, 0xffff0000, v3  // 00000005EB4C: CA240080 080406FF FFFF0000
	v_mov_b32_dpp v4, v41 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000005EB58: 7E0802FA FF00B129
	s_cmp_lt_i32 s3, s39                                       // 00000005EB60: BF042703
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000005EB64: BF870193
	v_and_b32_e32 v9, 0xffff0000, v7                           // 00000005EB68: 36120EFF FFFF0000
	v_mov_b32_dpp v8, v39 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000005EB70: 7E1002FA FF00B127
	s_cselect_b32 s58, -1, 0                                   // 00000005EB78: 983A80C1
	v_perm_b32 v4, v41, v4, v2                                 // 00000005EB7C: D6440004 040A0929
	s_or_b32 s3, s54, 2                                        // 00000005EB84: 8C038236
	s_waitcnt lgkmcnt(5)                                       // 00000005EB88: BF89FC57
	v_lshlrev_b32_e32 v14, 16, v14                             // 00000005EB8C: 301C1C90
	v_perm_b32 v8, v39, v8, v2                                 // 00000005EB90: D6440008 040A1127
	s_cmp_lt_i32 s3, s39                                       // 00000005EB98: BF042703
	v_and_b32_e32 v6, 0xffff0000, v4                           // 00000005EB9C: 360C08FF FFFF0000
	v_mov_b32_e32 v10, 0                                       // 00000005EBA4: 7E140280
	v_mov_b32_dpp v11, v37 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000005EBA8: 7E1602FA FF00B125
	v_and_b32_e32 v17, 0xffff0000, v8                          // 00000005EBB0: 362210FF FFFF0000
	s_cselect_b32 s59, -1, 0                                   // 00000005EBB8: 983B80C1
	s_or_b32 s3, s54, 3                                        // 00000005EBBC: 8C038336
	v_mov_b32_dpp v10, v38 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000005EBC0: 7E1402FA FF00B126
	v_perm_b32 v22, v37, v11, v2                               // 00000005EBC8: D6440016 040A1725
	s_cmp_lt_i32 s3, s39                                       // 00000005EBD0: BF042703
	s_waitcnt lgkmcnt(4)                                       // 00000005EBD4: BF89FC47
	v_lshlrev_b32_e32 v15, 16, v15                             // 00000005EBD8: 301E1E90
	s_cselect_b32 s60, -1, 0                                   // 00000005EBDC: 983C80C1
	v_perm_b32 v21, v38, v10, v2                               // 00000005EBE0: D6440015 040A1526
	v_dual_mov_b32 v11, 0 :: v_dual_and_b32 v24, 0xffff0000, v22// 00000005EBE8: CA240080 0B182CFF FFFF0000
	s_or_b32 s3, s54, 4                                        // 00000005EBF4: 8C038436
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005EBF8: BF870122
	v_dual_mov_b32 v10, 0 :: v_dual_and_b32 v23, 0xffff0000, v21// 00000005EBFC: CA240080 0A162AFF FFFF0000
	s_cmp_lt_i32 s3, s39                                       // 00000005EC08: BF042703
	v_mov_b32_dpp v11, v36 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000005EC0C: 7E1602FA FF00B124
	s_cselect_b32 s61, -1, 0                                   // 00000005EC14: 983D80C1
	s_or_b32 s3, s54, 5                                        // 00000005EC18: 8C038536
	v_mov_b32_dpp v10, v35 quad_perm:[1,0,3,2] row_mask:0xf bank_mask:0xf// 00000005EC1C: 7E1402FA FF00B123
	s_cmp_lt_i32 s3, s39                                       // 00000005EC24: BF042703
	v_perm_b32 v42, v36, v11, v2                               // 00000005EC28: D644002A 040A1724
	s_waitcnt lgkmcnt(0)                                       // 00000005EC30: BF89FC07
	v_lshlrev_b32_e32 v11, 16, v20                             // 00000005EC34: 30162890
	s_cselect_b32 s62, -1, 0                                   // 00000005EC38: 983E80C1
	v_perm_b32 v25, v35, v10, v2                               // 00000005EC3C: D6440019 040A1523
	ds_load_u16 v2, v53 offset:8592                            // 00000005EC44: D8F02190 02000035
	ds_load_u16 v26, v53 offset:9136                           // 00000005EC4C: D8F023B0 1A000035
	ds_load_u16 v27, v53 offset:9680                           // 00000005EC54: D8F025D0 1B000035
	ds_load_u16 v28, v53 offset:10224                          // 00000005EC5C: D8F027F0 1C000035
	ds_load_u16 v29, v53 offset:9952                           // 00000005EC64: D8F026E0 1D000035
	ds_load_u16 v30, v53 offset:9408                           // 00000005EC6C: D8F024C0 1E000035
	ds_load_u16 v31, v53 offset:8864                           // 00000005EC74: D8F022A0 1F000035
	ds_load_u16 v32, v53 offset:8320                           // 00000005EC7C: D8F02080 20000035
	v_lshlrev_b32_e32 v10, 16, v12                             // 00000005EC84: 30141890
	v_lshlrev_b32_e32 v12, 16, v13                             // 00000005EC88: 30181A90
	v_lshlrev_b32_e32 v13, 16, v19                             // 00000005EC8C: 301A2690
	s_or_b32 s3, s54, 6                                        // 00000005EC90: 8C038636
	v_and_b32_e32 v33, 0xffff0000, v25                         // 00000005EC94: 364232FF FFFF0000
	.long 0x7f14150a                                           // 00000005EC9C: 7F14150A
	v_cvt_f16_f32_e32 v10, v11                                 // 00000005ECA0: 7E14150B
	.long 0x7f16150c                                           // 00000005ECA4: 7F16150C
	v_cvt_f16_f32_e32 v11, v13                                 // 00000005ECA8: 7E16150D
	v_lshlrev_b32_e32 v13, 16, v18                             // 00000005ECAC: 301A2490
	.long 0x7f18150e                                           // 00000005ECB0: 7F18150E
	v_lshlrev_b32_e32 v14, 16, v16                             // 00000005ECB4: 301C2090
	s_waitcnt lgkmcnt(7)                                       // 00000005ECB8: BF89FC77
	v_lshlrev_b32_e32 v2, 16, v2                               // 00000005ECBC: 30040490
	s_cmp_lt_i32 s3, s39                                       // 00000005ECC0: BF042703
	v_cvt_f16_f32_e32 v12, v13                                 // 00000005ECC4: 7E18150D
	.long 0x7f1a150f                                           // 00000005ECC8: 7F1A150F
	v_cvt_f16_f32_e32 v13, v14                                 // 00000005ECCC: 7E1A150E
	.long 0x7f1c1502                                           // 00000005ECD0: 7F1C1502
	s_waitcnt lgkmcnt(6)                                       // 00000005ECD4: BF89FC67
	v_lshlrev_b32_e32 v2, 16, v26                              // 00000005ECD8: 30043490
	s_waitcnt lgkmcnt(0)                                       // 00000005ECDC: BF89FC07
	v_lshlrev_b32_e32 v15, 16, v32                             // 00000005ECE0: 301E4090
	s_cselect_b32 s63, -1, 0                                   // 00000005ECE4: 983F80C1
	s_or_b32 s3, s54, 7                                        // 00000005ECE8: 8C038736
	v_lshlrev_b32_e32 v16, 16, v31                             // 00000005ECEC: 30203E90
	s_cmp_lt_i32 s3, s39                                       // 00000005ECF0: BF042703
	v_cvt_f16_f32_e32 v14, v15                                 // 00000005ECF4: 7E1C150F
	.long 0x7f1e1502                                           // 00000005ECF8: 7F1E1502
	v_lshlrev_b32_e32 v2, 16, v3                               // 00000005ECFC: 30040690
	v_lshlrev_b32_e32 v3, 16, v4                               // 00000005ED00: 30060890
	v_lshlrev_b32_e32 v18, 16, v27                             // 00000005ED04: 30243690
	v_lshlrev_b32_e32 v19, 16, v30                             // 00000005ED08: 30263C90
	v_lshlrev_b32_e32 v4, 16, v7                               // 00000005ED0C: 30080E90
	v_cvt_f16_f32_e32 v2, v2                                   // 00000005ED10: 7E041502
	.long 0x7f041505                                           // 00000005ED14: 7F041505
	v_cvt_f16_f32_e32 v3, v3                                   // 00000005ED18: 7E061503
	s_cselect_b32 s64, -1, 0                                   // 00000005ED1C: 984080C1
	s_or_b32 s3, s54, 8                                        // 00000005ED20: 8C038836
	v_cvt_f16_f32_e32 v15, v16                                 // 00000005ED24: 7E1E1510
	s_cmp_lt_i32 s3, s39                                       // 00000005ED28: BF042703
	.long 0x7f201512                                           // 00000005ED2C: 7F201512
	s_cselect_b32 s65, -1, 0                                   // 00000005ED30: 984180C1
	s_or_b32 s3, s54, 9                                        // 00000005ED34: 8C038936
	v_cvt_f16_f32_e32 v16, v19                                 // 00000005ED38: 7E201513
	v_cndmask_b16 v18, 0, v2, s57                              // 00000005ED3C: D65D0012 00E60480
	v_cndmask_b16 v18, 0, v2, s58                              // 00000005ED44: D65D5012 00EA0480
	v_cvt_f16_f32_e32 v2, v6                                   // 00000005ED4C: 7E041506
	.long 0x7f041504                                           // 00000005ED50: 7F041504
	v_cndmask_b16 v19, 0, v3, s59                              // 00000005ED54: D65D0013 00EE0680
	v_lshlrev_b32_e32 v4, 16, v8                               // 00000005ED5C: 30081090
	v_cvt_f16_f32_e32 v3, v9                                   // 00000005ED60: 7E061509
	v_lshlrev_b32_e32 v6, 16, v21                              // 00000005ED64: 300C2A90
	s_cmp_lt_i32 s3, s39                                       // 00000005ED68: BF042703
	v_cndmask_b16 v19, 0, v2, s60                              // 00000005ED6C: D65D4013 00F20480
	s_cselect_b32 s66, -1, 0                                   // 00000005ED74: 984280C1
	s_or_b32 s3, s54, 10                                       // 00000005ED78: 8C038A36
	v_cndmask_b16 v20, 0, v2, s61                              // 00000005ED7C: D65D1014 00F60480
	v_cvt_f16_f32_e32 v2, v4                                   // 00000005ED84: 7E041504
	v_cndmask_b16 v20, 0, v3, s62                              // 00000005ED88: D65D4014 00FA0680
	.long 0x7f041511                                           // 00000005ED90: 7F041511
	v_lshlrev_b32_e32 v4, 16, v22                              // 00000005ED94: 30082C90
	v_cvt_f16_f32_e32 v3, v6                                   // 00000005ED98: 7E061506
	s_cmp_lt_i32 s3, s39                                       // 00000005ED9C: BF042703
	v_lshlrev_b32_e32 v70, 16, v29                             // 00000005EDA0: 308C3A90
	s_cselect_b32 s55, -1, 0                                   // 00000005EDA4: 983780C1
	s_or_b32 s3, s54, 11                                       // 00000005EDA8: 8C038B36
	v_cndmask_b16 v21, 0, v2, s64                              // 00000005EDAC: D65D5015 01020480
	s_cmp_lt_i32 s3, s39                                       // 00000005EDB4: BF042703
	.long 0x7f041504                                           // 00000005EDB8: 7F041504
	v_cndmask_b16 v22, 0, v3, s65                              // 00000005EDBC: D65D0016 01060680
	v_lshlrev_b32_e32 v3, 16, v25                              // 00000005EDC4: 30063290
	v_mul_u32_u24_e32 v4, 48, v50                              // 00000005EDC8: 160864B0
	s_cselect_b32 s3, -1, 0                                    // 00000005EDCC: 980380C1
	s_or_b32 s4, s54, 12                                       // 00000005EDD0: 8C048C36
	v_lshlrev_b32_e32 v5, 16, v28                              // 00000005EDD4: 300A3890
	s_cmp_lt_i32 s4, s39                                       // 00000005EDD8: BF042704
	v_cndmask_b16 v21, 0, v2, s63                              // 00000005EDDC: D65D0015 00FE0480
	v_cvt_f16_f32_e32 v2, v23                                  // 00000005EDE4: 7E041517
	v_cndmask_b16 v23, 0, v2, s55                              // 00000005EDE8: D65D1017 00DE0480
	.long 0x7f041503                                           // 00000005EDF0: 7F041503
	v_cvt_f16_f32_e32 v3, v33                                  // 00000005EDF4: 7E061521
	ds_load_b128 v[30:33], v4 offset:21520                     // 00000005EDF8: DBFC5410 1E000004
	ds_load_b128 v[26:29], v4 offset:21504                     // 00000005EE00: DBFC5400 1A000004
	ds_load_b128 v[38:41], v4 offset:19984                     // 00000005EE08: DBFC4E10 26000004
	ds_load_b128 v[34:37], v4 offset:19968                     // 00000005EE10: DBFC4E00 22000004
	s_cselect_b32 s4, -1, 0                                    // 00000005EE18: 980480C1
	s_or_b32 s29, s54, 13                                      // 00000005EE1C: 8C1D8D36
	v_and_b32_e32 v62, 0xffff0000, v42                         // 00000005EE20: 367C54FF FFFF0000
	s_cmp_lt_i32 s29, s39                                      // 00000005EE28: BF04271D
	v_lshlrev_b32_e32 v6, 16, v42                              // 00000005EE2C: 300C5490
	s_cselect_b32 s29, -1, 0                                   // 00000005EE30: 981D80C1
	s_or_b32 s56, s54, 14                                      // 00000005EE34: 8C388E36
	ds_load_b128 v[46:49], v4 offset:20752                     // 00000005EE38: DBFC5110 2E000004
	ds_load_b128 v[42:45], v4 offset:20736                     // 00000005EE40: DBFC5100 2A000004
	ds_load_b128 v[54:57], v4 offset:19200                     // 00000005EE48: DBFC4B00 36000004
	ds_load_b128 v[58:61], v4 offset:19216                     // 00000005EE50: DBFC4B10 3A000004
	s_cmp_lt_i32 s56, s39                                      // 00000005EE58: BF042738
	v_cndmask_b16 v22, 0, v2, s66                              // 00000005EE5C: D65D4016 010A0480
	s_cselect_b32 s56, -1, 0                                   // 00000005EE64: 983880C1
	s_or_b32 s67, s54, 15                                      // 00000005EE68: 8C438F36
	v_cvt_f16_f32_e32 v2, v24                                  // 00000005EE6C: 7E041518
	.long 0x7f061506                                           // 00000005EE70: 7F061506
	v_cvt_f16_f32_e32 v4, v62                                  // 00000005EE74: 7E08153E
	s_cmp_lt_i32 s67, s39                                      // 00000005EE78: BF042743
	v_mov_b32_e32 v69, s27                                     // 00000005EE7C: 7E8A021B
	s_cselect_b32 s67, -1, 0                                   // 00000005EE80: 984380C1
	v_cndmask_b16 v23, 0, v2, s3                               // 00000005EE84: D65D4017 000E0480
	v_cndmask_b16 v24, 0, v2, s4                               // 00000005EE8C: D65D1018 00120480
	v_cndmask_b16 v24, 0, v3, s29                              // 00000005EE94: D65D4018 00760680
	v_cndmask_b16 v25, 0, v3, s56                              // 00000005EE9C: D65D1019 00E20680
	v_cndmask_b16 v25, 0, v4, s67                              // 00000005EEA4: D65D4019 010E0880
	v_dual_mov_b32 v68, s26 :: v_dual_mov_b32 v67, s25         // 00000005EEAC: CA10001A 44420019
	v_dual_mov_b32 v66, s24 :: v_dual_mov_b32 v65, s23         // 00000005EEB4: CA100018 42400017
	v_dual_mov_b32 v64, s22 :: v_dual_mov_b32 v63, s21         // 00000005EEBC: CA100016 403E0015
	v_mov_b32_e32 v62, s20                                     // 00000005EEC4: 7E7C0214
	.long 0x7f221505                                           // 00000005EEC8: 7F221505
	v_cvt_f16_f32_e32 v17, v70                                 // 00000005EECC: 7E221546
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 00000005EED0: 916A267E
	s_waitcnt lgkmcnt(6)                                       // 00000005EED4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[2:9], v[26:33], v[18:25], v[62:69]// 00000005EED8: CC404002 1CFA251A
	s_waitcnt lgkmcnt(4)                                       // 00000005EEE0: BF89FC47
	v_wmma_f32_16x16x16_f16 v[26:33], v[34:41], v[10:17], v[62:69]// 00000005EEE4: CC40401A 1CFA1522
	s_waitcnt lgkmcnt(2)                                       // 00000005EEEC: BF89FC27
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 00000005EEF0: BF870152
	v_wmma_f32_16x16x16_f16 v[2:9], v[42:49], v[18:25], v[2:9] // 00000005EEF4: CC404002 1C0A252A
	s_waitcnt lgkmcnt(0)                                       // 00000005EEFC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[26:33], v[54:61], v[10:17], v[26:33]// 00000005EF00: CC40401A 1C6A1536
	v_mad_u32_u24 v14, 0x110, v160, v53                        // 00000005EF08: D60B000E 04D740FF 00000110
	v_cvt_f16_f32_e32 v10, v26                                 // 00000005EF14: 7E14151A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005EF18: BF870213
	.long 0x7f14151b                                           // 00000005EF1C: 7F14151B
	v_cvt_f16_f32_e32 v11, v28                                 // 00000005EF20: 7E16151C
	.long 0x7f16151d                                           // 00000005EF24: 7F16151D
	v_cvt_f16_f32_e32 v12, v30                                 // 00000005EF28: 7E18151E
	.long 0x7f18151f                                           // 00000005EF2C: 7F18151F
	v_cvt_f16_f32_e32 v13, v32                                 // 00000005EF30: 7E1A1520
	.long 0x7f1a1521                                           // 00000005EF34: 7F1A1521
	ds_store_b16 v14, v10 offset:14848                         // 00000005EF38: D87C3A00 00000A0E
	ds_store_b16_d16_hi v14, v10 offset:15392                  // 00000005EF40: DA843C20 00000A0E
	ds_store_b16 v14, v11 offset:15936                         // 00000005EF48: D87C3E40 00000B0E
	ds_store_b16_d16_hi v14, v11 offset:16480                  // 00000005EF50: DA844060 00000B0E
	ds_store_b16 v14, v12 offset:17024                         // 00000005EF58: D87C4280 00000C0E
	ds_store_b16_d16_hi v14, v12 offset:17568                  // 00000005EF60: DA8444A0 00000C0E
	ds_store_b16 v14, v13 offset:18112                         // 00000005EF68: D87C46C0 00000D0E
	ds_store_b16_d16_hi v14, v13 offset:18656                  // 00000005EF70: DA8448E0 00000D0E
	s_waitcnt lgkmcnt(0)                                       // 00000005EF78: BF89FC07
	s_barrier                                                  // 00000005EF7C: BFBD0000
	s_cbranch_vccnz 1                                          // 00000005EF80: BFA40001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3188>
	s_sendmsg_rtn_b64 s[28:29], sendmsg(MSG_RTN_GET_REALTIME)  // 00000005EF84: BE9C4D83
	v_fma_mixlo_f16 v10, v139, s51, 0                          // 00000005EF88: CC21000A 0200678B
	v_fma_mixhi_f16 v10, v138, s51, 0                          // 00000005EF90: CC22000A 0200678A
	v_cmp_eq_u32_e32 vcc_lo, 0, v160                           // 00000005EF98: 7C954080
	v_mov_b32_e32 v12, 0x3020706                               // 00000005EF9C: 7E1802FF 03020706
	ds_load_b128 v[46:49], v52 offset:14864                    // 00000005EFA4: DBFC3A10 2E000034
	ds_load_b128 v[42:45], v52 offset:14848                    // 00000005EFAC: DBFC3A00 2A000034
	ds_load_b128 v[60:63], v52 offset:14896                    // 00000005EFB4: DBFC3A30 3C000034
	ds_load_b128 v[56:59], v52 offset:14880                    // 00000005EFBC: DBFC3A20 38000034
	v_dual_mov_b32 v11, v10 :: v_dual_cndmask_b32 v54, 0x5040100, v72// 00000005EFC4: CA12010A 0B3690FF 05040100
	v_cndmask_b32_e32 v55, 0x7060302, v12, vcc_lo              // 00000005EFD0: 026E18FF 07060302
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005EFD8: BF870092
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000005EFDC: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v26, v10, v11, v54                              // 00000005EFE8: D644001A 04DA170A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000005EFF0: BF8700B3
	v_perm_b32 v27, v10, v11, v55                              // 00000005EFF4: D644001B 04DE170A
	v_fma_mixlo_f16 v10, v137, s51, 0                          // 00000005EFFC: CC21000A 02006789
	v_fma_mixhi_f16 v10, v136, s51, 0                          // 00000005F004: CC22000A 02006788
	v_mov_b32_e32 v11, v10                                     // 00000005F00C: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F010: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000005F014: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v28, v10, v11, v54                              // 00000005F020: D644001C 04DA170A
	v_perm_b32 v29, v10, v11, v55                              // 00000005F028: D644001D 04DE170A
	v_fma_mixlo_f16 v10, v135, s51, 0                          // 00000005F030: CC21000A 02006787
	v_fma_mixhi_f16 v10, v134, s51, 0                          // 00000005F038: CC22000A 02006786
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F040: BF870091
	v_mov_b32_e32 v11, v10                                     // 00000005F044: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000005F048: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000005F054: BF8700C1
	v_perm_b32 v30, v10, v11, v54                              // 00000005F058: D644001E 04DA170A
	v_perm_b32 v31, v10, v11, v55                              // 00000005F060: D644001F 04DE170A
	v_fma_mixlo_f16 v10, v133, s51, 0                          // 00000005F068: CC21000A 02006785
	v_fma_mixhi_f16 v10, v158, s51, 0                          // 00000005F070: CC22000A 0200679E
	v_mov_b32_e32 v11, v10                                     // 00000005F078: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F07C: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000005F080: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v32, v10, v11, v54                              // 00000005F08C: D6440020 04DA170A
	v_perm_b32 v33, v10, v11, v55                              // 00000005F094: D6440021 04DE170A
	v_fma_mixlo_f16 v10, v132, s51, 0                          // 00000005F09C: CC21000A 02006784
	v_fma_mixhi_f16 v10, v131, s51, 0                          // 00000005F0A4: CC22000A 02006783
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F0AC: BF870091
	v_mov_b32_e32 v11, v10                                     // 00000005F0B0: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000005F0B4: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000005F0C0: BF8700C1
	v_perm_b32 v34, v10, v11, v54                              // 00000005F0C4: D6440022 04DA170A
	v_perm_b32 v35, v10, v11, v55                              // 00000005F0CC: D6440023 04DE170A
	v_fma_mixlo_f16 v10, v130, s51, 0                          // 00000005F0D4: CC21000A 02006782
	v_fma_mixhi_f16 v10, v129, s51, 0                          // 00000005F0DC: CC22000A 02006781
	v_mov_b32_e32 v11, v10                                     // 00000005F0E4: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F0E8: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000005F0EC: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v36, v10, v11, v54                              // 00000005F0F8: D6440024 04DA170A
	v_perm_b32 v37, v10, v11, v55                              // 00000005F100: D6440025 04DE170A
	v_fma_mixlo_f16 v10, v128, s51, 0                          // 00000005F108: CC21000A 02006780
	v_fma_mixhi_f16 v10, v127, s51, 0                          // 00000005F110: CC22000A 0200677F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F118: BF870091
	v_mov_b32_e32 v11, v10                                     // 00000005F11C: 7E16030A
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000005F120: D65C000B 03FC690B FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000005F12C: BF8700C1
	v_perm_b32 v38, v10, v11, v54                              // 00000005F130: D6440026 04DA170A
	v_perm_b32 v39, v10, v11, v55                              // 00000005F138: D6440027 04DE170A
	v_fma_mixlo_f16 v10, v126, s51, 0                          // 00000005F140: CC21000A 0200677E
	v_fma_mixhi_f16 v10, v157, s51, 0                          // 00000005F148: CC22000A 0200679D
	v_mov_b32_e32 v11, v10                                     // 00000005F150: 7E16030A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F154: BF870091
	v_permlanex16_b32 v11, v11, s52, 0xfedcba98                // 00000005F158: D65C000B 03FC690B FEDCBA98
	v_perm_b32 v40, v10, v11, v54                              // 00000005F164: D6440028 04DA170A
	v_perm_b32 v41, v10, v11, v55                              // 00000005F16C: D6440029 04DE170A
	v_dual_mov_b32 v10, s20 :: v_dual_mov_b32 v11, s21         // 00000005F174: CA100014 0A0A0015
	v_dual_mov_b32 v12, s22 :: v_dual_mov_b32 v13, s23         // 00000005F17C: CA100016 0C0C0017
	v_dual_mov_b32 v14, s24 :: v_dual_mov_b32 v15, s25         // 00000005F184: CA100018 0E0E0019
	v_dual_mov_b32 v16, s26 :: v_dual_mov_b32 v17, s27         // 00000005F18C: CA10001A 1010001B
	s_waitcnt lgkmcnt(0)                                       // 00000005F194: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F198: BF870091
	v_wmma_f32_16x16x16_f16 v[18:25], v[42:49], v[26:33], v[10:17]// 00000005F19C: CC404012 1C2A352A
	v_wmma_f32_16x16x16_f16 v[18:25], v[56:63], v[34:41], v[18:25]// 00000005F1A4: CC404012 1C4A4538
	ds_load_b128 v[56:59], v52 offset:10496                    // 00000005F1AC: DBFC2900 38000034
	ds_load_b128 v[60:63], v52 offset:10512                    // 00000005F1B4: DBFC2910 3C000034
	s_waitcnt lgkmcnt(0)                                       // 00000005F1BC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[56:63], v[26:33], v[10:17]// 00000005F1C0: CC40402A 1C2A3538
	ds_load_b128 v[26:29], v52 offset:10528                    // 00000005F1C8: DBFC2920 1A000034
	ds_load_b128 v[30:33], v52 offset:10544                    // 00000005F1D0: DBFC2930 1E000034
	s_waitcnt lgkmcnt(0)                                       // 00000005F1D8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[26:33], v[34:41], v[42:49]// 00000005F1DC: CC40402A 1CAA451A
	v_fma_mixlo_f16 v27, v125, s51, 0                          // 00000005F1E4: CC21001B 0200677D
	v_fma_mixhi_f16 v27, v124, s51, 0                          // 00000005F1EC: CC22001B 0200677C
	v_fma_mixlo_f16 v29, v123, s51, 0                          // 00000005F1F4: CC21001D 0200677B
	v_fma_mixhi_f16 v29, v122, s51, 0                          // 00000005F1FC: CC22001D 0200677A
	v_fma_mixlo_f16 v31, v121, s51, 0                          // 00000005F204: CC21001F 02006779
	v_fma_mixhi_f16 v31, v120, s51, 0                          // 00000005F20C: CC22001F 02006778
	v_fma_mixlo_f16 v33, v119, s51, 0                          // 00000005F214: CC210021 02006777
	v_fma_mixhi_f16 v33, v156, s51, 0                          // 00000005F21C: CC220021 0200679C
	v_mov_b32_e32 v28, v27                                     // 00000005F224: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000005F228: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000005F22C: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F230: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000005F234: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000005F238: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F244: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000005F248: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000005F254: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F260: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000005F264: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v54                              // 00000005F270: D644001A 04DA391B
	v_perm_b32 v27, v27, v28, v55                              // 00000005F278: D644001B 04DE391B
	v_perm_b32 v28, v29, v30, v54                              // 00000005F280: D644001C 04DA3D1D
	v_perm_b32 v29, v29, v30, v55                              // 00000005F288: D644001D 04DE3D1D
	v_perm_b32 v30, v31, v32, v54                              // 00000005F290: D644001E 04DA411F
	v_perm_b32 v31, v31, v32, v55                              // 00000005F298: D644001F 04DE411F
	v_perm_b32 v32, v33, v34, v54                              // 00000005F2A0: D6440020 04DA4521
	v_perm_b32 v33, v33, v34, v55                              // 00000005F2A8: D6440021 04DE4521
	ds_load_b128 v[38:41], v52 offset:14928                    // 00000005F2B0: DBFC3A50 26000034
	ds_load_b128 v[34:37], v52 offset:14912                    // 00000005F2B8: DBFC3A40 22000034
	s_waitcnt lgkmcnt(0)                                       // 00000005F2C0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000005F2C4: CC404012 1C4A3522
	ds_load_b128 v[38:41], v52 offset:10576                    // 00000005F2CC: DBFC2950 26000034
	ds_load_b128 v[34:37], v52 offset:10560                    // 00000005F2D4: DBFC2940 22000034
	s_waitcnt lgkmcnt(0)                                       // 00000005F2DC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000005F2E0: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v118, s51, 0                          // 00000005F2E8: CC21001B 02006776
	v_fma_mixhi_f16 v27, v117, s51, 0                          // 00000005F2F0: CC22001B 02006775
	v_fma_mixlo_f16 v29, v116, s51, 0                          // 00000005F2F8: CC21001D 02006774
	v_fma_mixhi_f16 v29, v115, s51, 0                          // 00000005F300: CC22001D 02006773
	v_fma_mixlo_f16 v31, v114, s51, 0                          // 00000005F308: CC21001F 02006772
	v_fma_mixhi_f16 v31, v113, s51, 0                          // 00000005F310: CC22001F 02006771
	v_fma_mixlo_f16 v33, v112, s51, 0                          // 00000005F318: CC210021 02006770
	v_fma_mixhi_f16 v33, v155, s51, 0                          // 00000005F320: CC220021 0200679B
	v_mov_b32_e32 v28, v27                                     // 00000005F328: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000005F32C: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000005F330: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F334: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000005F338: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000005F33C: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F348: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000005F34C: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000005F358: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F364: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000005F368: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v54                              // 00000005F374: D644001A 04DA391B
	v_perm_b32 v27, v27, v28, v55                              // 00000005F37C: D644001B 04DE391B
	v_perm_b32 v28, v29, v30, v54                              // 00000005F384: D644001C 04DA3D1D
	v_perm_b32 v29, v29, v30, v55                              // 00000005F38C: D644001D 04DE3D1D
	v_perm_b32 v30, v31, v32, v54                              // 00000005F394: D644001E 04DA411F
	v_perm_b32 v31, v31, v32, v55                              // 00000005F39C: D644001F 04DE411F
	v_perm_b32 v32, v33, v34, v54                              // 00000005F3A4: D6440020 04DA4521
	v_perm_b32 v33, v33, v34, v55                              // 00000005F3AC: D6440021 04DE4521
	ds_load_b128 v[38:41], v52 offset:14960                    // 00000005F3B4: DBFC3A70 26000034
	ds_load_b128 v[34:37], v52 offset:14944                    // 00000005F3BC: DBFC3A60 22000034
	s_waitcnt lgkmcnt(0)                                       // 00000005F3C4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000005F3C8: CC404012 1C4A3522
	ds_load_b128 v[38:41], v52 offset:10608                    // 00000005F3D0: DBFC2970 26000034
	ds_load_b128 v[34:37], v52 offset:10592                    // 00000005F3D8: DBFC2960 22000034
	s_waitcnt lgkmcnt(0)                                       // 00000005F3E0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000005F3E4: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v111, s51, 0                          // 00000005F3EC: CC21001B 0200676F
	v_fma_mixhi_f16 v27, v110, s51, 0                          // 00000005F3F4: CC22001B 0200676E
	v_fma_mixlo_f16 v29, v109, s51, 0                          // 00000005F3FC: CC21001D 0200676D
	v_fma_mixhi_f16 v29, v108, s51, 0                          // 00000005F404: CC22001D 0200676C
	v_fma_mixlo_f16 v31, v107, s51, 0                          // 00000005F40C: CC21001F 0200676B
	v_fma_mixhi_f16 v31, v106, s51, 0                          // 00000005F414: CC22001F 0200676A
	v_fma_mixlo_f16 v33, v105, s51, 0                          // 00000005F41C: CC210021 02006769
	v_fma_mixhi_f16 v33, v154, s51, 0                          // 00000005F424: CC220021 0200679A
	v_mov_b32_e32 v28, v27                                     // 00000005F42C: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000005F430: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000005F434: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F438: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000005F43C: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000005F440: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F44C: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000005F450: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000005F45C: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F468: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000005F46C: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v54                              // 00000005F478: D644001A 04DA391B
	v_perm_b32 v27, v27, v28, v55                              // 00000005F480: D644001B 04DE391B
	v_perm_b32 v28, v29, v30, v54                              // 00000005F488: D644001C 04DA3D1D
	v_perm_b32 v29, v29, v30, v55                              // 00000005F490: D644001D 04DE3D1D
	v_perm_b32 v30, v31, v32, v54                              // 00000005F498: D644001E 04DA411F
	v_perm_b32 v31, v31, v32, v55                              // 00000005F4A0: D644001F 04DE411F
	v_perm_b32 v32, v33, v34, v54                              // 00000005F4A8: D6440020 04DA4521
	v_perm_b32 v33, v33, v34, v55                              // 00000005F4B0: D6440021 04DE4521
	ds_load_b128 v[38:41], v52 offset:14992                    // 00000005F4B8: DBFC3A90 26000034
	ds_load_b128 v[34:37], v52 offset:14976                    // 00000005F4C0: DBFC3A80 22000034
	s_waitcnt lgkmcnt(0)                                       // 00000005F4C8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000005F4CC: CC404012 1C4A3522
	ds_load_b128 v[38:41], v52 offset:10640                    // 00000005F4D4: DBFC2990 26000034
	ds_load_b128 v[34:37], v52 offset:10624                    // 00000005F4DC: DBFC2980 22000034
	s_waitcnt lgkmcnt(0)                                       // 00000005F4E4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000005F4E8: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v104, s51, 0                          // 00000005F4F0: CC21001B 02006768
	v_fma_mixhi_f16 v27, v103, s51, 0                          // 00000005F4F8: CC22001B 02006767
	v_fma_mixlo_f16 v29, v102, s51, 0                          // 00000005F500: CC21001D 02006766
	v_fma_mixhi_f16 v29, v101, s51, 0                          // 00000005F508: CC22001D 02006765
	v_fma_mixlo_f16 v31, v100, s51, 0                          // 00000005F510: CC21001F 02006764
	v_fma_mixhi_f16 v31, v99, s51, 0                           // 00000005F518: CC22001F 02006763
	v_fma_mixlo_f16 v33, v98, s51, 0                           // 00000005F520: CC210021 02006762
	v_fma_mixhi_f16 v33, v153, s51, 0                          // 00000005F528: CC220021 02006799
	v_mov_b32_e32 v28, v27                                     // 00000005F530: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000005F534: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000005F538: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F53C: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000005F540: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000005F544: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F550: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000005F554: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000005F560: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F56C: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000005F570: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v54                              // 00000005F57C: D644001A 04DA391B
	v_perm_b32 v27, v27, v28, v55                              // 00000005F584: D644001B 04DE391B
	v_perm_b32 v28, v29, v30, v54                              // 00000005F58C: D644001C 04DA3D1D
	v_perm_b32 v29, v29, v30, v55                              // 00000005F594: D644001D 04DE3D1D
	v_perm_b32 v30, v31, v32, v54                              // 00000005F59C: D644001E 04DA411F
	v_perm_b32 v31, v31, v32, v55                              // 00000005F5A4: D644001F 04DE411F
	v_perm_b32 v32, v33, v34, v54                              // 00000005F5AC: D6440020 04DA4521
	v_perm_b32 v33, v33, v34, v55                              // 00000005F5B4: D6440021 04DE4521
	ds_load_b128 v[38:41], v52 offset:15024                    // 00000005F5BC: DBFC3AB0 26000034
	ds_load_b128 v[34:37], v52 offset:15008                    // 00000005F5C4: DBFC3AA0 22000034
	s_waitcnt lgkmcnt(0)                                       // 00000005F5CC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000005F5D0: CC404012 1C4A3522
	ds_load_b128 v[38:41], v52 offset:10672                    // 00000005F5D8: DBFC29B0 26000034
	ds_load_b128 v[34:37], v52 offset:10656                    // 00000005F5E0: DBFC29A0 22000034
	s_waitcnt lgkmcnt(0)                                       // 00000005F5E8: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000005F5EC: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v143, s51, 0                          // 00000005F5F4: CC21001B 0200678F
	v_fma_mixhi_f16 v27, v149, s51, 0                          // 00000005F5FC: CC22001B 02006795
	v_fma_mixlo_f16 v29, v148, s51, 0                          // 00000005F604: CC21001D 02006794
	v_fma_mixhi_f16 v29, v147, s51, 0                          // 00000005F60C: CC22001D 02006793
	v_fma_mixlo_f16 v31, v146, s51, 0                          // 00000005F614: CC21001F 02006792
	v_fma_mixhi_f16 v31, v145, s51, 0                          // 00000005F61C: CC22001F 02006791
	v_fma_mixlo_f16 v33, v141, s51, 0                          // 00000005F624: CC210021 0200678D
	v_fma_mixhi_f16 v33, v152, s51, 0                          // 00000005F62C: CC220021 02006798
	v_mov_b32_e32 v28, v27                                     // 00000005F634: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000005F638: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000005F63C: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F640: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000005F644: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000005F648: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F654: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000005F658: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000005F664: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F670: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000005F674: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v54                              // 00000005F680: D644001A 04DA391B
	v_perm_b32 v27, v27, v28, v55                              // 00000005F688: D644001B 04DE391B
	v_perm_b32 v28, v29, v30, v54                              // 00000005F690: D644001C 04DA3D1D
	v_perm_b32 v29, v29, v30, v55                              // 00000005F698: D644001D 04DE3D1D
	v_perm_b32 v30, v31, v32, v54                              // 00000005F6A0: D644001E 04DA411F
	v_perm_b32 v31, v31, v32, v55                              // 00000005F6A8: D644001F 04DE411F
	v_perm_b32 v32, v33, v34, v54                              // 00000005F6B0: D6440020 04DA4521
	v_perm_b32 v33, v33, v34, v55                              // 00000005F6B8: D6440021 04DE4521
	ds_load_b128 v[38:41], v52 offset:15056                    // 00000005F6C0: DBFC3AD0 26000034
	ds_load_b128 v[34:37], v52 offset:15040                    // 00000005F6C8: DBFC3AC0 22000034
	s_waitcnt lgkmcnt(0)                                       // 00000005F6D0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000005F6D4: CC404012 1C4A3522
	ds_load_b128 v[38:41], v52 offset:10704                    // 00000005F6DC: DBFC29D0 26000034
	ds_load_b128 v[34:37], v52 offset:10688                    // 00000005F6E4: DBFC29C0 22000034
	s_waitcnt lgkmcnt(0)                                       // 00000005F6EC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000005F6F0: CC40402A 1CAA3522
	v_fma_mixlo_f16 v27, v150, s51, 0                          // 00000005F6F8: CC21001B 02006796
	v_fma_mixhi_f16 v27, v142, s51, 0                          // 00000005F700: CC22001B 0200678E
	v_fma_mixlo_f16 v29, v191, s51, 0                          // 00000005F708: CC21001D 020067BF
	v_fma_mixhi_f16 v29, v190, s51, 0                          // 00000005F710: CC22001D 020067BE
	v_fma_mixlo_f16 v31, v189, s51, 0                          // 00000005F718: CC21001F 020067BD
	v_fma_mixhi_f16 v31, v187, s51, 0                          // 00000005F720: CC22001F 020067BB
	v_fma_mixlo_f16 v33, v188, s51, 0                          // 00000005F728: CC210021 020067BC
	v_fma_mixhi_f16 v33, v151, s51, 0                          // 00000005F730: CC220021 02006797
	v_mov_b32_e32 v28, v27                                     // 00000005F738: 7E38031B
	v_mov_b32_e32 v30, v29                                     // 00000005F73C: 7E3C031D
	v_mov_b32_e32 v32, v31                                     // 00000005F740: 7E40031F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F744: BF870214
	v_mov_b32_e32 v34, v33                                     // 00000005F748: 7E440321
	v_permlanex16_b32 v28, v28, s52, 0xfedcba98                // 00000005F74C: D65C001C 03FC691C FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F758: BF870214
	v_permlanex16_b32 v30, v30, s52, 0xfedcba98                // 00000005F75C: D65C001E 03FC691E FEDCBA98
	v_permlanex16_b32 v32, v32, s52, 0xfedcba98                // 00000005F768: D65C0020 03FC6920 FEDCBA98
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000005F774: BF870214
	v_permlanex16_b32 v34, v34, s52, 0xfedcba98                // 00000005F778: D65C0022 03FC6922 FEDCBA98
	v_perm_b32 v26, v27, v28, v54                              // 00000005F784: D644001A 04DA391B
	v_perm_b32 v27, v27, v28, v55                              // 00000005F78C: D644001B 04DE391B
	v_perm_b32 v28, v29, v30, v54                              // 00000005F794: D644001C 04DA3D1D
	v_perm_b32 v29, v29, v30, v55                              // 00000005F79C: D644001D 04DE3D1D
	v_perm_b32 v30, v31, v32, v54                              // 00000005F7A4: D644001E 04DA411F
	v_perm_b32 v31, v31, v32, v55                              // 00000005F7AC: D644001F 04DE411F
	v_perm_b32 v32, v33, v34, v54                              // 00000005F7B4: D6440020 04DA4521
	v_perm_b32 v33, v33, v34, v55                              // 00000005F7BC: D6440021 04DE4521
	ds_load_b128 v[38:41], v52 offset:15088                    // 00000005F7C4: DBFC3AF0 26000034
	ds_load_b128 v[34:37], v52 offset:15072                    // 00000005F7CC: DBFC3AE0 22000034
	s_waitcnt lgkmcnt(0)                                       // 00000005F7D4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[18:25], v[34:41], v[26:33], v[18:25]// 00000005F7D8: CC404012 1C4A3522
	ds_load_b128 v[38:41], v52 offset:10736                    // 00000005F7E0: DBFC29F0 26000034
	ds_load_b128 v[34:37], v52 offset:10720                    // 00000005F7E8: DBFC29E0 22000034
	v_dual_mul_f32 v19, 0x3b800000, v19 :: v_dual_mul_f32 v18, 0x3b800000, v18// 00000005F7F0: C8C626FF 131224FF 3B800000
	v_dual_mul_f32 v20, 0x3b800000, v20 :: v_dual_mul_f32 v21, 0x3b800000, v21// 00000005F7FC: C8C628FF 14142AFF 3B800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005F808: BF870222
	v_dual_mul_f32 v22, 0x3b800000, v22 :: v_dual_sub_f32 v3, v3, v19// 00000005F80C: C8CA2CFF 16022703 3B800000
	v_or_b32_e32 v19, s54, v160                                // 00000005F818: 38274036
	v_sub_f32_e32 v2, v2, v18                                  // 00000005F81C: 08042502
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000005F820: BF870224
	v_dual_sub_f32 v4, v4, v20 :: v_dual_sub_f32 v5, v5, v21   // 00000005F824: C94A2904 04042B05
	v_mul_f32_e32 v23, 0x3b800000, v23                         // 00000005F82C: 102E2EFF 3B800000
	v_or_b32_e32 v18, 2, v19                                   // 00000005F834: 38242682
	.long 0xd4440003                                           // 00000005F838: D4440003
	v_cndmask_b32_e32 v1, s39, v19, vcc_lo                     // 00000005F83C: 02022627
	v_fma_mixlo_f16 v2, v2, s48, 0                             // 00000005F840: CC210002 02006102
	v_fma_mixhi_f16 v2, v3, s48, 0                             // 00000005F848: CC220002 02006103
	v_sub_f32_e32 v6, v6, v22                                  // 00000005F850: 080C2D06
	v_cmp_gt_i32_e32 vcc_lo, s39, v18                          // 00000005F854: 7C882427
	v_sub_f32_e32 v7, v7, v23                                  // 00000005F858: 080E2F07
	v_cndmask_b16 v2, 0, v2, s3                                // 00000005F85C: D65D0002 000E0480
	v_dual_mul_f32 v24, 0x3b800000, v24 :: v_dual_mul_f32 v25, 0x3b800000, v25// 00000005F864: C8C630FF 181832FF 3B800000
	v_cndmask_b16 v2, 0, v2, vcc_lo                            // 00000005F870: D65D5002 01AA0480
	v_mad_u32_u24 v18, v50, 48, 0x4b00                         // 00000005F878: D60B0012 03FD6132 00004B00
	s_waitcnt lgkmcnt(0)                                       // 00000005F884: BF89FC07
	v_wmma_f32_16x16x16_f16 v[42:49], v[34:41], v[26:33], v[42:49]// 00000005F888: CC40402A 1CAA3522
	v_dual_sub_f32 v8, v8, v24 :: v_dual_sub_f32 v9, v9, v25   // 00000005F890: C94A3108 08083309
	v_mov_b32_e32 v3, v2                                       // 00000005F898: 7E060302
	ds_load_b128 v[20:23], v18 offset:4096                     // 00000005F89C: DBFC1000 14000012
	ds_load_b128 v[24:27], v18 offset:4112                     // 00000005F8A4: DBFC1010 18000012
	v_permlanex16_b32 v3, v3, s52, 0xfedcba98                  // 00000005F8AC: D65C0003 03FC6903 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000005F8B8: BF8700B1
	v_perm_b32 v66, v2, v3, v54                                // 00000005F8BC: D6440042 04DA0702
	v_perm_b32 v67, v2, v3, v55                                // 00000005F8C4: D6440043 04DE0702
	v_or_b32_e32 v2, 4, v19                                    // 00000005F8CC: 38042684
	v_cmp_gt_i32_e32 vcc_lo, s39, v2                           // 00000005F8D0: 7C880427
	v_or_b32_e32 v2, 6, v19                                    // 00000005F8D4: 38042686
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000005F8D8: BF870131
	.long 0xd4440004                                           // 00000005F8DC: D4440004
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005F8E0: 02020427
	v_fma_mixlo_f16 v2, v4, s48, 0                             // 00000005F8E4: CC210002 02006104
	v_fma_mixhi_f16 v2, v5, s48, 0                             // 00000005F8EC: CC220002 02006105
	v_cndmask_b16 v2, 0, v2, vcc_lo                            // 00000005F8F4: D65D0002 01AA0480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F8FC: BF870092
	v_cndmask_b16 v2, 0, v2, s4                                // 00000005F900: D65D5002 00120480
	v_mov_b32_e32 v3, v2                                       // 00000005F908: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F90C: BF870091
	v_permlanex16_b32 v3, v3, s52, 0xfedcba98                  // 00000005F910: D65C0003 03FC6903 FEDCBA98
	v_perm_b32 v68, v2, v3, v54                                // 00000005F91C: D6440044 04DA0702
	v_perm_b32 v69, v2, v3, v55                                // 00000005F924: D6440045 04DE0702
	v_or_b32_e32 v2, 8, v19                                    // 00000005F92C: 38042688
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005F930: BF8700A1
	v_cmp_gt_i32_e32 vcc_lo, s39, v2                           // 00000005F934: 7C880427
	v_or_b32_e32 v2, 10, v19                                   // 00000005F938: 3804268A
	.long 0xd4440004                                           // 00000005F93C: D4440004
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005F940: 02020427
	v_fma_mixlo_f16 v2, v6, s48, 0                             // 00000005F944: CC210002 02006106
	v_fma_mixhi_f16 v2, v7, s48, 0                             // 00000005F94C: CC220002 02006107
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000005F954: BF870112
	v_cndmask_b16 v2, 0, v2, vcc_lo                            // 00000005F958: D65D0002 01AA0480
	v_cndmask_b16 v2, 0, v2, s4                                // 00000005F960: D65D5002 00120480
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F968: BF870091
	v_mov_b32_e32 v3, v2                                       // 00000005F96C: 7E060302
	v_permlanex16_b32 v3, v3, s52, 0xfedcba98                  // 00000005F970: D65C0003 03FC6903 FEDCBA98
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000005F97C: BF8700B1
	v_perm_b32 v70, v2, v3, v54                                // 00000005F980: D6440046 04DA0702
	v_perm_b32 v71, v2, v3, v55                                // 00000005F988: D6440047 04DE0702
	v_or_b32_e32 v2, 12, v19                                   // 00000005F990: 3804268C
	v_cmp_gt_i32_e32 vcc_lo, s39, v2                           // 00000005F994: 7C880427
	v_or_b32_e32 v2, 14, v19                                   // 00000005F998: 3804268E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000005F99C: BF870131
	.long 0xd4440004                                           // 00000005F9A0: D4440004
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005F9A4: 02020427
	v_fma_mixlo_f16 v2, v8, s48, 0                             // 00000005F9A8: CC210002 02006108
	v_fma_mixhi_f16 v2, v9, s48, 0                             // 00000005F9B0: CC220002 02006109
	v_cndmask_b16 v2, 0, v2, vcc_lo                            // 00000005F9B8: D65D0002 01AA0480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F9C0: BF870092
	v_cndmask_b16 v2, 0, v2, s4                                // 00000005F9C4: D65D5002 00120480
	v_mov_b32_e32 v3, v2                                       // 00000005F9CC: 7E060302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005F9D0: BF870091
	v_permlanex16_b32 v3, v3, s52, 0xfedcba98                  // 00000005F9D4: D65C0003 03FC6903 FEDCBA98
	v_perm_b32 v72, v2, v3, v54                                // 00000005F9E0: D6440048 04DA0702
	v_perm_b32 v73, v2, v3, v55                                // 00000005F9E8: D6440049 04DE0702
	s_waitcnt lgkmcnt(0)                                       // 00000005F9F0: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000005F9F4: BF8700A1
	v_wmma_f32_16x16x16_f16 v[2:9], v[20:27], v[66:73], v[10:17]// 00000005F9F8: CC404002 1C2A8514
	.long 0xd700040a                                           // 00000005FA00: D700040A
	v_cndmask_b32_e32 v1, s44, v53, vcc_lo                     // 00000005FA04: 02026A2C
	v_add_co_ci_u32_e64 v11, null, s45, 0, s4                  // 00000005FA08: D5207C0B 0011002D
	s_and_saveexec_b32 s4, s3                                  // 00000005FA10: BE842003
	s_cbranch_execz 19                                         // 00000005FA14: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3c64>
	ds_load_b32 v12, v51 offset:24320                          // 00000005FA18: D8D85F00 0C000033
	s_waitcnt lgkmcnt(0)                                       // 00000005FA20: BF89FC07
	v_mul_f32_e32 v12, v42, v12                                // 00000005FA24: 1018192A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000005FA28: BF870121
	v_add_f32_e32 v2, v2, v12                                  // 00000005FA2C: 06041902
	v_mad_u64_u32 v[12:13], null, 0x3000, v19, v[10:11]        // 00000005FA30: D6FE7C0C 042A26FF 00003000
	v_mul_f32_e32 v2, 0x3b800000, v2                           // 00000005FA3C: 100404FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FA44: BF870091
	v_bfe_u32 v14, v2, 16, 1                                   // 00000005FA48: D610000E 02052102
	v_add3_u32 v2, v2, v14, 0x7fff                             // 00000005FA50: D6550002 03FE1D02 00007FFF
	global_store_d16_hi_b16 v[12:13], v2, off                  // 00000005FA5C: DC960000 007C020C
	s_or_b32 exec_lo, exec_lo, s4                              // 00000005FA64: 8C7E047E
	v_or3_b32 v2, v160, s54, 2                                 // 00000005FA68: D6580002 02086DA0
	s_mov_b32 s3, exec_lo                                      // 00000005FA70: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005FA74: BF870001
	.long 0xd4c4007e                                           // 00000005FA78: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005FA7C: 02020427
	s_cbranch_execz 19                                         // 00000005FA80: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3cd0>
	ds_load_b32 v12, v51 offset:24328                          // 00000005FA84: D8D85F08 0C000033
	s_waitcnt lgkmcnt(0)                                       // 00000005FA8C: BF89FC07
	v_mul_f32_e32 v12, v43, v12                                // 00000005FA90: 1018192B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FA94: BF870091
	v_add_f32_e32 v3, v3, v12                                  // 00000005FA98: 06061903
	v_mul_f32_e32 v12, 0x3b800000, v3                          // 00000005FA9C: 101806FF 3B800000
	v_mad_u64_u32 v[2:3], null, 0x3000, v2, v[10:11]           // 00000005FAA4: D6FE7C02 042A04FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FAB0: BF870092
	v_bfe_u32 v13, v12, 16, 1                                  // 00000005FAB4: D610000D 0205210C
	v_add3_u32 v12, v12, v13, 0x7fff                           // 00000005FABC: D655000C 03FE1B0C 00007FFF
	global_store_d16_hi_b16 v[2:3], v12, off                   // 00000005FAC8: DC960000 007C0C02
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005FAD0: 8C7E037E
	v_or3_b32 v2, v160, s54, 4                                 // 00000005FAD4: D6580002 02106DA0
	s_mov_b32 s3, exec_lo                                      // 00000005FADC: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005FAE0: BF870001
	.long 0xd4c4007e                                           // 00000005FAE4: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005FAE8: 02020427
	s_cbranch_execz 19                                         // 00000005FAEC: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3d3c>
	ds_load_b32 v3, v51 offset:24336                           // 00000005FAF0: D8D85F10 03000033
	s_waitcnt lgkmcnt(0)                                       // 00000005FAF8: BF89FC07
	v_mul_f32_e32 v3, v44, v3                                  // 00000005FAFC: 1006072C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FB00: BF870091
	v_add_f32_e32 v3, v4, v3                                   // 00000005FB04: 06060704
	v_mul_f32_e32 v4, 0x3b800000, v3                           // 00000005FB08: 100806FF 3B800000
	v_mad_u64_u32 v[2:3], null, 0x3000, v2, v[10:11]           // 00000005FB10: D6FE7C02 042A04FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FB1C: BF870092
	v_bfe_u32 v12, v4, 16, 1                                   // 00000005FB20: D610000C 02052104
	v_add3_u32 v4, v4, v12, 0x7fff                             // 00000005FB28: D6550004 03FE1904 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000005FB34: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005FB3C: 8C7E037E
	v_or3_b32 v2, v160, s54, 6                                 // 00000005FB40: D6580002 02186DA0
	s_mov_b32 s3, exec_lo                                      // 00000005FB48: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005FB4C: BF870001
	.long 0xd4c4007e                                           // 00000005FB50: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005FB54: 02020427
	s_cbranch_execz 19                                         // 00000005FB58: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3da8>
	ds_load_b32 v3, v51 offset:24344                           // 00000005FB5C: D8D85F18 03000033
	s_waitcnt lgkmcnt(0)                                       // 00000005FB64: BF89FC07
	v_mul_f32_e32 v3, v45, v3                                  // 00000005FB68: 1006072D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FB6C: BF870091
	v_add_f32_e32 v3, v5, v3                                   // 00000005FB70: 06060705
	v_mul_f32_e32 v4, 0x3b800000, v3                           // 00000005FB74: 100806FF 3B800000
	v_mad_u64_u32 v[2:3], null, 0x3000, v2, v[10:11]           // 00000005FB7C: D6FE7C02 042A04FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FB88: BF870092
	v_bfe_u32 v5, v4, 16, 1                                    // 00000005FB8C: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000005FB94: D6550004 03FE0B04 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000005FBA0: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005FBA8: 8C7E037E
	v_or3_b32 v2, v160, s54, 8                                 // 00000005FBAC: D6580002 02206DA0
	s_mov_b32 s3, exec_lo                                      // 00000005FBB4: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005FBB8: BF870001
	.long 0xd4c4007e                                           // 00000005FBBC: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005FBC0: 02020427
	s_cbranch_execz 19                                         // 00000005FBC4: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3e14>
	ds_load_b32 v3, v51 offset:24352                           // 00000005FBC8: D8D85F20 03000033
	s_waitcnt lgkmcnt(0)                                       // 00000005FBD0: BF89FC07
	v_mul_f32_e32 v3, v46, v3                                  // 00000005FBD4: 1006072E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FBD8: BF870091
	v_add_f32_e32 v3, v6, v3                                   // 00000005FBDC: 06060706
	v_mul_f32_e32 v4, 0x3b800000, v3                           // 00000005FBE0: 100806FF 3B800000
	v_mad_u64_u32 v[2:3], null, 0x3000, v2, v[10:11]           // 00000005FBE8: D6FE7C02 042A04FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FBF4: BF870092
	v_bfe_u32 v5, v4, 16, 1                                    // 00000005FBF8: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000005FC00: D6550004 03FE0B04 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000005FC0C: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005FC14: 8C7E037E
	v_or3_b32 v2, v160, s54, 10                                // 00000005FC18: D6580002 02286DA0
	s_mov_b32 s3, exec_lo                                      // 00000005FC20: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005FC24: BF870001
	.long 0xd4c4007e                                           // 00000005FC28: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005FC2C: 02020427
	s_cbranch_execz 19                                         // 00000005FC30: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3e80>
	ds_load_b32 v3, v51 offset:24360                           // 00000005FC34: D8D85F28 03000033
	s_waitcnt lgkmcnt(0)                                       // 00000005FC3C: BF89FC07
	v_mul_f32_e32 v3, v47, v3                                  // 00000005FC40: 1006072F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FC44: BF870091
	v_add_f32_e32 v3, v7, v3                                   // 00000005FC48: 06060707
	v_mul_f32_e32 v4, 0x3b800000, v3                           // 00000005FC4C: 100806FF 3B800000
	v_mad_u64_u32 v[2:3], null, 0x3000, v2, v[10:11]           // 00000005FC54: D6FE7C02 042A04FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FC60: BF870092
	v_bfe_u32 v5, v4, 16, 1                                    // 00000005FC64: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000005FC6C: D6550004 03FE0B04 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000005FC78: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005FC80: 8C7E037E
	v_or3_b32 v2, v160, s54, 12                                // 00000005FC84: D6580002 02306DA0
	s_mov_b32 s3, exec_lo                                      // 00000005FC8C: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005FC90: BF870001
	.long 0xd4c4007e                                           // 00000005FC94: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005FC98: 02020427
	s_cbranch_execz 19                                         // 00000005FC9C: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3eec>
	ds_load_b32 v3, v51 offset:24368                           // 00000005FCA0: D8D85F30 03000033
	s_waitcnt lgkmcnt(0)                                       // 00000005FCA8: BF89FC07
	v_mul_f32_e32 v3, v48, v3                                  // 00000005FCAC: 10060730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FCB0: BF870091
	v_add_f32_e32 v3, v8, v3                                   // 00000005FCB4: 06060708
	v_mul_f32_e32 v4, 0x3b800000, v3                           // 00000005FCB8: 100806FF 3B800000
	v_mad_u64_u32 v[2:3], null, 0x3000, v2, v[10:11]           // 00000005FCC0: D6FE7C02 042A04FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FCCC: BF870092
	v_bfe_u32 v5, v4, 16, 1                                    // 00000005FCD0: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000005FCD8: D6550004 03FE0B04 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000005FCE4: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005FCEC: 8C7E037E
	v_or3_b32 v2, v160, s54, 14                                // 00000005FCF0: D6580002 02386DA0
	s_mov_b32 s3, exec_lo                                      // 00000005FCF8: BE83007E
	s_delay_alu instid0(VALU_DEP_1)                            // 00000005FCFC: BF870001
	.long 0xd4c4007e                                           // 00000005FD00: D4C4007E
	v_cndmask_b32_e32 v1, s39, v2, vcc_lo                      // 00000005FD04: 02020427
	s_cbranch_execz 19                                         // 00000005FD08: BFA50013 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x3f58>
	ds_load_b32 v3, v51 offset:24376                           // 00000005FD0C: D8D85F38 03000033
	s_waitcnt lgkmcnt(0)                                       // 00000005FD14: BF89FC07
	v_mul_f32_e32 v3, v49, v3                                  // 00000005FD18: 10060731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FD1C: BF870091
	v_add_f32_e32 v3, v9, v3                                   // 00000005FD20: 06060709
	v_mul_f32_e32 v4, 0x3b800000, v3                           // 00000005FD24: 100806FF 3B800000
	v_mad_u64_u32 v[2:3], null, 0x3000, v2, v[10:11]           // 00000005FD2C: D6FE7C02 042A04FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FD38: BF870092
	v_bfe_u32 v5, v4, 16, 1                                    // 00000005FD3C: D6100005 02052104
	v_add3_u32 v4, v4, v5, 0x7fff                              // 00000005FD44: D6550004 03FE0B04 00007FFF
	global_store_d16_hi_b16 v[2:3], v4, off                    // 00000005FD50: DC960000 007C0402
	s_or_b32 exec_lo, exec_lo, s3                              // 00000005FD58: 8C7E037E
	v_dual_mov_b32 v97, s27 :: v_dual_add_nc_u32 v34, 0xffffb500, v18// 00000005FD5C: CA20001B 612224FF FFFFB500
	v_dual_mov_b32 v96, s26 :: v_dual_mov_b32 v95, s25         // 00000005FD68: CA10001A 605E0019
	ds_load_b32 v35, v1 offset:24188                           // 00000005FD70: D8D85E7C 23000001
	ds_load_b128 v[2:5], v34                                   // 00000005FD78: DBFC0000 02000022
	ds_load_b128 v[6:9], v34 offset:16                         // 00000005FD80: DBFC0010 06000022
	ds_load_b128 v[10:13], v34 offset:768                      // 00000005FD88: DBFC0300 0A000022
	ds_load_b128 v[14:17], v34 offset:784                      // 00000005FD90: DBFC0310 0E000022
	ds_load_b128 v[18:21], v34 offset:1536                     // 00000005FD98: DBFC0600 12000022
	ds_load_b128 v[22:25], v34 offset:1552                     // 00000005FDA0: DBFC0610 16000022
	ds_load_b128 v[26:29], v34 offset:2304                     // 00000005FDA8: DBFC0900 1A000022
	ds_load_b128 v[30:33], v34 offset:2320                     // 00000005FDB0: DBFC0910 1E000022
	ds_load_b128 v[82:85], v34 offset:3072                     // 00000005FDB8: DBFC0C00 52000022
	ds_load_b128 v[86:89], v34 offset:3088                     // 00000005FDC0: DBFC0C10 56000022
	ds_load_b128 v[161:164], v34 offset:3840                   // 00000005FDC8: DBFC0F00 A1000022
	ds_load_b128 v[165:168], v34 offset:3856                   // 00000005FDD0: DBFC0F10 A5000022
	ds_load_b128 v[169:172], v34 offset:4608                   // 00000005FDD8: DBFC1200 A9000022
	ds_load_b128 v[181:184], v34 offset:5392                   // 00000005FDE0: DBFC1510 B5000022
	ds_load_b128 v[173:176], v34 offset:4624                   // 00000005FDE8: DBFC1210 AD000022
	ds_load_b128 v[177:180], v34 offset:5376                   // 00000005FDF0: DBFC1500 B1000022
	v_dual_mov_b32 v94, s24 :: v_dual_mov_b32 v93, s23         // 00000005FDF8: CA100018 5E5C0017
	v_dual_mov_b32 v92, s22 :: v_dual_mov_b32 v91, s21         // 00000005FE00: CA100016 5C5A0015
	v_mov_b32_e32 v90, s20                                     // 00000005FE08: 7EB40214
	s_waitcnt lgkmcnt(16)                                      // 00000005FE0C: BF89FD07
	v_readfirstlane_b32 s3, v35                                // 00000005FE10: 7E060523
	s_waitcnt lgkmcnt(0)                                       // 00000005FE14: BF89FC07
	s_barrier                                                  // 00000005FE18: BFBD0000
	s_and_not1_b32 vcc_lo, exec_lo, s38                        // 00000005FE1C: 916A267E
	s_waitcnt lgkmcnt(14)                                      // 00000005FE20: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[58:65], v[2:9], v[66:73], v[90:97]// 00000005FE24: CC40403A 1D6A8502
	s_waitcnt lgkmcnt(12)                                      // 00000005FE2C: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[50:57], v[10:17], v[66:73], v[90:97]// 00000005FE30: CC404032 1D6A850A
	s_waitcnt lgkmcnt(10)                                      // 00000005FE38: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[42:49], v[18:25], v[66:73], v[90:97]// 00000005FE3C: CC40402A 1D6A8512
	s_waitcnt lgkmcnt(8)                                       // 00000005FE44: BF89FC87
	v_wmma_f32_16x16x16_f16 v[34:41], v[26:33], v[66:73], v[90:97]// 00000005FE48: CC404022 1D6A851A
	s_waitcnt lgkmcnt(6)                                       // 00000005FE50: BF89FC67
	v_wmma_f32_16x16x16_f16 v[26:33], v[82:89], v[66:73], v[90:97]// 00000005FE54: CC40401A 1D6A8552
	s_waitcnt lgkmcnt(4)                                       // 00000005FE5C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[10:17], v[161:168], v[66:73], v[90:97]// 00000005FE60: CC40400A 1D6A85A1
	s_waitcnt lgkmcnt(1)                                       // 00000005FE68: BF89FC17
	v_wmma_f32_16x16x16_f16 v[18:25], v[169:176], v[66:73], v[90:97]// 00000005FE6C: CC404012 1D6A85A9
	s_waitcnt lgkmcnt(0)                                       // 00000005FE74: BF89FC07
	v_wmma_f32_16x16x16_f16 v[2:9], v[177:184], v[66:73], v[90:97]// 00000005FE78: CC404002 1D6A85B1
	s_cbranch_vccnz 4                                          // 00000005FE80: BFA40004 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4094>
	s_sendmsg_rtn_b64 s[56:57], sendmsg(MSG_RTN_GET_REALTIME)  // 00000005FE84: BEB84D83
	s_sub_i32 s4, s6, s28                                      // 00000005FE88: 81841C06
	s_waitcnt lgkmcnt(0)                                       // 00000005FE8C: BF89FC07
	s_add_i32 s6, s4, s56                                      // 00000005FE90: 81063804
	s_mul_f32 s4, s3, 0x3fb8aa3b                               // 00000005FE94: A204FF03 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000005FE9C: BF8704CB
	s_xor_b32 s29, s4, 0x80000000                              // 00000005FEA0: 8D1DFF04 80000000
	s_rndne_f32 s55, s4                                        // 00000005FEA8: BEB76304
	s_fmamk_f32 s29, s3, 0x3fb8aa3b, s29                       // 00000005FEAC: A31D1D03 3FB8AA3B
	s_cmp_nlt_f32 s3, 0xc2ce8ed0                               // 00000005FEB4: BF4EFF03 C2CE8ED0
	s_sub_f32 s4, s4, s55                                      // 00000005FEBC: A0843704
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000005FEC0: BF8704B9
	s_fmamk_f32 s29, s3, 0x32a5705f, s29                       // 00000005FEC4: A31D1D03 32A5705F
	s_cselect_b32 vcc_lo, -1, 0                                // 00000005FECC: 986A80C1
	s_cmp_ngt_f32 s3, 0x42b17218                               // 00000005FED0: BF4BFF03 42B17218
	s_add_f32 s4, s4, s29                                      // 00000005FED8: A0041D04
	s_delay_alu instid0(SALU_CYCLE_3)                          // 00000005FEDC: BF87000B
	v_exp_f32_e32 v66, s4                                      // 00000005FEE0: 7E844A04
	s_cvt_i32_f32 s4, s55                                      // 00000005FEE4: BE846637
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 00000005FEE8: BF870585
	.long 0xd71c0042                                           // 00000005FEEC: D71C0042
	v_cndmask_b32_e32 v0, v66, v4, vcc_lo                      // 00000005FEF0: 02000942
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000005FEF4: BF8704B1
	v_cndmask_b32_e32 v66, 0, v66, vcc_lo                      // 00000005FEF8: 02848480
	s_cselect_b32 vcc_lo, -1, 0                                // 00000005FEFC: 986A80C1
	s_add_i32 s54, s54, 16                                     // 00000005FF00: 81369036
	s_cmp_lg_u32 s12, s54                                      // 00000005FF04: BF07360C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000005FF08: BF870091
	v_cndmask_b32_e32 v66, 0x7f800000, v66, vcc_lo             // 00000005FF0C: 028484FF 7F800000
	v_fma_f32 v136, v136, v66, v61                             // 00000005FF14: D6130088 04F68588
	v_fma_f32 v139, v139, v66, v58                             // 00000005FF1C: D613008B 04EA858B
	v_fma_f32 v138, v138, v66, v59                             // 00000005FF24: D613008A 04EE858A
	v_fma_f32 v137, v137, v66, v60                             // 00000005FF2C: D6130089 04F28589
	v_fma_f32 v135, v135, v66, v62                             // 00000005FF34: D6130087 04FA8587
	v_fma_f32 v134, v134, v66, v63                             // 00000005FF3C: D6130086 04FE8586
	v_fma_f32 v133, v133, v66, v64                             // 00000005FF44: D6130085 05028585
	v_dual_fmac_f32 v65, v158, v66 :: v_dual_mul_f32 v72, 0x3b800000, v136// 00000005FF4C: C806859E 414910FF 3B800000
	v_fma_f32 v132, v132, v66, v50                             // 00000005FF58: D6130084 04CA8584
	v_fma_f32 v131, v131, v66, v51                             // 00000005FF60: D6130083 04CE8583
	v_fma_f32 v130, v130, v66, v52                             // 00000005FF68: D6130082 04D28582
	v_fma_f32 v129, v129, v66, v53                             // 00000005FF70: D6130081 04D68581
	v_fma_f32 v128, v128, v66, v54                             // 00000005FF78: D6130080 04DA8580
	v_fma_f32 v127, v127, v66, v55                             // 00000005FF80: D613007F 04DE857F
	v_fma_f32 v126, v126, v66, v56                             // 00000005FF88: D613007E 04E2857E
	v_fmac_f32_e32 v57, v157, v66                              // 00000005FF90: 5672859D
	v_fma_f32 v125, v125, v66, v42                             // 00000005FF94: D613007D 04AA857D
	v_fma_f32 v124, v124, v66, v43                             // 00000005FF9C: D613007C 04AE857C
	v_fma_f32 v123, v123, v66, v44                             // 00000005FFA4: D613007B 04B2857B
	v_fma_f32 v122, v122, v66, v45                             // 00000005FFAC: D613007A 04B6857A
	v_fma_f32 v121, v121, v66, v46                             // 00000005FFB4: D6130079 04BA8579
	v_fma_f32 v120, v120, v66, v47                             // 00000005FFBC: D6130078 04BE8578
	v_fma_f32 v119, v119, v66, v48                             // 00000005FFC4: D6130077 04C28577
	v_fmac_f32_e32 v49, v156, v66                              // 00000005FFCC: 5662859C
	v_fma_f32 v118, v118, v66, v34                             // 00000005FFD0: D6130076 048A8576
	v_fma_f32 v117, v117, v66, v35                             // 00000005FFD8: D6130075 048E8575
	v_fma_f32 v116, v116, v66, v36                             // 00000005FFE0: D6130074 04928574
	v_fma_f32 v115, v115, v66, v37                             // 00000005FFE8: D6130073 04968573
	v_fma_f32 v114, v114, v66, v38                             // 00000005FFF0: D6130072 049A8572
	v_fma_f32 v113, v113, v66, v39                             // 00000005FFF8: D6130071 049E8571
	v_fma_f32 v112, v112, v66, v40                             // 000000060000: D6130070 04A28570
	v_dual_fmac_f32 v41, v155, v66 :: v_dual_mul_f32 v68, 0x3b800000, v131// 000000060008: C806859B 294506FF 3B800000
	v_fma_f32 v111, v111, v66, v26                             // 000000060014: D613006F 046A856F
	v_fma_f32 v110, v110, v66, v27                             // 00000006001C: D613006E 046E856E
	v_fma_f32 v109, v109, v66, v28                             // 000000060024: D613006D 0472856D
	v_fma_f32 v108, v108, v66, v29                             // 00000006002C: D613006C 0476856C
	v_fma_f32 v107, v107, v66, v30                             // 000000060034: D613006B 047A856B
	v_fma_f32 v106, v106, v66, v31                             // 00000006003C: D613006A 047E856A
	v_fma_f32 v105, v105, v66, v32                             // 000000060044: D6130069 04828569
	v_fmac_f32_e32 v33, v154, v66                              // 00000006004C: 5642859A
	v_fma_f32 v104, v104, v66, v10                             // 000000060050: D6130068 042A8568
	v_fma_f32 v103, v103, v66, v11                             // 000000060058: D6130067 042E8567
	v_fma_f32 v102, v102, v66, v12                             // 000000060060: D6130066 04328566
	v_fma_f32 v101, v101, v66, v13                             // 000000060068: D6130065 04368565
	v_fma_f32 v100, v100, v66, v14                             // 000000060070: D6130064 043A8564
	v_fma_f32 v99, v99, v66, v15                               // 000000060078: D6130063 043E8563
	v_fma_f32 v98, v98, v66, v16                               // 000000060080: D6130062 04428562
	v_dual_fmac_f32 v17, v153, v66 :: v_dual_mul_f32 v64, 0x3b800000, v127// 000000060088: C8068599 1140FEFF 3B800000
	v_fma_f32 v143, v143, v66, v18                             // 000000060094: D613008F 044A858F
	v_fma_f32 v149, v149, v66, v19                             // 00000006009C: D6130095 044E8595
	v_fma_f32 v148, v148, v66, v20                             // 0000000600A4: D6130094 04528594
	v_fma_f32 v147, v147, v66, v21                             // 0000000600AC: D6130093 04568593
	v_fma_f32 v146, v146, v66, v22                             // 0000000600B4: D6130092 045A8592
	v_fma_f32 v145, v145, v66, v23                             // 0000000600BC: D6130091 045E8591
	v_fma_f32 v141, v141, v66, v24                             // 0000000600C4: D613008D 0462858D
	v_dual_fmac_f32 v25, v152, v66 :: v_dual_mul_f32 v60, 0x3b800000, v123// 0000000600CC: C8068598 193CF6FF 3B800000
	v_fma_f32 v150, v150, v66, v2                              // 0000000600D8: D6130096 040A8596
	v_fma_f32 v142, v142, v66, v3                              // 0000000600E0: D613008E 040E858E
	v_fma_f32 v191, v191, v66, v4                              // 0000000600E8: D61300BF 041285BF
	v_fma_f32 v190, v190, v66, v5                              // 0000000600F0: D61300BE 041685BE
	v_fma_f32 v189, v189, v66, v6                              // 0000000600F8: D61300BD 041A85BD
	v_fma_f32 v187, v187, v66, v7                              // 000000060100: D61300BB 041E85BB
	v_fma_f32 v188, v188, v66, v8                              // 000000060108: D61300BC 042285BC
	v_dual_fmac_f32 v9, v151, v66 :: v_dual_mul_f32 v8, 0x3b800000, v121// 000000060110: C8068597 0908F2FF 3B800000
	v_lshl_add_u32 v2, v160, 7, v159                           // 00000006011C: D6460002 067D0FA0
	v_dual_mul_f32 v69, 0x3b800000, v139 :: v_dual_mul_f32 v70, 0x3b800000, v138// 000000060124: C8C716FF 454714FF 3B800000
	v_dual_mul_f32 v71, 0x3b800000, v137 :: v_dual_mul_f32 v4, 0x3b800000, v135// 000000060130: C8C712FF 47050EFF 3B800000
	v_dual_mul_f32 v73, 0x3b800000, v134 :: v_dual_mul_f32 v52, 0x3b800000, v120// 00000006013C: C8C70CFF 4934F0FF 3B800000
	v_dual_mul_f32 v151, 0x3b800000, v133 :: v_dual_mul_f32 v62, 0x3b800000, v130// 000000060148: C8C70AFF 973F04FF 3B800000
	v_dual_mul_f32 v152, 0x3b800000, v65 :: v_dual_mul_f32 v5, 0x3b800000, v132// 000000060154: C8C682FF 980508FF 3B800000
	v_dual_mul_f32 v66, 0x3b800000, v126 :: v_dual_mul_f32 v63, 0x3b800000, v129// 000000060160: C8C6FCFF 423F02FF 3B800000
	v_mul_f32_e32 v10, 0x3b800000, v118                        // 00000006016C: 1014ECFF 3B800000
	v_dual_mul_f32 v6, 0x3b800000, v128 :: v_dual_mul_f32 v67, 0x3b800000, v57// 000000060174: C8C700FF 064272FF 3B800000
	v_dual_mul_f32 v56, 0x3b800000, v116 :: v_dual_mul_f32 v7, 0x3b800000, v125// 000000060180: C8C6E8FF 3806FAFF 3B800000
	v_dual_mul_f32 v58, 0x3b800000, v115 :: v_dual_mul_f32 v59, 0x3b800000, v124// 00000006018C: C8C6E6FF 3A3AF8FF 3B800000
	v_dual_mul_f32 v54, 0x3b800000, v49 :: v_dual_mul_f32 v61, 0x3b800000, v122// 000000060198: C8C662FF 363CF4FF 3B800000
	v_dual_mul_f32 v50, 0x3b800000, v113 :: v_dual_mul_f32 v53, 0x3b800000, v119// 0000000601A4: C8C6E2FF 3234EEFF 3B800000
	v_mul_f32_e32 v40, 0x3b800000, v41                         // 0000000601B0: 105052FF 3B800000
	v_dual_mul_f32 v55, 0x3b800000, v117 :: v_dual_mul_f32 v12, 0x3b800000, v111// 0000000601B8: C8C6EAFF 370CDEFF 3B800000
	v_dual_mul_f32 v11, 0x3b800000, v114 :: v_dual_mul_f32 v44, 0x3b800000, v109// 0000000601C4: C8C6E4FF 0B2CDAFF 3B800000
	v_dual_mul_f32 v51, 0x3b800000, v112 :: v_dual_mul_f32 v14, 0x3b800000, v107// 0000000601D0: C8C6E0FF 330ED6FF 3B800000
	v_dual_mul_f32 v43, 0x3b800000, v110 :: v_dual_mul_f32 v48, 0x3b800000, v33// 0000000601DC: C8C6DCFF 2B3042FF 3B800000
	v_dual_mul_f32 v45, 0x3b800000, v108 :: v_dual_mul_f32 v46, 0x3b800000, v106// 0000000601E8: C8C6D8FF 2D2ED4FF 3B800000
	v_dual_mul_f32 v47, 0x3b800000, v105 :: v_dual_mul_f32 v42, 0x3b800000, v103// 0000000601F4: C8C6D2FF 2F2ACEFF 3B800000
	v_dual_mul_f32 v15, 0x3b800000, v104 :: v_dual_mul_f32 v36, 0x3b800000, v101// 000000060200: C8C6D0FF 0F24CAFF 3B800000
	v_dual_mul_f32 v35, 0x3b800000, v102 :: v_dual_mul_f32 v28, 0x3b800000, v143// 00000006020C: C8C6CCFF 231D1EFF 3B800000
	v_dual_mul_f32 v27, 0x3b800000, v100 :: v_dual_mul_f32 v38, 0x3b800000, v98// 000000060218: C8C6C8FF 1B26C4FF 3B800000
	v_dual_mul_f32 v37, 0x3b800000, v99 :: v_dual_mul_f32 v32, 0x3b800000, v148// 000000060224: C8C6C6FF 252128FF 3B800000
	v_dual_mul_f32 v39, 0x3b800000, v17 :: v_dual_mul_f32 v34, 0x3b800000, v147// 000000060230: C8C622FF 272326FF 3B800000
	v_dual_mul_f32 v31, 0x3b800000, v149 :: v_dual_mul_f32 v30, 0x3b800000, v150// 00000006023C: C8C72AFF 1F1F2CFF 3B800000
	v_dual_mul_f32 v29, 0x3b800000, v146 :: v_dual_mul_f32 v20, 0x3b800000, v145// 000000060248: C8C724FF 1D1522FF 3B800000
	v_dual_mul_f32 v21, 0x3b800000, v141 :: v_dual_mul_f32 v24, 0x3b800000, v191// 000000060254: C8C71AFF 15197EFF 3B800000
	v_dual_mul_f32 v22, 0x3b800000, v25 :: v_dual_mul_f32 v23, 0x3b800000, v142// 000000060260: C8C632FF 16171CFF 3B800000
	v_dual_mul_f32 v26, 0x3b800000, v190 :: v_dual_mul_f32 v19, 0x3b800000, v188// 00000006026C: C8C77CFF 1A1378FF 3B800000
	v_mul_f32_e32 v16, 0x3b800000, v189                        // 000000060278: 10217AFF 3B800000
	v_dual_mul_f32 v18, 0x3b800000, v187 :: v_dual_mul_f32 v13, 0x3b800000, v9// 000000060280: C8C776FF 120C12FF 3B800000
	s_cbranch_scc0 5                                           // 00000006028C: BFA10005 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x44a4>
	s_cmp_lg_u32 s13, s54                                      // 000000060290: BF07360D
	s_cbranch_scc0 273                                         // 000000060294: BFA10111 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x48dc>
	s_cmp_lg_u32 s14, s54                                      // 000000060298: BF07360E
	s_cbranch_scc1 61734                                       // 00000006029C: BFA2F126 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x938>
	s_branch 540                                               // 0000000602A0: BFA0021C <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4d14>
	v_mov_b32_e32 v82, v2                                      // 0000000602A4: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000602A8: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 0000000602AC: 34A6A49F
	.long 0xd73c0052                                           // 0000000602B0: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 0000000602B4: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000602B8: BF870091
	.long 0xd7006a52                                           // 0000000602BC: D7006A52
	v_cndmask_b32_e32 v1, s16, v82, vcc_lo                     // 0000000602C0: 0202A410
	v_add_co_ci_u32_e64 v83, null, s17, v83, vcc_lo            // 0000000602C4: D5207C53 01AAA611
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000602CC: BF870092
	.long 0xd7006a54                                           // 0000000602D0: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 0000000602D4: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000602DC: D5207C55 01AAA680
	.long 0xd7006a56                                           // 0000000602E4: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000602E8: 0201FF52
	.long 0x00002000                                           // 0000000602EC: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000602F0: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 0000000602F4: D5207C57 01AAA680
	.long 0xd7006a58                                           // 0000000602FC: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 000000060300: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 000000060308: D5207C59 01AAA680
	s_clause 0x7                                               // 000000060310: BF850007
	global_store_b32 v[82:83], v69, off                        // 000000060314: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 00000006031C: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 000000060324: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 00000006032C: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 000000060334: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 00000006033C: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 000000060344: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 00000006034C: DC6A0400 007C4458
	.long 0xd7006a54                                           // 000000060354: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 000000060358: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060360: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000060364: D5207C55 01AAA680
	.long 0xd7006a5a                                           // 00000006036C: D7006A5A
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000060370: 0201FF52
	.long 0x00004000                                           // 000000060374: 00004000
	v_add_co_ci_u32_e64 v91, null, 0, v83, vcc_lo              // 000000060378: D5207C5B 01AAA680
	.long 0xd7006a5c                                           // 000000060380: D7006A5C
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 000000060384: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006038C: BF870001
	v_add_co_ci_u32_e64 v93, null, 0, v83, vcc_lo              // 000000060390: D5207C5D 01AAA680
	s_clause 0x7                                               // 000000060398: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 00000006039C: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 0000000603A4: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 0000000603AC: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 0000000603B4: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 0000000603BC: DC6A0C00 007C4354
	global_store_b32 v[92:93], v59, off offset:1024            // 0000000603C4: DC6A0400 007C3B5C
	global_store_b32 v[92:93], v60, off offset:2048            // 0000000603CC: DC6A0800 007C3C5C
	global_store_b32 v[92:93], v61, off offset:3072            // 0000000603D4: DC6A0C00 007C3D5C
	.long 0xd7006a54                                           // 0000000603DC: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 0000000603E0: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000603E8: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000603EC: D5207C55 01AAA680
	.long 0xd7006a58                                           // 0000000603F4: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000603F8: 0201FF52
	.long 0x00006000                                           // 0000000603FC: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 000000060400: D5207C59 01AAA680
	.long 0xd7006a5c                                           // 000000060408: D7006A5C
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 00000006040C: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060414: BF8700A1
	v_add_co_ci_u32_e64 v93, null, 0, v83, vcc_lo              // 000000060418: D5207C5D 01AAA680
	.long 0xd7006a5e                                           // 000000060420: D7006A5E
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 000000060424: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v95, null, 0, v83, vcc_lo              // 00000006042C: D5207C5F 01AAA680
	.long 0xd7006a60                                           // 000000060434: D7006A60
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000060438: 0201FF52
	.long 0x00008000                                           // 00000006043C: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000060440: BF870001
	v_add_co_ci_u32_e64 v97, null, 0, v83, vcc_lo              // 000000060444: D5207C61 01AAA680
	s_clause 0x7                                               // 00000006044C: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 000000060450: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 000000060458: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 000000060460: DC6A0C00 007C3654
	global_store_b32 v[92:93], v55, off offset:1024            // 000000060468: DC6A0400 007C375C
	global_store_b32 v[92:93], v56, off offset:2048            // 000000060470: DC6A0800 007C385C
	global_store_b32 v[92:93], v58, off offset:3072            // 000000060478: DC6A0C00 007C3A5C
	global_store_b32 v[94:95], v50, off offset:1024            // 000000060480: DC6A0400 007C325E
	global_store_b32 v[94:95], v51, off offset:2048            // 000000060488: DC6A0800 007C335E
	.long 0xd7006a54                                           // 000000060490: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 000000060494: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006049C: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000604A0: D5207C55 01AAA680
	.long 0xd7006a5c                                           // 0000000604A8: D7006A5C
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 0000000604AC: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v93, null, 0, v83, vcc_lo              // 0000000604B4: D5207C5D 01AAA680
	.long 0xd7006a99                                           // 0000000604BC: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000604C0: 0201FF52
	.long 0x0000a000                                           // 0000000604C4: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000604C8: BF8700A1
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 0000000604CC: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 0000000604D4: D7006A9B
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 0000000604D8: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 0000000604E0: D5207C9C 01AAA680
	s_clause 0x7                                               // 0000000604E8: BF850007
	global_store_b32 v[94:95], v40, off offset:3072            // 0000000604EC: DC6A0C00 007C285E
	global_store_b32 v[84:85], v43, off offset:1024            // 0000000604F4: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 0000000604FC: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 000000060504: DC6A0C00 007C2D54
	global_store_b32 v[92:93], v46, off offset:1024            // 00000006050C: DC6A0400 007C2E5C
	global_store_b32 v[92:93], v47, off offset:2048            // 000000060514: DC6A0800 007C2F5C
	global_store_b32 v[92:93], v48, off offset:3072            // 00000006051C: DC6A0C00 007C305C
	global_store_b32 v[155:156], v42, off offset:1024          // 000000060524: DC6A0400 007C2A9B
	.long 0xd7006a54                                           // 00000006052C: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 000000060530: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060538: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000006053C: D5207C55 01AAA680
	.long 0xd7006a5c                                           // 000000060544: D7006A5C
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000060548: 0201FF52
	.long 0x0000c000                                           // 00000006054C: 0000C000
	v_add_co_ci_u32_e64 v93, null, 0, v83, vcc_lo              // 000000060550: D5207C5D 01AAA680
	.long 0xd7006a5e                                           // 000000060558: D7006A5E
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 00000006055C: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000060564: BF870001
	v_add_co_ci_u32_e64 v95, null, 0, v83, vcc_lo              // 000000060568: D5207C5F 01AAA680
	s_clause 0x7                                               // 000000060570: BF850007
	global_store_b32 v[155:156], v35, off offset:2048          // 000000060574: DC6A0800 007C239B
	global_store_b32 v[155:156], v36, off offset:3072          // 00000006057C: DC6A0C00 007C249B
	global_store_b32 v[84:85], v37, off offset:1024            // 000000060584: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 00000006058C: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 000000060594: DC6A0C00 007C2754
	global_store_b32 v[94:95], v31, off offset:1024            // 00000006059C: DC6A0400 007C1F5E
	global_store_b32 v[94:95], v32, off offset:2048            // 0000000605A4: DC6A0800 007C205E
	global_store_b32 v[94:95], v34, off offset:3072            // 0000000605AC: DC6A0C00 007C225E
	.long 0xd7006a54                                           // 0000000605B4: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 0000000605B8: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000605C0: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000605C4: D5207C55 01AAA680
	.long 0xd7006a5e                                           // 0000000605CC: D7006A5E
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000605D0: 0201FF52
	.long 0x0000e000                                           // 0000000605D4: 0000E000
	v_add_co_ci_u32_e64 v95, null, 0, v83, vcc_lo              // 0000000605D8: D5207C5F 01AAA680
	.long 0xd7006a9b                                           // 0000000605E0: D7006A9B
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 0000000605E4: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000605EC: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 0000000605F0: D5207C9C 01AAA680
	.long 0xd7006a52                                           // 0000000605F8: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 0000000605FC: 0202A4FF 0000F000
	s_clause 0x7                                               // 000000060604: BF850007
	global_store_b32 v[96:97], v11, off offset:-4096           // 000000060608: DC6A1000 007C0B60
	global_store_b32 v[96:97], v12, off                        // 000000060610: DC6A0000 007C0C60
	global_store_b32 v[153:154], v14, off offset:-4096         // 000000060618: DC6A1000 007C0E99
	global_store_b32 v[153:154], v15, off                      // 000000060620: DC6A0000 007C0F99
	global_store_b32 v[92:93], v27, off offset:-4096           // 000000060628: DC6A1000 007C1B5C
	global_store_b32 v[92:93], v28, off                        // 000000060630: DC6A0000 007C1C5C
	global_store_b32 v[94:95], v29, off offset:-4096           // 000000060638: DC6A1000 007C1D5E
	global_store_b32 v[94:95], v30, off                        // 000000060640: DC6A0000 007C1E5E
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 000000060648: D5207C53 01AAA680
	s_clause 0xf                                               // 000000060650: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 000000060654: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 00000006065C: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 000000060664: DC6A0C00 007C1654
	global_store_b32 v[155:156], v23, off offset:1024          // 00000006066C: DC6A0400 007C179B
	global_store_b32 v[155:156], v24, off offset:2048          // 000000060674: DC6A0800 007C189B
	global_store_b32 v[155:156], v26, off offset:3072          // 00000006067C: DC6A0C00 007C1A9B
	global_store_b32 v[82:83], v16, off                        // 000000060684: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 00000006068C: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 000000060694: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 00000006069C: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 0000000606A4: DC6A0000 007C0556
	global_store_b32 v[90:91], v6, off offset:-4096            // 0000000606AC: DC6A1000 007C065A
	global_store_b32 v[90:91], v7, off                         // 0000000606B4: DC6A0000 007C075A
	global_store_b32 v[88:89], v8, off offset:-4096            // 0000000606BC: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 0000000606C4: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 0000000606CC: DC6A0C00 007C0D52
	s_cmp_lg_u32 s13, s54                                      // 0000000606D4: BF07360D
	s_cbranch_scc1 65263                                       // 0000000606D8: BFA2FEEF <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x4498>
	v_mov_b32_e32 v82, v2                                      // 0000000606DC: 7EA40302
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000606E0: BF870091
	v_ashrrev_i32_e32 v83, 31, v82                             // 0000000606E4: 34A6A49F
	.long 0xd73c0052                                           // 0000000606E8: D73C0052
	v_cndmask_b32_e32 v1, 2, v82, vcc_lo                       // 0000000606EC: 0202A482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000606F0: BF870091
	.long 0xd7006a52                                           // 0000000606F4: D7006A52
	v_cndmask_b32_e32 v1, s18, v82, vcc_lo                     // 0000000606F8: 0202A412
	v_add_co_ci_u32_e64 v83, null, s19, v83, vcc_lo            // 0000000606FC: D5207C53 01AAA613
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060704: BF870092
	.long 0xd7006a54                                           // 000000060708: D7006A54
	v_cndmask_b32_e32 v1, 0x1000, v82, vcc_lo                  // 00000006070C: 0202A4FF 00001000
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000060714: D5207C55 01AAA680
	.long 0xd7006a56                                           // 00000006071C: D7006A56
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000060720: 0201FF52
	.long 0x00002000                                           // 000000060724: 00002000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060728: BF8700A1
	v_add_co_ci_u32_e64 v87, null, 0, v83, vcc_lo              // 00000006072C: D5207C57 01AAA680
	.long 0xd7006a58                                           // 000000060734: D7006A58
	v_cndmask_b32_e32 v1, 0x2000, v82, vcc_lo                  // 000000060738: 0202A4FF 00002000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 000000060740: D5207C59 01AAA680
	s_clause 0x7                                               // 000000060748: BF850007
	global_store_b32 v[82:83], v69, off                        // 00000006074C: DC6A0000 007C4552
	global_store_b32 v[82:83], v70, off offset:1024            // 000000060754: DC6A0400 007C4652
	global_store_b32 v[82:83], v71, off offset:2048            // 00000006075C: DC6A0800 007C4752
	global_store_b32 v[82:83], v72, off offset:3072            // 000000060764: DC6A0C00 007C4852
	global_store_b32 v[84:85], v73, off offset:1024            // 00000006076C: DC6A0400 007C4954
	global_store_b32 v[84:85], v151, off offset:2048           // 000000060774: DC6A0800 007C9754
	global_store_b32 v[84:85], v152, off offset:3072           // 00000006077C: DC6A0C00 007C9854
	global_store_b32 v[88:89], v68, off offset:1024            // 000000060784: DC6A0400 007C4458
	.long 0xd7006a54                                           // 00000006078C: D7006A54
	v_cndmask_b32_e32 v1, 0x3000, v82, vcc_lo                  // 000000060790: 0202A4FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060798: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 00000006079C: D5207C55 01AAA680
	.long 0xd7006a5a                                           // 0000000607A4: D7006A5A
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000607A8: 0201FF52
	.long 0x00004000                                           // 0000000607AC: 00004000
	v_add_co_ci_u32_e64 v91, null, 0, v83, vcc_lo              // 0000000607B0: D5207C5B 01AAA680
	.long 0xd7006a5c                                           // 0000000607B8: D7006A5C
	v_cndmask_b32_e32 v1, 0x4000, v82, vcc_lo                  // 0000000607BC: 0202A4FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000607C4: BF870001
	v_add_co_ci_u32_e64 v93, null, 0, v83, vcc_lo              // 0000000607C8: D5207C5D 01AAA680
	s_clause 0x7                                               // 0000000607D0: BF850007
	global_store_b32 v[88:89], v62, off offset:2048            // 0000000607D4: DC6A0800 007C3E58
	global_store_b32 v[88:89], v63, off offset:3072            // 0000000607DC: DC6A0C00 007C3F58
	global_store_b32 v[84:85], v64, off offset:1024            // 0000000607E4: DC6A0400 007C4054
	global_store_b32 v[84:85], v66, off offset:2048            // 0000000607EC: DC6A0800 007C4254
	global_store_b32 v[84:85], v67, off offset:3072            // 0000000607F4: DC6A0C00 007C4354
	global_store_b32 v[92:93], v59, off offset:1024            // 0000000607FC: DC6A0400 007C3B5C
	global_store_b32 v[92:93], v60, off offset:2048            // 000000060804: DC6A0800 007C3C5C
	global_store_b32 v[92:93], v61, off offset:3072            // 00000006080C: DC6A0C00 007C3D5C
	.long 0xd7006a54                                           // 000000060814: D7006A54
	v_cndmask_b32_e32 v1, 0x5000, v82, vcc_lo                  // 000000060818: 0202A4FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060820: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000060824: D5207C55 01AAA680
	.long 0xd7006a58                                           // 00000006082C: D7006A58
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000060830: 0201FF52
	.long 0x00006000                                           // 000000060834: 00006000
	v_add_co_ci_u32_e64 v89, null, 0, v83, vcc_lo              // 000000060838: D5207C59 01AAA680
	.long 0xd7006a5c                                           // 000000060840: D7006A5C
	v_cndmask_b32_e32 v1, 0x6000, v82, vcc_lo                  // 000000060844: 0202A4FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000006084C: BF8700A1
	v_add_co_ci_u32_e64 v93, null, 0, v83, vcc_lo              // 000000060850: D5207C5D 01AAA680
	.long 0xd7006a5e                                           // 000000060858: D7006A5E
	v_cndmask_b32_e32 v1, 0x7000, v82, vcc_lo                  // 00000006085C: 0202A4FF 00007000
	v_add_co_ci_u32_e64 v95, null, 0, v83, vcc_lo              // 000000060864: D5207C5F 01AAA680
	.long 0xd7006a60                                           // 00000006086C: D7006A60
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000060870: 0201FF52
	.long 0x00008000                                           // 000000060874: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000060878: BF870001
	v_add_co_ci_u32_e64 v97, null, 0, v83, vcc_lo              // 00000006087C: D5207C61 01AAA680
	s_clause 0x7                                               // 000000060884: BF850007
	global_store_b32 v[84:85], v52, off offset:1024            // 000000060888: DC6A0400 007C3454
	global_store_b32 v[84:85], v53, off offset:2048            // 000000060890: DC6A0800 007C3554
	global_store_b32 v[84:85], v54, off offset:3072            // 000000060898: DC6A0C00 007C3654
	global_store_b32 v[92:93], v55, off offset:1024            // 0000000608A0: DC6A0400 007C375C
	global_store_b32 v[92:93], v56, off offset:2048            // 0000000608A8: DC6A0800 007C385C
	global_store_b32 v[92:93], v58, off offset:3072            // 0000000608B0: DC6A0C00 007C3A5C
	global_store_b32 v[94:95], v50, off offset:1024            // 0000000608B8: DC6A0400 007C325E
	global_store_b32 v[94:95], v51, off offset:2048            // 0000000608C0: DC6A0800 007C335E
	.long 0xd7006a54                                           // 0000000608C8: D7006A54
	v_cndmask_b32_e32 v1, 0x8000, v82, vcc_lo                  // 0000000608CC: 0202A4FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000608D4: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000608D8: D5207C55 01AAA680
	.long 0xd7006a5c                                           // 0000000608E0: D7006A5C
	v_cndmask_b32_e32 v1, 0x9000, v82, vcc_lo                  // 0000000608E4: 0202A4FF 00009000
	v_add_co_ci_u32_e64 v93, null, 0, v83, vcc_lo              // 0000000608EC: D5207C5D 01AAA680
	.long 0xd7006a99                                           // 0000000608F4: D7006A99
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 0000000608F8: 0201FF52
	.long 0x0000a000                                           // 0000000608FC: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060900: BF8700A1
	v_add_co_ci_u32_e64 v154, null, 0, v83, vcc_lo             // 000000060904: D5207C9A 01AAA680
	.long 0xd7006a9b                                           // 00000006090C: D7006A9B
	v_cndmask_b32_e32 v1, 0xa000, v82, vcc_lo                  // 000000060910: 0202A4FF 0000A000
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000060918: D5207C9C 01AAA680
	s_clause 0x7                                               // 000000060920: BF850007
	global_store_b32 v[94:95], v40, off offset:3072            // 000000060924: DC6A0C00 007C285E
	global_store_b32 v[84:85], v43, off offset:1024            // 00000006092C: DC6A0400 007C2B54
	global_store_b32 v[84:85], v44, off offset:2048            // 000000060934: DC6A0800 007C2C54
	global_store_b32 v[84:85], v45, off offset:3072            // 00000006093C: DC6A0C00 007C2D54
	global_store_b32 v[92:93], v46, off offset:1024            // 000000060944: DC6A0400 007C2E5C
	global_store_b32 v[92:93], v47, off offset:2048            // 00000006094C: DC6A0800 007C2F5C
	global_store_b32 v[92:93], v48, off offset:3072            // 000000060954: DC6A0C00 007C305C
	global_store_b32 v[155:156], v42, off offset:1024          // 00000006095C: DC6A0400 007C2A9B
	.long 0xd7006a54                                           // 000000060964: D7006A54
	v_cndmask_b32_e32 v1, 0xb000, v82, vcc_lo                  // 000000060968: 0202A4FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060970: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 000000060974: D5207C55 01AAA680
	.long 0xd7006a5c                                           // 00000006097C: D7006A5C
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000060980: 0201FF52
	.long 0x0000c000                                           // 000000060984: 0000C000
	v_add_co_ci_u32_e64 v93, null, 0, v83, vcc_lo              // 000000060988: D5207C5D 01AAA680
	.long 0xd7006a5e                                           // 000000060990: D7006A5E
	v_cndmask_b32_e32 v1, 0xc000, v82, vcc_lo                  // 000000060994: 0202A4FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000006099C: BF870001
	v_add_co_ci_u32_e64 v95, null, 0, v83, vcc_lo              // 0000000609A0: D5207C5F 01AAA680
	s_clause 0x7                                               // 0000000609A8: BF850007
	global_store_b32 v[155:156], v35, off offset:2048          // 0000000609AC: DC6A0800 007C239B
	global_store_b32 v[155:156], v36, off offset:3072          // 0000000609B4: DC6A0C00 007C249B
	global_store_b32 v[84:85], v37, off offset:1024            // 0000000609BC: DC6A0400 007C2554
	global_store_b32 v[84:85], v38, off offset:2048            // 0000000609C4: DC6A0800 007C2654
	global_store_b32 v[84:85], v39, off offset:3072            // 0000000609CC: DC6A0C00 007C2754
	global_store_b32 v[94:95], v31, off offset:1024            // 0000000609D4: DC6A0400 007C1F5E
	global_store_b32 v[94:95], v32, off offset:2048            // 0000000609DC: DC6A0800 007C205E
	global_store_b32 v[94:95], v34, off offset:3072            // 0000000609E4: DC6A0C00 007C225E
	.long 0xd7006a54                                           // 0000000609EC: D7006A54
	v_cndmask_b32_e32 v1, 0xd000, v82, vcc_lo                  // 0000000609F0: 0202A4FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000609F8: BF8700A1
	v_add_co_ci_u32_e64 v85, null, 0, v83, vcc_lo              // 0000000609FC: D5207C55 01AAA680
	.long 0xd7006a5e                                           // 000000060A04: D7006A5E
	v_cndmask_b32_e32 v0, v82, v255, vcc_lo                    // 000000060A08: 0201FF52
	.long 0x0000e000                                           // 000000060A0C: 0000E000
	v_add_co_ci_u32_e64 v95, null, 0, v83, vcc_lo              // 000000060A10: D5207C5F 01AAA680
	.long 0xd7006a9b                                           // 000000060A18: D7006A9B
	v_cndmask_b32_e32 v1, 0xe000, v82, vcc_lo                  // 000000060A1C: 0202A4FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000060A24: BF870001
	v_add_co_ci_u32_e64 v156, null, 0, v83, vcc_lo             // 000000060A28: D5207C9C 01AAA680
	.long 0xd7006a52                                           // 000000060A30: D7006A52
	v_cndmask_b32_e32 v1, 0xf000, v82, vcc_lo                  // 000000060A34: 0202A4FF 0000F000
	s_clause 0x7                                               // 000000060A3C: BF850007
	global_store_b32 v[96:97], v11, off offset:-4096           // 000000060A40: DC6A1000 007C0B60
	global_store_b32 v[96:97], v12, off                        // 000000060A48: DC6A0000 007C0C60
	global_store_b32 v[153:154], v14, off offset:-4096         // 000000060A50: DC6A1000 007C0E99
	global_store_b32 v[153:154], v15, off                      // 000000060A58: DC6A0000 007C0F99
	global_store_b32 v[92:93], v27, off offset:-4096           // 000000060A60: DC6A1000 007C1B5C
	global_store_b32 v[92:93], v28, off                        // 000000060A68: DC6A0000 007C1C5C
	global_store_b32 v[94:95], v29, off offset:-4096           // 000000060A70: DC6A1000 007C1D5E
	global_store_b32 v[94:95], v30, off                        // 000000060A78: DC6A0000 007C1E5E
	v_add_co_ci_u32_e64 v83, null, 0, v83, vcc_lo              // 000000060A80: D5207C53 01AAA680
	s_clause 0xf                                               // 000000060A88: BF85000F
	global_store_b32 v[84:85], v20, off offset:1024            // 000000060A8C: DC6A0400 007C1454
	global_store_b32 v[84:85], v21, off offset:2048            // 000000060A94: DC6A0800 007C1554
	global_store_b32 v[84:85], v22, off offset:3072            // 000000060A9C: DC6A0C00 007C1654
	global_store_b32 v[155:156], v23, off offset:1024          // 000000060AA4: DC6A0400 007C179B
	global_store_b32 v[155:156], v24, off offset:2048          // 000000060AAC: DC6A0800 007C189B
	global_store_b32 v[155:156], v26, off offset:3072          // 000000060AB4: DC6A0C00 007C1A9B
	global_store_b32 v[82:83], v16, off                        // 000000060ABC: DC6A0000 007C1052
	global_store_b32 v[82:83], v18, off offset:1024            // 000000060AC4: DC6A0400 007C1252
	global_store_b32 v[82:83], v19, off offset:2048            // 000000060ACC: DC6A0800 007C1352
	global_store_b32 v[86:87], v4, off offset:-4096            // 000000060AD4: DC6A1000 007C0456
	global_store_b32 v[86:87], v5, off                         // 000000060ADC: DC6A0000 007C0556
	global_store_b32 v[90:91], v6, off offset:-4096            // 000000060AE4: DC6A1000 007C065A
	global_store_b32 v[90:91], v7, off                         // 000000060AEC: DC6A0000 007C075A
	global_store_b32 v[88:89], v8, off offset:-4096            // 000000060AF4: DC6A1000 007C0858
	global_store_b32 v[88:89], v10, off                        // 000000060AFC: DC6A0000 007C0A58
	global_store_b32 v[82:83], v13, off offset:3072            // 000000060B04: DC6A0C00 007C0D52
	s_cmp_lg_u32 s14, s54                                      // 000000060B0C: BF07360E
	s_cbranch_scc1 61193                                       // 000000060B10: BFA2EF09 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x938>
	v_ashrrev_i32_e32 v3, 31, v2                               // 000000060B14: 3406049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000060B18: BF870091
	.long 0xd73c0002                                           // 000000060B1C: D73C0002
	v_cndmask_b32_e32 v1, 2, v2, vcc_lo                        // 000000060B20: 02020482
	.long 0xd7006a02                                           // 000000060B24: D7006A02
	v_cndmask_b32_e32 v1, s47, v2, vcc_lo                      // 000000060B28: 0202042F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000060B2C: BF870111
	v_add_co_ci_u32_e64 v3, null, s7, v3, vcc_lo               // 000000060B30: D5207C03 01AA0607
	.long 0xd7006a52                                           // 000000060B38: D7006A52
	v_cndmask_b32_e32 v1, 0x1000, v2, vcc_lo                   // 000000060B3C: 020204FF 00001000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060B44: BF8700A1
	v_add_co_ci_u32_e64 v83, null, 0, v3, vcc_lo               // 000000060B48: D5207C53 01AA0680
	.long 0xd7006a54                                           // 000000060B50: D7006A54
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000060B54: 0201FF02
	.long 0x00002000                                           // 000000060B58: 00002000
	v_add_co_ci_u32_e64 v85, null, 0, v3, vcc_lo               // 000000060B5C: D5207C55 01AA0680
	.long 0xd7006a56                                           // 000000060B64: D7006A56
	v_cndmask_b32_e32 v1, 0x2000, v2, vcc_lo                   // 000000060B68: 020204FF 00002000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000060B70: BF870001
	v_add_co_ci_u32_e64 v87, null, 0, v3, vcc_lo               // 000000060B74: D5207C57 01AA0680
	s_clause 0x7                                               // 000000060B7C: BF850007
	global_store_b32 v[2:3], v69, off                          // 000000060B80: DC6A0000 007C4502
	global_store_b32 v[2:3], v70, off offset:1024              // 000000060B88: DC6A0400 007C4602
	global_store_b32 v[2:3], v71, off offset:2048              // 000000060B90: DC6A0800 007C4702
	global_store_b32 v[2:3], v72, off offset:3072              // 000000060B98: DC6A0C00 007C4802
	global_store_b32 v[82:83], v73, off offset:1024            // 000000060BA0: DC6A0400 007C4952
	global_store_b32 v[82:83], v151, off offset:2048           // 000000060BA8: DC6A0800 007C9752
	global_store_b32 v[82:83], v152, off offset:3072           // 000000060BB0: DC6A0C00 007C9852
	global_store_b32 v[86:87], v68, off offset:1024            // 000000060BB8: DC6A0400 007C4456
	.long 0xd7006a44                                           // 000000060BC0: D7006A44
	v_cndmask_b32_e32 v1, 0x3000, v2, vcc_lo                   // 000000060BC4: 020204FF 00003000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060BCC: BF8700A1
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 000000060BD0: D5207C45 01AA0680
	.long 0xd7006a46                                           // 000000060BD8: D7006A46
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000060BDC: 0201FF02
	.long 0x00004000                                           // 000000060BE0: 00004000
	v_add_co_ci_u32_e64 v71, null, 0, v3, vcc_lo               // 000000060BE4: D5207C47 01AA0680
	.long 0xd7006a48                                           // 000000060BEC: D7006A48
	v_cndmask_b32_e32 v1, 0x4000, v2, vcc_lo                   // 000000060BF0: 020204FF 00004000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000060BF8: BF870001
	v_add_co_ci_u32_e64 v73, null, 0, v3, vcc_lo               // 000000060BFC: D5207C49 01AA0680
	s_clause 0x7                                               // 000000060C04: BF850007
	global_store_b32 v[86:87], v62, off offset:2048            // 000000060C08: DC6A0800 007C3E56
	global_store_b32 v[86:87], v63, off offset:3072            // 000000060C10: DC6A0C00 007C3F56
	global_store_b32 v[68:69], v64, off offset:1024            // 000000060C18: DC6A0400 007C4044
	global_store_b32 v[68:69], v66, off offset:2048            // 000000060C20: DC6A0800 007C4244
	global_store_b32 v[68:69], v67, off offset:3072            // 000000060C28: DC6A0C00 007C4344
	global_store_b32 v[72:73], v59, off offset:1024            // 000000060C30: DC6A0400 007C3B48
	global_store_b32 v[72:73], v60, off offset:2048            // 000000060C38: DC6A0800 007C3C48
	global_store_b32 v[72:73], v61, off offset:3072            // 000000060C40: DC6A0C00 007C3D48
	.long 0xd7006a3b                                           // 000000060C48: D7006A3B
	v_cndmask_b32_e32 v1, 0x5000, v2, vcc_lo                   // 000000060C4C: 020204FF 00005000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060C54: BF8700A1
	v_add_co_ci_u32_e64 v60, null, 0, v3, vcc_lo               // 000000060C58: D5207C3C 01AA0680
	.long 0xd7006a3d                                           // 000000060C60: D7006A3D
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000060C64: 0201FF02
	.long 0x00006000                                           // 000000060C68: 00006000
	v_add_co_ci_u32_e64 v62, null, 0, v3, vcc_lo               // 000000060C6C: D5207C3E 01AA0680
	.long 0xd7006a3f                                           // 000000060C74: D7006A3F
	v_cndmask_b32_e32 v1, 0x6000, v2, vcc_lo                   // 000000060C78: 020204FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060C80: BF8700A1
	v_add_co_ci_u32_e64 v64, null, 0, v3, vcc_lo               // 000000060C84: D5207C40 01AA0680
	.long 0xd7006a42                                           // 000000060C8C: D7006A42
	v_cndmask_b32_e32 v1, 0x7000, v2, vcc_lo                   // 000000060C90: 020204FF 00007000
	v_add_co_ci_u32_e64 v67, null, 0, v3, vcc_lo               // 000000060C98: D5207C43 01AA0680
	.long 0xd7006a44                                           // 000000060CA0: D7006A44
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000060CA4: 0201FF02
	.long 0x00008000                                           // 000000060CA8: 00008000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000060CAC: BF870001
	v_add_co_ci_u32_e64 v69, null, 0, v3, vcc_lo               // 000000060CB0: D5207C45 01AA0680
	s_clause 0x7                                               // 000000060CB8: BF850007
	global_store_b32 v[59:60], v52, off offset:1024            // 000000060CBC: DC6A0400 007C343B
	global_store_b32 v[59:60], v53, off offset:2048            // 000000060CC4: DC6A0800 007C353B
	global_store_b32 v[59:60], v54, off offset:3072            // 000000060CCC: DC6A0C00 007C363B
	global_store_b32 v[63:64], v55, off offset:1024            // 000000060CD4: DC6A0400 007C373F
	global_store_b32 v[63:64], v56, off offset:2048            // 000000060CDC: DC6A0800 007C383F
	global_store_b32 v[63:64], v58, off offset:3072            // 000000060CE4: DC6A0C00 007C3A3F
	global_store_b32 v[66:67], v50, off offset:1024            // 000000060CEC: DC6A0400 007C3242
	global_store_b32 v[66:67], v51, off offset:2048            // 000000060CF4: DC6A0800 007C3342
	.long 0xd7006a32                                           // 000000060CFC: D7006A32
	v_cndmask_b32_e32 v1, 0x8000, v2, vcc_lo                   // 000000060D00: 020204FF 00008000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060D08: BF8700A1
	v_add_co_ci_u32_e64 v51, null, 0, v3, vcc_lo               // 000000060D0C: D5207C33 01AA0680
	.long 0xd7006a34                                           // 000000060D14: D7006A34
	v_cndmask_b32_e32 v1, 0x9000, v2, vcc_lo                   // 000000060D18: 020204FF 00009000
	v_add_co_ci_u32_e64 v53, null, 0, v3, vcc_lo               // 000000060D20: D5207C35 01AA0680
	.long 0xd7006a36                                           // 000000060D28: D7006A36
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000060D2C: 0201FF02
	.long 0x0000a000                                           // 000000060D30: 0000A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060D34: BF8700A1
	v_add_co_ci_u32_e64 v55, null, 0, v3, vcc_lo               // 000000060D38: D5207C37 01AA0680
	.long 0xd7006a3a                                           // 000000060D40: D7006A3A
	v_cndmask_b32_e32 v1, 0xa000, v2, vcc_lo                   // 000000060D44: 020204FF 0000A000
	v_add_co_ci_u32_e64 v59, null, 0, v3, vcc_lo               // 000000060D4C: D5207C3B 01AA0680
	s_clause 0x7                                               // 000000060D54: BF850007
	global_store_b32 v[66:67], v40, off offset:3072            // 000000060D58: DC6A0C00 007C2842
	global_store_b32 v[50:51], v43, off offset:1024            // 000000060D60: DC6A0400 007C2B32
	global_store_b32 v[50:51], v44, off offset:2048            // 000000060D68: DC6A0800 007C2C32
	global_store_b32 v[50:51], v45, off offset:3072            // 000000060D70: DC6A0C00 007C2D32
	global_store_b32 v[52:53], v46, off offset:1024            // 000000060D78: DC6A0400 007C2E34
	global_store_b32 v[52:53], v47, off offset:2048            // 000000060D80: DC6A0800 007C2F34
	global_store_b32 v[52:53], v48, off offset:3072            // 000000060D88: DC6A0C00 007C3034
	global_store_b32 v[58:59], v42, off offset:1024            // 000000060D90: DC6A0400 007C2A3A
	.long 0xd7006a2a                                           // 000000060D98: D7006A2A
	v_cndmask_b32_e32 v1, 0xb000, v2, vcc_lo                   // 000000060D9C: 020204FF 0000B000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060DA4: BF8700A1
	v_add_co_ci_u32_e64 v43, null, 0, v3, vcc_lo               // 000000060DA8: D5207C2B 01AA0680
	.long 0xd7006a2c                                           // 000000060DB0: D7006A2C
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000060DB4: 0201FF02
	.long 0x0000c000                                           // 000000060DB8: 0000C000
	v_add_co_ci_u32_e64 v45, null, 0, v3, vcc_lo               // 000000060DBC: D5207C2D 01AA0680
	.long 0xd7006a2e                                           // 000000060DC4: D7006A2E
	v_cndmask_b32_e32 v1, 0xc000, v2, vcc_lo                   // 000000060DC8: 020204FF 0000C000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000060DD0: BF870001
	v_add_co_ci_u32_e64 v47, null, 0, v3, vcc_lo               // 000000060DD4: D5207C2F 01AA0680
	s_clause 0x7                                               // 000000060DDC: BF850007
	global_store_b32 v[58:59], v35, off offset:2048            // 000000060DE0: DC6A0800 007C233A
	global_store_b32 v[58:59], v36, off offset:3072            // 000000060DE8: DC6A0C00 007C243A
	global_store_b32 v[42:43], v37, off offset:1024            // 000000060DF0: DC6A0400 007C252A
	global_store_b32 v[42:43], v38, off offset:2048            // 000000060DF8: DC6A0800 007C262A
	global_store_b32 v[42:43], v39, off offset:3072            // 000000060E00: DC6A0C00 007C272A
	global_store_b32 v[46:47], v31, off offset:1024            // 000000060E08: DC6A0400 007C1F2E
	global_store_b32 v[46:47], v32, off offset:2048            // 000000060E10: DC6A0800 007C202E
	global_store_b32 v[46:47], v34, off offset:3072            // 000000060E18: DC6A0C00 007C222E
	.long 0xd7006a1f                                           // 000000060E20: D7006A1F
	v_cndmask_b32_e32 v1, 0xd000, v2, vcc_lo                   // 000000060E24: 020204FF 0000D000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000060E2C: BF8700A1
	v_add_co_ci_u32_e64 v32, null, 0, v3, vcc_lo               // 000000060E30: D5207C20 01AA0680
	.long 0xd7006a22                                           // 000000060E38: D7006A22
	v_cndmask_b32_e32 v0, v2, v255, vcc_lo                     // 000000060E3C: 0201FF02
	.long 0x0000e000                                           // 000000060E40: 0000E000
	v_add_co_ci_u32_e64 v35, null, 0, v3, vcc_lo               // 000000060E44: D5207C23 01AA0680
	.long 0xd7006a24                                           // 000000060E4C: D7006A24
	v_cndmask_b32_e32 v1, 0xe000, v2, vcc_lo                   // 000000060E50: 020204FF 0000E000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000060E58: BF870001
	v_add_co_ci_u32_e64 v37, null, 0, v3, vcc_lo               // 000000060E5C: D5207C25 01AA0680
	.long 0xd7006a02                                           // 000000060E64: D7006A02
	v_cndmask_b32_e32 v1, 0xf000, v2, vcc_lo                   // 000000060E68: 020204FF 0000F000
	s_clause 0x7                                               // 000000060E70: BF850007
	global_store_b32 v[68:69], v11, off offset:-4096           // 000000060E74: DC6A1000 007C0B44
	global_store_b32 v[68:69], v12, off                        // 000000060E7C: DC6A0000 007C0C44
	global_store_b32 v[54:55], v14, off offset:-4096           // 000000060E84: DC6A1000 007C0E36
	global_store_b32 v[54:55], v15, off                        // 000000060E8C: DC6A0000 007C0F36
	global_store_b32 v[44:45], v27, off offset:-4096           // 000000060E94: DC6A1000 007C1B2C
	global_store_b32 v[44:45], v28, off                        // 000000060E9C: DC6A0000 007C1C2C
	global_store_b32 v[34:35], v29, off offset:-4096           // 000000060EA4: DC6A1000 007C1D22
	global_store_b32 v[34:35], v30, off                        // 000000060EAC: DC6A0000 007C1E22
	v_add_co_ci_u32_e64 v3, null, 0, v3, vcc_lo                // 000000060EB4: D5207C03 01AA0680
	s_clause 0xf                                               // 000000060EBC: BF85000F
	global_store_b32 v[31:32], v20, off offset:1024            // 000000060EC0: DC6A0400 007C141F
	global_store_b32 v[31:32], v21, off offset:2048            // 000000060EC8: DC6A0800 007C151F
	global_store_b32 v[31:32], v22, off offset:3072            // 000000060ED0: DC6A0C00 007C161F
	global_store_b32 v[36:37], v23, off offset:1024            // 000000060ED8: DC6A0400 007C1724
	global_store_b32 v[36:37], v24, off offset:2048            // 000000060EE0: DC6A0800 007C1824
	global_store_b32 v[36:37], v26, off offset:3072            // 000000060EE8: DC6A0C00 007C1A24
	global_store_b32 v[2:3], v16, off                          // 000000060EF0: DC6A0000 007C1002
	global_store_b32 v[2:3], v18, off offset:1024              // 000000060EF8: DC6A0400 007C1202
	global_store_b32 v[2:3], v19, off offset:2048              // 000000060F00: DC6A0800 007C1302
	global_store_b32 v[84:85], v4, off offset:-4096            // 000000060F08: DC6A1000 007C0454
	global_store_b32 v[84:85], v5, off                         // 000000060F10: DC6A0000 007C0554
	global_store_b32 v[70:71], v6, off offset:-4096            // 000000060F18: DC6A1000 007C0646
	global_store_b32 v[70:71], v7, off                         // 000000060F20: DC6A0000 007C0746
	global_store_b32 v[61:62], v8, off offset:-4096            // 000000060F28: DC6A1000 007C083D
	global_store_b32 v[61:62], v10, off                        // 000000060F30: DC6A0000 007C0A3D
	global_store_b32 v[2:3], v13, off offset:3072              // 000000060F38: DC6A0C00 007C0D02
	s_branch 60925                                             // 000000060F40: BFA0EDFD <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x938>
	v_mov_b32_e32 v158, v65                                    // 000000060F44: 7F3C0341
	v_mov_b32_e32 v157, v57                                    // 000000060F48: 7F3A0339
	v_mov_b32_e32 v156, v49                                    // 000000060F4C: 7F380331
	v_mov_b32_e32 v155, v41                                    // 000000060F50: 7F360329
	v_mov_b32_e32 v154, v33                                    // 000000060F54: 7F340321
	v_mov_b32_e32 v153, v17                                    // 000000060F58: 7F320311
	v_mov_b32_e32 v152, v25                                    // 000000060F5C: 7F300319
	v_mov_b32_e32 v151, v9                                     // 000000060F60: 7F2E0309
	s_mov_b32 s7, 0                                            // 000000060F64: BE870080
	s_branch 1                                                 // 000000060F68: BFA00001 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x5170>
	s_mov_b64 s[6:7], 0                                        // 000000060F6C: BE860180
	v_dual_mul_f32 v2, 0x3b800000, v139 :: v_dual_mul_f32 v3, 0x3b800000, v138// 000000060F70: C8C716FF 020314FF 3B800000
	v_dual_mul_f32 v4, 0x3b800000, v137 :: v_dual_mul_f32 v5, 0x3b800000, v136// 000000060F7C: C8C712FF 040510FF 3B800000
	.long 0xd7006a00                                           // 000000060F88: D7006A00
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 000000060F8C: 0201FFB9
	.long 0x00002000                                           // 000000060F90: 00002000
	v_dual_mul_f32 v6, 0x3b800000, v135 :: v_dual_mul_f32 v7, 0x3b800000, v134// 000000060F94: C8C70EFF 06070CFF 3B800000
	v_add_co_ci_u32_e64 v1, null, 0, v186, vcc_lo              // 000000060FA0: D5207C01 01AB7480
	v_dual_mul_f32 v8, 0x3b800000, v133 :: v_dual_mul_f32 v9, 0x3b800000, v158// 000000060FA8: C8C70AFF 08093CFF 3B800000
	s_clause 0x7                                               // 000000060FB4: BF850007
	global_store_b32 v[185:186], v2, off                       // 000000060FB8: DC6A0000 007C02B9
	global_store_b32 v[185:186], v3, off offset:1024           // 000000060FC0: DC6A0400 007C03B9
	global_store_b32 v[185:186], v4, off offset:2048           // 000000060FC8: DC6A0800 007C04B9
	global_store_b32 v[185:186], v5, off offset:3072           // 000000060FD0: DC6A0C00 007C05B9
	global_store_b32 v[0:1], v6, off offset:-4096              // 000000060FD8: DC6A1000 007C0600
	global_store_b32 v[0:1], v7, off offset:-3072              // 000000060FE0: DC6A1400 007C0700
	global_store_b32 v[0:1], v8, off offset:-2048              // 000000060FE8: DC6A1800 007C0800
	global_store_b32 v[0:1], v9, off offset:-1024              // 000000060FF0: DC6A1C00 007C0900
	v_dual_mul_f32 v4, 0x3b800000, v132 :: v_dual_mul_f32 v5, 0x3b800000, v131// 000000060FF8: C8C708FF 040506FF 3B800000
	v_dual_mul_f32 v6, 0x3b800000, v130 :: v_dual_mul_f32 v7, 0x3b800000, v129// 000000061004: C8C704FF 060702FF 3B800000
	.long 0xd7006a02                                           // 000000061010: D7006A02
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 000000061014: 0201FFB9
	.long 0x00004000                                           // 000000061018: 00004000
	v_dual_mul_f32 v8, 0x3b800000, v128 :: v_dual_mul_f32 v9, 0x3b800000, v127// 00000006101C: C8C700FF 0808FEFF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v186, vcc_lo              // 000000061028: D5207C03 01AB7480
	v_dual_mul_f32 v10, 0x3b800000, v126 :: v_dual_mul_f32 v11, 0x3b800000, v157// 000000061030: C8C6FCFF 0A0B3AFF 3B800000
	s_clause 0x7                                               // 00000006103C: BF850007
	global_store_b32 v[0:1], v4, off                           // 000000061040: DC6A0000 007C0400
	global_store_b32 v[0:1], v5, off offset:1024               // 000000061048: DC6A0400 007C0500
	global_store_b32 v[0:1], v6, off offset:2048               // 000000061050: DC6A0800 007C0600
	global_store_b32 v[0:1], v7, off offset:3072               // 000000061058: DC6A0C00 007C0700
	global_store_b32 v[2:3], v8, off offset:-4096              // 000000061060: DC6A1000 007C0802
	global_store_b32 v[2:3], v9, off offset:-3072              // 000000061068: DC6A1400 007C0902
	global_store_b32 v[2:3], v10, off offset:-2048             // 000000061070: DC6A1800 007C0A02
	global_store_b32 v[2:3], v11, off offset:-1024             // 000000061078: DC6A1C00 007C0B02
	v_dual_mul_f32 v4, 0x3b800000, v125 :: v_dual_mul_f32 v5, 0x3b800000, v124// 000000061080: C8C6FAFF 0404F8FF 3B800000
	v_dual_mul_f32 v6, 0x3b800000, v123 :: v_dual_mul_f32 v7, 0x3b800000, v122// 00000006108C: C8C6F6FF 0606F4FF 3B800000
	.long 0xd7006a00                                           // 000000061098: D7006A00
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 00000006109C: 0201FFB9
	.long 0x00006000                                           // 0000000610A0: 00006000
	v_dual_mul_f32 v8, 0x3b800000, v121 :: v_dual_mul_f32 v9, 0x3b800000, v120// 0000000610A4: C8C6F2FF 0808F0FF 3B800000
	v_add_co_ci_u32_e64 v1, null, 0, v186, vcc_lo              // 0000000610B0: D5207C01 01AB7480
	v_dual_mul_f32 v10, 0x3b800000, v119 :: v_dual_mul_f32 v11, 0x3b800000, v156// 0000000610B8: C8C6EEFF 0A0B38FF 3B800000
	s_clause 0x7                                               // 0000000610C4: BF850007
	global_store_b32 v[2:3], v4, off                           // 0000000610C8: DC6A0000 007C0402
	global_store_b32 v[2:3], v5, off offset:1024               // 0000000610D0: DC6A0400 007C0502
	global_store_b32 v[2:3], v6, off offset:2048               // 0000000610D8: DC6A0800 007C0602
	global_store_b32 v[2:3], v7, off offset:3072               // 0000000610E0: DC6A0C00 007C0702
	global_store_b32 v[0:1], v8, off offset:-4096              // 0000000610E8: DC6A1000 007C0800
	global_store_b32 v[0:1], v9, off offset:-3072              // 0000000610F0: DC6A1400 007C0900
	global_store_b32 v[0:1], v10, off offset:-2048             // 0000000610F8: DC6A1800 007C0A00
	global_store_b32 v[0:1], v11, off offset:-1024             // 000000061100: DC6A1C00 007C0B00
	v_dual_mul_f32 v4, 0x3b800000, v118 :: v_dual_mul_f32 v5, 0x3b800000, v117// 000000061108: C8C6ECFF 0404EAFF 3B800000
	v_dual_mul_f32 v6, 0x3b800000, v116 :: v_dual_mul_f32 v7, 0x3b800000, v115// 000000061114: C8C6E8FF 0606E6FF 3B800000
	.long 0xd7006a02                                           // 000000061120: D7006A02
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 000000061124: 0201FFB9
	.long 0x00008000                                           // 000000061128: 00008000
	v_dual_mul_f32 v8, 0x3b800000, v114 :: v_dual_mul_f32 v9, 0x3b800000, v113// 00000006112C: C8C6E4FF 0808E2FF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v186, vcc_lo              // 000000061138: D5207C03 01AB7480
	v_dual_mul_f32 v10, 0x3b800000, v112 :: v_dual_mul_f32 v11, 0x3b800000, v155// 000000061140: C8C6E0FF 0A0B36FF 3B800000
	s_clause 0x7                                               // 00000006114C: BF850007
	global_store_b32 v[0:1], v4, off                           // 000000061150: DC6A0000 007C0400
	global_store_b32 v[0:1], v5, off offset:1024               // 000000061158: DC6A0400 007C0500
	global_store_b32 v[0:1], v6, off offset:2048               // 000000061160: DC6A0800 007C0600
	global_store_b32 v[0:1], v7, off offset:3072               // 000000061168: DC6A0C00 007C0700
	global_store_b32 v[2:3], v8, off offset:-4096              // 000000061170: DC6A1000 007C0802
	global_store_b32 v[2:3], v9, off offset:-3072              // 000000061178: DC6A1400 007C0902
	global_store_b32 v[2:3], v10, off offset:-2048             // 000000061180: DC6A1800 007C0A02
	global_store_b32 v[2:3], v11, off offset:-1024             // 000000061188: DC6A1C00 007C0B02
	v_dual_mul_f32 v4, 0x3b800000, v111 :: v_dual_mul_f32 v5, 0x3b800000, v110// 000000061190: C8C6DEFF 0404DCFF 3B800000
	v_dual_mul_f32 v6, 0x3b800000, v109 :: v_dual_mul_f32 v7, 0x3b800000, v108// 00000006119C: C8C6DAFF 0606D8FF 3B800000
	.long 0xd7006a00                                           // 0000000611A8: D7006A00
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 0000000611AC: 0201FFB9
	.long 0x0000a000                                           // 0000000611B0: 0000A000
	v_dual_mul_f32 v8, 0x3b800000, v107 :: v_dual_mul_f32 v9, 0x3b800000, v106// 0000000611B4: C8C6D6FF 0808D4FF 3B800000
	v_add_co_ci_u32_e64 v1, null, 0, v186, vcc_lo              // 0000000611C0: D5207C01 01AB7480
	v_dual_mul_f32 v10, 0x3b800000, v105 :: v_dual_mul_f32 v11, 0x3b800000, v154// 0000000611C8: C8C6D2FF 0A0B34FF 3B800000
	s_clause 0x7                                               // 0000000611D4: BF850007
	global_store_b32 v[2:3], v4, off                           // 0000000611D8: DC6A0000 007C0402
	global_store_b32 v[2:3], v5, off offset:1024               // 0000000611E0: DC6A0400 007C0502
	global_store_b32 v[2:3], v6, off offset:2048               // 0000000611E8: DC6A0800 007C0602
	global_store_b32 v[2:3], v7, off offset:3072               // 0000000611F0: DC6A0C00 007C0702
	global_store_b32 v[0:1], v8, off offset:-4096              // 0000000611F8: DC6A1000 007C0800
	global_store_b32 v[0:1], v9, off offset:-3072              // 000000061200: DC6A1400 007C0900
	global_store_b32 v[0:1], v10, off offset:-2048             // 000000061208: DC6A1800 007C0A00
	global_store_b32 v[0:1], v11, off offset:-1024             // 000000061210: DC6A1C00 007C0B00
	v_dual_mul_f32 v4, 0x3b800000, v104 :: v_dual_mul_f32 v5, 0x3b800000, v103// 000000061218: C8C6D0FF 0404CEFF 3B800000
	v_dual_mul_f32 v6, 0x3b800000, v102 :: v_dual_mul_f32 v7, 0x3b800000, v101// 000000061224: C8C6CCFF 0606CAFF 3B800000
	.long 0xd7006a02                                           // 000000061230: D7006A02
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 000000061234: 0201FFB9
	.long 0x0000c000                                           // 000000061238: 0000C000
	v_dual_mul_f32 v8, 0x3b800000, v100 :: v_dual_mul_f32 v9, 0x3b800000, v99// 00000006123C: C8C6C8FF 0808C6FF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v186, vcc_lo              // 000000061248: D5207C03 01AB7480
	v_dual_mul_f32 v10, 0x3b800000, v98 :: v_dual_mul_f32 v11, 0x3b800000, v153// 000000061250: C8C6C4FF 0A0B32FF 3B800000
	s_clause 0x7                                               // 00000006125C: BF850007
	global_store_b32 v[0:1], v4, off                           // 000000061260: DC6A0000 007C0400
	global_store_b32 v[0:1], v5, off offset:1024               // 000000061268: DC6A0400 007C0500
	global_store_b32 v[0:1], v6, off offset:2048               // 000000061270: DC6A0800 007C0600
	global_store_b32 v[0:1], v7, off offset:3072               // 000000061278: DC6A0C00 007C0700
	global_store_b32 v[2:3], v8, off offset:-4096              // 000000061280: DC6A1000 007C0802
	global_store_b32 v[2:3], v9, off offset:-3072              // 000000061288: DC6A1400 007C0902
	global_store_b32 v[2:3], v10, off offset:-2048             // 000000061290: DC6A1800 007C0A02
	global_store_b32 v[2:3], v11, off offset:-1024             // 000000061298: DC6A1C00 007C0B02
	v_dual_mul_f32 v4, 0x3b800000, v143 :: v_dual_mul_f32 v5, 0x3b800000, v149// 0000000612A0: C8C71EFF 04052AFF 3B800000
	v_dual_mul_f32 v6, 0x3b800000, v148 :: v_dual_mul_f32 v7, 0x3b800000, v147// 0000000612AC: C8C728FF 060726FF 3B800000
	.long 0xd7006a00                                           // 0000000612B8: D7006A00
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 0000000612BC: 0201FFB9
	.long 0x0000e000                                           // 0000000612C0: 0000E000
	v_dual_mul_f32 v8, 0x3b800000, v146 :: v_dual_mul_f32 v9, 0x3b800000, v145// 0000000612C4: C8C724FF 080922FF 3B800000
	v_add_co_ci_u32_e64 v1, null, 0, v186, vcc_lo              // 0000000612D0: D5207C01 01AB7480
	v_dual_mul_f32 v10, 0x3b800000, v141 :: v_dual_mul_f32 v11, 0x3b800000, v152// 0000000612D8: C8C71AFF 0A0B30FF 3B800000
	s_clause 0x7                                               // 0000000612E4: BF850007
	global_store_b32 v[2:3], v4, off                           // 0000000612E8: DC6A0000 007C0402
	global_store_b32 v[2:3], v5, off offset:1024               // 0000000612F0: DC6A0400 007C0502
	global_store_b32 v[2:3], v6, off offset:2048               // 0000000612F8: DC6A0800 007C0602
	global_store_b32 v[2:3], v7, off offset:3072               // 000000061300: DC6A0C00 007C0702
	global_store_b32 v[0:1], v8, off offset:-4096              // 000000061308: DC6A1000 007C0800
	global_store_b32 v[0:1], v9, off offset:-3072              // 000000061310: DC6A1400 007C0900
	global_store_b32 v[0:1], v10, off offset:-2048             // 000000061318: DC6A1800 007C0A00
	global_store_b32 v[0:1], v11, off offset:-1024             // 000000061320: DC6A1C00 007C0B00
	v_dual_mul_f32 v4, 0x3b800000, v150 :: v_dual_mul_f32 v11, 0x3b800000, v188// 000000061328: C8C72CFF 040B78FF 3B800000
	v_and_or_b32 v9, v71, 31, s5                               // 000000061334: D6570009 00153F47
	v_dual_mul_f32 v5, 0x3b800000, v142 :: v_dual_mul_f32 v6, 0x3b800000, v191// 00000006133C: C8C71CFF 05077EFF 3B800000
	.long 0xd7006a02                                           // 000000061348: D7006A02
	v_cndmask_b32_e32 v0, v185, v255, vcc_lo                   // 00000006134C: 0201FFB9
	.long 0x0000fc00                                           // 000000061350: 0000FC00
	v_dual_mul_f32 v7, 0x3b800000, v190 :: v_dual_mul_f32 v8, 0x3b800000, v189// 000000061354: C8C77CFF 07097AFF 3B800000
	v_add_co_ci_u32_e64 v3, null, 0, v186, vcc_lo              // 000000061360: D5207C03 01AB7480
	v_mul_f32_e32 v10, 0x3b800000, v187                        // 000000061368: 101576FF 3B800000
	v_mul_f32_e32 v12, 0x3b800000, v151                        // 000000061370: 10192EFF 3B800000
	s_clause 0x7                                               // 000000061378: BF850007
	global_store_b32 v[0:1], v4, off                           // 00000006137C: DC6A0000 007C0400
	global_store_b32 v[0:1], v5, off offset:1024               // 000000061384: DC6A0400 007C0500
	global_store_b32 v[0:1], v6, off offset:2048               // 00000006138C: DC6A0800 007C0600
	global_store_b32 v[0:1], v7, off offset:3072               // 000000061394: DC6A0C00 007C0700
	global_store_b32 v[2:3], v8, off offset:-3072              // 00000006139C: DC6A1400 007C0802
	global_store_b32 v[2:3], v10, off offset:-2048             // 0000000613A4: DC6A1800 007C0A02
	global_store_b32 v[2:3], v11, off offset:-1024             // 0000000613AC: DC6A1C00 007C0B02
	global_store_b32 v[2:3], v12, off                          // 0000000613B4: DC6A0000 007C0C02
	s_mov_b32 s2, exec_lo                                      // 0000000613BC: BE82007E
	v_cmpx_eq_u32_e32 0, v9                                    // 0000000613C0: 7D941280
	s_cbranch_execz 8                                          // 0000000613C4: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dn_fused16ILi11ELb0ELb0ELb0EEEvPKtPKfS5_PfPKilPtiPyNS0_7DnfTapsENS0_7DnfNormE+0x55e8>
	s_load_b64 s[0:1], s[0:1], 0x40                            // 0000000613C8: F4040000 F8000040
	v_mov_b32_e32 v0, s6                                       // 0000000613D0: 7E000206
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, s7              // 0000000613D4: CA100080 02000007
	s_waitcnt lgkmcnt(0)                                       // 0000000613DC: BF89FC07
	global_store_b64 v2, v[0:1], s[0:1] offset:80              // 0000000613E0: DC6E0050 00000002
	s_endpgm                                                   // 0000000613E8: BFB00000
		...

