00000000001c4e00 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE():
	s_load_b256 s[16:23], s[0:1], 0x38                         // 0000001C4E00: F40C0400 F8000038
	s_lshl_b32 s6, s3, 6                                       // 0000001C4E08: 84068603
	s_ashr_i32 s3, s2, 31                                      // 0000001C4E0C: 86039F02
	s_ashr_i32 s7, s6, 31                                      // 0000001C4E10: 86079F06
	v_and_b32_e32 v1, 63, v0                                   // 0000001C4E14: 360200BF
	v_mov_b32_e32 v5, v0                                       // 0000001C4E18: 7E0A0300
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001C4E1C: BF8704D2
	v_lshlrev_b32_e32 v3, 2, v1                                // 0000001C4E20: 30060282
	v_mul_u32_u24_e32 v2, 0x210, v1                            // 0000001C4E24: 160402FF 00000210
	s_waitcnt lgkmcnt(0)                                       // 0000001C4E2C: BF89FC07
	s_load_b32 s4, s[18:19], null                              // 0000001C4E30: F4000109 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000001C4E38: 84928214
	s_add_u32 s5, s16, s18                                     // 0000001C4E3C: 80051210
	s_addc_u32 s8, s17, s19                                    // 0000001C4E40: 82081311
	s_lshl_b64 s[34:35], s[2:3], 16                            // 0000001C4E44: 84A29002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001C4E48: BF870009
	s_add_u32 s5, s5, s34                                      // 0000001C4E4C: 80052205
	s_addc_u32 s8, s8, s35                                     // 0000001C4E50: 82082308
	s_waitcnt lgkmcnt(0)                                       // 0000001C4E54: BF89FC07
	s_mul_i32 s46, s4, 0x9000000                               // 0000001C4E58: 962EFF04 09000000
	s_mul_hi_i32 s33, s4, 0x9000000                            // 0000001C4E60: 9721FF04 09000000
	s_add_u32 s4, s5, s46                                      // 0000001C4E68: 80042E05
	s_addc_u32 s5, s8, s33                                     // 0000001C4E6C: 82052108
	s_lshl_b64 s[44:45], s[6:7], 2                             // 0000001C4E70: 84AC8206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001C4E74: BF8700B9
	s_add_u32 s4, s4, s44                                      // 0000001C4E78: 80042C04
	s_addc_u32 s5, s5, s45                                     // 0000001C4E7C: 82052D05
	.long 0xd7000403                                           // 0000001C4E80: D7000403
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 0000001C4E84: 02020604
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 0000001C4E88: D5207C04 00110005
	s_mov_b32 s4, 0                                            // 0000001C4E90: BE840080
	s_nop 0                                                    // 0000001C4E94: BF800000
	s_nop 0                                                    // 0000001C4E98: BF800000
	s_nop 0                                                    // 0000001C4E9C: BF800000
	s_nop 0                                                    // 0000001C4EA0: BF800000
	s_nop 0                                                    // 0000001C4EA4: BF800000
	s_nop 0                                                    // 0000001C4EA8: BF800000
	s_nop 0                                                    // 0000001C4EAC: BF800000
	s_nop 0                                                    // 0000001C4EB0: BF800000
	s_nop 0                                                    // 0000001C4EB4: BF800000
	s_nop 0                                                    // 0000001C4EB8: BF800000
	s_nop 0                                                    // 0000001C4EBC: BF800000
	v_lshrrev_b32_e32 v8, 6, v5                                // 0000001C4EC0: 32100A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001C4EC4: BF870121
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000001C4EC8: 300C1089
	v_lshl_add_u32 v8, v8, 2, v2                               // 0000001C4ECC: D6460008 04090508
	.long 0xd7006a06                                           // 0000001C4ED4: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 0000001C4ED8: 02020D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001C4EDC: BF8700D1
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 0000001C4EE0: D5207C07 01AA0880
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v5                        // 0000001C4EE8: 7C920AFF 00001F7F
	global_load_b32 v6, v[6:7], off                            // 0000001C4EF0: DC520000 067C0006
	v_add_nc_u32_e32 v7, 0x80, v5                              // 0000001C4EF8: 4A0E0AFF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 0000001C4F00: 8C04046A
	v_mov_b32_e32 v5, v7                                       // 0000001C4F04: 7E0A0307
	s_waitcnt vmcnt(0)                                         // 0000001C4F08: BF8903F7
	ds_store_b32 v8, v6                                        // 0000001C4F0C: D8340000 00000608
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001C4F14: 917E047E
	s_cbranch_execnz 65513                                     // 0000001C4F18: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001C4F1C: 8C7E047E
	s_load_b32 s47, s[0:1], 0x58                               // 0000001C4F20: F4000BC0 F8000058
	v_or_b32_e32 v204, 0xffffff80, v0                          // 0000001C4F28: 399800FF FFFFFF80
	v_lshlrev_b32_e32 v5, 3, v0                                // 0000001C4F30: 300A0083
	v_lshlrev_b32_e32 v203, 2, v1                              // 0000001C4F34: 31960282
	v_mul_u32_u24_e32 v3, 0x210, v1                            // 0000001C4F38: 160602FF 00000210
	v_lshrrev_b32_e32 v4, 4, v0                                // 0000001C4F40: 32080084
	s_mov_b32 s4, 0                                            // 0000001C4F44: BE840080
	s_waitcnt lgkmcnt(0)                                       // 0000001C4F48: BF89FC07
	s_barrier                                                  // 0000001C4F4C: BFBD0000
	buffer_gl0_inv                                             // 0000001C4F50: E0AC0000 00000000
	s_cmp_gt_i32 s47, 0                                        // 0000001C4F58: BF02802F
	s_cbranch_scc1 14                                          // 0000001C4F5C: BFA2000E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	v_dual_mov_b32 v194, 0 :: v_dual_and_b32 v193, 0x200, v5   // 0000001C4F60: CA240080 C2C00AFF 00000200
	v_or_b32_e32 v6, 0xffffff80, v0                            // 0000001C4F6C: 380C00FF FFFFFF80
	v_and_or_b32 v209, v4, 4, v3                               // 0000001C4F74: D65700D1 040D0904
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C4F7C: BF870003
	v_dual_mov_b32 v1, s44 :: v_dual_mov_b32 v216, v194        // 0000001C4F80: CA10002C 01D801C2
	v_mov_b32_e32 v2, s45                                      // 0000001C4F88: 7E04022D
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 0000001C4F8C: 916A047E
	s_cbranch_vccz 1                                           // 0000001C4F90: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	s_branch 7261                                              // 0000001C4F94: BFA01C5D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x730c>
	s_clause 0x3                                               // 0000001C4F98: BF850003
	s_load_b128 s[12:15], s[0:1], 0x10                         // 0000001C4F9C: F4080300 F8000010
	s_load_b64 s[8:9], s[0:1], 0x20                            // 0000001C4FA4: F4040200 F8000020
	s_load_b64 s[10:11], s[0:1], 0x70                          // 0000001C4FAC: F4040280 F8000070
	s_load_b128 s[28:31], s[0:1], 0x60                         // 0000001C4FB4: F4080700 F8000060
	v_lshlrev_b32_e32 v2, 2, v0                                // 0000001C4FBC: 30040082
	v_lshrrev_b32_e32 v1, 5, v0                                // 0000001C4FC0: 32020085
	s_add_i32 s20, s47, 63                                     // 0000001C4FC4: 8114BF2F
	s_add_i32 s49, s47, -1                                     // 0000001C4FC8: 8131C12F
	s_lshr_b32 s50, s20, 6                                     // 0000001C4FCC: 85328614
	s_mul_i32 s20, s49, 48                                     // 0000001C4FD0: 9614B031
	s_add_i32 s48, s2, 0xbd0                                   // 0000001C4FD4: 8130FF02 00000BD0
	s_mul_hi_u32 s21, s49, 48                                  // 0000001C4FDC: 9695B031
	s_add_u32 s20, s20, s2                                     // 0000001C4FE0: 80140214
	v_or_b32_e32 v205, 0xf000, v2                              // 0000001C4FE4: 399A04FF 0000F000
	v_add_nc_u32_e32 v206, 0xf100, v2                          // 0000001C4FEC: 4B9C04FF 0000F100
	s_addc_u32 s21, s21, s3                                    // 0000001C4FF4: 82150315
	v_and_b32_e32 v6, 15, v0                                   // 0000001C4FF8: 360C008F
	v_bfe_u32 v7, v0, 4, 1                                     // 0000001C4FFC: D6100007 02050900
	v_mul_u32_u24_e32 v8, 0x2100, v1                           // 0000001C5004: 161002FF 00002100
	s_load_b256 s[36:43], s[0:1], 0x80                         // 0000001C500C: F40C0900 F8000080
	s_waitcnt lgkmcnt(0)                                       // 0000001C5014: BF89FC07
	.long 0xd7000ccf                                           // 0000001C5018: D7000CCF
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000001C501C: 0202040C
	v_lshlrev_b32_e32 v2, 4, v1                                // 0000001C5020: 30040284
	v_add_co_ci_u32_e64 v208, null, s13, 0, s12                // 0000001C5024: D5207CD0 0031000D
	s_lshl_b64 s[12:13], s[20:21], 9                           // 0000001C502C: 848C8914
	s_mov_b32 s21, 0xcc00                                      // 0000001C5030: BE9500FF 0000CC00
	.long 0xd7006ad2                                           // 0000001C5038: D7006AD2
	v_cndmask_b32_e32 v0, v207, v12, vcc_lo                    // 0000001C503C: 020019CF
	v_or_b32_e32 v213, v2, v6                                  // 0000001C5040: 39AA0D02
	s_add_u32 s12, s8, s44                                     // 0000001C5044: 800C2C08
	v_add_co_ci_u32_e64 v211, null, s13, v208, vcc_lo          // 0000001C5048: D5207CD3 01ABA00D
	s_addc_u32 s13, s9, s45                                    // 0000001C5050: 820D2D09
	s_lshl_b32 s8, s2, 7                                       // 0000001C5054: 84088702
	v_or_b32_e32 v217, v2, v7                                  // 0000001C5058: 39B20F02
	v_mad_u32_u24 v2, 0x210, v6, v8                            // 0000001C505C: D60B0002 04220CFF 00000210
	s_ashr_i32 s9, s8, 31                                      // 0000001C5068: 86099F08
	v_lshlrev_b32_e32 v8, 7, v213                              // 0000001C506C: 3011AA87
	s_lshl_b64 s[8:9], s[8:9], 1                               // 0000001C5070: 84888108
	s_load_b64 s[0:1], s[0:1], 0xa0                            // 0000001C5074: F4040000 F80000A0
	s_add_u32 s8, s22, s8                                      // 0000001C507C: 80080816
	v_lshl_or_b32 v220, v7, 2, v2                              // 0000001C5080: D65600DC 04090507
	v_lshlrev_b32_e32 v2, 2, v6                                // 0000001C5088: 30040C82
	s_addc_u32 s9, s23, s9                                     // 0000001C508C: 82090917
	s_lshl_b64 s[6:7], s[6:7], 1                               // 0000001C5090: 84868106
	v_dual_mov_b32 v194, 0 :: v_dual_and_b32 v193, 0x200, v5   // 0000001C5094: CA240080 C2C00AFF 00000200
	s_add_u32 s8, s8, s6                                       // 0000001C50A0: 80080608
	.long 0xd70006dd                                           // 0000001C50A4: D70006DD
	v_cndmask_b32_e32 v1, s10, v8, vcc_lo                      // 0000001C50A8: 0202100A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C50AC: BF870001
	v_add_co_ci_u32_e64 v222, null, s11, 0, s6                 // 0000001C50B0: D5207CDE 0019000B
	.long 0xd70006df                                           // 0000001C50B8: D70006DF
	v_cndmask_b32_e32 v1, s12, v2, vcc_lo                      // 0000001C50BC: 0202040C
	v_lshlrev_b32_e32 v2, 1, v6                                // 0000001C50C0: 30040C81
	v_mad_u32_u24 v215, 0x90, v6, s21                          // 0000001C50C4: D60B00D7 00560CFF 00000090
	s_addc_u32 s9, s9, s7                                      // 0000001C50D0: 82090709
	v_add_co_ci_u32_e64 v224, null, s13, 0, s6                 // 0000001C50D4: D5207CE0 0019000D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C50DC: BF870093
	.long 0xd70008c3                                           // 0000001C50E0: D70008C3
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 0000001C50E4: 02020408
	v_add_co_ci_u32_e64 v196, null, s9, 0, s8                  // 0000001C50E8: D5207CC4 00210009
	s_add_u32 s8, s44, s34                                     // 0000001C50F0: 8008222C
	v_mad_u32_u24 v218, 0x900, v1, v215                        // 0000001C50F4: D60B00DA 075E02FF 00000900
	.long 0xd44d0006                                           // 0000001C5100: D44D0006
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 0000001C5104: 02020280
	s_addc_u32 s9, s45, s35                                    // 0000001C5108: 8209232D
	.long 0xd7000801                                           // 0000001C510C: D7000801
	v_cndmask_b32_e32 v1, s8, v193, vcc_lo                     // 0000001C5110: 02038208
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001C5114: BF8700B1
	v_add_co_ci_u32_e64 v2, null, s9, 0, s8                    // 0000001C5118: D5207C02 00210009
	s_movk_i32 s20, 0x90                                       // 0000001C5120: B0140090
	.long 0xd7006a01                                           // 0000001C5124: D7006A01
	v_cndmask_b32_e32 v1, v1, v203, vcc_lo                     // 0000001C5128: 02039701
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000001C512C: D5207C02 01AA0480
	.long 0xd44c0004                                           // 0000001C5134: D44C0004
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 0000001C5138: 020200C0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C513C: BF870093
	.long 0xd7006ac5                                           // 0000001C5140: D7006AC5
	v_cndmask_b32_e32 v1, s40, v1, vcc_lo                      // 0000001C5144: 02020228
	v_add_co_ci_u32_e64 v198, null, s41, v2, vcc_lo            // 0000001C5148: D5207CC6 01AA0429
	.long 0xd7006ac7                                           // 0000001C5150: D7006AC7
	v_cndmask_b32_e32 v1, s42, v1, vcc_lo                      // 0000001C5154: 0202022A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5158: BF870001
	v_add_co_ci_u32_e64 v200, null, s43, v2, vcc_lo            // 0000001C515C: D5207CC8 01AA042B
	s_waitcnt lgkmcnt(0)                                       // 0000001C5164: BF89FC07
	.long 0xd7006ac9                                           // 0000001C5168: D7006AC9
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 0000001C516C: 02020200
	.long 0xd4490005                                           // 0000001C5170: D4490005
	v_cndmask_b32_e32 v1, 63, v0, vcc_lo                       // 0000001C5174: 020200BF
	v_mad_u32_u24 v212, v0, s20, 0x8400                        // 0000001C5178: D60B00D4 03FC2900 00008400
	v_mul_u32_u24_e32 v214, 0x210, v6                          // 0000001C5184: 17AC0CFF 00000210
	v_mad_u32_u24 v219, v6, s20, 0x8400                        // 0000001C518C: D60B00DB 03FC2906 00008400
	v_lshl_add_u32 v225, v217, 1, v215                         // 0000001C5198: D64600E1 075D03D9
	.long 0xd4490007                                           // 0000001C51A0: D4490007
	v_cndmask_b32_e32 v1, 0x5f, v0, vcc_lo                     // 0000001C51A4: 020200FF 0000005F
	v_lshl_or_b32 v226, v217, 2, 0xf100                        // 0000001C51AC: D65600E2 03FD05D9 0000F100
	v_mov_b32_e32 v216, v194                                   // 0000001C51B8: 7FB003C2
	v_and_or_b32 v209, v4, 4, v3                               // 0000001C51BC: D65700D1 040D0904
	v_add_co_ci_u32_e64 v202, null, s1, v2, vcc_lo             // 0000001C51C4: D5207CCA 01AA0401
	s_mov_b32 s20, 0                                           // 0000001C51CC: BE940080
	s_mov_b32 s39, 0x41800000                                  // 0000001C51D0: BEA700FF 41800000
	s_mov_b32 s21, s20                                         // 0000001C51D8: BE950014
	s_mov_b32 s22, s20                                         // 0000001C51DC: BE960014
	s_mov_b32 s23, s20                                         // 0000001C51E0: BE970014
	s_mov_b32 s24, s20                                         // 0000001C51E4: BE980014
	s_mov_b32 s25, s20                                         // 0000001C51E8: BE990014
	s_mov_b32 s26, s20                                         // 0000001C51EC: BE9A0014
	s_mov_b32 s27, s20                                         // 0000001C51F0: BE9B0014
	s_mov_b32 s40, s20                                         // 0000001C51F4: BEA80014
	s_branch 4                                                 // 0000001C51F8: BFA00004 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x40c>
	s_add_i32 s40, s40, 1                                      // 0000001C51FC: 81288128
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001C5200: BF870009
	s_cmp_eq_u32 s40, s50                                      // 0000001C5204: BF063228
	s_cbranch_scc1 7101                                        // 0000001C5208: BFA21BBD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7300>
	s_mul_i32 s0, s40, 0xc00                                   // 0000001C520C: 9600FF28 00000C00
	s_lshl_b32 s42, s40, 6                                     // 0000001C5214: 842A8628
	s_add_i32 s8, s48, s0                                      // 0000001C5218: 81080030
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001C521C: BF870499
	s_ashr_i32 s9, s8, 31                                      // 0000001C5220: 86099F08
	s_lshl_b64 s[8:9], s[8:9], 2                               // 0000001C5224: 84888208
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001C5228: BF870009
	s_add_u32 s8, s14, s8                                      // 0000001C522C: 8008080E
	s_addc_u32 s9, s15, s9                                     // 0000001C5230: 8209090F
	global_load_b32 v1, v194, s[8:9]                           // 0000001C5234: DC520000 010800C2
	s_waitcnt vmcnt(0)                                         // 0000001C523C: BF8903F7
	v_readfirstlane_b32 s41, v1                                // 0000001C5240: 7E520501
	s_and_saveexec_b32 s1, s4                                  // 0000001C5244: BE812004
	s_cbranch_execz 69                                         // 0000001C5248: BFA50045 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x560>
	v_or_b32_e32 v1, s42, v0                                   // 0000001C524C: 3802002A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C5250: BF870091
	v_mad_u64_u32 v[1:2], null, v1, 48, s[2:3]                 // 0000001C5254: D6FE7C01 00096101
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000001C525C: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C5260: BF870091
	.long 0xd73c0001                                           // 0000001C5264: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000001C5268: 02020282
	.long 0xd7006a01                                           // 0000001C526C: D7006A01
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 0000001C5270: 0202020E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001C5274: BF8700C1
	v_add_co_ci_u32_e64 v2, null, s15, v2, vcc_lo              // 0000001C5278: D5207C02 01AA040F
	global_load_b32 v1, v[1:2], off                            // 0000001C5280: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001C5288: BF8903F7
	v_sub_f32_e32 v2, s41, v1                                  // 0000001C528C: 08040229
	v_dual_mul_f32 v4, 0x3fb8aa3b, v1 :: v_dual_mul_f32 v3, 0x3fb8aa3b, v2// 0000001C5290: C8C602FF 040204FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001C529C: BF8701A1
	v_rndne_f32_e32 v8, v4                                     // 0000001C52A0: 7E104704
	v_fma_f32 v7, 0x3fb8aa3b, v1, -v4                          // 0000001C52A4: D6130007 841202FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v2, -v3                          // 0000001C52B0: D6130005 840E04FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 0000001C52BC: 7E0C4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001C52C0: BF870191
	v_dual_sub_f32 v4, v4, v8 :: v_dual_sub_f32 v3, v3, v6     // 0000001C52C4: C94A1104 04020D03
	v_fmac_f32_e32 v5, 0x32a5705f, v2                          // 0000001C52CC: 560A04FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2                   // 0000001C52D4: 7C3604FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001C52DC: BF8701B2
	v_add_f32_e32 v3, v3, v5                                   // 0000001C52E0: 06060B03
	v_cvt_i32_f32_e32 v5, v6                                   // 0000001C52E4: 7E0A1106
	v_cvt_i32_f32_e32 v6, v8                                   // 0000001C52E8: 7E0C1108
	v_exp_f32_e32 v3, v3                                       // 0000001C52EC: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C52F0: BF870095
	.long 0xd71c0003                                           // 0000001C52F4: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000001C52F8: 02020B03
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 0000001C52FC: 02060680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 0000001C5300: 7C3602FF C2CE8ED0
	v_fmac_f32_e32 v7, 0x32a5705f, v1                          // 0000001C5308: 560E02FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C5310: BF870091
	v_add_f32_e32 v4, v4, v7                                   // 0000001C5314: 06080F04
	v_exp_f32_e32 v4, v4                                       // 0000001C5318: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C531C: BF870095
	.long 0xd71c0004                                           // 0000001C5320: D71C0004
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000001C5324: 02020D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 0000001C5328: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2                   // 0000001C532C: 7C3C04FF 42B17218
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo               // 0000001C5334: 020406FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 0000001C533C: 7C3C02FF 42B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001C5344: BF870004
	v_cndmask_b32_e32 v1, 0x7f800000, v4, vcc_lo               // 0000001C5348: 020208FF 7F800000
	ds_store_b32 v205, v2                                      // 0000001C5350: D8340000 000002CD
	ds_store_b32 v206, v1                                      // 0000001C5358: D8340000 000001CE
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001C5360: 8C7E017E
	s_sub_i32 s8, s47, s42                                     // 0000001C5364: 81882A2F
	s_mul_hi_u32 s1, s40, 0xc00                                // 0000001C5368: 9681FF28 00000C00
	s_add_u32 s0, s0, s2                                       // 0000001C5370: 80000200
	s_addc_u32 s1, s1, s3                                      // 0000001C5374: 82010301
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001C5378: BF8700B9
	s_lshl_b64 s[10:11], s[0:1], 9                             // 0000001C537C: 848A8900
	s_cmp_gt_i32 s8, 0                                         // 0000001C5380: BF028008
	.long 0xd7006a01                                           // 0000001C5384: D7006A01
	v_cndmask_b32_e32 v0, v207, v10, vcc_lo                    // 0000001C5388: 020015CF
	v_add_co_ci_u32_e64 v2, null, s11, v208, vcc_lo            // 0000001C538C: D5207C02 01ABA00B
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5394: 986A80C1
	s_cmp_gt_i32 s8, 1                                         // 0000001C5398: BF028108
	v_dual_cndmask_b32 v3, v210, v1 :: v_dual_cndmask_b32 v4, v211, v2// 0000001C539C: CA5203D2 030405D3
	global_load_b32 v11, v[3:4], off                           // 0000001C53A4: DC520000 0B7C0003
	.long 0xd7006a03                                           // 0000001C53AC: D7006A03
	v_cndmask_b32_e32 v1, 0x6000, v1, vcc_lo                   // 0000001C53B0: 020202FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C53B8: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001C53BC: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001C53C4: D7006A05
	v_cndmask_b32_e32 v1, 0xc000, v1, vcc_lo                   // 0000001C53C8: 020202FF 0000C000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C53D0: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C53D8: 986A80C1
	s_cmp_gt_i32 s8, 2                                         // 0000001C53DC: BF028208
	v_dual_cndmask_b32 v4, v211, v4 :: v_dual_cndmask_b32 v3, v210, v3// 0000001C53E0: CA5209D3 040207D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C53E8: 986A80C1
	s_cmp_gt_i32 s8, 3                                         // 0000001C53EC: BF028308
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C53F0: CA520DD3 06040BD2
	.long 0xd7006a07                                           // 0000001C53F8: D7006A07
	v_cndmask_b32_e32 v1, 0x12000, v1, vcc_lo                  // 0000001C53FC: 020202FF 00012000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5404: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5408: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5410: 986A80C1
	global_load_b32 v12, v[3:4], off                           // 0000001C5414: DC520000 0C7C0003
	global_load_b32 v13, v[5:6], off                           // 0000001C541C: DC520000 0D7C0005
	v_dual_cndmask_b32 v4, v211, v8 :: v_dual_cndmask_b32 v3, v210, v7// 0000001C5424: CA5211D3 04020FD2
	.long 0xd7006a05                                           // 0000001C542C: D7006A05
	v_cndmask_b32_e32 v1, 0x18000, v1, vcc_lo                  // 0000001C5430: 020202FF 00018000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5438: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C543C: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001C5444: D7006A07
	v_cndmask_b32_e32 v1, 0x1e000, v1, vcc_lo                  // 0000001C5448: 020202FF 0001E000
	s_cmp_gt_i32 s8, 4                                         // 0000001C5450: BF028408
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5454: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C545C: 986A80C1
	s_cmp_gt_i32 s8, 5                                         // 0000001C5460: BF028508
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C5464: CA520DD3 06040BD2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C546C: 986A80C1
	s_cmp_gt_i32 s8, 6                                         // 0000001C5470: BF028608
	v_dual_cndmask_b32 v8, v211, v8 :: v_dual_cndmask_b32 v7, v210, v7// 0000001C5474: CA5211D3 08060FD2
	.long 0xd7006a09                                           // 0000001C547C: D7006A09
	v_cndmask_b32_e32 v1, 0x24000, v1, vcc_lo                  // 0000001C5480: 020202FF 00024000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C5488: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001C548C: D5207C0A 01AA0480
	.long 0xd7006a0e                                           // 0000001C5494: D7006A0E
	v_cndmask_b32_e32 v1, 0x2a000, v1, vcc_lo                  // 0000001C5498: 020202FF 0002A000
	v_add_co_ci_u32_e64 v15, null, 0, v2, vcc_lo               // 0000001C54A0: D5207C0F 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C54A8: 986A80C1
	s_cmp_gt_i32 s8, 7                                         // 0000001C54AC: BF028708
	v_dual_cndmask_b32 v10, v211, v10 :: v_dual_cndmask_b32 v9, v210, v9// 0000001C54B0: CA5215D3 0A0813D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C54B8: 986A80C1
	s_cmp_gt_i32 s8, 8                                         // 0000001C54BC: BF028808
	v_dual_cndmask_b32 v19, v211, v15 :: v_dual_cndmask_b32 v18, v210, v14// 0000001C54C0: CA521FD3 13121DD2
	global_load_b32 v14, v[3:4], off                           // 0000001C54C8: DC520000 0E7C0003
	global_load_b32 v15, v[5:6], off                           // 0000001C54D0: DC520000 0F7C0005
	global_load_b32 v16, v[7:8], off                           // 0000001C54D8: DC520000 107C0007
	global_load_b32 v17, v[9:10], off                          // 0000001C54E0: DC520000 117C0009
	global_load_b32 v18, v[18:19], off                         // 0000001C54E8: DC520000 127C0012
	.long 0xd7006a03                                           // 0000001C54F0: D7006A03
	v_cndmask_b32_e32 v1, 0x30000, v1, vcc_lo                  // 0000001C54F4: 020202FF 00030000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C54FC: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001C5500: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001C5508: D7006A05
	v_cndmask_b32_e32 v1, 0x36000, v1, vcc_lo                  // 0000001C550C: 020202FF 00036000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C5514: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C551C: 986A80C1
	s_cmp_gt_i32 s8, 9                                         // 0000001C5520: BF028908
	v_dual_cndmask_b32 v4, v211, v4 :: v_dual_cndmask_b32 v3, v210, v3// 0000001C5524: CA5209D3 040207D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C552C: 986A80C1
	s_cmp_gt_i32 s8, 10                                        // 0000001C5530: BF028A08
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C5534: CA520DD3 06040BD2
	.long 0xd7006a07                                           // 0000001C553C: D7006A07
	v_cndmask_b32_e32 v1, 0x3c000, v1, vcc_lo                  // 0000001C5540: 020202FF 0003C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5548: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C554C: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5554: 986A80C1
	global_load_b32 v19, v[3:4], off                           // 0000001C5558: DC520000 137C0003
	global_load_b32 v20, v[5:6], off                           // 0000001C5560: DC520000 147C0005
	v_dual_cndmask_b32 v4, v211, v8 :: v_dual_cndmask_b32 v3, v210, v7// 0000001C5568: CA5211D3 04020FD2
	.long 0xd7006a05                                           // 0000001C5570: D7006A05
	v_cndmask_b32_e32 v1, 0x42000, v1, vcc_lo                  // 0000001C5574: 020202FF 00042000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C557C: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C5580: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001C5588: D7006A07
	v_cndmask_b32_e32 v1, 0x48000, v1, vcc_lo                  // 0000001C558C: 020202FF 00048000
	s_cmp_gt_i32 s8, 11                                        // 0000001C5594: BF028B08
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5598: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C55A0: 986A80C1
	s_cmp_gt_i32 s8, 12                                        // 0000001C55A4: BF028C08
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C55A8: CA520DD3 06040BD2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C55B0: 986A80C1
	s_cmp_gt_i32 s8, 13                                        // 0000001C55B4: BF028D08
	v_dual_cndmask_b32 v8, v211, v8 :: v_dual_cndmask_b32 v7, v210, v7// 0000001C55B8: CA5211D3 08060FD2
	.long 0xd7006a09                                           // 0000001C55C0: D7006A09
	v_cndmask_b32_e32 v1, 0x4e000, v1, vcc_lo                  // 0000001C55C4: 020202FF 0004E000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C55CC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001C55D0: D5207C0A 01AA0480
	.long 0xd7006a15                                           // 0000001C55D8: D7006A15
	v_cndmask_b32_e32 v1, 0x54000, v1, vcc_lo                  // 0000001C55DC: 020202FF 00054000
	v_add_co_ci_u32_e64 v22, null, 0, v2, vcc_lo               // 0000001C55E4: D5207C16 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C55EC: 986A80C1
	s_cmp_gt_i32 s8, 14                                        // 0000001C55F0: BF028E08
	v_dual_cndmask_b32 v10, v211, v10 :: v_dual_cndmask_b32 v9, v210, v9// 0000001C55F4: CA5215D3 0A0813D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C55FC: 986A80C1
	s_cmp_gt_i32 s8, 15                                        // 0000001C5600: BF028F08
	v_dual_cndmask_b32 v26, v211, v22 :: v_dual_cndmask_b32 v25, v210, v21// 0000001C5604: CA522DD3 1A182BD2
	global_load_b32 v21, v[3:4], off                           // 0000001C560C: DC520000 157C0003
	global_load_b32 v22, v[5:6], off                           // 0000001C5614: DC520000 167C0005
	global_load_b32 v23, v[7:8], off                           // 0000001C561C: DC520000 177C0007
	global_load_b32 v24, v[9:10], off                          // 0000001C5624: DC520000 187C0009
	global_load_b32 v33, v[25:26], off                         // 0000001C562C: DC520000 217C0019
	.long 0xd7006a03                                           // 0000001C5634: D7006A03
	v_cndmask_b32_e32 v1, 0x5a000, v1, vcc_lo                  // 0000001C5638: 020202FF 0005A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C5640: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001C5644: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001C564C: D7006A05
	v_cndmask_b32_e32 v1, 0x60000, v1, vcc_lo                  // 0000001C5650: 020202FF 00060000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C5658: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5660: 986A80C1
	s_cmp_gt_i32 s8, 16                                        // 0000001C5664: BF029008
	v_dual_cndmask_b32 v4, v211, v4 :: v_dual_cndmask_b32 v3, v210, v3// 0000001C5668: CA5209D3 040207D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5670: 986A80C1
	s_cmp_gt_i32 s8, 17                                        // 0000001C5674: BF029108
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C5678: CA520DD3 06040BD2
	.long 0xd7006a07                                           // 0000001C5680: D7006A07
	v_cndmask_b32_e32 v1, 0x66000, v1, vcc_lo                  // 0000001C5684: 020202FF 00066000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C568C: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5690: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5698: 986A80C1
	global_load_b32 v34, v[3:4], off                           // 0000001C569C: DC520000 227C0003
	global_load_b32 v35, v[5:6], off                           // 0000001C56A4: DC520000 237C0005
	v_dual_cndmask_b32 v4, v211, v8 :: v_dual_cndmask_b32 v3, v210, v7// 0000001C56AC: CA5211D3 04020FD2
	.long 0xd7006a05                                           // 0000001C56B4: D7006A05
	v_cndmask_b32_e32 v1, 0x6c000, v1, vcc_lo                  // 0000001C56B8: 020202FF 0006C000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C56C0: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C56C4: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001C56CC: D7006A07
	v_cndmask_b32_e32 v1, 0x72000, v1, vcc_lo                  // 0000001C56D0: 020202FF 00072000
	s_cmp_gt_i32 s8, 18                                        // 0000001C56D8: BF029208
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C56DC: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C56E4: 986A80C1
	s_cmp_gt_i32 s8, 19                                        // 0000001C56E8: BF029308
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C56EC: CA520DD3 06040BD2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C56F4: 986A80C1
	s_cmp_gt_i32 s8, 20                                        // 0000001C56F8: BF029408
	v_dual_cndmask_b32 v8, v211, v8 :: v_dual_cndmask_b32 v7, v210, v7// 0000001C56FC: CA5211D3 08060FD2
	.long 0xd7006a09                                           // 0000001C5704: D7006A09
	v_cndmask_b32_e32 v1, 0x78000, v1, vcc_lo                  // 0000001C5708: 020202FF 00078000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C5710: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001C5714: D5207C0A 01AA0480
	.long 0xd7006a19                                           // 0000001C571C: D7006A19
	v_cndmask_b32_e32 v1, 0x7e000, v1, vcc_lo                  // 0000001C5720: 020202FF 0007E000
	v_add_co_ci_u32_e64 v26, null, 0, v2, vcc_lo               // 0000001C5728: D5207C1A 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5730: 986A80C1
	s_cmp_gt_i32 s8, 21                                        // 0000001C5734: BF029508
	v_dual_cndmask_b32 v10, v211, v10 :: v_dual_cndmask_b32 v9, v210, v9// 0000001C5738: CA5215D3 0A0813D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5740: 986A80C1
	s_cmp_gt_i32 s8, 22                                        // 0000001C5744: BF029608
	v_dual_cndmask_b32 v26, v211, v26 :: v_dual_cndmask_b32 v25, v210, v25// 0000001C5748: CA5235D3 1A1833D2
	global_load_b32 v42, v[3:4], off                           // 0000001C5750: DC520000 2A7C0003
	global_load_b32 v43, v[5:6], off                           // 0000001C5758: DC520000 2B7C0005
	global_load_b32 v44, v[7:8], off                           // 0000001C5760: DC520000 2C7C0007
	global_load_b32 v36, v[9:10], off                          // 0000001C5768: DC520000 247C0009
	global_load_b32 v37, v[25:26], off                         // 0000001C5770: DC520000 257C0019
	.long 0xd7006a03                                           // 0000001C5778: D7006A03
	v_cndmask_b32_e32 v1, 0x84000, v1, vcc_lo                  // 0000001C577C: 020202FF 00084000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C5784: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001C5788: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001C5790: D7006A05
	v_cndmask_b32_e32 v1, 0x8a000, v1, vcc_lo                  // 0000001C5794: 020202FF 0008A000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C579C: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C57A4: 986A80C1
	s_cmp_gt_i32 s8, 23                                        // 0000001C57A8: BF029708
	v_dual_cndmask_b32 v4, v211, v4 :: v_dual_cndmask_b32 v3, v210, v3// 0000001C57AC: CA5209D3 040207D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C57B4: 986A80C1
	s_cmp_gt_i32 s8, 24                                        // 0000001C57B8: BF029808
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C57BC: CA520DD3 06040BD2
	.long 0xd7006a07                                           // 0000001C57C4: D7006A07
	v_cndmask_b32_e32 v1, 0x90000, v1, vcc_lo                  // 0000001C57C8: 020202FF 00090000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C57D0: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C57D4: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C57DC: 986A80C1
	global_load_b32 v39, v[3:4], off                           // 0000001C57E0: DC520000 277C0003
	global_load_b32 v38, v[5:6], off                           // 0000001C57E8: DC520000 267C0005
	v_dual_cndmask_b32 v4, v211, v8 :: v_dual_cndmask_b32 v3, v210, v7// 0000001C57F0: CA5211D3 04020FD2
	.long 0xd7006a05                                           // 0000001C57F8: D7006A05
	v_cndmask_b32_e32 v1, 0x96000, v1, vcc_lo                  // 0000001C57FC: 020202FF 00096000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5804: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C5808: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001C5810: D7006A07
	v_cndmask_b32_e32 v1, 0x9c000, v1, vcc_lo                  // 0000001C5814: 020202FF 0009C000
	s_cmp_gt_i32 s8, 25                                        // 0000001C581C: BF029908
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5820: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5828: 986A80C1
	s_cmp_gt_i32 s8, 26                                        // 0000001C582C: BF029A08
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C5830: CA520DD3 06040BD2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5838: 986A80C1
	s_cmp_gt_i32 s8, 27                                        // 0000001C583C: BF029B08
	v_dual_cndmask_b32 v8, v211, v8 :: v_dual_cndmask_b32 v7, v210, v7// 0000001C5840: CA5211D3 08060FD2
	.long 0xd7006a09                                           // 0000001C5848: D7006A09
	v_cndmask_b32_e32 v1, 0xa2000, v1, vcc_lo                  // 0000001C584C: 020202FF 000A2000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C5854: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001C5858: D5207C0A 01AA0480
	.long 0xd7006a19                                           // 0000001C5860: D7006A19
	v_cndmask_b32_e32 v1, 0xa8000, v1, vcc_lo                  // 0000001C5864: 020202FF 000A8000
	v_add_co_ci_u32_e64 v26, null, 0, v2, vcc_lo               // 0000001C586C: D5207C1A 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5874: 986A80C1
	s_cmp_gt_i32 s8, 28                                        // 0000001C5878: BF029C08
	v_dual_cndmask_b32 v10, v211, v10 :: v_dual_cndmask_b32 v9, v210, v9// 0000001C587C: CA5215D3 0A0813D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5884: 986A80C1
	s_cmp_gt_i32 s8, 29                                        // 0000001C5888: BF029D08
	v_dual_cndmask_b32 v26, v211, v26 :: v_dual_cndmask_b32 v25, v210, v25// 0000001C588C: CA5235D3 1A1833D2
	global_load_b32 v97, v[3:4], off                           // 0000001C5894: DC520000 617C0003
	global_load_b32 v46, v[5:6], off                           // 0000001C589C: DC520000 2E7C0005
	global_load_b32 v45, v[7:8], off                           // 0000001C58A4: DC520000 2D7C0007
	global_load_b32 v40, v[9:10], off                          // 0000001C58AC: DC520000 287C0009
	global_load_b32 v41, v[25:26], off                         // 0000001C58B4: DC520000 297C0019
	.long 0xd7006a03                                           // 0000001C58BC: D7006A03
	v_cndmask_b32_e32 v1, 0xae000, v1, vcc_lo                  // 0000001C58C0: 020202FF 000AE000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C58C8: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001C58CC: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001C58D4: D7006A05
	v_cndmask_b32_e32 v1, 0xb4000, v1, vcc_lo                  // 0000001C58D8: 020202FF 000B4000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C58E0: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C58E8: 986A80C1
	s_cmp_gt_i32 s8, 30                                        // 0000001C58EC: BF029E08
	v_dual_cndmask_b32 v4, v211, v4 :: v_dual_cndmask_b32 v3, v210, v3// 0000001C58F0: CA5209D3 040207D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C58F8: 986A80C1
	s_cmp_gt_i32 s8, 31                                        // 0000001C58FC: BF029F08
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C5900: CA520DD3 06040BD2
	.long 0xd7006a07                                           // 0000001C5908: D7006A07
	v_cndmask_b32_e32 v1, 0xba000, v1, vcc_lo                  // 0000001C590C: 020202FF 000BA000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5914: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5918: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5920: 986A80C1
	global_load_b32 v47, v[3:4], off                           // 0000001C5924: DC520000 2F7C0003
	global_load_b32 v48, v[5:6], off                           // 0000001C592C: DC520000 307C0005
	v_dual_cndmask_b32 v4, v211, v8 :: v_dual_cndmask_b32 v3, v210, v7// 0000001C5934: CA5211D3 04020FD2
	.long 0xd7006a05                                           // 0000001C593C: D7006A05
	v_cndmask_b32_e32 v1, 0xc0000, v1, vcc_lo                  // 0000001C5940: 020202FF 000C0000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5948: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C594C: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001C5954: D7006A07
	v_cndmask_b32_e32 v1, 0xc6000, v1, vcc_lo                  // 0000001C5958: 020202FF 000C6000
	s_cmp_gt_i32 s8, 32                                        // 0000001C5960: BF02A008
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5964: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C596C: 986A80C1
	s_cmp_gt_i32 s8, 33                                        // 0000001C5970: BF02A108
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C5974: CA520DD3 06040BD2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C597C: 986A80C1
	s_cmp_gt_i32 s8, 34                                        // 0000001C5980: BF02A208
	v_dual_cndmask_b32 v8, v211, v8 :: v_dual_cndmask_b32 v7, v210, v7// 0000001C5984: CA5211D3 08060FD2
	.long 0xd7006a09                                           // 0000001C598C: D7006A09
	v_cndmask_b32_e32 v1, 0xcc000, v1, vcc_lo                  // 0000001C5990: 020202FF 000CC000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C5998: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001C599C: D5207C0A 01AA0480
	.long 0xd7006a19                                           // 0000001C59A4: D7006A19
	v_cndmask_b32_e32 v1, 0xd2000, v1, vcc_lo                  // 0000001C59A8: 020202FF 000D2000
	v_add_co_ci_u32_e64 v26, null, 0, v2, vcc_lo               // 0000001C59B0: D5207C1A 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C59B8: 986A80C1
	s_cmp_gt_i32 s8, 35                                        // 0000001C59BC: BF02A308
	v_dual_cndmask_b32 v10, v211, v10 :: v_dual_cndmask_b32 v9, v210, v9// 0000001C59C0: CA5215D3 0A0813D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C59C8: 986A80C1
	s_cmp_gt_i32 s8, 36                                        // 0000001C59CC: BF02A408
	v_dual_cndmask_b32 v26, v211, v26 :: v_dual_cndmask_b32 v25, v210, v25// 0000001C59D0: CA5235D3 1A1833D2
	global_load_b32 v104, v[3:4], off                          // 0000001C59D8: DC520000 687C0003
	global_load_b32 v101, v[5:6], off                          // 0000001C59E0: DC520000 657C0005
	global_load_b32 v100, v[7:8], off                          // 0000001C59E8: DC520000 647C0007
	global_load_b32 v98, v[9:10], off                          // 0000001C59F0: DC520000 627C0009
	global_load_b32 v99, v[25:26], off                         // 0000001C59F8: DC520000 637C0019
	.long 0xd7006a03                                           // 0000001C5A00: D7006A03
	v_cndmask_b32_e32 v1, 0xd8000, v1, vcc_lo                  // 0000001C5A04: 020202FF 000D8000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C5A0C: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001C5A10: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001C5A18: D7006A05
	v_cndmask_b32_e32 v1, 0xde000, v1, vcc_lo                  // 0000001C5A1C: 020202FF 000DE000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C5A24: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5A2C: 986A80C1
	s_cmp_gt_i32 s8, 37                                        // 0000001C5A30: BF02A508
	v_dual_cndmask_b32 v4, v211, v4 :: v_dual_cndmask_b32 v3, v210, v3// 0000001C5A34: CA5209D3 040207D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5A3C: 986A80C1
	s_cmp_gt_i32 s8, 38                                        // 0000001C5A40: BF02A608
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C5A44: CA520DD3 06040BD2
	.long 0xd7006a07                                           // 0000001C5A4C: D7006A07
	v_cndmask_b32_e32 v1, 0xe4000, v1, vcc_lo                  // 0000001C5A50: 020202FF 000E4000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5A58: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5A5C: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5A64: 986A80C1
	global_load_b32 v103, v[3:4], off                          // 0000001C5A68: DC520000 677C0003
	global_load_b32 v102, v[5:6], off                          // 0000001C5A70: DC520000 667C0005
	v_dual_cndmask_b32 v4, v211, v8 :: v_dual_cndmask_b32 v3, v210, v7// 0000001C5A78: CA5211D3 04020FD2
	.long 0xd7006a05                                           // 0000001C5A80: D7006A05
	v_cndmask_b32_e32 v1, 0xea000, v1, vcc_lo                  // 0000001C5A84: 020202FF 000EA000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5A8C: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C5A90: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001C5A98: D7006A07
	v_cndmask_b32_e32 v1, 0xf0000, v1, vcc_lo                  // 0000001C5A9C: 020202FF 000F0000
	s_cmp_gt_i32 s8, 39                                        // 0000001C5AA4: BF02A708
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5AA8: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5AB0: 986A80C1
	s_cmp_gt_i32 s8, 40                                        // 0000001C5AB4: BF02A808
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C5AB8: CA520DD3 06040BD2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5AC0: 986A80C1
	s_cmp_gt_i32 s8, 41                                        // 0000001C5AC4: BF02A908
	v_dual_cndmask_b32 v8, v211, v8 :: v_dual_cndmask_b32 v7, v210, v7// 0000001C5AC8: CA5211D3 08060FD2
	.long 0xd7006a09                                           // 0000001C5AD0: D7006A09
	v_cndmask_b32_e32 v1, 0xf6000, v1, vcc_lo                  // 0000001C5AD4: 020202FF 000F6000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C5ADC: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001C5AE0: D5207C0A 01AA0480
	.long 0xd7006a19                                           // 0000001C5AE8: D7006A19
	v_cndmask_b32_e32 v1, 0xfc000, v1, vcc_lo                  // 0000001C5AEC: 020202FF 000FC000
	v_add_co_ci_u32_e64 v26, null, 0, v2, vcc_lo               // 0000001C5AF4: D5207C1A 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5AFC: 986A80C1
	s_cmp_gt_i32 s8, 42                                        // 0000001C5B00: BF02AA08
	v_dual_cndmask_b32 v10, v211, v10 :: v_dual_cndmask_b32 v9, v210, v9// 0000001C5B04: CA5215D3 0A0813D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5B0C: 986A80C1
	s_cmp_gt_i32 s8, 43                                        // 0000001C5B10: BF02AB08
	v_dual_cndmask_b32 v26, v211, v26 :: v_dual_cndmask_b32 v25, v210, v25// 0000001C5B14: CA5235D3 1A1833D2
	global_load_b32 v110, v[3:4], off                          // 0000001C5B1C: DC520000 6E7C0003
	global_load_b32 v109, v[5:6], off                          // 0000001C5B24: DC520000 6D7C0005
	global_load_b32 v107, v[7:8], off                          // 0000001C5B2C: DC520000 6B7C0007
	global_load_b32 v106, v[9:10], off                         // 0000001C5B34: DC520000 6A7C0009
	global_load_b32 v105, v[25:26], off                        // 0000001C5B3C: DC520000 697C0019
	.long 0xd7006a03                                           // 0000001C5B44: D7006A03
	v_cndmask_b32_e32 v1, 0x102000, v1, vcc_lo                 // 0000001C5B48: 020202FF 00102000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C5B50: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001C5B54: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001C5B5C: D7006A05
	v_cndmask_b32_e32 v1, 0x108000, v1, vcc_lo                 // 0000001C5B60: 020202FF 00108000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C5B68: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5B70: 986A80C1
	s_cmp_gt_i32 s8, 44                                        // 0000001C5B74: BF02AC08
	v_dual_cndmask_b32 v4, v211, v4 :: v_dual_cndmask_b32 v3, v210, v3// 0000001C5B78: CA5209D3 040207D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5B80: 986A80C1
	s_cmp_gt_i32 s8, 45                                        // 0000001C5B84: BF02AD08
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C5B88: CA520DD3 06040BD2
	.long 0xd7006a07                                           // 0000001C5B90: D7006A07
	v_cndmask_b32_e32 v1, 0x10e000, v1, vcc_lo                 // 0000001C5B94: 020202FF 0010E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5B9C: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5BA0: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5BA8: 986A80C1
	global_load_b32 v111, v[3:4], off                          // 0000001C5BAC: DC520000 6F7C0003
	global_load_b32 v108, v[5:6], off                          // 0000001C5BB4: DC520000 6C7C0005
	v_dual_cndmask_b32 v4, v211, v8 :: v_dual_cndmask_b32 v3, v210, v7// 0000001C5BBC: CA5211D3 04020FD2
	.long 0xd7006a05                                           // 0000001C5BC4: D7006A05
	v_cndmask_b32_e32 v1, 0x114000, v1, vcc_lo                 // 0000001C5BC8: 020202FF 00114000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5BD0: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C5BD4: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001C5BDC: D7006A07
	v_cndmask_b32_e32 v1, 0x11a000, v1, vcc_lo                 // 0000001C5BE0: 020202FF 0011A000
	s_cmp_gt_i32 s8, 46                                        // 0000001C5BE8: BF02AE08
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5BEC: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5BF4: 986A80C1
	s_cmp_gt_i32 s8, 47                                        // 0000001C5BF8: BF02AF08
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C5BFC: CA520DD3 06040BD2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5C04: 986A80C1
	s_cmp_gt_i32 s8, 48                                        // 0000001C5C08: BF02B008
	v_dual_cndmask_b32 v8, v211, v8 :: v_dual_cndmask_b32 v7, v210, v7// 0000001C5C0C: CA5211D3 08060FD2
	.long 0xd7006a09                                           // 0000001C5C14: D7006A09
	v_cndmask_b32_e32 v1, 0x120000, v1, vcc_lo                 // 0000001C5C18: 020202FF 00120000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C5C20: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001C5C24: D5207C0A 01AA0480
	.long 0xd7006a19                                           // 0000001C5C2C: D7006A19
	v_cndmask_b32_e32 v1, 0x126000, v1, vcc_lo                 // 0000001C5C30: 020202FF 00126000
	v_add_co_ci_u32_e64 v26, null, 0, v2, vcc_lo               // 0000001C5C38: D5207C1A 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5C40: 986A80C1
	s_cmp_gt_i32 s8, 49                                        // 0000001C5C44: BF02B108
	v_dual_cndmask_b32 v10, v211, v10 :: v_dual_cndmask_b32 v9, v210, v9// 0000001C5C48: CA5215D3 0A0813D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5C50: 986A80C1
	s_cmp_gt_i32 s8, 50                                        // 0000001C5C54: BF02B208
	v_dual_cndmask_b32 v26, v211, v26 :: v_dual_cndmask_b32 v25, v210, v25// 0000001C5C58: CA5235D3 1A1833D2
	global_load_b32 v117, v[3:4], off                          // 0000001C5C60: DC520000 757C0003
	global_load_b32 v115, v[5:6], off                          // 0000001C5C68: DC520000 737C0005
	global_load_b32 v114, v[7:8], off                          // 0000001C5C70: DC520000 727C0007
	global_load_b32 v113, v[9:10], off                         // 0000001C5C78: DC520000 717C0009
	global_load_b32 v112, v[25:26], off                        // 0000001C5C80: DC520000 707C0019
	.long 0xd7006a03                                           // 0000001C5C88: D7006A03
	v_cndmask_b32_e32 v1, 0x12c000, v1, vcc_lo                 // 0000001C5C8C: 020202FF 0012C000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C5C94: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001C5C98: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001C5CA0: D7006A05
	v_cndmask_b32_e32 v1, 0x132000, v1, vcc_lo                 // 0000001C5CA4: 020202FF 00132000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C5CAC: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5CB4: 986A80C1
	s_cmp_gt_i32 s8, 51                                        // 0000001C5CB8: BF02B308
	v_dual_cndmask_b32 v4, v211, v4 :: v_dual_cndmask_b32 v3, v210, v3// 0000001C5CBC: CA5209D3 040207D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5CC4: 986A80C1
	s_cmp_gt_i32 s8, 52                                        // 0000001C5CC8: BF02B408
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C5CCC: CA520DD3 06040BD2
	.long 0xd7006a07                                           // 0000001C5CD4: D7006A07
	v_cndmask_b32_e32 v1, 0x138000, v1, vcc_lo                 // 0000001C5CD8: 020202FF 00138000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5CE0: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5CE4: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5CEC: 986A80C1
	global_load_b32 v118, v[3:4], off                          // 0000001C5CF0: DC520000 767C0003
	global_load_b32 v116, v[5:6], off                          // 0000001C5CF8: DC520000 747C0005
	v_dual_cndmask_b32 v4, v211, v8 :: v_dual_cndmask_b32 v3, v210, v7// 0000001C5D00: CA5211D3 04020FD2
	.long 0xd7006a05                                           // 0000001C5D08: D7006A05
	v_cndmask_b32_e32 v1, 0x13e000, v1, vcc_lo                 // 0000001C5D0C: 020202FF 0013E000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5D14: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C5D18: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001C5D20: D7006A07
	v_cndmask_b32_e32 v1, 0x144000, v1, vcc_lo                 // 0000001C5D24: 020202FF 00144000
	s_cmp_gt_i32 s8, 53                                        // 0000001C5D2C: BF02B508
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5D30: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5D38: 986A80C1
	s_cmp_gt_i32 s8, 54                                        // 0000001C5D3C: BF02B608
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C5D40: CA520DD3 06040BD2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5D48: 986A80C1
	s_cmp_gt_i32 s8, 55                                        // 0000001C5D4C: BF02B708
	v_dual_cndmask_b32 v8, v211, v8 :: v_dual_cndmask_b32 v7, v210, v7// 0000001C5D50: CA5211D3 08060FD2
	.long 0xd7006a09                                           // 0000001C5D58: D7006A09
	v_cndmask_b32_e32 v1, 0x14a000, v1, vcc_lo                 // 0000001C5D5C: 020202FF 0014A000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C5D64: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001C5D68: D5207C0A 01AA0480
	.long 0xd7006a19                                           // 0000001C5D70: D7006A19
	v_cndmask_b32_e32 v1, 0x150000, v1, vcc_lo                 // 0000001C5D74: 020202FF 00150000
	v_add_co_ci_u32_e64 v26, null, 0, v2, vcc_lo               // 0000001C5D7C: D5207C1A 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5D84: 986A80C1
	s_cmp_gt_i32 s8, 56                                        // 0000001C5D88: BF02B808
	v_dual_cndmask_b32 v10, v211, v10 :: v_dual_cndmask_b32 v9, v210, v9// 0000001C5D8C: CA5215D3 0A0813D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5D94: 986A80C1
	s_cmp_gt_i32 s8, 57                                        // 0000001C5D98: BF02B908
	v_dual_cndmask_b32 v26, v211, v26 :: v_dual_cndmask_b32 v25, v210, v25// 0000001C5D9C: CA5235D3 1A1833D2
	global_load_b32 v123, v[3:4], off                          // 0000001C5DA4: DC520000 7B7C0003
	global_load_b32 v122, v[5:6], off                          // 0000001C5DAC: DC520000 7A7C0005
	global_load_b32 v121, v[7:8], off                          // 0000001C5DB4: DC520000 797C0007
	global_load_b32 v120, v[9:10], off                         // 0000001C5DBC: DC520000 787C0009
	global_load_b32 v119, v[25:26], off                        // 0000001C5DC4: DC520000 777C0019
	.long 0xd7006a03                                           // 0000001C5DCC: D7006A03
	v_cndmask_b32_e32 v1, 0x156000, v1, vcc_lo                 // 0000001C5DD0: 020202FF 00156000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C5DD8: BF8700A1
	v_add_co_ci_u32_e64 v4, null, 0, v2, vcc_lo                // 0000001C5DDC: D5207C04 01AA0480
	.long 0xd7006a05                                           // 0000001C5DE4: D7006A05
	v_cndmask_b32_e32 v1, 0x15c000, v1, vcc_lo                 // 0000001C5DE8: 020202FF 0015C000
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C5DF0: D5207C06 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5DF8: 986A80C1
	s_cmp_gt_i32 s8, 58                                        // 0000001C5DFC: BF02BA08
	v_dual_cndmask_b32 v4, v211, v4 :: v_dual_cndmask_b32 v3, v210, v3// 0000001C5E00: CA5209D3 040207D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5E08: 986A80C1
	s_cmp_gt_i32 s8, 59                                        // 0000001C5E0C: BF02BB08
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C5E10: CA520DD3 06040BD2
	.long 0xd7006a07                                           // 0000001C5E18: D7006A07
	v_cndmask_b32_e32 v1, 0x162000, v1, vcc_lo                 // 0000001C5E1C: 020202FF 00162000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5E24: BF870001
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5E28: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5E30: 986A80C1
	global_load_b32 v124, v[3:4], off                          // 0000001C5E34: DC520000 7C7C0003
	global_load_b32 v125, v[5:6], off                          // 0000001C5E3C: DC520000 7D7C0005
	v_dual_cndmask_b32 v4, v211, v8 :: v_dual_cndmask_b32 v3, v210, v7// 0000001C5E44: CA5211D3 04020FD2
	.long 0xd7006a05                                           // 0000001C5E4C: D7006A05
	v_cndmask_b32_e32 v1, 0x168000, v1, vcc_lo                 // 0000001C5E50: 020202FF 00168000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C5E58: BF870001
	v_add_co_ci_u32_e64 v6, null, 0, v2, vcc_lo                // 0000001C5E5C: D5207C06 01AA0480
	.long 0xd7006a07                                           // 0000001C5E64: D7006A07
	v_cndmask_b32_e32 v1, 0x16e000, v1, vcc_lo                 // 0000001C5E68: 020202FF 0016E000
	s_cmp_gt_i32 s8, 60                                        // 0000001C5E70: BF02BC08
	v_add_co_ci_u32_e64 v8, null, 0, v2, vcc_lo                // 0000001C5E74: D5207C08 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5E7C: 986A80C1
	s_cmp_gt_i32 s8, 61                                        // 0000001C5E80: BF02BD08
	v_dual_cndmask_b32 v6, v211, v6 :: v_dual_cndmask_b32 v5, v210, v5// 0000001C5E84: CA520DD3 06040BD2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5E8C: 986A80C1
	s_cmp_gt_i32 s8, 62                                        // 0000001C5E90: BF02BE08
	v_dual_cndmask_b32 v8, v211, v8 :: v_dual_cndmask_b32 v7, v210, v7// 0000001C5E94: CA5211D3 08060FD2
	.long 0xd7006a09                                           // 0000001C5E9C: D7006A09
	v_cndmask_b32_e32 v1, 0x174000, v1, vcc_lo                 // 0000001C5EA0: 020202FF 00174000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C5EA8: BF8700A1
	v_add_co_ci_u32_e64 v10, null, 0, v2, vcc_lo               // 0000001C5EAC: D5207C0A 01AA0480
	.long 0xd7006a19                                           // 0000001C5EB4: D7006A19
	v_cndmask_b32_e32 v1, 0x17a000, v1, vcc_lo                 // 0000001C5EB8: 020202FF 0017A000
	v_add_co_ci_u32_e64 v26, null, 0, v2, vcc_lo               // 0000001C5EC0: D5207C1A 01AA0480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5EC8: 986A80C1
	s_cmp_gt_i32 s8, 63                                        // 0000001C5ECC: BF02BF08
	v_dual_cndmask_b32 v2, v211, v10 :: v_dual_cndmask_b32 v1, v210, v9// 0000001C5ED0: CA5215D3 020013D2
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001C5ED8: 986A80C1
	s_cmp_gt_i32 s47, s42                                      // 0000001C5EDC: BF022A2F
	v_dual_cndmask_b32 v10, v211, v26 :: v_dual_cndmask_b32 v9, v210, v25// 0000001C5EE0: CA5235D3 0A0833D2
	global_load_b32 v130, v[3:4], off                          // 0000001C5EE8: DC520000 827C0003
	global_load_b32 v129, v[5:6], off                          // 0000001C5EF0: DC520000 817C0005
	global_load_b32 v127, v[7:8], off                          // 0000001C5EF8: DC520000 7F7C0007
	global_load_b32 v126, v[1:2], off                          // 0000001C5F00: DC520000 7E7C0001
	global_load_b32 v128, v[9:10], off                         // 0000001C5F08: DC520000 807C0009
	s_cselect_b32 s8, -1, 0                                    // 0000001C5F10: 980880C1
	s_or_b32 s9, s42, 1                                        // 0000001C5F14: 8C09812A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001C5F18: BF8704B9
	s_cmp_lt_i32 s9, s47                                       // 0000001C5F1C: BF042F09
	s_cselect_b32 s9, -1, 0                                    // 0000001C5F20: 980980C1
	s_or_b32 s10, s42, 2                                       // 0000001C5F24: 8C0A822A
	s_cmp_lt_i32 s10, s47                                      // 0000001C5F28: BF042F0A
	s_cselect_b32 s10, -1, 0                                   // 0000001C5F2C: 980A80C1
	s_or_b32 s11, s42, 3                                       // 0000001C5F30: 8C0B832A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001C5F34: BF8704B9
	s_cmp_lt_i32 s11, s47                                      // 0000001C5F38: BF042F0B
	s_cselect_b32 s11, -1, 0                                   // 0000001C5F3C: 980B80C1
	s_or_b32 s12, s42, 4                                       // 0000001C5F40: 8C0C842A
	s_cmp_lt_i32 s12, s47                                      // 0000001C5F44: BF042F0C
	s_cselect_b32 s12, -1, 0                                   // 0000001C5F48: 980C80C1
	s_or_b32 s13, s42, 5                                       // 0000001C5F4C: 8C0D852A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001C5F50: BF8704B9
	s_cmp_lt_i32 s13, s47                                      // 0000001C5F54: BF042F0D
	s_cselect_b32 s13, -1, 0                                   // 0000001C5F58: 980D80C1
	s_or_b32 s43, s42, 6                                       // 0000001C5F5C: 8C2B862A
	s_cmp_lt_i32 s43, s47                                      // 0000001C5F60: BF042F2B
	s_cselect_b32 s43, -1, 0                                   // 0000001C5F64: 982B80C1
	s_or_b32 s51, s42, 7                                       // 0000001C5F68: 8C33872A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001C5F6C: BF8704B9
	s_cmp_lt_i32 s51, s47                                      // 0000001C5F70: BF042F33
	s_cselect_b32 s51, -1, 0                                   // 0000001C5F74: 983380C1
	s_or_b32 s52, s42, 8                                       // 0000001C5F78: 8C34882A
	s_cmp_lt_i32 s52, s47                                      // 0000001C5F7C: BF042F34
	s_cselect_b32 s52, -1, 0                                   // 0000001C5F80: 983480C1
	s_or_b32 s53, s42, 9                                       // 0000001C5F84: 8C35892A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001C5F88: BF8704B9
	s_cmp_lt_i32 s53, s47                                      // 0000001C5F8C: BF042F35
	s_cselect_b32 s53, -1, 0                                   // 0000001C5F90: 983580C1
	s_or_b32 s54, s42, 10                                      // 0000001C5F94: 8C368A2A
	s_cmp_lt_i32 s54, s47                                      // 0000001C5F98: BF042F36
	s_cselect_b32 s54, -1, 0                                   // 0000001C5F9C: 983680C1
	s_or_b32 s55, s42, 11                                      // 0000001C5FA0: 8C378B2A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001C5FA4: BF8704B9
	s_cmp_lt_i32 s55, s47                                      // 0000001C5FA8: BF042F37
	s_cselect_b32 s55, -1, 0                                   // 0000001C5FAC: 983780C1
	s_or_b32 s56, s42, 12                                      // 0000001C5FB0: 8C388C2A
	s_cmp_lt_i32 s56, s47                                      // 0000001C5FB4: BF042F38
	s_cselect_b32 s56, -1, 0                                   // 0000001C5FB8: 983880C1
	s_or_b32 s57, s42, 13                                      // 0000001C5FBC: 8C398D2A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001C5FC0: BF8704B9
	s_cmp_lt_i32 s57, s47                                      // 0000001C5FC4: BF042F39
	s_cselect_b32 s57, -1, 0                                   // 0000001C5FC8: 983980C1
	s_or_b32 s58, s42, 14                                      // 0000001C5FCC: 8C3A8E2A
	s_cmp_lt_i32 s58, s47                                      // 0000001C5FD0: BF042F3A
	s_cselect_b32 s58, -1, 0                                   // 0000001C5FD4: 983A80C1
	s_or_b32 s59, s42, 15                                      // 0000001C5FD8: 8C3B8F2A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001C5FDC: BF8704B9
	s_cmp_lt_i32 s59, s47                                      // 0000001C5FE0: BF042F3B
	s_cselect_b32 s59, -1, 0                                   // 0000001C5FE4: 983B80C1
	s_or_b32 s60, s42, 16                                      // 0000001C5FE8: 8C3C902A
	s_cmp_lt_i32 s60, s47                                      // 0000001C5FEC: BF042F3C
	s_cselect_b32 s60, -1, 0                                   // 0000001C5FF0: 983C80C1
	s_or_b32 s61, s42, 17                                      // 0000001C5FF4: 8C3D912A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001C5FF8: BF8704B9
	s_cmp_lt_i32 s61, s47                                      // 0000001C5FFC: BF042F3D
	s_cselect_b32 s61, -1, 0                                   // 0000001C6000: 983D80C1
	s_or_b32 s62, s42, 18                                      // 0000001C6004: 8C3E922A
	s_cmp_lt_i32 s62, s47                                      // 0000001C6008: BF042F3E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001C600C: BF890007
	s_barrier                                                  // 0000001C6010: BFBD0000
	buffer_gl0_inv                                             // 0000001C6014: E0AC0000 00000000
	ds_load_b128 v[131:134], v194 offset:61440                 // 0000001C601C: DBFCF000 830000C2
	ds_load_b128 v[135:138], v194 offset:61456                 // 0000001C6024: DBFCF010 870000C2
	ds_load_b128 v[139:142], v194 offset:61472                 // 0000001C602C: DBFCF020 8B0000C2
	ds_load_b128 v[143:146], v194 offset:61488                 // 0000001C6034: DBFCF030 8F0000C2
	ds_load_b128 v[147:150], v194 offset:61504                 // 0000001C603C: DBFCF040 930000C2
	ds_load_b128 v[151:154], v194 offset:61520                 // 0000001C6044: DBFCF050 970000C2
	s_waitcnt lgkmcnt(5)                                       // 0000001C604C: BF89FC57
	v_dual_mul_f32 v12, v12, v132 :: v_dual_add_nc_u32 v155, s42, v213// 0000001C6050: C8E1090C 0C9BAA2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001C6058: BF8701C1
	v_min_i32_e32 v1, s49, v155                                // 0000001C605C: 22033631
	v_dual_mul_f32 v11, v11, v131 :: v_dual_mul_f32 v14, v14, v134// 0000001C6060: C8C7070B 0B0F0D0E
	s_waitcnt lgkmcnt(4)                                       // 0000001C6068: BF89FC47
	v_dual_mul_f32 v13, v13, v133 :: v_dual_mul_f32 v16, v16, v136// 0000001C606C: C8C70B0D 0D111110
	v_mad_i64_i32 v[1:2], null, v1, 48, s[2:3]                 // 0000001C6074: D6FF7C01 00096101
	ds_load_b128 v[131:134], v194 offset:61536                 // 0000001C607C: DBFCF060 830000C2
	v_dual_mul_f32 v15, v15, v135 :: v_dual_mul_f32 v18, v18, v138// 0000001C6084: C8C70F0F 0F131512
	s_waitcnt lgkmcnt(4)                                       // 0000001C608C: BF89FC47
	v_dual_mul_f32 v17, v17, v137 :: v_dual_mul_f32 v20, v20, v140// 0000001C6090: C8C71311 11151914
	v_dual_mul_f32 v19, v19, v139 :: v_dual_mul_f32 v22, v22, v142// 0000001C6098: C8C71713 13171D16
	.long 0xd73c0009                                           // 0000001C60A0: D73C0009
	v_cndmask_b32_e32 v1, 8, v1, vcc_lo                        // 0000001C60A4: 02020288
	s_waitcnt lgkmcnt(2)                                       // 0000001C60A8: BF89FC27
	v_mul_f32_e32 v43, v43, v149                               // 0000001C60AC: 10572B2B
	v_fma_mixlo_f16 v11, v11, s39, 0                           // 0000001C60B0: CC21000B 02004F0B
	v_fma_mixhi_f16 v11, v12, s39, 0                           // 0000001C60B8: CC22000B 02004F0C
	v_dual_mul_f32 v35, v35, v147 :: v_dual_mul_f32 v44, v44, v150// 0000001C60C0: C8C72723 232D2D2C
	.long 0xd7006a05                                           // 0000001C60C8: D7006A05
	v_cndmask_b32_e32 v1, s28, v9, vcc_lo                      // 0000001C60CC: 0202121C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C60D0: BF870001
	v_add_co_ci_u32_e64 v6, null, s29, v10, vcc_lo             // 0000001C60D4: D5207C06 01AA141D
	s_clause 0xf                                               // 0000001C60DC: BF85000F
	global_load_b128 v[89:92], v[5:6], off                     // 0000001C60E0: DC5E0000 597C0005
	global_load_b128 v[93:96], v[5:6], off offset:16           // 0000001C60E8: DC5E0010 5D7C0005
	global_load_b128 v[81:84], v[5:6], off offset:32           // 0000001C60F0: DC5E0020 517C0005
	global_load_b128 v[85:88], v[5:6], off offset:48           // 0000001C60F8: DC5E0030 557C0005
	global_load_b128 v[73:76], v[5:6], off offset:64           // 0000001C6100: DC5E0040 497C0005
	global_load_b128 v[77:80], v[5:6], off offset:80           // 0000001C6108: DC5E0050 4D7C0005
	global_load_b128 v[65:68], v[5:6], off offset:96           // 0000001C6110: DC5E0060 417C0005
	global_load_b128 v[69:72], v[5:6], off offset:112          // 0000001C6118: DC5E0070 457C0005
	global_load_b128 v[57:60], v[5:6], off offset:128          // 0000001C6120: DC5E0080 397C0005
	global_load_b128 v[61:64], v[5:6], off offset:144          // 0000001C6128: DC5E0090 3D7C0005
	global_load_b128 v[49:52], v[5:6], off offset:160          // 0000001C6130: DC5E00A0 317C0005
	global_load_b128 v[53:56], v[5:6], off offset:176          // 0000001C6138: DC5E00B0 357C0005
	global_load_b128 v[25:28], v[5:6], off offset:192          // 0000001C6140: DC5E00C0 197C0005
	global_load_b128 v[29:32], v[5:6], off offset:208          // 0000001C6148: DC5E00D0 1D7C0005
	global_load_b128 v[1:4], v[5:6], off offset:224            // 0000001C6150: DC5E00E0 017C0005
	global_load_b128 v[5:8], v[5:6], off offset:240            // 0000001C6158: DC5E00F0 057C0005
	v_fma_mixlo_f16 v12, v13, s39, 0                           // 0000001C6160: CC21000C 02004F0D
	v_fma_mixlo_f16 v13, v15, s39, 0                           // 0000001C6168: CC21000D 02004F0F
	v_fma_mixhi_f16 v13, v16, s39, 0                           // 0000001C6170: CC22000D 02004F10
	v_fma_mixhi_f16 v15, v20, s39, 0                           // 0000001C6178: CC22000F 02004F14
	v_fma_mixhi_f16 v16, v22, s39, 0                           // 0000001C6180: CC220010 02004F16
	s_waitcnt lgkmcnt(1)                                       // 0000001C6188: BF89FC17
	v_mul_f32_e32 v22, v37, v152                               // 0000001C618C: 102D3125
	v_fma_mixlo_f16 v20, v43, s39, 0                           // 0000001C6190: CC210014 02004F2B
	v_cndmask_b16 v11, 0, v11, s8                              // 0000001C6198: D65D000B 00221680
	v_cndmask_b16 v11, 0, v11, s9                              // 0000001C61A0: D65D500B 00261680
	s_cselect_b32 s8, -1, 0                                    // 0000001C61A8: 980880C1
	s_or_b32 s9, s42, 19                                       // 0000001C61AC: 8C09932A
	v_dual_mul_f32 v21, v21, v141 :: v_dual_mul_f32 v24, v24, v144// 0000001C61B0: C8C71B15 15192118
	s_cmp_lt_i32 s9, s47                                       // 0000001C61B8: BF042F09
	v_dual_mul_f32 v23, v23, v143 :: v_dual_mul_f32 v34, v34, v146// 0000001C61BC: C8C71F17 17232522
	v_dual_mul_f32 v33, v33, v145 :: v_dual_mul_f32 v42, v42, v148// 0000001C61C4: C8C72321 212B292A
	v_fma_mixhi_f16 v20, v44, s39, 0                           // 0000001C61CC: CC220014 02004F2C
	v_cndmask_b16 v20, 0, v20, s8                              // 0000001C61D4: D65D0014 00222880
	s_cselect_b32 s8, -1, 0                                    // 0000001C61DC: 980880C1
	s_or_b32 s9, s42, 20                                       // 0000001C61E0: 8C09942A
	v_fma_mixlo_f16 v16, v21, s39, 0                           // 0000001C61E4: CC210010 02004F15
	s_cmp_lt_i32 s9, s47                                       // 0000001C61EC: BF042F09
	v_mul_f32_e32 v21, v36, v151                               // 0000001C61F0: 102B2F24
	v_fma_mixhi_f16 v12, v14, s39, 0                           // 0000001C61F4: CC22000C 02004F0E
	v_fma_mixlo_f16 v14, v17, s39, 0                           // 0000001C61FC: CC21000E 02004F11
	v_fma_mixhi_f16 v14, v18, s39, 0                           // 0000001C6204: CC22000E 02004F12
	v_fma_mixlo_f16 v15, v19, s39, 0                           // 0000001C620C: CC21000F 02004F13
	v_fma_mixlo_f16 v17, v23, s39, 0                           // 0000001C6214: CC210011 02004F17
	v_fma_mixlo_f16 v18, v33, s39, 0                           // 0000001C621C: CC210012 02004F21
	v_fma_mixhi_f16 v18, v34, s39, 0                           // 0000001C6224: CC220012 02004F22
	v_fma_mixlo_f16 v19, v35, s39, 0                           // 0000001C622C: CC210013 02004F23
	v_cndmask_b16 v20, 0, v20, s8                              // 0000001C6234: D65D5014 00222880
	s_cselect_b32 s8, -1, 0                                    // 0000001C623C: 980880C1
	s_or_b32 s9, s42, 21                                       // 0000001C6240: 8C09952A
	ds_load_b128 v[33:36], v194 offset:61552                   // 0000001C6244: DBFCF070 210000C2
	v_mul_f32_e32 v23, v39, v153                               // 0000001C624C: 102F3327
	s_cmp_lt_i32 s9, s47                                       // 0000001C6250: BF042F09
	v_fma_mixlo_f16 v21, v21, s39, 0                           // 0000001C6254: CC210015 02004F15
	v_cndmask_b16 v12, 0, v12, s10                             // 0000001C625C: D65D000C 002A1880
	s_cselect_b32 s9, -1, 0                                    // 0000001C6264: 980980C1
	s_or_b32 s10, s42, 22                                      // 0000001C6268: 8C0A962A
	v_fma_mixhi_f16 v17, v24, s39, 0                           // 0000001C626C: CC220011 02004F18
	v_fma_mixhi_f16 v21, v22, s39, 0                           // 0000001C6274: CC220015 02004F16
	s_waitcnt lgkmcnt(1)                                       // 0000001C627C: BF89FC17
	v_mul_f32_e32 v24, v97, v131                               // 0000001C6280: 10310761
	v_fma_mixlo_f16 v22, v23, s39, 0                           // 0000001C6284: CC210016 02004F17
	s_cmp_lt_i32 s10, s47                                      // 0000001C628C: BF042F0A
	v_cndmask_b16 v21, 0, v21, s8                              // 0000001C6290: D65D0015 00222A80
	s_cselect_b32 s8, -1, 0                                    // 0000001C6298: 980880C1
	v_dual_mul_f32 v23, v38, v154 :: v_dual_mul_f32 v38, v45, v133// 0000001C629C: C8C73526 17270B2D
	v_cndmask_b16 v22, 0, v22, s8                              // 0000001C62A4: D65D0016 00222C80
	s_or_b32 s8, s42, 23                                       // 0000001C62AC: 8C08972A
	v_cndmask_b16 v21, 0, v21, s9                              // 0000001C62B0: D65D5015 00262A80
	s_cmp_lt_i32 s8, s47                                       // 0000001C62B8: BF042F08
	v_fma_mixhi_f16 v22, v23, s39, 0                           // 0000001C62BC: CC220016 02004F17
	s_cselect_b32 s8, -1, 0                                    // 0000001C62C4: 980880C1
	s_or_b32 s9, s42, 24                                       // 0000001C62C8: 8C09982A
	v_fma_mixlo_f16 v23, v24, s39, 0                           // 0000001C62CC: CC210017 02004F18
	s_cmp_lt_i32 s9, s47                                       // 0000001C62D4: BF042F09
	v_mul_f32_e32 v24, v46, v132                               // 0000001C62D8: 1031092E
	v_cndmask_b16 v22, 0, v22, s8                              // 0000001C62DC: D65D5016 00222C80
	s_cselect_b32 s8, -1, 0                                    // 0000001C62E4: 980880C1
	v_fma_mixhi_f16 v19, v42, s39, 0                           // 0000001C62E8: CC220013 02004F2A
	v_cndmask_b16 v37, 0, v23, s8                              // 0000001C62F0: D65D0025 00222E80
	s_or_b32 s8, s42, 25                                       // 0000001C62F8: 8C08992A
	v_fma_mixlo_f16 v23, v24, s39, 0                           // 0000001C62FC: CC210017 02004F18
	s_cmp_lt_i32 s8, s47                                       // 0000001C6304: BF042F08
	s_waitcnt lgkmcnt(0)                                       // 0000001C6308: BF89FC07
	v_dual_mul_f32 v24, v40, v134 :: v_dual_mul_f32 v33, v41, v33// 0000001C630C: C8C70D28 18204329
	ds_load_b128 v[41:44], v194 offset:61568                   // 0000001C6314: DBFCF080 290000C2
	s_cselect_b32 s8, -1, 0                                    // 0000001C631C: 980880C1
	s_or_b32 s9, s42, 26                                       // 0000001C6320: 8C099A2A
	v_fma_mixhi_f16 v23, v38, s39, 0                           // 0000001C6324: CC220017 02004F26
	s_cmp_lt_i32 s9, s47                                       // 0000001C632C: BF042F09
	v_cndmask_b16 v37, 0, v23, s8                              // 0000001C6330: D65D4025 00222E80
	s_cselect_b32 s8, -1, 0                                    // 0000001C6338: 980880C1
	v_fma_mixlo_f16 v23, v24, s39, 0                           // 0000001C633C: CC210017 02004F18
	v_cndmask_b16 v38, 0, v23, s8                              // 0000001C6344: D65D1026 00222E80
	s_or_b32 s8, s42, 27                                       // 0000001C634C: 8C089B2A
	v_fma_mixhi_f16 v23, v33, s39, 0                           // 0000001C6350: CC220017 02004F21
	s_cmp_lt_i32 s8, s47                                       // 0000001C6358: BF042F08
	v_cndmask_b16 v12, 0, v12, s11                             // 0000001C635C: D65D500C 002E1880
	s_cselect_b32 s8, -1, 0                                    // 0000001C6364: 980880C1
	s_or_b32 s9, s42, 28                                       // 0000001C6368: 8C099C2A
	v_cndmask_b16 v13, 0, v13, s12                             // 0000001C636C: D65D000D 00321A80
	s_cmp_lt_i32 s9, s47                                       // 0000001C6374: BF042F09
	v_cndmask_b16 v13, 0, v13, s13                             // 0000001C6378: D65D500D 00361A80
	v_cndmask_b16 v14, 0, v14, s43                             // 0000001C6380: D65D000E 00AE1C80
	v_cndmask_b16 v14, 0, v14, s51                             // 0000001C6388: D65D500E 00CE1C80
	v_cndmask_b16 v15, 0, v15, s52                             // 0000001C6390: D65D000F 00D21E80
	v_cndmask_b16 v15, 0, v15, s53                             // 0000001C6398: D65D500F 00D61E80
	v_cndmask_b16 v16, 0, v16, s54                             // 0000001C63A0: D65D0010 00DA2080
	v_cndmask_b16 v16, 0, v16, s55                             // 0000001C63A8: D65D5010 00DE2080
	v_cndmask_b16 v17, 0, v17, s56                             // 0000001C63B0: D65D0011 00E22280
	v_cndmask_b16 v17, 0, v17, s57                             // 0000001C63B8: D65D5011 00E62280
	v_cndmask_b16 v18, 0, v18, s58                             // 0000001C63C0: D65D0012 00EA2480
	v_cndmask_b16 v18, 0, v18, s59                             // 0000001C63C8: D65D5012 00EE2480
	v_cndmask_b16 v38, 0, v23, s8                              // 0000001C63D0: D65D4026 00222E80
	s_cselect_b32 s8, -1, 0                                    // 0000001C63D8: 980880C1
	s_or_b32 s9, s42, 29                                       // 0000001C63DC: 8C099D2A
	v_cndmask_b16 v39, 0, v23, s8                              // 0000001C63E0: D65D1027 00222E80
	s_cmp_lt_i32 s9, s47                                       // 0000001C63E8: BF042F09
	v_dual_mul_f32 v23, v47, v34 :: v_dual_mul_f32 v24, v48, v35// 0000001C63EC: C8C6452F 17184730
	s_cselect_b32 s8, -1, 0                                    // 0000001C63F4: 980880C1
	s_or_b32 s9, s42, 30                                       // 0000001C63F8: 8C099E2A
	ds_store_b128 v212, v[11:14]                               // 0000001C63FC: DB7C0000 00000BD4
	ds_store_b128 v212, v[15:18] offset:16                     // 0000001C6404: DB7C0010 00000FD4
	ds_load_b128 v[11:14], v194 offset:61584                   // 0000001C640C: DBFCF090 0B0000C2
	v_mul_f32_e32 v33, v104, v36                               // 0000001C6414: 10424968
	s_waitcnt lgkmcnt(3)                                       // 0000001C6418: BF89FC37
	v_dual_mul_f32 v15, v101, v41 :: v_dual_mul_f32 v16, v100, v42// 0000001C641C: C8C65365 0F105564
	s_cmp_lt_i32 s9, s47                                       // 0000001C6424: BF042F09
	v_fma_mixlo_f16 v23, v23, s39, 0                           // 0000001C6428: CC210017 02004F17
	s_cselect_b32 s9, -1, 0                                    // 0000001C6430: 980980C1
	s_or_b32 s10, s42, 31                                      // 0000001C6434: 8C0A9F2A
	v_fma_mixhi_f16 v23, v24, s39, 0                           // 0000001C6438: CC220017 02004F18
	v_fma_mixlo_f16 v15, v15, s39, 0                           // 0000001C6440: CC21000F 02004F0F
	v_fma_mixhi_f16 v15, v16, s39, 0                           // 0000001C6448: CC22000F 02004F10
	v_mul_f32_e32 v16, v98, v43                                // 0000001C6450: 10205762
	v_fma_mixlo_f16 v24, v33, s39, 0                           // 0000001C6454: CC210018 02004F21
	s_cmp_lt_i32 s10, s47                                      // 0000001C645C: BF042F0A
	v_cndmask_b16 v39, 0, v23, s8                              // 0000001C6460: D65D4027 00222E80
	s_cselect_b32 s8, -1, 0                                    // 0000001C6468: 980880C1
	v_cndmask_b16 v40, 0, v23, s9                              // 0000001C646C: D65D1028 00262E80
	v_cndmask_b16 v40, 0, v24, s8                              // 0000001C6474: D65D4028 00223080
	s_or_b32 s8, s42, 32                                       // 0000001C647C: 8C08A02A
	v_cndmask_b16 v19, 0, v19, s60                             // 0000001C6480: D65D0013 00F22680
	s_cmp_lt_i32 s8, s47                                       // 0000001C6488: BF042F08
	v_cndmask_b16 v19, 0, v19, s61                             // 0000001C648C: D65D5013 00F62680
	s_cselect_b32 s8, -1, 0                                    // 0000001C6494: 980880C1
	s_or_b32 s9, s42, 33                                       // 0000001C6498: 8C09A12A
	v_cndmask_b16 v15, 0, v15, s8                              // 0000001C649C: D65D000F 00221E80
	s_cmp_lt_i32 s9, s47                                       // 0000001C64A4: BF042F09
	v_mul_f32_e32 v17, v99, v44                                // 0000001C64A8: 10225963
	s_cselect_b32 s8, -1, 0                                    // 0000001C64AC: 980880C1
	s_or_b32 s9, s42, 34                                       // 0000001C64B0: 8C09A22A
	v_cndmask_b16 v15, 0, v15, s8                              // 0000001C64B4: D65D500F 00221E80
	s_cmp_lt_i32 s9, s47                                       // 0000001C64BC: BF042F09
	s_waitcnt lgkmcnt(0)                                       // 0000001C64C0: BF89FC07
	v_mul_f32_e32 v18, v103, v11                               // 0000001C64C4: 10241767
	s_cselect_b32 s8, -1, 0                                    // 0000001C64C8: 980880C1
	s_or_b32 s9, s42, 35                                       // 0000001C64CC: 8C09A32A
	ds_store_b128 v212, v[19:22] offset:32                     // 0000001C64D0: DB7C0020 000013D4
	ds_store_b128 v212, v[37:40] offset:48                     // 0000001C64D8: DB7C0030 000025D4
	ds_load_b128 v[19:22], v194 offset:61600                   // 0000001C64E0: DBFCF0A0 130000C2
	s_cmp_lt_i32 s9, s47                                       // 0000001C64E8: BF042F09
	v_fma_mixlo_f16 v16, v16, s39, 0                           // 0000001C64EC: CC210010 02004F10
	s_cselect_b32 s9, -1, 0                                    // 0000001C64F4: 980980C1
	v_fma_mixlo_f16 v11, v17, s39, 0                           // 0000001C64F8: CC21000B 02004F11
	s_or_b32 s10, s42, 36                                      // 0000001C6500: 8C0AA42A
	v_fma_mixhi_f16 v11, v18, s39, 0                           // 0000001C6504: CC22000B 02004F12
	s_cmp_lt_i32 s10, s47                                      // 0000001C650C: BF042F0A
	v_cndmask_b16 v16, 0, v16, s8                              // 0000001C6510: D65D0010 00222080
	s_cselect_b32 s8, -1, 0                                    // 0000001C6518: 980880C1
	v_cndmask_b16 v16, 0, v11, s9                              // 0000001C651C: D65D4010 00261680
	s_or_b32 s9, s42, 37                                       // 0000001C6524: 8C09A52A
	v_cndmask_b16 v17, 0, v11, s8                              // 0000001C6528: D65D1011 00221680
	v_mul_f32_e32 v11, v102, v12                               // 0000001C6530: 10161966
	v_mul_f32_e32 v12, v110, v13                               // 0000001C6534: 10181B6E
	s_cmp_lt_i32 s9, s47                                       // 0000001C6538: BF042F09
	v_mul_f32_e32 v13, v109, v14                               // 0000001C653C: 101A1D6D
	s_cselect_b32 s8, -1, 0                                    // 0000001C6540: 980880C1
	s_or_b32 s9, s42, 38                                       // 0000001C6544: 8C09A62A
	v_fma_mixlo_f16 v11, v11, s39, 0                           // 0000001C6548: CC21000B 02004F0B
	s_cmp_lt_i32 s9, s47                                       // 0000001C6550: BF042F09
	v_fma_mixhi_f16 v11, v12, s39, 0                           // 0000001C6554: CC22000B 02004F0C
	s_cselect_b32 s9, -1, 0                                    // 0000001C655C: 980980C1
	s_or_b32 s10, s42, 39                                      // 0000001C6560: 8C0AA72A
	v_fma_mixhi_f16 v18, v13, s39, 0                           // 0000001C6564: CC220012 02004F0D
	s_cmp_lt_i32 s10, s47                                      // 0000001C656C: BF042F0A
	v_cndmask_b16 v17, 0, v11, s8                              // 0000001C6570: D65D4011 00221680
	v_cndmask_b16 v18, 0, v11, s9                              // 0000001C6578: D65D1012 00261680
	ds_load_b128 v[11:14], v194 offset:61616                   // 0000001C6580: DBFCF0B0 0B0000C2
	s_cselect_b32 s8, -1, 0                                    // 0000001C6588: 980880C1
	s_waitcnt lgkmcnt(1)                                       // 0000001C658C: BF89FC17
	v_mul_f32_e32 v19, v107, v19                               // 0000001C6590: 1026276B
	v_cndmask_b16 v18, 0, v18, s8                              // 0000001C6594: D65D5012 00222480
	s_or_b32 s8, s42, 40                                       // 0000001C659C: 8C08A82A
	v_mul_f32_e32 v20, v106, v20                               // 0000001C65A0: 1028296A
	s_cmp_lt_i32 s8, s47                                       // 0000001C65A4: BF042F08
	v_fma_mixlo_f16 v19, v19, s39, 0                           // 0000001C65A8: CC210013 02004F13
	s_cselect_b32 s8, -1, 0                                    // 0000001C65B0: 980880C1
	s_or_b32 s9, s42, 41                                       // 0000001C65B4: 8C09A92A
	v_fma_mixhi_f16 v19, v20, s39, 0                           // 0000001C65B8: CC220013 02004F14
	s_cmp_lt_i32 s9, s47                                       // 0000001C65C0: BF042F09
	v_cndmask_b16 v19, 0, v19, s8                              // 0000001C65C4: D65D0013 00222680
	s_cselect_b32 s8, -1, 0                                    // 0000001C65CC: 980880C1
	v_mul_f32_e32 v20, v105, v21                               // 0000001C65D0: 10282B69
	v_cndmask_b16 v19, 0, v19, s8                              // 0000001C65D4: D65D5013 00222680
	s_or_b32 s8, s42, 42                                       // 0000001C65DC: 8C08AA2A
	ds_load_b128 v[33:36], v194 offset:61632                   // 0000001C65E0: DBFCF0C0 210000C2
	v_mul_f32_e32 v21, v111, v22                               // 0000001C65E8: 102A2D6F
	s_cmp_lt_i32 s8, s47                                       // 0000001C65EC: BF042F08
	v_fma_mixlo_f16 v20, v20, s39, 0                           // 0000001C65F0: CC210014 02004F14
	s_cselect_b32 s8, -1, 0                                    // 0000001C65F8: 980880C1
	s_or_b32 s9, s42, 43                                       // 0000001C65FC: 8C09AB2A
	s_waitcnt lgkmcnt(1)                                       // 0000001C6600: BF89FC17
	v_mul_f32_e32 v12, v117, v12                               // 0000001C6604: 10181975
	s_cmp_lt_i32 s9, s47                                       // 0000001C6608: BF042F09
	v_fma_mixhi_f16 v20, v21, s39, 0                           // 0000001C660C: CC220014 02004F15
	v_cndmask_b16 v20, 0, v20, s8                              // 0000001C6614: D65D0014 00222880
	s_cselect_b32 s8, -1, 0                                    // 0000001C661C: 980880C1
	s_or_b32 s9, s42, 44                                       // 0000001C6620: 8C09AC2A
	v_mul_f32_e32 v11, v108, v11                               // 0000001C6624: 1016176C
	s_cmp_lt_i32 s9, s47                                       // 0000001C6628: BF042F09
	v_cndmask_b16 v20, 0, v20, s8                              // 0000001C662C: D65D5014 00222880
	s_cselect_b32 s8, -1, 0                                    // 0000001C6634: 980880C1
	s_or_b32 s9, s42, 45                                       // 0000001C6638: 8C09AD2A
	v_fma_mixlo_f16 v11, v11, s39, 0                           // 0000001C663C: CC21000B 02004F0B
	s_cmp_lt_i32 s9, s47                                       // 0000001C6644: BF042F09
	v_fma_mixhi_f16 v11, v12, s39, 0                           // 0000001C6648: CC22000B 02004F0C
	v_mul_f32_e32 v12, v115, v13                               // 0000001C6650: 10181B73
	s_cselect_b32 s9, -1, 0                                    // 0000001C6654: 980980C1
	s_or_b32 s10, s42, 46                                      // 0000001C6658: 8C0AAE2A
	v_cndmask_b16 v21, 0, v11, s8                              // 0000001C665C: D65D0015 00221680
	s_cmp_lt_i32 s10, s47                                      // 0000001C6664: BF042F0A
	v_cndmask_b16 v21, 0, v11, s9                              // 0000001C6668: D65D5015 00261680
	s_cselect_b32 s8, -1, 0                                    // 0000001C6670: 980880C1
	s_or_b32 s10, s42, 47                                      // 0000001C6674: 8C0AAF2A
	v_mul_f32_e32 v23, v114, v14                               // 0000001C6678: 102E1D72
	v_fma_mixlo_f16 v22, v12, s39, 0                           // 0000001C667C: CC210016 02004F0C
	ds_load_b128 v[11:14], v194 offset:61648                   // 0000001C6684: DBFCF0D0 0B0000C2
	s_waitcnt lgkmcnt(1)                                       // 0000001C668C: BF89FC17
	v_mul_f32_e32 v24, v113, v33                               // 0000001C6690: 10304371
	s_cmp_lt_i32 s10, s47                                      // 0000001C6694: BF042F0A
	v_fma_mixhi_f16 v22, v23, s39, 0                           // 0000001C6698: CC220016 02004F17
	s_cselect_b32 s9, -1, 0                                    // 0000001C66A0: 980980C1
	s_or_b32 s10, s42, 48                                      // 0000001C66A4: 8C0AB02A
	v_fma_mixlo_f16 v23, v24, s39, 0                           // 0000001C66A8: CC210017 02004F18
	s_cmp_lt_i32 s10, s47                                      // 0000001C66B0: BF042F0A
	v_cndmask_b16 v22, 0, v22, s8                              // 0000001C66B4: D65D0016 00222C80
	s_cselect_b32 s8, -1, 0                                    // 0000001C66BC: 980880C1
	v_mul_f32_e32 v24, v118, v35                               // 0000001C66C0: 10304776
	v_cndmask_b16 v33, 0, v23, s8                              // 0000001C66C4: D65D0021 00222E80
	s_or_b32 s8, s42, 49                                       // 0000001C66CC: 8C08B12A
	v_mul_f32_e32 v23, v112, v34                               // 0000001C66D0: 102E4570
	s_cmp_lt_i32 s8, s47                                       // 0000001C66D4: BF042F08
	v_cndmask_b16 v22, 0, v22, s9                              // 0000001C66D8: D65D5016 00262C80
	s_cselect_b32 s8, -1, 0                                    // 0000001C66E0: 980880C1
	s_or_b32 s9, s42, 50                                       // 0000001C66E4: 8C09B22A
	v_fma_mixlo_f16 v23, v23, s39, 0                           // 0000001C66E8: CC210017 02004F17
	v_fma_mixhi_f16 v23, v24, s39, 0                           // 0000001C66F0: CC220017 02004F18
	s_cmp_lt_i32 s9, s47                                       // 0000001C66F8: BF042F09
	s_waitcnt lgkmcnt(0)                                       // 0000001C66FC: BF89FC07
	v_mul_f32_e32 v24, v123, v11                               // 0000001C6700: 1030177B
	s_cselect_b32 s9, -1, 0                                    // 0000001C6704: 980980C1
	s_or_b32 s10, s42, 51                                      // 0000001C6708: 8C0AB32A
	v_cndmask_b16 v33, 0, v23, s8                              // 0000001C670C: D65D4021 00222E80
	v_cndmask_b16 v34, 0, v23, s9                              // 0000001C6714: D65D1022 00262E80
	v_mul_f32_e32 v23, v116, v36                               // 0000001C671C: 102E4974
	s_cmp_lt_i32 s10, s47                                      // 0000001C6720: BF042F0A
	v_mul_f32_e32 v12, v122, v12                               // 0000001C6724: 1018197A
	s_cselect_b32 s8, -1, 0                                    // 0000001C6728: 980880C1
	s_or_b32 s9, s42, 52                                       // 0000001C672C: 8C09B42A
	v_fma_mixlo_f16 v11, v23, s39, 0                           // 0000001C6730: CC21000B 02004F17
	v_fma_mixhi_f16 v11, v24, s39, 0                           // 0000001C6738: CC22000B 02004F18
	ds_load_b128 v[37:40], v194 offset:61664                   // 0000001C6740: DBFCF0E0 250000C2
	ds_load_b128 v[41:44], v194 offset:61680                   // 0000001C6748: DBFCF0F0 290000C2
	s_cmp_lt_i32 s9, s47                                       // 0000001C6750: BF042F09
	v_cmp_le_i32_e32 vcc_lo, s47, v155                         // 0000001C6754: 7C87362F
	s_cselect_b32 s9, -1, 0                                    // 0000001C6758: 980980C1
	s_or_b32 s10, s42, 53                                      // 0000001C675C: 8C0AB52A
	v_cndmask_b16 v34, 0, v11, s8                              // 0000001C6760: D65D4022 00221680
	v_cndmask_b16 v35, 0, v11, s9                              // 0000001C6768: D65D1023 00261680
	v_mul_f32_e32 v11, v121, v13                               // 0000001C6770: 10161B79
	v_fma_mixlo_f16 v12, v12, s39, 0                           // 0000001C6774: CC21000C 02004F0C
	s_cmp_lt_i32 s10, s47                                      // 0000001C677C: BF042F0A
	s_cselect_b32 s8, -1, 0                                    // 0000001C6780: 980880C1
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001C6784: BF870112
	v_fma_mixlo_f16 v11, v11, s39, 0                           // 0000001C6788: CC21000B 02004F0B
	v_cndmask_b16 v35, 0, v12, s8                              // 0000001C6790: D65D4023 00221880
	s_or_b32 s8, s42, 54                                       // 0000001C6798: 8C08B62A
	v_mul_f32_e32 v12, v120, v14                               // 0000001C679C: 10181D78
	s_cmp_lt_i32 s8, s47                                       // 0000001C67A0: BF042F08
	s_cselect_b32 s8, -1, 0                                    // 0000001C67A4: 980880C1
	s_or_b32 s9, s42, 55                                       // 0000001C67A8: 8C09B72A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C67AC: BF870001
	v_fma_mixhi_f16 v11, v12, s39, 0                           // 0000001C67B0: CC22000B 02004F0C
	s_cmp_lt_i32 s9, s47                                       // 0000001C67B8: BF042F09
	v_cndmask_b16 v36, 0, v11, s8                              // 0000001C67BC: D65D0024 00221680
	s_cselect_b32 s9, -1, 0                                    // 0000001C67C4: 980980C1
	s_or_b32 s10, s42, 56                                      // 0000001C67C8: 8C0AB82A
	v_cndmask_b16 v36, 0, v11, s9                              // 0000001C67CC: D65D5024 00261680
	s_cmp_lt_i32 s10, s47                                      // 0000001C67D4: BF042F0A
	s_waitcnt lgkmcnt(1)                                       // 0000001C67D8: BF89FC17
	v_mul_f32_e32 v11, v119, v37                               // 0000001C67DC: 10164B77
	s_cselect_b32 s8, -1, 0                                    // 0000001C67E0: 980880C1
	s_or_b32 s9, s42, 57                                       // 0000001C67E4: 8C09B92A
	v_dual_mul_f32 v12, v124, v38 :: v_dual_mul_f32 v13, v125, v39// 0000001C67E8: C8C64D7C 0C0C4F7D
	s_cmp_lt_i32 s9, s47                                       // 0000001C67F0: BF042F09
	v_fma_mixlo_f16 v11, v11, s39, 0                           // 0000001C67F4: CC21000B 02004F0B
	s_cselect_b32 s9, -1, 0                                    // 0000001C67FC: 980980C1
	s_or_b32 s10, s42, 58                                      // 0000001C6800: 8C0ABA2A
	v_fma_mixhi_f16 v11, v12, s39, 0                           // 0000001C6804: CC22000B 02004F0C
	v_fma_mixlo_f16 v12, v13, s39, 0                           // 0000001C680C: CC21000C 02004F0D
	s_cmp_lt_i32 s10, s47                                      // 0000001C6814: BF042F0A
	v_cndmask_b16 v11, 0, v11, s8                              // 0000001C6818: D65D000B 00221680
	s_cselect_b32 s8, -1, 0                                    // 0000001C6820: 980880C1
	s_waitcnt lgkmcnt(0)                                       // 0000001C6824: BF89FC07
	v_dual_mul_f32 v13, v130, v40 :: v_dual_mul_f32 v14, v129, v41// 0000001C6828: C8C65182 0D0E5381
	v_cndmask_b16 v12, 0, v12, s8                              // 0000001C6830: D65D000C 00221880
	s_or_b32 s8, s42, 59                                       // 0000001C6838: 8C08BB2A
	v_cndmask_b16 v11, 0, v11, s9                              // 0000001C683C: D65D500B 00261680
	s_cmp_lt_i32 s8, s47                                       // 0000001C6844: BF042F08
	v_fma_mixhi_f16 v12, v13, s39, 0                           // 0000001C6848: CC22000C 02004F0D
	s_cselect_b32 s8, -1, 0                                    // 0000001C6850: 980880C1
	s_or_b32 s9, s42, 60                                       // 0000001C6854: 8C09BC2A
	v_fma_mixlo_f16 v13, v14, s39, 0                           // 0000001C6858: CC21000D 02004F0E
	s_cmp_lt_i32 s9, s47                                       // 0000001C6860: BF042F09
	v_dual_mul_f32 v14, v127, v42 :: v_dual_mul_f32 v23, v126, v43// 0000001C6864: C8C6557F 0E16577E
	s_cselect_b32 s9, -1, 0                                    // 0000001C686C: 980980C1
	s_or_b32 s10, s42, 61                                      // 0000001C6870: 8C0ABD2A
	v_cndmask_b16 v12, 0, v12, s8                              // 0000001C6874: D65D500C 00221880
	s_cmp_lt_i32 s10, s47                                      // 0000001C687C: BF042F0A
	v_cndmask_b16 v13, 0, v13, s9                              // 0000001C6880: D65D000D 00261A80
	s_cselect_b32 s8, -1, 0                                    // 0000001C6888: 980880C1
	s_or_b32 s9, s42, 62                                       // 0000001C688C: 8C09BE2A
	v_mul_f32_e32 v24, v128, v44                               // 0000001C6890: 10305980
	s_cmp_lt_i32 s9, s47                                       // 0000001C6894: BF042F09
	v_fma_mixhi_f16 v13, v14, s39, 0                           // 0000001C6898: CC22000D 02004F0E
	s_cselect_b32 s9, -1, 0                                    // 0000001C68A0: 980980C1
	s_or_b32 s10, s42, 63                                      // 0000001C68A4: 8C0ABF2A
	v_fma_mixlo_f16 v14, v23, s39, 0                           // 0000001C68A8: CC21000E 02004F17
	v_fma_mixhi_f16 v14, v24, s39, 0                           // 0000001C68B0: CC22000E 02004F18
	s_cmp_lt_i32 s10, s47                                      // 0000001C68B8: BF042F0A
	v_cndmask_b16 v13, 0, v13, s8                              // 0000001C68BC: D65D500D 00221A80
	s_cselect_b32 s8, -1, 0                                    // 0000001C68C4: 980880C1
	v_cndmask_b16 v14, 0, v14, s9                              // 0000001C68C8: D65D000E 00261C80
	v_cndmask_b16 v14, 0, v14, s8                              // 0000001C68D0: D65D500E 00221C80
	ds_store_b128 v212, v[15:18] offset:64                     // 0000001C68D8: DB7C0040 00000FD4
	ds_store_b128 v212, v[19:22] offset:80                     // 0000001C68E0: DB7C0050 000013D4
	ds_store_b128 v212, v[33:36] offset:96                     // 0000001C68E8: DB7C0060 000021D4
	ds_store_b128 v212, v[11:14] offset:112                    // 0000001C68F0: DB7C0070 00000BD4
	s_and_saveexec_b32 s8, vcc_lo                              // 0000001C68F8: BE88206A
	s_cbranch_execz 67                                         // 0000001C68FC: BFA50043 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x1c0c>
	s_waitcnt vmcnt(1)                                         // 0000001C6900: BF8907F7
	v_mov_b32_e32 v1, 0                                        // 0000001C6904: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C6908: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000001C690C: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000001C6910: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000001C6914: 7E080301
	s_waitcnt vmcnt(0)                                         // 0000001C6918: BF8903F7
	v_mov_b32_e32 v5, v1                                       // 0000001C691C: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000001C6920: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000001C6924: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000001C6928: 7E100301
	v_mov_b32_e32 v25, v1                                      // 0000001C692C: 7E320301
	v_mov_b32_e32 v26, v1                                      // 0000001C6930: 7E340301
	v_mov_b32_e32 v27, v1                                      // 0000001C6934: 7E360301
	v_mov_b32_e32 v28, v1                                      // 0000001C6938: 7E380301
	v_mov_b32_e32 v29, v1                                      // 0000001C693C: 7E3A0301
	v_mov_b32_e32 v30, v1                                      // 0000001C6940: 7E3C0301
	v_mov_b32_e32 v31, v1                                      // 0000001C6944: 7E3E0301
	v_mov_b32_e32 v32, v1                                      // 0000001C6948: 7E400301
	v_mov_b32_e32 v49, v1                                      // 0000001C694C: 7E620301
	v_mov_b32_e32 v50, v1                                      // 0000001C6950: 7E640301
	v_mov_b32_e32 v51, v1                                      // 0000001C6954: 7E660301
	v_mov_b32_e32 v52, v1                                      // 0000001C6958: 7E680301
	v_mov_b32_e32 v53, v1                                      // 0000001C695C: 7E6A0301
	v_mov_b32_e32 v54, v1                                      // 0000001C6960: 7E6C0301
	v_mov_b32_e32 v55, v1                                      // 0000001C6964: 7E6E0301
	v_mov_b32_e32 v56, v1                                      // 0000001C6968: 7E700301
	v_mov_b32_e32 v57, v1                                      // 0000001C696C: 7E720301
	v_mov_b32_e32 v58, v1                                      // 0000001C6970: 7E740301
	v_mov_b32_e32 v59, v1                                      // 0000001C6974: 7E760301
	v_mov_b32_e32 v60, v1                                      // 0000001C6978: 7E780301
	v_mov_b32_e32 v61, v1                                      // 0000001C697C: 7E7A0301
	v_mov_b32_e32 v62, v1                                      // 0000001C6980: 7E7C0301
	v_mov_b32_e32 v63, v1                                      // 0000001C6984: 7E7E0301
	v_mov_b32_e32 v64, v1                                      // 0000001C6988: 7E800301
	v_mov_b32_e32 v65, v1                                      // 0000001C698C: 7E820301
	v_mov_b32_e32 v66, v1                                      // 0000001C6990: 7E840301
	v_mov_b32_e32 v67, v1                                      // 0000001C6994: 7E860301
	v_mov_b32_e32 v68, v1                                      // 0000001C6998: 7E880301
	v_mov_b32_e32 v69, v1                                      // 0000001C699C: 7E8A0301
	v_mov_b32_e32 v70, v1                                      // 0000001C69A0: 7E8C0301
	v_mov_b32_e32 v71, v1                                      // 0000001C69A4: 7E8E0301
	v_mov_b32_e32 v72, v1                                      // 0000001C69A8: 7E900301
	v_mov_b32_e32 v73, v1                                      // 0000001C69AC: 7E920301
	v_mov_b32_e32 v74, v1                                      // 0000001C69B0: 7E940301
	v_mov_b32_e32 v75, v1                                      // 0000001C69B4: 7E960301
	v_mov_b32_e32 v76, v1                                      // 0000001C69B8: 7E980301
	v_mov_b32_e32 v77, v1                                      // 0000001C69BC: 7E9A0301
	v_mov_b32_e32 v78, v1                                      // 0000001C69C0: 7E9C0301
	v_mov_b32_e32 v79, v1                                      // 0000001C69C4: 7E9E0301
	v_mov_b32_e32 v80, v1                                      // 0000001C69C8: 7EA00301
	v_mov_b32_e32 v81, v1                                      // 0000001C69CC: 7EA20301
	v_mov_b32_e32 v82, v1                                      // 0000001C69D0: 7EA40301
	v_mov_b32_e32 v83, v1                                      // 0000001C69D4: 7EA60301
	v_mov_b32_e32 v84, v1                                      // 0000001C69D8: 7EA80301
	v_mov_b32_e32 v85, v1                                      // 0000001C69DC: 7EAA0301
	v_mov_b32_e32 v86, v1                                      // 0000001C69E0: 7EAC0301
	v_mov_b32_e32 v87, v1                                      // 0000001C69E4: 7EAE0301
	v_mov_b32_e32 v88, v1                                      // 0000001C69E8: 7EB00301
	v_mov_b32_e32 v89, v1                                      // 0000001C69EC: 7EB20301
	v_mov_b32_e32 v90, v1                                      // 0000001C69F0: 7EB40301
	v_mov_b32_e32 v91, v1                                      // 0000001C69F4: 7EB60301
	v_mov_b32_e32 v92, v1                                      // 0000001C69F8: 7EB80301
	v_mov_b32_e32 v93, v1                                      // 0000001C69FC: 7EBA0301
	v_mov_b32_e32 v94, v1                                      // 0000001C6A00: 7EBC0301
	v_mov_b32_e32 v95, v1                                      // 0000001C6A04: 7EBE0301
	v_mov_b32_e32 v96, v1                                      // 0000001C6A08: 7EC00301
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001C6A0C: 8C7E087E
	s_mul_hi_u32 s8, s40, 0xfffff430                           // 0000001C6A10: 9688FF28 FFFFF430
	s_mul_i32 s9, s40, 0xfffff430                              // 0000001C6A18: 9609FF28 FFFFF430
	s_sub_i32 s8, s8, s40                                      // 0000001C6A20: 81882808
	s_add_u32 s0, s0, s9                                       // 0000001C6A24: 80000900
	s_addc_u32 s1, s1, s8                                      // 0000001C6A28: 82010801
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001C6A2C: BF870499
	s_lshl_b64 s[0:1], s[0:1], 13                              // 0000001C6A30: 84808D00
	.long 0xd700000b                                           // 0000001C6A34: D700000B
	v_cndmask_b32_e32 v0, v221, v0, vcc_lo                     // 0000001C6A38: 020001DD
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001C6A3C: BF8700A1
	v_add_co_ci_u32_e64 v12, null, s1, v222, s0                // 0000001C6A40: D5207C0C 0003BC01
	.long 0xd7000065                                           // 0000001C6A48: D7000065
	v_cndmask_b32_e32 v1, s30, v9, vcc_lo                      // 0000001C6A4C: 0202121E
	v_add_co_ci_u32_e64 v102, null, s31, v10, s0               // 0000001C6A50: D5207C66 0002141F
	s_clause 0x7                                               // 0000001C6A58: BF850007
	global_load_b128 v[45:48], v[11:12], off offset:16         // 0000001C6A5C: DC5E0010 2D7C000B
	global_load_b128 v[41:44], v[11:12], off                   // 0000001C6A64: DC5E0000 297C000B
	global_load_b128 v[37:40], v[11:12], off offset:48         // 0000001C6A6C: DC5E0030 257C000B
	global_load_b128 v[33:36], v[11:12], off offset:32         // 0000001C6A74: DC5E0020 217C000B
	global_load_b128 v[21:24], v[11:12], off offset:80         // 0000001C6A7C: DC5E0050 157C000B
	global_load_b128 v[17:20], v[11:12], off offset:64         // 0000001C6A84: DC5E0040 117C000B
	global_load_b128 v[13:16], v[11:12], off offset:112        // 0000001C6A8C: DC5E0070 0D7C000B
	global_load_b128 v[9:12], v[11:12], off offset:96          // 0000001C6A94: DC5E0060 097C000B
	s_clause 0xf                                               // 0000001C6A9C: BF85000F
	global_load_b128 v[185:188], v[101:102], off               // 0000001C6AA0: DC5E0000 B97C0065
	global_load_b128 v[189:192], v[101:102], off offset:16     // 0000001C6AA8: DC5E0010 BD7C0065
	global_load_b128 v[177:180], v[101:102], off offset:32     // 0000001C6AB0: DC5E0020 B17C0065
	global_load_b128 v[181:184], v[101:102], off offset:48     // 0000001C6AB8: DC5E0030 B57C0065
	global_load_b128 v[169:172], v[101:102], off offset:64     // 0000001C6AC0: DC5E0040 A97C0065
	global_load_b128 v[173:176], v[101:102], off offset:80     // 0000001C6AC8: DC5E0050 AD7C0065
	global_load_b128 v[161:164], v[101:102], off offset:96     // 0000001C6AD0: DC5E0060 A17C0065
	global_load_b128 v[165:168], v[101:102], off offset:112    // 0000001C6AD8: DC5E0070 A57C0065
	global_load_b128 v[153:156], v[101:102], off offset:128    // 0000001C6AE0: DC5E0080 997C0065
	global_load_b128 v[157:160], v[101:102], off offset:144    // 0000001C6AE8: DC5E0090 9D7C0065
	global_load_b128 v[145:148], v[101:102], off offset:160    // 0000001C6AF0: DC5E00A0 917C0065
	global_load_b128 v[149:152], v[101:102], off offset:176    // 0000001C6AF8: DC5E00B0 957C0065
	global_load_b128 v[129:132], v[101:102], off offset:192    // 0000001C6B00: DC5E00C0 817C0065
	global_load_b128 v[133:136], v[101:102], off offset:208    // 0000001C6B08: DC5E00D0 857C0065
	global_load_b128 v[97:100], v[101:102], off offset:224     // 0000001C6B10: DC5E00E0 617C0065
	global_load_b128 v[101:104], v[101:102], off offset:240    // 0000001C6B18: DC5E00F0 657C0065
	s_and_saveexec_b32 s0, vcc_lo                              // 0000001C6B20: BE80206A
	s_cbranch_execz 67                                         // 0000001C6B24: BFA50043 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x1e34>
	s_waitcnt vmcnt(1)                                         // 0000001C6B28: BF8907F7
	v_mov_b32_e32 v97, 0                                       // 0000001C6B2C: 7EC20280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C6B30: BF870001
	v_mov_b32_e32 v98, v97                                     // 0000001C6B34: 7EC40361
	v_mov_b32_e32 v99, v97                                     // 0000001C6B38: 7EC60361
	v_mov_b32_e32 v100, v97                                    // 0000001C6B3C: 7EC80361
	s_waitcnt vmcnt(0)                                         // 0000001C6B40: BF8903F7
	v_mov_b32_e32 v101, v97                                    // 0000001C6B44: 7ECA0361
	v_mov_b32_e32 v102, v97                                    // 0000001C6B48: 7ECC0361
	v_mov_b32_e32 v103, v97                                    // 0000001C6B4C: 7ECE0361
	v_mov_b32_e32 v104, v97                                    // 0000001C6B50: 7ED00361
	v_mov_b32_e32 v129, v97                                    // 0000001C6B54: 7F020361
	v_mov_b32_e32 v130, v97                                    // 0000001C6B58: 7F040361
	v_mov_b32_e32 v131, v97                                    // 0000001C6B5C: 7F060361
	v_mov_b32_e32 v132, v97                                    // 0000001C6B60: 7F080361
	v_mov_b32_e32 v133, v97                                    // 0000001C6B64: 7F0A0361
	v_mov_b32_e32 v134, v97                                    // 0000001C6B68: 7F0C0361
	v_mov_b32_e32 v135, v97                                    // 0000001C6B6C: 7F0E0361
	v_mov_b32_e32 v136, v97                                    // 0000001C6B70: 7F100361
	v_mov_b32_e32 v145, v97                                    // 0000001C6B74: 7F220361
	v_mov_b32_e32 v146, v97                                    // 0000001C6B78: 7F240361
	v_mov_b32_e32 v147, v97                                    // 0000001C6B7C: 7F260361
	v_mov_b32_e32 v148, v97                                    // 0000001C6B80: 7F280361
	v_mov_b32_e32 v149, v97                                    // 0000001C6B84: 7F2A0361
	v_mov_b32_e32 v150, v97                                    // 0000001C6B88: 7F2C0361
	v_mov_b32_e32 v151, v97                                    // 0000001C6B8C: 7F2E0361
	v_mov_b32_e32 v152, v97                                    // 0000001C6B90: 7F300361
	v_mov_b32_e32 v153, v97                                    // 0000001C6B94: 7F320361
	v_mov_b32_e32 v154, v97                                    // 0000001C6B98: 7F340361
	v_mov_b32_e32 v155, v97                                    // 0000001C6B9C: 7F360361
	v_mov_b32_e32 v156, v97                                    // 0000001C6BA0: 7F380361
	v_mov_b32_e32 v157, v97                                    // 0000001C6BA4: 7F3A0361
	v_mov_b32_e32 v158, v97                                    // 0000001C6BA8: 7F3C0361
	v_mov_b32_e32 v159, v97                                    // 0000001C6BAC: 7F3E0361
	v_mov_b32_e32 v160, v97                                    // 0000001C6BB0: 7F400361
	v_mov_b32_e32 v161, v97                                    // 0000001C6BB4: 7F420361
	v_mov_b32_e32 v162, v97                                    // 0000001C6BB8: 7F440361
	v_mov_b32_e32 v163, v97                                    // 0000001C6BBC: 7F460361
	v_mov_b32_e32 v164, v97                                    // 0000001C6BC0: 7F480361
	v_mov_b32_e32 v165, v97                                    // 0000001C6BC4: 7F4A0361
	v_mov_b32_e32 v166, v97                                    // 0000001C6BC8: 7F4C0361
	v_mov_b32_e32 v167, v97                                    // 0000001C6BCC: 7F4E0361
	v_mov_b32_e32 v168, v97                                    // 0000001C6BD0: 7F500361
	v_mov_b32_e32 v169, v97                                    // 0000001C6BD4: 7F520361
	v_mov_b32_e32 v170, v97                                    // 0000001C6BD8: 7F540361
	v_mov_b32_e32 v171, v97                                    // 0000001C6BDC: 7F560361
	v_mov_b32_e32 v172, v97                                    // 0000001C6BE0: 7F580361
	v_mov_b32_e32 v173, v97                                    // 0000001C6BE4: 7F5A0361
	v_mov_b32_e32 v174, v97                                    // 0000001C6BE8: 7F5C0361
	v_mov_b32_e32 v175, v97                                    // 0000001C6BEC: 7F5E0361
	v_mov_b32_e32 v176, v97                                    // 0000001C6BF0: 7F600361
	v_mov_b32_e32 v177, v97                                    // 0000001C6BF4: 7F620361
	v_mov_b32_e32 v178, v97                                    // 0000001C6BF8: 7F640361
	v_mov_b32_e32 v179, v97                                    // 0000001C6BFC: 7F660361
	v_mov_b32_e32 v180, v97                                    // 0000001C6C00: 7F680361
	v_mov_b32_e32 v181, v97                                    // 0000001C6C04: 7F6A0361
	v_mov_b32_e32 v182, v97                                    // 0000001C6C08: 7F6C0361
	v_mov_b32_e32 v183, v97                                    // 0000001C6C0C: 7F6E0361
	v_mov_b32_e32 v184, v97                                    // 0000001C6C10: 7F700361
	v_mov_b32_e32 v185, v97                                    // 0000001C6C14: 7F720361
	v_mov_b32_e32 v186, v97                                    // 0000001C6C18: 7F740361
	v_mov_b32_e32 v187, v97                                    // 0000001C6C1C: 7F760361
	v_mov_b32_e32 v188, v97                                    // 0000001C6C20: 7F780361
	v_mov_b32_e32 v189, v97                                    // 0000001C6C24: 7F7A0361
	v_mov_b32_e32 v190, v97                                    // 0000001C6C28: 7F7C0361
	v_mov_b32_e32 v191, v97                                    // 0000001C6C2C: 7F7E0361
	v_mov_b32_e32 v192, v97                                    // 0000001C6C30: 7F800361
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001C6C34: 8C7E007E
	ds_load_b128 v[105:108], v214                              // 0000001C6C38: DBFC0000 690000D6
	ds_load_b128 v[109:112], v214 offset:16                    // 0000001C6C40: DBFC0010 6D0000D6
	ds_load_b128 v[113:116], v214 offset:32                    // 0000001C6C48: DBFC0020 710000D6
	ds_load_b128 v[117:120], v214 offset:48                    // 0000001C6C50: DBFC0030 750000D6
	ds_load_b128 v[121:124], v214 offset:8448                  // 0000001C6C58: DBFC2100 790000D6
	ds_load_b128 v[125:128], v214 offset:8464                  // 0000001C6C60: DBFC2110 7D0000D6
	ds_load_b128 v[137:140], v214 offset:8480                  // 0000001C6C68: DBFC2120 890000D6
	ds_load_b128 v[141:144], v214 offset:8496                  // 0000001C6C70: DBFC2130 8D0000D6
	ds_load_b128 v[227:230], v214 offset:16896                 // 0000001C6C78: DBFC4200 E30000D6
	ds_load_b128 v[235:238], v214 offset:25344                 // 0000001C6C80: DBFC6300 EB0000D6
	v_dual_mov_b32 v250, s27 :: v_dual_mov_b32 v249, s26       // 0000001C6C88: CA10001B FAF8001A
	v_dual_mov_b32 v248, s25 :: v_dual_mov_b32 v247, s24       // 0000001C6C90: CA100019 F8F60018
	v_dual_mov_b32 v246, s23 :: v_dual_mov_b32 v245, s22       // 0000001C6C98: CA100017 F6F40016
	v_dual_mov_b32 v244, s21 :: v_dual_mov_b32 v243, s20       // 0000001C6CA0: CA100015 F4F20014
	ds_load_b128 v[251:254], v214 offset:64                    // 0000001C6CA8: DBFC0040 FB0000D6
	s_waitcnt lgkmcnt(10)                                      // 0000001C6CB0: BF89FCA7
	v_fma_mixlo_f16 v105, v105, s39, 0                         // 0000001C6CB4: CC210069 02004F69
	v_fma_mixhi_f16 v105, v106, s39, 0                         // 0000001C6CBC: CC220069 02004F6A
	v_fma_mixlo_f16 v106, v107, s39, 0                         // 0000001C6CC4: CC21006A 02004F6B
	s_waitcnt lgkmcnt(9)                                       // 0000001C6CCC: BF89FC97
	v_fma_mixlo_f16 v107, v109, s39, 0                         // 0000001C6CD0: CC21006B 02004F6D
	v_fma_mixhi_f16 v107, v110, s39, 0                         // 0000001C6CD8: CC22006B 02004F6E
	s_waitcnt lgkmcnt(8)                                       // 0000001C6CE0: BF89FC87
	v_fma_mixlo_f16 v109, v113, s39, 0                         // 0000001C6CE4: CC21006D 02004F71
	v_fma_mixhi_f16 v109, v114, s39, 0                         // 0000001C6CEC: CC22006D 02004F72
	v_fma_mixlo_f16 v110, v115, s39, 0                         // 0000001C6CF4: CC21006E 02004F73
	v_fma_mixhi_f16 v110, v116, s39, 0                         // 0000001C6CFC: CC22006E 02004F74
	s_waitcnt lgkmcnt(6)                                       // 0000001C6D04: BF89FC67
	v_fma_mixlo_f16 v113, v121, s39, 0                         // 0000001C6D08: CC210071 02004F79
	v_fma_mixhi_f16 v113, v122, s39, 0                         // 0000001C6D10: CC220071 02004F7A
	v_fma_mixlo_f16 v114, v123, s39, 0                         // 0000001C6D18: CC210072 02004F7B
	v_fma_mixhi_f16 v114, v124, s39, 0                         // 0000001C6D20: CC220072 02004F7C
	s_waitcnt lgkmcnt(5)                                       // 0000001C6D28: BF89FC57
	v_fma_mixlo_f16 v115, v125, s39, 0                         // 0000001C6D2C: CC210073 02004F7D
	ds_load_b128 v[121:124], v214 offset:16912                 // 0000001C6D34: DBFC4210 790000D6
	v_fma_mixhi_f16 v115, v126, s39, 0                         // 0000001C6D3C: CC220073 02004F7E
	v_fma_mixlo_f16 v116, v127, s39, 0                         // 0000001C6D44: CC210074 02004F7F
	v_fma_mixhi_f16 v116, v128, s39, 0                         // 0000001C6D4C: CC220074 02004F80
	ds_load_b128 v[125:128], v214 offset:16928                 // 0000001C6D54: DBFC4220 7D0000D6
	v_fma_mixhi_f16 v106, v108, s39, 0                         // 0000001C6D5C: CC22006A 02004F6C
	v_fma_mixlo_f16 v108, v111, s39, 0                         // 0000001C6D64: CC21006C 02004F6F
	v_fma_mixhi_f16 v108, v112, s39, 0                         // 0000001C6D6C: CC22006C 02004F70
	v_fma_mixlo_f16 v111, v117, s39, 0                         // 0000001C6D74: CC21006F 02004F75
	v_fma_mixhi_f16 v111, v118, s39, 0                         // 0000001C6D7C: CC22006F 02004F76
	v_fma_mixlo_f16 v112, v119, s39, 0                         // 0000001C6D84: CC210070 02004F77
	v_fma_mixhi_f16 v112, v120, s39, 0                         // 0000001C6D8C: CC220070 02004F78
	s_waitcnt lgkmcnt(6)                                       // 0000001C6D94: BF89FC67
	v_fma_mixlo_f16 v117, v137, s39, 0                         // 0000001C6D98: CC210075 02004F89
	v_fma_mixhi_f16 v117, v138, s39, 0                         // 0000001C6DA0: CC220075 02004F8A
	v_fma_mixlo_f16 v118, v139, s39, 0                         // 0000001C6DA8: CC210076 02004F8B
	v_fma_mixhi_f16 v118, v140, s39, 0                         // 0000001C6DB0: CC220076 02004F8C
	ds_load_b128 v[137:140], v214 offset:16944                 // 0000001C6DB8: DBFC4230 890000D6
	s_waitcnt lgkmcnt(6)                                       // 0000001C6DC0: BF89FC67
	v_fma_mixlo_f16 v119, v141, s39, 0                         // 0000001C6DC4: CC210077 02004F8D
	v_fma_mixhi_f16 v119, v142, s39, 0                         // 0000001C6DCC: CC220077 02004F8E
	v_fma_mixlo_f16 v120, v143, s39, 0                         // 0000001C6DD4: CC210078 02004F8F
	v_fma_mixhi_f16 v120, v144, s39, 0                         // 0000001C6DDC: CC220078 02004F90
	s_waitcnt lgkmcnt(5)                                       // 0000001C6DE4: BF89FC57
	v_fma_mixlo_f16 v227, v227, s39, 0                         // 0000001C6DE8: CC2100E3 02004FE3
	v_fma_mixhi_f16 v227, v228, s39, 0                         // 0000001C6DF0: CC2200E3 02004FE4
	v_fma_mixlo_f16 v228, v229, s39, 0                         // 0000001C6DF8: CC2100E4 02004FE5
	v_fma_mixhi_f16 v228, v230, s39, 0                         // 0000001C6E00: CC2200E4 02004FE6
	ds_load_b128 v[141:144], v214 offset:25360                 // 0000001C6E08: DBFC6310 8D0000D6
	s_waitcnt lgkmcnt(3)                                       // 0000001C6E10: BF89FC37
	v_fma_mixlo_f16 v229, v121, s39, 0                         // 0000001C6E14: CC2100E5 02004F79
	v_fma_mixhi_f16 v229, v122, s39, 0                         // 0000001C6E1C: CC2200E5 02004F7A
	v_fma_mixlo_f16 v230, v123, s39, 0                         // 0000001C6E24: CC2100E6 02004F7B
	v_fma_mixhi_f16 v230, v124, s39, 0                         // 0000001C6E2C: CC2200E6 02004F7C
	ds_load_b128 v[121:124], v214 offset:25376                 // 0000001C6E34: DBFC6320 790000D6
	s_waitcnt lgkmcnt(3)                                       // 0000001C6E3C: BF89FC37
	v_fma_mixlo_f16 v231, v125, s39, 0                         // 0000001C6E40: CC2100E7 02004F7D
	v_fma_mixhi_f16 v231, v126, s39, 0                         // 0000001C6E48: CC2200E7 02004F7E
	v_fma_mixlo_f16 v232, v127, s39, 0                         // 0000001C6E50: CC2100E8 02004F7F
	v_fma_mixhi_f16 v232, v128, s39, 0                         // 0000001C6E58: CC2200E8 02004F80
	ds_load_b128 v[125:128], v214 offset:25392                 // 0000001C6E60: DBFC6330 7D0000D6
	s_waitcnt lgkmcnt(3)                                       // 0000001C6E68: BF89FC37
	v_fma_mixlo_f16 v233, v137, s39, 0                         // 0000001C6E6C: CC2100E9 02004F89
	v_fma_mixhi_f16 v233, v138, s39, 0                         // 0000001C6E74: CC2200E9 02004F8A
	v_fma_mixlo_f16 v234, v139, s39, 0                         // 0000001C6E7C: CC2100EA 02004F8B
	v_fma_mixhi_f16 v234, v140, s39, 0                         // 0000001C6E84: CC2200EA 02004F8C
	v_fma_mixlo_f16 v235, v235, s39, 0                         // 0000001C6E8C: CC2100EB 02004FEB
	v_fma_mixhi_f16 v235, v236, s39, 0                         // 0000001C6E94: CC2200EB 02004FEC
	v_fma_mixlo_f16 v236, v237, s39, 0                         // 0000001C6E9C: CC2100EC 02004FED
	v_fma_mixhi_f16 v236, v238, s39, 0                         // 0000001C6EA4: CC2200EC 02004FEE
	s_waitcnt lgkmcnt(2)                                       // 0000001C6EAC: BF89FC27
	v_fma_mixlo_f16 v237, v141, s39, 0                         // 0000001C6EB0: CC2100ED 02004F8D
	v_fma_mixhi_f16 v237, v142, s39, 0                         // 0000001C6EB8: CC2200ED 02004F8E
	v_fma_mixlo_f16 v238, v143, s39, 0                         // 0000001C6EC0: CC2100EE 02004F8F
	v_fma_mixhi_f16 v238, v144, s39, 0                         // 0000001C6EC8: CC2200EE 02004F90
	s_waitcnt vmcnt(14)                                        // 0000001C6ED0: BF893BF7
	v_wmma_f32_16x16x16_f16 v[137:144], v[185:192], v[105:112], v[243:250]// 0000001C6ED4: CC404089 1FCED3B9
	s_waitcnt lgkmcnt(1)                                       // 0000001C6EDC: BF89FC17
	v_fma_mixlo_f16 v239, v121, s39, 0                         // 0000001C6EE0: CC2100EF 02004F79
	v_fma_mixhi_f16 v239, v122, s39, 0                         // 0000001C6EE8: CC2200EF 02004F7A
	v_fma_mixlo_f16 v240, v123, s39, 0                         // 0000001C6EF0: CC2100F0 02004F7B
	v_fma_mixhi_f16 v240, v124, s39, 0                         // 0000001C6EF8: CC2200F0 02004F7C
	s_waitcnt lgkmcnt(0)                                       // 0000001C6F00: BF89FC07
	v_fma_mixlo_f16 v241, v125, s39, 0                         // 0000001C6F04: CC2100F1 02004F7D
	v_fma_mixhi_f16 v241, v126, s39, 0                         // 0000001C6F0C: CC2200F1 02004F7E
	v_fma_mixlo_f16 v242, v127, s39, 0                         // 0000001C6F14: CC2100F2 02004F7F
	v_fma_mixhi_f16 v242, v128, s39, 0                         // 0000001C6F1C: CC2200F2 02004F80
	v_wmma_f32_16x16x16_f16 v[121:128], v[185:192], v[113:120], v[243:250]// 0000001C6F24: CC404079 1FCEE3B9
	v_wmma_f32_16x16x16_f16 v[113:120], v[185:192], v[227:234], v[243:250]// 0000001C6F2C: CC404071 1FCFC7B9
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C6F34: BF870003
	v_wmma_f32_16x16x16_f16 v[105:112], v[185:192], v[235:242], v[243:250]// 0000001C6F38: CC404069 1FCFD7B9
	ds_load_b128 v[187:190], v214 offset:80                    // 0000001C6F40: DBFC0050 BB0000D6
	ds_load_b128 v[227:230], v214 offset:96                    // 0000001C6F48: DBFC0060 E30000D6
	ds_load_b128 v[231:234], v214 offset:112                   // 0000001C6F50: DBFC0070 E70000D6
	ds_load_b128 v[235:238], v214 offset:8512                  // 0000001C6F58: DBFC2140 EB0000D6
	v_fma_mixlo_f16 v185, v251, s39, 0                         // 0000001C6F60: CC2100B9 02004FFB
	v_fma_mixhi_f16 v185, v252, s39, 0                         // 0000001C6F68: CC2200B9 02004FFC
	v_fma_mixlo_f16 v186, v253, s39, 0                         // 0000001C6F70: CC2100BA 02004FFD
	v_fma_mixhi_f16 v186, v254, s39, 0                         // 0000001C6F78: CC2200BA 02004FFE
	ds_load_b128 v[239:242], v214 offset:17120                 // 0000001C6F80: DBFC42E0 EF0000D6
	s_waitcnt lgkmcnt(4)                                       // 0000001C6F88: BF89FC47
	v_fma_mixlo_f16 v187, v187, s39, 0                         // 0000001C6F8C: CC2100BB 02004FBB
	v_fma_mixhi_f16 v187, v188, s39, 0                         // 0000001C6F94: CC2200BB 02004FBC
	v_fma_mixlo_f16 v188, v189, s39, 0                         // 0000001C6F9C: CC2100BC 02004FBD
	v_fma_mixhi_f16 v188, v190, s39, 0                         // 0000001C6FA4: CC2200BC 02004FBE
	s_waitcnt lgkmcnt(3)                                       // 0000001C6FAC: BF89FC37
	v_fma_mixlo_f16 v189, v227, s39, 0                         // 0000001C6FB0: CC2100BD 02004FE3
	v_fma_mixhi_f16 v189, v228, s39, 0                         // 0000001C6FB8: CC2200BD 02004FE4
	v_fma_mixlo_f16 v190, v229, s39, 0                         // 0000001C6FC0: CC2100BE 02004FE5
	v_fma_mixhi_f16 v190, v230, s39, 0                         // 0000001C6FC8: CC2200BE 02004FE6
	ds_load_b128 v[227:230], v214 offset:8528                  // 0000001C6FD0: DBFC2150 E30000D6
	s_waitcnt lgkmcnt(3)                                       // 0000001C6FD8: BF89FC37
	v_fma_mixlo_f16 v191, v231, s39, 0                         // 0000001C6FDC: CC2100BF 02004FE7
	v_fma_mixhi_f16 v191, v232, s39, 0                         // 0000001C6FE4: CC2200BF 02004FE8
	v_fma_mixlo_f16 v192, v233, s39, 0                         // 0000001C6FEC: CC2100C0 02004FE9
	v_fma_mixhi_f16 v192, v234, s39, 0                         // 0000001C6FF4: CC2200C0 02004FEA
	ds_load_b128 v[231:234], v214 offset:8544                  // 0000001C6FFC: DBFC2160 E70000D6
	s_waitcnt vmcnt(12)                                        // 0000001C7004: BF8933F7
	v_wmma_f32_16x16x16_f16 v[137:144], v[177:184], v[185:192], v[137:144]// 0000001C7008: CC404089 1E2773B1
	s_waitcnt lgkmcnt(3)                                       // 0000001C7010: BF89FC37
	v_fma_mixlo_f16 v185, v235, s39, 0                         // 0000001C7014: CC2100B9 02004FEB
	v_fma_mixhi_f16 v185, v236, s39, 0                         // 0000001C701C: CC2200B9 02004FEC
	v_fma_mixlo_f16 v186, v237, s39, 0                         // 0000001C7024: CC2100BA 02004FED
	v_fma_mixhi_f16 v186, v238, s39, 0                         // 0000001C702C: CC2200BA 02004FEE
	ds_load_b128 v[235:238], v214 offset:8560                  // 0000001C7034: DBFC2170 EB0000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C703C: BF89FC27
	v_fma_mixlo_f16 v187, v227, s39, 0                         // 0000001C7040: CC2100BB 02004FE3
	v_fma_mixhi_f16 v187, v228, s39, 0                         // 0000001C7048: CC2200BB 02004FE4
	v_fma_mixlo_f16 v188, v229, s39, 0                         // 0000001C7050: CC2100BC 02004FE5
	v_fma_mixhi_f16 v188, v230, s39, 0                         // 0000001C7058: CC2200BC 02004FE6
	ds_load_b128 v[227:230], v214 offset:16960                 // 0000001C7060: DBFC4240 E30000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C7068: BF89FC27
	v_fma_mixlo_f16 v189, v231, s39, 0                         // 0000001C706C: CC2100BD 02004FE7
	v_fma_mixhi_f16 v189, v232, s39, 0                         // 0000001C7074: CC2200BD 02004FE8
	v_fma_mixlo_f16 v190, v233, s39, 0                         // 0000001C707C: CC2100BE 02004FE9
	v_fma_mixhi_f16 v190, v234, s39, 0                         // 0000001C7084: CC2200BE 02004FEA
	ds_load_b128 v[231:234], v214 offset:16976                 // 0000001C708C: DBFC4250 E70000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C7094: BF89FC27
	v_fma_mixlo_f16 v191, v235, s39, 0                         // 0000001C7098: CC2100BF 02004FEB
	v_fma_mixhi_f16 v191, v236, s39, 0                         // 0000001C70A0: CC2200BF 02004FEC
	v_fma_mixlo_f16 v192, v237, s39, 0                         // 0000001C70A8: CC2100C0 02004FED
	v_fma_mixhi_f16 v192, v238, s39, 0                         // 0000001C70B0: CC2200C0 02004FEE
	ds_load_b128 v[235:238], v214 offset:16992                 // 0000001C70B8: DBFC4260 EB0000D6
	v_wmma_f32_16x16x16_f16 v[121:128], v[177:184], v[185:192], v[121:128]// 0000001C70C0: CC404079 1DE773B1
	s_waitcnt lgkmcnt(2)                                       // 0000001C70C8: BF89FC27
	v_fma_mixlo_f16 v185, v227, s39, 0                         // 0000001C70CC: CC2100B9 02004FE3
	v_fma_mixhi_f16 v185, v228, s39, 0                         // 0000001C70D4: CC2200B9 02004FE4
	v_fma_mixlo_f16 v186, v229, s39, 0                         // 0000001C70DC: CC2100BA 02004FE5
	v_fma_mixhi_f16 v186, v230, s39, 0                         // 0000001C70E4: CC2200BA 02004FE6
	ds_load_b128 v[227:230], v214 offset:17008                 // 0000001C70EC: DBFC4270 E30000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C70F4: BF89FC27
	v_fma_mixlo_f16 v187, v231, s39, 0                         // 0000001C70F8: CC2100BB 02004FE7
	v_fma_mixhi_f16 v187, v232, s39, 0                         // 0000001C7100: CC2200BB 02004FE8
	v_fma_mixlo_f16 v188, v233, s39, 0                         // 0000001C7108: CC2100BC 02004FE9
	v_fma_mixhi_f16 v188, v234, s39, 0                         // 0000001C7110: CC2200BC 02004FEA
	ds_load_b128 v[231:234], v214 offset:25408                 // 0000001C7118: DBFC6340 E70000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C7120: BF89FC27
	v_fma_mixlo_f16 v189, v235, s39, 0                         // 0000001C7124: CC2100BD 02004FEB
	v_fma_mixhi_f16 v189, v236, s39, 0                         // 0000001C712C: CC2200BD 02004FEC
	v_fma_mixlo_f16 v190, v237, s39, 0                         // 0000001C7134: CC2100BE 02004FED
	v_fma_mixhi_f16 v190, v238, s39, 0                         // 0000001C713C: CC2200BE 02004FEE
	ds_load_b128 v[235:238], v214 offset:25424                 // 0000001C7144: DBFC6350 EB0000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C714C: BF89FC27
	v_fma_mixlo_f16 v191, v227, s39, 0                         // 0000001C7150: CC2100BF 02004FE3
	v_fma_mixhi_f16 v191, v228, s39, 0                         // 0000001C7158: CC2200BF 02004FE4
	v_fma_mixlo_f16 v192, v229, s39, 0                         // 0000001C7160: CC2100C0 02004FE5
	v_fma_mixhi_f16 v192, v230, s39, 0                         // 0000001C7168: CC2200C0 02004FE6
	ds_load_b128 v[227:230], v214 offset:25440                 // 0000001C7170: DBFC6360 E30000D6
	v_wmma_f32_16x16x16_f16 v[113:120], v[177:184], v[185:192], v[113:120]// 0000001C7178: CC404071 1DC773B1
	s_waitcnt lgkmcnt(2)                                       // 0000001C7180: BF89FC27
	v_fma_mixlo_f16 v185, v231, s39, 0                         // 0000001C7184: CC2100B9 02004FE7
	v_fma_mixhi_f16 v185, v232, s39, 0                         // 0000001C718C: CC2200B9 02004FE8
	v_fma_mixlo_f16 v186, v233, s39, 0                         // 0000001C7194: CC2100BA 02004FE9
	v_fma_mixhi_f16 v186, v234, s39, 0                         // 0000001C719C: CC2200BA 02004FEA
	ds_load_b128 v[231:234], v214 offset:25456                 // 0000001C71A4: DBFC6370 E70000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C71AC: BF89FC27
	v_fma_mixlo_f16 v187, v235, s39, 0                         // 0000001C71B0: CC2100BB 02004FEB
	v_fma_mixhi_f16 v187, v236, s39, 0                         // 0000001C71B8: CC2200BB 02004FEC
	v_fma_mixlo_f16 v188, v237, s39, 0                         // 0000001C71C0: CC2100BC 02004FED
	v_fma_mixhi_f16 v188, v238, s39, 0                         // 0000001C71C8: CC2200BC 02004FEE
	ds_load_b128 v[235:238], v214 offset:128                   // 0000001C71D0: DBFC0080 EB0000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C71D8: BF89FC27
	v_fma_mixlo_f16 v189, v227, s39, 0                         // 0000001C71DC: CC2100BD 02004FE3
	v_fma_mixhi_f16 v189, v228, s39, 0                         // 0000001C71E4: CC2200BD 02004FE4
	v_fma_mixlo_f16 v190, v229, s39, 0                         // 0000001C71EC: CC2100BE 02004FE5
	v_fma_mixhi_f16 v190, v230, s39, 0                         // 0000001C71F4: CC2200BE 02004FE6
	ds_load_b128 v[227:230], v214 offset:144                   // 0000001C71FC: DBFC0090 E30000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C7204: BF89FC27
	v_fma_mixlo_f16 v191, v231, s39, 0                         // 0000001C7208: CC2100BF 02004FE7
	v_fma_mixhi_f16 v191, v232, s39, 0                         // 0000001C7210: CC2200BF 02004FE8
	v_fma_mixlo_f16 v192, v233, s39, 0                         // 0000001C7218: CC2100C0 02004FE9
	v_fma_mixhi_f16 v192, v234, s39, 0                         // 0000001C7220: CC2200C0 02004FEA
	ds_load_b128 v[231:234], v214 offset:160                   // 0000001C7228: DBFC00A0 E70000D6
	v_wmma_f32_16x16x16_f16 v[105:112], v[177:184], v[185:192], v[105:112]// 0000001C7230: CC404069 1DA773B1
	ds_load_b128 v[183:186], v214 offset:176                   // 0000001C7238: DBFC00B0 B70000D6
	ds_load_b128 v[187:190], v214 offset:8576                  // 0000001C7240: DBFC2180 BB0000D6
	s_waitcnt lgkmcnt(4)                                       // 0000001C7248: BF89FC47
	v_fma_mixlo_f16 v177, v235, s39, 0                         // 0000001C724C: CC2100B1 02004FEB
	v_fma_mixhi_f16 v177, v236, s39, 0                         // 0000001C7254: CC2200B1 02004FEC
	v_fma_mixlo_f16 v178, v237, s39, 0                         // 0000001C725C: CC2100B2 02004FED
	v_fma_mixhi_f16 v178, v238, s39, 0                         // 0000001C7264: CC2200B2 02004FEE
	ds_load_b128 v[235:238], v214 offset:8592                  // 0000001C726C: DBFC2190 EB0000D6
	s_waitcnt lgkmcnt(4)                                       // 0000001C7274: BF89FC47
	v_fma_mixlo_f16 v179, v227, s39, 0                         // 0000001C7278: CC2100B3 02004FE3
	v_fma_mixhi_f16 v179, v228, s39, 0                         // 0000001C7280: CC2200B3 02004FE4
	v_fma_mixlo_f16 v180, v229, s39, 0                         // 0000001C7288: CC2100B4 02004FE5
	v_fma_mixhi_f16 v180, v230, s39, 0                         // 0000001C7290: CC2200B4 02004FE6
	ds_load_b128 v[227:230], v214 offset:8608                  // 0000001C7298: DBFC21A0 E30000D6
	s_waitcnt lgkmcnt(4)                                       // 0000001C72A0: BF89FC47
	v_fma_mixlo_f16 v181, v231, s39, 0                         // 0000001C72A4: CC2100B5 02004FE7
	v_fma_mixhi_f16 v181, v232, s39, 0                         // 0000001C72AC: CC2200B5 02004FE8
	v_fma_mixlo_f16 v182, v233, s39, 0                         // 0000001C72B4: CC2100B6 02004FE9
	v_fma_mixhi_f16 v182, v234, s39, 0                         // 0000001C72BC: CC2200B6 02004FEA
	s_waitcnt lgkmcnt(3)                                       // 0000001C72C4: BF89FC37
	v_fma_mixlo_f16 v183, v183, s39, 0                         // 0000001C72C8: CC2100B7 02004FB7
	v_fma_mixhi_f16 v183, v184, s39, 0                         // 0000001C72D0: CC2200B7 02004FB8
	v_fma_mixlo_f16 v184, v185, s39, 0                         // 0000001C72D8: CC2100B8 02004FB9
	v_fma_mixhi_f16 v184, v186, s39, 0                         // 0000001C72E0: CC2200B8 02004FBA
	s_waitcnt lgkmcnt(2)                                       // 0000001C72E8: BF89FC27
	v_fma_mixlo_f16 v185, v187, s39, 0                         // 0000001C72EC: CC2100B9 02004FBB
	v_fma_mixhi_f16 v185, v188, s39, 0                         // 0000001C72F4: CC2200B9 02004FBC
	v_fma_mixlo_f16 v186, v189, s39, 0                         // 0000001C72FC: CC2100BA 02004FBD
	v_fma_mixhi_f16 v186, v190, s39, 0                         // 0000001C7304: CC2200BA 02004FBE
	ds_load_b128 v[231:234], v214 offset:8624                  // 0000001C730C: DBFC21B0 E70000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C7314: BF89FC27
	v_fma_mixlo_f16 v187, v235, s39, 0                         // 0000001C7318: CC2100BB 02004FEB
	v_fma_mixhi_f16 v187, v236, s39, 0                         // 0000001C7320: CC2200BB 02004FEC
	v_fma_mixlo_f16 v188, v237, s39, 0                         // 0000001C7328: CC2100BC 02004FED
	v_fma_mixhi_f16 v188, v238, s39, 0                         // 0000001C7330: CC2200BC 02004FEE
	ds_load_b128 v[235:238], v214 offset:17024                 // 0000001C7338: DBFC4280 EB0000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C7340: BF89FC27
	v_fma_mixlo_f16 v189, v227, s39, 0                         // 0000001C7344: CC2100BD 02004FE3
	v_fma_mixhi_f16 v189, v228, s39, 0                         // 0000001C734C: CC2200BD 02004FE4
	v_fma_mixlo_f16 v190, v229, s39, 0                         // 0000001C7354: CC2100BE 02004FE5
	v_fma_mixhi_f16 v190, v230, s39, 0                         // 0000001C735C: CC2200BE 02004FE6
	ds_load_b128 v[227:230], v214 offset:17040                 // 0000001C7364: DBFC4290 E30000D6
	s_waitcnt vmcnt(10)                                        // 0000001C736C: BF892BF7
	v_wmma_f32_16x16x16_f16 v[137:144], v[169:176], v[177:184], v[137:144]// 0000001C7370: CC404089 1E2763A9
	s_waitcnt lgkmcnt(2)                                       // 0000001C7378: BF89FC27
	v_fma_mixlo_f16 v191, v231, s39, 0                         // 0000001C737C: CC2100BF 02004FE7
	v_fma_mixhi_f16 v191, v232, s39, 0                         // 0000001C7384: CC2200BF 02004FE8
	v_fma_mixlo_f16 v192, v233, s39, 0                         // 0000001C738C: CC2100C0 02004FE9
	v_fma_mixhi_f16 v192, v234, s39, 0                         // 0000001C7394: CC2200C0 02004FEA
	ds_load_b128 v[231:234], v214 offset:17056                 // 0000001C739C: DBFC42A0 E70000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C73A4: BF89FC27
	v_fma_mixlo_f16 v177, v235, s39, 0                         // 0000001C73A8: CC2100B1 02004FEB
	v_fma_mixhi_f16 v177, v236, s39, 0                         // 0000001C73B0: CC2200B1 02004FEC
	v_fma_mixlo_f16 v178, v237, s39, 0                         // 0000001C73B8: CC2100B2 02004FED
	v_fma_mixhi_f16 v178, v238, s39, 0                         // 0000001C73C0: CC2200B2 02004FEE
	ds_load_b128 v[235:238], v214 offset:17072                 // 0000001C73C8: DBFC42B0 EB0000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C73D0: BF89FC27
	v_fma_mixlo_f16 v179, v227, s39, 0                         // 0000001C73D4: CC2100B3 02004FE3
	v_fma_mixhi_f16 v179, v228, s39, 0                         // 0000001C73DC: CC2200B3 02004FE4
	v_fma_mixlo_f16 v180, v229, s39, 0                         // 0000001C73E4: CC2100B4 02004FE5
	v_fma_mixhi_f16 v180, v230, s39, 0                         // 0000001C73EC: CC2200B4 02004FE6
	ds_load_b128 v[227:230], v214 offset:25472                 // 0000001C73F4: DBFC6380 E30000D6
	v_wmma_f32_16x16x16_f16 v[121:128], v[169:176], v[185:192], v[121:128]// 0000001C73FC: CC404079 1DE773A9
	s_waitcnt lgkmcnt(2)                                       // 0000001C7404: BF89FC27
	v_fma_mixlo_f16 v181, v231, s39, 0                         // 0000001C7408: CC2100B5 02004FE7
	v_fma_mixhi_f16 v181, v232, s39, 0                         // 0000001C7410: CC2200B5 02004FE8
	v_fma_mixlo_f16 v182, v233, s39, 0                         // 0000001C7418: CC2100B6 02004FE9
	v_fma_mixhi_f16 v182, v234, s39, 0                         // 0000001C7420: CC2200B6 02004FEA
	ds_load_b128 v[231:234], v214 offset:25488                 // 0000001C7428: DBFC6390 E70000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C7430: BF89FC27
	v_fma_mixlo_f16 v183, v235, s39, 0                         // 0000001C7434: CC2100B7 02004FEB
	v_fma_mixhi_f16 v183, v236, s39, 0                         // 0000001C743C: CC2200B7 02004FEC
	v_fma_mixlo_f16 v184, v237, s39, 0                         // 0000001C7444: CC2100B8 02004FED
	v_fma_mixhi_f16 v184, v238, s39, 0                         // 0000001C744C: CC2200B8 02004FEE
	ds_load_b128 v[235:238], v214 offset:25504                 // 0000001C7454: DBFC63A0 EB0000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C745C: BF89FC27
	v_fma_mixlo_f16 v185, v227, s39, 0                         // 0000001C7460: CC2100B9 02004FE3
	v_fma_mixhi_f16 v185, v228, s39, 0                         // 0000001C7468: CC2200B9 02004FE4
	v_fma_mixlo_f16 v186, v229, s39, 0                         // 0000001C7470: CC2100BA 02004FE5
	v_fma_mixhi_f16 v186, v230, s39, 0                         // 0000001C7478: CC2200BA 02004FE6
	ds_load_b128 v[227:230], v214 offset:25520                 // 0000001C7480: DBFC63B0 E30000D6
	v_wmma_f32_16x16x16_f16 v[113:120], v[169:176], v[177:184], v[113:120]// 0000001C7488: CC404071 1DC763A9
	ds_load_b128 v[177:180], v214 offset:240                   // 0000001C7490: DBFC00F0 B10000D6
	ds_load_b128 v[181:184], v214 offset:8640                  // 0000001C7498: DBFC21C0 B50000D6
	s_waitcnt lgkmcnt(4)                                       // 0000001C74A0: BF89FC47
	v_fma_mixlo_f16 v187, v231, s39, 0                         // 0000001C74A4: CC2100BB 02004FE7
	v_fma_mixhi_f16 v187, v232, s39, 0                         // 0000001C74AC: CC2200BB 02004FE8
	v_fma_mixlo_f16 v188, v233, s39, 0                         // 0000001C74B4: CC2100BC 02004FE9
	v_fma_mixhi_f16 v188, v234, s39, 0                         // 0000001C74BC: CC2200BC 02004FEA
	ds_load_b128 v[231:234], v214 offset:192                   // 0000001C74C4: DBFC00C0 E70000D6
	s_waitcnt lgkmcnt(4)                                       // 0000001C74CC: BF89FC47
	v_fma_mixlo_f16 v189, v235, s39, 0                         // 0000001C74D0: CC2100BD 02004FEB
	v_fma_mixhi_f16 v189, v236, s39, 0                         // 0000001C74D8: CC2200BD 02004FEC
	v_fma_mixlo_f16 v190, v237, s39, 0                         // 0000001C74E0: CC2100BE 02004FED
	v_fma_mixhi_f16 v190, v238, s39, 0                         // 0000001C74E8: CC2200BE 02004FEE
	ds_load_b128 v[235:238], v214 offset:208                   // 0000001C74F0: DBFC00D0 EB0000D6
	s_waitcnt lgkmcnt(4)                                       // 0000001C74F8: BF89FC47
	v_fma_mixlo_f16 v191, v227, s39, 0                         // 0000001C74FC: CC2100BF 02004FE3
	v_fma_mixhi_f16 v191, v228, s39, 0                         // 0000001C7504: CC2200BF 02004FE4
	v_fma_mixlo_f16 v192, v229, s39, 0                         // 0000001C750C: CC2100C0 02004FE5
	v_fma_mixhi_f16 v192, v230, s39, 0                         // 0000001C7514: CC2200C0 02004FE6
	ds_load_b128 v[227:230], v214 offset:224                   // 0000001C751C: DBFC00E0 E30000D6
	v_wmma_f32_16x16x16_f16 v[105:112], v[169:176], v[185:192], v[105:112]// 0000001C7524: CC404069 1DA773A9
	ds_load_b128 v[185:188], v214 offset:8656                  // 0000001C752C: DBFC21D0 B90000D6
	ds_load_b128 v[189:192], v214 offset:8672                  // 0000001C7534: DBFC21E0 BD0000D6
	s_waitcnt lgkmcnt(6)                                       // 0000001C753C: BF89FC67
	v_fma_mixhi_f16 v175, v178, s39, 0                         // 0000001C7540: CC2200AF 02004FB2
	v_fma_mixlo_f16 v176, v179, s39, 0                         // 0000001C7548: CC2100B0 02004FB3
	s_waitcnt lgkmcnt(5)                                       // 0000001C7550: BF89FC57
	v_fma_mixlo_f16 v178, v183, s39, 0                         // 0000001C7554: CC2100B2 02004FB7
	s_waitcnt lgkmcnt(4)                                       // 0000001C755C: BF89FC47
	v_fma_mixlo_f16 v169, v231, s39, 0                         // 0000001C7560: CC2100A9 02004FE7
	v_fma_mixhi_f16 v169, v232, s39, 0                         // 0000001C7568: CC2200A9 02004FE8
	v_fma_mixlo_f16 v170, v233, s39, 0                         // 0000001C7570: CC2100AA 02004FE9
	v_fma_mixhi_f16 v170, v234, s39, 0                         // 0000001C7578: CC2200AA 02004FEA
	ds_load_b128 v[231:234], v214 offset:17088                 // 0000001C7580: DBFC42C0 E70000D6
	s_waitcnt lgkmcnt(4)                                       // 0000001C7588: BF89FC47
	v_fma_mixlo_f16 v171, v235, s39, 0                         // 0000001C758C: CC2100AB 02004FEB
	v_fma_mixhi_f16 v171, v236, s39, 0                         // 0000001C7594: CC2200AB 02004FEC
	v_fma_mixlo_f16 v172, v237, s39, 0                         // 0000001C759C: CC2100AC 02004FED
	v_fma_mixhi_f16 v172, v238, s39, 0                         // 0000001C75A4: CC2200AC 02004FEE
	v_fma_mixhi_f16 v178, v184, s39, 0                         // 0000001C75AC: CC2200B2 02004FB8
	s_waitcnt lgkmcnt(3)                                       // 0000001C75B4: BF89FC37
	v_fma_mixlo_f16 v173, v227, s39, 0                         // 0000001C75B8: CC2100AD 02004FE3
	v_fma_mixhi_f16 v173, v228, s39, 0                         // 0000001C75C0: CC2200AD 02004FE4
	v_fma_mixlo_f16 v174, v229, s39, 0                         // 0000001C75C8: CC2100AE 02004FE5
	v_fma_mixhi_f16 v174, v230, s39, 0                         // 0000001C75D0: CC2200AE 02004FE6
	ds_load_b128 v[227:230], v214 offset:8688                  // 0000001C75D8: DBFC21F0 E30000D6
	ds_load_b128 v[235:238], v214 offset:17104                 // 0000001C75E0: DBFC42D0 EB0000D6
	s_waitcnt lgkmcnt(4)                                       // 0000001C75E8: BF89FC47
	v_fma_mixlo_f16 v179, v185, s39, 0                         // 0000001C75EC: CC2100B3 02004FB9
	v_fma_mixhi_f16 v179, v186, s39, 0                         // 0000001C75F4: CC2200B3 02004FBA
	v_fma_mixlo_f16 v175, v177, s39, 0                         // 0000001C75FC: CC2100AF 02004FB1
	v_fma_mixhi_f16 v176, v180, s39, 0                         // 0000001C7604: CC2200B0 02004FB4
	v_fma_mixhi_f16 v177, v182, s39, 0                         // 0000001C760C: CC2200B1 02004FB6
	v_fma_mixlo_f16 v180, v187, s39, 0                         // 0000001C7614: CC2100B4 02004FBB
	v_fma_mixhi_f16 v180, v188, s39, 0                         // 0000001C761C: CC2200B4 02004FBC
	s_waitcnt lgkmcnt(3)                                       // 0000001C7624: BF89FC37
	v_fma_mixlo_f16 v182, v191, s39, 0                         // 0000001C7628: CC2100B6 02004FBF
	s_waitcnt lgkmcnt(2)                                       // 0000001C7630: BF89FC27
	v_fma_mixlo_f16 v185, v231, s39, 0                         // 0000001C7634: CC2100B9 02004FE7
	v_fma_mixhi_f16 v185, v232, s39, 0                         // 0000001C763C: CC2200B9 02004FE8
	v_fma_mixlo_f16 v186, v233, s39, 0                         // 0000001C7644: CC2100BA 02004FE9
	v_fma_mixhi_f16 v186, v234, s39, 0                         // 0000001C764C: CC2200BA 02004FEA
	ds_load_b128 v[231:234], v214 offset:25536                 // 0000001C7654: DBFC63C0 E70000D6
	v_fma_mixhi_f16 v182, v192, s39, 0                         // 0000001C765C: CC2200B6 02004FC0
	s_waitcnt vmcnt(8)                                         // 0000001C7664: BF8923F7
	v_wmma_f32_16x16x16_f16 v[137:144], v[161:168], v[169:176], v[137:144]// 0000001C7668: CC404089 1E2753A1
	v_fma_mixlo_f16 v177, v181, s39, 0                         // 0000001C7670: CC2100B1 02004FB5
	v_fma_mixlo_f16 v181, v189, s39, 0                         // 0000001C7678: CC2100B5 02004FBD
	v_fma_mixhi_f16 v181, v190, s39, 0                         // 0000001C7680: CC2200B5 02004FBE
	s_waitcnt lgkmcnt(2)                                       // 0000001C7688: BF89FC27
	v_fma_mixlo_f16 v183, v227, s39, 0                         // 0000001C768C: CC2100B7 02004FE3
	v_fma_mixhi_f16 v183, v228, s39, 0                         // 0000001C7694: CC2200B7 02004FE4
	v_fma_mixlo_f16 v184, v229, s39, 0                         // 0000001C769C: CC2100B8 02004FE5
	v_fma_mixhi_f16 v184, v230, s39, 0                         // 0000001C76A4: CC2200B8 02004FE6
	ds_load_b128 v[227:230], v214 offset:17136                 // 0000001C76AC: DBFC42F0 E30000D6
	s_waitcnt lgkmcnt(2)                                       // 0000001C76B4: BF89FC27
	v_fma_mixlo_f16 v187, v235, s39, 0                         // 0000001C76B8: CC2100BB 02004FEB
	v_fma_mixhi_f16 v187, v236, s39, 0                         // 0000001C76C0: CC2200BB 02004FEC
	v_fma_mixlo_f16 v188, v237, s39, 0                         // 0000001C76C8: CC2100BC 02004FED
	v_fma_mixhi_f16 v188, v238, s39, 0                         // 0000001C76D0: CC2200BC 02004FEE
	ds_load_b128 v[235:238], v214 offset:25552                 // 0000001C76D8: DBFC63D0 EB0000D6
	v_wmma_f32_16x16x16_f16 v[121:128], v[161:168], v[177:184], v[121:128]// 0000001C76E0: CC404079 1DE763A1
	ds_load_b128 v[177:180], v214 offset:304                   // 0000001C76E8: DBFC0130 B10000D6
	v_fma_mixlo_f16 v189, v239, s39, 0                         // 0000001C76F0: CC2100BD 02004FEF
	v_fma_mixhi_f16 v189, v240, s39, 0                         // 0000001C76F8: CC2200BD 02004FF0
	s_waitcnt lgkmcnt(3)                                       // 0000001C7700: BF89FC37
	v_fma_mixlo_f16 v169, v231, s39, 0                         // 0000001C7704: CC2100A9 02004FE7
	v_fma_mixhi_f16 v169, v232, s39, 0                         // 0000001C770C: CC2200A9 02004FE8
	v_fma_mixlo_f16 v170, v233, s39, 0                         // 0000001C7714: CC2100AA 02004FE9
	v_fma_mixhi_f16 v170, v234, s39, 0                         // 0000001C771C: CC2200AA 02004FEA
	ds_load_b128 v[231:234], v214 offset:25584                 // 0000001C7724: DBFC63F0 E70000D6
	v_fma_mixlo_f16 v190, v241, s39, 0                         // 0000001C772C: CC2100BE 02004FF1
	v_fma_mixhi_f16 v190, v242, s39, 0                         // 0000001C7734: CC2200BE 02004FF2
	ds_load_b128 v[181:184], v214 offset:8736                  // 0000001C773C: DBFC2220 B50000D6
	ds_load_b128 v[239:242], v214 offset:25616                 // 0000001C7744: DBFC6410 EF0000D6
	s_waitcnt lgkmcnt(5)                                       // 0000001C774C: BF89FC57
	v_fma_mixlo_f16 v191, v227, s39, 0                         // 0000001C7750: CC2100BF 02004FE3
	v_fma_mixhi_f16 v191, v228, s39, 0                         // 0000001C7758: CC2200BF 02004FE4
	v_fma_mixlo_f16 v192, v229, s39, 0                         // 0000001C7760: CC2100C0 02004FE5
	v_fma_mixhi_f16 v192, v230, s39, 0                         // 0000001C7768: CC2200C0 02004FE6
	ds_load_b128 v[227:230], v214 offset:25568                 // 0000001C7770: DBFC63E0 E30000D6
	s_waitcnt lgkmcnt(5)                                       // 0000001C7778: BF89FC57
	v_fma_mixlo_f16 v171, v235, s39, 0                         // 0000001C777C: CC2100AB 02004FEB
	v_fma_mixhi_f16 v171, v236, s39, 0                         // 0000001C7784: CC2200AB 02004FEC
	v_fma_mixlo_f16 v172, v237, s39, 0                         // 0000001C778C: CC2100AC 02004FED
	v_fma_mixhi_f16 v172, v238, s39, 0                         // 0000001C7794: CC2200AC 02004FEE
	ds_load_b128 v[235:238], v214 offset:256                   // 0000001C779C: DBFC0100 EB0000D6
	v_wmma_f32_16x16x16_f16 v[113:120], v[161:168], v[185:192], v[113:120]// 0000001C77A4: CC404071 1DC773A1
	ds_load_b128 v[189:192], v214 offset:17168                 // 0000001C77AC: DBFC4310 BD0000D6
	ds_load_b128 v[185:188], v214 offset:8752                  // 0000001C77B4: DBFC2230 B90000D6
	s_waitcnt lgkmcnt(6)                                       // 0000001C77BC: BF89FC67
	v_fma_mixlo_f16 v175, v231, s39, 0                         // 0000001C77C0: CC2100AF 02004FE7
	v_fma_mixhi_f16 v175, v232, s39, 0                         // 0000001C77C8: CC2200AF 02004FE8
	v_fma_mixlo_f16 v176, v233, s39, 0                         // 0000001C77D0: CC2100B0 02004FE9
	v_fma_mixhi_f16 v176, v234, s39, 0                         // 0000001C77D8: CC2200B0 02004FEA
	ds_load_b128 v[231:234], v214 offset:288                   // 0000001C77E0: DBFC0120 E70000D6
	s_waitcnt lgkmcnt(4)                                       // 0000001C77E8: BF89FC47
	v_fma_mixlo_f16 v173, v227, s39, 0                         // 0000001C77EC: CC2100AD 02004FE3
	v_fma_mixhi_f16 v173, v228, s39, 0                         // 0000001C77F4: CC2200AD 02004FE4
	v_fma_mixlo_f16 v174, v229, s39, 0                         // 0000001C77FC: CC2100AE 02004FE5
	v_fma_mixhi_f16 v174, v230, s39, 0                         // 0000001C7804: CC2200AE 02004FE6
	ds_load_b128 v[227:230], v214 offset:272                   // 0000001C780C: DBFC0110 E30000D6
	v_wmma_f32_16x16x16_f16 v[105:112], v[161:168], v[169:176], v[105:112]// 0000001C7814: CC404069 1DA753A1
	ds_load_b128 v[169:172], v214 offset:8704                  // 0000001C781C: DBFC2200 A90000D6
	ds_load_b128 v[173:176], v214 offset:8720                  // 0000001C7824: DBFC2210 AD0000D6
	v_fma_mixlo_f16 v167, v177, s39, 0                         // 0000001C782C: CC2100A7 02004FB1
	v_fma_mixhi_f16 v167, v178, s39, 0                         // 0000001C7834: CC2200A7 02004FB2
	v_fma_mixlo_f16 v168, v179, s39, 0                         // 0000001C783C: CC2100A8 02004FB3
	v_fma_mixhi_f16 v168, v180, s39, 0                         // 0000001C7844: CC2200A8 02004FB4
	ds_load_b128 v[177:180], v214 offset:17152                 // 0000001C784C: DBFC4300 B10000D6
	s_waitcnt lgkmcnt(7)                                       // 0000001C7854: BF89FC77
	v_fma_mixlo_f16 v161, v235, s39, 0                         // 0000001C7858: CC2100A1 02004FEB
	v_fma_mixhi_f16 v161, v236, s39, 0                         // 0000001C7860: CC2200A1 02004FEC
	v_fma_mixlo_f16 v162, v237, s39, 0                         // 0000001C7868: CC2100A2 02004FED
	v_fma_mixhi_f16 v162, v238, s39, 0                         // 0000001C7870: CC2200A2 02004FEE
	s_waitcnt lgkmcnt(4)                                       // 0000001C7878: BF89FC47
	v_fma_mixlo_f16 v165, v231, s39, 0                         // 0000001C787C: CC2100A5 02004FE7
	v_fma_mixhi_f16 v165, v232, s39, 0                         // 0000001C7884: CC2200A5 02004FE8
	v_fma_mixlo_f16 v166, v233, s39, 0                         // 0000001C788C: CC2100A6 02004FE9
	v_fma_mixhi_f16 v166, v234, s39, 0                         // 0000001C7894: CC2200A6 02004FEA
	s_waitcnt lgkmcnt(3)                                       // 0000001C789C: BF89FC37
	v_fma_mixlo_f16 v163, v227, s39, 0                         // 0000001C78A0: CC2100A3 02004FE3
	v_fma_mixhi_f16 v163, v228, s39, 0                         // 0000001C78A8: CC2200A3 02004FE4
	v_fma_mixlo_f16 v164, v229, s39, 0                         // 0000001C78B0: CC2100A4 02004FE5
	v_fma_mixhi_f16 v164, v230, s39, 0                         // 0000001C78B8: CC2200A4 02004FE6
	ds_load_b128 v[227:230], v214 offset:17184                 // 0000001C78C0: DBFC4320 E30000D6
	ds_load_b128 v[231:234], v214 offset:17200                 // 0000001C78C8: DBFC4330 E70000D6
	s_waitcnt lgkmcnt(4)                                       // 0000001C78D0: BF89FC47
	v_fma_mixlo_f16 v169, v169, s39, 0                         // 0000001C78D4: CC2100A9 02004FA9
	v_fma_mixhi_f16 v169, v170, s39, 0                         // 0000001C78DC: CC2200A9 02004FAA
	v_fma_mixlo_f16 v170, v171, s39, 0                         // 0000001C78E4: CC2100AA 02004FAB
	s_waitcnt lgkmcnt(3)                                       // 0000001C78EC: BF89FC37
	v_fma_mixlo_f16 v171, v173, s39, 0                         // 0000001C78F0: CC2100AB 02004FAD
	v_fma_mixlo_f16 v173, v181, s39, 0                         // 0000001C78F8: CC2100AD 02004FB5
	v_fma_mixhi_f16 v173, v182, s39, 0                         // 0000001C7900: CC2200AD 02004FB6
	ds_load_b128 v[235:238], v214 offset:25600                 // 0000001C7908: DBFC6400 EB0000D6
	s_waitcnt lgkmcnt(3)                                       // 0000001C7910: BF89FC37
	v_fma_mixlo_f16 v177, v177, s39, 0                         // 0000001C7914: CC2100B1 02004FB1
	v_fma_mixhi_f16 v177, v178, s39, 0                         // 0000001C791C: CC2200B1 02004FB2
	v_fma_mixlo_f16 v178, v179, s39, 0                         // 0000001C7924: CC2100B2 02004FB3
	v_fma_mixhi_f16 v178, v180, s39, 0                         // 0000001C792C: CC2200B2 02004FB4
	v_fma_mixlo_f16 v179, v189, s39, 0                         // 0000001C7934: CC2100B3 02004FBD
	v_fma_mixhi_f16 v179, v190, s39, 0                         // 0000001C793C: CC2200B3 02004FBE
	v_fma_mixlo_f16 v180, v191, s39, 0                         // 0000001C7944: CC2100B4 02004FBF
	v_fma_mixhi_f16 v180, v192, s39, 0                         // 0000001C794C: CC2200B4 02004FC0
	ds_load_b128 v[189:192], v214 offset:25632                 // 0000001C7954: DBFC6420 BD0000D6
	v_fma_mixhi_f16 v170, v172, s39, 0                         // 0000001C795C: CC2200AA 02004FAC
	v_fma_mixhi_f16 v171, v174, s39, 0                         // 0000001C7964: CC2200AB 02004FAE
	s_waitcnt lgkmcnt(3)                                       // 0000001C796C: BF89FC37
	v_fma_mixlo_f16 v181, v227, s39, 0                         // 0000001C7970: CC2100B5 02004FE3
	v_fma_mixhi_f16 v181, v228, s39, 0                         // 0000001C7978: CC2200B5 02004FE4
	v_fma_mixlo_f16 v182, v229, s39, 0                         // 0000001C7980: CC2100B6 02004FE5
	v_fma_mixhi_f16 v182, v230, s39, 0                         // 0000001C7988: CC2200B6 02004FE6
	ds_load_b128 v[227:230], v214 offset:25648                 // 0000001C7990: DBFC6430 E30000D6
	v_fma_mixlo_f16 v172, v175, s39, 0                         // 0000001C7998: CC2100AC 02004FAF
	v_fma_mixhi_f16 v172, v176, s39, 0                         // 0000001C79A0: CC2200AC 02004FB0
	v_fma_mixlo_f16 v174, v183, s39, 0                         // 0000001C79A8: CC2100AE 02004FB7
	v_fma_mixhi_f16 v174, v184, s39, 0                         // 0000001C79B0: CC2200AE 02004FB8
	v_fma_mixlo_f16 v175, v185, s39, 0                         // 0000001C79B8: CC2100AF 02004FB9
	v_fma_mixhi_f16 v175, v186, s39, 0                         // 0000001C79C0: CC2200AF 02004FBA
	v_fma_mixlo_f16 v176, v187, s39, 0                         // 0000001C79C8: CC2100B0 02004FBB
	v_fma_mixhi_f16 v176, v188, s39, 0                         // 0000001C79D0: CC2200B0 02004FBC
	s_waitcnt lgkmcnt(3)                                       // 0000001C79D8: BF89FC37
	v_fma_mixlo_f16 v183, v231, s39, 0                         // 0000001C79DC: CC2100B7 02004FE7
	v_fma_mixhi_f16 v183, v232, s39, 0                         // 0000001C79E4: CC2200B7 02004FE8
	v_fma_mixlo_f16 v184, v233, s39, 0                         // 0000001C79EC: CC2100B8 02004FE9
	v_fma_mixhi_f16 v184, v234, s39, 0                         // 0000001C79F4: CC2200B8 02004FEA
	s_waitcnt lgkmcnt(2)                                       // 0000001C79FC: BF89FC27
	v_fma_mixlo_f16 v185, v235, s39, 0                         // 0000001C7A00: CC2100B9 02004FEB
	v_fma_mixhi_f16 v185, v236, s39, 0                         // 0000001C7A08: CC2200B9 02004FEC
	v_fma_mixlo_f16 v186, v237, s39, 0                         // 0000001C7A10: CC2100BA 02004FED
	v_fma_mixhi_f16 v186, v238, s39, 0                         // 0000001C7A18: CC2200BA 02004FEE
	v_fma_mixlo_f16 v187, v239, s39, 0                         // 0000001C7A20: CC2100BB 02004FEF
	v_fma_mixhi_f16 v187, v240, s39, 0                         // 0000001C7A28: CC2200BB 02004FF0
	v_fma_mixlo_f16 v188, v241, s39, 0                         // 0000001C7A30: CC2100BC 02004FF1
	v_fma_mixhi_f16 v188, v242, s39, 0                         // 0000001C7A38: CC2200BC 02004FF2
	s_waitcnt lgkmcnt(1)                                       // 0000001C7A40: BF89FC17
	v_fma_mixlo_f16 v189, v189, s39, 0                         // 0000001C7A44: CC2100BD 02004FBD
	v_fma_mixhi_f16 v189, v190, s39, 0                         // 0000001C7A4C: CC2200BD 02004FBE
	v_fma_mixlo_f16 v190, v191, s39, 0                         // 0000001C7A54: CC2100BE 02004FBF
	v_fma_mixhi_f16 v190, v192, s39, 0                         // 0000001C7A5C: CC2200BE 02004FC0
	s_waitcnt lgkmcnt(0)                                       // 0000001C7A64: BF89FC07
	v_fma_mixlo_f16 v191, v227, s39, 0                         // 0000001C7A68: CC2100BF 02004FE3
	v_fma_mixhi_f16 v191, v228, s39, 0                         // 0000001C7A70: CC2200BF 02004FE4
	v_fma_mixlo_f16 v192, v229, s39, 0                         // 0000001C7A78: CC2100C0 02004FE5
	v_fma_mixhi_f16 v192, v230, s39, 0                         // 0000001C7A80: CC2200C0 02004FE6
	ds_load_b128 v[231:234], v214 offset:320                   // 0000001C7A88: DBFC0140 E70000D6
	ds_load_b128 v[235:238], v214 offset:336                   // 0000001C7A90: DBFC0150 EB0000D6
	ds_load_b128 v[227:230], v214 offset:352                   // 0000001C7A98: DBFC0160 E30000D6
	s_waitcnt vmcnt(6)                                         // 0000001C7AA0: BF891BF7
	v_wmma_f32_16x16x16_f16 v[137:144], v[153:160], v[161:168], v[137:144]// 0000001C7AA4: CC404089 1E274399
	ds_load_b128 v[161:164], v214 offset:368                   // 0000001C7AAC: DBFC0170 A10000D6
	v_wmma_f32_16x16x16_f16 v[121:128], v[153:160], v[169:176], v[121:128]// 0000001C7AB4: CC404079 1DE75399
	v_wmma_f32_16x16x16_f16 v[113:120], v[153:160], v[177:184], v[113:120]// 0000001C7ABC: CC404071 1DC76399
	v_wmma_f32_16x16x16_f16 v[105:112], v[153:160], v[185:192], v[105:112]// 0000001C7AC4: CC404069 1DA77399
	ds_load_b128 v[165:168], v214 offset:8768                  // 0000001C7ACC: DBFC2240 A50000D6
	ds_load_b128 v[169:172], v214 offset:8784                  // 0000001C7AD4: DBFC2250 A90000D6
	ds_load_b128 v[173:176], v214 offset:8800                  // 0000001C7ADC: DBFC2260 AD0000D6
	ds_load_b128 v[177:180], v214 offset:8816                  // 0000001C7AE4: DBFC2270 B10000D6
	ds_load_b128 v[181:184], v214 offset:17216                 // 0000001C7AEC: DBFC4340 B50000D6
	ds_load_b128 v[185:188], v214 offset:17232                 // 0000001C7AF4: DBFC4350 B90000D6
	ds_load_b128 v[189:192], v214 offset:17248                 // 0000001C7AFC: DBFC4360 BD0000D6
	s_waitcnt lgkmcnt(10)                                      // 0000001C7B04: BF89FCA7
	v_fma_mixlo_f16 v153, v231, s39, 0                         // 0000001C7B08: CC210099 02004FE7
	v_fma_mixhi_f16 v153, v232, s39, 0                         // 0000001C7B10: CC220099 02004FE8
	v_fma_mixlo_f16 v154, v233, s39, 0                         // 0000001C7B18: CC21009A 02004FE9
	v_fma_mixhi_f16 v154, v234, s39, 0                         // 0000001C7B20: CC22009A 02004FEA
	s_waitcnt lgkmcnt(8)                                       // 0000001C7B28: BF89FC87
	v_fma_mixlo_f16 v157, v227, s39, 0                         // 0000001C7B2C: CC21009D 02004FE3
	v_fma_mixhi_f16 v157, v228, s39, 0                         // 0000001C7B34: CC22009D 02004FE4
	v_fma_mixlo_f16 v158, v229, s39, 0                         // 0000001C7B3C: CC21009E 02004FE5
	v_fma_mixhi_f16 v158, v230, s39, 0                         // 0000001C7B44: CC22009E 02004FE6
	s_waitcnt lgkmcnt(7)                                       // 0000001C7B4C: BF89FC77
	v_fma_mixhi_f16 v159, v162, s39, 0                         // 0000001C7B50: CC22009F 02004FA2
	v_fma_mixlo_f16 v160, v163, s39, 0                         // 0000001C7B58: CC2100A0 02004FA3
	v_fma_mixhi_f16 v160, v164, s39, 0                         // 0000001C7B60: CC2200A0 02004FA4
	s_waitcnt lgkmcnt(6)                                       // 0000001C7B68: BF89FC67
	v_fma_mixlo_f16 v162, v167, s39, 0                         // 0000001C7B6C: CC2100A2 02004FA7
	v_fma_mixhi_f16 v162, v168, s39, 0                         // 0000001C7B74: CC2200A2 02004FA8
	s_waitcnt lgkmcnt(5)                                       // 0000001C7B7C: BF89FC57
	v_fma_mixlo_f16 v163, v169, s39, 0                         // 0000001C7B80: CC2100A3 02004FA9
	v_fma_mixhi_f16 v163, v170, s39, 0                         // 0000001C7B88: CC2200A3 02004FAA
	v_fma_mixlo_f16 v164, v171, s39, 0                         // 0000001C7B90: CC2100A4 02004FAB
	v_fma_mixhi_f16 v164, v172, s39, 0                         // 0000001C7B98: CC2200A4 02004FAC
	s_waitcnt lgkmcnt(3)                                       // 0000001C7BA0: BF89FC37
	v_fma_mixlo_f16 v167, v177, s39, 0                         // 0000001C7BA4: CC2100A7 02004FB1
	ds_load_b128 v[227:230], v214 offset:17264                 // 0000001C7BAC: DBFC4370 E30000D6
	v_fma_mixhi_f16 v167, v178, s39, 0                         // 0000001C7BB4: CC2200A7 02004FB2
	v_fma_mixlo_f16 v168, v179, s39, 0                         // 0000001C7BBC: CC2100A8 02004FB3
	v_fma_mixhi_f16 v168, v180, s39, 0                         // 0000001C7BC4: CC2200A8 02004FB4
	ds_load_b128 v[177:180], v214 offset:25664                 // 0000001C7BCC: DBFC6440 B10000D6
	ds_load_b128 v[231:234], v214 offset:25680                 // 0000001C7BD4: DBFC6450 E70000D6
	s_waitcnt lgkmcnt(5)                                       // 0000001C7BDC: BF89FC57
	v_fma_mixlo_f16 v169, v181, s39, 0                         // 0000001C7BE0: CC2100A9 02004FB5
	v_fma_mixhi_f16 v169, v182, s39, 0                         // 0000001C7BE8: CC2200A9 02004FB6
	v_fma_mixlo_f16 v170, v183, s39, 0                         // 0000001C7BF0: CC2100AA 02004FB7
	v_fma_mixhi_f16 v170, v184, s39, 0                         // 0000001C7BF8: CC2200AA 02004FB8
	s_waitcnt lgkmcnt(4)                                       // 0000001C7C00: BF89FC47
	v_fma_mixlo_f16 v171, v185, s39, 0                         // 0000001C7C04: CC2100AB 02004FB9
	v_fma_mixhi_f16 v171, v186, s39, 0                         // 0000001C7C0C: CC2200AB 02004FBA
	v_fma_mixlo_f16 v172, v187, s39, 0                         // 0000001C7C14: CC2100AC 02004FBB
	ds_load_b128 v[181:184], v214 offset:25696                 // 0000001C7C1C: DBFC6460 B50000D6
	v_fma_mixhi_f16 v172, v188, s39, 0                         // 0000001C7C24: CC2200AC 02004FBC
	ds_load_b128 v[185:188], v214 offset:25712                 // 0000001C7C2C: DBFC6470 B90000D6
	v_fma_mixlo_f16 v155, v235, s39, 0                         // 0000001C7C34: CC21009B 02004FEB
	v_fma_mixhi_f16 v155, v236, s39, 0                         // 0000001C7C3C: CC22009B 02004FEC
	v_fma_mixlo_f16 v156, v237, s39, 0                         // 0000001C7C44: CC21009C 02004FED
	v_fma_mixhi_f16 v156, v238, s39, 0                         // 0000001C7C4C: CC22009C 02004FEE
	v_fma_mixlo_f16 v159, v161, s39, 0                         // 0000001C7C54: CC21009F 02004FA1
	v_fma_mixlo_f16 v161, v165, s39, 0                         // 0000001C7C5C: CC2100A1 02004FA5
	v_fma_mixhi_f16 v161, v166, s39, 0                         // 0000001C7C64: CC2200A1 02004FA6
	v_fma_mixlo_f16 v165, v173, s39, 0                         // 0000001C7C6C: CC2100A5 02004FAD
	v_fma_mixhi_f16 v165, v174, s39, 0                         // 0000001C7C74: CC2200A5 02004FAE
	v_fma_mixlo_f16 v166, v175, s39, 0                         // 0000001C7C7C: CC2100A6 02004FAF
	v_fma_mixhi_f16 v166, v176, s39, 0                         // 0000001C7C84: CC2200A6 02004FB0
	s_waitcnt lgkmcnt(5)                                       // 0000001C7C8C: BF89FC57
	v_fma_mixlo_f16 v173, v189, s39, 0                         // 0000001C7C90: CC2100AD 02004FBD
	v_fma_mixhi_f16 v173, v190, s39, 0                         // 0000001C7C98: CC2200AD 02004FBE
	v_fma_mixlo_f16 v174, v191, s39, 0                         // 0000001C7CA0: CC2100AE 02004FBF
	v_fma_mixhi_f16 v174, v192, s39, 0                         // 0000001C7CA8: CC2200AE 02004FC0
	s_waitcnt lgkmcnt(4)                                       // 0000001C7CB0: BF89FC47
	v_fma_mixlo_f16 v175, v227, s39, 0                         // 0000001C7CB4: CC2100AF 02004FE3
	v_fma_mixhi_f16 v175, v228, s39, 0                         // 0000001C7CBC: CC2200AF 02004FE4
	v_fma_mixlo_f16 v176, v229, s39, 0                         // 0000001C7CC4: CC2100B0 02004FE5
	v_fma_mixhi_f16 v176, v230, s39, 0                         // 0000001C7CCC: CC2200B0 02004FE6
	s_waitcnt lgkmcnt(3)                                       // 0000001C7CD4: BF89FC37
	v_fma_mixlo_f16 v177, v177, s39, 0                         // 0000001C7CD8: CC2100B1 02004FB1
	v_fma_mixhi_f16 v177, v178, s39, 0                         // 0000001C7CE0: CC2200B1 02004FB2
	v_fma_mixlo_f16 v178, v179, s39, 0                         // 0000001C7CE8: CC2100B2 02004FB3
	v_fma_mixhi_f16 v178, v180, s39, 0                         // 0000001C7CF0: CC2200B2 02004FB4
	s_waitcnt lgkmcnt(2)                                       // 0000001C7CF8: BF89FC27
	v_fma_mixlo_f16 v179, v231, s39, 0                         // 0000001C7CFC: CC2100B3 02004FE7
	v_fma_mixhi_f16 v179, v232, s39, 0                         // 0000001C7D04: CC2200B3 02004FE8
	v_fma_mixlo_f16 v180, v233, s39, 0                         // 0000001C7D0C: CC2100B4 02004FE9
	v_fma_mixhi_f16 v180, v234, s39, 0                         // 0000001C7D14: CC2200B4 02004FEA
	s_waitcnt lgkmcnt(1)                                       // 0000001C7D1C: BF89FC17
	v_fma_mixlo_f16 v181, v181, s39, 0                         // 0000001C7D20: CC2100B5 02004FB5
	v_fma_mixhi_f16 v181, v182, s39, 0                         // 0000001C7D28: CC2200B5 02004FB6
	v_fma_mixlo_f16 v182, v183, s39, 0                         // 0000001C7D30: CC2100B6 02004FB7
	v_fma_mixhi_f16 v182, v184, s39, 0                         // 0000001C7D38: CC2200B6 02004FB8
	s_waitcnt lgkmcnt(0)                                       // 0000001C7D40: BF89FC07
	v_fma_mixlo_f16 v183, v185, s39, 0                         // 0000001C7D44: CC2100B7 02004FB9
	v_fma_mixhi_f16 v183, v186, s39, 0                         // 0000001C7D4C: CC2200B7 02004FBA
	v_fma_mixlo_f16 v184, v187, s39, 0                         // 0000001C7D54: CC2100B8 02004FBB
	v_fma_mixhi_f16 v184, v188, s39, 0                         // 0000001C7D5C: CC2200B8 02004FBC
	ds_load_b128 v[189:192], v214 offset:384                   // 0000001C7D64: DBFC0180 BD0000D6
	ds_load_b128 v[227:230], v214 offset:400                   // 0000001C7D6C: DBFC0190 E30000D6
	ds_load_b128 v[231:234], v214 offset:416                   // 0000001C7D74: DBFC01A0 E70000D6
	s_waitcnt vmcnt(4)                                         // 0000001C7D7C: BF8913F7
	v_wmma_f32_16x16x16_f16 v[137:144], v[145:152], v[153:160], v[137:144]// 0000001C7D80: CC404089 1E273391
	ds_load_b128 v[153:156], v214 offset:432                   // 0000001C7D88: DBFC01B0 990000D6
	v_wmma_f32_16x16x16_f16 v[121:128], v[145:152], v[161:168], v[121:128]// 0000001C7D90: CC404079 1DE74391
	v_wmma_f32_16x16x16_f16 v[113:120], v[145:152], v[169:176], v[113:120]// 0000001C7D98: CC404071 1DC75391
	v_wmma_f32_16x16x16_f16 v[105:112], v[145:152], v[177:184], v[105:112]// 0000001C7DA0: CC404069 1DA76391
	ds_load_b128 v[157:160], v214 offset:8832                  // 0000001C7DA8: DBFC2280 9D0000D6
	ds_load_b128 v[161:164], v214 offset:8848                  // 0000001C7DB0: DBFC2290 A10000D6
	ds_load_b128 v[165:168], v214 offset:8864                  // 0000001C7DB8: DBFC22A0 A50000D6
	ds_load_b128 v[169:172], v214 offset:8880                  // 0000001C7DC0: DBFC22B0 A90000D6
	ds_load_b128 v[173:176], v214 offset:17280                 // 0000001C7DC8: DBFC4380 AD0000D6
	ds_load_b128 v[177:180], v214 offset:17296                 // 0000001C7DD0: DBFC4390 B10000D6
	ds_load_b128 v[181:184], v214 offset:17312                 // 0000001C7DD8: DBFC43A0 B50000D6
	ds_load_b128 v[185:188], v214 offset:17328                 // 0000001C7DE0: DBFC43B0 B90000D6
	s_waitcnt lgkmcnt(11)                                      // 0000001C7DE8: BF89FCB7
	v_fma_mixlo_f16 v145, v189, s39, 0                         // 0000001C7DEC: CC210091 02004FBD
	v_fma_mixhi_f16 v145, v190, s39, 0                         // 0000001C7DF4: CC220091 02004FBE
	v_fma_mixlo_f16 v146, v191, s39, 0                         // 0000001C7DFC: CC210092 02004FBF
	v_fma_mixhi_f16 v146, v192, s39, 0                         // 0000001C7E04: CC220092 02004FC0
	s_waitcnt lgkmcnt(8)                                       // 0000001C7E0C: BF89FC87
	v_fma_mixhi_f16 v151, v154, s39, 0                         // 0000001C7E10: CC220097 02004F9A
	v_fma_mixlo_f16 v152, v155, s39, 0                         // 0000001C7E18: CC210098 02004F9B
	v_fma_mixhi_f16 v152, v156, s39, 0                         // 0000001C7E20: CC220098 02004F9C
	ds_load_b128 v[189:192], v214 offset:25744                 // 0000001C7E28: DBFC6490 BD0000D6
	s_waitcnt lgkmcnt(8)                                       // 0000001C7E30: BF89FC87
	v_fma_mixlo_f16 v154, v159, s39, 0                         // 0000001C7E34: CC21009A 02004F9F
	v_fma_mixhi_f16 v154, v160, s39, 0                         // 0000001C7E3C: CC22009A 02004FA0
	s_waitcnt lgkmcnt(7)                                       // 0000001C7E44: BF89FC77
	v_fma_mixlo_f16 v155, v161, s39, 0                         // 0000001C7E48: CC21009B 02004FA1
	v_fma_mixhi_f16 v155, v162, s39, 0                         // 0000001C7E50: CC22009B 02004FA2
	v_fma_mixlo_f16 v156, v163, s39, 0                         // 0000001C7E58: CC21009C 02004FA3
	v_fma_mixhi_f16 v156, v164, s39, 0                         // 0000001C7E60: CC22009C 02004FA4
	s_waitcnt lgkmcnt(5)                                       // 0000001C7E68: BF89FC57
	v_fma_mixlo_f16 v159, v169, s39, 0                         // 0000001C7E6C: CC21009F 02004FA9
	v_fma_mixhi_f16 v159, v170, s39, 0                         // 0000001C7E74: CC22009F 02004FAA
	v_fma_mixlo_f16 v160, v171, s39, 0                         // 0000001C7E7C: CC2100A0 02004FAB
	v_fma_mixhi_f16 v160, v172, s39, 0                         // 0000001C7E84: CC2200A0 02004FAC
	ds_load_b128 v[169:172], v214 offset:25728                 // 0000001C7E8C: DBFC6480 A90000D6
	s_waitcnt lgkmcnt(5)                                       // 0000001C7E94: BF89FC57
	v_fma_mixlo_f16 v161, v173, s39, 0                         // 0000001C7E98: CC2100A1 02004FAD
	v_fma_mixhi_f16 v161, v174, s39, 0                         // 0000001C7EA0: CC2200A1 02004FAE
	v_fma_mixlo_f16 v162, v175, s39, 0                         // 0000001C7EA8: CC2100A2 02004FAF
	v_fma_mixhi_f16 v162, v176, s39, 0                         // 0000001C7EB0: CC2200A2 02004FB0
	s_waitcnt lgkmcnt(4)                                       // 0000001C7EB8: BF89FC47
	v_fma_mixlo_f16 v163, v177, s39, 0                         // 0000001C7EBC: CC2100A3 02004FB1
	v_fma_mixhi_f16 v163, v178, s39, 0                         // 0000001C7EC4: CC2200A3 02004FB2
	v_fma_mixlo_f16 v164, v179, s39, 0                         // 0000001C7ECC: CC2100A4 02004FB3
	ds_load_b128 v[173:176], v214 offset:25760                 // 0000001C7ED4: DBFC64A0 AD0000D6
	v_fma_mixhi_f16 v164, v180, s39, 0                         // 0000001C7EDC: CC2200A4 02004FB4
	ds_load_b128 v[177:180], v214 offset:25776                 // 0000001C7EE4: DBFC64B0 B10000D6
	v_fma_mixlo_f16 v147, v227, s39, 0                         // 0000001C7EEC: CC210093 02004FE3
	v_fma_mixhi_f16 v147, v228, s39, 0                         // 0000001C7EF4: CC220093 02004FE4
	v_fma_mixlo_f16 v148, v229, s39, 0                         // 0000001C7EFC: CC210094 02004FE5
	v_fma_mixhi_f16 v148, v230, s39, 0                         // 0000001C7F04: CC220094 02004FE6
	v_fma_mixlo_f16 v149, v231, s39, 0                         // 0000001C7F0C: CC210095 02004FE7
	v_fma_mixhi_f16 v149, v232, s39, 0                         // 0000001C7F14: CC220095 02004FE8
	v_fma_mixlo_f16 v150, v233, s39, 0                         // 0000001C7F1C: CC210096 02004FE9
	v_fma_mixhi_f16 v150, v234, s39, 0                         // 0000001C7F24: CC220096 02004FEA
	v_fma_mixlo_f16 v151, v153, s39, 0                         // 0000001C7F2C: CC210097 02004F99
	v_fma_mixlo_f16 v153, v157, s39, 0                         // 0000001C7F34: CC210099 02004F9D
	v_fma_mixhi_f16 v153, v158, s39, 0                         // 0000001C7F3C: CC220099 02004F9E
	v_fma_mixlo_f16 v157, v165, s39, 0                         // 0000001C7F44: CC21009D 02004FA5
	v_fma_mixhi_f16 v157, v166, s39, 0                         // 0000001C7F4C: CC22009D 02004FA6
	v_fma_mixlo_f16 v158, v167, s39, 0                         // 0000001C7F54: CC21009E 02004FA7
	v_fma_mixhi_f16 v158, v168, s39, 0                         // 0000001C7F5C: CC22009E 02004FA8
	s_waitcnt lgkmcnt(5)                                       // 0000001C7F64: BF89FC57
	v_fma_mixlo_f16 v165, v181, s39, 0                         // 0000001C7F68: CC2100A5 02004FB5
	v_fma_mixhi_f16 v165, v182, s39, 0                         // 0000001C7F70: CC2200A5 02004FB6
	v_fma_mixlo_f16 v166, v183, s39, 0                         // 0000001C7F78: CC2100A6 02004FB7
	v_fma_mixhi_f16 v166, v184, s39, 0                         // 0000001C7F80: CC2200A6 02004FB8
	s_waitcnt lgkmcnt(4)                                       // 0000001C7F88: BF89FC47
	v_fma_mixlo_f16 v167, v185, s39, 0                         // 0000001C7F8C: CC2100A7 02004FB9
	v_fma_mixhi_f16 v167, v186, s39, 0                         // 0000001C7F94: CC2200A7 02004FBA
	v_fma_mixlo_f16 v168, v187, s39, 0                         // 0000001C7F9C: CC2100A8 02004FBB
	v_fma_mixhi_f16 v168, v188, s39, 0                         // 0000001C7FA4: CC2200A8 02004FBC
	s_waitcnt lgkmcnt(2)                                       // 0000001C7FAC: BF89FC27
	v_fma_mixlo_f16 v169, v169, s39, 0                         // 0000001C7FB0: CC2100A9 02004FA9
	v_fma_mixhi_f16 v169, v170, s39, 0                         // 0000001C7FB8: CC2200A9 02004FAA
	v_fma_mixlo_f16 v170, v171, s39, 0                         // 0000001C7FC0: CC2100AA 02004FAB
	v_fma_mixhi_f16 v170, v172, s39, 0                         // 0000001C7FC8: CC2200AA 02004FAC
	v_fma_mixlo_f16 v171, v189, s39, 0                         // 0000001C7FD0: CC2100AB 02004FBD
	v_fma_mixhi_f16 v171, v190, s39, 0                         // 0000001C7FD8: CC2200AB 02004FBE
	v_fma_mixlo_f16 v172, v191, s39, 0                         // 0000001C7FE0: CC2100AC 02004FBF
	v_fma_mixhi_f16 v172, v192, s39, 0                         // 0000001C7FE8: CC2200AC 02004FC0
	s_waitcnt lgkmcnt(1)                                       // 0000001C7FF0: BF89FC17
	v_fma_mixlo_f16 v173, v173, s39, 0                         // 0000001C7FF4: CC2100AD 02004FAD
	v_fma_mixhi_f16 v173, v174, s39, 0                         // 0000001C7FFC: CC2200AD 02004FAE
	v_fma_mixlo_f16 v174, v175, s39, 0                         // 0000001C8004: CC2100AE 02004FAF
	v_fma_mixhi_f16 v174, v176, s39, 0                         // 0000001C800C: CC2200AE 02004FB0
	s_waitcnt lgkmcnt(0)                                       // 0000001C8014: BF89FC07
	v_fma_mixlo_f16 v175, v177, s39, 0                         // 0000001C8018: CC2100AF 02004FB1
	v_fma_mixhi_f16 v175, v178, s39, 0                         // 0000001C8020: CC2200AF 02004FB2
	v_fma_mixlo_f16 v176, v179, s39, 0                         // 0000001C8028: CC2100B0 02004FB3
	v_fma_mixhi_f16 v176, v180, s39, 0                         // 0000001C8030: CC2200B0 02004FB4
	ds_load_b128 v[181:184], v214 offset:448                   // 0000001C8038: DBFC01C0 B50000D6
	ds_load_b128 v[185:188], v214 offset:464                   // 0000001C8040: DBFC01D0 B90000D6
	ds_load_b128 v[189:192], v214 offset:480                   // 0000001C8048: DBFC01E0 BD0000D6
	s_waitcnt vmcnt(2)                                         // 0000001C8050: BF890BF7
	v_wmma_f32_16x16x16_f16 v[137:144], v[129:136], v[145:152], v[137:144]// 0000001C8054: CC404089 1E272381
	ds_load_b128 v[145:148], v214 offset:496                   // 0000001C805C: DBFC01F0 910000D6
	v_wmma_f32_16x16x16_f16 v[121:128], v[129:136], v[153:160], v[121:128]// 0000001C8064: CC404079 1DE73381
	v_wmma_f32_16x16x16_f16 v[113:120], v[129:136], v[161:168], v[113:120]// 0000001C806C: CC404071 1DC74381
	v_wmma_f32_16x16x16_f16 v[105:112], v[129:136], v[169:176], v[105:112]// 0000001C8074: CC404069 1DA75381
	ds_load_b128 v[149:152], v214 offset:8896                  // 0000001C807C: DBFC22C0 950000D6
	ds_load_b128 v[153:156], v214 offset:8912                  // 0000001C8084: DBFC22D0 990000D6
	ds_load_b128 v[157:160], v214 offset:8928                  // 0000001C808C: DBFC22E0 9D0000D6
	ds_load_b128 v[161:164], v214 offset:8944                  // 0000001C8094: DBFC22F0 A10000D6
	ds_load_b128 v[165:168], v214 offset:17344                 // 0000001C809C: DBFC43C0 A50000D6
	ds_load_b128 v[169:172], v214 offset:17360                 // 0000001C80A4: DBFC43D0 A90000D6
	ds_load_b128 v[173:176], v214 offset:17376                 // 0000001C80AC: DBFC43E0 AD0000D6
	ds_load_b128 v[177:180], v214 offset:17392                 // 0000001C80B4: DBFC43F0 B10000D6
	s_waitcnt lgkmcnt(11)                                      // 0000001C80BC: BF89FCB7
	v_fma_mixlo_f16 v129, v181, s39, 0                         // 0000001C80C0: CC210081 02004FB5
	v_fma_mixhi_f16 v129, v182, s39, 0                         // 0000001C80C8: CC220081 02004FB6
	v_fma_mixlo_f16 v130, v183, s39, 0                         // 0000001C80D0: CC210082 02004FB7
	v_fma_mixhi_f16 v130, v184, s39, 0                         // 0000001C80D8: CC220082 02004FB8
	s_waitcnt lgkmcnt(8)                                       // 0000001C80E0: BF89FC87
	v_fma_mixhi_f16 v135, v146, s39, 0                         // 0000001C80E4: CC220087 02004F92
	v_fma_mixlo_f16 v136, v147, s39, 0                         // 0000001C80EC: CC210088 02004F93
	v_fma_mixhi_f16 v136, v148, s39, 0                         // 0000001C80F4: CC220088 02004F94
	ds_load_b128 v[181:184], v214 offset:25808                 // 0000001C80FC: DBFC64D0 B50000D6
	s_waitcnt lgkmcnt(8)                                       // 0000001C8104: BF89FC87
	v_fma_mixlo_f16 v146, v151, s39, 0                         // 0000001C8108: CC210092 02004F97
	v_fma_mixhi_f16 v146, v152, s39, 0                         // 0000001C8110: CC220092 02004F98
	s_waitcnt lgkmcnt(7)                                       // 0000001C8118: BF89FC77
	v_fma_mixlo_f16 v147, v153, s39, 0                         // 0000001C811C: CC210093 02004F99
	v_fma_mixhi_f16 v147, v154, s39, 0                         // 0000001C8124: CC220093 02004F9A
	v_fma_mixlo_f16 v148, v155, s39, 0                         // 0000001C812C: CC210094 02004F9B
	v_fma_mixhi_f16 v148, v156, s39, 0                         // 0000001C8134: CC220094 02004F9C
	s_waitcnt lgkmcnt(5)                                       // 0000001C813C: BF89FC57
	v_fma_mixlo_f16 v151, v161, s39, 0                         // 0000001C8140: CC210097 02004FA1
	v_fma_mixhi_f16 v151, v162, s39, 0                         // 0000001C8148: CC220097 02004FA2
	v_fma_mixlo_f16 v152, v163, s39, 0                         // 0000001C8150: CC210098 02004FA3
	v_fma_mixhi_f16 v152, v164, s39, 0                         // 0000001C8158: CC220098 02004FA4
	ds_load_b128 v[161:164], v214 offset:25792                 // 0000001C8160: DBFC64C0 A10000D6
	s_waitcnt lgkmcnt(5)                                       // 0000001C8168: BF89FC57
	v_fma_mixlo_f16 v153, v165, s39, 0                         // 0000001C816C: CC210099 02004FA5
	v_fma_mixhi_f16 v153, v166, s39, 0                         // 0000001C8174: CC220099 02004FA6
	v_fma_mixlo_f16 v154, v167, s39, 0                         // 0000001C817C: CC21009A 02004FA7
	v_fma_mixhi_f16 v154, v168, s39, 0                         // 0000001C8184: CC22009A 02004FA8
	s_waitcnt lgkmcnt(4)                                       // 0000001C818C: BF89FC47
	v_fma_mixlo_f16 v155, v169, s39, 0                         // 0000001C8190: CC21009B 02004FA9
	v_fma_mixhi_f16 v155, v170, s39, 0                         // 0000001C8198: CC22009B 02004FAA
	ds_load_b128 v[165:168], v214 offset:25824                 // 0000001C81A0: DBFC64E0 A50000D6
	v_fma_mixlo_f16 v156, v171, s39, 0                         // 0000001C81A8: CC21009C 02004FAB
	v_fma_mixhi_f16 v156, v172, s39, 0                         // 0000001C81B0: CC22009C 02004FAC
	ds_load_b128 v[169:172], v214 offset:25840                 // 0000001C81B8: DBFC64F0 A90000D6
	v_fma_mixlo_f16 v131, v185, s39, 0                         // 0000001C81C0: CC210083 02004FB9
	v_fma_mixhi_f16 v131, v186, s39, 0                         // 0000001C81C8: CC220083 02004FBA
	v_fma_mixlo_f16 v132, v187, s39, 0                         // 0000001C81D0: CC210084 02004FBB
	v_fma_mixhi_f16 v132, v188, s39, 0                         // 0000001C81D8: CC220084 02004FBC
	v_fma_mixlo_f16 v133, v189, s39, 0                         // 0000001C81E0: CC210085 02004FBD
	v_fma_mixhi_f16 v133, v190, s39, 0                         // 0000001C81E8: CC220085 02004FBE
	v_fma_mixlo_f16 v134, v191, s39, 0                         // 0000001C81F0: CC210086 02004FBF
	v_fma_mixhi_f16 v134, v192, s39, 0                         // 0000001C81F8: CC220086 02004FC0
	v_fma_mixlo_f16 v135, v145, s39, 0                         // 0000001C8200: CC210087 02004F91
	v_fma_mixlo_f16 v145, v149, s39, 0                         // 0000001C8208: CC210091 02004F95
	v_fma_mixhi_f16 v145, v150, s39, 0                         // 0000001C8210: CC220091 02004F96
	v_fma_mixlo_f16 v149, v157, s39, 0                         // 0000001C8218: CC210095 02004F9D
	v_fma_mixhi_f16 v149, v158, s39, 0                         // 0000001C8220: CC220095 02004F9E
	v_fma_mixlo_f16 v150, v159, s39, 0                         // 0000001C8228: CC210096 02004F9F
	v_fma_mixhi_f16 v150, v160, s39, 0                         // 0000001C8230: CC220096 02004FA0
	s_waitcnt lgkmcnt(5)                                       // 0000001C8238: BF89FC57
	v_fma_mixlo_f16 v157, v173, s39, 0                         // 0000001C823C: CC21009D 02004FAD
	v_fma_mixhi_f16 v157, v174, s39, 0                         // 0000001C8244: CC22009D 02004FAE
	v_fma_mixlo_f16 v158, v175, s39, 0                         // 0000001C824C: CC21009E 02004FAF
	v_fma_mixhi_f16 v158, v176, s39, 0                         // 0000001C8254: CC22009E 02004FB0
	s_waitcnt lgkmcnt(4)                                       // 0000001C825C: BF89FC47
	v_fma_mixlo_f16 v159, v177, s39, 0                         // 0000001C8260: CC21009F 02004FB1
	v_fma_mixhi_f16 v159, v178, s39, 0                         // 0000001C8268: CC22009F 02004FB2
	v_fma_mixlo_f16 v160, v179, s39, 0                         // 0000001C8270: CC2100A0 02004FB3
	v_fma_mixhi_f16 v160, v180, s39, 0                         // 0000001C8278: CC2200A0 02004FB4
	s_waitcnt lgkmcnt(2)                                       // 0000001C8280: BF89FC27
	v_fma_mixlo_f16 v161, v161, s39, 0                         // 0000001C8284: CC2100A1 02004FA1
	v_fma_mixhi_f16 v161, v162, s39, 0                         // 0000001C828C: CC2200A1 02004FA2
	v_fma_mixlo_f16 v162, v163, s39, 0                         // 0000001C8294: CC2100A2 02004FA3
	v_fma_mixhi_f16 v162, v164, s39, 0                         // 0000001C829C: CC2200A2 02004FA4
	v_fma_mixlo_f16 v163, v181, s39, 0                         // 0000001C82A4: CC2100A3 02004FB5
	v_fma_mixhi_f16 v163, v182, s39, 0                         // 0000001C82AC: CC2200A3 02004FB6
	v_fma_mixlo_f16 v164, v183, s39, 0                         // 0000001C82B4: CC2100A4 02004FB7
	v_fma_mixhi_f16 v164, v184, s39, 0                         // 0000001C82BC: CC2200A4 02004FB8
	s_waitcnt lgkmcnt(1)                                       // 0000001C82C4: BF89FC17
	v_fma_mixlo_f16 v165, v165, s39, 0                         // 0000001C82C8: CC2100A5 02004FA5
	v_fma_mixhi_f16 v165, v166, s39, 0                         // 0000001C82D0: CC2200A5 02004FA6
	v_fma_mixlo_f16 v166, v167, s39, 0                         // 0000001C82D8: CC2100A6 02004FA7
	v_fma_mixhi_f16 v166, v168, s39, 0                         // 0000001C82E0: CC2200A6 02004FA8
	s_waitcnt lgkmcnt(0)                                       // 0000001C82E8: BF89FC07
	v_fma_mixlo_f16 v167, v169, s39, 0                         // 0000001C82EC: CC2100A7 02004FA9
	v_fma_mixhi_f16 v167, v170, s39, 0                         // 0000001C82F4: CC2200A7 02004FAA
	v_fma_mixlo_f16 v168, v171, s39, 0                         // 0000001C82FC: CC2100A8 02004FAB
	v_fma_mixhi_f16 v168, v172, s39, 0                         // 0000001C8304: CC2200A8 02004FAC
	s_waitcnt vmcnt(0)                                         // 0000001C830C: BF8903F7
	v_wmma_f32_16x16x16_f16 v[137:144], v[97:104], v[129:136], v[137:144]// 0000001C8310: CC404089 1E270361
	v_wmma_f32_16x16x16_f16 v[121:128], v[97:104], v[145:152], v[121:128]// 0000001C8318: CC404079 1DE72361
	v_wmma_f32_16x16x16_f16 v[113:120], v[97:104], v[153:160], v[113:120]// 0000001C8320: CC404071 1DC73361
	v_wmma_f32_16x16x16_f16 v[105:112], v[97:104], v[161:168], v[105:112]// 0000001C8328: CC404069 1DA74361
	v_add_nc_u32_e32 v145, s42, v217                           // 0000001C8330: 4B23B22A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C8334: BF870001
	v_or_b32_e32 v97, 2, v145                                  // 0000001C8338: 38C32282
	v_or_b32_e32 v98, 4, v145                                  // 0000001C833C: 38C52284
	v_or_b32_e32 v101, 6, v145                                 // 0000001C8340: 38CB2286
	v_or_b32_e32 v103, 8, v145                                 // 0000001C8344: 38CF2288
	v_or_b32_e32 v104, 10, v145                                // 0000001C8348: 38D1228A
	v_min_i32_e32 v97, s49, v97                                // 0000001C834C: 22C2C231
	v_min_i32_e32 v102, s49, v98                               // 0000001C8350: 22CCC431
	v_min_i32_e32 v130, s49, v101                              // 0000001C8354: 2304CA31
	v_or_b32_e32 v129, 12, v145                                // 0000001C8358: 3903228C
	v_min_i32_e32 v131, s49, v103                              // 0000001C835C: 2306CE31
	v_mad_i64_i32 v[97:98], null, v97, 48, s[2:3]              // 0000001C8360: D6FF7C61 00096161
	v_mad_i64_i32 v[101:102], null, v102, 48, s[2:3]           // 0000001C8368: D6FF7C65 00096166
	v_min_i32_e32 v133, s49, v104                              // 0000001C8370: 230AD031
	v_mad_i64_i32 v[103:104], null, v130, 48, s[2:3]           // 0000001C8374: D6FF7C67 00096182
	v_min_i32_e32 v134, s49, v129                              // 0000001C837C: 230D0231
	v_mad_i64_i32 v[129:130], null, v131, 48, s[2:3]           // 0000001C8380: D6FF7C81 00096183
	v_or_b32_e32 v135, 14, v145                                // 0000001C8388: 390F228E
	v_min_i32_e32 v99, s49, v145                               // 0000001C838C: 22C72231
	.long 0xd73c0061                                           // 0000001C8390: D73C0061
	v_cndmask_b32_e32 v1, 9, v97, vcc_lo                       // 0000001C8394: 0202C289
	.long 0xd73c0065                                           // 0000001C8398: D73C0065
	v_cndmask_b32_e32 v1, 9, v101, vcc_lo                      // 0000001C839C: 0202CA89
	.long 0xd4440000                                           // 0000001C83A0: D4440000
	v_cndmask_b32_e32 v1, s47, v145, vcc_lo                    // 0000001C83A4: 0203222F
	v_min_i32_e32 v135, s49, v135                              // 0000001C83A8: 230F0E31
	v_mad_i64_i32 v[99:100], null, v99, 48, s[2:3]             // 0000001C83AC: D6FF7C63 00096163
	.long 0xd73c0081                                           // 0000001C83B4: D73C0081
	v_cndmask_b32_e32 v1, 9, v129, vcc_lo                      // 0000001C83B8: 02030289
	.long 0xd7006a83                                           // 0000001C83BC: D7006A83
	v_cndmask_b32_e32 v1, v223, v97, vcc_lo                    // 0000001C83C0: 0202C3DF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001C83C4: BF8700D1
	v_add_co_ci_u32_e64 v132, null, v224, v98, vcc_lo          // 0000001C83C8: D5207C84 01AAC5E0
	.long 0xd73c0061                                           // 0000001C83D0: D73C0061
	v_cndmask_b32_e32 v1, 9, v103, vcc_lo                      // 0000001C83D4: 0202CE89
	v_mad_i64_i32 v[103:104], null, v133, 48, s[2:3]           // 0000001C83D8: D6FF7C67 00096185
	v_mad_i64_i32 v[133:134], null, v134, 48, s[2:3]           // 0000001C83E0: D6FF7C85 00096186
	.long 0xd7006a65                                           // 0000001C83E8: D7006A65
	v_cndmask_b32_e32 v1, v223, v101, vcc_lo                   // 0000001C83EC: 0202CBDF
	v_add_co_ci_u32_e64 v102, null, v224, v102, vcc_lo         // 0000001C83F0: D5207C66 01AACDE0
	.long 0xd7006a93                                           // 0000001C83F8: D7006A93
	v_cndmask_b32_e32 v1, v223, v97, vcc_lo                    // 0000001C83FC: 0202C3DF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001C8400: BF8700B1
	v_add_co_ci_u32_e64 v148, null, v224, v98, vcc_lo          // 0000001C8404: D5207C94 01AAC5E0
	.long 0xd73c0061                                           // 0000001C840C: D73C0061
	v_cndmask_b32_e32 v1, 9, v103, vcc_lo                      // 0000001C8410: 0202CE89
	.long 0xd7006a67                                           // 0000001C8414: D7006A67
	v_cndmask_b32_e32 v1, v223, v129, vcc_lo                   // 0000001C8418: 020303DF
	v_add_co_ci_u32_e64 v104, null, v224, v130, vcc_lo         // 0000001C841C: D5207C68 01AB05E0
	.long 0xd73c0081                                           // 0000001C8424: D73C0081
	v_cndmask_b32_e32 v1, 9, v133, vcc_lo                      // 0000001C8428: 02030A89
	v_mad_i64_i32 v[133:134], null, v135, 48, s[2:3]           // 0000001C842C: D6FF7C85 00096187
	.long 0xd7006a9a                                           // 0000001C8434: D7006A9A
	v_cndmask_b32_e32 v1, v223, v97, vcc_lo                    // 0000001C8438: 0202C3DF
	.long 0xd73c0063                                           // 0000001C843C: D73C0063
	v_cndmask_b32_e32 v1, 9, v99, vcc_lo                       // 0000001C8440: 0202C689
	v_add_co_ci_u32_e64 v155, null, v224, v98, vcc_lo          // 0000001C8444: D5207C9B 01AAC5E0
	.long 0xd7006aa6                                           // 0000001C844C: D7006AA6
	v_cndmask_b32_e32 v1, v223, v129, vcc_lo                   // 0000001C8450: 020303DF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001C8454: BF8700B1
	v_add_co_ci_u32_e64 v167, null, v224, v130, vcc_lo         // 0000001C8458: D5207CA7 01AB05E0
	.long 0xd73c0081                                           // 0000001C8460: D73C0081
	v_cndmask_b32_e32 v1, 9, v133, vcc_lo                      // 0000001C8464: 02030A89
	.long 0xd7006a62                                           // 0000001C8468: D7006A62
	v_cndmask_b32_e32 v1, v223, v99, vcc_lo                    // 0000001C846C: 0202C7DF
	v_add_co_ci_u32_e64 v99, null, v224, v100, vcc_lo          // 0000001C8470: D5207C63 01AAC9E0
	.long 0x7ec23880                                           // 0000001C8478: 7EC23880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001C847C: BF870094
	.long 0xd7006aa8                                           // 0000001C8480: D7006AA8
	v_cndmask_b32_e32 v1, v223, v129, vcc_lo                   // 0000001C8484: 020303DF
	v_add_co_ci_u32_e64 v169, null, v224, v130, vcc_lo         // 0000001C8488: D5207CA9 01AB05E0
	s_clause 0x1e                                              // 0000001C8490: BF85001E
	global_load_b32 v146, v[131:132], off                      // 0000001C8494: DC520000 927C0083
	global_load_b32 v160, v[101:102], off                      // 0000001C849C: DC520000 A07C0065
	global_load_b32 v156, v[98:99], off offset:64              // 0000001C84A4: DC520040 9C7C0062
	global_load_b32 v157, v[131:132], off offset:64            // 0000001C84AC: DC520040 9D7C0083
	global_load_b32 v151, v[98:99], off offset:128             // 0000001C84B4: DC520080 977C0062
	global_load_b32 v135, v[131:132], off offset:128           // 0000001C84BC: DC520080 877C0083
	global_load_b32 v129, v[131:132], off offset:192           // 0000001C84C4: DC5200C0 817C0083
	global_load_b32 v130, v[98:99], off offset:192             // 0000001C84CC: DC5200C0 827C0062
	global_load_b32 v165, v[147:148], off                      // 0000001C84D4: DC520000 A57C0093
	global_load_b32 v164, v[103:104], off                      // 0000001C84DC: DC520000 A47C0067
	global_load_b32 v159, v[101:102], off offset:64            // 0000001C84E4: DC520040 9F7C0065
	global_load_b32 v158, v[147:148], off offset:64            // 0000001C84EC: DC520040 9E7C0093
	global_load_b32 v150, v[101:102], off offset:128           // 0000001C84F4: DC520080 967C0065
	global_load_b32 v132, v[147:148], off offset:128           // 0000001C84FC: DC520080 847C0093
	global_load_b32 v100, v[147:148], off offset:192           // 0000001C8504: DC5200C0 647C0093
	global_load_b32 v131, v[101:102], off offset:192           // 0000001C850C: DC5200C0 837C0065
	global_load_b32 v163, v[154:155], off                      // 0000001C8514: DC520000 A37C009A
	global_load_b32 v161, v[166:167], off                      // 0000001C851C: DC520000 A17C00A6
	global_load_b32 v152, v[103:104], off offset:64            // 0000001C8524: DC520040 987C0067
	global_load_b32 v153, v[154:155], off offset:64            // 0000001C852C: DC520040 997C009A
	global_load_b32 v136, v[103:104], off offset:128           // 0000001C8534: DC520080 887C0067
	global_load_b32 v149, v[154:155], off offset:128           // 0000001C853C: DC520080 957C009A
	global_load_b32 v101, v[154:155], off offset:192           // 0000001C8544: DC5200C0 657C009A
	global_load_b32 v102, v[103:104], off offset:192           // 0000001C854C: DC5200C0 667C0067
	global_load_b32 v162, v[168:169], off                      // 0000001C8554: DC520000 A27C00A8
	global_load_b32 v154, v[166:167], off offset:64            // 0000001C855C: DC520040 9A7C00A6
	global_load_b32 v155, v[168:169], off offset:64            // 0000001C8564: DC520040 9B7C00A8
	global_load_b32 v133, v[166:167], off offset:128           // 0000001C856C: DC520080 857C00A6
	global_load_b32 v134, v[168:169], off offset:128           // 0000001C8574: DC520080 867C00A8
	global_load_b32 v103, v[168:169], off offset:192           // 0000001C857C: DC5200C0 677C00A8
	global_load_b32 v104, v[166:167], off offset:192           // 0000001C8584: DC5200C0 687C00A6
	s_and_saveexec_b32 s1, s0                                  // 0000001C858C: BE812000
	s_cbranch_execz 8                                          // 0000001C8590: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x37b4>
	global_load_b32 v97, v[98:99], off                         // 0000001C8594: DC520000 617C0062
	s_waitcnt vmcnt(0)                                         // 0000001C859C: BF8903F7
	v_fmac_f32_e32 v97, 0xbb800000, v137                       // 0000001C85A0: 56C312FF BB800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001C85A8: BF870001
	v_fma_mixlo_f16 v97, v97, s39, 0                           // 0000001C85AC: CC210061 02004F61
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001C85B4: 8C7E017E
	s_waitcnt vmcnt(30)                                        // 0000001C85B8: BF897BF7
	v_dual_fmac_f32 v146, 0xbb800000, v138 :: v_dual_add_nc_u32 v147, 4, v145// 0000001C85BC: C82114FF 92932284 BB800000
	s_waitcnt vmcnt(22)                                        // 0000001C85C8: BF895BF7
	v_dual_fmac_f32 v165, 0xbb800000, v140 :: v_dual_add_nc_u32 v148, 2, v145// 0000001C85CC: C82118FF A5952282 BB800000
	v_dual_fmac_f32 v160, 0xbb800000, v139 :: v_dual_add_nc_u32 v139, 10, v145// 0000001C85D8: C82116FF A08B228A BB800000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001C85E4: BF870003
	v_fma_mixhi_f16 v97, v146, s39, 0                          // 0000001C85E8: CC220061 02004F92
	s_waitcnt vmcnt(14)                                        // 0000001C85F0: BF893BF7
	v_dual_fmac_f32 v163, 0xbb800000, v142 :: v_dual_add_nc_u32 v146, 6, v145// 0000001C85F4: C8211CFF A3932286 BB800000
	s_waitcnt vmcnt(13)                                        // 0000001C8600: BF8937F7
	v_dual_fmac_f32 v161, 0xbb800000, v143 :: v_dual_add_nc_u32 v140, 8, v145// 0000001C8604: C8211EFF A18D2288 BB800000
	v_dual_fmac_f32 v164, 0xbb800000, v141 :: v_dual_fmac_f32 v157, 0xbb800000, v122// 0000001C8610: C8011AFF A49CF4FF BB800000
	v_dual_fmac_f32 v159, 0xbb800000, v123 :: v_dual_add_nc_u32 v138, 12, v145// 0000001C861C: C820F6FF 9F8B228C BB800000
	s_waitcnt vmcnt(6)                                         // 0000001C8628: BF891BF7
	v_dual_fmac_f32 v162, 0xbb800000, v144 :: v_dual_add_nc_u32 v137, 14, v145// 0000001C862C: C82120FF A289228E BB800000
	.long 0xd444000d                                           // 0000001C8638: D444000D
	v_cndmask_b32_e32 v1, s47, v148, vcc_lo                    // 0000001C863C: 0203282F
	.long 0xd444000c                                           // 0000001C8640: D444000C
	v_cndmask_b32_e32 v1, s47, v147, vcc_lo                    // 0000001C8644: 0203262F
	v_fma_mixlo_f16 v98, v160, s39, 0                          // 0000001C8648: CC210062 02004FA0
	v_dual_fmac_f32 v156, 0xbb800000, v121 :: v_dual_fmac_f32 v153, 0xbb800000, v126// 0000001C8650: C800F2FF 9C98FCFF BB800000
	.long 0xd444000b                                           // 0000001C865C: D444000B
	v_cndmask_b32_e32 v1, s47, v146, vcc_lo                    // 0000001C8660: 0203242F
	v_fma_mixhi_f16 v98, v165, s39, 0                          // 0000001C8664: CC220062 02004FA5
	.long 0xd444000a                                           // 0000001C866C: D444000A
	v_cndmask_b32_e32 v1, s47, v140, vcc_lo                    // 0000001C8670: 0203182F
	v_fma_mixlo_f16 v99, v164, s39, 0                          // 0000001C8674: CC210063 02004FA4
	.long 0xd4440008                                           // 0000001C867C: D4440008
	v_cndmask_b32_e32 v1, s47, v139, vcc_lo                    // 0000001C8680: 0203162F
	v_fma_mixhi_f16 v99, v163, s39, 0                          // 0000001C8684: CC220063 02004FA3
	.long 0xd4440009                                           // 0000001C868C: D4440009
	v_cndmask_b32_e32 v1, s47, v138, vcc_lo                    // 0000001C8690: 0203142F
	v_fma_mixlo_f16 v141, v161, s39, 0                         // 0000001C8694: CC21008D 02004FA1
	.long 0xd4440001                                           // 0000001C869C: D4440001
	v_cndmask_b32_e32 v1, s47, v137, vcc_lo                    // 0000001C86A0: 0203122F
	v_fma_mixhi_f16 v141, v162, s39, 0                         // 0000001C86A4: CC22008D 02004FA2
	v_dual_fmac_f32 v158, 0xbb800000, v124 :: v_dual_fmac_f32 v151, 0xbb800000, v113// 0000001C86AC: C800F8FF 9E96E2FF BB800000
	v_cndmask_b16 v97, 0, v97, s13                             // 0000001C86B8: D65D5061 0036C280
	s_waitcnt vmcnt(4)                                         // 0000001C86C0: BF8913F7
	v_dual_fmac_f32 v152, 0xbb800000, v125 :: v_dual_fmac_f32 v155, 0xbb800000, v128// 0000001C86C4: C800FAFF 989B00FF BB800000
	v_dual_fmac_f32 v154, 0xbb800000, v127 :: v_dual_fmac_f32 v135, 0xbb800000, v114// 0000001C86D0: C800FEFF 9A86E4FF BB800000
	v_cndmask_b16 v98, 0, v98, s12                             // 0000001C86DC: D65D0062 0032C480
	v_fma_mixlo_f16 v122, v156, s39, 0                         // 0000001C86E4: CC21007A 02004F9C
	v_cndmask_b16 v98, 0, v98, s11                             // 0000001C86EC: D65D5062 002EC480
	v_fma_mixhi_f16 v122, v157, s39, 0                         // 0000001C86F4: CC22007A 02004F9D
	v_cndmask_b16 v99, 0, v99, s10                             // 0000001C86FC: D65D0063 002AC680
	v_fma_mixlo_f16 v123, v159, s39, 0                         // 0000001C8704: CC21007B 02004F9F
	v_cndmask_b16 v99, 0, v99, s8                              // 0000001C870C: D65D5063 0022C680
	v_cndmask_b16 v121, 0, v141, s9                            // 0000001C8714: D65D0079 00271A80
	v_cndmask_b16 v121, 0, v141, s1                            // 0000001C871C: D65D5079 00071A80
	ds_store_b16 v225, v97                                     // 0000001C8724: D87C0000 000061E1
	ds_store_b16_d16_hi v225, v97 offset:4                     // 0000001C872C: DA840004 000061E1
	ds_store_b16 v225, v98 offset:8                            // 0000001C8734: D87C0008 000062E1
	ds_store_b16_d16_hi v225, v98 offset:12                    // 0000001C873C: DA84000C 000062E1
	ds_store_b16 v225, v99 offset:16                           // 0000001C8744: D87C0010 000063E1
	ds_store_b16_d16_hi v225, v99 offset:20                    // 0000001C874C: DA840014 000063E1
	ds_store_b16 v225, v121 offset:24                          // 0000001C8754: D87C0018 000079E1
	ds_store_b16_d16_hi v225, v121 offset:28                   // 0000001C875C: DA84001C 000079E1
	v_fma_mixhi_f16 v98, v158, s39, 0                          // 0000001C8764: CC220062 02004F9E
	v_fma_mixlo_f16 v99, v152, s39, 0                          // 0000001C876C: CC210063 02004F98
	v_fma_mixlo_f16 v121, v154, s39, 0                         // 0000001C8774: CC210079 02004F9A
	v_cndmask_b16 v97, 0, v122, s0                             // 0000001C877C: D65D0061 0002F480
	v_fma_mixhi_f16 v99, v153, s39, 0                          // 0000001C8784: CC220063 02004F99
	v_fma_mixhi_f16 v121, v155, s39, 0                         // 0000001C878C: CC220079 02004F9B
	v_cndmask_b16 v97, 0, v122, s13                            // 0000001C8794: D65D5061 0036F480
	v_dual_fmac_f32 v150, 0xbb800000, v115 :: v_dual_fmac_f32 v149, 0xbb800000, v118// 0000001C879C: C800E6FF 9694ECFF BB800000
	v_cndmask_b16 v98, 0, v123, s12                            // 0000001C87A8: D65D0062 0032F680
	s_waitcnt vmcnt(3)                                         // 0000001C87B0: BF890FF7
	v_dual_fmac_f32 v132, 0xbb800000, v116 :: v_dual_fmac_f32 v133, 0xbb800000, v119// 0000001C87B4: C800E8FF 8484EEFF BB800000
	v_cndmask_b16 v98, 0, v98, s11                             // 0000001C87C0: D65D5062 002EC480
	v_dual_fmac_f32 v136, 0xbb800000, v117 :: v_dual_fmac_f32 v129, 0xbb800000, v106// 0000001C87C8: C800EAFF 8880D4FF BB800000
	v_cndmask_b16 v99, 0, v99, s10                             // 0000001C87D4: D65D0063 002AC680
	v_cndmask_b16 v113, 0, v121, s9                            // 0000001C87DC: D65D0071 0026F280
	v_fma_mixlo_f16 v121, v151, s39, 0                         // 0000001C87E4: CC210079 02004F97
	s_waitcnt vmcnt(2)                                         // 0000001C87EC: BF890BF7
	v_dual_fmac_f32 v134, 0xbb800000, v120 :: v_dual_fmac_f32 v131, 0xbb800000, v107// 0000001C87F0: C800F0FF 8682D6FF BB800000
	v_cndmask_b16 v99, 0, v99, s8                              // 0000001C87FC: D65D5063 0022C680
	v_cndmask_b16 v113, 0, v121, s1                            // 0000001C8804: D65D5071 0006F280
	ds_store_b16 v225, v97 offset:2304                         // 0000001C880C: D87C0900 000061E1
	ds_store_b16_d16_hi v225, v97 offset:2308                  // 0000001C8814: DA840904 000061E1
	ds_store_b16 v225, v98 offset:2312                         // 0000001C881C: D87C0908 000062E1
	ds_store_b16_d16_hi v225, v98 offset:2316                  // 0000001C8824: DA84090C 000062E1
	ds_store_b16 v225, v99 offset:2320                         // 0000001C882C: D87C0910 000063E1
	ds_store_b16_d16_hi v225, v99 offset:2324                  // 0000001C8834: DA840914 000063E1
	ds_store_b16 v225, v113 offset:2328                        // 0000001C883C: D87C0918 000071E1
	ds_store_b16_d16_hi v225, v113 offset:2332                 // 0000001C8844: DA84091C 000071E1
	v_fma_mixhi_f16 v97, v135, s39, 0                          // 0000001C884C: CC220061 02004F87
	v_fma_mixlo_f16 v98, v150, s39, 0                          // 0000001C8854: CC210062 02004F96
	v_fma_mixhi_f16 v98, v132, s39, 0                          // 0000001C885C: CC220062 02004F84
	v_fma_mixlo_f16 v99, v136, s39, 0                          // 0000001C8864: CC210063 02004F88
	v_fma_mixhi_f16 v99, v149, s39, 0                          // 0000001C886C: CC220063 02004F95
	v_cndmask_b16 v97, 0, v121, s0                             // 0000001C8874: D65D0061 0002F280
	v_fma_mixlo_f16 v113, v133, s39, 0                         // 0000001C887C: CC210071 02004F85
	v_fma_mixhi_f16 v113, v134, s39, 0                         // 0000001C8884: CC220071 02004F86
	v_dual_fmac_f32 v130, 0xbb800000, v105 :: v_dual_fmac_f32 v101, 0xbb800000, v110// 0000001C888C: C800D2FF 8264DCFF BB800000
	v_fmac_f32_e32 v100, 0xbb800000, v108                      // 0000001C8898: 56C8D8FF BB800000
	s_waitcnt vmcnt(1)                                         // 0000001C88A0: BF8907F7
	v_dual_fmac_f32 v102, 0xbb800000, v109 :: v_dual_fmac_f32 v103, 0xbb800000, v112// 0000001C88A4: C800DAFF 6666E0FF BB800000
	s_waitcnt vmcnt(0)                                         // 0000001C88B0: BF8903F7
	v_fmac_f32_e32 v104, 0xbb800000, v111                      // 0000001C88B4: 56D0DEFF BB800000
	v_cndmask_b16 v97, 0, v97, s13                             // 0000001C88BC: D65D5061 0036C280
	v_cndmask_b16 v98, 0, v98, s12                             // 0000001C88C4: D65D0062 0032C480
	v_cndmask_b16 v98, 0, v98, s11                             // 0000001C88CC: D65D5062 002EC480
	v_cndmask_b16 v99, 0, v99, s10                             // 0000001C88D4: D65D0063 002AC680
	v_cndmask_b16 v99, 0, v99, s8                              // 0000001C88DC: D65D5063 0022C680
	v_cndmask_b16 v105, 0, v113, s9                            // 0000001C88E4: D65D0069 0026E280
	v_cndmask_b16 v105, 0, v113, s1                            // 0000001C88EC: D65D5069 0006E280
	v_fma_mixlo_f16 v106, v130, s39, 0                         // 0000001C88F4: CC21006A 02004F82
	v_fma_mixhi_f16 v106, v129, s39, 0                         // 0000001C88FC: CC22006A 02004F81
	v_fma_mixlo_f16 v107, v131, s39, 0                         // 0000001C8904: CC21006B 02004F83
	ds_store_b16 v225, v97 offset:4608                         // 0000001C890C: D87C1200 000061E1
	ds_store_b16_d16_hi v225, v97 offset:4612                  // 0000001C8914: DA841204 000061E1
	ds_store_b16 v225, v98 offset:4616                         // 0000001C891C: D87C1208 000062E1
	ds_store_b16_d16_hi v225, v98 offset:4620                  // 0000001C8924: DA84120C 000062E1
	ds_store_b16 v225, v99 offset:4624                         // 0000001C892C: D87C1210 000063E1
	ds_store_b16_d16_hi v225, v99 offset:4628                  // 0000001C8934: DA841214 000063E1
	ds_store_b16 v225, v105 offset:4632                        // 0000001C893C: D87C1218 000069E1
	ds_store_b16_d16_hi v225, v105 offset:4636                 // 0000001C8944: DA84121C 000069E1
	v_fma_mixhi_f16 v98, v100, s39, 0                          // 0000001C894C: CC220062 02004F64
	v_fma_mixlo_f16 v99, v102, s39, 0                          // 0000001C8954: CC210063 02004F66
	v_fma_mixhi_f16 v99, v101, s39, 0                          // 0000001C895C: CC220063 02004F65
	v_fma_mixlo_f16 v100, v104, s39, 0                         // 0000001C8964: CC210064 02004F68
	v_fma_mixhi_f16 v100, v103, s39, 0                         // 0000001C896C: CC220064 02004F67
	v_cndmask_b16 v97, 0, v106, s0                             // 0000001C8974: D65D0061 0002D480
	v_cndmask_b16 v97, 0, v106, s13                            // 0000001C897C: D65D5061 0036D480
	v_cndmask_b16 v98, 0, v107, s12                            // 0000001C8984: D65D0062 0032D680
	v_cndmask_b16 v98, 0, v98, s11                             // 0000001C898C: D65D5062 002EC480
	v_cndmask_b16 v99, 0, v99, s10                             // 0000001C8994: D65D0063 002AC680
	v_cndmask_b16 v99, 0, v99, s8                              // 0000001C899C: D65D5063 0022C680
	v_cndmask_b16 v100, 0, v100, s9                            // 0000001C89A4: D65D0064 0026C880
	v_cndmask_b16 v100, 0, v100, s1                            // 0000001C89AC: D65D5064 0006C880
	ds_store_b16 v225, v97 offset:6912                         // 0000001C89B4: D87C1B00 000061E1
	ds_store_b16_d16_hi v225, v97 offset:6916                  // 0000001C89BC: DA841B04 000061E1
	ds_store_b16 v225, v98 offset:6920                         // 0000001C89C4: D87C1B08 000062E1
	ds_store_b16_d16_hi v225, v98 offset:6924                  // 0000001C89CC: DA841B0C 000062E1
	ds_store_b16 v225, v99 offset:6928                         // 0000001C89D4: D87C1B10 000063E1
	ds_store_b16_d16_hi v225, v99 offset:6932                  // 0000001C89DC: DA841B14 000063E1
	ds_store_b16 v225, v100 offset:6936                        // 0000001C89E4: D87C1B18 000064E1
	ds_store_b16_d16_hi v225, v100 offset:6940                 // 0000001C89EC: DA841B1C 000064E1
	s_waitcnt lgkmcnt(0)                                       // 0000001C89F4: BF89FC07
	s_barrier                                                  // 0000001C89F8: BFBD0000
	buffer_gl0_inv                                             // 0000001C89FC: E0AC0000 00000000
	ds_load_b128 v[97:100], v214                               // 0000001C8A04: DBFC0000 610000D6
	ds_load_b128 v[101:104], v214 offset:16                    // 0000001C8A0C: DBFC0010 650000D6
	ds_load_b128 v[105:108], v214 offset:32                    // 0000001C8A14: DBFC0020 690000D6
	ds_load_b128 v[109:112], v214 offset:48                    // 0000001C8A1C: DBFC0030 6D0000D6
	ds_load_b128 v[113:116], v214 offset:8448                  // 0000001C8A24: DBFC2100 710000D6
	ds_load_b128 v[117:120], v214 offset:8464                  // 0000001C8A2C: DBFC2110 750000D6
	ds_load_b128 v[121:124], v214 offset:8480                  // 0000001C8A34: DBFC2120 790000D6
	v_dual_mov_b32 v136, s27 :: v_dual_mov_b32 v135, s26       // 0000001C8A3C: CA10001B 8886001A
	v_dual_mov_b32 v134, s25 :: v_dual_mov_b32 v133, s24       // 0000001C8A44: CA100019 86840018
	v_dual_mov_b32 v132, s23 :: v_dual_mov_b32 v131, s22       // 0000001C8A4C: CA100017 84820016
	v_dual_mov_b32 v130, s21 :: v_dual_mov_b32 v129, s20       // 0000001C8A54: CA100015 82800014
	ds_load_b128 v[149:152], v214 offset:16912                 // 0000001C8A5C: DBFC4210 950000D6
	ds_load_b128 v[153:156], v214 offset:16928                 // 0000001C8A64: DBFC4220 990000D6
	ds_load_b128 v[157:160], v214 offset:16944                 // 0000001C8A6C: DBFC4230 9D0000D6
	ds_load_b128 v[169:172], v214 offset:16992                 // 0000001C8A74: DBFC4260 A90000D6
	ds_load_b128 v[141:144], v214 offset:16896                 // 0000001C8A7C: DBFC4200 8D0000D6
	s_waitcnt lgkmcnt(11)                                      // 0000001C8A84: BF89FCB7
	v_fma_mixlo_f16 v97, v97, s39, 0                           // 0000001C8A88: CC210061 02004F61
	v_fma_mixhi_f16 v97, v98, s39, 0                           // 0000001C8A90: CC220061 02004F62
	v_fma_mixlo_f16 v98, v99, s39, 0                           // 0000001C8A98: CC210062 02004F63
	s_waitcnt lgkmcnt(10)                                      // 0000001C8AA0: BF89FCA7
	v_fma_mixlo_f16 v99, v101, s39, 0                          // 0000001C8AA4: CC210063 02004F65
	v_fma_mixhi_f16 v99, v102, s39, 0                          // 0000001C8AAC: CC220063 02004F66
	s_waitcnt lgkmcnt(9)                                       // 0000001C8AB4: BF89FC97
	v_fma_mixlo_f16 v101, v105, s39, 0                         // 0000001C8AB8: CC210065 02004F69
	v_fma_mixhi_f16 v101, v106, s39, 0                         // 0000001C8AC0: CC220065 02004F6A
	v_fma_mixlo_f16 v102, v107, s39, 0                         // 0000001C8AC8: CC210066 02004F6B
	v_fma_mixhi_f16 v102, v108, s39, 0                         // 0000001C8AD0: CC220066 02004F6C
	ds_load_b128 v[105:108], v214 offset:8496                  // 0000001C8AD8: DBFC2130 690000D6
	v_fma_mixhi_f16 v98, v100, s39, 0                          // 0000001C8AE0: CC220062 02004F64
	v_fma_mixlo_f16 v100, v103, s39, 0                         // 0000001C8AE8: CC210064 02004F67
	v_fma_mixhi_f16 v100, v104, s39, 0                         // 0000001C8AF0: CC220064 02004F68
	s_waitcnt lgkmcnt(9)                                       // 0000001C8AF8: BF89FC97
	v_fma_mixlo_f16 v103, v109, s39, 0                         // 0000001C8AFC: CC210067 02004F6D
	v_fma_mixhi_f16 v103, v110, s39, 0                         // 0000001C8B04: CC220067 02004F6E
	v_fma_mixlo_f16 v104, v111, s39, 0                         // 0000001C8B0C: CC210068 02004F6F
	v_fma_mixhi_f16 v104, v112, s39, 0                         // 0000001C8B14: CC220068 02004F70
	s_waitcnt lgkmcnt(8)                                       // 0000001C8B1C: BF89FC87
	v_fma_mixlo_f16 v113, v113, s39, 0                         // 0000001C8B20: CC210071 02004F71
	v_fma_mixhi_f16 v113, v114, s39, 0                         // 0000001C8B28: CC220071 02004F72
	v_fma_mixlo_f16 v114, v115, s39, 0                         // 0000001C8B30: CC210072 02004F73
	s_waitcnt lgkmcnt(7)                                       // 0000001C8B38: BF89FC77
	v_fma_mixlo_f16 v115, v117, s39, 0                         // 0000001C8B3C: CC210073 02004F75
	v_fma_mixhi_f16 v115, v118, s39, 0                         // 0000001C8B44: CC220073 02004F76
	s_waitcnt lgkmcnt(6)                                       // 0000001C8B4C: BF89FC67
	v_fma_mixlo_f16 v117, v121, s39, 0                         // 0000001C8B50: CC210075 02004F79
	v_fma_mixhi_f16 v117, v122, s39, 0                         // 0000001C8B58: CC220075 02004F7A
	v_fma_mixlo_f16 v118, v123, s39, 0                         // 0000001C8B60: CC210076 02004F7B
	v_fma_mixhi_f16 v118, v124, s39, 0                         // 0000001C8B68: CC220076 02004F7C
	v_wmma_f32_16x16x16_f16 v[121:128], v[89:96], v[97:104], v[129:136]// 0000001C8B70: CC404079 1E06C359
	s_waitcnt lgkmcnt(1)                                       // 0000001C8B78: BF89FC17
	v_fma_mixlo_f16 v97, v141, s39, 0                          // 0000001C8B7C: CC210061 02004F8D
	v_fma_mixhi_f16 v97, v142, s39, 0                          // 0000001C8B84: CC220061 02004F8E
	v_fma_mixlo_f16 v98, v143, s39, 0                          // 0000001C8B8C: CC210062 02004F8F
	v_fma_mixhi_f16 v98, v144, s39, 0                          // 0000001C8B94: CC220062 02004F90
	ds_load_b128 v[141:144], v214 offset:25376                 // 0000001C8B9C: DBFC6320 8D0000D6
	ds_load_b128 v[161:164], v214 offset:25392                 // 0000001C8BA4: DBFC6330 A10000D6
	v_fma_mixhi_f16 v114, v116, s39, 0                         // 0000001C8BAC: CC220072 02004F74
	v_fma_mixlo_f16 v116, v119, s39, 0                         // 0000001C8BB4: CC210074 02004F77
	v_fma_mixhi_f16 v116, v120, s39, 0                         // 0000001C8BBC: CC220074 02004F78
	s_waitcnt lgkmcnt(2)                                       // 0000001C8BC4: BF89FC27
	v_fma_mixlo_f16 v119, v105, s39, 0                         // 0000001C8BC8: CC210077 02004F69
	v_fma_mixhi_f16 v119, v106, s39, 0                         // 0000001C8BD0: CC220077 02004F6A
	v_fma_mixlo_f16 v120, v107, s39, 0                         // 0000001C8BD8: CC210078 02004F6B
	v_fma_mixhi_f16 v120, v108, s39, 0                         // 0000001C8BE0: CC220078 02004F6C
	v_fma_mixlo_f16 v101, v153, s39, 0                         // 0000001C8BE8: CC210065 02004F99
	v_fma_mixhi_f16 v101, v154, s39, 0                         // 0000001C8BF0: CC220065 02004F9A
	v_fma_mixlo_f16 v103, v157, s39, 0                         // 0000001C8BF8: CC210067 02004F9D
	v_fma_mixhi_f16 v103, v158, s39, 0                         // 0000001C8C00: CC220067 02004F9E
	v_wmma_f32_16x16x16_f16 v[105:112], v[89:96], v[113:120], v[129:136]// 0000001C8C08: CC404069 1E06E359
	ds_load_b128 v[113:116], v214 offset:25344                 // 0000001C8C10: DBFC6300 710000D6
	ds_load_b128 v[117:120], v214 offset:25360                 // 0000001C8C18: DBFC6310 750000D6
	v_fma_mixlo_f16 v104, v159, s39, 0                         // 0000001C8C20: CC210068 02004F9F
	v_fma_mixhi_f16 v104, v160, s39, 0                         // 0000001C8C28: CC220068 02004FA0
	ds_load_b128 v[157:160], v214 offset:64                    // 0000001C8C30: DBFC0040 9D0000D6
	ds_load_b128 v[165:168], v214 offset:80                    // 0000001C8C38: DBFC0050 A50000D6
	s_waitcnt lgkmcnt(5)                                       // 0000001C8C40: BF89FC57
	v_fma_mixlo_f16 v153, v141, s39, 0                         // 0000001C8C44: CC210099 02004F8D
	v_fma_mixhi_f16 v153, v142, s39, 0                         // 0000001C8C4C: CC220099 02004F8E
	v_fma_mixlo_f16 v154, v143, s39, 0                         // 0000001C8C54: CC21009A 02004F8F
	v_fma_mixhi_f16 v154, v144, s39, 0                         // 0000001C8C5C: CC22009A 02004F90
	ds_load_b128 v[141:144], v214 offset:96                    // 0000001C8C64: DBFC0060 8D0000D6
	v_fma_mixlo_f16 v99, v149, s39, 0                          // 0000001C8C6C: CC210063 02004F95
	v_fma_mixhi_f16 v99, v150, s39, 0                          // 0000001C8C74: CC220063 02004F96
	v_fma_mixlo_f16 v100, v151, s39, 0                         // 0000001C8C7C: CC210064 02004F97
	v_fma_mixhi_f16 v100, v152, s39, 0                         // 0000001C8C84: CC220064 02004F98
	v_fma_mixlo_f16 v102, v155, s39, 0                         // 0000001C8C8C: CC210066 02004F9B
	v_fma_mixhi_f16 v102, v156, s39, 0                         // 0000001C8C94: CC220066 02004F9C
	s_waitcnt lgkmcnt(5)                                       // 0000001C8C9C: BF89FC57
	v_fma_mixlo_f16 v155, v161, s39, 0                         // 0000001C8CA0: CC21009B 02004FA1
	v_fma_mixhi_f16 v155, v162, s39, 0                         // 0000001C8CA8: CC22009B 02004FA2
	v_fma_mixlo_f16 v156, v163, s39, 0                         // 0000001C8CB0: CC21009C 02004FA3
	s_waitcnt lgkmcnt(4)                                       // 0000001C8CB8: BF89FC47
	v_fma_mixlo_f16 v149, v113, s39, 0                         // 0000001C8CBC: CC210095 02004F71
	v_fma_mixhi_f16 v149, v114, s39, 0                         // 0000001C8CC4: CC220095 02004F72
	v_fma_mixlo_f16 v150, v115, s39, 0                         // 0000001C8CCC: CC210096 02004F73
	v_fma_mixhi_f16 v150, v116, s39, 0                         // 0000001C8CD4: CC220096 02004F74
	s_waitcnt lgkmcnt(3)                                       // 0000001C8CDC: BF89FC37
	v_fma_mixlo_f16 v151, v117, s39, 0                         // 0000001C8CE0: CC210097 02004F75
	v_fma_mixhi_f16 v151, v118, s39, 0                         // 0000001C8CE8: CC220097 02004F76
	v_fma_mixlo_f16 v152, v119, s39, 0                         // 0000001C8CF0: CC210098 02004F77
	v_fma_mixhi_f16 v152, v120, s39, 0                         // 0000001C8CF8: CC220098 02004F78
	v_fma_mixhi_f16 v156, v164, s39, 0                         // 0000001C8D00: CC22009C 02004FA4
	ds_load_b128 v[161:164], v214 offset:112                   // 0000001C8D08: DBFC0070 A10000D6
	v_wmma_f32_16x16x16_f16 v[113:120], v[89:96], v[97:104], v[129:136]// 0000001C8D10: CC404071 1E06C359
	ds_load_b128 v[177:180], v214 offset:25424                 // 0000001C8D18: DBFC6350 B10000D6
	v_wmma_f32_16x16x16_f16 v[97:104], v[89:96], v[149:156], v[129:136]// 0000001C8D20: CC404061 1E072B59
	ds_load_b128 v[149:152], v214 offset:8512                  // 0000001C8D28: DBFC2140 950000D6
	ds_load_b128 v[153:156], v214 offset:8528                  // 0000001C8D30: DBFC2150 990000D6
	s_waitcnt lgkmcnt(6)                                       // 0000001C8D38: BF89FC67
	v_fma_mixlo_f16 v89, v157, s39, 0                          // 0000001C8D3C: CC210059 02004F9D
	v_fma_mixhi_f16 v89, v158, s39, 0                          // 0000001C8D44: CC220059 02004F9E
	v_fma_mixlo_f16 v90, v159, s39, 0                          // 0000001C8D4C: CC21005A 02004F9F
	v_fma_mixhi_f16 v90, v160, s39, 0                          // 0000001C8D54: CC22005A 02004FA0
	ds_load_b128 v[157:160], v214 offset:8544                  // 0000001C8D5C: DBFC2160 9D0000D6
	s_waitcnt lgkmcnt(5)                                       // 0000001C8D64: BF89FC57
	v_fma_mixlo_f16 v93, v141, s39, 0                          // 0000001C8D68: CC21005D 02004F8D
	v_fma_mixhi_f16 v93, v142, s39, 0                          // 0000001C8D70: CC22005D 02004F8E
	v_fma_mixlo_f16 v94, v143, s39, 0                          // 0000001C8D78: CC21005E 02004F8F
	v_fma_mixhi_f16 v94, v144, s39, 0                          // 0000001C8D80: CC22005E 02004F90
	ds_load_b128 v[141:144], v214 offset:8560                  // 0000001C8D88: DBFC2170 8D0000D6
	v_fma_mixlo_f16 v91, v165, s39, 0                          // 0000001C8D90: CC21005B 02004FA5
	v_fma_mixhi_f16 v91, v166, s39, 0                          // 0000001C8D98: CC22005B 02004FA6
	v_fma_mixlo_f16 v92, v167, s39, 0                          // 0000001C8DA0: CC21005C 02004FA7
	v_fma_mixhi_f16 v92, v168, s39, 0                          // 0000001C8DA8: CC22005C 02004FA8
	s_waitcnt lgkmcnt(5)                                       // 0000001C8DB0: BF89FC57
	v_fma_mixlo_f16 v95, v161, s39, 0                          // 0000001C8DB4: CC21005F 02004FA1
	v_fma_mixhi_f16 v95, v162, s39, 0                          // 0000001C8DBC: CC22005F 02004FA2
	v_fma_mixlo_f16 v96, v163, s39, 0                          // 0000001C8DC4: CC210060 02004FA3
	v_fma_mixhi_f16 v96, v164, s39, 0                          // 0000001C8DCC: CC220060 02004FA4
	s_waitcnt lgkmcnt(3)                                       // 0000001C8DD4: BF89FC37
	v_fma_mixlo_f16 v149, v149, s39, 0                         // 0000001C8DD8: CC210095 02004F95
	ds_load_b128 v[161:164], v214 offset:16960                 // 0000001C8DE0: DBFC4240 A10000D6
	ds_load_b128 v[165:168], v214 offset:16976                 // 0000001C8DE8: DBFC4250 A50000D6
	v_fma_mixhi_f16 v149, v150, s39, 0                         // 0000001C8DF0: CC220095 02004F96
	v_fma_mixhi_f16 v150, v152, s39, 0                         // 0000001C8DF8: CC220096 02004F98
	s_waitcnt lgkmcnt(4)                                       // 0000001C8E00: BF89FC47
	v_fma_mixlo_f16 v152, v155, s39, 0                         // 0000001C8E04: CC210098 02004F9B
	v_fma_mixhi_f16 v152, v156, s39, 0                         // 0000001C8E0C: CC220098 02004F9C
	ds_load_b128 v[181:184], v214 offset:25440                 // 0000001C8E14: DBFC6360 B50000D6
	ds_load_b128 v[185:188], v214 offset:25456                 // 0000001C8E1C: DBFC6370 B90000D6
	ds_load_b128 v[173:176], v214 offset:17008                 // 0000001C8E24: DBFC4270 AD0000D6
	v_fma_mixlo_f16 v150, v151, s39, 0                         // 0000001C8E2C: CC210096 02004F97
	s_waitcnt lgkmcnt(5)                                       // 0000001C8E34: BF89FC57
	v_fma_mixlo_f16 v155, v141, s39, 0                         // 0000001C8E38: CC21009B 02004F8D
	v_fma_mixhi_f16 v155, v142, s39, 0                         // 0000001C8E40: CC22009B 02004F8E
	v_fma_mixlo_f16 v156, v143, s39, 0                         // 0000001C8E48: CC21009C 02004F8F
	v_fma_mixhi_f16 v156, v144, s39, 0                         // 0000001C8E50: CC22009C 02004F90
	ds_load_b128 v[141:144], v214 offset:25408                 // 0000001C8E58: DBFC6340 8D0000D6
	v_fma_mixhi_f16 v151, v154, s39, 0                         // 0000001C8E60: CC220097 02004F9A
	v_fma_mixlo_f16 v154, v159, s39, 0                         // 0000001C8E68: CC21009A 02004F9F
	v_fma_mixlo_f16 v151, v153, s39, 0                         // 0000001C8E70: CC210097 02004F99
	v_fma_mixlo_f16 v153, v157, s39, 0                         // 0000001C8E78: CC210099 02004F9D
	v_fma_mixhi_f16 v154, v160, s39, 0                         // 0000001C8E80: CC22009A 02004FA0
	s_waitcnt lgkmcnt(5)                                       // 0000001C8E88: BF89FC57
	v_fma_mixlo_f16 v157, v161, s39, 0                         // 0000001C8E8C: CC21009D 02004FA1
	s_waitcnt lgkmcnt(4)                                       // 0000001C8E94: BF89FC47
	v_fma_mixlo_f16 v159, v165, s39, 0                         // 0000001C8E98: CC21009F 02004FA5
	v_fma_mixhi_f16 v159, v166, s39, 0                         // 0000001C8EA0: CC22009F 02004FA6
	v_fma_mixhi_f16 v157, v162, s39, 0                         // 0000001C8EA8: CC22009D 02004FA2
	v_fma_mixlo_f16 v160, v167, s39, 0                         // 0000001C8EB0: CC2100A0 02004FA7
	v_fma_mixhi_f16 v160, v168, s39, 0                         // 0000001C8EB8: CC2200A0 02004FA8
	v_fma_mixlo_f16 v161, v169, s39, 0                         // 0000001C8EC0: CC2100A1 02004FA9
	v_fma_mixhi_f16 v161, v170, s39, 0                         // 0000001C8EC8: CC2200A1 02004FAA
	v_fma_mixlo_f16 v162, v171, s39, 0                         // 0000001C8ED0: CC2100A2 02004FAB
	v_fma_mixhi_f16 v162, v172, s39, 0                         // 0000001C8ED8: CC2200A2 02004FAC
	v_fma_mixlo_f16 v167, v177, s39, 0                         // 0000001C8EE0: CC2100A7 02004FB1
	v_fma_mixhi_f16 v167, v178, s39, 0                         // 0000001C8EE8: CC2200A7 02004FB2
	v_fma_mixlo_f16 v168, v179, s39, 0                         // 0000001C8EF0: CC2100A8 02004FB3
	v_fma_mixhi_f16 v168, v180, s39, 0                         // 0000001C8EF8: CC2200A8 02004FB4
	s_waitcnt lgkmcnt(0)                                       // 0000001C8F00: BF89FC07
	v_fma_mixlo_f16 v165, v141, s39, 0                         // 0000001C8F04: CC2100A5 02004F8D
	v_fma_mixhi_f16 v165, v142, s39, 0                         // 0000001C8F0C: CC2200A5 02004F8E
	v_fma_mixlo_f16 v166, v143, s39, 0                         // 0000001C8F14: CC2100A6 02004F8F
	v_fma_mixhi_f16 v166, v144, s39, 0                         // 0000001C8F1C: CC2200A6 02004F90
	ds_load_b128 v[141:144], v214 offset:128                   // 0000001C8F24: DBFC0080 8D0000D6
	v_fma_mixlo_f16 v169, v181, s39, 0                         // 0000001C8F2C: CC2100A9 02004FB5
	v_fma_mixhi_f16 v169, v182, s39, 0                         // 0000001C8F34: CC2200A9 02004FB6
	v_fma_mixlo_f16 v170, v183, s39, 0                         // 0000001C8F3C: CC2100AA 02004FB7
	v_fma_mixhi_f16 v170, v184, s39, 0                         // 0000001C8F44: CC2200AA 02004FB8
	v_fma_mixlo_f16 v171, v185, s39, 0                         // 0000001C8F4C: CC2100AB 02004FB9
	v_fma_mixhi_f16 v171, v186, s39, 0                         // 0000001C8F54: CC2200AB 02004FBA
	v_fma_mixlo_f16 v172, v187, s39, 0                         // 0000001C8F5C: CC2100AC 02004FBB
	v_fma_mixhi_f16 v172, v188, s39, 0                         // 0000001C8F64: CC2200AC 02004FBC
	v_fma_mixhi_f16 v153, v158, s39, 0                         // 0000001C8F6C: CC220099 02004F9E
	v_fma_mixlo_f16 v158, v163, s39, 0                         // 0000001C8F74: CC21009E 02004FA3
	v_fma_mixhi_f16 v158, v164, s39, 0                         // 0000001C8F7C: CC22009E 02004FA4
	ds_load_b128 v[177:180], v214 offset:160                   // 0000001C8F84: DBFC00A0 B10000D6
	v_wmma_f32_16x16x16_f16 v[97:104], v[81:88], v[165:172], v[97:104]// 0000001C8F8C: CC404061 1D874B51
	ds_load_b128 v[165:168], v214 offset:17072                 // 0000001C8F94: DBFC42B0 A50000D6
	v_fma_mixlo_f16 v163, v173, s39, 0                         // 0000001C8F9C: CC2100A3 02004FAD
	v_fma_mixhi_f16 v163, v174, s39, 0                         // 0000001C8FA4: CC2200A3 02004FAE
	v_fma_mixlo_f16 v164, v175, s39, 0                         // 0000001C8FAC: CC2100A4 02004FAF
	v_fma_mixhi_f16 v164, v176, s39, 0                         // 0000001C8FB4: CC2200A4 02004FB0
	ds_load_b128 v[173:176], v214 offset:144                   // 0000001C8FBC: DBFC0090 AD0000D6
	v_wmma_f32_16x16x16_f16 v[121:128], v[81:88], v[89:96], v[121:128]// 0000001C8FC4: CC404079 1DE6B351
	ds_load_b128 v[89:92], v214 offset:176                     // 0000001C8FCC: DBFC00B0 590000D6
	v_wmma_f32_16x16x16_f16 v[105:112], v[81:88], v[149:156], v[105:112]// 0000001C8FD4: CC404069 1DA72B51
	v_wmma_f32_16x16x16_f16 v[113:120], v[81:88], v[157:164], v[113:120]// 0000001C8FDC: CC404071 1DC73B51
	ds_load_b128 v[93:96], v214 offset:8576                    // 0000001C8FE4: DBFC2180 5D0000D6
	s_waitcnt lgkmcnt(5)                                       // 0000001C8FEC: BF89FC57
	v_fma_mixlo_f16 v81, v141, s39, 0                          // 0000001C8FF0: CC210051 02004F8D
	v_fma_mixhi_f16 v81, v142, s39, 0                          // 0000001C8FF8: CC220051 02004F8E
	v_fma_mixlo_f16 v82, v143, s39, 0                          // 0000001C9000: CC210052 02004F8F
	v_fma_mixhi_f16 v82, v144, s39, 0                          // 0000001C9008: CC220052 02004F90
	ds_load_b128 v[141:144], v214 offset:8592                  // 0000001C9010: DBFC2190 8D0000D6
	ds_load_b128 v[149:152], v214 offset:8608                  // 0000001C9018: DBFC21A0 950000D6
	ds_load_b128 v[153:156], v214 offset:8624                  // 0000001C9020: DBFC21B0 990000D6
	s_waitcnt lgkmcnt(7)                                       // 0000001C9028: BF89FC77
	v_fma_mixlo_f16 v85, v177, s39, 0                          // 0000001C902C: CC210055 02004FB1
	v_fma_mixhi_f16 v85, v178, s39, 0                          // 0000001C9034: CC220055 02004FB2
	v_fma_mixlo_f16 v86, v179, s39, 0                          // 0000001C903C: CC210056 02004FB3
	v_fma_mixhi_f16 v86, v180, s39, 0                          // 0000001C9044: CC220056 02004FB4
	ds_load_b128 v[157:160], v214 offset:17024                 // 0000001C904C: DBFC4280 9D0000D6
	ds_load_b128 v[161:164], v214 offset:17040                 // 0000001C9054: DBFC4290 A10000D6
	ds_load_b128 v[169:172], v214 offset:25472                 // 0000001C905C: DBFC6380 A90000D6
	s_waitcnt lgkmcnt(8)                                       // 0000001C9064: BF89FC87
	v_fma_mixlo_f16 v83, v173, s39, 0                          // 0000001C9068: CC210053 02004FAD
	v_fma_mixhi_f16 v83, v174, s39, 0                          // 0000001C9070: CC220053 02004FAE
	v_fma_mixlo_f16 v84, v175, s39, 0                          // 0000001C9078: CC210054 02004FAF
	v_fma_mixhi_f16 v84, v176, s39, 0                          // 0000001C9080: CC220054 02004FB0
	ds_load_b128 v[173:176], v214 offset:25488                 // 0000001C9088: DBFC6390 AD0000D6
	ds_load_b128 v[177:180], v214 offset:25504                 // 0000001C9090: DBFC63A0 B10000D6
	ds_load_b128 v[181:184], v214 offset:25520                 // 0000001C9098: DBFC63B0 B50000D6
	s_waitcnt lgkmcnt(10)                                      // 0000001C90A0: BF89FCA7
	v_fma_mixlo_f16 v88, v91, s39, 0                           // 0000001C90A4: CC210058 02004F5B
	v_fma_mixhi_f16 v88, v92, s39, 0                           // 0000001C90AC: CC220058 02004F5C
	v_fma_mixlo_f16 v87, v89, s39, 0                           // 0000001C90B4: CC210057 02004F59
	s_waitcnt lgkmcnt(8)                                       // 0000001C90BC: BF89FC87
	v_fma_mixlo_f16 v91, v141, s39, 0                          // 0000001C90C0: CC21005B 02004F8D
	v_fma_mixhi_f16 v91, v142, s39, 0                          // 0000001C90C8: CC22005B 02004F8E
	v_fma_mixlo_f16 v92, v143, s39, 0                          // 0000001C90D0: CC21005C 02004F8F
	v_fma_mixhi_f16 v92, v144, s39, 0                          // 0000001C90D8: CC22005C 02004F90
	ds_load_b128 v[141:144], v214 offset:17056                 // 0000001C90E0: DBFC42A0 8D0000D6
	v_fma_mixlo_f16 v89, v93, s39, 0                           // 0000001C90E8: CC210059 02004F5D
	v_fma_mixhi_f16 v89, v94, s39, 0                           // 0000001C90F0: CC220059 02004F5E
	s_waitcnt lgkmcnt(8)                                       // 0000001C90F8: BF89FC87
	v_fma_mixlo_f16 v93, v149, s39, 0                          // 0000001C90FC: CC21005D 02004F95
	v_fma_mixhi_f16 v93, v150, s39, 0                          // 0000001C9104: CC22005D 02004F96
	v_fma_mixlo_f16 v94, v151, s39, 0                          // 0000001C910C: CC21005E 02004F97
	v_fma_mixhi_f16 v94, v152, s39, 0                          // 0000001C9114: CC22005E 02004F98
	s_waitcnt lgkmcnt(6)                                       // 0000001C911C: BF89FC67
	v_fma_mixlo_f16 v149, v157, s39, 0                         // 0000001C9120: CC210095 02004F9D
	v_fma_mixhi_f16 v149, v158, s39, 0                         // 0000001C9128: CC220095 02004F9E
	v_fma_mixlo_f16 v150, v159, s39, 0                         // 0000001C9130: CC210096 02004F9F
	v_fma_mixhi_f16 v150, v160, s39, 0                         // 0000001C9138: CC220096 02004FA0
	s_waitcnt lgkmcnt(5)                                       // 0000001C9140: BF89FC57
	v_fma_mixlo_f16 v151, v161, s39, 0                         // 0000001C9144: CC210097 02004FA1
	v_fma_mixhi_f16 v151, v162, s39, 0                         // 0000001C914C: CC220097 02004FA2
	v_fma_mixlo_f16 v152, v163, s39, 0                         // 0000001C9154: CC210098 02004FA3
	v_fma_mixhi_f16 v152, v164, s39, 0                         // 0000001C915C: CC220098 02004FA4
	s_waitcnt lgkmcnt(4)                                       // 0000001C9164: BF89FC47
	v_fma_mixlo_f16 v157, v169, s39, 0                         // 0000001C9168: CC21009D 02004FA9
	v_fma_mixhi_f16 v157, v170, s39, 0                         // 0000001C9170: CC22009D 02004FAA
	v_fma_mixlo_f16 v158, v171, s39, 0                         // 0000001C9178: CC21009E 02004FAB
	v_fma_mixhi_f16 v158, v172, s39, 0                         // 0000001C9180: CC22009E 02004FAC
	s_waitcnt lgkmcnt(3)                                       // 0000001C9188: BF89FC37
	v_fma_mixlo_f16 v159, v173, s39, 0                         // 0000001C918C: CC21009F 02004FAD
	v_fma_mixhi_f16 v159, v174, s39, 0                         // 0000001C9194: CC22009F 02004FAE
	v_fma_mixlo_f16 v160, v175, s39, 0                         // 0000001C919C: CC2100A0 02004FAF
	v_fma_mixhi_f16 v160, v176, s39, 0                         // 0000001C91A4: CC2200A0 02004FB0
	s_waitcnt lgkmcnt(2)                                       // 0000001C91AC: BF89FC27
	v_fma_mixlo_f16 v161, v177, s39, 0                         // 0000001C91B0: CC2100A1 02004FB1
	v_fma_mixhi_f16 v161, v178, s39, 0                         // 0000001C91B8: CC2200A1 02004FB2
	v_fma_mixlo_f16 v162, v179, s39, 0                         // 0000001C91C0: CC2100A2 02004FB3
	v_fma_mixhi_f16 v162, v180, s39, 0                         // 0000001C91C8: CC2200A2 02004FB4
	s_waitcnt lgkmcnt(1)                                       // 0000001C91D0: BF89FC17
	v_fma_mixlo_f16 v163, v181, s39, 0                         // 0000001C91D4: CC2100A3 02004FB5
	v_fma_mixhi_f16 v163, v182, s39, 0                         // 0000001C91DC: CC2200A3 02004FB6
	v_fma_mixlo_f16 v164, v183, s39, 0                         // 0000001C91E4: CC2100A4 02004FB7
	v_fma_mixhi_f16 v164, v184, s39, 0                         // 0000001C91EC: CC2200A4 02004FB8
	v_fma_mixhi_f16 v87, v90, s39, 0                           // 0000001C91F4: CC220057 02004F5A
	v_fma_mixlo_f16 v90, v95, s39, 0                           // 0000001C91FC: CC21005A 02004F5F
	v_fma_mixlo_f16 v95, v153, s39, 0                          // 0000001C9204: CC21005F 02004F99
	v_fma_mixhi_f16 v95, v154, s39, 0                          // 0000001C920C: CC22005F 02004F9A
	v_wmma_f32_16x16x16_f16 v[97:104], v[73:80], v[157:164], v[97:104]// 0000001C9214: CC404061 1D873B49
	ds_load_b128 v[157:160], v214 offset:17120                 // 0000001C921C: DBFC42E0 9D0000D6
	s_waitcnt lgkmcnt(1)                                       // 0000001C9224: BF89FC17
	v_fma_mixlo_f16 v153, v141, s39, 0                         // 0000001C9228: CC210099 02004F8D
	v_fma_mixhi_f16 v153, v142, s39, 0                         // 0000001C9230: CC220099 02004F8E
	v_fma_mixlo_f16 v154, v143, s39, 0                         // 0000001C9238: CC21009A 02004F8F
	v_fma_mixhi_f16 v154, v144, s39, 0                         // 0000001C9240: CC22009A 02004F90
	ds_load_b128 v[141:144], v214 offset:192                   // 0000001C9248: DBFC00C0 8D0000D6
	v_fma_mixhi_f16 v90, v96, s39, 0                           // 0000001C9250: CC22005A 02004F60
	v_fma_mixlo_f16 v96, v155, s39, 0                          // 0000001C9258: CC210060 02004F9B
	v_fma_mixhi_f16 v96, v156, s39, 0                          // 0000001C9260: CC220060 02004F9C
	v_fma_mixlo_f16 v155, v165, s39, 0                         // 0000001C9268: CC21009B 02004FA5
	v_fma_mixhi_f16 v155, v166, s39, 0                         // 0000001C9270: CC22009B 02004FA6
	v_fma_mixlo_f16 v156, v167, s39, 0                         // 0000001C9278: CC21009C 02004FA7
	v_fma_mixhi_f16 v156, v168, s39, 0                         // 0000001C9280: CC22009C 02004FA8
	ds_load_b128 v[165:168], v214 offset:208                   // 0000001C9288: DBFC00D0 A50000D6
	ds_load_b128 v[169:172], v214 offset:224                   // 0000001C9290: DBFC00E0 A90000D6
	v_wmma_f32_16x16x16_f16 v[121:128], v[73:80], v[81:88], v[121:128]// 0000001C9298: CC404079 1DE6A349
	ds_load_b128 v[81:84], v214 offset:240                     // 0000001C92A0: DBFC00F0 510000D6
	v_wmma_f32_16x16x16_f16 v[105:112], v[73:80], v[89:96], v[105:112]// 0000001C92A8: CC404069 1DA6B349
	v_wmma_f32_16x16x16_f16 v[113:120], v[73:80], v[149:156], v[113:120]// 0000001C92B0: CC404071 1DC72B49
	ds_load_b128 v[85:88], v214 offset:8640                    // 0000001C92B8: DBFC21C0 550000D6
	ds_load_b128 v[89:92], v214 offset:8656                    // 0000001C92C0: DBFC21D0 590000D6
	ds_load_b128 v[93:96], v214 offset:8672                    // 0000001C92C8: DBFC21E0 5D0000D6
	ds_load_b128 v[149:152], v214 offset:17088                 // 0000001C92D0: DBFC42C0 950000D6
	ds_load_b128 v[153:156], v214 offset:17104                 // 0000001C92D8: DBFC42D0 990000D6
	ds_load_b128 v[161:164], v214 offset:17136                 // 0000001C92E0: DBFC42F0 A10000D6
	s_waitcnt lgkmcnt(9)                                       // 0000001C92E8: BF89FC97
	v_fma_mixlo_f16 v73, v141, s39, 0                          // 0000001C92EC: CC210049 02004F8D
	v_fma_mixhi_f16 v73, v142, s39, 0                          // 0000001C92F4: CC220049 02004F8E
	v_fma_mixlo_f16 v74, v143, s39, 0                          // 0000001C92FC: CC21004A 02004F8F
	v_fma_mixhi_f16 v74, v144, s39, 0                          // 0000001C9304: CC22004A 02004F90
	ds_load_b128 v[141:144], v214 offset:8688                  // 0000001C930C: DBFC21F0 8D0000D6
	s_waitcnt lgkmcnt(9)                                       // 0000001C9314: BF89FC97
	v_fma_mixlo_f16 v75, v165, s39, 0                          // 0000001C9318: CC21004B 02004FA5
	v_fma_mixhi_f16 v75, v166, s39, 0                          // 0000001C9320: CC22004B 02004FA6
	v_fma_mixlo_f16 v76, v167, s39, 0                          // 0000001C9328: CC21004C 02004FA7
	s_waitcnt lgkmcnt(7)                                       // 0000001C9330: BF89FC77
	v_fma_mixhi_f16 v79, v82, s39, 0                           // 0000001C9334: CC22004F 02004F52
	v_fma_mixhi_f16 v76, v168, s39, 0                          // 0000001C933C: CC22004C 02004FA8
	v_fma_mixlo_f16 v77, v169, s39, 0                          // 0000001C9344: CC21004D 02004FA9
	s_waitcnt lgkmcnt(6)                                       // 0000001C934C: BF89FC67
	v_fma_mixlo_f16 v82, v87, s39, 0                           // 0000001C9350: CC210052 02004F57
	v_fma_mixhi_f16 v82, v88, s39, 0                           // 0000001C9358: CC220052 02004F58
	v_fma_mixhi_f16 v77, v170, s39, 0                          // 0000001C9360: CC22004D 02004FAA
	v_fma_mixlo_f16 v78, v171, s39, 0                          // 0000001C9368: CC21004E 02004FAB
	v_fma_mixhi_f16 v78, v172, s39, 0                          // 0000001C9370: CC22004E 02004FAC
	v_fma_mixlo_f16 v79, v81, s39, 0                           // 0000001C9378: CC21004F 02004F51
	v_fma_mixhi_f16 v80, v84, s39, 0                           // 0000001C9380: CC220050 02004F54
	v_fma_mixlo_f16 v81, v85, s39, 0                           // 0000001C9388: CC210051 02004F55
	s_waitcnt lgkmcnt(5)                                       // 0000001C9390: BF89FC57
	v_fma_mixhi_f16 v84, v92, s39, 0                           // 0000001C9394: CC220054 02004F5C
	s_waitcnt lgkmcnt(4)                                       // 0000001C939C: BF89FC47
	v_fma_mixlo_f16 v85, v93, s39, 0                           // 0000001C93A0: CC210055 02004F5D
	s_waitcnt lgkmcnt(0)                                       // 0000001C93A8: BF89FC07
	v_fma_mixlo_f16 v87, v141, s39, 0                          // 0000001C93AC: CC210057 02004F8D
	v_fma_mixhi_f16 v87, v142, s39, 0                          // 0000001C93B4: CC220057 02004F8E
	v_fma_mixlo_f16 v88, v143, s39, 0                          // 0000001C93BC: CC210058 02004F8F
	v_fma_mixhi_f16 v88, v144, s39, 0                          // 0000001C93C4: CC220058 02004F90
	ds_load_b128 v[141:144], v214 offset:25536                 // 0000001C93CC: DBFC63C0 8D0000D6
	ds_load_b128 v[165:168], v214 offset:25552                 // 0000001C93D4: DBFC63D0 A50000D6
	v_fma_mixlo_f16 v92, v155, s39, 0                          // 0000001C93DC: CC21005C 02004F9B
	ds_load_b128 v[169:172], v214 offset:25568                 // 0000001C93E4: DBFC63E0 A90000D6
	v_fma_mixhi_f16 v92, v156, s39, 0                          // 0000001C93EC: CC22005C 02004F9C
	v_fma_mixlo_f16 v93, v157, s39, 0                          // 0000001C93F4: CC21005D 02004F9D
	v_fma_mixhi_f16 v93, v158, s39, 0                          // 0000001C93FC: CC22005D 02004F9E
	ds_load_b128 v[155:158], v214 offset:25584                 // 0000001C9404: DBFC63F0 9B0000D6
	v_fma_mixlo_f16 v80, v83, s39, 0                           // 0000001C940C: CC210050 02004F53
	v_fma_mixlo_f16 v83, v89, s39, 0                           // 0000001C9414: CC210053 02004F59
	v_fma_mixlo_f16 v89, v149, s39, 0                          // 0000001C941C: CC210059 02004F95
	v_fma_mixhi_f16 v89, v150, s39, 0                          // 0000001C9424: CC220059 02004F96
	v_fma_mixhi_f16 v83, v90, s39, 0                           // 0000001C942C: CC220053 02004F5A
	v_fma_mixlo_f16 v84, v91, s39, 0                           // 0000001C9434: CC210054 02004F5B
	v_fma_mixlo_f16 v90, v151, s39, 0                          // 0000001C943C: CC21005A 02004F97
	v_fma_mixhi_f16 v90, v152, s39, 0                          // 0000001C9444: CC22005A 02004F98
	v_fma_mixlo_f16 v91, v153, s39, 0                          // 0000001C944C: CC21005B 02004F99
	v_fma_mixhi_f16 v91, v154, s39, 0                          // 0000001C9454: CC22005B 02004F9A
	v_fma_mixhi_f16 v81, v86, s39, 0                           // 0000001C945C: CC220051 02004F56
	v_fma_mixhi_f16 v85, v94, s39, 0                           // 0000001C9464: CC220055 02004F5E
	s_waitcnt lgkmcnt(3)                                       // 0000001C946C: BF89FC37
	v_fma_mixlo_f16 v149, v141, s39, 0                         // 0000001C9470: CC210095 02004F8D
	v_fma_mixhi_f16 v149, v142, s39, 0                         // 0000001C9478: CC220095 02004F8E
	v_fma_mixlo_f16 v150, v143, s39, 0                         // 0000001C9480: CC210096 02004F8F
	v_fma_mixhi_f16 v150, v144, s39, 0                         // 0000001C9488: CC220096 02004F90
	ds_load_b128 v[141:144], v214 offset:256                   // 0000001C9490: DBFC0100 8D0000D6
	s_waitcnt lgkmcnt(3)                                       // 0000001C9498: BF89FC37
	v_fma_mixlo_f16 v151, v165, s39, 0                         // 0000001C949C: CC210097 02004FA5
	v_fma_mixhi_f16 v151, v166, s39, 0                         // 0000001C94A4: CC220097 02004FA6
	v_fma_mixlo_f16 v152, v167, s39, 0                         // 0000001C94AC: CC210098 02004FA7
	v_fma_mixhi_f16 v152, v168, s39, 0                         // 0000001C94B4: CC220098 02004FA8
	s_waitcnt lgkmcnt(2)                                       // 0000001C94BC: BF89FC27
	v_fma_mixlo_f16 v153, v169, s39, 0                         // 0000001C94C0: CC210099 02004FA9
	v_fma_mixhi_f16 v153, v170, s39, 0                         // 0000001C94C8: CC220099 02004FAA
	v_fma_mixlo_f16 v154, v171, s39, 0                         // 0000001C94D0: CC21009A 02004FAB
	v_fma_mixhi_f16 v154, v172, s39, 0                         // 0000001C94D8: CC22009A 02004FAC
	s_waitcnt lgkmcnt(1)                                       // 0000001C94E0: BF89FC17
	v_fma_mixlo_f16 v155, v155, s39, 0                         // 0000001C94E4: CC21009B 02004F9B
	v_fma_mixhi_f16 v155, v156, s39, 0                         // 0000001C94EC: CC22009B 02004F9C
	v_fma_mixlo_f16 v156, v157, s39, 0                         // 0000001C94F4: CC21009C 02004F9D
	v_fma_mixhi_f16 v156, v158, s39, 0                         // 0000001C94FC: CC22009C 02004F9E
	v_fma_mixlo_f16 v86, v95, s39, 0                           // 0000001C9504: CC210056 02004F5F
	v_fma_mixhi_f16 v86, v96, s39, 0                           // 0000001C950C: CC220056 02004F60
	v_fma_mixlo_f16 v94, v159, s39, 0                          // 0000001C9514: CC21005E 02004F9F
	v_fma_mixhi_f16 v94, v160, s39, 0                          // 0000001C951C: CC22005E 02004FA0
	v_wmma_f32_16x16x16_f16 v[97:104], v[65:72], v[149:156], v[97:104]// 0000001C9524: CC404061 1D872B41
	ds_load_b128 v[149:152], v214 offset:17184                 // 0000001C952C: DBFC4320 950000D6
	v_fma_mixlo_f16 v95, v161, s39, 0                          // 0000001C9534: CC21005F 02004FA1
	v_fma_mixhi_f16 v95, v162, s39, 0                          // 0000001C953C: CC22005F 02004FA2
	v_fma_mixlo_f16 v96, v163, s39, 0                          // 0000001C9544: CC210060 02004FA3
	v_fma_mixhi_f16 v96, v164, s39, 0                          // 0000001C954C: CC220060 02004FA4
	ds_load_b128 v[159:162], v214 offset:272                   // 0000001C9554: DBFC0110 9F0000D6
	ds_load_b128 v[163:166], v214 offset:288                   // 0000001C955C: DBFC0120 A30000D6
	v_wmma_f32_16x16x16_f16 v[121:128], v[65:72], v[73:80], v[121:128]// 0000001C9564: CC404079 1DE69341
	ds_load_b128 v[73:76], v214 offset:304                     // 0000001C956C: DBFC0130 490000D6
	v_wmma_f32_16x16x16_f16 v[105:112], v[65:72], v[81:88], v[105:112]// 0000001C9574: CC404069 1DA6A341
	v_wmma_f32_16x16x16_f16 v[113:120], v[65:72], v[89:96], v[113:120]// 0000001C957C: CC404071 1DC6B341
	ds_load_b128 v[77:80], v214 offset:8704                    // 0000001C9584: DBFC2200 4D0000D6
	ds_load_b128 v[81:84], v214 offset:8720                    // 0000001C958C: DBFC2210 510000D6
	s_waitcnt lgkmcnt(6)                                       // 0000001C9594: BF89FC67
	v_fma_mixlo_f16 v65, v141, s39, 0                          // 0000001C9598: CC210041 02004F8D
	v_fma_mixhi_f16 v65, v142, s39, 0                          // 0000001C95A0: CC220041 02004F8E
	v_fma_mixlo_f16 v66, v143, s39, 0                          // 0000001C95A8: CC210042 02004F8F
	v_fma_mixhi_f16 v66, v144, s39, 0                          // 0000001C95B0: CC220042 02004F90
	ds_load_b128 v[85:88], v214 offset:8736                    // 0000001C95B8: DBFC2220 550000D6
	ds_load_b128 v[89:92], v214 offset:8752                    // 0000001C95C0: DBFC2230 590000D6
	ds_load_b128 v[93:96], v214 offset:17152                   // 0000001C95C8: DBFC4300 5D0000D6
	ds_load_b128 v[141:144], v214 offset:17168                 // 0000001C95D0: DBFC4310 8D0000D6
	ds_load_b128 v[153:156], v214 offset:17200                 // 0000001C95D8: DBFC4330 990000D6
	s_waitcnt lgkmcnt(9)                                       // 0000001C95E0: BF89FC97
	v_fma_mixlo_f16 v67, v159, s39, 0                          // 0000001C95E4: CC210043 02004F9F
	v_fma_mixhi_f16 v67, v160, s39, 0                          // 0000001C95EC: CC220043 02004FA0
	ds_load_b128 v[157:160], v214 offset:25616                 // 0000001C95F4: DBFC6410 9D0000D6
	s_waitcnt lgkmcnt(8)                                       // 0000001C95FC: BF89FC87
	v_fma_mixhi_f16 v71, v74, s39, 0                           // 0000001C9600: CC220047 02004F4A
	v_fma_mixlo_f16 v72, v75, s39, 0                           // 0000001C9608: CC210048 02004F4B
	v_fma_mixhi_f16 v72, v76, s39, 0                           // 0000001C9610: CC220048 02004F4C
	s_waitcnt lgkmcnt(7)                                       // 0000001C9618: BF89FC77
	v_fma_mixlo_f16 v74, v79, s39, 0                           // 0000001C961C: CC21004A 02004F4F
	v_fma_mixhi_f16 v74, v80, s39, 0                           // 0000001C9624: CC22004A 02004F50
	s_waitcnt lgkmcnt(6)                                       // 0000001C962C: BF89FC67
	v_fma_mixlo_f16 v75, v81, s39, 0                           // 0000001C9630: CC21004B 02004F51
	v_fma_mixhi_f16 v75, v82, s39, 0                           // 0000001C9638: CC22004B 02004F52
	v_fma_mixlo_f16 v76, v83, s39, 0                           // 0000001C9640: CC21004C 02004F53
	v_fma_mixhi_f16 v76, v84, s39, 0                           // 0000001C9648: CC22004C 02004F54
	v_fma_mixlo_f16 v68, v161, s39, 0                          // 0000001C9650: CC210044 02004FA1
	s_waitcnt lgkmcnt(4)                                       // 0000001C9658: BF89FC47
	v_fma_mixlo_f16 v79, v89, s39, 0                           // 0000001C965C: CC21004F 02004F59
	v_fma_mixhi_f16 v79, v90, s39, 0                           // 0000001C9664: CC22004F 02004F5A
	v_fma_mixlo_f16 v80, v91, s39, 0                           // 0000001C966C: CC210050 02004F5B
	v_fma_mixhi_f16 v80, v92, s39, 0                           // 0000001C9674: CC220050 02004F5C
	ds_load_b128 v[89:92], v214 offset:25600                   // 0000001C967C: DBFC6400 590000D6
	s_waitcnt lgkmcnt(4)                                       // 0000001C9684: BF89FC47
	v_fma_mixlo_f16 v81, v93, s39, 0                           // 0000001C9688: CC210051 02004F5D
	v_fma_mixhi_f16 v81, v94, s39, 0                           // 0000001C9690: CC220051 02004F5E
	v_fma_mixlo_f16 v82, v95, s39, 0                           // 0000001C9698: CC210052 02004F5F
	v_fma_mixhi_f16 v82, v96, s39, 0                           // 0000001C96A0: CC220052 02004F60
	s_waitcnt lgkmcnt(3)                                       // 0000001C96A8: BF89FC37
	v_fma_mixlo_f16 v83, v141, s39, 0                          // 0000001C96AC: CC210053 02004F8D
	v_fma_mixhi_f16 v83, v142, s39, 0                          // 0000001C96B4: CC220053 02004F8E
	v_fma_mixlo_f16 v84, v143, s39, 0                          // 0000001C96BC: CC210054 02004F8F
	ds_load_b128 v[93:96], v214 offset:25632                   // 0000001C96C4: DBFC6420 5D0000D6
	v_fma_mixhi_f16 v84, v144, s39, 0                          // 0000001C96CC: CC220054 02004F90
	ds_load_b128 v[141:144], v214 offset:25648                 // 0000001C96D4: DBFC6430 8D0000D6
	v_fma_mixhi_f16 v68, v162, s39, 0                          // 0000001C96DC: CC220044 02004FA2
	v_fma_mixlo_f16 v69, v163, s39, 0                          // 0000001C96E4: CC210045 02004FA3
	v_fma_mixhi_f16 v69, v164, s39, 0                          // 0000001C96EC: CC220045 02004FA4
	v_fma_mixlo_f16 v70, v165, s39, 0                          // 0000001C96F4: CC210046 02004FA5
	v_fma_mixhi_f16 v70, v166, s39, 0                          // 0000001C96FC: CC220046 02004FA6
	v_fma_mixlo_f16 v71, v73, s39, 0                           // 0000001C9704: CC210047 02004F49
	v_fma_mixlo_f16 v73, v77, s39, 0                           // 0000001C970C: CC210049 02004F4D
	v_fma_mixhi_f16 v73, v78, s39, 0                           // 0000001C9714: CC220049 02004F4E
	v_fma_mixlo_f16 v77, v85, s39, 0                           // 0000001C971C: CC21004D 02004F55
	s_waitcnt lgkmcnt(2)                                       // 0000001C9724: BF89FC27
	v_fma_mixlo_f16 v89, v89, s39, 0                           // 0000001C9728: CC210059 02004F59
	v_fma_mixhi_f16 v89, v90, s39, 0                           // 0000001C9730: CC220059 02004F5A
	v_fma_mixlo_f16 v90, v91, s39, 0                           // 0000001C9738: CC21005A 02004F5B
	v_fma_mixhi_f16 v90, v92, s39, 0                           // 0000001C9740: CC22005A 02004F5C
	v_fma_mixlo_f16 v91, v157, s39, 0                          // 0000001C9748: CC21005B 02004F9D
	v_fma_mixhi_f16 v91, v158, s39, 0                          // 0000001C9750: CC22005B 02004F9E
	v_fma_mixlo_f16 v92, v159, s39, 0                          // 0000001C9758: CC21005C 02004F9F
	v_fma_mixhi_f16 v92, v160, s39, 0                          // 0000001C9760: CC22005C 02004FA0
	s_waitcnt lgkmcnt(1)                                       // 0000001C9768: BF89FC17
	v_fma_mixlo_f16 v93, v93, s39, 0                           // 0000001C976C: CC21005D 02004F5D
	v_fma_mixhi_f16 v93, v94, s39, 0                           // 0000001C9774: CC22005D 02004F5E
	v_fma_mixlo_f16 v94, v95, s39, 0                           // 0000001C977C: CC21005E 02004F5F
	v_fma_mixhi_f16 v94, v96, s39, 0                           // 0000001C9784: CC22005E 02004F60
	s_waitcnt lgkmcnt(0)                                       // 0000001C978C: BF89FC07
	v_fma_mixlo_f16 v95, v141, s39, 0                          // 0000001C9790: CC21005F 02004F8D
	v_fma_mixhi_f16 v95, v142, s39, 0                          // 0000001C9798: CC22005F 02004F8E
	v_fma_mixlo_f16 v96, v143, s39, 0                          // 0000001C97A0: CC210060 02004F8F
	v_fma_mixhi_f16 v96, v144, s39, 0                          // 0000001C97A8: CC220060 02004F90
	v_fma_mixhi_f16 v77, v86, s39, 0                           // 0000001C97B0: CC22004D 02004F56
	v_fma_mixlo_f16 v78, v87, s39, 0                           // 0000001C97B8: CC21004E 02004F57
	v_fma_mixhi_f16 v78, v88, s39, 0                           // 0000001C97C0: CC22004E 02004F58
	v_fma_mixlo_f16 v85, v149, s39, 0                          // 0000001C97C8: CC210055 02004F95
	v_fma_mixhi_f16 v85, v150, s39, 0                          // 0000001C97D0: CC220055 02004F96
	v_fma_mixlo_f16 v86, v151, s39, 0                          // 0000001C97D8: CC210056 02004F97
	v_fma_mixhi_f16 v86, v152, s39, 0                          // 0000001C97E0: CC220056 02004F98
	v_wmma_f32_16x16x16_f16 v[97:104], v[57:64], v[89:96], v[97:104]// 0000001C97E8: CC404061 1D86B339
	ds_load_b128 v[89:92], v214 offset:17232                   // 0000001C97F0: DBFC4350 590000D6
	v_fma_mixlo_f16 v87, v153, s39, 0                          // 0000001C97F8: CC210057 02004F99
	v_fma_mixhi_f16 v87, v154, s39, 0                          // 0000001C9800: CC220057 02004F9A
	v_fma_mixlo_f16 v88, v155, s39, 0                          // 0000001C9808: CC210058 02004F9B
	v_fma_mixhi_f16 v88, v156, s39, 0                          // 0000001C9810: CC220058 02004F9C
	ds_load_b128 v[149:152], v214 offset:320                   // 0000001C9818: DBFC0140 950000D6
	ds_load_b128 v[153:156], v214 offset:336                   // 0000001C9820: DBFC0150 990000D6
	ds_load_b128 v[157:160], v214 offset:352                   // 0000001C9828: DBFC0160 9D0000D6
	v_wmma_f32_16x16x16_f16 v[121:128], v[57:64], v[65:72], v[121:128]// 0000001C9830: CC404079 1DE68339
	ds_load_b128 v[65:68], v214 offset:368                     // 0000001C9838: DBFC0170 410000D6
	v_wmma_f32_16x16x16_f16 v[105:112], v[57:64], v[73:80], v[105:112]// 0000001C9840: CC404069 1DA69339
	v_wmma_f32_16x16x16_f16 v[113:120], v[57:64], v[81:88], v[113:120]// 0000001C9848: CC404071 1DC6A339
	ds_load_b128 v[69:72], v214 offset:8768                    // 0000001C9850: DBFC2240 450000D6
	ds_load_b128 v[73:76], v214 offset:8784                    // 0000001C9858: DBFC2250 490000D6
	ds_load_b128 v[77:80], v214 offset:8800                    // 0000001C9860: DBFC2260 4D0000D6
	ds_load_b128 v[81:84], v214 offset:8816                    // 0000001C9868: DBFC2270 510000D6
	ds_load_b128 v[85:88], v214 offset:17216                   // 0000001C9870: DBFC4340 550000D6
	ds_load_b128 v[93:96], v214 offset:17248                   // 0000001C9878: DBFC4360 5D0000D6
	ds_load_b128 v[141:144], v214 offset:17264                 // 0000001C9880: DBFC4370 8D0000D6
	s_waitcnt lgkmcnt(10)                                      // 0000001C9888: BF89FCA7
	v_fma_mixlo_f16 v57, v149, s39, 0                          // 0000001C988C: CC210039 02004F95
	v_fma_mixhi_f16 v57, v150, s39, 0                          // 0000001C9894: CC220039 02004F96
	v_fma_mixlo_f16 v58, v151, s39, 0                          // 0000001C989C: CC21003A 02004F97
	v_fma_mixhi_f16 v58, v152, s39, 0                          // 0000001C98A4: CC22003A 02004F98
	s_waitcnt lgkmcnt(7)                                       // 0000001C98AC: BF89FC77
	v_fma_mixhi_f16 v63, v66, s39, 0                           // 0000001C98B0: CC22003F 02004F42
	v_fma_mixlo_f16 v64, v67, s39, 0                           // 0000001C98B8: CC210040 02004F43
	v_fma_mixhi_f16 v64, v68, s39, 0                           // 0000001C98C0: CC220040 02004F44
	s_waitcnt lgkmcnt(6)                                       // 0000001C98C8: BF89FC67
	v_fma_mixlo_f16 v66, v71, s39, 0                           // 0000001C98CC: CC210042 02004F47
	v_fma_mixhi_f16 v66, v72, s39, 0                           // 0000001C98D4: CC220042 02004F48
	s_waitcnt lgkmcnt(5)                                       // 0000001C98DC: BF89FC57
	v_fma_mixlo_f16 v67, v73, s39, 0                           // 0000001C98E0: CC210043 02004F49
	v_fma_mixhi_f16 v67, v74, s39, 0                           // 0000001C98E8: CC220043 02004F4A
	v_fma_mixlo_f16 v68, v75, s39, 0                           // 0000001C98F0: CC210044 02004F4B
	v_fma_mixhi_f16 v68, v76, s39, 0                           // 0000001C98F8: CC220044 02004F4C
	s_waitcnt lgkmcnt(3)                                       // 0000001C9900: BF89FC37
	v_fma_mixlo_f16 v71, v81, s39, 0                           // 0000001C9904: CC210047 02004F51
	v_fma_mixhi_f16 v71, v82, s39, 0                           // 0000001C990C: CC220047 02004F52
	v_fma_mixlo_f16 v72, v83, s39, 0                           // 0000001C9914: CC210048 02004F53
	v_fma_mixhi_f16 v72, v84, s39, 0                           // 0000001C991C: CC220048 02004F54
	ds_load_b128 v[81:84], v214 offset:25664                   // 0000001C9924: DBFC6440 510000D6
	ds_load_b128 v[149:152], v214 offset:25680                 // 0000001C992C: DBFC6450 950000D6
	s_waitcnt lgkmcnt(4)                                       // 0000001C9934: BF89FC47
	v_fma_mixlo_f16 v73, v85, s39, 0                           // 0000001C9938: CC210049 02004F55
	v_fma_mixhi_f16 v73, v86, s39, 0                           // 0000001C9940: CC220049 02004F56
	v_fma_mixlo_f16 v74, v87, s39, 0                           // 0000001C9948: CC21004A 02004F57
	v_fma_mixhi_f16 v74, v88, s39, 0                           // 0000001C9950: CC22004A 02004F58
	v_fma_mixlo_f16 v75, v89, s39, 0                           // 0000001C9958: CC21004B 02004F59
	v_fma_mixhi_f16 v75, v90, s39, 0                           // 0000001C9960: CC22004B 02004F5A
	v_fma_mixlo_f16 v76, v91, s39, 0                           // 0000001C9968: CC21004C 02004F5B
	ds_load_b128 v[85:88], v214 offset:25696                   // 0000001C9970: DBFC6460 550000D6
	v_fma_mixhi_f16 v76, v92, s39, 0                           // 0000001C9978: CC22004C 02004F5C
	ds_load_b128 v[89:92], v214 offset:25712                   // 0000001C9980: DBFC6470 590000D6
	v_fma_mixlo_f16 v59, v153, s39, 0                          // 0000001C9988: CC21003B 02004F99
	v_fma_mixhi_f16 v59, v154, s39, 0                          // 0000001C9990: CC22003B 02004F9A
	v_fma_mixlo_f16 v60, v155, s39, 0                          // 0000001C9998: CC21003C 02004F9B
	v_fma_mixhi_f16 v60, v156, s39, 0                          // 0000001C99A0: CC22003C 02004F9C
	v_fma_mixlo_f16 v61, v157, s39, 0                          // 0000001C99A8: CC21003D 02004F9D
	v_fma_mixhi_f16 v61, v158, s39, 0                          // 0000001C99B0: CC22003D 02004F9E
	v_fma_mixlo_f16 v62, v159, s39, 0                          // 0000001C99B8: CC21003E 02004F9F
	v_fma_mixhi_f16 v62, v160, s39, 0                          // 0000001C99C0: CC22003E 02004FA0
	s_waitcnt lgkmcnt(3)                                       // 0000001C99C8: BF89FC37
	v_fma_mixlo_f16 v81, v81, s39, 0                           // 0000001C99CC: CC210051 02004F51
	v_fma_mixhi_f16 v81, v82, s39, 0                           // 0000001C99D4: CC220051 02004F52
	v_fma_mixlo_f16 v82, v83, s39, 0                           // 0000001C99DC: CC210052 02004F53
	v_fma_mixhi_f16 v82, v84, s39, 0                           // 0000001C99E4: CC220052 02004F54
	s_waitcnt lgkmcnt(2)                                       // 0000001C99EC: BF89FC27
	v_fma_mixlo_f16 v83, v149, s39, 0                          // 0000001C99F0: CC210053 02004F95
	v_fma_mixhi_f16 v83, v150, s39, 0                          // 0000001C99F8: CC220053 02004F96
	v_fma_mixlo_f16 v84, v151, s39, 0                          // 0000001C9A00: CC210054 02004F97
	v_fma_mixhi_f16 v84, v152, s39, 0                          // 0000001C9A08: CC220054 02004F98
	v_fma_mixlo_f16 v63, v65, s39, 0                           // 0000001C9A10: CC21003F 02004F41
	s_waitcnt lgkmcnt(1)                                       // 0000001C9A18: BF89FC17
	v_fma_mixlo_f16 v85, v85, s39, 0                           // 0000001C9A1C: CC210055 02004F55
	v_fma_mixhi_f16 v85, v86, s39, 0                           // 0000001C9A24: CC220055 02004F56
	v_fma_mixlo_f16 v86, v87, s39, 0                           // 0000001C9A2C: CC210056 02004F57
	v_fma_mixhi_f16 v86, v88, s39, 0                           // 0000001C9A34: CC220056 02004F58
	s_waitcnt lgkmcnt(0)                                       // 0000001C9A3C: BF89FC07
	v_fma_mixlo_f16 v87, v89, s39, 0                           // 0000001C9A40: CC210057 02004F59
	v_fma_mixhi_f16 v87, v90, s39, 0                           // 0000001C9A48: CC220057 02004F5A
	v_fma_mixlo_f16 v88, v91, s39, 0                           // 0000001C9A50: CC210058 02004F5B
	v_fma_mixhi_f16 v88, v92, s39, 0                           // 0000001C9A58: CC220058 02004F5C
	v_fma_mixlo_f16 v65, v69, s39, 0                           // 0000001C9A60: CC210041 02004F45
	v_fma_mixhi_f16 v65, v70, s39, 0                           // 0000001C9A68: CC220041 02004F46
	v_fma_mixlo_f16 v69, v77, s39, 0                           // 0000001C9A70: CC210045 02004F4D
	v_fma_mixhi_f16 v69, v78, s39, 0                           // 0000001C9A78: CC220045 02004F4E
	v_fma_mixlo_f16 v70, v79, s39, 0                           // 0000001C9A80: CC210046 02004F4F
	v_fma_mixhi_f16 v70, v80, s39, 0                           // 0000001C9A88: CC220046 02004F50
	v_fma_mixlo_f16 v77, v93, s39, 0                           // 0000001C9A90: CC21004D 02004F5D
	v_fma_mixhi_f16 v77, v94, s39, 0                           // 0000001C9A98: CC22004D 02004F5E
	v_fma_mixlo_f16 v78, v95, s39, 0                           // 0000001C9AA0: CC21004E 02004F5F
	v_fma_mixhi_f16 v78, v96, s39, 0                           // 0000001C9AA8: CC22004E 02004F60
	v_wmma_f32_16x16x16_f16 v[97:104], v[49:56], v[81:88], v[97:104]// 0000001C9AB0: CC404061 1D86A331
	ds_load_b128 v[81:84], v214 offset:17296                   // 0000001C9AB8: DBFC4390 510000D6
	v_fma_mixlo_f16 v79, v141, s39, 0                          // 0000001C9AC0: CC21004F 02004F8D
	v_fma_mixhi_f16 v79, v142, s39, 0                          // 0000001C9AC8: CC22004F 02004F8E
	v_fma_mixlo_f16 v80, v143, s39, 0                          // 0000001C9AD0: CC210050 02004F8F
	v_fma_mixhi_f16 v80, v144, s39, 0                          // 0000001C9AD8: CC220050 02004F90
	ds_load_b128 v[93:96], v214 offset:384                     // 0000001C9AE0: DBFC0180 5D0000D6
	ds_load_b128 v[141:144], v214 offset:400                   // 0000001C9AE8: DBFC0190 8D0000D6
	ds_load_b128 v[149:152], v214 offset:416                   // 0000001C9AF0: DBFC01A0 950000D6
	v_wmma_f32_16x16x16_f16 v[121:128], v[49:56], v[57:64], v[121:128]// 0000001C9AF8: CC404079 1DE67331
	ds_load_b128 v[57:60], v214 offset:432                     // 0000001C9B00: DBFC01B0 390000D6
	v_wmma_f32_16x16x16_f16 v[105:112], v[49:56], v[65:72], v[105:112]// 0000001C9B08: CC404069 1DA68331
	v_wmma_f32_16x16x16_f16 v[113:120], v[49:56], v[73:80], v[113:120]// 0000001C9B10: CC404071 1DC69331
	ds_load_b128 v[61:64], v214 offset:8832                    // 0000001C9B18: DBFC2280 3D0000D6
	ds_load_b128 v[65:68], v214 offset:8848                    // 0000001C9B20: DBFC2290 410000D6
	ds_load_b128 v[69:72], v214 offset:8864                    // 0000001C9B28: DBFC22A0 450000D6
	ds_load_b128 v[73:76], v214 offset:8880                    // 0000001C9B30: DBFC22B0 490000D6
	ds_load_b128 v[77:80], v214 offset:17280                   // 0000001C9B38: DBFC4380 4D0000D6
	ds_load_b128 v[85:88], v214 offset:17312                   // 0000001C9B40: DBFC43A0 550000D6
	ds_load_b128 v[89:92], v214 offset:17328                   // 0000001C9B48: DBFC43B0 590000D6
	ds_load_b128 v[157:160], v214 offset:25840                 // 0000001C9B50: DBFC64F0 9D0000D6
	s_waitcnt lgkmcnt(11)                                      // 0000001C9B58: BF89FCB7
	v_fma_mixlo_f16 v49, v93, s39, 0                           // 0000001C9B5C: CC210031 02004F5D
	v_fma_mixhi_f16 v49, v94, s39, 0                           // 0000001C9B64: CC220031 02004F5E
	v_fma_mixlo_f16 v50, v95, s39, 0                           // 0000001C9B6C: CC210032 02004F5F
	v_fma_mixhi_f16 v50, v96, s39, 0                           // 0000001C9B74: CC220032 02004F60
	s_waitcnt lgkmcnt(8)                                       // 0000001C9B7C: BF89FC87
	v_fma_mixhi_f16 v55, v58, s39, 0                           // 0000001C9B80: CC220037 02004F3A
	v_fma_mixlo_f16 v56, v59, s39, 0                           // 0000001C9B88: CC210038 02004F3B
	v_fma_mixhi_f16 v56, v60, s39, 0                           // 0000001C9B90: CC220038 02004F3C
	s_waitcnt lgkmcnt(7)                                       // 0000001C9B98: BF89FC77
	v_fma_mixlo_f16 v58, v63, s39, 0                           // 0000001C9B9C: CC21003A 02004F3F
	v_fma_mixhi_f16 v58, v64, s39, 0                           // 0000001C9BA4: CC22003A 02004F40
	s_waitcnt lgkmcnt(6)                                       // 0000001C9BAC: BF89FC67
	v_fma_mixlo_f16 v59, v65, s39, 0                           // 0000001C9BB0: CC21003B 02004F41
	v_fma_mixhi_f16 v59, v66, s39, 0                           // 0000001C9BB8: CC22003B 02004F42
	v_fma_mixlo_f16 v60, v67, s39, 0                           // 0000001C9BC0: CC21003C 02004F43
	v_fma_mixhi_f16 v60, v68, s39, 0                           // 0000001C9BC8: CC22003C 02004F44
	s_waitcnt lgkmcnt(4)                                       // 0000001C9BD0: BF89FC47
	v_fma_mixlo_f16 v63, v73, s39, 0                           // 0000001C9BD4: CC21003F 02004F49
	v_fma_mixhi_f16 v63, v74, s39, 0                           // 0000001C9BDC: CC22003F 02004F4A
	v_fma_mixlo_f16 v64, v75, s39, 0                           // 0000001C9BE4: CC210040 02004F4B
	v_fma_mixhi_f16 v64, v76, s39, 0                           // 0000001C9BEC: CC220040 02004F4C
	ds_load_b128 v[73:76], v214 offset:25728                   // 0000001C9BF4: DBFC6480 490000D6
	ds_load_b128 v[93:96], v214 offset:25744                   // 0000001C9BFC: DBFC6490 5D0000D6
	s_waitcnt lgkmcnt(5)                                       // 0000001C9C04: BF89FC57
	v_fma_mixlo_f16 v65, v77, s39, 0                           // 0000001C9C08: CC210041 02004F4D
	v_fma_mixhi_f16 v65, v78, s39, 0                           // 0000001C9C10: CC220041 02004F4E
	v_fma_mixlo_f16 v66, v79, s39, 0                           // 0000001C9C18: CC210042 02004F4F
	v_fma_mixhi_f16 v66, v80, s39, 0                           // 0000001C9C20: CC220042 02004F50
	v_fma_mixlo_f16 v67, v81, s39, 0                           // 0000001C9C28: CC210043 02004F51
	v_fma_mixhi_f16 v67, v82, s39, 0                           // 0000001C9C30: CC220043 02004F52
	v_fma_mixlo_f16 v68, v83, s39, 0                           // 0000001C9C38: CC210044 02004F53
	ds_load_b128 v[77:80], v214 offset:25760                   // 0000001C9C40: DBFC64A0 4D0000D6
	v_fma_mixhi_f16 v68, v84, s39, 0                           // 0000001C9C48: CC220044 02004F54
	ds_load_b128 v[81:84], v214 offset:25776                   // 0000001C9C50: DBFC64B0 510000D6
	v_fma_mixlo_f16 v55, v57, s39, 0                           // 0000001C9C58: CC210037 02004F39
	v_fma_mixlo_f16 v57, v61, s39, 0                           // 0000001C9C60: CC210039 02004F3D
	v_fma_mixlo_f16 v61, v69, s39, 0                           // 0000001C9C68: CC21003D 02004F45
	v_fma_mixhi_f16 v61, v70, s39, 0                           // 0000001C9C70: CC22003D 02004F46
	s_waitcnt lgkmcnt(6)                                       // 0000001C9C78: BF89FC67
	v_fma_mixlo_f16 v69, v85, s39, 0                           // 0000001C9C7C: CC210045 02004F55
	v_fma_mixhi_f16 v69, v86, s39, 0                           // 0000001C9C84: CC220045 02004F56
	v_fma_mixlo_f16 v70, v87, s39, 0                           // 0000001C9C8C: CC210046 02004F57
	v_fma_mixhi_f16 v70, v88, s39, 0                           // 0000001C9C94: CC220046 02004F58
	s_waitcnt lgkmcnt(3)                                       // 0000001C9C9C: BF89FC37
	v_fma_mixlo_f16 v73, v73, s39, 0                           // 0000001C9CA0: CC210049 02004F49
	v_fma_mixhi_f16 v73, v74, s39, 0                           // 0000001C9CA8: CC220049 02004F4A
	v_fma_mixlo_f16 v74, v75, s39, 0                           // 0000001C9CB0: CC21004A 02004F4B
	v_fma_mixhi_f16 v74, v76, s39, 0                           // 0000001C9CB8: CC22004A 02004F4C
	s_waitcnt lgkmcnt(2)                                       // 0000001C9CC0: BF89FC27
	v_fma_mixlo_f16 v75, v93, s39, 0                           // 0000001C9CC4: CC21004B 02004F5D
	ds_load_b128 v[85:88], v214 offset:448                     // 0000001C9CCC: DBFC01C0 550000D6
	v_fma_mixhi_f16 v75, v94, s39, 0                           // 0000001C9CD4: CC22004B 02004F5E
	v_fma_mixlo_f16 v76, v95, s39, 0                           // 0000001C9CDC: CC21004C 02004F5F
	v_fma_mixhi_f16 v76, v96, s39, 0                           // 0000001C9CE4: CC22004C 02004F60
	s_waitcnt lgkmcnt(2)                                       // 0000001C9CEC: BF89FC27
	v_fma_mixlo_f16 v77, v77, s39, 0                           // 0000001C9CF0: CC21004D 02004F4D
	v_fma_mixhi_f16 v77, v78, s39, 0                           // 0000001C9CF8: CC22004D 02004F4E
	v_fma_mixlo_f16 v78, v79, s39, 0                           // 0000001C9D00: CC21004E 02004F4F
	v_fma_mixhi_f16 v78, v80, s39, 0                           // 0000001C9D08: CC22004E 02004F50
	s_waitcnt lgkmcnt(1)                                       // 0000001C9D10: BF89FC17
	v_fma_mixlo_f16 v79, v81, s39, 0                           // 0000001C9D14: CC21004F 02004F51
	ds_load_b128 v[93:96], v214 offset:480                     // 0000001C9D1C: DBFC01E0 5D0000D6
	v_fma_mixhi_f16 v79, v82, s39, 0                           // 0000001C9D24: CC22004F 02004F52
	v_fma_mixlo_f16 v80, v83, s39, 0                           // 0000001C9D2C: CC210050 02004F53
	v_fma_mixhi_f16 v80, v84, s39, 0                           // 0000001C9D34: CC220050 02004F54
	ds_load_b128 v[81:84], v214 offset:496                     // 0000001C9D3C: DBFC01F0 510000D6
	v_fma_mixlo_f16 v51, v141, s39, 0                          // 0000001C9D44: CC210033 02004F8D
	v_fma_mixhi_f16 v51, v142, s39, 0                          // 0000001C9D4C: CC220033 02004F8E
	v_fma_mixlo_f16 v52, v143, s39, 0                          // 0000001C9D54: CC210034 02004F8F
	v_fma_mixhi_f16 v52, v144, s39, 0                          // 0000001C9D5C: CC220034 02004F90
	v_fma_mixlo_f16 v53, v149, s39, 0                          // 0000001C9D64: CC210035 02004F95
	v_fma_mixhi_f16 v53, v150, s39, 0                          // 0000001C9D6C: CC220035 02004F96
	v_fma_mixlo_f16 v54, v151, s39, 0                          // 0000001C9D74: CC210036 02004F97
	v_fma_mixhi_f16 v54, v152, s39, 0                          // 0000001C9D7C: CC220036 02004F98
	v_fma_mixhi_f16 v57, v62, s39, 0                           // 0000001C9D84: CC220039 02004F3E
	v_fma_mixlo_f16 v62, v71, s39, 0                           // 0000001C9D8C: CC21003E 02004F47
	v_fma_mixhi_f16 v62, v72, s39, 0                           // 0000001C9D94: CC22003E 02004F48
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[73:80], v[97:104]// 0000001C9D9C: CC404061 1D869319
	ds_load_b128 v[73:76], v214 offset:17376                   // 0000001C9DA4: DBFC43E0 490000D6
	v_fma_mixlo_f16 v71, v89, s39, 0                           // 0000001C9DAC: CC210047 02004F59
	v_fma_mixhi_f16 v71, v90, s39, 0                           // 0000001C9DB4: CC220047 02004F5A
	v_fma_mixlo_f16 v72, v91, s39, 0                           // 0000001C9DBC: CC210048 02004F5B
	v_fma_mixhi_f16 v72, v92, s39, 0                           // 0000001C9DC4: CC220048 02004F5C
	ds_load_b128 v[89:92], v214 offset:464                     // 0000001C9DCC: DBFC01D0 590000D6
	v_wmma_f32_16x16x16_f16 v[121:128], v[25:32], v[49:56], v[121:128]// 0000001C9DD4: CC404079 1DE66319
	v_wmma_f32_16x16x16_f16 v[105:112], v[25:32], v[57:64], v[105:112]// 0000001C9DDC: CC404069 1DA67319
	ds_load_b128 v[49:52], v214 offset:8896                    // 0000001C9DE4: DBFC22C0 310000D6
	ds_load_b128 v[53:56], v214 offset:8912                    // 0000001C9DEC: DBFC22D0 350000D6
	v_wmma_f32_16x16x16_f16 v[113:120], v[25:32], v[65:72], v[113:120]// 0000001C9DF4: CC404071 1DC68319
	s_waitcnt lgkmcnt(6)                                       // 0000001C9DFC: BF89FC67
	v_fma_mixlo_f16 v25, v85, s39, 0                           // 0000001C9E00: CC210019 02004F55
	v_fma_mixhi_f16 v25, v86, s39, 0                           // 0000001C9E08: CC220019 02004F56
	v_fma_mixlo_f16 v26, v87, s39, 0                           // 0000001C9E10: CC21001A 02004F57
	v_fma_mixhi_f16 v26, v88, s39, 0                           // 0000001C9E18: CC22001A 02004F58
	ds_load_b128 v[57:60], v214 offset:8928                    // 0000001C9E20: DBFC22E0 390000D6
	ds_load_b128 v[61:64], v214 offset:8944                    // 0000001C9E28: DBFC22F0 3D0000D6
	s_waitcnt lgkmcnt(6)                                       // 0000001C9E30: BF89FC67
	v_fma_mixlo_f16 v31, v81, s39, 0                           // 0000001C9E34: CC21001F 02004F51
	v_fma_mixhi_f16 v31, v82, s39, 0                           // 0000001C9E3C: CC22001F 02004F52
	v_fma_mixlo_f16 v32, v83, s39, 0                           // 0000001C9E44: CC210020 02004F53
	v_fma_mixhi_f16 v32, v84, s39, 0                           // 0000001C9E4C: CC220020 02004F54
	ds_load_b128 v[65:68], v214 offset:17344                   // 0000001C9E54: DBFC43C0 410000D6
	ds_load_b128 v[69:72], v214 offset:17360                   // 0000001C9E5C: DBFC43D0 450000D6
	ds_load_b128 v[77:80], v214 offset:17392                   // 0000001C9E64: DBFC43F0 4D0000D6
	ds_load_b128 v[81:84], v214 offset:25792                   // 0000001C9E6C: DBFC64C0 510000D6
	ds_load_b128 v[85:88], v214 offset:25808                   // 0000001C9E74: DBFC64D0 550000D6
	ds_load_b128 v[141:144], v214 offset:25824                 // 0000001C9E7C: DBFC64E0 8D0000D6
	s_waitcnt lgkmcnt(10)                                      // 0000001C9E84: BF89FCA7
	v_fma_mixlo_f16 v27, v89, s39, 0                           // 0000001C9E88: CC21001B 02004F59
	v_fma_mixhi_f16 v27, v90, s39, 0                           // 0000001C9E90: CC22001B 02004F5A
	v_fma_mixlo_f16 v28, v91, s39, 0                           // 0000001C9E98: CC21001C 02004F5B
	v_fma_mixhi_f16 v28, v92, s39, 0                           // 0000001C9EA0: CC22001C 02004F5C
	v_fma_mixlo_f16 v29, v93, s39, 0                           // 0000001C9EA8: CC21001D 02004F5D
	v_fma_mixhi_f16 v29, v94, s39, 0                           // 0000001C9EB0: CC22001D 02004F5E
	v_fma_mixlo_f16 v30, v95, s39, 0                           // 0000001C9EB8: CC21001E 02004F5F
	v_fma_mixhi_f16 v30, v96, s39, 0                           // 0000001C9EC0: CC22001E 02004F60
	s_waitcnt lgkmcnt(9)                                       // 0000001C9EC8: BF89FC97
	v_fma_mixlo_f16 v49, v49, s39, 0                           // 0000001C9ECC: CC210031 02004F31
	v_fma_mixhi_f16 v49, v50, s39, 0                           // 0000001C9ED4: CC220031 02004F32
	v_fma_mixlo_f16 v50, v51, s39, 0                           // 0000001C9EDC: CC210032 02004F33
	v_fma_mixhi_f16 v50, v52, s39, 0                           // 0000001C9EE4: CC220032 02004F34
	s_waitcnt lgkmcnt(8)                                       // 0000001C9EEC: BF89FC87
	v_fma_mixlo_f16 v51, v53, s39, 0                           // 0000001C9EF0: CC210033 02004F35
	v_fma_mixlo_f16 v52, v55, s39, 0                           // 0000001C9EF8: CC210034 02004F37
	v_fma_mixhi_f16 v52, v56, s39, 0                           // 0000001C9F00: CC220034 02004F38
	s_waitcnt lgkmcnt(7)                                       // 0000001C9F08: BF89FC77
	v_fma_mixlo_f16 v53, v57, s39, 0                           // 0000001C9F0C: CC210035 02004F39
	v_fma_mixhi_f16 v53, v58, s39, 0                           // 0000001C9F14: CC220035 02004F3A
	s_waitcnt lgkmcnt(6)                                       // 0000001C9F1C: BF89FC67
	v_fma_mixlo_f16 v55, v61, s39, 0                           // 0000001C9F20: CC210037 02004F3D
	v_fma_mixhi_f16 v55, v62, s39, 0                           // 0000001C9F28: CC220037 02004F3E
	v_fma_mixlo_f16 v56, v63, s39, 0                           // 0000001C9F30: CC210038 02004F3F
	v_fma_mixhi_f16 v56, v64, s39, 0                           // 0000001C9F38: CC220038 02004F40
	s_waitcnt lgkmcnt(5)                                       // 0000001C9F40: BF89FC57
	v_fma_mixlo_f16 v57, v65, s39, 0                           // 0000001C9F44: CC210039 02004F41
	v_fma_mixhi_f16 v57, v66, s39, 0                           // 0000001C9F4C: CC220039 02004F42
	v_fma_mixlo_f16 v58, v67, s39, 0                           // 0000001C9F54: CC21003A 02004F43
	v_fma_mixhi_f16 v58, v68, s39, 0                           // 0000001C9F5C: CC22003A 02004F44
	v_fma_mixlo_f16 v61, v73, s39, 0                           // 0000001C9F64: CC21003D 02004F49
	v_fma_mixhi_f16 v61, v74, s39, 0                           // 0000001C9F6C: CC22003D 02004F4A
	v_fma_mixlo_f16 v62, v75, s39, 0                           // 0000001C9F74: CC21003E 02004F4B
	v_fma_mixhi_f16 v62, v76, s39, 0                           // 0000001C9F7C: CC22003E 02004F4C
	s_waitcnt lgkmcnt(3)                                       // 0000001C9F84: BF89FC37
	v_fma_mixlo_f16 v63, v77, s39, 0                           // 0000001C9F88: CC21003F 02004F4D
	v_fma_mixhi_f16 v63, v78, s39, 0                           // 0000001C9F90: CC22003F 02004F4E
	v_fma_mixlo_f16 v64, v79, s39, 0                           // 0000001C9F98: CC210040 02004F4F
	v_fma_mixhi_f16 v64, v80, s39, 0                           // 0000001C9FA0: CC220040 02004F50
	s_waitcnt lgkmcnt(2)                                       // 0000001C9FA8: BF89FC27
	v_fma_mixlo_f16 v65, v81, s39, 0                           // 0000001C9FAC: CC210041 02004F51
	v_fma_mixhi_f16 v65, v82, s39, 0                           // 0000001C9FB4: CC220041 02004F52
	v_fma_mixlo_f16 v66, v83, s39, 0                           // 0000001C9FBC: CC210042 02004F53
	v_fma_mixhi_f16 v66, v84, s39, 0                           // 0000001C9FC4: CC220042 02004F54
	s_waitcnt lgkmcnt(1)                                       // 0000001C9FCC: BF89FC17
	v_fma_mixlo_f16 v67, v85, s39, 0                           // 0000001C9FD0: CC210043 02004F55
	v_fma_mixhi_f16 v67, v86, s39, 0                           // 0000001C9FD8: CC220043 02004F56
	v_fma_mixlo_f16 v68, v87, s39, 0                           // 0000001C9FE0: CC210044 02004F57
	v_fma_mixhi_f16 v68, v88, s39, 0                           // 0000001C9FE8: CC220044 02004F58
	ds_load_b128 v[73:76], v215                                // 0000001C9FF0: DBFC0000 490000D7
	ds_load_b128 v[77:80], v215 offset:16                      // 0000001C9FF8: DBFC0010 4D0000D7
	ds_load_b128 v[85:88], v215 offset:2320                    // 0000001CA000: DBFC0910 550000D7
	ds_load_b128 v[81:84], v215 offset:2304                    // 0000001CA008: DBFC0900 510000D7
	ds_load_b128 v[93:96], v215 offset:4624                    // 0000001CA010: DBFC1210 5D0000D7
	ds_load_b128 v[89:92], v215 offset:4608                    // 0000001CA018: DBFC1200 590000D7
	ds_load_b128 v[153:156], v215 offset:6928                  // 0000001CA020: DBFC1B10 990000D7
	ds_load_b128 v[149:152], v215 offset:6912                  // 0000001CA028: DBFC1B00 950000D7
	v_fma_mixhi_f16 v51, v54, s39, 0                           // 0000001CA030: CC220033 02004F36
	v_fma_mixlo_f16 v54, v59, s39, 0                           // 0000001CA038: CC210036 02004F3B
	v_fma_mixhi_f16 v54, v60, s39, 0                           // 0000001CA040: CC220036 02004F3C
	v_fma_mixlo_f16 v59, v69, s39, 0                           // 0000001CA048: CC21003B 02004F45
	v_fma_mixhi_f16 v59, v70, s39, 0                           // 0000001CA050: CC22003B 02004F46
	v_fma_mixlo_f16 v60, v71, s39, 0                           // 0000001CA058: CC21003C 02004F47
	v_fma_mixhi_f16 v60, v72, s39, 0                           // 0000001CA060: CC22003C 02004F48
	s_waitcnt lgkmcnt(8)                                       // 0000001CA068: BF89FC87
	v_fma_mixlo_f16 v69, v141, s39, 0                          // 0000001CA06C: CC210045 02004F8D
	v_fma_mixhi_f16 v69, v142, s39, 0                          // 0000001CA074: CC220045 02004F8E
	v_fma_mixlo_f16 v70, v143, s39, 0                          // 0000001CA07C: CC210046 02004F8F
	v_fma_mixhi_f16 v70, v144, s39, 0                          // 0000001CA084: CC220046 02004F90
	v_fma_mixlo_f16 v71, v157, s39, 0                          // 0000001CA08C: CC210047 02004F9D
	v_fma_mixhi_f16 v71, v158, s39, 0                          // 0000001CA094: CC220047 02004F9E
	v_fma_mixlo_f16 v72, v159, s39, 0                          // 0000001CA09C: CC210048 02004F9F
	v_fma_mixhi_f16 v72, v160, s39, 0                          // 0000001CA0A4: CC220048 02004FA0
	v_wmma_f32_16x16x16_f16 v[121:128], v[1:8], v[25:32], v[121:128]// 0000001CA0AC: CC404079 1DE63301
	v_wmma_f32_16x16x16_f16 v[105:112], v[1:8], v[49:56], v[105:112]// 0000001CA0B4: CC404069 1DA66301
	v_wmma_f32_16x16x16_f16 v[113:120], v[1:8], v[57:64], v[113:120]// 0000001CA0BC: CC404071 1DC67301
	s_waitcnt lgkmcnt(6)                                       // 0000001CA0C4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[41:48], v[73:80], v[129:136]// 0000001CA0C8: CC404039 1E069329
	v_wmma_f32_16x16x16_f16 v[97:104], v[1:8], v[65:72], v[97:104]// 0000001CA0D0: CC404061 1D868301
	s_waitcnt lgkmcnt(4)                                       // 0000001CA0D8: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[41:48], v[81:88], v[129:136]// 0000001CA0DC: CC404031 1E06A329
	s_waitcnt lgkmcnt(2)                                       // 0000001CA0E4: BF89FC27
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[89:96], v[129:136]// 0000001CA0E8: CC404019 1E06B329
	s_waitcnt lgkmcnt(0)                                       // 0000001CA0F0: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[41:48], v[149:156], v[129:136]// 0000001CA0F4: CC404001 1E072B29
	s_and_saveexec_b32 s43, s6                                 // 0000001CA0FC: BEAB2006
	s_cbranch_execnz 1206                                      // 0000001CA100: BFA604B6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x65dc>
	s_or_b32 exec_lo, exec_lo, s43                             // 0000001CA104: 8C7E2B7E
	s_and_saveexec_b32 s43, s5                                 // 0000001CA108: BEAB2005
	s_cbranch_execnz 1234                                      // 0000001CA10C: BFA604D2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6658>
	s_or_b32 exec_lo, exec_lo, s43                             // 0000001CA110: 8C7E2B7E
	s_and_saveexec_b32 s43, s7                                 // 0000001CA114: BEAB2007
	s_cbranch_execz 28                                         // 0000001CA118: BFA5001C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x538c>
	ds_load_b128 v[17:20], v215 offset:96                      // 0000001CA11C: DBFC0060 110000D7
	ds_load_b128 v[21:24], v215 offset:112                     // 0000001CA124: DBFC0070 150000D7
	ds_load_b128 v[37:40], v215 offset:2416                    // 0000001CA12C: DBFC0970 250000D7
	ds_load_b128 v[33:36], v215 offset:2400                    // 0000001CA134: DBFC0960 210000D7
	ds_load_b128 v[45:48], v215 offset:4720                    // 0000001CA13C: DBFC1270 2D0000D7
	ds_load_b128 v[41:44], v215 offset:4704                    // 0000001CA144: DBFC1260 290000D7
	ds_load_b128 v[69:72], v215 offset:7024                    // 0000001CA14C: DBFC1B70 450000D7
	ds_load_b128 v[65:68], v215 offset:7008                    // 0000001CA154: DBFC1B60 410000D7
	s_waitcnt lgkmcnt(6)                                       // 0000001CA15C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[9:16], v[17:24], v[57:64]// 0000001CA160: CC404039 1CE62309
	s_waitcnt lgkmcnt(4)                                       // 0000001CA168: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[9:16], v[33:40], v[49:56]// 0000001CA16C: CC404031 1CC64309
	s_waitcnt lgkmcnt(2)                                       // 0000001CA174: BF89FC27
	v_wmma_f32_16x16x16_f16 v[25:32], v[9:16], v[41:48], v[25:32]// 0000001CA178: CC404019 1C665309
	s_waitcnt lgkmcnt(0)                                       // 0000001CA180: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[9:16], v[65:72], v[1:8]  // 0000001CA184: CC404001 1C068309
	s_or_b32 exec_lo, exec_lo, s43                             // 0000001CA18C: 8C7E2B7E
	s_add_i32 s42, s42, 64                                     // 0000001CA190: 812AC02A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001CA194: BF870009
	s_cmp_le_i32 s42, s47                                      // 0000001CA198: BF052F2A
	s_mov_b32 s42, -1                                          // 0000001CA19C: BEAA00C1
	s_cbranch_scc0 391                                         // 0000001CA1A0: BFA10187 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x59c0>
	ds_load_2addr_b32 v[9:10], v226 offset1:2                  // 0000001CA1A4: D8DC0200 090000E2
	ds_load_2addr_b32 v[11:12], v226 offset0:4 offset1:6       // 0000001CA1AC: D8DC0604 0B0000E2
	ds_load_2addr_b32 v[13:14], v226 offset0:8 offset1:10      // 0000001CA1B4: D8DC0A08 0D0000E2
	ds_load_2addr_b32 v[15:16], v226 offset0:12 offset1:14     // 0000001CA1BC: D8DC0E0C 0F0000E2
	v_mad_u64_u32 v[17:18], null, 0x3000, v145, v[195:196]     // 0000001CA1C4: D6FE7C11 070F22FF 00003000
	v_mad_u64_u32 v[19:20], null, 0x3000, v148, v[195:196]     // 0000001CA1D0: D6FE7C13 070F28FF 00003000
	v_mad_u64_u32 v[21:22], null, 0x3000, v147, v[195:196]     // 0000001CA1DC: D6FE7C15 070F26FF 00003000
	v_mad_u64_u32 v[23:24], null, 0x3000, v146, v[195:196]     // 0000001CA1E8: D6FE7C17 070F24FF 00003000
	s_mov_b32 s42, 0                                           // 0000001CA1F4: BEAA0080
	s_waitcnt lgkmcnt(3)                                       // 0000001CA1F8: BF89FC37
	v_fma_f32 v48, v105, v9, v49                               // 0000001CA1FC: D6130030 04C61369
	v_fma_f32 v65, v106, v10, v50                              // 0000001CA204: D6130041 04CA156A
	s_waitcnt lgkmcnt(2)                                       // 0000001CA20C: BF89FC27
	v_fma_f32 v66, v107, v11, v51                              // 0000001CA210: D6130042 04CE176B
	v_fma_f32 v68, v108, v12, v52                              // 0000001CA218: D6130044 04D2196C
	s_waitcnt lgkmcnt(1)                                       // 0000001CA220: BF89FC17
	v_fma_f32 v72, v109, v13, v53                              // 0000001CA224: D6130048 04D61B6D
	v_dual_mul_f32 v48, 0x3b800000, v48 :: v_dual_mul_f32 v65, 0x3b800000, v65// 0000001CA22C: C8C660FF 304082FF 3B800000
	v_mul_f32_e32 v66, 0x3b800000, v66                         // 0000001CA238: 108484FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 0000001CA240: BF89FC07
	v_fma_f32 v73, v112, v16, v56                              // 0000001CA244: D6130049 04E22170
	v_mul_f32_e32 v68, 0x3b800000, v68                         // 0000001CA24C: 108888FF 3B800000
	v_bfe_u32 v69, v48, 16, 1                                  // 0000001CA254: D6100045 02052130
	v_bfe_u32 v70, v65, 16, 1                                  // 0000001CA25C: D6100046 02052141
	v_bfe_u32 v71, v66, 16, 1                                  // 0000001CA264: D6100047 02052142
	v_mul_f32_e32 v73, 0x3b800000, v73                         // 0000001CA26C: 109292FF 3B800000
	v_fma_f32 v77, v114, v10, v26                              // 0000001CA274: D613004D 046A1572
	v_add3_u32 v48, v48, v69, 0x7fff                           // 0000001CA27C: D6550030 03FE8B30 00007FFF
	v_add3_u32 v65, v65, v70, 0x7fff                           // 0000001CA288: D6550041 03FE8D41 00007FFF
	v_add3_u32 v66, v66, v71, 0x7fff                           // 0000001CA294: D6550042 03FE8F42 00007FFF
	v_bfe_u32 v69, v68, 16, 1                                  // 0000001CA2A0: D6100045 02052144
	v_mul_f32_e32 v70, 0x3b800000, v72                         // 0000001CA2A8: 108C90FF 3B800000
	v_fma_f32 v71, v110, v14, v54                              // 0000001CA2B0: D6130047 04DA1D6E
	v_fma_f32 v72, v111, v15, v55                              // 0000001CA2B8: D6130048 04DE1F6F
	v_fma_f32 v74, v113, v9, v25                               // 0000001CA2C0: D613004A 04661371
	v_add3_u32 v68, v68, v69, 0x7fff                           // 0000001CA2C8: D6550044 03FE8B44 00007FFF
	v_bfe_u32 v69, v70, 16, 1                                  // 0000001CA2D4: D6100045 02052146
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CA2DC: BF870234
	v_dual_mul_f32 v71, 0x3b800000, v71 :: v_dual_mul_f32 v72, 0x3b800000, v72// 0000001CA2E0: C8C68EFF 474890FF 3B800000
	v_bfe_u32 v76, v73, 16, 1                                  // 0000001CA2EC: D610004C 02052149
	v_fma_f32 v79, v118, v14, v30                              // 0000001CA2F4: D613004F 047A1D76
	v_add3_u32 v69, v70, v69, 0x7fff                           // 0000001CA2FC: D6550045 03FE8B46 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001CA308: BF870224
	v_bfe_u32 v70, v71, 16, 1                                  // 0000001CA30C: D6100046 02052147
	v_bfe_u32 v75, v72, 16, 1                                  // 0000001CA314: D610004B 02052148
	v_dual_mul_f32 v74, 0x3b800000, v74 :: v_dual_mul_f32 v79, 0x3b800000, v79// 0000001CA31C: C8C694FF 4A4E9EFF 3B800000
	v_fma_f32 v78, v117, v13, v29                              // 0000001CA328: D613004E 04761B75
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001CA330: BF870214
	v_add3_u32 v70, v71, v70, 0x7fff                           // 0000001CA334: D6550046 03FE8D47 00007FFF
	v_add3_u32 v71, v72, v75, 0x7fff                           // 0000001CA340: D6550047 03FE9748 00007FFF
	v_add3_u32 v72, v73, v76, 0x7fff                           // 0000001CA34C: D6550048 03FE9949 00007FFF
	v_bfe_u32 v73, v74, 16, 1                                  // 0000001CA358: D6100049 0205214A
	v_mul_f32_e32 v75, 0x3b800000, v77                         // 0000001CA360: 10969AFF 3B800000
	v_fma_f32 v76, v115, v11, v27                              // 0000001CA368: D613004C 046E1773
	v_fma_f32 v77, v116, v12, v28                              // 0000001CA370: D613004D 04721974
	v_fma_f32 v33, v121, v9, v57                               // 0000001CA378: D6130021 04E61379
	v_add3_u32 v73, v74, v73, 0x7fff                           // 0000001CA380: D6550049 03FE934A 00007FFF
	v_bfe_u32 v74, v75, 16, 1                                  // 0000001CA38C: D610004A 0205214B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CA394: BF870234
	v_dual_mul_f32 v76, 0x3b800000, v76 :: v_dual_mul_f32 v77, 0x3b800000, v77// 0000001CA398: C8C698FF 4C4C9AFF 3B800000
	v_fma_f32 v9, v97, v9, v1                                  // 0000001CA3A4: D6130009 04061361
	v_mul_f32_e32 v78, 0x3b800000, v78                         // 0000001CA3AC: 109C9CFF 3B800000
	v_add3_u32 v74, v75, v74, 0x7fff                           // 0000001CA3B4: D655004A 03FE954B 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001CA3C0: BF870004
	v_bfe_u32 v75, v76, 16, 1                                  // 0000001CA3C4: D610004B 0205214C
	v_bfe_u32 v80, v77, 16, 1                                  // 0000001CA3CC: D6100050 0205214D
	v_fma_f32 v82, v119, v15, v31                              // 0000001CA3D4: D6130052 047E1F77
	v_mul_f32_e32 v9, 0x3b800000, v9                           // 0000001CA3DC: 101212FF 3B800000
	v_bfe_u32 v81, v78, 16, 1                                  // 0000001CA3E4: D6100051 0205214E
	v_fma_f32 v35, v123, v11, v59                              // 0000001CA3EC: D6130023 04EE177B
	v_add3_u32 v75, v76, v75, 0x7fff                           // 0000001CA3F4: D655004B 03FE974C 00007FFF
	v_add3_u32 v76, v77, v80, 0x7fff                           // 0000001CA400: D655004C 03FEA14D 00007FFF
	v_fma_f32 v11, v99, v11, v3                                // 0000001CA40C: D613000B 040E1763
	v_add3_u32 v77, v78, v81, 0x7fff                           // 0000001CA414: D655004D 03FEA34E 00007FFF
	v_bfe_u32 v78, v79, 16, 1                                  // 0000001CA420: D610004E 0205214F
	v_mul_f32_e32 v80, 0x3b800000, v82                         // 0000001CA428: 10A0A4FF 3B800000
	v_fma_f32 v81, v120, v16, v32                              // 0000001CA430: D6130051 04822178
	v_fma_f32 v34, v122, v10, v58                              // 0000001CA438: D6130022 04EA157A
	v_fma_f32 v10, v98, v10, v2                                // 0000001CA440: D613000A 040A1562
	v_mul_f32_e32 v33, 0x3b800000, v33                         // 0000001CA448: 104242FF 3B800000
	v_add3_u32 v78, v79, v78, 0x7fff                           // 0000001CA450: D655004E 03FE9D4F 00007FFF
	v_mul_f32_e32 v81, 0x3b800000, v81                         // 0000001CA45C: 10A2A2FF 3B800000
	v_mul_f32_e32 v11, 0x3b800000, v11                         // 0000001CA464: 101616FF 3B800000
	v_bfe_u32 v79, v80, 16, 1                                  // 0000001CA46C: D610004F 02052150
	v_mul_f32_e32 v34, 0x3b800000, v34                         // 0000001CA474: 104444FF 3B800000
	v_fma_f32 v37, v125, v13, v61                              // 0000001CA47C: D6130025 04F61B7D
	v_fma_f32 v13, v101, v13, v5                               // 0000001CA484: D613000D 04161B65
	v_mul_f32_e32 v10, 0x3b800000, v10                         // 0000001CA48C: 101414FF 3B800000
	v_fma_f32 v36, v124, v12, v60                              // 0000001CA494: D6130024 04F2197C
	v_fma_f32 v39, v127, v15, v63                              // 0000001CA49C: D6130027 04FE1F7F
	v_bfe_u32 v41, v33, 16, 1                                  // 0000001CA4A4: D6100029 02052121
	v_add3_u32 v79, v80, v79, 0x7fff                           // 0000001CA4AC: D655004F 03FE9F50 00007FFF
	v_bfe_u32 v80, v81, 16, 1                                  // 0000001CA4B8: D6100050 02052151
	v_fma_f32 v12, v100, v12, v4                               // 0000001CA4C0: D613000C 04121964
	v_fma_f32 v38, v126, v14, v62                              // 0000001CA4C8: D6130026 04FA1D7E
	v_bfe_u32 v42, v34, 16, 1                                  // 0000001CA4D0: D610002A 02052122
	v_bfe_u32 v82, v9, 16, 1                                   // 0000001CA4D8: D6100052 02052109
	v_bfe_u32 v83, v10, 16, 1                                  // 0000001CA4E0: D6100053 0205210A
	v_fma_f32 v40, v128, v16, v64                              // 0000001CA4E8: D6130028 05022180
	v_dual_mul_f32 v35, 0x3b800000, v35 :: v_dual_mul_f32 v36, 0x3b800000, v36// 0000001CA4F0: C8C646FF 232448FF 3B800000
	v_mul_f32_e32 v39, 0x3b800000, v39                         // 0000001CA4FC: 104E4EFF 3B800000
	v_add3_u32 v41, v33, v41, 0x7fff                           // 0000001CA504: D6550029 03FE5321 00007FFF
	v_add3_u32 v80, v81, v80, 0x7fff                           // 0000001CA510: D6550050 03FEA151 00007FFF
	v_bfe_u32 v81, v11, 16, 1                                  // 0000001CA51C: D6100051 0205210B
	v_fma_f32 v14, v102, v14, v6                               // 0000001CA524: D613000E 041A1D66
	v_dual_mul_f32 v12, 0x3b800000, v12 :: v_dual_mul_f32 v37, 0x3b800000, v37// 0000001CA52C: C8C618FF 0C244AFF 3B800000
	v_mul_f32_e32 v38, 0x3b800000, v38                         // 0000001CA538: 104C4CFF 3B800000
	v_add3_u32 v42, v34, v42, 0x7fff                           // 0000001CA540: D655002A 03FE5522 00007FFF
	v_add3_u32 v9, v9, v82, 0x7fff                             // 0000001CA54C: D6550009 03FEA509 00007FFF
	v_add3_u32 v10, v10, v83, 0x7fff                           // 0000001CA558: D655000A 03FEA70A 00007FFF
	v_mul_f32_e32 v40, 0x3b800000, v40                         // 0000001CA564: 105050FF 3B800000
	v_bfe_u32 v43, v35, 16, 1                                  // 0000001CA56C: D610002B 02052123
	v_bfe_u32 v47, v39, 16, 1                                  // 0000001CA574: D610002F 02052127
	s_clause 0x7                                               // 0000001CA57C: BF850007
	global_store_d16_hi_b16 v[17:18], v41, off                 // 0000001CA580: DC960000 007C2911
	global_store_d16_hi_b16 v[17:18], v48, off offset:32       // 0000001CA588: DC960020 007C3011
	global_store_d16_hi_b16 v[17:18], v73, off offset:64       // 0000001CA590: DC960040 007C4911
	global_store_d16_hi_b16 v[19:20], v42, off                 // 0000001CA598: DC960000 007C2A13
	global_store_d16_hi_b16 v[19:20], v65, off offset:32       // 0000001CA5A0: DC960020 007C4113
	global_store_d16_hi_b16 v[19:20], v74, off offset:64       // 0000001CA5A8: DC960040 007C4A13
	global_store_d16_hi_b16 v[17:18], v9, off offset:96        // 0000001CA5B0: DC960060 007C0911
	global_store_d16_hi_b16 v[19:20], v10, off offset:96       // 0000001CA5B8: DC960060 007C0A13
	v_add3_u32 v9, v11, v81, 0x7fff                            // 0000001CA5C0: D6550009 03FEA30B 00007FFF
	v_mul_f32_e32 v11, 0x3b800000, v13                         // 0000001CA5CC: 10161AFF 3B800000
	v_mul_f32_e32 v13, 0x3b800000, v14                         // 0000001CA5D4: 101A1CFF 3B800000
	v_bfe_u32 v10, v12, 16, 1                                  // 0000001CA5DC: D610000A 0205210C
	v_fma_f32 v14, v103, v15, v7                               // 0000001CA5E4: D613000E 041E1F67
	v_fma_f32 v15, v104, v16, v8                               // 0000001CA5EC: D613000F 04222168
	v_bfe_u32 v45, v37, 16, 1                                  // 0000001CA5F4: D610002D 02052125
	v_bfe_u32 v46, v38, 16, 1                                  // 0000001CA5FC: D610002E 02052126
	v_bfe_u32 v44, v36, 16, 1                                  // 0000001CA604: D610002C 02052124
	v_add3_u32 v43, v35, v43, 0x7fff                           // 0000001CA60C: D655002B 03FE5723 00007FFF
	v_add3_u32 v47, v39, v47, 0x7fff                           // 0000001CA618: D655002F 03FE5F27 00007FFF
	v_bfe_u32 v39, v40, 16, 1                                  // 0000001CA624: D6100027 02052128
	v_add3_u32 v10, v12, v10, 0x7fff                           // 0000001CA62C: D655000A 03FE150C 00007FFF
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CA638: D610000C 0205210B
	v_dual_mul_f32 v14, 0x3b800000, v14 :: v_dual_mul_f32 v15, 0x3b800000, v15// 0000001CA640: C8C61CFF 0E0E1EFF 3B800000
	v_add3_u32 v45, v37, v45, 0x7fff                           // 0000001CA64C: D655002D 03FE5B25 00007FFF
	v_mad_u64_u32 v[33:34], null, 0x3000, v140, v[195:196]     // 0000001CA658: D6FE7C21 070F18FF 00003000
	v_add3_u32 v46, v38, v46, 0x7fff                           // 0000001CA664: D655002E 03FE5D26 00007FFF
	v_mad_u64_u32 v[37:38], null, 0x3000, v138, v[195:196]     // 0000001CA670: D6FE7C25 070F14FF 00003000
	v_add3_u32 v44, v36, v44, 0x7fff                           // 0000001CA67C: D655002C 03FE5924 00007FFF
	v_bfe_u32 v16, v13, 16, 1                                  // 0000001CA688: D6100010 0205210D
	v_mad_u64_u32 v[35:36], null, 0x3000, v139, v[195:196]     // 0000001CA690: D6FE7C23 070F16FF 00003000
	v_add3_u32 v67, v40, v39, 0x7fff                           // 0000001CA69C: D6550043 03FE4F28 00007FFF
	v_mad_u64_u32 v[39:40], null, 0x3000, v137, v[195:196]     // 0000001CA6A8: D6FE7C27 070F12FF 00003000
	s_clause 0x7                                               // 0000001CA6B4: BF850007
	global_store_d16_hi_b16 v[21:22], v43, off                 // 0000001CA6B8: DC960000 007C2B15
	global_store_d16_hi_b16 v[21:22], v66, off offset:32       // 0000001CA6C0: DC960020 007C4215
	global_store_d16_hi_b16 v[21:22], v75, off offset:64       // 0000001CA6C8: DC960040 007C4B15
	global_store_d16_hi_b16 v[23:24], v44, off                 // 0000001CA6D0: DC960000 007C2C17
	global_store_d16_hi_b16 v[23:24], v68, off offset:32       // 0000001CA6D8: DC960020 007C4417
	global_store_d16_hi_b16 v[23:24], v76, off offset:64       // 0000001CA6E0: DC960040 007C4C17
	global_store_d16_hi_b16 v[21:22], v9, off offset:96        // 0000001CA6E8: DC960060 007C0915
	global_store_d16_hi_b16 v[23:24], v10, off offset:96       // 0000001CA6F0: DC960060 007C0A17
	v_add3_u32 v9, v11, v12, 0x7fff                            // 0000001CA6F8: D6550009 03FE190B 00007FFF
	v_bfe_u32 v11, v14, 16, 1                                  // 0000001CA704: D610000B 0205210E
	v_bfe_u32 v12, v15, 16, 1                                  // 0000001CA70C: D610000C 0205210F
	v_add3_u32 v10, v13, v16, 0x7fff                           // 0000001CA714: D655000A 03FE210D 00007FFF
	s_clause 0x7                                               // 0000001CA720: BF850007
	global_store_d16_hi_b16 v[33:34], v45, off                 // 0000001CA724: DC960000 007C2D21
	global_store_d16_hi_b16 v[33:34], v69, off offset:32       // 0000001CA72C: DC960020 007C4521
	global_store_d16_hi_b16 v[33:34], v77, off offset:64       // 0000001CA734: DC960040 007C4D21
	global_store_d16_hi_b16 v[35:36], v46, off                 // 0000001CA73C: DC960000 007C2E23
	global_store_d16_hi_b16 v[35:36], v70, off offset:32       // 0000001CA744: DC960020 007C4623
	global_store_d16_hi_b16 v[35:36], v78, off offset:64       // 0000001CA74C: DC960040 007C4E23
	global_store_d16_hi_b16 v[33:34], v9, off offset:96        // 0000001CA754: DC960060 007C0921
	global_store_d16_hi_b16 v[35:36], v10, off offset:96       // 0000001CA75C: DC960060 007C0A23
	v_add3_u32 v9, v14, v11, 0x7fff                            // 0000001CA764: D6550009 03FE170E 00007FFF
	v_add3_u32 v10, v15, v12, 0x7fff                           // 0000001CA770: D655000A 03FE190F 00007FFF
	s_clause 0x7                                               // 0000001CA77C: BF850007
	global_store_d16_hi_b16 v[37:38], v47, off                 // 0000001CA780: DC960000 007C2F25
	global_store_d16_hi_b16 v[37:38], v71, off offset:32       // 0000001CA788: DC960020 007C4725
	global_store_d16_hi_b16 v[37:38], v79, off offset:64       // 0000001CA790: DC960040 007C4F25
	global_store_d16_hi_b16 v[39:40], v67, off                 // 0000001CA798: DC960000 007C4327
	global_store_d16_hi_b16 v[39:40], v72, off offset:32       // 0000001CA7A0: DC960020 007C4827
	global_store_d16_hi_b16 v[39:40], v80, off offset:64       // 0000001CA7A8: DC960040 007C5027
	global_store_d16_hi_b16 v[37:38], v9, off offset:96        // 0000001CA7B0: DC960060 007C0925
	global_store_d16_hi_b16 v[39:40], v10, off offset:96       // 0000001CA7B8: DC960060 007C0A27
	s_and_not1_b32 vcc_lo, exec_lo, s42                        // 0000001CA7C0: 916A2A7E
	s_cbranch_vccnz 114                                        // 0000001CA7C4: BFA40072 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b90>
	s_and_saveexec_b32 s42, s0                                 // 0000001CA7C8: BEAA2000
	s_cbranch_execnz 929                                       // 0000001CA7CC: BFA603A1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6854>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA7D0: 8C7E2A7E
	s_and_saveexec_b32 s42, s13                                // 0000001CA7D4: BEAA200D
	s_cbranch_execnz 948                                       // 0000001CA7D8: BFA603B4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68ac>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA7DC: 8C7E2A7E
	s_and_saveexec_b32 s42, s12                                // 0000001CA7E0: BEAA200C
	s_cbranch_execnz 967                                       // 0000001CA7E4: BFA603C7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6904>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA7E8: 8C7E2A7E
	s_and_saveexec_b32 s42, s11                                // 0000001CA7EC: BEAA200B
	s_cbranch_execnz 986                                       // 0000001CA7F0: BFA603DA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x695c>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA7F4: 8C7E2A7E
	s_and_saveexec_b32 s42, s10                                // 0000001CA7F8: BEAA200A
	s_cbranch_execnz 1005                                      // 0000001CA7FC: BFA603ED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x69b4>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA800: 8C7E2A7E
	s_and_saveexec_b32 s42, s8                                 // 0000001CA804: BEAA2008
	s_cbranch_execnz 1024                                      // 0000001CA808: BFA60400 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6a0c>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA80C: 8C7E2A7E
	s_and_saveexec_b32 s42, s9                                 // 0000001CA810: BEAA2009
	s_cbranch_execnz 1043                                      // 0000001CA814: BFA60413 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6a64>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA818: 8C7E2A7E
	s_and_saveexec_b32 s42, s1                                 // 0000001CA81C: BEAA2001
	s_cbranch_execnz 1062                                      // 0000001CA820: BFA60426 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6abc>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA824: 8C7E2A7E
	s_and_saveexec_b32 s42, s0                                 // 0000001CA828: BEAA2000
	s_cbranch_execnz 1081                                      // 0000001CA82C: BFA60439 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6b14>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA830: 8C7E2A7E
	s_and_saveexec_b32 s42, s13                                // 0000001CA834: BEAA200D
	s_cbranch_execnz 1100                                      // 0000001CA838: BFA6044C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6b6c>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA83C: 8C7E2A7E
	s_and_saveexec_b32 s42, s12                                // 0000001CA840: BEAA200C
	s_cbranch_execnz 1119                                      // 0000001CA844: BFA6045F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6bc4>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA848: 8C7E2A7E
	s_and_saveexec_b32 s42, s11                                // 0000001CA84C: BEAA200B
	s_cbranch_execnz 1138                                      // 0000001CA850: BFA60472 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6c1c>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA854: 8C7E2A7E
	s_and_saveexec_b32 s42, s10                                // 0000001CA858: BEAA200A
	s_cbranch_execnz 1157                                      // 0000001CA85C: BFA60485 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6c74>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA860: 8C7E2A7E
	s_and_saveexec_b32 s42, s8                                 // 0000001CA864: BEAA2008
	s_cbranch_execnz 1176                                      // 0000001CA868: BFA60498 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6ccc>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA86C: 8C7E2A7E
	s_and_saveexec_b32 s42, s9                                 // 0000001CA870: BEAA2009
	s_cbranch_execnz 1195                                      // 0000001CA874: BFA604AB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6d24>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA878: 8C7E2A7E
	s_and_saveexec_b32 s42, s1                                 // 0000001CA87C: BEAA2001
	s_cbranch_execnz 1214                                      // 0000001CA880: BFA604BE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6d7c>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA884: 8C7E2A7E
	s_and_saveexec_b32 s42, s0                                 // 0000001CA888: BEAA2000
	s_cbranch_execnz 1233                                      // 0000001CA88C: BFA604D1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6dd4>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA890: 8C7E2A7E
	s_and_saveexec_b32 s42, s13                                // 0000001CA894: BEAA200D
	s_cbranch_execnz 1252                                      // 0000001CA898: BFA604E4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6e2c>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA89C: 8C7E2A7E
	s_and_saveexec_b32 s42, s12                                // 0000001CA8A0: BEAA200C
	s_cbranch_execnz 1271                                      // 0000001CA8A4: BFA604F7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6e84>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA8A8: 8C7E2A7E
	s_and_saveexec_b32 s42, s11                                // 0000001CA8AC: BEAA200B
	s_cbranch_execnz 1290                                      // 0000001CA8B0: BFA6050A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6edc>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA8B4: 8C7E2A7E
	s_and_saveexec_b32 s42, s10                                // 0000001CA8B8: BEAA200A
	s_cbranch_execnz 1309                                      // 0000001CA8BC: BFA6051D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6f34>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA8C0: 8C7E2A7E
	s_and_saveexec_b32 s42, s8                                 // 0000001CA8C4: BEAA2008
	s_cbranch_execnz 1328                                      // 0000001CA8C8: BFA60530 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6f8c>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA8CC: 8C7E2A7E
	s_and_saveexec_b32 s42, s9                                 // 0000001CA8D0: BEAA2009
	s_cbranch_execnz 1347                                      // 0000001CA8D4: BFA60543 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6fe4>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA8D8: 8C7E2A7E
	s_and_saveexec_b32 s42, s1                                 // 0000001CA8DC: BEAA2001
	s_cbranch_execnz 1366                                      // 0000001CA8E0: BFA60556 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x703c>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA8E4: 8C7E2A7E
	s_and_saveexec_b32 s42, s0                                 // 0000001CA8E8: BEAA2000
	s_cbranch_execnz 1385                                      // 0000001CA8EC: BFA60569 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7094>
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CA8F0: 8C7E2A7E
	s_and_saveexec_b32 s0, s13                                 // 0000001CA8F4: BE80200D
	s_cbranch_execnz 1404                                      // 0000001CA8F8: BFA6057C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x70ec>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CA8FC: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001CA900: BE80200C
	s_cbranch_execnz 1423                                      // 0000001CA904: BFA6058F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7144>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CA908: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001CA90C: BE80200B
	s_cbranch_execnz 1442                                      // 0000001CA910: BFA605A2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x719c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CA914: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001CA918: BE80200A
	s_cbranch_execnz 1461                                      // 0000001CA91C: BFA605B5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x71f4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CA920: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001CA924: BE802008
	s_cbranch_execnz 1480                                      // 0000001CA928: BFA605C8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x724c>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CA92C: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001CA930: BE802009
	s_cbranch_execnz 1499                                      // 0000001CA934: BFA605DB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x72a4>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CA938: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001CA93C: BE802001
	s_cbranch_execz 18                                         // 0000001CA940: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b8c>
	ds_load_b32 v1, v226 offset:56                             // 0000001CA944: D8D80038 010000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CA94C: BF89FC07
	v_fmac_f32_e32 v8, v104, v1                                // 0000001CA950: 56100368
	v_mad_u64_u32 v[1:2], null, 0x3000, v137, v[195:196]       // 0000001CA954: D6FE7C01 070F12FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CA960: BF870092
	v_mul_f32_e32 v3, 0x3b800000, v8                           // 0000001CA964: 100610FF 3B800000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001CA96C: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CA974: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001CA978: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001CA984: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CA98C: 8C7E007E
	s_waitcnt_vscnt null, 0x0                                  // 0000001CA990: BC7C0000
	s_barrier                                                  // 0000001CA994: BFBD0000
	buffer_gl0_inv                                             // 0000001CA998: E0AC0000 00000000
	ds_load_b128 v[1:4], v218                                  // 0000001CA9A0: DBFC0000 010000DA
	ds_load_b128 v[5:8], v218 offset:16                        // 0000001CA9A8: DBFC0010 050000DA
	ds_load_b128 v[25:28], v219                                // 0000001CA9B0: DBFC0000 190000DB
	ds_load_b128 v[29:32], v219 offset:16                      // 0000001CA9B8: DBFC0010 1D0000DB
	ds_load_b128 v[9:12], v218 offset:32                       // 0000001CA9C0: DBFC0020 090000DA
	ds_load_b128 v[13:16], v218 offset:48                      // 0000001CA9C8: DBFC0030 0D0000DA
	ds_load_b128 v[33:36], v219 offset:2304                    // 0000001CA9D0: DBFC0900 210000DB
	ds_load_b128 v[37:40], v219 offset:2320                    // 0000001CA9D8: DBFC0910 250000DB
	ds_load_b128 v[41:44], v219 offset:4608                    // 0000001CA9E0: DBFC1200 290000DB
	ds_load_b128 v[45:48], v219 offset:4624                    // 0000001CA9E8: DBFC1210 2D0000DB
	ds_load_b128 v[49:52], v219 offset:6912                    // 0000001CA9F0: DBFC1B00 310000DB
	ds_load_b128 v[53:56], v219 offset:6928                    // 0000001CA9F8: DBFC1B10 350000DB
	ds_load_b128 v[57:60], v219 offset:9216                    // 0000001CAA00: DBFC2400 390000DB
	ds_load_b128 v[61:64], v219 offset:9232                    // 0000001CAA08: DBFC2410 3D0000DB
	ds_load_b128 v[65:68], v219 offset:11520                   // 0000001CAA10: DBFC2D00 410000DB
	ds_load_b128 v[69:72], v219 offset:11536                   // 0000001CAA18: DBFC2D10 450000DB
	ds_load_b128 v[73:76], v219 offset:13824                   // 0000001CAA20: DBFC3600 490000DB
	ds_load_b128 v[77:80], v219 offset:13840                   // 0000001CAA28: DBFC3610 4D0000DB
	ds_load_b128 v[81:84], v219 offset:16128                   // 0000001CAA30: DBFC3F00 510000DB
	ds_load_b128 v[85:88], v219 offset:16144                   // 0000001CAA38: DBFC3F10 550000DB
	ds_load_b128 v[89:92], v219 offset:32                      // 0000001CAA40: DBFC0020 590000DB
	ds_load_b128 v[93:96], v219 offset:48                      // 0000001CAA48: DBFC0030 5D0000DB
	v_dual_mov_b32 v17, s20 :: v_dual_mov_b32 v18, s21         // 0000001CAA50: CA100014 11120015
	v_dual_mov_b32 v19, s22 :: v_dual_mov_b32 v20, s23         // 0000001CAA58: CA100016 13140017
	v_dual_mov_b32 v21, s24 :: v_dual_mov_b32 v22, s25         // 0000001CAA60: CA100018 15160019
	v_dual_mov_b32 v23, s26 :: v_dual_mov_b32 v24, s27         // 0000001CAA68: CA10001A 1718001B
	s_mul_f32 s0, s41, 0x3fb8aa3b                              // 0000001CAA70: A200FF29 3FB8AA3B
	s_delay_alu instid0(SALU_CYCLE_3)                          // 0000001CAA78: BF87000B
	s_xor_b32 s1, s0, 0x80000000                               // 0000001CAA7C: 8D01FF00 80000000
	s_rndne_f32 s8, s0                                         // 0000001CAA84: BE886300
	s_waitcnt lgkmcnt(14)                                      // 0000001CAA88: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[105:112], v[33:40], v[1:8], v[17:24]// 0000001CAA8C: CC404069 1C460321
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[1:8], v[17:24]// 0000001CAA94: CC404061 1C460319
	ds_load_b128 v[25:28], v219 offset:2336                    // 0000001CAA9C: DBFC0920 190000DB
	ds_load_b128 v[29:32], v219 offset:2352                    // 0000001CAAA4: DBFC0930 1D0000DB
	s_waitcnt lgkmcnt(14)                                      // 0000001CAAAC: BF89FCE7
	v_wmma_f32_16x16x16_f16 v[33:40], v[41:48], v[1:8], v[17:24]// 0000001CAAB0: CC404021 1C460329
	s_waitcnt lgkmcnt(12)                                      // 0000001CAAB8: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[41:48], v[49:56], v[1:8], v[17:24]// 0000001CAABC: CC404029 1C460331
	s_waitcnt lgkmcnt(10)                                      // 0000001CAAC4: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[49:56], v[57:64], v[1:8], v[17:24]// 0000001CAAC8: CC404031 1C460339
	s_waitcnt lgkmcnt(8)                                       // 0000001CAAD0: BF89FC87
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[1:8], v[17:24]// 0000001CAAD4: CC404039 1C460341
	s_waitcnt lgkmcnt(6)                                       // 0000001CAADC: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[73:80], v[1:8], v[17:24]// 0000001CAAE0: CC404041 1C460349
	s_waitcnt lgkmcnt(4)                                       // 0000001CAAE8: BF89FC47
	v_wmma_f32_16x16x16_f16 v[73:80], v[81:88], v[1:8], v[17:24]// 0000001CAAEC: CC404049 1C460351
	ds_load_b128 v[1:4], v219 offset:4640                      // 0000001CAAF4: DBFC1220 010000DB
	ds_load_b128 v[5:8], v219 offset:4656                      // 0000001CAAFC: DBFC1230 050000DB
	ds_load_b128 v[17:20], v219 offset:6944                    // 0000001CAB04: DBFC1B20 110000DB
	ds_load_b128 v[21:24], v219 offset:6960                    // 0000001CAB0C: DBFC1B30 150000DB
	ds_load_b128 v[81:84], v219 offset:9248                    // 0000001CAB14: DBFC2420 510000DB
	ds_load_b128 v[85:88], v219 offset:9264                    // 0000001CAB1C: DBFC2430 550000DB
	s_waitcnt lgkmcnt(8)                                       // 0000001CAB24: BF89FC87
	v_wmma_f32_16x16x16_f16 v[97:104], v[89:96], v[9:16], v[97:104]// 0000001CAB28: CC404061 1D861359
	s_fmamk_f32 s1, s41, 0x3fb8aa3b, s1                        // 0000001CAB30: A3010129 3FB8AA3B
	s_sub_f32 s0, s0, s8                                       // 0000001CAB38: A0800800
	s_cmp_nlt_f32 s41, 0xc2ce8ed0                              // 0000001CAB3C: BF4EFF29 C2CE8ED0
	s_waitcnt lgkmcnt(6)                                       // 0000001CAB44: BF89FC67
	v_wmma_f32_16x16x16_f16 v[105:112], v[25:32], v[9:16], v[105:112]// 0000001CAB48: CC404069 1DA61319
	ds_load_b128 v[25:28], v219 offset:11552                   // 0000001CAB50: DBFC2D20 190000DB
	ds_load_b128 v[29:32], v219 offset:11568                   // 0000001CAB58: DBFC2D30 1D0000DB
	s_fmamk_f32 s1, s41, 0x32a5705f, s1                        // 0000001CAB60: A3010129 32A5705F
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CAB68: 986A80C1
	s_cmp_ngt_f32 s41, 0x42b17218                              // 0000001CAB6C: BF4BFF29 42B17218
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000001CAB74: BF870599
	s_add_f32 s0, s0, s1                                       // 0000001CAB78: A0000100
	v_exp_f32_e32 v91, s0                                      // 0000001CAB7C: 7EB64A00
	s_waitcnt lgkmcnt(6)                                       // 0000001CAB80: BF89FC67
	v_wmma_f32_16x16x16_f16 v[33:40], v[1:8], v[9:16], v[33:40]// 0000001CAB84: CC404021 1C861301
	ds_load_b128 v[1:4], v219 offset:13856                     // 0000001CAB8C: DBFC3620 010000DB
	ds_load_b128 v[5:8], v219 offset:13872                     // 0000001CAB94: DBFC3630 050000DB
	s_waitcnt lgkmcnt(6)                                       // 0000001CAB9C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[9:16], v[41:48]// 0000001CABA0: CC404029 1CA61311
	ds_load_b128 v[17:20], v219 offset:16160                   // 0000001CABA8: DBFC3F20 110000DB
	ds_load_b128 v[21:24], v219 offset:16176                   // 0000001CABB0: DBFC3F30 150000DB
	s_waitcnt lgkmcnt(6)                                       // 0000001CABB8: BF89FC67
	v_wmma_f32_16x16x16_f16 v[49:56], v[81:88], v[9:16], v[49:56]// 0000001CABBC: CC404031 1CC61351
	ds_load_b128 v[85:88], v218 offset:80                      // 0000001CABC4: DBFC0050 550000DA
	ds_load_b128 v[81:84], v218 offset:64                      // 0000001CABCC: DBFC0040 510000DA
	s_cvt_i32_f32 s0, s8                                       // 0000001CABD4: BE806608
	s_waitcnt lgkmcnt(6)                                       // 0000001CABD8: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[25:32], v[9:16], v[57:64]// 0000001CABDC: CC404039 1CE61319
	ds_load_b128 v[29:32], v219 offset:80                      // 0000001CABE4: DBFC0050 1D0000DB
	ds_load_b128 v[25:28], v219 offset:64                      // 0000001CABEC: DBFC0040 190000DB
	.long 0xd71c005b                                           // 0000001CABF4: D71C005B
	v_cndmask_b32_e32 v0, v91, v0, vcc_lo                      // 0000001CABF8: 0200015B
	s_waitcnt lgkmcnt(6)                                       // 0000001CABFC: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[1:8], v[9:16], v[65:72]// 0000001CAC00: CC404041 1D061301
	ds_load_b128 v[5:8], v219 offset:2384                      // 0000001CAC08: DBFC0950 050000DB
	ds_load_b128 v[1:4], v219 offset:2368                      // 0000001CAC10: DBFC0940 010000DB
	s_waitcnt lgkmcnt(6)                                       // 0000001CAC18: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[9:16], v[73:80]// 0000001CAC1C: CC404049 1D261311
	ds_load_b128 v[13:16], v219 offset:4688                    // 0000001CAC24: DBFC1250 0D0000DB
	ds_load_b128 v[9:12], v219 offset:4672                     // 0000001CAC2C: DBFC1240 090000DB
	ds_load_b128 v[21:24], v219 offset:6992                    // 0000001CAC34: DBFC1B50 150000DB
	ds_load_b128 v[17:20], v219 offset:6976                    // 0000001CAC3C: DBFC1B40 110000DB
	s_waitcnt lgkmcnt(6)                                       // 0000001CAC44: BF89FC67
	v_wmma_f32_16x16x16_f16 v[97:104], v[25:32], v[81:88], v[97:104]// 0000001CAC48: CC404061 1D86A319
	ds_load_b128 v[29:32], v219 offset:9296                    // 0000001CAC50: DBFC2450 1D0000DB
	ds_load_b128 v[25:28], v219 offset:9280                    // 0000001CAC58: DBFC2440 190000DB
	s_waitcnt lgkmcnt(6)                                       // 0000001CAC60: BF89FC67
	v_wmma_f32_16x16x16_f16 v[105:112], v[1:8], v[81:88], v[105:112]// 0000001CAC64: CC404069 1DA6A301
	ds_load_b128 v[5:8], v219 offset:11600                     // 0000001CAC6C: DBFC2D50 050000DB
	ds_load_b128 v[1:4], v219 offset:11584                     // 0000001CAC74: DBFC2D40 010000DB
	s_waitcnt lgkmcnt(6)                                       // 0000001CAC7C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[33:40], v[9:16], v[81:88], v[33:40]// 0000001CAC80: CC404021 1C86A309
	ds_load_b128 v[13:16], v219 offset:13904                   // 0000001CAC88: DBFC3650 0D0000DB
	ds_load_b128 v[9:12], v219 offset:13888                    // 0000001CAC90: DBFC3640 090000DB
	s_waitcnt lgkmcnt(6)                                       // 0000001CAC98: BF89FC67
	v_wmma_f32_16x16x16_f16 v[41:48], v[17:24], v[81:88], v[41:48]// 0000001CAC9C: CC404029 1CA6A311
	ds_load_b128 v[21:24], v219 offset:16208                   // 0000001CACA4: DBFC3F50 150000DB
	ds_load_b128 v[17:20], v219 offset:16192                   // 0000001CACAC: DBFC3F40 110000DB
	s_waitcnt lgkmcnt(6)                                       // 0000001CACB4: BF89FC67
	v_wmma_f32_16x16x16_f16 v[49:56], v[25:32], v[81:88], v[49:56]// 0000001CACB8: CC404031 1CC6A319
	ds_load_b128 v[29:32], v218 offset:112                     // 0000001CACC0: DBFC0070 1D0000DA
	ds_load_b128 v[25:28], v218 offset:96                      // 0000001CACC8: DBFC0060 190000DA
	s_waitcnt lgkmcnt(6)                                       // 0000001CACD0: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[1:8], v[81:88], v[57:64]// 0000001CACD4: CC404039 1CE6A301
	ds_load_b128 v[5:8], v219 offset:112                       // 0000001CACDC: DBFC0070 050000DB
	ds_load_b128 v[1:4], v219 offset:96                        // 0000001CACE4: DBFC0060 010000DB
	s_waitcnt lgkmcnt(6)                                       // 0000001CACEC: BF89FC67
	v_wmma_f32_16x16x16_f16 v[65:72], v[9:16], v[81:88], v[65:72]// 0000001CACF0: CC404041 1D06A309
	ds_load_b128 v[13:16], v219 offset:2416                    // 0000001CACF8: DBFC0970 0D0000DB
	ds_load_b128 v[9:12], v219 offset:2400                     // 0000001CAD00: DBFC0960 090000DB
	s_waitcnt lgkmcnt(6)                                       // 0000001CAD08: BF89FC67
	v_wmma_f32_16x16x16_f16 v[73:80], v[17:24], v[81:88], v[73:80]// 0000001CAD0C: CC404049 1D26A311
	ds_load_b128 v[21:24], v219 offset:4720                    // 0000001CAD14: DBFC1270 150000DB
	ds_load_b128 v[17:20], v219 offset:4704                    // 0000001CAD1C: DBFC1260 110000DB
	ds_load_b128 v[85:88], v219 offset:7024                    // 0000001CAD24: DBFC1B70 550000DB
	ds_load_b128 v[81:84], v219 offset:7008                    // 0000001CAD2C: DBFC1B60 510000DB
	s_waitcnt lgkmcnt(6)                                       // 0000001CAD34: BF89FC67
	v_wmma_f32_16x16x16_f16 v[97:104], v[1:8], v[25:32], v[97:104]// 0000001CAD38: CC404061 1D863301
	ds_load_b128 v[5:8], v219 offset:9328                      // 0000001CAD40: DBFC2470 050000DB
	ds_load_b128 v[1:4], v219 offset:9312                      // 0000001CAD48: DBFC2460 010000DB
	s_waitcnt lgkmcnt(4)                                       // 0000001CAD50: BF89FC47
	v_wmma_f32_16x16x16_f16 v[33:40], v[17:24], v[25:32], v[33:40]// 0000001CAD54: CC404021 1C863311
	ds_load_b128 v[21:24], v219 offset:13936                   // 0000001CAD5C: DBFC3670 150000DB
	ds_load_b128 v[17:20], v219 offset:13920                   // 0000001CAD64: DBFC3660 110000DB
	s_waitcnt lgkmcnt(4)                                       // 0000001CAD6C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[25:32], v[41:48]// 0000001CAD70: CC404029 1CA63351
	ds_load_b128 v[85:88], v219 offset:16240                   // 0000001CAD78: DBFC3F70 550000DB
	ds_load_b128 v[81:84], v219 offset:16224                   // 0000001CAD80: DBFC3F60 510000DB
	v_wmma_f32_16x16x16_f16 v[105:112], v[9:16], v[25:32], v[105:112]// 0000001CAD88: CC404069 1DA63309
	ds_load_b128 v[13:16], v219 offset:11632                   // 0000001CAD90: DBFC2D70 0D0000DB
	ds_load_b128 v[9:12], v219 offset:11616                    // 0000001CAD98: DBFC2D60 090000DB
	ds_load_2addr_b32 v[89:90], v220 offset1:2                 // 0000001CADA0: D8DC0200 590000DC
	s_waitcnt lgkmcnt(7)                                       // 0000001CADA8: BF89FC77
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[25:32], v[49:56]// 0000001CADAC: CC404031 1CC63301
	ds_load_2addr_b32 v[1:2], v220 offset0:4 offset1:6         // 0000001CADB4: D8DC0604 010000DC
	ds_load_2addr_b32 v[3:4], v220 offset0:8 offset1:10        // 0000001CADBC: D8DC0A08 030000DC
	ds_load_2addr_b32 v[5:6], v220 offset0:12 offset1:14       // 0000001CADC4: D8DC0E0C 050000DC
	s_waitcnt lgkmcnt(8)                                       // 0000001CADCC: BF89FC87
	v_wmma_f32_16x16x16_f16 v[65:72], v[17:24], v[25:32], v[65:72]// 0000001CADD0: CC404041 1D063311
	ds_load_2addr_b32 v[7:8], v220 offset0:16 offset1:18       // 0000001CADD8: D8DC1210 070000DC
	s_waitcnt lgkmcnt(7)                                       // 0000001CADE0: BF89FC77
	v_wmma_f32_16x16x16_f16 v[73:80], v[81:88], v[25:32], v[73:80]// 0000001CADE4: CC404049 1D263351
	s_waitcnt lgkmcnt(5)                                       // 0000001CADEC: BF89FC57
	v_wmma_f32_16x16x16_f16 v[57:64], v[9:16], v[25:32], v[57:64]// 0000001CADF0: CC404039 1CE63309
	v_cndmask_b32_e32 v31, 0, v91, vcc_lo                      // 0000001CADF8: 023EB680
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001CADFC: 986A80C1
	ds_load_2addr_b32 v[9:10], v220 offset0:20 offset1:22      // 0000001CAE00: D8DC1614 090000DC
	ds_load_2addr_b32 v[11:12], v220 offset0:24 offset1:26     // 0000001CAE08: D8DC1A18 0B0000DC
	ds_load_2addr_b32 v[13:14], v220 offset0:28 offset1:30     // 0000001CAE10: D8DC1E1C 0D0000DC
	ds_load_2addr_b32 v[15:16], v220 offset0:32 offset1:34     // 0000001CAE18: D8DC2220 0F0000DC
	ds_load_2addr_b32 v[17:18], v220 offset0:36 offset1:38     // 0000001CAE20: D8DC2624 110000DC
	v_cndmask_b32_e32 v91, 0x7f800000, v31, vcc_lo             // 0000001CAE28: 02B63EFF 7F800000
	ds_load_2addr_b32 v[19:20], v220 offset0:40 offset1:42     // 0000001CAE30: D8DC2A28 130000DC
	ds_load_2addr_b32 v[21:22], v220 offset0:44 offset1:46     // 0000001CAE38: D8DC2E2C 150000DC
	ds_load_2addr_b32 v[23:24], v220 offset0:48 offset1:50     // 0000001CAE40: D8DC3230 170000DC
	ds_load_2addr_b32 v[25:26], v220 offset0:52 offset1:54     // 0000001CAE48: D8DC3634 190000DC
	ds_load_2addr_b32 v[27:28], v220 offset0:56 offset1:58     // 0000001CAE50: D8DC3A38 1B0000DC
	ds_load_2addr_b32 v[29:30], v220 offset0:60 offset1:62     // 0000001CAE58: D8DC3E3C 1D0000DC
	s_waitcnt lgkmcnt(15)                                      // 0000001CAE60: BF89FCF7
	v_mul_f32_e32 v90, v91, v90                                // 0000001CAE64: 10B4B55B
	v_mul_f32_e32 v89, v91, v89                                // 0000001CAE68: 10B2B35B
	ds_load_2addr_b32 v[31:32], v220 offset0:64 offset1:66     // 0000001CAE6C: D8DC4240 1F0000DC
	ds_load_2addr_b32 v[81:82], v220 offset0:68 offset1:70     // 0000001CAE74: D8DC4644 510000DC
	ds_load_2addr_b32 v[83:84], v220 offset0:72 offset1:74     // 0000001CAE7C: D8DC4A48 530000DC
	ds_load_2addr_b32 v[85:86], v220 offset0:76 offset1:78     // 0000001CAE84: D8DC4E4C 550000DC
	s_waitcnt lgkmcnt(18)                                      // 0000001CAE8C: BF89FD27
	v_mul_f32_e32 v93, v91, v2                                 // 0000001CAE90: 10BA055B
	v_mul_f32_e32 v92, v91, v1                                 // 0000001CAE94: 10B8035B
	v_fmac_f32_e32 v90, 0x3b800000, v98                        // 0000001CAE98: 56B4C4FF 3B800000
	s_waitcnt lgkmcnt(17)                                      // 0000001CAEA0: BF89FD17
	v_dual_mul_f32 v94, v91, v3 :: v_dual_fmac_f32 v89, 0x3b800000, v97// 0000001CAEA4: C8C0075B 5E58C2FF 3B800000
	v_mul_f32_e32 v95, v91, v4                                 // 0000001CAEB0: 10BE095B
	v_dual_fmac_f32 v93, 0x3b800000, v100 :: v_dual_fmac_f32 v92, 0x3b800000, v99// 0000001CAEB4: C800C8FF 5D5CC6FF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001CAEC0: BF8701A3
	v_fmac_f32_e32 v94, 0x3b800000, v101                       // 0000001CAEC4: 56BCCAFF 3B800000
	s_waitcnt lgkmcnt(16)                                      // 0000001CAECC: BF89FD07
	v_dual_mul_f32 v96, v91, v5 :: v_dual_fmac_f32 v95, 0x3b800000, v102// 0000001CAED0: C8C00B5B 605ECCFF 3B800000
	v_mul_f32_e32 v113, v91, v6                                // 0000001CAEDC: 10E20D5B
	s_waitcnt lgkmcnt(14)                                      // 0000001CAEE0: BF89FCE7
	v_mul_f32_e32 v100, v91, v10                               // 0000001CAEE4: 10C8155B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001CAEE8: BF870233
	v_dual_mul_f32 v99, v91, v9 :: v_dual_fmac_f32 v96, 0x3b800000, v103// 0000001CAEEC: C8C0135B 6360CEFF 3B800000
	v_mul_f32_e32 v98, v91, v8                                 // 0000001CAEF8: 10C4115B
	v_fmac_f32_e32 v113, 0x3b800000, v104                      // 0000001CAEFC: 56E2D0FF 3B800000
	v_fmac_f32_e32 v100, 0x3b800000, v108                      // 0000001CAF04: 56C8D8FF 3B800000
	s_waitcnt lgkmcnt(13)                                      // 0000001CAF0C: BF89FCD7
	v_dual_mul_f32 v102, v91, v12 :: v_dual_fmac_f32 v99, 0x3b800000, v107// 0000001CAF10: C8C0195B 6662D6FF 3B800000
	v_mul_f32_e32 v101, v91, v11                               // 0000001CAF1C: 10CA175B
	v_dual_mul_f32 v97, v91, v7 :: v_dual_fmac_f32 v98, 0x3b800000, v106// 0000001CAF20: C8C00F5B 6162D4FF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001CAF2C: BF8701A3
	v_fmac_f32_e32 v102, 0x3b800000, v110                      // 0000001CAF30: 56CCDCFF 3B800000
	s_waitcnt lgkmcnt(12)                                      // 0000001CAF38: BF89FCC7
	v_dual_mul_f32 v104, v91, v14 :: v_dual_fmac_f32 v101, 0x3b800000, v109// 0000001CAF3C: C8C01D5B 6864DAFF 3B800000
	v_mul_f32_e32 v103, v91, v13                               // 0000001CAF48: 10CE1B5B
	s_waitcnt lgkmcnt(11)                                      // 0000001CAF4C: BF89FCB7
	v_dual_fmac_f32 v97, 0x3b800000, v105 :: v_dual_mul_f32 v106, v91, v16// 0000001CAF50: C806D2FF 616A215B 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CAF5C: BF870193
	v_dual_fmac_f32 v104, 0x3b800000, v112 :: v_dual_mul_f32 v105, v91, v15// 0000001CAF60: C806E0FF 68681F5B 3B800000
	v_fmac_f32_e32 v103, 0x3b800000, v111                      // 0000001CAF6C: 56CEDEFF 3B800000
	ds_load_2addr_b32 v[1:2], v220 offset0:80 offset1:82       // 0000001CAF74: D8DC5250 010000DC
	ds_load_2addr_b32 v[3:4], v220 offset0:84 offset1:86       // 0000001CAF7C: D8DC5654 030000DC
	ds_load_2addr_b32 v[5:6], v220 offset0:88 offset1:90       // 0000001CAF84: D8DC5A58 050000DC
	ds_load_2addr_b32 v[87:88], v220 offset0:92 offset1:94     // 0000001CAF8C: D8DC5E5C 570000DC
	v_fmac_f32_e32 v106, 0x3b800000, v34                       // 0000001CAF94: 56D444FF 3B800000
	s_waitcnt lgkmcnt(14)                                      // 0000001CAF9C: BF89FCE7
	v_dual_mul_f32 v108, v91, v18 :: v_dual_fmac_f32 v105, 0x3b800000, v33// 0000001CAFA0: C8C0255B 6C6842FF 3B800000
	v_mul_f32_e32 v107, v91, v17                               // 0000001CAFAC: 10D6235B
	ds_load_2addr_b32 v[7:8], v220 offset0:96 offset1:98       // 0000001CAFB0: D8DC6260 070000DC
	ds_load_2addr_b32 v[9:10], v220 offset0:100 offset1:102    // 0000001CAFB8: D8DC6664 090000DC
	ds_load_2addr_b32 v[11:12], v220 offset0:104 offset1:106   // 0000001CAFC0: D8DC6A68 0B0000DC
	ds_load_2addr_b32 v[13:14], v220 offset0:108 offset1:110   // 0000001CAFC8: D8DC6E6C 0D0000DC
	s_waitcnt lgkmcnt(15)                                      // 0000001CAFD0: BF89FCF7
	v_mul_f32_e32 v24, v91, v24                                // 0000001CAFD4: 1030315B
	v_fmac_f32_e32 v108, 0x3b800000, v36                       // 0000001CAFD8: 56D848FF 3B800000
	v_dual_mul_f32 v110, v91, v20 :: v_dual_fmac_f32 v107, 0x3b800000, v35// 0000001CAFE0: C8C0295B 6E6A46FF 3B800000
	v_mul_f32_e32 v109, v91, v19                               // 0000001CAFEC: 10DA275B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001CAFF0: BF870194
	v_dual_mul_f32 v23, v91, v23 :: v_dual_fmac_f32 v24, 0x3b800000, v42// 0000001CAFF4: C8C02F5B 171854FF 3B800000
	v_fmac_f32_e32 v110, 0x3b800000, v38                       // 0000001CB000: 56DC4CFF 3B800000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001CB008: BF870003
	v_dual_mul_f32 v112, v91, v22 :: v_dual_fmac_f32 v109, 0x3b800000, v37// 0000001CB00C: C8C02D5B 706C4AFF 3B800000
	v_mul_f32_e32 v111, v91, v21                               // 0000001CB018: 10DE2B5B
	ds_load_2addr_b32 v[15:16], v220 offset0:112 offset1:114   // 0000001CB01C: D8DC7270 0F0000DC
	ds_load_2addr_b32 v[17:18], v220 offset0:116 offset1:118   // 0000001CB024: D8DC7674 110000DC
	ds_load_2addr_b32 v[19:20], v220 offset0:120 offset1:122   // 0000001CB02C: D8DC7A78 130000DC
	ds_load_2addr_b32 v[21:22], v220 offset0:124 offset1:126   // 0000001CB034: D8DC7E7C 150000DC
	s_waitcnt lgkmcnt(18)                                      // 0000001CB03C: BF89FD27
	v_dual_mul_f32 v26, v91, v26 :: v_dual_fmac_f32 v23, 0x3b800000, v41// 0000001CB040: C8C0355B 1A1652FF 3B800000
	v_dual_fmac_f32 v112, 0x3b800000, v40 :: v_dual_fmac_f32 v111, 0x3b800000, v39// 0000001CB04C: C80050FF 706E4EFF 3B800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000001CB058: BF870142
	v_dual_mul_f32 v25, v91, v25 :: v_dual_fmac_f32 v26, 0x3b800000, v44// 0000001CB05C: C8C0335B 191A58FF 3B800000
	s_waitcnt lgkmcnt(17)                                      // 0000001CB068: BF89FD17
	v_mul_f32_e32 v28, v91, v28                                // 0000001CB06C: 1038395B
	s_cmp_lg_u32 s40, s36                                      // 0000001CB070: BF072428
	v_fmac_f32_e32 v25, 0x3b800000, v43                        // 0000001CB074: 563256FF 3B800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB07C: BF8700A2
	v_dual_mul_f32 v27, v91, v27 :: v_dual_fmac_f32 v28, 0x3b800000, v46// 0000001CB080: C8C0375B 1B1C5CFF 3B800000
	s_waitcnt lgkmcnt(16)                                      // 0000001CB08C: BF89FD07
	v_dual_mul_f32 v30, v91, v30 :: v_dual_fmac_f32 v27, 0x3b800000, v45// 0000001CB090: C8C03D5B 1E1A5AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB09C: BF8700A1
	v_dual_mul_f32 v29, v91, v29 :: v_dual_fmac_f32 v30, 0x3b800000, v48// 0000001CB0A0: C8C03B5B 1D1E60FF 3B800000
	s_waitcnt lgkmcnt(15)                                      // 0000001CB0AC: BF89FCF7
	v_dual_mul_f32 v32, v91, v32 :: v_dual_fmac_f32 v29, 0x3b800000, v47// 0000001CB0B0: C8C0415B 201C5EFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB0BC: BF8700A1
	v_dual_mul_f32 v31, v91, v31 :: v_dual_fmac_f32 v32, 0x3b800000, v50// 0000001CB0C0: C8C03F5B 1F2064FF 3B800000
	s_waitcnt lgkmcnt(14)                                      // 0000001CB0CC: BF89FCE7
	v_dual_mul_f32 v34, v91, v82 :: v_dual_fmac_f32 v31, 0x3b800000, v49// 0000001CB0D0: C8C0A55B 221E62FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB0DC: BF8700A1
	v_dual_mul_f32 v33, v91, v81 :: v_dual_fmac_f32 v34, 0x3b800000, v52// 0000001CB0E0: C8C0A35B 212268FF 3B800000
	s_waitcnt lgkmcnt(13)                                      // 0000001CB0EC: BF89FCD7
	v_dual_mul_f32 v36, v91, v84 :: v_dual_fmac_f32 v33, 0x3b800000, v51// 0000001CB0F0: C8C0A95B 242066FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB0FC: BF8700A1
	v_dual_mul_f32 v35, v91, v83 :: v_dual_fmac_f32 v36, 0x3b800000, v54// 0000001CB100: C8C0A75B 23246CFF 3B800000
	s_waitcnt lgkmcnt(12)                                      // 0000001CB10C: BF89FCC7
	v_dual_mul_f32 v38, v91, v86 :: v_dual_fmac_f32 v35, 0x3b800000, v53// 0000001CB110: C8C0AD5B 26226AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB11C: BF8700A1
	v_dual_mul_f32 v37, v91, v85 :: v_dual_fmac_f32 v38, 0x3b800000, v56// 0000001CB120: C8C0AB5B 252670FF 3B800000
	s_waitcnt lgkmcnt(11)                                      // 0000001CB12C: BF89FCB7
	v_dual_mul_f32 v2, v91, v2 :: v_dual_fmac_f32 v37, 0x3b800000, v55// 0000001CB130: C8C0055B 02246EFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB13C: BF8700A1
	v_dual_mul_f32 v1, v91, v1 :: v_dual_fmac_f32 v2, 0x3b800000, v58// 0000001CB140: C8C0035B 010274FF 3B800000
	s_waitcnt lgkmcnt(10)                                      // 0000001CB14C: BF89FCA7
	v_dual_mul_f32 v4, v91, v4 :: v_dual_fmac_f32 v1, 0x3b800000, v57// 0000001CB150: C8C0095B 040072FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB15C: BF8700A1
	v_dual_mul_f32 v3, v91, v3 :: v_dual_fmac_f32 v4, 0x3b800000, v60// 0000001CB160: C8C0075B 030478FF 3B800000
	s_waitcnt lgkmcnt(9)                                       // 0000001CB16C: BF89FC97
	v_dual_mul_f32 v6, v91, v6 :: v_dual_fmac_f32 v3, 0x3b800000, v59// 0000001CB170: C8C00D5B 060276FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB17C: BF8700A1
	v_dual_mul_f32 v5, v91, v5 :: v_dual_fmac_f32 v6, 0x3b800000, v62// 0000001CB180: C8C00B5B 05067CFF 3B800000
	s_waitcnt lgkmcnt(8)                                       // 0000001CB18C: BF89FC87
	v_dual_mul_f32 v40, v91, v88 :: v_dual_fmac_f32 v5, 0x3b800000, v61// 0000001CB190: C8C0B15B 28047AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB19C: BF8700A1
	v_dual_mul_f32 v39, v91, v87 :: v_dual_fmac_f32 v40, 0x3b800000, v64// 0000001CB1A0: C8C0AF5B 272880FF 3B800000
	s_waitcnt lgkmcnt(7)                                       // 0000001CB1AC: BF89FC77
	v_dual_mul_f32 v8, v91, v8 :: v_dual_fmac_f32 v39, 0x3b800000, v63// 0000001CB1B0: C8C0115B 08267EFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB1BC: BF8700A1
	v_dual_mul_f32 v7, v91, v7 :: v_dual_fmac_f32 v8, 0x3b800000, v66// 0000001CB1C0: C8C00F5B 070884FF 3B800000
	s_waitcnt lgkmcnt(6)                                       // 0000001CB1CC: BF89FC67
	v_dual_mul_f32 v10, v91, v10 :: v_dual_fmac_f32 v7, 0x3b800000, v65// 0000001CB1D0: C8C0155B 0A0682FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB1DC: BF8700A1
	v_dual_mul_f32 v9, v91, v9 :: v_dual_fmac_f32 v10, 0x3b800000, v68// 0000001CB1E0: C8C0135B 090A88FF 3B800000
	s_waitcnt lgkmcnt(5)                                       // 0000001CB1EC: BF89FC57
	v_dual_mul_f32 v12, v91, v12 :: v_dual_fmac_f32 v9, 0x3b800000, v67// 0000001CB1F0: C8C0195B 0C0886FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB1FC: BF8700A1
	v_dual_mul_f32 v11, v91, v11 :: v_dual_fmac_f32 v12, 0x3b800000, v70// 0000001CB200: C8C0175B 0B0C8CFF 3B800000
	s_waitcnt lgkmcnt(4)                                       // 0000001CB20C: BF89FC47
	v_dual_mul_f32 v14, v91, v14 :: v_dual_fmac_f32 v11, 0x3b800000, v69// 0000001CB210: C8C01D5B 0E0A8AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB21C: BF8700A1
	v_dual_mul_f32 v13, v91, v13 :: v_dual_fmac_f32 v14, 0x3b800000, v72// 0000001CB220: C8C01B5B 0D0E90FF 3B800000
	s_waitcnt lgkmcnt(3)                                       // 0000001CB22C: BF89FC37
	v_dual_mul_f32 v16, v91, v16 :: v_dual_fmac_f32 v13, 0x3b800000, v71// 0000001CB230: C8C0215B 100C8EFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB23C: BF8700A1
	v_dual_mul_f32 v15, v91, v15 :: v_dual_fmac_f32 v16, 0x3b800000, v74// 0000001CB240: C8C01F5B 0F1094FF 3B800000
	s_waitcnt lgkmcnt(2)                                       // 0000001CB24C: BF89FC27
	v_dual_mul_f32 v18, v91, v18 :: v_dual_fmac_f32 v15, 0x3b800000, v73// 0000001CB250: C8C0255B 120E92FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB25C: BF8700A1
	v_dual_mul_f32 v17, v91, v17 :: v_dual_fmac_f32 v18, 0x3b800000, v76// 0000001CB260: C8C0235B 111298FF 3B800000
	s_waitcnt lgkmcnt(1)                                       // 0000001CB26C: BF89FC17
	v_dual_mul_f32 v20, v91, v20 :: v_dual_fmac_f32 v17, 0x3b800000, v75// 0000001CB270: C8C0295B 141096FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001CB27C: BF8700A1
	v_dual_mul_f32 v19, v91, v19 :: v_dual_fmac_f32 v20, 0x3b800000, v78// 0000001CB280: C8C0275B 13149CFF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 0000001CB28C: BF89FC07
	v_dual_mul_f32 v22, v91, v22 :: v_dual_fmac_f32 v19, 0x3b800000, v77// 0000001CB290: C8C02D5B 16129AFF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CB29C: BF870091
	v_dual_mul_f32 v21, v91, v21 :: v_dual_fmac_f32 v22, 0x3b800000, v80// 0000001CB2A0: C8C02B5B 1516A0FF 3B800000
	v_fmac_f32_e32 v21, 0x3b800000, v79                        // 0000001CB2AC: 562A9EFF 3B800000
	ds_store_2addr_b32 v220, v89, v90 offset1:2                // 0000001CB2B4: D8380200 005A59DC
	ds_store_2addr_b32 v220, v92, v93 offset0:4 offset1:6      // 0000001CB2BC: D8380604 005D5CDC
	ds_store_2addr_b32 v220, v94, v95 offset0:8 offset1:10     // 0000001CB2C4: D8380A08 005F5EDC
	ds_store_2addr_b32 v220, v96, v113 offset0:12 offset1:14   // 0000001CB2CC: D8380E0C 007160DC
	ds_store_2addr_b32 v220, v97, v98 offset0:16 offset1:18    // 0000001CB2D4: D8381210 006261DC
	ds_store_2addr_b32 v220, v99, v100 offset0:20 offset1:22   // 0000001CB2DC: D8381614 006463DC
	ds_store_2addr_b32 v220, v101, v102 offset0:24 offset1:26  // 0000001CB2E4: D8381A18 006665DC
	ds_store_2addr_b32 v220, v103, v104 offset0:28 offset1:30  // 0000001CB2EC: D8381E1C 006867DC
	ds_store_2addr_b32 v220, v105, v106 offset0:32 offset1:34  // 0000001CB2F4: D8382220 006A69DC
	ds_store_2addr_b32 v220, v107, v108 offset0:36 offset1:38  // 0000001CB2FC: D8382624 006C6BDC
	ds_store_2addr_b32 v220, v109, v110 offset0:40 offset1:42  // 0000001CB304: D8382A28 006E6DDC
	ds_store_2addr_b32 v220, v111, v112 offset0:44 offset1:46  // 0000001CB30C: D8382E2C 00706FDC
	ds_store_2addr_b32 v220, v23, v24 offset0:48 offset1:50    // 0000001CB314: D8383230 001817DC
	ds_store_2addr_b32 v220, v25, v26 offset0:52 offset1:54    // 0000001CB31C: D8383634 001A19DC
	ds_store_2addr_b32 v220, v27, v28 offset0:56 offset1:58    // 0000001CB324: D8383A38 001C1BDC
	ds_store_2addr_b32 v220, v29, v30 offset0:60 offset1:62    // 0000001CB32C: D8383E3C 001E1DDC
	ds_store_2addr_b32 v220, v31, v32 offset0:64 offset1:66    // 0000001CB334: D8384240 00201FDC
	ds_store_2addr_b32 v220, v33, v34 offset0:68 offset1:70    // 0000001CB33C: D8384644 002221DC
	ds_store_2addr_b32 v220, v35, v36 offset0:72 offset1:74    // 0000001CB344: D8384A48 002423DC
	ds_store_2addr_b32 v220, v37, v38 offset0:76 offset1:78    // 0000001CB34C: D8384E4C 002625DC
	ds_store_2addr_b32 v220, v1, v2 offset0:80 offset1:82      // 0000001CB354: D8385250 000201DC
	ds_store_2addr_b32 v220, v3, v4 offset0:84 offset1:86      // 0000001CB35C: D8385654 000403DC
	ds_store_2addr_b32 v220, v5, v6 offset0:88 offset1:90      // 0000001CB364: D8385A58 000605DC
	ds_store_2addr_b32 v220, v39, v40 offset0:92 offset1:94    // 0000001CB36C: D8385E5C 002827DC
	ds_store_2addr_b32 v220, v7, v8 offset0:96 offset1:98      // 0000001CB374: D8386260 000807DC
	ds_store_2addr_b32 v220, v9, v10 offset0:100 offset1:102   // 0000001CB37C: D8386664 000A09DC
	ds_store_2addr_b32 v220, v11, v12 offset0:104 offset1:106  // 0000001CB384: D8386A68 000C0BDC
	ds_store_2addr_b32 v220, v13, v14 offset0:108 offset1:110  // 0000001CB38C: D8386E6C 000E0DDC
	ds_store_2addr_b32 v220, v15, v16 offset0:112 offset1:114  // 0000001CB394: D8387270 00100FDC
	ds_store_2addr_b32 v220, v17, v18 offset0:116 offset1:118  // 0000001CB39C: D8387674 001211DC
	ds_store_2addr_b32 v220, v19, v20 offset0:120 offset1:122  // 0000001CB3A4: D8387A78 001413DC
	ds_store_2addr_b32 v220, v21, v22 offset0:124 offset1:126  // 0000001CB3AC: D8387E7C 001615DC
	s_waitcnt lgkmcnt(0)                                       // 0000001CB3B4: BF89FC07
	s_barrier                                                  // 0000001CB3B8: BFBD0000
	buffer_gl0_inv                                             // 0000001CB3BC: E0AC0000 00000000
	s_cbranch_scc0 68                                          // 0000001CB3C4: BFA10044 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66d8>
	s_cmp_lg_u32 s40, s37                                      // 0000001CB3C8: BF072528
	s_cbranch_scc0 98                                          // 0000001CB3CC: BFA10062 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6758>
	s_cmp_lg_u32 s40, s38                                      // 0000001CB3D0: BF072628
	s_cbranch_scc1 59273                                       // 0000001CB3D4: BFA2E789 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3fc>
	s_branch 127                                               // 0000001CB3D8: BFA0007F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67d8>
	ds_load_b128 v[41:44], v215 offset:32                      // 0000001CB3DC: DBFC0020 290000D7
	ds_load_b128 v[45:48], v215 offset:48                      // 0000001CB3E4: DBFC0030 2D0000D7
	ds_load_b128 v[69:72], v215 offset:2352                    // 0000001CB3EC: DBFC0930 450000D7
	ds_load_b128 v[65:68], v215 offset:2336                    // 0000001CB3F4: DBFC0920 410000D7
	ds_load_b128 v[77:80], v215 offset:4656                    // 0000001CB3FC: DBFC1230 4D0000D7
	ds_load_b128 v[73:76], v215 offset:4640                    // 0000001CB404: DBFC1220 490000D7
	ds_load_b128 v[85:88], v215 offset:6960                    // 0000001CB40C: DBFC1B30 550000D7
	ds_load_b128 v[81:84], v215 offset:6944                    // 0000001CB414: DBFC1B20 510000D7
	s_waitcnt lgkmcnt(6)                                       // 0000001CB41C: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[33:40], v[41:48], v[57:64]// 0000001CB420: CC404039 1CE65321
	s_waitcnt lgkmcnt(4)                                       // 0000001CB428: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[33:40], v[65:72], v[49:56]// 0000001CB42C: CC404031 1CC68321
	s_waitcnt lgkmcnt(2)                                       // 0000001CB434: BF89FC27
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[73:80], v[25:32]// 0000001CB438: CC404019 1C669321
	s_waitcnt lgkmcnt(0)                                       // 0000001CB440: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[33:40], v[81:88], v[1:8] // 0000001CB444: CC404001 1C06A321
	s_or_b32 exec_lo, exec_lo, s43                             // 0000001CB44C: 8C7E2B7E
	s_and_saveexec_b32 s43, s5                                 // 0000001CB450: BEAB2005
	s_cbranch_execz 64302                                      // 0000001CB454: BFA5FB2E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5310>
	ds_load_b128 v[33:36], v215 offset:64                      // 0000001CB458: DBFC0040 210000D7
	ds_load_b128 v[37:40], v215 offset:80                      // 0000001CB460: DBFC0050 250000D7
	ds_load_b128 v[45:48], v215 offset:2384                    // 0000001CB468: DBFC0950 2D0000D7
	ds_load_b128 v[41:44], v215 offset:2368                    // 0000001CB470: DBFC0940 290000D7
	ds_load_b128 v[69:72], v215 offset:4688                    // 0000001CB478: DBFC1250 450000D7
	ds_load_b128 v[65:68], v215 offset:4672                    // 0000001CB480: DBFC1240 410000D7
	ds_load_b128 v[77:80], v215 offset:6992                    // 0000001CB488: DBFC1B50 4D0000D7
	ds_load_b128 v[73:76], v215 offset:6976                    // 0000001CB490: DBFC1B40 490000D7
	s_waitcnt lgkmcnt(6)                                       // 0000001CB498: BF89FC67
	v_wmma_f32_16x16x16_f16 v[57:64], v[17:24], v[33:40], v[57:64]// 0000001CB49C: CC404039 1CE64311
	s_waitcnt lgkmcnt(4)                                       // 0000001CB4A4: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[17:24], v[41:48], v[49:56]// 0000001CB4A8: CC404031 1CC65311
	s_waitcnt lgkmcnt(2)                                       // 0000001CB4B0: BF89FC27
	v_wmma_f32_16x16x16_f16 v[25:32], v[17:24], v[65:72], v[25:32]// 0000001CB4B4: CC404019 1C668311
	s_waitcnt lgkmcnt(0)                                       // 0000001CB4BC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[1:8], v[17:24], v[73:80], v[1:8] // 0000001CB4C0: CC404001 1C069311
	s_or_b32 exec_lo, exec_lo, s43                             // 0000001CB4C8: 8C7E2B7E
	s_and_saveexec_b32 s43, s7                                 // 0000001CB4CC: BEAB2007
	s_cbranch_execnz 64274                                     // 0000001CB4D0: BFA6FB12 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x531c>
	s_branch 64301                                             // 0000001CB4D4: BFA0FB2D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x538c>
	v_dual_mov_b32 v1, v197 :: v_dual_mov_b32 v4, v204         // 0000001CB4D8: CA1001C5 010401CC
	v_dual_mov_b32 v3, v209 :: v_dual_mov_b32 v2, v198         // 0000001CB4E0: CA1001D1 030201C6
	s_mov_b32 s1, 0                                            // 0000001CB4E8: BE810080
	s_nop 0                                                    // 0000001CB4EC: BF800000
	s_nop 0                                                    // 0000001CB4F0: BF800000
	s_nop 0                                                    // 0000001CB4F4: BF800000
	s_nop 0                                                    // 0000001CB4F8: BF800000
	s_nop 0                                                    // 0000001CB4FC: BF800000
	ds_load_b32 v5, v3                                         // 0000001CB500: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001CB508: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001CB510: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001CB514: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001CB518: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001CB520: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001CB524: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001CB528: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001CB530: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001CB534: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001CB53C: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001CB544: 917E017E
	s_cbranch_execnz 65517                                     // 0000001CB548: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6700>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001CB54C: 8C7E017E
	s_cmp_lg_u32 s40, s37                                      // 0000001CB550: BF072528
	s_cbranch_scc1 65438                                       // 0000001CB554: BFA2FF9E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x65d0>
	v_dual_mov_b32 v1, v199 :: v_dual_mov_b32 v4, v204         // 0000001CB558: CA1001C7 010401CC
	v_dual_mov_b32 v3, v209 :: v_dual_mov_b32 v2, v200         // 0000001CB560: CA1001D1 030201C8
	s_mov_b32 s1, 0                                            // 0000001CB568: BE810080
	s_nop 0                                                    // 0000001CB56C: BF800000
	s_nop 0                                                    // 0000001CB570: BF800000
	s_nop 0                                                    // 0000001CB574: BF800000
	s_nop 0                                                    // 0000001CB578: BF800000
	s_nop 0                                                    // 0000001CB57C: BF800000
	ds_load_b32 v5, v3                                         // 0000001CB580: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001CB588: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001CB590: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001CB594: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001CB598: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001CB5A0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001CB5A4: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001CB5A8: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001CB5B0: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001CB5B4: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001CB5BC: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001CB5C4: 917E017E
	s_cbranch_execnz 65517                                     // 0000001CB5C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6780>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001CB5CC: 8C7E017E
	s_cmp_lg_u32 s40, s38                                      // 0000001CB5D0: BF072628
	s_cbranch_scc1 59145                                       // 0000001CB5D4: BFA2E709 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3fc>
	v_dual_mov_b32 v1, v201 :: v_dual_mov_b32 v4, v204         // 0000001CB5D8: CA1001C9 010401CC
	v_dual_mov_b32 v3, v209 :: v_dual_mov_b32 v2, v202         // 0000001CB5E0: CA1001D1 030201CA
	s_mov_b32 s1, 0                                            // 0000001CB5E8: BE810080
	s_nop 0                                                    // 0000001CB5EC: BF800000
	s_nop 0                                                    // 0000001CB5F0: BF800000
	s_nop 0                                                    // 0000001CB5F4: BF800000
	s_nop 0                                                    // 0000001CB5F8: BF800000
	s_nop 0                                                    // 0000001CB5FC: BF800000
	ds_load_b32 v5, v3                                         // 0000001CB600: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001CB608: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001CB610: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001CB614: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001CB618: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001CB620: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001CB624: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001CB628: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001CB630: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001CB634: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001CB63C: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001CB644: 917E017E
	s_cbranch_execnz 65517                                     // 0000001CB648: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6800>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001CB64C: 8C7E017E
	s_branch 59114                                             // 0000001CB650: BFA0E6EA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x3fc>
	ds_load_b32 v9, v226                                       // 0000001CB654: D8D80000 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CB65C: BF89FC07
	v_fma_f32 v9, v121, v9, v57                                // 0000001CB660: D6130009 04E61379
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CB668: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CB66C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v145, v[195:196]      // 0000001CB674: D6FE7C09 070F22FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CB680: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CB688: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CB68C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off                  // 0000001CB698: DC960000 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CB6A0: 8C7E2A7E
	s_and_saveexec_b32 s42, s13                                // 0000001CB6A4: BEAA200D
	s_cbranch_execz 64588                                      // 0000001CB6A8: BFA5FC4C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x59dc>
	ds_load_b32 v9, v226 offset:8                              // 0000001CB6AC: D8D80008 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CB6B4: BF89FC07
	v_fma_f32 v9, v122, v9, v58                                // 0000001CB6B8: D6130009 04EA137A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CB6C0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CB6C4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v148, v[195:196]      // 0000001CB6CC: D6FE7C09 070F28FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CB6D8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CB6E0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CB6E4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off                  // 0000001CB6F0: DC960000 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CB6F8: 8C7E2A7E
	s_and_saveexec_b32 s42, s12                                // 0000001CB6FC: BEAA200C
	s_cbranch_execz 64569                                      // 0000001CB700: BFA5FC39 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x59e8>
	ds_load_b32 v9, v226 offset:16                             // 0000001CB704: D8D80010 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CB70C: BF89FC07
	v_fma_f32 v9, v123, v9, v59                                // 0000001CB710: D6130009 04EE137B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CB718: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CB71C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v147, v[195:196]      // 0000001CB724: D6FE7C09 070F26FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CB730: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CB738: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CB73C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off                  // 0000001CB748: DC960000 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CB750: 8C7E2A7E
	s_and_saveexec_b32 s42, s11                                // 0000001CB754: BEAA200B
	s_cbranch_execz 64550                                      // 0000001CB758: BFA5FC26 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x59f4>
	ds_load_b32 v9, v226 offset:24                             // 0000001CB75C: D8D80018 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CB764: BF89FC07
	v_fma_f32 v9, v124, v9, v60                                // 0000001CB768: D6130009 04F2137C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CB770: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CB774: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v146, v[195:196]      // 0000001CB77C: D6FE7C09 070F24FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CB788: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CB790: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CB794: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off                  // 0000001CB7A0: DC960000 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CB7A8: 8C7E2A7E
	s_and_saveexec_b32 s42, s10                                // 0000001CB7AC: BEAA200A
	s_cbranch_execz 64531                                      // 0000001CB7B0: BFA5FC13 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a00>
	ds_load_b32 v9, v226 offset:32                             // 0000001CB7B4: D8D80020 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CB7BC: BF89FC07
	v_fma_f32 v9, v125, v9, v61                                // 0000001CB7C0: D6130009 04F6137D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CB7C8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CB7CC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v140, v[195:196]      // 0000001CB7D4: D6FE7C09 070F18FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CB7E0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CB7E8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CB7EC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off                  // 0000001CB7F8: DC960000 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CB800: 8C7E2A7E
	s_and_saveexec_b32 s42, s8                                 // 0000001CB804: BEAA2008
	s_cbranch_execz 64512                                      // 0000001CB808: BFA5FC00 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a0c>
	ds_load_b32 v9, v226 offset:40                             // 0000001CB80C: D8D80028 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CB814: BF89FC07
	v_fma_f32 v9, v126, v9, v62                                // 0000001CB818: D6130009 04FA137E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CB820: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CB824: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v139, v[195:196]      // 0000001CB82C: D6FE7C09 070F16FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CB838: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CB840: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CB844: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off                  // 0000001CB850: DC960000 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CB858: 8C7E2A7E
	s_and_saveexec_b32 s42, s9                                 // 0000001CB85C: BEAA2009
	s_cbranch_execz 64493                                      // 0000001CB860: BFA5FBED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a18>
	ds_load_b32 v9, v226 offset:48                             // 0000001CB864: D8D80030 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CB86C: BF89FC07
	v_fma_f32 v9, v127, v9, v63                                // 0000001CB870: D6130009 04FE137F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CB878: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CB87C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v138, v[195:196]      // 0000001CB884: D6FE7C09 070F14FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CB890: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CB898: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CB89C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off                  // 0000001CB8A8: DC960000 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CB8B0: 8C7E2A7E
	s_and_saveexec_b32 s42, s1                                 // 0000001CB8B4: BEAA2001
	s_cbranch_execz 64474                                      // 0000001CB8B8: BFA5FBDA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a24>
	ds_load_b32 v9, v226 offset:56                             // 0000001CB8BC: D8D80038 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CB8C4: BF89FC07
	v_fma_f32 v9, v128, v9, v64                                // 0000001CB8C8: D6130009 05021380
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CB8D0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CB8D4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v137, v[195:196]      // 0000001CB8DC: D6FE7C09 070F12FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CB8E8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CB8F0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CB8F4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off                  // 0000001CB900: DC960000 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CB908: 8C7E2A7E
	s_and_saveexec_b32 s42, s0                                 // 0000001CB90C: BEAA2000
	s_cbranch_execz 64455                                      // 0000001CB910: BFA5FBC7 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a30>
	ds_load_b32 v9, v226                                       // 0000001CB914: D8D80000 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CB91C: BF89FC07
	v_fma_f32 v9, v105, v9, v49                                // 0000001CB920: D6130009 04C61369
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CB928: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CB92C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v145, v[195:196]      // 0000001CB934: D6FE7C09 070F22FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CB940: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CB948: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CB94C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001CB958: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CB960: 8C7E2A7E
	s_and_saveexec_b32 s42, s13                                // 0000001CB964: BEAA200D
	s_cbranch_execz 64436                                      // 0000001CB968: BFA5FBB4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a3c>
	ds_load_b32 v9, v226 offset:8                              // 0000001CB96C: D8D80008 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CB974: BF89FC07
	v_fma_f32 v9, v106, v9, v50                                // 0000001CB978: D6130009 04CA136A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CB980: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CB984: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v148, v[195:196]      // 0000001CB98C: D6FE7C09 070F28FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CB998: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CB9A0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CB9A4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001CB9B0: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CB9B8: 8C7E2A7E
	s_and_saveexec_b32 s42, s12                                // 0000001CB9BC: BEAA200C
	s_cbranch_execz 64417                                      // 0000001CB9C0: BFA5FBA1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a48>
	ds_load_b32 v9, v226 offset:16                             // 0000001CB9C4: D8D80010 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CB9CC: BF89FC07
	v_fma_f32 v9, v107, v9, v51                                // 0000001CB9D0: D6130009 04CE136B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CB9D8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CB9DC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v147, v[195:196]      // 0000001CB9E4: D6FE7C09 070F26FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CB9F0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CB9F8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CB9FC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001CBA08: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBA10: 8C7E2A7E
	s_and_saveexec_b32 s42, s11                                // 0000001CBA14: BEAA200B
	s_cbranch_execz 64398                                      // 0000001CBA18: BFA5FB8E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a54>
	ds_load_b32 v9, v226 offset:24                             // 0000001CBA1C: D8D80018 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBA24: BF89FC07
	v_fma_f32 v9, v108, v9, v52                                // 0000001CBA28: D6130009 04D2136C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBA30: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CBA34: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v146, v[195:196]      // 0000001CBA3C: D6FE7C09 070F24FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CBA48: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBA50: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CBA54: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001CBA60: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBA68: 8C7E2A7E
	s_and_saveexec_b32 s42, s10                                // 0000001CBA6C: BEAA200A
	s_cbranch_execz 64379                                      // 0000001CBA70: BFA5FB7B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a60>
	ds_load_b32 v9, v226 offset:32                             // 0000001CBA74: D8D80020 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBA7C: BF89FC07
	v_fma_f32 v9, v109, v9, v53                                // 0000001CBA80: D6130009 04D6136D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBA88: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CBA8C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v140, v[195:196]      // 0000001CBA94: D6FE7C09 070F18FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CBAA0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBAA8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CBAAC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001CBAB8: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBAC0: 8C7E2A7E
	s_and_saveexec_b32 s42, s8                                 // 0000001CBAC4: BEAA2008
	s_cbranch_execz 64360                                      // 0000001CBAC8: BFA5FB68 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a6c>
	ds_load_b32 v9, v226 offset:40                             // 0000001CBACC: D8D80028 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBAD4: BF89FC07
	v_fma_f32 v9, v110, v9, v54                                // 0000001CBAD8: D6130009 04DA136E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBAE0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CBAE4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v139, v[195:196]      // 0000001CBAEC: D6FE7C09 070F16FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CBAF8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBB00: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CBB04: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001CBB10: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBB18: 8C7E2A7E
	s_and_saveexec_b32 s42, s9                                 // 0000001CBB1C: BEAA2009
	s_cbranch_execz 64341                                      // 0000001CBB20: BFA5FB55 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a78>
	ds_load_b32 v9, v226 offset:48                             // 0000001CBB24: D8D80030 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBB2C: BF89FC07
	v_fma_f32 v9, v111, v9, v55                                // 0000001CBB30: D6130009 04DE136F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBB38: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CBB3C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v138, v[195:196]      // 0000001CBB44: D6FE7C09 070F14FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CBB50: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBB58: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CBB5C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001CBB68: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBB70: 8C7E2A7E
	s_and_saveexec_b32 s42, s1                                 // 0000001CBB74: BEAA2001
	s_cbranch_execz 64322                                      // 0000001CBB78: BFA5FB42 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a84>
	ds_load_b32 v9, v226 offset:56                             // 0000001CBB7C: D8D80038 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBB84: BF89FC07
	v_fma_f32 v9, v112, v9, v56                                // 0000001CBB88: D6130009 04E21370
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBB90: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CBB94: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v137, v[195:196]      // 0000001CBB9C: D6FE7C09 070F12FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CBBA8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBBB0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CBBB4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001CBBC0: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBBC8: 8C7E2A7E
	s_and_saveexec_b32 s42, s0                                 // 0000001CBBCC: BEAA2000
	s_cbranch_execz 64303                                      // 0000001CBBD0: BFA5FB2F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a90>
	ds_load_b32 v9, v226                                       // 0000001CBBD4: D8D80000 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBBDC: BF89FC07
	v_fma_f32 v9, v113, v9, v25                                // 0000001CBBE0: D6130009 04661371
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBBE8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CBBEC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v145, v[195:196]      // 0000001CBBF4: D6FE7C09 070F22FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CBC00: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBC08: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CBC0C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001CBC18: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBC20: 8C7E2A7E
	s_and_saveexec_b32 s42, s13                                // 0000001CBC24: BEAA200D
	s_cbranch_execz 64284                                      // 0000001CBC28: BFA5FB1C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a9c>
	ds_load_b32 v9, v226 offset:8                              // 0000001CBC2C: D8D80008 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBC34: BF89FC07
	v_fma_f32 v9, v114, v9, v26                                // 0000001CBC38: D6130009 046A1372
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBC40: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CBC44: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v148, v[195:196]      // 0000001CBC4C: D6FE7C09 070F28FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CBC58: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBC60: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CBC64: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001CBC70: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBC78: 8C7E2A7E
	s_and_saveexec_b32 s42, s12                                // 0000001CBC7C: BEAA200C
	s_cbranch_execz 64265                                      // 0000001CBC80: BFA5FB09 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5aa8>
	ds_load_b32 v9, v226 offset:16                             // 0000001CBC84: D8D80010 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBC8C: BF89FC07
	v_fma_f32 v9, v115, v9, v27                                // 0000001CBC90: D6130009 046E1373
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBC98: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CBC9C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v147, v[195:196]      // 0000001CBCA4: D6FE7C09 070F26FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CBCB0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBCB8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CBCBC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001CBCC8: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBCD0: 8C7E2A7E
	s_and_saveexec_b32 s42, s11                                // 0000001CBCD4: BEAA200B
	s_cbranch_execz 64246                                      // 0000001CBCD8: BFA5FAF6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5ab4>
	ds_load_b32 v9, v226 offset:24                             // 0000001CBCDC: D8D80018 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBCE4: BF89FC07
	v_fma_f32 v9, v116, v9, v28                                // 0000001CBCE8: D6130009 04721374
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBCF0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CBCF4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v146, v[195:196]      // 0000001CBCFC: D6FE7C09 070F24FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CBD08: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBD10: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CBD14: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001CBD20: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBD28: 8C7E2A7E
	s_and_saveexec_b32 s42, s10                                // 0000001CBD2C: BEAA200A
	s_cbranch_execz 64227                                      // 0000001CBD30: BFA5FAE3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5ac0>
	ds_load_b32 v9, v226 offset:32                             // 0000001CBD34: D8D80020 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBD3C: BF89FC07
	v_fma_f32 v9, v117, v9, v29                                // 0000001CBD40: D6130009 04761375
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBD48: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CBD4C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v140, v[195:196]      // 0000001CBD54: D6FE7C09 070F18FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CBD60: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBD68: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CBD6C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001CBD78: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBD80: 8C7E2A7E
	s_and_saveexec_b32 s42, s8                                 // 0000001CBD84: BEAA2008
	s_cbranch_execz 64208                                      // 0000001CBD88: BFA5FAD0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5acc>
	ds_load_b32 v9, v226 offset:40                             // 0000001CBD8C: D8D80028 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBD94: BF89FC07
	v_fma_f32 v9, v118, v9, v30                                // 0000001CBD98: D6130009 047A1376
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBDA0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CBDA4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v139, v[195:196]      // 0000001CBDAC: D6FE7C09 070F16FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CBDB8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBDC0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CBDC4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001CBDD0: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBDD8: 8C7E2A7E
	s_and_saveexec_b32 s42, s9                                 // 0000001CBDDC: BEAA2009
	s_cbranch_execz 64189                                      // 0000001CBDE0: BFA5FABD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5ad8>
	ds_load_b32 v9, v226 offset:48                             // 0000001CBDE4: D8D80030 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBDEC: BF89FC07
	v_fma_f32 v9, v119, v9, v31                                // 0000001CBDF0: D6130009 047E1377
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBDF8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CBDFC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v138, v[195:196]      // 0000001CBE04: D6FE7C09 070F14FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CBE10: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBE18: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CBE1C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001CBE28: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBE30: 8C7E2A7E
	s_and_saveexec_b32 s42, s1                                 // 0000001CBE34: BEAA2001
	s_cbranch_execz 64170                                      // 0000001CBE38: BFA5FAAA <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5ae4>
	ds_load_b32 v9, v226 offset:56                             // 0000001CBE3C: D8D80038 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBE44: BF89FC07
	v_fma_f32 v9, v120, v9, v32                                // 0000001CBE48: D6130009 04821378
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBE50: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001CBE54: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v137, v[195:196]      // 0000001CBE5C: D6FE7C09 070F12FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001CBE68: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBE70: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001CBE74: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001CBE80: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBE88: 8C7E2A7E
	s_and_saveexec_b32 s42, s0                                 // 0000001CBE8C: BEAA2000
	s_cbranch_execz 64151                                      // 0000001CBE90: BFA5FA97 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5af0>
	ds_load_b32 v9, v226                                       // 0000001CBE94: D8D80000 090000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBE9C: BF89FC07
	v_fma_f32 v1, v97, v9, v1                                  // 0000001CBEA0: D6130001 04061361
	v_mad_u64_u32 v[9:10], null, 0x3000, v145, v[195:196]      // 0000001CBEA8: D6FE7C09 070F22FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CBEB4: BF870092
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 0000001CBEB8: 100202FF 3B800000
	v_bfe_u32 v11, v1, 16, 1                                   // 0000001CBEC0: D610000B 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBEC8: BF870001
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001CBECC: D6550001 03FE1701 00007FFF
	global_store_d16_hi_b16 v[9:10], v1, off offset:96         // 0000001CBED8: DC960060 007C0109
	s_or_b32 exec_lo, exec_lo, s42                             // 0000001CBEE0: 8C7E2A7E
	s_and_saveexec_b32 s0, s13                                 // 0000001CBEE4: BE80200D
	s_cbranch_execz 64132                                      // 0000001CBEE8: BFA5FA84 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5afc>
	ds_load_b32 v1, v226 offset:8                              // 0000001CBEEC: D8D80008 010000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBEF4: BF89FC07
	v_fma_f32 v1, v98, v1, v2                                  // 0000001CBEF8: D6130001 040A0362
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBF00: BF870121
	v_mul_f32_e32 v9, 0x3b800000, v1                           // 0000001CBF04: 101202FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v148, v[195:196]       // 0000001CBF0C: D6FE7C01 070F28FF 00003000
	v_bfe_u32 v10, v9, 16, 1                                   // 0000001CBF18: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBF20: BF870001
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000001CBF24: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[1:2], v9, off offset:96          // 0000001CBF30: DC960060 007C0901
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CBF38: 8C7E007E
	s_and_saveexec_b32 s0, s12                                 // 0000001CBF3C: BE80200C
	s_cbranch_execz 64113                                      // 0000001CBF40: BFA5FA71 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b08>
	ds_load_b32 v1, v226 offset:16                             // 0000001CBF44: D8D80010 010000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBF4C: BF89FC07
	v_fma_f32 v1, v99, v1, v3                                  // 0000001CBF50: D6130001 040E0363
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBF58: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001CBF5C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v147, v[195:196]       // 0000001CBF64: D6FE7C01 070F26FF 00003000
	v_bfe_u32 v9, v3, 16, 1                                    // 0000001CBF70: D6100009 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBF78: BF870001
	v_add3_u32 v3, v3, v9, 0x7fff                              // 0000001CBF7C: D6550003 03FE1303 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001CBF88: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CBF90: 8C7E007E
	s_and_saveexec_b32 s0, s11                                 // 0000001CBF94: BE80200B
	s_cbranch_execz 64094                                      // 0000001CBF98: BFA5FA5E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b14>
	ds_load_b32 v1, v226 offset:24                             // 0000001CBF9C: D8D80018 010000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBFA4: BF89FC07
	v_fma_f32 v1, v100, v1, v4                                 // 0000001CBFA8: D6130001 04120364
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CBFB0: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001CBFB4: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v146, v[195:196]       // 0000001CBFBC: D6FE7C01 070F24FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001CBFC8: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CBFD0: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001CBFD4: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001CBFE0: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CBFE8: 8C7E007E
	s_and_saveexec_b32 s0, s10                                 // 0000001CBFEC: BE80200A
	s_cbranch_execz 64075                                      // 0000001CBFF0: BFA5FA4B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b20>
	ds_load_b32 v1, v226 offset:32                             // 0000001CBFF4: D8D80020 010000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CBFFC: BF89FC07
	v_fma_f32 v1, v101, v1, v5                                 // 0000001CC000: D6130001 04160365
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CC008: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001CC00C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v140, v[195:196]       // 0000001CC014: D6FE7C01 070F18FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001CC020: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CC028: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001CC02C: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001CC038: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CC040: 8C7E007E
	s_and_saveexec_b32 s0, s8                                  // 0000001CC044: BE802008
	s_cbranch_execz 64056                                      // 0000001CC048: BFA5FA38 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b2c>
	ds_load_b32 v1, v226 offset:40                             // 0000001CC04C: D8D80028 010000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CC054: BF89FC07
	v_fma_f32 v1, v102, v1, v6                                 // 0000001CC058: D6130001 041A0366
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CC060: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001CC064: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v139, v[195:196]       // 0000001CC06C: D6FE7C01 070F16FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001CC078: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CC080: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001CC084: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001CC090: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CC098: 8C7E007E
	s_and_saveexec_b32 s0, s9                                  // 0000001CC09C: BE802009
	s_cbranch_execz 64037                                      // 0000001CC0A0: BFA5FA25 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b38>
	ds_load_b32 v1, v226 offset:48                             // 0000001CC0A4: D8D80030 010000E2
	s_waitcnt lgkmcnt(0)                                       // 0000001CC0AC: BF89FC07
	v_fma_f32 v1, v103, v1, v7                                 // 0000001CC0B0: D6130001 041E0367
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001CC0B8: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001CC0BC: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v138, v[195:196]       // 0000001CC0C4: D6FE7C01 070F14FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001CC0D0: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001CC0D8: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001CC0DC: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001CC0E8: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001CC0F0: 8C7E007E
	s_and_saveexec_b32 s0, s1                                  // 0000001CC0F4: BE802001
	s_cbranch_execnz 64018                                     // 0000001CC0F8: BFA6FA12 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b44>
	s_branch 64035                                             // 0000001CC0FC: BFA0FA23 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b8c>
	v_dual_mov_b32 v1, s44 :: v_dual_mov_b32 v2, s45           // 0000001CC100: CA10002C 0102002D
	v_mov_b32_e32 v6, v204                                     // 0000001CC108: 7E0C03CC
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CC10C: BF870092
	.long 0xd7006a00                                           // 0000001CC110: D7006A00
	v_cndmask_b32_e32 v0, v1, v18, vcc_lo                      // 0000001CC114: 02002501
	v_add_co_ci_u32_e64 v1, null, s19, v2, vcc_lo              // 0000001CC118: D5207C01 01AA0413
	s_add_u32 s0, s46, s34                                     // 0000001CC120: 8000222E
	s_addc_u32 s1, s33, s35                                    // 0000001CC124: 82012321
	.long 0xd7006a00                                           // 0000001CC128: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000001CC12C: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001CC130: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000001CC134: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000001CC13C: BE810080
	.long 0xd7006a00                                           // 0000001CC140: D7006A00
	v_cndmask_b32_e32 v1, v0, v193, vcc_lo                     // 0000001CC144: 02038300
	v_add_co_ci_u32_e64 v1, null, v1, v194, vcc_lo             // 0000001CC148: D5207C01 01AB8501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CC150: BF870092
	.long 0xd7006a00                                           // 0000001CC154: D7006A00
	v_cndmask_b32_e32 v1, v0, v203, vcc_lo                     // 0000001CC158: 02039700
	v_add_co_ci_u32_e64 v1, null, v1, v216, vcc_lo             // 0000001CC15C: D5207C01 01ABB101
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001CC164: BF870092
	.long 0xd7006a00                                           // 0000001CC168: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000001CC16C: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000001CC170: D5207C01 01AA0211
	s_nop 0                                                    // 0000001CC178: BF800000
	s_nop 0                                                    // 0000001CC17C: BF800000
	ds_load_b32 v2, v209                                       // 0000001CC180: D8D80000 020000D1
	v_add_nc_u32_e32 v6, 0x80, v6                              // 0000001CC188: 4A0C0CFF 00000080
	v_add_nc_u32_e32 v209, 8, v209                             // 0000001CC190: 4BA3A288
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001CC194: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v6                        // 0000001CC198: 7C920CFF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001CC1A0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001CC1A4: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000001CC1A8: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000001CC1B0: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 0000001CC1B4: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000001CC1BC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001CC1C4: 917E017E
	s_cbranch_execnz 65517                                     // 0000001CC1C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb0ELi2ELi0ELi0ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7380>
	s_nop 0                                                    // 0000001CC1CC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001CC1D0: BFB60003
	s_endpgm                                                   // 0000001CC1D4: BFB00000
		...

