00000000000a1c00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000A1C00: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000A1C04: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000A1C0C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000A1C14: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000A1C18: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000A1C1C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000A1C20: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000A1C28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000A1C2C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000A1C30: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000A1C34: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000A1C3C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000A1C40: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000A1C44: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000A1C48: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1C4C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000A1C50: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000A1C54: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000A1C58: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000A1C5C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000A1C64: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000A1C6C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000A1C70: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000A1C74: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000A1C78: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000A1C7C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000A1C80: 821E191E
	.long 0xd7001f02                                           // 0000000A1C84: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000A1C88: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000A1C8C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000A1C94: BE9E0080
	s_nop 0                                                    // 0000000A1C98: BF800000
	s_nop 0                                                    // 0000000A1C9C: BF800000
	s_nop 0                                                    // 0000000A1CA0: BF800000
	s_nop 0                                                    // 0000000A1CA4: BF800000
	s_nop 0                                                    // 0000000A1CA8: BF800000
	s_nop 0                                                    // 0000000A1CAC: BF800000
	s_nop 0                                                    // 0000000A1CB0: BF800000
	s_nop 0                                                    // 0000000A1CB4: BF800000
	s_nop 0                                                    // 0000000A1CB8: BF800000
	s_nop 0                                                    // 0000000A1CBC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000A1CC0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000A1CC4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1CCC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000A1CD0: 300C1089
	.long 0xd7006a06                                           // 0000000A1CD4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000A1CD8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A1CDC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000A1CE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000A1CE8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000A1CF0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000A1CF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000A1CFC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000A1D08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000A1D0C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000A1D10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000A1D18: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000A1D1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000A1D20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000A1D24: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 0000000A1D2C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000A1D34: 32040084
	s_mov_b32 s0, 0                                            // 0000000A1D38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000A1D3C: BF89FC07
	s_barrier                                                  // 0000000A1D40: BFBD0000
	buffer_gl0_inv                                             // 0000000A1D44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000A1D4C: BF02801E
	s_cbranch_scc1 12                                          // 0000000A1D50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000A1D54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000A1D5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A1D64: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 0000000A1D68: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000A1D70: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000A1D74: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000A1D78: 916A007E
	s_cbranch_vccz 2                                           // 0000000A1D7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2200                                              // 0000000A1D80: BFA00898 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23e4>
	v_lshlrev_b32_e32 v39, 2, v5                               // 0000000A1D84: 304E0A82
	s_add_i32 s0, s30, 63                                      // 0000000A1D88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000A1D8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000A1D94: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000A1D98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000A1D9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000A1DA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 0000000A1DA4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 0000000A1DAC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000A1DB0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000A1DB4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000A1DB8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000A1DBC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000A1DC0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000A1DC4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 0000000A1DC8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000A1DD4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000A1DD8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000A1DDC: B00A0204
	.long 0xd7000b2c                                           // 0000000A1DE0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 0000000A1DE4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000A1DE8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 0000000A1DEC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 0000000A1DF4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000A1E00: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 0000000A1E04: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 0000000A1E10: 3816500A
	.long 0xd7000a05                                           // 0000000A1E14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000A1E18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A1E1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000A1E20: D5207C06 00290001
	.long 0xd7000107                                           // 0000000A1E28: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000A1E2C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A1E30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000A1E34: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000A1E3C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000A1E40: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000A1E44: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000A1E4C: 84848E02
	.long 0xd700010b                                           // 0000000A1E50: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000A1E54: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000A1E58: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000A1E5C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000A1E64: 8205050F
	.long 0xd700010d                                           // 0000000A1E68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000A1E6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A1E70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000A1E74: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000A1E7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000A1E80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000A1E88: D5207C10 00061880
	.long 0xd7000111                                           // 0000000A1E90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000A1E94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A1E9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000A1EA0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000A1EA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000A1EAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000A1EB4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000A1EBC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000A1EC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A1EC8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000A1ECC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000A1ED4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000A1ED8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000A1EE0: D5207C18 00061880
	.long 0xd7000119                                           // 0000000A1EE8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000A1EEC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A1EF4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000A1EF8: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000A1F00: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000A1F04: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 0000000A1F0C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 0000000A1F14: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000A1F18: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 0000000A1F20: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 0000000A1F24: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 0000000A1F2C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000A1F34: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 0000000A1F3C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 0000000A1F44: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 0000000A1F4C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 0000000A1F54: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 0000000A1F5C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 0000000A1F64: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 0000000A1F6C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 0000000A1F74: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 0000000A1F7C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 0000000A1F84: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 0000000A1F8C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 0000000A1F94: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 0000000A1F9C: BE850080
	s_mov_b32 s6, 4.0                                          // 0000000A1FA0: BE8600F6
	s_mov_b32 s7, 0x3e800000                                   // 0000000A1FA4: BE8700FF 3E800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000A1FAC: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000A1FB0: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000A1FB8: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000A1FBC: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000A1FC0: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A1FC4: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000A1FC8: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000A1FCC: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000A1FD0: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000A1FD4: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000A1FD8: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000A1FE0: BE84206A
	s_cbranch_execz 77                                         // 0000000A1FE4: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x51c>
	v_or_b32_e32 v29, s11, v0                                  // 0000000A1FE8: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1FEC: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000A1FF0: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000A1FF8: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A1FFC: BF870091
	.long 0xd73c001d                                           // 0000000A2000: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000A2004: 02023A82
	.long 0xd700011d                                           // 0000000A2008: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000A200C: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A2010: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000A2014: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000A201C: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A2024: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000A2028: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000A202C: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000A2038: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 0000000A203C: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 0000000A2048: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000A204C: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000A2058: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000A205C: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 0000000A2060: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000A206C: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A2070: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 0000000A2074: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 0000000A207C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000A2080: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 0000000A2088: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000A2090: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 0000000A2094: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A2098: BF870193
	v_exp_f32_e32 v32, v32                                     // 0000000A209C: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 0000000A20A0: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000000A20A4: BF870296
	.long 0xd71c0020                                           // 0000000A20A8: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000A20AC: 02024520
	.long 0xd71c001f                                           // 0000000A20B0: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000A20B4: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A20B8: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000A20BC: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000A20C4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000A20C8: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000A20D0: D5010020 00064080
	.long 0xd41e0001                                           // 0000000A20D8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000A20DC: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A20E4: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000A20E8: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000A20F4: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000A20F8: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000A2100: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 0000000A210C: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 0000000A2114: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A211C: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000A2120: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000A2128: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A212C: BF89FC07
	s_barrier                                                  // 0000000A2130: BFBD0000
	buffer_gl0_inv                                             // 0000000A2134: E0AC0000 00000000
	s_branch 15                                                // 0000000A213C: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x57c>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A2140: 8C7E047E
	.long 0xd700011d                                           // 0000000A2144: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000A2148: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A2150: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A2154: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000A215C: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000A2160: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000A2164: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000A2168: BF89FC07
	s_barrier                                                  // 0000000A216C: BFBD0000
	buffer_gl0_inv                                             // 0000000A2170: E0AC0000 00000000
	s_cbranch_scc1 703                                         // 0000000A2178: BFA202BF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000A217C: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 0000000A2184: CA100128 21220126
	s_mov_b32 s13, 0                                           // 0000000A218C: BE8D0080
	s_nop 0                                                    // 0000000A2190: BF800000
	s_nop 0                                                    // 0000000A2194: BF800000
	s_nop 0                                                    // 0000000A2198: BF800000
	s_nop 0                                                    // 0000000A219C: BF800000
	s_nop 0                                                    // 0000000A21A0: BF800000
	s_nop 0                                                    // 0000000A21A4: BF800000
	s_nop 0                                                    // 0000000A21A8: BF800000
	s_nop 0                                                    // 0000000A21AC: BF800000
	s_nop 0                                                    // 0000000A21B0: BF800000
	s_nop 0                                                    // 0000000A21B4: BF800000
	s_nop 0                                                    // 0000000A21B8: BF800000
	s_nop 0                                                    // 0000000A21BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000000A21C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000A21C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000A21D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000A21D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A21DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000A21E0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000A21E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000A21EC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000A21F4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000A21F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000000A21FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000A2204: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000A220C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000A2210: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000A2214: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000A2218: BF89FC07
	s_barrier                                                  // 0000000A221C: BFBD0000
	buffer_gl0_inv                                             // 0000000A2220: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000A2228: BE842000
	s_cbranch_execz 65476                                      // 0000000A222C: BFA5FFC4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x540>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 0000000A2230: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 0000000A2238: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 0000000A2240: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 0000000A2248: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 0000000A2250: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 0000000A2258: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 0000000A2260: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 0000000A2268: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 0000000A2270: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 0000000A2278: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 0000000A2280: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 0000000A2288: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 0000000A2290: D8DCFFEE 50000001
	v_or3_b32 v70, s12, s11, v2                                // 0000000A2298: D6580046 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A22A0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 0000000A22A4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 0000000A22AC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 0000000A22B0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A22B4: BF870091
	.long 0xd7000146                                           // 0000000A22B8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 0000000A22BC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 0000000A22C0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 0000000A22C8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 0000000A22D0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 0000000A22D4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A22DC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 0000000A22E0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 0000000A22E8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 0000000A22EC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 0000000A22F4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 0000000A22FC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 0000000A2304: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 0000000A230C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 0000000A2314: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2318: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 0000000A231C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 0000000A2324: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 0000000A232C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2330: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 0000000A2334: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 0000000A233C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 0000000A2344: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2348: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 0000000A234C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 0000000A2354: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 0000000A235C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A2360: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000A2364: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 0000000A236C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 0000000A2374: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 0000000A237C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 0000000A2384: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 0000000A238C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 0000000A2394: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 0000000A239C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000A23A4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 0000000A23AC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 0000000A23B4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A23B8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 0000000A23BC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 0000000A23C4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A23CC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 0000000A23D0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 0000000A23D8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 0000000A23E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A23E4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 0000000A23E8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 0000000A23F0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 0000000A23F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A23FC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 0000000A2400: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 0000000A2408: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 0000000A2410: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 0000000A2418: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 0000000A2420: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 0000000A2428: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 0000000A2430: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 0000000A2438: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 0000000A2440: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 0000000A2448: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 0000000A2450: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2454: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 0000000A2458: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 0000000A2460: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 0000000A2468: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A246C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000A2470: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000A2478: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000A2480: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2484: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 0000000A2488: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 0000000A2490: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 0000000A2498: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A249C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000A24A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 0000000A24A8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 0000000A24B0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 0000000A24B8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 0000000A24C0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 0000000A24C8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 0000000A24D0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000A24D8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000A24E0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 0000000A24E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000A24F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A24F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000A24F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000A2500: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000A2508: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A250C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 0000000A2510: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 0000000A2518: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 0000000A2520: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2524: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 0000000A2528: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 0000000A2530: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 0000000A2538: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A253C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 0000000A2540: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 0000000A2548: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 0000000A2550: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 0000000A2558: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 0000000A2560: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 0000000A2568: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 0000000A2570: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 0000000A2578: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 0000000A2580: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 0000000A2588: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 0000000A2590: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2594: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000A2598: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000A25A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000A25A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A25AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000A25B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000A25B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000A25C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A25C4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 0000000A25C8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 0000000A25D0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 0000000A25D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A25DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000A25E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 0000000A25E8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 0000000A25F0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 0000000A25F8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 0000000A2600: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 0000000A2608: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 0000000A2610: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 0000000A2618: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 0000000A2620: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 0000000A2628: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000A2630: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2634: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000A2638: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000A2640: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000A2648: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A264C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000A2650: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000A2658: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000A2660: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2664: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000A2668: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A2670: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A2678: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A267C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000A2680: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 0000000A2688: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 0000000A2690: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 0000000A2698: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 0000000A26A0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 0000000A26A8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 0000000A26B0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 0000000A26B8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 0000000A26C0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 0000000A26C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000A26D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A26D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000A26D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000A26E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000A26E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A26EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000A26F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000A26F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000A2700: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2704: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000A2708: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A2710: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A2718: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A271C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000A2720: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 0000000A2728: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 0000000A2730: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 0000000A2738: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 0000000A2740: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 0000000A2748: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 0000000A2750: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 0000000A2758: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 0000000A2760: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 0000000A2768: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000A2770: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2774: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000A2778: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000A2780: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000A2788: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A278C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000A2790: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000A2798: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000A27A0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A27A4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000A27A8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A27B0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A27B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A27BC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000A27C0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 0000000A27C8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 0000000A27D0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 0000000A27D8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 0000000A27E0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 0000000A27E8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 0000000A27F0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 0000000A27F8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 0000000A2800: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 0000000A2808: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000A2810: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2814: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000A2818: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000A2820: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000A2828: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A282C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000A2830: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000A2838: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000A2840: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2844: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000A2848: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A2850: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A2858: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A285C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000A2860: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 0000000A2868: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 0000000A2870: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 0000000A2878: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 0000000A2880: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 0000000A2888: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 0000000A2890: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 0000000A2898: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000A28A0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 0000000A28A8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000A28B0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A28B4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000A28B8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000A28C0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000A28C8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A28CC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000A28D0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000A28D8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000A28E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A28E4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000A28E8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A28F0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A28F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A28FC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000A2900: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 0000000A2908: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 0000000A2910: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 0000000A2918: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 0000000A2920: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 0000000A2928: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 0000000A2930: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 0000000A2938: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 0000000A2940: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 0000000A2948: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000A2950: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2954: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000A2958: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000A2960: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000A2968: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A296C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000A2970: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000A2978: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000A2980: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2984: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000A2988: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A2990: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A2998: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A299C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000A29A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 0000000A29A8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 0000000A29B0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 0000000A29B8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 0000000A29C0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 0000000A29C8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 0000000A29D0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 0000000A29D8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 0000000A29E0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 0000000A29E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000A29F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A29F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000A29F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000A2A00: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000A2A08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2A0C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000A2A10: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000A2A18: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000A2A20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2A24: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000A2A28: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A2A30: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A2A38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A2A3C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000A2A40: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 0000000A2A48: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 0000000A2A50: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 0000000A2A58: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 0000000A2A60: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 0000000A2A68: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 0000000A2A70: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 0000000A2A78: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 0000000A2A80: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 0000000A2A88: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000A2A90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2A94: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000A2A98: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000A2AA0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000A2AA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2AAC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000A2AB0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000A2AB8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000A2AC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2AC4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000A2AC8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A2AD0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A2AD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A2ADC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000A2AE0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 0000000A2AE8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 0000000A2AF0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 0000000A2AF8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 0000000A2B00: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 0000000A2B08: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 0000000A2B10: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 0000000A2B18: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 0000000A2B20: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 0000000A2B28: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000A2B30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2B34: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000A2B38: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000A2B40: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000A2B48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2B4C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000A2B50: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000A2B58: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000A2B60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2B64: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000A2B68: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A2B70: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A2B78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A2B7C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000A2B80: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 0000000A2B88: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 0000000A2B90: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 0000000A2B98: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 0000000A2BA0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 0000000A2BA8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 0000000A2BB0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 0000000A2BB8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 0000000A2BC0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 0000000A2BC8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000A2BD0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2BD4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000A2BD8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000A2BE0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000A2BE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2BEC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000A2BF0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000A2BF8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000A2C00: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2C04: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 0000000A2C08: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000A2C10: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000A2C18: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2C1C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 0000000A2C20: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 0000000A2C28: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 0000000A2C30: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2C34: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 0000000A2C38: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 0000000A2C40: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 0000000A2C48: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A2C4C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 0000000A2C50: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s12, v[4:5]            // 0000000A2C58: D6FE7C1F 041018FF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 0000000A2C64: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 0000000A2C6C: D8340000 0000201F
	s_branch 64818                                             // 0000000A2C74: BFA0FD32 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x540>
	v_mov_b32_e32 v30, v14                                     // 0000000A2C78: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000A2C7C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000A2C84: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 0000000A2C88: 7E46032B
	s_mov_b32 s12, 0                                           // 0000000A2C8C: BE8C0080
	s_branch 21                                                // 0000000A2C90: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000A2C94: 8C7E0D7E
	.long 0xd700011f                                           // 0000000A2C98: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000A2C9C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A2CA4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000A2CA8: D5207C20 00064080
	.long 0xd700011d                                           // 0000000A2CB0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000A2CB4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 0000000A2CBC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A2CC0: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000A2CC8: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000A2CCC: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000A2CD0: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000A2CD4: BC7C0000
	s_barrier                                                  // 0000000A2CD8: BFBD0000
	buffer_gl0_inv                                             // 0000000A2CDC: E0AC0000 00000000
	s_cbranch_scc1 198                                         // 0000000A2CE4: BFA200C6 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1400>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A2CE8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000A2CEC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 0000000A2CF4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 0000000A2CF8: 7E780326
	s_mov_b32 s13, 0                                           // 0000000A2CFC: BE8D0080
	global_load_b32 v61, v[33:34], off                         // 0000000A2D00: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 0000000A2D08: 4A7878FF 00000080
	.long 0xd7000121                                           // 0000000A2D10: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000A2D14: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A2D1C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000A2D20: D5207C22 00064480
	.long 0xd4490004                                           // 0000000A2D28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 0000000A2D2C: 020278FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000A2D34: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000A2D38: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 0000000A2D3C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 0000000A2D44: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000A2D4C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000A2D50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000A2D54: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000A2D58: BF89FC07
	s_barrier                                                  // 0000000A2D5C: BFBD0000
	buffer_gl0_inv                                             // 0000000A2D60: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000A2D68: BE8D2000
	s_cbranch_execz 65481                                      // 0000000A2D6C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s12, v2                                  // 0000000A2D70: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2D74: BF870091
	v_or_b32_e32 v36, s11, v33                                 // 0000000A2D78: 3848420B
	.long 0xd4440001                                           // 0000000A2D7C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 0000000A2D80: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000A2D84: 8B7E017E
	s_cbranch_execz 65474                                      // 0000000A2D88: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_mov_b32_e32 v60, 0                                       // 0000000A2D8C: 7E780280
	s_mov_b32 s1, 0                                            // 0000000A2D90: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000A2D94: BF870009
	v_lshl_add_u32 v34, s1, 2, v46                             // 0000000A2D98: D6460022 04B90401
	s_add_i32 s4, s1, 8                                        // 0000000A2DA0: 81048801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000A2DA4: B6810078
	ds_load_2addr_b32 v[70:71], v34 offset1:1                  // 0000000A2DA8: D8DC0100 46000022
	ds_load_2addr_b32 v[72:73], v34 offset0:2 offset1:3        // 0000000A2DB0: D8DC0302 48000022
	ds_load_2addr_b32 v[74:75], v34 offset0:4 offset1:5        // 0000000A2DB8: D8DC0504 4A000022
	ds_load_2addr_b32 v[76:77], v34 offset0:6 offset1:7        // 0000000A2DC0: D8DC0706 4C000022
	v_mad_u64_u32 v[61:62], null, 0x44, s1, v[1:2]             // 0000000A2DC8: D6FE7C3D 040402FF 00000044
	s_mov_b32 s1, s4                                           // 0000000A2DD4: BE810004
	ds_load_2addr_b32 v[62:63], v61 offset1:17                 // 0000000A2DD8: D8DC1100 3E00003D
	ds_load_2addr_b32 v[64:65], v61 offset0:34 offset1:51      // 0000000A2DE0: D8DC3322 4000003D
	ds_load_2addr_b32 v[66:67], v61 offset0:68 offset1:85      // 0000000A2DE8: D8DC5544 4200003D
	ds_load_2addr_b32 v[68:69], v61 offset0:102 offset1:119    // 0000000A2DF0: D8DC7766 4400003D
	s_waitcnt lgkmcnt(7)                                       // 0000000A2DF8: BF89FC77
	v_fma_mixlo_f16 v61, v70, s6, 0                            // 0000000A2DFC: CC21003D 02000D46
	s_waitcnt lgkmcnt(6)                                       // 0000000A2E04: BF89FC67
	v_fma_mixlo_f16 v70, v72, s6, 0                            // 0000000A2E08: CC210046 02000D48
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A2E10: BF870002
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2E14: CC20003D 8A000F3D
	s_waitcnt lgkmcnt(3)                                       // 0000000A2E1C: BF89FC37
	v_fma_mixlo_f16 v34, v62, s6, 0                            // 0000000A2E20: CC210022 02000D3E
	v_fma_mixlo_f16 v62, v63, s6, 0                            // 0000000A2E28: CC21003E 02000D3F
	v_fma_mixlo_f16 v63, v71, s6, 0                            // 0000000A2E30: CC21003F 02000D47
	s_waitcnt lgkmcnt(2)                                       // 0000000A2E38: BF89FC27
	v_fma_mixlo_f16 v64, v64, s6, 0                            // 0000000A2E3C: CC210040 02000D40
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2E44: CC200022 8A000F22
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2E4C: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2E54: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000A2E5C: BF870214
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2E60: CC200040 8A000F40
	v_fmac_f32_e32 v60, v61, v34                               // 0000000A2E68: 5678453D
	v_fma_mixlo_f16 v34, v65, s6, 0                            // 0000000A2E6C: CC210022 02000D41
	v_fma_mixlo_f16 v61, v73, s6, 0                            // 0000000A2E74: CC21003D 02000D49
	v_fma_mix_f32 v65, v70, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2E7C: CC200041 8A000F46
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A2E84: BF870004
	v_fmac_f32_e32 v60, v63, v62                               // 0000000A2E88: 56787D3F
	s_waitcnt lgkmcnt(1)                                       // 0000000A2E8C: BF89FC17
	v_fma_mixlo_f16 v62, v66, s6, 0                            // 0000000A2E90: CC21003E 02000D42
	v_fma_mixlo_f16 v63, v74, s6, 0                            // 0000000A2E98: CC21003F 02000D4A
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2EA0: CC200022 8A000F22
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2EA8: CC20003D 8A000F3D
	v_fmac_f32_e32 v60, v65, v64                               // 0000000A2EB0: 56788141
	v_fma_mixlo_f16 v64, v67, s6, 0                            // 0000000A2EB4: CC210040 02000D43
	v_fma_mixlo_f16 v65, v75, s6, 0                            // 0000000A2EBC: CC210041 02000D4B
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2EC4: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2ECC: CC20003F 8A000F3F
	v_fmac_f32_e32 v60, v61, v34                               // 0000000A2ED4: 5678453D
	s_waitcnt lgkmcnt(0)                                       // 0000000A2ED8: BF89FC07
	v_fma_mixlo_f16 v34, v68, s6, 0                            // 0000000A2EDC: CC210022 02000D44
	v_fma_mixlo_f16 v61, v76, s6, 0                            // 0000000A2EE4: CC21003D 02000D4C
	v_fma_mix_f32 v64, v64, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2EEC: CC200040 8A000F40
	v_fma_mix_f32 v65, v65, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2EF4: CC200041 8A000F41
	v_fmac_f32_e32 v60, v63, v62                               // 0000000A2EFC: 56787D3F
	v_fma_mixlo_f16 v62, v69, s6, 0                            // 0000000A2F00: CC21003E 02000D45
	v_fma_mixlo_f16 v63, v77, s6, 0                            // 0000000A2F08: CC21003F 02000D4D
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2F10: CC200022 8A000F22
	v_fma_mix_f32 v61, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2F18: CC20003D 8A000F3D
	v_fmac_f32_e32 v60, v65, v64                               // 0000000A2F20: 56788141
	v_fma_mix_f32 v62, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2F24: CC20003E 8A000F3E
	v_fma_mix_f32 v63, v63, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000A2F2C: CC20003F 8A000F3F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A2F34: BF870093
	v_fmac_f32_e32 v60, v61, v34                               // 0000000A2F38: 5678453D
	v_fmac_f32_e32 v60, v63, v62                               // 0000000A2F3C: 56787D3F
	s_cbranch_scc1 65428                                       // 0000000A2F40: BFA2FF94 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1194>
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000A2F44: 30424282
	v_mov_b32_e32 v61, v1                                      // 0000000A2F48: 7E7A0301
	s_mov_b32 s14, 0                                           // 0000000A2F4C: BE8E0080
	ds_load_b32 v62, v33 offset:17440                          // 0000000A2F50: D8D84420 3E000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000A2F58: CA10011E 2220011D
	s_waitcnt lgkmcnt(0)                                       // 0000000A2F60: BF89FC07
	v_mul_f32_e32 v60, v60, v62                                // 0000000A2F64: 10787D3C
	v_mov_b32_e32 v62, v35                                     // 0000000A2F68: 7E7C0323
	s_nop 0                                                    // 0000000A2F6C: BF800000
	s_nop 0                                                    // 0000000A2F70: BF800000
	s_nop 0                                                    // 0000000A2F74: BF800000
	s_nop 0                                                    // 0000000A2F78: BF800000
	s_nop 0                                                    // 0000000A2F7C: BF800000
	global_load_b32 v63, v[33:34], off                         // 0000000A2F80: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 0000000A2F88: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 0000000A2F90: 4A7C7CC1
	.long 0xd7000121                                           // 0000000A2F94: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000A2F98: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000A2F9C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000A2FA0: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000A2FA8: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 0000000A2FAC: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 0000000A2FB0: 4A7A7AFF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000A2FB8: 8C0E0E04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A2FBC: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 0000000A2FC0: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000A2FC4: 917E0E7E
	s_cbranch_execnz 65517                                     // 0000000A2FC8: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1380>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000A2FCC: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A2FD0: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 0000000A2FD4: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 0000000A2FDC: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 0000000A2FE8: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 0000000A2FF4: DC960000 007C2421
	s_branch 65317                                             // 0000000A2FFC: BFA0FF25 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000A3000: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 0000000A3008: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000A300C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000A3010: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000A3018: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000A301C: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000A3024: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000A302C: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000A3030: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000A3034: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000A303C: A0010401
	s_mov_b32 s4, 0                                            // 0000000A3040: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000A3044: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000A3048: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000A304C: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000A3050: BF870585
	.long 0xd71c001d                                           // 0000000A3054: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000A3058: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000A305C: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000A3060: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000A3068: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000A306C: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000A3074: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000000A3078: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000A307C: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000A3088: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000A3090: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A3098: BF870001
	.long 0xd4490001                                           // 0000000A309C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000A30A0: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000A30A8: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000A30AC: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000A30B0: 1040411E
	ds_store_b32 v29, v32                                      // 0000000A30B4: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000A30BC: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A30C4: 917E047E
	s_cbranch_execnz 65519                                     // 0000000A30C8: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1488>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A30CC: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000A30D0: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 0000000A30D8: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 0000000A30E0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A30E4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A30E8: BF89FC07
	s_barrier                                                  // 0000000A30EC: BFBD0000
	buffer_gl0_inv                                             // 0000000A30F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000A30F8: BF800000
	s_nop 0                                                    // 0000000A30FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A3100: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 0000000A3108: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A3110: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A3118: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A311C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000A3124: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A3128: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A3130: BF870004
	.long 0xd4490004                                           // 0000000A3134: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A3138: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A3140: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A3144: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A3148: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 0000000A314C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000A3154: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A315C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A3160: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1500>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A3164: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000A3168: BF89FC07
	s_barrier                                                  // 0000000A316C: BFBD0000
	buffer_gl0_inv                                             // 0000000A3170: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000000A3178: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 0000000A3180: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 0000000A3188: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 0000000A3190: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000A3198: 7E780300
	s_mov_b32 s4, 0                                            // 0000000A319C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A31A0: BF840001
	s_nop 0                                                    // 0000000A31A4: BF800000
	s_nop 0                                                    // 0000000A31A8: BF800000
	s_nop 0                                                    // 0000000A31AC: BF800000
	s_nop 0                                                    // 0000000A31B0: BF800000
	s_nop 0                                                    // 0000000A31B4: BF800000
	s_nop 0                                                    // 0000000A31B8: BF800000
	s_nop 0                                                    // 0000000A31BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A31C0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000A31C4: 327A7884
	.long 0xd4490001                                           // 0000000A31C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A31CC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000A31D4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000A31D8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A31E4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000A31E8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000A31F0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000A31F8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000A3200: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000A3208: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000A3210: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000A3218: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000A3220: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000A3224: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A3230: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000A3234: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000A3238: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000A3240: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000A3244: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000A3248: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000A324C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3250: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000A3254: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000A3258: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000A325C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3260: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000A3264: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000A3270: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000A3278: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A3280: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A3284: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_set_inst_prefetch_distance 0x2                           // 0000000A3288: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A328C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 0000000A3290: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A3298: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A32A0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A32A4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A32A8: BF89FC07
	s_barrier                                                  // 0000000A32AC: BFBD0000
	buffer_gl0_inv                                             // 0000000A32B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000A32B8: BF800000
	s_nop 0                                                    // 0000000A32BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A32C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 0000000A32C8: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A32D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A32D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A32DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A32E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A32E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A32F0: BF870004
	.long 0xd4490004                                           // 0000000A32F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A32F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A3300: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A3304: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A3308: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A330C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A3314: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A331C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A3320: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16c0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A3324: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000A3328: BF89FC07
	s_barrier                                                  // 0000000A332C: BFBD0000
	buffer_gl0_inv                                             // 0000000A3330: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000A3338: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000000A3340: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000000A3348: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000000A3350: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000000A3358: 7E780300
	s_mov_b32 s4, 0                                            // 0000000A335C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A3360: BF840001
	s_nop 0                                                    // 0000000A3364: BF800000
	s_nop 0                                                    // 0000000A3368: BF800000
	s_nop 0                                                    // 0000000A336C: BF800000
	s_nop 0                                                    // 0000000A3370: BF800000
	s_nop 0                                                    // 0000000A3374: BF800000
	s_nop 0                                                    // 0000000A3378: BF800000
	s_nop 0                                                    // 0000000A337C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A3380: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000A3384: 327A7884
	.long 0xd4490001                                           // 0000000A3388: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A338C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000A3394: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000A3398: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A33A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000A33A8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000A33B0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000A33B8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000A33C0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000A33C8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000A33D0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000A33D8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000A33E0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000A33E4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A33F0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000A33F4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000A33F8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000A3400: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000A3404: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000A3408: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000A340C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3410: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000A3414: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000A3418: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000A341C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3420: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000A3424: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000A3430: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000A3438: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A3440: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A3444: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1780>
	s_set_inst_prefetch_distance 0x2                           // 0000000A3448: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A344C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000000A3450: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A3458: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A3460: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A3464: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A3468: BF89FC07
	s_barrier                                                  // 0000000A346C: BFBD0000
	buffer_gl0_inv                                             // 0000000A3470: E0AC0000 00000000
	s_nop 0                                                    // 0000000A3478: BF800000
	s_nop 0                                                    // 0000000A347C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A3480: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 0000000A3488: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A3490: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A3498: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A349C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A34A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A34A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A34B0: BF870004
	.long 0xd4490004                                           // 0000000A34B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A34B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A34C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A34C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A34C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A34CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A34D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A34DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A34E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1880>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A34E4: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000A34E8: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000A34F0: BF89FC07
	s_barrier                                                  // 0000000A34F4: BFBD0000
	buffer_gl0_inv                                             // 0000000A34F8: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000A3500: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 0000000A3504: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 0000000A350C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 0000000A3514: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 0000000A351C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000A3524: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A3528: BF840001
	s_nop 0                                                    // 0000000A352C: BF800000
	s_nop 0                                                    // 0000000A3530: BF800000
	s_nop 0                                                    // 0000000A3534: BF800000
	s_nop 0                                                    // 0000000A3538: BF800000
	s_nop 0                                                    // 0000000A353C: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000A3540: 327C7A84
	.long 0xd4490001                                           // 0000000A3544: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000A3548: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A3550: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000A3554: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000A3558: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A3564: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000A3568: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000A3570: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000A3578: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000A3580: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000A3588: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000A3590: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000A3598: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000A35A0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000A35A4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A35A8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000A35AC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000A35B8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000A35C0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000A35C4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000A35C8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000A35CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A35D0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000A35D4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000A35D8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000A35DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A35E0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000A35E4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000A35F0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000A35F8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A3600: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A3604: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_set_inst_prefetch_distance 0x2                           // 0000000A3608: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A360C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000A3610: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A3618: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A3620: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A3624: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A3628: BF89FC07
	s_barrier                                                  // 0000000A362C: BFBD0000
	buffer_gl0_inv                                             // 0000000A3630: E0AC0000 00000000
	s_nop 0                                                    // 0000000A3638: BF800000
	s_nop 0                                                    // 0000000A363C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A3640: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 0000000A3648: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A3650: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A3658: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A365C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A3664: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A3668: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A3670: BF870004
	.long 0xd4490004                                           // 0000000A3674: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A3678: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A3680: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A3684: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A3688: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A368C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A3694: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A369C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A36A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A36A4: 8C7E0A7E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 0000000A36A8: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 0000000A36B0: BF89FC07
	s_barrier                                                  // 0000000A36B4: BFBD0000
	buffer_gl0_inv                                             // 0000000A36B8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 0000000A36C0: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 0000000A36C8: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 0000000A36D0: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 0000000A36D8: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000A36E0: 7E780300
	s_mov_b32 s4, 0                                            // 0000000A36E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A36E8: BF840001
	s_nop 0                                                    // 0000000A36EC: BF800000
	s_nop 0                                                    // 0000000A36F0: BF800000
	s_nop 0                                                    // 0000000A36F4: BF800000
	s_nop 0                                                    // 0000000A36F8: BF800000
	s_nop 0                                                    // 0000000A36FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A3700: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000A3704: 327A7884
	.long 0xd4490001                                           // 0000000A3708: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A370C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000A3714: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000A3718: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A3724: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000A3728: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000A3730: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000A3738: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000A3740: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000A3748: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000A3750: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000A3758: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000A3760: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000A3764: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A3770: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000A3774: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000A3778: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000A3780: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000A3784: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000A3788: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000A378C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3790: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000A3794: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000A3798: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000A379C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A37A0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000A37A4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000A37B0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000A37B8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A37C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A37C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_set_inst_prefetch_distance 0x2                           // 0000000A37C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A37CC: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 0000000A37D0: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A37D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A37E0: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A37E4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A37E8: BF89FC07
	s_barrier                                                  // 0000000A37EC: BFBD0000
	buffer_gl0_inv                                             // 0000000A37F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000A37F8: BF800000
	s_nop 0                                                    // 0000000A37FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A3800: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 0000000A3808: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A3810: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A3818: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A381C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A3824: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A3828: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A3830: BF870004
	.long 0xd4490004                                           // 0000000A3834: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A3838: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A3840: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A3844: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A3848: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A384C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A3854: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A385C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A3860: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A3864: 8C7E0A7E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 0000000A3868: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 0000000A3870: BF89FC07
	s_barrier                                                  // 0000000A3874: BFBD0000
	buffer_gl0_inv                                             // 0000000A3878: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 0000000A3880: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 0000000A3884: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 0000000A388C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 0000000A3894: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 0000000A389C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 0000000A38A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A38A8: BF840001
	s_nop 0                                                    // 0000000A38AC: BF800000
	s_nop 0                                                    // 0000000A38B0: BF800000
	s_nop 0                                                    // 0000000A38B4: BF800000
	s_nop 0                                                    // 0000000A38B8: BF800000
	s_nop 0                                                    // 0000000A38BC: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 0000000A38C0: 327C7884
	.long 0xd4490001                                           // 0000000A38C4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A38C8: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A38D0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000A38D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000A38D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A38E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000A38E8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000A38F0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000A38F8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000A3900: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000A3908: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000A3910: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000A3918: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000A3920: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000A3924: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A3928: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000A392C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000A3938: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000A3940: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000A3944: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000A3948: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000A394C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3950: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000A3954: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000A3958: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000A395C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3960: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 0000000A3964: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 0000000A3970: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000A3974: BF870002
	v_mov_b32_e32 v60, v63                                     // 0000000A3978: 7E78033F
	ds_store_b32 v62, v70                                      // 0000000A397C: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A3984: 917E047E
	s_cbranch_execnz 65485                                     // 0000000A3988: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_set_inst_prefetch_distance 0x2                           // 0000000A398C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A3990: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 0000000A3994: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A399C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A39A4: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A39A8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A39AC: BF89FC07
	s_barrier                                                  // 0000000A39B0: BFBD0000
	buffer_gl0_inv                                             // 0000000A39B4: E0AC0000 00000000
	s_nop 0                                                    // 0000000A39BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A39C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 0000000A39C8: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A39D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A39D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A39DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A39E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A39E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A39F0: BF870004
	.long 0xd4490004                                           // 0000000A39F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A39F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A3A00: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A3A04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A3A08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A3A0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A3A14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A3A1C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A3A20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A3A24: 8C7E0A7E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 0000000A3A28: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000A3A30: BF89FC07
	s_barrier                                                  // 0000000A3A34: BFBD0000
	buffer_gl0_inv                                             // 0000000A3A38: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 0000000A3A40: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 0000000A3A48: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 0000000A3A50: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 0000000A3A58: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000A3A60: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000A3A64: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A3A68: BF840001
	s_nop 0                                                    // 0000000A3A6C: BF800000
	s_nop 0                                                    // 0000000A3A70: BF800000
	s_nop 0                                                    // 0000000A3A74: BF800000
	s_nop 0                                                    // 0000000A3A78: BF800000
	s_nop 0                                                    // 0000000A3A7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A3A80: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000A3A84: 327C7A84
	.long 0xd4490001                                           // 0000000A3A88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000A3A8C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000A3A94: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000A3A98: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A3AA4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000A3AA8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000A3AB0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000A3AB8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000A3AC0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000A3AC8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000A3AD0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000A3AD8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000A3AE0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000A3AE4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A3AE8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000A3AEC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000A3AF8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000A3B00: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000A3B04: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000A3B08: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000A3B0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3B10: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000A3B14: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000A3B18: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000A3B1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3B20: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000A3B24: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000A3B30: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000A3B38: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A3B40: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A3B44: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e80>
	s_set_inst_prefetch_distance 0x2                           // 0000000A3B48: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A3B4C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 0000000A3B50: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A3B58: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A3B60: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A3B64: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A3B68: BF89FC07
	s_barrier                                                  // 0000000A3B6C: BFBD0000
	buffer_gl0_inv                                             // 0000000A3B70: E0AC0000 00000000
	s_nop 0                                                    // 0000000A3B78: BF800000
	s_nop 0                                                    // 0000000A3B7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A3B80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 0000000A3B88: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A3B90: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A3B98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A3B9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A3BA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A3BA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A3BB0: BF870004
	.long 0xd4490004                                           // 0000000A3BB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A3BB8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A3BC0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A3BC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A3BC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A3BCC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A3BD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A3BDC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A3BE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A3BE4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000A3BE8: BF89FC07
	s_barrier                                                  // 0000000A3BEC: BFBD0000
	buffer_gl0_inv                                             // 0000000A3BF0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 0000000A3BF8: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 0000000A3C00: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 0000000A3C08: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 0000000A3C10: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 0000000A3C18: 7E7A0300
	s_mov_b32 s4, 0                                            // 0000000A3C1C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A3C20: BF840001
	s_nop 0                                                    // 0000000A3C24: BF800000
	s_nop 0                                                    // 0000000A3C28: BF800000
	s_nop 0                                                    // 0000000A3C2C: BF800000
	s_nop 0                                                    // 0000000A3C30: BF800000
	s_nop 0                                                    // 0000000A3C34: BF800000
	s_nop 0                                                    // 0000000A3C38: BF800000
	s_nop 0                                                    // 0000000A3C3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A3C40: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000000A3C44: 327C7A84
	.long 0xd4490001                                           // 0000000A3C48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000000A3C4C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000000A3C54: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000000A3C58: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A3C64: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000000A3C68: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 0000000A3C70: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 0000000A3C78: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 0000000A3C80: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000000A3C88: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 0000000A3C90: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 0000000A3C98: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 0000000A3CA0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 0000000A3CA4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A3CA8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 0000000A3CAC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 0000000A3CB8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 0000000A3CC0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 0000000A3CC4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 0000000A3CC8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 0000000A3CCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3CD0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 0000000A3CD4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 0000000A3CD8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 0000000A3CDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3CE0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000A3CE4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000A3CF0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000A3CF8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A3D00: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A3D04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_set_inst_prefetch_distance 0x2                           // 0000000A3D08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A3D0C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 0000000A3D10: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000A3D18: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000A3D20: 7E420326
	s_mov_b32 s10, 0                                           // 0000000A3D24: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000A3D28: BF89FC07
	s_barrier                                                  // 0000000A3D2C: BFBD0000
	buffer_gl0_inv                                             // 0000000A3D30: E0AC0000 00000000
	s_nop 0                                                    // 0000000A3D38: BF800000
	s_nop 0                                                    // 0000000A3D3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000A3D40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000000A3D48: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000A3D50: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000A3D58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000A3D5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000A3D64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000A3D68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000A3D70: BF870004
	.long 0xd4490004                                           // 0000000A3D74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000A3D78: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000A3D80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000A3D84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000A3D88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000A3D8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000A3D94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000A3D9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000A3DA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2140>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000A3DA4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 0000000A3DA8: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 0000000A3DB0: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000A3DB8: BF89FC07
	s_barrier                                                  // 0000000A3DBC: BFBD0000
	buffer_gl0_inv                                             // 0000000A3DC0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 0000000A3DC8: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 0000000A3DD0: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000A3DD8: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 0000000A3DE0: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000A3DE8: 7E780300
	s_mov_b32 s4, 0                                            // 0000000A3DEC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000A3DF0: BF840001
	s_nop 0                                                    // 0000000A3DF4: BF800000
	s_nop 0                                                    // 0000000A3DF8: BF800000
	s_nop 0                                                    // 0000000A3DFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000A3E00: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000A3E04: 327A7884
	.long 0xd4490001                                           // 0000000A3E08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000A3E0C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000A3E14: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000A3E18: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000A3E24: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000A3E28: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000A3E30: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000A3E38: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000A3E40: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000A3E48: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000A3E50: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000A3E58: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000A3E60: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000A3E64: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000A3E70: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000A3E74: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000A3E78: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000A3E80: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000A3E84: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000A3E88: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000A3E8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3E90: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000A3E94: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000A3E98: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000A3E9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A3EA0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000A3EA4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000A3EB0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000A3EB8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000A3EC0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000A3EC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2200>
	s_set_inst_prefetch_distance 0x2                           // 0000000A3EC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000A3ECC: 8C7E047E
	.long 0xd7000107                                           // 0000000A3ED0: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000A3ED4: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A3EDC: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000A3EE0: D5207C08 00061080
	.long 0xd7000109                                           // 0000000A3EE8: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000A3EEC: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000A3EF4: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000A3EFC: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000A3F00: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A3F08: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000A3F0C: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000A3F14: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000A3F18: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000A3F20: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000A3F28: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000A3F2C: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A3F34: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000A3F38: D5207C10 00062080
	.long 0xd7000111                                           // 0000000A3F40: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000A3F44: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000A3F4C: D5207C12 00062480
	.long 0xd7000113                                           // 0000000A3F54: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000A3F58: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A3F60: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000A3F64: D5207C14 00062880
	.long 0xd7000115                                           // 0000000A3F6C: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000A3F70: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000A3F78: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000A3F80: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000A3F84: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000A3F8C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000A3F90: D5207C18 00063080
	.long 0xd7000119                                           // 0000000A3F98: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000A3F9C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000A3FA4: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000A3FAC: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000A3FB0: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000A3FB8: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000A3FBC: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000A3FC4: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000A3FC8: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000A3FCC: BF062105
	s_barrier                                                  // 0000000A3FD0: BFBD0000
	buffer_gl0_inv                                             // 0000000A3FD4: E0AC0000 00000000
	s_cbranch_scc0 63476                                       // 0000000A3FDC: BFA1F7F4 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3b0>
	v_mov_b32_e32 v4, v38                                      // 0000000A3FE0: 7E080326
	s_add_u32 s0, s28, s20                                     // 0000000A3FE4: 8000141C
	.long 0xd73c0000                                           // 0000000A3FE8: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000A3FEC: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000A3FF0: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000A3FF4: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000A3FF8: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000A3FFC: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000A4000: 82010103
	.long 0xd7006a00                                           // 0000000A4004: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000A4008: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000A400C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000A4010: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000A4018: BE810080
	.long 0xd7006a00                                           // 0000000A401C: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 0000000A4020: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000A4024: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000A402C: BF870092
	.long 0xd7006a00                                           // 0000000A4030: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000A4034: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000A4038: D5207C01 01AA0211
	ds_load_b32 v2, v37                                        // 0000000A4040: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000A4048: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000000A4050: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000A4058: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000A405C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000A4064: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000A4068: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000A406C: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000A4074: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000A4078: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000A4080: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000A4088: 917E017E
	s_cbranch_execnz 65516                                     // 0000000A408C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi10ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2440>
	s_endpgm                                                   // 0000000A4090: BFB00000
		...

