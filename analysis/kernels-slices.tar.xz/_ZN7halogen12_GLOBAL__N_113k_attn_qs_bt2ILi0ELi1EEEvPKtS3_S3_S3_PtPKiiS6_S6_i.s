00000000001b7300 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i>:
; _ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i():
	s_clause 0x1                                               // 0000001B7300: BF850001
	s_load_b128 s[12:15], s[0:1], 0x20                         // 0000001B7304: F4080300 F8000020
	s_load_b128 s[16:19], s[0:1], 0x38                         // 0000001B730C: F4080400 F8000038
	s_mov_b32 s20, s3                                          // 0000001B7314: BE940003
	s_ashr_i32 s3, s2, 31                                      // 0000001B7318: 86039F02
	s_load_b32 s21, s[0:1], 0x48                               // 0000001B731C: F4000540 F8000048
	s_waitcnt lgkmcnt(0)                                       // 0000001B7324: BF89FC07
	s_load_b32 s14, s[14:15], null                             // 0000001B7328: F4000387 F8000000
	s_load_b256 s[4:11], s[0:1], null                          // 0000001B7330: F40C0100 F8000000
	s_lshl_b64 s[0:1], s[2:3], 2                               // 0000001B7338: 84808202
	s_waitcnt lgkmcnt(0)                                       // 0000001B733C: BF89FC07
	s_add_i32 s14, s14, s2                                     // 0000001B7340: 810E020E
	s_add_u32 s0, s18, s0                                      // 0000001B7344: 80000012
	s_addc_u32 s1, s19, s1                                     // 0000001B7348: 82010113
	s_add_i32 s15, s14, 1                                      // 0000001B734C: 810F810E
	s_load_b32 s3, s[0:1], null                                // 0000001B7350: F40000C0 F8000000
	s_ashr_i32 s0, s15, 31                                     // 0000001B7358: 86009F0F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001B735C: BF870499
	s_lshr_b32 s0, s0, 30                                      // 0000001B7360: 85009E00
	s_add_i32 s0, s15, s0                                      // 0000001B7364: 8100000F
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B7368: BF870009
	s_and_b32 s1, s0, -4                                       // 0000001B736C: 8B01C400
	s_ashr_i32 s18, s0, 2                                      // 0000001B7370: 86128200
	s_sub_i32 s15, s14, s1                                     // 0000001B7374: 818F010E
	s_mul_hi_i32 s1, s21, s2                                   // 0000001B7378: 97010215
	s_cmp_gt_i32 s15, -1                                       // 0000001B737C: BF02C10F
	s_mul_i32 s0, s21, s2                                      // 0000001B7380: 96000215
	s_cselect_b32 s14, -1, 0                                   // 0000001B7384: 980E80C1
	s_mov_b32 s19, s18                                         // 0000001B7388: BE930012
	s_and_b32 vcc_lo, exec_lo, s14                             // 0000001B738C: 8B6A0E7E
	s_cbranch_vccnz 15                                         // 0000001B7390: BFA4000F <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0xd0>
	s_lshl_b64 s[22:23], s[0:1], 2                             // 0000001B7394: 84968200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(SALU_CYCLE_1)// 0000001B7398: BF8704D9
	s_add_u32 s19, s16, s22                                    // 0000001B739C: 80131610
	s_addc_u32 s21, s17, s23                                   // 0000001B73A0: 82151711
	s_waitcnt lgkmcnt(0)                                       // 0000001B73A4: BF89FC07
	s_max_i32 s22, s3, 1                                       // 0000001B73A8: 8A168103
	s_mov_b32 s23, 0                                           // 0000001B73AC: BE970080
	s_lshl_b64 s[22:23], s[22:23], 2                           // 0000001B73B0: 84968216
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B73B4: BF870009
	s_add_u32 s19, s19, s22                                    // 0000001B73B8: 80131613
	s_addc_u32 s21, s21, s23                                   // 0000001B73BC: 82151715
	s_add_u32 s22, s19, -4                                     // 0000001B73C0: 8016C413
	s_addc_u32 s23, s21, -1                                    // 0000001B73C4: 8217C115
	s_load_b32 s19, s[22:23], null                             // 0000001B73C8: F40004CB F8000000
	v_cndmask_b32_e64 v1, 0, 1, s14                            // 0000001B73D0: D5010001 00390280
	s_mov_b32 s23, exec_lo                                     // 0000001B73D8: BE97007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001B73DC: BF8704B1
	v_readfirstlane_b32 s14, v1                                // 0000001B73E0: 7E1C0501
	s_waitcnt lgkmcnt(0)                                       // 0000001B73E4: BF89FC07
	s_add_i32 s21, s3, s14                                     // 0000001B73E8: 81150E03
	s_add_i32 s14, s21, 3                                      // 0000001B73EC: 810E8315
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001B73F0: BF870499
	s_and_b32 s22, s14, -4                                     // 0000001B73F4: 8B16C40E
	.long 0xd4c4007e                                           // 0000001B73F8: D4C4007E
	v_cndmask_b32_e32 v1, s22, v0, vcc_lo                      // 0000001B73FC: 02020016
	s_cbranch_execz 45                                         // 0000001B7400: BFA5002D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	v_dual_mov_b32 v4, v0 :: v_dual_lshlrev_b32 v3, 2, v0      // 0000001B7404: CA220100 04020082
	s_lshl_b64 s[0:1], s[0:1], 2                               // 0000001B740C: 84808200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001B7410: BF8700A9
	s_add_u32 s0, s16, s0                                      // 0000001B7414: 80000010
	s_addc_u32 s1, s17, s1                                     // 0000001B7418: 82010111
	.long 0xd7000001                                           // 0000001B741C: D7000001
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000001B7420: 02020600
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B7424: BF870001
	v_add_co_ci_u32_e64 v2, null, s1, 0, s0                    // 0000001B7428: D5207C02 00010001
	s_mov_b32 s1, 0                                            // 0000001B7430: BE810080
	s_set_inst_prefetch_distance 0x1                           // 0000001B7434: BF840001
	s_branch 18                                                // 0000001B7438: BFA00012 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x184>
	s_nop 0                                                    // 0000001B743C: BF800000
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001B7440: 8C7E007E
	v_add_nc_u32_e32 v4, 64, v4                                // 0000001B7444: 4A0808C0
	.long 0xd7000001                                           // 0000001B7448: D7000001
	v_cndmask_b32_e32 v1, 0x100, v1, vcc_lo                    // 0000001B744C: 020202FF 00000100
	s_waitcnt vmcnt(0)                                         // 0000001B7454: BF8903F7
	ds_store_b32 v3, v5 offset:1024                            // 0000001B7458: D8340400 00000503
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001B7460: D5207C02 00020480
	v_cmp_le_i32_e32 vcc_lo, s22, v4                           // 0000001B7468: 7C860816
	v_add_nc_u32_e32 v3, 0x100, v3                             // 0000001B746C: 4A0606FF 00000100
	s_or_b32 s1, vcc_lo, s1                                    // 0000001B7474: 8C01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B7478: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001B747C: 917E017E
	s_cbranch_execz 13                                         // 0000001B7480: BFA5000D <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x1b8>
	s_mov_b32 s0, exec_lo                                      // 0000001B7484: BE80007E
	.long 0xd4c3007e                                           // 0000001B7488: D4C3007E
	v_cndmask_b32_e32 v1, s3, v4, vcc_lo                       // 0000001B748C: 02020803
	s_xor_b32 s0, exec_lo, s0                                  // 0000001B7490: 8D00007E
	v_mov_b32_e32 v5, s18                                      // 0000001B7494: 7E0A0212
	v_cmp_gt_i32_e32 vcc_lo, s21, v4                           // 0000001B7498: 7C880815
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001B749C: BF870002
	v_cndmask_b32_e32 v5, s19, v5, vcc_lo                      // 0000001B74A0: 020A0A13
	s_and_not1_saveexec_b32 s0, s0                             // 0000001B74A4: BE803000
	s_cbranch_execz 65509                                      // 0000001B74A8: BFA5FFE5 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	global_load_b32 v5, v[1:2], off                            // 0000001B74AC: DC520000 057C0001
	s_branch 65506                                             // 0000001B74B4: BFA0FFE2 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x140>
	s_set_inst_prefetch_distance 0x2                           // 0000001B74B8: BF840002
	s_or_b32 exec_lo, exec_lo, s23                             // 0000001B74BC: 8C7E177E
	v_lshrrev_b32_e32 v7, 5, v0                                // 0000001B74C0: 320E0085
	s_mov_b32 s1, exec_lo                                      // 0000001B74C4: BE81007E
	v_cmpx_gt_u32_e32 0x180, v0                                // 0000001B74C8: 7D9800FF 00000180
	s_cbranch_execz 48                                         // 0000001B74D0: BFA50030 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x294>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001B74D4: BF870002
	v_mul_u32_u24_e32 v1, 0x210, v7                            // 0000001B74D8: 16020EFF 00000210
	v_and_b32_e32 v2, 31, v0                                   // 0000001B74E0: 3604009F
	s_mul_i32 s16, s20, 0xc00                                  // 0000001B74E4: 9610FF14 00000C00
	s_mul_i32 s18, s2, 0x3000                                  // 0000001B74EC: 9612FF02 00003000
	s_ashr_i32 s17, s16, 31                                    // 0000001B74F4: 86119F10
	s_mul_hi_i32 s0, s2, 0x3000                                // 0000001B74F8: 9700FF02 00003000
	s_lshl_b64 s[16:17], s[16:17], 1                           // 0000001B7500: 84908110
	v_lshl_add_u32 v4, v2, 4, v1                               // 0000001B7504: D6460004 04050902
	v_lshlrev_b32_e32 v1, 4, v0                                // 0000001B750C: 30020084
	s_add_u32 s4, s4, s16                                      // 0000001B7510: 80041004
	s_addc_u32 s5, s5, s17                                     // 0000001B7514: 82051105
	s_add_u32 s4, s4, s18                                      // 0000001B7518: 80041204
	s_addc_u32 s0, s5, s0                                      // 0000001B751C: 82000005
	.long 0xd7000401                                           // 0000001B7520: D7000401
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 0000001B7524: 02020204
	v_lshl_or_b32 v3, v0, 3, 0xfffffe00                        // 0000001B7528: D6560003 03FD0700 FFFFFE00
	v_add_co_ci_u32_e64 v2, null, s0, 0, s4                    // 0000001B7534: D5207C02 00110000
	s_mov_b32 s4, 0                                            // 0000001B753C: BE840080
	global_load_b128 v[8:11], v[1:2], off                      // 0000001B7540: DC5E0000 087C0001
	v_add_nc_u32_e32 v3, 0x200, v3                             // 0000001B7548: 4A0606FF 00000200
	.long 0xd7006a01                                           // 0000001B7550: D7006A01
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001B7554: 020202FF 00000400
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B755C: BF870191
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 0000001B7560: D5207C02 01AA0480
	.long 0xd4490000                                           // 0000001B7568: D4490000
	v_cndmask_b32_e32 v1, 0x9ff, v3, vcc_lo                    // 0000001B756C: 020206FF 000009FF
	s_or_b32 s4, s0, s4                                        // 0000001B7574: 8C040400
	s_waitcnt vmcnt(0)                                         // 0000001B7578: BF8903F7
	ds_store_b128 v4, v[8:11] offset:9232                      // 0000001B757C: DB7C2410 00000804
	v_add_nc_u32_e32 v4, 0x420, v4                             // 0000001B7584: 4A0808FF 00000420
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001B758C: 917E047E
	s_cbranch_execnz 65515                                     // 0000001B7590: BFA6FFEB <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x240>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001B7594: 8C7E017E
	v_lshlrev_b32_e32 v210, 7, v7                              // 0000001B7598: 31A40E87
	s_ashr_i32 s14, s14, 2                                     // 0000001B759C: 860E820E
	s_mov_b32 s0, 0                                            // 0000001B75A0: BE800080
	s_cmp_gt_i32 s14, 0                                        // 0000001B75A4: BF02800E
	s_waitcnt lgkmcnt(0)                                       // 0000001B75A8: BF89FC07
	s_barrier                                                  // 0000001B75AC: BFBD0000
	buffer_gl0_inv                                             // 0000001B75B0: E0AC0000 00000000
	s_cbranch_scc1 2                                           // 0000001B75B8: BFA20002 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x2c4>
	v_lshlrev_b32_e32 v8, 7, v7                                // 0000001B75BC: 30100E87
	s_branch 1                                                 // 0000001B75C0: BFA00001 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x2c8>
	s_mov_b32 s0, -1                                           // 0000001B75C4: BE8000C1
	v_mov_b32_e32 v38, 0                                       // 0000001B75C8: 7E4C0280
	v_and_b32_e32 v208, 15, v0                                 // 0000001B75CC: 37A0008F
	v_bfe_u32 v209, v0, 4, 1                                   // 0000001B75D0: D61000D1 02050900
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000001B75D8: 916A007E
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B75DC: BF870003
	v_mov_b32_e32 v37, v38                                     // 0000001B75E0: 7E4A0326
	v_mov_b32_e32 v36, v38                                     // 0000001B75E4: 7E480326
	v_mov_b32_e32 v35, v38                                     // 0000001B75E8: 7E460326
	v_mov_b32_e32 v34, v38                                     // 0000001B75EC: 7E440326
	v_mov_b32_e32 v33, v38                                     // 0000001B75F0: 7E420326
	v_mov_b32_e32 v46, v38                                     // 0000001B75F4: 7E5C0326
	v_mov_b32_e32 v45, v38                                     // 0000001B75F8: 7E5A0326
	v_mov_b32_e32 v44, v38                                     // 0000001B75FC: 7E580326
	v_mov_b32_e32 v43, v38                                     // 0000001B7600: 7E560326
	v_mov_b32_e32 v42, v38                                     // 0000001B7604: 7E540326
	v_mov_b32_e32 v41, v38                                     // 0000001B7608: 7E520326
	v_mov_b32_e32 v54, v38                                     // 0000001B760C: 7E6C0326
	v_mov_b32_e32 v53, v38                                     // 0000001B7610: 7E6A0326
	v_mov_b32_e32 v52, v38                                     // 0000001B7614: 7E680326
	v_mov_b32_e32 v51, v38                                     // 0000001B7618: 7E660326
	v_mov_b32_e32 v50, v38                                     // 0000001B761C: 7E640326
	v_mov_b32_e32 v49, v38                                     // 0000001B7620: 7E620326
	v_mov_b32_e32 v62, v38                                     // 0000001B7624: 7E7C0326
	v_mov_b32_e32 v61, v38                                     // 0000001B7628: 7E7A0326
	v_mov_b32_e32 v60, v38                                     // 0000001B762C: 7E780326
	v_mov_b32_e32 v59, v38                                     // 0000001B7630: 7E760326
	v_mov_b32_e32 v58, v38                                     // 0000001B7634: 7E740326
	v_mov_b32_e32 v57, v38                                     // 0000001B7638: 7E720326
	v_mov_b32_e32 v30, v38                                     // 0000001B763C: 7E3C0326
	v_mov_b32_e32 v29, v38                                     // 0000001B7640: 7E3A0326
	v_mov_b32_e32 v28, v38                                     // 0000001B7644: 7E380326
	v_mov_b32_e32 v27, v38                                     // 0000001B7648: 7E360326
	v_mov_b32_e32 v26, v38                                     // 0000001B764C: 7E340326
	v_mov_b32_e32 v25, v38                                     // 0000001B7650: 7E320326
	v_mov_b32_e32 v22, v38                                     // 0000001B7654: 7E2C0326
	v_mov_b32_e32 v21, v38                                     // 0000001B7658: 7E2A0326
	v_mov_b32_e32 v20, v38                                     // 0000001B765C: 7E280326
	v_mov_b32_e32 v19, v38                                     // 0000001B7660: 7E260326
	v_mov_b32_e32 v18, v38                                     // 0000001B7664: 7E240326
	v_mov_b32_e32 v17, v38                                     // 0000001B7668: 7E220326
	v_mov_b32_e32 v14, v38                                     // 0000001B766C: 7E1C0326
	v_mov_b32_e32 v13, v38                                     // 0000001B7670: 7E1A0326
	v_mov_b32_e32 v12, v38                                     // 0000001B7674: 7E180326
	v_mov_b32_e32 v11, v38                                     // 0000001B7678: 7E160326
	v_mov_b32_e32 v10, v38                                     // 0000001B767C: 7E140326
	v_mov_b32_e32 v9, v38                                      // 0000001B7680: 7E120326
	v_mov_b32_e32 v6, v38                                      // 0000001B7684: 7E0C0326
	v_mov_b32_e32 v5, v38                                      // 0000001B7688: 7E0A0326
	v_mov_b32_e32 v4, v38                                      // 0000001B768C: 7E080326
	v_mov_b32_e32 v3, v38                                      // 0000001B7690: 7E060326
	v_mov_b32_e32 v2, v38                                      // 0000001B7694: 7E040326
	v_mov_b32_e32 v1, v38                                      // 0000001B7698: 7E020326
	v_mov_b32_e32 v211, v38                                    // 0000001B769C: 7FA60326
	v_mov_b32_e32 v206, v38                                    // 0000001B76A0: 7F9C0326
	v_mov_b32_e32 v212, v38                                    // 0000001B76A4: 7FA80326
	v_mov_b32_e32 v207, v38                                    // 0000001B76A8: 7F9E0326
	v_mov_b32_e32 v213, v38                                    // 0000001B76AC: 7FAA0326
	v_mov_b32_e32 v205, v38                                    // 0000001B76B0: 7F9A0326
	s_cbranch_vccnz 1209                                       // 0000001B76B4: BFA404B9 <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x169c>
	v_cmp_gt_u32_e32 vcc_lo, 12, v208                          // 0000001B76B8: 7C99A08C
	s_ashr_i32 s21, s20, 31                                    // 0000001B76BC: 86159F14
	s_lshl2_add_u32 s3, s3, s15                                // 0000001B76C0: 87830F03
	v_dual_mov_b32 v65, 0 :: v_dual_lshlrev_b32 v4, 9, v7      // 0000001B76C4: CA220080 41040E89
	v_lshlrev_b32_e32 v3, 10, v7                               // 0000001B76CC: 30060E8A
	s_lshl_b64 s[0:1], s[20:21], 11                            // 0000001B76D0: 84808B14
	s_add_i32 s15, s3, 1                                       // 0000001B76D4: 810F8103
	s_add_u32 s0, s6, s0                                       // 0000001B76D8: 80000006
	v_cndmask_b32_e32 v2, 0, v208, vcc_lo                      // 0000001B76DC: 0205A080
	s_addc_u32 s1, s7, s1                                      // 0000001B76E0: 82010107
	v_mov_b32_e32 v66, v65                                     // 0000001B76E4: 7E840341
	.long 0xd7000005                                           // 0000001B76E8: D7000005
	v_cndmask_b32_e32 v1, s0, v3, vcc_lo                       // 0000001B76EC: 02020600
	v_dual_mov_b32 v205, 0 :: v_dual_lshlrev_b32 v0, 5, v0     // 0000001B76F0: CA220080 CD000085
	v_add_co_ci_u32_e64 v6, null, s1, 0, s0                    // 0000001B76F8: D5207C06 00010001
	s_movk_i32 s0, 0x210                                       // 0000001B7700: B0000210
	v_dual_mov_b32 v67, v65 :: v_dual_and_b32 v0, 0x60, v0     // 0000001B7704: CA240141 430000FF 00000060
	v_mad_u32_u24 v2, v2, s0, 0x2410                           // 0000001B7710: D60B0002 03FC0102 00002410
	s_lshl_b64 s[0:1], s[20:21], 8                             // 0000001B771C: 84808814
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B7720: BF870199
	v_dual_mov_b32 v220, s1 :: v_dual_lshlrev_b32 v1, 2, v208  // 0000001B7724: CA220001 DC01A082
	.long 0xd7006a00                                           // 0000001B772C: D7006A00
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 0000001B7730: 02020105
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B7734: BF870191
	v_add_co_ci_u32_e64 v214, null, 0, v6, vcc_lo              // 0000001B7738: D5207CD6 01AA0C80
	v_lshl_or_b32 v1, v209, 6, v1                              // 0000001B7740: D6560001 04050DD1
	v_xor_b32_e32 v5, 1, v7                                    // 0000001B7748: 3A0A0E81
	v_dual_mov_b32 v223, 0xf149f2ca :: v_dual_lshlrev_b32 v6, 5, v209// 0000001B774C: CA2200FF DF07A285 F149F2CA
	v_dual_mov_b32 v69, v65 :: v_dual_lshlrev_b32 v8, 1, v208  // 0000001B7758: CA220141 4509A081
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B7760: BF8701A4
	v_add_nc_u32_e32 v1, 0x3cd0, v1                            // 0000001B7764: 4A0202FF 00003CD0
	v_dual_mov_b32 v68, v65 :: v_dual_lshlrev_b32 v7, 8, v7    // 0000001B776C: CA220141 44060E88
	v_or3_b32 v217, v4, v6, v8                                 // 0000001B7774: D65800D9 04220D04
	v_lshl_or_b32 v218, v208, 5, v4                            // 0000001B777C: D65600DA 04110BD0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B7784: BF870004
	v_dual_mov_b32 v224, 0xf149f2ca :: v_dual_add_nc_u32 v215, v1, v3// 0000001B7788: CA2000FF E0D60701 F149F2CA
	v_lshl_add_u32 v216, v5, 10, v1                            // 0000001B7794: D64600D8 04051505
	v_or3_b32 v219, s0, v208, v210                             // 0000001B779C: D65800DB 074BA000
	v_dual_mov_b32 v70, v65 :: v_dual_and_b32 v221, 12, v208   // 0000001B77A4: CA240141 46DDA08C
	v_dual_mov_b32 v71, v65 :: v_dual_add_nc_u32 v222, v2, v7  // 0000001B77AC: CA200141 47DE0F02
	v_dual_mov_b32 v72, v65 :: v_dual_mov_b32 v225, 0xf149f2ca // 0000001B77B4: CA100141 48E000FF F149F2CA
	v_dual_mov_b32 v227, 0xf149f2ca :: v_dual_mov_b32 v228, 0xf149f2ca// 0000001B77C0: CA1000FF E3E400FF F149F2CA
	v_dual_mov_b32 v229, 0xf149f2ca :: v_dual_mov_b32 v230, 0xf149f2ca// 0000001B77CC: CA1000FF E5E600FF F149F2CA
	v_dual_mov_b32 v231, 0xf149f2ca :: v_dual_mov_b32 v212, 0  // 0000001B77D8: CA1000FF E7D40080 F149F2CA
	v_dual_mov_b32 v213, 0 :: v_dual_mov_b32 v206, 0           // 0000001B77E4: CA100080 D5CE0080
	v_dual_mov_b32 v207, 0 :: v_dual_mov_b32 v226, 0           // 0000001B77EC: CA100080 CFE20080
	v_dual_mov_b32 v211, 0 :: v_dual_mov_b32 v236, 0           // 0000001B77F4: CA100080 D3EC0080
	v_dual_mov_b32 v1, 0 :: v_dual_mov_b32 v2, v205            // 0000001B77FC: CA100080 010201CD
	v_mov_b32_e32 v3, v205                                     // 0000001B7804: 7E0603CD
	v_dual_mov_b32 v4, v205 :: v_dual_mov_b32 v9, 0            // 0000001B7808: CA1001CD 04080080
	v_mov_b32_e32 v5, v205                                     // 0000001B7810: 7E0A03CD
	v_dual_mov_b32 v6, v205 :: v_dual_mov_b32 v17, 0           // 0000001B7814: CA1001CD 06100080
	v_mov_b32_e32 v7, v205                                     // 0000001B781C: 7E0E03CD
	v_dual_mov_b32 v8, v205 :: v_dual_mov_b32 v25, 0           // 0000001B7820: CA1001CD 08180080
	v_dual_mov_b32 v10, v205 :: v_dual_mov_b32 v57, 0          // 0000001B7828: CA1001CD 0A380080
	v_mov_b32_e32 v11, v205                                    // 0000001B7830: 7E1603CD
	v_dual_mov_b32 v12, v205 :: v_dual_mov_b32 v49, 0          // 0000001B7834: CA1001CD 0C300080
	v_mov_b32_e32 v13, v205                                    // 0000001B783C: 7E1A03CD
	v_dual_mov_b32 v14, v205 :: v_dual_mov_b32 v41, 0          // 0000001B7840: CA1001CD 0E280080
	v_mov_b32_e32 v15, v205                                    // 0000001B7848: 7E1E03CD
	v_dual_mov_b32 v16, v205 :: v_dual_mov_b32 v33, 0          // 0000001B784C: CA1001CD 10200080
	v_mov_b32_e32 v18, v205                                    // 0000001B7854: 7E2403CD
	v_mov_b32_e32 v19, v205                                    // 0000001B7858: 7E2603CD
	v_mov_b32_e32 v20, v205                                    // 0000001B785C: 7E2803CD
	v_mov_b32_e32 v21, v205                                    // 0000001B7860: 7E2A03CD
	v_mov_b32_e32 v22, v205                                    // 0000001B7864: 7E2C03CD
	v_mov_b32_e32 v23, v205                                    // 0000001B7868: 7E2E03CD
	v_mov_b32_e32 v24, v205                                    // 0000001B786C: 7E3003CD
	v_mov_b32_e32 v26, v205                                    // 0000001B7870: 7E3403CD
	v_mov_b32_e32 v27, v205                                    // 0000001B7874: 7E3603CD
	v_mov_b32_e32 v28, v205                                    // 0000001B7878: 7E3803CD
	v_mov_b32_e32 v29, v205                                    // 0000001B787C: 7E3A03CD
	v_mov_b32_e32 v30, v205                                    // 0000001B7880: 7E3C03CD
	v_mov_b32_e32 v31, v205                                    // 0000001B7884: 7E3E03CD
	v_mov_b32_e32 v32, v205                                    // 0000001B7888: 7E4003CD
	v_mov_b32_e32 v58, v205                                    // 0000001B788C: 7E7403CD
	v_mov_b32_e32 v59, v205                                    // 0000001B7890: 7E7603CD
	v_mov_b32_e32 v60, v205                                    // 0000001B7894: 7E7803CD
	v_mov_b32_e32 v61, v205                                    // 0000001B7898: 7E7A03CD
	v_mov_b32_e32 v62, v205                                    // 0000001B789C: 7E7C03CD
	v_mov_b32_e32 v63, v205                                    // 0000001B78A0: 7E7E03CD
	v_mov_b32_e32 v64, v205                                    // 0000001B78A4: 7E8003CD
	v_mov_b32_e32 v50, v205                                    // 0000001B78A8: 7E6403CD
	v_mov_b32_e32 v51, v205                                    // 0000001B78AC: 7E6603CD
	v_mov_b32_e32 v52, v205                                    // 0000001B78B0: 7E6803CD
	v_mov_b32_e32 v53, v205                                    // 0000001B78B4: 7E6A03CD
	v_mov_b32_e32 v54, v205                                    // 0000001B78B8: 7E6C03CD
	v_mov_b32_e32 v55, v205                                    // 0000001B78BC: 7E6E03CD
	v_mov_b32_e32 v56, v205                                    // 0000001B78C0: 7E7003CD
	v_mov_b32_e32 v42, v205                                    // 0000001B78C4: 7E5403CD
	v_mov_b32_e32 v43, v205                                    // 0000001B78C8: 7E5603CD
	v_mov_b32_e32 v44, v205                                    // 0000001B78CC: 7E5803CD
	v_mov_b32_e32 v45, v205                                    // 0000001B78D0: 7E5A03CD
	v_mov_b32_e32 v46, v205                                    // 0000001B78D4: 7E5C03CD
	v_mov_b32_e32 v47, v205                                    // 0000001B78D8: 7E5E03CD
	v_mov_b32_e32 v48, v205                                    // 0000001B78DC: 7E6003CD
	v_mov_b32_e32 v34, v205                                    // 0000001B78E0: 7E4403CD
	v_mov_b32_e32 v35, v205                                    // 0000001B78E4: 7E4603CD
	v_mov_b32_e32 v36, v205                                    // 0000001B78E8: 7E4803CD
	v_mov_b32_e32 v37, v205                                    // 0000001B78EC: 7E4A03CD
	v_mov_b32_e32 v38, v205                                    // 0000001B78F0: 7E4C03CD
	v_mov_b32_e32 v39, v205                                    // 0000001B78F4: 7E4E03CD
	v_mov_b32_e32 v40, v205                                    // 0000001B78F8: 7E5003CD
	.long 0xd59c40ed                                           // 0000001B78FC: D59C40ED
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 0000001B7900: 02010080
	s_mov_b32 s16, 0                                           // 0000001B7904: BE900080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001B7908: BF870009
	v_dual_mov_b32 v138, s16 :: v_dual_add_nc_u32 v137, s16, v221// 0000001B790C: CA200010 8A89BA10
	ds_load_b128 v[73:76], v222                                // 0000001B7914: DBFC0000 490000DE
	ds_load_b128 v[77:80], v222 offset:16                      // 0000001B791C: DBFC0010 4D0000DE
	ds_load_b128 v[81:84], v222 offset:32                      // 0000001B7924: DBFC0020 510000DE
	ds_load_b128 v[85:88], v222 offset:48                      // 0000001B792C: DBFC0030 550000DE
	ds_load_b128 v[93:96], v222 offset:80                      // 0000001B7934: DBFC0050 5D0000DE
	ds_load_b128 v[89:92], v222 offset:64                      // 0000001B793C: DBFC0040 590000DE
	ds_load_b128 v[101:104], v222 offset:112                   // 0000001B7944: DBFC0070 650000DE
	ds_load_b128 v[97:100], v222 offset:96                     // 0000001B794C: DBFC0060 610000DE
	ds_load_b128 v[109:112], v222 offset:144                   // 0000001B7954: DBFC0090 6D0000DE
	ds_load_b128 v[105:108], v222 offset:128                   // 0000001B795C: DBFC0080 690000DE
	ds_load_b128 v[117:120], v222 offset:176                   // 0000001B7964: DBFC00B0 750000DE
	ds_load_b128 v[113:116], v222 offset:160                   // 0000001B796C: DBFC00A0 710000DE
	ds_load_b128 v[125:128], v222 offset:208                   // 0000001B7974: DBFC00D0 7D0000DE
	ds_load_b128 v[121:124], v222 offset:192                   // 0000001B797C: DBFC00C0 790000DE
	ds_load_b128 v[133:136], v222 offset:240                   // 0000001B7984: DBFC00F0 850000DE
	ds_load_b128 v[129:132], v222 offset:224                   // 0000001B798C: DBFC00E0 810000DE
	ds_load_b32 v137, v137 offset:1024                         // 0000001B7994: D8D80400 89000089
	ds_load_b128 v[240:243], v138 offset:1024                  // 0000001B799C: DBFC0400 F000008A
	v_dual_mov_b32 v232, v236 :: v_dual_mov_b32 v233, v211     // 0000001B79A4: CA1001EC E8E801D3
	v_dual_mov_b32 v234, v212 :: v_dual_mov_b32 v235, v213     // 0000001B79AC: CA1001D4 EAEA01D5
	.long 0xd59c48ee                                           // 0000001B79B4: D59C48EE
	v_cndmask_b32_e32 v0, v237, v128, vcc_lo                   // 0000001B79B8: 020101ED
	.long 0xd59c48fc                                           // 0000001B79BC: D59C48FC
	v_cndmask_b32_e32 v0, v237, v128, vcc_lo                   // 0000001B79C0: 020101ED
	.long 0xd59c48fd                                           // 0000001B79C4: D59C48FD
	v_cndmask_b32_e32 v0, v237, v128, vcc_lo                   // 0000001B79C8: 020101ED
	.long 0xd59c48ef                                           // 0000001B79CC: D59C48EF
	v_cndmask_b32_e32 v0, v237, v128, vcc_lo                   // 0000001B79D0: 020101ED
	s_add_i32 s14, s14, -1                                     // 0000001B79D4: 810EC10E
	s_add_i32 s16, s16, 16                                     // 0000001B79D8: 81109010
	s_waitcnt lgkmcnt(1)                                       // 0000001B79DC: BF89FC17
	v_ashrrev_i32_e32 v138, 31, v137                           // 0000001B79E0: 3515129F
	s_waitcnt lgkmcnt(0)                                       // 0000001B79E4: BF89FC07
	v_ashrrev_i32_e32 v202, 31, v240                           // 0000001B79E8: 3595E09F
	v_mov_b32_e32 v201, v240                                   // 0000001B79EC: 7F9203F0
	v_ashrrev_i32_e32 v204, 31, v241                           // 0000001B79F0: 3599E29F
	v_mov_b32_e32 v203, v241                                   // 0000001B79F4: 7F9603F1
	.long 0xd73c0089                                           // 0000001B79F8: D73C0089
	v_cndmask_b32_e32 v1, 12, v137, vcc_lo                     // 0000001B79FC: 0203128C
	v_ashrrev_i32_e32 v212, 31, v242                           // 0000001B7A00: 35A9E49F
	v_mov_b32_e32 v211, v242                                   // 0000001B7A04: 7FA603F2
	.long 0xd73c00c9                                           // 0000001B7A08: D73C00C9
	v_cndmask_b32_e32 v1, 9, v201, vcc_lo                      // 0000001B7A0C: 02039289
	v_ashrrev_i32_e32 v244, 31, v243                           // 0000001B7A10: 35E9E69F
	.long 0xd73c00cb                                           // 0000001B7A14: D73C00CB
	v_cndmask_b32_e32 v1, 9, v203, vcc_lo                      // 0000001B7A18: 02039689
	.long 0xd7006ac1                                           // 0000001B7A1C: D7006AC1
	v_cndmask_b32_e32 v1, v0, v137, vcc_lo                     // 0000001B7A20: 02031300
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B7A24: BF870001
	v_add_co_ci_u32_e64 v194, null, v214, v138, vcc_lo         // 0000001B7A28: D5207CC2 01AB15D6
	.long 0xd73c00d3                                           // 0000001B7A30: D73C00D3
	v_cndmask_b32_e32 v1, 9, v211, vcc_lo                      // 0000001B7A34: 0203A689
	.long 0xd73c00f0                                           // 0000001B7A38: D73C00F0
	v_cndmask_b32_e32 v1, 9, v243, vcc_lo                      // 0000001B7A3C: 0203E689
	s_clause 0xf                                               // 0000001B7A40: BF85000F
	global_load_b128 v[141:144], v[193:194], off offset:16     // 0000001B7A44: DC5E0010 8D7C00C1
	global_load_b128 v[137:140], v[193:194], off               // 0000001B7A4C: DC5E0000 897C00C1
	global_load_b128 v[149:152], v[193:194], off offset:144    // 0000001B7A54: DC5E0090 957C00C1
	global_load_b128 v[145:148], v[193:194], off offset:128    // 0000001B7A5C: DC5E0080 917C00C1
	global_load_b128 v[157:160], v[193:194], off offset:272    // 0000001B7A64: DC5E0110 9D7C00C1
	global_load_b128 v[153:156], v[193:194], off offset:256    // 0000001B7A6C: DC5E0100 997C00C1
	global_load_b128 v[165:168], v[193:194], off offset:400    // 0000001B7A74: DC5E0190 A57C00C1
	global_load_b128 v[161:164], v[193:194], off offset:384    // 0000001B7A7C: DC5E0180 A17C00C1
	global_load_b128 v[173:176], v[193:194], off offset:528    // 0000001B7A84: DC5E0210 AD7C00C1
	global_load_b128 v[169:172], v[193:194], off offset:512    // 0000001B7A8C: DC5E0200 A97C00C1
	global_load_b128 v[181:184], v[193:194], off offset:656    // 0000001B7A94: DC5E0290 B57C00C1
	global_load_b128 v[177:180], v[193:194], off offset:640    // 0000001B7A9C: DC5E0280 B17C00C1
	global_load_b128 v[189:192], v[193:194], off offset:784    // 0000001B7AA4: DC5E0310 BD7C00C1
	global_load_b128 v[185:188], v[193:194], off offset:768    // 0000001B7AAC: DC5E0300 B97C00C1
	global_load_b128 v[197:200], v[193:194], off offset:912    // 0000001B7AB4: DC5E0390 C57C00C1
	global_load_b128 v[193:196], v[193:194], off offset:896    // 0000001B7ABC: DC5E0380 C17C00C1
	.long 0xd7006ac9                                           // 0000001B7AC4: D7006AC9
	v_cndmask_b32_e32 v1, v201, v219, vcc_lo                   // 0000001B7AC8: 0203B7C9
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001B7ACC: BF8700A1
	v_add_co_ci_u32_e64 v202, null, v202, v220, vcc_lo         // 0000001B7AD0: D5207CCA 01ABB9CA
	.long 0xd7006acb                                           // 0000001B7AD8: D7006ACB
	v_cndmask_b32_e32 v1, v203, v219, vcc_lo                   // 0000001B7ADC: 0203B7CB
	v_add_co_ci_u32_e64 v204, null, v204, v220, vcc_lo         // 0000001B7AE0: D5207CCC 01ABB9CC
	.long 0xd7006ad3                                           // 0000001B7AE8: D7006AD3
	v_cndmask_b32_e32 v1, v211, v219, vcc_lo                   // 0000001B7AEC: 0203B7D3
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B7AF0: BF870001
	v_add_co_ci_u32_e64 v212, null, v212, v220, vcc_lo         // 0000001B7AF4: D5207CD4 01ABB9D4
	.long 0xd7006af0                                           // 0000001B7AFC: D7006AF0
	v_cndmask_b32_e32 v1, v240, v219, vcc_lo                   // 0000001B7B00: 0203B7F0
	.long 0xd73c00c9                                           // 0000001B7B04: D73C00C9
	v_cndmask_b32_e32 v1, 3, v201, vcc_lo                      // 0000001B7B08: 02039283
	v_add_co_ci_u32_e64 v241, null, v241, v220, vcc_lo         // 0000001B7B0C: D5207CF1 01ABB9F1
	.long 0xd73c00cb                                           // 0000001B7B14: D73C00CB
	v_cndmask_b32_e32 v1, 3, v203, vcc_lo                      // 0000001B7B18: 02039683
	.long 0xd73c00d3                                           // 0000001B7B1C: D73C00D3
	v_cndmask_b32_e32 v1, 3, v211, vcc_lo                      // 0000001B7B20: 0203A683
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001B7B24: BF8700A3
	.long 0xd73c00f0                                           // 0000001B7B28: D73C00F0
	v_cndmask_b32_e32 v1, 3, v240, vcc_lo                      // 0000001B7B2C: 0203E083
	.long 0xd7006af8                                           // 0000001B7B30: D7006AF8
	v_cndmask_b32_e32 v1, s8, v201, vcc_lo                     // 0000001B7B34: 02039208
	v_add_co_ci_u32_e64 v249, null, s9, v202, vcc_lo           // 0000001B7B38: D5207CF9 01AB9409
	.long 0xd7006afa                                           // 0000001B7B40: D7006AFA
	v_cndmask_b32_e32 v1, s8, v203, vcc_lo                     // 0000001B7B44: 02039608
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001B7B48: BF8700A1
	v_add_co_ci_u32_e64 v251, null, s9, v204, vcc_lo           // 0000001B7B4C: D5207CFB 01AB9809
	.long 0xd7006acb                                           // 0000001B7B54: D7006ACB
	v_cndmask_b32_e32 v1, s8, v211, vcc_lo                     // 0000001B7B58: 0203A608
	v_add_co_ci_u32_e64 v204, null, s9, v212, vcc_lo           // 0000001B7B5C: D5207CCC 01ABA809
	.long 0xd7006ac9                                           // 0000001B7B64: D7006AC9
	v_cndmask_b32_e32 v1, s8, v240, vcc_lo                     // 0000001B7B68: 0203E008
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B7B6C: BF870001
	v_add_co_ci_u32_e64 v202, null, s9, v241, vcc_lo           // 0000001B7B70: D5207CCA 01ABE209
	v_cmp_gt_i32_e32 vcc_lo, s15, v208                         // 0000001B7B78: 7C89A00F
	s_add_i32 s15, s15, -16                                    // 0000001B7B7C: 810FD00F
	s_cmp_lg_u32 s14, 0                                        // 0000001B7B80: BF07800E
	s_waitcnt vmcnt(14)                                        // 0000001B7B84: BF893BF7
	v_wmma_f32_16x16x16_bf16 v[240:247], v[73:80], v[137:144], v[65:72]// 0000001B7B88: CC4140F0 1D071349
	s_waitcnt vmcnt(12)                                        // 0000001B7B90: BF8933F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001B7B94: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[240:247], v[81:88], v[145:152], v[240:247]// 0000001B7B98: CC4140F0 1FC32351
	s_waitcnt vmcnt(10)                                        // 0000001B7BA0: BF892BF7
	v_wmma_f32_16x16x16_bf16 v[240:247], v[89:96], v[153:160], v[240:247]// 0000001B7BA4: CC4140F0 1FC33359
	s_waitcnt vmcnt(8)                                         // 0000001B7BAC: BF8923F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001B7BB0: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[240:247], v[97:104], v[161:168], v[240:247]// 0000001B7BB4: CC4140F0 1FC34361
	s_waitcnt vmcnt(6)                                         // 0000001B7BBC: BF891BF7
	v_wmma_f32_16x16x16_bf16 v[240:247], v[105:112], v[169:176], v[240:247]// 0000001B7BC0: CC4140F0 1FC35369
	s_waitcnt vmcnt(4)                                         // 0000001B7BC8: BF8913F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001B7BCC: BF8700A1
	v_wmma_f32_16x16x16_bf16 v[240:247], v[113:120], v[177:184], v[240:247]// 0000001B7BD0: CC4140F0 1FC36371
	s_waitcnt vmcnt(2)                                         // 0000001B7BD8: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[240:247], v[121:128], v[185:192], v[240:247]// 0000001B7BDC: CC4140F0 1FC37379
	s_waitcnt vmcnt(0)                                         // 0000001B7BE4: BF8903F7
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B7BE8: BF870001
	v_wmma_f32_16x16x16_bf16 v[240:247], v[129:136], v[193:200], v[240:247]// 0000001B7BEC: CC4140F0 1FC38381
	ds_store_2addr_b32 v215, v240, v241 offset1:32             // 0000001B7BF4: D8382000 00F1F0D7
	ds_store_2addr_b32 v215, v242, v243 offset0:64 offset1:96  // 0000001B7BFC: D8386040 00F3F2D7
	ds_store_2addr_b32 v215, v244, v245 offset0:128 offset1:160// 0000001B7C04: D838A080 00F5F4D7
	ds_store_2addr_b32 v215, v246, v247 offset0:192 offset1:224// 0000001B7C0C: D838E0C0 00F7F6D7
	s_waitcnt lgkmcnt(0)                                       // 0000001B7C14: BF89FC07
	s_barrier                                                  // 0000001B7C18: BFBD0000
	buffer_gl0_inv                                             // 0000001B7C1C: E0AC0000 00000000
	ds_load_2addr_b32 v[73:74], v216 offset1:32                // 0000001B7C24: D8DC2000 490000D8
	ds_load_2addr_b32 v[75:76], v216 offset0:64 offset1:96     // 0000001B7C2C: D8DC6040 4B0000D8
	ds_load_2addr_b32 v[77:78], v216 offset0:128 offset1:160   // 0000001B7C34: D8DCA080 4D0000D8
	ds_load_2addr_b32 v[79:80], v216 offset0:192 offset1:224   // 0000001B7C3C: D8DCE0C0 4F0000D8
	s_waitcnt lgkmcnt(3)                                       // 0000001B7C44: BF89FC37
	v_dual_add_f32 v74, v241, v74 :: v_dual_add_f32 v73, v240, v73// 0000001B7C48: C90895F1 4A4893F0
	s_waitcnt lgkmcnt(0)                                       // 0000001B7C50: BF89FC07
	v_dual_add_f32 v75, v242, v75 :: v_dual_add_f32 v80, v247, v80// 0000001B7C54: C90897F2 4B50A1F7
	v_add_f32_e32 v76, v243, v76                               // 0000001B7C5C: 069899F3
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B7C60: BF870193
	v_dual_mul_f32 v74, 0x3d800000, v74 :: v_dual_mul_f32 v73, 0x3d800000, v73// 0000001B7C64: C8C694FF 4A4892FF 3D800000
	v_dual_add_f32 v77, v244, v77 :: v_dual_mul_f32 v80, 0x3d800000, v80// 0000001B7C70: C9069BF4 4D50A0FF 3D800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B7C7C: BF870193
	v_mul_f32_e32 v76, 0x3d800000, v76                         // 0000001B7C80: 109898FF 3D800000
	v_dual_cndmask_b32 v74, 0xf149f2ca, v74 :: v_dual_cndmask_b32 v73, 0xf149f2ca, v73// 0000001B7C88: CA5294FF 4A4892FF F149F2CA
	v_dual_add_f32 v78, v245, v78 :: v_dual_add_f32 v79, v246, v79// 0000001B7C94: C9089DF5 4E4E9FF6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B7C9C: BF870112
	v_mov_b32_dpp v82, v74 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7CA0: 7EA402FA FF09614A
	v_dual_mul_f32 v75, 0x3d800000, v75 :: v_dual_mul_f32 v78, 0x3d800000, v78// 0000001B7CA8: C8C696FF 4B4E9CFF 3D800000
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B7CB4: BF870194
	v_mov_b32_dpp v81, v73 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7CB8: 7EA202FA FF096149
	v_max_f32_e32 v82, v82, v82                                // 0000001B7CC0: 20A4A552
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B7CC4: BF870113
	v_dual_cndmask_b32 v76, 0xf149f2ca, v76 :: v_dual_cndmask_b32 v75, 0xf149f2ca, v75// 0000001B7CC8: CA5298FF 4C4A96FF F149F2CA
	v_max_f32_e32 v82, v74, v82                                // 0000001B7CD4: 20A4A54A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B7CD8: BF870222
	v_mov_b32_dpp v84, v76 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7CDC: 7EA802FA FF09614C
	v_mul_f32_e32 v77, 0x3d800000, v77                         // 0000001B7CE4: 109A9AFF 3D800000
	v_mov_b32_dpp v83, v75 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7CEC: 7EA602FA FF09614B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B7CF4: BF870214
	v_mov_b32_dpp v90, v82 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7CF8: 7EB402FA FF096252
	v_max_f32_e32 v84, v84, v84                                // 0000001B7D00: 20A8A954
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B7D04: BF870194
	v_dual_cndmask_b32 v78, 0xf149f2ca, v78 :: v_dual_cndmask_b32 v77, 0xf149f2ca, v77// 0000001B7D08: CA529CFF 4E4C9AFF F149F2CA
	v_dual_max_f32 v83, v83, v83 :: v_dual_max_f32 v90, v90, v90// 0000001B7D14: CA94A753 535AB55A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B7D1C: BF870193
	v_max_f32_e32 v84, v76, v84                                // 0000001B7D20: 20A8A94C
	v_mov_b32_dpp v86, v78 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7D24: 7EAC02FA FF09614E
	v_mul_f32_e32 v79, 0x3d800000, v79                         // 0000001B7D2C: 109E9EFF 3D800000
	v_mov_b32_dpp v85, v77 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7D34: 7EAA02FA FF09614D
	v_max_f32_e32 v83, v75, v83                                // 0000001B7D3C: 20A6A74B
	v_mov_b32_dpp v92, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7D40: 7EB802FA FF096254
	v_max_f32_e32 v86, v86, v86                                // 0000001B7D48: 20ACAD56
	v_dual_cndmask_b32 v80, 0xf149f2ca, v80 :: v_dual_cndmask_b32 v79, 0xf149f2ca, v79// 0000001B7D4C: CA52A0FF 504E9EFF F149F2CA
	v_max_f32_e32 v85, v85, v85                                // 0000001B7D58: 20AAAB55
	v_mov_b32_dpp v91, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7D5C: 7EB602FA FF096253
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B7D64: BF870214
	v_max_f32_e32 v86, v78, v86                                // 0000001B7D68: 20ACAD4E
	v_mov_b32_dpp v88, v80 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7D6C: 7EB002FA FF096150
	v_mov_b32_dpp v87, v79 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7D74: 7EAE02FA FF09614F
	v_max_f32_e32 v81, v81, v81                                // 0000001B7D7C: 20A2A351
	v_dual_max_f32 v85, v77, v85 :: v_dual_max_f32 v92, v92, v92// 0000001B7D80: CA94AB4D 555CB95C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B7D88: BF870193
	v_dual_max_f32 v88, v88, v88 :: v_dual_max_f32 v87, v87, v87// 0000001B7D8C: CA94B158 5856AF57
	v_max_f32_e32 v81, v73, v81                                // 0000001B7D94: 20A2A349
	v_mov_b32_dpp v94, v86 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7D98: 7EBC02FA FF096256
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B7DA0: BF870214
	v_mov_b32_dpp v93, v85 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7DA4: 7EBA02FA FF096255
	v_dual_max_f32 v88, v80, v88 :: v_dual_max_f32 v87, v79, v87// 0000001B7DAC: CA94B150 5856AF4F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B7DB4: BF8701A4
	v_mov_b32_dpp v89, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7DB8: 7EB202FA FF096251
	v_dual_max_f32 v91, v91, v91 :: v_dual_max_f32 v82, v82, v90// 0000001B7DC0: CA94B75B 5B52B552
	v_mov_b32_dpp v96, v88 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7DC8: 7EC002FA FF096258
	v_max_f32_e32 v94, v94, v94                                // 0000001B7DD0: 20BCBD5E
	v_mov_b32_dpp v95, v87 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7DD4: 7EBE02FA FF096257
	v_max_f32_e32 v89, v89, v89                                // 0000001B7DDC: 20B2B359
	v_dual_max_f32 v93, v93, v93 :: v_dual_max_f32 v84, v84, v92// 0000001B7DE0: CA94BB5D 5D54B954
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001B7DE8: BF870243
	v_dual_max_f32 v96, v96, v96 :: v_dual_max_f32 v95, v95, v95// 0000001B7DEC: CA94C160 605EBF5F
	v_max_f32_e32 v86, v86, v94                                // 0000001B7DF4: 20ACBD56
	v_mov_b32_dpp v90, v82 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7DF8: 7EB402FA FF096452
	v_max_f32_e32 v83, v83, v91                                // 0000001B7E00: 20A6B753
	v_dual_max_f32 v81, v81, v89 :: v_dual_max_f32 v88, v88, v96// 0000001B7E04: CA94B351 5158C158
	v_mov_b32_dpp v92, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7E0C: 7EB802FA FF096454
	v_max_f32_e32 v85, v85, v93                                // 0000001B7E14: 20AABB55
	v_mov_b32_dpp v94, v86 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7E18: 7EBC02FA FF096456
	v_dual_max_f32 v87, v87, v95 :: v_dual_max_f32 v90, v90, v90// 0000001B7E20: CA94BF57 575AB55A
	v_mov_b32_dpp v91, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7E28: 7EB602FA FF096453
	v_mov_b32_dpp v89, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7E30: 7EB202FA FF096451
	v_mov_b32_dpp v96, v88 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7E38: 7EC002FA FF096458
	v_max_f32_e32 v92, v92, v92                                // 0000001B7E40: 20B8B95C
	v_mov_b32_dpp v93, v85 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7E44: 7EBA02FA FF096455
	v_dual_max_f32 v91, v91, v91 :: v_dual_max_f32 v82, v82, v90// 0000001B7E4C: CA94B75B 5B52B552
	v_max_f32_e32 v94, v94, v94                                // 0000001B7E54: 20BCBD5E
	v_mov_b32_dpp v95, v87 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7E58: 7EBE02FA FF096457
	v_dual_max_f32 v89, v89, v89 :: v_dual_max_f32 v96, v96, v96// 0000001B7E60: CA94B359 5960C160
	v_dual_max_f32 v93, v93, v93 :: v_dual_max_f32 v84, v84, v92// 0000001B7E68: CA94BB5D 5D54B954
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B7E70: BF870223
	v_dual_max_f32 v95, v95, v95 :: v_dual_max_f32 v86, v86, v94// 0000001B7E74: CA94BF5F 5F56BD56
	v_mov_b32_dpp v90, v82 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7E7C: 7EB402FA FF096852
	v_dual_max_f32 v81, v81, v89 :: v_dual_max_f32 v88, v88, v96// 0000001B7E84: CA94B351 5158C158
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B7E8C: BF870214
	v_mov_b32_dpp v92, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7E90: 7EB802FA FF096854
	v_mov_b32_dpp v94, v86 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7E98: 7EBC02FA FF096856
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B7EA0: BF870004
	v_max3_f32 v146, v224, v82, v90                            // 0000001B7EA4: D61C0092 056AA5E0
	v_max_f32_e32 v83, v83, v91                                // 0000001B7EAC: 20A6B753
	v_mov_b32_dpp v89, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7EB0: 7EB202FA FF096851
	v_mov_b32_dpp v96, v88 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7EB8: 7EC002FA FF096858
	v_max3_f32 v148, v227, v84, v92                            // 0000001B7EC0: D61C0094 0572A9E3
	v_max_f32_e32 v85, v85, v93                                // 0000001B7EC8: 20AABB55
	v_max3_f32 v150, v229, v86, v94                            // 0000001B7ECC: D61C0096 057AADE5
	v_dual_max_f32 v87, v87, v95 :: v_dual_sub_f32 v74, v74, v146// 0000001B7ED4: CA8ABF57 574B254A
	v_mov_b32_dpp v91, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7EDC: 7EB602FA FF096853
	v_max3_f32 v145, v223, v81, v89                            // 0000001B7EE4: D61C0091 0566A3DF
	v_max3_f32 v152, v231, v88, v96                            // 0000001B7EEC: D61C0098 0582B1E7
	v_sub_f32_e32 v76, v76, v148                               // 0000001B7EF4: 0899294C
	v_mov_b32_dpp v93, v85 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7EF8: 7EBA02FA FF096855
	v_max3_f32 v147, v225, v83, v91                            // 0000001B7F00: D61C0093 056EA7E1
	v_sub_f32_e32 v78, v78, v150                               // 0000001B7F08: 089D2D4E
	v_mov_b32_dpp v95, v87 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B7F0C: 7EBE02FA FF096857
	v_dual_sub_f32 v73, v73, v145 :: v_dual_sub_f32 v80, v80, v152// 0000001B7F14: C94B2349 49513150
	v_max3_f32 v149, v228, v85, v93                            // 0000001B7F1C: D61C0095 0576ABE4
	v_sub_f32_e32 v75, v75, v147                               // 0000001B7F24: 0897274B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B7F28: BF870214
	v_max3_f32 v151, v230, v87, v95                            // 0000001B7F2C: D61C0097 057EAFE6
	v_mul_f32_e32 v82, 0x3fb8aa3b, v73                         // 0000001B7F34: 10A492FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v73                  // 0000001B7F3C: 7C3692FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B7F44: BF870214
	v_dual_sub_f32 v77, v77, v149 :: v_dual_mul_f32 v84, 0x3fb8aa3b, v75// 0000001B7F48: C9472B4D 4D5496FF 3FB8AA3B
	v_sub_f32_e32 v79, v79, v151                               // 0000001B7F54: 089F2F4F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B7F58: BF870224
	v_fma_f32 v91, 0x3fb8aa3b, v73, -v82                       // 0000001B7F5C: D613005B 854A92FF 3FB8AA3B
	v_rndne_f32_e32 v92, v82                                   // 0000001B7F68: 7EB84752
	v_dual_mul_f32 v86, 0x3fb8aa3b, v77 :: v_dual_mul_f32 v81, 0x3fb8aa3b, v74// 0000001B7F6C: C8C69AFF 565094FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B7F78: BF870194
	v_dual_mul_f32 v88, 0x3fb8aa3b, v79 :: v_dual_mul_f32 v85, 0x3fb8aa3b, v78// 0000001B7F7C: C8C69EFF 58549CFF 3FB8AA3B
	v_sub_f32_e32 v82, v82, v92                                // 0000001B7F88: 08A4B952
	v_cvt_i32_f32_e32 v92, v92                                 // 0000001B7F8C: 7EB8115C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B7F90: BF870214
	v_fma_f32 v89, 0x3fb8aa3b, v74, -v81                       // 0000001B7F94: D6130059 854694FF 3FB8AA3B
	v_rndne_f32_e32 v104, v88                                  // 0000001B7FA0: 7ED04758
	v_fmac_f32_e32 v91, 0x32a5705f, v73                        // 0000001B7FA4: 56B692FF 32A5705F
	v_fma_f32 v103, 0x3fb8aa3b, v79, -v88                      // 0000001B7FAC: D6130067 85629EFF 3FB8AA3B
	v_fma_f32 v95, 0x3fb8aa3b, v75, -v84                       // 0000001B7FB8: D613005F 855296FF 3FB8AA3B
	v_rndne_f32_e32 v96, v84                                   // 0000001B7FC4: 7EC04754
	v_sub_f32_e32 v88, v88, v104                               // 0000001B7FC8: 08B0D158
	v_dual_mul_f32 v83, 0x3fb8aa3b, v76 :: v_dual_add_f32 v82, v82, v91// 0000001B7FCC: C8C898FF 5352B752 3FB8AA3B
	v_rndne_f32_e32 v90, v81                                   // 0000001B7FD8: 7EB44751
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B7FDC: BF870224
	v_dual_fmac_f32 v89, 0x32a5705f, v74 :: v_dual_sub_f32 v84, v84, v96// 0000001B7FE0: C80A94FF 5954C154 32A5705F
	v_rndne_f32_e32 v100, v86                                  // 0000001B7FEC: 7EC84756
	v_exp_f32_e32 v82, v82                                     // 0000001B7FF0: 7EA44B52
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001B7FF4: BF870243
	v_sub_f32_e32 v81, v81, v90                                // 0000001B7FF8: 08A2B551
	v_fma_f32 v99, 0x3fb8aa3b, v77, -v86                       // 0000001B7FFC: D6130063 855A9AFF 3FB8AA3B
	v_sub_f32_e32 v158, v224, v146                             // 0000001B8008: 093D25E0
	v_dual_sub_f32 v86, v86, v100 :: v_dual_sub_f32 v157, v223, v145// 0000001B800C: C94AC956 569D23DF
	v_dual_add_f32 v81, v81, v89 :: v_dual_sub_f32 v164, v231, v152// 0000001B8014: C90AB351 51A531E7
	v_mov_b32_e32 v224, v146                                   // 0000001B801C: 7FC00392
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B8020: BF870294
	v_mul_f32_e32 v146, 0x3fb8aa3b, v158                       // 0000001B8024: 11253CFF 3FB8AA3B
	.long 0xd71c0052                                           // 0000001B802C: D71C0052
	v_cndmask_b32_e32 v1, v82, v92, vcc_lo                     // 0000001B8030: 0202B952
	v_fmac_f32_e32 v95, 0x32a5705f, v75                        // 0000001B8034: 56BE96FF 32A5705F
	v_exp_f32_e32 v81, v81                                     // 0000001B803C: 7EA24B51
	v_cvt_i32_f32_e32 v90, v90                                 // 0000001B8040: 7EB4115A
	v_rndne_f32_e32 v168, v146                                 // 0000001B8044: 7F504792
	v_dual_cndmask_b32 v82, 0, v82 :: v_dual_mul_f32 v87, 0x3fb8aa3b, v80// 0000001B8048: CA46A480 5256A0FF 3FB8AA3B
	v_add_f32_e32 v84, v84, v95                                // 0000001B8054: 06A8BF54
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v73                  // 0000001B8058: 7C3C92FF 42B17218
	v_fma_f32 v93, 0x3fb8aa3b, v76, -v83                       // 0000001B8060: D613005D 854E98FF 3FB8AA3B
	v_rndne_f32_e32 v94, v83                                   // 0000001B806C: 7EBC4753
	v_fma_f32 v101, 0x3fb8aa3b, v80, -v87                      // 0000001B8070: D6130065 855EA0FF 3FB8AA3B
	v_rndne_f32_e32 v102, v87                                  // 0000001B807C: 7ECC4757
	v_cndmask_b32_e32 v153, 0x7f800000, v82, vcc_lo            // 0000001B8080: 0332A4FF 7F800000
	.long 0xd71c0051                                           // 0000001B8088: D71C0051
	v_cndmask_b32_e32 v1, v81, v90, vcc_lo                     // 0000001B808C: 0202B551
	.long 0xd41b0007                                           // 0000001B8090: D41B0007
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v74, vcc_lo              // 0000001B8094: 020294FF C2CE8ED0
	v_fmac_f32_e32 v101, 0x32a5705f, v80                       // 0000001B809C: 56CAA0FF 32A5705F
	v_sub_f32_e32 v87, v87, v102                               // 0000001B80A4: 08AECD57
	v_fma_f32 v167, 0x3fb8aa3b, v158, -v146                    // 0000001B80A8: D61300A7 864B3CFF 3FB8AA3B
	v_sub_f32_e32 v146, v146, v168                             // 0000001B80B4: 09255192
	.long 0xd59c08ee                                           // 0000001B80B8: D59C08EE
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                   // 0000001B80BC: 02010199
	v_fmac_f32_e32 v99, 0x32a5705f, v77                        // 0000001B80C0: 56C69AFF 32A5705F
	v_dual_fmac_f32 v103, 0x32a5705f, v79 :: v_dual_sub_f32 v160, v227, v148// 0000001B80C8: C80A9EFF 67A129E3 32A5705F
	v_sub_f32_e32 v83, v83, v94                                // 0000001B80D4: 08A6BD53
	v_cndmask_b32_e64 v81, 0, v81, s7                          // 0000001B80D8: D5010051 001EA280
	.long 0xd41e0007                                           // 0000001B80E0: D41E0007
	v_cndmask_b32_e32 v1, 0x42b17218, v74, vcc_lo              // 0000001B80E4: 020294FF 42B17218
	v_dual_fmac_f32 v93, 0x32a5705f, v76 :: v_dual_and_b32 v74, 1, v238// 0000001B80EC: C82498FF 5D4BDC81 32A5705F
	v_add_f32_e32 v86, v86, v99                                // 0000001B80F8: 06ACC756
	v_add_f32_e32 v88, v88, v103                               // 0000001B80FC: 06B0CF58
	v_sub_f32_e32 v162, v229, v150                             // 0000001B8100: 09452DE5
	v_cvt_i32_f32_e32 v94, v94                                 // 0000001B8104: 7EBC115E
	v_add_f32_e32 v83, v83, v93                                // 0000001B8108: 06A6BB53
	.long 0xd41b0000                                           // 0000001B810C: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v76, vcc_lo              // 0000001B8110: 020298FF C2CE8ED0
	v_cndmask_b32_e64 v213, 0x7f800000, v81, s7                // 0000001B8118: D50100D5 001EA2FF 7F800000
	v_fmac_f32_e32 v167, 0x32a5705f, v158                      // 0000001B8124: 574F3CFF 32A5705F
	v_fma_f32 v97, 0x3fb8aa3b, v78, -v85                       // 0000001B812C: D6130061 85569CFF 3FB8AA3B
	v_exp_f32_e32 v83, v83                                     // 0000001B8138: 7EA64B53
	v_rndne_f32_e32 v98, v85                                   // 0000001B813C: 7EC44755
	.long 0xd59c08ed                                           // 0000001B8140: D59C08ED
	v_cndmask_b32_e32 v0, v213, v128, vcc_lo                   // 0000001B8144: 020101D5
	v_dual_sub_f32 v161, v228, v149 :: v_dual_add_f32 v146, v146, v167// 0000001B8148: C9492BE4 A1934F92
	v_fmac_f32_e32 v97, 0x32a5705f, v78                        // 0000001B8150: 56C29CFF 32A5705F
	v_dual_add_f32 v87, v87, v101 :: v_dual_mov_b32 v228, v149 // 0000001B8158: C910CB57 57E40195
	v_cvt_i32_f32_e32 v168, v168                               // 0000001B8160: 7F5011A8
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001B8164: BF870314
	v_exp_f32_e32 v146, v146                                   // 0000001B8168: 7F244B92
	.long 0xd71c0053                                           // 0000001B816C: D71C0053
	v_cndmask_b32_e32 v1, v83, v94, vcc_lo                     // 0000001B8170: 0202BD53
	v_exp_f32_e32 v84, v84                                     // 0000001B8174: 7EA84B54
	v_exp_f32_e32 v86, v86                                     // 0000001B8178: 7EAC4B56
	v_exp_f32_e32 v87, v87                                     // 0000001B817C: 7EAE4B57
	v_exp_f32_e32 v88, v88                                     // 0000001B8180: 7EB04B58
	v_cndmask_b32_e64 v73, 0, v83, s0                          // 0000001B8184: D5010049 0002A680
	.long 0xd41e0000                                           // 0000001B818C: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v76, vcc_lo              // 0000001B8190: 020298FF 42B17218
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v158                 // 0000001B8198: 7C373CFF C2CE8ED0
	v_cvt_i32_f32_e32 v96, v96                                 // 0000001B81A0: 7EC01160
	.long 0xd71c0092                                           // 0000001B81A4: D71C0092
	v_cndmask_b32_e32 v1, v146, v168, vcc_lo                   // 0000001B81A8: 02035192
	v_sub_f32_e32 v163, v230, v151                             // 0000001B81AC: 09472FE6
	v_cndmask_b32_e64 v212, 0x7f800000, v73, s0                // 0000001B81B0: D50100D4 000292FF 7F800000
	v_dual_mov_b32 v230, v151 :: v_dual_and_b32 v73, 1, v237   // 0000001B81BC: CA240197 E649DA81
	v_cvt_i32_f32_e32 v100, v100                               // 0000001B81C4: 7EC81164
	v_cvt_i32_f32_e32 v102, v102                               // 0000001B81C8: 7ECC1166
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B81CC: BF870004
	.long 0xd59c08ed                                           // 0000001B81D0: D59C08ED
	v_cndmask_b32_e32 v0, v212, v128, vcc_lo                   // 0000001B81D4: 020101D4
	v_sub_f32_e32 v85, v85, v98                                // 0000001B81D8: 08AAC555
	v_cvt_i32_f32_e32 v98, v98                                 // 0000001B81DC: 7EC41162
	v_cvt_i32_f32_e32 v104, v104                               // 0000001B81E0: 7ED01168
	.long 0xd71c0054                                           // 0000001B81E4: D71C0054
	v_cndmask_b32_e32 v1, v84, v96, vcc_lo                     // 0000001B81E8: 0202C154
	.long 0xd41b0001                                           // 0000001B81EC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v75, vcc_lo              // 0000001B81F0: 020296FF C2CE8ED0
	v_add_f32_e32 v85, v85, v97                                // 0000001B81F8: 06AAC355
	.long 0xd41b0003                                           // 0000001B81FC: D41B0003
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v78, vcc_lo              // 0000001B8200: 02029CFF C2CE8ED0
	.long 0xd71c0056                                           // 0000001B8208: D71C0056
	v_cndmask_b32_e32 v1, v86, v100, vcc_lo                    // 0000001B820C: 0202C956
	.long 0xd41b0004                                           // 0000001B8210: D41B0004
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v77, vcc_lo              // 0000001B8214: 02029AFF C2CE8ED0
	.long 0xd71c0057                                           // 0000001B821C: D71C0057
	v_cndmask_b32_e32 v1, v87, v102, vcc_lo                    // 0000001B8220: 0202CD57
	v_exp_f32_e32 v85, v85                                     // 0000001B8224: 7EAA4B55
	.long 0xd41b0005                                           // 0000001B8228: D41B0005
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v80, vcc_lo              // 0000001B822C: 0202A0FF C2CE8ED0
	.long 0xd71c0058                                           // 0000001B8234: D71C0058
	v_cndmask_b32_e32 v1, v88, v104, vcc_lo                    // 0000001B8238: 0202D158
	.long 0xd41b0006                                           // 0000001B823C: D41B0006
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v79, vcc_lo              // 0000001B8240: 02029EFF C2CE8ED0
	v_cndmask_b32_e64 v76, 0, v84, s1                          // 0000001B8248: D501004C 0006A880
	.long 0xd41e0001                                           // 0000001B8250: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v75, vcc_lo              // 0000001B8254: 020296FF 42B17218
	v_cndmask_b32_e32 v146, 0, v146, vcc_lo                    // 0000001B825C: 03252480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v158                 // 0000001B8260: 7C3D3CFF 42B17218
	v_dual_mov_b32 v227, v148 :: v_dual_mul_f32 v148, 0x3fb8aa3b, v160// 0000001B8268: CA060194 E39540FF 3FB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001B8274: BF870245
	.long 0xd71c0055                                           // 0000001B8278: D71C0055
	v_cndmask_b32_e32 v1, v85, v98, vcc_lo                     // 0000001B827C: 0202C555
	v_cndmask_b32_e64 v154, 0x7f800000, v76, s1                // 0000001B8280: D501009A 000698FF 7F800000
	v_dual_cndmask_b32 v146, 0x7f800000, v146 :: v_dual_mov_b32 v231, v152// 0000001B828C: CA5124FF 92E60198 7F800000
	v_mul_f32_e32 v152, 0x3fb8aa3b, v164                       // 0000001B8298: 113148FF 3FB8AA3B
	v_cndmask_b32_e64 v75, 0, v85, s3                          // 0000001B82A0: D501004B 000EAA80
	.long 0xd41e0003                                           // 0000001B82A8: D41E0003
	v_cndmask_b32_e32 v1, 0x42b17218, v78, vcc_lo              // 0000001B82AC: 02029CFF 42B17218
	v_cndmask_b32_e64 v78, 0, v86, s4                          // 0000001B82B4: D501004E 0012AC80
	.long 0xd41e0004                                           // 0000001B82BC: D41E0004
	v_cndmask_b32_e32 v1, 0x42b17218, v77, vcc_lo              // 0000001B82C0: 02029AFF 42B17218
	v_cndmask_b32_e64 v77, 0, v87, s5                          // 0000001B82C8: D501004D 0016AE80
	.long 0xd41e0005                                           // 0000001B82D0: D41E0005
	v_cndmask_b32_e32 v1, 0x42b17218, v80, vcc_lo              // 0000001B82D4: 0202A0FF 42B17218
	v_cndmask_b32_e64 v80, 0, v88, s6                          // 0000001B82DC: D5010050 001AB080
	.long 0xd41e0006                                           // 0000001B82E4: D41E0006
	v_cndmask_b32_e32 v1, 0x42b17218, v79, vcc_lo              // 0000001B82E8: 02029EFF 42B17218
	v_cndmask_b32_e64 v211, 0x7f800000, v75, s3                // 0000001B82F0: D50100D3 000E96FF 7F800000
	.long 0xd59c08ef                                           // 0000001B82FC: D59C08EF
	v_cndmask_b32_e32 v0, v154, v128, vcc_lo                   // 0000001B8300: 0201019A
	v_cndmask_b32_e64 v236, 0x7f800000, v77, s5                // 0000001B8304: D50100EC 00169AFF 7F800000
	v_cndmask_b32_e64 v155, 0x7f800000, v78, s4                // 0000001B8310: D501009B 00129CFF 7F800000
	v_cndmask_b32_e64 v156, 0x7f800000, v80, s6                // 0000001B831C: D501009C 001AA0FF 7F800000
	v_and_b32_e32 v78, 1, v237                                 // 0000001B8328: 369DDA81
	.long 0xd59c08ed                                           // 0000001B832C: D59C08ED
	v_cndmask_b32_e32 v0, v211, v128, vcc_lo                   // 0000001B8330: 020101D3
	v_fma_f32 v179, 0x3fb8aa3b, v164, -v152                    // 0000001B8334: D61300B3 866348FF 3FB8AA3B
	v_rndne_f32_e32 v180, v152                                 // 0000001B8340: 7F684798
	.long 0xd59c08fd                                           // 0000001B8344: D59C08FD
	v_cndmask_b32_e32 v0, v156, v128, vcc_lo                   // 0000001B8348: 0201019C
	v_and_b32_e32 v75, 1, v239                                 // 0000001B834C: 3697DE81
	.long 0xd59c08fc                                           // 0000001B8350: D59C08FC
	v_cndmask_b32_e32 v0, v155, v128, vcc_lo                   // 0000001B8354: 0201019B
	v_add3_u32 v74, v153, v74, 0x7fff                          // 0000001B8358: D655004A 03FE9599 00007FFF
	v_dual_sub_f32 v159, v225, v147 :: v_dual_sub_f32 v152, v152, v180// 0000001B8364: C94B27E1 9F996998
	v_and_b32_e32 v77, 1, v253                                 // 0000001B836C: 369BFA81
	v_rndne_f32_e32 v172, v148                                 // 0000001B8370: 7F584794
	v_and_b32_e32 v79, 1, v237                                 // 0000001B8374: 369FDA81
	.long 0xd59c08ed                                           // 0000001B8378: D59C08ED
	v_cndmask_b32_e32 v0, v236, v128, vcc_lo                   // 0000001B837C: 020101EC
	v_fmac_f32_e32 v179, 0x32a5705f, v164                      // 0000001B8380: 576748FF 32A5705F
	v_dual_mov_b32 v229, v150 :: v_dual_mul_f32 v150, 0x3fb8aa3b, v162// 0000001B8388: CA060196 E59744FF 3FB8AA3B
	v_add3_u32 v73, v213, v73, 0x7fff                          // 0000001B8394: D6550049 03FE93D5 00007FFF
	v_add3_u32 v75, v154, v75, 0x7fff                          // 0000001B83A0: D655004B 03FE979A 00007FFF
	v_and_b32_e32 v76, 1, v252                                 // 0000001B83AC: 3699F881
	ds_store_b16_d16_hi v217, v74                              // 0000001B83B0: DA840000 00004AD9
	ds_store_b16_d16_hi v217, v73 offset:64                    // 0000001B83B8: DA840040 000049D9
	ds_store_b16_d16_hi v217, v75 offset:128                   // 0000001B83C0: DA840080 00004BD9
	v_rndne_f32_e32 v176, v150                                 // 0000001B83C8: 7F604796
	v_and_b32_e32 v73, 1, v237                                 // 0000001B83CC: 3693DA81
	v_add3_u32 v78, v212, v78, 0x7fff                          // 0000001B83D0: D655004E 03FE9DD4 00007FFF
	v_fma_f32 v171, 0x3fb8aa3b, v160, -v148                    // 0000001B83DC: D61300AB 865340FF 3FB8AA3B
	v_sub_f32_e32 v148, v148, v172                             // 0000001B83E8: 09295994
	v_add3_u32 v74, v211, v79, 0x7fff                          // 0000001B83EC: D655004A 03FE9FD3 00007FFF
	v_add3_u32 v76, v155, v76, 0x7fff                          // 0000001B83F8: D655004C 03FE999B 00007FFF
	v_add3_u32 v77, v156, v77, 0x7fff                          // 0000001B8404: D655004D 03FE9B9C 00007FFF
	v_fma_f32 v175, 0x3fb8aa3b, v162, -v150                    // 0000001B8410: D61300AF 865B44FF 3FB8AA3B
	v_sub_f32_e32 v150, v150, v176                             // 0000001B841C: 092D6196
	v_add3_u32 v73, v236, v73, 0x7fff                          // 0000001B8420: D6550049 03FE93EC 00007FFF
	ds_store_b16_d16_hi v217, v78 offset:192                   // 0000001B842C: DA8400C0 00004ED9
	ds_store_b16_d16_hi v217, v76 offset:256                   // 0000001B8434: DA840100 00004CD9
	ds_store_b16_d16_hi v217, v74 offset:320                   // 0000001B843C: DA840140 00004AD9
	ds_store_b16_d16_hi v217, v77 offset:384                   // 0000001B8444: DA840180 00004DD9
	ds_store_b16_d16_hi v217, v73 offset:448                   // 0000001B844C: DA8401C0 000049D9
	ds_load_b128 v[73:76], v218                                // 0000001B8454: DBFC0000 490000DA
	ds_load_b128 v[77:80], v218 offset:16                      // 0000001B845C: DBFC0010 4D0000DA
	s_clause 0x1f                                              // 0000001B8464: BF85001F
	global_load_b64 v[81:82], v[248:249], off                  // 0000001B8468: DC560000 517C00F8
	global_load_b64 v[89:90], v[248:249], off offset:128       // 0000001B8470: DC560080 597C00F8
	global_load_b64 v[97:98], v[248:249], off offset:256       // 0000001B8478: DC560100 617C00F8
	global_load_b64 v[105:106], v[248:249], off offset:384     // 0000001B8480: DC560180 697C00F8
	global_load_b64 v[83:84], v[250:251], off                  // 0000001B8488: DC560000 537C00FA
	global_load_b64 v[91:92], v[250:251], off offset:128       // 0000001B8490: DC560080 5B7C00FA
	global_load_b64 v[99:100], v[250:251], off offset:256      // 0000001B8498: DC560100 637C00FA
	global_load_b64 v[107:108], v[250:251], off offset:384     // 0000001B84A0: DC560180 6B7C00FA
	global_load_b64 v[85:86], v[203:204], off                  // 0000001B84A8: DC560000 557C00CB
	global_load_b64 v[93:94], v[203:204], off offset:128       // 0000001B84B0: DC560080 5D7C00CB
	global_load_b64 v[101:102], v[203:204], off offset:256     // 0000001B84B8: DC560100 657C00CB
	global_load_b64 v[109:110], v[203:204], off offset:384     // 0000001B84C0: DC560180 6D7C00CB
	global_load_b64 v[87:88], v[201:202], off                  // 0000001B84C8: DC560000 577C00C9
	global_load_b64 v[95:96], v[201:202], off offset:128       // 0000001B84D0: DC560080 5F7C00C9
	global_load_b64 v[103:104], v[201:202], off offset:256     // 0000001B84D8: DC560100 677C00C9
	global_load_b64 v[111:112], v[201:202], off offset:384     // 0000001B84E0: DC560180 6F7C00C9
	global_load_b64 v[113:114], v[248:249], off offset:512     // 0000001B84E8: DC560200 717C00F8
	global_load_b64 v[121:122], v[248:249], off offset:640     // 0000001B84F0: DC560280 797C00F8
	global_load_b64 v[129:130], v[248:249], off offset:768     // 0000001B84F8: DC560300 817C00F8
	global_load_b64 v[137:138], v[248:249], off offset:896     // 0000001B8500: DC560380 897C00F8
	global_load_b64 v[115:116], v[250:251], off offset:512     // 0000001B8508: DC560200 737C00FA
	global_load_b64 v[123:124], v[250:251], off offset:640     // 0000001B8510: DC560280 7B7C00FA
	global_load_b64 v[131:132], v[250:251], off offset:768     // 0000001B8518: DC560300 837C00FA
	global_load_b64 v[139:140], v[250:251], off offset:896     // 0000001B8520: DC560380 8B7C00FA
	global_load_b64 v[117:118], v[203:204], off offset:512     // 0000001B8528: DC560200 757C00CB
	global_load_b64 v[125:126], v[203:204], off offset:640     // 0000001B8530: DC560280 7D7C00CB
	global_load_b64 v[133:134], v[203:204], off offset:768     // 0000001B8538: DC560300 857C00CB
	global_load_b64 v[141:142], v[203:204], off offset:896     // 0000001B8540: DC560380 8D7C00CB
	global_load_b64 v[119:120], v[201:202], off offset:512     // 0000001B8548: DC560200 777C00C9
	global_load_b64 v[127:128], v[201:202], off offset:640     // 0000001B8550: DC560280 7F7C00C9
	global_load_b64 v[135:136], v[201:202], off offset:768     // 0000001B8558: DC560300 877C00C9
	global_load_b64 v[143:144], v[201:202], off offset:896     // 0000001B8560: DC560380 8F7C00C9
	v_add_f32_e32 v152, v152, v179                             // 0000001B8568: 07316798
	v_cvt_i32_f32_e32 v180, v180                               // 0000001B856C: 7F6811B4
	.long 0xd41b0006                                           // 0000001B8570: D41B0006
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v164, vcc_lo             // 0000001B8574: 020348FF C2CE8ED0
	v_dual_fmac_f32 v171, 0x32a5705f, v160 :: v_dual_mul_f32 v42, v42, v146// 0000001B857C: C80740FF AB2B252A 32A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B8588: BF8701B4
	v_exp_f32_e32 v152, v152                                   // 0000001B858C: 7F304B98
	v_mov_b32_e32 v223, v145                                   // 0000001B8590: 7FBE0391
	v_cvt_i32_f32_e32 v172, v172                               // 0000001B8594: 7F5811AC
	v_add_f32_e32 v148, v148, v171                             // 0000001B8598: 07295794
	v_cvt_i32_f32_e32 v176, v176                               // 0000001B859C: 7F6011B0
	.long 0xd41b0001                                           // 0000001B85A0: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v160, vcc_lo             // 0000001B85A4: 020340FF C2CE8ED0
	.long 0xd41b0004                                           // 0000001B85AC: D41B0004
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v162, vcc_lo             // 0000001B85B0: 020344FF C2CE8ED0
	v_dual_mul_f32 v151, 0x3fb8aa3b, v163 :: v_dual_mul_f32 v50, v50, v146// 0000001B85B8: C8C746FF 97332532 3FB8AA3B
	v_exp_f32_e32 v148, v148                                   // 0000001B85C4: 7F284B94
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B85C8: BF8701A6
	.long 0xd71c0098                                           // 0000001B85CC: D71C0098
	v_cndmask_b32_e32 v1, v152, v180, vcc_lo                   // 0000001B85D0: 02036998
	v_mul_f32_e32 v34, v34, v146                               // 0000001B85D4: 10452522
	v_fma_f32 v177, 0x3fb8aa3b, v163, -v151                    // 0000001B85D8: D61300B1 865F46FF 3FB8AA3B
	v_rndne_f32_e32 v178, v151                                 // 0000001B85E4: 7F644797
	v_mul_f32_e32 v26, v26, v146                               // 0000001B85E8: 1035251A
	v_cndmask_b32_e64 v152, 0, v152, s6                        // 0000001B85EC: D5010098 001B3080
	.long 0xd41e0006                                           // 0000001B85F4: D41E0006
	v_cndmask_b32_e32 v1, 0x42b17218, v164, vcc_lo             // 0000001B85F8: 020348FF 42B17218
	v_dual_fmac_f32 v177, 0x32a5705f, v163 :: v_dual_mul_f32 v18, v18, v146// 0000001B8600: C80746FF B1132512 32A5705F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B860C: BF870225
	.long 0xd71c0094                                           // 0000001B8610: D71C0094
	v_cndmask_b32_e32 v1, v148, v172, vcc_lo                   // 0000001B8614: 02035994
	.long 0xd41b0000                                           // 0000001B8618: D41B0000
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v159, vcc_lo             // 0000001B861C: 02033EFF C2CE8ED0
	v_cndmask_b32_e64 v152, 0x7f800000, v152, s6               // 0000001B8624: D5010098 001B30FF 7F800000
	v_fmac_f32_e32 v175, 0x32a5705f, v162                      // 0000001B8630: 575F44FF 32A5705F
	v_mul_f32_e32 v149, 0x3fb8aa3b, v161                       // 0000001B8638: 112B42FF 3FB8AA3B
	v_cndmask_b32_e64 v148, 0, v148, s1                        // 0000001B8640: D5010094 00072880
	.long 0xd41e0001                                           // 0000001B8648: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v160, vcc_lo             // 0000001B864C: 020340FF 42B17218
	v_dual_mul_f32 v40, v40, v152 :: v_dual_mov_b32 v225, v147 // 0000001B8654: C8D13128 28E00193
	v_add_f32_e32 v150, v150, v175                             // 0000001B865C: 072D5F96
	v_mul_f32_e32 v64, v64, v152                               // 0000001B8660: 10813140
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B8664: BF870004
	v_cndmask_b32_e64 v148, 0x7f800000, v148, s1               // 0000001B8668: D5010094 000728FF 7F800000
	v_mul_f32_e32 v145, 0x3fb8aa3b, v157                       // 0000001B8674: 11233AFF 3FB8AA3B
	v_fma_f32 v173, 0x3fb8aa3b, v161, -v149                    // 0000001B867C: D61300AD 865742FF 3FB8AA3B
	v_exp_f32_e32 v150, v150                                   // 0000001B8688: 7F2C4B96
	v_rndne_f32_e32 v174, v149                                 // 0000001B868C: 7F5C4795
	v_mul_f32_e32 v60, v60, v148                               // 0000001B8690: 1079293C
	v_fma_f32 v165, 0x3fb8aa3b, v157, -v145                    // 0000001B8694: D61300A5 86473AFF 3FB8AA3B
	v_rndne_f32_e32 v166, v145                                 // 0000001B86A0: 7F4C4791
	v_dual_sub_f32 v151, v151, v178 :: v_dual_mul_f32 v28, v28, v148// 0000001B86A4: C9476597 971D291C
	v_dual_sub_f32 v149, v149, v174 :: v_dual_mul_f32 v36, v36, v148// 0000001B86AC: C9475D95 95252924
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B86B4: BF870294
	v_dual_fmac_f32 v165, 0x32a5705f, v157 :: v_dual_mul_f32 v52, v52, v148// 0000001B86B8: C8073AFF A5352934 32A5705F
	.long 0xd71c0096                                           // 0000001B86C4: D71C0096
	v_cndmask_b32_e32 v1, v150, v176, vcc_lo                   // 0000001B86C8: 02036196
	v_dual_sub_f32 v145, v145, v166 :: v_dual_mul_f32 v56, v56, v152// 0000001B86CC: C9474D91 91393138
	v_dual_add_f32 v151, v151, v177 :: v_dual_mul_f32 v48, v48, v152// 0000001B86D4: C9076397 97313130
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B86DC: BF870223
	v_cndmask_b32_e64 v150, 0, v150, s4                        // 0000001B86E0: D5010096 00132C80
	.long 0xd41e0004                                           // 0000001B86E8: D41E0004
	v_cndmask_b32_e32 v1, 0x42b17218, v162, vcc_lo             // 0000001B86EC: 020344FF 42B17218
	v_add_f32_e32 v145, v145, v165                             // 0000001B86F4: 07234B91
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B86F8: BF870004
	v_exp_f32_e32 v151, v151                                   // 0000001B86FC: 7F2E4B97
	v_mul_f32_e32 v32, v32, v152                               // 0000001B8700: 10413120
	v_cvt_i32_f32_e32 v166, v166                               // 0000001B8704: 7F4C11A6
	v_cndmask_b32_e64 v150, 0x7f800000, v150, s4               // 0000001B8708: D5010096 00132CFF 7F800000
	v_mul_f32_e32 v147, 0x3fb8aa3b, v159                       // 0000001B8714: 11273EFF 3FB8AA3B
	v_fmac_f32_e32 v173, 0x32a5705f, v161                      // 0000001B871C: 575B42FF 32A5705F
	v_exp_f32_e32 v145, v145                                   // 0000001B8724: 7F224B91
	v_cvt_i32_f32_e32 v174, v174                               // 0000001B8728: 7F5C11AE
	v_mul_f32_e32 v62, v62, v150                               // 0000001B872C: 107D2D3E
	v_fma_f32 v169, 0x3fb8aa3b, v159, -v147                    // 0000001B8730: D61300A9 864F3EFF 3FB8AA3B
	v_rndne_f32_e32 v170, v147                                 // 0000001B873C: 7F544793
	v_mul_f32_e32 v54, v54, v150                               // 0000001B8740: 106D2D36
	v_dual_mul_f32 v46, v46, v150 :: v_dual_add_f32 v149, v149, v173// 0000001B8744: C8C92D2E 2E955B95
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B874C: BF870214
	v_fmac_f32_e32 v169, 0x32a5705f, v159                      // 0000001B8750: 57533EFF 32A5705F
	v_sub_f32_e32 v147, v147, v170                             // 0000001B8758: 09275593
	v_mul_f32_e32 v30, v30, v150                               // 0000001B875C: 103D2D1E
	v_cvt_i32_f32_e32 v170, v170                               // 0000001B8760: 7F5411AA
	v_exp_f32_e32 v149, v149                                   // 0000001B8764: 7F2A4B95
	v_cvt_i32_f32_e32 v178, v178                               // 0000001B8768: 7F6411B2
	v_add_f32_e32 v147, v147, v169                             // 0000001B876C: 07275393
	.long 0xd71c0091                                           // 0000001B8770: D71C0091
	v_cndmask_b32_e32 v1, v145, v166, vcc_lo                   // 0000001B8774: 02034D91
	.long 0xd41b0003                                           // 0000001B8778: D41B0003
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v161, vcc_lo             // 0000001B877C: 020342FF C2CE8ED0
	.long 0xd41b0005                                           // 0000001B8784: D41B0005
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v163, vcc_lo             // 0000001B8788: 020346FF C2CE8ED0
	.long 0xd71c0097                                           // 0000001B8790: D71C0097
	v_cndmask_b32_e32 v1, v151, v178, vcc_lo                   // 0000001B8794: 02036597
	v_exp_f32_e32 v147, v147                                   // 0000001B8798: 7F264B93
	.long 0xd41b0007                                           // 0000001B879C: D41B0007
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v157, vcc_lo             // 0000001B87A0: 02033AFF C2CE8ED0
	v_mul_f32_e32 v58, v58, v146                               // 0000001B87A8: 1075253A
	.long 0xd71c0095                                           // 0000001B87AC: D71C0095
	v_cndmask_b32_e32 v1, v149, v174, vcc_lo                   // 0000001B87B0: 02035D95
	v_cndmask_b32_e64 v151, 0, v151, s5                        // 0000001B87B4: D5010097 00172E80
	.long 0xd41e0005                                           // 0000001B87BC: D41E0005
	v_cndmask_b32_e32 v1, 0x42b17218, v163, vcc_lo             // 0000001B87C0: 020346FF 42B17218
	v_cndmask_b32_e64 v145, 0, v145, s7                        // 0000001B87C8: D5010091 001F2280
	.long 0xd41e0007                                           // 0000001B87D0: D41E0007
	v_cndmask_b32_e32 v1, 0x42b17218, v157, vcc_lo             // 0000001B87D4: 02033AFF 42B17218
	v_cndmask_b32_e64 v149, 0, v149, s3                        // 0000001B87DC: D5010095 000F2A80
	.long 0xd41e0003                                           // 0000001B87E4: D41E0003
	v_cndmask_b32_e32 v1, 0x42b17218, v161, vcc_lo             // 0000001B87E8: 020342FF 42B17218
	.long 0xd71c0093                                           // 0000001B87F0: D71C0093
	v_cndmask_b32_e32 v1, v147, v170, vcc_lo                   // 0000001B87F4: 02035593
	v_cndmask_b32_e64 v151, 0x7f800000, v151, s5               // 0000001B87F8: D5010097 00172EFF 7F800000
	v_cndmask_b32_e64 v145, 0x7f800000, v145, s7               // 0000001B8804: D5010091 001F22FF 7F800000
	v_mul_f32_e32 v44, v44, v148                               // 0000001B8810: 1059292C
	v_cndmask_b32_e64 v149, 0x7f800000, v149, s3               // 0000001B8814: D5010095 000F2AFF 7F800000
	v_cndmask_b32_e64 v147, 0, v147, s0                        // 0000001B8820: D5010093 00032680
	.long 0xd41e0000                                           // 0000001B8828: D41E0000
	v_cndmask_b32_e32 v1, 0x42b17218, v159, vcc_lo             // 0000001B882C: 02033EFF 42B17218
	v_dual_mul_f32 v57, v57, v145 :: v_dual_mul_f32 v20, v20, v148// 0000001B8834: C8C72339 39152914
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B883C: BF870194
	v_dual_mul_f32 v61, v61, v149 :: v_dual_mul_f32 v24, v24, v152// 0000001B8840: C8C72B3D 3D193118
	v_cndmask_b32_e64 v147, 0x7f800000, v147, s0               // 0000001B8848: D5010093 000326FF 7F800000
	v_dual_mul_f32 v63, v63, v151 :: v_dual_mul_f32 v10, v10, v146// 0000001B8854: C8C72F3F 3F0B250A
	v_dual_mul_f32 v49, v49, v145 :: v_dual_mul_f32 v12, v12, v148// 0000001B885C: C8C72331 310D290C
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B8864: BF870003
	v_dual_mul_f32 v59, v59, v147 :: v_dual_mul_f32 v22, v22, v150// 0000001B8868: C8C7273B 3B172D16
	v_dual_mul_f32 v51, v51, v147 :: v_dual_mul_f32 v14, v14, v150// 0000001B8870: C8C72733 330F2D0E
	v_dual_mul_f32 v53, v53, v149 :: v_dual_mul_f32 v16, v16, v152// 0000001B8878: C8C72B35 35113110
	v_dual_mul_f32 v55, v55, v151 :: v_dual_mul_f32 v2, v2, v146// 0000001B8880: C8C72F37 37032502
	v_dual_mul_f32 v41, v41, v145 :: v_dual_mul_f32 v4, v4, v148// 0000001B8888: C8C72329 29052904
	v_dual_mul_f32 v43, v43, v147 :: v_dual_mul_f32 v6, v6, v150// 0000001B8890: C8C7272B 2B072D06
	v_dual_mul_f32 v45, v45, v149 :: v_dual_mul_f32 v8, v8, v152// 0000001B8898: C8C72B2D 2D093108
	v_dual_mul_f32 v47, v47, v151 :: v_dual_fmac_f32 v212, v234, v148// 0000001B88A0: C8C12F2F 2FD529EA
	v_dual_mul_f32 v33, v33, v145 :: v_dual_fmac_f32 v236, v232, v152// 0000001B88A8: C8C12321 21ED31E8
	v_mul_f32_e32 v35, v35, v147                               // 0000001B88B0: 10472723
	v_dual_mul_f32 v37, v37, v149 :: v_dual_mul_f32 v38, v38, v150// 0000001B88B4: C8C72B25 25272D26
	v_mul_f32_e32 v39, v39, v151                               // 0000001B88BC: 104F2F27
	v_mul_f32_e32 v25, v25, v145                               // 0000001B88C0: 10332319
	v_mul_f32_e32 v27, v27, v147                               // 0000001B88C4: 1037271B
	v_mul_f32_e32 v29, v29, v149                               // 0000001B88C8: 103B2B1D
	v_mul_f32_e32 v31, v31, v151                               // 0000001B88CC: 103F2F1F
	v_mul_f32_e32 v17, v17, v145                               // 0000001B88D0: 10232311
	v_mul_f32_e32 v19, v19, v147                               // 0000001B88D4: 10272713
	v_mul_f32_e32 v21, v21, v149                               // 0000001B88D8: 102B2B15
	v_mul_f32_e32 v23, v23, v151                               // 0000001B88DC: 102F2F17
	v_mul_f32_e32 v9, v9, v145                                 // 0000001B88E0: 10132309
	v_mul_f32_e32 v11, v11, v147                               // 0000001B88E4: 1017270B
	v_mul_f32_e32 v13, v13, v149                               // 0000001B88E8: 101B2B0D
	v_mul_f32_e32 v15, v15, v151                               // 0000001B88EC: 101F2F0F
	v_mul_f32_e32 v1, v1, v145                                 // 0000001B88F0: 10032301
	v_mul_f32_e32 v3, v3, v147                                 // 0000001B88F4: 10072703
	v_mul_f32_e32 v5, v5, v149                                 // 0000001B88F8: 100B2B05
	v_mul_f32_e32 v7, v7, v151                                 // 0000001B88FC: 100F2F07
	v_fma_f32 v205, v205, v145, v153                           // 0000001B8900: D61300CD 066723CD
	v_fma_f32 v207, v207, v147, v154                           // 0000001B8908: D61300CF 066B27CF
	v_fma_f32 v206, v206, v149, v155                           // 0000001B8910: D61300CE 066F2BCE
	v_fma_f32 v226, v226, v151, v156                           // 0000001B8918: D61300E2 06732FE2
	v_fmac_f32_e32 v213, v235, v146                            // 0000001B8920: 57AB25EB
	v_fmac_f32_e32 v211, v233, v150                            // 0000001B8924: 57A72DE9
	s_waitcnt vmcnt(19) lgkmcnt(0)                             // 0000001B8928: BF894C07
	v_wmma_f32_16x16x16_bf16 v[57:64], v[73:80], v[81:88], v[57:64]// 0000001B892C: CC414039 1CE6A349
	s_waitcnt vmcnt(18)                                        // 0000001B8934: BF894BF7
	v_wmma_f32_16x16x16_bf16 v[49:56], v[73:80], v[89:96], v[49:56]// 0000001B8938: CC414031 1CC6B349
	s_waitcnt vmcnt(17)                                        // 0000001B8940: BF8947F7
	v_wmma_f32_16x16x16_bf16 v[41:48], v[73:80], v[97:104], v[41:48]// 0000001B8944: CC414029 1CA6C349
	s_waitcnt vmcnt(16)                                        // 0000001B894C: BF8943F7
	v_wmma_f32_16x16x16_bf16 v[33:40], v[73:80], v[105:112], v[33:40]// 0000001B8950: CC414021 1C86D349
	s_waitcnt vmcnt(3)                                         // 0000001B8958: BF890FF7
	v_wmma_f32_16x16x16_bf16 v[25:32], v[73:80], v[113:120], v[25:32]// 0000001B895C: CC414019 1C66E349
	s_waitcnt vmcnt(2)                                         // 0000001B8964: BF890BF7
	v_wmma_f32_16x16x16_bf16 v[17:24], v[73:80], v[121:128], v[17:24]// 0000001B8968: CC414011 1C46F349
	s_waitcnt vmcnt(1)                                         // 0000001B8970: BF8907F7
	v_wmma_f32_16x16x16_bf16 v[9:16], v[73:80], v[129:136], v[9:16]// 0000001B8974: CC414009 1C270349
	s_waitcnt vmcnt(0)                                         // 0000001B897C: BF8903F7
	v_wmma_f32_16x16x16_bf16 v[1:8], v[73:80], v[137:144], v[1:8]// 0000001B8980: CC414001 1C071349
	s_barrier                                                  // 0000001B8988: BFBD0000
	buffer_gl0_inv                                             // 0000001B898C: E0AC0000 00000000
	s_cbranch_scc1 64476                                       // 0000001B8994: BFA2FBDC <_ZN7halogen12_GLOBAL__N_113k_attn_qs_bt2ILi0ELi1EEEvPKtS3_S3_S3_PtPKiiS6_S6_i+0x608>
	v_mov_b32_e32 v8, v210                                     // 0000001B8998: 7E1003D2
	s_mul_i32 s0, s20, 12                                      // 0000001B899C: 96008C14
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B89A0: BF870001
	v_or_b32_e32 v7, v8, v208                                  // 0000001B89A4: 380FA108
	v_or_b32_e32 v0, s0, v209                                  // 0000001B89A8: 3801A200
	v_mov_b32_dpp v78, v211 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B89AC: 7E9C02FA FF0961D3
	v_mov_b32_dpp v75, v212 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B89B4: 7E9602FA FF0961D4
	v_mov_b32_dpp v74, v207 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B89BC: 7E9402FA FF0961CF
	v_mov_b32_dpp v76, v206 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B89C4: 7E9802FA FF0961CE
	v_lshlrev_b32_e32 v0, 8, v0                                // 0000001B89CC: 30000088
	v_mov_b32_e32 v8, 0                                        // 0000001B89D0: 7E100280
	v_dual_add_f32 v78, v211, v78 :: v_dual_add_f32 v81, v212, v75// 0000001B89D4: C9089DD3 4E5097D4
	v_add_f32_e32 v83, v207, v74                               // 0000001B89DC: 06A695CF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B89E0: BF870214
	v_add_nc_u32_e32 v23, 0x400, v0                            // 0000001B89E4: 4A2E00FF 00000400
	v_mad_i64_i32 v[7:8], null, 0x1800, s2, v[7:8]             // 0000001B89EC: D6FF7C07 041C04FF 00001800
	v_ashrrev_i32_e32 v16, 31, v0                              // 0000001B89F8: 3420009F
	v_add_nc_u32_e32 v31, 0x600, v0                            // 0000001B89FC: 4A3E00FF 00000600
	v_add_nc_u32_e32 v39, 0x800, v0                            // 0000001B8A04: 4A4E00FF 00000800
	v_ashrrev_i32_e32 v24, 31, v23                             // 0000001B8A0C: 34302E9F
	v_or_b32_e32 v65, 0x200, v0                                // 0000001B8A10: 388200FF 00000200
	v_add_f32_dpp v81, v81, v81 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8A18: 06A2A2FA FF096251
	v_ashrrev_i32_e32 v32, 31, v31                             // 0000001B8A20: 34403E9F
	.long 0xd7006a0f                                           // 0000001B8A24: D7006A0F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000001B8A28: 02020107
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001B8A2C: BF8700A1
	v_add_co_ci_u32_e64 v16, null, v8, v16, vcc_lo             // 0000001B8A30: D5207C10 01AA2108
	.long 0xd7006a17                                           // 0000001B8A38: D7006A17
	v_cndmask_b32_e32 v1, v7, v23, vcc_lo                      // 0000001B8A3C: 02022F07
	v_add_co_ci_u32_e64 v24, null, v8, v24, vcc_lo             // 0000001B8A40: D5207C18 01AA3108
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001B8A48: BF870233
	.long 0xd73c000f                                           // 0000001B8A4C: D73C000F
	v_cndmask_b32_e32 v1, 1, v15, vcc_lo                       // 0000001B8A50: 02021E81
	v_add_nc_u32_e32 v0, 0xa00, v0                             // 0000001B8A54: 4A0000FF 00000A00
	v_ashrrev_i32_e32 v40, 31, v39                             // 0000001B8A5C: 34504E9F
	.long 0xd73c0017                                           // 0000001B8A60: D73C0017
	v_cndmask_b32_e32 v1, 1, v23, vcc_lo                       // 0000001B8A64: 02022E81
	v_ashrrev_i32_e32 v66, 31, v65                             // 0000001B8A68: 3484829F
	v_add_f32_dpp v78, v78, v78 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8A6C: 069C9CFA FF09624E
	.long 0xd7006a45                                           // 0000001B8A74: D7006A45
	v_cndmask_b32_e32 v1, s10, v15, vcc_lo                     // 0000001B8A78: 02021E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001B8A7C: BF8700A1
	v_add_co_ci_u32_e64 v70, null, s11, v16, vcc_lo            // 0000001B8A80: D5207C46 01AA200B
	.long 0xd7006a1f                                           // 0000001B8A88: D7006A1F
	v_cndmask_b32_e32 v1, v7, v31, vcc_lo                      // 0000001B8A8C: 02023F07
	v_add_co_ci_u32_e64 v32, null, v8, v32, vcc_lo             // 0000001B8A90: D5207C20 01AA4108
	.long 0xd7006a37                                           // 0000001B8A98: D7006A37
	v_cndmask_b32_e32 v1, s10, v23, vcc_lo                     // 0000001B8A9C: 02022E0A
	v_ashrrev_i32_e32 v48, 31, v0                              // 0000001B8AA0: 3460009F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001B8AA4: BF8700B3
	.long 0xd73c001f                                           // 0000001B8AA8: D73C001F
	v_cndmask_b32_e32 v1, 1, v31, vcc_lo                       // 0000001B8AAC: 02023E81
	v_add_co_ci_u32_e64 v56, null, s11, v24, vcc_lo            // 0000001B8AB0: D5207C38 01AA300B
	.long 0xd7006a27                                           // 0000001B8AB8: D7006A27
	v_cndmask_b32_e32 v1, v7, v39, vcc_lo                      // 0000001B8ABC: 02024F07
	v_add_co_ci_u32_e64 v40, null, v8, v40, vcc_lo             // 0000001B8AC0: D5207C28 01AA5108
	.long 0xd7006a2f                                           // 0000001B8AC8: D7006A2F
	v_cndmask_b32_e32 v1, v7, v0, vcc_lo                       // 0000001B8ACC: 02020107
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B8AD0: BF870001
	v_add_co_ci_u32_e64 v48, null, v8, v48, vcc_lo             // 0000001B8AD4: D5207C30 01AA6108
	.long 0xd7006a3f                                           // 0000001B8ADC: D7006A3F
	v_cndmask_b32_e32 v1, s10, v31, vcc_lo                     // 0000001B8AE0: 02023E0A
	global_load_u16 v73, v[69:70], off offset:1024             // 0000001B8AE4: DC4A0400 497C0045
	v_add_co_ci_u32_e64 v64, null, s11, v32, vcc_lo            // 0000001B8AEC: D5207C40 01AA400B
	.long 0xd7006a07                                           // 0000001B8AF4: D7006A07
	v_cndmask_b32_e32 v1, v7, v65, vcc_lo                      // 0000001B8AF8: 02028307
	s_clause 0x2                                               // 0000001B8AFC: BF850002
	global_load_u16 v80, v[69:70], off                         // 0000001B8B00: DC4A0000 507C0045
	global_load_u16 v82, v[69:70], off offset:32               // 0000001B8B08: DC4A0020 527C0045
	global_load_u16 v103, v[69:70], off offset:64              // 0000001B8B10: DC4A0040 677C0045
	v_add_co_ci_u32_e64 v8, null, v8, v66, vcc_lo              // 0000001B8B18: D5207C08 01AA8508
	.long 0xd73c0027                                           // 0000001B8B20: D73C0027
	v_cndmask_b32_e32 v1, 1, v39, vcc_lo                       // 0000001B8B24: 02024E81
	.long 0xd73c002f                                           // 0000001B8B28: D73C002F
	v_cndmask_b32_e32 v1, 1, v47, vcc_lo                       // 0000001B8B2C: 02025E81
	v_add_f32_dpp v83, v83, v83 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8B30: 06A6A6FA FF096253
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001B8B38: BF8700C4
	.long 0xd73c0056                                           // 0000001B8B3C: D73C0056
	v_cndmask_b32_e32 v1, 1, v7, vcc_lo                        // 0000001B8B40: 02020E81
	v_mov_b32_dpp v8, v213 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8B44: 7E1002FA FF0961D5
	v_mov_b32_dpp v7, v205 row_xmask:1 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8B4C: 7E0E02FA FF0961CD
	.long 0xd7006a43                                           // 0000001B8B54: D7006A43
	v_cndmask_b32_e32 v1, s10, v39, vcc_lo                     // 0000001B8B58: 02024E0A
	v_add_co_ci_u32_e64 v68, null, s11, v40, vcc_lo            // 0000001B8B5C: D5207C44 01AA500B
	.long 0xd7006a41                                           // 0000001B8B64: D7006A41
	v_cndmask_b32_e32 v1, s10, v47, vcc_lo                     // 0000001B8B68: 02025E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001B8B6C: BF8700A1
	v_add_co_ci_u32_e64 v66, null, s11, v48, vcc_lo            // 0000001B8B70: D5207C42 01AA600B
	.long 0xd7006a47                                           // 0000001B8B78: D7006A47
	v_cndmask_b32_e32 v1, s10, v86, vcc_lo                     // 0000001B8B7C: 0202AC0A
	v_add_co_ci_u32_e64 v72, null, s11, v87, vcc_lo            // 0000001B8B80: D5207C48 01AAAE0B
	s_clause 0x9                                               // 0000001B8B88: BF850009
	global_load_u16 v99, v[63:64], off                         // 0000001B8B8C: DC4A0000 637C003F
	global_load_u16 v98, v[55:56], off                         // 0000001B8B94: DC4A0000 627C0037
	global_load_u16 v101, v[65:66], off                        // 0000001B8B9C: DC4A0000 657C0041
	global_load_u16 v100, v[67:68], off                        // 0000001B8BA4: DC4A0000 647C0043
	global_load_u16 v102, v[71:72], off offset:32              // 0000001B8BAC: DC4A0020 667C0047
	global_load_u16 v94, v[63:64], off offset:32               // 0000001B8BB4: DC4A0020 5E7C003F
	global_load_u16 v93, v[55:56], off offset:32               // 0000001B8BBC: DC4A0020 5D7C0037
	global_load_u16 v96, v[65:66], off offset:32               // 0000001B8BC4: DC4A0020 607C0041
	global_load_u16 v95, v[67:68], off offset:32               // 0000001B8BCC: DC4A0020 5F7C0043
	global_load_u16 v97, v[71:72], off offset:64               // 0000001B8BD4: DC4A0040 617C0047
	v_add_f32_e32 v8, v213, v8                                 // 0000001B8BDC: 061011D5
	v_add_f32_e32 v7, v205, v7                                 // 0000001B8BE0: 060E0FCD
	v_add_f32_dpp v83, v83, v83 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8BE4: 06A6A6FA FF096453
	v_add_f32_dpp v81, v81, v81 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8BEC: 06A2A2FA FF096451
	v_add_f32_dpp v78, v78, v78 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8BF4: 069C9CFA FF09644E
	v_add_f32_dpp v8, v8, v8 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8BFC: 061010FA FF096208
	v_add_f32_dpp v7, v7, v7 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8C04: 060E0EFA FF096207
	v_add_f32_dpp v89, v83, v83 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8C0C: 06B2A6FA FF096853
	v_add_f32_dpp v88, v81, v81 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8C14: 06B0A2FA FF096851
	v_add_f32_dpp v81, v78, v78 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8C1C: 06A29CFA FF09684E
	v_add_f32_dpp v8, v8, v8 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8C24: 061010FA FF096408
	v_add_f32_dpp v7, v7, v7 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8C2C: 060E0EFA FF096407
	v_div_scale_f32 v109, null, v89, v89, 1.0                  // 0000001B8C34: D6FC7C6D 03CAB359
	v_div_scale_f32 v110, null, v88, v88, 1.0                  // 0000001B8C3C: D6FC7C6E 03CAB158
	v_div_scale_f32 v115, null, v81, v81, 1.0                  // 0000001B8C44: D6FC7C73 03CAA351
	v_add_f32_dpp v107, v8, v8 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8C4C: 06D610FA FF096808
	v_add_f32_dpp v108, v7, v7 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8C54: 06D80EFA FF096807
	.long 0xd7000507                                           // 0000001B8C5C: D7000507
	v_cndmask_b32_e32 v1, s12, v15, vcc_lo                     // 0000001B8C60: 02021E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001B8C64: BF8700B1
	v_add_co_ci_u32_e64 v8, null, s13, v16, s5                 // 0000001B8C68: D5207C08 0016200D
	v_rcp_f32_e32 v91, v109                                    // 0000001B8C70: 7EB6556D
	.long 0xd700050f                                           // 0000001B8C74: D700050F
	v_cndmask_b32_e32 v1, s12, v23, vcc_lo                     // 0000001B8C78: 02022E0C
	v_add_co_ci_u32_e64 v16, null, s13, v24, s5                // 0000001B8C7C: D5207C10 0016300D
	.long 0xd7000517                                           // 0000001B8C84: D7000517
	v_cndmask_b32_e32 v1, s12, v31, vcc_lo                     // 0000001B8C88: 02023E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001B8C8C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, s13, v32, s5                // 0000001B8C90: D5207C18 0016400D
	.long 0xd700051f                                           // 0000001B8C98: D700051F
	v_cndmask_b32_e32 v1, s12, v39, vcc_lo                     // 0000001B8C9C: 02024E0C
	v_add_co_ci_u32_e64 v32, null, s13, v40, s5                // 0000001B8CA0: D5207C20 0016500D
	.long 0xd7000527                                           // 0000001B8CA8: D7000527
	v_cndmask_b32_e32 v1, s12, v47, vcc_lo                     // 0000001B8CAC: 02025E0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001B8CB0: BF8700A1
	v_add_co_ci_u32_e64 v40, null, s13, v48, s5                // 0000001B8CB4: D5207C28 0016600D
	.long 0xd700052f                                           // 0000001B8CBC: D700052F
	v_cndmask_b32_e32 v1, s12, v86, vcc_lo                     // 0000001B8CC0: 0202AC0C
	v_add_co_ci_u32_e64 v48, null, s13, v87, s5                // 0000001B8CC4: D5207C30 0016AE0D
	s_clause 0x1f                                              // 0000001B8CCC: BF85001F
	global_load_u16 v78, v[69:70], off offset:96               // 0000001B8CD0: DC4A0060 4E7C0045
	global_load_u16 v86, v[69:70], off offset:128              // 0000001B8CD8: DC4A0080 567C0045
	global_load_u16 v87, v[69:70], off offset:160              // 0000001B8CE0: DC4A00A0 577C0045
	global_load_u16 v92, v[69:70], off offset:192              // 0000001B8CE8: DC4A00C0 5C7C0045
	global_load_u16 v69, v[69:70], off offset:224              // 0000001B8CF0: DC4A00E0 457C0045
	global_load_u16 v138, v[55:56], off offset:64              // 0000001B8CF8: DC4A0040 8A7C0037
	global_load_u16 v133, v[55:56], off offset:96              // 0000001B8D00: DC4A0060 857C0037
	global_load_u16 v128, v[55:56], off offset:128             // 0000001B8D08: DC4A0080 807C0037
	global_load_u16 v124, v[55:56], off offset:160             // 0000001B8D10: DC4A00A0 7C7C0037
	global_load_u16 v104, v[55:56], off offset:192             // 0000001B8D18: DC4A00C0 687C0037
	global_load_u16 v137, v[63:64], off offset:64              // 0000001B8D20: DC4A0040 897C003F
	global_load_u16 v132, v[63:64], off offset:96              // 0000001B8D28: DC4A0060 847C003F
	global_load_u16 v127, v[63:64], off offset:128             // 0000001B8D30: DC4A0080 7F7C003F
	global_load_u16 v123, v[63:64], off offset:160             // 0000001B8D38: DC4A00A0 7B7C003F
	global_load_u16 v70, v[63:64], off offset:192              // 0000001B8D40: DC4A00C0 467C003F
	global_load_u16 v56, v[55:56], off offset:224              // 0000001B8D48: DC4A00E0 387C0037
	global_load_u16 v140, v[67:68], off offset:64              // 0000001B8D50: DC4A0040 8C7C0043
	global_load_u16 v135, v[67:68], off offset:96              // 0000001B8D58: DC4A0060 877C0043
	global_load_u16 v130, v[67:68], off offset:128             // 0000001B8D60: DC4A0080 827C0043
	global_load_u16 v126, v[67:68], off offset:160             // 0000001B8D68: DC4A00A0 7E7C0043
	global_load_u16 v106, v[67:68], off offset:192             // 0000001B8D70: DC4A00C0 6A7C0043
	global_load_u16 v55, v[63:64], off offset:224              // 0000001B8D78: DC4A00E0 377C003F
	global_load_u16 v139, v[65:66], off offset:64              // 0000001B8D80: DC4A0040 8B7C0041
	global_load_u16 v134, v[65:66], off offset:96              // 0000001B8D88: DC4A0060 867C0041
	global_load_u16 v129, v[65:66], off offset:128             // 0000001B8D90: DC4A0080 817C0041
	global_load_u16 v125, v[65:66], off offset:160             // 0000001B8D98: DC4A00A0 7D7C0041
	global_load_u16 v105, v[65:66], off offset:192             // 0000001B8DA0: DC4A00C0 697C0041
	global_load_u16 v63, v[67:68], off offset:224              // 0000001B8DA8: DC4A00E0 3F7C0043
	global_load_u16 v141, v[71:72], off offset:96              // 0000001B8DB0: DC4A0060 8D7C0047
	global_load_u16 v136, v[71:72], off offset:128             // 0000001B8DB8: DC4A0080 887C0047
	global_load_u16 v131, v[71:72], off offset:160             // 0000001B8DC0: DC4A00A0 837C0047
	global_load_u16 v68, v[71:72], off offset:192              // 0000001B8DC8: DC4A00C0 447C0047
	s_clause 0x1                                               // 0000001B8DD0: BF850001
	global_load_u16 v67, v[71:72], off offset:224              // 0000001B8DD4: DC4A00E0 437C0047
	global_load_u16 v64, v[65:66], off offset:224              // 0000001B8DDC: DC4A00E0 407C0041
	v_fma_f32 v71, -v109, v91, 1.0                             // 0000001B8DE4: D6130047 23CAB76D
	v_add_f32_e32 v84, v206, v76                               // 0000001B8DEC: 06A899CE
	v_div_scale_f32 v117, null, v108, v108, 1.0                // 0000001B8DF0: D6FC7C75 03CAD96C
	v_div_scale_f32 v118, null, v107, v107, 1.0                // 0000001B8DF8: D6FC7C76 03CAD76B
	v_rcp_f32_e32 v90, v110                                    // 0000001B8E00: 7EB4556E
	v_fmac_f32_e32 v91, v71, v91                               // 0000001B8E04: 56B6B747
	v_add_f32_dpp v84, v84, v84 row_xmask:2 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8E08: 06A8A8FA FF096254
	v_rcp_f32_e32 v122, v117                                   // 0000001B8E10: 7EF45575
	v_rcp_f32_e32 v121, v118                                   // 0000001B8E14: 7EF25576
	v_div_scale_f32 v119, vcc_lo, 1.0, v108, 1.0               // 0000001B8E18: D6FC6A77 03CAD8F2
	v_div_scale_f32 v120, s4, 1.0, v107, 1.0                   // 0000001B8E20: D6FC0478 03CAD6F2
	v_add_f32_dpp v84, v84, v84 row_xmask:4 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8E28: 06A8A8FA FF096454
	v_div_scale_f32 v112, s2, 1.0, v89, 1.0                    // 0000001B8E30: D6FC0270 03CAB2F2
	v_div_scale_f32 v116, s1, 1.0, v81, 1.0                    // 0000001B8E38: D6FC0174 03CAA2F2
	v_fma_f32 v72, -v110, v90, 1.0                             // 0000001B8E40: D6130048 23CAB56E
	v_div_scale_f32 v113, s3, 1.0, v88, 1.0                    // 0000001B8E48: D6FC0371 03CAB0F2
	v_add_f32_dpp v83, v84, v84 row_xmask:8 row_mask:0xf bank_mask:0xf bound_ctrl:1// 0000001B8E50: 06A6A8FA FF096854
	v_fma_f32 v65, -v117, v122, 1.0                            // 0000001B8E58: D6130041 23CAF575
	v_fma_f32 v66, -v118, v121, 1.0                            // 0000001B8E60: D6130042 23CAF376
	v_fmac_f32_e32 v90, v72, v90                               // 0000001B8E68: 56B4B548
	v_rcp_f32_e32 v84, v115                                    // 0000001B8E6C: 7EA85573
	v_div_scale_f32 v111, null, v83, v83, 1.0                  // 0000001B8E70: D6FC7C6F 03CAA753
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001B8E78: BF870233
	v_dual_fmac_f32 v122, v65, v122 :: v_dual_fmac_f32 v121, v66, v121// 0000001B8E7C: C800F541 7A78F342
	v_div_scale_f32 v114, s0, 1.0, v83, 1.0                    // 0000001B8E84: D6FC0072 03CAA6F2
	v_dual_mul_f32 v71, v112, v91 :: v_dual_mul_f32 v72, v113, v90// 0000001B8E8C: C8C6B770 4748B571
	v_rcp_f32_e32 v85, v111                                    // 0000001B8E94: 7EAA556F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001B8E98: BF870313
	v_dual_mul_f32 v65, v119, v122 :: v_dual_mul_f32 v66, v120, v121// 0000001B8E9C: C8C6F577 4142F378
	v_fma_f32 v143, -v115, v84, 1.0                            // 0000001B8EA4: D613008F 23CAA973
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B8EAC: BF870223
	v_fma_f32 v146, -v109, v71, v112                           // 0000001B8EB0: D6130092 25C28F6D
	v_fma_f32 v147, -v110, v72, v113                           // 0000001B8EB8: D6130093 25C6916E
	v_fma_f32 v144, -v117, v65, v119                           // 0000001B8EC0: D6130090 25DE8375
	v_fma_f32 v145, -v118, v66, v120                           // 0000001B8EC8: D6130091 25E28576
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B8ED0: BF870214
	v_dual_fmac_f32 v84, v143, v84 :: v_dual_fmac_f32 v71, v146, v91// 0000001B8ED4: C800A98F 5446B792
	v_fmac_f32_e32 v72, v147, v90                              // 0000001B8EDC: 5690B593
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B8EE0: BF870215
	v_fma_f32 v142, -v111, v85, 1.0                            // 0000001B8EE4: D613008E 23CAAB6F
	v_dual_fmac_f32 v65, v144, v122 :: v_dual_fmac_f32 v66, v145, v121// 0000001B8EEC: C800F590 4142F391
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B8EF4: BF870224
	v_mul_f32_e32 v143, v116, v84                              // 0000001B8EF8: 111EA974
	v_fma_f32 v109, -v109, v71, v112                           // 0000001B8EFC: D613006D 25C28F6D
	v_fmac_f32_e32 v85, v142, v85                              // 0000001B8F04: 56AAAB8E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B8F08: BF870004
	v_fma_f32 v117, -v117, v65, v119                           // 0000001B8F0C: D6130075 25DE8375
	v_fma_f32 v118, -v118, v66, v120                           // 0000001B8F14: D6130076 25E28576
	v_fma_f32 v144, -v115, v143, v116                          // 0000001B8F1C: D6130090 25D31F73
	.long 0x7f003880                                           // 0000001B8F24: 7F003880
	v_mul_f32_e32 v142, v114, v85                              // 0000001B8F28: 111CAB72
	v_div_fmas_f32 v65, v117, v122, v65                        // 0000001B8F2C: D6370041 0506F575
	s_mov_b32 vcc_lo, s4                                       // 0000001B8F34: BEEA0004
	v_div_fmas_f32 v117, v118, v121, v66                       // 0000001B8F38: D6370075 050AF376
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B8F40: BF870193
	v_fma_f32 v148, -v111, v142, v114                          // 0000001B8F44: D6130094 25CB1D6F
	v_div_fixup_f32 v66, v65, v108, 1.0                        // 0000001B8F4C: D6270042 03CAD941
	v_fma_f32 v108, -v110, v72, v113                           // 0000001B8F54: D613006C 25C6916E
	.long 0x7f9e3980                                           // 0000001B8F5C: 7F9E3980
	v_div_fixup_f32 v65, v117, v107, 1.0                       // 0000001B8F60: D6270041 03CAD775
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001B8F68: BF870234
	v_dual_fmac_f32 v142, v148, v85 :: v_dual_mul_f32 v57, v57, v66// 0000001B8F6C: C806AB94 8E388539
	v_fmac_f32_e32 v143, v144, v84                             // 0000001B8F74: 571EA990
	.long 0x7f983980                                           // 0000001B8F78: 7F983980
	v_mul_f32_e32 v58, v58, v65                                // 0000001B8F7C: 1074833A
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B8F80: BF870004
	v_fma_f32 v107, -v111, v142, v114                          // 0000001B8F84: D613006B 25CB1D6F
	v_mul_f32_e32 v111, v49, v66                               // 0000001B8F8C: 10DE8531
	v_fma_f32 v110, -v115, v143, v116                          // 0000001B8F90: D613006E 25D31F73
	.long 0x7f9a3980                                           // 0000001B8F98: 7F9A3980
	.long 0x7f963980                                           // 0000001B8F9C: 7F963980
	.long 0x7f943980                                           // 0000001B8FA0: 7F943980
	v_dual_mul_f32 v33, v33, v66 :: v_dual_mul_f32 v26, v26, v65// 0000001B8FA4: C8C68521 211A831A
	v_mul_f32_e32 v25, v25, v66                                // 0000001B8FAC: 10328519
	v_mul_f32_e32 v17, v17, v66                                // 0000001B8FB0: 10228511
	v_mul_f32_e32 v9, v9, v66                                  // 0000001B8FB4: 10128509
	v_dual_mul_f32 v1, v1, v66 :: v_dual_mul_f32 v18, v18, v65 // 0000001B8FB8: C8C68501 01128312
	v_mul_f32_e32 v42, v42, v65                                // 0000001B8FC0: 1054832A
	v_mul_f32_e32 v34, v34, v65                                // 0000001B8FC4: 10448322
	v_mul_f32_e32 v10, v10, v65                                // 0000001B8FC8: 1014830A
	v_mul_f32_e32 v2, v2, v65                                  // 0000001B8FCC: 10048302
	s_waitcnt vmcnt(47)                                        // 0000001B8FD0: BF89BFF7
	v_lshlrev_b32_e32 v73, 16, v73                             // 0000001B8FD4: 30929290
	s_waitcnt vmcnt(46)                                        // 0000001B8FD8: BF89BBF7
	v_dual_mul_f32 v80, v50, v65 :: v_dual_lshlrev_b32 v49, 16, v80// 0000001B8FDC: C8E28332 5030A090
	s_waitcnt vmcnt(45)                                        // 0000001B8FE4: BF89B7F7
	v_lshlrev_b32_e32 v50, 16, v82                             // 0000001B8FE8: 3064A490
	s_waitcnt vmcnt(44)                                        // 0000001B8FEC: BF89B3F7
	v_lshlrev_b32_e32 v82, 16, v103                            // 0000001B8FF0: 30A4CE90
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B8FF4: BF870001
	v_mul_f32_e32 v114, 0xbfb8aa3b, v82                        // 0000001B8FF8: 10E4A4FF BFB8AA3B
	v_mul_f32_e32 v112, 0xbfb8aa3b, v73                        // 0000001B9000: 10E092FF BFB8AA3B
	v_mul_f32_e32 v103, 0xbfb8aa3b, v49                        // 0000001B9008: 10CE62FF BFB8AA3B
	v_mul_f32_e32 v113, 0xbfb8aa3b, v50                        // 0000001B9010: 10E264FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v49                  // 0000001B9018: 7C3C62FF 42CE8ED0
	v_rndne_f32_e32 v152, v114                                 // 0000001B9020: 7F304772
	v_fma_f32 v117, 0xbfb8aa3b, v73, -v112                     // 0000001B9024: D6130075 85C292FF BFB8AA3B
	v_fma_f32 v115, 0xbfb8aa3b, v49, -v103                     // 0000001B9030: D6130073 859E62FF BFB8AA3B
	v_rndne_f32_e32 v116, v103                                 // 0000001B903C: 7EE84767
	s_waitcnt vmcnt(40)                                        // 0000001B9040: BF89A3F7
	v_lshlrev_b32_e32 v100, 16, v100                           // 0000001B9044: 30C8C890
	v_lshlrev_b32_e32 v98, 16, v98                             // 0000001B9048: 30C4C490
	v_rndne_f32_e32 v118, v112                                 // 0000001B904C: 7EEC4770
	v_lshlrev_b32_e32 v101, 16, v101                           // 0000001B9050: 30CACA90
	v_lshlrev_b32_e32 v99, 16, v99                             // 0000001B9054: 30C6C690
	s_waitcnt vmcnt(37)                                        // 0000001B9058: BF8997F7
	v_lshlrev_b32_e32 v93, 16, v93                             // 0000001B905C: 30BABA90
	v_dual_mul_f32 v121, 0xbfb8aa3b, v100 :: v_dual_lshlrev_b32 v102, 16, v102// 0000001B9060: C8E2C8FF 7966CC90 BFB8AA3B
	v_mul_f32_e32 v119, 0xbfb8aa3b, v98                        // 0000001B906C: 10EEC4FF BFB8AA3B
	v_fma_f32 v151, 0xbfb8aa3b, v82, -v114                     // 0000001B9074: D6130097 85CAA4FF BFB8AA3B
	v_dual_fmac_f32 v115, 0xb2a5705f, v49 :: v_dual_sub_f32 v112, v112, v118// 0000001B9080: C80A62FF 7370ED70 B2A5705F
	v_dual_fmac_f32 v117, 0xb2a5705f, v73 :: v_dual_sub_f32 v114, v114, v152// 0000001B908C: C80A92FF 75733172 B2A5705F
	v_dual_sub_f32 v103, v103, v116 :: v_dual_mul_f32 v122, 0xbfb8aa3b, v101// 0000001B9098: C946E967 677ACAFF BFB8AA3B
	v_mul_f32_e32 v120, 0xbfb8aa3b, v99                        // 0000001B90A4: 10F0C6FF BFB8AA3B
	v_fma_f32 v145, 0xbfb8aa3b, v50, -v113                     // 0000001B90AC: D6130091 85C664FF BFB8AA3B
	v_rndne_f32_e32 v146, v113                                 // 0000001B90B8: 7F244771
	v_dual_mul_f32 v147, 0xbfb8aa3b, v93 :: v_dual_mul_f32 v144, 0xbfb8aa3b, v102// 0000001B90BC: C8C6BAFF 9390CCFF BFB8AA3B
	v_fma_f32 v154, 0xbfb8aa3b, v98, -v119                     // 0000001B90C8: D613009A 85DEC4FF BFB8AA3B
	v_dual_add_f32 v112, v112, v117 :: v_dual_add_f32 v103, v103, v115// 0000001B90D4: C908EB70 7066E767
	v_fma_f32 v156, 0xbfb8aa3b, v99, -v120                     // 0000001B90DC: D613009C 85E2C6FF BFB8AA3B
	v_fma_f32 v158, 0xbfb8aa3b, v100, -v121                    // 0000001B90E8: D613009E 85E6C8FF BFB8AA3B
	v_rndne_f32_e32 v163, v144                                 // 0000001B90F4: 7F464790
	v_fmac_f32_e32 v145, 0xb2a5705f, v50                       // 0000001B90F8: 572264FF B2A5705F
	v_sub_f32_e32 v113, v113, v146                             // 0000001B9100: 08E32571
	v_fmac_f32_e32 v154, 0xb2a5705f, v98                       // 0000001B9104: 5734C4FF B2A5705F
	v_exp_f32_e32 v103, v103                                   // 0000001B910C: 7ECE4B67
	s_waitcnt vmcnt(35)                                        // 0000001B9110: BF898FF7
	v_lshlrev_b32_e32 v95, 16, v95                             // 0000001B9114: 30BEBE90
	s_waitcnt vmcnt(34)                                        // 0000001B9118: BF898BF7
	v_lshlrev_b32_e32 v97, 16, v97                             // 0000001B911C: 30C2C290
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000001B9120: 30C0C090
	v_cvt_i32_f32_e32 v116, v116                               // 0000001B9124: 7EE81174
	v_rndne_f32_e32 v155, v119                                 // 0000001B9128: 7F364777
	v_fma_f32 v160, 0xbfb8aa3b, v101, -v122                    // 0000001B912C: D61300A0 85EACAFF BFB8AA3B
	v_rndne_f32_e32 v161, v122                                 // 0000001B9138: 7F42477A
	v_fma_f32 v162, 0xbfb8aa3b, v102, -v144                    // 0000001B913C: D61300A2 8642CCFF BFB8AA3B
	v_fmac_f32_e32 v156, 0xb2a5705f, v99                       // 0000001B9148: 5738C6FF B2A5705F
	v_fmac_f32_e32 v158, 0xb2a5705f, v100                      // 0000001B9150: 573CC8FF B2A5705F
	v_dual_sub_f32 v144, v144, v163 :: v_dual_add_f32 v113, v113, v145// 0000001B9158: C9494790 90712371
	v_exp_f32_e32 v112, v112                                   // 0000001B9160: 7EE04B70
	v_dual_mul_f32 v149, 0xbfb8aa3b, v95 :: v_dual_lshlrev_b32 v94, 16, v94// 0000001B9164: C8E2BEFF 955EBC90 BFB8AA3B
	v_dual_mul_f32 v153, 0xbfb8aa3b, v97 :: v_dual_mul_f32 v150, 0xbfb8aa3b, v96// 0000001B9170: C8C6C2FF 9996C0FF BFB8AA3B
	v_cvt_i32_f32_e32 v118, v118                               // 0000001B917C: 7EEC1176
	v_rndne_f32_e32 v157, v120                                 // 0000001B9180: 7F3A4778
	v_dual_fmac_f32 v151, 0xb2a5705f, v82 :: v_dual_fmac_f32 v160, 0xb2a5705f, v101// 0000001B9184: C800A4FF 97A0CAFF B2A5705F
	v_dual_sub_f32 v115, v119, v155 :: v_dual_sub_f32 v122, v122, v161// 0000001B9190: C94B3777 737B437A
	v_exp_f32_e32 v113, v113                                   // 0000001B9198: 7EE24B71
	.long 0xd71c0067                                           // 0000001B919C: D71C0067
	v_cndmask_b32_e32 v1, v103, v116, vcc_lo                   // 0000001B91A0: 0202E967
	v_mul_f32_e32 v148, 0xbfb8aa3b, v94                        // 0000001B91A4: 1128BCFF BFB8AA3B
	v_rndne_f32_e32 v159, v121                                 // 0000001B91AC: 7F3E4779
	v_cvt_i32_f32_e32 v146, v146                               // 0000001B91B0: 7F241192
	v_fma_f32 v164, 0xbfb8aa3b, v93, -v147                     // 0000001B91B4: D61300A4 864EBAFF BFB8AA3B
	v_fma_f32 v168, 0xbfb8aa3b, v95, -v149                     // 0000001B91C0: D61300A8 8656BEFF BFB8AA3B
	v_fma_f32 v170, 0xbfb8aa3b, v96, -v150                     // 0000001B91CC: D61300AA 865AC0FF BFB8AA3B
	v_rndne_f32_e32 v171, v150                                 // 0000001B91D8: 7F564796
	v_dual_sub_f32 v119, v120, v157 :: v_dual_fmac_f32 v162, 0xb2a5705f, v102// 0000001B91DC: C9413B78 77A2CCFF B2A5705F
	v_dual_add_f32 v122, v122, v160 :: v_dual_cndmask_b32 v103, 0, v103// 0000001B91E8: C913417A 7A66CE80
	.long 0xd71c0070                                           // 0000001B91F0: D71C0070
	v_cndmask_b32_e32 v1, v112, v118, vcc_lo                   // 0000001B91F4: 0202ED70
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v73                  // 0000001B91F8: 7C3C92FF 42CE8ED0
	v_rndne_f32_e32 v165, v147                                 // 0000001B9200: 7F4A4793
	v_fma_f32 v166, 0xbfb8aa3b, v94, -v148                     // 0000001B9204: D61300A6 8652BCFF BFB8AA3B
	v_dual_sub_f32 v121, v121, v159 :: v_dual_fmac_f32 v164, 0xb2a5705f, v93// 0000001B9210: C9413F79 79A4BAFF B2A5705F
	v_dual_fmac_f32 v168, 0xb2a5705f, v95 :: v_dual_add_f32 v115, v115, v154// 0000001B921C: C808BEFF A8733573 B2A5705F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001B9228: BF870002
	v_dual_fmac_f32 v170, 0xb2a5705f, v96 :: v_dual_add_f32 v121, v121, v158// 0000001B922C: C808C0FF AA793D79 B2A5705F
	v_dual_sub_f32 v150, v150, v171 :: v_dual_add_f32 v119, v119, v156// 0000001B9238: C9495796 96773977
	.long 0xd71c0071                                           // 0000001B9240: D71C0071
	v_cndmask_b32_e32 v1, v113, v146, vcc_lo                   // 0000001B9244: 02032571
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 0000001B9248: 02E0E080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v50                  // 0000001B924C: 7C3C64FF 42CE8ED0
	v_dual_sub_f32 v145, v147, v165 :: v_dual_fmac_f32 v166, 0xb2a5705f, v94// 0000001B9254: C9414B93 91A6BCFF B2A5705F
	v_add_f32_e32 v144, v144, v162                             // 0000001B9260: 07214590
	v_dual_add_f32 v150, v150, v170 :: v_dual_cndmask_b32 v113, 0, v113// 0000001B9264: C9135596 9670E280
	v_exp_f32_e32 v115, v115                                   // 0000001B926C: 7EE64B73
	v_exp_f32_e32 v119, v119                                   // 0000001B9270: 7EEE4B77
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v49                  // 0000001B9274: 7C3662FF C2B17218
	v_cvt_i32_f32_e32 v117, v155                               // 0000001B927C: 7EEA119B
	v_cvt_i32_f32_e32 v120, v157                               // 0000001B9280: 7EF0119D
	v_add_f32_e32 v145, v145, v164                             // 0000001B9284: 07234991
	v_exp_f32_e32 v144, v144                                   // 0000001B9288: 7F204B90
	v_cndmask_b32_e32 v49, 0x7f800000, v103, vcc_lo            // 0000001B928C: 0262CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v73                  // 0000001B9294: 7C3692FF C2B17218
	v_cvt_i32_f32_e32 v155, v159                               // 0000001B929C: 7F36119F
	v_cvt_i32_f32_e32 v159, v163                               // 0000001B92A0: 7F3E11A3
	v_exp_f32_e32 v121, v121                                   // 0000001B92A4: 7EF24B79
	.long 0xd71c0073                                           // 0000001B92A8: D71C0073
	v_cndmask_b32_e32 v1, v115, v117, vcc_lo                   // 0000001B92AC: 0202EB73
	.long 0xd71c0075                                           // 0000001B92B0: D71C0075
	v_cndmask_b32_e32 v1, v119, v120, vcc_lo                   // 0000001B92B4: 0202F177
	v_cndmask_b32_e32 v73, 0x7f800000, v112, vcc_lo            // 0000001B92B8: 0292E0FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v98                  // 0000001B92C0: 7C3CC4FF 42CE8ED0
	v_exp_f32_e32 v122, v122                                   // 0000001B92C8: 7EF44B7A
	.long 0xd71c0078                                           // 0000001B92CC: D71C0078
	v_cndmask_b32_e32 v1, v144, v159, vcc_lo                   // 0000001B92D0: 02033F90
	v_rndne_f32_e32 v167, v148                                 // 0000001B92D4: 7F4E4794
	v_cvt_i32_f32_e32 v157, v161                               // 0000001B92D8: 7F3A11A1
	v_cndmask_b32_e32 v103, 0, v115, vcc_lo                    // 0000001B92DC: 02CEE680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v99                  // 0000001B92E0: 7C3CC6FF 42CE8ED0
	.long 0xd71c0076                                           // 0000001B92E8: D71C0076
	v_cndmask_b32_e32 v1, v121, v155, vcc_lo                   // 0000001B92EC: 02033779
	v_rndne_f32_e32 v169, v149                                 // 0000001B92F0: 7F524795
	v_sub_f32_e32 v148, v148, v167                             // 0000001B92F4: 09294F94
	v_exp_f32_e32 v145, v145                                   // 0000001B92F8: 7F224B91
	v_cndmask_b32_e32 v112, 0, v117, vcc_lo                    // 0000001B92FC: 02E0EA80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v100                 // 0000001B9300: 7C3CC8FF 42CE8ED0
	.long 0xd71c0077                                           // 0000001B9308: D71C0077
	v_cndmask_b32_e32 v1, v122, v157, vcc_lo                   // 0000001B930C: 02033B7A
	v_dual_sub_f32 v149, v149, v169 :: v_dual_add_f32 v148, v148, v166// 0000001B9310: C9495395 95954D94
	v_cvt_i32_f32_e32 v147, v165                               // 0000001B9318: 7F2611A5
	v_cndmask_b32_e32 v115, 0, v118, vcc_lo                    // 0000001B931C: 02E6EC80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v101                 // 0000001B9320: 7C3CCAFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B9328: BF870004
	v_add_f32_e32 v149, v149, v168                             // 0000001B932C: 072B5195
	v_exp_f32_e32 v148, v148                                   // 0000001B9330: 7F284B94
	v_exp_f32_e32 v116, v150                                   // 0000001B9334: 7EE84B96
	v_cvt_i32_f32_e32 v161, v167                               // 0000001B9338: 7F4211A7
	v_cndmask_b32_e32 v117, 0, v119, vcc_lo                    // 0000001B933C: 02EAEE80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v102                 // 0000001B9340: 7C3CCCFF 42CE8ED0
	v_cvt_i32_f32_e32 v165, v171                               // 0000001B9348: 7F4A11AB
	v_exp_f32_e32 v149, v149                                   // 0000001B934C: 7F2A4B95
	.long 0xd71c0079                                           // 0000001B9350: D71C0079
	v_cndmask_b32_e32 v1, v145, v147, vcc_lo                   // 0000001B9354: 02032791
	v_cvt_i32_f32_e32 v163, v169                               // 0000001B9358: 7F4611A9
	v_cndmask_b32_e32 v118, 0, v120, vcc_lo                    // 0000001B935C: 02ECF080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v50                  // 0000001B9360: 7C3664FF C2B17218
	.long 0xd71c007a                                           // 0000001B9368: D71C007A
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 0000001B936C: 02034394
	.long 0xd71c0074                                           // 0000001B9370: D71C0074
	v_cndmask_b32_e32 v1, v116, v165, vcc_lo                   // 0000001B9374: 02034B74
	v_add_f32_e32 v120, 1.0, v49                               // 0000001B9378: 06F062F2
	.long 0xd41b0005                                           // 0000001B937C: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v94, vcc_lo              // 0000001B9380: 0202BCFF C2B17218
	v_cndmask_b32_e32 v50, 0x7f800000, v113, vcc_lo            // 0000001B9388: 0264E2FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v93                  // 0000001B9390: 7C3CBAFF 42CE8ED0
	.long 0xd71c0090                                           // 0000001B9398: D71C0090
	v_cndmask_b32_e32 v1, v149, v163, vcc_lo                   // 0000001B939C: 02034795
	v_cndmask_b32_e32 v113, 0, v121, vcc_lo                    // 0000001B93A0: 02E2F280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v94                  // 0000001B93A4: 7C3CBCFF 42CE8ED0
	v_div_scale_f32 v121, null, v120, v120, v57                // 0000001B93AC: D6FC7C79 04E6F178
	v_cndmask_b32_e32 v119, 0, v122, vcc_lo                    // 0000001B93B4: 02EEF480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v95                  // 0000001B93B8: 7C3CBEFF 42CE8ED0
	v_cndmask_b32_e32 v49, 0, v144, vcc_lo                     // 0000001B93C0: 02632080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000001B93C4: 7C3CC0FF 42CE8ED0
	v_cndmask_b32_e32 v116, 0, v116, vcc_lo                    // 0000001B93CC: 02E8E880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v98                  // 0000001B93D0: 7C36C4FF C2B17218
	v_cndmask_b32_e32 v98, 0x7f800000, v103, vcc_lo            // 0000001B93D8: 02C4CEFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v99                  // 0000001B93E0: 7C36C6FF C2B17218
	v_rcp_f32_e32 v103, v121                                   // 0000001B93E8: 7ECE5579
	v_cndmask_b32_e64 v94, 0x7f800000, v119, s5                // 0000001B93EC: D501005E 0016EEFF 7F800000
	.long 0xd41b0005                                           // 0000001B93F8: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v95, vcc_lo              // 0000001B93FC: 0202BEFF C2B17218
	v_dual_add_f32 v98, 1.0, v98 :: v_dual_cndmask_b32 v99, 0x7f800000, v112// 0000001B9404: C912C4F2 6262E0FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v100                 // 0000001B9410: 7C36C8FF C2B17218
	v_dual_add_f32 v73, 1.0, v73 :: v_dual_cndmask_b32 v100, 0x7f800000, v115// 0000001B9418: C91292F2 4964E6FF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B9424: BF870121
	v_div_scale_f32 v122, null, v73, v73, v58                  // 0000001B9428: D6FC7C7A 04EA9349
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v101                 // 0000001B9430: 7C36CAFF C2B17218
	v_rcp_f32_e32 v112, v122                                   // 0000001B9438: 7EE0557A
	v_cndmask_b32_e32 v101, 0x7f800000, v117, vcc_lo           // 0000001B943C: 02CAEAFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v102                 // 0000001B9444: 7C36CCFF C2B17218
	v_cndmask_b32_e32 v102, 0x7f800000, v118, vcc_lo           // 0000001B944C: 02CCECFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v93                  // 0000001B9454: 7C36BAFF C2B17218
	v_div_scale_f32 v118, s4, v58, v73, v58                    // 0000001B945C: D6FC0476 04EA933A
	v_cndmask_b32_e64 v95, 0x7f800000, v49, s5                 // 0000001B9464: D501005F 001662FF 7F800000
	.long 0xd41b0005                                           // 0000001B9470: D41B0005
	v_cndmask_b32_e32 v1, 0xc2b17218, v96, vcc_lo              // 0000001B9474: 0202C0FF C2B17218
	v_dual_add_f32 v102, 1.0, v102 :: v_dual_cndmask_b32 v93, 0x7f800000, v113// 0000001B947C: C912CCF2 665CE2FF 7F800000
	v_div_scale_f32 v117, vcc_lo, v57, v120, v57               // 0000001B9488: D6FC6A75 04E6F139
	v_add_f32_e32 v115, 1.0, v50                               // 0000001B9490: 06E664F2
	v_fma_f32 v50, -v121, v103, 1.0                            // 0000001B9494: D6130032 23CACF79
	v_fma_f32 v113, -v122, v112, 1.0                           // 0000001B949C: D6130071 23CAE17A
	v_div_scale_f32 v119, null, v102, v102, v80                // 0000001B94A4: D6FC7C77 0542CD66
	v_cndmask_b32_e64 v96, 0x7f800000, v116, s5                // 0000001B94AC: D5010060 0016E8FF 7F800000
	v_dual_add_f32 v94, 1.0, v94 :: v_dual_add_f32 v95, 1.0, v95// 0000001B94B8: C908BCF2 5E5EBEF2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B94C0: BF870214
	v_dual_fmac_f32 v103, v50, v103 :: v_dual_fmac_f32 v112, v113, v112// 0000001B94C4: C800CF32 6770E171
	v_rcp_f32_e32 v146, v119                                   // 0000001B94CC: 7F245577
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B94D0: BF870111
	v_mul_f32_e32 v50, v117, v103                              // 0000001B94D4: 1064CF75
	v_mul_f32_e32 v144, v118, v112                             // 0000001B94D8: 1120E176
	v_div_scale_f32 v113, null, v115, v115, v111               // 0000001B94DC: D6FC7C71 05BEE773
	v_div_scale_f32 v116, s5, v111, v115, v111                 // 0000001B94E4: D6FC0574 05BEE76F
	v_add_f32_e32 v93, 1.0, v93                                // 0000001B94EC: 06BABAF2
	v_fma_f32 v49, -v121, v50, v117                            // 0000001B94F0: D6130031 25D66579
	v_fma_f32 v147, -v122, v144, v118                          // 0000001B94F8: D6130093 25DB217A
	v_rcp_f32_e32 v145, v113                                   // 0000001B9500: 7F225571
	v_add_f32_e32 v99, 1.0, v99                                // 0000001B9504: 06C6C6F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B9508: BF870193
	v_fmac_f32_e32 v50, v49, v103                              // 0000001B950C: 5664CF31
	v_fmac_f32_e32 v144, v147, v112                            // 0000001B9510: 5720E193
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B9514: BF870112
	v_fma_f32 v117, -v121, v50, v117                           // 0000001B9518: D6130075 25D66579
	v_fma_f32 v118, -v122, v144, v118                          // 0000001B9520: D6130076 25DB217A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B9528: BF870225
	v_fma_f32 v49, -v113, v145, 1.0                            // 0000001B952C: D6130031 23CB2371
	v_fma_f32 v121, -v119, v146, 1.0                           // 0000001B9534: D6130079 23CB2577
	v_div_fmas_f32 v103, v117, v103, v50                       // 0000001B953C: D6370067 04CACF75
	s_mov_b32 vcc_lo, s4                                       // 0000001B9544: BEEA0004
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B9548: BF870003
	v_fmac_f32_e32 v145, v49, v145                             // 0000001B954C: 57232331
	v_div_fmas_f32 v112, v118, v112, v144                      // 0000001B9550: D6370070 0642E176
	s_mov_b32 vcc_lo, s2                                       // 0000001B9558: BEEA0002
	v_fmac_f32_e32 v146, v121, v146                            // 0000001B955C: 57252579
	v_div_fmas_f32 v50, v109, v91, v71                         // 0000001B9560: D6370032 051EB76D
	s_mov_b32 vcc_lo, s3                                       // 0000001B9568: BEEA0003
	v_div_fixup_f32 v57, v103, v120, v57                       // 0000001B956C: D6270039 04E6F167
	v_div_fmas_f32 v71, v108, v90, v72                         // 0000001B9574: D6370047 0522B56C
	v_div_scale_f32 v72, s2, v80, v102, v80                    // 0000001B957C: D6FC0248 0542CD50
	v_div_fixup_f32 v50, v50, v89, 1.0                         // 0000001B9584: D6270032 03CAB332
	v_add_f32_e32 v90, 1.0, v100                               // 0000001B958C: 06B4C8F2
	v_add_f32_e32 v96, 1.0, v96                                // 0000001B9590: 06C0C0F2
	v_div_fixup_f32 v49, v71, v88, 1.0                         // 0000001B9594: D6270031 03CAB147
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001B959C: BF870244
	v_dual_mul_f32 v88, v116, v145 :: v_dual_mul_f32 v59, v59, v50// 0000001B95A0: C8C72374 583A653B
	v_add_f32_e32 v71, 1.0, v101                               // 0000001B95A8: 068ECAF2
	v_mul_f32_e32 v103, v51, v50                               // 0000001B95AC: 10CE6533
	.long 0x7e9e39b9                                           // 0000001B95B0: 7E9E39B9
	v_fma_f32 v91, -v113, v88, v116                            // 0000001B95B4: D613005B 25D2B171
	v_mul_f32_e32 v89, v72, v146                               // 0000001B95BC: 10B32548
	v_div_scale_f32 v100, null, v98, v98, v59                  // 0000001B95C0: D6FC7C64 04EEC562
	v_div_fixup_f32 v58, v112, v73, v58                        // 0000001B95C8: D627003A 04EA9370
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B95D0: BF870214
	v_dual_fmac_f32 v88, v91, v145 :: v_dual_and_b32 v79, 1, v79// 0000001B95D4: C825235B 584E9E81
	v_fma_f32 v101, -v119, v89, v72                            // 0000001B95DC: D6130065 2522B377
	v_mul_f32_e32 v60, v60, v49                                // 0000001B95E4: 1078633C
	v_rcp_f32_e32 v91, v100                                    // 0000001B95E8: 7EB65564
	.long 0x7e0039ba                                           // 0000001B95EC: 7E0039BA
	v_fma_f32 v109, -v113, v88, v116                           // 0000001B95F0: D613006D 25D2B171
	v_fmac_f32_e32 v89, v101, v146                             // 0000001B95F8: 56B32565
	v_div_scale_f32 v108, null, v99, v99, v60                  // 0000001B95FC: D6FC7C6C 04F2C763
	v_mul_f32_e32 v113, v52, v49                               // 0000001B9604: 10E26334
	v_div_scale_f32 v116, vcc_lo, v59, v98, v59                // 0000001B9608: D6FC6A74 04EEC53B
	v_div_scale_f32 v122, s4, v103, v93, v103                  // 0000001B9610: D6FC047A 059EBB67
	v_div_scale_f32 v117, null, v93, v93, v103                 // 0000001B9618: D6FC7C75 059EBB5D
	v_rcp_f32_e32 v101, v108                                   // 0000001B9620: 7ECA556C
	v_fma_f32 v51, -v100, v91, 1.0                             // 0000001B9624: D6130033 23CAB764
	v_fma_f32 v72, -v119, v89, v72                             // 0000001B962C: D6130048 2522B377
	v_add3_u32 v57, v57, v79, 0x7fff                           // 0000001B9634: D6550039 03FE9F39 00007FFF
	v_rcp_f32_e32 v112, v117                                   // 0000001B9640: 7EE05575
	v_dual_mul_f32 v43, v43, v50 :: v_dual_mul_f32 v44, v44, v49// 0000001B9644: C8C6652B 2B2C632C
	v_dual_mul_f32 v36, v36, v49 :: v_dual_mul_f32 v35, v35, v50// 0000001B964C: C8C66324 24226523
	v_mul_f32_e32 v28, v28, v49                                // 0000001B9654: 1038631C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001B9658: BF870246
	v_fma_f32 v52, -v108, v101, 1.0                            // 0000001B965C: D6130034 23CACB6C
	v_dual_mul_f32 v20, v20, v49 :: v_dual_mul_f32 v27, v27, v50// 0000001B9664: C8C66314 141A651B
	v_dual_mul_f32 v12, v12, v49 :: v_dual_mul_f32 v19, v19, v50// 0000001B966C: C8C6630C 0C126513
	v_mul_f32_e32 v4, v4, v49                                  // 0000001B9674: 10086304
	v_fmac_f32_e32 v101, v52, v101                             // 0000001B9678: 56CACB34
	v_fmac_f32_e32 v91, v51, v91                               // 0000001B967C: 56B6B733
	v_div_scale_f32 v51, s3, v60, v99, v60                     // 0000001B9680: D6FC0333 04F2C73C
	v_mul_f32_e32 v11, v11, v50                                // 0000001B9688: 1016650B
	v_mul_f32_e32 v3, v3, v50                                  // 0000001B968C: 10066503
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B9690: BF870093
	v_mul_f32_e32 v118, v51, v101                              // 0000001B9694: 10ECCB33
	v_fma_f32 v121, -v108, v118, v51                           // 0000001B9698: D6130079 24CEED6C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B96A0: BF870121
	v_fmac_f32_e32 v118, v121, v101                            // 0000001B96A4: 56ECCB79
	v_mul_f32_e32 v52, v116, v91                               // 0000001B96A8: 1068B774
	v_fma_f32 v51, -v108, v118, v51                            // 0000001B96AC: D6130033 24CEED6C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B96B4: BF870092
	v_fma_f32 v120, -v100, v52, v116                           // 0000001B96B8: D6130078 25D26964
	v_fmac_f32_e32 v52, v120, v91                              // 0000001B96C0: 5668B778
	v_fma_f32 v120, -v117, v112, 1.0                           // 0000001B96C4: D6130078 23CAE175
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B96CC: BF870092
	v_fma_f32 v100, -v100, v52, v116                           // 0000001B96D0: D6130064 25D26964
	v_div_fmas_f32 v91, v100, v91, v52                         // 0000001B96D8: D637005B 04D2B764
	s_mov_b32 vcc_lo, s3                                       // 0000001B96E0: BEEA0003
	v_div_fmas_f32 v100, v51, v101, v118                       // 0000001B96E4: D6370064 05DACB33
	s_mov_b32 vcc_lo, s0                                       // 0000001B96EC: BEEA0000
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001B96F0: BF870002
	v_div_fixup_f32 v59, v91, v98, v59                         // 0000001B96F4: D627003B 04EEC55B
	v_div_fmas_f32 v51, v107, v85, v142                        // 0000001B96FC: D6370033 063AAB6B
	s_mov_b32 vcc_lo, s1                                       // 0000001B9704: BEEA0001
	v_div_fixup_f32 v60, v100, v99, v60                        // 0000001B9708: D627003C 04F2C764
	v_div_fmas_f32 v84, v110, v84, v143                        // 0000001B9710: D6370054 063EA96E
	v_and_b32_e32 v85, 1, v0                                   // 0000001B9718: 36AA0081
	v_div_fixup_f32 v52, v51, v83, 1.0                         // 0000001B971C: D6270034 03CAA733
	.long 0x7e9a39bb                                           // 0000001B9724: 7E9A39BB
	.long 0x7e0039bc                                           // 0000001B9728: 7E0039BC
	v_div_fixup_f32 v51, v84, v81, 1.0                         // 0000001B972C: D6270033 03CAA354
	v_add3_u32 v58, v58, v85, 0x7fff                           // 0000001B9734: D655003A 03FEAB3A 00007FFF
	v_mul_f32_e32 v61, v61, v52                                // 0000001B9740: 107A693D
	s_clause 0x1                                               // 0000001B9744: BF850001
	global_store_d16_hi_b16 v[7:8], v57, off                   // 0000001B9748: DC960000 007C3907
	global_store_d16_hi_b16 v[7:8], v58, off offset:1024       // 0000001B9750: DC960400 007C3A07
	v_mul_f32_e32 v62, v62, v51                                // 0000001B9758: 107C673E
	v_div_scale_f32 v73, null, v94, v94, v113                  // 0000001B975C: D6FC7C49 05C6BD5E
	v_div_scale_f32 v121, s6, v113, v94, v113                  // 0000001B9764: D6FC0679 05C6BD71
	v_mul_f32_e32 v54, v54, v51                                // 0000001B976C: 106C6736
	v_div_scale_f32 v85, null, v90, v90, v61                   // 0000001B9770: D6FC7C55 04F6B55A
	v_mul_f32_e32 v53, v53, v52                                // 0000001B9778: 106A6935
	v_rcp_f32_e32 v119, v73                                    // 0000001B977C: 7EEE5549
	v_div_scale_f32 v99, vcc_lo, v61, v90, v61                 // 0000001B9780: D6FC6A63 04F6B53D
	v_div_scale_f32 v116, null, v96, v96, v54                  // 0000001B9788: D6FC7C74 04DAC160
	v_mul_f32_e32 v37, v37, v52                                // 0000001B9790: 104A6925
	v_div_scale_f32 v100, null, v95, v95, v53                  // 0000001B9794: D6FC7C64 04D6BF5F
	v_div_scale_f32 v110, s1, v53, v95, v53                    // 0000001B979C: D6FC016E 04D6BF35
	v_dual_mul_f32 v22, v22, v51 :: v_dual_mul_f32 v29, v29, v52// 0000001B97A4: C8C66716 161C691D
	v_mul_f32_e32 v14, v14, v51                                // 0000001B97AC: 101C670E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001B97B0: BF870314
	v_rcp_f32_e32 v107, v100                                   // 0000001B97B4: 7ED65564
	v_fma_f32 v144, -v73, v119, 1.0                            // 0000001B97B8: D6130090 23CAEF49
	v_mul_f32_e32 v21, v21, v52                                // 0000001B97C0: 102A6915
	v_mul_f32_e32 v13, v13, v52                                // 0000001B97C4: 101A690D
	v_dual_mul_f32 v5, v5, v52 :: v_dual_mul_f32 v6, v6, v51   // 0000001B97C8: C8C66905 05066706
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B97D0: BF870094
	v_fmac_f32_e32 v119, v144, v119                            // 0000001B97D4: 56EEEF90
	v_dual_fmac_f32 v112, v120, v112 :: v_dual_mul_f32 v81, v121, v119// 0000001B97D8: C806E178 7050EF79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B97E0: BF870111
	v_mul_f32_e32 v83, v122, v112                              // 0000001B97E4: 10A6E17A
	v_fma_f32 v84, -v73, v81, v121                             // 0000001B97E8: D6130054 25E6A349
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B97F0: BF870092
	v_fma_f32 v79, -v117, v83, v122                            // 0000001B97F4: D613004F 25EAA775
	v_fmac_f32_e32 v83, v79, v112                              // 0000001B97FC: 56A6E14F
	v_div_scale_f32 v79, null, v71, v71, v62                   // 0000001B9800: D6FC7C4F 04FA8F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B9808: BF870291
	v_rcp_f32_e32 v91, v79                                     // 0000001B980C: 7EB6554F
	v_fma_f32 v98, -v79, v91, 1.0                              // 0000001B9810: D6130062 23CAB74F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001B9818: BF870131
	v_dual_fmac_f32 v91, v98, v91 :: v_dual_and_b32 v98, 1, v0 // 0000001B981C: C824B762 5B620081
	v_fmac_f32_e32 v81, v84, v119                              // 0000001B9824: 56A2EF54
	v_rcp_f32_e32 v84, v85                                     // 0000001B9828: 7EA85555
	v_add3_u32 v60, v60, v98, 0x7fff                           // 0000001B982C: D655003C 03FEC53C 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B9838: BF870292
	v_fma_f32 v58, -v73, v81, v121                             // 0000001B983C: D613003A 25E6A349
	v_fma_f32 v73, -v85, v84, 1.0                              // 0000001B9844: D6130049 23CAA955
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001B984C: BF8700A1
	v_fmac_f32_e32 v84, v73, v84                               // 0000001B9850: 56A8A949
	v_div_scale_f32 v73, s0, v62, v71, v62                     // 0000001B9854: D6FC0049 04FA8F3E
	v_dual_mul_f32 v101, v99, v84 :: v_dual_mul_f32 v108, v73, v91// 0000001B985C: C8C6A963 656CB749
	v_fma_f32 v57, -v117, v83, v122                            // 0000001B9864: D6130039 25EAA775
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B986C: BF870092
	v_fma_f32 v117, -v79, v108, v73                            // 0000001B9870: D6130075 2526D94F
	v_dual_fmac_f32 v108, v117, v91 :: v_dual_and_b32 v77, 1, v77// 0000001B9878: C824B775 6C4C9A81
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001B9880: BF870001
	v_add3_u32 v59, v59, v77, 0x7fff                           // 0000001B9884: D655003B 03FE9B3B 00007FFF
	v_fma_f32 v77, -v85, v101, v99                             // 0000001B9890: D613004D 258ECB55
	global_store_d16_hi_b16 v[15:16], v59, off                 // 0000001B9898: DC960000 007C3B0F
	v_fma_f32 v59, -v100, v107, 1.0                            // 0000001B98A0: D613003B 23CAD764
	global_store_d16_hi_b16 v[23:24], v60, off                 // 0000001B98A8: DC960000 007C3C17
	v_fmac_f32_e32 v107, v59, v107                             // 0000001B98B0: 56D6D73B
	v_fmac_f32_e32 v101, v77, v84                              // 0000001B98B4: 56CAA94D
	v_fma_f32 v59, -v79, v108, v73                             // 0000001B98B8: D613003B 2526D94F
	v_rcp_f32_e32 v77, v116                                    // 0000001B98C0: 7E9A5574
	s_waitcnt vmcnt(23)                                        // 0000001B98C4: BF895FF7
	v_lshlrev_b32_e32 v79, 16, v137                            // 0000001B98C8: 309F1290
	v_mul_f32_e32 v41, v41, v66                                // 0000001B98CC: 10528529
	v_fma_f32 v60, -v85, v101, v99                             // 0000001B98D0: D613003C 258ECB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000001B98D8: BF870141
	v_div_fmas_f32 v60, v60, v84, v101                         // 0000001B98DC: D637003C 0596A93C
	s_mov_b32 vcc_lo, s0                                       // 0000001B98E4: BEEA0000
	v_div_fmas_f32 v59, v59, v91, v108                         // 0000001B98E8: D637003B 05B2B73B
	s_mov_b32 vcc_lo, s2                                       // 0000001B98F0: BEEA0002
	v_div_fixup_f32 v60, v60, v90, v61                         // 0000001B98F4: D627003C 04F6B53C
	v_div_fmas_f32 v72, v72, v146, v89                         // 0000001B98FC: D6370048 05672548
	s_mov_b32 vcc_lo, s5                                       // 0000001B9904: BEEA0005
	v_div_fixup_f32 v59, v59, v71, v62                         // 0000001B9908: D627003B 04FA8F3B
	v_div_fmas_f32 v61, v109, v145, v88                        // 0000001B9910: D637003D 0563236D
	.long 0x7e9839bc                                           // 0000001B9918: 7E9839BC
	v_div_fixup_f32 v62, v72, v102, v80                        // 0000001B991C: D627003E 0542CD48
	s_mov_b32 vcc_lo, s4                                       // 0000001B9924: BEEA0004
	.long 0x7e0039bb                                           // 0000001B9928: 7E0039BB
	v_div_fixup_f32 v61, v61, v115, v111                       // 0000001B992C: D627003D 05BEE73D
	v_and_b32_e32 v72, 1, v76                                  // 0000001B9934: 36909881
	.long 0x7e9639be                                           // 0000001B9938: 7E9639BE
	v_div_fmas_f32 v57, v57, v112, v83                         // 0000001B993C: D6370039 054EE139
	v_and_b32_e32 v71, 1, v0                                   // 0000001B9944: 368E0081
	.long 0x7e0039bd                                           // 0000001B9948: 7E0039BD
	v_add3_u32 v60, v60, v72, 0x7fff                           // 0000001B994C: D655003C 03FE913C 00007FFF
	v_fma_f32 v72, 0xbfb8aa3b, v97, -v153                      // 0000001B9958: D6130048 8666C2FF BFB8AA3B
	s_mov_b32 vcc_lo, s6                                       // 0000001B9964: BEEA0006
	v_add3_u32 v59, v59, v71, 0x7fff                           // 0000001B9968: D655003B 03FE8F3B 00007FFF
	v_div_fmas_f32 v58, v58, v119, v81                         // 0000001B9974: D637003A 0546EF3A
	v_div_fixup_f32 v57, v57, v93, v103                        // 0000001B997C: D6270039 059EBB39
	v_dual_fmac_f32 v72, 0xb2a5705f, v97 :: v_dual_and_b32 v73, 1, v75// 0000001B9984: C824C2FF 48489681 B2A5705F
	v_and_b32_e32 v75, 1, v0                                   // 0000001B9990: 36960081
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B9994: BF870004
	v_div_fixup_f32 v58, v58, v94, v113                        // 0000001B9998: D627003A 05C6BD3A
	s_clause 0x1                                               // 0000001B99A0: BF850001
	global_store_d16_hi_b16 v[31:32], v60, off                 // 0000001B99A4: DC960000 007C3C1F
	global_store_d16_hi_b16 v[39:40], v59, off                 // 0000001B99AC: DC960000 007C3B27
	v_fma_f32 v60, -v116, v77, 1.0                             // 0000001B99B4: D613003C 23CA9B74
	v_add3_u32 v62, v62, v73, 0x7fff                           // 0000001B99BC: D655003E 03FE933E 00007FFF
	v_add3_u32 v61, v61, v75, 0x7fff                           // 0000001B99C8: D655003D 03FE973D 00007FFF
	s_clause 0x1                                               // 0000001B99D4: BF850001
	global_store_d16_hi_b16 v[7:8], v61, off offset:32         // 0000001B99D8: DC960020 007C3D07
	global_store_d16_hi_b16 v[47:48], v62, off offset:32       // 0000001B99E0: DC960020 007C3E2F
	v_add_f32_e32 v61, v114, v151                              // 0000001B99E8: 067B2F72
	.long 0x7e0039ba                                           // 0000001B99EC: 7E0039BA
	.long 0x7e9439b9                                           // 0000001B99F0: 7E9439B9
	v_rndne_f32_e32 v73, v153                                  // 0000001B99F4: 7E924799
	v_fmac_f32_e32 v77, v60, v77                               // 0000001B99F8: 569A9B3C
	v_exp_f32_e32 v60, v61                                     // 0000001B99FC: 7E784B3D
	v_div_scale_f32 v61, s0, v54, v96, v54                     // 0000001B9A00: D6FC003D 04DAC136
	v_and_b32_e32 v59, 1, v0                                   // 0000001B9A08: 36760081
	v_dual_sub_f32 v74, v153, v73 :: v_dual_and_b32 v71, 1, v74// 0000001B9A0C: C9649399 4A469481
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v82                  // 0000001B9A14: 7C3CA4FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B9A1C: BF870004
	v_mul_f32_e32 v76, v61, v77                                // 0000001B9A20: 10989B3D
	v_mul_f32_e32 v62, v110, v107                              // 0000001B9A24: 107CD76E
	v_add3_u32 v58, v58, v59, 0x7fff                           // 0000001B9A28: D655003A 03FE773A 00007FFF
	v_cvt_i32_f32_e32 v59, v152                                // 0000001B9A34: 7E761198
	v_add_f32_e32 v72, v74, v72                                // 0000001B9A38: 0690914A
	v_add3_u32 v57, v57, v71, 0x7fff                           // 0000001B9A3C: D6550039 03FE8F39 00007FFF
	v_fma_f32 v75, -v100, v62, v110                            // 0000001B9A48: D613004B 25BA7D64
	v_mul_f32_e32 v80, 0xbfb8aa3b, v79                         // 0000001B9A50: 10A09EFF BFB8AA3B
	.long 0xd71c003b                                           // 0000001B9A58: D71C003B
	v_cndmask_b32_e32 v1, v60, v59, vcc_lo                     // 0000001B9A5C: 0202773C
	v_fma_f32 v60, -v116, v76, v61                             // 0000001B9A60: D613003C 24F69974
	v_exp_f32_e32 v71, v72                                     // 0000001B9A68: 7E8E4B48
	v_fmac_f32_e32 v62, v75, v107                              // 0000001B9A6C: 567CD74B
	global_store_d16_hi_b16 v[15:16], v57, off offset:32       // 0000001B9A70: DC960020 007C390F
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 0000001B9A78: 02767680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v82                  // 0000001B9A7C: 7C36A4FF C2B17218
	v_fmac_f32_e32 v76, v60, v77                               // 0000001B9A84: 56989B3C
	v_fma_f32 v72, -v100, v62, v110                            // 0000001B9A88: D6130048 25BA7D64
	v_cvt_i32_f32_e32 v60, v73                                 // 0000001B9A90: 7E781149
	global_store_d16_hi_b16 v[23:24], v58, off offset:32       // 0000001B9A94: DC960020 007C3A17
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 0000001B9A9C: 027676FF 7F800000
	s_mov_b32 vcc_lo, s1                                       // 0000001B9AA4: BEEA0001
	v_fma_f32 v61, -v116, v76, v61                             // 0000001B9AA8: D613003D 24F69974
	v_div_fmas_f32 v62, v72, v107, v62                         // 0000001B9AB0: D637003E 04FAD748
	.long 0xd71c003c                                           // 0000001B9AB8: D71C003C
	v_cndmask_b32_e32 v1, v71, v60, vcc_lo                     // 0000001B9ABC: 02027947
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v97                  // 0000001B9AC0: 7C3CC2FF 42CE8ED0
	.long 0x7f903980                                           // 0000001B9AC8: 7F903980
	v_fma_f32 v82, 0xbfb8aa3b, v79, -v80                       // 0000001B9ACC: D6130052 85429EFF BFB8AA3B
	v_div_fixup_f32 v53, v62, v95, v53                         // 0000001B9AD8: D6270035 04D6BF3E
	v_rndne_f32_e32 v83, v80                                   // 0000001B9AE0: 7EA64750
	v_cndmask_b32_e32 v60, 0, v60, vcc_lo                      // 0000001B9AE4: 02787880
	s_mov_b32 vcc_lo, s0                                       // 0000001B9AE8: BEEA0000
	v_div_fmas_f32 v61, v61, v77, v76                          // 0000001B9AEC: D637003D 05329B3D
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v97                  // 0000001B9AF4: 7C36C2FF C2B17218
	.long 0x7e9039b5                                           // 0000001B9AFC: 7E9039B5
	v_sub_f32_e32 v80, v80, v83                                // 0000001B9B00: 08A0A750
	v_fmac_f32_e32 v82, 0xb2a5705f, v79                        // 0000001B9B04: 56A49EFF B2A5705F
	v_div_fixup_f32 v54, v61, v96, v54                         // 0000001B9B0C: D6270036 04DAC13D
	v_dual_cndmask_b32 v60, 0x7f800000, v60 :: v_dual_lshlrev_b32 v61, 16, v138// 0000001B9B14: CA6278FF 3C3D1490 7F800000
	v_and_b32_e32 v72, 1, v72                                  // 0000001B9B20: 36909081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B9B24: BF870214
	v_add_f32_e32 v80, v80, v82                                // 0000001B9B28: 06A0A550
	.long 0x7e0039b6                                           // 0000001B9B2C: 7E0039B6
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001B9B30: BF870234
	v_add_f32_e32 v60, 1.0, v60                                // 0000001B9B34: 067878F2
	v_mul_f32_e32 v62, 0xbfb8aa3b, v61                         // 0000001B9B38: 107C7AFF BFB8AA3B
	v_add3_u32 v53, v53, v72, 0x7fff                           // 0000001B9B40: D6550035 03FE9135 00007FFF
	v_and_b32_e32 v77, 1, v0                                   // 0000001B9B4C: 369A0081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B9B50: BF870214
	v_div_scale_f32 v58, null, v60, v60, v42                   // 0000001B9B54: D6FC7C3A 04AA793C
	v_fma_f32 v75, 0xbfb8aa3b, v61, -v62                       // 0000001B9B5C: D613004B 84FA7AFF BFB8AA3B
	v_rndne_f32_e32 v76, v62                                   // 0000001B9B68: 7E98473E
	global_store_d16_hi_b16 v[31:32], v53, off offset:32       // 0000001B9B6C: DC960020 007C351F
	v_add3_u32 v54, v54, v77, 0x7fff                           // 0000001B9B74: D6550036 03FE9B36 00007FFF
	v_rcp_f32_e32 v74, v58                                     // 0000001B9B80: 7E94553A
	v_sub_f32_e32 v62, v62, v76                                // 0000001B9B84: 087C993E
	v_cvt_i32_f32_e32 v76, v76                                 // 0000001B9B88: 7E98114C
	global_store_d16_hi_b16 v[39:40], v54, off offset:32       // 0000001B9B8C: DC960020 007C3627
	v_fma_f32 v81, -v58, v74, 1.0                              // 0000001B9B94: D6130051 23CA953A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B9B9C: BF870091
	v_dual_add_f32 v59, 1.0, v59 :: v_dual_fmac_f32 v74, v81, v74// 0000001B9BA0: C90076F2 3B4A9551
	v_div_scale_f32 v71, null, v59, v59, v41                   // 0000001B9BA8: D6FC7C47 04A6773B
	v_div_scale_f32 v81, s0, v42, v60, v42                     // 0000001B9BB0: D6FC0051 04AA792A
	v_fmac_f32_e32 v75, 0xb2a5705f, v61                        // 0000001B9BB8: 56967AFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B9BC0: BF870113
	v_rcp_f32_e32 v57, v71                                     // 0000001B9BC4: 7E725547
	v_mul_f32_e32 v84, v81, v74                                // 0000001B9BC8: 10A89551
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B9BCC: BF8701A2
	v_add_f32_e32 v62, v62, v75                                // 0000001B9BD0: 067C973E
	.long 0xd41e0001                                           // 0000001B9BD4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v61, vcc_lo              // 0000001B9BD8: 02027AFF 42CE8ED0
	v_fma_f32 v72, -v58, v84, v81                              // 0000001B9BE0: D6130048 2546A93A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001B9BE8: BF870313
	v_exp_f32_e32 v62, v62                                     // 0000001B9BEC: 7E7C4B3E
	v_fma_f32 v73, -v71, v57, 1.0                              // 0000001B9BF0: D6130049 23CA7347
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B9BF8: BF8701A2
	v_fmac_f32_e32 v84, v72, v74                               // 0000001B9BFC: 56A89548
	v_cvt_i32_f32_e32 v72, v83                                 // 0000001B9C00: 7E901153
	v_fmac_f32_e32 v57, v73, v57                               // 0000001B9C04: 56727349
	v_div_scale_f32 v73, vcc_lo, v41, v59, v41                 // 0000001B9C08: D6FC6A49 04A67729
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B9C10: BF8701B5
	.long 0xd71c003e                                           // 0000001B9C14: D71C003E
	v_cndmask_b32_e32 v1, v62, v76, vcc_lo                     // 0000001B9C18: 0202993E
	v_exp_f32_e32 v76, v80                                     // 0000001B9C1C: 7E984B50
	v_fma_f32 v58, -v58, v84, v81                              // 0000001B9C20: D613003A 2546A93A
	v_mul_f32_e32 v75, v73, v57                                // 0000001B9C28: 10967349
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B9C2C: BF8701A3
	v_cndmask_b32_e64 v62, 0, v62, s1                          // 0000001B9C30: D501003E 00067C80
	.long 0xd41b0001                                           // 0000001B9C38: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v61, vcc_lo              // 0000001B9C3C: 02027AFF C2B17218
	v_fma_f32 v77, -v71, v75, v73                              // 0000001B9C44: D613004D 25269747
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B9C4C: BF870292
	v_cndmask_b32_e64 v61, 0x7f800000, v62, s1                 // 0000001B9C50: D501003D 00067CFF 7F800000
	.long 0xd71c003e                                           // 0000001B9C5C: D71C003E
	v_cndmask_b32_e32 v1, v76, v72, vcc_lo                     // 0000001B9C60: 0202914C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B9C64: BF870093
	v_fmac_f32_e32 v75, v77, v57                               // 0000001B9C68: 5696734D
	v_fma_f32 v71, -v71, v75, v73                              // 0000001B9C6C: D6130047 25269747
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001B9C74: BF870121
	v_div_fmas_f32 v57, v71, v57, v75                          // 0000001B9C78: D6370039 052E7347
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v79                  // 0000001B9C80: 7C3C9EFF 42CE8ED0
	v_div_fixup_f32 v41, v57, v59, v41                         // 0000001B9C88: D6270029 04A67739
	v_cndmask_b32_e32 v62, 0, v62, vcc_lo                      // 0000001B9C90: 027C7C80
	s_mov_b32 vcc_lo, s0                                       // 0000001B9C94: BEEA0000
	.long 0x7f763980                                           // 0000001B9C98: 7F763980
	v_div_fmas_f32 v58, v58, v74, v84                          // 0000001B9C9C: D637003A 0552953A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v79                  // 0000001B9CA4: 7C369EFF C2B17218
	v_add_f32_e32 v61, 1.0, v61                                // 0000001B9CAC: 067A7AF2
	.long 0x7e7639a9                                           // 0000001B9CB0: 7E7639A9
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B9CB4: BF870224
	v_div_fixup_f32 v42, v58, v60, v42                         // 0000001B9CB8: D627002A 04AA793A
	v_cndmask_b32_e32 v62, 0x7f800000, v62, vcc_lo             // 0000001B9CC0: 027C7CFF 7F800000
	v_div_scale_f32 v71, null, v61, v61, v43                   // 0000001B9CC8: D6FC7C47 04AE7B3D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B9CD0: BF870113
	.long 0x7e0039aa                                           // 0000001B9CD4: 7E0039AA
	v_rcp_f32_e32 v53, v71                                     // 0000001B9CD8: 7E6A5547
	s_waitcnt vmcnt(17)                                        // 0000001B9CDC: BF8947F7
	v_lshlrev_b32_e32 v60, 16, v140                            // 0000001B9CE0: 30791890
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B9CE4: BF870092
	v_dual_add_f32 v58, 1.0, v62 :: v_dual_and_b32 v75, 1, v0  // 0000001B9CE8: C9247CF2 3A4A0081
	v_add3_u32 v42, v42, v75, 0x7fff                           // 0000001B9CF0: D655002A 03FE972A 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B9CFC: BF870095
	v_fma_f32 v62, -v71, v53, 1.0                              // 0000001B9D00: D613003E 23CA6B47
	v_fmac_f32_e32 v53, v62, v53                               // 0000001B9D08: 566A6B3E
	v_mul_f32_e32 v57, 0xbfb8aa3b, v60                         // 0000001B9D0C: 107278FF BFB8AA3B
	v_div_scale_f32 v54, null, v58, v58, v44                   // 0000001B9D14: D6FC7C36 04B2753A
	v_div_scale_f32 v62, vcc_lo, v43, v61, v43                 // 0000001B9D1C: D6FC6A3E 04AE7B2B
	.long 0xd41e0001                                           // 0000001B9D24: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v60, vcc_lo              // 0000001B9D28: 020278FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B9D30: BF870214
	v_fma_f32 v73, 0xbfb8aa3b, v60, -v57                       // 0000001B9D34: D6130049 84E678FF BFB8AA3B
	v_rcp_f32_e32 v72, v54                                     // 0000001B9D40: 7E905536
	v_rndne_f32_e32 v74, v57                                   // 0000001B9D44: 7E944739
	s_waitcnt vmcnt(11)                                        // 0000001B9D48: BF892FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B9D4C: BF870092
	v_dual_fmac_f32 v73, 0xb2a5705f, v60 :: v_dual_lshlrev_b32 v76, 16, v139// 0000001B9D50: C82278FF 494D1690 B2A5705F
	v_mul_f32_e32 v77, 0xbfb8aa3b, v76                         // 0000001B9D5C: 109A98FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B9D64: BF8701A5
	v_fma_f32 v79, -v54, v72, 1.0                              // 0000001B9D68: D613004F 23CA9136
	v_sub_f32_e32 v57, v57, v74                                // 0000001B9D70: 08729539
	v_fma_f32 v80, 0xbfb8aa3b, v76, -v77                       // 0000001B9D74: D6130050 853698FF BFB8AA3B
	v_and_b32_e32 v59, 1, v59                                  // 0000001B9D80: 36767681
	v_rndne_f32_e32 v81, v77                                   // 0000001B9D84: 7EA2474D
	v_fmac_f32_e32 v72, v79, v72                               // 0000001B9D88: 5690914F
	v_div_scale_f32 v79, s0, v44, v58, v44                     // 0000001B9D8C: D6FC004F 04B2752C
	v_dual_add_f32 v57, v57, v73 :: v_dual_fmac_f32 v80, 0xb2a5705f, v76// 0000001B9D94: C9009339 395098FF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001B9DA0: BF870224
	v_sub_f32_e32 v77, v77, v81                                // 0000001B9DA4: 089AA34D
	v_add3_u32 v41, v41, v59, 0x7fff                           // 0000001B9DA8: D6550029 03FE7729 00007FFF
	v_mul_f32_e32 v82, v79, v72                                // 0000001B9DB4: 10A4914F
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001B9DB8: BF870004
	v_exp_f32_e32 v57, v57                                     // 0000001B9DBC: 7E724B39
	v_cvt_i32_f32_e32 v74, v74                                 // 0000001B9DC0: 7E94114A
	v_add_f32_e32 v77, v77, v80                                // 0000001B9DC4: 069AA14D
	global_store_d16_hi_b16 v[7:8], v41, off offset:64         // 0000001B9DC8: DC960040 007C2907
	v_fma_f32 v59, -v54, v82, v79                              // 0000001B9DD0: D613003B 253EA536
	v_mul_f32_e32 v73, v62, v53                                // 0000001B9DD8: 10926B3E
	global_store_d16_hi_b16 v[47:48], v42, off offset:64       // 0000001B9DDC: DC960040 007C2A2F
	v_fmac_f32_e32 v82, v59, v72                               // 0000001B9DE4: 56A4913B
	v_fma_f32 v75, -v71, v73, v62                              // 0000001B9DE8: D613004B 24FA9347
	.long 0xd71c0039                                           // 0000001B9DF0: D71C0039
	v_cndmask_b32_e32 v1, v57, v74, vcc_lo                     // 0000001B9DF4: 02029539
	v_exp_f32_e32 v74, v77                                     // 0000001B9DF8: 7E944B4D
	v_cvt_i32_f32_e32 v59, v81                                 // 0000001B9DFC: 7E761151
	v_fma_f32 v54, -v54, v82, v79                              // 0000001B9E00: D6130036 253EA536
	v_fmac_f32_e32 v73, v75, v53                               // 0000001B9E08: 56926B4B
	v_cndmask_b32_e64 v57, 0, v57, s1                          // 0000001B9E0C: D5010039 00067280
	.long 0xd41b0001                                           // 0000001B9E14: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v60, vcc_lo              // 0000001B9E18: 020278FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B9E20: BF870293
	v_fma_f32 v62, -v71, v73, v62                              // 0000001B9E24: D613003E 24FA9347
	.long 0xd71c003b                                           // 0000001B9E2C: D71C003B
	v_cndmask_b32_e32 v1, v74, v59, vcc_lo                     // 0000001B9E30: 0202774A
	s_waitcnt vmcnt(5)                                         // 0000001B9E34: BF8917F7
	v_lshlrev_b32_e32 v74, 16, v141                            // 0000001B9E38: 30951A90
	v_cndmask_b32_e64 v57, 0x7f800000, v57, s1                 // 0000001B9E3C: D5010039 000672FF 7F800000
	v_div_fmas_f32 v53, v62, v53, v73                          // 0000001B9E48: D6370035 05266B3E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v76                  // 0000001B9E50: 7C3C98FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001B9E58: BF870194
	v_mul_f32_e32 v75, 0xbfb8aa3b, v74                         // 0000001B9E5C: 109694FF BFB8AA3B
	v_div_fixup_f32 v43, v53, v61, v43                         // 0000001B9E64: D627002B 04AE7B35
	v_cndmask_b32_e32 v59, 0, v59, vcc_lo                      // 0000001B9E6C: 02767680
	s_mov_b32 vcc_lo, s0                                       // 0000001B9E70: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001B9E74: BF8701B3
	v_fma_f32 v77, 0xbfb8aa3b, v74, -v75                       // 0000001B9E78: D613004D 852E94FF BFB8AA3B
	v_div_fmas_f32 v54, v54, v72, v82                          // 0000001B9E84: D6370036 054A9136
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v76                  // 0000001B9E8C: 7C3698FF C2B17218
	v_fmac_f32_e32 v77, 0xb2a5705f, v74                        // 0000001B9E94: 569A94FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B9E9C: BF870003
	v_div_fixup_f32 v41, v54, v58, v44                         // 0000001B9EA0: D6270029 04B27536
	v_cndmask_b32_e32 v59, 0x7f800000, v59, vcc_lo             // 0000001B9EA8: 027676FF 7F800000
	v_mul_f32_e32 v44, v46, v51                                // 0000001B9EB0: 1058672E
	v_lshlrev_b32_e32 v58, 16, v78                             // 0000001B9EB4: 30749C90
	v_rndne_f32_e32 v78, v75                                   // 0000001B9EB8: 7E9C474B
	.long 0x7e0039a9                                           // 0000001B9EBC: 7E0039A9
	v_add_f32_e32 v54, 1.0, v59                                // 0000001B9EC0: 066C76F2
	.long 0x7e7639ab                                           // 0000001B9EC4: 7E7639AB
	v_mul_f32_e32 v53, 0xbfb8aa3b, v58                         // 0000001B9EC8: 106A74FF BFB8AA3B
	.long 0x7f763980                                           // 0000001B9ED0: 7F763980
	v_sub_f32_e32 v75, v75, v78                                // 0000001B9ED4: 08969D4B
	v_div_scale_f32 v42, null, v54, v54, v44                   // 0000001B9ED8: D6FC7C2A 04B26D36
	.long 0xd41e0001                                           // 0000001B9EE0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v58, vcc_lo              // 0000001B9EE4: 020274FF 42CE8ED0
	v_fma_f32 v71, 0xbfb8aa3b, v58, -v53                       // 0000001B9EEC: D6130047 84D674FF BFB8AA3B
	v_rndne_f32_e32 v72, v53                                   // 0000001B9EF8: 7E904735
	v_and_b32_e32 v59, 1, v59                                  // 0000001B9EFC: 36767681
	v_rcp_f32_e32 v62, v42                                     // 0000001B9F00: 7E7C552A
	v_add_f32_e32 v75, v75, v77                                // 0000001B9F04: 06969B4B
	v_fmac_f32_e32 v71, 0xb2a5705f, v58                        // 0000001B9F08: 568E74FF B2A5705F
	v_sub_f32_e32 v53, v53, v72                                // 0000001B9F10: 086A9135
	v_cvt_i32_f32_e32 v72, v72                                 // 0000001B9F14: 7E901148
	v_add3_u32 v43, v43, v59, 0x7fff                           // 0000001B9F18: D655002B 03FE772B 00007FFF
	v_and_b32_e32 v73, 1, v0                                   // 0000001B9F24: 36920081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001B9F28: BF870294
	v_add_f32_e32 v53, v53, v71                                // 0000001B9F2C: 066A8F35
	v_fma_f32 v76, -v42, v62, 1.0                              // 0000001B9F30: D613004C 23CA7D2A
	v_mul_f32_e32 v45, v45, v52                                // 0000001B9F38: 105A692D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001B9F3C: BF870214
	v_add3_u32 v41, v41, v73, 0x7fff                           // 0000001B9F40: D6550029 03FE9329 00007FFF
	v_exp_f32_e32 v53, v53                                     // 0000001B9F4C: 7E6A4B35
	global_store_d16_hi_b16 v[15:16], v43, off offset:64       // 0000001B9F50: DC960040 007C2B0F
	v_fmac_f32_e32 v62, v76, v62                               // 0000001B9F58: 567C7D4C
	v_div_scale_f32 v76, s0, v44, v54, v44                     // 0000001B9F5C: D6FC004C 04B26D2C
	global_store_d16_hi_b16 v[23:24], v41, off offset:64       // 0000001B9F64: DC960040 007C2917
	v_mul_f32_e32 v79, v76, v62                                // 0000001B9F6C: 109E7D4C
	.long 0xd71c0035                                           // 0000001B9F70: D71C0035
	v_cndmask_b32_e32 v1, v53, v72, vcc_lo                     // 0000001B9F74: 02029135
	v_exp_f32_e32 v72, v75                                     // 0000001B9F78: 7E904B4B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001B9F7C: BF870112
	v_fma_f32 v59, -v42, v79, v76                              // 0000001B9F80: D613003B 25329F2A
	v_cndmask_b32_e64 v53, 0, v53, s1                          // 0000001B9F88: D5010035 00066A80
	.long 0xd41b0001                                           // 0000001B9F90: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v58, vcc_lo              // 0000001B9F94: 020274FF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001B9F9C: BF8701A3
	v_fmac_f32_e32 v79, v59, v62                               // 0000001B9FA0: 569E7D3B
	v_cvt_i32_f32_e32 v59, v78                                 // 0000001B9FA4: 7E76114E
	v_cndmask_b32_e64 v53, 0x7f800000, v53, s1                 // 0000001B9FA8: D5010035 00066AFF 7F800000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001B9FB4: BF870003
	v_fma_f32 v42, -v42, v79, v76                              // 0000001B9FB8: D613002A 25329F2A
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001B9FC0: BF870185
	.long 0xd71c003a                                           // 0000001B9FC4: D71C003A
	v_cndmask_b32_e32 v1, v72, v59, vcc_lo                     // 0000001B9FC8: 02027748
	v_dual_add_f32 v57, 1.0, v57 :: v_dual_lshlrev_b32 v72, 16, v132// 0000001B9FCC: C92272F2 39490890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B9FD4: BF870091
	v_div_scale_f32 v60, null, v57, v57, v45                   // 0000001B9FD8: D6FC7C3C 04B67339
	v_rcp_f32_e32 v46, v60                                     // 0000001B9FE0: 7E5C553C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B9FE4: BF870095
	v_fma_f32 v61, -v60, v46, 1.0                              // 0000001B9FE8: D613003D 23CA5D3C
	v_fmac_f32_e32 v46, v61, v46                               // 0000001B9FF0: 565C5D3D
	v_div_scale_f32 v61, vcc_lo, v45, v57, v45                 // 0000001B9FF4: D6FC6A3D 04B6732D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001B9FFC: BF870091
	v_mul_f32_e32 v71, v61, v46                                // 0000001BA000: 108E5D3D
	v_fma_f32 v73, -v60, v71, v61                              // 0000001BA004: D6130049 24F68F3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BA00C: BF870121
	v_fmac_f32_e32 v71, v73, v46                               // 0000001BA010: 568E5D49
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000001BA014: 109290FF BFB8AA3B
	v_fma_f32 v60, -v60, v71, v61                              // 0000001BA01C: D613003C 24F68F3C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BA024: BF8701A2
	v_fma_f32 v75, 0xbfb8aa3b, v72, -v73                       // 0000001BA028: D613004B 852690FF BFB8AA3B
	v_rndne_f32_e32 v76, v73                                   // 0000001BA034: 7E984749
	v_div_fmas_f32 v46, v60, v46, v71                          // 0000001BA038: D637002E 051E5D3C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v74                  // 0000001BA040: 7C3C94FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BA048: BF870214
	v_fmac_f32_e32 v75, 0xb2a5705f, v72                        // 0000001BA04C: 569690FF B2A5705F
	v_dual_sub_f32 v73, v73, v76 :: v_dual_cndmask_b32 v58, 0, v58// 0000001BA054: C9529949 493A7480
	s_mov_b32 vcc_lo, s0                                       // 0000001BA05C: BEEA0000
	v_div_fixup_f32 v45, v46, v57, v45                         // 0000001BA060: D627002D 04B6732E
	v_div_fmas_f32 v42, v42, v62, v79                          // 0000001BA068: D637002A 053E7D2A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v74                  // 0000001BA070: 7C3694FF C2B17218
	.long 0x7f723980                                           // 0000001BA078: 7F723980
	v_add_f32_e32 v73, v73, v75                                // 0000001BA07C: 06929749
	.long 0x7e7239ad                                           // 0000001BA080: 7E7239AD
	v_div_fixup_f32 v42, v42, v54, v44                         // 0000001BA084: D627002A 04B26D2A
	v_cndmask_b32_e32 v58, 0x7f800000, v58, vcc_lo             // 0000001BA08C: 027474FF 7F800000
	v_lshlrev_b32_e32 v54, 16, v133                            // 0000001BA094: 306D0A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BA098: BF870214
	v_and_b32_e32 v57, 1, v57                                  // 0000001BA09C: 36727281
	.long 0x7e0039aa                                           // 0000001BA0A0: 7E0039AA
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BA0A4: BF870214
	v_add_f32_e32 v44, 1.0, v58                                // 0000001BA0A8: 065874F2
	v_mul_f32_e32 v46, 0xbfb8aa3b, v54                         // 0000001BA0AC: 105C6CFF BFB8AA3B
	.long 0xd41e0001                                           // 0000001BA0B4: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v54, vcc_lo              // 0000001BA0B8: 02026CFF 42CE8ED0
	v_add3_u32 v45, v45, v57, 0x7fff                           // 0000001BA0C0: D655002D 03FE732D 00007FFF
	v_and_b32_e32 v71, 1, v0                                   // 0000001BA0CC: 368E0081
	v_div_scale_f32 v41, null, v44, v44, v34                   // 0000001BA0D0: D6FC7C29 048A592C
	v_fma_f32 v61, 0xbfb8aa3b, v54, -v46                       // 0000001BA0D8: D613003D 84BA6CFF BFB8AA3B
	v_rndne_f32_e32 v62, v46                                   // 0000001BA0E4: 7E7C472E
	global_store_d16_hi_b16 v[31:32], v45, off offset:64       // 0000001BA0E8: DC960040 007C2D1F
	v_add3_u32 v42, v42, v71, 0x7fff                           // 0000001BA0F0: D655002A 03FE8F2A 00007FFF
	v_rcp_f32_e32 v60, v41                                     // 0000001BA0FC: 7E785529
	v_fmac_f32_e32 v61, 0xb2a5705f, v54                        // 0000001BA100: 567A6CFF B2A5705F
	v_sub_f32_e32 v46, v46, v62                                // 0000001BA108: 085C7D2E
	v_cvt_i32_f32_e32 v62, v62                                 // 0000001BA10C: 7E7C113E
	v_lshlrev_b32_e32 v45, 16, v135                            // 0000001BA110: 305B0E90
	global_store_d16_hi_b16 v[39:40], v42, off offset:64       // 0000001BA114: DC960040 007C2A27
	v_add_f32_e32 v46, v46, v61                                // 0000001BA11C: 065C7B2E
	v_fma_f32 v74, -v41, v60, 1.0                              // 0000001BA120: D613004A 23CA7929
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BA128: BF870092
	v_exp_f32_e32 v46, v46                                     // 0000001BA12C: 7E5C4B2E
	v_fmac_f32_e32 v60, v74, v60                               // 0000001BA130: 5678794A
	v_div_scale_f32 v74, s0, v34, v44, v34                     // 0000001BA134: D6FC004A 048A5922
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001BA13C: BF870291
	v_mul_f32_e32 v77, v74, v60                                // 0000001BA140: 109A794A
	.long 0xd71c002e                                           // 0000001BA144: D71C002E
	v_cndmask_b32_e32 v1, v46, v62, vcc_lo                     // 0000001BA148: 02027D2E
	v_exp_f32_e32 v62, v73                                     // 0000001BA14C: 7E7C4B49
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BA150: BF870112
	v_fma_f32 v57, -v41, v77, v74                              // 0000001BA154: D6130039 252A9B29
	v_cndmask_b32_e64 v46, 0, v46, s1                          // 0000001BA15C: D501002E 00065C80
	.long 0xd41b0001                                           // 0000001BA164: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v54, vcc_lo              // 0000001BA168: 02026CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BA170: BF8701A3
	v_fmac_f32_e32 v77, v57, v60                               // 0000001BA174: 569A7939
	v_cvt_i32_f32_e32 v57, v76                                 // 0000001BA178: 7E72114C
	v_cndmask_b32_e64 v46, 0x7f800000, v46, s1                 // 0000001BA17C: D501002E 00065CFF 7F800000
	.long 0xd41e0001                                           // 0000001BA188: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v45, vcc_lo              // 0000001BA18C: 02025AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BA194: BF870004
	v_fma_f32 v41, -v41, v77, v74                              // 0000001BA198: D6130029 252A9B29
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_4)   // 0000001BA1A0: BF870205
	.long 0xd71c0036                                           // 0000001BA1A4: D71C0036
	v_cndmask_b32_e32 v1, v62, v57, vcc_lo                     // 0000001BA1A8: 0202733E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BA1AC: BF870124
	v_dual_add_f32 v53, 1.0, v53 :: v_dual_add_f32 v46, 1.0, v46// 0000001BA1B0: C9086AF2 352E5CF2
	v_lshlrev_b32_e32 v62, 16, v134                            // 0000001BA1B8: 307D0C90
	v_div_scale_f32 v59, null, v53, v53, v33                   // 0000001BA1BC: D6FC7C3B 04866B35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BA1C4: BF870113
	v_div_scale_f32 v57, null, v46, v46, v35                   // 0000001BA1C8: D6FC7C39 048E5D2E
	v_rcp_f32_e32 v43, v59                                     // 0000001BA1D0: 7E56553B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BA1D4: BF870095
	v_fma_f32 v58, -v59, v43, 1.0                              // 0000001BA1D8: D613003A 23CA573B
	v_fmac_f32_e32 v43, v58, v43                               // 0000001BA1E0: 5656573A
	v_div_scale_f32 v58, vcc_lo, v33, v53, v33                 // 0000001BA1E4: D6FC6A3A 04866B21
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001BA1EC: BF870091
	v_mul_f32_e32 v61, v58, v43                                // 0000001BA1F0: 107A573A
	v_fma_f32 v71, -v59, v61, v58                              // 0000001BA1F4: D6130047 24EA7B3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BA1FC: BF870121
	v_fmac_f32_e32 v61, v71, v43                               // 0000001BA200: 567A5747
	v_mul_f32_e32 v71, 0xbfb8aa3b, v62                         // 0000001BA204: 108E7CFF BFB8AA3B
	v_fma_f32 v58, -v59, v61, v58                              // 0000001BA20C: D613003A 24EA7B3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BA214: BF8701A2
	v_fma_f32 v73, 0xbfb8aa3b, v62, -v71                       // 0000001BA218: D6130049 851E7CFF BFB8AA3B
	v_rndne_f32_e32 v74, v71                                   // 0000001BA224: 7E944747
	v_div_fmas_f32 v43, v58, v43, v61                          // 0000001BA228: D637002B 04F6573A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000001BA230: 7C3C90FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BA238: BF870214
	v_fmac_f32_e32 v73, 0xb2a5705f, v62                        // 0000001BA23C: 56927CFF B2A5705F
	v_sub_f32_e32 v71, v71, v74                                // 0000001BA244: 088E9547
	v_cndmask_b32_e32 v54, 0, v54, vcc_lo                      // 0000001BA248: 026C6C80
	s_mov_b32 vcc_lo, s0                                       // 0000001BA24C: BEEA0000
	v_div_fixup_f32 v33, v43, v53, v33                         // 0000001BA250: D6270021 04866B2B
	v_div_fmas_f32 v41, v41, v60, v77                          // 0000001BA258: D6370029 05367929
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000001BA260: 7C3690FF C2B17218
	v_mul_f32_e32 v43, 0xbfb8aa3b, v45                         // 0000001BA268: 10565AFF BFB8AA3B
	.long 0x7f6a3980                                           // 0000001BA270: 7F6A3980
	.long 0x7e6a39a1                                           // 0000001BA274: 7E6A39A1
	v_div_fixup_f32 v34, v41, v44, v34                         // 0000001BA278: D6270022 048A5929
	v_cndmask_b32_e32 v54, 0x7f800000, v54, vcc_lo             // 0000001BA280: 026C6CFF 7F800000
	v_rcp_f32_e32 v41, v57                                     // 0000001BA288: 7E525539
	v_fma_f32 v59, 0xbfb8aa3b, v45, -v43                       // 0000001BA28C: D613003B 84AE5AFF BFB8AA3B
	v_rndne_f32_e32 v60, v43                                   // 0000001BA298: 7E78472B
	.long 0x7e0039a2                                           // 0000001BA29C: 7E0039A2
	v_dual_add_f32 v44, 1.0, v54 :: v_dual_and_b32 v53, 1, v53 // 0000001BA2A0: C9246CF2 2C346A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BA2A8: BF870214
	v_fmac_f32_e32 v59, 0xb2a5705f, v45                        // 0000001BA2AC: 56765AFF B2A5705F
	v_sub_f32_e32 v43, v43, v60                                // 0000001BA2B4: 0856792B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BA2B8: BF870214
	v_and_b32_e32 v61, 1, v0                                   // 0000001BA2BC: 367A0081
	v_div_scale_f32 v42, null, v44, v44, v36                   // 0000001BA2C0: D6FC7C2A 0492592C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001BA2C8: BF870005
	v_fma_f32 v54, -v57, v41, 1.0                              // 0000001BA2CC: D6130036 23CA5339
	v_cvt_i32_f32_e32 v60, v60                                 // 0000001BA2D4: 7E78113C
	v_add_f32_e32 v43, v43, v59                                // 0000001BA2D8: 0656772B
	v_add3_u32 v34, v34, v61, 0x7fff                           // 0000001BA2DC: D6550022 03FE7B22 00007FFF
	v_rcp_f32_e32 v58, v42                                     // 0000001BA2E8: 7E74552A
	v_fmac_f32_e32 v41, v54, v41                               // 0000001BA2EC: 56525336
	v_div_scale_f32 v54, vcc_lo, v35, v46, v35                 // 0000001BA2F0: D6FC6A36 048E5D23
	v_exp_f32_e32 v43, v43                                     // 0000001BA2F8: 7E564B2B
	v_add_f32_e32 v71, v71, v73                                // 0000001BA2FC: 068E9347
	v_add3_u32 v33, v33, v53, 0x7fff                           // 0000001BA300: D6550021 03FE6B21 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001BA30C: BF870313
	v_mul_f32_e32 v59, v54, v41                                // 0000001BA310: 10765336
	v_fma_f32 v72, -v42, v58, 1.0                              // 0000001BA314: D6130048 23CA752A
	global_store_d16_hi_b16 v[7:8], v33, off offset:96         // 0000001BA31C: DC960060 007C2107
	v_fma_f32 v61, -v57, v59, v54                              // 0000001BA324: D613003D 24DA7739
	.long 0xd71c002b                                           // 0000001BA32C: D71C002B
	v_cndmask_b32_e32 v1, v43, v60, vcc_lo                     // 0000001BA330: 0202792B
	v_exp_f32_e32 v60, v71                                     // 0000001BA334: 7E784B47
	v_fmac_f32_e32 v58, v72, v58                               // 0000001BA338: 56747548
	v_div_scale_f32 v72, s0, v36, v44, v36                     // 0000001BA33C: D6FC0048 04925924
	v_fmac_f32_e32 v59, v61, v41                               // 0000001BA344: 5676533D
	v_cndmask_b32_e64 v43, 0, v43, s1                          // 0000001BA348: D501002B 00065680
	.long 0xd41b0001                                           // 0000001BA350: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v45, vcc_lo              // 0000001BA354: 02025AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v34, off offset:96       // 0000001BA35C: DC960060 007C222F
	v_mul_f32_e32 v75, v72, v58                                // 0000001BA364: 10967548
	v_fma_f32 v54, -v57, v59, v54                              // 0000001BA368: D6130036 24DA7739
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 0000001BA370: D501002B 000656FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BA37C: BF870193
	v_fma_f32 v53, -v42, v75, v72                              // 0000001BA380: D6130035 2522972A
	v_div_fmas_f32 v41, v54, v41, v59                          // 0000001BA388: D6370029 04EE5336
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v62                  // 0000001BA390: 7C3C7CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BA398: BF870214
	v_add_f32_e32 v43, 1.0, v43                                // 0000001BA39C: 065656F2
	v_fmac_f32_e32 v75, v53, v58                               // 0000001BA3A0: 56967535
	v_cvt_i32_f32_e32 v53, v74                                 // 0000001BA3A4: 7E6A114A
	v_div_fixup_f32 v35, v41, v46, v35                         // 0000001BA3A8: D6270023 048E5D29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BA3B0: BF870193
	v_fma_f32 v42, -v42, v75, v72                              // 0000001BA3B4: D613002A 2522972A
	.long 0xd71c002d                                           // 0000001BA3BC: D71C002D
	v_cndmask_b32_e32 v1, v60, v53, vcc_lo                     // 0000001BA3C0: 02026B3C
	v_div_scale_f32 v53, null, v43, v43, v37                   // 0000001BA3C4: D6FC7C35 0496572B
	s_waitcnt vmcnt(4)                                         // 0000001BA3CC: BF8913F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BA3D0: BF8700A2
	v_dual_cndmask_b32 v45, 0, v45 :: v_dual_lshlrev_b32 v60, 16, v136// 0000001BA3D4: CA625A80 2D3D1090
	s_mov_b32 vcc_lo, s0                                       // 0000001BA3DC: BEEA0000
	v_mul_f32_e32 v61, 0xbfb8aa3b, v60                         // 0000001BA3E0: 107A78FF BFB8AA3B
	v_div_fmas_f32 v42, v42, v58, v75                          // 0000001BA3E8: D637002A 052E752A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v62                  // 0000001BA3F0: 7C367CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BA3F8: BF870193
	v_fma_f32 v71, 0xbfb8aa3b, v60, -v61                       // 0000001BA3FC: D6130047 84F678FF BFB8AA3B
	v_div_fixup_f32 v33, v42, v44, v36                         // 0000001BA408: D6270021 0492592A
	v_dual_cndmask_b32 v45, 0x7f800000, v45 :: v_dual_mul_f32 v36, v38, v51// 0000001BA410: CA465AFF 2D246726 7F800000
	v_lshlrev_b32_e32 v44, 16, v86                             // 0000001BA41C: 3058AC90
	v_rcp_f32_e32 v38, v53                                     // 0000001BA420: 7E4C5535
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BA424: BF870193
	.long 0x7e0039a1                                           // 0000001BA428: 7E0039A1
	v_add_f32_e32 v42, 1.0, v45                                // 0000001BA42C: 06545AF2
	v_rndne_f32_e32 v72, v61                                   // 0000001BA430: 7E90473D
	v_mul_f32_e32 v41, 0xbfb8aa3b, v44                         // 0000001BA434: 105258FF BFB8AA3B
	.long 0x7e5a39a3                                           // 0000001BA43C: 7E5A39A3
	.long 0x7f5a3980                                           // 0000001BA440: 7F5A3980
	v_div_scale_f32 v34, null, v42, v42, v36                   // 0000001BA444: D6FC7C22 0492552A
	v_and_b32_e32 v59, 1, v0                                   // 0000001BA44C: 36760081
	v_fma_f32 v57, 0xbfb8aa3b, v44, -v41                       // 0000001BA450: D6130039 84A658FF BFB8AA3B
	v_rndne_f32_e32 v58, v41                                   // 0000001BA45C: 7E744729
	v_fma_f32 v46, -v53, v38, 1.0                              // 0000001BA460: D613002E 23CA4D35
	v_rcp_f32_e32 v54, v34                                     // 0000001BA468: 7E6C5522
	v_fmac_f32_e32 v71, 0xb2a5705f, v60                        // 0000001BA46C: 568E78FF B2A5705F
	v_fmac_f32_e32 v57, 0xb2a5705f, v44                        // 0000001BA474: 567258FF B2A5705F
	v_sub_f32_e32 v41, v41, v58                                // 0000001BA47C: 08527529
	v_fmac_f32_e32 v38, v46, v38                               // 0000001BA480: 564C4D2E
	v_div_scale_f32 v46, vcc_lo, v37, v43, v37                 // 0000001BA484: D6FC6A2E 04965725
	v_sub_f32_e32 v61, v61, v72                                // 0000001BA48C: 087A913D
	v_and_b32_e32 v45, 1, v45                                  // 0000001BA490: 365A5A81
	v_add_f32_e32 v41, v41, v57                                // 0000001BA494: 06527329
	v_add3_u32 v33, v33, v59, 0x7fff                           // 0000001BA498: D6550021 03FE7721 00007FFF
	v_fma_f32 v62, -v34, v54, 1.0                              // 0000001BA4A4: D613003E 23CA6D22
	v_mul_f32_e32 v57, v46, v38                                // 0000001BA4AC: 10724D2E
	v_cvt_i32_f32_e32 v58, v58                                 // 0000001BA4B0: 7E74113A
	v_exp_f32_e32 v41, v41                                     // 0000001BA4B4: 7E524B29
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001BA4B8: BF870253
	v_dual_add_f32 v61, v61, v71 :: v_dual_fmac_f32 v54, v62, v54// 0000001BA4BC: C9008F3D 3D366D3E
	v_div_scale_f32 v62, s0, v36, v42, v36                     // 0000001BA4C4: D6FC003E 04925524
	v_fma_f32 v59, -v53, v57, v46                              // 0000001BA4CC: D613003B 24BA7335
	v_add3_u32 v35, v35, v45, 0x7fff                           // 0000001BA4D4: D6550023 03FE5B23 00007FFF
	.long 0xd41e0001                                           // 0000001BA4E0: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v44, vcc_lo              // 0000001BA4E4: 020258FF 42CE8ED0
	v_mul_f32_e32 v73, v62, v54                                // 0000001BA4EC: 10926D3E
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001BA4F0: BF870294
	v_fmac_f32_e32 v57, v59, v38                               // 0000001BA4F4: 56724D3B
	.long 0xd71c0029                                           // 0000001BA4F8: D71C0029
	v_cndmask_b32_e32 v1, v41, v58, vcc_lo                     // 0000001BA4FC: 02027529
	v_exp_f32_e32 v58, v61                                     // 0000001BA500: 7E744B3D
	global_store_d16_hi_b16 v[15:16], v35, off offset:96       // 0000001BA504: DC960060 007C230F
	v_fma_f32 v45, -v34, v73, v62                              // 0000001BA50C: D613002D 24FA9322
	v_fma_f32 v46, -v53, v57, v46                              // 0000001BA514: D613002E 24BA7335
	v_cndmask_b32_e64 v41, 0, v41, s1                          // 0000001BA51C: D5010029 00065280
	.long 0xd41b0001                                           // 0000001BA524: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v44, vcc_lo              // 0000001BA528: 020258FF C2B17218
	global_store_d16_hi_b16 v[23:24], v33, off offset:96       // 0000001BA530: DC960060 007C2117
	v_fmac_f32_e32 v73, v45, v54                               // 0000001BA538: 56926D2D
	v_cvt_i32_f32_e32 v45, v72                                 // 0000001BA53C: 7E5A1148
	v_div_fmas_f32 v38, v46, v38, v57                          // 0000001BA540: D6370026 04E64D2E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v60                  // 0000001BA548: 7C3C78FF 42CE8ED0
	v_cndmask_b32_e64 v41, 0x7f800000, v41, s1                 // 0000001BA550: D5010029 000652FF 7F800000
	v_fma_f32 v34, -v34, v73, v62                              // 0000001BA55C: D6130022 24FA9322
	.long 0xd71c002c                                           // 0000001BA564: D71C002C
	v_cndmask_b32_e32 v1, v58, v45, vcc_lo                     // 0000001BA568: 02025B3A
	v_div_fixup_f32 v37, v38, v43, v37                         // 0000001BA56C: D6270025 04965726
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BA574: BF870224
	v_dual_add_f32 v41, 1.0, v41 :: v_dual_lshlrev_b32 v58, 16, v127// 0000001BA578: C92252F2 293AFE90
	.long 0x7f563980                                           // 0000001BA580: 7F563980
	v_cndmask_b32_e32 v44, 0, v44, vcc_lo                      // 0000001BA584: 02585880
	s_mov_b32 vcc_lo, s0                                       // 0000001BA588: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BA58C: BF870003
	v_mul_f32_e32 v59, 0xbfb8aa3b, v58                         // 0000001BA590: 107674FF BFB8AA3B
	v_div_fmas_f32 v34, v34, v54, v73                          // 0000001BA598: D6370022 05266D22
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v60                  // 0000001BA5A0: 7C3678FF C2B17218
	v_div_scale_f32 v45, null, v41, v41, v25                   // 0000001BA5A8: D6FC7C2D 04665329
	.long 0x7e5639a5                                           // 0000001BA5B0: 7E5639A5
	v_fma_f32 v61, 0xbfb8aa3b, v58, -v59                       // 0000001BA5B4: D613003D 84EE74FF BFB8AA3B
	v_div_fixup_f32 v34, v34, v42, v36                         // 0000001BA5C0: D6270022 04925522
	v_cndmask_b32_e32 v44, 0x7f800000, v44, vcc_lo             // 0000001BA5C8: 025858FF 7F800000
	v_lshlrev_b32_e32 v42, 16, v128                            // 0000001BA5D0: 30550090
	v_rcp_f32_e32 v35, v45                                     // 0000001BA5D4: 7E46552D
	v_rndne_f32_e32 v62, v59                                   // 0000001BA5D8: 7E7C473B
	.long 0x7e0039a2                                           // 0000001BA5DC: 7E0039A2
	v_add_f32_e32 v36, 1.0, v44                                // 0000001BA5E0: 064858F2
	v_mul_f32_e32 v38, 0xbfb8aa3b, v42                         // 0000001BA5E4: 104C54FF BFB8AA3B
	v_fmac_f32_e32 v61, 0xb2a5705f, v58                        // 0000001BA5EC: 567A74FF B2A5705F
	v_sub_f32_e32 v59, v59, v62                                // 0000001BA5F4: 08767D3B
	v_and_b32_e32 v57, 1, v0                                   // 0000001BA5F8: 36720081
	v_div_scale_f32 v33, null, v36, v36, v26                   // 0000001BA5FC: D6FC7C21 046A4924
	v_fma_f32 v53, 0xbfb8aa3b, v42, -v38                       // 0000001BA604: D6130035 849A54FF BFB8AA3B
	v_rndne_f32_e32 v54, v38                                   // 0000001BA610: 7E6C4726
	v_fma_f32 v44, -v45, v35, 1.0                              // 0000001BA614: D613002C 23CA472D
	v_and_b32_e32 v43, 1, v43                                  // 0000001BA61C: 36565681
	v_rcp_f32_e32 v46, v33                                     // 0000001BA620: 7E5C5521
	v_fmac_f32_e32 v53, 0xb2a5705f, v42                        // 0000001BA624: 566A54FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001BA62C: BF870243
	v_dual_sub_f32 v38, v38, v54 :: v_dual_fmac_f32 v35, v44, v35// 0000001BA630: C9406D26 2622472C
	v_div_scale_f32 v44, vcc_lo, v25, v41, v25                 // 0000001BA638: D6FC6A2C 04665319
	v_add3_u32 v34, v34, v57, 0x7fff                           // 0000001BA640: D6550022 03FE7322 00007FFF
	v_cvt_i32_f32_e32 v54, v54                                 // 0000001BA64C: 7E6C1136
	v_add_f32_e32 v38, v38, v53                                // 0000001BA650: 064C6B26
	v_add_f32_e32 v59, v59, v61                                // 0000001BA654: 06767B3B
	v_mul_f32_e32 v53, v44, v35                                // 0000001BA658: 106A472C
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001BA65C: BF870005
	v_fma_f32 v60, -v33, v46, 1.0                              // 0000001BA660: D613003C 23CA5D21
	v_add3_u32 v37, v37, v43, 0x7fff                           // 0000001BA668: D6550025 03FE5725 00007FFF
	v_exp_f32_e32 v38, v38                                     // 0000001BA674: 7E4C4B26
	.long 0xd41e0001                                           // 0000001BA678: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v42, vcc_lo              // 0000001BA67C: 020254FF 42CE8ED0
	v_fma_f32 v57, -v45, v53, v44                              // 0000001BA684: D6130039 24B26B2D
	v_fmac_f32_e32 v46, v60, v46                               // 0000001BA68C: 565C5D3C
	v_div_scale_f32 v60, s0, v26, v36, v26                     // 0000001BA690: D6FC003C 046A491A
	global_store_d16_hi_b16 v[31:32], v37, off offset:96       // 0000001BA698: DC960060 007C251F
	v_lshlrev_b32_e32 v37, 16, v130                            // 0000001BA6A0: 304B0490
	v_fmac_f32_e32 v53, v57, v35                               // 0000001BA6A4: 566A4739
	global_store_d16_hi_b16 v[39:40], v34, off offset:96       // 0000001BA6A8: DC960060 007C2227
	v_mul_f32_e32 v71, v60, v46                                // 0000001BA6B0: 108E5D3C
	.long 0xd71c0026                                           // 0000001BA6B4: D71C0026
	v_cndmask_b32_e32 v1, v38, v54, vcc_lo                     // 0000001BA6B8: 02026D26
	v_exp_f32_e32 v54, v59                                     // 0000001BA6BC: 7E6C4B3B
	v_fma_f32 v44, -v45, v53, v44                              // 0000001BA6C0: D613002C 24B26B2D
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BA6C8: BF870193
	v_fma_f32 v43, -v33, v71, v60                              // 0000001BA6CC: D613002B 24F28F21
	v_cndmask_b32_e64 v38, 0, v38, s1                          // 0000001BA6D4: D5010026 00064C80
	.long 0xd41b0001                                           // 0000001BA6DC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v42, vcc_lo              // 0000001BA6E0: 020254FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BA6E8: BF870004
	v_div_fmas_f32 v35, v44, v35, v53                          // 0000001BA6EC: D6370023 04D6472C
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v58                  // 0000001BA6F4: 7C3C74FF 42CE8ED0
	v_fmac_f32_e32 v71, v43, v46                               // 0000001BA6FC: 568E5D2B
	v_cvt_i32_f32_e32 v43, v62                                 // 0000001BA700: 7E56113E
	v_cndmask_b32_e64 v38, 0x7f800000, v38, s1                 // 0000001BA704: D5010026 00064CFF 7F800000
	v_div_fixup_f32 v25, v35, v41, v25                         // 0000001BA710: D6270019 04665323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v37                         // 0000001BA718: 10464AFF BFB8AA3B
	v_fma_f32 v33, -v33, v71, v60                              // 0000001BA720: D6130021 24F28F21
	.long 0xd71c002a                                           // 0000001BA728: D71C002A
	v_cndmask_b32_e32 v1, v54, v43, vcc_lo                     // 0000001BA72C: 02025736
	v_add_f32_e32 v38, 1.0, v38                                // 0000001BA730: 064C4CF2
	v_lshlrev_b32_e32 v54, 16, v129                            // 0000001BA734: 306D0290
	v_fma_f32 v45, 0xbfb8aa3b, v37, -v35                       // 0000001BA738: D613002D 848E4AFF BFB8AA3B
	.long 0x7e523999                                           // 0000001BA744: 7E523999
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000001BA748: 02545480
	s_mov_b32 vcc_lo, s0                                       // 0000001BA74C: BEEA0000
	v_div_scale_f32 v43, null, v38, v38, v27                   // 0000001BA750: D6FC7C2B 046E4D26
	v_div_fmas_f32 v33, v33, v46, v71                          // 0000001BA758: D6370021 051E5D21
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v58                  // 0000001BA760: 7C3674FF C2B17218
	v_rndne_f32_e32 v46, v35                                   // 0000001BA768: 7E5C4723
	v_fmac_f32_e32 v45, 0xb2a5705f, v37                        // 0000001BA76C: 565A4AFF B2A5705F
	v_mul_f32_e32 v57, 0xbfb8aa3b, v54                         // 0000001BA774: 10726CFF BFB8AA3B
	v_div_fixup_f32 v26, v33, v36, v26                         // 0000001BA77C: D627001A 046A4921
	v_cndmask_b32_e32 v42, 0x7f800000, v42, vcc_lo             // 0000001BA784: 025454FF 7F800000
	v_rcp_f32_e32 v33, v43                                     // 0000001BA78C: 7E42552B
	v_sub_f32_e32 v35, v35, v46                                // 0000001BA790: 08465D23
	v_fma_f32 v59, 0xbfb8aa3b, v54, -v57                       // 0000001BA794: D613003B 84E66CFF BFB8AA3B
	.long 0x7e00399a                                           // 0000001BA7A0: 7E00399A
	v_add_f32_e32 v36, 1.0, v42                                // 0000001BA7A4: 064854F2
	v_rndne_f32_e32 v60, v57                                   // 0000001BA7A8: 7E784739
	v_add_f32_e32 v35, v35, v45                                // 0000001BA7AC: 06465B23
	.long 0x7f523980                                           // 0000001BA7B0: 7F523980
	v_and_b32_e32 v53, 1, v0                                   // 0000001BA7B4: 366A0081
	v_div_scale_f32 v34, null, v36, v36, v28                   // 0000001BA7B8: D6FC7C22 04724924
	v_fma_f32 v42, -v43, v33, 1.0                              // 0000001BA7C0: D613002A 23CA432B
	v_exp_f32_e32 v35, v35                                     // 0000001BA7C8: 7E464B23
	v_fmac_f32_e32 v59, 0xb2a5705f, v54                        // 0000001BA7CC: 56766CFF B2A5705F
	v_sub_f32_e32 v57, v57, v60                                // 0000001BA7D4: 08727939
	v_rcp_f32_e32 v44, v34                                     // 0000001BA7D8: 7E585522
	v_fmac_f32_e32 v33, v42, v33                               // 0000001BA7DC: 5642432A
	v_div_scale_f32 v42, vcc_lo, v27, v38, v27                 // 0000001BA7E0: D6FC6A2A 046E4D1B
	v_and_b32_e32 v41, 1, v41                                  // 0000001BA7E8: 36525281
	v_add3_u32 v26, v26, v53, 0x7fff                           // 0000001BA7EC: D655001A 03FE6B1A 00007FFF
	v_cvt_i32_f32_e32 v46, v46                                 // 0000001BA7F8: 7E5C112E
	v_add_f32_e32 v57, v57, v59                                // 0000001BA7FC: 06727739
	v_mul_f32_e32 v45, v42, v33                                // 0000001BA800: 105A432A
	v_add3_u32 v25, v25, v41, 0x7fff                           // 0000001BA804: D6550019 03FE5319 00007FFF
	.long 0xd41e0001                                           // 0000001BA810: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v37, vcc_lo              // 0000001BA814: 02024AFF 42CE8ED0
	v_fma_f32 v58, -v34, v44, 1.0                              // 0000001BA81C: D613003A 23CA5922
	.long 0xd71c0023                                           // 0000001BA824: D71C0023
	v_cndmask_b32_e32 v1, v35, v46, vcc_lo                     // 0000001BA828: 02025D23
	v_fma_f32 v53, -v43, v45, v42                              // 0000001BA82C: D6130035 24AA5B2B
	v_exp_f32_e32 v46, v57                                     // 0000001BA834: 7E5C4B39
	global_store_d16_hi_b16 v[7:8], v25, off offset:128        // 0000001BA838: DC960080 007C1907
	v_fmac_f32_e32 v44, v58, v44                               // 0000001BA840: 5658593A
	v_div_scale_f32 v58, s0, v28, v36, v28                     // 0000001BA844: D6FC003A 0472491C
	v_fmac_f32_e32 v45, v53, v33                               // 0000001BA84C: 565A4335
	v_cndmask_b32_e64 v35, 0, v35, s1                          // 0000001BA850: D5010023 00064680
	.long 0xd41b0001                                           // 0000001BA858: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v37, vcc_lo              // 0000001BA85C: 02024AFF C2B17218
	global_store_d16_hi_b16 v[47:48], v26, off offset:128      // 0000001BA864: DC960080 007C1A2F
	v_mul_f32_e32 v61, v58, v44                                // 0000001BA86C: 107A593A
	v_fma_f32 v42, -v43, v45, v42                              // 0000001BA870: D613002A 24AA5B2B
	v_cndmask_b32_e64 v35, 0x7f800000, v35, s1                 // 0000001BA878: D5010023 000646FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BA884: BF870193
	v_fma_f32 v41, -v34, v61, v58                              // 0000001BA888: D6130029 24EA7B22
	v_div_fmas_f32 v33, v42, v33, v45                          // 0000001BA890: D6370021 04B6432A
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v54                  // 0000001BA898: 7C3C6CFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BA8A0: BF870214
	v_add_f32_e32 v35, 1.0, v35                                // 0000001BA8A4: 064646F2
	v_fmac_f32_e32 v61, v41, v44                               // 0000001BA8A8: 567A5929
	v_cvt_i32_f32_e32 v41, v60                                 // 0000001BA8AC: 7E52113C
	v_div_fixup_f32 v27, v33, v38, v27                         // 0000001BA8B0: D627001B 046E4D21
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BA8B8: BF870193
	v_fma_f32 v34, -v34, v61, v58                              // 0000001BA8BC: D6130022 24EA7B22
	.long 0xd71c0025                                           // 0000001BA8C4: D71C0025
	v_cndmask_b32_e32 v1, v46, v41, vcc_lo                     // 0000001BA8C8: 0202532E
	v_div_scale_f32 v41, null, v35, v35, v29                   // 0000001BA8CC: D6FC7C29 04764723
	s_waitcnt vmcnt(3)                                         // 0000001BA8D4: BF890FF7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001BA8D8: BF8700A2
	v_dual_cndmask_b32 v37, 0, v37 :: v_dual_lshlrev_b32 v46, 16, v131// 0000001BA8DC: CA624A80 252F0690
	s_mov_b32 vcc_lo, s0                                       // 0000001BA8E4: BEEA0000
	v_mul_f32_e32 v53, 0xbfb8aa3b, v46                         // 0000001BA8E8: 106A5CFF BFB8AA3B
	v_div_fmas_f32 v34, v34, v44, v61                          // 0000001BA8F0: D6370022 04F65922
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v54                  // 0000001BA8F8: 7C366CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BA900: BF870193
	v_fma_f32 v57, 0xbfb8aa3b, v46, -v53                       // 0000001BA904: D6130039 84D65CFF BFB8AA3B
	v_div_fixup_f32 v25, v34, v36, v28                         // 0000001BA910: D6270019 04724922
	v_dual_cndmask_b32 v37, 0x7f800000, v37 :: v_dual_mul_f32 v28, v30, v51// 0000001BA918: CA464AFF 251C671E 7F800000
	v_lshlrev_b32_e32 v36, 16, v87                             // 0000001BA924: 3048AE90
	v_rcp_f32_e32 v30, v41                                     // 0000001BA928: 7E3C5529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BA92C: BF870193
	.long 0x7e003999                                           // 0000001BA930: 7E003999
	v_add_f32_e32 v34, 1.0, v37                                // 0000001BA934: 06444AF2
	v_rndne_f32_e32 v58, v53                                   // 0000001BA938: 7E744735
	v_mul_f32_e32 v33, 0xbfb8aa3b, v36                         // 0000001BA93C: 104248FF BFB8AA3B
	.long 0x7e4a399b                                           // 0000001BA944: 7E4A399B
	.long 0x7f4a3980                                           // 0000001BA948: 7F4A3980
	v_div_scale_f32 v26, null, v34, v34, v28                   // 0000001BA94C: D6FC7C1A 04724522
	v_and_b32_e32 v45, 1, v0                                   // 0000001BA954: 365A0081
	v_fma_f32 v43, 0xbfb8aa3b, v36, -v33                       // 0000001BA958: D613002B 848648FF BFB8AA3B
	v_rndne_f32_e32 v44, v33                                   // 0000001BA964: 7E584721
	v_fma_f32 v38, -v41, v30, 1.0                              // 0000001BA968: D6130026 23CA3D29
	v_rcp_f32_e32 v42, v26                                     // 0000001BA970: 7E54551A
	v_fmac_f32_e32 v57, 0xb2a5705f, v46                        // 0000001BA974: 56725CFF B2A5705F
	v_fmac_f32_e32 v43, 0xb2a5705f, v36                        // 0000001BA97C: 565648FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001BA984: BF870243
	v_dual_sub_f32 v33, v33, v44 :: v_dual_fmac_f32 v30, v38, v30// 0000001BA988: C9405921 211E3D26
	v_div_scale_f32 v38, vcc_lo, v29, v35, v29                 // 0000001BA990: D6FC6A26 0476471D
	v_sub_f32_e32 v53, v53, v58                                // 0000001BA998: 086A7535
	v_and_b32_e32 v37, 1, v37                                  // 0000001BA99C: 364A4A81
	v_add_f32_e32 v33, v33, v43                                // 0000001BA9A0: 06425721
	v_add3_u32 v25, v25, v45, 0x7fff                           // 0000001BA9A4: D6550019 03FE5B19 00007FFF
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001BA9B0: BF8701C5
	v_fma_f32 v54, -v26, v42, 1.0                              // 0000001BA9B4: D6130036 23CA551A
	v_mul_f32_e32 v43, v38, v30                                // 0000001BA9BC: 10563D26
	v_cvt_i32_f32_e32 v44, v44                                 // 0000001BA9C0: 7E58112C
	v_exp_f32_e32 v33, v33                                     // 0000001BA9C4: 7E424B21
	v_dual_add_f32 v53, v53, v57 :: v_dual_fmac_f32 v42, v54, v42// 0000001BA9C8: C9007335 352A5536
	v_div_scale_f32 v54, s0, v28, v34, v28                     // 0000001BA9D0: D6FC0036 0472451C
	v_fma_f32 v45, -v41, v43, v38                              // 0000001BA9D8: D613002D 249A5729
	v_add3_u32 v27, v27, v37, 0x7fff                           // 0000001BA9E0: D655001B 03FE4B1B 00007FFF
	.long 0xd41e0001                                           // 0000001BA9EC: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v36, vcc_lo              // 0000001BA9F0: 020248FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BA9F8: BF870214
	v_mul_f32_e32 v59, v54, v42                                // 0000001BA9FC: 10765536
	v_fmac_f32_e32 v43, v45, v30                               // 0000001BAA00: 56563D2D
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001BAA04: BF870005
	.long 0xd71c0021                                           // 0000001BAA08: D71C0021
	v_cndmask_b32_e32 v1, v33, v44, vcc_lo                     // 0000001BAA0C: 02025921
	v_exp_f32_e32 v44, v53                                     // 0000001BAA10: 7E584B35
	global_store_d16_hi_b16 v[15:16], v27, off offset:128      // 0000001BAA14: DC960080 007C1B0F
	v_fma_f32 v37, -v26, v59, v54                              // 0000001BAA1C: D6130025 24DA771A
	v_fma_f32 v38, -v41, v43, v38                              // 0000001BAA24: D6130026 249A5729
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 0000001BAA2C: D5010021 00064280
	.long 0xd41b0001                                           // 0000001BAA34: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v36, vcc_lo              // 0000001BAA38: 020248FF C2B17218
	global_store_d16_hi_b16 v[23:24], v25, off offset:128      // 0000001BAA40: DC960080 007C1917
	v_fmac_f32_e32 v59, v37, v42                               // 0000001BAA48: 56765525
	v_cvt_i32_f32_e32 v37, v58                                 // 0000001BAA4C: 7E4A113A
	v_div_fmas_f32 v30, v38, v30, v43                          // 0000001BAA50: D637001E 04AE3D26
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v46                  // 0000001BAA58: 7C3C5CFF 42CE8ED0
	v_cndmask_b32_e64 v33, 0x7f800000, v33, s1                 // 0000001BAA60: D5010021 000642FF 7F800000
	v_fma_f32 v26, -v26, v59, v54                              // 0000001BAA6C: D613001A 24DA771A
	.long 0xd71c0024                                           // 0000001BAA74: D71C0024
	v_cndmask_b32_e32 v1, v44, v37, vcc_lo                     // 0000001BAA78: 02024B2C
	v_div_fixup_f32 v29, v30, v35, v29                         // 0000001BAA7C: D627001D 0476471E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BAA84: BF870224
	v_dual_add_f32 v33, 1.0, v33 :: v_dual_lshlrev_b32 v44, 16, v123// 0000001BAA88: C92242F2 212CF690
	.long 0x7f463980                                           // 0000001BAA90: 7F463980
	v_cndmask_b32_e32 v36, 0, v36, vcc_lo                      // 0000001BAA94: 02484880
	s_mov_b32 vcc_lo, s0                                       // 0000001BAA98: BEEA0000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BAA9C: BF870003
	v_mul_f32_e32 v45, 0xbfb8aa3b, v44                         // 0000001BAAA0: 105A58FF BFB8AA3B
	v_div_fmas_f32 v26, v26, v42, v59                          // 0000001BAAA8: D637001A 04EE551A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v46                  // 0000001BAAB0: 7C365CFF C2B17218
	v_div_scale_f32 v37, null, v33, v33, v17                   // 0000001BAAB8: D6FC7C25 04464321
	.long 0x7e46399d                                           // 0000001BAAC0: 7E46399D
	v_fma_f32 v53, 0xbfb8aa3b, v44, -v45                       // 0000001BAAC4: D6130035 84B658FF BFB8AA3B
	v_div_fixup_f32 v26, v26, v34, v28                         // 0000001BAAD0: D627001A 0472451A
	v_cndmask_b32_e32 v36, 0x7f800000, v36, vcc_lo             // 0000001BAAD8: 024848FF 7F800000
	v_lshlrev_b32_e32 v34, 16, v124                            // 0000001BAAE0: 3044F890
	v_rcp_f32_e32 v27, v37                                     // 0000001BAAE4: 7E365525
	v_rndne_f32_e32 v54, v45                                   // 0000001BAAE8: 7E6C472D
	.long 0x7e00399a                                           // 0000001BAAEC: 7E00399A
	v_add_f32_e32 v28, 1.0, v36                                // 0000001BAAF0: 063848F2
	v_mul_f32_e32 v30, 0xbfb8aa3b, v34                         // 0000001BAAF4: 103C44FF BFB8AA3B
	v_fmac_f32_e32 v53, 0xb2a5705f, v44                        // 0000001BAAFC: 566A58FF B2A5705F
	v_sub_f32_e32 v45, v45, v54                                // 0000001BAB04: 085A6D2D
	v_and_b32_e32 v43, 1, v0                                   // 0000001BAB08: 36560081
	v_div_scale_f32 v25, null, v28, v28, v18                   // 0000001BAB0C: D6FC7C19 044A391C
	v_fma_f32 v41, 0xbfb8aa3b, v34, -v30                       // 0000001BAB14: D6130029 847A44FF BFB8AA3B
	v_rndne_f32_e32 v42, v30                                   // 0000001BAB20: 7E54471E
	v_fma_f32 v36, -v37, v27, 1.0                              // 0000001BAB24: D6130024 23CA3725
	v_and_b32_e32 v35, 1, v35                                  // 0000001BAB2C: 36464681
	v_rcp_f32_e32 v38, v25                                     // 0000001BAB30: 7E4C5519
	v_fmac_f32_e32 v41, 0xb2a5705f, v34                        // 0000001BAB34: 565244FF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001BAB3C: BF870243
	v_dual_sub_f32 v30, v30, v42 :: v_dual_fmac_f32 v27, v36, v27// 0000001BAB40: C940551E 1E1A3724
	v_div_scale_f32 v36, vcc_lo, v17, v33, v17                 // 0000001BAB48: D6FC6A24 04464311
	v_add3_u32 v26, v26, v43, 0x7fff                           // 0000001BAB50: D655001A 03FE571A 00007FFF
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001BAB5C: 7E54112A
	v_add_f32_e32 v30, v30, v41                                // 0000001BAB60: 063C531E
	v_add_f32_e32 v45, v45, v53                                // 0000001BAB64: 065A6B2D
	v_mul_f32_e32 v41, v36, v27                                // 0000001BAB68: 10523724
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001BAB6C: BF870005
	v_fma_f32 v46, -v25, v38, 1.0                              // 0000001BAB70: D613002E 23CA4D19
	v_add3_u32 v29, v29, v35, 0x7fff                           // 0000001BAB78: D655001D 03FE471D 00007FFF
	v_exp_f32_e32 v30, v30                                     // 0000001BAB84: 7E3C4B1E
	.long 0xd41e0001                                           // 0000001BAB88: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v34, vcc_lo              // 0000001BAB8C: 020244FF 42CE8ED0
	v_fma_f32 v43, -v37, v41, v36                              // 0000001BAB94: D613002B 24925325
	v_fmac_f32_e32 v38, v46, v38                               // 0000001BAB9C: 564C4D2E
	v_div_scale_f32 v46, s0, v18, v28, v18                     // 0000001BABA0: D6FC002E 044A3912
	s_clause 0x1                                               // 0000001BABA8: BF850001
	global_store_d16_hi_b16 v[31:32], v29, off offset:128      // 0000001BABAC: DC960080 007C1D1F
	global_store_d16_hi_b16 v[39:40], v26, off offset:128      // 0000001BABB4: DC960080 007C1A27
	v_dual_fmac_f32 v41, v43, v27 :: v_dual_lshlrev_b32 v26, 16, v126// 0000001BABBC: C822372B 291AFC90
	v_mul_f32_e32 v57, v46, v38                                // 0000001BABC4: 10724D2E
	.long 0xd71c001e                                           // 0000001BABC8: D71C001E
	v_cndmask_b32_e32 v1, v30, v42, vcc_lo                     // 0000001BABCC: 0202551E
	v_exp_f32_e32 v42, v45                                     // 0000001BABD0: 7E544B2D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BABD4: BF870003
	v_fma_f32 v36, -v37, v41, v36                              // 0000001BABD8: D6130024 24925325
	.long 0x7f3a3980                                           // 0000001BABE0: 7F3A3980
	v_fma_f32 v35, -v25, v57, v46                              // 0000001BABE4: D6130023 24BA7319
	v_cndmask_b32_e64 v30, 0, v30, s1                          // 0000001BABEC: D501001E 00063C80
	.long 0xd41b0001                                           // 0000001BABF4: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v34, vcc_lo              // 0000001BABF8: 020244FF C2B17218
	v_div_fmas_f32 v27, v36, v27, v41                          // 0000001BAC00: D637001B 04A63724
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v44                  // 0000001BAC08: 7C3C58FF 42CE8ED0
	v_fmac_f32_e32 v57, v35, v38                               // 0000001BAC10: 56724D23
	v_cvt_i32_f32_e32 v35, v54                                 // 0000001BAC14: 7E461136
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000001BAC18: D501001E 00063CFF 7F800000
	v_div_fixup_f32 v17, v27, v33, v17                         // 0000001BAC24: D6270011 0446431B
	v_mul_f32_e32 v33, 0xbfb8aa3b, v26                         // 0000001BAC2C: 104234FF BFB8AA3B
	v_fma_f32 v25, -v25, v57, v46                              // 0000001BAC34: D6130019 24BA7319
	.long 0xd71c0022                                           // 0000001BAC3C: D71C0022
	v_cndmask_b32_e32 v1, v42, v35, vcc_lo                     // 0000001BAC40: 0202472A
	v_add_f32_e32 v30, 1.0, v30                                // 0000001BAC44: 063C3CF2
	.long 0xd41e0001                                           // 0000001BAC48: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v26, vcc_lo              // 0000001BAC4C: 020234FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v26, -v33                       // 0000001BAC54: D6130029 848634FF BFB8AA3B
	v_rndne_f32_e32 v42, v33                                   // 0000001BAC60: 7E544721
	v_cndmask_b32_e32 v34, 0, v34, vcc_lo                      // 0000001BAC64: 02444480
	s_mov_b32 vcc_lo, s0                                       // 0000001BAC68: BEEA0000
	v_div_scale_f32 v35, null, v30, v30, v19                   // 0000001BAC6C: D6FC7C23 044E3D1E
	v_div_fmas_f32 v25, v25, v38, v57                          // 0000001BAC74: D6370019 04E64D19
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v44                  // 0000001BAC7C: 7C3658FF C2B17218
	v_dual_fmac_f32 v41, 0xb2a5705f, v26 :: v_dual_lshlrev_b32 v38, 16, v125// 0000001BAC84: C82234FF 2926FA90 B2A5705F
	v_sub_f32_e32 v33, v33, v42                                // 0000001BAC90: 08425521
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BAC94: BF870004
	v_div_fixup_f32 v18, v25, v28, v18                         // 0000001BAC98: D6270012 044A3919
	v_cndmask_b32_e32 v34, 0x7f800000, v34, vcc_lo             // 0000001BACA0: 024444FF 7F800000
	v_rcp_f32_e32 v25, v35                                     // 0000001BACA8: 7E325523
	v_mul_f32_e32 v43, 0xbfb8aa3b, v38                         // 0000001BACAC: 10564CFF BFB8AA3B
	v_add_f32_e32 v33, v33, v41                                // 0000001BACB4: 06425321
	.long 0x7e003992                                           // 0000001BACB8: 7E003992
	v_add_f32_e32 v28, 1.0, v34                                // 0000001BACBC: 063844F2
	v_cvt_i32_f32_e32 v42, v42                                 // 0000001BACC0: 7E54112A
	v_fma_f32 v46, 0xbfb8aa3b, v38, -v43                       // 0000001BACC4: D613002E 84AE4CFF BFB8AA3B
	v_rndne_f32_e32 v53, v43                                   // 0000001BACD0: 7E6A472B
	v_exp_f32_e32 v33, v33                                     // 0000001BACD4: 7E424B21
	v_div_scale_f32 v27, null, v28, v28, v20                   // 0000001BACD8: D6FC7C1B 0452391C
	v_fma_f32 v34, -v35, v25, 1.0                              // 0000001BACE0: D6130022 23CA3323
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BACE8: BF870223
	v_dual_fmac_f32 v46, 0xb2a5705f, v38 :: v_dual_sub_f32 v43, v43, v53// 0000001BACEC: C80A4CFF 2E2A6B2B B2A5705F
	v_div_scale_f32 v41, s0, v20, v28, v20                     // 0000001BACF8: D6FC0029 04523914
	v_rcp_f32_e32 v36, v27                                     // 0000001BAD00: 7E48551B
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BAD04: BF870003
	v_fmac_f32_e32 v25, v34, v25                               // 0000001BAD08: 56323322
	v_div_scale_f32 v34, vcc_lo, v19, v30, v19                 // 0000001BAD0C: D6FC6A22 044E3D13
	v_and_b32_e32 v37, 1, v0                                   // 0000001BAD14: 364A0081
	v_add_f32_e32 v43, v43, v46                                // 0000001BAD18: 06565D2B
	.long 0xd71c0021                                           // 0000001BAD1C: D71C0021
	v_cndmask_b32_e32 v1, v33, v42, vcc_lo                     // 0000001BAD20: 02025521
	.long 0x7e3a3991                                           // 0000001BAD24: 7E3A3991
	v_mul_f32_e32 v45, v34, v25                                // 0000001BAD28: 105A3322
	v_add3_u32 v18, v18, v37, 0x7fff                           // 0000001BAD2C: D6550012 03FE4B12 00007FFF
	v_exp_f32_e32 v37, v43                                     // 0000001BAD38: 7E4A4B2B
	v_fma_f32 v44, -v27, v36, 1.0                              // 0000001BAD3C: D613002C 23CA491B
	v_cndmask_b32_e64 v33, 0, v33, s1                          // 0000001BAD44: D5010021 00064280
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001BAD4C: BF870122
	v_dual_fmac_f32 v36, v44, v36 :: v_dual_and_b32 v29, 1, v29// 0000001BAD50: C824492C 241C3A81
	v_fma_f32 v44, -v35, v45, v34                              // 0000001BAD58: D613002C 248A5B23
	v_add3_u32 v17, v17, v29, 0x7fff                           // 0000001BAD60: D6550011 03FE3B11 00007FFF
	v_lshlrev_b32_e32 v29, 16, v92                             // 0000001BAD6C: 303AB890
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BAD70: BF870003
	v_dual_mul_f32 v54, v41, v36 :: v_dual_fmac_f32 v45, v44, v25// 0000001BAD74: C8C04929 362C332C
	s_clause 0x1                                               // 0000001BAD7C: BF850001
	global_store_d16_hi_b16 v[7:8], v17, off offset:160        // 0000001BAD80: DC9600A0 007C1107
	global_store_d16_hi_b16 v[47:48], v18, off offset:160      // 0000001BAD88: DC9600A0 007C122F
	v_fma_f32 v44, -v27, v54, v41                              // 0000001BAD90: D613002C 24A66D1B
	v_fma_f32 v34, -v35, v45, v34                              // 0000001BAD98: D6130022 248A5B23
	v_cvt_i32_f32_e32 v35, v53                                 // 0000001BADA0: 7E461135
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BADA4: BF870193
	v_fmac_f32_e32 v54, v44, v36                               // 0000001BADA8: 566C492C
	v_div_fmas_f32 v25, v34, v25, v45                          // 0000001BADAC: D6370019 04B63322
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v26                  // 0000001BADB4: 7C3634FF C2B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BADBC: BF870004
	.long 0xd71c0022                                           // 0000001BADC0: D71C0022
	v_cndmask_b32_e32 v1, v37, v35, vcc_lo                     // 0000001BADC4: 02024725
	v_mul_f32_e32 v35, 0xbfb8aa3b, v29                         // 0000001BADC8: 10463AFF BFB8AA3B
	v_fma_f32 v27, -v27, v54, v41                              // 0000001BADD0: D613001B 24A66D1B
	v_div_fixup_f32 v17, v25, v30, v19                         // 0000001BADD8: D6270011 044E3D19
	v_cndmask_b32_e32 v26, 0x7f800000, v33, vcc_lo             // 0000001BADE0: 023442FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 0000001BADE8: 7C3C4CFF 42CE8ED0
	.long 0x7f3c3980                                           // 0000001BADF0: 7F3C3980
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BADF4: BF870214
	.long 0x7e3c3991                                           // 0000001BADF8: 7E3C3991
	v_add_f32_e32 v26, 1.0, v26                                // 0000001BADFC: 063434F2
	v_cndmask_b32_e32 v33, 0, v34, vcc_lo                      // 0000001BAE00: 02424480
	s_mov_b32 vcc_lo, s0                                       // 0000001BAE04: BEEA0000
	v_div_fmas_f32 v27, v27, v36, v54                          // 0000001BAE08: D637001B 04DA491B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 0000001BAE10: 7C364CFF C2B17218
	v_rndne_f32_e32 v36, v35                                   // 0000001BAE18: 7E484723
	s_waitcnt vmcnt(2)                                         // 0000001BAE1C: BF890BF7
	v_lshlrev_b32_e32 v38, 16, v68                             // 0000001BAE20: 304C8890
	v_and_b32_e32 v30, 1, v30                                  // 0000001BAE24: 363C3C81
	v_div_fixup_f32 v20, v27, v28, v20                         // 0000001BAE28: D6270014 0452391B
	v_cndmask_b32_e32 v33, 0x7f800000, v33, vcc_lo             // 0000001BAE30: 024242FF 7F800000
	v_div_scale_f32 v27, null, v26, v26, v21                   // 0000001BAE38: D6FC7C1B 0456351A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BAE40: BF870214
	v_add3_u32 v17, v17, v30, 0x7fff                           // 0000001BAE44: D6550011 03FE3D11 00007FFF
	.long 0x7e003994                                           // 0000001BAE50: 7E003994
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BAE54: BF870214
	v_add_f32_e32 v28, 1.0, v33                                // 0000001BAE58: 063842F2
	v_rcp_f32_e32 v19, v27                                     // 0000001BAE5C: 7E26551B
	global_store_d16_hi_b16 v[15:16], v17, off offset:160      // 0000001BAE60: DC9600A0 007C110F
	v_and_b32_e32 v33, 1, v0                                   // 0000001BAE68: 36420081
	v_div_scale_f32 v25, null, v28, v28, v22                   // 0000001BAE6C: D6FC7C19 045A391C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BAE74: BF870112
	v_add3_u32 v20, v20, v33, 0x7fff                           // 0000001BAE78: D6550014 03FE4314 00007FFF
	v_rcp_f32_e32 v34, v25                                     // 0000001BAE84: 7E445519
	v_fma_f32 v18, -v27, v19, 1.0                              // 0000001BAE88: D6130012 23CA271B
	v_fma_f32 v33, 0xbfb8aa3b, v29, -v35                       // 0000001BAE90: D6130021 848E3AFF BFB8AA3B
	v_sub_f32_e32 v35, v35, v36                                // 0000001BAE9C: 08464923
	v_cvt_i32_f32_e32 v36, v36                                 // 0000001BAEA0: 7E481124
	global_store_d16_hi_b16 v[23:24], v20, off offset:160      // 0000001BAEA4: DC9600A0 007C1417
	v_fmac_f32_e32 v19, v18, v19                               // 0000001BAEAC: 56262712
	v_div_scale_f32 v18, vcc_lo, v21, v26, v21                 // 0000001BAEB0: D6FC6A12 04563515
	v_fmac_f32_e32 v33, 0xb2a5705f, v29                        // 0000001BAEB8: 56423AFF B2A5705F
	v_fma_f32 v37, -v25, v34, 1.0                              // 0000001BAEC0: D6130025 23CA4519
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BAEC8: BF870193
	v_mul_f32_e32 v41, v18, v19                                // 0000001BAECC: 10522712
	v_add_f32_e32 v33, v35, v33                                // 0000001BAED0: 06424323
	v_mul_f32_e32 v35, 0xbfb8aa3b, v38                         // 0000001BAED4: 10464CFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BAEDC: BF870004
	v_fmac_f32_e32 v34, v37, v34                               // 0000001BAEE0: 56444525
	v_div_scale_f32 v37, s0, v22, v28, v22                     // 0000001BAEE4: D6FC0025 045A3916
	v_fma_f32 v30, -v27, v41, v18                              // 0000001BAEEC: D613001E 244A531B
	v_exp_f32_e32 v33, v33                                     // 0000001BAEF4: 7E424B21
	v_fma_f32 v43, 0xbfb8aa3b, v38, -v35                       // 0000001BAEF8: D613002B 848E4CFF BFB8AA3B
	v_rndne_f32_e32 v44, v35                                   // 0000001BAF04: 7E584723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BAF08: BF870193
	v_dual_mul_f32 v42, v37, v34 :: v_dual_fmac_f32 v41, v30, v19// 0000001BAF0C: C8C04525 2A28271E
	v_fmac_f32_e32 v43, 0xb2a5705f, v38                        // 0000001BAF14: 56564CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BAF1C: BF870193
	v_sub_f32_e32 v35, v35, v44                                // 0000001BAF20: 08465923
	v_fma_f32 v30, -v25, v42, v37                              // 0000001BAF24: D613001E 24965519
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001BAF2C: BF870294
	v_fma_f32 v17, -v27, v41, v18                              // 0000001BAF30: D6130011 244A531B
	.long 0xd71c0012                                           // 0000001BAF38: D71C0012
	v_cndmask_b32_e32 v1, v33, v36, vcc_lo                     // 0000001BAF3C: 02024921
	v_cvt_i32_f32_e32 v20, v44                                 // 0000001BAF40: 7E28112C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BAF44: BF870214
	v_dual_add_f32 v27, v35, v43 :: v_dual_fmac_f32 v42, v30, v34// 0000001BAF48: C9005723 1B2A451E
	v_div_fmas_f32 v17, v17, v19, v41                          // 0000001BAF50: D6370011 04A62711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001BAF58: 7C3C3AFF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BAF60: BF870213
	v_fma_f32 v19, -v25, v42, v37                              // 0000001BAF64: D6130013 24965519
	v_exp_f32_e32 v25, v27                                     // 0000001BAF6C: 7E324B1B
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001BAF70: 02242480
	s_mov_b32 vcc_lo, s0                                       // 0000001BAF74: BEEA0000
	v_div_fixup_f32 v17, v17, v26, v21                         // 0000001BAF78: D6270011 04563511
	v_div_fmas_f32 v19, v19, v34, v42                          // 0000001BAF80: D6370013 04AA4513
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001BAF88: 7C363AFF C2B17218
	.long 0x7f2a3980                                           // 0000001BAF90: 7F2A3980
	v_lshlrev_b32_e32 v34, 16, v70                             // 0000001BAF94: 30448C90
	.long 0x7e2a3991                                           // 0000001BAF98: 7E2A3991
	v_div_fixup_f32 v19, v19, v28, v22                         // 0000001BAF9C: D6270013 045A3913
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001BAFA4: 022424FF 7F800000
	.long 0xd71c0014                                           // 0000001BAFAC: D71C0014
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000001BAFB0: 02022919
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v38                  // 0000001BAFB4: 7C3C4CFF 42CE8ED0
	v_lshlrev_b32_e32 v25, 16, v104                            // 0000001BAFBC: 3032D090
	.long 0x7e003993                                           // 0000001BAFC0: 7E003993
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_and_b32 v21, 1, v21 // 0000001BAFC4: C92424F2 12142A81
	v_cndmask_b32_e32 v20, 0, v20, vcc_lo                      // 0000001BAFCC: 02282880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v38                  // 0000001BAFD0: 7C364CFF C2B17218
	v_mul_f32_e32 v27, 0xbfb8aa3b, v25                         // 0000001BAFD8: 103632FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001BAFE0: BF870234
	v_div_scale_f32 v22, null, v18, v18, v9                    // 0000001BAFE4: D6FC7C16 04262512
	v_dual_mul_f32 v37, 0xbfb8aa3b, v34 :: v_dual_and_b32 v28, 1, v0// 0000001BAFEC: C8E444FF 251C0081 BFB8AA3B
	v_cndmask_b32_e32 v20, 0x7f800000, v20, vcc_lo             // 0000001BAFF8: 022828FF 7F800000
	v_fma_f32 v29, 0xbfb8aa3b, v25, -v27                       // 0000001BB000: D613001D 846E32FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001BB00C: BF8701B4
	v_rcp_f32_e32 v26, v22                                     // 0000001BB010: 7E345516
	v_rndne_f32_e32 v30, v27                                   // 0000001BB014: 7E3C471B
	v_add3_u32 v17, v17, v21, 0x7fff                           // 0000001BB018: D6550011 03FE2B11 00007FFF
	v_dual_add_f32 v20, 1.0, v20 :: v_dual_fmac_f32 v29, 0xb2a5705f, v25// 0000001BB024: C90028F2 141C32FF B2A5705F
	v_add3_u32 v19, v19, v28, 0x7fff                           // 0000001BB030: D6550013 03FE3913 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BB03C: BF870224
	v_sub_f32_e32 v27, v27, v30                                // 0000001BB040: 08363D1B
	v_rndne_f32_e32 v28, v37                                   // 0000001BB044: 7E384725
	v_div_scale_f32 v33, null, v20, v20, v10                   // 0000001BB048: D6FC7C21 042A2914
	v_cvt_i32_f32_e32 v30, v30                                 // 0000001BB050: 7E3C111E
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001BB054: BF870005
	v_fma_f32 v35, -v22, v26, 1.0                              // 0000001BB058: D6130023 23CA3516
	v_add_f32_e32 v21, v27, v29                                // 0000001BB060: 062A3B1B
	v_fma_f32 v27, 0xbfb8aa3b, v34, -v37                       // 0000001BB064: D613001B 849644FF BFB8AA3B
	v_rcp_f32_e32 v36, v33                                     // 0000001BB070: 7E485521
	v_div_scale_f32 v29, vcc_lo, v9, v18, v9                   // 0000001BB074: D6FC6A1D 04262509
	v_fmac_f32_e32 v26, v35, v26                               // 0000001BB07C: 56343523
	v_exp_f32_e32 v21, v21                                     // 0000001BB080: 7E2A4B15
	v_fmac_f32_e32 v27, 0xb2a5705f, v34                        // 0000001BB084: 563644FF B2A5705F
	v_sub_f32_e32 v37, v37, v28                                // 0000001BB08C: 084A3925
	global_store_d16_hi_b16 v[31:32], v17, off offset:160      // 0000001BB090: DC9600A0 007C111F
	v_mul_f32_e32 v38, v29, v26                                // 0000001BB098: 104C351D
	.long 0xd41e0001                                           // 0000001BB09C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001BB0A0: 020232FF 42CE8ED0
	v_cvt_i32_f32_e32 v28, v28                                 // 0000001BB0A8: 7E38111C
	v_fma_f32 v35, -v33, v36, 1.0                              // 0000001BB0AC: D6130023 23CA4921
	v_add_f32_e32 v27, v37, v27                                // 0000001BB0B4: 06363725
	global_store_d16_hi_b16 v[39:40], v19, off offset:160      // 0000001BB0B8: DC9600A0 007C1327
	.long 0xd71c0011                                           // 0000001BB0C0: D71C0011
	v_cndmask_b32_e32 v1, v21, v30, vcc_lo                     // 0000001BB0C4: 02023D15
	v_fma_f32 v21, -v22, v38, v29                              // 0000001BB0C8: D6130015 24764D16
	v_fmac_f32_e32 v36, v35, v36                               // 0000001BB0D0: 56484923
	v_div_scale_f32 v35, s0, v10, v20, v10                     // 0000001BB0D4: D6FC0023 042A290A
	v_exp_f32_e32 v27, v27                                     // 0000001BB0DC: 7E364B1B
	v_cndmask_b32_e64 v17, 0, v17, s1                          // 0000001BB0E0: D5010011 00062280
	v_fmac_f32_e32 v38, v21, v26                               // 0000001BB0E8: 564C3515
	.long 0xd41b0001                                           // 0000001BB0EC: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v25, vcc_lo              // 0000001BB0F0: 020232FF C2B17218
	v_dual_mul_f32 v30, v35, v36 :: v_dual_lshlrev_b32 v19, 16, v106// 0000001BB0F8: C8E24923 1E12D490
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BB100: BF870193
	v_fma_f32 v22, -v22, v38, v29                              // 0000001BB104: D6130016 24764D16
	v_cndmask_b32_e64 v17, 0x7f800000, v17, s1                 // 0000001BB10C: D5010011 000622FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BB118: BF870213
	v_fma_f32 v21, -v33, v30, v35                              // 0000001BB11C: D6130015 248E3D21
	.long 0xd41e0001                                           // 0000001BB124: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v19, vcc_lo              // 0000001BB128: 020226FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BB130: BF870224
	v_div_fmas_f32 v22, v22, v26, v38                          // 0000001BB134: D6370016 049A3516
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 0000001BB13C: 7C3C44FF 42CE8ED0
	v_fmac_f32_e32 v30, v21, v36                               // 0000001BB144: 563C4915
	.long 0xd71c0015                                           // 0000001BB148: D71C0015
	v_cndmask_b32_e32 v1, v27, v28, vcc_lo                     // 0000001BB14C: 0202391B
	v_add_f32_e32 v17, 1.0, v17                                // 0000001BB150: 062222F2
	v_div_fixup_f32 v9, v22, v18, v9                           // 0000001BB154: D6270009 04262516
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BB15C: BF870214
	v_fma_f32 v25, -v33, v30, v35                              // 0000001BB160: D6130019 248E3D21
	v_cndmask_b32_e32 v21, 0, v21, vcc_lo                      // 0000001BB168: 022A2A80
	s_mov_b32 vcc_lo, s0                                       // 0000001BB16C: BEEA0000
	v_div_scale_f32 v26, null, v17, v17, v11                   // 0000001BB170: D6FC7C1A 042E2311
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001BB178: BF870233
	v_div_fmas_f32 v25, v25, v36, v30                          // 0000001BB17C: D6370019 047A4919
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 0000001BB184: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v34, 16, v105                            // 0000001BB18C: 3044D290
	v_rcp_f32_e32 v27, v26                                     // 0000001BB190: 7E36551A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BB194: BF870003
	v_div_fixup_f32 v10, v25, v20, v10                         // 0000001BB198: D627000A 042A2919
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001BB1A0: 022A2AFF 7F800000
	v_mul_f32_e32 v25, 0xbfb8aa3b, v19                         // 0000001BB1A8: 103226FF BFB8AA3B
	v_div_scale_f32 v33, vcc_lo, v11, v17, v11                 // 0000001BB1B0: D6FC6A21 042E230B
	v_mul_f32_e32 v36, 0xbfb8aa3b, v34                         // 0000001BB1B8: 104844FF BFB8AA3B
	.long 0x7e00398a                                           // 0000001BB1C0: 7E00398A
	v_add_f32_e32 v18, 1.0, v21                                // 0000001BB1C4: 06242AF2
	v_fma_f32 v29, 0xbfb8aa3b, v19, -v25                       // 0000001BB1C8: D613001D 846626FF BFB8AA3B
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001BB1D4: BF870005
	v_fma_f32 v21, -v26, v27, 1.0                              // 0000001BB1D8: D6130015 23CA371A
	v_rndne_f32_e32 v30, v25                                   // 0000001BB1E0: 7E3C4719
	v_and_b32_e32 v28, 1, v0                                   // 0000001BB1E4: 36380081
	v_div_scale_f32 v22, null, v18, v18, v12                   // 0000001BB1E8: D6FC7C16 04322512
	v_fmac_f32_e32 v29, 0xb2a5705f, v19                        // 0000001BB1F0: 563A26FF B2A5705F
	v_fmac_f32_e32 v27, v21, v27                               // 0000001BB1F8: 56363715
	v_sub_f32_e32 v25, v25, v30                                // 0000001BB1FC: 08323D19
	.long 0x7e283989                                           // 0000001BB200: 7E283989
	v_rcp_f32_e32 v21, v22                                     // 0000001BB204: 7E2A5516
	.long 0x7f283980                                           // 0000001BB208: 7F283980
	v_mul_f32_e32 v35, v33, v27                                // 0000001BB20C: 10463721
	v_add_f32_e32 v25, v25, v29                                // 0000001BB210: 06323B19
	v_fma_f32 v37, 0xbfb8aa3b, v34, -v36                       // 0000001BB214: D6130025 849244FF BFB8AA3B
	v_rndne_f32_e32 v38, v36                                   // 0000001BB220: 7E4C4724
	v_add3_u32 v10, v10, v28, 0x7fff                           // 0000001BB224: D655000A 03FE390A 00007FFF
	v_and_b32_e32 v20, 1, v20                                  // 0000001BB230: 36282881
	v_fma_f32 v29, -v26, v35, v33                              // 0000001BB234: D613001D 2486471A
	v_exp_f32_e32 v25, v25                                     // 0000001BB23C: 7E324B19
	v_fma_f32 v28, -v22, v21, 1.0                              // 0000001BB240: D613001C 23CA2B16
	v_fmac_f32_e32 v37, 0xb2a5705f, v34                        // 0000001BB248: 564A44FF B2A5705F
	v_sub_f32_e32 v36, v36, v38                                // 0000001BB250: 08484D24
	v_add3_u32 v9, v9, v20, 0x7fff                             // 0000001BB254: D6550009 03FE2909 00007FFF
	v_cvt_i32_f32_e32 v20, v30                                 // 0000001BB260: 7E28111E
	v_fmac_f32_e32 v21, v28, v21                               // 0000001BB264: 562A2B1C
	v_div_scale_f32 v28, s0, v12, v18, v12                     // 0000001BB268: D6FC001C 0432250C
	v_dual_fmac_f32 v35, v29, v27 :: v_dual_add_f32 v30, v36, v37// 0000001BB270: C808371D 231E4B24
	global_store_d16_hi_b16 v[7:8], v9, off offset:192         // 0000001BB278: DC9600C0 007C0907
	.long 0xd71c0009                                           // 0000001BB280: D71C0009
	v_cndmask_b32_e32 v1, v25, v20, vcc_lo                     // 0000001BB284: 02022919
	v_mul_f32_e32 v29, v28, v21                                // 0000001BB288: 103A2B1C
	v_fma_f32 v20, -v26, v35, v33                              // 0000001BB28C: D6130014 2486471A
	v_exp_f32_e32 v26, v30                                     // 0000001BB294: 7E344B1E
	global_store_d16_hi_b16 v[47:48], v10, off offset:192      // 0000001BB298: DC9600C0 007C0A2F
	v_cndmask_b32_e64 v9, 0, v9, s1                            // 0000001BB2A0: D5010009 00061280
	v_fma_f32 v25, -v22, v29, v28                              // 0000001BB2A8: D6130019 24723B16
	v_div_fmas_f32 v20, v20, v27, v35                          // 0000001BB2B0: D6370014 048E3714
	v_cvt_i32_f32_e32 v27, v38                                 // 0000001BB2B8: 7E361126
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v19                  // 0000001BB2BC: 7C3626FF C2B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BB2C4: BF870214
	v_fmac_f32_e32 v29, v25, v21                               // 0000001BB2C8: 563A2B19
	v_div_fixup_f32 v11, v20, v17, v11                         // 0000001BB2CC: D627000B 042E2314
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BB2D4: BF870004
	.long 0xd71c0011                                           // 0000001BB2D8: D71C0011
	v_cndmask_b32_e32 v1, v26, v27, vcc_lo                     // 0000001BB2DC: 0202371A
	v_cndmask_b32_e32 v9, 0x7f800000, v9, vcc_lo               // 0000001BB2E0: 021212FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v34                  // 0000001BB2E8: 7C3C44FF 42CE8ED0
	v_fma_f32 v19, -v22, v29, v28                              // 0000001BB2F0: D6130013 24723B16
	s_waitcnt vmcnt(1)                                         // 0000001BB2F8: BF8907F7
	v_lshlrev_b32_e32 v25, 16, v67                             // 0000001BB2FC: 30328690
	.long 0x7e2c398b                                           // 0000001BB300: 7E2C398B
	v_add_f32_e32 v9, 1.0, v9                                  // 0000001BB304: 061212F2
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 0000001BB308: 02222280
	s_mov_b32 vcc_lo, s0                                       // 0000001BB30C: BEEA0000
	v_mul_f32_e32 v30, 0xbfb8aa3b, v25                         // 0000001BB310: 103C32FF BFB8AA3B
	v_div_fmas_f32 v19, v19, v21, v29                          // 0000001BB318: D6370013 04762B13
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v34                  // 0000001BB320: 7C3644FF C2B17218
	v_lshlrev_b32_e32 v21, 16, v69                             // 0000001BB328: 302A8A90
	v_div_scale_f32 v20, null, v9, v9, v13                     // 0000001BB32C: D6FC7C14 04361309
	v_fma_f32 v34, 0xbfb8aa3b, v25, -v30                       // 0000001BB334: D6130022 847A32FF BFB8AA3B
	v_div_fixup_f32 v12, v19, v18, v12                         // 0000001BB340: D627000C 04322513
	v_cndmask_b32_e32 v17, 0x7f800000, v17, vcc_lo             // 0000001BB348: 022222FF 7F800000
	v_mul_f32_e32 v19, 0xbfb8aa3b, v21                         // 0000001BB350: 10262AFF BFB8AA3B
	v_rcp_f32_e32 v18, v20                                     // 0000001BB358: 7E245514
	v_rndne_f32_e32 v35, v30                                   // 0000001BB35C: 7E46471E
	v_fmac_f32_e32 v34, 0xb2a5705f, v25                        // 0000001BB360: 564432FF B2A5705F
	v_add_f32_e32 v17, 1.0, v17                                // 0000001BB368: 062222F2
	v_fma_f32 v27, 0xbfb8aa3b, v21, -v19                       // 0000001BB36C: D613001B 844E2AFF BFB8AA3B
	v_rndne_f32_e32 v28, v19                                   // 0000001BB378: 7E384713
	.long 0xd41e0001                                           // 0000001BB37C: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v21, vcc_lo              // 0000001BB380: 02022AFF 42CE8ED0
	.long 0x7e00398c                                           // 0000001BB388: 7E00398C
	v_div_scale_f32 v26, null, v17, v17, v14                   // 0000001BB38C: D6FC7C1A 043A2311
	v_fmac_f32_e32 v27, 0xb2a5705f, v21                        // 0000001BB394: 56362AFF B2A5705F
	v_sub_f32_e32 v19, v19, v28                                // 0000001BB39C: 08263913
	v_fma_f32 v29, -v20, v18, 1.0                              // 0000001BB3A0: D613001D 23CA2514
	v_cvt_i32_f32_e32 v28, v28                                 // 0000001BB3A8: 7E38111C
	v_rcp_f32_e32 v33, v26                                     // 0000001BB3AC: 7E42551A
	.long 0x7f2c3980                                           // 0000001BB3B0: 7F2C3980
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001BB3B4: BF8701B3
	v_dual_add_f32 v19, v19, v27 :: v_dual_fmac_f32 v18, v29, v18// 0000001BB3B8: C9003713 1312251D
	v_div_scale_f32 v27, vcc_lo, v13, v9, v13                  // 0000001BB3C0: D6FC6A1B 0436130D
	v_dual_sub_f32 v29, v30, v35 :: v_dual_and_b32 v36, 1, v0  // 0000001BB3C8: C964471E 1D240081
	v_exp_f32_e32 v19, v19                                     // 0000001BB3D0: 7E264B13
	v_and_b32_e32 v22, 1, v22                                  // 0000001BB3D4: 362C2C81
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000001BB3D8: BF870313
	v_mul_f32_e32 v37, v27, v18                                // 0000001BB3DC: 104A251B
	v_fma_f32 v30, -v26, v33, 1.0                              // 0000001BB3E0: D613001E 23CA431A
	v_add_f32_e32 v29, v29, v34                                // 0000001BB3E8: 063A451D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BB3EC: BF870214
	v_add3_u32 v10, v11, v22, 0x7fff                           // 0000001BB3F0: D655000A 03FE2D0B 00007FFF
	v_fma_f32 v34, -v20, v37, v27                              // 0000001BB3FC: D6130022 246E4B14
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BB404: BF870004
	v_fmac_f32_e32 v33, v30, v33                               // 0000001BB408: 5642431E
	v_div_scale_f32 v30, s0, v14, v17, v14                     // 0000001BB40C: D6FC001E 043A230E
	v_exp_f32_e32 v29, v29                                     // 0000001BB414: 7E3A4B1D
	.long 0xd71c0013                                           // 0000001BB418: D71C0013
	v_cndmask_b32_e32 v1, v19, v28, vcc_lo                     // 0000001BB41C: 02023913
	v_fmac_f32_e32 v37, v34, v18                               // 0000001BB420: 564A2522
	v_cvt_i32_f32_e32 v34, v35                                 // 0000001BB424: 7E441123
	v_mul_f32_e32 v28, v30, v33                                // 0000001BB428: 1038431E
	v_add3_u32 v11, v12, v36, 0x7fff                           // 0000001BB42C: D655000B 03FE490C 00007FFF
	v_cndmask_b32_e64 v19, 0, v19, s1                          // 0000001BB438: D5010013 00062680
	.long 0xd41b0001                                           // 0000001BB440: D41B0001
	v_cndmask_b32_e32 v1, 0xc2b17218, v21, vcc_lo              // 0000001BB444: 02022AFF C2B17218
	v_fma_f32 v20, -v20, v37, v27                              // 0000001BB44C: D6130014 246E4B14
	v_fma_f32 v35, -v26, v28, v30                              // 0000001BB454: D6130023 247A391A
	.long 0xd71c001b                                           // 0000001BB45C: D71C001B
	v_cndmask_b32_e32 v1, v29, v34, vcc_lo                     // 0000001BB460: 0202451D
	global_store_d16_hi_b16 v[15:16], v10, off offset:192      // 0000001BB464: DC9600C0 007C0A0F
	v_cndmask_b32_e64 v19, 0x7f800000, v19, s1                 // 0000001BB46C: D5010013 000626FF 7F800000
	.long 0xd41e0001                                           // 0000001BB478: D41E0001
	v_cndmask_b32_e32 v1, 0x42ce8ed0, v25, vcc_lo              // 0000001BB47C: 020232FF 42CE8ED0
	v_fmac_f32_e32 v28, v35, v33                               // 0000001BB484: 56384323
	v_div_fmas_f32 v18, v20, v18, v37                          // 0000001BB488: D6370012 04962514
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v25                  // 0000001BB490: 7C3632FF C2B17218
	v_add_f32_e32 v19, 1.0, v19                                // 0000001BB498: 062626F2
	v_cndmask_b32_e64 v21, 0, v27, s1                          // 0000001BB49C: D5010015 00063680
	v_fma_f32 v20, -v26, v28, v30                              // 0000001BB4A4: D6130014 247A391A
	v_div_fixup_f32 v9, v18, v9, v13                           // 0000001BB4AC: D6270009 04361312
	global_store_d16_hi_b16 v[23:24], v11, off offset:192      // 0000001BB4B4: DC9600C0 007C0B17
	v_div_scale_f32 v26, null, v19, v19, v1                    // 0000001BB4BC: D6FC7C1A 04062713
	v_cndmask_b32_e32 v21, 0x7f800000, v21, vcc_lo             // 0000001BB4C4: 022A2AFF 7F800000
	s_mov_b32 vcc_lo, s0                                       // 0000001BB4CC: BEEA0000
	v_lshlrev_b32_e32 v18, 16, v56                             // 0000001BB4D0: 30247090
	v_div_fmas_f32 v20, v20, v33, v28                          // 0000001BB4D4: D6370014 04724314
	v_rcp_f32_e32 v25, v26                                     // 0000001BB4DC: 7E32551A
	v_add_f32_e32 v21, 1.0, v21                                // 0000001BB4E0: 062A2AF2
	v_lshlrev_b32_e32 v29, 16, v55                             // 0000001BB4E4: 303A6E90
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BB4E8: BF870223
	v_div_fixup_f32 v12, v20, v17, v14                         // 0000001BB4EC: D627000C 043A2314
	.long 0x7e223989                                           // 0000001BB4F4: 7E223989
	v_div_scale_f32 v14, null, v21, v21, v2                    // 0000001BB4F8: D6FC7C0E 040A2B15
	.long 0x7f223980                                           // 0000001BB500: 7F223980
	v_mul_f32_e32 v30, 0xbfb8aa3b, v29                         // 0000001BB504: 103C3AFF BFB8AA3B
	.long 0x7e00398c                                           // 0000001BB50C: 7E00398C
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001BB510: BF8701B5
	v_fma_f32 v10, -v26, v25, 1.0                              // 0000001BB514: D613000A 23CA331A
	v_rcp_f32_e32 v13, v14                                     // 0000001BB51C: 7E1A550E
	v_and_b32_e32 v17, 1, v17                                  // 0000001BB520: 36222281
	v_and_b32_e32 v11, 1, v0                                   // 0000001BB524: 36160081
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BB528: BF870223
	v_fmac_f32_e32 v25, v10, v25                               // 0000001BB52C: 5632330A
	v_div_scale_f32 v10, vcc_lo, v1, v19, v1                   // 0000001BB530: D6FC6A0A 04062701
	v_add3_u32 v9, v9, v17, 0x7fff                             // 0000001BB538: D6550009 03FE2309 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BB544: BF870224
	v_add3_u32 v11, v12, v11, 0x7fff                           // 0000001BB548: D655000B 03FE170C 00007FFF
	v_mul_f32_e32 v12, 0xbfb8aa3b, v18                         // 0000001BB554: 101824FF BFB8AA3B
	v_mul_f32_e32 v20, v10, v25                                // 0000001BB55C: 1028330A
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001BB560: BF870005
	v_fma_f32 v22, -v14, v13, 1.0                              // 0000001BB564: D6130016 23CA1B0E
	s_clause 0x1                                               // 0000001BB56C: BF850001
	global_store_d16_hi_b16 v[31:32], v9, off offset:192       // 0000001BB570: DC9600C0 007C091F
	global_store_d16_hi_b16 v[39:40], v11, off offset:192      // 0000001BB578: DC9600C0 007C0B27
	v_fma_f32 v27, 0xbfb8aa3b, v18, -v12                       // 0000001BB580: D613001B 843224FF BFB8AA3B
	v_fma_f32 v17, -v26, v20, v10                              // 0000001BB58C: D6130011 242A291A
	v_fmac_f32_e32 v13, v22, v13                               // 0000001BB594: 561A1B16
	v_div_scale_f32 v22, s0, v2, v21, v2                       // 0000001BB598: D6FC0016 040A2B02
	v_rndne_f32_e32 v28, v12                                   // 0000001BB5A0: 7E38470C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BB5A4: BF870114
	v_dual_fmac_f32 v27, 0xb2a5705f, v18 :: v_dual_fmac_f32 v20, v17, v25// 0000001BB5A8: C80024FF 1B143311 B2A5705F
	v_dual_mul_f32 v17, v22, v13 :: v_dual_sub_f32 v12, v12, v28// 0000001BB5B4: C8CA1B16 110C390C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001BB5BC: BF8701A2
	v_fma_f32 v9, -v26, v20, v10                               // 0000001BB5C0: D6130009 242A291A
	v_fma_f32 v26, 0xbfb8aa3b, v29, -v30                       // 0000001BB5C8: D613001A 847A3AFF BFB8AA3B
	v_fma_f32 v10, -v14, v17, v22                              // 0000001BB5D4: D613000A 245A230E
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001BB5DC: BF870004
	v_add_f32_e32 v12, v12, v27                                // 0000001BB5E0: 0618370C
	v_rndne_f32_e32 v27, v30                                   // 0000001BB5E4: 7E36471E
	v_div_fmas_f32 v9, v9, v25, v20                            // 0000001BB5E8: D6370009 04523309
	v_fmac_f32_e32 v26, 0xb2a5705f, v29                        // 0000001BB5F0: 56343AFF B2A5705F
	v_fmac_f32_e32 v17, v10, v13                               // 0000001BB5F8: 56221B0A
	v_exp_f32_e32 v10, v12                                     // 0000001BB5FC: 7E144B0C
	v_sub_f32_e32 v12, v30, v27                                // 0000001BB600: 0818371E
	v_lshlrev_b32_e32 v20, 16, v63                             // 0000001BB604: 30287E90
	v_cvt_i32_f32_e32 v25, v28                                 // 0000001BB608: 7E32111C
	v_fma_f32 v14, -v14, v17, v22                              // 0000001BB60C: D613000E 245A230E
	s_waitcnt vmcnt(0)                                         // 0000001BB614: BF8903F7
	v_lshlrev_b32_e32 v22, 16, v64                             // 0000001BB618: 302C8090
	v_add_f32_e32 v12, v12, v26                                // 0000001BB61C: 0618350C
	v_mul_f32_e32 v26, 0xbfb8aa3b, v20                         // 0000001BB620: 103428FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v18                  // 0000001BB628: 7C3C24FF 42CE8ED0
	v_cvt_i32_f32_e32 v27, v27                                 // 0000001BB630: 7E36111B
	v_mul_f32_e32 v28, 0xbfb8aa3b, v22                         // 0000001BB634: 10382CFF BFB8AA3B
	.long 0xd71c000a                                           // 0000001BB63C: D71C000A
	v_cndmask_b32_e32 v1, v10, v25, vcc_lo                     // 0000001BB640: 0202330A
	v_fma_f32 v25, 0xbfb8aa3b, v20, -v26                       // 0000001BB644: D6130019 846A28FF BFB8AA3B
	v_rndne_f32_e32 v30, v26                                   // 0000001BB650: 7E3C471A
	v_exp_f32_e32 v12, v12                                     // 0000001BB654: 7E184B0C
	v_fma_f32 v33, 0xbfb8aa3b, v22, -v28                       // 0000001BB658: D6130021 84722CFF BFB8AA3B
	v_rndne_f32_e32 v34, v28                                   // 0000001BB664: 7E44471C
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BB668: BF870223
	v_dual_fmac_f32 v25, 0xb2a5705f, v20 :: v_dual_sub_f32 v26, v26, v30// 0000001BB66C: C80A28FF 191A3D1A B2A5705F
	v_cndmask_b32_e32 v10, 0, v10, vcc_lo                      // 0000001BB678: 02141480
	v_fmac_f32_e32 v33, 0xb2a5705f, v22                        // 0000001BB67C: 56422CFF B2A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(TRANS32_DEP_1)// 0000001BB684: BF8702B4
	v_sub_f32_e32 v28, v28, v34                                // 0000001BB688: 0838451C
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v18                  // 0000001BB68C: 7C3624FF C2B17218
	v_add_f32_e32 v25, v26, v25                                // 0000001BB694: 0632331A
	.long 0xd71c000c                                           // 0000001BB698: D71C000C
	v_cndmask_b32_e32 v1, v12, v27, vcc_lo                     // 0000001BB69C: 0202370C
	v_cvt_i32_f32_e32 v27, v34                                 // 0000001BB6A0: 7E361122
	v_add_f32_e32 v26, v28, v33                                // 0000001BB6A4: 0634431C
	v_cndmask_b32_e32 v10, 0x7f800000, v10, vcc_lo             // 0000001BB6A8: 021414FF 7F800000
	v_exp_f32_e32 v18, v25                                     // 0000001BB6B0: 7E244B19
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v29                  // 0000001BB6B4: 7C3C3AFF 42CE8ED0
	v_div_fixup_f32 v1, v9, v19, v1                            // 0000001BB6BC: D6270001 04062709
	v_exp_f32_e32 v25, v26                                     // 0000001BB6C4: 7E324B1A
	v_cvt_i32_f32_e32 v26, v30                                 // 0000001BB6C8: 7E34111E
	v_add_f32_e32 v10, 1.0, v10                                // 0000001BB6CC: 061414F2
	v_cndmask_b32_e32 v12, 0, v12, vcc_lo                      // 0000001BB6D0: 02181880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v29                  // 0000001BB6D4: 7C363AFF C2B17218
	.long 0x7e443981                                           // 0000001BB6DC: 7E443981
	.long 0x7f443980                                           // 0000001BB6E0: 7F443980
	.long 0xd71c0012                                           // 0000001BB6E4: D71C0012
	v_cndmask_b32_e32 v1, v18, v26, vcc_lo                     // 0000001BB6E8: 02023512
	v_div_scale_f32 v26, null, v10, v10, v3                    // 0000001BB6EC: D6FC7C1A 040E150A
	v_cndmask_b32_e32 v12, 0x7f800000, v12, vcc_lo             // 0000001BB6F4: 021818FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v20                  // 0000001BB6FC: 7C3C28FF 42CE8ED0
	.long 0xd71c0019                                           // 0000001BB704: D71C0019
	v_cndmask_b32_e32 v1, v25, v27, vcc_lo                     // 0000001BB708: 02023719
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BB70C: BF870194
	v_rcp_f32_e32 v27, v26                                     // 0000001BB710: 7E36551A
	v_add_f32_e32 v12, 1.0, v12                                // 0000001BB714: 061818F2
	v_cndmask_b32_e32 v18, 0, v18, vcc_lo                      // 0000001BB718: 02242480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v22                  // 0000001BB71C: 7C3C2CFF 42CE8ED0
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 0000001BB724: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v20                  // 0000001BB728: 7C3628FF C2B17218
	v_div_scale_f32 v20, null, v12, v12, v4                    // 0000001BB730: D6FC7C14 0412190C
	v_cndmask_b32_e32 v18, 0x7f800000, v18, vcc_lo             // 0000001BB738: 022424FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v22                  // 0000001BB740: 7C362CFF C2B17218
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BB748: BF870113
	v_rcp_f32_e32 v28, v20                                     // 0000001BB74C: 7E385514
	v_add_f32_e32 v18, 1.0, v18                                // 0000001BB750: 062424F2
	v_cndmask_b32_e32 v22, 0x7f800000, v25, vcc_lo             // 0000001BB754: 022C32FF 7F800000
	v_fma_f32 v25, -v26, v27, 1.0                              // 0000001BB75C: D6130019 23CA371A
	s_mov_b32 vcc_lo, s0                                       // 0000001BB764: BEEA0000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BB768: BF870193
	v_div_scale_f32 v29, null, v18, v18, v5                    // 0000001BB76C: D6FC7C1D 04162512
	v_add_f32_e32 v22, 1.0, v22                                // 0000001BB774: 062C2CF2
	v_div_fmas_f32 v13, v14, v13, v17                          // 0000001BB778: D637000D 04461B0E
	v_fmac_f32_e32 v27, v25, v27                               // 0000001BB780: 56363719
	v_div_scale_f32 v17, vcc_lo, v3, v10, v3                   // 0000001BB784: D6FC6A11 040E1503
	v_rcp_f32_e32 v14, v29                                     // 0000001BB78C: 7E1C551D
	v_div_scale_f32 v25, null, v22, v22, v6                    // 0000001BB790: D6FC7C19 041A2D16
	v_fma_f32 v30, -v20, v28, 1.0                              // 0000001BB798: D613001E 23CA3914
	v_div_fixup_f32 v2, v13, v21, v2                           // 0000001BB7A0: D6270002 040A2B0D
	v_mul_f32_e32 v11, v17, v27                                // 0000001BB7A8: 10163711
	v_div_scale_f32 v21, s0, v4, v12, v4                       // 0000001BB7AC: D6FC0015 04121904
	v_rcp_f32_e32 v13, v25                                     // 0000001BB7B4: 7E1A5519
	v_fmac_f32_e32 v28, v30, v28                               // 0000001BB7B8: 5638391E
	.long 0x7e003982                                           // 0000001BB7BC: 7E003982
	v_fma_f32 v9, -v26, v11, v17                               // 0000001BB7C0: D6130009 2446171A
	v_fma_f32 v30, -v29, v14, 1.0                              // 0000001BB7C8: D613001E 23CA1D1D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BB7D0: BF870114
	v_mul_f32_e32 v19, v21, v28                                // 0000001BB7D4: 10263915
	v_dual_fmac_f32 v11, v9, v27 :: v_dual_fmac_f32 v14, v30, v14// 0000001BB7D8: C8003709 0B0E1D1E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BB7E0: BF870225
	v_fma_f32 v33, -v25, v13, 1.0                              // 0000001BB7E4: D6130021 23CA1B19
	v_div_scale_f32 v30, s1, v5, v18, v5                       // 0000001BB7EC: D6FC011E 04162505
	v_fma_f32 v9, -v20, v19, v21                               // 0000001BB7F4: D6130009 24562714
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BB7FC: BF870214
	v_fma_f32 v17, -v26, v11, v17                              // 0000001BB800: D6130011 2446171A
	v_fmac_f32_e32 v13, v33, v13                               // 0000001BB808: 561A1B21
	v_div_scale_f32 v33, s2, v6, v22, v6                       // 0000001BB80C: D6FC0221 041A2D06
	v_mul_f32_e32 v35, v30, v14                                // 0000001BB814: 10461D1E
	v_fmac_f32_e32 v19, v9, v28                                // 0000001BB818: 56263909
	v_div_fmas_f32 v11, v17, v27, v11                          // 0000001BB81C: D637000B 042E3711
	s_mov_b32 vcc_lo, s0                                       // 0000001BB824: BEEA0000
	v_mul_f32_e32 v26, v33, v13                                // 0000001BB828: 10341B21
	v_fma_f32 v9, -v29, v35, v30                               // 0000001BB82C: D6130009 247A471D
	v_fma_f32 v17, -v20, v19, v21                              // 0000001BB834: D6130011 24562714
	v_div_fixup_f32 v3, v11, v10, v3                           // 0000001BB83C: D6270003 040E150B
	v_and_b32_e32 v11, 1, v34                                  // 0000001BB844: 36164481
	v_fma_f32 v20, -v25, v26, v33                              // 0000001BB848: D6130014 24863519
	v_fmac_f32_e32 v35, v9, v14                                // 0000001BB850: 56461D09
	v_div_fmas_f32 v9, v17, v28, v19                           // 0000001BB854: D6370009 044E3911
	s_mov_b32 vcc_lo, s1                                       // 0000001BB85C: BEEA0001
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001BB860: BF870193
	v_dual_fmac_f32 v26, v20, v13 :: v_dual_and_b32 v17, 1, v0 // 0000001BB864: C8241B14 1A100081
	v_fma_f32 v10, -v29, v35, v30                              // 0000001BB86C: D613000A 247A471D
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001BB874: BF870003
	v_div_fixup_f32 v4, v9, v12, v4                            // 0000001BB878: D6270004 04121909
	.long 0x7f183980                                           // 0000001BB880: 7F183980
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001BB884: D6550001 03FE1701 00007FFF
	v_fma_f32 v9, -v25, v26, v33                               // 0000001BB890: D6130009 24863519
	v_div_fmas_f32 v10, v10, v14, v35                          // 0000001BB898: D637000A 048E1D0A
	s_mov_b32 vcc_lo, s2                                       // 0000001BB8A0: BEEA0002
	.long 0x7e003984                                           // 0000001BB8A4: 7E003984
	v_add3_u32 v2, v2, v17, 0x7fff                             // 0000001BB8A8: D6550002 03FE2302 00007FFF
	v_div_fmas_f32 v9, v9, v13, v26                            // 0000001BB8B4: D6370009 046A1B09
	v_div_fixup_f32 v5, v10, v18, v5                           // 0000001BB8BC: D6270005 0416250A
	.long 0x7e143983                                           // 0000001BB8C4: 7E143983
	.long 0x7f143980                                           // 0000001BB8C8: 7F143980
	global_store_d16_hi_b16 v[7:8], v1, off offset:224         // 0000001BB8CC: DC9600E0 007C0107
	v_div_fixup_f32 v6, v9, v22, v6                            // 0000001BB8D4: D6270006 041A2D09
	.long 0x7e183985                                           // 0000001BB8DC: 7E183985
	v_and_b32_e32 v9, 1, v0                                    // 0000001BB8E0: 36120081
	v_and_b32_e32 v10, 1, v10                                  // 0000001BB8E4: 36141481
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001BB8E8: BF870214
	.long 0x7e003986                                           // 0000001BB8EC: 7E003986
	v_and_b32_e32 v11, 1, v12                                  // 0000001BB8F0: 36161881
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001BB8F4: BF870223
	v_add3_u32 v1, v3, v10, 0x7fff                             // 0000001BB8F8: D6550001 03FE1503 00007FFF
	v_add3_u32 v3, v4, v9, 0x7fff                              // 0000001BB904: D6550003 03FE1304 00007FFF
	v_and_b32_e32 v0, 1, v0                                    // 0000001BB910: 36000081
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001BB914: BF870114
	v_add3_u32 v4, v5, v11, 0x7fff                             // 0000001BB918: D6550004 03FE1705 00007FFF
	v_add3_u32 v0, v6, v0, 0x7fff                              // 0000001BB924: D6550000 03FE0106 00007FFF
	s_clause 0x4                                               // 0000001BB930: BF850004
	global_store_d16_hi_b16 v[47:48], v2, off offset:224       // 0000001BB934: DC9600E0 007C022F
	global_store_d16_hi_b16 v[15:16], v1, off offset:224       // 0000001BB93C: DC9600E0 007C010F
	global_store_d16_hi_b16 v[23:24], v3, off offset:224       // 0000001BB944: DC9600E0 007C0317
	global_store_d16_hi_b16 v[31:32], v4, off offset:224       // 0000001BB94C: DC9600E0 007C041F
	global_store_d16_hi_b16 v[39:40], v0, off offset:224       // 0000001BB954: DC9600E0 007C0027
	s_nop 0                                                    // 0000001BB95C: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001BB960: BFB60003
	s_endpgm                                                   // 0000001BB964: BFB00000
		...

