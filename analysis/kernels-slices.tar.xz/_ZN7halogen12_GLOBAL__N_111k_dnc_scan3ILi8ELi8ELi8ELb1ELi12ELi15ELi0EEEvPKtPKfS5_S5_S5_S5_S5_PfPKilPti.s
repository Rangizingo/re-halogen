00000000000b6e00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 0000000B6E00: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 0000000B6E04: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 0000000B6E0C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 0000000B6E14: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 0000000B6E18: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 0000000B6E1C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 0000000B6E20: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000B6E28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 0000000B6E2C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 0000000B6E30: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 0000000B6E34: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 0000000B6E3C: 84928214
	s_add_u32 s25, s16, s18                                    // 0000000B6E40: 80191210
	s_addc_u32 s28, s17, s19                                   // 0000000B6E44: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 0000000B6E48: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B6E4C: BF870009
	s_add_u32 s25, s25, s20                                    // 0000000B6E50: 80191419
	s_addc_u32 s30, s28, s21                                   // 0000000B6E54: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 0000000B6E58: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 0000000B6E5C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 0000000B6E64: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 0000000B6E6C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 0000000B6E70: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 0000000B6E74: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000B6E78: BF8700B9
	s_add_u32 s31, s31, s24                                    // 0000000B6E7C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 0000000B6E80: 821E191E
	.long 0xd7001f02                                           // 0000000B6E84: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 0000000B6E88: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 0000000B6E8C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 0000000B6E94: BE9E0080
	s_nop 0                                                    // 0000000B6E98: BF800000
	s_nop 0                                                    // 0000000B6E9C: BF800000
	s_nop 0                                                    // 0000000B6EA0: BF800000
	s_nop 0                                                    // 0000000B6EA4: BF800000
	s_nop 0                                                    // 0000000B6EA8: BF800000
	s_nop 0                                                    // 0000000B6EAC: BF800000
	s_nop 0                                                    // 0000000B6EB0: BF800000
	s_nop 0                                                    // 0000000B6EB4: BF800000
	s_nop 0                                                    // 0000000B6EB8: BF800000
	s_nop 0                                                    // 0000000B6EBC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 0000000B6EC0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 0000000B6EC4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B6ECC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000B6ED0: 300C1089
	.long 0xd7006a06                                           // 0000000B6ED4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000B6ED8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B6EDC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000B6EE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000B6EE8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 0000000B6EF0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 0000000B6EF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000B6EFC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 0000000B6F08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 0000000B6F0C: BF8903F7
	ds_store_b32 v6, v9                                        // 0000000B6F10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 0000000B6F18: 917E1E7E
	s_cbranch_execnz 65512                                     // 0000000B6F1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 0000000B6F20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 0000000B6F24: F4000780 F8000058
	v_or_b32_e32 v36, 0xffffff80, v0                           // 0000000B6F2C: 384800FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 0000000B6F34: 32040084
	s_mov_b32 s0, 0                                            // 0000000B6F38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 0000000B6F3C: BF89FC07
	s_barrier                                                  // 0000000B6F40: BFBD0000
	buffer_gl0_inv                                             // 0000000B6F44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 0000000B6F4C: BF02801E
	s_cbranch_scc1 12                                          // 0000000B6F50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 0000000B6F54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 0000000B6F5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B6F64: BF870002
	v_lshl_add_u32 v35, v5, 2, v3                              // 0000000B6F68: D6460023 040D0505
	v_mov_b32_e32 v3, 0                                        // 0000000B6F70: 7E060280
	v_lshlrev_b32_e32 v37, 2, v5                               // 0000000B6F74: 304A0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 0000000B6F78: 916A007E
	s_cbranch_vccz 2                                           // 0000000B6F7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2201                                              // 0000000B6F80: BFA00899 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23e8>
	v_lshlrev_b32_e32 v37, 2, v5                               // 0000000B6F84: 304A0A82
	s_add_i32 s0, s30, 63                                      // 0000000B6F88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 0000000B6F8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 0000000B6F94: 85218600
	s_add_u32 s34, s10, s24                                    // 0000000B6F98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 0000000B6F9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000B6FA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v38, 2, v0      // 0000000B6FA4: CA220080 03260082
	s_ashr_i32 s1, s0, 31                                      // 0000000B6FAC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 0000000B6FB0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000B6FB4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 0000000B6FB8: 301A0488
	s_add_u32 s22, s22, s0                                     // 0000000B6FBC: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000B6FC0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000B6FC4: 848A811A
	v_mad_u32_u24 v35, 0x44, v2, v37                           // 0000000B6FC8: D60B0023 049604FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000B6FD4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000B6FD8: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000B6FDC: B00A0204
	.long 0xd7000b2a                                           // 0000000B6FE0: D7000B2A
	v_cndmask_b32_e32 v1, s34, v37, vcc_lo                     // 0000000B6FE4: 02024A22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000B6FE8: BF8704B1
	v_add_co_ci_u32_e64 v43, null, s35, 0, s11                 // 0000000B6FEC: D5207C2B 002D0023
	v_mad_u32_u24 v44, v2, s10, 0x3300                         // 0000000B6FF4: D60B002C 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000B7000: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v39, 0x4320, v38// 0000000B7004: CA20000B 0C264CFF 00004320
	v_or_b32_e32 v11, s10, v38                                 // 0000000B7010: 38164C0A
	.long 0xd7000a05                                           // 0000000B7014: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 0000000B7018: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B701C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 0000000B7020: D5207C06 00290001
	.long 0xd7000107                                           // 0000000B7028: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 0000000B702C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B7030: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 0000000B7034: D5207C08 0006180D
	.long 0xd7000109                                           // 0000000B703C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 0000000B7040: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 0000000B7044: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 0000000B704C: 84848E02
	.long 0xd700010b                                           // 0000000B7050: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 0000000B7054: 02021606
	s_add_u32 s4, s14, s4                                      // 0000000B7058: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 0000000B705C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 0000000B7064: 8205050F
	.long 0xd700010d                                           // 0000000B7068: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 0000000B706C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B7070: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 0000000B7074: D5207C0E 00050005
	.long 0xd700010f                                           // 0000000B707C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 0000000B7080: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 0000000B7088: D5207C10 00061880
	.long 0xd7000111                                           // 0000000B7090: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 0000000B7094: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B709C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 0000000B70A0: D5207C12 00061880
	.long 0xd7000113                                           // 0000000B70A8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 0000000B70AC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 0000000B70B4: D5207C14 00061880
	.long 0xd7000115                                           // 0000000B70BC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 0000000B70C0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000B70C8: BF8700D1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 0000000B70CC: D5207C16 00061880
	.long 0xd7000117                                           // 0000000B70D4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 0000000B70D8: 020216FF 000F0000
	v_or_b32_e32 v45, 0x2200, v1                               // 0000000B70E0: 385A02FF 00002200
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 0000000B70E8: D5207C18 00061880
	.long 0xd7000119                                           // 0000000B70F0: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 0000000B70F4: 020216FF 00120000
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 0000000B70FC: D5207C1A 00061880
	.long 0xd700011b                                           // 0000000B7104: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 0000000B7108: 020216FF 00150000
	v_add_nc_u32_e32 v40, 0x4420, v38                          // 0000000B7110: 4A504CFF 00004420
	.long 0xd44c0000                                           // 0000000B7118: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 0000000B711C: 020200FF 00000080
	v_add_nc_u32_e32 v41, 1, v2                                // 0000000B7124: 4A520481
	v_add_nc_u32_e32 v4, 0x2200, v35                           // 0000000B7128: 4A0846FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 0000000B7130: D5207C1C 00061880
	v_add_nc_u32_e32 v46, 0x400, v45                           // 0000000B7138: 4A5C5AFF 00000400
	v_add_nc_u32_e32 v47, 0x600, v45                           // 0000000B7140: 4A5E5AFF 00000600
	v_add_nc_u32_e32 v48, 0x800, v45                           // 0000000B7148: 4A605AFF 00000800
	s_mov_b32 s5, 0                                            // 0000000B7150: BE850080
	s_mov_b32 s6, 0x41800000                                   // 0000000B7154: BE8600FF 41800000
	s_mov_b32 s7, 0x3d800000                                   // 0000000B715C: BE8700FF 3D800000
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000B7164: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 0000000B7168: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000B7170: BF870499
	s_add_i32 s10, s31, s1                                     // 0000000B7174: 810A011F
	s_ashr_i32 s11, s10, 31                                    // 0000000B7178: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B717C: BF870009
	s_lshl_b64 s[12:13], s[10:11], 2                           // 0000000B7180: 848C820A
	s_lshl_b32 s11, s5, 6                                      // 0000000B7184: 840B8605
	s_add_u32 s12, s8, s12                                     // 0000000B7188: 800C0C08
	s_addc_u32 s13, s9, s13                                    // 0000000B718C: 820D0D09
	s_load_b32 s10, s[12:13], null                             // 0000000B7190: F4000286 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000B7198: BE84206A
	s_cbranch_execz 77                                         // 0000000B719C: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4d4>
	v_or_b32_e32 v29, s11, v0                                  // 0000000B71A0: 383A000B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B71A4: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000B71A8: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000B71B0: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B71B4: BF870091
	.long 0xd73c001d                                           // 0000000B71B8: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000B71BC: 02023A82
	.long 0xd700011d                                           // 0000000B71C0: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 0000000B71C4: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000B71C8: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 0000000B71CC: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 0000000B71D4: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B71DC: BF890007
	v_sub_f32_e32 v30, s10, v29                                // 0000000B71E0: 083C3A0A
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 0000000B71E4: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000000B71F0: BF8701A1
	v_fma_f32 v49, 0x3fb8aa3b, v29, -v32                       // 0000000B71F4: D6130031 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v50, v32                                   // 0000000B7200: 7E644720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 0000000B7204: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 0000000B7210: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000000B7214: BF870113
	v_dual_fmac_f32 v49, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v50// 0000000B7218: C80A3AFF 31206520 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 0000000B7224: 083E451F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B7228: BF870122
	v_dual_fmac_f32 v33, 0x32a5705f, v30 :: v_dual_add_f32 v32, v32, v49// 0000000B722C: C8083CFF 21206320 32A5705F
	.long 0xd41b0001                                           // 0000000B7238: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 0000000B723C: 02023CFF C2CE8ED0
	v_add_f32_e32 v31, v31, v33                                // 0000000B7244: 063E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 0000000B7248: 7E421122
	v_cvt_i32_f32_e32 v34, v50                                 // 0000000B724C: 7E441132
	v_exp_f32_e32 v32, v32                                     // 0000000B7250: 7E404B20
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_2)// 0000000B7254: BF870313
	v_exp_f32_e32 v31, v31                                     // 0000000B7258: 7E3E4B1F
	.long 0xd71c0020                                           // 0000000B725C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000B7260: 02024520
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7264: BF870095
	.long 0xd71c001f                                           // 0000000B7268: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000B726C: 0202431F
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000B7270: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000B7278: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000B727C: 02023AFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B7284: BF8700A1
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000B7288: D5010020 00064080
	.long 0xd41e0001                                           // 0000000B7290: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000B7294: 02023CFF 42B17218
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000B729C: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000B72A8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000B72AC: 02023AFF 42B17218
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B72B4: BF870001
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000B72B8: D501001D 000640FF 7F800000
	ds_store_b32 v39, v30                                      // 0000000B72C4: D8340000 00001E27
	ds_store_b32 v40, v29                                      // 0000000B72CC: D8340000 00001D28
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B72D4: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 0000000B72D8: CA100108 1E1C0107
	s_mov_b32 s12, 0                                           // 0000000B72E0: BE8C0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B72E4: BF89FC07
	s_barrier                                                  // 0000000B72E8: BFBD0000
	buffer_gl0_inv                                             // 0000000B72EC: E0AC0000 00000000
	s_branch 15                                                // 0000000B72F4: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B72F8: 8C7E047E
	.long 0xd700011d                                           // 0000000B72FC: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 0000000B7300: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B7308: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B730C: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000B7314: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000B7318: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000B731C: BE8C0001
	s_waitcnt lgkmcnt(0)                                       // 0000000B7320: BF89FC07
	s_barrier                                                  // 0000000B7324: BFBD0000
	buffer_gl0_inv                                             // 0000000B7328: E0AC0000 00000000
	s_cbranch_scc1 185                                         // 0000000B7330: BFA200B9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x818>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 0000000B7334: CA10011E 201E011D
	v_dual_mov_b32 v33, v38 :: v_dual_mov_b32 v34, v36         // 0000000B733C: CA100126 21220124
	s_mov_b32 s13, 0                                           // 0000000B7344: BE8D0080
	s_nop 0                                                    // 0000000B7348: BF800000
	s_nop 0                                                    // 0000000B734C: BF800000
	s_nop 0                                                    // 0000000B7350: BF800000
	s_nop 0                                                    // 0000000B7354: BF800000
	s_nop 0                                                    // 0000000B7358: BF800000
	s_nop 0                                                    // 0000000B735C: BF800000
	s_nop 0                                                    // 0000000B7360: BF800000
	s_nop 0                                                    // 0000000B7364: BF800000
	s_nop 0                                                    // 0000000B7368: BF800000
	s_nop 0                                                    // 0000000B736C: BF800000
	s_nop 0                                                    // 0000000B7370: BF800000
	s_nop 0                                                    // 0000000B7374: BF800000
	s_nop 0                                                    // 0000000B7378: BF800000
	s_nop 0                                                    // 0000000B737C: BF800000
	global_load_b32 v49, v[31:32], off                         // 0000000B7380: DC520000 317C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000B7388: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000B7390: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000B7394: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B739C: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000B73A0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000B73A8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000B73AC: 020244FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000B73B4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000B73B8: BF8903F7
	ds_store_b32 v33, v49 offset:13056                         // 0000000B73BC: D8343300 00003121
	v_add_nc_u32_e32 v33, 0x204, v33                           // 0000000B73C4: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000B73CC: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000B73D0: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x580>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000B73D4: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B73D8: BF89FC07
	s_barrier                                                  // 0000000B73DC: BFBD0000
	buffer_gl0_inv                                             // 0000000B73E0: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 0000000B73E8: BE842000
	s_cbranch_execz 65474                                      // 0000000B73EC: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f8>
	v_or3_b32 v31, s12, s11, v2                                // 0000000B73F0: D658001F 0408160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B73F8: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 0000000B73FC: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 0000000B7404: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 0000000B7408: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B740C: BF870091
	.long 0xd700011f                                           // 0000000B7410: D700011F
	v_cndmask_b32_e32 v1, v42, v31, vcc_lo                     // 0000000B7414: 02023F2A
	v_add_co_ci_u32_e64 v32, null, v43, v32, s1                // 0000000B7418: D5207C20 0006412B
	s_mov_b32 s1, 0                                            // 0000000B7420: BE810080
	global_load_b32 v31, v[31:32], off                         // 0000000B7424: DC520000 1F7C001F
	v_mad_u64_u32 v[32:33], null, 0x44, s1, v[1:2]             // 0000000B742C: D6FE7C20 040402FF 00000044
	s_add_i32 s13, s1, 8                                       // 0000000B7438: 810D8801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000B743C: B6810078
	ds_load_2addr_b32 v[33:34], v32 offset1:17                 // 0000000B7440: D8DC1100 21000020
	ds_load_2addr_b32 v[49:50], v32 offset0:34 offset1:51      // 0000000B7448: D8DC3322 31000020
	ds_load_2addr_b32 v[51:52], v32 offset0:68 offset1:85      // 0000000B7450: D8DC5544 33000020
	ds_load_2addr_b32 v[53:54], v32 offset0:102 offset1:119    // 0000000B7458: D8DC7766 35000020
	v_lshl_add_u32 v32, s1, 2, v44                             // 0000000B7460: D6460020 04B10401
	s_mov_b32 s1, s13                                          // 0000000B7468: BE81000D
	ds_load_2addr_b32 v[55:56], v32 offset1:1                  // 0000000B746C: D8DC0100 37000020
	ds_load_2addr_b32 v[57:58], v32 offset0:2 offset1:3        // 0000000B7474: D8DC0302 39000020
	ds_load_2addr_b32 v[59:60], v32 offset0:4 offset1:5        // 0000000B747C: D8DC0504 3B000020
	ds_load_2addr_b32 v[61:62], v32 offset0:6 offset1:7        // 0000000B7484: D8DC0706 3D000020
	s_waitcnt lgkmcnt(7)                                       // 0000000B748C: BF89FC77
	v_fma_mixlo_f16 v32, v33, s6, 0                            // 0000000B7490: CC210020 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000B7498: CC210022 02000D22
	s_waitcnt lgkmcnt(6)                                       // 0000000B74A0: BF89FC67
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000B74A4: CC210031 02000D31
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B74AC: BF870193
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B74B0: CC200020 8A000F20
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B74B8: CC200022 8A000F22
	s_delay_alu instid0(VALU_DEP_3)                            // 0000000B74C0: BF870003
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B74C4: CC200031 8A000F31
	s_waitcnt lgkmcnt(3)                                       // 0000000B74CC: BF89FC37
	v_fma_mixlo_f16 v33, v55, s6, 0                            // 0000000B74D0: CC210021 02000D37
	v_fma_mixlo_f16 v55, v56, s6, 0                            // 0000000B74D8: CC210037 02000D38
	s_waitcnt lgkmcnt(2)                                       // 0000000B74E0: BF89FC27
	v_fma_mixlo_f16 v56, v57, s6, 0                            // 0000000B74E4: CC210038 02000D39
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B74EC: BF870193
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B74F0: CC200021 8A000F21
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B74F8: CC200037 8A000F37
	s_waitcnt vmcnt(0)                                         // 0000000B7500: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000000B7504: BF870242
	v_fma_f32 v31, -v33, v32, v31                              // 0000000B7508: D613001F 247E4121
	v_fma_mixlo_f16 v32, v50, s6, 0                            // 0000000B7510: CC210020 02000D32
	v_fma_mixlo_f16 v33, v58, s6, 0                            // 0000000B7518: CC210021 02000D3A
	v_fma_mix_f32 v50, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7520: CC200032 8A000F38
	v_fma_f32 v31, -v55, v34, v31                              // 0000000B7528: D613001F 247E4537
	v_fma_mixlo_f16 v34, v51, s6, 0                            // 0000000B7530: CC210022 02000D33
	s_waitcnt lgkmcnt(1)                                       // 0000000B7538: BF89FC17
	v_fma_mixlo_f16 v51, v59, s6, 0                            // 0000000B753C: CC210033 02000D3B
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7544: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B754C: CC200021 8A000F21
	v_fma_f32 v31, -v50, v49, v31                              // 0000000B7554: D613001F 247E6332
	v_fma_mixlo_f16 v49, v52, s6, 0                            // 0000000B755C: CC210031 02000D34
	v_fma_mixlo_f16 v50, v60, s6, 0                            // 0000000B7564: CC210032 02000D3C
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B756C: CC200022 8A000F22
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7574: CC200033 8A000F33
	v_fma_f32 v31, -v33, v32, v31                              // 0000000B757C: D613001F 247E4121
	v_fma_mixlo_f16 v32, v53, s6, 0                            // 0000000B7584: CC210020 02000D35
	s_waitcnt lgkmcnt(0)                                       // 0000000B758C: BF89FC07
	v_fma_mixlo_f16 v33, v61, s6, 0                            // 0000000B7590: CC210021 02000D3D
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7598: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B75A0: CC200032 8A000F32
	v_fma_f32 v31, -v51, v34, v31                              // 0000000B75A8: D613001F 247E4533
	v_fma_mixlo_f16 v34, v54, s6, 0                            // 0000000B75B0: CC210022 02000D36
	v_fma_mixlo_f16 v51, v62, s6, 0                            // 0000000B75B8: CC210033 02000D3E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B75C0: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B75C8: CC200021 8A000F21
	v_fma_f32 v31, -v50, v49, v31                              // 0000000B75D0: D613001F 247E6332
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B75D8: CC200022 8A000F22
	v_fma_mix_f32 v49, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B75E0: CC200031 8A000F33
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B75E8: BF870093
	v_fma_f32 v31, -v33, v32, v31                              // 0000000B75EC: D613001F 247E4121
	v_fma_f32 v31, -v49, v34, v31                              // 0000000B75F4: D613001F 247E4531
	s_cbranch_scc1 65419                                       // 0000000B75FC: BFA2FF8B <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x62c>
	v_mad_u64_u32 v[32:33], null, 0x44, s12, v[4:5]            // 0000000B7600: D6FE7C20 041018FF 00000044
	ds_store_b32 v32, v31                                      // 0000000B760C: D8340000 00001F20
	s_branch 65336                                             // 0000000B7614: BFA0FF38 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x4f8>
	v_mov_b32_e32 v30, v14                                     // 0000000B7618: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 0000000B761C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 0000000B7624: 7E3E0309
	v_mov_b32_e32 v49, v41                                     // 0000000B7628: 7E620329
	s_mov_b32 s12, 0                                           // 0000000B762C: BE8C0080
	s_branch 21                                                // 0000000B7630: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x888>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000B7634: 8C7E0D7E
	.long 0xd700011f                                           // 0000000B7638: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 0000000B763C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B7644: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000B7648: D5207C20 00064080
	.long 0xd700011d                                           // 0000000B7650: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 0000000B7654: 02023AFF 00000800
	v_add_nc_u32_e32 v49, 8, v49                               // 0000000B765C: 4A626288
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B7660: D5207C1E 00063C80
	s_add_i32 s1, s12, 8                                       // 0000000B7668: 8101880C
	s_cmp_gt_u32 s12, 55                                       // 0000000B766C: BF08B70C
	s_mov_b32 s12, s1                                          // 0000000B7670: BE8C0001
	s_waitcnt_vscnt null, 0x0                                  // 0000000B7674: BC7C0000
	s_barrier                                                  // 0000000B7678: BFBD0000
	buffer_gl0_inv                                             // 0000000B767C: E0AC0000 00000000
	s_cbranch_scc1 217                                         // 0000000B7684: BFA200D9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xbec>
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B7688: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 0000000B768C: CA100120 2220011F
	v_dual_mov_b32 v50, v38 :: v_dual_mov_b32 v51, v36         // 0000000B7694: CA100126 32320124
	s_mov_b32 s13, 0                                           // 0000000B769C: BE8D0080
	s_nop 0                                                    // 0000000B76A0: BF800000
	s_nop 0                                                    // 0000000B76A4: BF800000
	s_nop 0                                                    // 0000000B76A8: BF800000
	s_nop 0                                                    // 0000000B76AC: BF800000
	s_nop 0                                                    // 0000000B76B0: BF800000
	s_nop 0                                                    // 0000000B76B4: BF800000
	s_nop 0                                                    // 0000000B76B8: BF800000
	s_nop 0                                                    // 0000000B76BC: BF800000
	global_load_b32 v52, v[33:34], off                         // 0000000B76C0: DC520000 347C0021
	v_add_nc_u32_e32 v51, 0x80, v51                            // 0000000B76C8: 4A6666FF 00000080
	.long 0xd7000121                                           // 0000000B76D0: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 0000000B76D4: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B76DC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000B76E0: D5207C22 00064480
	.long 0xd4490004                                           // 0000000B76E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v51, vcc_lo                   // 0000000B76EC: 020266FF 0000037F
	s_or_b32 s13, s4, s13                                      // 0000000B76F4: 8C0D0D04
	s_waitcnt vmcnt(0)                                         // 0000000B76F8: BF8903F7
	ds_store_b32 v50, v52 offset:13056                         // 0000000B76FC: D8343300 00003432
	v_add_nc_u32_e32 v50, 0x204, v50                           // 0000000B7704: 4A6464FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s13                       // 0000000B770C: 917E0D7E
	s_cbranch_execnz 65515                                     // 0000000B7710: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8c0>
	s_or_b32 exec_lo, exec_lo, s13                             // 0000000B7714: 8C7E0D7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B7718: BF89FC07
	s_barrier                                                  // 0000000B771C: BFBD0000
	buffer_gl0_inv                                             // 0000000B7720: E0AC0000 00000000
	s_and_saveexec_b32 s13, s0                                 // 0000000B7728: BE8D2000
	s_cbranch_execz 65473                                      // 0000000B772C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	v_or_b32_e32 v33, s12, v2                                  // 0000000B7730: 3842040C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7734: BF870091
	v_or_b32_e32 v50, s11, v33                                 // 0000000B7738: 3864420B
	.long 0xd4440001                                           // 0000000B773C: D4440001
	v_cndmask_b32_e32 v1, s30, v50, vcc_lo                     // 0000000B7740: 0202641E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000B7744: 8B7E017E
	s_cbranch_execz 65466                                      // 0000000B7748: BFA5FFBA <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	v_mov_b32_e32 v51, 0                                       // 0000000B774C: 7E660280
	s_mov_b32 s1, 0                                            // 0000000B7750: BE810080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000B7754: BF870009
	v_lshl_add_u32 v34, s1, 2, v44                             // 0000000B7758: D6460022 04B10401
	s_add_i32 s4, s1, 8                                        // 0000000B7760: 81048801
	s_cmpk_lt_u32 s1, 0x78                                     // 0000000B7764: B6810078
	ds_load_2addr_b32 v[61:62], v34 offset1:1                  // 0000000B7768: D8DC0100 3D000022
	ds_load_2addr_b32 v[63:64], v34 offset0:2 offset1:3        // 0000000B7770: D8DC0302 3F000022
	ds_load_2addr_b32 v[65:66], v34 offset0:4 offset1:5        // 0000000B7778: D8DC0504 41000022
	ds_load_2addr_b32 v[67:68], v34 offset0:6 offset1:7        // 0000000B7780: D8DC0706 43000022
	v_mad_u64_u32 v[52:53], null, 0x44, s1, v[1:2]             // 0000000B7788: D6FE7C34 040402FF 00000044
	s_mov_b32 s1, s4                                           // 0000000B7794: BE810004
	ds_load_2addr_b32 v[53:54], v52 offset1:17                 // 0000000B7798: D8DC1100 35000034
	ds_load_2addr_b32 v[55:56], v52 offset0:34 offset1:51      // 0000000B77A0: D8DC3322 37000034
	ds_load_2addr_b32 v[57:58], v52 offset0:68 offset1:85      // 0000000B77A8: D8DC5544 39000034
	ds_load_2addr_b32 v[59:60], v52 offset0:102 offset1:119    // 0000000B77B0: D8DC7766 3B000034
	s_waitcnt lgkmcnt(7)                                       // 0000000B77B8: BF89FC77
	v_fma_mixlo_f16 v52, v61, s6, 0                            // 0000000B77BC: CC210034 02000D3D
	s_waitcnt lgkmcnt(6)                                       // 0000000B77C4: BF89FC67
	v_fma_mixlo_f16 v61, v63, s6, 0                            // 0000000B77C8: CC21003D 02000D3F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B77D0: BF870002
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B77D4: CC200034 8A000F34
	s_waitcnt lgkmcnt(3)                                       // 0000000B77DC: BF89FC37
	v_fma_mixlo_f16 v34, v53, s6, 0                            // 0000000B77E0: CC210022 02000D35
	v_fma_mixlo_f16 v53, v54, s6, 0                            // 0000000B77E8: CC210035 02000D36
	v_fma_mixlo_f16 v54, v62, s6, 0                            // 0000000B77F0: CC210036 02000D3E
	s_waitcnt lgkmcnt(2)                                       // 0000000B77F8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000B77FC: CC210037 02000D37
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7804: CC200022 8A000F22
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B780C: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7814: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000000B781C: BF870214
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7820: CC200037 8A000F37
	v_fmac_f32_e32 v51, v52, v34                               // 0000000B7828: 56664534
	v_fma_mixlo_f16 v34, v56, s6, 0                            // 0000000B782C: CC210022 02000D38
	v_fma_mixlo_f16 v52, v64, s6, 0                            // 0000000B7834: CC210034 02000D40
	v_fma_mix_f32 v56, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B783C: CC200038 8A000F3D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B7844: BF870004
	v_fmac_f32_e32 v51, v54, v53                               // 0000000B7848: 56666B36
	s_waitcnt lgkmcnt(1)                                       // 0000000B784C: BF89FC17
	v_fma_mixlo_f16 v53, v57, s6, 0                            // 0000000B7850: CC210035 02000D39
	v_fma_mixlo_f16 v54, v65, s6, 0                            // 0000000B7858: CC210036 02000D41
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7860: CC200022 8A000F22
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7868: CC200034 8A000F34
	v_fmac_f32_e32 v51, v56, v55                               // 0000000B7870: 56666F38
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000B7874: CC210037 02000D3A
	v_fma_mixlo_f16 v56, v66, s6, 0                            // 0000000B787C: CC210038 02000D42
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7884: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B788C: CC200036 8A000F36
	v_fmac_f32_e32 v51, v52, v34                               // 0000000B7894: 56664534
	s_waitcnt lgkmcnt(0)                                       // 0000000B7898: BF89FC07
	v_fma_mixlo_f16 v34, v59, s6, 0                            // 0000000B789C: CC210022 02000D3B
	v_fma_mixlo_f16 v52, v67, s6, 0                            // 0000000B78A4: CC210034 02000D43
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B78AC: CC200037 8A000F37
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B78B4: CC200038 8A000F38
	v_fmac_f32_e32 v51, v54, v53                               // 0000000B78BC: 56666B36
	v_fma_mixlo_f16 v53, v60, s6, 0                            // 0000000B78C0: CC210035 02000D3C
	v_fma_mixlo_f16 v54, v68, s6, 0                            // 0000000B78C8: CC210036 02000D44
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B78D0: CC200022 8A000F22
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B78D8: CC200034 8A000F34
	v_fmac_f32_e32 v51, v56, v55                               // 0000000B78E0: 56666F38
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B78E4: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B78EC: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B78F4: BF870093
	v_fmac_f32_e32 v51, v52, v34                               // 0000000B78F8: 56664534
	v_fmac_f32_e32 v51, v54, v53                               // 0000000B78FC: 56666B36
	s_cbranch_scc1 65428                                       // 0000000B7900: BFA2FF94 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x954>
	v_dual_mov_b32 v52, v1 :: v_dual_lshlrev_b32 v33, 2, v33   // 0000000B7904: CA220101 34204282
	s_mov_b32 s14, 0                                           // 0000000B790C: BE8E0080
	ds_load_b32 v53, v33 offset:17440                          // 0000000B7910: D8D84420 35000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000000B7918: CA10011E 2220011D
	s_waitcnt lgkmcnt(0)                                       // 0000000B7920: BF89FC07
	v_mul_f32_e32 v51, v51, v53                                // 0000000B7924: 10666B33
	v_mov_b32_e32 v53, v49                                     // 0000000B7928: 7E6A0331
	s_nop 0                                                    // 0000000B792C: BF800000
	s_nop 0                                                    // 0000000B7930: BF800000
	s_nop 0                                                    // 0000000B7934: BF800000
	s_nop 0                                                    // 0000000B7938: BF800000
	s_nop 0                                                    // 0000000B793C: BF800000
	global_load_b32 v54, v[33:34], off                         // 0000000B7940: DC520000 367C0021
	ds_load_b32 v55, v52 offset:8704                           // 0000000B7948: D8D82200 37000034
	v_add_nc_u32_e32 v53, -1, v53                              // 0000000B7950: 4A6A6AC1
	.long 0xd7000121                                           // 0000000B7954: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 0000000B7958: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B795C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 0000000B7960: D5207C22 00064480
	.long 0xd44a0004                                           // 0000000B7968: D44A0004
	v_cndmask_b32_e32 v1, 0, v53, vcc_lo                       // 0000000B796C: 02026A80
	v_add_nc_u32_e32 v52, 0x44, v52                            // 0000000B7970: 4A6868FF 00000044
	s_or_b32 s14, s4, s14                                      // 0000000B7978: 8C0E0E04
	s_waitcnt lgkmcnt(0)                                       // 0000000B797C: BF89FC07
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000B7980: CC210037 02000D37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000B7988: BF8700B1
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B798C: CC200037 8A000F37
	s_waitcnt vmcnt(0)                                         // 0000000B7994: BF8903F7
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000B7998: CC210036 02000D36
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B79A0: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B79A8: BF870001
	v_fmac_f32_e32 v51, v54, v55                               // 0000000B79AC: 56666F36
	s_and_not1_b32 exec_lo, exec_lo, s14                       // 0000000B79B0: 917E0E7E
	s_cbranch_execnz 65506                                     // 0000000B79B4: BFA6FFE2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xb40>
	s_or_b32 exec_lo, exec_lo, s14                             // 0000000B79B8: 8C7E0E7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B79BC: BF870121
	v_bfe_u32 v52, v51, 16, 1                                  // 0000000B79C0: D6100034 02052133
	v_mad_u64_u32 v[33:34], null, 0x3000, v50, v[5:6]          // 0000000B79C8: D6FE7C21 041664FF 00003000
	v_add3_u32 v50, v51, v52, 0x7fff                           // 0000000B79D4: D6550032 03FE6933 00007FFF
	global_store_d16_hi_b16 v[33:34], v50, off                 // 0000000B79E0: DC960000 007C3221
	s_branch 65298                                             // 0000000B79E8: BFA0FF12 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x834>
	s_mul_f32 s1, s10, 0x3fb8aa3b                              // 0000000B79EC: A201FF0A 3FB8AA3B
	v_mov_b32_e32 v31, v36                                     // 0000000B79F4: 7E3E0324
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000B79F8: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000B79FC: 8D04FF01 80000000
	s_rndne_f32 s11, s1                                        // 0000000B7A04: BE8B6301
	s_fmamk_f32 s4, s10, 0x3fb8aa3b, s4                        // 0000000B7A08: A304040A 3FB8AA3B
	s_cmp_nlt_f32 s10, 0xc2ce8ed0                              // 0000000B7A10: BF4EFF0A C2CE8ED0
	s_sub_f32 s1, s1, s11                                      // 0000000B7A18: A0810B01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000B7A1C: BF870599
	s_fmamk_f32 s4, s10, 0x32a5705f, s4                        // 0000000B7A20: A304040A 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000B7A28: A0010401
	s_mov_b32 s4, 0                                            // 0000000B7A2C: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000000B7A30: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000000B7A34: 7E3A4A01
	s_cvt_i32_f32 s1, s11                                      // 0000000B7A38: BE81660B
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000000B7A3C: BF870585
	.long 0xd71c001d                                           // 0000000B7A40: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000000B7A44: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000000B7A48: 980180C1
	s_cmp_ngt_f32 s10, 0x42b17218                              // 0000000B7A4C: BF4BFF0A 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000000B7A54: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000000B7A58: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000000B7A60: 980180C1
	v_mov_b32_e32 v29, v35                                     // 0000000B7A64: 7E3A0323
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000000B7A68: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 0000000B7A74: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 0000000B7A7C: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B7A84: BF870001
	.long 0xd4490001                                           // 0000000B7A88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 0000000B7A8C: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 0000000B7A94: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 0000000B7A98: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 0000000B7A9C: 1040411E
	ds_store_b32 v29, v32                                      // 0000000B7AA0: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 0000000B7AA8: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B7AB0: 917E047E
	s_cbranch_execnz 65519                                     // 0000000B7AB4: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc74>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B7AB8: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 0000000B7ABC: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v38           // 0000000B7AC4: CA100080 1F200126
	v_mov_b32_e32 v33, v36                                     // 0000000B7ACC: 7E420324
	s_mov_b32 s10, 0                                           // 0000000B7AD0: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B7AD4: BF89FC07
	s_barrier                                                  // 0000000B7AD8: BFBD0000
	buffer_gl0_inv                                             // 0000000B7ADC: E0AC0000 00000000
	s_nop 0                                                    // 0000000B7AE4: BF800000
	s_nop 0                                                    // 0000000B7AE8: BF800000
	s_nop 0                                                    // 0000000B7AEC: BF800000
	s_nop 0                                                    // 0000000B7AF0: BF800000
	s_nop 0                                                    // 0000000B7AF4: BF800000
	s_nop 0                                                    // 0000000B7AF8: BF800000
	s_nop 0                                                    // 0000000B7AFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B7B00: DC520000 227C001D
	ds_load_b32 v49, v31 offset:17184                          // 0000000B7B08: D8D84320 3100001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B7B10: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B7B18: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B7B1C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000B7B24: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B7B28: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B7B30: BF870004
	.long 0xd4490004                                           // 0000000B7B34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B7B38: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B7B40: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B7B44: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000B7B48: 10446322
	ds_store_b32 v32, v34 offset:13056                         // 0000000B7B4C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000B7B54: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B7B5C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B7B60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xd00>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B7B64: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B7B68: BF89FC07
	s_barrier                                                  // 0000000B7B6C: BFBD0000
	buffer_gl0_inv                                             // 0000000B7B70: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v45 offset1:17                 // 0000000B7B78: D8DC1100 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:34 offset1:51      // 0000000B7B80: D8DC3322 1F00002D
	ds_load_2addr_b32 v[33:34], v45 offset0:68 offset1:85      // 0000000B7B88: D8DC5544 2100002D
	ds_load_2addr_b32 v[49:50], v45 offset0:102 offset1:119    // 0000000B7B90: D8DC7766 3100002D
	v_mov_b32_e32 v51, v0                                      // 0000000B7B98: 7E660300
	s_mov_b32 s4, 0                                            // 0000000B7B9C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000B7BA0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000B7BA4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000B7BAC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000B7BB4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000B7BB8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000B7BC0: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000B7BC8: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000B7BCC: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000B7BD4: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000B7BDC: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000B7BE0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000B7BE8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7BF0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7BF8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7C00: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7C08: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7C10: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7C18: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7C20: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7C28: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000B7C30: 326C6684
	.long 0xd4490001                                           // 0000000B7C34: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000B7C38: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B7C40: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000B7C44: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000B7C48: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B7C54: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000B7C58: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000B7C60: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000B7C68: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000B7C70: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000B7C78: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000B7C80: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000B7C88: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000B7C90: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000B7C98: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000B7C9C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000B7CA4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000B7CA8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000B7CB0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000B7CB8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000B7CC0: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000B7CC4: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7CCC: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7CD4: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000B7CDC: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7CE4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7CEC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7CF4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000B7CFC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7D00: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000B7D04: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000B7D08: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000B7D0C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000B7D14: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000B7D18: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000B7D1C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000B7D20: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7D28: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000B7D30: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000B7D38: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B7D3C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7D40: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7D48: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7D50: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000B7D54: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000B7D58: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000B7D5C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B7D64: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000B7D68: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000B7D70: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B7D78: 917E047E
	s_cbranch_execnz 65452                                     // 0000000B7D7C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xe30>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B7D80: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v31, v38         // 0000000B7D84: CA100110 1E1E0126
	v_dual_mov_b32 v29, v15 :: v_dual_mov_b32 v32, 0           // 0000000B7D8C: CA10010F 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000B7D94: 7E420324
	s_mov_b32 s10, 0                                           // 0000000B7D98: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B7D9C: BF89FC07
	s_barrier                                                  // 0000000B7DA0: BFBD0000
	buffer_gl0_inv                                             // 0000000B7DA4: E0AC0000 00000000
	s_nop 0                                                    // 0000000B7DAC: BF800000
	s_nop 0                                                    // 0000000B7DB0: BF800000
	s_nop 0                                                    // 0000000B7DB4: BF800000
	s_nop 0                                                    // 0000000B7DB8: BF800000
	s_nop 0                                                    // 0000000B7DBC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B7DC0: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17216                          // 0000000B7DC8: D8D84340 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B7DD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B7DD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B7DDC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B7DE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B7DE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B7DF0: BF870004
	.long 0xd4490004                                           // 0000000B7DF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B7DF8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B7E00: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B7E04: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000B7E08: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000B7E0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B7E14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B7E1C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B7E20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfc0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B7E24: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B7E28: BF89FC07
	s_barrier                                                  // 0000000B7E2C: BFBD0000
	buffer_gl0_inv                                             // 0000000B7E30: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v45 offset0:136 offset1:153    // 0000000B7E38: D8DC9988 1D00002D
	ds_load_2addr_b32 v[31:32], v45 offset0:170 offset1:187    // 0000000B7E40: D8DCBBAA 1F00002D
	ds_load_2addr_b32 v[33:34], v45 offset0:204 offset1:221    // 0000000B7E48: D8DCDDCC 2100002D
	ds_load_2addr_b32 v[49:50], v45 offset0:238 offset1:255    // 0000000B7E50: D8DCFFEE 3100002D
	v_mov_b32_e32 v51, v0                                      // 0000000B7E58: 7E660300
	s_mov_b32 s4, 0                                            // 0000000B7E5C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000B7E60: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000B7E64: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000B7E6C: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000B7E74: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000B7E78: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000B7E80: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000B7E88: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000B7E8C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000B7E94: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000B7E9C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000B7EA0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000B7EA8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7EB0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7EB8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7EC0: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7EC8: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7ED0: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7ED8: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7EE0: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7EE8: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000B7EF0: 326C6684
	.long 0xd4490001                                           // 0000000B7EF4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000B7EF8: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B7F00: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000B7F04: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000B7F08: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B7F14: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000B7F18: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000B7F20: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000B7F28: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000B7F30: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000B7F38: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000B7F40: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000B7F48: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000B7F50: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000B7F58: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000B7F5C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000B7F64: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000B7F68: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000B7F70: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000B7F78: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000B7F80: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000B7F84: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7F8C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7F94: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000B7F9C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7FA4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7FAC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7FB4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000B7FBC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B7FC0: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000B7FC4: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000B7FC8: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000B7FCC: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000B7FD4: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000B7FD8: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000B7FDC: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000B7FE0: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B7FE8: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000B7FF0: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000B7FF8: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B7FFC: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8000: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8008: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8010: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000B8014: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000B8018: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000B801C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B8024: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000B8028: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000B8030: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B8038: 917E047E
	s_cbranch_execnz 65452                                     // 0000000B803C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10f0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B8040: 8C7E047E
	v_mov_b32_e32 v30, v18                                     // 0000000B8044: 7E3C0312
	v_mov_b32_e32 v31, v38                                     // 0000000B8048: 7E3E0326
	v_dual_mov_b32 v29, v17 :: v_dual_mov_b32 v32, 0           // 0000000B804C: CA100111 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000B8054: 7E420324
	s_mov_b32 s10, 0                                           // 0000000B8058: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B805C: BF89FC07
	s_barrier                                                  // 0000000B8060: BFBD0000
	buffer_gl0_inv                                             // 0000000B8064: E0AC0000 00000000
	s_nop 0                                                    // 0000000B806C: BF800000
	s_nop 0                                                    // 0000000B8070: BF800000
	s_nop 0                                                    // 0000000B8074: BF800000
	s_nop 0                                                    // 0000000B8078: BF800000
	s_nop 0                                                    // 0000000B807C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B8080: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17248                          // 0000000B8088: D8D84360 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B8090: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B8098: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B809C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B80A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B80A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B80B0: BF870004
	.long 0xd4490004                                           // 0000000B80B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B80B8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B80C0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B80C4: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000B80C8: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000B80CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B80D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B80DC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B80E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1280>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B80E4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B80E8: BF89FC07
	s_barrier                                                  // 0000000B80EC: BFBD0000
	buffer_gl0_inv                                             // 0000000B80F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v46 offset0:16 offset1:33      // 0000000B80F8: D8DC2110 1D00002E
	ds_load_2addr_b32 v[31:32], v46 offset0:50 offset1:67      // 0000000B8100: D8DC4332 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:84 offset1:101     // 0000000B8108: D8DC6554 2100002E
	ds_load_2addr_b32 v[49:50], v46 offset0:118 offset1:135    // 0000000B8110: D8DC8776 3100002E
	v_mov_b32_e32 v51, v0                                      // 0000000B8118: 7E660300
	s_mov_b32 s4, 0                                            // 0000000B811C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000B8120: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000B8124: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000B812C: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000B8134: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000B8138: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000B8140: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000B8148: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000B814C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000B8154: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000B815C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000B8160: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000B8168: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8170: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8178: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8180: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8188: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8190: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8198: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B81A0: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B81A8: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000B81B0: 326C6684
	.long 0xd4490001                                           // 0000000B81B4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000B81B8: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B81C0: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000B81C4: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000B81C8: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B81D4: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000B81D8: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000B81E0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000B81E8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000B81F0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000B81F8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000B8200: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000B8208: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000B8210: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000B8218: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000B821C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000B8224: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000B8228: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000B8230: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000B8238: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000B8240: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000B8244: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B824C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8254: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000B825C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8264: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B826C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8274: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000B827C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8280: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000B8284: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000B8288: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000B828C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000B8294: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000B8298: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000B829C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000B82A0: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B82A8: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000B82B0: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000B82B8: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B82BC: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B82C0: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B82C8: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B82D0: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000B82D4: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000B82D8: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000B82DC: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B82E4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000B82E8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000B82F0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B82F8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000B82FC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x13b0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B8300: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v31, v38         // 0000000B8304: CA100114 1E1E0126
	v_dual_mov_b32 v29, v19 :: v_dual_mov_b32 v32, 0           // 0000000B830C: CA100113 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000B8314: 7E420324
	s_mov_b32 s10, 0                                           // 0000000B8318: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B831C: BF89FC07
	s_barrier                                                  // 0000000B8320: BFBD0000
	buffer_gl0_inv                                             // 0000000B8324: E0AC0000 00000000
	s_nop 0                                                    // 0000000B832C: BF800000
	s_nop 0                                                    // 0000000B8330: BF800000
	s_nop 0                                                    // 0000000B8334: BF800000
	s_nop 0                                                    // 0000000B8338: BF800000
	s_nop 0                                                    // 0000000B833C: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B8340: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17280                          // 0000000B8348: D8D84380 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B8350: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B8358: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B835C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B8364: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B8368: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B8370: BF870004
	.long 0xd4490004                                           // 0000000B8374: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B8378: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B8380: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B8384: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000B8388: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000B838C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B8394: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B839C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B83A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1540>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B83A4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B83A8: BF89FC07
	s_barrier                                                  // 0000000B83AC: BFBD0000
	buffer_gl0_inv                                             // 0000000B83B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v46 offset0:152 offset1:169    // 0000000B83B8: D8DCA998 1D00002E
	ds_load_2addr_b32 v[31:32], v46 offset0:186 offset1:203    // 0000000B83C0: D8DCCBBA 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:220 offset1:237    // 0000000B83C8: D8DCEDDC 2100002E
	ds_load_2addr_b32 v[49:50], v47 offset0:126 offset1:143    // 0000000B83D0: D8DC8F7E 3100002F
	v_mov_b32_e32 v51, v0                                      // 0000000B83D8: 7E660300
	s_mov_b32 s4, 0                                            // 0000000B83DC: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000B83E0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000B83E4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000B83EC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000B83F4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000B83F8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000B8400: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000B8408: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000B840C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000B8414: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000B841C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000B8420: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000B8428: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8430: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8438: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8440: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8448: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8450: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8458: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8460: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8468: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000B8470: 326C6684
	.long 0xd4490001                                           // 0000000B8474: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000B8478: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B8480: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000B8484: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000B8488: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B8494: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000B8498: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000B84A0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000B84A8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000B84B0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000B84B8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000B84C0: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000B84C8: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000B84D0: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000B84D8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000B84DC: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000B84E4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000B84E8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000B84F0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000B84F8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000B8500: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000B8504: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B850C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8514: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000B851C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8524: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B852C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8534: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000B853C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8540: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000B8544: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000B8548: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000B854C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000B8554: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000B8558: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000B855C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000B8560: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8568: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000B8570: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000B8578: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B857C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8580: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8588: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8590: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000B8594: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000B8598: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000B859C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B85A4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000B85A8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000B85B0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B85B8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000B85BC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1670>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B85C0: 8C7E047E
	v_mov_b32_e32 v30, v22                                     // 0000000B85C4: 7E3C0316
	v_mov_b32_e32 v31, v38                                     // 0000000B85C8: 7E3E0326
	v_dual_mov_b32 v29, v21 :: v_dual_mov_b32 v32, 0           // 0000000B85CC: CA100115 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000B85D4: 7E420324
	s_mov_b32 s10, 0                                           // 0000000B85D8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B85DC: BF89FC07
	s_barrier                                                  // 0000000B85E0: BFBD0000
	buffer_gl0_inv                                             // 0000000B85E4: E0AC0000 00000000
	s_nop 0                                                    // 0000000B85EC: BF800000
	s_nop 0                                                    // 0000000B85F0: BF800000
	s_nop 0                                                    // 0000000B85F4: BF800000
	s_nop 0                                                    // 0000000B85F8: BF800000
	s_nop 0                                                    // 0000000B85FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B8600: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17312                          // 0000000B8608: D8D843A0 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B8610: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B8618: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B861C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B8624: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B8628: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B8630: BF870004
	.long 0xd4490004                                           // 0000000B8634: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B8638: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B8640: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B8644: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000B8648: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000B864C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B8654: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B865C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B8660: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1800>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B8664: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B8668: BF89FC07
	s_barrier                                                  // 0000000B866C: BFBD0000
	buffer_gl0_inv                                             // 0000000B8670: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v48 offset0:32 offset1:49      // 0000000B8678: D8DC3120 1D000030
	ds_load_2addr_b32 v[31:32], v48 offset0:66 offset1:83      // 0000000B8680: D8DC5342 1F000030
	ds_load_2addr_b32 v[33:34], v48 offset0:100 offset1:117    // 0000000B8688: D8DC7564 21000030
	ds_load_2addr_b32 v[49:50], v48 offset0:134 offset1:151    // 0000000B8690: D8DC9786 31000030
	v_mov_b32_e32 v51, v0                                      // 0000000B8698: 7E660300
	s_mov_b32 s4, 0                                            // 0000000B869C: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000B86A0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000B86A4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000B86AC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000B86B4: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000B86B8: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000B86C0: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000B86C8: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000B86CC: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000B86D4: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000B86DC: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000B86E0: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000B86E8: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B86F0: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B86F8: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8700: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8708: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8710: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8718: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8720: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8728: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000B8730: 326C6684
	.long 0xd4490001                                           // 0000000B8734: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000B8738: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B8740: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000B8744: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000B8748: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B8754: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000B8758: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000B8760: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000B8768: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000B8770: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000B8778: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000B8780: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000B8788: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000B8790: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000B8798: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000B879C: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000B87A4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000B87A8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000B87B0: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000B87B8: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000B87C0: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000B87C4: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B87CC: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B87D4: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000B87DC: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B87E4: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B87EC: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B87F4: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000B87FC: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8800: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000B8804: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000B8808: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000B880C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000B8814: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000B8818: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000B881C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000B8820: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8828: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000B8830: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000B8838: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B883C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8840: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8848: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8850: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000B8854: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000B8858: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000B885C: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B8864: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000B8868: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000B8870: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B8878: 917E047E
	s_cbranch_execnz 65452                                     // 0000000B887C: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1930>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B8880: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v31, v38         // 0000000B8884: CA100118 1E1E0126
	v_dual_mov_b32 v29, v23 :: v_dual_mov_b32 v32, 0           // 0000000B888C: CA100117 1D200080
	v_mov_b32_e32 v33, v36                                     // 0000000B8894: 7E420324
	s_mov_b32 s10, 0                                           // 0000000B8898: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B889C: BF89FC07
	s_barrier                                                  // 0000000B88A0: BFBD0000
	buffer_gl0_inv                                             // 0000000B88A4: E0AC0000 00000000
	s_nop 0                                                    // 0000000B88AC: BF800000
	s_nop 0                                                    // 0000000B88B0: BF800000
	s_nop 0                                                    // 0000000B88B4: BF800000
	s_nop 0                                                    // 0000000B88B8: BF800000
	s_nop 0                                                    // 0000000B88BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000B88C0: DC520000 227C001D
	ds_load_b32 v49, v32 offset:17344                          // 0000000B88C8: D8D843C0 31000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000B88D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000B88D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B88DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000B88E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B88E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B88F0: BF870004
	.long 0xd4490004                                           // 0000000B88F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000B88F8: 020242FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B8900: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B8904: BF890007
	v_mul_f32_e32 v34, v34, v49                                // 0000000B8908: 10446322
	ds_store_b32 v31, v34 offset:13056                         // 0000000B890C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000B8914: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B891C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B8920: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ac0>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B8924: 8C7E0A7E
	v_add_nc_u32_e32 v31, 0xc00, v45                           // 0000000B8928: 4A3E5AFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000B8930: BF89FC07
	s_barrier                                                  // 0000000B8934: BFBD0000
	buffer_gl0_inv                                             // 0000000B8938: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v48 offset0:168 offset1:185    // 0000000B8940: D8DCB9A8 1D000030
	ds_load_2addr_b32 v[32:33], v48 offset0:202 offset1:219    // 0000000B8948: D8DCDBCA 20000030
	ds_load_2addr_b32 v[49:50], v48 offset0:236 offset1:253    // 0000000B8950: D8DCFDEC 31000030
	ds_load_2addr_b32 v[51:52], v31 offset0:14 offset1:31      // 0000000B8958: D8DC1F0E 3300001F
	s_mov_b32 s4, 0                                            // 0000000B8960: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000B8964: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000B8968: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000B8970: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000B8978: BF89FC27
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000B897C: CC210020 02000D20
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000B8984: CC210021 02000D21
	s_waitcnt lgkmcnt(1)                                       // 0000000B898C: BF89FC17
	v_fma_mixlo_f16 v34, v49, s6, 0                            // 0000000B8990: CC210022 02000D31
	v_fma_mixlo_f16 v49, v50, s6, 0                            // 0000000B8998: CC210031 02000D32
	s_waitcnt lgkmcnt(0)                                       // 0000000B89A0: BF89FC07
	v_fma_mixlo_f16 v50, v51, s6, 0                            // 0000000B89A4: CC210032 02000D33
	v_fma_mixlo_f16 v51, v52, s6, 0                            // 0000000B89AC: CC210033 02000D34
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B89B4: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B89BC: CC20001E 8A000F1E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B89C4: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B89CC: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B89D4: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B89DC: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B89E4: CC200032 8A000F32
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B89EC: CC200033 8A000F33
	v_mov_b32_e32 v52, v0                                      // 0000000B89F4: 7E680300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B89F8: BF870121
	v_lshrrev_b32_e32 v55, 4, v52                              // 0000000B89FC: 326E6884
	.long 0xd4490001                                           // 0000000B8A00: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v52, vcc_lo                   // 0000000B8A04: 020268FF 0000077F
	v_lshlrev_b32_e32 v60, 2, v55                              // 0000000B8A0C: 30786E82
	v_mad_u64_u32 v[55:56], null, 0x44, v55, v[1:2]            // 0000000B8A10: D6FE7C37 04066EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B8A1C: 8C040401
	v_add_nc_u32_e32 v53, 0x3200, v60                          // 0000000B8A20: 4A6A78FF 00003200
	v_add_nc_u32_e32 v56, 0x3600, v60                          // 0000000B8A28: 4A7078FF 00003600
	v_add_nc_u32_e32 v58, 0x3a00, v60                          // 0000000B8A30: 4A7478FF 00003A00
	v_add_nc_u32_e32 v60, 0x3e00, v60                          // 0000000B8A38: 4A7878FF 00003E00
	ds_load_b32 v61, v55                                       // 0000000B8A40: D8D80000 3D000037
	ds_load_2addr_b32 v[56:57], v56 offset0:66 offset1:195     // 0000000B8A48: D8DCC342 38000038
	ds_load_2addr_b32 v[53:54], v53 offset0:64 offset1:193     // 0000000B8A50: D8DCC140 35000035
	ds_load_2addr_b32 v[58:59], v58 offset0:68 offset1:197     // 0000000B8A58: D8DCC544 3A00003A
	s_waitcnt lgkmcnt(2)                                       // 0000000B8A60: BF89FC27
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000B8A64: CC210038 02000D38
	s_waitcnt lgkmcnt(1)                                       // 0000000B8A6C: BF89FC17
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000B8A70: CC210035 02000D35
	v_fma_mixlo_f16 v62, v54, s6, 0                            // 0000000B8A78: CC21003E 02000D36
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000B8A80: CC210039 02000D39
	s_waitcnt lgkmcnt(0)                                       // 0000000B8A88: BF89FC07
	v_fma_mixlo_f16 v58, v58, s6, 0                            // 0000000B8A8C: CC21003A 02000D3A
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8A94: CC200038 8A000F38
	v_fma_mix_f32 v63, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8A9C: CC20003F 8A000F35
	ds_load_2addr_b32 v[53:54], v60 offset0:70 offset1:199     // 0000000B8AA4: D8DCC746 3500003C
	v_fma_mix_f32 v60, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8AAC: CC20003C 8A000F3E
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8AB4: CC200039 8A000F39
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8ABC: CC20003A 8A000F3A
	v_fmac_f32_e32 v61, v63, v29                               // 0000000B8AC4: 567A3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8AC8: BF870091
	v_fmac_f32_e32 v61, v60, v30                               // 0000000B8ACC: 567A3D3C
	v_fmac_f32_e32 v61, v56, v32                               // 0000000B8AD0: 567A4138
	v_fma_mixlo_f16 v56, v59, s6, 0                            // 0000000B8AD4: CC210038 02000D3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000B8ADC: BF8701B2
	v_fmac_f32_e32 v61, v57, v33                               // 0000000B8AE0: 567A4339
	s_waitcnt lgkmcnt(0)                                       // 0000000B8AE4: BF89FC07
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000B8AE8: CC210035 02000D35
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8AF0: CC200038 8A000F38
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000B8AF8: CC210036 02000D36
	v_fmac_f32_e32 v61, v58, v34                               // 0000000B8B00: 567A453A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B8B04: BF870194
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8B08: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8B10: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8B18: BF870093
	v_fmac_f32_e32 v61, v56, v49                               // 0000000B8B1C: 567A6338
	v_fmac_f32_e32 v61, v53, v50                               // 0000000B8B20: 567A6535
	v_add_nc_u32_e32 v53, 0x80, v52                            // 0000000B8B24: 4A6A68FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B8B2C: BF870001
	v_dual_fmac_f32 v61, v54, v51 :: v_dual_mov_b32 v52, v53   // 0000000B8B30: C8106736 3D340135
	ds_store_b32 v55, v61                                      // 0000000B8B38: D8340000 00003D37
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B8B40: 917E047E
	s_cbranch_execnz 65452                                     // 0000000B8B44: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1bf8>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B8B48: 8C7E047E
	v_mov_b32_e32 v30, v26                                     // 0000000B8B4C: 7E3C031A
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v29, v25         // 0000000B8B50: CA100126 201C0119
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 0000000B8B58: CA100080 21220124
	s_mov_b32 s10, 0                                           // 0000000B8B60: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B8B64: BF89FC07
	s_barrier                                                  // 0000000B8B68: BFBD0000
	buffer_gl0_inv                                             // 0000000B8B6C: E0AC0000 00000000
	s_nop 0                                                    // 0000000B8B74: BF800000
	s_nop 0                                                    // 0000000B8B78: BF800000
	s_nop 0                                                    // 0000000B8B7C: BF800000
	global_load_b32 v49, v[29:30], off                         // 0000000B8B80: DC520000 317C001D
	ds_load_b32 v50, v33 offset:17376                          // 0000000B8B88: D8D843E0 32000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000B8B90: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000B8B98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B8B9C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000B8BA4: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B8BA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B8BB0: BF870004
	.long 0xd4490004                                           // 0000000B8BB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000B8BB8: 020244FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B8BC0: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B8BC4: BF890007
	v_mul_f32_e32 v49, v49, v50                                // 0000000B8BC8: 10626531
	ds_store_b32 v32, v49 offset:13056                         // 0000000B8BCC: D8343300 00003120
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000B8BD4: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B8BDC: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B8BE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d80>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B8BE4: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 0000000B8BE8: BF89FC07
	s_barrier                                                  // 0000000B8BEC: BFBD0000
	buffer_gl0_inv                                             // 0000000B8BF0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:48 offset1:65      // 0000000B8BF8: D8DC4130 1D00001F
	ds_load_2addr_b32 v[32:33], v31 offset0:82 offset1:99      // 0000000B8C00: D8DC6352 2000001F
	ds_load_2addr_b32 v[49:50], v31 offset0:116 offset1:133    // 0000000B8C08: D8DC8574 3100001F
	ds_load_2addr_b32 v[51:52], v31 offset0:150 offset1:167    // 0000000B8C10: D8DCA796 3300001F
	s_mov_b32 s4, 0                                            // 0000000B8C18: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000B8C1C: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000B8C20: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000B8C28: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000B8C30: BF89FC27
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000B8C34: CC210020 02000D20
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000B8C3C: CC210021 02000D21
	s_waitcnt lgkmcnt(1)                                       // 0000000B8C44: BF89FC17
	v_fma_mixlo_f16 v34, v49, s6, 0                            // 0000000B8C48: CC210022 02000D31
	v_fma_mixlo_f16 v49, v50, s6, 0                            // 0000000B8C50: CC210031 02000D32
	s_waitcnt lgkmcnt(0)                                       // 0000000B8C58: BF89FC07
	v_fma_mixlo_f16 v50, v51, s6, 0                            // 0000000B8C5C: CC210032 02000D33
	v_fma_mixlo_f16 v51, v52, s6, 0                            // 0000000B8C64: CC210033 02000D34
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8C6C: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8C74: CC20001E 8A000F1E
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8C7C: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8C84: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8C8C: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8C94: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8C9C: CC200032 8A000F32
	v_fma_mix_f32 v51, v51, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8CA4: CC200033 8A000F33
	v_mov_b32_e32 v52, v0                                      // 0000000B8CAC: 7E680300
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000B8CB0: BF870121
	v_lshrrev_b32_e32 v55, 4, v52                              // 0000000B8CB4: 326E6884
	.long 0xd4490001                                           // 0000000B8CB8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v52, vcc_lo                   // 0000000B8CBC: 020268FF 0000077F
	v_lshlrev_b32_e32 v60, 2, v55                              // 0000000B8CC4: 30786E82
	v_mad_u64_u32 v[55:56], null, 0x44, v55, v[1:2]            // 0000000B8CC8: D6FE7C37 04066EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B8CD4: 8C040401
	v_add_nc_u32_e32 v53, 0x3200, v60                          // 0000000B8CD8: 4A6A78FF 00003200
	v_add_nc_u32_e32 v56, 0x3600, v60                          // 0000000B8CE0: 4A7078FF 00003600
	v_add_nc_u32_e32 v58, 0x3a00, v60                          // 0000000B8CE8: 4A7478FF 00003A00
	v_add_nc_u32_e32 v60, 0x3e00, v60                          // 0000000B8CF0: 4A7878FF 00003E00
	ds_load_b32 v61, v55                                       // 0000000B8CF8: D8D80000 3D000037
	ds_load_2addr_b32 v[56:57], v56 offset0:66 offset1:195     // 0000000B8D00: D8DCC342 38000038
	ds_load_2addr_b32 v[53:54], v53 offset0:64 offset1:193     // 0000000B8D08: D8DCC140 35000035
	ds_load_2addr_b32 v[58:59], v58 offset0:68 offset1:197     // 0000000B8D10: D8DCC544 3A00003A
	s_waitcnt lgkmcnt(2)                                       // 0000000B8D18: BF89FC27
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000B8D1C: CC210038 02000D38
	s_waitcnt lgkmcnt(1)                                       // 0000000B8D24: BF89FC17
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000B8D28: CC210035 02000D35
	v_fma_mixlo_f16 v62, v54, s6, 0                            // 0000000B8D30: CC21003E 02000D36
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000B8D38: CC210039 02000D39
	s_waitcnt lgkmcnt(0)                                       // 0000000B8D40: BF89FC07
	v_fma_mixlo_f16 v58, v58, s6, 0                            // 0000000B8D44: CC21003A 02000D3A
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8D4C: CC200038 8A000F38
	v_fma_mix_f32 v63, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8D54: CC20003F 8A000F35
	ds_load_2addr_b32 v[53:54], v60 offset0:70 offset1:199     // 0000000B8D5C: D8DCC746 3500003C
	v_fma_mix_f32 v60, v62, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8D64: CC20003C 8A000F3E
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8D6C: CC200039 8A000F39
	v_fma_mix_f32 v58, v58, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8D74: CC20003A 8A000F3A
	v_fmac_f32_e32 v61, v63, v29                               // 0000000B8D7C: 567A3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8D80: BF870091
	v_fmac_f32_e32 v61, v60, v30                               // 0000000B8D84: 567A3D3C
	v_fmac_f32_e32 v61, v56, v32                               // 0000000B8D88: 567A4138
	v_fma_mixlo_f16 v56, v59, s6, 0                            // 0000000B8D8C: CC210038 02000D3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000B8D94: BF8701B2
	v_fmac_f32_e32 v61, v57, v33                               // 0000000B8D98: 567A4339
	s_waitcnt lgkmcnt(0)                                       // 0000000B8D9C: BF89FC07
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000B8DA0: CC210035 02000D35
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8DA8: CC200038 8A000F38
	v_fma_mixlo_f16 v54, v54, s6, 0                            // 0000000B8DB0: CC210036 02000D36
	v_fmac_f32_e32 v61, v58, v34                               // 0000000B8DB8: 567A453A
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B8DBC: BF870194
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8DC0: CC200035 8A000F35
	v_fma_mix_f32 v54, v54, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8DC8: CC200036 8A000F36
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B8DD0: BF870093
	v_fmac_f32_e32 v61, v56, v49                               // 0000000B8DD4: 567A6338
	v_fmac_f32_e32 v61, v53, v50                               // 0000000B8DD8: 567A6535
	v_add_nc_u32_e32 v53, 0x80, v52                            // 0000000B8DDC: 4A6A68FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B8DE4: BF870001
	v_dual_fmac_f32 v61, v54, v51 :: v_dual_mov_b32 v52, v53   // 0000000B8DE8: C8106736 3D340135
	ds_store_b32 v55, v61                                      // 0000000B8DF0: D8340000 00003D37
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B8DF8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000B8DFC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1eb0>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B8E00: 8C7E047E
	v_mov_b32_e32 v30, v28                                     // 0000000B8E04: 7E3C031C
	v_dual_mov_b32 v32, v38 :: v_dual_mov_b32 v29, v27         // 0000000B8E08: CA100126 201C011B
	v_dual_mov_b32 v33, 0 :: v_dual_mov_b32 v34, v36           // 0000000B8E10: CA100080 21220124
	s_mov_b32 s10, 0                                           // 0000000B8E18: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000B8E1C: BF89FC07
	s_barrier                                                  // 0000000B8E20: BFBD0000
	buffer_gl0_inv                                             // 0000000B8E24: E0AC0000 00000000
	s_nop 0                                                    // 0000000B8E2C: BF800000
	s_nop 0                                                    // 0000000B8E30: BF800000
	s_nop 0                                                    // 0000000B8E34: BF800000
	s_nop 0                                                    // 0000000B8E38: BF800000
	s_nop 0                                                    // 0000000B8E3C: BF800000
	global_load_b32 v49, v[29:30], off                         // 0000000B8E40: DC520000 317C001D
	ds_load_b32 v50, v33 offset:17408                          // 0000000B8E48: D8D84400 32000021
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000B8E50: 4A4444FF 00000080
	.long 0xd700011d                                           // 0000000B8E58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000B8E5C: 02023AFF 00006000
	v_add_nc_u32_e32 v33, 4, v33                               // 0000000B8E64: 4A424284
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000B8E68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000B8E70: BF870004
	.long 0xd4490004                                           // 0000000B8E74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000B8E78: 020244FF 0000037F
	s_or_b32 s10, s4, s10                                      // 0000000B8E80: 8C0A0A04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000B8E84: BF890007
	v_mul_f32_e32 v49, v49, v50                                // 0000000B8E88: 10626531
	ds_store_b32 v32, v49 offset:13056                         // 0000000B8E8C: D8343300 00003120
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000000B8E94: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 0000000B8E9C: 917E0A7E
	s_cbranch_execnz 65511                                     // 0000000B8EA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000000B8EA4: 8C7E0A7E
	v_add_nc_u32_e32 v33, 0xe00, v45                           // 0000000B8EA8: 4A425AFF 00000E00
	v_add_nc_u32_e32 v49, 0x1000, v45                          // 0000000B8EB0: 4A625AFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 0000000B8EB8: BF89FC07
	s_barrier                                                  // 0000000B8EBC: BFBD0000
	buffer_gl0_inv                                             // 0000000B8EC0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v31 offset0:184 offset1:201    // 0000000B8EC8: D8DCC9B8 1D00001F
	ds_load_2addr_b32 v[31:32], v31 offset0:218 offset1:235    // 0000000B8ED0: D8DCEBDA 1F00001F
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 0000000B8ED8: D8DC8D7C 21000021
	ds_load_2addr_b32 v[49:50], v49 offset0:30 offset1:47      // 0000000B8EE0: D8DC2F1E 31000031
	v_mov_b32_e32 v51, v0                                      // 0000000B8EE8: 7E660300
	s_mov_b32 s4, 0                                            // 0000000B8EEC: BE840080
	s_waitcnt lgkmcnt(3)                                       // 0000000B8EF0: BF89FC37
	v_fma_mixlo_f16 v29, v29, s6, 0                            // 0000000B8EF4: CC21001D 02000D1D
	v_fma_mixlo_f16 v30, v30, s6, 0                            // 0000000B8EFC: CC21001E 02000D1E
	s_waitcnt lgkmcnt(2)                                       // 0000000B8F04: BF89FC27
	v_fma_mixlo_f16 v31, v31, s6, 0                            // 0000000B8F08: CC21001F 02000D1F
	v_fma_mixlo_f16 v32, v32, s6, 0                            // 0000000B8F10: CC210020 02000D20
	s_waitcnt lgkmcnt(1)                                       // 0000000B8F18: BF89FC17
	v_fma_mixlo_f16 v33, v33, s6, 0                            // 0000000B8F1C: CC210021 02000D21
	v_fma_mixlo_f16 v34, v34, s6, 0                            // 0000000B8F24: CC210022 02000D22
	s_waitcnt lgkmcnt(0)                                       // 0000000B8F2C: BF89FC07
	v_fma_mixlo_f16 v49, v49, s6, 0                            // 0000000B8F30: CC210031 02000D31
	v_fma_mixlo_f16 v50, v50, s6, 0                            // 0000000B8F38: CC210032 02000D32
	v_fma_mix_f32 v29, v29, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8F40: CC20001D 8A000F1D
	v_fma_mix_f32 v30, v30, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8F48: CC20001E 8A000F1E
	v_fma_mix_f32 v31, v31, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8F50: CC20001F 8A000F1F
	v_fma_mix_f32 v32, v32, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8F58: CC200020 8A000F20
	v_fma_mix_f32 v33, v33, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8F60: CC200021 8A000F21
	v_fma_mix_f32 v34, v34, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8F68: CC200022 8A000F22
	v_fma_mix_f32 v49, v49, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8F70: CC200031 8A000F31
	v_fma_mix_f32 v50, v50, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B8F78: CC200032 8A000F32
	v_lshrrev_b32_e32 v54, 4, v51                              // 0000000B8F80: 326C6684
	.long 0xd4490001                                           // 0000000B8F84: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v51, vcc_lo                   // 0000000B8F88: 020266FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000000B8F90: BF870002
	v_lshlrev_b32_e32 v59, 2, v54                              // 0000000B8F94: 30766C82
	v_mad_u64_u32 v[54:55], null, 0x44, v54, v[1:2]            // 0000000B8F98: D6FE7C36 04066CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000B8FA4: 8C040401
	v_add_nc_u32_e32 v52, 0x3200, v59                          // 0000000B8FA8: 4A6876FF 00003200
	v_add_nc_u32_e32 v55, 0x3600, v59                          // 0000000B8FB0: 4A6E76FF 00003600
	v_add_nc_u32_e32 v57, 0x3a00, v59                          // 0000000B8FB8: 4A7276FF 00003A00
	v_add_nc_u32_e32 v59, 0x3e00, v59                          // 0000000B8FC0: 4A7676FF 00003E00
	ds_load_b32 v60, v54                                       // 0000000B8FC8: D8D80000 3C000036
	ds_load_2addr_b32 v[55:56], v55 offset0:66 offset1:195     // 0000000B8FD0: D8DCC342 37000037
	ds_load_2addr_b32 v[52:53], v52 offset0:64 offset1:193     // 0000000B8FD8: D8DCC140 34000034
	ds_load_2addr_b32 v[57:58], v57 offset0:68 offset1:197     // 0000000B8FE0: D8DCC544 39000039
	s_waitcnt lgkmcnt(2)                                       // 0000000B8FE8: BF89FC27
	v_fma_mixlo_f16 v55, v55, s6, 0                            // 0000000B8FEC: CC210037 02000D37
	s_waitcnt lgkmcnt(1)                                       // 0000000B8FF4: BF89FC17
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000B8FF8: CC210034 02000D34
	v_fma_mixlo_f16 v61, v53, s6, 0                            // 0000000B9000: CC21003D 02000D35
	v_fma_mixlo_f16 v56, v56, s6, 0                            // 0000000B9008: CC210038 02000D38
	s_waitcnt lgkmcnt(0)                                       // 0000000B9010: BF89FC07
	v_fma_mixlo_f16 v57, v57, s6, 0                            // 0000000B9014: CC210039 02000D39
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B901C: CC200037 8A000F37
	v_fma_mix_f32 v62, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9024: CC20003E 8A000F34
	ds_load_2addr_b32 v[52:53], v59 offset0:70 offset1:199     // 0000000B902C: D8DCC746 3400003B
	v_fma_mix_f32 v59, v61, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9034: CC20003B 8A000F3D
	v_fma_mix_f32 v56, v56, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B903C: CC200038 8A000F38
	v_fma_mix_f32 v57, v57, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9044: CC200039 8A000F39
	v_fmac_f32_e32 v60, v62, v29                               // 0000000B904C: 56783B3E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9050: BF870091
	v_fmac_f32_e32 v60, v59, v30                               // 0000000B9054: 56783D3B
	v_fmac_f32_e32 v60, v55, v31                               // 0000000B9058: 56783F37
	v_fma_mixlo_f16 v55, v58, s6, 0                            // 0000000B905C: CC210037 02000D3A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000000B9064: BF8701B2
	v_fmac_f32_e32 v60, v56, v32                               // 0000000B9068: 56784138
	s_waitcnt lgkmcnt(0)                                       // 0000000B906C: BF89FC07
	v_fma_mixlo_f16 v52, v52, s6, 0                            // 0000000B9070: CC210034 02000D34
	v_fma_mix_f32 v55, v55, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9078: CC200037 8A000F37
	v_fma_mixlo_f16 v53, v53, s6, 0                            // 0000000B9080: CC210035 02000D35
	v_fmac_f32_e32 v60, v57, v33                               // 0000000B9088: 56784339
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000B908C: BF870194
	v_fma_mix_f32 v52, v52, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9090: CC200034 8A000F34
	v_fma_mix_f32 v53, v53, s7, neg(0) op_sel_hi:[1,0,0]       // 0000000B9098: CC200035 8A000F35
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B90A0: BF870093
	v_fmac_f32_e32 v60, v55, v34                               // 0000000B90A4: 56784537
	v_fmac_f32_e32 v60, v52, v49                               // 0000000B90A8: 56786334
	v_add_nc_u32_e32 v52, 0x80, v51                            // 0000000B90AC: 4A6866FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B90B4: BF870001
	v_dual_fmac_f32 v60, v53, v50 :: v_dual_mov_b32 v51, v52   // 0000000B90B8: C8106535 3C320134
	ds_store_b32 v54, v60                                      // 0000000B90C0: D8340000 00003C36
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000B90C8: 917E047E
	s_cbranch_execnz 65452                                     // 0000000B90CC: BFA6FFAC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000B90D0: 8C7E047E
	.long 0xd7000107                                           // 0000000B90D4: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 0000000B90D8: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B90E0: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 0000000B90E4: D5207C08 00061080
	.long 0xd7000109                                           // 0000000B90EC: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 0000000B90F0: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 0000000B90F8: D5207C0A 00061480
	.long 0xd700010d                                           // 0000000B9100: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 0000000B9104: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B910C: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 0000000B9110: D5207C0E 00061C80
	.long 0xd700010b                                           // 0000000B9118: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 0000000B911C: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 0000000B9124: D5207C0C 00061880
	.long 0xd700010f                                           // 0000000B912C: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000000B9130: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9138: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000000B913C: D5207C10 00062080
	.long 0xd7000111                                           // 0000000B9144: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000000B9148: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000000B9150: D5207C12 00062480
	.long 0xd7000113                                           // 0000000B9158: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000000B915C: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9164: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000000B9168: D5207C14 00062880
	.long 0xd7000115                                           // 0000000B9170: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000000B9174: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000000B917C: D5207C16 00062C80
	.long 0xd7000117                                           // 0000000B9184: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 0000000B9188: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000B9190: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 0000000B9194: D5207C18 00063080
	.long 0xd7000119                                           // 0000000B919C: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 0000000B91A0: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 0000000B91A8: D5207C1A 00063480
	.long 0xd700011b                                           // 0000000B91B0: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 0000000B91B4: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000B91BC: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 0000000B91C0: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 0000000B91C8: 81058105
	s_waitcnt lgkmcnt(0)                                       // 0000000B91CC: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 0000000B91D0: BF062105
	s_barrier                                                  // 0000000B91D4: BFBD0000
	buffer_gl0_inv                                             // 0000000B91D8: E0AC0000 00000000
	s_cbranch_scc0 63457                                       // 0000000B91E0: BFA1F7E1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x368>
	v_mov_b32_e32 v4, v36                                      // 0000000B91E4: 7E080324
	s_add_u32 s0, s28, s20                                     // 0000000B91E8: 8000141C
	.long 0xd73c0000                                           // 0000000B91EC: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 0000000B91F0: 02020489
	s_addc_u32 s1, s29, s21                                    // 0000000B91F4: 8201151D
	s_add_u32 s2, s24, s18                                     // 0000000B91F8: 80021218
	s_addc_u32 s3, s25, s19                                    // 0000000B91FC: 82031319
	s_add_u32 s0, s2, s0                                       // 0000000B9200: 80000002
	s_addc_u32 s1, s3, s1                                      // 0000000B9204: 82010103
	.long 0xd7006a00                                           // 0000000B9208: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 0000000B920C: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000000B9210: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000000B9214: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000000B921C: BE810080
	.long 0xd7006a00                                           // 0000000B9220: D7006A00
	v_cndmask_b32_e32 v1, v0, v37, vcc_lo                      // 0000000B9224: 02024B00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000000B9228: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000B9230: BF870092
	.long 0xd7006a00                                           // 0000000B9234: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000000B9238: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000000B923C: D5207C01 01AA0211
	s_nop 0                                                    // 0000000B9244: BF800000
	s_nop 0                                                    // 0000000B9248: BF800000
	s_nop 0                                                    // 0000000B924C: BF800000
	s_nop 0                                                    // 0000000B9250: BF800000
	s_nop 0                                                    // 0000000B9254: BF800000
	s_nop 0                                                    // 0000000B9258: BF800000
	s_nop 0                                                    // 0000000B925C: BF800000
	s_nop 0                                                    // 0000000B9260: BF800000
	s_nop 0                                                    // 0000000B9264: BF800000
	s_nop 0                                                    // 0000000B9268: BF800000
	s_nop 0                                                    // 0000000B926C: BF800000
	s_nop 0                                                    // 0000000B9270: BF800000
	s_nop 0                                                    // 0000000B9274: BF800000
	s_nop 0                                                    // 0000000B9278: BF800000
	s_nop 0                                                    // 0000000B927C: BF800000
	ds_load_b32 v2, v35                                        // 0000000B9280: D8D80000 02000023
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000000B9288: 4A0808FF 00000080
	v_add_nc_u32_e32 v35, 0x220, v35                           // 0000000B9290: 4A4646FF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000000B9298: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000000B929C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000000B92A4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000000B92A8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000000B92AC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000000B92B4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000000B92B8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000000B92C0: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000000B92C8: 917E017E
	s_cbranch_execnz 65516                                     // 0000000B92CC: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi12ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2480>
	s_endpgm                                                   // 0000000B92D0: BFB00000
		...

