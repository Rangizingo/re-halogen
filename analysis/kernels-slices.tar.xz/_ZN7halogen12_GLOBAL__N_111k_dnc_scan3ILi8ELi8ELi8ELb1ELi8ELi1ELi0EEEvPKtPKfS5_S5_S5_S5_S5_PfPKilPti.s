0000000000090700 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000090700: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 000000090704: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000009070C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 000000090714: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 000000090718: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000009071C: 861B9F1A
	v_dual_mov_b32 v5, v0 :: v_dual_and_b32 v4, 15, v0         // 000000090720: CA240100 0504008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000090728: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v4                                // 00000009072C: 30020882
	s_waitcnt lgkmcnt(0)                                       // 000000090730: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 000000090734: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000009073C: 84928214
	s_add_u32 s25, s16, s18                                    // 000000090740: 80191210
	s_addc_u32 s28, s17, s19                                   // 000000090744: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 000000090748: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000009074C: BF870009
	s_add_u32 s25, s25, s20                                    // 000000090750: 80191419
	s_addc_u32 s30, s28, s21                                   // 000000090754: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 000000090758: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000009075C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 000000090764: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000009076C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 000000090770: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 000000090774: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000090778: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000009077C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 000000090780: 821E191E
	.long 0xd7001f02                                           // 000000090784: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 000000090788: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000009078C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 000000090794: BE9E0080
	s_nop 0                                                    // 000000090798: BF800000
	s_nop 0                                                    // 00000009079C: BF800000
	s_nop 0                                                    // 0000000907A0: BF800000
	s_nop 0                                                    // 0000000907A4: BF800000
	s_nop 0                                                    // 0000000907A8: BF800000
	s_nop 0                                                    // 0000000907AC: BF800000
	s_nop 0                                                    // 0000000907B0: BF800000
	s_nop 0                                                    // 0000000907B4: BF800000
	s_nop 0                                                    // 0000000907B8: BF800000
	s_nop 0                                                    // 0000000907BC: BF800000
	v_lshrrev_b32_e32 v8, 4, v5                                // 0000000907C0: 32100A84
	v_add_nc_u32_e32 v10, 0x80, v5                             // 0000000907C4: 4A140AFF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000907CC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 0000000907D0: 300C1089
	.long 0xd7006a06                                           // 0000000907D4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 0000000907D8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000907DC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 0000000907E0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v5                         // 0000000907E8: 7C920AFF 0000077F
	v_mov_b32_e32 v5, v10                                      // 0000000907F0: 7E0A030A
	global_load_b32 v9, v[6:7], off                            // 0000000907F4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 0000000907FC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 000000090808: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000009080C: BF8903F7
	ds_store_b32 v6, v9                                        // 000000090810: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 000000090818: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000009081C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 000000090820: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 000000090824: F4000780 F8000058
	v_or_b32_e32 v51, 0xffffff80, v0                           // 00000009082C: 386600FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 000000090834: 32040084
	s_mov_b32 s0, 0                                            // 000000090838: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000009083C: BF89FC07
	s_barrier                                                  // 000000090840: BFBD0000
	buffer_gl0_inv                                             // 000000090844: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000009084C: BF02801E
	s_cbranch_scc1 12                                          // 000000090850: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 000000090854: 160604FF 00000044
	v_or_b32_e32 v5, 0xffffff80, v0                            // 00000009085C: 380A00FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000090864: BF870002
	v_lshl_add_u32 v50, v4, 2, v3                              // 000000090868: D6460032 040D0504
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v52, 2, v4      // 000000090870: CA220080 03340882
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000090878: 916A007E
	s_cbranch_vccz 2                                           // 00000009087C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 3502                                              // 000000090880: BFA00DAE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x383c>
	v_lshlrev_b32_e32 v52, 2, v4                               // 000000090884: 30680882
	s_add_i32 s0, s30, 63                                      // 000000090888: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000009088C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 000000090894: 85218600
	s_add_u32 s34, s10, s24                                    // 000000090898: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000009089C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 0000000908A0: 84008702
	v_lshlrev_b32_e32 v53, 2, v0                               // 0000000908A4: 306A0082
	s_ashr_i32 s1, s0, 31                                      // 0000000908A8: 86019F00
	v_lshlrev_b32_e32 v4, 1, v4                                // 0000000908AC: 30080881
	s_lshl_b64 s[0:1], s[0:1], 1                               // 0000000908B0: 84808100
	v_lshlrev_b32_e32 v24, 8, v2                               // 0000000908B4: 30300488
	s_add_u32 s22, s22, s0                                     // 0000000908B8: 80160016
	s_addc_u32 s1, s23, s1                                     // 0000000908BC: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 0000000908C0: 848A811A
	v_mad_u32_u24 v50, 0x44, v2, v52                           // 0000000908C4: D60B0032 04D204FF 00000044
	s_add_u32 s22, s22, s10                                    // 0000000908D0: 80160A16
	s_addc_u32 s1, s1, s11                                     // 0000000908D4: 82010B01
	s_movk_i32 s10, 0x204                                      // 0000000908D8: B00A0204
	.long 0xd7000b39                                           // 0000000908DC: D7000B39
	v_cndmask_b32_e32 v1, s34, v52, vcc_lo                     // 0000000908E0: 02026822
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000000908E4: BF8704B1
	v_add_co_ci_u32_e64 v58, null, s35, 0, s11                 // 0000000908E8: D5207C3A 002D0023
	v_mad_u32_u24 v59, v2, s10, 0x3300                         // 0000000908F0: D60B003B 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 0000000908FC: 848A8902
	v_dual_mov_b32 v27, s11 :: v_dual_add_nc_u32 v56, 1, v2    // 000000090900: CA20000B 1B380481
	v_or_b32_e32 v26, s10, v53                                 // 000000090908: 38346A0A
	.long 0xd7000a04                                           // 00000009090C: D7000A04
	v_cndmask_b32_e32 v1, s22, v4, vcc_lo                      // 000000090910: 02020816
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000090914: BF870191
	v_add_co_ci_u32_e64 v5, null, s1, 0, s10                   // 000000090918: D5207C05 00290001
	.long 0xd700011c                                           // 000000090920: D700011C
	v_cndmask_b32_e32 v1, 0x30000, v26, vcc_lo                 // 000000090924: 020234FF 00030000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000009092C: BF8700A1
	v_add_co_ci_u32_e64 v29, null, 0, v27, s1                  // 000000090930: D5207C1D 00063680
	.long 0xd7000106                                           // 000000090938: D7000106
	v_cndmask_b32_e32 v1, s12, v26, vcc_lo                     // 00000009093C: 0202340C
	v_add_co_ci_u32_e64 v7, null, s13, v27, s1                 // 000000090940: D5207C07 0006360D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000090948: BF870094
	.long 0xd7000108                                           // 00000009094C: D7000108
	v_cndmask_b32_e32 v1, s12, v28, vcc_lo                     // 000000090950: 0202380C
	v_add_co_ci_u32_e64 v9, null, s13, v29, s1                 // 000000090954: D5207C09 00063A0D
	.long 0xd700011e                                           // 00000009095C: D700011E
	v_cndmask_b32_e32 v1, 0x60000, v26, vcc_lo                 // 000000090960: 020234FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000090968: BF8700A1
	v_add_co_ci_u32_e64 v31, null, 0, v27, s1                  // 00000009096C: D5207C1F 00063680
	.long 0xd7000120                                           // 000000090974: D7000120
	v_cndmask_b32_e32 v1, 0x90000, v26, vcc_lo                 // 000000090978: 020234FF 00090000
	v_add_co_ci_u32_e64 v33, null, 0, v27, s1                  // 000000090980: D5207C21 00063680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000090988: BF870094
	.long 0xd700010a                                           // 00000009098C: D700010A
	v_cndmask_b32_e32 v1, s12, v30, vcc_lo                     // 000000090990: 02023C0C
	v_add_co_ci_u32_e64 v11, null, s13, v31, s1                // 000000090994: D5207C0B 00063E0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009099C: BF870094
	.long 0xd700010c                                           // 0000000909A0: D700010C
	v_cndmask_b32_e32 v1, s12, v32, vcc_lo                     // 0000000909A4: 0202400C
	v_add_co_ci_u32_e64 v13, null, s13, v33, s1                // 0000000909A8: D5207C0D 0006420D
	.long 0xd7000122                                           // 0000000909B0: D7000122
	v_cndmask_b32_e32 v1, 0xc0000, v26, vcc_lo                 // 0000000909B4: 020234FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000909BC: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v27, s1                  // 0000000909C0: D5207C23 00063680
	.long 0xd7000124                                           // 0000000909C8: D7000124
	v_cndmask_b32_e32 v1, 0xf0000, v26, vcc_lo                 // 0000000909CC: 020234FF 000F0000
	v_add_co_ci_u32_e64 v37, null, 0, v27, s1                  // 0000000909D4: D5207C25 00063680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000909DC: BF870094
	.long 0xd700010e                                           // 0000000909E0: D700010E
	v_cndmask_b32_e32 v1, s12, v34, vcc_lo                     // 0000000909E4: 0202440C
	v_add_co_ci_u32_e64 v15, null, s13, v35, s1                // 0000000909E8: D5207C0F 0006460D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000909F0: BF870094
	.long 0xd7000110                                           // 0000000909F4: D7000110
	v_cndmask_b32_e32 v1, s12, v36, vcc_lo                     // 0000000909F8: 0202480C
	v_add_co_ci_u32_e64 v17, null, s13, v37, s1                // 0000000909FC: D5207C11 00064A0D
	.long 0xd7000126                                           // 000000090A04: D7000126
	v_cndmask_b32_e32 v1, 0x120000, v26, vcc_lo                // 000000090A08: 020234FF 00120000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000090A10: BF8700A1
	v_add_co_ci_u32_e64 v39, null, 0, v27, s1                  // 000000090A14: D5207C27 00063680
	.long 0xd7000128                                           // 000000090A1C: D7000128
	v_cndmask_b32_e32 v1, 0x150000, v26, vcc_lo                // 000000090A20: 020234FF 00150000
	v_add_co_ci_u32_e64 v41, null, 0, v27, s1                  // 000000090A28: D5207C29 00063680
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000090A30: BF870094
	.long 0xd7000112                                           // 000000090A34: D7000112
	v_cndmask_b32_e32 v1, s12, v38, vcc_lo                     // 000000090A38: 02024C0C
	v_add_co_ci_u32_e64 v19, null, s13, v39, s1                // 000000090A3C: D5207C13 00064E0D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000090A44: BF870094
	.long 0xd7000114                                           // 000000090A48: D7000114
	v_cndmask_b32_e32 v1, s12, v40, vcc_lo                     // 000000090A4C: 0202500C
	v_add_co_ci_u32_e64 v21, null, s13, v41, s1                // 000000090A50: D5207C15 0006520D
	s_lshl_b64 s[10:11], s[2:3], 14                            // 000000090A58: 848A8E02
	.long 0xd7000116                                           // 000000090A5C: D7000116
	v_cndmask_b32_e32 v1, s4, v26, vcc_lo                      // 000000090A60: 02023404
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000090A64: BF8700C1
	v_add_co_ci_u32_e64 v23, null, s5, v27, s1                 // 000000090A68: D5207C17 00063605
	s_add_u32 s1, s14, s10                                     // 000000090A70: 80010A0E
	s_addc_u32 s4, s15, s11                                    // 000000090A74: 82040B0F
	.long 0xd7000118                                           // 000000090A78: D7000118
	v_cndmask_b32_e32 v1, s1, v24, vcc_lo                      // 000000090A7C: 02023001
	v_add_co_ci_u32_e64 v25, null, s4, 0, s1                   // 000000090A80: D5207C19 00050004
	.long 0xd700011a                                           // 000000090A88: D700011A
	v_cndmask_b32_e32 v1, s6, v26, vcc_lo                      // 000000090A8C: 02023406
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000090A90: BF8700A1
	v_add_co_ci_u32_e64 v27, null, s7, v27, s1                 // 000000090A94: D5207C1B 00063607
	.long 0xd700011c                                           // 000000090A9C: D700011C
	v_cndmask_b32_e32 v1, s6, v28, vcc_lo                      // 000000090AA0: 02023806
	v_add_co_ci_u32_e64 v29, null, s7, v29, s1                 // 000000090AA4: D5207C1D 00063A07
	.long 0xd700011e                                           // 000000090AAC: D700011E
	v_cndmask_b32_e32 v1, s6, v30, vcc_lo                      // 000000090AB0: 02023C06
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000090AB4: BF8700A1
	v_add_co_ci_u32_e64 v31, null, s7, v31, s1                 // 000000090AB8: D5207C1F 00063E07
	.long 0xd7000120                                           // 000000090AC0: D7000120
	v_cndmask_b32_e32 v1, s6, v32, vcc_lo                      // 000000090AC4: 02024006
	v_add_co_ci_u32_e64 v33, null, s7, v33, s1                 // 000000090AC8: D5207C21 00064207
	.long 0xd7000122                                           // 000000090AD0: D7000122
	v_cndmask_b32_e32 v1, s6, v34, vcc_lo                      // 000000090AD4: 02024406
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000090AD8: BF8700A1
	v_add_co_ci_u32_e64 v35, null, s7, v35, s1                 // 000000090ADC: D5207C23 00064607
	.long 0xd7000124                                           // 000000090AE4: D7000124
	v_cndmask_b32_e32 v1, s6, v36, vcc_lo                      // 000000090AE8: 02024806
	v_add_co_ci_u32_e64 v37, null, s7, v37, s1                 // 000000090AEC: D5207C25 00064A07
	.long 0xd7000126                                           // 000000090AF4: D7000126
	v_cndmask_b32_e32 v1, s6, v38, vcc_lo                      // 000000090AF8: 02024C06
	s_delay_alu instid0(VALU_DEP_1)                            // 000000090AFC: BF870001
	v_add_co_ci_u32_e64 v39, null, s7, v39, s1                 // 000000090B00: D5207C27 00064E07
	.long 0xd7000128                                           // 000000090B08: D7000128
	v_cndmask_b32_e32 v1, s6, v40, vcc_lo                      // 000000090B0C: 02025006
	v_dual_mov_b32 v3, 0 :: v_dual_add_nc_u32 v54, 0x4320, v53 // 000000090B10: CA200080 03366AFF 00004320
	v_add_nc_u32_e32 v55, 0x4420, v53                          // 000000090B1C: 4A6E6AFF 00004420
	.long 0xd44c0000                                           // 000000090B24: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000090B28: 020200FF 00000080
	v_add_nc_u32_e32 v60, 0x2200, v50                          // 000000090B30: 4A7864FF 00002200
	v_or_b32_e32 v61, 0x2200, v1                               // 000000090B38: 387A02FF 00002200
	v_add_co_ci_u32_e64 v41, null, s7, v41, s1                 // 000000090B40: D5207C29 00065207
	s_mov_b32 s5, 0                                            // 000000090B48: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 000000090B4C: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 000000090B50: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000090B58: BF870499
	s_add_i32 s6, s31, s1                                      // 000000090B5C: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 000000090B60: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000090B64: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 000000090B68: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 000000090B6C: 84078605
	s_add_u32 s10, s8, s10                                     // 000000090B70: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 000000090B74: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 000000090B78: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 000000090B80: BE84206A
	s_cbranch_execz 77                                         // 000000090B84: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5bc>
	v_or_b32_e32 v42, s7, v0                                   // 000000090B88: 38540007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000090B8C: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 000000090B90: D6FE7C2A 0009612A
	v_ashrrev_i32_e32 v43, 31, v42                             // 000000090B98: 3456549F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000090B9C: BF870091
	.long 0xd73c002a                                           // 000000090BA0: D73C002A
	v_cndmask_b32_e32 v1, 2, v42, vcc_lo                       // 000000090BA4: 02025482
	.long 0xd700012a                                           // 000000090BA8: D700012A
	v_cndmask_b32_e32 v1, s8, v42, vcc_lo                      // 000000090BAC: 02025408
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000090BB0: BF8700C1
	v_add_co_ci_u32_e64 v43, null, s9, v43, s1                 // 000000090BB4: D5207C2B 00065609
	global_load_b32 v42, v[42:43], off                         // 000000090BBC: DC520000 2A7C002A
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000090BC4: BF890007
	v_sub_f32_e32 v43, s6, v42                                 // 000000090BC8: 08565406
	v_dual_mul_f32 v45, 0x3fb8aa3b, v42 :: v_dual_mul_f32 v44, 0x3fb8aa3b, v43// 000000090BCC: C8C654FF 2D2C56FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000090BD8: BF8701A1
	v_fma_f32 v48, 0x3fb8aa3b, v42, -v45                       // 000000090BDC: D6130030 84B654FF 3FB8AA3B
	v_rndne_f32_e32 v49, v45                                   // 000000090BE8: 7E62472D
	v_fma_f32 v46, 0x3fb8aa3b, v43, -v44                       // 000000090BEC: D613002E 84B256FF 3FB8AA3B
	v_rndne_f32_e32 v47, v44                                   // 000000090BF8: 7E5E472C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000090BFC: BF870113
	v_dual_fmac_f32 v48, 0x32a5705f, v42 :: v_dual_sub_f32 v45, v45, v49// 000000090C00: C80A54FF 302C632D 32A5705F
	v_sub_f32_e32 v44, v44, v47                                // 000000090C0C: 08585F2C
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000090C10: BF870124
	v_fmac_f32_e32 v46, 0x32a5705f, v43                        // 000000090C14: 565C56FF 32A5705F
	.long 0xd41b0001                                           // 000000090C1C: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v43, vcc_lo              // 000000090C20: 020256FF C2CE8ED0
	v_dual_add_f32 v45, v45, v48 :: v_dual_add_f32 v44, v44, v46// 000000090C28: C908612D 2D2C5D2C
	v_cvt_i32_f32_e32 v46, v47                                 // 000000090C30: 7E5C112F
	v_cvt_i32_f32_e32 v47, v49                                 // 000000090C34: 7E5E1131
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000090C38: BF870193
	v_exp_f32_e32 v45, v45                                     // 000000090C3C: 7E5A4B2D
	v_exp_f32_e32 v44, v44                                     // 000000090C40: 7E584B2C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000090C44: BF870296
	.long 0xd71c002d                                           // 000000090C48: D71C002D
	v_cndmask_b32_e32 v1, v45, v47, vcc_lo                     // 000000090C4C: 02025F2D
	.long 0xd71c002c                                           // 000000090C50: D71C002C
	v_cndmask_b32_e32 v1, v44, v46, vcc_lo                     // 000000090C54: 02025D2C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000090C58: BF8700A1
	v_cndmask_b32_e64 v44, 0, v44, s1                          // 000000090C5C: D501002C 00065880
	.long 0xd41b0001                                           // 000000090C64: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v42, vcc_lo              // 000000090C68: 020254FF C2CE8ED0
	v_cndmask_b32_e64 v45, 0, v45, s1                          // 000000090C70: D501002D 00065A80
	.long 0xd41e0001                                           // 000000090C78: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v43, vcc_lo              // 000000090C7C: 020256FF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000090C84: BF8700A1
	v_cndmask_b32_e64 v43, 0x7f800000, v44, s1                 // 000000090C88: D501002B 000658FF 7F800000
	.long 0xd41e0001                                           // 000000090C94: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v42, vcc_lo              // 000000090C98: 020254FF 42B17218
	v_cndmask_b32_e64 v42, 0x7f800000, v45, s1                 // 000000090CA0: D501002A 00065AFF 7F800000
	ds_store_b32 v54, v43                                      // 000000090CAC: D8340000 00002B36
	ds_store_b32 v55, v42                                      // 000000090CB4: D8340000 00002A37
	s_or_b32 exec_lo, exec_lo, s4                              // 000000090CBC: 8C7E047E
	v_dual_mov_b32 v43, v7 :: v_dual_mov_b32 v42, v6           // 000000090CC0: CA100107 2B2A0106
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 000000090CC8: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 000000090CD0: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000090CD4: BF89FC07
	s_barrier                                                  // 000000090CD8: BFBD0000
	buffer_gl0_inv                                             // 000000090CDC: E0AC0000 00000000
	s_nop 0                                                    // 000000090CE4: BF800000
	s_nop 0                                                    // 000000090CE8: BF800000
	s_nop 0                                                    // 000000090CEC: BF800000
	s_nop 0                                                    // 000000090CF0: BF800000
	s_nop 0                                                    // 000000090CF4: BF800000
	s_nop 0                                                    // 000000090CF8: BF800000
	s_nop 0                                                    // 000000090CFC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000090D00: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000090D08: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000090D10: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000090D14: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000090D1C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000090D20: D5207C2B 00065680
	.long 0xd4490004                                           // 000000090D28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 000000090D2C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000090D34: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000090D38: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 000000090D3C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000090D44: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000090D4C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000090D50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x600>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000090D54: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000090D58: BF89FC07
	s_barrier                                                  // 000000090D5C: BFBD0000
	buffer_gl0_inv                                             // 000000090D60: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000090D68: BE842000
	s_cbranch_execz 140                                        // 000000090D6C: BFA5008C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x8a0>
	v_or_b32_e32 v42, s7, v2                                   // 000000090D70: 38540407
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000090D74: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 000000090D78: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000090D80: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000090D84: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000090D88: BF870091
	.long 0xd700012a                                           // 000000090D8C: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 000000090D90: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 000000090D94: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 000000090D9C: BE810080
	global_load_b32 v42, v[42:43], off                         // 000000090DA0: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 000000090DA8: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 000000090DB4: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 000000090DBC: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 000000090DC0: B6810070
	s_mov_b32 s1, s10                                          // 000000090DC4: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 000000090DC8: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 000000090DD0: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 000000090DD8: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 000000090DE0: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 000000090DE8: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 000000090DF0: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 000000090DF8: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000090DFC: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000090E00: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000090E04: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000090E0C: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000090E10: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000090E14: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 000000090E18: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000090E20: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000090E24: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 000000090E28: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000090E2C: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000090E34: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 000000090E38: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000090E3C: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000090E40: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000090E44: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000090E4C: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000090E50: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000090E54: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000090E5C: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000090E64: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 000000090E68: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000090E6C: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000090E70: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000090E74: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 000000090E78: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 000000090E80: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 000000090E88: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000090E90: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 000000090E94: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 000000090E98: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 000000090EA0: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 000000090EA8: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 000000090EAC: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 000000090EB4: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 000000090EBC: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 000000090EC4: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 000000090ECC: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 000000090ED4: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 000000090ED8: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 000000090EDC: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000090EE0: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000090EE4: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 000000090EEC: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 000000090EF0: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 000000090EF4: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000090EF8: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000090F00: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000090F04: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000090F08: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000090F0C: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000090F14: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 000000090F18: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000090F1C: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000090F20: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 000000090F28: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000090F2C: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000090F30: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000090F34: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000090F3C: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000090F40: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000090F44: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000090F48: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000090F50: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000090F54: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000090F58: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000090F5C: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000090F64: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 000000090F68: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000090F6C: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000090F70: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 000000090F78: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000090F7C: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000090F80: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000090F84: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000090F8C: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000090F94: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x6a8>
	ds_store_b32 v60, v42                                      // 000000090F98: D8340000 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 000000090FA0: 8C7E047E
	v_dual_mov_b32 v43, v9 :: v_dual_mov_b32 v42, v8           // 000000090FA4: CA100109 2B2A0108
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 000000090FAC: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 000000090FB4: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000090FB8: BF89FC07
	s_barrier                                                  // 000000090FBC: BFBD0000
	buffer_gl0_inv                                             // 000000090FC0: E0AC0000 00000000
	s_nop 0                                                    // 000000090FC8: BF800000
	s_nop 0                                                    // 000000090FCC: BF800000
	s_nop 0                                                    // 000000090FD0: BF800000
	s_nop 0                                                    // 000000090FD4: BF800000
	s_nop 0                                                    // 000000090FD8: BF800000
	s_nop 0                                                    // 000000090FDC: BF800000
	s_nop 0                                                    // 000000090FE0: BF800000
	s_nop 0                                                    // 000000090FE4: BF800000
	s_nop 0                                                    // 000000090FE8: BF800000
	s_nop 0                                                    // 000000090FEC: BF800000
	s_nop 0                                                    // 000000090FF0: BF800000
	s_nop 0                                                    // 000000090FF4: BF800000
	s_nop 0                                                    // 000000090FF8: BF800000
	s_nop 0                                                    // 000000090FFC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000091000: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000091008: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000091010: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000091014: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000009101C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000091020: D5207C2B 00065680
	.long 0xd4490004                                           // 000000091028: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000009102C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000091034: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000091038: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000009103C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000091044: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000009104C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000091050: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x900>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000091054: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000091058: BF89FC07
	s_barrier                                                  // 00000009105C: BFBD0000
	buffer_gl0_inv                                             // 000000091060: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000091068: BE842000
	s_cbranch_execz 141                                        // 00000009106C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xba4>
	v_add3_u32 v42, v2, s7, 8                                  // 000000091070: D655002A 02200F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000091078: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000009107C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000091084: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000091088: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009108C: BF870091
	.long 0xd700012a                                           // 000000091090: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 000000091094: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 000000091098: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 0000000910A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 0000000910A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 0000000910AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 0000000910B8: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 0000000910C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 0000000910C4: B6810070
	s_mov_b32 s1, s10                                          // 0000000910C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 0000000910CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 0000000910D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 0000000910DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 0000000910E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 0000000910EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 0000000910F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 0000000910FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000091100: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000091104: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000091108: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000091110: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000091114: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000091118: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000009111C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000091124: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000091128: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000009112C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000091130: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000091138: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000009113C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000091140: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000091144: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000091148: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000091150: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000091154: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000091158: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000091160: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000091168: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000009116C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000091170: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000091174: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000091178: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000009117C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 000000091184: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000009118C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000091194: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 000000091198: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000009119C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 0000000911A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 0000000911AC: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 0000000911B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 0000000911B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 0000000911C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 0000000911C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 0000000911D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 0000000911D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 0000000911DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 0000000911E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000911E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 0000000911E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 0000000911F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 0000000911F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 0000000911F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 0000000911FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000091204: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000091208: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000009120C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091210: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000091218: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000009121C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000091220: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091224: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000009122C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000091230: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000091234: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091238: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000091240: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000091244: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000091248: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000009124C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000091254: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000091258: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000009125C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091260: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000091268: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000009126C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000091270: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091274: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000009127C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000091280: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000091284: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091288: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091290: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000091298: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x9ac>
	ds_store_b32 v60, v42 offset:544                           // 00000009129C: D8340220 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000912A4: 8C7E047E
	v_dual_mov_b32 v43, v11 :: v_dual_mov_b32 v42, v10         // 0000000912A8: CA10010B 2B2A010A
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 0000000912B0: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 0000000912B8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000912BC: BF89FC07
	s_barrier                                                  // 0000000912C0: BFBD0000
	buffer_gl0_inv                                             // 0000000912C4: E0AC0000 00000000
	s_nop 0                                                    // 0000000912CC: BF800000
	s_nop 0                                                    // 0000000912D0: BF800000
	s_nop 0                                                    // 0000000912D4: BF800000
	s_nop 0                                                    // 0000000912D8: BF800000
	s_nop 0                                                    // 0000000912DC: BF800000
	s_nop 0                                                    // 0000000912E0: BF800000
	s_nop 0                                                    // 0000000912E4: BF800000
	s_nop 0                                                    // 0000000912E8: BF800000
	s_nop 0                                                    // 0000000912EC: BF800000
	s_nop 0                                                    // 0000000912F0: BF800000
	s_nop 0                                                    // 0000000912F4: BF800000
	s_nop 0                                                    // 0000000912F8: BF800000
	s_nop 0                                                    // 0000000912FC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000091300: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000091308: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000091310: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000091314: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000009131C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000091320: D5207C2B 00065680
	.long 0xd4490004                                           // 000000091328: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000009132C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000091334: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000091338: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000009133C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000091344: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000009134C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000091350: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc00>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000091354: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000091358: BF89FC07
	s_barrier                                                  // 00000009135C: BFBD0000
	buffer_gl0_inv                                             // 000000091360: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000091368: BE842000
	s_cbranch_execz 141                                        // 00000009136C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xea4>
	v_add3_u32 v42, v2, s7, 16                                 // 000000091370: D655002A 02400F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000091378: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000009137C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000091384: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000091388: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009138C: BF870091
	.long 0xd700012a                                           // 000000091390: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 000000091394: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 000000091398: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 0000000913A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 0000000913A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 0000000913AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 0000000913B8: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 0000000913C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 0000000913C4: B6810070
	s_mov_b32 s1, s10                                          // 0000000913C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 0000000913CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 0000000913D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 0000000913DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 0000000913E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 0000000913EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 0000000913F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 0000000913FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000091400: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000091404: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000091408: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000091410: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000091414: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000091418: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000009141C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000091424: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000091428: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000009142C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000091430: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000091438: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000009143C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000091440: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000091444: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000091448: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000091450: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000091454: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000091458: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000091460: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000091468: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000009146C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000091470: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000091474: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000091478: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000009147C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 000000091484: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000009148C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000091494: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 000000091498: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000009149C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 0000000914A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 0000000914AC: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 0000000914B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 0000000914B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 0000000914C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 0000000914C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 0000000914D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 0000000914D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 0000000914DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 0000000914E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000914E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 0000000914E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 0000000914F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 0000000914F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 0000000914F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 0000000914FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000091504: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000091508: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000009150C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091510: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000091518: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000009151C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000091520: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091524: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000009152C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000091530: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000091534: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091538: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000091540: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000091544: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000091548: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000009154C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000091554: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000091558: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000009155C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091560: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000091568: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000009156C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000091570: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091574: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000009157C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000091580: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000091584: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091588: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091590: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000091598: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xcac>
	ds_store_b32 v60, v42 offset:1088                          // 00000009159C: D8340440 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000915A4: 8C7E047E
	v_dual_mov_b32 v43, v13 :: v_dual_mov_b32 v42, v12         // 0000000915A8: CA10010D 2B2A010C
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 0000000915B0: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 0000000915B8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000915BC: BF89FC07
	s_barrier                                                  // 0000000915C0: BFBD0000
	buffer_gl0_inv                                             // 0000000915C4: E0AC0000 00000000
	s_nop 0                                                    // 0000000915CC: BF800000
	s_nop 0                                                    // 0000000915D0: BF800000
	s_nop 0                                                    // 0000000915D4: BF800000
	s_nop 0                                                    // 0000000915D8: BF800000
	s_nop 0                                                    // 0000000915DC: BF800000
	s_nop 0                                                    // 0000000915E0: BF800000
	s_nop 0                                                    // 0000000915E4: BF800000
	s_nop 0                                                    // 0000000915E8: BF800000
	s_nop 0                                                    // 0000000915EC: BF800000
	s_nop 0                                                    // 0000000915F0: BF800000
	s_nop 0                                                    // 0000000915F4: BF800000
	s_nop 0                                                    // 0000000915F8: BF800000
	s_nop 0                                                    // 0000000915FC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000091600: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000091608: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000091610: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000091614: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000009161C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000091620: D5207C2B 00065680
	.long 0xd4490004                                           // 000000091628: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000009162C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000091634: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000091638: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000009163C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000091644: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000009164C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000091650: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xf00>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000091654: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000091658: BF89FC07
	s_barrier                                                  // 00000009165C: BFBD0000
	buffer_gl0_inv                                             // 000000091660: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000091668: BE842000
	s_cbranch_execz 141                                        // 00000009166C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x11a4>
	v_add3_u32 v42, v2, s7, 24                                 // 000000091670: D655002A 02600F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000091678: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000009167C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000091684: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000091688: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009168C: BF870091
	.long 0xd700012a                                           // 000000091690: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 000000091694: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 000000091698: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 0000000916A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 0000000916A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 0000000916AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 0000000916B8: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 0000000916C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 0000000916C4: B6810070
	s_mov_b32 s1, s10                                          // 0000000916C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 0000000916CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 0000000916D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 0000000916DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 0000000916E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 0000000916EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 0000000916F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 0000000916FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000091700: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000091704: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000091708: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000091710: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000091714: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000091718: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000009171C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000091724: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000091728: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000009172C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000091730: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000091738: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000009173C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000091740: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000091744: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000091748: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000091750: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000091754: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000091758: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000091760: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000091768: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000009176C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000091770: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000091774: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000091778: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000009177C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 000000091784: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000009178C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000091794: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 000000091798: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000009179C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 0000000917A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 0000000917AC: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 0000000917B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 0000000917B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 0000000917C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 0000000917C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 0000000917D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 0000000917D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 0000000917DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 0000000917E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000917E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 0000000917E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 0000000917F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 0000000917F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 0000000917F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 0000000917FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000091804: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000091808: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000009180C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091810: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000091818: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000009181C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000091820: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091824: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000009182C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000091830: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000091834: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091838: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000091840: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000091844: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000091848: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000009184C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000091854: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000091858: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000009185C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091860: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000091868: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000009186C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000091870: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091874: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000009187C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000091880: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000091884: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091888: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091890: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000091898: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xfac>
	ds_store_b32 v60, v42 offset:1632                          // 00000009189C: D8340660 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000918A4: 8C7E047E
	v_dual_mov_b32 v43, v15 :: v_dual_mov_b32 v42, v14         // 0000000918A8: CA10010F 2B2A010E
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 0000000918B0: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 0000000918B8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000918BC: BF89FC07
	s_barrier                                                  // 0000000918C0: BFBD0000
	buffer_gl0_inv                                             // 0000000918C4: E0AC0000 00000000
	s_nop 0                                                    // 0000000918CC: BF800000
	s_nop 0                                                    // 0000000918D0: BF800000
	s_nop 0                                                    // 0000000918D4: BF800000
	s_nop 0                                                    // 0000000918D8: BF800000
	s_nop 0                                                    // 0000000918DC: BF800000
	s_nop 0                                                    // 0000000918E0: BF800000
	s_nop 0                                                    // 0000000918E4: BF800000
	s_nop 0                                                    // 0000000918E8: BF800000
	s_nop 0                                                    // 0000000918EC: BF800000
	s_nop 0                                                    // 0000000918F0: BF800000
	s_nop 0                                                    // 0000000918F4: BF800000
	s_nop 0                                                    // 0000000918F8: BF800000
	s_nop 0                                                    // 0000000918FC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000091900: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000091908: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000091910: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000091914: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000009191C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000091920: D5207C2B 00065680
	.long 0xd4490004                                           // 000000091928: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000009192C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000091934: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000091938: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000009193C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000091944: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000009194C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000091950: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1200>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000091954: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000091958: BF89FC07
	s_barrier                                                  // 00000009195C: BFBD0000
	buffer_gl0_inv                                             // 000000091960: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000091968: BE842000
	s_cbranch_execz 141                                        // 00000009196C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x14a4>
	v_add3_u32 v42, v2, s7, 32                                 // 000000091970: D655002A 02800F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000091978: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000009197C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000091984: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000091988: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009198C: BF870091
	.long 0xd700012a                                           // 000000091990: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 000000091994: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 000000091998: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 0000000919A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 0000000919A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 0000000919AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 0000000919B8: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 0000000919C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 0000000919C4: B6810070
	s_mov_b32 s1, s10                                          // 0000000919C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 0000000919CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 0000000919D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 0000000919DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 0000000919E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 0000000919EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 0000000919F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 0000000919FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000091A00: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000091A04: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000091A08: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000091A10: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000091A14: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000091A18: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 000000091A1C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000091A24: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000091A28: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 000000091A2C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000091A30: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000091A38: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 000000091A3C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000091A40: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000091A44: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000091A48: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000091A50: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000091A54: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000091A58: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000091A60: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000091A68: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 000000091A6C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000091A70: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000091A74: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000091A78: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 000000091A7C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 000000091A84: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 000000091A8C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000091A94: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 000000091A98: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 000000091A9C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 000000091AA4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 000000091AAC: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 000000091AB0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 000000091AB8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 000000091AC0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 000000091AC8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 000000091AD0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 000000091AD8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 000000091ADC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 000000091AE0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000091AE4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091AE8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 000000091AF0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 000000091AF4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 000000091AF8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091AFC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000091B04: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000091B08: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000091B0C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091B10: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000091B18: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 000000091B1C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000091B20: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091B24: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 000000091B2C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000091B30: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000091B34: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091B38: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000091B40: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000091B44: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000091B48: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091B4C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000091B54: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000091B58: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000091B5C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091B60: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000091B68: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 000000091B6C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000091B70: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091B74: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 000000091B7C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000091B80: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000091B84: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091B88: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091B90: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000091B98: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x12ac>
	ds_store_b32 v60, v42 offset:2176                          // 000000091B9C: D8340880 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 000000091BA4: 8C7E047E
	v_dual_mov_b32 v43, v17 :: v_dual_mov_b32 v42, v16         // 000000091BA8: CA100111 2B2A0110
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 000000091BB0: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 000000091BB8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000091BBC: BF89FC07
	s_barrier                                                  // 000000091BC0: BFBD0000
	buffer_gl0_inv                                             // 000000091BC4: E0AC0000 00000000
	s_nop 0                                                    // 000000091BCC: BF800000
	s_nop 0                                                    // 000000091BD0: BF800000
	s_nop 0                                                    // 000000091BD4: BF800000
	s_nop 0                                                    // 000000091BD8: BF800000
	s_nop 0                                                    // 000000091BDC: BF800000
	s_nop 0                                                    // 000000091BE0: BF800000
	s_nop 0                                                    // 000000091BE4: BF800000
	s_nop 0                                                    // 000000091BE8: BF800000
	s_nop 0                                                    // 000000091BEC: BF800000
	s_nop 0                                                    // 000000091BF0: BF800000
	s_nop 0                                                    // 000000091BF4: BF800000
	s_nop 0                                                    // 000000091BF8: BF800000
	s_nop 0                                                    // 000000091BFC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000091C00: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000091C08: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000091C10: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000091C14: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000091C1C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000091C20: D5207C2B 00065680
	.long 0xd4490004                                           // 000000091C28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 000000091C2C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000091C34: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000091C38: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 000000091C3C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000091C44: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000091C4C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000091C50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1500>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000091C54: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000091C58: BF89FC07
	s_barrier                                                  // 000000091C5C: BFBD0000
	buffer_gl0_inv                                             // 000000091C60: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000091C68: BE842000
	s_cbranch_execz 141                                        // 000000091C6C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x17a4>
	v_add3_u32 v42, v2, s7, 40                                 // 000000091C70: D655002A 02A00F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000091C78: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 000000091C7C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000091C84: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000091C88: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000091C8C: BF870091
	.long 0xd700012a                                           // 000000091C90: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 000000091C94: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 000000091C98: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 000000091CA0: BE810080
	global_load_b32 v42, v[42:43], off                         // 000000091CA4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 000000091CAC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 000000091CB8: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 000000091CC0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 000000091CC4: B6810070
	s_mov_b32 s1, s10                                          // 000000091CC8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 000000091CCC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 000000091CD4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 000000091CDC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 000000091CE4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 000000091CEC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 000000091CF4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 000000091CFC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000091D00: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000091D04: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000091D08: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000091D10: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000091D14: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000091D18: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 000000091D1C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000091D24: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000091D28: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 000000091D2C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000091D30: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000091D38: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 000000091D3C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000091D40: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000091D44: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000091D48: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000091D50: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000091D54: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000091D58: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000091D60: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000091D68: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 000000091D6C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000091D70: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000091D74: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000091D78: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 000000091D7C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 000000091D84: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 000000091D8C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000091D94: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 000000091D98: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 000000091D9C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 000000091DA4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 000000091DAC: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 000000091DB0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 000000091DB8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 000000091DC0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 000000091DC8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 000000091DD0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 000000091DD8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 000000091DDC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 000000091DE0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000091DE4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091DE8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 000000091DF0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 000000091DF4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 000000091DF8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091DFC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000091E04: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000091E08: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000091E0C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091E10: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000091E18: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 000000091E1C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000091E20: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091E24: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 000000091E2C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000091E30: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000091E34: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091E38: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000091E40: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000091E44: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000091E48: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091E4C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000091E54: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000091E58: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000091E5C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091E60: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000091E68: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 000000091E6C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000091E70: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091E74: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 000000091E7C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000091E80: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000091E84: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000091E88: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000091E90: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000091E98: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15ac>
	ds_store_b32 v60, v42 offset:2720                          // 000000091E9C: D8340AA0 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 000000091EA4: 8C7E047E
	v_dual_mov_b32 v43, v19 :: v_dual_mov_b32 v42, v18         // 000000091EA8: CA100113 2B2A0112
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 000000091EB0: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 000000091EB8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 000000091EBC: BF89FC07
	s_barrier                                                  // 000000091EC0: BFBD0000
	buffer_gl0_inv                                             // 000000091EC4: E0AC0000 00000000
	s_nop 0                                                    // 000000091ECC: BF800000
	s_nop 0                                                    // 000000091ED0: BF800000
	s_nop 0                                                    // 000000091ED4: BF800000
	s_nop 0                                                    // 000000091ED8: BF800000
	s_nop 0                                                    // 000000091EDC: BF800000
	s_nop 0                                                    // 000000091EE0: BF800000
	s_nop 0                                                    // 000000091EE4: BF800000
	s_nop 0                                                    // 000000091EE8: BF800000
	s_nop 0                                                    // 000000091EEC: BF800000
	s_nop 0                                                    // 000000091EF0: BF800000
	s_nop 0                                                    // 000000091EF4: BF800000
	s_nop 0                                                    // 000000091EF8: BF800000
	s_nop 0                                                    // 000000091EFC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000091F00: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000091F08: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000091F10: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000091F14: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000091F1C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000091F20: D5207C2B 00065680
	.long 0xd4490004                                           // 000000091F28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 000000091F2C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000091F34: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000091F38: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 000000091F3C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000091F44: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 000000091F4C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000091F50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1800>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000091F54: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000091F58: BF89FC07
	s_barrier                                                  // 000000091F5C: BFBD0000
	buffer_gl0_inv                                             // 000000091F60: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000091F68: BE842000
	s_cbranch_execz 141                                        // 000000091F6C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1aa4>
	v_add3_u32 v42, v2, s7, 48                                 // 000000091F70: D655002A 02C00F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000091F78: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 000000091F7C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000091F84: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000091F88: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000091F8C: BF870091
	.long 0xd700012a                                           // 000000091F90: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 000000091F94: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 000000091F98: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 000000091FA0: BE810080
	global_load_b32 v42, v[42:43], off                         // 000000091FA4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 000000091FAC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 000000091FB8: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 000000091FC0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 000000091FC4: B6810070
	s_mov_b32 s1, s10                                          // 000000091FC8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 000000091FCC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 000000091FD4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 000000091FDC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 000000091FE4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 000000091FEC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 000000091FF4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 000000091FFC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000092000: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000092004: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000092008: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000092010: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000092014: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000092018: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000009201C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000092024: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000092028: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000009202C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000092030: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000092038: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000009203C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000092040: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000092044: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000092048: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000092050: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000092054: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000092058: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000092060: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000092068: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000009206C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000092070: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000092074: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000092078: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000009207C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 000000092084: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000009208C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000092094: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 000000092098: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000009209C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 0000000920A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 0000000920AC: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 0000000920B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 0000000920B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 0000000920C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 0000000920C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 0000000920D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 0000000920D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 0000000920DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 0000000920E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000920E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 0000000920E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 0000000920F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 0000000920F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 0000000920F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 0000000920FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000092104: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000092108: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000009210C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000092110: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000092118: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000009211C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000092120: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000092124: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000009212C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000092130: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000092134: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000092138: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000092140: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000092144: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000092148: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000009214C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000092154: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000092158: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000009215C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000092160: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000092168: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000009216C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000092170: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000092174: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000009217C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000092180: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092184: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000092188: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000092190: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000092198: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x18ac>
	ds_store_b32 v60, v42 offset:3264                          // 00000009219C: D8340CC0 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000921A4: 8C7E047E
	v_dual_mov_b32 v43, v21 :: v_dual_mov_b32 v42, v20         // 0000000921A8: CA100115 2B2A0114
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, v51         // 0000000921B0: CA100135 2C2C0133
	s_mov_b32 s10, 0                                           // 0000000921B8: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 0000000921BC: BF89FC07
	s_barrier                                                  // 0000000921C0: BFBD0000
	buffer_gl0_inv                                             // 0000000921C4: E0AC0000 00000000
	s_nop 0                                                    // 0000000921CC: BF800000
	s_nop 0                                                    // 0000000921D0: BF800000
	s_nop 0                                                    // 0000000921D4: BF800000
	s_nop 0                                                    // 0000000921D8: BF800000
	s_nop 0                                                    // 0000000921DC: BF800000
	s_nop 0                                                    // 0000000921E0: BF800000
	s_nop 0                                                    // 0000000921E4: BF800000
	s_nop 0                                                    // 0000000921E8: BF800000
	s_nop 0                                                    // 0000000921EC: BF800000
	s_nop 0                                                    // 0000000921F0: BF800000
	s_nop 0                                                    // 0000000921F4: BF800000
	s_nop 0                                                    // 0000000921F8: BF800000
	s_nop 0                                                    // 0000000921FC: BF800000
	global_load_b32 v46, v[42:43], off                         // 000000092200: DC520000 2E7C002A
	v_add_nc_u32_e32 v45, 0x80, v45                            // 000000092208: 4A5A5AFF 00000080
	.long 0xd700012a                                           // 000000092210: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000092214: 020254FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000009221C: BF870191
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000092220: D5207C2B 00065680
	.long 0xd4490004                                           // 000000092228: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v45, vcc_lo                   // 00000009222C: 02025AFF 0000037F
	s_or_b32 s10, s4, s10                                      // 000000092234: 8C0A0A04
	s_waitcnt vmcnt(0)                                         // 000000092238: BF8903F7
	ds_store_b32 v44, v46 offset:13056                         // 00000009223C: D8343300 00002E2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000092244: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s10                       // 00000009224C: 917E0A7E
	s_cbranch_execnz 65515                                     // 000000092250: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_or_b32 exec_lo, exec_lo, s10                             // 000000092254: 8C7E0A7E
	s_waitcnt lgkmcnt(0)                                       // 000000092258: BF89FC07
	s_barrier                                                  // 00000009225C: BFBD0000
	buffer_gl0_inv                                             // 000000092260: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000092268: BE842000
	s_cbranch_execz 141                                        // 00000009226C: BFA5008D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1da4>
	v_add3_u32 v42, v2, s7, 56                                 // 000000092270: D655002A 02E00F02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092278: BF870091
	v_mad_u64_u32 v[42:43], null, v42, 48, s[2:3]              // 00000009227C: D6FE7C2A 0009612A
	.long 0xd73c002a                                           // 000000092284: D73C002A
	v_cndmask_b32_e32 v1, 9, v42, vcc_lo                       // 000000092288: 02025489
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000009228C: BF870091
	.long 0xd700012a                                           // 000000092290: D700012A
	v_cndmask_b32_e32 v1, v57, v42, vcc_lo                     // 000000092294: 02025539
	v_add_co_ci_u32_e64 v43, null, v58, v43, s1                // 000000092298: D5207C2B 0006573A
	s_mov_b32 s1, 0                                            // 0000000922A0: BE810080
	global_load_b32 v42, v[42:43], off                         // 0000000922A4: DC520000 2A7C002A
	v_mad_u64_u32 v[43:44], null, 0x44, s1, v[1:2]             // 0000000922AC: D6FE7C2B 040402FF 00000044
	v_lshl_add_u32 v72, s1, 2, v59                             // 0000000922B8: D6460048 04ED0401
	s_add_i32 s10, s1, 16                                      // 0000000922C0: 810A9001
	s_cmpk_lt_u32 s1, 0x70                                     // 0000000922C4: B6810070
	s_mov_b32 s1, s10                                          // 0000000922C8: BE81000A
	ds_load_2addr_b32 v[44:45], v43 offset0:68 offset1:85      // 0000000922CC: D8DC5544 2C00002B
	ds_load_2addr_b32 v[64:65], v43 offset0:102 offset1:119    // 0000000922D4: D8DC7766 4000002B
	ds_load_2addr_b32 v[74:75], v43 offset0:136 offset1:153    // 0000000922DC: D8DC9988 4A00002B
	ds_load_2addr_b32 v[76:77], v43 offset0:170 offset1:187    // 0000000922E4: D8DCBBAA 4C00002B
	ds_load_2addr_b32 v[78:79], v43 offset0:204 offset1:221    // 0000000922EC: D8DCDDCC 4E00002B
	ds_load_2addr_b32 v[80:81], v43 offset0:238 offset1:255    // 0000000922F4: D8DCFFEE 5000002B
	s_waitcnt lgkmcnt(5)                                       // 0000000922FC: BF89FC57
	v_cvt_f16_f32_e32 v82, v44                                 // 000000092300: 7EA4152C
	v_cvt_f16_f32_e32 v83, v45                                 // 000000092304: 7EA6152D
	ds_load_2addr_b32 v[44:45], v43 offset0:34 offset1:51      // 000000092308: D8DC3322 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000092310: BF89FC07
	v_cvt_f16_f32_e32 v84, v44                                 // 000000092314: 7EA8152C
	v_cvt_f16_f32_e32 v85, v45                                 // 000000092318: 7EAA152D
	ds_load_2addr_b32 v[44:45], v43 offset1:17                 // 00000009231C: D8DC1100 2C00002B
	s_waitcnt lgkmcnt(0)                                       // 000000092324: BF89FC07
	v_cvt_f16_f32_e32 v86, v44                                 // 000000092328: 7EAC152C
	v_cvt_f16_f32_e32 v87, v45                                 // 00000009232C: 7EAE152D
	ds_load_2addr_b32 v[44:45], v72 offset1:1                  // 000000092330: D8DC0100 2C000048
	s_waitcnt lgkmcnt(0)                                       // 000000092338: BF89FC07
	v_cvt_f16_f32_e32 v43, v44                                 // 00000009233C: 7E56152C
	s_waitcnt vmcnt(0)                                         // 000000092340: BF8903F7
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000092344: BF870131
	v_fma_mix_f32 v42, -v43, v86, v42 op_sel_hi:[1,1,0]        // 000000092348: CC20002A 3CAAAD2B
	v_cvt_f16_f32_e32 v44, v45                                 // 000000092350: 7E58152D
	v_cvt_f16_f32_e32 v45, v64                                 // 000000092354: 7E5A1540
	v_fma_mix_f32 v42, -v44, v87, v42 op_sel_hi:[1,1,0]        // 000000092358: CC20002A 3CAAAF2C
	ds_load_2addr_b32 v[46:47], v72 offset0:2 offset1:3        // 000000092360: D8DC0302 2E000048
	s_waitcnt lgkmcnt(0)                                       // 000000092368: BF89FC07
	v_cvt_f16_f32_e32 v43, v46                                 // 00000009236C: 7E56152E
	v_cvt_f16_f32_e32 v44, v47                                 // 000000092370: 7E58152F
	v_cvt_f16_f32_e32 v46, v65                                 // 000000092374: 7E5C1541
	s_delay_alu instid0(VALU_DEP_3)                            // 000000092378: BF870003
	v_fma_mix_f32 v42, -v43, v84, v42 op_sel_hi:[1,1,0]        // 00000009237C: CC20002A 3CAAA92B
	ds_load_2addr_b32 v[48:49], v72 offset0:4 offset1:5        // 000000092384: D8DC0504 30000048
	v_fma_mix_f32 v42, -v44, v85, v42 op_sel_hi:[1,1,0]        // 00000009238C: CC20002A 3CAAAB2C
	s_waitcnt lgkmcnt(0)                                       // 000000092394: BF89FC07
	v_cvt_f16_f32_e32 v43, v48                                 // 000000092398: 7E561530
	ds_load_2addr_b32 v[62:63], v72 offset0:6 offset1:7        // 00000009239C: D8DC0706 3E000048
	ds_load_2addr_b32 v[66:67], v72 offset0:8 offset1:9        // 0000000923A4: D8DC0908 42000048
	v_cvt_f16_f32_e32 v44, v49                                 // 0000000923AC: 7E581531
	ds_load_2addr_b32 v[68:69], v72 offset0:10 offset1:11      // 0000000923B0: D8DC0B0A 44000048
	v_fma_mix_f32 v42, -v43, v82, v42 op_sel_hi:[1,1,0]        // 0000000923B8: CC20002A 3CAAA52B
	ds_load_2addr_b32 v[70:71], v72 offset0:12 offset1:13      // 0000000923C0: D8DC0D0C 46000048
	ds_load_2addr_b32 v[72:73], v72 offset0:14 offset1:15      // 0000000923C8: D8DC0F0E 48000048
	v_fma_mix_f32 v42, -v44, v83, v42 op_sel_hi:[1,1,0]        // 0000000923D0: CC20002A 3CAAA72C
	s_waitcnt lgkmcnt(4)                                       // 0000000923D8: BF89FC47
	v_cvt_f16_f32_e32 v43, v62                                 // 0000000923DC: 7E56153E
	v_cvt_f16_f32_e32 v44, v63                                 // 0000000923E0: 7E58153F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000000923E4: BF8701C2
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 0000000923E8: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(3)                                       // 0000000923F0: BF89FC37
	v_cvt_f16_f32_e32 v43, v66                                 // 0000000923F4: 7E561542
	v_cvt_f16_f32_e32 v45, v74                                 // 0000000923F8: 7E5A154A
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 0000000923FC: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v67                                 // 000000092404: 7E581543
	v_cvt_f16_f32_e32 v46, v75                                 // 000000092408: 7E5C154B
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000009240C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000092410: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(2)                                       // 000000092418: BF89FC27
	v_cvt_f16_f32_e32 v43, v68                                 // 00000009241C: 7E561544
	v_cvt_f16_f32_e32 v45, v76                                 // 000000092420: 7E5A154C
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000092424: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v69                                 // 00000009242C: 7E581545
	v_cvt_f16_f32_e32 v46, v77                                 // 000000092430: 7E5C154D
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000092434: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000092438: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(1)                                       // 000000092440: BF89FC17
	v_cvt_f16_f32_e32 v43, v70                                 // 000000092444: 7E561546
	v_cvt_f16_f32_e32 v45, v78                                 // 000000092448: 7E5A154E
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 00000009244C: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v71                                 // 000000092454: 7E581547
	v_cvt_f16_f32_e32 v46, v79                                 // 000000092458: 7E5C154F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 00000009245C: BF8701C3
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000092460: CC20002A 3CAA5B2B
	s_waitcnt lgkmcnt(0)                                       // 000000092468: BF89FC07
	v_cvt_f16_f32_e32 v43, v72                                 // 00000009246C: 7E561548
	v_cvt_f16_f32_e32 v45, v80                                 // 000000092470: 7E5A1550
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000092474: CC20002A 3CAA5D2C
	v_cvt_f16_f32_e32 v44, v73                                 // 00000009247C: 7E581549
	v_cvt_f16_f32_e32 v46, v81                                 // 000000092480: 7E5C1551
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092484: BF870093
	v_fma_mix_f32 v42, -v43, v45, v42 op_sel_hi:[1,1,0]        // 000000092488: CC20002A 3CAA5B2B
	v_fma_mix_f32 v42, -v44, v46, v42 op_sel_hi:[1,1,0]        // 000000092490: CC20002A 3CAA5D2C
	s_cbranch_scc1 65412                                       // 000000092498: BFA2FF84 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1bac>
	ds_store_b32 v60, v42 offset:3808                          // 00000009249C: D8340EE0 00002A3C
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000924A4: 8C7E047E
	v_mov_b32_e32 v43, v25                                     // 0000000924A8: 7E560319
	v_dual_mov_b32 v45, v23 :: v_dual_mov_b32 v42, v24         // 0000000924AC: CA100117 2D2A0118
	v_mov_b32_e32 v44, v22                                     // 0000000924B4: 7E580316
	v_mov_b32_e32 v48, v56                                     // 0000000924B8: 7E600338
	s_waitcnt lgkmcnt(0)                                       // 0000000924BC: BF89FC07
	s_barrier                                                  // 0000000924C0: BFBD0000
	s_mov_b32 s10, 0                                           // 0000000924C4: BE8A0080
	buffer_gl0_inv                                             // 0000000924C8: E0AC0000 00000000
	s_branch 21                                                // 0000000924D0: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e28>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000000924D4: 8C7E0B7E
	.long 0xd700012c                                           // 0000000924D8: D700012C
	v_cndmask_b32_e32 v1, 0x30000, v44, vcc_lo                 // 0000000924DC: 020258FF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000924E4: BF870001
	v_add_co_ci_u32_e64 v45, null, 0, v45, s1                  // 0000000924E8: D5207C2D 00065A80
	.long 0xd700012a                                           // 0000000924F0: D700012A
	v_cndmask_b32_e32 v1, 0x800, v42, vcc_lo                   // 0000000924F4: 020254FF 00000800
	v_add_nc_u32_e32 v48, 8, v48                               // 0000000924FC: 4A606088
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000092500: D5207C2B 00065680
	s_add_i32 s1, s10, 8                                       // 000000092508: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000009250C: BF08B70A
	s_mov_b32 s10, s1                                          // 000000092510: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 000000092514: BC7C0000
	s_barrier                                                  // 000000092518: BFBD0000
	buffer_gl0_inv                                             // 00000009251C: E0AC0000 00000000
	s_cbranch_scc1 614                                         // 000000092524: BFA20266 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x27c0>
	v_dual_mov_b32 v47, v45 :: v_dual_mov_b32 v46, v44         // 000000092528: CA10012D 2F2E012C
	v_dual_mov_b32 v49, v53 :: v_dual_mov_b32 v62, v51         // 000000092530: CA100135 313E0133
	s_mov_b32 s11, 0                                           // 000000092538: BE8B0080
	s_nop 0                                                    // 00000009253C: BF800000
	global_load_b32 v63, v[46:47], off                         // 000000092540: DC520000 3F7C002E
	v_add_nc_u32_e32 v62, 0x80, v62                            // 000000092548: 4A7C7CFF 00000080
	.long 0xd700012e                                           // 000000092550: D700012E
	v_cndmask_b32_e32 v1, 0x6000, v46, vcc_lo                  // 000000092554: 02025CFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000009255C: BF870191
	v_add_co_ci_u32_e64 v47, null, 0, v47, s1                  // 000000092560: D5207C2F 00065E80
	.long 0xd4490004                                           // 000000092568: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v62, vcc_lo                   // 00000009256C: 02027CFF 0000037F
	s_or_b32 s11, s4, s11                                      // 000000092574: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 000000092578: BF8903F7
	ds_store_b32 v49, v63 offset:13056                         // 00000009257C: D8343300 00003F31
	v_add_nc_u32_e32 v49, 0x204, v49                           // 000000092584: 4A6262FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000009258C: 917E0B7E
	s_cbranch_execnz 65515                                     // 000000092590: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e40>
	s_or_b32 exec_lo, exec_lo, s11                             // 000000092594: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 000000092598: BF89FC07
	s_barrier                                                  // 00000009259C: BFBD0000
	buffer_gl0_inv                                             // 0000000925A0: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 0000000925A8: BE8B2000
	s_cbranch_execz 65481                                      // 0000000925AC: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dd4>
	v_or_b32_e32 v46, s10, v2                                  // 0000000925B0: 385C040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000925B4: BF870091
	v_or_b32_e32 v49, s7, v46                                  // 0000000925B8: 38625C07
	.long 0xd4440001                                           // 0000000925BC: D4440001
	v_cndmask_b32_e32 v1, s30, v49, vcc_lo                     // 0000000925C0: 0202621E
	s_and_b32 exec_lo, exec_lo, s1                             // 0000000925C4: 8B7E017E
	s_cbranch_execz 65474                                      // 0000000925C8: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dd4>
	ds_load_2addr_b32 v[62:63], v59 offset1:1                  // 0000000925CC: D8DC0100 3E00003B
	ds_load_2addr_b32 v[64:65], v1 offset1:17                  // 0000000925D4: D8DC1100 40000001
	ds_load_2addr_b32 v[66:67], v59 offset0:2 offset1:3        // 0000000925DC: D8DC0302 4200003B
	ds_load_2addr_b32 v[68:69], v1 offset0:34 offset1:51       // 0000000925E4: D8DC3322 44000001
	ds_load_2addr_b32 v[70:71], v59 offset0:4 offset1:5        // 0000000925EC: D8DC0504 4600003B
	ds_load_2addr_b32 v[72:73], v59 offset0:6 offset1:7        // 0000000925F4: D8DC0706 4800003B
	ds_load_2addr_b32 v[74:75], v1 offset0:68 offset1:85       // 0000000925FC: D8DC5544 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:102 offset1:119     // 000000092604: D8DC7766 4C000001
	ds_load_2addr_b32 v[79:80], v59 offset0:28 offset1:29      // 00000009260C: D8DC1D1C 4F00003B
	ds_load_2addr_b32 v[81:82], v59 offset0:30 offset1:31      // 000000092614: D8DC1F1E 5100003B
	v_lshlrev_b32_e32 v46, 2, v46                              // 00000009261C: 305C5C82
	s_mov_b32 s12, 0                                           // 000000092620: BE8C0080
	s_waitcnt lgkmcnt(8)                                       // 000000092624: BF89FC87
	v_fma_f32 v62, v62, v64, 0                                 // 000000092628: D613003E 0202813E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092630: BF8700A1
	v_fmac_f32_e32 v62, v63, v65                               // 000000092634: 567C833F
	s_waitcnt lgkmcnt(6)                                       // 000000092638: BF89FC67
	v_fmac_f32_e32 v62, v66, v68                               // 00000009263C: 567C8942
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092640: BF8700A1
	v_fmac_f32_e32 v62, v67, v69                               // 000000092644: 567C8B43
	s_waitcnt lgkmcnt(3)                                       // 000000092648: BF89FC37
	v_fmac_f32_e32 v62, v70, v74                               // 00000009264C: 567C9546
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092650: BF8700A1
	v_fmac_f32_e32 v62, v71, v75                               // 000000092654: 567C9747
	s_waitcnt lgkmcnt(2)                                       // 000000092658: BF89FC27
	v_fmac_f32_e32 v62, v72, v76                               // 00000009265C: 567C9948
	s_delay_alu instid0(VALU_DEP_1)                            // 000000092660: BF870001
	v_fmac_f32_e32 v62, v73, v77                               // 000000092664: 567C9B49
	ds_load_2addr_b32 v[63:64], v59 offset0:8 offset1:9        // 000000092668: D8DC0908 3F00003B
	ds_load_2addr_b32 v[65:66], v1 offset0:136 offset1:153     // 000000092670: D8DC9988 41000001
	ds_load_2addr_b32 v[67:68], v59 offset0:10 offset1:11      // 000000092678: D8DC0B0A 4300003B
	ds_load_2addr_b32 v[69:70], v1 offset0:170 offset1:187     // 000000092680: D8DCBBAA 45000001
	ds_load_2addr_b32 v[71:72], v59 offset0:12 offset1:13      // 000000092688: D8DC0D0C 4700003B
	ds_load_2addr_b32 v[73:74], v59 offset0:14 offset1:15      // 000000092690: D8DC0F0E 4900003B
	ds_load_2addr_b32 v[75:76], v1 offset0:204 offset1:221     // 000000092698: D8DCDDCC 4B000001
	ds_load_2addr_b32 v[77:78], v1 offset0:238 offset1:255     // 0000000926A0: D8DCFFEE 4D000001
	s_waitcnt lgkmcnt(6)                                       // 0000000926A8: BF89FC67
	v_fmac_f32_e32 v62, v63, v65                               // 0000000926AC: 567C833F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000926B0: BF8700A1
	v_fmac_f32_e32 v62, v64, v66                               // 0000000926B4: 567C8540
	s_waitcnt lgkmcnt(4)                                       // 0000000926B8: BF89FC47
	v_fmac_f32_e32 v62, v67, v69                               // 0000000926BC: 567C8B43
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000926C0: BF8700A1
	v_fmac_f32_e32 v62, v68, v70                               // 0000000926C4: 567C8D44
	s_waitcnt lgkmcnt(1)                                       // 0000000926C8: BF89FC17
	v_fmac_f32_e32 v62, v71, v75                               // 0000000926CC: 567C9747
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000926D0: BF8700A1
	v_fmac_f32_e32 v62, v72, v76                               // 0000000926D4: 567C9948
	s_waitcnt lgkmcnt(0)                                       // 0000000926D8: BF89FC07
	v_fmac_f32_e32 v62, v73, v77                               // 0000000926DC: 567C9B49
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000926E0: BF870001
	v_fmac_f32_e32 v62, v74, v78                               // 0000000926E4: 567C9D4A
	ds_load_2addr_b32 v[63:64], v59 offset0:16 offset1:17      // 0000000926E8: D8DC1110 3F00003B
	ds_load_2addr_b32 v[65:66], v59 offset0:18 offset1:19      // 0000000926F0: D8DC1312 4100003B
	ds_load_2addr_b32 v[67:68], v59 offset0:20 offset1:21      // 0000000926F8: D8DC1514 4300003B
	ds_load_2addr_b32 v[69:70], v59 offset0:22 offset1:23      // 000000092700: D8DC1716 4500003B
	ds_load_2addr_b32 v[75:76], v59 offset0:24 offset1:25      // 000000092708: D8DC1918 4B00003B
	ds_load_2addr_b32 v[77:78], v59 offset0:26 offset1:27      // 000000092710: D8DC1B1A 4D00003B
	v_add_nc_u32_e32 v47, 0x400, v1                            // 000000092718: 4A5E02FF 00000400
	v_add_nc_u32_e32 v95, 0x800, v1                            // 000000092720: 4ABE02FF 00000800
	v_add_nc_u32_e32 v101, 0x1000, v1                          // 000000092728: 4ACA02FF 00001000
	v_add_nc_u32_e32 v103, 0x1800, v1                          // 000000092730: 4ACE02FF 00001800
	ds_load_2addr_b32 v[71:72], v47 offset0:16 offset1:33      // 000000092738: D8DC2110 4700002F
	ds_load_2addr_b32 v[73:74], v47 offset0:50 offset1:67      // 000000092740: D8DC4332 4900002F
	ds_load_2addr_b32 v[83:84], v47 offset0:84 offset1:101     // 000000092748: D8DC6554 5300002F
	ds_load_2addr_b32 v[85:86], v47 offset0:118 offset1:135    // 000000092750: D8DC8776 5500002F
	ds_load_2addr_b32 v[87:88], v47 offset0:152 offset1:169    // 000000092758: D8DCA998 5700002F
	ds_load_2addr_b32 v[89:90], v47 offset0:186 offset1:203    // 000000092760: D8DCCBBA 5900002F
	ds_load_2addr_b32 v[91:92], v47 offset0:220 offset1:237    // 000000092768: D8DCEDDC 5B00002F
	ds_load_2addr_b32 v[93:94], v95 offset0:202 offset1:219    // 000000092770: D8DCDBCA 5D00005F
	ds_load_2addr_b32 v[99:100], v101 offset0:200 offset1:217  // 000000092778: D8DCD9C8 63000065
	s_waitcnt lgkmcnt(8)                                       // 000000092780: BF89FC87
	v_fmac_f32_e32 v62, v63, v71                               // 000000092784: 567C8F3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092788: BF8700A1
	v_fmac_f32_e32 v62, v64, v72                               // 00000009278C: 567C9140
	s_waitcnt lgkmcnt(7)                                       // 000000092790: BF89FC77
	v_fmac_f32_e32 v62, v65, v73                               // 000000092794: 567C9341
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092798: BF8700A1
	v_fmac_f32_e32 v62, v66, v74                               // 00000009279C: 567C9542
	s_waitcnt lgkmcnt(6)                                       // 0000000927A0: BF89FC67
	v_fmac_f32_e32 v62, v67, v83                               // 0000000927A4: 567CA743
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000927A8: BF8700A1
	v_fmac_f32_e32 v62, v68, v84                               // 0000000927AC: 567CA944
	s_waitcnt lgkmcnt(5)                                       // 0000000927B0: BF89FC57
	v_fmac_f32_e32 v62, v69, v85                               // 0000000927B4: 567CAB45
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000927B8: BF870001
	v_fmac_f32_e32 v62, v70, v86                               // 0000000927BC: 567CAD46
	ds_load_2addr_b32 v[63:64], v59 offset0:32 offset1:33      // 0000000927C0: D8DC2120 3F00003B
	ds_load_2addr_b32 v[65:66], v59 offset0:34 offset1:35      // 0000000927C8: D8DC2322 4100003B
	ds_load_2addr_b32 v[67:68], v59 offset0:36 offset1:37      // 0000000927D0: D8DC2524 4300003B
	ds_load_2addr_b32 v[69:70], v59 offset0:38 offset1:39      // 0000000927D8: D8DC2726 4500003B
	ds_load_2addr_b32 v[73:74], v95 offset0:32 offset1:49      // 0000000927E0: D8DC3120 4900005F
	ds_load_2addr_b32 v[83:84], v59 offset0:40 offset1:41      // 0000000927E8: D8DC2928 5300003B
	ds_load_2addr_b32 v[85:86], v59 offset0:42 offset1:43      // 0000000927F0: D8DC2B2A 5500003B
	s_waitcnt lgkmcnt(11)                                      // 0000000927F8: BF89FCB7
	v_dual_fmac_f32 v62, v75, v87 :: v_dual_add_nc_u32 v47, 0x600, v1// 0000000927FC: C820AF4B 3E2E02FF 00000600
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092808: BF8700A1
	v_fmac_f32_e32 v62, v76, v88                               // 00000009280C: 567CB14C
	s_waitcnt lgkmcnt(10)                                      // 000000092810: BF89FCA7
	v_fmac_f32_e32 v62, v77, v89                               // 000000092814: 567CB34D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092818: BF8700A1
	v_fmac_f32_e32 v62, v78, v90                               // 00000009281C: 567CB54E
	s_waitcnt lgkmcnt(9)                                       // 000000092820: BF89FC97
	v_fmac_f32_e32 v62, v79, v91                               // 000000092824: 567CB74F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000092828: BF870001
	v_fmac_f32_e32 v62, v80, v92                               // 00000009282C: 567CB950
	ds_load_2addr_b32 v[71:72], v47 offset0:126 offset1:143    // 000000092830: D8DC8F7E 4700002F
	ds_load_2addr_b32 v[75:76], v95 offset0:66 offset1:83      // 000000092838: D8DC5342 4B00005F
	ds_load_2addr_b32 v[77:78], v95 offset0:100 offset1:117    // 000000092840: D8DC7564 4D00005F
	ds_load_2addr_b32 v[79:80], v95 offset0:134 offset1:151    // 000000092848: D8DC9786 4F00005F
	ds_load_2addr_b32 v[87:88], v59 offset0:44 offset1:45      // 000000092850: D8DC2D2C 5700003B
	ds_load_2addr_b32 v[89:90], v59 offset0:46 offset1:47      // 000000092858: D8DC2F2E 5900003B
	ds_load_2addr_b32 v[91:92], v95 offset0:168 offset1:185    // 000000092860: D8DCB9A8 5B00005F
	ds_load_2addr_b32 v[95:96], v95 offset0:236 offset1:253    // 000000092868: D8DCFDEC 5F00005F
	s_waitcnt lgkmcnt(7)                                       // 000000092870: BF89FC77
	v_fmac_f32_e32 v62, v81, v71                               // 000000092874: 567C8F51
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092878: BF870091
	v_fmac_f32_e32 v62, v82, v72                               // 00000009287C: 567C9152
	v_fmac_f32_e32 v62, v63, v73                               // 000000092880: 567C933F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092884: BF8700A1
	v_fmac_f32_e32 v62, v64, v74                               // 000000092888: 567C9540
	s_waitcnt lgkmcnt(6)                                       // 00000009288C: BF89FC67
	v_fmac_f32_e32 v62, v65, v75                               // 000000092890: 567C9741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092894: BF8700A1
	v_fmac_f32_e32 v62, v66, v76                               // 000000092898: 567C9942
	s_waitcnt lgkmcnt(5)                                       // 00000009289C: BF89FC57
	v_fmac_f32_e32 v62, v67, v77                               // 0000000928A0: 567C9B43
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000928A4: BF870001
	v_fmac_f32_e32 v62, v68, v78                               // 0000000928A8: 567C9D44
	ds_load_2addr_b32 v[63:64], v59 offset0:48 offset1:49      // 0000000928AC: D8DC3130 3F00003B
	ds_load_2addr_b32 v[65:66], v59 offset0:50 offset1:51      // 0000000928B4: D8DC3332 4100003B
	ds_load_2addr_b32 v[67:68], v59 offset0:52 offset1:53      // 0000000928BC: D8DC3534 4300003B
	ds_load_2addr_b32 v[71:72], v59 offset0:54 offset1:55      // 0000000928C4: D8DC3736 4700003B
	ds_load_2addr_b32 v[81:82], v59 offset0:56 offset1:57      // 0000000928CC: D8DC3938 5100003B
	s_waitcnt lgkmcnt(9)                                       // 0000000928D4: BF89FC97
	v_dual_fmac_f32 v62, v69, v79 :: v_dual_add_nc_u32 v47, 0xc00, v1// 0000000928D8: C8209F45 3E2E02FF 00000C00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000928E4: BF8700A1
	v_fmac_f32_e32 v62, v70, v80                               // 0000000928E8: 567CA146
	s_waitcnt lgkmcnt(6)                                       // 0000000928EC: BF89FC67
	v_fmac_f32_e32 v62, v83, v91                               // 0000000928F0: 567CB753
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000928F4: BF870091
	v_fmac_f32_e32 v62, v84, v92                               // 0000000928F8: 567CB954
	v_fmac_f32_e32 v62, v85, v93                               // 0000000928FC: 567CBB55
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092900: BF8700A1
	v_fmac_f32_e32 v62, v86, v94                               // 000000092904: 567CBD56
	s_waitcnt lgkmcnt(5)                                       // 000000092908: BF89FC57
	v_fmac_f32_e32 v62, v87, v95                               // 00000009290C: 567CBF57
	ds_load_2addr_b32 v[69:70], v47 offset0:14 offset1:31      // 000000092910: D8DC1F0E 4500002F
	ds_load_2addr_b32 v[73:74], v47 offset0:48 offset1:65      // 000000092918: D8DC4130 4900002F
	ds_load_2addr_b32 v[75:76], v47 offset0:82 offset1:99      // 000000092920: D8DC6352 4B00002F
	ds_load_2addr_b32 v[77:78], v47 offset0:116 offset1:133    // 000000092928: D8DC8574 4D00002F
	ds_load_2addr_b32 v[79:80], v47 offset0:150 offset1:167    // 000000092930: D8DCA796 4F00002F
	ds_load_2addr_b32 v[83:84], v59 offset0:58 offset1:59      // 000000092938: D8DC3B3A 5300003B
	ds_load_2addr_b32 v[85:86], v59 offset0:60 offset1:61      // 000000092940: D8DC3D3C 5500003B
	ds_load_2addr_b32 v[91:92], v59 offset0:62 offset1:63      // 000000092948: D8DC3F3E 5B00003B
	ds_load_2addr_b32 v[93:94], v47 offset0:184 offset1:201    // 000000092950: D8DCC9B8 5D00002F
	ds_load_2addr_b32 v[97:98], v47 offset0:218 offset1:235    // 000000092958: D8DCEBDA 6100002F
	v_fmac_f32_e32 v62, v88, v96                               // 000000092960: 567CC158
	s_waitcnt lgkmcnt(9)                                       // 000000092964: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092968: BF870091
	v_fmac_f32_e32 v62, v89, v69                               // 00000009296C: 567C8B59
	v_fmac_f32_e32 v62, v90, v70                               // 000000092970: 567C8D5A
	s_waitcnt lgkmcnt(8)                                       // 000000092974: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092978: BF870091
	v_fmac_f32_e32 v62, v63, v73                               // 00000009297C: 567C933F
	v_fmac_f32_e32 v62, v64, v74                               // 000000092980: 567C9540
	s_waitcnt lgkmcnt(7)                                       // 000000092984: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092988: BF870091
	v_fmac_f32_e32 v62, v65, v75                               // 00000009298C: 567C9741
	v_fmac_f32_e32 v62, v66, v76                               // 000000092990: 567C9942
	s_waitcnt lgkmcnt(6)                                       // 000000092994: BF89FC67
	s_delay_alu instid0(VALU_DEP_1)                            // 000000092998: BF870001
	v_fmac_f32_e32 v62, v67, v77                               // 00000009299C: 567C9B43
	ds_load_2addr_b32 v[63:64], v59 offset0:64 offset1:65      // 0000000929A0: D8DC4140 3F00003B
	ds_load_2addr_b32 v[65:66], v59 offset0:66 offset1:67      // 0000000929A8: D8DC4342 4100003B
	ds_load_2addr_b32 v[69:70], v59 offset0:68 offset1:69      // 0000000929B0: D8DC4544 4500003B
	ds_load_2addr_b32 v[73:74], v59 offset0:70 offset1:71      // 0000000929B8: D8DC4746 4900003B
	ds_load_2addr_b32 v[75:76], v101 offset0:64 offset1:81     // 0000000929C0: D8DC5140 4B000065
	ds_load_2addr_b32 v[87:88], v59 offset0:72 offset1:73      // 0000000929C8: D8DC4948 5700003B
	ds_load_2addr_b32 v[89:90], v59 offset0:74 offset1:75      // 0000000929D0: D8DC4B4A 5900003B
	ds_load_2addr_b32 v[95:96], v59 offset0:78 offset1:79      // 0000000929D8: D8DC4F4E 5F00003B
	v_dual_fmac_f32 v62, v68, v78 :: v_dual_add_nc_u32 v47, 0xe00, v1// 0000000929E0: C8209D44 3E2E02FF 00000E00
	s_waitcnt lgkmcnt(13)                                      // 0000000929EC: BF89FCD7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000929F0: BF870091
	v_fmac_f32_e32 v62, v71, v79                               // 0000000929F4: 567C9F47
	v_fmac_f32_e32 v62, v72, v80                               // 0000000929F8: 567CA148
	s_waitcnt lgkmcnt(9)                                       // 0000000929FC: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092A00: BF870091
	v_fmac_f32_e32 v62, v81, v93                               // 000000092A04: 567CBB51
	v_fmac_f32_e32 v62, v82, v94                               // 000000092A08: 567CBD52
	s_waitcnt lgkmcnt(8)                                       // 000000092A0C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092A10: BF870091
	v_fmac_f32_e32 v62, v83, v97                               // 000000092A14: 567CC353
	v_fmac_f32_e32 v62, v84, v98                               // 000000092A18: 567CC554
	ds_load_2addr_b32 v[67:68], v47 offset0:124 offset1:141    // 000000092A1C: D8DC8D7C 4300002F
	ds_load_2addr_b32 v[71:72], v101 offset0:30 offset1:47     // 000000092A24: D8DC2F1E 47000065
	ds_load_2addr_b32 v[77:78], v101 offset0:98 offset1:115    // 000000092A2C: D8DC7362 4D000065
	ds_load_2addr_b32 v[79:80], v101 offset0:132 offset1:149   // 000000092A34: D8DC9584 4F000065
	ds_load_2addr_b32 v[81:82], v101 offset0:166 offset1:183   // 000000092A3C: D8DCB7A6 51000065
	ds_load_2addr_b32 v[93:94], v59 offset0:76 offset1:77      // 000000092A44: D8DC4D4C 5D00003B
	ds_load_2addr_b32 v[101:102], v101 offset0:234 offset1:251 // 000000092A4C: D8DCFBEA 65000065
	ds_load_2addr_b32 v[83:84], v59 offset0:88 offset1:89      // 000000092A54: D8DC5958 5300003B
	s_waitcnt lgkmcnt(7)                                       // 000000092A5C: BF89FC77
	v_fmac_f32_e32 v62, v85, v67                               // 000000092A60: 567C8755
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092A64: BF8700A1
	v_fmac_f32_e32 v62, v86, v68                               // 000000092A68: 567C8956
	s_waitcnt lgkmcnt(6)                                       // 000000092A6C: BF89FC67
	v_fmac_f32_e32 v62, v91, v71                               // 000000092A70: 567C8F5B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092A74: BF870091
	v_fmac_f32_e32 v62, v92, v72                               // 000000092A78: 567C915C
	v_fmac_f32_e32 v62, v63, v75                               // 000000092A7C: 567C973F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092A80: BF8700A1
	v_fmac_f32_e32 v62, v64, v76                               // 000000092A84: 567C9940
	s_waitcnt lgkmcnt(5)                                       // 000000092A88: BF89FC57
	v_fmac_f32_e32 v62, v65, v77                               // 000000092A8C: 567C9B41
	s_delay_alu instid0(VALU_DEP_1)                            // 000000092A90: BF870001
	v_fmac_f32_e32 v62, v66, v78                               // 000000092A94: 567C9D42
	ds_load_2addr_b32 v[63:64], v59 offset0:80 offset1:81      // 000000092A98: D8DC5150 3F00003B
	ds_load_2addr_b32 v[67:68], v59 offset0:82 offset1:83      // 000000092AA0: D8DC5352 4300003B
	ds_load_2addr_b32 v[71:72], v59 offset0:84 offset1:85      // 000000092AA8: D8DC5554 4700003B
	ds_load_2addr_b32 v[75:76], v59 offset0:86 offset1:87      // 000000092AB0: D8DC5756 4B00003B
	ds_load_2addr_b32 v[85:86], v59 offset0:90 offset1:91      // 000000092AB8: D8DC5B5A 5500003B
	ds_load_2addr_b32 v[91:92], v59 offset0:94 offset1:95      // 000000092AC0: D8DC5F5E 5B00003B
	s_waitcnt lgkmcnt(10)                                      // 000000092AC8: BF89FCA7
	v_dual_fmac_f32 v62, v69, v79 :: v_dual_add_nc_u32 v47, 0x1400, v1// 000000092ACC: C8209F45 3E2E02FF 00001400
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092AD8: BF8700A1
	v_fmac_f32_e32 v62, v70, v80                               // 000000092ADC: 567CA146
	s_waitcnt lgkmcnt(9)                                       // 000000092AE0: BF89FC97
	v_fmac_f32_e32 v62, v73, v81                               // 000000092AE4: 567CA349
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092AE8: BF870091
	v_fmac_f32_e32 v62, v74, v82                               // 000000092AEC: 567CA54A
	v_fmac_f32_e32 v62, v87, v99                               // 000000092AF0: 567CC757
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092AF4: BF8700A1
	v_fmac_f32_e32 v62, v88, v100                              // 000000092AF8: 567CC958
	s_waitcnt lgkmcnt(7)                                       // 000000092AFC: BF89FC77
	v_fmac_f32_e32 v62, v89, v101                              // 000000092B00: 567CCB59
	ds_load_2addr_b32 v[65:66], v47 offset0:12 offset1:29      // 000000092B04: D8DC1D0C 4100002F
	ds_load_2addr_b32 v[69:70], v47 offset0:46 offset1:63      // 000000092B0C: D8DC3F2E 4500002F
	ds_load_2addr_b32 v[73:74], v47 offset0:80 offset1:97      // 000000092B14: D8DC6150 4900002F
	ds_load_2addr_b32 v[77:78], v47 offset0:114 offset1:131    // 000000092B1C: D8DC8372 4D00002F
	ds_load_2addr_b32 v[79:80], v47 offset0:148 offset1:165    // 000000092B24: D8DCA594 4F00002F
	ds_load_2addr_b32 v[81:82], v47 offset0:182 offset1:199    // 000000092B2C: D8DCC7B6 5100002F
	ds_load_2addr_b32 v[87:88], v59 offset0:92 offset1:93      // 000000092B34: D8DC5D5C 5700003B
	ds_load_2addr_b32 v[97:98], v47 offset0:216 offset1:233    // 000000092B3C: D8DCE9D8 6100002F
	ds_load_2addr_b32 v[99:100], v59 offset0:108 offset1:109   // 000000092B44: D8DC6D6C 6300003B
	v_fmac_f32_e32 v62, v90, v102                              // 000000092B4C: 567CCD5A
	s_waitcnt lgkmcnt(8)                                       // 000000092B50: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092B54: BF870091
	v_fmac_f32_e32 v62, v93, v65                               // 000000092B58: 567C835D
	v_fmac_f32_e32 v62, v94, v66                               // 000000092B5C: 567C855E
	s_waitcnt lgkmcnt(7)                                       // 000000092B60: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092B64: BF870091
	v_fmac_f32_e32 v62, v95, v69                               // 000000092B68: 567C8B5F
	v_fmac_f32_e32 v62, v96, v70                               // 000000092B6C: 567C8D60
	s_waitcnt lgkmcnt(6)                                       // 000000092B70: BF89FC67
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092B74: BF870091
	v_fmac_f32_e32 v62, v63, v73                               // 000000092B78: 567C933F
	v_fmac_f32_e32 v62, v64, v74                               // 000000092B7C: 567C9540
	s_waitcnt lgkmcnt(5)                                       // 000000092B80: BF89FC57
	s_delay_alu instid0(VALU_DEP_1)                            // 000000092B84: BF870001
	v_fmac_f32_e32 v62, v67, v77                               // 000000092B88: 567C9B43
	ds_load_2addr_b32 v[63:64], v59 offset0:96 offset1:97      // 000000092B8C: D8DC6160 3F00003B
	ds_load_2addr_b32 v[65:66], v59 offset0:98 offset1:99      // 000000092B94: D8DC6362 4100003B
	ds_load_2addr_b32 v[69:70], v59 offset0:100 offset1:101    // 000000092B9C: D8DC6564 4500003B
	ds_load_2addr_b32 v[73:74], v59 offset0:102 offset1:103    // 000000092BA4: D8DC6766 4900003B
	ds_load_2addr_b32 v[89:90], v103 offset0:198 offset1:215   // 000000092BAC: D8DCD7C6 59000067
	ds_load_2addr_b32 v[93:94], v59 offset0:104 offset1:105    // 000000092BB4: D8DC6968 5D00003B
	ds_load_2addr_b32 v[95:96], v59 offset0:106 offset1:107    // 000000092BBC: D8DC6B6A 5F00003B
	ds_load_2addr_b32 v[101:102], v59 offset0:110 offset1:111  // 000000092BC4: D8DC6F6E 6500003B
	v_dual_fmac_f32 v62, v68, v78 :: v_dual_add_nc_u32 v47, 0x1600, v1// 000000092BCC: C8209D44 3E2E02FF 00001600
	s_waitcnt lgkmcnt(12)                                      // 000000092BD8: BF89FCC7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092BDC: BF870091
	v_fmac_f32_e32 v62, v71, v79                               // 000000092BE0: 567C9F47
	v_fmac_f32_e32 v62, v72, v80                               // 000000092BE4: 567CA148
	s_waitcnt lgkmcnt(11)                                      // 000000092BE8: BF89FCB7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092BEC: BF870091
	v_fmac_f32_e32 v62, v75, v81                               // 000000092BF0: 567CA34B
	v_fmac_f32_e32 v62, v76, v82                               // 000000092BF4: 567CA54C
	s_waitcnt lgkmcnt(9)                                       // 000000092BF8: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092BFC: BF870091
	v_fmac_f32_e32 v62, v83, v97                               // 000000092C00: 567CC353
	v_fmac_f32_e32 v62, v84, v98                               // 000000092C04: 567CC554
	ds_load_2addr_b32 v[67:68], v47 offset0:122 offset1:139    // 000000092C08: D8DC8B7A 4300002F
	ds_load_2addr_b32 v[71:72], v103 offset0:28 offset1:45     // 000000092C10: D8DC2D1C 47000067
	ds_load_2addr_b32 v[75:76], v103 offset0:62 offset1:79     // 000000092C18: D8DC4F3E 4B000067
	ds_load_2addr_b32 v[77:78], v103 offset0:96 offset1:113    // 000000092C20: D8DC7160 4D000067
	ds_load_2addr_b32 v[79:80], v103 offset0:130 offset1:147   // 000000092C28: D8DC9382 4F000067
	ds_load_2addr_b32 v[81:82], v103 offset0:164 offset1:181   // 000000092C30: D8DCB5A4 51000067
	ds_load_2addr_b32 v[103:104], v103 offset0:232 offset1:249 // 000000092C38: D8DCF9E8 67000067
	s_waitcnt lgkmcnt(6)                                       // 000000092C40: BF89FC67
	v_fmac_f32_e32 v62, v85, v67                               // 000000092C44: 567C8755
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092C48: BF8700A1
	v_fmac_f32_e32 v62, v86, v68                               // 000000092C4C: 567C8956
	s_waitcnt lgkmcnt(5)                                       // 000000092C50: BF89FC57
	v_fmac_f32_e32 v62, v87, v71                               // 000000092C54: 567C8F57
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092C58: BF8700A1
	v_fmac_f32_e32 v62, v88, v72                               // 000000092C5C: 567C9158
	s_waitcnt lgkmcnt(4)                                       // 000000092C60: BF89FC47
	v_fmac_f32_e32 v62, v91, v75                               // 000000092C64: 567C975B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092C68: BF8700A1
	v_fmac_f32_e32 v62, v92, v76                               // 000000092C6C: 567C995C
	s_waitcnt lgkmcnt(3)                                       // 000000092C70: BF89FC37
	v_fmac_f32_e32 v62, v63, v77                               // 000000092C74: 567C9B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092C78: BF8700A1
	v_dual_fmac_f32 v62, v64, v78 :: v_dual_add_nc_u32 v47, 0x1e00, v1// 000000092C7C: C8209D40 3E2E02FF 00001E00
	s_waitcnt lgkmcnt(2)                                       // 000000092C88: BF89FC27
	v_fmac_f32_e32 v62, v65, v79                               // 000000092C8C: 567C9F41
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092C90: BF8700A1
	v_fmac_f32_e32 v62, v66, v80                               // 000000092C94: 567CA142
	s_waitcnt lgkmcnt(1)                                       // 000000092C98: BF89FC17
	v_fmac_f32_e32 v62, v69, v81                               // 000000092C9C: 567CA345
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092CA0: BF870091
	v_fmac_f32_e32 v62, v70, v82                               // 000000092CA4: 567CA546
	v_fmac_f32_e32 v62, v73, v89                               // 000000092CA8: 567CB349
	s_delay_alu instid0(VALU_DEP_1)                            // 000000092CAC: BF870001
	v_fmac_f32_e32 v62, v74, v90                               // 000000092CB0: 567CB54A
	ds_load_2addr_b32 v[77:78], v47 offset0:120 offset1:137    // 000000092CB4: D8DC8978 4D00002F
	v_add_nc_u32_e32 v47, 0x1c00, v1                           // 000000092CBC: 4A5E02FF 00001C00
	ds_load_2addr_b32 v[87:88], v47 offset0:10 offset1:27      // 000000092CC4: D8DC1B0A 5700002F
	ds_load_2addr_b32 v[89:90], v47 offset0:44 offset1:61      // 000000092CCC: D8DC3D2C 5900002F
	ds_load_2addr_b32 v[91:92], v47 offset0:78 offset1:95      // 000000092CD4: D8DC5F4E 5B00002F
	s_waitcnt lgkmcnt(4)                                       // 000000092CDC: BF89FC47
	v_fmac_f32_e32 v62, v93, v103                              // 000000092CE0: 567CCF5D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092CE4: BF8700A1
	v_fmac_f32_e32 v62, v94, v104                              // 000000092CE8: 567CD15E
	s_waitcnt lgkmcnt(2)                                       // 000000092CEC: BF89FC27
	v_fmac_f32_e32 v62, v95, v87                               // 000000092CF0: 567CAF5F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092CF4: BF8700A1
	v_fmac_f32_e32 v62, v96, v88                               // 000000092CF8: 567CB160
	s_waitcnt lgkmcnt(1)                                       // 000000092CFC: BF89FC17
	v_fmac_f32_e32 v62, v99, v89                               // 000000092D00: 567CB363
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092D04: BF8700A1
	v_fmac_f32_e32 v62, v100, v90                              // 000000092D08: 567CB564
	s_waitcnt lgkmcnt(0)                                       // 000000092D0C: BF89FC07
	v_fmac_f32_e32 v62, v101, v91                              // 000000092D10: 567CB765
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000092D14: BF8700D1
	v_fmac_f32_e32 v62, v102, v92                              // 000000092D18: 567CB966
	ds_load_2addr_b32 v[67:68], v59 offset0:112 offset1:113    // 000000092D1C: D8DC7170 4300003B
	ds_load_2addr_b32 v[97:98], v47 offset0:112 offset1:129    // 000000092D24: D8DC8170 6100002F
	s_waitcnt lgkmcnt(0)                                       // 000000092D2C: BF89FC07
	v_fmac_f32_e32 v62, v67, v97                               // 000000092D30: 567CC343
	v_fmac_f32_e32 v62, v68, v98                               // 000000092D34: 567CC544
	ds_load_2addr_b32 v[71:72], v59 offset0:114 offset1:115    // 000000092D38: D8DC7372 4700003B
	ds_load_2addr_b32 v[105:106], v47 offset0:146 offset1:163  // 000000092D40: D8DCA392 6900002F
	s_waitcnt lgkmcnt(0)                                       // 000000092D48: BF89FC07
	v_fmac_f32_e32 v62, v71, v105                              // 000000092D4C: 567CD347
	s_delay_alu instid0(VALU_DEP_1)                            // 000000092D50: BF870001
	v_fmac_f32_e32 v62, v72, v106                              // 000000092D54: 567CD548
	ds_load_2addr_b32 v[83:84], v59 offset0:118 offset1:119    // 000000092D58: D8DC7776 5300003B
	ds_load_2addr_b32 v[75:76], v59 offset0:116 offset1:117    // 000000092D60: D8DC7574 4B00003B
	ds_load_2addr_b32 v[63:64], v59 offset0:120 offset1:121    // 000000092D68: D8DC7978 3F00003B
	v_add_nc_u32_e32 v85, 0x2000, v1                           // 000000092D70: 4AAA02FF 00002000
	ds_load_2addr_b32 v[107:108], v47 offset0:180 offset1:197  // 000000092D78: D8DCC5B4 6B00002F
	ds_load_2addr_b32 v[109:110], v47 offset0:214 offset1:231  // 000000092D80: D8DCE7D6 6D00002F
	ds_load_2addr_b32 v[65:66], v59 offset0:122 offset1:123    // 000000092D88: D8DC7B7A 4100003B
	ds_load_2addr_b32 v[69:70], v59 offset0:124 offset1:125    // 000000092D90: D8DC7D7C 4500003B
	ds_load_2addr_b32 v[79:80], v85 offset0:26 offset1:43      // 000000092D98: D8DC2B1A 4F000055
	ds_load_2addr_b32 v[81:82], v85 offset0:60 offset1:77      // 000000092DA0: D8DC4D3C 51000055
	ds_load_2addr_b32 v[73:74], v59 offset0:126 offset1:127    // 000000092DA8: D8DC7F7E 4900003B
	ds_load_2addr_b32 v[85:86], v85 offset0:94 offset1:111     // 000000092DB0: D8DC6F5E 55000055
	s_waitcnt lgkmcnt(7)                                       // 000000092DB8: BF89FC77
	v_fmac_f32_e32 v62, v75, v107                              // 000000092DBC: 567CD74B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000092DC0: BF8700A1
	v_fmac_f32_e32 v62, v76, v108                              // 000000092DC4: 567CD94C
	s_waitcnt lgkmcnt(6)                                       // 000000092DC8: BF89FC67
	v_fmac_f32_e32 v62, v83, v109                              // 000000092DCC: 567CDB53
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092DD0: BF870091
	v_fmac_f32_e32 v62, v84, v110                              // 000000092DD4: 567CDD54
	v_dual_fmac_f32 v62, v63, v77 :: v_dual_mov_b32 v63, v1    // 000000092DD8: C8109B3F 3E3E0101
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000092DE0: BF8700D1
	v_fmac_f32_e32 v62, v64, v78                               // 000000092DE4: 567C9D40
	ds_load_b32 v64, v46 offset:17440                          // 000000092DE8: D8D84420 4000002E
	v_dual_mov_b32 v47, v43 :: v_dual_mov_b32 v46, v42         // 000000092DF0: CA10012B 2F2E012A
	s_waitcnt lgkmcnt(4)                                       // 000000092DF8: BF89FC47
	v_fmac_f32_e32 v62, v65, v79                               // 000000092DFC: 567C9F41
	v_fmac_f32_e32 v62, v66, v80                               // 000000092E00: 567CA142
	s_waitcnt lgkmcnt(3)                                       // 000000092E04: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092E08: BF870091
	v_fmac_f32_e32 v62, v69, v81                               // 000000092E0C: 567CA345
	v_fmac_f32_e32 v62, v70, v82                               // 000000092E10: 567CA546
	s_waitcnt lgkmcnt(1)                                       // 000000092E14: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000092E18: BF870091
	v_fmac_f32_e32 v62, v73, v85                               // 000000092E1C: 567CAB49
	v_fmac_f32_e32 v62, v74, v86                               // 000000092E20: 567CAD4A
	s_waitcnt lgkmcnt(0)                                       // 000000092E24: BF89FC07
	s_delay_alu instid0(VALU_DEP_1)                            // 000000092E28: BF870001
	v_mul_f32_e32 v62, v62, v64                                // 000000092E2C: 107C813E
	v_mov_b32_e32 v64, v48                                     // 000000092E30: 7E800330
	s_nop 0                                                    // 000000092E34: BF800000
	s_nop 0                                                    // 000000092E38: BF800000
	s_nop 0                                                    // 000000092E3C: BF800000
	global_load_b32 v65, v[46:47], off                         // 000000092E40: DC520000 417C002E
	ds_load_b32 v66, v63 offset:8704                           // 000000092E48: D8D82200 4200003F
	v_add_nc_u32_e32 v64, -1, v64                              // 000000092E50: 4A8080C1
	.long 0xd700012e                                           // 000000092E54: D700012E
	v_cndmask_b32_e32 v0, v46, v132, vcc_lo                    // 000000092E58: 0201092E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000092E5C: BF870191
	v_add_co_ci_u32_e64 v47, null, 0, v47, s1                  // 000000092E60: D5207C2F 00065E80
	.long 0xd44a0004                                           // 000000092E68: D44A0004
	v_cndmask_b32_e32 v1, 0, v64, vcc_lo                       // 000000092E6C: 02028080
	v_add_nc_u32_e32 v63, 0x44, v63                            // 000000092E70: 4A7E7EFF 00000044
	s_or_b32 s12, s4, s12                                      // 000000092E78: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000092E7C: BF890007
	v_fmac_f32_e32 v62, v65, v66                               // 000000092E80: 567C8541
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000092E84: 917E0C7E
	s_cbranch_execnz 65517                                     // 000000092E88: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2740>
	s_or_b32 exec_lo, exec_lo, s12                             // 000000092E8C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000092E90: BF870121
	v_bfe_u32 v63, v62, 16, 1                                  // 000000092E94: D610003F 0205213E
	v_mad_u64_u32 v[46:47], null, 0x3000, v49, v[4:5]          // 000000092E9C: D6FE7C2E 041262FF 00003000
	v_add3_u32 v49, v62, v63, 0x7fff                           // 000000092EA8: D6550031 03FE7F3E 00007FFF
	global_store_d16_hi_b16 v[46:47], v49, off                 // 000000092EB4: DC960000 007C312E
	s_branch 64901                                             // 000000092EBC: BFA0FD85 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dd4>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 000000092EC0: A201FF06 3FB8AA3B
	v_mov_b32_e32 v44, v51                                     // 000000092EC8: 7E580333
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000092ECC: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 000000092ED0: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 000000092ED8: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 000000092EDC: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 000000092EE4: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 000000092EEC: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 000000092EF0: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 000000092EF4: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 000000092EFC: A0010401
	s_mov_b32 s4, 0                                            // 000000092F00: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 000000092F04: BF87000A
	v_exp_f32_e32 v42, s1                                      // 000000092F08: 7E544A01
	s_cvt_i32_f32 s1, s7                                       // 000000092F0C: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000092F10: BF870585
	.long 0xd71c002a                                           // 000000092F14: D71C002A
	v_cndmask_b32_e32 v0, v42, v1, vcc_lo                      // 000000092F18: 0200032A
	s_cselect_b32 s1, -1, 0                                    // 000000092F1C: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 000000092F20: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000092F28: BF870131
	v_cndmask_b32_e64 v43, 0, v42, s1                          // 000000092F2C: D501002B 00065480
	s_cselect_b32 s1, -1, 0                                    // 000000092F34: 980180C1
	v_mov_b32_e32 v42, v50                                     // 000000092F38: 7E540332
	v_cndmask_b32_e64 v43, 0x7f800000, v43, s1                 // 000000092F3C: D501002B 000656FF 7F800000
	ds_load_b32 v45, v42                                       // 000000092F48: D8D80000 2D00002A
	v_add_nc_u32_e32 v44, 0x80, v44                            // 000000092F50: 4A5858FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000092F58: BF870001
	.long 0xd4490001                                           // 000000092F5C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v44, vcc_lo                   // 000000092F60: 020258FF 0000077F
	s_or_b32 s4, s1, s4                                        // 000000092F68: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 000000092F6C: BF89FC07
	v_mul_f32_e32 v45, v43, v45                                // 000000092F70: 105A5B2B
	ds_store_b32 v42, v45                                      // 000000092F74: D8340000 00002D2A
	v_add_nc_u32_e32 v42, 0x220, v42                           // 000000092F7C: 4A5454FF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000092F84: 917E047E
	s_cbranch_execnz 65519                                     // 000000092F88: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2848>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000092F8C: 8C7E047E
	v_dual_mov_b32 v43, v27 :: v_dual_mov_b32 v42, v26         // 000000092F90: CA10011B 2B2A011A
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v45, v53           // 000000092F98: CA100080 2C2C0135
	v_mov_b32_e32 v46, v51                                     // 000000092FA0: 7E5C0333
	s_mov_b32 s6, 0                                            // 000000092FA4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000092FA8: BF89FC07
	s_barrier                                                  // 000000092FAC: BFBD0000
	buffer_gl0_inv                                             // 000000092FB0: E0AC0000 00000000
	s_nop 0                                                    // 000000092FB8: BF800000
	s_nop 0                                                    // 000000092FBC: BF800000
	global_load_b32 v47, v[42:43], off                         // 000000092FC0: DC520000 2F7C002A
	ds_load_b32 v48, v44 offset:17184                          // 000000092FC8: D8D84320 3000002C
	v_add_nc_u32_e32 v46, 0x80, v46                            // 000000092FD0: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 000000092FD8: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000092FDC: 020254FF 00006000
	v_add_nc_u32_e32 v44, 4, v44                               // 000000092FE4: 4A585884
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000092FE8: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 000000092FF0: BF870004
	.long 0xd4490004                                           // 000000092FF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 000000092FF8: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000093000: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000093004: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 000000093008: 105E612F
	ds_store_b32 v45, v47 offset:13056                         // 00000009300C: D8343300 00002F2D
	v_add_nc_u32_e32 v45, 0x204, v45                           // 000000093014: 4A5A5AFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000009301C: 917E067E
	s_cbranch_execnz 65511                                     // 000000093020: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x28c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000093024: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000093028: BF89FC07
	s_barrier                                                  // 00000009302C: BFBD0000
	buffer_gl0_inv                                             // 000000093030: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v61 offset1:17                 // 000000093038: D8DC1100 2A00003D
	ds_load_2addr_b32 v[44:45], v61 offset0:34 offset1:51      // 000000093040: D8DC3322 2C00003D
	ds_load_2addr_b32 v[46:47], v61 offset0:68 offset1:85      // 000000093048: D8DC5544 2E00003D
	ds_load_2addr_b32 v[48:49], v61 offset0:102 offset1:119    // 000000093050: D8DC7766 3000003D
	v_mov_b32_e32 v62, v0                                      // 000000093058: 7E7C0300
	s_mov_b32 s4, 0                                            // 00000009305C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000093060: BF840001
	s_nop 0                                                    // 000000093064: BF800000
	s_nop 0                                                    // 000000093068: BF800000
	s_nop 0                                                    // 00000009306C: BF800000
	s_nop 0                                                    // 000000093070: BF800000
	s_nop 0                                                    // 000000093074: BF800000
	s_nop 0                                                    // 000000093078: BF800000
	s_nop 0                                                    // 00000009307C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000093080: BF870121
	v_lshrrev_b32_e32 v63, 4, v62                              // 000000093084: 327E7C84
	.long 0xd4490001                                           // 000000093088: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v62, vcc_lo                   // 00000009308C: 02027CFF 0000077F
	v_lshlrev_b32_e32 v70, 2, v63                              // 000000093094: 308C7E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 000000093098: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000930A4: 8C040401
	v_add_nc_u32_e32 v64, 0x3200, v70                          // 0000000930A8: 4A808CFF 00003200
	v_add_nc_u32_e32 v66, 0x3600, v70                          // 0000000930B0: 4A848CFF 00003600
	v_add_nc_u32_e32 v68, 0x3a00, v70                          // 0000000930B8: 4A888CFF 00003A00
	ds_load_b32 v71, v63                                       // 0000000930C0: D8D80000 4700003F
	ds_load_2addr_b32 v[64:65], v64 offset0:64 offset1:193     // 0000000930C8: D8DCC140 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:66 offset1:195     // 0000000930D0: D8DCC342 42000042
	ds_load_2addr_b32 v[68:69], v68 offset0:68 offset1:197     // 0000000930D8: D8DCC544 44000044
	s_waitcnt lgkmcnt(2)                                       // 0000000930E0: BF89FC27
	v_fmac_f32_e32 v71, v64, v42                               // 0000000930E4: 568E5540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000930E8: BF8700C1
	v_dual_fmac_f32 v71, v65, v43 :: v_dual_add_nc_u32 v64, 0x3e00, v70// 0000000930EC: C8205741 47408CFF 00003E00
	ds_load_2addr_b32 v[64:65], v64 offset0:70 offset1:199     // 0000000930F8: D8DCC746 40000040
	s_waitcnt lgkmcnt(2)                                       // 000000093100: BF89FC27
	v_fmac_f32_e32 v71, v66, v44                               // 000000093104: 568E5942
	v_fmac_f32_e32 v71, v67, v45                               // 000000093108: 568E5B43
	s_waitcnt lgkmcnt(1)                                       // 00000009310C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000093110: BF870091
	v_fmac_f32_e32 v71, v68, v46                               // 000000093114: 568E5D44
	v_fmac_f32_e32 v71, v69, v47                               // 000000093118: 568E5F45
	s_waitcnt lgkmcnt(0)                                       // 00000009311C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000093120: BF870091
	v_dual_fmac_f32 v71, v64, v48 :: v_dual_add_nc_u32 v64, 0x80, v62// 000000093124: C8206140 47407CFF 00000080
	v_dual_fmac_f32 v71, v65, v49 :: v_dual_mov_b32 v62, v64   // 000000093130: C8106341 473E0140
	ds_store_b32 v63, v71                                      // 000000093138: D8340000 0000473F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000093140: 917E047E
	s_cbranch_execnz 65486                                     // 000000093144: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2980>
	s_set_inst_prefetch_distance 0x2                           // 000000093148: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000009314C: 8C7E047E
	v_dual_mov_b32 v43, v29 :: v_dual_mov_b32 v42, v28         // 000000093150: CA10011D 2B2A011C
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, 0           // 000000093158: CA100135 2C2C0080
	v_mov_b32_e32 v46, v51                                     // 000000093160: 7E5C0333
	s_mov_b32 s6, 0                                            // 000000093164: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000093168: BF89FC07
	s_barrier                                                  // 00000009316C: BFBD0000
	buffer_gl0_inv                                             // 000000093170: E0AC0000 00000000
	s_nop 0                                                    // 000000093178: BF800000
	s_nop 0                                                    // 00000009317C: BF800000
	global_load_b32 v47, v[42:43], off                         // 000000093180: DC520000 2F7C002A
	ds_load_b32 v48, v45 offset:17216                          // 000000093188: D8D84340 3000002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 000000093190: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 000000093198: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000009319C: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 0000000931A4: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 0000000931A8: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000931B0: BF870004
	.long 0xd4490004                                           // 0000000931B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 0000000931B8: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 0000000931C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000931C4: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 0000000931C8: 105E612F
	ds_store_b32 v44, v47 offset:13056                         // 0000000931CC: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 0000000931D4: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000931DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000000931E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2a80>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000931E4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000000931E8: BF89FC07
	s_barrier                                                  // 0000000931EC: BFBD0000
	buffer_gl0_inv                                             // 0000000931F0: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v61 offset0:136 offset1:153    // 0000000931F8: D8DC9988 2A00003D
	ds_load_2addr_b32 v[44:45], v61 offset0:170 offset1:187    // 000000093200: D8DCBBAA 2C00003D
	ds_load_2addr_b32 v[46:47], v61 offset0:204 offset1:221    // 000000093208: D8DCDDCC 2E00003D
	ds_load_2addr_b32 v[48:49], v61 offset0:238 offset1:255    // 000000093210: D8DCFFEE 3000003D
	v_mov_b32_e32 v62, v0                                      // 000000093218: 7E7C0300
	s_mov_b32 s4, 0                                            // 00000009321C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000093220: BF840001
	s_nop 0                                                    // 000000093224: BF800000
	s_nop 0                                                    // 000000093228: BF800000
	s_nop 0                                                    // 00000009322C: BF800000
	s_nop 0                                                    // 000000093230: BF800000
	s_nop 0                                                    // 000000093234: BF800000
	s_nop 0                                                    // 000000093238: BF800000
	s_nop 0                                                    // 00000009323C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000093240: BF870121
	v_lshrrev_b32_e32 v63, 4, v62                              // 000000093244: 327E7C84
	.long 0xd4490001                                           // 000000093248: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v62, vcc_lo                   // 00000009324C: 02027CFF 0000077F
	v_lshlrev_b32_e32 v70, 2, v63                              // 000000093254: 308C7E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 000000093258: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000093264: 8C040401
	v_add_nc_u32_e32 v64, 0x3200, v70                          // 000000093268: 4A808CFF 00003200
	v_add_nc_u32_e32 v66, 0x3600, v70                          // 000000093270: 4A848CFF 00003600
	v_add_nc_u32_e32 v68, 0x3a00, v70                          // 000000093278: 4A888CFF 00003A00
	ds_load_b32 v71, v63                                       // 000000093280: D8D80000 4700003F
	ds_load_2addr_b32 v[64:65], v64 offset0:64 offset1:193     // 000000093288: D8DCC140 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:66 offset1:195     // 000000093290: D8DCC342 42000042
	ds_load_2addr_b32 v[68:69], v68 offset0:68 offset1:197     // 000000093298: D8DCC544 44000044
	s_waitcnt lgkmcnt(2)                                       // 0000000932A0: BF89FC27
	v_fmac_f32_e32 v71, v64, v42                               // 0000000932A4: 568E5540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000932A8: BF8700C1
	v_dual_fmac_f32 v71, v65, v43 :: v_dual_add_nc_u32 v64, 0x3e00, v70// 0000000932AC: C8205741 47408CFF 00003E00
	ds_load_2addr_b32 v[64:65], v64 offset0:70 offset1:199     // 0000000932B8: D8DCC746 40000040
	s_waitcnt lgkmcnt(2)                                       // 0000000932C0: BF89FC27
	v_fmac_f32_e32 v71, v66, v44                               // 0000000932C4: 568E5942
	v_fmac_f32_e32 v71, v67, v45                               // 0000000932C8: 568E5B43
	s_waitcnt lgkmcnt(1)                                       // 0000000932CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000932D0: BF870091
	v_fmac_f32_e32 v71, v68, v46                               // 0000000932D4: 568E5D44
	v_fmac_f32_e32 v71, v69, v47                               // 0000000932D8: 568E5F45
	s_waitcnt lgkmcnt(0)                                       // 0000000932DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000932E0: BF870091
	v_dual_fmac_f32 v71, v64, v48 :: v_dual_add_nc_u32 v64, 0x80, v62// 0000000932E4: C8206140 47407CFF 00000080
	v_dual_fmac_f32 v71, v65, v49 :: v_dual_mov_b32 v62, v64   // 0000000932F0: C8106341 473E0140
	ds_store_b32 v63, v71                                      // 0000000932F8: D8340000 0000473F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000093300: 917E047E
	s_cbranch_execnz 65486                                     // 000000093304: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2b40>
	s_set_inst_prefetch_distance 0x2                           // 000000093308: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000009330C: 8C7E047E
	v_dual_mov_b32 v43, v31 :: v_dual_mov_b32 v42, v30         // 000000093310: CA10011F 2B2A011E
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, 0           // 000000093318: CA100135 2C2C0080
	v_mov_b32_e32 v46, v51                                     // 000000093320: 7E5C0333
	s_mov_b32 s6, 0                                            // 000000093324: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000093328: BF89FC07
	s_barrier                                                  // 00000009332C: BFBD0000
	buffer_gl0_inv                                             // 000000093330: E0AC0000 00000000
	s_nop 0                                                    // 000000093338: BF800000
	s_nop 0                                                    // 00000009333C: BF800000
	global_load_b32 v47, v[42:43], off                         // 000000093340: DC520000 2F7C002A
	ds_load_b32 v48, v45 offset:17248                          // 000000093348: D8D84360 3000002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 000000093350: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 000000093358: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000009335C: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 000000093364: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000093368: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 000000093370: BF870004
	.long 0xd4490004                                           // 000000093374: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 000000093378: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000093380: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000093384: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 000000093388: 105E612F
	ds_store_b32 v44, v47 offset:13056                         // 00000009338C: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000093394: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000009339C: 917E067E
	s_cbranch_execnz 65511                                     // 0000000933A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2c40>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000933A4: 8C7E067E
	v_add_nc_u32_e32 v62, 0x400, v61                           // 0000000933A8: 4A7C7AFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000933B0: BF89FC07
	s_barrier                                                  // 0000000933B4: BFBD0000
	buffer_gl0_inv                                             // 0000000933B8: E0AC0000 00000000
	v_mov_b32_e32 v63, v0                                      // 0000000933C0: 7E7E0300
	ds_load_2addr_b32 v[42:43], v62 offset0:16 offset1:33      // 0000000933C4: D8DC2110 2A00003E
	ds_load_2addr_b32 v[44:45], v62 offset0:50 offset1:67      // 0000000933CC: D8DC4332 2C00003E
	ds_load_2addr_b32 v[46:47], v62 offset0:84 offset1:101     // 0000000933D4: D8DC6554 2E00003E
	ds_load_2addr_b32 v[48:49], v62 offset0:118 offset1:135    // 0000000933DC: D8DC8776 3000003E
	s_mov_b32 s4, 0                                            // 0000000933E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000933E8: BF840001
	s_nop 0                                                    // 0000000933EC: BF800000
	s_nop 0                                                    // 0000000933F0: BF800000
	s_nop 0                                                    // 0000000933F4: BF800000
	s_nop 0                                                    // 0000000933F8: BF800000
	s_nop 0                                                    // 0000000933FC: BF800000
	v_lshrrev_b32_e32 v64, 4, v63                              // 000000093400: 32807E84
	.long 0xd4490001                                           // 000000093404: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v63, vcc_lo                   // 000000093408: 02027EFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000093410: BF870002
	v_lshlrev_b32_e32 v71, 2, v64                              // 000000093414: 308E8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 000000093418: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 000000093424: 8C040401
	v_add_nc_u32_e32 v65, 0x3200, v71                          // 000000093428: 4A828EFF 00003200
	v_add_nc_u32_e32 v67, 0x3600, v71                          // 000000093430: 4A868EFF 00003600
	v_add_nc_u32_e32 v69, 0x3a00, v71                          // 000000093438: 4A8A8EFF 00003A00
	ds_load_b32 v72, v64                                       // 000000093440: D8D80000 48000040
	ds_load_2addr_b32 v[65:66], v65 offset0:64 offset1:193     // 000000093448: D8DCC140 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:66 offset1:195     // 000000093450: D8DCC342 43000043
	ds_load_2addr_b32 v[69:70], v69 offset0:68 offset1:197     // 000000093458: D8DCC544 45000045
	s_waitcnt lgkmcnt(2)                                       // 000000093460: BF89FC27
	v_dual_fmac_f32 v72, v65, v42 :: v_dual_add_nc_u32 v65, 0x3e00, v71// 000000093464: C8205541 48408EFF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000093470: BF8700C1
	v_fmac_f32_e32 v72, v66, v43                               // 000000093474: 56905742
	ds_load_2addr_b32 v[65:66], v65 offset0:70 offset1:199     // 000000093478: D8DCC746 41000041
	s_waitcnt lgkmcnt(2)                                       // 000000093480: BF89FC27
	v_fmac_f32_e32 v72, v67, v44                               // 000000093484: 56905943
	v_fmac_f32_e32 v72, v68, v45                               // 000000093488: 56905B44
	s_waitcnt lgkmcnt(1)                                       // 00000009348C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000093490: BF870091
	v_fmac_f32_e32 v72, v69, v46                               // 000000093494: 56905D45
	v_fmac_f32_e32 v72, v70, v47                               // 000000093498: 56905F46
	s_waitcnt lgkmcnt(0)                                       // 00000009349C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000934A0: BF870091
	v_dual_fmac_f32 v72, v65, v48 :: v_dual_add_nc_u32 v65, 0x80, v63// 0000000934A4: C8206141 48407EFF 00000080
	v_dual_fmac_f32 v72, v66, v49 :: v_dual_mov_b32 v63, v65   // 0000000934B0: C8106342 483E0141
	ds_store_b32 v64, v72                                      // 0000000934B8: D8340000 00004840
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000934C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000934C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2d00>
	s_set_inst_prefetch_distance 0x2                           // 0000000934C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000934CC: 8C7E047E
	v_dual_mov_b32 v43, v33 :: v_dual_mov_b32 v42, v32         // 0000000934D0: CA100121 2B2A0120
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, 0           // 0000000934D8: CA100135 2C2C0080
	v_mov_b32_e32 v46, v51                                     // 0000000934E0: 7E5C0333
	s_mov_b32 s6, 0                                            // 0000000934E4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000934E8: BF89FC07
	s_barrier                                                  // 0000000934EC: BFBD0000
	buffer_gl0_inv                                             // 0000000934F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000934F8: BF800000
	s_nop 0                                                    // 0000000934FC: BF800000
	global_load_b32 v47, v[42:43], off                         // 000000093500: DC520000 2F7C002A
	ds_load_b32 v48, v45 offset:17280                          // 000000093508: D8D84380 3000002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 000000093510: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 000000093518: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000009351C: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 000000093524: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000093528: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 000000093530: BF870004
	.long 0xd4490004                                           // 000000093534: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 000000093538: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000093540: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000093544: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 000000093548: 105E612F
	ds_store_b32 v44, v47 offset:13056                         // 00000009354C: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000093554: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000009355C: 917E067E
	s_cbranch_execnz 65511                                     // 000000093560: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2e00>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000093564: 8C7E067E
	v_add_nc_u32_e32 v48, 0x600, v61                           // 000000093568: 4A607AFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 000000093570: BF89FC07
	s_barrier                                                  // 000000093574: BFBD0000
	buffer_gl0_inv                                             // 000000093578: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v62 offset0:152 offset1:169    // 000000093580: D8DCA998 2A00003E
	ds_load_2addr_b32 v[44:45], v62 offset0:186 offset1:203    // 000000093588: D8DCCBBA 2C00003E
	ds_load_2addr_b32 v[46:47], v62 offset0:220 offset1:237    // 000000093590: D8DCEDDC 2E00003E
	ds_load_2addr_b32 v[48:49], v48 offset0:126 offset1:143    // 000000093598: D8DC8F7E 30000030
	v_mov_b32_e32 v62, v0                                      // 0000000935A0: 7E7C0300
	s_mov_b32 s4, 0                                            // 0000000935A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000935A8: BF840001
	s_nop 0                                                    // 0000000935AC: BF800000
	s_nop 0                                                    // 0000000935B0: BF800000
	s_nop 0                                                    // 0000000935B4: BF800000
	s_nop 0                                                    // 0000000935B8: BF800000
	s_nop 0                                                    // 0000000935BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000935C0: BF870121
	v_lshrrev_b32_e32 v63, 4, v62                              // 0000000935C4: 327E7C84
	.long 0xd4490001                                           // 0000000935C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v62, vcc_lo                   // 0000000935CC: 02027CFF 0000077F
	v_lshlrev_b32_e32 v70, 2, v63                              // 0000000935D4: 308C7E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 0000000935D8: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000935E4: 8C040401
	v_add_nc_u32_e32 v64, 0x3200, v70                          // 0000000935E8: 4A808CFF 00003200
	v_add_nc_u32_e32 v66, 0x3600, v70                          // 0000000935F0: 4A848CFF 00003600
	v_add_nc_u32_e32 v68, 0x3a00, v70                          // 0000000935F8: 4A888CFF 00003A00
	ds_load_b32 v71, v63                                       // 000000093600: D8D80000 4700003F
	ds_load_2addr_b32 v[64:65], v64 offset0:64 offset1:193     // 000000093608: D8DCC140 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:66 offset1:195     // 000000093610: D8DCC342 42000042
	ds_load_2addr_b32 v[68:69], v68 offset0:68 offset1:197     // 000000093618: D8DCC544 44000044
	s_waitcnt lgkmcnt(2)                                       // 000000093620: BF89FC27
	v_fmac_f32_e32 v71, v64, v42                               // 000000093624: 568E5540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000093628: BF8700C1
	v_dual_fmac_f32 v71, v65, v43 :: v_dual_add_nc_u32 v64, 0x3e00, v70// 00000009362C: C8205741 47408CFF 00003E00
	ds_load_2addr_b32 v[64:65], v64 offset0:70 offset1:199     // 000000093638: D8DCC746 40000040
	s_waitcnt lgkmcnt(2)                                       // 000000093640: BF89FC27
	v_fmac_f32_e32 v71, v66, v44                               // 000000093644: 568E5942
	v_fmac_f32_e32 v71, v67, v45                               // 000000093648: 568E5B43
	s_waitcnt lgkmcnt(1)                                       // 00000009364C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000093650: BF870091
	v_fmac_f32_e32 v71, v68, v46                               // 000000093654: 568E5D44
	v_fmac_f32_e32 v71, v69, v47                               // 000000093658: 568E5F45
	s_waitcnt lgkmcnt(0)                                       // 00000009365C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000093660: BF870091
	v_dual_fmac_f32 v71, v64, v48 :: v_dual_add_nc_u32 v64, 0x80, v62// 000000093664: C8206140 47407CFF 00000080
	v_dual_fmac_f32 v71, v65, v49 :: v_dual_mov_b32 v62, v64   // 000000093670: C8106341 473E0140
	ds_store_b32 v63, v71                                      // 000000093678: D8340000 0000473F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000093680: 917E047E
	s_cbranch_execnz 65486                                     // 000000093684: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2ec0>
	s_set_inst_prefetch_distance 0x2                           // 000000093688: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000009368C: 8C7E047E
	v_dual_mov_b32 v43, v35 :: v_dual_mov_b32 v42, v34         // 000000093690: CA100123 2B2A0122
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, 0           // 000000093698: CA100135 2C2C0080
	v_mov_b32_e32 v46, v51                                     // 0000000936A0: 7E5C0333
	s_mov_b32 s6, 0                                            // 0000000936A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000000936A8: BF89FC07
	s_barrier                                                  // 0000000936AC: BFBD0000
	buffer_gl0_inv                                             // 0000000936B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000936B8: BF800000
	s_nop 0                                                    // 0000000936BC: BF800000
	global_load_b32 v47, v[42:43], off                         // 0000000936C0: DC520000 2F7C002A
	ds_load_b32 v48, v45 offset:17312                          // 0000000936C8: D8D843A0 3000002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 0000000936D0: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 0000000936D8: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 0000000936DC: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 0000000936E4: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 0000000936E8: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000936F0: BF870004
	.long 0xd4490004                                           // 0000000936F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 0000000936F8: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000093700: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000093704: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 000000093708: 105E612F
	ds_store_b32 v44, v47 offset:13056                         // 00000009370C: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000093714: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000009371C: 917E067E
	s_cbranch_execnz 65511                                     // 000000093720: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2fc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000093724: 8C7E067E
	v_add_nc_u32_e32 v63, 0x800, v61                           // 000000093728: 4A7E7AFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 000000093730: BF89FC07
	s_barrier                                                  // 000000093734: BFBD0000
	buffer_gl0_inv                                             // 000000093738: E0AC0000 00000000
	v_mov_b32_e32 v62, v0                                      // 000000093740: 7E7C0300
	ds_load_2addr_b32 v[42:43], v63 offset0:32 offset1:49      // 000000093744: D8DC3120 2A00003F
	ds_load_2addr_b32 v[44:45], v63 offset0:66 offset1:83      // 00000009374C: D8DC5342 2C00003F
	ds_load_2addr_b32 v[46:47], v63 offset0:100 offset1:117    // 000000093754: D8DC7564 2E00003F
	ds_load_2addr_b32 v[48:49], v63 offset0:134 offset1:151    // 00000009375C: D8DC9786 3000003F
	s_mov_b32 s4, 0                                            // 000000093764: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000093768: BF840001
	s_nop 0                                                    // 00000009376C: BF800000
	s_nop 0                                                    // 000000093770: BF800000
	s_nop 0                                                    // 000000093774: BF800000
	s_nop 0                                                    // 000000093778: BF800000
	s_nop 0                                                    // 00000009377C: BF800000
	v_lshrrev_b32_e32 v64, 4, v62                              // 000000093780: 32807C84
	.long 0xd4490001                                           // 000000093784: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v62, vcc_lo                   // 000000093788: 02027CFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000093790: BF870002
	v_lshlrev_b32_e32 v71, 2, v64                              // 000000093794: 308E8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 000000093798: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000937A4: 8C040401
	v_add_nc_u32_e32 v65, 0x3200, v71                          // 0000000937A8: 4A828EFF 00003200
	v_add_nc_u32_e32 v67, 0x3600, v71                          // 0000000937B0: 4A868EFF 00003600
	v_add_nc_u32_e32 v69, 0x3a00, v71                          // 0000000937B8: 4A8A8EFF 00003A00
	ds_load_b32 v72, v64                                       // 0000000937C0: D8D80000 48000040
	ds_load_2addr_b32 v[65:66], v65 offset0:64 offset1:193     // 0000000937C8: D8DCC140 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:66 offset1:195     // 0000000937D0: D8DCC342 43000043
	ds_load_2addr_b32 v[69:70], v69 offset0:68 offset1:197     // 0000000937D8: D8DCC544 45000045
	s_waitcnt lgkmcnt(2)                                       // 0000000937E0: BF89FC27
	v_dual_fmac_f32 v72, v65, v42 :: v_dual_add_nc_u32 v65, 0x3e00, v71// 0000000937E4: C8205541 48408EFF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000937F0: BF8700C1
	v_fmac_f32_e32 v72, v66, v43                               // 0000000937F4: 56905742
	ds_load_2addr_b32 v[65:66], v65 offset0:70 offset1:199     // 0000000937F8: D8DCC746 41000041
	s_waitcnt lgkmcnt(2)                                       // 000000093800: BF89FC27
	v_fmac_f32_e32 v72, v67, v44                               // 000000093804: 56905943
	v_fmac_f32_e32 v72, v68, v45                               // 000000093808: 56905B44
	s_waitcnt lgkmcnt(1)                                       // 00000009380C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000093810: BF870091
	v_fmac_f32_e32 v72, v69, v46                               // 000000093814: 56905D45
	v_fmac_f32_e32 v72, v70, v47                               // 000000093818: 56905F46
	s_waitcnt lgkmcnt(0)                                       // 00000009381C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000093820: BF870091
	v_dual_fmac_f32 v72, v65, v48 :: v_dual_add_nc_u32 v65, 0x80, v62// 000000093824: C8206141 48407CFF 00000080
	v_fmac_f32_e32 v72, v66, v49                               // 000000093830: 56906342
	s_delay_alu instid0(VALU_DEP_2)                            // 000000093834: BF870002
	v_mov_b32_e32 v62, v65                                     // 000000093838: 7E7C0341
	ds_store_b32 v64, v72                                      // 00000009383C: D8340000 00004840
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000093844: 917E047E
	s_cbranch_execnz 65485                                     // 000000093848: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3080>
	s_set_inst_prefetch_distance 0x2                           // 00000009384C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000093850: 8C7E047E
	v_dual_mov_b32 v43, v37 :: v_dual_mov_b32 v42, v36         // 000000093854: CA100125 2B2A0124
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, 0           // 00000009385C: CA100135 2C2C0080
	v_mov_b32_e32 v46, v51                                     // 000000093864: 7E5C0333
	s_mov_b32 s6, 0                                            // 000000093868: BE860080
	s_waitcnt lgkmcnt(0)                                       // 00000009386C: BF89FC07
	s_barrier                                                  // 000000093870: BFBD0000
	buffer_gl0_inv                                             // 000000093874: E0AC0000 00000000
	s_nop 0                                                    // 00000009387C: BF800000
	global_load_b32 v47, v[42:43], off                         // 000000093880: DC520000 2F7C002A
	ds_load_b32 v48, v45 offset:17344                          // 000000093888: D8D843C0 3000002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 000000093890: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 000000093898: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 00000009389C: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 0000000938A4: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 0000000938A8: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000938B0: BF870004
	.long 0xd4490004                                           // 0000000938B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 0000000938B8: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 0000000938C0: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000938C4: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 0000000938C8: 105E612F
	ds_store_b32 v44, v47 offset:13056                         // 0000000938CC: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 0000000938D4: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000000938DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000000938E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3180>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000000938E4: 8C7E067E
	v_add_nc_u32_e32 v62, 0xc00, v61                           // 0000000938E8: 4A7C7AFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 0000000938F0: BF89FC07
	s_barrier                                                  // 0000000938F4: BFBD0000
	buffer_gl0_inv                                             // 0000000938F8: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v63 offset0:168 offset1:185    // 000000093900: D8DCB9A8 2A00003F
	ds_load_2addr_b32 v[44:45], v63 offset0:202 offset1:219    // 000000093908: D8DCDBCA 2C00003F
	ds_load_2addr_b32 v[46:47], v63 offset0:236 offset1:253    // 000000093910: D8DCFDEC 2E00003F
	ds_load_2addr_b32 v[48:49], v62 offset0:14 offset1:31      // 000000093918: D8DC1F0E 3000003E
	v_mov_b32_e32 v63, v0                                      // 000000093920: 7E7E0300
	s_mov_b32 s4, 0                                            // 000000093924: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000093928: BF840001
	s_nop 0                                                    // 00000009392C: BF800000
	s_nop 0                                                    // 000000093930: BF800000
	s_nop 0                                                    // 000000093934: BF800000
	s_nop 0                                                    // 000000093938: BF800000
	s_nop 0                                                    // 00000009393C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000093940: BF870121
	v_lshrrev_b32_e32 v64, 4, v63                              // 000000093944: 32807E84
	.long 0xd4490001                                           // 000000093948: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v63, vcc_lo                   // 00000009394C: 02027EFF 0000077F
	v_lshlrev_b32_e32 v71, 2, v64                              // 000000093954: 308E8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 000000093958: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 000000093964: 8C040401
	v_add_nc_u32_e32 v65, 0x3200, v71                          // 000000093968: 4A828EFF 00003200
	v_add_nc_u32_e32 v67, 0x3600, v71                          // 000000093970: 4A868EFF 00003600
	v_add_nc_u32_e32 v69, 0x3a00, v71                          // 000000093978: 4A8A8EFF 00003A00
	ds_load_b32 v72, v64                                       // 000000093980: D8D80000 48000040
	ds_load_2addr_b32 v[65:66], v65 offset0:64 offset1:193     // 000000093988: D8DCC140 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:66 offset1:195     // 000000093990: D8DCC342 43000043
	ds_load_2addr_b32 v[69:70], v69 offset0:68 offset1:197     // 000000093998: D8DCC544 45000045
	s_waitcnt lgkmcnt(2)                                       // 0000000939A0: BF89FC27
	v_dual_fmac_f32 v72, v65, v42 :: v_dual_add_nc_u32 v65, 0x3e00, v71// 0000000939A4: C8205541 48408EFF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000939B0: BF8700C1
	v_fmac_f32_e32 v72, v66, v43                               // 0000000939B4: 56905742
	ds_load_2addr_b32 v[65:66], v65 offset0:70 offset1:199     // 0000000939B8: D8DCC746 41000041
	s_waitcnt lgkmcnt(2)                                       // 0000000939C0: BF89FC27
	v_fmac_f32_e32 v72, v67, v44                               // 0000000939C4: 56905943
	v_fmac_f32_e32 v72, v68, v45                               // 0000000939C8: 56905B44
	s_waitcnt lgkmcnt(1)                                       // 0000000939CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000939D0: BF870091
	v_fmac_f32_e32 v72, v69, v46                               // 0000000939D4: 56905D45
	v_fmac_f32_e32 v72, v70, v47                               // 0000000939D8: 56905F46
	s_waitcnt lgkmcnt(0)                                       // 0000000939DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000939E0: BF870091
	v_dual_fmac_f32 v72, v65, v48 :: v_dual_add_nc_u32 v65, 0x80, v63// 0000000939E4: C8206141 48407EFF 00000080
	v_dual_fmac_f32 v72, v66, v49 :: v_dual_mov_b32 v63, v65   // 0000000939F0: C8106342 483E0141
	ds_store_b32 v64, v72                                      // 0000000939F8: D8340000 00004840
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000093A00: 917E047E
	s_cbranch_execnz 65486                                     // 000000093A04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3240>
	s_set_inst_prefetch_distance 0x2                           // 000000093A08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000093A0C: 8C7E047E
	v_dual_mov_b32 v43, v39 :: v_dual_mov_b32 v42, v38         // 000000093A10: CA100127 2B2A0126
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, 0           // 000000093A18: CA100135 2C2C0080
	v_mov_b32_e32 v46, v51                                     // 000000093A20: 7E5C0333
	s_mov_b32 s6, 0                                            // 000000093A24: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000093A28: BF89FC07
	s_barrier                                                  // 000000093A2C: BFBD0000
	buffer_gl0_inv                                             // 000000093A30: E0AC0000 00000000
	s_nop 0                                                    // 000000093A38: BF800000
	s_nop 0                                                    // 000000093A3C: BF800000
	global_load_b32 v47, v[42:43], off                         // 000000093A40: DC520000 2F7C002A
	ds_load_b32 v48, v45 offset:17376                          // 000000093A48: D8D843E0 3000002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 000000093A50: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 000000093A58: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000093A5C: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 000000093A64: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000093A68: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 000000093A70: BF870004
	.long 0xd4490004                                           // 000000093A74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 000000093A78: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000093A80: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000093A84: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 000000093A88: 105E612F
	ds_store_b32 v44, v47 offset:13056                         // 000000093A8C: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000093A94: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000093A9C: 917E067E
	s_cbranch_execnz 65511                                     // 000000093AA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3340>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000093AA4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000093AA8: BF89FC07
	s_barrier                                                  // 000000093AAC: BFBD0000
	buffer_gl0_inv                                             // 000000093AB0: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v62 offset0:48 offset1:65      // 000000093AB8: D8DC4130 2A00003E
	ds_load_2addr_b32 v[44:45], v62 offset0:82 offset1:99      // 000000093AC0: D8DC6352 2C00003E
	ds_load_2addr_b32 v[46:47], v62 offset0:116 offset1:133    // 000000093AC8: D8DC8574 2E00003E
	ds_load_2addr_b32 v[48:49], v62 offset0:150 offset1:167    // 000000093AD0: D8DCA796 3000003E
	v_mov_b32_e32 v63, v0                                      // 000000093AD8: 7E7E0300
	s_mov_b32 s4, 0                                            // 000000093ADC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000093AE0: BF840001
	s_nop 0                                                    // 000000093AE4: BF800000
	s_nop 0                                                    // 000000093AE8: BF800000
	s_nop 0                                                    // 000000093AEC: BF800000
	s_nop 0                                                    // 000000093AF0: BF800000
	s_nop 0                                                    // 000000093AF4: BF800000
	s_nop 0                                                    // 000000093AF8: BF800000
	s_nop 0                                                    // 000000093AFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000093B00: BF870121
	v_lshrrev_b32_e32 v64, 4, v63                              // 000000093B04: 32807E84
	.long 0xd4490001                                           // 000000093B08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v63, vcc_lo                   // 000000093B0C: 02027EFF 0000077F
	v_lshlrev_b32_e32 v71, 2, v64                              // 000000093B14: 308E8082
	v_mad_u64_u32 v[64:65], null, 0x44, v64, v[1:2]            // 000000093B18: D6FE7C40 040680FF 00000044
	s_or_b32 s4, s1, s4                                        // 000000093B24: 8C040401
	v_add_nc_u32_e32 v65, 0x3200, v71                          // 000000093B28: 4A828EFF 00003200
	v_add_nc_u32_e32 v67, 0x3600, v71                          // 000000093B30: 4A868EFF 00003600
	v_add_nc_u32_e32 v69, 0x3a00, v71                          // 000000093B38: 4A8A8EFF 00003A00
	ds_load_b32 v72, v64                                       // 000000093B40: D8D80000 48000040
	ds_load_2addr_b32 v[65:66], v65 offset0:64 offset1:193     // 000000093B48: D8DCC140 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:66 offset1:195     // 000000093B50: D8DCC342 43000043
	ds_load_2addr_b32 v[69:70], v69 offset0:68 offset1:197     // 000000093B58: D8DCC544 45000045
	s_waitcnt lgkmcnt(2)                                       // 000000093B60: BF89FC27
	v_dual_fmac_f32 v72, v65, v42 :: v_dual_add_nc_u32 v65, 0x3e00, v71// 000000093B64: C8205541 48408EFF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000093B70: BF8700C1
	v_fmac_f32_e32 v72, v66, v43                               // 000000093B74: 56905742
	ds_load_2addr_b32 v[65:66], v65 offset0:70 offset1:199     // 000000093B78: D8DCC746 41000041
	s_waitcnt lgkmcnt(2)                                       // 000000093B80: BF89FC27
	v_fmac_f32_e32 v72, v67, v44                               // 000000093B84: 56905943
	v_fmac_f32_e32 v72, v68, v45                               // 000000093B88: 56905B44
	s_waitcnt lgkmcnt(1)                                       // 000000093B8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000093B90: BF870091
	v_fmac_f32_e32 v72, v69, v46                               // 000000093B94: 56905D45
	v_fmac_f32_e32 v72, v70, v47                               // 000000093B98: 56905F46
	s_waitcnt lgkmcnt(0)                                       // 000000093B9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000093BA0: BF870091
	v_dual_fmac_f32 v72, v65, v48 :: v_dual_add_nc_u32 v65, 0x80, v63// 000000093BA4: C8206141 48407EFF 00000080
	v_dual_fmac_f32 v72, v66, v49 :: v_dual_mov_b32 v63, v65   // 000000093BB0: C8106342 483E0141
	ds_store_b32 v64, v72                                      // 000000093BB8: D8340000 00004840
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000093BC0: 917E047E
	s_cbranch_execnz 65486                                     // 000000093BC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3400>
	s_set_inst_prefetch_distance 0x2                           // 000000093BC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000093BCC: 8C7E047E
	v_dual_mov_b32 v43, v41 :: v_dual_mov_b32 v42, v40         // 000000093BD0: CA100129 2B2A0128
	v_dual_mov_b32 v44, v53 :: v_dual_mov_b32 v45, 0           // 000000093BD8: CA100135 2C2C0080
	v_mov_b32_e32 v46, v51                                     // 000000093BE0: 7E5C0333
	s_mov_b32 s6, 0                                            // 000000093BE4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000093BE8: BF89FC07
	s_barrier                                                  // 000000093BEC: BFBD0000
	buffer_gl0_inv                                             // 000000093BF0: E0AC0000 00000000
	s_nop 0                                                    // 000000093BF8: BF800000
	s_nop 0                                                    // 000000093BFC: BF800000
	global_load_b32 v47, v[42:43], off                         // 000000093C00: DC520000 2F7C002A
	ds_load_b32 v48, v45 offset:17408                          // 000000093C08: D8D84400 3000002D
	v_add_nc_u32_e32 v46, 0x80, v46                            // 000000093C10: 4A5C5CFF 00000080
	.long 0xd700012a                                           // 000000093C18: D700012A
	v_cndmask_b32_e32 v1, 0x6000, v42, vcc_lo                  // 000000093C1C: 020254FF 00006000
	v_add_nc_u32_e32 v45, 4, v45                               // 000000093C24: 4A5A5A84
	v_add_co_ci_u32_e64 v43, null, 0, v43, s1                  // 000000093C28: D5207C2B 00065680
	s_delay_alu instid0(VALU_DEP_4)                            // 000000093C30: BF870004
	.long 0xd4490004                                           // 000000093C34: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v46, vcc_lo                   // 000000093C38: 02025CFF 0000037F
	s_or_b32 s6, s4, s6                                        // 000000093C40: 8C060604
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000093C44: BF890007
	v_mul_f32_e32 v47, v47, v48                                // 000000093C48: 105E612F
	ds_store_b32 v44, v47 offset:13056                         // 000000093C4C: D8343300 00002F2C
	v_add_nc_u32_e32 v44, 0x204, v44                           // 000000093C54: 4A5858FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000093C5C: 917E067E
	s_cbranch_execnz 65511                                     // 000000093C60: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3500>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000093C64: 8C7E067E
	v_add_nc_u32_e32 v46, 0xe00, v61                           // 000000093C68: 4A5C7AFF 00000E00
	v_add_nc_u32_e32 v48, 0x1000, v61                          // 000000093C70: 4A607AFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 000000093C78: BF89FC07
	s_barrier                                                  // 000000093C7C: BFBD0000
	buffer_gl0_inv                                             // 000000093C80: E0AC0000 00000000
	ds_load_2addr_b32 v[42:43], v62 offset0:184 offset1:201    // 000000093C88: D8DCC9B8 2A00003E
	ds_load_2addr_b32 v[44:45], v62 offset0:218 offset1:235    // 000000093C90: D8DCEBDA 2C00003E
	ds_load_2addr_b32 v[46:47], v46 offset0:124 offset1:141    // 000000093C98: D8DC8D7C 2E00002E
	ds_load_2addr_b32 v[48:49], v48 offset0:30 offset1:47      // 000000093CA0: D8DC2F1E 30000030
	v_mov_b32_e32 v62, v0                                      // 000000093CA8: 7E7C0300
	s_mov_b32 s4, 0                                            // 000000093CAC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000093CB0: BF840001
	s_nop 0                                                    // 000000093CB4: BF800000
	s_nop 0                                                    // 000000093CB8: BF800000
	s_nop 0                                                    // 000000093CBC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000093CC0: BF870121
	v_lshrrev_b32_e32 v63, 4, v62                              // 000000093CC4: 327E7C84
	.long 0xd4490001                                           // 000000093CC8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v62, vcc_lo                   // 000000093CCC: 02027CFF 0000077F
	v_lshlrev_b32_e32 v70, 2, v63                              // 000000093CD4: 308C7E82
	v_mad_u64_u32 v[63:64], null, 0x44, v63, v[1:2]            // 000000093CD8: D6FE7C3F 04067EFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000093CE4: 8C040401
	v_add_nc_u32_e32 v64, 0x3200, v70                          // 000000093CE8: 4A808CFF 00003200
	v_add_nc_u32_e32 v66, 0x3600, v70                          // 000000093CF0: 4A848CFF 00003600
	v_add_nc_u32_e32 v68, 0x3a00, v70                          // 000000093CF8: 4A888CFF 00003A00
	ds_load_b32 v71, v63                                       // 000000093D00: D8D80000 4700003F
	ds_load_2addr_b32 v[64:65], v64 offset0:64 offset1:193     // 000000093D08: D8DCC140 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:66 offset1:195     // 000000093D10: D8DCC342 42000042
	ds_load_2addr_b32 v[68:69], v68 offset0:68 offset1:197     // 000000093D18: D8DCC544 44000044
	s_waitcnt lgkmcnt(2)                                       // 000000093D20: BF89FC27
	v_fmac_f32_e32 v71, v64, v42                               // 000000093D24: 568E5540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000093D28: BF8700C1
	v_dual_fmac_f32 v71, v65, v43 :: v_dual_add_nc_u32 v64, 0x3e00, v70// 000000093D2C: C8205741 47408CFF 00003E00
	ds_load_2addr_b32 v[64:65], v64 offset0:70 offset1:199     // 000000093D38: D8DCC746 40000040
	s_waitcnt lgkmcnt(2)                                       // 000000093D40: BF89FC27
	v_fmac_f32_e32 v71, v66, v44                               // 000000093D44: 568E5942
	v_fmac_f32_e32 v71, v67, v45                               // 000000093D48: 568E5B43
	s_waitcnt lgkmcnt(1)                                       // 000000093D4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000093D50: BF870091
	v_fmac_f32_e32 v71, v68, v46                               // 000000093D54: 568E5D44
	v_fmac_f32_e32 v71, v69, v47                               // 000000093D58: 568E5F45
	s_waitcnt lgkmcnt(0)                                       // 000000093D5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000093D60: BF870091
	v_dual_fmac_f32 v71, v64, v48 :: v_dual_add_nc_u32 v64, 0x80, v62// 000000093D64: C8206140 47407CFF 00000080
	v_dual_fmac_f32 v71, v65, v49 :: v_dual_mov_b32 v62, v64   // 000000093D70: C8106341 473E0140
	ds_store_b32 v63, v71                                      // 000000093D78: D8340000 0000473F
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000093D80: 917E047E
	s_cbranch_execnz 65486                                     // 000000093D84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x35c0>
	s_set_inst_prefetch_distance 0x2                           // 000000093D88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000093D8C: 8C7E047E
	.long 0xd7000106                                           // 000000093D90: D7000106
	v_cndmask_b32_e32 v1, 0x180000, v6, vcc_lo                 // 000000093D94: 02020CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000093D9C: BF8700A1
	v_add_co_ci_u32_e64 v7, null, 0, v7, s1                    // 000000093DA0: D5207C07 00060E80
	.long 0xd7000108                                           // 000000093DA8: D7000108
	v_cndmask_b32_e32 v1, 0x180000, v8, vcc_lo                 // 000000093DAC: 020210FF 00180000
	v_add_co_ci_u32_e64 v9, null, 0, v9, s1                    // 000000093DB4: D5207C09 00061280
	.long 0xd700010a                                           // 000000093DBC: D700010A
	v_cndmask_b32_e32 v1, 0x180000, v10, vcc_lo                // 000000093DC0: 020214FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000093DC8: BF8700A1
	v_add_co_ci_u32_e64 v11, null, 0, v11, s1                  // 000000093DCC: D5207C0B 00061680
	.long 0xd700010c                                           // 000000093DD4: D700010C
	v_cndmask_b32_e32 v1, 0x180000, v12, vcc_lo                // 000000093DD8: 020218FF 00180000
	v_add_co_ci_u32_e64 v13, null, 0, v13, s1                  // 000000093DE0: D5207C0D 00061A80
	.long 0xd700010e                                           // 000000093DE8: D700010E
	v_cndmask_b32_e32 v1, 0x180000, v14, vcc_lo                // 000000093DEC: 02021CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000093DF4: BF8700A1
	v_add_co_ci_u32_e64 v15, null, 0, v15, s1                  // 000000093DF8: D5207C0F 00061E80
	.long 0xd7000110                                           // 000000093E00: D7000110
	v_cndmask_b32_e32 v1, 0x180000, v16, vcc_lo                // 000000093E04: 020220FF 00180000
	v_add_co_ci_u32_e64 v17, null, 0, v17, s1                  // 000000093E0C: D5207C11 00062280
	.long 0xd7000112                                           // 000000093E14: D7000112
	v_cndmask_b32_e32 v1, 0x180000, v18, vcc_lo                // 000000093E18: 020224FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000093E20: BF8700A1
	v_add_co_ci_u32_e64 v19, null, 0, v19, s1                  // 000000093E24: D5207C13 00062680
	.long 0xd7000114                                           // 000000093E2C: D7000114
	v_cndmask_b32_e32 v1, 0x180000, v20, vcc_lo                // 000000093E30: 020228FF 00180000
	v_add_co_ci_u32_e64 v21, null, 0, v21, s1                  // 000000093E38: D5207C15 00062A80
	.long 0xd7000116                                           // 000000093E40: D7000116
	v_cndmask_b32_e32 v1, 0x180000, v22, vcc_lo                // 000000093E44: 02022CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000093E4C: BF8700A1
	v_add_co_ci_u32_e64 v23, null, 0, v23, s1                  // 000000093E50: D5207C17 00062E80
	.long 0xd7000118                                           // 000000093E58: D7000118
	v_cndmask_b32_e32 v1, 0xc0000, v24, vcc_lo                 // 000000093E5C: 020230FF 000C0000
	v_add_co_ci_u32_e64 v25, null, 0, v25, s1                  // 000000093E64: D5207C19 00063280
	.long 0xd700011a                                           // 000000093E6C: D700011A
	v_cndmask_b32_e32 v1, 0x180000, v26, vcc_lo                // 000000093E70: 020234FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000093E78: BF8700A1
	v_add_co_ci_u32_e64 v27, null, 0, v27, s1                  // 000000093E7C: D5207C1B 00063680
	.long 0xd700011c                                           // 000000093E84: D700011C
	v_cndmask_b32_e32 v1, 0x180000, v28, vcc_lo                // 000000093E88: 020238FF 00180000
	v_add_co_ci_u32_e64 v29, null, 0, v29, s1                  // 000000093E90: D5207C1D 00063A80
	.long 0xd700011e                                           // 000000093E98: D700011E
	v_cndmask_b32_e32 v1, 0x180000, v30, vcc_lo                // 000000093E9C: 02023CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000093EA4: BF8700A1
	v_add_co_ci_u32_e64 v31, null, 0, v31, s1                  // 000000093EA8: D5207C1F 00063E80
	.long 0xd7000120                                           // 000000093EB0: D7000120
	v_cndmask_b32_e32 v1, 0x180000, v32, vcc_lo                // 000000093EB4: 020240FF 00180000
	v_add_co_ci_u32_e64 v33, null, 0, v33, s1                  // 000000093EBC: D5207C21 00064280
	.long 0xd7000122                                           // 000000093EC4: D7000122
	v_cndmask_b32_e32 v1, 0x180000, v34, vcc_lo                // 000000093EC8: 020244FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000093ED0: BF8700A1
	v_add_co_ci_u32_e64 v35, null, 0, v35, s1                  // 000000093ED4: D5207C23 00064680
	.long 0xd7000124                                           // 000000093EDC: D7000124
	v_cndmask_b32_e32 v1, 0x180000, v36, vcc_lo                // 000000093EE0: 020248FF 00180000
	v_add_co_ci_u32_e64 v37, null, 0, v37, s1                  // 000000093EE8: D5207C25 00064A80
	.long 0xd7000126                                           // 000000093EF0: D7000126
	v_cndmask_b32_e32 v1, 0x180000, v38, vcc_lo                // 000000093EF4: 02024CFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000093EFC: BF8700A1
	v_add_co_ci_u32_e64 v39, null, 0, v39, s1                  // 000000093F00: D5207C27 00064E80
	.long 0xd7000128                                           // 000000093F08: D7000128
	v_cndmask_b32_e32 v1, 0x180000, v40, vcc_lo                // 000000093F0C: 020250FF 00180000
	v_add_co_ci_u32_e64 v41, null, 0, v41, s1                  // 000000093F14: D5207C29 00065280
	s_add_i32 s5, s5, 1                                        // 000000093F1C: 81058105
	s_waitcnt lgkmcnt(0)                                       // 000000093F20: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 000000093F24: BF062105
	s_barrier                                                  // 000000093F28: BFBD0000
	buffer_gl0_inv                                             // 000000093F2C: E0AC0000 00000000
	s_cbranch_scc0 62214                                       // 000000093F34: BFA1F306 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x450>
	v_mov_b32_e32 v5, v51                                      // 000000093F38: 7E0A0333
	s_add_u32 s0, s28, s20                                     // 000000093F3C: 8000141C
	.long 0xd73c0000                                           // 000000093F40: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 000000093F44: 02020489
	s_addc_u32 s1, s29, s21                                    // 000000093F48: 8201151D
	s_add_u32 s2, s24, s18                                     // 000000093F4C: 80021218
	s_addc_u32 s3, s25, s19                                    // 000000093F50: 82031319
	s_add_u32 s0, s2, s0                                       // 000000093F54: 80000002
	s_addc_u32 s1, s3, s1                                      // 000000093F58: 82010103
	.long 0xd7006a00                                           // 000000093F5C: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000093F60: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000093F64: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 000000093F68: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000093F70: BE810080
	.long 0xd7006a00                                           // 000000093F74: D7006A00
	v_cndmask_b32_e32 v1, v0, v52, vcc_lo                      // 000000093F78: 02026900
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000093F7C: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000093F84: BF870092
	.long 0xd7006a00                                           // 000000093F88: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 000000093F8C: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 000000093F90: D5207C01 01AA0211
	s_nop 0                                                    // 000000093F98: BF800000
	s_nop 0                                                    // 000000093F9C: BF800000
	s_nop 0                                                    // 000000093FA0: BF800000
	s_nop 0                                                    // 000000093FA4: BF800000
	s_nop 0                                                    // 000000093FA8: BF800000
	s_nop 0                                                    // 000000093FAC: BF800000
	s_nop 0                                                    // 000000093FB0: BF800000
	s_nop 0                                                    // 000000093FB4: BF800000
	s_nop 0                                                    // 000000093FB8: BF800000
	s_nop 0                                                    // 000000093FBC: BF800000
	ds_load_b32 v2, v50                                        // 000000093FC0: D8D80000 02000032
	v_add_nc_u32_e32 v5, 0x80, v5                              // 000000093FC8: 4A0A0AFF 00000080
	v_add_nc_u32_e32 v50, 0x220, v50                           // 000000093FD0: 4A6464FF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000093FD8: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v5                         // 000000093FDC: 7C920AFF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 000000093FE4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 000000093FE8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 000000093FEC: DC6A0000 007C0200
	.long 0xd7000000                                           // 000000093FF4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 000000093FF8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 000000094000: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000094008: 917E017E
	s_cbranch_execnz 65516                                     // 00000009400C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi8ELi1ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x38c0>
	s_nop 0                                                    // 000000094010: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 000000094014: BFB60003
	s_endpgm                                                   // 000000094018: BFB00000
		...

