000000000023cc00 <_ZN7halogen12_GLOBAL__N_111k_ngram_idsEPKxPKiS2_S2_S2_iPx>:
; _ZN7halogen12_GLOBAL__N_111k_ngram_idsEPKxPKiS2_S2_S2_iPx():
	s_mov_b32 s3, exec_lo                                      // 00000023CC00: BE83007E
	v_cmpx_gt_u32_e32 16, v0                                   // 00000023CC04: 7D980090
	s_cbranch_execz 318                                        // 00000023CC08: BFA5013E <_ZN7halogen12_GLOBAL__N_111k_ngram_idsEPKxPKiS2_S2_S2_iPx+0x504>
	s_clause 0x1                                               // 00000023CC0C: BF850001
	s_load_b32 s12, s[0:1], 0x28                               // 00000023CC10: F4000300 F8000028
	s_load_b256 s[4:11], s[0:1], null                          // 00000023CC18: F40C0100 F8000000
	s_ashr_i32 s3, s2, 31                                      // 00000023CC20: 86039F02
	v_lshrrev_b32_e32 v1, 3, v0                                // 00000023CC24: 32020083
	s_lshl_b64 s[14:15], s[2:3], 2                             // 00000023CC28: 848E8202
	s_mov_b32 s20, 1                                           // 00000023CC2C: BE940081
	s_mov_b32 s22, 0                                           // 00000023CC30: BE960080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000023CC34: BF870001
	v_sub_nc_u32_e32 v3, 0, v1                                 // 00000023CC38: 4C060280
	s_waitcnt lgkmcnt(0)                                       // 00000023CC3C: BF89FC07
	s_ashr_i32 s13, s12, 31                                    // 00000023CC40: 860D9F0C
	s_add_u32 s6, s6, s14                                      // 00000023CC44: 80060E06
	s_addc_u32 s7, s7, s15                                     // 00000023CC48: 82070F07
	s_lshl_b64 s[14:15], s[2:3], 3                             // 00000023CC4C: 848E8302
	s_load_b32 s21, s[6:7], 0x8                                // 00000023CC50: F4000543 F8000008
	s_add_u32 s6, s4, s14                                      // 00000023CC58: 80060E04
	s_addc_u32 s7, s5, s15                                     // 00000023CC5C: 82070F05
	s_load_b64 s[16:17], s[8:9], null                          // 00000023CC60: F4040404 F8000000
	s_load_b64 s[18:19], s[6:7], 0x10                          // 00000023CC68: F4040483 F8000010
	s_load_b64 s[6:7], s[0:1], 0x20                            // 00000023CC70: F4040180 F8000020
	s_mov_b32 s15, 0                                           // 00000023CC78: BE8F0080
	s_waitcnt lgkmcnt(0)                                       // 00000023CC7C: BF89FC07
	s_sub_i32 s21, s2, s21                                     // 00000023CC80: 81951502
	s_mul_i32 s14, s16, s19                                    // 00000023CC84: 960E1310
	s_mul_hi_u32 s19, s16, s18                                 // 00000023CC88: 96931210
	s_mul_i32 s17, s17, s18                                    // 00000023CC8C: 96111211
	s_add_i32 s14, s19, s14                                    // 00000023CC90: 810E0E13
	s_add_i32 s21, s21, 2                                      // 00000023CC94: 81158215
	s_add_i32 s17, s14, s17                                    // 00000023CC98: 8111110E
	s_add_u32 s8, s8, 8                                        // 00000023CC9C: 80088808
	s_mul_i32 s16, s16, s18                                    // 00000023CCA0: 96101210
	s_addc_u32 s9, s9, 0                                       // 00000023CCA4: 82098009
	s_add_i32 s14, s2, 1                                       // 00000023CCA8: 810E8102
	s_set_inst_prefetch_distance 0x1                           // 00000023CCAC: BF840001
	s_branch 26                                                // 00000023CCB0: BFA0001A <_ZN7halogen12_GLOBAL__N_111k_ngram_idsEPKxPKiS2_S2_S2_iPx+0x11c>
	s_nop 0                                                    // 00000023CCB4: BF800000
	s_nop 0                                                    // 00000023CCB8: BF800000
	s_nop 0                                                    // 00000023CCBC: BF800000
	s_load_b64 s[24:25], s[8:9], null                          // 00000023CCC0: F4040604 F8000000
	s_add_i32 s20, s20, 1                                      // 00000023CCC8: 81148114
	s_waitcnt lgkmcnt(0)                                       // 00000023CCCC: BF89FC07
	s_mul_i32 s19, s24, s19                                    // 00000023CCD0: 96131318
	s_mul_hi_u32 s23, s24, s18                                 // 00000023CCD4: 96971218
	s_mul_i32 s25, s25, s18                                    // 00000023CCD8: 96191219
	s_add_i32 s19, s23, s19                                    // 00000023CCDC: 81131317
	s_mul_i32 s18, s24, s18                                    // 00000023CCE0: 96121218
	s_add_i32 s19, s19, s25                                    // 00000023CCE4: 81131913
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000023CCE8: BF8700D9
	s_xor_b64 s[16:17], s[18:19], s[16:17]                     // 00000023CCEC: 8D901012
	v_add_nc_u32_e32 v1, s20, v3                               // 00000023CCF0: 4A020614
	s_add_u32 s8, s8, 8                                        // 00000023CCF4: 80088808
	s_addc_u32 s9, s9, 0                                       // 00000023CCF8: 82098009
	s_add_i32 s14, s14, -1                                     // 00000023CCFC: 810EC10E
	v_cmp_eq_u32_e32 vcc_lo, 2, v1                             // 00000023CD00: 7C940282
	v_dual_mov_b32 v1, s16 :: v_dual_mov_b32 v2, s17           // 00000023CD04: CA100010 01020011
	s_or_b32 s22, vcc_lo, s22                                  // 00000023CD0C: 8C16166A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000023CD10: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 00000023CD14: 917E167E
	s_cbranch_execz 16                                         // 00000023CD18: BFA50010 <_ZN7halogen12_GLOBAL__N_111k_ngram_idsEPKxPKiS2_S2_S2_iPx+0x15c>
	s_cmp_ge_i32 s21, s20                                      // 00000023CD1C: BF031415
	s_cselect_b32 s18, -1, 0                                   // 00000023CD20: 981280C1
	s_cmp_gt_i32 s14, -1                                       // 00000023CD24: BF02C10E
	s_cselect_b32 s19, -1, 0                                   // 00000023CD28: 981380C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000023CD2C: BF870499
	s_and_b32 s18, s18, s19                                    // 00000023CD30: 8B121312
	s_and_not1_b32 vcc_lo, exec_lo, s18                        // 00000023CD34: 916A127E
	s_mov_b64 s[18:19], s[12:13]                               // 00000023CD38: BE92010C
	s_cbranch_vccnz 65504                                      // 00000023CD3C: BFA4FFE0 <_ZN7halogen12_GLOBAL__N_111k_ngram_idsEPKxPKiS2_S2_S2_iPx+0xc0>
	s_lshl_b64 s[18:19], s[14:15], 3                           // 00000023CD40: 8492830E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000023CD44: BF870009
	s_add_u32 s18, s4, s18                                     // 00000023CD48: 80121204
	s_addc_u32 s19, s5, s19                                    // 00000023CD4C: 82131305
	s_load_b64 s[18:19], s[18:19], null                        // 00000023CD50: F4040489 F8000000
	s_branch 65497                                             // 00000023CD58: BFA0FFD9 <_ZN7halogen12_GLOBAL__N_111k_ngram_idsEPKxPKiS2_S2_S2_iPx+0xc0>
	s_set_inst_prefetch_distance 0x2                           // 00000023CD5C: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 00000023CD60: 8C7E167E
	v_lshlrev_b32_e32 v11, 3, v0                               // 00000023CD64: 30160083
	s_load_b64 s[0:1], s[0:1], 0x30                            // 00000023CD68: F4040000 F8000030
	s_lshl_b64 s[2:3], s[2:3], 7                               // 00000023CD70: 84828702
	s_clause 0x1                                               // 00000023CD74: BF850001
	global_load_b64 v[3:4], v11, s[10:11]                      // 00000023CD78: DC560000 030A000B
	global_load_b64 v[5:6], v11, s[6:7]                        // 00000023CD80: DC560000 0506000B
	s_waitcnt lgkmcnt(0)                                       // 00000023CD88: BF89FC07
	s_add_u32 s0, s0, s2                                       // 00000023CD8C: 80000200
	s_addc_u32 s1, s1, s3                                      // 00000023CD90: 82010301
	s_waitcnt vmcnt(1)                                         // 00000023CD94: BF8907F7
	v_ashrrev_i32_e32 v0, 31, v4                               // 00000023CD98: 3400089F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023CD9C: BF870091
	.long 0xd7006a03                                           // 00000023CDA0: D7006A03
	v_cndmask_b32_e32 v1, v3, v0, vcc_lo                       // 00000023CDA4: 02020103
	v_add_co_ci_u32_e64 v4, null, v4, v0, vcc_lo               // 00000023CDA8: D5207C04 01AA0104
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000023CDB0: BF870112
	v_xor_b32_e32 v12, v3, v0                                  // 00000023CDB4: 3A180103
	v_xor_b32_e32 v13, v4, v0                                  // 00000023CDB8: 3A1A0104
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000023CDBC: BF8701A2
	v_cvt_f32_u32_e32 v0, v12                                  // 00000023CDC0: 7E000D0C
	.long 0xd7016a0e                                           // 00000023CDC4: D7016A0E
	v_cndmask_b32_e32 v1, 0, v12, vcc_lo                       // 00000023CDC8: 02021880
	v_cvt_f32_u32_e32 v3, v13                                  // 00000023CDCC: 7E060D0D
	v_sub_co_ci_u32_e64 v15, null, 0, v13, vcc_lo              // 00000023CDD0: D5217C0F 01AA1A80
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023CDD8: BF870092
	v_fmamk_f32 v0, v3, 0x4f800000, v0                         // 00000023CDDC: 58000103 4F800000
	v_rcp_f32_e32 v0, v0                                       // 00000023CDE4: 7E005500
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023CDE8: BF870095
	v_mul_f32_e32 v0, 0x5f7ffffc, v0                           // 00000023CDEC: 100000FF 5F7FFFFC
	v_mul_f32_e32 v3, 0x2f800000, v0                           // 00000023CDF4: 100600FF 2F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023CDFC: BF870091
	v_trunc_f32_e32 v3, v3                                     // 00000023CE00: 7E064303
	v_fmamk_f32 v0, v3, 0xcf800000, v0                         // 00000023CE04: 58000103 CF800000
	v_cvt_u32_f32_e32 v16, v3                                  // 00000023CE0C: 7E200F03
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000023CE10: BF870112
	v_cvt_u32_f32_e32 v0, v0                                   // 00000023CE14: 7E000F00
	.long 0xd72c0007                                           // 00000023CE18: D72C0007
	v_cndmask_b32_e32 v1, v14, v16, vcc_lo                     // 00000023CE1C: 0202210E
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000023CE20: BF8700A2
	.long 0xd72c0008                                           // 00000023CE24: D72C0008
	v_cndmask_b32_e32 v1, v15, v0, vcc_lo                      // 00000023CE28: 0202010F
	v_mad_u64_u32 v[3:4], null, v14, v0, 0                     // 00000023CE2C: D6FE7C03 0202010E
	v_add3_u32 v9, v4, v7, v8                                  // 00000023CE34: D6550009 04220F04
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000023CE3C: BF8701A2
	.long 0xd72d0011                                           // 00000023CE40: D72D0011
	v_cndmask_b32_e32 v1, v0, v3, vcc_lo                       // 00000023CE44: 02020700
	v_mad_u64_u32 v[3:4], null, v16, v3, 0                     // 00000023CE48: D6FE7C03 02020710
	v_mad_u64_u32 v[7:8], null, v0, v9, 0                      // 00000023CE50: D6FE7C07 02021300
	v_mad_u64_u32 v[9:10], null, v16, v9, 0                    // 00000023CE58: D6FE7C09 02021310
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023CE60: BF870092
	.long 0xd7006a07                                           // 00000023CE64: D7006A07
	v_cndmask_b32_e32 v1, v17, v7, vcc_lo                      // 00000023CE68: 02020F11
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 00000023CE6C: D5207C08 01AA1080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000023CE74: BF870112
	.long 0xd7006a03                                           // 00000023CE78: D7006A03
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 00000023CE7C: 02020707
	v_add_co_ci_u32_e32 v3, vcc_lo, v8, v4, vcc_lo             // 00000023CE80: 40060908
	v_add_co_ci_u32_e32 v4, vcc_lo, 0, v10, vcc_lo             // 00000023CE84: 40081480
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023CE88: BF870092
	.long 0xd7006a03                                           // 00000023CE8C: D7006A03
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 00000023CE90: 02021303
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000023CE94: D5207C04 01AA0880
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023CE9C: BF870092
	.long 0xd7006a00                                           // 00000023CEA0: D7006A00
	v_cndmask_b32_e32 v1, v0, v3, vcc_lo                       // 00000023CEA4: 02020700
	v_add_co_ci_u32_e64 v16, null, v16, v4, vcc_lo             // 00000023CEA8: D5207C10 01AA0910
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000023CEB0: BF8701A2
	.long 0xd72c0007                                           // 00000023CEB4: D72C0007
	v_cndmask_b32_e32 v1, v15, v0, vcc_lo                      // 00000023CEB8: 0202010F
	v_mad_u64_u32 v[3:4], null, v14, v0, 0                     // 00000023CEBC: D6FE7C03 0202010E
	.long 0xd72c0008                                           // 00000023CEC4: D72C0008
	v_cndmask_b32_e32 v1, v14, v16, vcc_lo                     // 00000023CEC8: 0202210E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000023CECC: BF870112
	.long 0xd72d000e                                           // 00000023CED0: D72D000E
	v_cndmask_b32_e32 v1, v0, v3, vcc_lo                       // 00000023CED4: 02020700
	v_add3_u32 v9, v4, v8, v7                                  // 00000023CED8: D6550009 041E1104
	v_mad_u64_u32 v[3:4], null, v16, v3, 0                     // 00000023CEE0: D6FE7C03 02020710
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000023CEE8: BF870122
	v_mad_u64_u32 v[7:8], null, v0, v9, 0                      // 00000023CEEC: D6FE7C07 02021300
	v_mad_u64_u32 v[9:10], null, v16, v9, 0                    // 00000023CEF4: D6FE7C09 02021310
	.long 0xd7006a07                                           // 00000023CEFC: D7006A07
	v_cndmask_b32_e32 v1, v14, v7, vcc_lo                      // 00000023CF00: 02020F0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000023CF04: BF8701A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, vcc_lo                // 00000023CF08: D5207C08 01AA1080
	v_ashrrev_i32_e32 v14, 31, v2                              // 00000023CF10: 341C049F
	.long 0xd7006a03                                           // 00000023CF14: D7006A03
	v_cndmask_b32_e32 v1, v7, v3, vcc_lo                       // 00000023CF18: 02020707
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000023CF1C: BF870223
	v_add_co_ci_u32_e32 v3, vcc_lo, v8, v4, vcc_lo             // 00000023CF20: 40060908
	v_add_co_ci_u32_e32 v4, vcc_lo, 0, v10, vcc_lo             // 00000023CF24: 40081480
	.long 0xd7006a01                                           // 00000023CF28: D7006A01
	v_cndmask_b32_e32 v1, v1, v14, vcc_lo                      // 00000023CF2C: 02021D01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000023CF30: BF870211
	v_add_co_ci_u32_e64 v2, null, v2, v14, vcc_lo              // 00000023CF34: D5207C02 01AA1D02
	.long 0xd7006a03                                           // 00000023CF3C: D7006A03
	v_cndmask_b32_e32 v1, v3, v9, vcc_lo                       // 00000023CF40: 02021303
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_4)// 00000023CF44: BF870211
	v_add_co_ci_u32_e64 v4, null, 0, v4, vcc_lo                // 00000023CF48: D5207C04 01AA0880
	v_xor_b32_e32 v9, v1, v14                                  // 00000023CF50: 3A121D01
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023CF54: BF870093
	.long 0xd7006a03                                           // 00000023CF58: D7006A03
	v_cndmask_b32_e32 v1, v0, v3, vcc_lo                       // 00000023CF5C: 02020700
	v_add_co_ci_u32_e64 v4, null, v16, v4, vcc_lo              // 00000023CF60: D5207C04 01AA0910
	v_xor_b32_e32 v10, v2, v14                                 // 00000023CF68: 3A141D02
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000023CF6C: BF870193
	.long 0xd72d000f                                           // 00000023CF70: D72D000F
	v_cndmask_b32_e32 v1, v9, v3, vcc_lo                       // 00000023CF74: 02020709
	v_mad_u64_u32 v[0:1], null, v9, v4, 0                      // 00000023CF78: D6FE7C00 02020909
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000023CF80: BF8701A3
	v_mad_u64_u32 v[2:3], null, v10, v3, 0                     // 00000023CF84: D6FE7C02 0202070A
	v_mad_u64_u32 v[7:8], null, v10, v4, 0                     // 00000023CF8C: D6FE7C07 0202090A
	.long 0xd7006a00                                           // 00000023CF94: D7006A00
	v_cndmask_b32_e32 v1, v15, v0, vcc_lo                      // 00000023CF98: 0202010F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000023CF9C: BF870111
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000023CFA0: D5207C01 01AA0280
	.long 0xd7006a00                                           // 00000023CFA8: D7006A00
	v_cndmask_b32_e32 v1, v0, v2, vcc_lo                       // 00000023CFAC: 02020500
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000023CFB0: BF870122
	v_add_co_ci_u32_e32 v0, vcc_lo, v1, v3, vcc_lo             // 00000023CFB4: 40000701
	v_add_co_ci_u32_e32 v1, vcc_lo, 0, v8, vcc_lo              // 00000023CFB8: 40021080
	.long 0xd7006a00                                           // 00000023CFBC: D7006A00
	v_cndmask_b32_e32 v1, v0, v7, vcc_lo                       // 00000023CFC0: 02020F00
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000023CFC4: BF870111
	v_add_co_ci_u32_e64 v2, null, 0, v1, vcc_lo                // 00000023CFC8: D5207C02 01AA0280
	.long 0xd72c0003                                           // 00000023CFD0: D72C0003
	v_cndmask_b32_e32 v1, v13, v0, vcc_lo                      // 00000023CFD4: 0202010D
	v_mad_u64_u32 v[0:1], null, v12, v0, 0                     // 00000023CFD8: D6FE7C00 0202010C
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000023CFE0: BF870113
	.long 0xd72c0002                                           // 00000023CFE4: D72C0002
	v_cndmask_b32_e32 v1, v12, v2, vcc_lo                      // 00000023CFE8: 0202050C
	.long 0xd7016a00                                           // 00000023CFEC: D7016A00
	v_cndmask_b32_e32 v1, v9, v0, vcc_lo                       // 00000023CFF0: 02020109
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000023CFF4: BF870112
	v_add3_u32 v1, v1, v2, v3                                  // 00000023CFF8: D6550001 040E0501
	.long 0xd44e0004                                           // 00000023D000: D44E0004
	v_cndmask_b32_e32 v1, v0, v12, vcc_lo                      // 00000023D004: 02021900
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000023D008: BF8701A2
	v_sub_nc_u32_e32 v2, v10, v1                               // 00000023D00C: 4C04030A
	v_sub_co_ci_u32_e64 v1, null, v10, v1, vcc_lo              // 00000023D010: D5217C01 01AA030A
	v_cndmask_b32_e64 v7, 0, -1, s4                            // 00000023D018: D5010007 00118280
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000023D020: BF8700A3
	v_sub_co_ci_u32_e64 v2, null, v2, v13, vcc_lo              // 00000023D024: D5217C02 01AA1B02
	.long 0xd7016a03                                           // 00000023D02C: D7016A03
	v_cndmask_b32_e32 v1, v0, v12, vcc_lo                      // 00000023D030: 02021900
	v_subrev_co_ci_u32_e64 v4, null, 0, v2, vcc_lo             // 00000023D034: D5227C04 01AA0480
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 00000023D03C: BF8701B2
	.long 0xd44e0004                                           // 00000023D040: D44E0004
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 00000023D044: 02021903
	v_sub_co_ci_u32_e64 v2, null, v2, v13, vcc_lo              // 00000023D048: D5217C02 01AA1B02
	v_cmp_ge_u32_e32 vcc_lo, v1, v13                           // 00000023D050: 7C9C1B01
	v_cndmask_b32_e64 v8, 0, -1, s4                            // 00000023D054: D5010008 00118280
	.long 0xd44e0004                                           // 00000023D05C: D44E0004
	v_cndmask_b32_e32 v1, v4, v13, vcc_lo                      // 00000023D060: 02021B04
	v_cndmask_b32_e64 v10, 0, -1, vcc_lo                       // 00000023D064: D501000A 01A98280
	v_cmp_eq_u32_e32 vcc_lo, v4, v13                           // 00000023D06C: 7C941B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023D070: BF870093
	v_cndmask_b32_e64 v9, 0, -1, s4                            // 00000023D074: D5010009 00118280
	v_cndmask_b32_e32 v8, v9, v8, vcc_lo                       // 00000023D07C: 02101109
	.long 0xd7016a09                                           // 00000023D080: D7016A09
	v_cndmask_b32_e32 v1, v3, v12, vcc_lo                      // 00000023D084: 02021903
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 00000023D088: BF870141
	v_subrev_co_ci_u32_e64 v2, null, 0, v2, vcc_lo             // 00000023D08C: D5227C02 01AA0480
	v_cmp_eq_u32_e32 vcc_lo, v1, v13                           // 00000023D094: 7C941B01
	v_cndmask_b32_e32 v7, v10, v7, vcc_lo                      // 00000023D098: 020E0F0A
	v_cmp_ne_u32_e32 vcc_lo, 0, v8                             // 00000023D09C: 7C9A1080
	.long 0xd44d0004                                           // 00000023D0A0: D44D0004
	v_cndmask_b32_e32 v1, 0, v7, vcc_lo                        // 00000023D0A4: 02020E80
	v_dual_cndmask_b32 v3, v3, v9 :: v_dual_cndmask_b32 v2, v4, v2// 00000023D0A8: CA521303 03020504
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000023D0B0: BF870111
	v_cndmask_b32_e64 v0, v0, v3, s4                           // 00000023D0B4: D5010000 00120700
	v_cndmask_b32_e64 v1, v1, v2, s4                           // 00000023D0BC: D5010001 00120501
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000023D0C4: BF870112
	v_xor_b32_e32 v0, v0, v14                                  // 00000023D0C8: 3A001D00
	v_xor_b32_e32 v1, v1, v14                                  // 00000023D0CC: 3A021D01
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023D0D0: BF870092
	.long 0xd7016a00                                           // 00000023D0D4: D7016A00
	v_cndmask_b32_e32 v1, v0, v14, vcc_lo                      // 00000023D0D8: 02021D00
	v_sub_co_ci_u32_e64 v1, null, v1, v14, vcc_lo              // 00000023D0DC: D5217C01 01AA1D01
	s_waitcnt vmcnt(0)                                         // 00000023D0E4: BF8903F7
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000023D0E8: BF870092
	.long 0xd7006a00                                           // 00000023D0EC: D7006A00
	v_cndmask_b32_e32 v1, v5, v0, vcc_lo                       // 00000023D0F0: 02020105
	v_add_co_ci_u32_e64 v1, null, v6, v1, vcc_lo               // 00000023D0F4: D5207C01 01AA0306
	global_store_b64 v11, v[0:1], s[0:1]                       // 00000023D0FC: DC6E0000 0000000B
	s_endpgm                                                   // 00000023D104: BFB00000
		...

