0000000000101d00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE>:
; _ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE():
	s_clause 0x1                                               // 000000101D00: BF850001
	s_load_b256 s[8:15], s[0:1], 0x30                          // 000000101D04: F40C0200 F8000030
	s_load_b128 s[20:23], s[0:1], 0x50                         // 000000101D0C: F4080500 F8000050
	v_and_b32_e32 v130, 31, v0                                 // 000000101D14: 3704009F
	v_lshrrev_b32_e32 v157, 5, v0                              // 000000101D18: 333A0085
	s_mov_b32 s24, s3                                          // 000000101D1C: BE980003
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000101D20: BF870112
	.long 0xd44c0003                                           // 000000101D24: D44C0003
	v_cndmask_b32_e32 v1, 16, v130, vcc_lo                     // 000000101D28: 02030490
	v_lshlrev_b32_e32 v131, 6, v157                            // 000000101D2C: 31073A86
	s_waitcnt lgkmcnt(0)                                       // 000000101D30: BF89FC07
	s_load_b32 s26, s[8:9], null                               // 000000101D34: F4000684 F8000000
	s_and_saveexec_b32 s4, s3                                  // 000000101D3C: BE842003
	s_delay_alu instid0(VALU_DEP_1)                            // 000000101D40: BF870001
	v_lshl_add_u32 v1, v130, 2, v131                           // 000000101D44: D6460001 060D0582
	v_dual_mov_b32 v2, 0xf149f2ca :: v_dual_mov_b32 v3, 0      // 000000101D4C: CA1000FF 02020080 F149F2CA
	ds_store_2addr_stride64_b32 v1, v2, v3 offset0:231 offset1:243// 000000101D58: D83CF3E7 00030201
	s_or_b32 exec_lo, exec_lo, s4                              // 000000101D60: 8C7E047E
	v_mul_u32_u24_e32 v1, 0x2ab, v0                            // 000000101D64: 160200FF 000002AB
	s_clause 0x1                                               // 000000101D6C: BF850001
	s_load_b256 s[4:11], s[0:1], null                          // 000000101D70: F40C0100 F8000000
	s_load_b128 s[16:19], s[0:1], 0x20                         // 000000101D78: F4080400 F8000020
	s_lshl_b32 s27, s2, 5                                      // 000000101D80: 841B8502
	v_dual_mov_b32 v144, 0 :: v_dual_and_b32 v159, 15, v0      // 000000101D84: CA240080 909E008F
	.long 0xd7381001                                           // 000000101D8C: D7381001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000101D90: 02020282
	.long 0x7f023880                                           // 000000101D94: 7F023880
	s_cmp_eq_u64 s[14:15], 0                                   // 000000101D98: BF10800E
	v_mov_b32_e32 v145, 0                                      // 000000101D9C: 7F220280
	s_cselect_b32 s25, -1, 0                                   // 000000101DA0: 981980C1
	.long 0xd7620001                                           // 000000101DA4: D7620001
	v_cndmask_b32_e32 v0, v1, v176, vcc_lo                     // 000000101DA8: 02016101
	s_and_b32 vcc_lo, exec_lo, s25                             // 000000101DAC: 8B6A197E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101DB0: BF870091
	v_add_nc_u32_e32 v158, s27, v1                             // 000000101DB4: 4B3C021B
	v_or_b32_e32 v128, v158, v159                              // 000000101DB8: 39013F9E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000101DBC: BF870001
	v_ashrrev_i32_e32 v129, 31, v128                           // 000000101DC0: 3503009F
	s_cbranch_vccnz 10                                         // 000000101DC4: BFA4000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xf0>
	v_mad_i64_i32 v[1:2], null, s23, v128, 0                   // 000000101DC8: D6FF7C01 02030017
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101DD0: BF870091
	.long 0xd73c0001                                           // 000000101DD4: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 000000101DD8: 02020282
	.long 0xd7006a90                                           // 000000101DDC: D7006A90
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 000000101DE0: 0202020E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000101DE4: BF870001
	v_add_co_ci_u32_e64 v145, null, s15, v2, vcc_lo            // 000000101DE8: D5207C91 01AA040F
	s_load_b64 s[14:15], s[0:1], 0x38                          // 000000101DF0: F4040380 F8000038
	v_mov_b32_e32 v161, 0                                      // 000000101DF8: 7F420280
	s_xor_b32 s0, s25, -1                                      // 000000101DFC: 8D00C119
	s_waitcnt lgkmcnt(0)                                       // 000000101E00: BF89FC07
	v_cmp_gt_i32_e32 vcc_lo, s14, v128                         // 000000101E04: 7C89000E
	s_and_b32 s23, s0, vcc_lo                                  // 000000101E08: 8B176A00
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000101E0C: BF870009
	s_and_saveexec_b32 s0, s23                                 // 000000101E10: BE802017
	s_cbranch_execz 9                                          // 000000101E14: BFA50009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13c>
	.long 0xd73c0001                                           // 000000101E18: D73C0001
	v_cndmask_b32_e32 v1, 2, v128, vcc_lo                      // 000000101E1C: 02030082
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101E20: BF870091
	.long 0xd7006a01                                           // 000000101E24: D7006A01
	v_cndmask_b32_e32 v1, s20, v1, vcc_lo                      // 000000101E28: 02020214
	v_add_co_ci_u32_e64 v2, null, s21, v2, vcc_lo              // 000000101E2C: D5207C02 01AA0415
	global_load_b32 v161, v[1:2], off                          // 000000101E34: DC520000 A17C0001
	s_or_b32 exec_lo, exec_lo, s0                              // 000000101E3C: 8C7E007E
	s_cmp_eq_u64 s[12:13], 0                                   // 000000101E40: BF10800C
	s_mov_b64 s[20:21], 0                                      // 000000101E44: BE940180
	s_cbranch_scc1 10                                          // 000000101E48: BFA2000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x174>
	s_ashr_i32 s0, s22, 31                                     // 000000101E4C: 86009F16
	s_mul_hi_u32 s1, s22, s2                                   // 000000101E50: 96810216
	s_mul_i32 s0, s0, s2                                       // 000000101E54: 96000200
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000101E58: BF8704A9
	s_add_i32 s1, s1, s0                                       // 000000101E5C: 81010001
	s_mul_i32 s0, s22, s2                                      // 000000101E60: 96000216
	s_lshl_b64 s[0:1], s[0:1], 2                               // 000000101E64: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000101E68: BF870009
	s_add_u32 s20, s12, s0                                     // 000000101E6C: 8014000C
	s_addc_u32 s21, s13, s1                                    // 000000101E70: 8215010D
	v_lshrrev_b32_e32 v1, 1, v0                                // 000000101E74: 32020081
	v_mov_b32_e32 v7, 0                                        // 000000101E78: 7E0E0280
	.long 0xd44c0000                                           // 000000101E7C: D44C0000
	v_cndmask_b32_e32 v1, 0x200, v0, vcc_lo                    // 000000101E80: 020200FF 00000200
	v_dual_mov_b32 v137, 0 :: v_dual_lshlrev_b32 v0, 3, v130   // 000000101E88: CA220080 89010483
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000101E90: BF8701A3
	v_dual_mov_b32 v10, v7 :: v_dual_and_b32 v133, 0x1f8, v1   // 000000101E94: CA240107 0A8402FF 000001F8
	v_mov_b32_e32 v8, v7                                       // 000000101EA0: 7E100307
	v_dual_mov_b32 v9, v7 :: v_dual_lshlrev_b32 v132, 1, v0    // 000000101EA4: CA220107 09840081
	s_delay_alu instid0(VALU_DEP_3)                            // 000000101EAC: BF870003
	v_dual_mov_b32 v138, 0 :: v_dual_lshlrev_b32 v129, 1, v133 // 000000101EB0: CA220080 8A810A81
	v_dual_mov_b32 v139, 0 :: v_dual_mov_b32 v140, 0           // 000000101EB8: CA100080 8B8C0080
	scratch_store_b128 off, v[7:10], off                       // 000000101EC0: DC750000 007C0700
	s_and_saveexec_b32 s1, s0                                  // 000000101EC8: BE812000
	s_cbranch_execz 67                                         // 000000101ECC: BFA50043 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2dc>
	s_add_i32 s2, s15, -1                                      // 000000101ED0: 8102C10F
	s_ashr_i32 s25, s24, 31                                    // 000000101ED4: 86199F18
	v_min_i32_e32 v0, s2, v157                                 // 000000101ED8: 22013A02
	v_min_i32_e32 v2, s2, v159                                 // 000000101EDC: 22053E02
	s_lshl_b64 s[12:13], s[24:25], 9                           // 000000101EE0: 848C8918
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000101EE4: BF870112
	v_ashrrev_i32_e32 v3, 31, v0                               // 000000101EE8: 3406009F
	v_ashrrev_i32_e32 v5, 31, v2                               // 000000101EEC: 340A049F
	.long 0xd72c0004                                           // 000000101EF0: D72C0004
	v_cndmask_b32_e32 v1, s11, v0, vcc_lo                      // 000000101EF4: 0202000B
	v_mad_u64_u32 v[0:1], null, s10, v0, 0                     // 000000101EF8: D6FE7C00 0202000A
	.long 0xd72c0008                                           // 000000101F00: D72C0008
	v_cndmask_b32_e32 v1, s11, v2, vcc_lo                      // 000000101F04: 0202040B
	.long 0xd72c0006                                           // 000000101F08: D72C0006
	v_cndmask_b32_e32 v1, s10, v3, vcc_lo                      // 000000101F0C: 0202060A
	v_mad_u64_u32 v[2:3], null, s10, v2, 0                     // 000000101F10: D6FE7C02 0202040A
	.long 0xd72c0005                                           // 000000101F18: D72C0005
	v_cndmask_b32_e32 v1, s10, v5, vcc_lo                      // 000000101F1C: 02020A0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000101F20: BF870113
	v_add3_u32 v1, v1, v6, v4                                  // 000000101F24: D6550001 04120D01
	v_add3_u32 v3, v3, v5, v8                                  // 000000101F2C: D6550003 04220B03
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000101F34: BF870112
	.long 0xd73c0000                                           // 000000101F38: D73C0000
	v_cndmask_b32_e32 v1, 1, v0, vcc_lo                        // 000000101F3C: 02020081
	.long 0xd73c0002                                           // 000000101F40: D73C0002
	v_cndmask_b32_e32 v1, 1, v2, vcc_lo                        // 000000101F44: 02020481
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101F48: BF870092
	.long 0xd7006a00                                           // 000000101F4C: D7006A00
	v_cndmask_b32_e32 v1, s6, v0, vcc_lo                       // 000000101F50: 02020006
	v_add_co_ci_u32_e64 v1, null, s7, v1, vcc_lo               // 000000101F54: D5207C01 01AA0207
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101F5C: BF870093
	.long 0xd7006a02                                           // 000000101F60: D7006A02
	v_cndmask_b32_e32 v1, s8, v2, vcc_lo                       // 000000101F64: 02020408
	v_add_co_ci_u32_e64 v3, null, s9, v3, vcc_lo               // 000000101F68: D5207C03 01AA0609
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101F70: BF870094
	.long 0xd7006a00                                           // 000000101F74: D7006A00
	v_cndmask_b32_e32 v0, v0, v12, vcc_lo                      // 000000101F78: 02001900
	v_add_co_ci_u32_e64 v1, null, s13, v1, vcc_lo              // 000000101F7C: D5207C01 01AA020D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101F84: BF870094
	.long 0xd7006a02                                           // 000000101F88: D7006A02
	v_cndmask_b32_e32 v0, v2, v12, vcc_lo                      // 000000101F8C: 02001902
	v_add_co_ci_u32_e64 v3, null, s13, v3, vcc_lo              // 000000101F90: D5207C03 01AA060D
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101F98: BF870094
	.long 0xd7006a00                                           // 000000101F9C: D7006A00
	v_cndmask_b32_e32 v1, v0, v132, vcc_lo                     // 000000101FA0: 02030900
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 000000101FA4: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000101FAC: BF870094
	.long 0xd7006a04                                           // 000000101FB0: D7006A04
	v_cndmask_b32_e32 v1, v2, v129, vcc_lo                     // 000000101FB4: 02030302
	v_add_co_ci_u32_e64 v5, null, 0, v3, vcc_lo                // 000000101FB8: D5207C05 01AA0680
	global_load_b128 v[0:3], v[0:1], off                       // 000000101FC0: DC5E0000 007C0000
	global_load_b128 v[137:140], v[4:5], off                   // 000000101FC8: DC5E0000 897C0004
	s_waitcnt vmcnt(1)                                         // 000000101FD0: BF8907F7
	scratch_store_b128 off, v[0:3], off                        // 000000101FD4: DC750000 007C0000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000101FDC: 8C7E017E
	.long 0xd7050000                                           // 000000101FE0: D7050000
	v_cndmask_b32_e32 v0, v157, v150, vcc_lo                   // 000000101FE4: 02012D9D
	s_or_b32 s27, s27, 31                                      // 000000101FE8: 8C1B9F1B
	s_add_i32 s1, s14, -1                                      // 000000101FEC: 8101C10E
	v_dual_mov_b32 v6, 0 :: v_dual_mov_b32 v5, 0               // 000000101FF0: CA100080 06040080
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000101FF8: BF8701C2
	.long 0xd7390000                                           // 000000101FFC: D7390000
	v_cndmask_b32_e32 v1, 8, v0, vcc_lo                        // 000000102000: 02020088
	s_min_i32 s1, s27, s1                                      // 000000102004: 8901011B
	v_dual_mov_b32 v4, 0 :: v_dual_mov_b32 v3, 0               // 000000102008: CA100080 04020080
	v_dual_mov_b32 v2, 0 :: v_dual_mov_b32 v1, 0               // 000000102010: CA100080 02000080
	.long 0xd7050008                                           // 000000102018: D7050008
	v_cndmask_b32_e32 v0, v0, v140, vcc_lo                     // 00000010201C: 02011900
	v_dual_mov_b32 v0, 0 :: v_dual_mov_b32 v15, 0              // 000000102020: CA100080 000E0080
	v_dual_mov_b32 v14, 0 :: v_dual_mov_b32 v13, 0             // 000000102028: CA100080 0E0C0080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000102030: BF8701B3
	.long 0xd7040008                                           // 000000102034: D7040008
	v_cndmask_b32_e32 v1, v157, v8, vcc_lo                     // 000000102038: 0202119D
	v_dual_mov_b32 v12, 0 :: v_dual_mov_b32 v11, 0             // 00000010203C: CA100080 0C0A0080
	v_dual_mov_b32 v10, 0 :: v_dual_mov_b32 v9, 0              // 000000102044: CA100080 0A080080
	v_dual_mov_b32 v23, 0 :: v_dual_and_b32 v16, 0xff, v8      // 00000010204C: CA240080 171010FF 000000FF
	v_dual_mov_b32 v8, 0 :: v_dual_mov_b32 v21, 0              // 000000102058: CA100080 08140080
	v_dual_mov_b32 v22, 0 :: v_dual_mov_b32 v19, 0             // 000000102060: CA100080 16120080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000102068: BF870243
	v_mad_u64_u32 v[141:142], null, s24, 12, v[16:17]          // 00000010206C: D6FE7C8D 04411818
	v_dual_mov_b32 v20, 0 :: v_dual_mov_b32 v17, 0             // 000000102074: CA100080 14100080
	v_dual_mov_b32 v18, 0 :: v_dual_mov_b32 v31, 0             // 00000010207C: CA100080 121E0080
	v_dual_mov_b32 v16, 0 :: v_dual_mov_b32 v29, 0             // 000000102084: CA100080 101C0080
	v_dual_mov_b32 v25, 0 :: v_dual_lshlrev_b32 v32, 8, v141   // 00000010208C: CA220080 19211A88
	v_dual_mov_b32 v30, 0 :: v_dual_mov_b32 v27, 0             // 000000102094: CA100080 1E1A0080
	v_dual_mov_b32 v28, 0 :: v_dual_mov_b32 v39, 0             // 00000010209C: CA100080 1C260080
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001020A4: BF8701B3
	v_ashrrev_i32_e32 v33, 31, v32                             // 0000001020A8: 3442409F
	v_dual_mov_b32 v26, 0 :: v_dual_mov_b32 v37, 0             // 0000001020AC: CA100080 1A240080
	v_dual_mov_b32 v24, 0 :: v_dual_mov_b32 v35, 0             // 0000001020B4: CA100080 18220080
	.long 0xd73c008e                                           // 0000001020BC: D73C008E
	v_cndmask_b32_e32 v1, 1, v32, vcc_lo                       // 0000001020C0: 02024081
	v_dual_mov_b32 v38, 0 :: v_dual_mov_b32 v33, 0             // 0000001020C4: CA100080 26200080
	v_dual_mov_b32 v36, 0 :: v_dual_mov_b32 v47, 0             // 0000001020CC: CA100080 242E0080
	v_dual_mov_b32 v34, 0 :: v_dual_mov_b32 v45, 0             // 0000001020D4: CA100080 222C0080
	v_dual_mov_b32 v32, 0 :: v_dual_mov_b32 v43, 0             // 0000001020DC: CA100080 202A0080
	v_dual_mov_b32 v46, 0 :: v_dual_mov_b32 v41, 0             // 0000001020E4: CA100080 2E280080
	v_dual_mov_b32 v44, 0 :: v_dual_mov_b32 v55, 0             // 0000001020EC: CA100080 2C360080
	v_dual_mov_b32 v42, 0 :: v_dual_mov_b32 v53, 0             // 0000001020F4: CA100080 2A340080
	v_dual_mov_b32 v40, 0 :: v_dual_mov_b32 v51, 0             // 0000001020FC: CA100080 28320080
	v_dual_mov_b32 v54, 0 :: v_dual_mov_b32 v49, 0             // 000000102104: CA100080 36300080
	v_dual_mov_b32 v52, 0 :: v_dual_mov_b32 v63, 0             // 00000010210C: CA100080 343E0080
	v_dual_mov_b32 v50, 0 :: v_dual_mov_b32 v61, 0             // 000000102114: CA100080 323C0080
	v_dual_mov_b32 v48, 0 :: v_dual_mov_b32 v59, 0             // 00000010211C: CA100080 303A0080
	v_dual_mov_b32 v62, 0 :: v_dual_mov_b32 v57, 0             // 000000102124: CA100080 3E380080
	v_dual_mov_b32 v60, 0 :: v_dual_mov_b32 v71, 0             // 00000010212C: CA100080 3C460080
	v_dual_mov_b32 v58, 0 :: v_dual_mov_b32 v69, 0             // 000000102134: CA100080 3A440080
	v_dual_mov_b32 v56, 0 :: v_dual_mov_b32 v67, 0             // 00000010213C: CA100080 38420080
	v_dual_mov_b32 v70, 0 :: v_dual_mov_b32 v65, 0             // 000000102144: CA100080 46400080
	v_dual_mov_b32 v68, 0 :: v_dual_mov_b32 v79, 0             // 00000010214C: CA100080 444E0080
	v_dual_mov_b32 v66, 0 :: v_dual_mov_b32 v77, 0             // 000000102154: CA100080 424C0080
	v_dual_mov_b32 v64, 0 :: v_dual_mov_b32 v75, 0             // 00000010215C: CA100080 404A0080
	v_dual_mov_b32 v78, 0 :: v_dual_mov_b32 v73, 0             // 000000102164: CA100080 4E480080
	v_dual_mov_b32 v76, 0 :: v_dual_mov_b32 v87, 0             // 00000010216C: CA100080 4C560080
	v_dual_mov_b32 v74, 0 :: v_dual_mov_b32 v85, 0             // 000000102174: CA100080 4A540080
	v_dual_mov_b32 v72, 0 :: v_dual_mov_b32 v83, 0             // 00000010217C: CA100080 48520080
	v_dual_mov_b32 v86, 0 :: v_dual_mov_b32 v81, 0             // 000000102184: CA100080 56500080
	v_dual_mov_b32 v84, 0 :: v_dual_mov_b32 v95, 0             // 00000010218C: CA100080 545E0080
	v_dual_mov_b32 v82, 0 :: v_dual_mov_b32 v93, 0             // 000000102194: CA100080 525C0080
	v_dual_mov_b32 v80, 0 :: v_dual_mov_b32 v91, 0             // 00000010219C: CA100080 505A0080
	v_dual_mov_b32 v94, 0 :: v_dual_mov_b32 v89, 0             // 0000001021A4: CA100080 5E580080
	v_dual_mov_b32 v92, 0 :: v_dual_mov_b32 v103, 0            // 0000001021AC: CA100080 5C660080
	v_dual_mov_b32 v90, 0 :: v_dual_mov_b32 v101, 0            // 0000001021B4: CA100080 5A640080
	v_dual_mov_b32 v88, 0 :: v_dual_mov_b32 v99, 0             // 0000001021BC: CA100080 58620080
	v_dual_mov_b32 v102, 0 :: v_dual_mov_b32 v97, 0            // 0000001021C4: CA100080 66600080
	v_dual_mov_b32 v100, 0 :: v_dual_mov_b32 v111, 0           // 0000001021CC: CA100080 646E0080
	v_dual_mov_b32 v98, 0 :: v_dual_mov_b32 v109, 0            // 0000001021D4: CA100080 626C0080
	v_dual_mov_b32 v96, 0 :: v_dual_mov_b32 v107, 0            // 0000001021DC: CA100080 606A0080
	v_dual_mov_b32 v110, 0 :: v_dual_mov_b32 v105, 0           // 0000001021E4: CA100080 6E680080
	v_dual_mov_b32 v108, 0 :: v_dual_mov_b32 v119, 0           // 0000001021EC: CA100080 6C760080
	v_dual_mov_b32 v106, 0 :: v_dual_mov_b32 v117, 0           // 0000001021F4: CA100080 6A740080
	v_dual_mov_b32 v104, 0 :: v_dual_mov_b32 v115, 0           // 0000001021FC: CA100080 68720080
	v_dual_mov_b32 v118, 0 :: v_dual_mov_b32 v113, 0           // 000000102204: CA100080 76700080
	v_dual_mov_b32 v116, 0 :: v_dual_mov_b32 v127, 0           // 00000010220C: CA100080 747E0080
	v_dual_mov_b32 v114, 0 :: v_dual_mov_b32 v125, 0           // 000000102214: CA100080 727C0080
	v_dual_mov_b32 v112, 0 :: v_dual_mov_b32 v123, 0           // 00000010221C: CA100080 707A0080
	v_dual_mov_b32 v126, 0 :: v_dual_mov_b32 v121, 0           // 000000102224: CA100080 7E780080
	v_mov_b32_e32 v124, 0                                      // 00000010222C: 7EF80280
	v_mov_b32_e32 v122, 0                                      // 000000102230: 7EF40280
	v_mov_b32_e32 v120, 0                                      // 000000102234: 7EF00280
	v_lshrrev_b32_e32 v162, 4, v130                            // 000000102238: 33450484
	v_lshlrev_b32_e32 v160, 1, v159                            // 00000010223C: 31413E81
	s_add_i32 s1, s26, s1                                      // 000000102240: 8101011A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000102244: BF870009
	s_cmp_lt_i32 s1, -15                                       // 000000102248: BF04CF01
	s_cbranch_scc1 2880                                        // 00000010224C: BFA20B40 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3250>
	v_mad_i64_i32 v[0:1], null, 0x3000, v128, s[4:5]           // 000000102250: D6FF7C00 001300FF 00003000
	s_ashr_i32 s2, s1, 31                                      // 00000010225C: 86029F01
	v_mul_u32_u24_e32 v2, 0x210, v157                          // 000000102260: 16053AFF 00000210
	s_lshr_b32 s2, s2, 28                                      // 000000102268: 85029C02
	v_mad_u32_u24 v181, v159, 48, 0x9600                       // 00000010226C: D60B00B5 03FD619F 00009600
	s_add_i32 s1, s1, s2                                       // 000000102278: 81010201
	v_add_nc_u32_e32 v167, s26, v158                           // 00000010227C: 4B4F3C1A
	s_ashr_i32 s5, s1, 4                                       // 000000102280: 86058401
	.long 0xd7006a92                                           // 000000102284: D7006A92
	v_cndmask_b32_e32 v1, v0, v142, vcc_lo                     // 000000102288: 02031D00
	s_cmp_eq_u64 s[20:21], 0                                   // 00000010228C: BF108014
	v_add_co_ci_u32_e64 v147, null, v1, v143, vcc_lo           // 000000102290: D5207C93 01AB1F01
	v_mul_u32_u24_e32 v0, 48, v133                             // 000000102298: 16010AB0
	v_add3_u32 v1, v128, s26, 1                                // 00000010229C: D6550001 02043580
	s_cselect_b32 s12, -1, 0                                   // 0000001022A4: 980C80C1
	s_cmp_lg_u64 s[20:21], 0                                   // 0000001022A8: BF118014
	v_add3_u32 v163, v2, v132, 0xc600                          // 0000001022AC: D65500A3 03FF0902 0000C600
	s_cselect_b32 s13, -1, 0                                   // 0000001022B8: 980D80C1
	s_ashr_i32 s25, s24, 31                                    // 0000001022BC: 86199F18
	v_add3_u32 v164, v0, v160, 0x9600                          // 0000001022C0: D65500A4 03FF4100 00009600
	v_ashrrev_i32_e32 v0, 31, v1                               // 0000001022CC: 3400029F
	s_lshl_b64 s[24:25], s[24:25], 9                           // 0000001022D0: 84988918
	s_add_i32 s15, s15, -1                                     // 0000001022D4: 810FC10F
	s_add_u32 s2, s6, s24                                      // 0000001022D8: 80021806
	s_movk_i32 s6, 0x440                                       // 0000001022DC: B0060440
	v_lshrrev_b32_e32 v0, 30, v0                               // 0000001022E0: 3200009E
	v_mad_u32_u24 v2, v157, s6, 0x3000                         // 0000001022E4: D60B0002 03FC0D9D 00003000
	v_mov_b32_e32 v128, 0                                      // 0000001022F0: 7F000280
	v_lshlrev_b32_e32 v4, 2, v130                              // 0000001022F4: 30090482
	s_addc_u32 s4, s7, s25                                     // 0000001022F8: 82041907
	v_add_nc_u32_e32 v0, v1, v0                                // 0000001022FC: 4A000101
	v_mad_u32_u24 v3, 0x44, v162, v2                           // 000000102300: D60B0003 040B44FF 00000044
	.long 0xd70002a5                                           // 00000010230C: D70002A5
	v_cndmask_b32_e32 v1, s2, v132, vcc_lo                     // 000000102310: 02030802
	v_mov_b32_e32 v121, v128                                   // 000000102314: 7EF20380
	v_dual_mov_b32 v120, 0 :: v_dual_add_nc_u32 v1, v131, v4   // 000000102318: CA200080 78000983
	s_delay_alu instid0(VALU_DEP_4)                            // 000000102320: BF870004
	v_lshl_add_u32 v168, v159, 2, v3                           // 000000102324: D64600A8 040D059F
	v_dual_mov_b32 v122, v128 :: v_dual_add_nc_u32 v3, 0xed00, v131// 00000010232C: CA200180 7A0306FF 0000ED00
	v_mov_b32_e32 v123, v128                                   // 000000102338: 7EF60380
	v_ashrrev_i32_e32 v169, 2, v0                              // 00000010233C: 35520082
	v_dual_mov_b32 v125, v128 :: v_dual_lshlrev_b32 v0, 9, v157// 000000102340: CA220180 7D013A89
	v_add_co_ci_u32_e64 v166, null, s4, 0, s2                  // 000000102348: D5207CA6 00090004
	s_add_u32 s2, s8, s24                                      // 000000102350: 80021808
	s_mov_b32 s1, 0xc600                                       // 000000102354: BE8100FF 0000C600
	s_addc_u32 s4, s9, s25                                     // 00000010235C: 82041909
	.long 0xd70002b2                                           // 000000102360: D70002B2
	v_cndmask_b32_e32 v1, s2, v129, vcc_lo                     // 000000102364: 02030202
	v_dual_mov_b32 v127, v128 :: v_dual_add_nc_u32 v170, v167, v130// 000000102368: CA200180 7FAB05A7
	v_dual_mov_b32 v124, v128 :: v_dual_add_nc_u32 v171, 0xe700, v1// 000000102370: CA200180 7CAA02FF 0000E700
	v_mad_u32_u24 v172, 0x44, v130, v2                         // 00000010237C: D60B00AC 040B04FF 00000044
	v_lshl_add_u32 v173, v130, 5, v0                           // 000000102388: D64600AD 04010B82
	v_dual_mov_b32 v113, v128 :: v_dual_add_nc_u32 v174, 0xf300, v1// 000000102390: CA200180 71AE02FF 0000F300
	v_dual_mov_b32 v126, v128 :: v_dual_add_nc_u32 v175, v3, v4// 00000010239C: CA200180 7EAE0903
	v_lshl_or_b32 v176, v162, 2, v3                            // 0000001023A4: D65600B0 040D05A2
	v_lshl_or_b32 v177, v159, 5, v0                            // 0000001023AC: D65600B1 04010B9F
	v_dual_mov_b32 v112, 0 :: v_dual_mov_b32 v115, v128        // 0000001023B4: CA100080 70720180
	v_mov_b32_e32 v114, v128                                   // 0000001023BC: 7EE40380
	v_mov_b32_e32 v116, v128                                   // 0000001023C0: 7EE80380
	v_dual_mov_b32 v117, v128 :: v_dual_mov_b32 v104, 0        // 0000001023C4: CA100180 75680080
	v_mov_b32_e32 v118, v128                                   // 0000001023CC: 7EEC0380
	v_dual_mov_b32 v119, v128 :: v_dual_mov_b32 v96, 0         // 0000001023D0: CA100180 77600080
	v_dual_mov_b32 v105, v128 :: v_dual_mov_b32 v88, 0         // 0000001023D8: CA100180 69580080
	v_mov_b32_e32 v106, v128                                   // 0000001023E0: 7ED40380
	v_dual_mov_b32 v107, v128 :: v_dual_mov_b32 v80, 0         // 0000001023E4: CA100180 6B500080
	v_mov_b32_e32 v108, v128                                   // 0000001023EC: 7ED80380
	v_dual_mov_b32 v109, v128 :: v_dual_mov_b32 v72, 0         // 0000001023F0: CA100180 6D480080
	v_mov_b32_e32 v110, v128                                   // 0000001023F8: 7EDC0380
	v_dual_mov_b32 v111, v128 :: v_dual_mov_b32 v64, 0         // 0000001023FC: CA100180 6F400080
	v_dual_mov_b32 v97, v128 :: v_dual_mov_b32 v56, 0          // 000000102404: CA100180 61380080
	v_mov_b32_e32 v98, v128                                    // 00000010240C: 7EC40380
	v_dual_mov_b32 v99, v128 :: v_dual_mov_b32 v48, 0          // 000000102410: CA100180 63300080
	v_mov_b32_e32 v100, v128                                   // 000000102418: 7EC80380
	v_dual_mov_b32 v101, v128 :: v_dual_mov_b32 v40, 0         // 00000010241C: CA100180 65280080
	v_mov_b32_e32 v102, v128                                   // 000000102424: 7ECC0380
	v_dual_mov_b32 v103, v128 :: v_dual_mov_b32 v32, 0         // 000000102428: CA100180 67200080
	v_dual_mov_b32 v89, v128 :: v_dual_mov_b32 v24, 0          // 000000102430: CA100180 59180080
	v_mov_b32_e32 v90, v128                                    // 000000102438: 7EB40380
	v_dual_mov_b32 v91, v128 :: v_dual_mov_b32 v16, 0          // 00000010243C: CA100180 5B100080
	v_mov_b32_e32 v92, v128                                    // 000000102444: 7EB80380
	v_dual_mov_b32 v93, v128 :: v_dual_mov_b32 v8, 0           // 000000102448: CA100180 5D080080
	v_mov_b32_e32 v94, v128                                    // 000000102450: 7EBC0380
	v_dual_mov_b32 v95, v128 :: v_dual_mov_b32 v0, 0           // 000000102454: CA100180 5F000080
	v_dual_mov_b32 v81, v128 :: v_dual_mov_b32 v148, 0         // 00000010245C: CA100180 51940080
	v_mov_b32_e32 v82, v128                                    // 000000102464: 7EA40380
	v_mov_b32_e32 v83, v128                                    // 000000102468: 7EA60380
	v_mov_b32_e32 v84, v128                                    // 00000010246C: 7EA80380
	v_mov_b32_e32 v85, v128                                    // 000000102470: 7EAA0380
	v_mov_b32_e32 v86, v128                                    // 000000102474: 7EAC0380
	v_mov_b32_e32 v87, v128                                    // 000000102478: 7EAE0380
	v_mov_b32_e32 v73, v128                                    // 00000010247C: 7E920380
	v_mov_b32_e32 v74, v128                                    // 000000102480: 7E940380
	v_mov_b32_e32 v75, v128                                    // 000000102484: 7E960380
	v_mov_b32_e32 v76, v128                                    // 000000102488: 7E980380
	v_mov_b32_e32 v77, v128                                    // 00000010248C: 7E9A0380
	v_mov_b32_e32 v78, v128                                    // 000000102490: 7E9C0380
	v_mov_b32_e32 v79, v128                                    // 000000102494: 7E9E0380
	v_mov_b32_e32 v65, v128                                    // 000000102498: 7E820380
	v_mov_b32_e32 v66, v128                                    // 00000010249C: 7E840380
	v_mov_b32_e32 v67, v128                                    // 0000001024A0: 7E860380
	v_mov_b32_e32 v68, v128                                    // 0000001024A4: 7E880380
	v_mov_b32_e32 v69, v128                                    // 0000001024A8: 7E8A0380
	v_mov_b32_e32 v70, v128                                    // 0000001024AC: 7E8C0380
	v_mov_b32_e32 v71, v128                                    // 0000001024B0: 7E8E0380
	v_mov_b32_e32 v57, v128                                    // 0000001024B4: 7E720380
	v_mov_b32_e32 v58, v128                                    // 0000001024B8: 7E740380
	v_mov_b32_e32 v59, v128                                    // 0000001024BC: 7E760380
	v_mov_b32_e32 v60, v128                                    // 0000001024C0: 7E780380
	v_mov_b32_e32 v61, v128                                    // 0000001024C4: 7E7A0380
	v_mov_b32_e32 v62, v128                                    // 0000001024C8: 7E7C0380
	v_mov_b32_e32 v63, v128                                    // 0000001024CC: 7E7E0380
	v_mov_b32_e32 v49, v128                                    // 0000001024D0: 7E620380
	v_mov_b32_e32 v50, v128                                    // 0000001024D4: 7E640380
	v_mov_b32_e32 v51, v128                                    // 0000001024D8: 7E660380
	v_mov_b32_e32 v52, v128                                    // 0000001024DC: 7E680380
	v_mov_b32_e32 v53, v128                                    // 0000001024E0: 7E6A0380
	v_mov_b32_e32 v54, v128                                    // 0000001024E4: 7E6C0380
	v_mov_b32_e32 v55, v128                                    // 0000001024E8: 7E6E0380
	v_mov_b32_e32 v41, v128                                    // 0000001024EC: 7E520380
	v_mov_b32_e32 v42, v128                                    // 0000001024F0: 7E540380
	v_mov_b32_e32 v43, v128                                    // 0000001024F4: 7E560380
	v_mov_b32_e32 v44, v128                                    // 0000001024F8: 7E580380
	v_mov_b32_e32 v45, v128                                    // 0000001024FC: 7E5A0380
	v_mov_b32_e32 v46, v128                                    // 000000102500: 7E5C0380
	v_mov_b32_e32 v47, v128                                    // 000000102504: 7E5E0380
	v_mov_b32_e32 v33, v128                                    // 000000102508: 7E420380
	v_mov_b32_e32 v34, v128                                    // 00000010250C: 7E440380
	v_mov_b32_e32 v35, v128                                    // 000000102510: 7E460380
	v_mov_b32_e32 v36, v128                                    // 000000102514: 7E480380
	v_mov_b32_e32 v37, v128                                    // 000000102518: 7E4A0380
	v_mov_b32_e32 v38, v128                                    // 00000010251C: 7E4C0380
	v_mov_b32_e32 v39, v128                                    // 000000102520: 7E4E0380
	v_mov_b32_e32 v25, v128                                    // 000000102524: 7E320380
	v_mov_b32_e32 v26, v128                                    // 000000102528: 7E340380
	v_mov_b32_e32 v27, v128                                    // 00000010252C: 7E360380
	v_mov_b32_e32 v28, v128                                    // 000000102530: 7E380380
	v_mov_b32_e32 v29, v128                                    // 000000102534: 7E3A0380
	v_mov_b32_e32 v30, v128                                    // 000000102538: 7E3C0380
	v_mov_b32_e32 v31, v128                                    // 00000010253C: 7E3E0380
	v_mov_b32_e32 v17, v128                                    // 000000102540: 7E220380
	v_mov_b32_e32 v18, v128                                    // 000000102544: 7E240380
	v_mov_b32_e32 v19, v128                                    // 000000102548: 7E260380
	v_mov_b32_e32 v20, v128                                    // 00000010254C: 7E280380
	v_mov_b32_e32 v21, v128                                    // 000000102550: 7E2A0380
	v_mov_b32_e32 v22, v128                                    // 000000102554: 7E2C0380
	v_mov_b32_e32 v23, v128                                    // 000000102558: 7E2E0380
	v_mov_b32_e32 v9, v128                                     // 00000010255C: 7E120380
	v_mov_b32_e32 v10, v128                                    // 000000102560: 7E140380
	v_mov_b32_e32 v11, v128                                    // 000000102564: 7E160380
	v_mov_b32_e32 v12, v128                                    // 000000102568: 7E180380
	v_mov_b32_e32 v13, v128                                    // 00000010256C: 7E1A0380
	v_mov_b32_e32 v14, v128                                    // 000000102570: 7E1C0380
	v_mov_b32_e32 v15, v128                                    // 000000102574: 7E1E0380
	v_mov_b32_e32 v1, v128                                     // 000000102578: 7E020380
	v_mov_b32_e32 v2, v128                                     // 00000010257C: 7E040380
	v_mov_b32_e32 v3, v128                                     // 000000102580: 7E060380
	v_mov_b32_e32 v4, v128                                     // 000000102584: 7E080380
	v_mov_b32_e32 v5, v128                                     // 000000102588: 7E0A0380
	v_mov_b32_e32 v6, v128                                     // 00000010258C: 7E0C0380
	v_mov_b32_e32 v7, v128                                     // 000000102590: 7E0E0380
	v_add_co_ci_u32_e64 v179, null, s4, 0, s2                  // 000000102594: D5207CB3 00090004
	v_mad_u32_u24 v180, 0x210, v159, s1                        // 00000010259C: D60B00B4 00073EFF 00000210
	s_mov_b32 s6, 0                                            // 0000001025A8: BE860080
	s_branch 116                                               // 0000001025AC: BFA00074 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa80>
	ds_load_b128 v[149:152], v181                              // 0000001025B0: DBFC0000 950000B5
	ds_load_b128 v[153:156], v181 offset:16                    // 0000001025B8: DBFC0010 990000B5
	s_waitcnt lgkmcnt(0)                                       // 0000001025C0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[120:127], v[129:136], v[149:156], v[120:127]// 0000001025C4: CC414078 1DE32B81
	ds_load_b128 v[153:156], v181 offset:784                   // 0000001025CC: DBFC0310 990000B5
	ds_load_b128 v[149:152], v181 offset:768                   // 0000001025D4: DBFC0300 950000B5
	s_waitcnt lgkmcnt(0)                                       // 0000001025DC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[112:119], v[129:136], v[149:156], v[112:119]// 0000001025E0: CC414070 1DC32B81
	ds_load_b128 v[153:156], v181 offset:1552                  // 0000001025E8: DBFC0610 990000B5
	ds_load_b128 v[149:152], v181 offset:1536                  // 0000001025F0: DBFC0600 950000B5
	s_waitcnt lgkmcnt(0)                                       // 0000001025F8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[104:111], v[129:136], v[149:156], v[104:111]// 0000001025FC: CC414068 1DA32B81
	ds_load_b128 v[153:156], v181 offset:2320                  // 000000102604: DBFC0910 990000B5
	ds_load_b128 v[149:152], v181 offset:2304                  // 00000010260C: DBFC0900 950000B5
	s_waitcnt lgkmcnt(0)                                       // 000000102614: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[96:103], v[129:136], v[149:156], v[96:103]// 000000102618: CC414060 1D832B81
	ds_load_b128 v[153:156], v181 offset:3088                  // 000000102620: DBFC0C10 990000B5
	ds_load_b128 v[149:152], v181 offset:3072                  // 000000102628: DBFC0C00 950000B5
	s_waitcnt lgkmcnt(0)                                       // 000000102630: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[88:95], v[129:136], v[149:156], v[88:95]// 000000102634: CC414058 1D632B81
	ds_load_b128 v[153:156], v181 offset:3856                  // 00000010263C: DBFC0F10 990000B5
	ds_load_b128 v[149:152], v181 offset:3840                  // 000000102644: DBFC0F00 950000B5
	s_waitcnt lgkmcnt(0)                                       // 00000010264C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[80:87], v[129:136], v[149:156], v[80:87]// 000000102650: CC414050 1D432B81
	ds_load_b128 v[153:156], v181 offset:4624                  // 000000102658: DBFC1210 990000B5
	ds_load_b128 v[149:152], v181 offset:4608                  // 000000102660: DBFC1200 950000B5
	s_waitcnt lgkmcnt(0)                                       // 000000102668: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[72:79], v[129:136], v[149:156], v[72:79]// 00000010266C: CC414048 1D232B81
	ds_load_b128 v[153:156], v181 offset:5392                  // 000000102674: DBFC1510 990000B5
	ds_load_b128 v[149:152], v181 offset:5376                  // 00000010267C: DBFC1500 950000B5
	s_waitcnt lgkmcnt(0)                                       // 000000102684: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[64:71], v[129:136], v[149:156], v[64:71]// 000000102688: CC414040 1D032B81
	ds_load_b128 v[153:156], v181 offset:6160                  // 000000102690: DBFC1810 990000B5
	ds_load_b128 v[149:152], v181 offset:6144                  // 000000102698: DBFC1800 950000B5
	s_waitcnt lgkmcnt(0)                                       // 0000001026A0: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[56:63], v[129:136], v[149:156], v[56:63]// 0000001026A4: CC414038 1CE32B81
	ds_load_b128 v[153:156], v181 offset:6928                  // 0000001026AC: DBFC1B10 990000B5
	ds_load_b128 v[149:152], v181 offset:6912                  // 0000001026B4: DBFC1B00 950000B5
	s_waitcnt lgkmcnt(0)                                       // 0000001026BC: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[48:55], v[129:136], v[149:156], v[48:55]// 0000001026C0: CC414030 1CC32B81
	ds_load_b128 v[153:156], v181 offset:7696                  // 0000001026C8: DBFC1E10 990000B5
	ds_load_b128 v[149:152], v181 offset:7680                  // 0000001026D0: DBFC1E00 950000B5
	s_waitcnt lgkmcnt(0)                                       // 0000001026D8: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[40:47], v[129:136], v[149:156], v[40:47]// 0000001026DC: CC414028 1CA32B81
	ds_load_b128 v[153:156], v181 offset:8464                  // 0000001026E4: DBFC2110 990000B5
	ds_load_b128 v[149:152], v181 offset:8448                  // 0000001026EC: DBFC2100 950000B5
	s_waitcnt lgkmcnt(0)                                       // 0000001026F4: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[32:39], v[129:136], v[149:156], v[32:39]// 0000001026F8: CC414020 1C832B81
	ds_load_b128 v[153:156], v181 offset:9232                  // 000000102700: DBFC2410 990000B5
	ds_load_b128 v[149:152], v181 offset:9216                  // 000000102708: DBFC2400 950000B5
	s_waitcnt lgkmcnt(0)                                       // 000000102710: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[24:31], v[129:136], v[149:156], v[24:31]// 000000102714: CC414018 1C632B81
	ds_load_b128 v[153:156], v181 offset:10000                 // 00000010271C: DBFC2710 990000B5
	ds_load_b128 v[149:152], v181 offset:9984                  // 000000102724: DBFC2700 950000B5
	s_waitcnt lgkmcnt(0)                                       // 00000010272C: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[16:23], v[129:136], v[149:156], v[16:23]// 000000102730: CC414010 1C432B81
	ds_load_b128 v[153:156], v181 offset:10768                 // 000000102738: DBFC2A10 990000B5
	ds_load_b128 v[149:152], v181 offset:10752                 // 000000102740: DBFC2A00 950000B5
	s_waitcnt lgkmcnt(0)                                       // 000000102748: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[8:15], v[129:136], v[149:156], v[8:15]// 00000010274C: CC414008 1C232B81
	ds_load_b128 v[153:156], v181 offset:11536                 // 000000102754: DBFC2D10 990000B5
	ds_load_b128 v[149:152], v181 offset:11520                 // 00000010275C: DBFC2D00 950000B5
	s_waitcnt lgkmcnt(0)                                       // 000000102764: BF89FC07
	v_wmma_f32_16x16x16_bf16 v[0:7], v[129:136], v[149:156], v[0:7]// 000000102768: CC414000 1C032B81
	s_add_i32 s1, s6, 1                                        // 000000102770: 81018106
	s_cmp_eq_u32 s6, s5                                        // 000000102774: BF060506
	s_mov_b32 s6, s1                                           // 000000102778: BE860001
	s_cbranch_scc1 2548                                        // 00000010277C: BFA209F4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3250>
	s_and_not1_b32 vcc_lo, exec_lo, s13                        // 000000102780: 916A0D7E
	s_mov_b32 s1, s12                                          // 000000102784: BE81000C
	s_cbranch_vccz 3                                           // 000000102788: BFA30003 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa98>
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 00000010278C: 916A017E
	s_cbranch_vccnz 65527                                      // 000000102790: BFA4FFF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa70>
	s_branch 15                                                // 000000102794: BFA0000F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xad4>
	s_lshr_b32 s1, s6, 3                                       // 000000102798: 85018306
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000010279C: BF870499
	s_and_b32 s1, s1, 0x1ffffffc                               // 0000001027A0: 8B01FF01 1FFFFFFC
	v_mov_b32_e32 v129, s1                                     // 0000001027A8: 7F020201
	global_load_b32 v129, v129, s[20:21]                       // 0000001027AC: DC520000 81140081
	s_waitcnt vmcnt(0)                                         // 0000001027B4: BF8903F7
	v_lshrrev_b32_e32 v129, s6, v129                           // 0000001027B8: 33030206
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001027BC: BF870091
	v_and_b32_e32 v129, 1, v129                                // 0000001027C0: 37030281
	.long 0xd44a0001                                           // 0000001027C4: D44A0001
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000001027C8: 02030281
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000001027CC: 916A017E
	s_cbranch_vccnz 65511                                      // 0000001027D0: BFA4FFE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa70>
	s_lshl_b32 s2, s6, 4                                       // 0000001027D4: 84028406
	s_waitcnt vmcnt(0)                                         // 0000001027D8: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 0000001027DC: BC7C0000
	s_barrier                                                  // 0000001027E0: BFBD0000
	buffer_gl0_inv                                             // 0000001027E4: E0AC0000 00000000
	s_and_saveexec_b32 s1, s0                                  // 0000001027EC: BE812000
	s_cbranch_execz 72                                         // 0000001027F0: BFA50048 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc14>
	scratch_load_b128 v[129:132], off, off                     // 0000001027F4: DC5D0000 817C0000
	s_cmp_ge_i32 s6, s5                                        // 0000001027FC: BF030506
	s_waitcnt vmcnt(0)                                         // 000000102800: BF8903F7
	ds_store_b128 v163, v[129:132]                             // 000000102804: DB7C0000 000081A3
	ds_store_b16 v164, v137                                    // 00000010280C: D87C0000 000089A4
	ds_store_b16_d16_hi v164, v137 offset:48                   // 000000102814: DA840030 000089A4
	ds_store_b16 v164, v138 offset:96                          // 00000010281C: D87C0060 00008AA4
	ds_store_b16_d16_hi v164, v138 offset:144                  // 000000102824: DA840090 00008AA4
	ds_store_b16 v164, v139 offset:192                         // 00000010282C: D87C00C0 00008BA4
	ds_store_b16_d16_hi v164, v139 offset:240                  // 000000102834: DA8400F0 00008BA4
	ds_store_b16 v164, v140 offset:288                         // 00000010283C: D87C0120 00008CA4
	ds_store_b16_d16_hi v164, v140 offset:336                  // 000000102844: DA840150 00008CA4
	s_cbranch_scc1 49                                          // 00000010284C: BFA20031 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc14>
	s_add_i32 s4, s2, 16                                       // 000000102850: 81049002
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000102854: BF870129
	v_or_b32_e32 v129, s4, v157                                // 000000102858: 39033A04
	v_or_b32_e32 v130, s4, v159                                // 00000010285C: 39053E04
	v_min_i32_e32 v129, s15, v129                              // 000000102860: 2303020F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000102864: BF870112
	v_min_i32_e32 v131, s15, v130                              // 000000102868: 2307040F
	v_ashrrev_i32_e32 v132, 31, v129                           // 00000010286C: 3509029F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000102870: BF870002
	v_ashrrev_i32_e32 v134, 31, v131                           // 000000102874: 350D069F
	.long 0xd72c0085                                           // 000000102878: D72C0085
	v_cndmask_b32_e32 v1, s11, v129, vcc_lo                    // 00000010287C: 0203020B
	v_mad_u64_u32 v[129:130], null, s10, v129, 0               // 000000102880: D6FE7C81 0203020A
	.long 0xd72c0088                                           // 000000102888: D72C0088
	v_cndmask_b32_e32 v1, s11, v131, vcc_lo                    // 00000010288C: 0203060B
	.long 0xd72c0087                                           // 000000102890: D72C0087
	v_cndmask_b32_e32 v1, s10, v132, vcc_lo                    // 000000102894: 0203080A
	v_mad_u64_u32 v[131:132], null, s10, v131, 0               // 000000102898: D6FE7C83 0203060A
	.long 0xd72c0086                                           // 0000001028A0: D72C0086
	v_cndmask_b32_e32 v1, s10, v134, vcc_lo                    // 0000001028A4: 02030C0A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001028A8: BF870113
	v_add3_u32 v130, v130, v135, v133                          // 0000001028AC: D6550082 06170F82
	v_add3_u32 v132, v132, v134, v136                          // 0000001028B4: D6550084 06230D84
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001028BC: BF870112
	.long 0xd73c0081                                           // 0000001028C0: D73C0081
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 0000001028C4: 02030281
	.long 0xd73c0083                                           // 0000001028C8: D73C0083
	v_cndmask_b32_e32 v1, 1, v131, vcc_lo                      // 0000001028CC: 02030681
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001028D0: BF870092
	.long 0xd7006a81                                           // 0000001028D4: D7006A81
	v_cndmask_b32_e32 v1, v165, v129, vcc_lo                   // 0000001028D8: 020303A5
	v_add_co_ci_u32_e64 v130, null, v166, v130, vcc_lo         // 0000001028DC: D5207C82 01AB05A6
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001028E4: BF870093
	.long 0xd7006a85                                           // 0000001028E8: D7006A85
	v_cndmask_b32_e32 v1, v178, v131, vcc_lo                   // 0000001028EC: 020307B2
	v_add_co_ci_u32_e64 v134, null, v179, v132, vcc_lo         // 0000001028F0: D5207C86 01AB09B3
	global_load_b128 v[129:132], v[129:130], off               // 0000001028F8: DC5E0000 817C0081
	global_load_b128 v[137:140], v[133:134], off               // 000000102900: DC5E0000 897C0085
	s_waitcnt vmcnt(1)                                         // 000000102908: BF8907F7
	scratch_store_b128 off, v[129:132], off                    // 00000010290C: DC750000 007C8100
	s_or_b32 exec_lo, exec_lo, s1                              // 000000102914: 8C7E017E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102918: BF890007
	s_waitcnt_vscnt null, 0x0                                  // 00000010291C: BC7C0000
	s_barrier                                                  // 000000102920: BFBD0000
	buffer_gl0_inv                                             // 000000102924: E0AC0000 00000000
	s_clause 0x1                                               // 00000010292C: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:16     // 000000102930: DC5E0010 997C0092
	global_load_b128 v[149:152], v[146:147], off               // 000000102938: DC5E0000 957C0092
	ds_load_b128 v[182:185], v180                              // 000000102940: DBFC0000 B60000B4
	ds_load_b128 v[186:189], v180 offset:16                    // 000000102948: DBFC0010 BA0000B4
	v_mov_b32_e32 v135, v128                                   // 000000102950: 7F0E0380
	v_mov_b32_e32 v129, v128                                   // 000000102954: 7F020380
	v_mov_b32_e32 v130, v128                                   // 000000102958: 7F040380
	v_mov_b32_e32 v131, v128                                   // 00000010295C: 7F060380
	v_mov_b32_e32 v132, v128                                   // 000000102960: 7F080380
	v_mov_b32_e32 v133, v128                                   // 000000102964: 7F0A0380
	v_mov_b32_e32 v134, v128                                   // 000000102968: 7F0C0380
	v_mov_b32_e32 v136, v135                                   // 00000010296C: 7F100387
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000102970: BF870212
	v_mov_b32_e32 v135, v134                                   // 000000102974: 7F0E0386
	v_mov_b32_e32 v134, v133                                   // 000000102978: 7F0C0385
	v_mov_b32_e32 v133, v132                                   // 00000010297C: 7F0A0384
	v_mov_b32_e32 v132, v131                                   // 000000102980: 7F080383
	v_mov_b32_e32 v131, v130                                   // 000000102984: 7F060382
	v_mov_b32_e32 v130, v129                                   // 000000102988: 7F040381
	v_mov_b32_e32 v129, v128                                   // 00000010298C: 7F020380
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102990: BF890007
	s_delay_alu instid0(VALU_DEP_1)                            // 000000102994: BF870001
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000102998: CC414081 1E076D95
	s_clause 0x1                                               // 0000001029A0: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:48     // 0000001029A4: DC5E0030 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:32     // 0000001029AC: DC5E0020 957C0092
	ds_load_b128 v[182:185], v180 offset:32                    // 0000001029B4: DBFC0020 B60000B4
	ds_load_b128 v[186:189], v180 offset:48                    // 0000001029BC: DBFC0030 BA0000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001029C4: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 0000001029C8: CC414081 1E076D95
	s_clause 0x1                                               // 0000001029D0: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:80     // 0000001029D4: DC5E0050 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:64     // 0000001029DC: DC5E0040 957C0092
	ds_load_b128 v[186:189], v180 offset:80                    // 0000001029E4: DBFC0050 BA0000B4
	ds_load_b128 v[182:185], v180 offset:64                    // 0000001029EC: DBFC0040 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001029F4: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 0000001029F8: CC414081 1E076D95
	s_clause 0x1                                               // 000000102A00: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:112    // 000000102A04: DC5E0070 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:96     // 000000102A0C: DC5E0060 957C0092
	ds_load_b128 v[186:189], v180 offset:112                   // 000000102A14: DBFC0070 BA0000B4
	ds_load_b128 v[182:185], v180 offset:96                    // 000000102A1C: DBFC0060 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102A24: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000102A28: CC414081 1E076D95
	s_clause 0x1                                               // 000000102A30: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:144    // 000000102A34: DC5E0090 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:128    // 000000102A3C: DC5E0080 957C0092
	ds_load_b128 v[186:189], v180 offset:144                   // 000000102A44: DBFC0090 BA0000B4
	ds_load_b128 v[182:185], v180 offset:128                   // 000000102A4C: DBFC0080 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102A54: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000102A58: CC414081 1E076D95
	s_clause 0x1                                               // 000000102A60: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:176    // 000000102A64: DC5E00B0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:160    // 000000102A6C: DC5E00A0 957C0092
	ds_load_b128 v[186:189], v180 offset:176                   // 000000102A74: DBFC00B0 BA0000B4
	ds_load_b128 v[182:185], v180 offset:160                   // 000000102A7C: DBFC00A0 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102A84: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000102A88: CC414081 1E076D95
	s_clause 0x1                                               // 000000102A90: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:208    // 000000102A94: DC5E00D0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:192    // 000000102A9C: DC5E00C0 957C0092
	ds_load_b128 v[186:189], v180 offset:208                   // 000000102AA4: DBFC00D0 BA0000B4
	ds_load_b128 v[182:185], v180 offset:192                   // 000000102AAC: DBFC00C0 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102AB4: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000102AB8: CC414081 1E076D95
	s_clause 0x1                                               // 000000102AC0: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:240    // 000000102AC4: DC5E00F0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:224    // 000000102ACC: DC5E00E0 957C0092
	ds_load_b128 v[186:189], v180 offset:240                   // 000000102AD4: DBFC00F0 BA0000B4
	ds_load_b128 v[182:185], v180 offset:224                   // 000000102ADC: DBFC00E0 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102AE4: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000102AE8: CC414081 1E076D95
	s_clause 0x1                                               // 000000102AF0: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:272    // 000000102AF4: DC5E0110 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:256    // 000000102AFC: DC5E0100 957C0092
	ds_load_b128 v[186:189], v180 offset:272                   // 000000102B04: DBFC0110 BA0000B4
	ds_load_b128 v[182:185], v180 offset:256                   // 000000102B0C: DBFC0100 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102B14: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000102B18: CC414081 1E076D95
	s_clause 0x1                                               // 000000102B20: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:304    // 000000102B24: DC5E0130 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:288    // 000000102B2C: DC5E0120 957C0092
	ds_load_b128 v[186:189], v180 offset:304                   // 000000102B34: DBFC0130 BA0000B4
	ds_load_b128 v[182:185], v180 offset:288                   // 000000102B3C: DBFC0120 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102B44: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000102B48: CC414081 1E076D95
	s_clause 0x1                                               // 000000102B50: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:336    // 000000102B54: DC5E0150 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:320    // 000000102B5C: DC5E0140 957C0092
	ds_load_b128 v[186:189], v180 offset:336                   // 000000102B64: DBFC0150 BA0000B4
	ds_load_b128 v[182:185], v180 offset:320                   // 000000102B6C: DBFC0140 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102B74: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000102B78: CC414081 1E076D95
	s_clause 0x1                                               // 000000102B80: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:368    // 000000102B84: DC5E0170 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:352    // 000000102B8C: DC5E0160 957C0092
	ds_load_b128 v[186:189], v180 offset:368                   // 000000102B94: DBFC0170 BA0000B4
	ds_load_b128 v[182:185], v180 offset:352                   // 000000102B9C: DBFC0160 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102BA4: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000102BA8: CC414081 1E076D95
	s_clause 0x1                                               // 000000102BB0: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:400    // 000000102BB4: DC5E0190 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:384    // 000000102BBC: DC5E0180 957C0092
	ds_load_b128 v[186:189], v180 offset:400                   // 000000102BC4: DBFC0190 BA0000B4
	ds_load_b128 v[182:185], v180 offset:384                   // 000000102BCC: DBFC0180 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102BD4: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000102BD8: CC414081 1E076D95
	s_clause 0x1                                               // 000000102BE0: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:432    // 000000102BE4: DC5E01B0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:416    // 000000102BEC: DC5E01A0 957C0092
	ds_load_b128 v[186:189], v180 offset:432                   // 000000102BF4: DBFC01B0 BA0000B4
	ds_load_b128 v[182:185], v180 offset:416                   // 000000102BFC: DBFC01A0 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102C04: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000102C08: CC414081 1E076D95
	s_clause 0x1                                               // 000000102C10: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:464    // 000000102C14: DC5E01D0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:448    // 000000102C1C: DC5E01C0 957C0092
	ds_load_b128 v[186:189], v180 offset:464                   // 000000102C24: DBFC01D0 BA0000B4
	ds_load_b128 v[182:185], v180 offset:448                   // 000000102C2C: DBFC01C0 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102C34: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000102C38: CC414081 1E076D95
	s_clause 0x1                                               // 000000102C40: BF850001
	global_load_b128 v[153:156], v[146:147], off offset:496    // 000000102C44: DC5E01F0 997C0092
	global_load_b128 v[149:152], v[146:147], off offset:480    // 000000102C4C: DC5E01E0 957C0092
	ds_load_b128 v[186:189], v180 offset:496                   // 000000102C54: DBFC01F0 BA0000B4
	ds_load_b128 v[182:185], v180 offset:480                   // 000000102C5C: DBFC01E0 B60000B4
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000102C64: BF890007
	v_wmma_f32_16x16x16_bf16 v[129:136], v[149:156], v[182:189], v[129:136]// 000000102C68: CC414081 1E076D95
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000102C70: BF870111
	v_dual_mul_f32 v129, 0x3d800000, v129 :: v_dual_mul_f32 v130, 0x3d800000, v130// 000000102C74: C8C702FF 818304FF 3D800000
	v_mul_f32_e32 v149, 0x3d800000, v133                       // 000000102C80: 112B0AFF 3D800000
	v_mov_b32_e32 v133, 0xffff                                 // 000000102C88: 7F0A02FF 0000FFFF
	s_delay_alu instid0(VALU_DEP_4)                            // 000000102C90: BF870004
	v_dual_mul_f32 v131, 0x3d800000, v131 :: v_dual_mul_f32 v132, 0x3d800000, v132// 000000102C94: C8C706FF 838508FF 3D800000
	v_dual_mul_f32 v134, 0x3d800000, v134 :: v_dual_mul_f32 v135, 0x3d800000, v135// 000000102CA0: C8C70CFF 86870EFF 3D800000
	v_mul_f32_e32 v136, 0x3d800000, v136                       // 000000102CAC: 111110FF 3D800000
	ds_store_2addr_b32 v168, v129, v130 offset1:34             // 000000102CB4: D8382200 008281A8
	ds_store_2addr_b32 v168, v131, v132 offset0:68 offset1:102 // 000000102CBC: D8386644 008483A8
	ds_store_2addr_b32 v168, v149, v134 offset0:136 offset1:170// 000000102CC4: D838AA88 008695A8
	ds_store_2addr_b32 v168, v135, v136 offset0:204 offset1:238// 000000102CCC: D838EECC 008887A8
	s_waitcnt lgkmcnt(0)                                       // 000000102CD4: BF89FC07
	s_barrier                                                  // 000000102CD8: BFBD0000
	buffer_gl0_inv                                             // 000000102CDC: E0AC0000 00000000
	s_and_saveexec_b32 s4, s23                                 // 000000102CE4: BE842017
	s_cbranch_execz 361                                        // 000000102CE8: BFA50169 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1590>
	s_lshl_b32 s7, s6, 2                                       // 000000102CEC: 84078206
	s_mov_b32 s8, exec_lo                                      // 000000102CF0: BE88007E
	.long 0xd4c1007e                                           // 000000102CF4: D4C1007E
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 000000102CF8: 02034394
	s_cbranch_execz 46                                         // 000000102CFC: BFA5002E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10b8>
	v_ashrrev_i32_e32 v149, 31, v148                           // 000000102D00: 352B289F
	s_mov_b32 s9, 0                                            // 000000102D04: BE890080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000102D08: BF870091
	.long 0xd73c0081                                           // 000000102D0C: D73C0081
	v_cndmask_b32_e32 v1, 2, v148, vcc_lo                      // 000000102D10: 02032882
	.long 0xd7006a81                                           // 000000102D14: D7006A81
	v_cndmask_b32_e32 v1, v144, v129, vcc_lo                   // 000000102D18: 02030390
	s_delay_alu instid0(VALU_DEP_1)                            // 000000102D1C: BF870001
	v_add_co_ci_u32_e64 v130, null, v145, v130, vcc_lo         // 000000102D20: D5207C82 01AB0591
	s_branch 13                                                // 000000102D28: BFA0000D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1060>
	s_nop 0                                                    // 000000102D2C: BF800000
	s_nop 0                                                    // 000000102D30: BF800000
	s_nop 0                                                    // 000000102D34: BF800000
	s_nop 0                                                    // 000000102D38: BF800000
	s_nop 0                                                    // 000000102D3C: BF800000
	s_or_b32 exec_lo, exec_lo, s24                             // 000000102D40: 8C7E187E
	v_mov_b32_e32 v132, v148                                   // 000000102D44: 7F080394
	v_mov_b32_e32 v148, v131                                   // 000000102D48: 7F280383
	s_and_b32 s1, exec_lo, s22                                 // 000000102D4C: 8B01167E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000102D50: BF870499
	s_or_b32 s9, s1, s9                                        // 000000102D54: 8C090901
	s_and_not1_b32 exec_lo, exec_lo, s9                        // 000000102D58: 917E097E
	s_cbranch_execz 20                                         // 000000102D5C: BFA50014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x10b0>
	global_load_b32 v131, v[129:130], off                      // 000000102D60: DC520000 837C0081
	s_or_b32 s22, s22, exec_lo                                 // 000000102D68: 8C167E16
	s_waitcnt vmcnt(0)                                         // 000000102D6C: BF8903F7
	v_cmp_gt_i32_e32 vcc_lo, s7, v131                          // 000000102D70: 7C890607
	s_and_saveexec_b32 s24, vcc_lo                             // 000000102D74: BE98206A
	s_cbranch_execz 65521                                      // 000000102D78: BFA5FFF1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	v_dual_mov_b32 v148, v161 :: v_dual_add_nc_u32 v131, 1, v148// 000000102D7C: CA2001A1 94832881
	.long 0xd7000181                                           // 000000102D84: D7000181
	v_cndmask_b32_e32 v0, v129, v132, vcc_lo                   // 000000102D88: 02010981
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000102D8C: BF870191
	v_add_co_ci_u32_e64 v130, null, 0, v130, s1                // 000000102D90: D5207C82 00070480
	v_cmp_eq_u32_e32 vcc_lo, v161, v131                        // 000000102D98: 7C9507A1
	s_and_not1_b32 s1, s22, exec_lo                            // 000000102D9C: 91017E16
	s_and_b32 s22, vcc_lo, exec_lo                             // 000000102DA0: 8B167E6A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000102DA4: BF870009
	s_or_b32 s22, s1, s22                                      // 000000102DA8: 8C161601
	s_branch 65508                                             // 000000102DAC: BFA0FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1040>
	s_or_b32 exec_lo, exec_lo, s9                              // 000000102DB0: 8C7E097E
	v_mov_b32_e32 v148, v132                                   // 000000102DB4: 7F280384
	s_or_b32 exec_lo, exec_lo, s8                              // 000000102DB8: 8C7E087E
	v_mov_b32_e32 v133, 15                                     // 000000102DBC: 7F0A028F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000102DC0: BF870002
	v_mov_b32_e32 v129, v148                                   // 000000102DC4: 7F020394
	s_mov_b32 s1, exec_lo                                      // 000000102DC8: BE81007E
	.long 0xd4c1007e                                           // 000000102DCC: D4C1007E
	v_cndmask_b32_e32 v1, s7, v169, vcc_lo                     // 000000102DD0: 02035207
	s_cbranch_execz 62                                         // 000000102DD4: BFA5003E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11d0>
	v_mov_b32_e32 v133, 0                                      // 000000102DD8: 7F0A0280
	v_mov_b32_e32 v129, v148                                   // 000000102DDC: 7F020394
	s_mov_b32 s8, exec_lo                                      // 000000102DE0: BE88007E
	.long 0xd4c1007e                                           // 000000102DE4: D4C1007E
	v_cndmask_b32_e32 v1, v148, v161, vcc_lo                   // 000000102DE8: 02034394
	s_cbranch_execz 54                                         // 000000102DEC: BFA50036 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x11c8>
	v_mov_b32_e32 v129, v148                                   // 000000102DF0: 7F020394
	s_mov_b32 s22, 0                                           // 000000102DF4: BE960080
	s_set_inst_prefetch_distance 0x1                           // 000000102DF8: BF840001
	s_branch 10                                                // 000000102DFC: BFA0000A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1128>
	s_or_b32 exec_lo, exec_lo, s26                             // 000000102E00: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000102E04: BF870499
	s_and_b32 s26, exec_lo, s25                                // 000000102E08: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 000000102E0C: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 000000102E10: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 000000102E14: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000102E18: BF870009
	s_or_b32 s9, s9, s26                                       // 000000102E1C: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 000000102E20: 917E167E
	s_cbranch_execz 28                                         // 000000102E24: BFA5001C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1198>
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000102E28: BF8700C1
	v_mov_b32_e32 v130, v129                                   // 000000102E2C: 7F040381
	s_or_b32 s24, s24, exec_lo                                 // 000000102E30: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 000000102E34: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 000000102E38: BE9A007E
	v_ashrrev_i32_e32 v131, 31, v130                           // 000000102E3C: 3507049F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000102E40: BF870091
	.long 0xd73c0083                                           // 000000102E44: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 000000102E48: 02030482
	.long 0xd7006a83                                           // 000000102E4C: D7006A83
	v_cndmask_b32_e32 v1, v144, v131, vcc_lo                   // 000000102E50: 02030790
	s_delay_alu instid0(VALU_DEP_1)                            // 000000102E54: BF870001
	v_add_co_ci_u32_e64 v132, null, v145, v132, vcc_lo         // 000000102E58: D5207C84 01AB0991
	global_load_b32 v131, v[131:132], off                      // 000000102E60: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 000000102E68: BF8903F7
	.long 0xd4c4007e                                           // 000000102E6C: D4C4007E
	v_cndmask_b32_e32 v1, s7, v131, vcc_lo                     // 000000102E70: 02030607
	s_cbranch_execz 65506                                      // 000000102E74: BFA5FFE2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1100>
	v_add_nc_u32_e32 v129, 1, v130                             // 000000102E78: 4B030481
	s_and_not1_b32 s25, s25, exec_lo                           // 000000102E7C: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 000000102E80: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000102E84: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 000000102E88: 7C9503A1
	s_and_b32 s27, vcc_lo, exec_lo                             // 000000102E8C: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 000000102E90: 8C191B19
	s_branch 65498                                             // 000000102E94: BFA0FFDA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1100>
	s_set_inst_prefetch_distance 0x2                           // 000000102E98: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 000000102E9C: 8C7E167E
	v_mov_b32_e32 v133, 0                                      // 000000102EA0: 7F0A0280
	v_mov_b32_e32 v129, v161                                   // 000000102EA4: 7F0203A1
	s_and_saveexec_b32 s22, s9                                 // 000000102EA8: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000102EAC: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 000000102EB0: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v131                          // 000000102EB4: 7C950607
	v_mov_b32_e32 v129, v130                                   // 000000102EB8: 7F020382
	v_cndmask_b32_e64 v133, 0, 15, vcc_lo                      // 000000102EBC: D5010085 01A91E80
	s_or_b32 exec_lo, exec_lo, s9                              // 000000102EC4: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000102EC8: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 000000102ECC: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000102ED0: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000102ED4: 8C7E017E
	s_or_b32 s8, s7, 1                                         // 000000102ED8: 8C088107
	s_mov_b32 s1, exec_lo                                      // 000000102EDC: BE81007E
	.long 0xd4c6007e                                           // 000000102EE0: D4C6007E
	v_cndmask_b32_e32 v1, s8, v169, vcc_lo                     // 000000102EE4: 02035208
	s_xor_b32 s1, exec_lo, s1                                  // 000000102EE8: 8D01017E
	v_or_b32_e32 v133, 0xf0, v133                              // 000000102EEC: 390B0AFF 000000F0
	s_and_not1_saveexec_b32 s1, s1                             // 000000102EF4: BE813001
	s_cbranch_execz 70                                         // 000000102EF8: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1314>
	s_mov_b32 s9, exec_lo                                      // 000000102EFC: BE89007E
	.long 0xd4c1007e                                           // 000000102F00: D4C1007E
	v_cndmask_b32_e32 v1, v129, v161, vcc_lo                   // 000000102F04: 02034381
	s_cbranch_execz 64                                         // 000000102F08: BFA50040 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x130c>
	s_mov_b32 s24, 0                                           // 000000102F0C: BE980080
	s_set_inst_prefetch_distance 0x1                           // 000000102F10: BF840001
	s_branch 20                                                // 000000102F14: BFA00014 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1268>
	s_nop 0                                                    // 000000102F18: BF800000
	s_nop 0                                                    // 000000102F1C: BF800000
	s_nop 0                                                    // 000000102F20: BF800000
	s_nop 0                                                    // 000000102F24: BF800000
	s_nop 0                                                    // 000000102F28: BF800000
	s_nop 0                                                    // 000000102F2C: BF800000
	s_nop 0                                                    // 000000102F30: BF800000
	s_nop 0                                                    // 000000102F34: BF800000
	s_nop 0                                                    // 000000102F38: BF800000
	s_nop 0                                                    // 000000102F3C: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 000000102F40: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000102F44: BF870499
	s_and_b32 s27, exec_lo, s26                                // 000000102F48: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 000000102F4C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 000000102F50: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 000000102F54: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000102F58: BF870009
	s_or_b32 s22, s22, s27                                     // 000000102F5C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 000000102F60: 917E187E
	s_cbranch_execz 27                                         // 000000102F64: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x12d4>
	v_mov_b32_e32 v130, v129                                   // 000000102F68: 7F040381
	s_or_b32 s25, s25, exec_lo                                 // 000000102F6C: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 000000102F70: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 000000102F74: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000102F78: BF870091
	v_ashrrev_i32_e32 v131, 31, v130                           // 000000102F7C: 3507049F
	.long 0xd73c0083                                           // 000000102F80: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 000000102F84: 02030482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000102F88: BF870091
	.long 0xd7006a83                                           // 000000102F8C: D7006A83
	v_cndmask_b32_e32 v1, v144, v131, vcc_lo                   // 000000102F90: 02030790
	v_add_co_ci_u32_e64 v132, null, v145, v132, vcc_lo         // 000000102F94: D5207C84 01AB0991
	global_load_b32 v131, v[131:132], off                      // 000000102F9C: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 000000102FA4: BF8903F7
	.long 0xd4c6007e                                           // 000000102FA8: D4C6007E
	v_cndmask_b32_e32 v1, s7, v131, vcc_lo                     // 000000102FAC: 02030607
	s_cbranch_execz 65507                                      // 000000102FB0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	v_add_nc_u32_e32 v129, 1, v130                             // 000000102FB4: 4B030481
	s_and_not1_b32 s26, s26, exec_lo                           // 000000102FB8: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 000000102FBC: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000102FC0: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 000000102FC4: 7C9503A1
	s_and_b32 s28, vcc_lo, exec_lo                             // 000000102FC8: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 000000102FCC: 8C1A1C1A
	s_branch 65499                                             // 000000102FD0: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1240>
	s_set_inst_prefetch_distance 0x2                           // 000000102FD4: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 000000102FD8: 8C7E187E
	v_mov_b32_e32 v129, v161                                   // 000000102FDC: 7F0203A1
	s_and_saveexec_b32 s24, s22                                // 000000102FE0: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000102FE4: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 000000102FE8: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v131                          // 000000102FEC: 7C950608
	v_cndmask_b32_e64 v129, 0, 0xf0, vcc_lo                    // 000000102FF0: D5010081 01A9FE80 000000F0
	s_delay_alu instid0(VALU_DEP_1)                            // 000000102FFC: BF870001
	v_or_b32_e32 v133, v129, v133                              // 000000103000: 390B0B81
	v_mov_b32_e32 v129, v130                                   // 000000103004: 7F020382
	s_or_b32 exec_lo, exec_lo, s22                             // 000000103008: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010300C: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 000000103010: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000103014: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000103018: 8C7E017E
	s_or_b32 s8, s7, 2                                         // 00000010301C: 8C088207
	s_mov_b32 s1, exec_lo                                      // 000000103020: BE81007E
	.long 0xd4c6007e                                           // 000000103024: D4C6007E
	v_cndmask_b32_e32 v1, s8, v169, vcc_lo                     // 000000103028: 02035208
	s_xor_b32 s1, exec_lo, s1                                  // 00000010302C: 8D01017E
	v_or_b32_e32 v133, 0xf00, v133                             // 000000103030: 390B0AFF 00000F00
	s_and_not1_saveexec_b32 s1, s1                             // 000000103038: BE813001
	s_cbranch_execz 69                                         // 00000010303C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1454>
	s_mov_b32 s9, exec_lo                                      // 000000103040: BE89007E
	.long 0xd4c1007e                                           // 000000103044: D4C1007E
	v_cndmask_b32_e32 v1, v129, v161, vcc_lo                   // 000000103048: 02034381
	s_cbranch_execz 63                                         // 00000010304C: BFA5003F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x144c>
	s_mov_b32 s24, 0                                           // 000000103050: BE980080
	s_set_inst_prefetch_distance 0x1                           // 000000103054: BF840001
	s_branch 19                                                // 000000103058: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x13a8>
	s_nop 0                                                    // 00000010305C: BF800000
	s_nop 0                                                    // 000000103060: BF800000
	s_nop 0                                                    // 000000103064: BF800000
	s_nop 0                                                    // 000000103068: BF800000
	s_nop 0                                                    // 00000010306C: BF800000
	s_nop 0                                                    // 000000103070: BF800000
	s_nop 0                                                    // 000000103074: BF800000
	s_nop 0                                                    // 000000103078: BF800000
	s_nop 0                                                    // 00000010307C: BF800000
	s_or_b32 exec_lo, exec_lo, s27                             // 000000103080: 8C7E1B7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000103084: BF870499
	s_and_b32 s27, exec_lo, s26                                // 000000103088: 8B1B1A7E
	s_or_b32 s24, s27, s24                                     // 00000010308C: 8C18181B
	s_and_not1_b32 s22, s22, exec_lo                           // 000000103090: 91167E16
	s_and_b32 s27, s25, exec_lo                                // 000000103094: 8B1B7E19
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000103098: BF870009
	s_or_b32 s22, s22, s27                                     // 00000010309C: 8C161B16
	s_and_not1_b32 exec_lo, exec_lo, s24                       // 0000001030A0: 917E187E
	s_cbranch_execz 27                                         // 0000001030A4: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1414>
	v_mov_b32_e32 v130, v129                                   // 0000001030A8: 7F040381
	s_or_b32 s25, s25, exec_lo                                 // 0000001030AC: 8C197E19
	s_or_b32 s26, s26, exec_lo                                 // 0000001030B0: 8C1A7E1A
	s_mov_b32 s27, exec_lo                                     // 0000001030B4: BE9B007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001030B8: BF870091
	v_ashrrev_i32_e32 v131, 31, v130                           // 0000001030BC: 3507049F
	.long 0xd73c0083                                           // 0000001030C0: D73C0083
	v_cndmask_b32_e32 v1, 2, v130, vcc_lo                      // 0000001030C4: 02030482
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001030C8: BF870091
	.long 0xd7006a83                                           // 0000001030CC: D7006A83
	v_cndmask_b32_e32 v1, v144, v131, vcc_lo                   // 0000001030D0: 02030790
	v_add_co_ci_u32_e64 v132, null, v145, v132, vcc_lo         // 0000001030D4: D5207C84 01AB0991
	global_load_b32 v131, v[131:132], off                      // 0000001030DC: DC520000 837C0083
	s_waitcnt vmcnt(0)                                         // 0000001030E4: BF8903F7
	.long 0xd4c4007e                                           // 0000001030E8: D4C4007E
	v_cndmask_b32_e32 v1, s8, v131, vcc_lo                     // 0000001030EC: 02030608
	s_cbranch_execz 65507                                      // 0000001030F0: BFA5FFE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1380>
	v_add_nc_u32_e32 v129, 1, v130                             // 0000001030F4: 4B030481
	s_and_not1_b32 s26, s26, exec_lo                           // 0000001030F8: 911A7E1A
	s_and_not1_b32 s25, s25, exec_lo                           // 0000001030FC: 91197E19
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000103100: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 000000103104: 7C9503A1
	s_and_b32 s28, vcc_lo, exec_lo                             // 000000103108: 8B1C7E6A
	s_or_b32 s26, s26, s28                                     // 00000010310C: 8C1A1C1A
	s_branch 65499                                             // 000000103110: BFA0FFDB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1380>
	s_set_inst_prefetch_distance 0x2                           // 000000103114: BF840002
	s_or_b32 exec_lo, exec_lo, s24                             // 000000103118: 8C7E187E
	v_mov_b32_e32 v129, v161                                   // 00000010311C: 7F0203A1
	s_and_saveexec_b32 s24, s22                                // 000000103120: BE982016
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000103124: BF870009
	s_xor_b32 s22, exec_lo, s24                                // 000000103128: 8D16187E
	v_cmp_eq_u32_e32 vcc_lo, s8, v131                          // 00000010312C: 7C950608
	v_cndmask_b32_e64 v129, 0, 0xf00, vcc_lo                   // 000000103130: D5010081 01A9FE80 00000F00
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010313C: BF870001
	v_or_b32_e32 v133, v129, v133                              // 000000103140: 390B0B81
	v_mov_b32_e32 v129, v130                                   // 000000103144: 7F020382
	s_or_b32 exec_lo, exec_lo, s22                             // 000000103148: 8C7E167E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010314C: BF870009
	s_or_b32 exec_lo, exec_lo, s9                              // 000000103150: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000103154: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 000000103158: 8C7E017E
	s_or_b32 s7, s7, 3                                         // 00000010315C: 8C078307
	s_mov_b32 s1, exec_lo                                      // 000000103160: BE81007E
	.long 0xd4c6007e                                           // 000000103164: D4C6007E
	v_cndmask_b32_e32 v1, s7, v169, vcc_lo                     // 000000103168: 02035207
	s_xor_b32 s1, exec_lo, s1                                  // 00000010316C: 8D01017E
	v_or_b32_e32 v133, 0xf000, v133                            // 000000103170: 390B0AFF 0000F000
	s_and_not1_saveexec_b32 s1, s1                             // 000000103178: BE813001
	s_cbranch_execz 66                                         // 00000010317C: BFA50042 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1588>
	s_mov_b32 s8, exec_lo                                      // 000000103180: BE88007E
	.long 0xd4c1007e                                           // 000000103184: D4C1007E
	v_cndmask_b32_e32 v1, v129, v161, vcc_lo                   // 000000103188: 02034381
	s_cbranch_execz 60                                         // 00000010318C: BFA5003C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1580>
	s_mov_b32 s22, 0                                           // 000000103190: BE960080
	s_set_inst_prefetch_distance 0x1                           // 000000103194: BF840001
	s_branch 19                                                // 000000103198: BFA00013 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14e8>
	s_nop 0                                                    // 00000010319C: BF800000
	s_nop 0                                                    // 0000001031A0: BF800000
	s_nop 0                                                    // 0000001031A4: BF800000
	s_nop 0                                                    // 0000001031A8: BF800000
	s_nop 0                                                    // 0000001031AC: BF800000
	s_nop 0                                                    // 0000001031B0: BF800000
	s_nop 0                                                    // 0000001031B4: BF800000
	s_nop 0                                                    // 0000001031B8: BF800000
	s_nop 0                                                    // 0000001031BC: BF800000
	s_or_b32 exec_lo, exec_lo, s26                             // 0000001031C0: 8C7E1A7E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000001031C4: BF870499
	s_and_b32 s26, exec_lo, s25                                // 0000001031C8: 8B1A197E
	s_or_b32 s22, s26, s22                                     // 0000001031CC: 8C16161A
	s_and_not1_b32 s9, s9, exec_lo                             // 0000001031D0: 91097E09
	s_and_b32 s26, s24, exec_lo                                // 0000001031D4: 8B1A7E18
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001031D8: BF870009
	s_or_b32 s9, s9, s26                                       // 0000001031DC: 8C091A09
	s_and_not1_b32 exec_lo, exec_lo, s22                       // 0000001031E0: 917E167E
	s_cbranch_execz 26                                         // 0000001031E4: BFA5001A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1550>
	v_ashrrev_i32_e32 v130, 31, v129                           // 0000001031E8: 3505029F
	s_or_b32 s24, s24, exec_lo                                 // 0000001031EC: 8C187E18
	s_or_b32 s25, s25, exec_lo                                 // 0000001031F0: 8C197E19
	s_mov_b32 s26, exec_lo                                     // 0000001031F4: BE9A007E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001031F8: BF870091
	.long 0xd73c0082                                           // 0000001031FC: D73C0082
	v_cndmask_b32_e32 v1, 2, v129, vcc_lo                      // 000000103200: 02030282
	.long 0xd7006a82                                           // 000000103204: D7006A82
	v_cndmask_b32_e32 v1, v144, v130, vcc_lo                   // 000000103208: 02030590
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010320C: BF870001
	v_add_co_ci_u32_e64 v131, null, v145, v131, vcc_lo         // 000000103210: D5207C83 01AB0791
	global_load_b32 v130, v[130:131], off                      // 000000103218: DC520000 827C0082
	s_waitcnt vmcnt(0)                                         // 000000103220: BF8903F7
	.long 0xd4c4007e                                           // 000000103224: D4C4007E
	v_cndmask_b32_e32 v1, s7, v130, vcc_lo                     // 000000103228: 02030407
	s_cbranch_execz 65508                                      // 00000010322C: BFA5FFE4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	v_add_nc_u32_e32 v129, 1, v129                             // 000000103230: 4B030281
	s_and_not1_b32 s25, s25, exec_lo                           // 000000103234: 91197E19
	s_and_not1_b32 s24, s24, exec_lo                           // 000000103238: 91187E18
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 00000010323C: BF8704A1
	v_cmp_eq_u32_e32 vcc_lo, v161, v129                        // 000000103240: 7C9503A1
	s_and_b32 s27, vcc_lo, exec_lo                             // 000000103244: 8B1B7E6A
	s_or_b32 s25, s25, s27                                     // 000000103248: 8C191B19
	s_branch 65500                                             // 00000010324C: BFA0FFDC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x14c0>
	s_set_inst_prefetch_distance 0x2                           // 000000103250: BF840002
	s_or_b32 exec_lo, exec_lo, s22                             // 000000103254: 8C7E167E
	s_and_saveexec_b32 s22, s9                                 // 000000103258: BE962009
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010325C: BF870009
	s_xor_b32 s9, exec_lo, s22                                 // 000000103260: 8D09167E
	v_cmp_eq_u32_e32 vcc_lo, s7, v130                          // 000000103264: 7C950407
	v_cndmask_b32_e64 v129, 0, 0xf000, vcc_lo                  // 000000103268: D5010081 01A9FE80 0000F000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000103274: BF870001
	v_or_b32_e32 v133, v129, v133                              // 000000103278: 390B0B81
	s_or_b32 exec_lo, exec_lo, s9                              // 00000010327C: 8C7E097E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000103280: BF870009
	s_or_b32 exec_lo, exec_lo, s8                              // 000000103284: 8C7E087E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000103288: BF870009
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010328C: 8C7E017E
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000103290: BF8704C9
	s_or_b32 exec_lo, exec_lo, s4                              // 000000103294: 8C7E047E
	v_cmp_eq_u32_e32 vcc_lo, 0xffff, v133                      // 000000103298: 7C950AFF 0000FFFF
	s_cmp_eq_u32 vcc_lo, -1                                    // 0000001032A0: BF06C16A
	s_cselect_b32 s1, -1, 0                                    // 0000001032A4: 980180C1
	v_cndmask_b32_e64 v129, 0, 1, s1                           // 0000001032A8: D5010081 00050280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001032B0: BF870001
	v_readfirstlane_b32 s1, v129                               // 0000001032B4: 7E020581
	s_bitcmp0_b32 s1, 0                                        // 0000001032B8: BF0C8001
	s_mov_b32 s1, 0                                            // 0000001032BC: BE810080
	s_cbranch_scc1 8                                           // 0000001032C0: BFA20008 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x15e4>
	s_or_b32 s1, s2, 15                                        // 0000001032C4: 8C018F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001032C8: BF8700A9
	v_cmp_le_i32_e32 vcc_lo, s1, v167                          // 0000001032CC: 7C874E01
	v_cndmask_b32_e64 v129, 0, 1, vcc_lo                       // 0000001032D0: D5010081 01A90280
	v_readfirstlane_b32 s1, v129                               // 0000001032D8: 7E020581
	s_bitcmp1_b32 s1, 0                                        // 0000001032DC: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 0000001032E0: 980180C1
	s_and_saveexec_b32 s4, s3                                  // 0000001032E4: BE842003
	s_cbranch_execz 1631                                       // 0000001032E8: BFA5065F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2f68>
	ds_load_b32 v131, v171                                     // 0000001032EC: D8D80000 830000AB
	s_xor_b32 s1, s1, -1                                       // 0000001032F4: 8D01C101
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001032F8: BF870009
	s_and_not1_b32 vcc_lo, exec_lo, s1                         // 0000001032FC: 916A017E
	s_mov_b32 s1, -1                                           // 000000103300: BE8100C1
	s_cbranch_vccnz 987                                        // 000000103304: BFA403DB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2574>
	s_waitcnt lgkmcnt(0)                                       // 000000103308: BF89FC07
	v_dual_mov_b32 v132, v131 :: v_dual_and_b32 v129, 1, v133  // 00000010330C: CA240183 84810A81
	v_cmp_le_i32_e32 vcc_lo, s2, v170                          // 000000103314: 7C875402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000103318: BF8704A2
	.long 0xd44a0001                                           // 00000010331C: D44A0001
	v_cndmask_b32_e32 v1, 1, v129, vcc_lo                      // 000000103320: 02030281
	s_and_b32 s35, vcc_lo, s1                                  // 000000103324: 8B23016A
	s_and_saveexec_b32 s1, s35                                 // 000000103328: BE812023
	s_cbranch_execz 7                                          // 00000010332C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x164c>
	ds_load_b32 v129, v172                                     // 000000103330: D8D80000 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103338: BF89FC07
	v_dual_max_f32 v130, v131, v131 :: v_dual_max_f32 v129, v129, v129// 00000010333C: CA950783 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000103344: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000103348: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010334C: 8C7E017E
	v_and_b32_e32 v129, 2, v133                                // 000000103350: 37030A82
	v_cmp_lt_i32_e32 vcc_lo, s2, v170                          // 000000103354: 7C835402
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(SALU_CYCLE_1)// 000000103358: BF8704A2
	.long 0xd44d0001                                           // 00000010335C: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000103360: 02030280
	s_and_b32 s34, vcc_lo, s1                                  // 000000103364: 8B22016A
	s_and_saveexec_b32 s1, s34                                 // 000000103368: BE812022
	s_cbranch_execz 7                                          // 00000010336C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x168c>
	ds_load_b32 v129, v172 offset:4                            // 000000103370: D8D80004 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103378: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 00000010337C: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000103384: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000103388: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010338C: 8C7E017E
	v_and_b32_e32 v129, 4, v133                                // 000000103390: 37030A84
	s_or_b32 s1, s2, 2                                         // 000000103394: 8C018202
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000103398: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 00000010339C: 7C875401
	.long 0xd44d0001                                           // 0000001033A0: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 0000001033A4: 02030280
	s_and_b32 s33, vcc_lo, s1                                  // 0000001033A8: 8B21016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001033AC: BF870009
	s_and_saveexec_b32 s1, s33                                 // 0000001033B0: BE812021
	s_cbranch_execz 7                                          // 0000001033B4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x16d4>
	ds_load_b32 v129, v172 offset:8                            // 0000001033B8: D8D80008 810000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001033C0: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 0000001033C4: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001033CC: BF870001
	v_max_f32_e32 v132, v130, v129                             // 0000001033D0: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001033D4: 8C7E017E
	v_and_b32_e32 v129, 8, v133                                // 0000001033D8: 37030A88
	s_or_b32 s1, s2, 3                                         // 0000001033DC: 8C018302
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001033E0: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 0000001033E4: 7C875401
	.long 0xd44d0001                                           // 0000001033E8: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 0000001033EC: 02030280
	s_and_b32 s31, vcc_lo, s1                                  // 0000001033F0: 8B1F016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001033F4: BF870009
	s_and_saveexec_b32 s1, s31                                 // 0000001033F8: BE81201F
	s_cbranch_execz 7                                          // 0000001033FC: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x171c>
	ds_load_b32 v129, v172 offset:12                           // 000000103400: D8D8000C 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103408: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 00000010340C: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000103414: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000103418: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010341C: 8C7E017E
	v_and_b32_e32 v129, 16, v133                               // 000000103420: 37030A90
	s_or_b32 s1, s2, 4                                         // 000000103424: 8C018402
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000103428: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 00000010342C: 7C875401
	.long 0xd44d0001                                           // 000000103430: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000103434: 02030280
	s_and_b32 s30, vcc_lo, s1                                  // 000000103438: 8B1E016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010343C: BF870009
	s_and_saveexec_b32 s1, s30                                 // 000000103440: BE81201E
	s_cbranch_execz 7                                          // 000000103444: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1764>
	ds_load_b32 v129, v172 offset:16                           // 000000103448: D8D80010 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103450: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000103454: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010345C: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000103460: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000103464: 8C7E017E
	v_and_b32_e32 v129, 32, v133                               // 000000103468: 37030AA0
	s_or_b32 s1, s2, 5                                         // 00000010346C: 8C018502
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000103470: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 000000103474: 7C875401
	.long 0xd44d0001                                           // 000000103478: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 00000010347C: 02030280
	s_and_b32 s29, vcc_lo, s1                                  // 000000103480: 8B1D016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000103484: BF870009
	s_and_saveexec_b32 s1, s29                                 // 000000103488: BE81201D
	s_cbranch_execz 7                                          // 00000010348C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17ac>
	ds_load_b32 v129, v172 offset:20                           // 000000103490: D8D80014 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103498: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 00000010349C: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001034A4: BF870001
	v_max_f32_e32 v132, v130, v129                             // 0000001034A8: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001034AC: 8C7E017E
	v_and_b32_e32 v129, 64, v133                               // 0000001034B0: 37030AC0
	s_or_b32 s1, s2, 6                                         // 0000001034B4: 8C018602
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001034B8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 0000001034BC: 7C875401
	.long 0xd44d0001                                           // 0000001034C0: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 0000001034C4: 02030280
	s_and_b32 s28, vcc_lo, s1                                  // 0000001034C8: 8B1C016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001034CC: BF870009
	s_and_saveexec_b32 s1, s28                                 // 0000001034D0: BE81201C
	s_cbranch_execz 7                                          // 0000001034D4: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x17f4>
	ds_load_b32 v129, v172 offset:24                           // 0000001034D8: D8D80018 810000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001034E0: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 0000001034E4: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001034EC: BF870001
	v_max_f32_e32 v132, v130, v129                             // 0000001034F0: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001034F4: 8C7E017E
	v_and_b32_e32 v129, 0x80, v133                             // 0000001034F8: 37030AFF 00000080
	s_or_b32 s1, s2, 7                                         // 000000103500: 8C018702
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000103504: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 000000103508: 7C875401
	.long 0xd44d0001                                           // 00000010350C: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000103510: 02030280
	s_and_b32 s27, vcc_lo, s1                                  // 000000103514: 8B1B016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000103518: BF870009
	s_and_saveexec_b32 s1, s27                                 // 00000010351C: BE81201B
	s_cbranch_execz 7                                          // 000000103520: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1840>
	ds_load_b32 v129, v172 offset:28                           // 000000103524: D8D8001C 810000AC
	s_waitcnt lgkmcnt(0)                                       // 00000010352C: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000103530: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000103538: BF870001
	v_max_f32_e32 v132, v130, v129                             // 00000010353C: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000103540: 8C7E017E
	v_and_b32_e32 v129, 0x100, v133                            // 000000103544: 37030AFF 00000100
	s_or_b32 s1, s2, 8                                         // 00000010354C: 8C018802
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000103550: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 000000103554: 7C875401
	.long 0xd44d0001                                           // 000000103558: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 00000010355C: 02030280
	s_and_b32 s26, vcc_lo, s1                                  // 000000103560: 8B1A016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000103564: BF870009
	s_and_saveexec_b32 s1, s26                                 // 000000103568: BE81201A
	s_cbranch_execz 7                                          // 00000010356C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x188c>
	ds_load_b32 v129, v172 offset:32                           // 000000103570: D8D80020 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103578: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 00000010357C: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000103584: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000103588: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 00000010358C: 8C7E017E
	v_and_b32_e32 v129, 0x200, v133                            // 000000103590: 37030AFF 00000200
	s_or_b32 s1, s2, 9                                         // 000000103598: 8C018902
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010359C: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 0000001035A0: 7C875401
	.long 0xd44d0001                                           // 0000001035A4: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 0000001035A8: 02030280
	s_and_b32 s25, vcc_lo, s1                                  // 0000001035AC: 8B19016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001035B0: BF870009
	s_and_saveexec_b32 s1, s25                                 // 0000001035B4: BE812019
	s_cbranch_execz 7                                          // 0000001035B8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x18d8>
	ds_load_b32 v129, v172 offset:36                           // 0000001035BC: D8D80024 810000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001035C4: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 0000001035C8: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001035D0: BF870001
	v_max_f32_e32 v132, v130, v129                             // 0000001035D4: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001035D8: 8C7E017E
	v_and_b32_e32 v129, 0x400, v133                            // 0000001035DC: 37030AFF 00000400
	s_or_b32 s1, s2, 10                                        // 0000001035E4: 8C018A02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001035E8: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 0000001035EC: 7C875401
	.long 0xd44d0001                                           // 0000001035F0: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 0000001035F4: 02030280
	s_and_b32 s24, vcc_lo, s1                                  // 0000001035F8: 8B18016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001035FC: BF870009
	s_and_saveexec_b32 s1, s24                                 // 000000103600: BE812018
	s_cbranch_execz 7                                          // 000000103604: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1924>
	ds_load_b32 v129, v172 offset:40                           // 000000103608: D8D80028 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103610: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000103614: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010361C: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000103620: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000103624: 8C7E017E
	v_and_b32_e32 v129, 0x800, v133                            // 000000103628: 37030AFF 00000800
	s_or_b32 s1, s2, 11                                        // 000000103630: 8C018B02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000103634: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 000000103638: 7C875401
	.long 0xd44d0001                                           // 00000010363C: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000103640: 02030280
	s_and_b32 s22, vcc_lo, s1                                  // 000000103644: 8B16016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000103648: BF870009
	s_and_saveexec_b32 s1, s22                                 // 00000010364C: BE812016
	s_cbranch_execz 7                                          // 000000103650: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1970>
	ds_load_b32 v129, v172 offset:44                           // 000000103654: D8D8002C 810000AC
	s_waitcnt lgkmcnt(0)                                       // 00000010365C: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000103660: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000103668: BF870001
	v_max_f32_e32 v132, v130, v129                             // 00000010366C: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000103670: 8C7E017E
	v_and_b32_e32 v129, 0x1000, v133                           // 000000103674: 37030AFF 00001000
	s_or_b32 s1, s2, 12                                        // 00000010367C: 8C018C02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000103680: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 000000103684: 7C875401
	.long 0xd44d0001                                           // 000000103688: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 00000010368C: 02030280
	s_and_b32 s9, vcc_lo, s1                                   // 000000103690: 8B09016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000103694: BF870009
	s_and_saveexec_b32 s1, s9                                  // 000000103698: BE812009
	s_cbranch_execz 7                                          // 00000010369C: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x19bc>
	ds_load_b32 v129, v172 offset:48                           // 0000001036A0: D8D80030 810000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001036A8: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 0000001036AC: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001036B4: BF870001
	v_max_f32_e32 v132, v130, v129                             // 0000001036B8: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001036BC: 8C7E017E
	v_and_b32_e32 v129, 0x2000, v133                           // 0000001036C0: 37030AFF 00002000
	s_or_b32 s1, s2, 13                                        // 0000001036C8: 8C018D02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001036CC: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 0000001036D0: 7C875401
	.long 0xd44d0001                                           // 0000001036D4: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 0000001036D8: 02030280
	s_and_b32 s8, vcc_lo, s1                                   // 0000001036DC: 8B08016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001036E0: BF870009
	s_and_saveexec_b32 s1, s8                                  // 0000001036E4: BE812008
	s_cbranch_execz 7                                          // 0000001036E8: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a08>
	ds_load_b32 v129, v172 offset:52                           // 0000001036EC: D8D80034 810000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001036F4: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 0000001036F8: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000103700: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000103704: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000103708: 8C7E017E
	v_and_b32_e32 v129, 0x4000, v133                           // 00000010370C: 37030AFF 00004000
	s_or_b32 s1, s2, 14                                        // 000000103714: 8C018E02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000103718: BF870119
	v_cmp_le_i32_e32 vcc_lo, s1, v170                          // 00000010371C: 7C875401
	.long 0xd44d0001                                           // 000000103720: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000103724: 02030280
	s_and_b32 s7, vcc_lo, s1                                   // 000000103728: 8B07016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000010372C: BF870009
	s_and_saveexec_b32 s1, s7                                  // 000000103730: BE812007
	s_cbranch_execz 7                                          // 000000103734: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1a54>
	ds_load_b32 v129, v172 offset:56                           // 000000103738: D8D80038 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103740: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000103744: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010374C: BF870001
	v_max_f32_e32 v132, v130, v129                             // 000000103750: 21090382
	s_or_b32 exec_lo, exec_lo, s1                              // 000000103754: 8C7E017E
	v_and_b32_e32 v129, 0x8000, v133                           // 000000103758: 37030AFF 00008000
	s_or_b32 s2, s2, 15                                        // 000000103760: 8C028F02
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000103764: BF870119
	v_cmp_le_i32_e32 vcc_lo, s2, v170                          // 000000103768: 7C875402
	.long 0xd44d0001                                           // 00000010376C: D44D0001
	v_cndmask_b32_e32 v1, 0, v129, vcc_lo                      // 000000103770: 02030280
	s_and_b32 s1, vcc_lo, s1                                   // 000000103774: 8B01016A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000103778: BF870009
	s_and_saveexec_b32 s2, s1                                  // 00000010377C: BE822001
	s_cbranch_execz 7                                          // 000000103780: BFA50007 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1aa0>
	ds_load_b32 v129, v172 offset:60                           // 000000103784: D8D8003C 810000AC
	s_waitcnt lgkmcnt(0)                                       // 00000010378C: BF89FC07
	v_dual_max_f32 v130, v132, v132 :: v_dual_max_f32 v129, v129, v129// 000000103790: CA950984 82810381
	s_delay_alu instid0(VALU_DEP_1)                            // 000000103798: BF870001
	v_max_f32_e32 v132, v130, v129                             // 00000010379C: 21090382
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001037A0: 8C7E027E
	v_dual_mov_b32 v129, 0 :: v_dual_mov_b32 v130, 0           // 0000001037A4: CA100080 81820080
	s_and_saveexec_b32 s2, s35                                 // 0000001037AC: BE822023
	s_cbranch_execz 30                                         // 0000001037B0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1b2c>
	ds_load_b32 v130, v172                                     // 0000001037B4: D8D80000 820000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001037BC: BF89FC07
	v_sub_f32_e32 v130, v130, v132                             // 0000001037C0: 09050982
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001037C4: BF870091
	v_mul_f32_e32 v133, 0x3fb8aa3b, v130                       // 0000001037C8: 110B04FF 3FB8AA3B
	v_fma_f32 v134, 0x3fb8aa3b, v130, -v133                    // 0000001037D0: D6130086 861704FF 3FB8AA3B
	v_rndne_f32_e32 v135, v133                                 // 0000001037DC: 7F0E4785
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001037E0: BF870221
	v_sub_f32_e32 v133, v133, v135                             // 0000001037E4: 090B0F85
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 0000001037E8: 7C3704FF C2CE8ED0
	v_fmac_f32_e32 v134, 0x32a5705f, v130                      // 0000001037F0: 570D04FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001037F8: BF870121
	v_add_f32_e32 v133, v133, v134                             // 0000001037FC: 070B0D85
	v_cvt_i32_f32_e32 v134, v135                               // 000000103800: 7F0C1187
	v_exp_f32_e32 v133, v133                                   // 000000103804: 7F0A4B85
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103808: BF870095
	.long 0xd71c0085                                           // 00000010380C: D71C0085
	v_cndmask_b32_e32 v1, v133, v134, vcc_lo                   // 000000103810: 02030D85
	v_cndmask_b32_e32 v133, 0, v133, vcc_lo                    // 000000103814: 030B0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 000000103818: 7C3D04FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000103820: BF870002
	v_cndmask_b32_e32 v130, 0x7f800000, v133, vcc_lo           // 000000103824: 03050AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 00000010382C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103830: BF870091
	v_bfe_u32 v133, v130, 16, 1                                // 000000103834: D6100085 02052182
	v_add3_u32 v133, v130, v133, 0x7fff                        // 00000010383C: D6550085 03FF0B82 00007FFF
	ds_store_b16_d16_hi v173, v133                             // 000000103848: DA840000 000085AD
	s_and_saveexec_b32 s2, s34                                 // 000000103850: BE822022
	s_cbranch_execz 29                                         // 000000103854: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1bcc>
	ds_load_b32 v129, v172 offset:4                            // 000000103858: D8D80004 810000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103860: BF89FC07
	v_sub_f32_e32 v129, v129, v132                             // 000000103864: 09030981
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103868: BF870121
	v_mul_f32_e32 v133, 0x3fb8aa3b, v129                       // 00000010386C: 110B02FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v129                 // 000000103874: 7C3702FF C2CE8ED0
	v_fma_f32 v134, 0x3fb8aa3b, v129, -v133                    // 00000010387C: D6130086 861702FF 3FB8AA3B
	v_rndne_f32_e32 v135, v133                                 // 000000103888: 7F0E4785
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010388C: BF870091
	v_dual_fmac_f32 v134, 0x32a5705f, v129 :: v_dual_sub_f32 v133, v133, v135// 000000103890: C80B02FF 86850F85 32A5705F
	v_add_f32_e32 v133, v133, v134                             // 00000010389C: 070B0D85
	v_cvt_i32_f32_e32 v134, v135                               // 0000001038A0: 7F0C1187
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001038A4: BF870292
	v_exp_f32_e32 v133, v133                                   // 0000001038A8: 7F0A4B85
	.long 0xd71c0085                                           // 0000001038AC: D71C0085
	v_cndmask_b32_e32 v1, v133, v134, vcc_lo                   // 0000001038B0: 02030D85
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001038B4: BF870121
	v_cndmask_b32_e32 v133, 0, v133, vcc_lo                    // 0000001038B8: 030B0A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v129                 // 0000001038BC: 7C3D02FF 42B17218
	v_cndmask_b32_e32 v129, 0x7f800000, v133, vcc_lo           // 0000001038C4: 03030AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001038CC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001038D0: BF870121
	v_bfe_u32 v133, v129, 16, 1                                // 0000001038D4: D6100085 02052181
	v_mov_b32_e32 v134, 0                                      // 0000001038DC: 7F0C0280
	v_add3_u32 v135, v129, v133, 0x7fff                        // 0000001038E0: D6550087 03FF0B81 00007FFF
	v_mov_b32_e32 v133, 0                                      // 0000001038EC: 7F0A0280
	ds_store_b16_d16_hi v173, v135 offset:2                    // 0000001038F0: DA840002 000087AD
	s_and_saveexec_b32 s2, s33                                 // 0000001038F8: BE822021
	s_cbranch_execz 30                                         // 0000001038FC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1c78>
	ds_load_b32 v134, v172 offset:8                            // 000000103900: D8D80008 860000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103908: BF89FC07
	v_sub_f32_e32 v134, v134, v132                             // 00000010390C: 090D0986
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103910: BF870091
	v_mul_f32_e32 v135, 0x3fb8aa3b, v134                       // 000000103914: 110F0CFF 3FB8AA3B
	v_fma_f32 v136, 0x3fb8aa3b, v134, -v135                    // 00000010391C: D6130088 861F0CFF 3FB8AA3B
	v_rndne_f32_e32 v149, v135                                 // 000000103928: 7F2A4787
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010392C: BF870221
	v_sub_f32_e32 v135, v135, v149                             // 000000103930: 090F2B87
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 000000103934: 7C370CFF C2CE8ED0
	v_fmac_f32_e32 v136, 0x32a5705f, v134                      // 00000010393C: 57110CFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103944: BF870121
	v_add_f32_e32 v135, v135, v136                             // 000000103948: 070F1187
	v_cvt_i32_f32_e32 v136, v149                               // 00000010394C: 7F101195
	v_exp_f32_e32 v135, v135                                   // 000000103950: 7F0E4B87
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103954: BF870095
	.long 0xd71c0087                                           // 000000103958: D71C0087
	v_cndmask_b32_e32 v1, v135, v136, vcc_lo                   // 00000010395C: 02031187
	v_cndmask_b32_e32 v135, 0, v135, vcc_lo                    // 000000103960: 030F0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 000000103964: 7C3D0CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 00000010396C: BF870002
	v_cndmask_b32_e32 v134, 0x7f800000, v135, vcc_lo           // 000000103970: 030D0EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000103978: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010397C: BF870091
	v_bfe_u32 v135, v134, 16, 1                                // 000000103980: D6100087 02052186
	v_add3_u32 v135, v134, v135, 0x7fff                        // 000000103988: D6550087 03FF0F86 00007FFF
	ds_store_b16_d16_hi v173, v135 offset:4                    // 000000103994: DA840004 000087AD
	s_and_saveexec_b32 s2, s31                                 // 00000010399C: BE82201F
	s_cbranch_execz 30                                         // 0000001039A0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1d1c>
	ds_load_b32 v133, v172 offset:12                           // 0000001039A4: D8D8000C 850000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001039AC: BF89FC07
	v_sub_f32_e32 v133, v133, v132                             // 0000001039B0: 090B0985
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001039B4: BF870121
	v_mul_f32_e32 v135, 0x3fb8aa3b, v133                       // 0000001039B8: 110F0AFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v133                 // 0000001039C0: 7C370AFF C2CE8ED0
	v_fma_f32 v136, 0x3fb8aa3b, v133, -v135                    // 0000001039C8: D6130088 861F0AFF 3FB8AA3B
	v_rndne_f32_e32 v149, v135                                 // 0000001039D4: 7F2A4787
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001039D8: BF870112
	v_fmac_f32_e32 v136, 0x32a5705f, v133                      // 0000001039DC: 57110AFF 32A5705F
	v_sub_f32_e32 v135, v135, v149                             // 0000001039E4: 090F2B87
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001039E8: BF870121
	v_add_f32_e32 v135, v135, v136                             // 0000001039EC: 070F1187
	v_cvt_i32_f32_e32 v136, v149                               // 0000001039F0: 7F101195
	v_exp_f32_e32 v135, v135                                   // 0000001039F4: 7F0E4B87
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001039F8: BF870095
	.long 0xd71c0087                                           // 0000001039FC: D71C0087
	v_cndmask_b32_e32 v1, v135, v136, vcc_lo                   // 000000103A00: 02031187
	v_cndmask_b32_e32 v135, 0, v135, vcc_lo                    // 000000103A04: 030F0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v133                 // 000000103A08: 7C3D0AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000103A10: BF870002
	v_cndmask_b32_e32 v133, 0x7f800000, v135, vcc_lo           // 000000103A14: 030B0EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000103A1C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103A20: BF870121
	v_bfe_u32 v135, v133, 16, 1                                // 000000103A24: D6100087 02052185
	v_mov_b32_e32 v136, 0                                      // 000000103A2C: 7F100280
	v_add3_u32 v149, v133, v135, 0x7fff                        // 000000103A30: D6550095 03FF0F85 00007FFF
	v_mov_b32_e32 v135, 0                                      // 000000103A3C: 7F0E0280
	ds_store_b16_d16_hi v173, v149 offset:6                    // 000000103A40: DA840006 000095AD
	s_and_saveexec_b32 s2, s30                                 // 000000103A48: BE82201E
	s_cbranch_execz 30                                         // 000000103A4C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1dc8>
	ds_load_b32 v136, v172 offset:16                           // 000000103A50: D8D80010 880000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103A58: BF89FC07
	v_sub_f32_e32 v136, v136, v132                             // 000000103A5C: 09110988
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103A60: BF870091
	v_mul_f32_e32 v149, 0x3fb8aa3b, v136                       // 000000103A64: 112B10FF 3FB8AA3B
	v_fma_f32 v150, 0x3fb8aa3b, v136, -v149                    // 000000103A6C: D6130096 865710FF 3FB8AA3B
	v_rndne_f32_e32 v151, v149                                 // 000000103A78: 7F2E4795
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000103A7C: BF870221
	v_sub_f32_e32 v149, v149, v151                             // 000000103A80: 092B2F95
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v136                 // 000000103A84: 7C3710FF C2CE8ED0
	v_fmac_f32_e32 v150, 0x32a5705f, v136                      // 000000103A8C: 572D10FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103A94: BF870121
	v_add_f32_e32 v149, v149, v150                             // 000000103A98: 072B2D95
	v_cvt_i32_f32_e32 v150, v151                               // 000000103A9C: 7F2C1197
	v_exp_f32_e32 v149, v149                                   // 000000103AA0: 7F2A4B95
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103AA4: BF870095
	.long 0xd71c0095                                           // 000000103AA8: D71C0095
	v_cndmask_b32_e32 v1, v149, v150, vcc_lo                   // 000000103AAC: 02032D95
	v_cndmask_b32_e32 v149, 0, v149, vcc_lo                    // 000000103AB0: 032B2A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v136                 // 000000103AB4: 7C3D10FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000103ABC: BF870002
	v_cndmask_b32_e32 v136, 0x7f800000, v149, vcc_lo           // 000000103AC0: 03112AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000103AC8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103ACC: BF870091
	v_bfe_u32 v149, v136, 16, 1                                // 000000103AD0: D6100095 02052188
	v_add3_u32 v149, v136, v149, 0x7fff                        // 000000103AD8: D6550095 03FF2B88 00007FFF
	ds_store_b16_d16_hi v173, v149 offset:8                    // 000000103AE4: DA840008 000095AD
	s_and_saveexec_b32 s2, s29                                 // 000000103AEC: BE82201D
	s_cbranch_execz 30                                         // 000000103AF0: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1e6c>
	ds_load_b32 v135, v172 offset:20                           // 000000103AF4: D8D80014 870000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103AFC: BF89FC07
	v_sub_f32_e32 v135, v135, v132                             // 000000103B00: 090F0987
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103B04: BF870121
	v_mul_f32_e32 v149, 0x3fb8aa3b, v135                       // 000000103B08: 112B0EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 000000103B10: 7C370EFF C2CE8ED0
	v_fma_f32 v150, 0x3fb8aa3b, v135, -v149                    // 000000103B18: D6130096 86570EFF 3FB8AA3B
	v_rndne_f32_e32 v151, v149                                 // 000000103B24: 7F2E4795
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000103B28: BF870112
	v_fmac_f32_e32 v150, 0x32a5705f, v135                      // 000000103B2C: 572D0EFF 32A5705F
	v_sub_f32_e32 v149, v149, v151                             // 000000103B34: 092B2F95
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103B38: BF870121
	v_add_f32_e32 v149, v149, v150                             // 000000103B3C: 072B2D95
	v_cvt_i32_f32_e32 v150, v151                               // 000000103B40: 7F2C1197
	v_exp_f32_e32 v149, v149                                   // 000000103B44: 7F2A4B95
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103B48: BF870095
	.long 0xd71c0095                                           // 000000103B4C: D71C0095
	v_cndmask_b32_e32 v1, v149, v150, vcc_lo                   // 000000103B50: 02032D95
	v_cndmask_b32_e32 v149, 0, v149, vcc_lo                    // 000000103B54: 032B2A80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 000000103B58: 7C3D0EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000103B60: BF870002
	v_cndmask_b32_e32 v135, 0x7f800000, v149, vcc_lo           // 000000103B64: 030F2AFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000103B6C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103B70: BF870121
	v_bfe_u32 v149, v135, 16, 1                                // 000000103B74: D6100095 02052187
	v_mov_b32_e32 v150, 0                                      // 000000103B7C: 7F2C0280
	v_add3_u32 v151, v135, v149, 0x7fff                        // 000000103B80: D6550097 03FF2B87 00007FFF
	v_mov_b32_e32 v149, 0                                      // 000000103B8C: 7F2A0280
	ds_store_b16_d16_hi v173, v151 offset:10                   // 000000103B90: DA84000A 000097AD
	s_and_saveexec_b32 s2, s28                                 // 000000103B98: BE82201C
	s_cbranch_execz 30                                         // 000000103B9C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1f18>
	ds_load_b32 v150, v172 offset:24                           // 000000103BA0: D8D80018 960000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103BA8: BF89FC07
	v_sub_f32_e32 v150, v150, v132                             // 000000103BAC: 092D0996
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103BB0: BF870091
	v_mul_f32_e32 v151, 0x3fb8aa3b, v150                       // 000000103BB4: 112F2CFF 3FB8AA3B
	v_fma_f32 v152, 0x3fb8aa3b, v150, -v151                    // 000000103BBC: D6130098 865F2CFF 3FB8AA3B
	v_rndne_f32_e32 v153, v151                                 // 000000103BC8: 7F324797
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000103BCC: BF870221
	v_sub_f32_e32 v151, v151, v153                             // 000000103BD0: 092F3397
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 000000103BD4: 7C372CFF C2CE8ED0
	v_fmac_f32_e32 v152, 0x32a5705f, v150                      // 000000103BDC: 57312CFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103BE4: BF870121
	v_add_f32_e32 v151, v151, v152                             // 000000103BE8: 072F3197
	v_cvt_i32_f32_e32 v152, v153                               // 000000103BEC: 7F301199
	v_exp_f32_e32 v151, v151                                   // 000000103BF0: 7F2E4B97
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103BF4: BF870095
	.long 0xd71c0097                                           // 000000103BF8: D71C0097
	v_cndmask_b32_e32 v1, v151, v152, vcc_lo                   // 000000103BFC: 02033197
	v_cndmask_b32_e32 v151, 0, v151, vcc_lo                    // 000000103C00: 032F2E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 000000103C04: 7C3D2CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000103C0C: BF870002
	v_cndmask_b32_e32 v150, 0x7f800000, v151, vcc_lo           // 000000103C10: 032D2EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000103C18: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103C1C: BF870091
	v_bfe_u32 v151, v150, 16, 1                                // 000000103C20: D6100097 02052196
	v_add3_u32 v151, v150, v151, 0x7fff                        // 000000103C28: D6550097 03FF2F96 00007FFF
	ds_store_b16_d16_hi v173, v151 offset:12                   // 000000103C34: DA84000C 000097AD
	s_and_saveexec_b32 s2, s27                                 // 000000103C3C: BE82201B
	s_cbranch_execz 30                                         // 000000103C40: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x1fbc>
	ds_load_b32 v149, v172 offset:28                           // 000000103C44: D8D8001C 950000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103C4C: BF89FC07
	v_sub_f32_e32 v149, v149, v132                             // 000000103C50: 092B0995
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103C54: BF870121
	v_mul_f32_e32 v151, 0x3fb8aa3b, v149                       // 000000103C58: 112F2AFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 000000103C60: 7C372AFF C2CE8ED0
	v_fma_f32 v152, 0x3fb8aa3b, v149, -v151                    // 000000103C68: D6130098 865F2AFF 3FB8AA3B
	v_rndne_f32_e32 v153, v151                                 // 000000103C74: 7F324797
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000103C78: BF870112
	v_fmac_f32_e32 v152, 0x32a5705f, v149                      // 000000103C7C: 57312AFF 32A5705F
	v_sub_f32_e32 v151, v151, v153                             // 000000103C84: 092F3397
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103C88: BF870121
	v_add_f32_e32 v151, v151, v152                             // 000000103C8C: 072F3197
	v_cvt_i32_f32_e32 v152, v153                               // 000000103C90: 7F301199
	v_exp_f32_e32 v151, v151                                   // 000000103C94: 7F2E4B97
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103C98: BF870095
	.long 0xd71c0097                                           // 000000103C9C: D71C0097
	v_cndmask_b32_e32 v1, v151, v152, vcc_lo                   // 000000103CA0: 02033197
	v_cndmask_b32_e32 v151, 0, v151, vcc_lo                    // 000000103CA4: 032F2E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 000000103CA8: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000103CB0: BF870002
	v_cndmask_b32_e32 v149, 0x7f800000, v151, vcc_lo           // 000000103CB4: 032B2EFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000103CBC: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103CC0: BF870121
	v_bfe_u32 v151, v149, 16, 1                                // 000000103CC4: D6100097 02052195
	v_mov_b32_e32 v152, 0                                      // 000000103CCC: 7F300280
	v_add3_u32 v153, v149, v151, 0x7fff                        // 000000103CD0: D6550099 03FF2F95 00007FFF
	v_mov_b32_e32 v151, 0                                      // 000000103CDC: 7F2E0280
	ds_store_b16_d16_hi v173, v153 offset:14                   // 000000103CE0: DA84000E 000099AD
	s_and_saveexec_b32 s2, s26                                 // 000000103CE8: BE82201A
	s_cbranch_execz 30                                         // 000000103CEC: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2068>
	ds_load_b32 v152, v172 offset:32                           // 000000103CF0: D8D80020 980000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103CF8: BF89FC07
	v_sub_f32_e32 v152, v152, v132                             // 000000103CFC: 09310998
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103D00: BF870091
	v_mul_f32_e32 v153, 0x3fb8aa3b, v152                       // 000000103D04: 113330FF 3FB8AA3B
	v_fma_f32 v154, 0x3fb8aa3b, v152, -v153                    // 000000103D0C: D613009A 866730FF 3FB8AA3B
	v_rndne_f32_e32 v155, v153                                 // 000000103D18: 7F364799
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000103D1C: BF870221
	v_sub_f32_e32 v153, v153, v155                             // 000000103D20: 09333799
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 000000103D24: 7C3730FF C2CE8ED0
	v_fmac_f32_e32 v154, 0x32a5705f, v152                      // 000000103D2C: 573530FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103D34: BF870121
	v_add_f32_e32 v153, v153, v154                             // 000000103D38: 07333599
	v_cvt_i32_f32_e32 v154, v155                               // 000000103D3C: 7F34119B
	v_exp_f32_e32 v153, v153                                   // 000000103D40: 7F324B99
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103D44: BF870095
	.long 0xd71c0099                                           // 000000103D48: D71C0099
	v_cndmask_b32_e32 v1, v153, v154, vcc_lo                   // 000000103D4C: 02033599
	v_cndmask_b32_e32 v153, 0, v153, vcc_lo                    // 000000103D50: 03333280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 000000103D54: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000103D5C: BF870002
	v_cndmask_b32_e32 v152, 0x7f800000, v153, vcc_lo           // 000000103D60: 033132FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000103D68: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103D6C: BF870091
	v_bfe_u32 v153, v152, 16, 1                                // 000000103D70: D6100099 02052198
	v_add3_u32 v153, v152, v153, 0x7fff                        // 000000103D78: D6550099 03FF3398 00007FFF
	ds_store_b16_d16_hi v173, v153 offset:16                   // 000000103D84: DA840010 000099AD
	s_and_saveexec_b32 s2, s25                                 // 000000103D8C: BE822019
	s_cbranch_execz 30                                         // 000000103D90: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x210c>
	ds_load_b32 v151, v172 offset:36                           // 000000103D94: D8D80024 970000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103D9C: BF89FC07
	v_sub_f32_e32 v151, v151, v132                             // 000000103DA0: 092F0997
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103DA4: BF870121
	v_mul_f32_e32 v153, 0x3fb8aa3b, v151                       // 000000103DA8: 11332EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 000000103DB0: 7C372EFF C2CE8ED0
	v_fma_f32 v154, 0x3fb8aa3b, v151, -v153                    // 000000103DB8: D613009A 86672EFF 3FB8AA3B
	v_rndne_f32_e32 v155, v153                                 // 000000103DC4: 7F364799
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000103DC8: BF870112
	v_fmac_f32_e32 v154, 0x32a5705f, v151                      // 000000103DCC: 57352EFF 32A5705F
	v_sub_f32_e32 v153, v153, v155                             // 000000103DD4: 09333799
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103DD8: BF870121
	v_add_f32_e32 v153, v153, v154                             // 000000103DDC: 07333599
	v_cvt_i32_f32_e32 v154, v155                               // 000000103DE0: 7F34119B
	v_exp_f32_e32 v153, v153                                   // 000000103DE4: 7F324B99
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103DE8: BF870095
	.long 0xd71c0099                                           // 000000103DEC: D71C0099
	v_cndmask_b32_e32 v1, v153, v154, vcc_lo                   // 000000103DF0: 02033599
	v_cndmask_b32_e32 v153, 0, v153, vcc_lo                    // 000000103DF4: 03333280
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 000000103DF8: 7C3D2EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000103E00: BF870002
	v_cndmask_b32_e32 v151, 0x7f800000, v153, vcc_lo           // 000000103E04: 032F32FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000103E0C: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103E10: BF870121
	v_bfe_u32 v153, v151, 16, 1                                // 000000103E14: D6100099 02052197
	v_mov_b32_e32 v154, 0                                      // 000000103E1C: 7F340280
	v_add3_u32 v155, v151, v153, 0x7fff                        // 000000103E20: D655009B 03FF3397 00007FFF
	v_mov_b32_e32 v153, 0                                      // 000000103E2C: 7F320280
	ds_store_b16_d16_hi v173, v155 offset:18                   // 000000103E30: DA840012 00009BAD
	s_and_saveexec_b32 s2, s24                                 // 000000103E38: BE822018
	s_cbranch_execz 30                                         // 000000103E3C: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x21b8>
	ds_load_b32 v154, v172 offset:40                           // 000000103E40: D8D80028 9A0000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103E48: BF89FC07
	v_sub_f32_e32 v154, v154, v132                             // 000000103E4C: 0935099A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103E50: BF870091
	v_mul_f32_e32 v155, 0x3fb8aa3b, v154                       // 000000103E54: 113734FF 3FB8AA3B
	v_fma_f32 v156, 0x3fb8aa3b, v154, -v155                    // 000000103E5C: D613009C 866F34FF 3FB8AA3B
	v_rndne_f32_e32 v182, v155                                 // 000000103E68: 7F6C479B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000103E6C: BF870221
	v_sub_f32_e32 v155, v155, v182                             // 000000103E70: 09376D9B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v154                 // 000000103E74: 7C3734FF C2CE8ED0
	v_fmac_f32_e32 v156, 0x32a5705f, v154                      // 000000103E7C: 573934FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103E84: BF870121
	v_add_f32_e32 v155, v155, v156                             // 000000103E88: 0737399B
	v_cvt_i32_f32_e32 v156, v182                               // 000000103E8C: 7F3811B6
	v_exp_f32_e32 v155, v155                                   // 000000103E90: 7F364B9B
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103E94: BF870095
	.long 0xd71c009b                                           // 000000103E98: D71C009B
	v_cndmask_b32_e32 v1, v155, v156, vcc_lo                   // 000000103E9C: 0203399B
	v_cndmask_b32_e32 v155, 0, v155, vcc_lo                    // 000000103EA0: 03373680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v154                 // 000000103EA4: 7C3D34FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000103EAC: BF870002
	v_cndmask_b32_e32 v154, 0x7f800000, v155, vcc_lo           // 000000103EB0: 033536FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000103EB8: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103EBC: BF870091
	v_bfe_u32 v155, v154, 16, 1                                // 000000103EC0: D610009B 0205219A
	v_add3_u32 v155, v154, v155, 0x7fff                        // 000000103EC8: D655009B 03FF379A 00007FFF
	ds_store_b16_d16_hi v173, v155 offset:20                   // 000000103ED4: DA840014 00009BAD
	s_and_saveexec_b32 s2, s22                                 // 000000103EDC: BE822016
	s_cbranch_execz 29                                         // 000000103EE0: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2258>
	ds_load_b32 v153, v172 offset:44                           // 000000103EE4: D8D8002C 990000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103EEC: BF89FC07
	v_sub_f32_e32 v153, v153, v132                             // 000000103EF0: 09330999
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103EF4: BF870121
	v_mul_f32_e32 v155, 0x3fb8aa3b, v153                       // 000000103EF8: 113732FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 000000103F00: 7C3732FF C2CE8ED0
	v_fma_f32 v156, 0x3fb8aa3b, v153, -v155                    // 000000103F08: D613009C 866F32FF 3FB8AA3B
	v_rndne_f32_e32 v182, v155                                 // 000000103F14: 7F6C479B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103F18: BF870091
	v_dual_fmac_f32 v156, 0x32a5705f, v153 :: v_dual_sub_f32 v155, v155, v182// 000000103F1C: C80B32FF 9C9B6D9B 32A5705F
	v_add_f32_e32 v155, v155, v156                             // 000000103F28: 0737399B
	v_cvt_i32_f32_e32 v156, v182                               // 000000103F2C: 7F3811B6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000103F30: BF870292
	v_exp_f32_e32 v155, v155                                   // 000000103F34: 7F364B9B
	.long 0xd71c009b                                           // 000000103F38: D71C009B
	v_cndmask_b32_e32 v1, v155, v156, vcc_lo                   // 000000103F3C: 0203399B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103F40: BF870121
	v_cndmask_b32_e32 v155, 0, v155, vcc_lo                    // 000000103F44: 03373680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 000000103F48: 7C3D32FF 42B17218
	v_cndmask_b32_e32 v153, 0x7f800000, v155, vcc_lo           // 000000103F50: 033336FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000103F58: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103F5C: BF870121
	v_bfe_u32 v155, v153, 16, 1                                // 000000103F60: D610009B 02052199
	v_mov_b32_e32 v156, 0                                      // 000000103F68: 7F380280
	v_add3_u32 v182, v153, v155, 0x7fff                        // 000000103F6C: D65500B6 03FF3799 00007FFF
	v_mov_b32_e32 v155, 0                                      // 000000103F78: 7F360280
	ds_store_b16_d16_hi v173, v182 offset:22                   // 000000103F7C: DA840016 0000B6AD
	s_and_saveexec_b32 s2, s9                                  // 000000103F84: BE822009
	s_cbranch_execz 30                                         // 000000103F88: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2304>
	ds_load_b32 v156, v172 offset:48                           // 000000103F8C: D8D80030 9C0000AC
	s_waitcnt lgkmcnt(0)                                       // 000000103F94: BF89FC07
	v_sub_f32_e32 v156, v156, v132                             // 000000103F98: 0939099C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103F9C: BF870121
	v_mul_f32_e32 v182, 0x3fb8aa3b, v156                       // 000000103FA0: 116D38FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v156                 // 000000103FA8: 7C3738FF C2CE8ED0
	v_fma_f32 v183, 0x3fb8aa3b, v156, -v182                    // 000000103FB0: D61300B7 86DB38FF 3FB8AA3B
	v_rndne_f32_e32 v184, v182                                 // 000000103FBC: 7F7047B6
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000103FC0: BF870112
	v_fmac_f32_e32 v183, 0x32a5705f, v156                      // 000000103FC4: 576F38FF 32A5705F
	v_sub_f32_e32 v182, v182, v184                             // 000000103FCC: 096D71B6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000103FD0: BF870121
	v_add_f32_e32 v182, v182, v183                             // 000000103FD4: 076D6FB6
	v_cvt_i32_f32_e32 v183, v184                               // 000000103FD8: 7F6E11B8
	v_exp_f32_e32 v182, v182                                   // 000000103FDC: 7F6C4BB6
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000103FE0: BF870095
	.long 0xd71c00b6                                           // 000000103FE4: D71C00B6
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                   // 000000103FE8: 02036FB6
	v_cndmask_b32_e32 v182, 0, v182, vcc_lo                    // 000000103FEC: 036D6C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v156                 // 000000103FF0: 7C3D38FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000103FF8: BF870002
	v_cndmask_b32_e32 v156, 0x7f800000, v182, vcc_lo           // 000000103FFC: 03396CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000104004: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000104008: BF870091
	v_bfe_u32 v182, v156, 16, 1                                // 00000010400C: D61000B6 0205219C
	v_add3_u32 v182, v156, v182, 0x7fff                        // 000000104014: D65500B6 03FF6D9C 00007FFF
	ds_store_b16_d16_hi v173, v182 offset:24                   // 000000104020: DA840018 0000B6AD
	s_and_saveexec_b32 s2, s8                                  // 000000104028: BE822008
	s_cbranch_execz 29                                         // 00000010402C: BFA5001D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x23a4>
	ds_load_b32 v155, v172 offset:52                           // 000000104030: D8D80034 9B0000AC
	s_waitcnt lgkmcnt(0)                                       // 000000104038: BF89FC07
	v_sub_f32_e32 v155, v155, v132                             // 00000010403C: 0937099B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000104040: BF870091
	v_mul_f32_e32 v182, 0x3fb8aa3b, v155                       // 000000104044: 116D36FF 3FB8AA3B
	v_fma_f32 v183, 0x3fb8aa3b, v155, -v182                    // 00000010404C: D61300B7 86DB36FF 3FB8AA3B
	v_rndne_f32_e32 v184, v182                                 // 000000104058: 7F7047B6
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010405C: BF870091
	v_dual_fmac_f32 v183, 0x32a5705f, v155 :: v_dual_sub_f32 v182, v182, v184// 000000104060: C80B36FF B7B771B6 32A5705F
	v_add_f32_e32 v182, v182, v183                             // 00000010406C: 076D6FB6
	v_cvt_i32_f32_e32 v183, v184                               // 000000104070: 7F6E11B8
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v155                 // 000000104074: 7C3736FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010407C: BF870293
	v_exp_f32_e32 v182, v182                                   // 000000104080: 7F6C4BB6
	.long 0xd71c00b6                                           // 000000104084: D71C00B6
	v_cndmask_b32_e32 v1, v182, v183, vcc_lo                   // 000000104088: 02036FB6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010408C: BF870121
	v_cndmask_b32_e32 v182, 0, v182, vcc_lo                    // 000000104090: 036D6C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v155                 // 000000104094: 7C3D36FF 42B17218
	v_cndmask_b32_e32 v155, 0x7f800000, v182, vcc_lo           // 00000010409C: 03376CFF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001040A4: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001040A8: BF870121
	v_bfe_u32 v182, v155, 16, 1                                // 0000001040AC: D61000B6 0205219B
	v_mov_b32_e32 v183, 0                                      // 0000001040B4: 7F6E0280
	v_add3_u32 v184, v155, v182, 0x7fff                        // 0000001040B8: D65500B8 03FF6D9B 00007FFF
	v_mov_b32_e32 v182, 0                                      // 0000001040C4: 7F6C0280
	ds_store_b16_d16_hi v173, v184 offset:26                   // 0000001040C8: DA84001A 0000B8AD
	s_and_saveexec_b32 s2, s7                                  // 0000001040D0: BE822007
	s_cbranch_execz 30                                         // 0000001040D4: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2450>
	ds_load_b32 v183, v172 offset:56                           // 0000001040D8: D8D80038 B70000AC
	s_waitcnt lgkmcnt(0)                                       // 0000001040E0: BF89FC07
	v_sub_f32_e32 v183, v183, v132                             // 0000001040E4: 096F09B7
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001040E8: BF870091
	v_mul_f32_e32 v184, 0x3fb8aa3b, v183                       // 0000001040EC: 11716EFF 3FB8AA3B
	v_fma_f32 v185, 0x3fb8aa3b, v183, -v184                    // 0000001040F4: D61300B9 86E36EFF 3FB8AA3B
	v_rndne_f32_e32 v186, v184                                 // 000000104100: 7F7447B8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000104104: BF870221
	v_sub_f32_e32 v184, v184, v186                             // 000000104108: 097175B8
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v183                 // 00000010410C: 7C376EFF C2CE8ED0
	v_fmac_f32_e32 v185, 0x32a5705f, v183                      // 000000104114: 57736EFF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010411C: BF870121
	v_add_f32_e32 v184, v184, v185                             // 000000104120: 077173B8
	v_cvt_i32_f32_e32 v185, v186                               // 000000104124: 7F7211BA
	v_exp_f32_e32 v184, v184                                   // 000000104128: 7F704BB8
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010412C: BF870095
	.long 0xd71c00b8                                           // 000000104130: D71C00B8
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                   // 000000104134: 020373B8
	v_cndmask_b32_e32 v184, 0, v184, vcc_lo                    // 000000104138: 03717080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v183                 // 00000010413C: 7C3D6EFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000104144: BF870002
	v_cndmask_b32_e32 v183, 0x7f800000, v184, vcc_lo           // 000000104148: 036F70FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 000000104150: 8C7E027E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000104154: BF870091
	v_bfe_u32 v184, v183, 16, 1                                // 000000104158: D61000B8 020521B7
	v_add3_u32 v184, v183, v184, 0x7fff                        // 000000104160: D65500B8 03FF71B7 00007FFF
	ds_store_b16_d16_hi v173, v184 offset:28                   // 00000010416C: DA84001C 0000B8AD
	s_and_saveexec_b32 s2, s1                                  // 000000104174: BE822001
	s_cbranch_execz 30                                         // 000000104178: BFA5001E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x24f4>
	ds_load_b32 v182, v172 offset:60                           // 00000010417C: D8D8003C B60000AC
	s_waitcnt lgkmcnt(0)                                       // 000000104184: BF89FC07
	v_sub_f32_e32 v182, v182, v132                             // 000000104188: 096D09B6
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010418C: BF870121
	v_mul_f32_e32 v184, 0x3fb8aa3b, v182                       // 000000104190: 11716CFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v182                 // 000000104198: 7C376CFF C2CE8ED0
	v_fma_f32 v185, 0x3fb8aa3b, v182, -v184                    // 0000001041A0: D61300B9 86E36CFF 3FB8AA3B
	v_rndne_f32_e32 v186, v184                                 // 0000001041AC: 7F7447B8
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001041B0: BF870112
	v_fmac_f32_e32 v185, 0x32a5705f, v182                      // 0000001041B4: 57736CFF 32A5705F
	v_sub_f32_e32 v184, v184, v186                             // 0000001041BC: 097175B8
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001041C0: BF870121
	v_add_f32_e32 v184, v184, v185                             // 0000001041C4: 077173B8
	v_cvt_i32_f32_e32 v185, v186                               // 0000001041C8: 7F7211BA
	v_exp_f32_e32 v184, v184                                   // 0000001041CC: 7F704BB8
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001041D0: BF870095
	.long 0xd71c00b8                                           // 0000001041D4: D71C00B8
	v_cndmask_b32_e32 v1, v184, v185, vcc_lo                   // 0000001041D8: 020373B8
	v_cndmask_b32_e32 v184, 0, v184, vcc_lo                    // 0000001041DC: 03717080
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v182                 // 0000001041E0: 7C3D6CFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001041E8: BF870002
	v_cndmask_b32_e32 v182, 0x7f800000, v184, vcc_lo           // 0000001041EC: 036D70FF 7F800000
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001041F4: 8C7E027E
	v_add_f32_e32 v129, v130, v129                             // 0000001041F8: 07030382
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001041FC: BF870122
	v_bfe_u32 v130, v182, 16, 1                                // 000000104200: D6100082 020521B6
	s_mov_b32 s1, 0                                            // 000000104208: BE810080
	v_add_f32_e32 v129, v129, v134                             // 00000010420C: 07030D81
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000104210: BF870112
	v_add3_u32 v130, v182, v130, 0x7fff                        // 000000104214: D6550082 03FF05B6 00007FFF
	v_add_f32_e32 v129, v129, v133                             // 000000104220: 07030B81
	ds_store_b16_d16_hi v173, v130 offset:30                   // 000000104224: DA84001E 000082AD
	v_add_f32_e32 v129, v129, v136                             // 00000010422C: 07031181
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000104230: BF870091
	v_add_f32_e32 v129, v129, v135                             // 000000104234: 07030F81
	v_add_f32_e32 v129, v129, v150                             // 000000104238: 07032D81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010423C: BF870091
	v_add_f32_e32 v129, v129, v149                             // 000000104240: 07032B81
	v_add_f32_e32 v129, v129, v152                             // 000000104244: 07033181
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000104248: BF870091
	v_add_f32_e32 v129, v129, v151                             // 00000010424C: 07032F81
	v_add_f32_e32 v129, v129, v154                             // 000000104250: 07033581
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000104254: BF870091
	v_add_f32_e32 v129, v129, v153                             // 000000104258: 07033381
	v_add_f32_e32 v129, v129, v156                             // 00000010425C: 07033981
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000104260: BF870091
	v_add_f32_e32 v129, v129, v155                             // 000000104264: 07033781
	v_add_f32_e32 v129, v129, v183                             // 000000104268: 07036F81
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010426C: BF870001
	v_add_f32_e32 v129, v129, v182                             // 000000104270: 07036D81
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000104274: 8B6A017E
	s_cbranch_vccz 591                                         // 000000104278: BFA3024F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2eb8>
	ds_load_2addr_b32 v[134:135], v172 offset1:1               // 00000010427C: D8DC0100 860000AC
	ds_load_2addr_b32 v[149:150], v172 offset0:2 offset1:3     // 000000104284: D8DC0302 950000AC
	ds_load_2addr_b32 v[151:152], v172 offset0:4 offset1:5     // 00000010428C: D8DC0504 970000AC
	ds_load_2addr_b32 v[153:154], v172 offset0:6 offset1:7     // 000000104294: D8DC0706 990000AC
	ds_load_2addr_b32 v[155:156], v172 offset0:8 offset1:9     // 00000010429C: D8DC0908 9B0000AC
	ds_load_2addr_b32 v[182:183], v172 offset0:10 offset1:11   // 0000001042A4: D8DC0B0A B60000AC
	.long 0xd59c4085                                           // 0000001042AC: D59C4085
	v_cndmask_b32_e32 v0, 0, v128, vcc_lo                      // 0000001042B0: 02010080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001042B4: BF8700D1
	.long 0xd59c4888                                           // 0000001042B8: D59C4888
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 0000001042BC: 02010185
	.long 0xd59c48ba                                           // 0000001042C0: D59C48BA
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 0000001042C4: 02010185
	s_waitcnt lgkmcnt(5)                                       // 0000001042C8: BF89FC57
	v_max3_f32 v129, v131, v134, v135                          // 0000001042CC: D61C0081 061F0D83
	s_waitcnt lgkmcnt(4)                                       // 0000001042D4: BF89FC47
	v_max3_f32 v129, v129, v149, v150                          // 0000001042D8: D61C0081 065B2B81
	s_waitcnt lgkmcnt(3)                                       // 0000001042E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001042E4: BF870001
	v_max3_f32 v132, v129, v151, v152                          // 0000001042E8: D61C0084 06632F81
	ds_load_2addr_b32 v[184:185], v172 offset0:12 offset1:13   // 0000001042F0: D8DC0D0C B80000AC
	ds_load_2addr_b32 v[129:130], v172 offset0:14 offset1:15   // 0000001042F8: D8DC0F0E 810000AC
	s_waitcnt lgkmcnt(4)                                       // 000000104300: BF89FC47
	v_max3_f32 v132, v132, v153, v154                          // 000000104304: D61C0084 066B3384
	s_waitcnt lgkmcnt(3)                                       // 00000010430C: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000104310: BF8700A1
	v_max3_f32 v132, v132, v155, v156                          // 000000104314: D61C0084 06733784
	s_waitcnt lgkmcnt(2)                                       // 00000010431C: BF89FC27
	v_max3_f32 v132, v132, v182, v183                          // 000000104320: D61C0084 06DF6D84
	s_waitcnt lgkmcnt(1)                                       // 000000104328: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000010432C: BF8700A1
	v_max3_f32 v132, v132, v184, v185                          // 000000104330: D61C0084 06E77184
	s_waitcnt lgkmcnt(0)                                       // 000000104338: BF89FC07
	v_max3_f32 v132, v132, v129, v130                          // 00000010433C: D61C0084 060B0384
	s_delay_alu instid0(VALU_DEP_1)                            // 000000104344: BF870001
	v_sub_f32_e32 v150, v150, v132                             // 000000104348: 092D0996
	v_sub_f32_e32 v134, v134, v132                             // 00000010434C: 090D0986
	v_sub_f32_e32 v149, v149, v132                             // 000000104350: 092B0995
	v_sub_f32_e32 v135, v135, v132                             // 000000104354: 090F0987
	v_sub_f32_e32 v153, v153, v132                             // 000000104358: 09330999
	v_mul_f32_e32 v189, 0x3fb8aa3b, v150                       // 00000010435C: 117B2CFF 3FB8AA3B
	v_mul_f32_e32 v187, 0x3fb8aa3b, v134                       // 000000104364: 11770CFF 3FB8AA3B
	v_dual_sub_f32 v151, v151, v132 :: v_dual_mul_f32 v190, 0x3fb8aa3b, v149// 00000010436C: C9470997 97BF2AFF 3FB8AA3B
	v_mul_f32_e32 v188, 0x3fb8aa3b, v135                       // 000000104378: 11790EFF 3FB8AA3B
	v_mul_f32_e32 v194, 0x3fb8aa3b, v153                       // 000000104380: 118532FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4)                            // 000000104388: BF870004
	v_fma_f32 v195, 0x3fb8aa3b, v134, -v187                    // 00000010438C: D61300C3 86EF0CFF 3FB8AA3B
	v_rndne_f32_e32 v196, v187                                 // 000000104398: 7F8847BB
	v_sub_f32_e32 v154, v154, v132                             // 00000010439C: 0935099A
	v_mul_f32_e32 v192, 0x3fb8aa3b, v151                       // 0000001043A0: 11812EFF 3FB8AA3B
	v_fma_f32 v197, 0x3fb8aa3b, v135, -v188                    // 0000001043A8: D61300C5 86F30EFF 3FB8AA3B
	v_rndne_f32_e32 v198, v188                                 // 0000001043B4: 7F8C47BC
	v_rndne_f32_e32 v202, v190                                 // 0000001043B8: 7F9447BE
	v_dual_fmac_f32 v195, 0x32a5705f, v134 :: v_dual_sub_f32 v152, v152, v132// 0000001043BC: C80B0CFF C3990998 32A5705F
	v_mul_f32_e32 v193, 0x3fb8aa3b, v154                       // 0000001043C8: 118334FF 3FB8AA3B
	v_sub_f32_e32 v187, v187, v196                             // 0000001043D0: 097789BB
	v_fma_f32 v199, 0x3fb8aa3b, v150, -v189                    // 0000001043D4: D61300C7 86F72CFF 3FB8AA3B
	v_rndne_f32_e32 v200, v189                                 // 0000001043E0: 7F9047BD
	v_dual_mul_f32 v191, 0x3fb8aa3b, v152 :: v_dual_sub_f32 v188, v188, v198// 0000001043E4: C8CB30FF BFBD8DBC 3FB8AA3B
	v_fma_f32 v201, 0x3fb8aa3b, v149, -v190                    // 0000001043F0: D61300C9 86FB2AFF 3FB8AA3B
	v_rndne_f32_e32 v206, v192                                 // 0000001043FC: 7F9C47C0
	v_rndne_f32_e32 v210, v194                                 // 000000104400: 7FA447C2
	v_dual_fmac_f32 v197, 0x32a5705f, v135 :: v_dual_sub_f32 v190, v190, v202// 000000104404: C80B0EFF C5BF95BE 32A5705F
	v_add_f32_e32 v187, v187, v195                             // 000000104410: 077787BB
	v_fma_f32 v205, 0x3fb8aa3b, v151, -v192                    // 000000104414: D61300CD 87032EFF 3FB8AA3B
	v_fma_f32 v209, 0x3fb8aa3b, v153, -v194                    // 000000104420: D61300D1 870B32FF 3FB8AA3B
	v_dual_fmac_f32 v201, 0x32a5705f, v149 :: v_dual_sub_f32 v194, v194, v210// 00000010442C: C80B2AFF C9C3A5C2 32A5705F
	v_dual_sub_f32 v189, v189, v200 :: v_dual_sub_f32 v192, v192, v206// 000000104438: C94B91BD BDC19DC0
	v_dual_fmac_f32 v199, 0x32a5705f, v150 :: v_dual_add_f32 v188, v188, v197// 000000104440: C8092CFF C7BD8BBC 32A5705F
	v_exp_f32_e32 v187, v187                                   // 00000010444C: 7F764BBB
	v_cvt_i32_f32_e32 v196, v196                               // 000000104450: 7F8811C4
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000104454: BF870192
	v_dual_add_f32 v190, v190, v201 :: v_dual_add_f32 v189, v189, v199// 000000104458: C90993BE BEBD8FBD
	v_exp_f32_e32 v188, v188                                   // 000000104460: 7F784BBC
	v_cvt_i32_f32_e32 v198, v198                               // 000000104464: 7F8C11C6
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v134                 // 000000104468: 7C370CFF C2CE8ED0
	v_cvt_i32_f32_e32 v200, v200                               // 000000104470: 7F9011C8
	v_exp_f32_e32 v189, v189                                   // 000000104474: 7F7A4BBD
	v_exp_f32_e32 v190, v190                                   // 000000104478: 7F7C4BBE
	.long 0xd71c00bb                                           // 00000010447C: D71C00BB
	v_cndmask_b32_e32 v1, v187, v196, vcc_lo                   // 000000104480: 020389BB
	v_fma_f32 v203, 0x3fb8aa3b, v152, -v191                    // 000000104484: D61300CB 86FF30FF 3FB8AA3B
	v_rndne_f32_e32 v204, v191                                 // 000000104490: 7F9847BF
	v_cvt_i32_f32_e32 v202, v202                               // 000000104494: 7F9411CA
	.long 0xd71c00bc                                           // 000000104498: D71C00BC
	v_cndmask_b32_e32 v1, v188, v198, vcc_lo                   // 00000010449C: 02038DBC
	v_cndmask_b32_e32 v187, 0, v187, vcc_lo                    // 0000001044A0: 03777680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v135                 // 0000001044A4: 7C370EFF C2CE8ED0
	v_fmac_f32_e32 v205, 0x32a5705f, v151                      // 0000001044AC: 579B2EFF 32A5705F
	.long 0xd71c00bd                                           // 0000001044B4: D71C00BD
	v_cndmask_b32_e32 v1, v189, v200, vcc_lo                   // 0000001044B8: 020391BD
	.long 0xd71c00be                                           // 0000001044BC: D71C00BE
	v_cndmask_b32_e32 v1, v190, v202, vcc_lo                   // 0000001044C0: 020395BE
	v_rndne_f32_e32 v208, v193                                 // 0000001044C4: 7FA047C1
	v_cndmask_b32_e32 v188, 0, v188, vcc_lo                    // 0000001044C8: 03797880
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v150                 // 0000001044CC: 7C372CFF C2CE8ED0
	v_dual_fmac_f32 v203, 0x32a5705f, v152 :: v_dual_add_f32 v192, v192, v205// 0000001044D4: C80930FF CBC19BC0 32A5705F
	v_fma_f32 v207, 0x3fb8aa3b, v154, -v193                    // 0000001044E0: D61300CF 870734FF 3FB8AA3B
	v_cvt_i32_f32_e32 v206, v206                               // 0000001044EC: 7F9C11CE
	v_cndmask_b32_e32 v189, 0, v189, vcc_lo                    // 0000001044F0: 037B7A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v149                 // 0000001044F4: 7C372AFF C2CE8ED0
	v_sub_f32_e32 v191, v191, v204                             // 0000001044FC: 097F99BF
	v_cvt_i32_f32_e32 v204, v204                               // 000000104500: 7F9811CC
	v_exp_f32_e32 v192, v192                                   // 000000104504: 7F804BC0
	v_dual_sub_f32 v129, v129, v132 :: v_dual_cndmask_b32 v190, 0, v190// 000000104508: C9530981 81BF7C80
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000104510: BF8701B3
	v_add_f32_e32 v191, v191, v203                             // 000000104514: 077F97BF
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v152                 // 000000104518: 7C3730FF C2CE8ED0
	v_sub_f32_e32 v156, v156, v132                             // 000000104520: 0939099C
	v_exp_f32_e32 v191, v191                                   // 000000104524: 7F7E4BBF
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000104528: BF870296
	.long 0xd71c00c0                                           // 00000010452C: D71C00C0
	v_cndmask_b32_e32 v1, v192, v206, vcc_lo                   // 000000104530: 02039DC0
	.long 0xd71c00bf                                           // 000000104534: D71C00BF
	v_cndmask_b32_e32 v1, v191, v204, vcc_lo                   // 000000104538: 020399BF
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_3)// 00000010453C: BF8701D1
	v_cndmask_b32_e32 v191, 0, v191, vcc_lo                    // 000000104540: 037F7E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v135                 // 000000104544: 7C3D0EFF 42B17218
	v_cndmask_b32_e32 v135, 0x7f800000, v188, vcc_lo           // 00000010454C: 030F78FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v134                 // 000000104554: 7C3D0CFF 42B17218
	v_sub_f32_e32 v193, v193, v208                             // 00000010455C: 0983A1C1
	.long 0xd59c0885                                           // 000000104560: D59C0885
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 000000104564: 02010187
	v_cndmask_b32_e32 v134, 0x7f800000, v187, vcc_lo           // 000000104568: 030D76FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v149                 // 000000104570: 7C3D2AFF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000104578: BF870002
	v_add_f32_e32 v149, v134, v135                             // 00000010457C: 072B0F86
	v_cndmask_b32_e32 v187, 0x7f800000, v190, vcc_lo           // 000000104580: 03777CFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v150                 // 000000104588: 7C3D2CFF 42B17218
	v_and_b32_e32 v150, 1, v133                                // 000000104590: 372D0A81
	.long 0xd59c0888                                           // 000000104594: D59C0888
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 000000104598: 02010186
	v_cndmask_b32_e32 v188, 0x7f800000, v189, vcc_lo           // 00000010459C: 03797AFF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v151                 // 0000001045A4: 7C372EFF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001045AC: BF870193
	v_and_b32_e32 v136, 1, v136                                // 0000001045B0: 37111081
	.long 0xd59c0885                                           // 0000001045B4: D59C0885
	v_cndmask_b32_e32 v0, v188, v128, vcc_lo                   // 0000001045B8: 020101BC
	v_fmac_f32_e32 v207, 0x32a5705f, v154                      // 0000001045BC: 579F34FF 32A5705F
	v_dual_cndmask_b32 v189, 0, v192 :: v_dual_add_f32 v192, v149, v187// 0000001045C4: CA498080 BDC17795
	v_add3_u32 v149, v135, v150, 0x7fff                        // 0000001045CC: D6550095 03FF2D87 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001045D8: BF8701B4
	v_and_b32_e32 v190, 1, v133                                // 0000001045DC: 377D0A81
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v151                 // 0000001045E0: 7C3D2EFF 42B17218
	v_add3_u32 v134, v134, v136, 0x7fff                        // 0000001045E8: D6550086 03FF1186 00007FFF
	v_add3_u32 v150, v188, v190, 0x7fff                        // 0000001045F4: D6550096 03FF7DBC 00007FFF
	v_add_f32_e32 v188, v192, v188                             // 000000104600: 077979C0
	.long 0xd59c08ba                                           // 000000104604: D59C08BA
	v_cndmask_b32_e32 v0, v187, v128, vcc_lo                   // 000000104608: 020101BB
	v_fmac_f32_e32 v209, 0x32a5705f, v153                      // 00000010460C: 57A332FF 32A5705F
	v_dual_cndmask_b32 v136, 0x7f800000, v189 :: v_dual_add_f32 v151, v193, v207// 000000104614: CA497AFF 88979FC1 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v152                 // 000000104620: 7C3D30FF 42B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000104628: BF870224
	v_and_b32_e32 v186, 1, v186                                // 00000010462C: 37757481
	v_cvt_i32_f32_e32 v189, v208                               // 000000104630: 7F7A11D0
	v_add_f32_e32 v188, v188, v136                             // 000000104634: 077911BC
	v_exp_f32_e32 v151, v151                                   // 000000104638: 7F2E4B97
	.long 0xd59c0895                                           // 00000010463C: D59C0895
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 000000104640: 02010186
	v_add3_u32 v135, v187, v186, 0x7fff                        // 000000104644: D6550087 03FF75BB 00007FFF
	v_add_f32_e32 v186, v194, v209                             // 000000104650: 0775A3C2
	.long 0xd59c08bb                                           // 000000104654: D59C08BB
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 000000104658: 02010188
	.long 0xd59c48bb                                           // 00000010465C: D59C48BB
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 000000104660: 02010185
	v_cndmask_b32_e32 v152, 0x7f800000, v191, vcc_lo           // 000000104664: 03317EFF 7F800000
	v_cvt_i32_f32_e32 v191, v210                               // 00000010466C: 7F7E11D2
	v_exp_f32_e32 v186, v186                                   // 000000104670: 7F744BBA
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v154                 // 000000104674: 7C3734FF C2CE8ED0
	v_and_b32_e32 v187, 1, v187                                // 00000010467C: 37777681
	.long 0xd71c00bd                                           // 000000104680: D71C00BD
	v_cndmask_b32_e32 v1, v151, v189, vcc_lo                   // 000000104684: 02037B97
	.long 0xd59c0885                                           // 000000104688: D59C0885
	v_cndmask_b32_e32 v0, v152, v128, vcc_lo                   // 00000010468C: 02010198
	.long 0xd59c0896                                           // 000000104690: D59C0896
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 000000104694: 02010187
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000104698: BF870214
	v_add3_u32 v136, v136, v187, 0x7fff                        // 00000010469C: D6550088 03FF7788 00007FFF
	v_cndmask_b32_e32 v187, 0, v189, vcc_lo                    // 0000001046A8: 03777A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 0000001046AC: 7C3732FF C2CE8ED0
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001046B4: BF8701B5
	.long 0xd71c00ba                                           // 0000001046B8: D71C00BA
	v_cndmask_b32_e32 v1, v186, v191, vcc_lo                   // 0000001046BC: 02037FBA
	v_and_b32_e32 v190, 1, v133                                // 0000001046C0: 377D0A81
	.long 0xd59c48bd                                           // 0000001046C4: D59C48BD
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 0000001046C8: 02010185
	v_cndmask_b32_e32 v186, 0, v186, vcc_lo                    // 0000001046CC: 03757480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v154                 // 0000001046D0: 7C3D34FF 42B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001046D8: BF870004
	v_add3_u32 v151, v152, v190, 0x7fff                        // 0000001046DC: D6550097 03FF7D98 00007FFF
	v_add_f32_e32 v152, v188, v152                             // 0000001046E8: 073131BC
	.long 0xd59c0897                                           // 0000001046EC: D59C0897
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 0000001046F0: 02010188
	v_cndmask_b32_e32 v154, 0x7f800000, v187, vcc_lo           // 0000001046F4: 033576FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 0000001046FC: 7C3D32FF 42B17218
	v_cndmask_b32_e32 v153, 0x7f800000, v186, vcc_lo           // 000000104704: 033374FF 7F800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000010470C: BF8701A3
	.long 0xd59c0885                                           // 000000104710: D59C0885
	v_cndmask_b32_e32 v0, v154, v128, vcc_lo                   // 000000104714: 0201019A
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v156                 // 000000104718: 7C3738FF C2CE8ED0
	.long 0xd59c08bd                                           // 000000104720: D59C08BD
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                   // 000000104724: 02010199
	v_sub_f32_e32 v155, v155, v132                             // 000000104728: 0937099B
	v_add_f32_e32 v191, v152, v153                             // 00000010472C: 077F3398
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000104730: BF870193
	v_dual_mul_f32 v187, 0x3fb8aa3b, v156 :: v_dual_and_b32 v152, 1, v189// 000000104734: C8E538FF BB997A81 3FB8AA3B
	v_dual_mul_f32 v190, 0x3fb8aa3b, v155 :: v_dual_and_b32 v189, 1, v133// 000000104740: C8E536FF BEBD0A81 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000010474C: BF870192
	v_add3_u32 v153, v153, v152, 0x7fff                        // 000000104750: D6550099 03FF3199 00007FFF
	v_fma_f32 v186, 0x3fb8aa3b, v156, -v187                    // 00000010475C: D61300BA 86EF38FF 3FB8AA3B
	v_rndne_f32_e32 v188, v187                                 // 000000104768: 7F7847BB
	s_delay_alu instid0(VALU_DEP_4)                            // 00000010476C: BF870004
	v_add3_u32 v152, v154, v189, 0x7fff                        // 000000104770: D6550098 03FF7B9A 00007FFF
	v_rndne_f32_e32 v192, v190                                 // 00000010477C: 7F8047BE
	.long 0xd59c0898                                           // 000000104780: D59C0898
	v_cndmask_b32_e32 v0, v153, v128, vcc_lo                   // 000000104784: 02010199
	v_fmac_f32_e32 v186, 0x32a5705f, v156                      // 000000104788: 577538FF 32A5705F
	v_sub_f32_e32 v153, v182, v132                             // 000000104790: 093309B6
	v_sub_f32_e32 v187, v187, v188                             // 000000104794: 097779BB
	v_cvt_i32_f32_e32 v135, v188                               // 000000104798: 7F0E11BC
	v_sub_f32_e32 v182, v183, v132                             // 00000010479C: 096D09B7
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001047A0: BF8701A3
	v_add_f32_e32 v186, v187, v186                             // 0000001047A4: 077575BB
	v_fma_f32 v187, 0x3fb8aa3b, v155, -v190                    // 0000001047A8: D61300BB 86FB36FF 3FB8AA3B
	v_mul_f32_e32 v183, 0x3fb8aa3b, v182                       // 0000001047B4: 116F6CFF 3FB8AA3B
	v_add_f32_e32 v154, v191, v154                             // 0000001047BC: 073535BF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001047C0: BF870194
	v_exp_f32_e32 v186, v186                                   // 0000001047C4: 7F744BBA
	v_fmac_f32_e32 v187, 0x32a5705f, v155                      // 0000001047C8: 577736FF 32A5705F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001047D0: BF870245
	.long 0xd71c0086                                           // 0000001047D4: D71C0086
	v_cndmask_b32_e32 v1, v186, v135, vcc_lo                   // 0000001047D8: 02030FBA
	v_sub_f32_e32 v189, v190, v192                             // 0000001047DC: 097B81BE
	v_cvt_i32_f32_e32 v186, v192                               // 0000001047E0: 7F7411C0
	v_rndne_f32_e32 v190, v183                                 // 0000001047E4: 7F7C47B7
	v_cndmask_b32_e32 v134, 0, v134, vcc_lo                    // 0000001047E8: 030D0C80
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001047EC: BF870244
	v_add_f32_e32 v136, v189, v187                             // 0000001047F0: 071177BD
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v155                 // 0000001047F4: 7C3736FF C2CE8ED0
	v_fma_f32 v189, 0x3fb8aa3b, v182, -v183                    // 0000001047FC: D61300BD 86DF6CFF 3FB8AA3B
	v_sub_f32_e32 v183, v183, v190                             // 000000104808: 096F7DB7
	v_exp_f32_e32 v135, v136                                   // 00000010480C: 7F0E4B88
	v_mul_f32_e32 v136, 0x3fb8aa3b, v153                       // 000000104810: 111132FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 000000104818: BF8702A1
	v_fma_f32 v187, 0x3fb8aa3b, v153, -v136                    // 00000010481C: D61300BB 862332FF 3FB8AA3B
	v_rndne_f32_e32 v188, v136                                 // 000000104828: 7F784788
	.long 0xd71c0087                                           // 00000010482C: D71C0087
	v_cndmask_b32_e32 v1, v135, v186, vcc_lo                   // 000000104830: 02037587
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 000000104834: BF8701A2
	v_dual_fmac_f32 v187, 0x32a5705f, v153 :: v_dual_sub_f32 v136, v136, v188// 000000104838: C80B32FF BB897988 32A5705F
	v_cvt_i32_f32_e32 v186, v190                               // 000000104844: 7F7411BE
	v_cndmask_b32_e32 v135, 0, v135, vcc_lo                    // 000000104848: 030F0E80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v156                 // 00000010484C: 7C3D38FF 42B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 000000104854: BF8701B4
	v_add_f32_e32 v136, v136, v187                             // 000000104858: 07117788
	v_cndmask_b32_e32 v134, 0x7f800000, v134, vcc_lo           // 00000010485C: 030D0CFF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v155                 // 000000104864: 7C3D36FF 42B17218
	v_exp_f32_e32 v136, v136                                   // 00000010486C: 7F104B88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 000000104870: BF8701C2
	.long 0xd59c0885                                           // 000000104874: D59C0885
	v_cndmask_b32_e32 v0, v134, v128, vcc_lo                   // 000000104878: 02010186
	v_cndmask_b32_e32 v135, 0x7f800000, v135, vcc_lo           // 00000010487C: 030F0EFF 7F800000
	v_fmac_f32_e32 v189, 0x32a5705f, v182                      // 000000104884: 577B6CFF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v153                 // 00000010488C: 7C3732FF C2CE8ED0
	v_add_f32_e32 v154, v154, v135                             // 000000104894: 07350F9A
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000104898: BF870233
	v_add_f32_e32 v156, v183, v189                             // 00000010489C: 07397BB7
	v_cvt_i32_f32_e32 v183, v188                               // 0000001048A0: 7F6E11BC
	v_and_b32_e32 v187, 1, v133                                // 0000001048A4: 37770A81
	v_dual_mul_f32 v189, 0x3fb8aa3b, v129 :: v_dual_add_f32 v154, v154, v134// 0000001048A8: C8C902FF BD9B0D9A 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001048B4: BF870194
	v_exp_f32_e32 v155, v156                                   // 0000001048B8: 7F364B9C
	.long 0xd71c0088                                           // 0000001048BC: D71C0088
	v_cndmask_b32_e32 v1, v136, v183, vcc_lo                   // 0000001048C0: 02036F88
	.long 0xd59c089c                                           // 0000001048C4: D59C089C
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 0000001048C8: 02010187
	.long 0xd59c489c                                           // 0000001048CC: D59C489C
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 0000001048D0: 02010185
	v_fma_f32 v191, 0x3fb8aa3b, v129, -v189                    // 0000001048D4: D61300BF 86F702FF 3FB8AA3B
	v_sub_f32_e32 v184, v184, v132                             // 0000001048E0: 097109B8
	v_cndmask_b32_e32 v136, 0, v136, vcc_lo                    // 0000001048E4: 03111080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v182                 // 0000001048E8: 7C376CFF C2CE8ED0
	v_and_b32_e32 v156, 1, v156                                // 0000001048F0: 37393881
	v_rndne_f32_e32 v192, v189                                 // 0000001048F4: 7F8047BD
	.long 0xd71c009b                                           // 0000001048F8: D71C009B
	v_cndmask_b32_e32 v1, v155, v186, vcc_lo                   // 0000001048FC: 0203759B
	v_dual_fmac_f32 v191, 0x32a5705f, v129 :: v_dual_sub_f32 v130, v130, v132// 000000104900: C80B02FF BF830982 32A5705F
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000010490C: BF870194
	v_add3_u32 v135, v135, v156, 0x7fff                        // 000000104910: D6550087 03FF3987 00007FFF
	v_cndmask_b32_e32 v155, 0, v155, vcc_lo                    // 00000010491C: 03373680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v153                 // 000000104920: 7C3D32FF 42B17218
	v_add3_u32 v153, v134, v187, 0x7fff                        // 000000104928: D6550099 03FF7786 00007FFF
	v_mul_f32_e32 v187, 0x3fb8aa3b, v184                       // 000000104934: 117770FF 3FB8AA3B
	.long 0xd59c0899                                           // 00000010493C: D59C0899
	v_cndmask_b32_e32 v0, v135, v128, vcc_lo                   // 000000104940: 02010187
	v_mul_f32_e32 v190, 0x3fb8aa3b, v130                       // 000000104944: 117D04FF 3FB8AA3B
	v_cndmask_b32_e32 v136, 0x7f800000, v136, vcc_lo           // 00000010494C: 031110FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v182                 // 000000104954: 7C3D6CFF 42B17218
	v_rndne_f32_e32 v188, v187                                 // 00000010495C: 7F7847BB
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000104960: BF870124
	v_fma_f32 v193, 0x3fb8aa3b, v130, -v190                    // 000000104964: D61300C1 86FB04FF 3FB8AA3B
	v_cndmask_b32_e32 v155, 0x7f800000, v155, vcc_lo           // 000000104970: 033736FF 7F800000
	v_fmac_f32_e32 v193, 0x32a5705f, v130                      // 000000104978: 578304FF 32A5705F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 000000104980: BF870242
	.long 0xd59c0885                                           // 000000104984: D59C0885
	v_cndmask_b32_e32 v0, v155, v128, vcc_lo                   // 000000104988: 0201019B
	v_sub_f32_e32 v183, v185, v132                             // 00000010498C: 096F09B9
	.long 0xd59c08b9                                           // 000000104990: D59C08B9
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 000000104994: 02010188
	.long 0xd59c48b9                                           // 000000104998: D59C48B9
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 00000010499C: 02010185
	v_and_b32_e32 v186, 1, v133                                // 0000001049A0: 37750A81
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001049A4: BF870224
	v_mul_f32_e32 v182, 0x3fb8aa3b, v183                       // 0000001049A8: 116D6EFF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v183                 // 0000001049B0: 7C376EFF C2CE8ED0
	v_dual_add_f32 v134, v154, v136 :: v_dual_and_b32 v185, 1, v185// 0000001049B8: C925119A 86B97281
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001049C0: BF8701A3
	v_fma_f32 v154, 0x3fb8aa3b, v183, -v182                    // 0000001049C4: D613009A 86DB6EFF 3FB8AA3B
	v_rndne_f32_e32 v156, v182                                 // 0000001049D0: 7F3847B6
	v_add3_u32 v136, v136, v185, 0x7fff                        // 0000001049D4: D6550088 03FF7388 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001049E0: BF870193
	v_fmac_f32_e32 v154, 0x32a5705f, v183                      // 0000001049E4: 57356EFF 32A5705F
	v_sub_f32_e32 v182, v182, v156                             // 0000001049EC: 096D39B6
	v_cvt_i32_f32_e32 v156, v156                               // 0000001049F0: 7F38119C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001049F4: BF8701B2
	v_add_f32_e32 v154, v182, v154                             // 0000001049F8: 073535B6
	v_fma_f32 v182, 0x3fb8aa3b, v184, -v187                    // 0000001049FC: D61300B6 86EF70FF 3FB8AA3B
	v_sub_f32_e32 v187, v187, v188                             // 000000104A08: 097779BB
	v_exp_f32_e32 v154, v154                                   // 000000104A0C: 7F344B9A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000104A10: BF870092
	v_fmac_f32_e32 v182, 0x32a5705f, v184                      // 000000104A14: 576D70FF 32A5705F
	v_dual_add_f32 v182, v187, v182 :: v_dual_sub_f32 v187, v189, v192// 000000104A1C: C90B6DBB B6BB81BD
	v_rndne_f32_e32 v194, v190                                 // 000000104A24: 7F8447BE
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000104A28: BF870195
	.long 0xd71c009a                                           // 000000104A2C: D71C009A
	v_cndmask_b32_e32 v1, v154, v156, vcc_lo                   // 000000104A30: 0203399A
	v_add_f32_e32 v185, v187, v191                             // 000000104A34: 07737FBB
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000104A38: BF870193
	v_sub_f32_e32 v189, v190, v194                             // 000000104A3C: 097B85BE
	v_cndmask_b32_e32 v154, 0, v154, vcc_lo                    // 000000104A40: 03353480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v183                 // 000000104A44: 7C3D6EFF 42B17218
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000104A4C: BF870194
	v_exp_f32_e32 v156, v185                                   // 000000104A50: 7F384BB9
	v_add_f32_e32 v187, v189, v193                             // 000000104A54: 077783BD
	v_exp_f32_e32 v182, v182                                   // 000000104A58: 7F6C4BB6
	v_cvt_i32_f32_e32 v185, v188                               // 000000104A5C: 7F7211BC
	v_dual_add_f32 v134, v134, v155 :: v_dual_cndmask_b32 v183, 0x7f800000, v154// 000000104A60: C9133786 86B734FF 7F800000
	v_cvt_i32_f32_e32 v188, v192                               // 000000104A6C: 7F7811C0
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v184                 // 000000104A70: 7C3770FF C2CE8ED0
	v_exp_f32_e32 v187, v187                                   // 000000104A78: 7F764BBB
	s_delay_alu instid0(VALU_DEP_3)                            // 000000104A7C: BF870003
	.long 0xd59c0885                                           // 000000104A80: D59C0885
	v_cndmask_b32_e32 v0, v183, v128, vcc_lo                   // 000000104A84: 020101B7
	s_delay_alu instid0(TRANS32_DEP_3) | instid1(VALU_DEP_3)   // 000000104A88: BF870187
	.long 0xd71c009a                                           // 000000104A8C: D71C009A
	v_cndmask_b32_e32 v1, v156, v188, vcc_lo                   // 000000104A90: 0203799C
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000104A94: BF870126
	.long 0xd71c00b6                                           // 000000104A98: D71C00B6
	v_cndmask_b32_e32 v1, v182, v185, vcc_lo                   // 000000104A9C: 020373B6
	v_cvt_i32_f32_e32 v185, v194                               // 000000104AA0: 7F7211C2
	v_cndmask_b32_e32 v156, 0, v182, vcc_lo                    // 000000104AA4: 03396C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v129                 // 000000104AA8: 7C3702FF C2CE8ED0
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 000000104AB0: BF870185
	.long 0xd71c00b6                                           // 000000104AB4: D71C00B6
	v_cndmask_b32_e32 v1, v187, v185, vcc_lo                   // 000000104AB8: 020373BB
	v_cndmask_b32_e32 v154, 0, v154, vcc_lo                    // 000000104ABC: 03353480
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v184                 // 000000104AC0: 7C3D70FF 42B17218
	v_cndmask_b32_e32 v156, 0x7f800000, v156, vcc_lo           // 000000104AC8: 033938FF 7F800000
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 000000104AD0: 7C3704FF C2CE8ED0
	v_cndmask_b32_e32 v182, 0, v182, vcc_lo                    // 000000104AD8: 036D6C80
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v129                 // 000000104ADC: 7C3D02FF 42B17218
	v_cndmask_b32_e32 v129, 0x7f800000, v154, vcc_lo           // 000000104AE4: 030334FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 000000104AEC: 7C3D04FF 42B17218
	.long 0xd59c089a                                           // 000000104AF4: D59C089A
	v_cndmask_b32_e32 v0, v156, v128, vcc_lo                   // 000000104AF8: 0201019C
	.long 0xd59c489a                                           // 000000104AFC: D59C489A
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 000000104B00: 02010185
	v_add_f32_e32 v134, v134, v156                             // 000000104B04: 070D3986
	v_cndmask_b32_e32 v130, 0x7f800000, v182, vcc_lo           // 000000104B08: 03056CFF 7F800000
	.long 0xd59c08b6                                           // 000000104B10: D59C08B6
	v_cndmask_b32_e32 v0, v129, v128, vcc_lo                   // 000000104B14: 02010181
	.long 0xd59c48b6                                           // 000000104B18: D59C48B6
	v_cndmask_b32_e32 v0, v133, v128, vcc_lo                   // 000000104B1C: 02010185
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 000000104B20: BF870234
	v_dual_add_f32 v134, v134, v183 :: v_dual_and_b32 v185, 1, v154// 000000104B24: C9256F86 86B93481
	v_add3_u32 v154, v155, v186, 0x7fff                        // 000000104B2C: D655009A 03FF759B 00007FFF
	.long 0xd59c089a                                           // 000000104B38: D59C089A
	v_cndmask_b32_e32 v0, v136, v128, vcc_lo                   // 000000104B3C: 02010188
	v_and_b32_e32 v182, 1, v182                                // 000000104B40: 376D6C81
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000104B44: BF870114
	v_add3_u32 v185, v156, v185, 0x7fff                        // 000000104B48: D65500B9 03FF739C 00007FFF
	v_add3_u32 v182, v129, v182, 0x7fff                        // 000000104B54: D65500B6 03FF6D81 00007FFF
	v_add_f32_e32 v129, v134, v129                             // 000000104B60: 07030386
	v_and_b32_e32 v184, 1, v133                                // 000000104B64: 37710A81
	.long 0xd59c0885                                           // 000000104B68: D59C0885
	v_cndmask_b32_e32 v0, v130, v128, vcc_lo                   // 000000104B6C: 02010182
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000104B70: BF870193
	v_add_f32_e32 v129, v129, v130                             // 000000104B74: 07030581
	v_add3_u32 v155, v183, v184, 0x7fff                        // 000000104B78: D655009B 03FF71B7 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000104B84: BF870123
	v_and_b32_e32 v133, 1, v133                                // 000000104B88: 370B0A81
	.long 0xd59c089b                                           // 000000104B8C: D59C089B
	v_cndmask_b32_e32 v0, v185, v128, vcc_lo                   // 000000104B90: 020101B9
	v_add3_u32 v156, v130, v133, 0x7fff                        // 000000104B94: D655009C 03FF0B82 00007FFF
	.long 0xd59c089c                                           // 000000104BA0: D59C089C
	v_cndmask_b32_e32 v0, v182, v128, vcc_lo                   // 000000104BA4: 020101B6
	ds_store_b128 v173, v[149:152]                             // 000000104BA8: DB7C0000 000095AD
	ds_store_b128 v173, v[153:156] offset:16                   // 000000104BB0: DB7C0010 000099AD
	v_mov_b32_e32 v130, 0                                      // 000000104BB8: 7F040280
	s_mov_b32 s1, exec_lo                                      // 000000104BBC: BE81007E
	s_waitcnt lgkmcnt(0)                                       // 000000104BC0: BF89FC07
	v_cmpx_lt_f32_e32 0xefa18f08, v131                         // 000000104BC4: 7D2306FF EFA18F08
	s_cbranch_execz 27                                         // 000000104BCC: BFA5001B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x2f3c>
	v_sub_f32_e32 v130, v131, v132                             // 000000104BD0: 09050983
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000104BD4: BF870121
	v_mul_f32_e32 v131, 0x3fb8aa3b, v130                       // 000000104BD8: 110704FF 3FB8AA3B
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v130                 // 000000104BE0: 7C3704FF C2CE8ED0
	v_fma_f32 v133, 0x3fb8aa3b, v130, -v131                    // 000000104BE8: D6130085 860F04FF 3FB8AA3B
	v_rndne_f32_e32 v134, v131                                 // 000000104BF4: 7F0C4783
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000104BF8: BF870112
	v_fmac_f32_e32 v133, 0x32a5705f, v130                      // 000000104BFC: 570B04FF 32A5705F
	v_sub_f32_e32 v131, v131, v134                             // 000000104C04: 09070D83
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000104C08: BF870121
	v_add_f32_e32 v131, v131, v133                             // 000000104C0C: 07070B83
	v_cvt_i32_f32_e32 v133, v134                               // 000000104C10: 7F0A1186
	v_exp_f32_e32 v131, v131                                   // 000000104C14: 7F064B83
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000104C18: BF870095
	.long 0xd71c0083                                           // 000000104C1C: D71C0083
	v_cndmask_b32_e32 v1, v131, v133, vcc_lo                   // 000000104C20: 02030B83
	v_cndmask_b32_e32 v131, 0, v131, vcc_lo                    // 000000104C24: 03070680
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v130                 // 000000104C28: 7C3D04FF 42B17218
	s_delay_alu instid0(VALU_DEP_2)                            // 000000104C30: BF870002
	v_cndmask_b32_e32 v130, 0x7f800000, v131, vcc_lo           // 000000104C34: 030506FF 7F800000
	s_or_b32 exec_lo, exec_lo, s1                              // 000000104C3C: 8C7E017E
	ds_load_b32 v131, v174                                     // 000000104C40: D8D80000 830000AE
	s_waitcnt lgkmcnt(0)                                       // 000000104C48: BF89FC07
	v_fmac_f32_e32 v129, v130, v131                            // 000000104C4C: 57030782
	ds_store_b32 v171, v132                                    // 000000104C50: D8340000 000084AB
	ds_store_b32 v174, v129                                    // 000000104C58: D8340000 000081AE
	ds_store_b32 v175, v130                                    // 000000104C60: D8340000 000082AF
	s_or_b32 exec_lo, exec_lo, s4                              // 000000104C68: 8C7E047E
	s_waitcnt lgkmcnt(0)                                       // 000000104C6C: BF89FC07
	s_barrier                                                  // 000000104C70: BFBD0000
	buffer_gl0_inv                                             // 000000104C74: E0AC0000 00000000
	ds_load_2addr_b32 v[155:156], v176 offset1:2               // 000000104C7C: D8DC0200 9B0000B0
	ds_load_2addr_b32 v[153:154], v176 offset0:4 offset1:6     // 000000104C84: D8DC0604 990000B0
	ds_load_2addr_b32 v[151:152], v176 offset0:8 offset1:10    // 000000104C8C: D8DC0A08 970000B0
	ds_load_2addr_b32 v[149:150], v176 offset0:12 offset1:14   // 000000104C94: D8DC0E0C 950000B0
	s_waitcnt lgkmcnt(3)                                       // 000000104C9C: BF89FC37
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v155                         // 000000104CA0: 7C2536F2
	.long 0xd4120001                                           // 000000104CA4: D4120001
	v_cndmask_b32_e32 v1, 1.0, v156, vcc_lo                    // 000000104CA8: 020338F2
	s_waitcnt lgkmcnt(2)                                       // 000000104CAC: BF89FC27
	.long 0xd4120002                                           // 000000104CB0: D4120002
	v_cndmask_b32_e32 v1, 1.0, v153, vcc_lo                    // 000000104CB4: 020332F2
	.long 0xd4120004                                           // 000000104CB8: D4120004
	v_cndmask_b32_e32 v1, 1.0, v154, vcc_lo                    // 000000104CBC: 020334F2
	s_and_b32 s1, vcc_lo, s1                                   // 000000104CC0: 8B01016A
	s_waitcnt lgkmcnt(1)                                       // 000000104CC4: BF89FC17
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v151                         // 000000104CC8: 7C252EF2
	s_and_b32 s2, s1, s2                                       // 000000104CCC: 8B020201
	.long 0xd4120001                                           // 000000104CD0: D4120001
	v_cndmask_b32_e32 v1, 1.0, v152, vcc_lo                    // 000000104CD4: 020330F2
	s_and_b32 s4, s2, s4                                       // 000000104CD8: 8B040402
	s_waitcnt lgkmcnt(0)                                       // 000000104CDC: BF89FC07
	.long 0xd4120002                                           // 000000104CE0: D4120002
	v_cndmask_b32_e32 v1, 1.0, v149, vcc_lo                    // 000000104CE4: 02032AF2
	s_and_b32 s4, s4, vcc_lo                                   // 000000104CE8: 8B046A04
	v_cmp_eq_f32_e32 vcc_lo, 1.0, v150                         // 000000104CEC: 7C252CF2
	s_and_b32 s1, s4, s1                                       // 000000104CF0: 8B010104
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 000000104CF4: BF870499
	s_and_b32 s1, s1, s2                                       // 000000104CF8: 8B010201
	s_and_b32 s1, s1, vcc_lo                                   // 000000104CFC: 8B016A01
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000104D00: BF870099
	v_cndmask_b32_e64 v129, 0, 1, s1                           // 000000104D04: D5010081 00050280
	v_cmp_ne_u32_e32 vcc_lo, 0, v129                           // 000000104D0C: 7C9B0280
	ds_load_b128 v[129:132], v177                              // 000000104D10: DBFC0000 810000B1
	ds_load_b128 v[133:136], v177 offset:16                    // 000000104D18: DBFC0010 850000B1
	s_cmp_eq_u32 vcc_lo, exec_lo                               // 000000104D20: BF067E6A
	s_cselect_b32 s1, -1, 0                                    // 000000104D24: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000104D28: BF870099
	v_cndmask_b32_e64 v182, 0, 1, s1                           // 000000104D2C: D50100B6 00050280
	v_readfirstlane_b32 s1, v182                               // 000000104D34: 7E0205B6
	s_bitcmp1_b32 s1, 0                                        // 000000104D38: BF0D8001
	s_cselect_b32 s1, -1, 0                                    // 000000104D3C: 980180C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000104D40: BF870009
	s_and_b32 vcc_lo, exec_lo, s1                              // 000000104D44: 8B6A017E
	s_cbranch_vccnz 63001                                      // 000000104D48: BFA4F619 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b0>
	v_dual_mul_f32 v120, v155, v120 :: v_dual_mul_f32 v121, v156, v121// 000000104D4C: C8C6F19B 7878F39C
	v_dual_mul_f32 v122, v153, v122 :: v_dual_mul_f32 v123, v154, v123// 000000104D54: C8C6F599 7A7AF79A
	v_dual_mul_f32 v124, v151, v124 :: v_dual_mul_f32 v125, v152, v125// 000000104D5C: C8C6F997 7C7CFB98
	v_dual_mul_f32 v126, v149, v126 :: v_dual_mul_f32 v127, v150, v127// 000000104D64: C8C6FD95 7E7EFF96
	v_dual_mul_f32 v112, v155, v112 :: v_dual_mul_f32 v113, v156, v113// 000000104D6C: C8C6E19B 7070E39C
	v_dual_mul_f32 v114, v153, v114 :: v_dual_mul_f32 v115, v154, v115// 000000104D74: C8C6E599 7272E79A
	v_dual_mul_f32 v116, v151, v116 :: v_dual_mul_f32 v117, v152, v117// 000000104D7C: C8C6E997 7474EB98
	v_dual_mul_f32 v118, v149, v118 :: v_dual_mul_f32 v119, v150, v119// 000000104D84: C8C6ED95 7676EF96
	v_dual_mul_f32 v104, v155, v104 :: v_dual_mul_f32 v105, v156, v105// 000000104D8C: C8C6D19B 6868D39C
	v_dual_mul_f32 v106, v153, v106 :: v_dual_mul_f32 v107, v154, v107// 000000104D94: C8C6D599 6A6AD79A
	v_dual_mul_f32 v108, v151, v108 :: v_dual_mul_f32 v109, v152, v109// 000000104D9C: C8C6D997 6C6CDB98
	v_dual_mul_f32 v110, v149, v110 :: v_dual_mul_f32 v111, v150, v111// 000000104DA4: C8C6DD95 6E6EDF96
	v_dual_mul_f32 v96, v155, v96 :: v_dual_mul_f32 v97, v156, v97// 000000104DAC: C8C6C19B 6060C39C
	v_dual_mul_f32 v98, v153, v98 :: v_dual_mul_f32 v99, v154, v99// 000000104DB4: C8C6C599 6262C79A
	v_dual_mul_f32 v100, v151, v100 :: v_dual_mul_f32 v101, v152, v101// 000000104DBC: C8C6C997 6464CB98
	v_dual_mul_f32 v102, v149, v102 :: v_dual_mul_f32 v103, v150, v103// 000000104DC4: C8C6CD95 6666CF96
	v_dual_mul_f32 v88, v155, v88 :: v_dual_mul_f32 v89, v156, v89// 000000104DCC: C8C6B19B 5858B39C
	v_dual_mul_f32 v90, v153, v90 :: v_dual_mul_f32 v91, v154, v91// 000000104DD4: C8C6B599 5A5AB79A
	v_dual_mul_f32 v92, v151, v92 :: v_dual_mul_f32 v93, v152, v93// 000000104DDC: C8C6B997 5C5CBB98
	v_dual_mul_f32 v94, v149, v94 :: v_dual_mul_f32 v95, v150, v95// 000000104DE4: C8C6BD95 5E5EBF96
	v_dual_mul_f32 v80, v155, v80 :: v_dual_mul_f32 v81, v156, v81// 000000104DEC: C8C6A19B 5050A39C
	v_dual_mul_f32 v82, v153, v82 :: v_dual_mul_f32 v83, v154, v83// 000000104DF4: C8C6A599 5252A79A
	v_dual_mul_f32 v84, v151, v84 :: v_dual_mul_f32 v85, v152, v85// 000000104DFC: C8C6A997 5454AB98
	v_dual_mul_f32 v86, v149, v86 :: v_dual_mul_f32 v87, v150, v87// 000000104E04: C8C6AD95 5656AF96
	v_dual_mul_f32 v72, v155, v72 :: v_dual_mul_f32 v73, v156, v73// 000000104E0C: C8C6919B 4848939C
	v_dual_mul_f32 v74, v153, v74 :: v_dual_mul_f32 v75, v154, v75// 000000104E14: C8C69599 4A4A979A
	v_dual_mul_f32 v76, v151, v76 :: v_dual_mul_f32 v77, v152, v77// 000000104E1C: C8C69997 4C4C9B98
	v_dual_mul_f32 v78, v149, v78 :: v_dual_mul_f32 v79, v150, v79// 000000104E24: C8C69D95 4E4E9F96
	v_dual_mul_f32 v64, v155, v64 :: v_dual_mul_f32 v65, v156, v65// 000000104E2C: C8C6819B 4040839C
	v_dual_mul_f32 v66, v153, v66 :: v_dual_mul_f32 v67, v154, v67// 000000104E34: C8C68599 4242879A
	v_dual_mul_f32 v68, v151, v68 :: v_dual_mul_f32 v69, v152, v69// 000000104E3C: C8C68997 44448B98
	v_dual_mul_f32 v70, v149, v70 :: v_dual_mul_f32 v71, v150, v71// 000000104E44: C8C68D95 46468F96
	v_dual_mul_f32 v56, v155, v56 :: v_dual_mul_f32 v57, v156, v57// 000000104E4C: C8C6719B 3838739C
	v_dual_mul_f32 v58, v153, v58 :: v_dual_mul_f32 v59, v154, v59// 000000104E54: C8C67599 3A3A779A
	v_dual_mul_f32 v60, v151, v60 :: v_dual_mul_f32 v61, v152, v61// 000000104E5C: C8C67997 3C3C7B98
	v_dual_mul_f32 v62, v149, v62 :: v_dual_mul_f32 v63, v150, v63// 000000104E64: C8C67D95 3E3E7F96
	v_dual_mul_f32 v48, v155, v48 :: v_dual_mul_f32 v49, v156, v49// 000000104E6C: C8C6619B 3030639C
	v_dual_mul_f32 v50, v153, v50 :: v_dual_mul_f32 v51, v154, v51// 000000104E74: C8C66599 3232679A
	v_dual_mul_f32 v52, v151, v52 :: v_dual_mul_f32 v53, v152, v53// 000000104E7C: C8C66997 34346B98
	v_dual_mul_f32 v54, v149, v54 :: v_dual_mul_f32 v55, v150, v55// 000000104E84: C8C66D95 36366F96
	v_dual_mul_f32 v40, v155, v40 :: v_dual_mul_f32 v41, v156, v41// 000000104E8C: C8C6519B 2828539C
	v_dual_mul_f32 v42, v153, v42 :: v_dual_mul_f32 v43, v154, v43// 000000104E94: C8C65599 2A2A579A
	v_dual_mul_f32 v44, v151, v44 :: v_dual_mul_f32 v45, v152, v45// 000000104E9C: C8C65997 2C2C5B98
	v_dual_mul_f32 v46, v149, v46 :: v_dual_mul_f32 v47, v150, v47// 000000104EA4: C8C65D95 2E2E5F96
	v_dual_mul_f32 v32, v155, v32 :: v_dual_mul_f32 v33, v156, v33// 000000104EAC: C8C6419B 2020439C
	v_dual_mul_f32 v34, v153, v34 :: v_dual_mul_f32 v35, v154, v35// 000000104EB4: C8C64599 2222479A
	v_dual_mul_f32 v36, v151, v36 :: v_dual_mul_f32 v37, v152, v37// 000000104EBC: C8C64997 24244B98
	v_dual_mul_f32 v38, v149, v38 :: v_dual_mul_f32 v39, v150, v39// 000000104EC4: C8C64D95 26264F96
	v_dual_mul_f32 v24, v155, v24 :: v_dual_mul_f32 v25, v156, v25// 000000104ECC: C8C6319B 1818339C
	v_dual_mul_f32 v26, v153, v26 :: v_dual_mul_f32 v27, v154, v27// 000000104ED4: C8C63599 1A1A379A
	v_dual_mul_f32 v28, v151, v28 :: v_dual_mul_f32 v29, v152, v29// 000000104EDC: C8C63997 1C1C3B98
	v_dual_mul_f32 v30, v149, v30 :: v_dual_mul_f32 v31, v150, v31// 000000104EE4: C8C63D95 1E1E3F96
	v_dual_mul_f32 v16, v155, v16 :: v_dual_mul_f32 v17, v156, v17// 000000104EEC: C8C6219B 1010239C
	v_dual_mul_f32 v18, v153, v18 :: v_dual_mul_f32 v19, v154, v19// 000000104EF4: C8C62599 1212279A
	v_dual_mul_f32 v20, v151, v20 :: v_dual_mul_f32 v21, v152, v21// 000000104EFC: C8C62997 14142B98
	v_dual_mul_f32 v22, v149, v22 :: v_dual_mul_f32 v23, v150, v23// 000000104F04: C8C62D95 16162F96
	v_dual_mul_f32 v8, v155, v8 :: v_dual_mul_f32 v9, v156, v9 // 000000104F0C: C8C6119B 0808139C
	v_dual_mul_f32 v10, v153, v10 :: v_dual_mul_f32 v11, v154, v11// 000000104F14: C8C61599 0A0A179A
	v_dual_mul_f32 v12, v151, v12 :: v_dual_mul_f32 v13, v152, v13// 000000104F1C: C8C61997 0C0C1B98
	v_dual_mul_f32 v14, v149, v14 :: v_dual_mul_f32 v15, v150, v15// 000000104F24: C8C61D95 0E0E1F96
	v_dual_mul_f32 v0, v155, v0 :: v_dual_mul_f32 v1, v156, v1 // 000000104F2C: C8C6019B 0000039C
	v_dual_mul_f32 v2, v153, v2 :: v_dual_mul_f32 v3, v154, v3 // 000000104F34: C8C60599 0202079A
	v_dual_mul_f32 v4, v151, v4 :: v_dual_mul_f32 v5, v152, v5 // 000000104F3C: C8C60997 04040B98
	v_dual_mul_f32 v6, v149, v6 :: v_dual_mul_f32 v7, v150, v7 // 000000104F44: C8C60D95 06060F96
	s_branch 62872                                             // 000000104F4C: BFA0F598 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8b0>
	v_lshlrev_b32_e32 v128, 2, v162                            // 000000104F50: 31014482
	.long 0xd700008e                                           // 000000104F54: D700008E
	v_cndmask_b32_e32 v1, s18, v142, vcc_lo                    // 000000104F58: 02031C12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000104F5C: BF870191
	v_add_co_ci_u32_e64 v143, null, s19, v143, s0              // 000000104F60: D5207C8F 00031E13
	v_lshl_or_b32 v128, v157, 6, v128                          // 000000104F68: D6560080 06010D9D
	s_waitcnt vmcnt(0)                                         // 000000104F70: BF8903F7
	v_or_b32_e32 v140, v158, v162                              // 000000104F74: 3919459E
	s_delay_alu instid0(VALU_DEP_2)                            // 000000104F78: BF870002
	v_add_nc_u32_e32 v132, 0xf000, v128                        // 000000104F7C: 4B0900FF 0000F000
	v_lshlrev_b32_e32 v128, 9, v141                            // 000000104F84: 31011A89
	ds_load_2addr_b32 v[138:139], v132 offset0:192 offset1:194 // 000000104F88: D8DCC2C0 8A000084
	ds_load_2addr_b32 v[136:137], v132 offset0:196 offset1:198 // 000000104F90: D8DCC6C4 88000084
	ds_load_2addr_b32 v[134:135], v132 offset0:200 offset1:202 // 000000104F98: D8DCCAC8 86000084
	ds_load_2addr_b32 v[132:133], v132 offset0:204 offset1:206 // 000000104FA0: D8DCCECC 84000084
	s_waitcnt lgkmcnt(3)                                       // 000000104FA8: BF89FC37
	v_div_scale_f32 v144, null, v138, v138, 1.0                // 000000104FAC: D6FC7C90 03CB158A
	v_div_scale_f32 v141, vcc_lo, 1.0, v138, 1.0               // 000000104FB4: D6FC6A8D 03CB14F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000104FBC: BF870292
	v_rcp_f32_e32 v145, v144                                   // 000000104FC0: 7F225590
	v_fma_f32 v129, -v144, v145, 1.0                           // 000000104FC4: D6130081 23CB2390
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000104FCC: BF870121
	v_fmac_f32_e32 v145, v129, v145                            // 000000104FD0: 57232381
	v_ashrrev_i32_e32 v129, 31, v128                           // 000000104FD4: 3503009F
	v_mul_f32_e32 v146, v141, v145                             // 000000104FD8: 1125238D
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000104FDC: BF8700A2
	.long 0xd73c0082                                           // 000000104FE0: D73C0082
	v_cndmask_b32_e32 v1, 1, v128, vcc_lo                      // 000000104FE4: 02030081
	.long 0xd7000080                                           // 000000104FE8: D7000080
	v_cndmask_b32_e32 v1, v142, v160, vcc_lo                   // 000000104FEC: 0203418E
	v_add_co_ci_u32_e64 v129, null, 0, v143, s0                // 000000104FF0: D5207C81 00031E80
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 000000104FF8: BF870214
	v_fma_f32 v147, -v144, v146, v141                          // 000000104FFC: D6130093 26372590
	.long 0xd7000082                                           // 000000105004: D7000082
	v_cndmask_b32_e32 v1, s16, v130, vcc_lo                    // 000000105008: 02030410
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000010500C: BF870191
	v_add_co_ci_u32_e64 v131, null, s17, v131, s0              // 000000105010: D5207C83 00030611
	v_fmac_f32_e32 v146, v147, v145                            // 000000105018: 57252393
	.long 0xd4440000                                           // 00000010501C: D4440000
	v_cndmask_b32_e32 v1, s14, v140, vcc_lo                    // 000000105020: 0203180E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105024: BF870092
	v_fma_f32 v141, -v144, v146, v141                          // 000000105028: D613008D 26372590
	v_div_fmas_f32 v141, v141, v145, v146                      // 000000105030: D637008D 064B238D
	.long 0xd7006a82                                           // 000000105038: D7006A82
	v_cndmask_b32_e32 v1, v130, v160, vcc_lo                   // 00000010503C: 02034182
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000105040: BF870191
	v_add_co_ci_u32_e64 v131, null, 0, v131, vcc_lo            // 000000105044: D5207C83 01AB0680
	v_div_fixup_f32 v138, v141, v138, 1.0                      // 00000010504C: D627008A 03CB158D
	s_and_saveexec_b32 s1, s0                                  // 000000105054: BE812000
	s_cbranch_execz 70                                         // 000000105058: BFA50046 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3474>
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010505C: BF870112
	v_mad_i64_i32 v[141:142], null, 0x6000, v140, v[130:131]   // 000000105060: D6FF7C8D 060B18FF 00006000
	v_mul_f32_e32 v120, v138, v120                             // 00000010506C: 10F0F18A
	global_load_u16 v141, v[141:142], off offset:512           // 000000105070: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000105078: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000010507C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105080: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000105084: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000010508C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000105098: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010509C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000001050A0: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000001050A4: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000001050AC: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001050B4: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000001050B8: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000001050BC: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000001050C0: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001050C4: BF870095
	.long 0xd71c008e                                           // 0000001050C8: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000001050CC: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000001050D0: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000001050D4: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001050DC: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000001050E0: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000001050E8: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001050EC: BF870091
	v_div_scale_f32 v142, null, v141, v141, v120               // 0000001050F0: D6FC7C8E 05E31B8D
	v_rcp_f32_e32 v143, v142                                   // 0000001050F8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001050FC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000105100: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000105108: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v120, v141, v120             // 00000010510C: D6FC6A90 05E31B78
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105114: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000105118: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 00000010511C: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105124: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000105128: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 00000010512C: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105134: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000105138: D637008E 06471F8E
	v_div_fixup_f32 v120, v142, v141, v120                     // 000000105140: D6270078 05E31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v140, v[128:129]   // 000000105148: D6FF7C8D 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105154: BF870092
	v_bfe_u32 v143, v120, 16, 1                                // 000000105158: D610008F 02052178
	v_add3_u32 v120, v120, v143, 0x7fff                        // 000000105160: D6550078 03FF1F78 00007FFF
	global_store_d16_hi_b16 v[141:142], v120, off              // 00000010516C: DC960000 007C788D
	s_or_b32 exec_lo, exec_lo, s1                              // 000000105174: 8C7E017E
	v_div_scale_f32 v120, null, v139, v139, 1.0                // 000000105178: D6FC7C78 03CB178B
	v_div_scale_f32 v143, vcc_lo, 1.0, v139, 1.0               // 000000105180: D6FC6A8F 03CB16F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000105188: BF870292
	v_rcp_f32_e32 v141, v120                                   // 00000010518C: 7F1A5578
	v_fma_f32 v142, -v120, v141, 1.0                           // 000000105190: D613008E 23CB1B78
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105198: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000010519C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000001051A0: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001051A4: BF870091
	v_fma_f32 v144, -v120, v142, v143                          // 0000001051A8: D6130090 263F1D78
	v_fmac_f32_e32 v142, v144, v141                            // 0000001051B0: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001051B4: BF870091
	v_fma_f32 v120, -v120, v142, v143                          // 0000001051B8: D6130078 263F1D78
	v_div_fmas_f32 v141, v120, v141, v142                      // 0000001051C0: D637008D 063B1B78
	v_or_b32_e32 v120, 2, v140                                 // 0000001051C8: 38F11882
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001051CC: BF870112
	v_div_fixup_f32 v139, v141, v139, 1.0                      // 0000001051D0: D627008B 03CB178D
	.long 0xd4440001                                           // 0000001051D8: D4440001
	v_cndmask_b32_e32 v1, s14, v120, vcc_lo                    // 0000001051DC: 0202F00E
	s_and_saveexec_b32 s2, s1                                  // 0000001051E0: BE822001
	s_cbranch_execz 69                                         // 0000001051E4: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x35fc>
	v_mad_i64_i32 v[141:142], null, 0x6000, v120, v[130:131]   // 0000001051E8: D6FF7C8D 060AF0FF 00006000
	v_mul_f32_e32 v121, v139, v121                             // 0000001051F4: 10F2F38B
	global_load_u16 v141, v[141:142], off offset:512           // 0000001051F8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000105200: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000105204: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105208: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 00000010520C: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000105214: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000105220: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000105224: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000105228: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000010522C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000105234: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010523C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000105240: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000105244: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000105248: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010524C: BF870095
	.long 0xd71c008e                                           // 000000105250: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000105254: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000105258: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000010525C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105264: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000105268: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000105270: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105274: BF870091
	v_div_scale_f32 v142, null, v141, v141, v121               // 000000105278: D6FC7C8E 05E71B8D
	v_rcp_f32_e32 v143, v142                                   // 000000105280: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105284: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000105288: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000105290: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v121, v141, v121             // 000000105294: D6FC6A90 05E71B79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010529C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000001052A0: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000001052A4: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001052AC: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000001052B0: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000001052B4: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001052BC: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000001052C0: D637008E 06471F8E
	v_div_fixup_f32 v121, v142, v141, v121                     // 0000001052C8: D6270079 05E71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v120, v[128:129]   // 0000001052D0: D6FF7C8D 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001052DC: BF870092
	v_bfe_u32 v143, v121, 16, 1                                // 0000001052E0: D610008F 02052179
	v_add3_u32 v121, v121, v143, 0x7fff                        // 0000001052E8: D6550079 03FF1F79 00007FFF
	global_store_d16_hi_b16 v[141:142], v121, off              // 0000001052F4: DC960000 007C798D
	s_or_b32 exec_lo, exec_lo, s2                              // 0000001052FC: 8C7E027E
	s_waitcnt lgkmcnt(2)                                       // 000000105300: BF89FC27
	v_div_scale_f32 v121, null, v136, v136, 1.0                // 000000105304: D6FC7C79 03CB1188
	v_div_scale_f32 v143, vcc_lo, 1.0, v136, 1.0               // 00000010530C: D6FC6A8F 03CB10F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000105314: BF870292
	v_rcp_f32_e32 v141, v121                                   // 000000105318: 7F1A5579
	v_fma_f32 v142, -v121, v141, 1.0                           // 00000010531C: D613008E 23CB1B79
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105324: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000105328: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 00000010532C: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105330: BF870091
	v_fma_f32 v144, -v121, v142, v143                          // 000000105334: D6130090 263F1D79
	v_fmac_f32_e32 v142, v144, v141                            // 00000010533C: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105340: BF870091
	v_fma_f32 v121, -v121, v142, v143                          // 000000105344: D6130079 263F1D79
	v_div_fmas_f32 v141, v121, v141, v142                      // 00000010534C: D637008D 063B1B79
	v_or_b32_e32 v121, 4, v140                                 // 000000105354: 38F31884
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000105358: BF870112
	v_div_fixup_f32 v136, v141, v136, 1.0                      // 00000010535C: D6270088 03CB118D
	.long 0xd4440002                                           // 000000105364: D4440002
	v_cndmask_b32_e32 v1, s14, v121, vcc_lo                    // 000000105368: 0202F20E
	s_and_saveexec_b32 s3, s2                                  // 00000010536C: BE832002
	s_cbranch_execz 69                                         // 000000105370: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3788>
	v_mad_i64_i32 v[141:142], null, 0x6000, v121, v[130:131]   // 000000105374: D6FF7C8D 060AF2FF 00006000
	v_mul_f32_e32 v122, v136, v122                             // 000000105380: 10F4F588
	global_load_u16 v141, v[141:142], off offset:512           // 000000105384: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 00000010538C: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000105390: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105394: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000105398: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000001053A0: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000001053AC: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001053B0: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000001053B4: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000001053B8: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000001053C0: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001053C8: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000001053CC: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000001053D0: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000001053D4: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001053D8: BF870095
	.long 0xd71c008e                                           // 0000001053DC: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000001053E0: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000001053E4: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000001053E8: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001053F0: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 0000001053F4: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 0000001053FC: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105400: BF870091
	v_div_scale_f32 v142, null, v141, v141, v122               // 000000105404: D6FC7C8E 05EB1B8D
	v_rcp_f32_e32 v143, v142                                   // 00000010540C: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105410: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000105414: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 00000010541C: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v122, v141, v122             // 000000105420: D6FC6A90 05EB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105428: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 00000010542C: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000105430: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105438: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 00000010543C: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000105440: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105448: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 00000010544C: D637008E 06471F8E
	v_div_fixup_f32 v122, v142, v141, v122                     // 000000105454: D627007A 05EB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v121, v[128:129]   // 00000010545C: D6FF7C8D 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105468: BF870092
	v_bfe_u32 v143, v122, 16, 1                                // 00000010546C: D610008F 0205217A
	v_add3_u32 v122, v122, v143, 0x7fff                        // 000000105474: D655007A 03FF1F7A 00007FFF
	global_store_d16_hi_b16 v[141:142], v122, off              // 000000105480: DC960000 007C7A8D
	s_or_b32 exec_lo, exec_lo, s3                              // 000000105488: 8C7E037E
	v_div_scale_f32 v122, null, v137, v137, 1.0                // 00000010548C: D6FC7C7A 03CB1389
	v_div_scale_f32 v143, vcc_lo, 1.0, v137, 1.0               // 000000105494: D6FC6A8F 03CB12F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010549C: BF870292
	v_rcp_f32_e32 v141, v122                                   // 0000001054A0: 7F1A557A
	v_fma_f32 v142, -v122, v141, 1.0                           // 0000001054A4: D613008E 23CB1B7A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001054AC: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000001054B0: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000001054B4: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001054B8: BF870091
	v_fma_f32 v144, -v122, v142, v143                          // 0000001054BC: D6130090 263F1D7A
	v_fmac_f32_e32 v142, v144, v141                            // 0000001054C4: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001054C8: BF870091
	v_fma_f32 v122, -v122, v142, v143                          // 0000001054CC: D613007A 263F1D7A
	v_div_fmas_f32 v141, v122, v141, v142                      // 0000001054D4: D637008D 063B1B7A
	v_or_b32_e32 v122, 6, v140                                 // 0000001054DC: 38F51886
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001054E0: BF870112
	v_div_fixup_f32 v137, v141, v137, 1.0                      // 0000001054E4: D6270089 03CB138D
	.long 0xd4440003                                           // 0000001054EC: D4440003
	v_cndmask_b32_e32 v1, s14, v122, vcc_lo                    // 0000001054F0: 0202F40E
	s_and_saveexec_b32 s4, s3                                  // 0000001054F4: BE842003
	s_cbranch_execz 69                                         // 0000001054F8: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3910>
	v_mad_i64_i32 v[141:142], null, 0x6000, v122, v[130:131]   // 0000001054FC: D6FF7C8D 060AF4FF 00006000
	v_mul_f32_e32 v123, v137, v123                             // 000000105508: 10F6F789
	global_load_u16 v141, v[141:142], off offset:512           // 00000010550C: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000105514: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 000000105518: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010551C: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000105520: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 000000105528: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000105534: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000105538: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 00000010553C: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000105540: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000105548: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000105550: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000105554: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000105558: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 00000010555C: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105560: BF870095
	.long 0xd71c008e                                           // 000000105564: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000105568: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 00000010556C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000105570: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105578: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 00000010557C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000105584: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105588: BF870091
	v_div_scale_f32 v142, null, v141, v141, v123               // 00000010558C: D6FC7C8E 05EF1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000105594: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105598: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 00000010559C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000001055A4: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v123, v141, v123             // 0000001055A8: D6FC6A90 05EF1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001055B0: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000001055B4: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000001055B8: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001055C0: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000001055C4: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000001055C8: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001055D0: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000001055D4: D637008E 06471F8E
	v_div_fixup_f32 v123, v142, v141, v123                     // 0000001055DC: D627007B 05EF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v122, v[128:129]   // 0000001055E4: D6FF7C8D 0602F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001055F0: BF870092
	v_bfe_u32 v143, v123, 16, 1                                // 0000001055F4: D610008F 0205217B
	v_add3_u32 v123, v123, v143, 0x7fff                        // 0000001055FC: D655007B 03FF1F7B 00007FFF
	global_store_d16_hi_b16 v[141:142], v123, off              // 000000105608: DC960000 007C7B8D
	s_or_b32 exec_lo, exec_lo, s4                              // 000000105610: 8C7E047E
	s_waitcnt lgkmcnt(1)                                       // 000000105614: BF89FC17
	v_div_scale_f32 v123, null, v134, v134, 1.0                // 000000105618: D6FC7C7B 03CB0D86
	v_div_scale_f32 v143, vcc_lo, 1.0, v134, 1.0               // 000000105620: D6FC6A8F 03CB0CF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000105628: BF870292
	v_rcp_f32_e32 v141, v123                                   // 00000010562C: 7F1A557B
	v_fma_f32 v142, -v123, v141, 1.0                           // 000000105630: D613008E 23CB1B7B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105638: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 00000010563C: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000105640: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105644: BF870091
	v_fma_f32 v144, -v123, v142, v143                          // 000000105648: D6130090 263F1D7B
	v_fmac_f32_e32 v142, v144, v141                            // 000000105650: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105654: BF870091
	v_fma_f32 v123, -v123, v142, v143                          // 000000105658: D613007B 263F1D7B
	v_div_fmas_f32 v141, v123, v141, v142                      // 000000105660: D637008D 063B1B7B
	v_or_b32_e32 v123, 8, v140                                 // 000000105668: 38F71888
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010566C: BF870112
	v_div_fixup_f32 v134, v141, v134, 1.0                      // 000000105670: D6270086 03CB0D8D
	.long 0xd4440004                                           // 000000105678: D4440004
	v_cndmask_b32_e32 v1, s14, v123, vcc_lo                    // 00000010567C: 0202F60E
	s_and_saveexec_b32 s5, s4                                  // 000000105680: BE852004
	s_cbranch_execz 69                                         // 000000105684: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3a9c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v123, v[130:131]   // 000000105688: D6FF7C8D 060AF6FF 00006000
	v_mul_f32_e32 v124, v134, v124                             // 000000105694: 10F8F986
	global_load_u16 v141, v[141:142], off offset:512           // 000000105698: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000001056A0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000001056A4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001056A8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000001056AC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000001056B4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000001056C0: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001056C4: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000001056C8: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000001056CC: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000001056D4: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001056DC: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000001056E0: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000001056E4: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000001056E8: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001056EC: BF870095
	.long 0xd71c008e                                           // 0000001056F0: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 0000001056F4: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 0000001056F8: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 0000001056FC: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105704: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000105708: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000105710: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105714: BF870091
	v_div_scale_f32 v142, null, v141, v141, v124               // 000000105718: D6FC7C8E 05F31B8D
	v_rcp_f32_e32 v143, v142                                   // 000000105720: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105724: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000105728: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000105730: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v124, v141, v124             // 000000105734: D6FC6A90 05F31B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010573C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000105740: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000105744: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010574C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000105750: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000105754: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010575C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000105760: D637008E 06471F8E
	v_div_fixup_f32 v124, v142, v141, v124                     // 000000105768: D627007C 05F31B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v123, v[128:129]   // 000000105770: D6FF7C8D 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010577C: BF870092
	v_bfe_u32 v143, v124, 16, 1                                // 000000105780: D610008F 0205217C
	v_add3_u32 v124, v124, v143, 0x7fff                        // 000000105788: D655007C 03FF1F7C 00007FFF
	global_store_d16_hi_b16 v[141:142], v124, off              // 000000105794: DC960000 007C7C8D
	s_or_b32 exec_lo, exec_lo, s5                              // 00000010579C: 8C7E057E
	v_div_scale_f32 v124, null, v135, v135, 1.0                // 0000001057A0: D6FC7C7C 03CB0F87
	v_div_scale_f32 v143, vcc_lo, 1.0, v135, 1.0               // 0000001057A8: D6FC6A8F 03CB0EF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001057B0: BF870292
	v_rcp_f32_e32 v141, v124                                   // 0000001057B4: 7F1A557C
	v_fma_f32 v142, -v124, v141, 1.0                           // 0000001057B8: D613008E 23CB1B7C
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001057C0: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 0000001057C4: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 0000001057C8: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001057CC: BF870091
	v_fma_f32 v144, -v124, v142, v143                          // 0000001057D0: D6130090 263F1D7C
	v_fmac_f32_e32 v142, v144, v141                            // 0000001057D8: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001057DC: BF870091
	v_fma_f32 v124, -v124, v142, v143                          // 0000001057E0: D613007C 263F1D7C
	v_div_fmas_f32 v141, v124, v141, v142                      // 0000001057E8: D637008D 063B1B7C
	v_or_b32_e32 v124, 10, v140                                // 0000001057F0: 38F9188A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001057F4: BF870112
	v_div_fixup_f32 v135, v141, v135, 1.0                      // 0000001057F8: D6270087 03CB0F8D
	.long 0xd4440005                                           // 000000105800: D4440005
	v_cndmask_b32_e32 v1, s14, v124, vcc_lo                    // 000000105804: 0202F80E
	s_and_saveexec_b32 s6, s5                                  // 000000105808: BE862005
	s_cbranch_execz 69                                         // 00000010580C: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3c24>
	v_mad_i64_i32 v[141:142], null, 0x6000, v124, v[130:131]   // 000000105810: D6FF7C8D 060AF8FF 00006000
	v_mul_f32_e32 v125, v135, v125                             // 00000010581C: 10FAFB87
	global_load_u16 v141, v[141:142], off offset:512           // 000000105820: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 000000105828: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 00000010582C: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105830: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 000000105834: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 00000010583C: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000105848: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010584C: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000105850: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 000000105854: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 00000010585C: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000105864: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000105868: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 00000010586C: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000105870: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105874: BF870095
	.long 0xd71c008e                                           // 000000105878: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 00000010587C: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000105880: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000105884: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010588C: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000105890: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000105898: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010589C: BF870091
	v_div_scale_f32 v142, null, v141, v141, v125               // 0000001058A0: D6FC7C8E 05F71B8D
	v_rcp_f32_e32 v143, v142                                   // 0000001058A8: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001058AC: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 0000001058B0: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 0000001058B8: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v125, v141, v125             // 0000001058BC: D6FC6A90 05F71B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001058C4: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 0000001058C8: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 0000001058CC: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001058D4: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 0000001058D8: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 0000001058DC: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001058E4: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000001058E8: D637008E 06471F8E
	v_div_fixup_f32 v125, v142, v141, v125                     // 0000001058F0: D627007D 05F71B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v124, v[128:129]   // 0000001058F8: D6FF7C8D 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105904: BF870092
	v_bfe_u32 v143, v125, 16, 1                                // 000000105908: D610008F 0205217D
	v_add3_u32 v125, v125, v143, 0x7fff                        // 000000105910: D655007D 03FF1F7D 00007FFF
	global_store_d16_hi_b16 v[141:142], v125, off              // 00000010591C: DC960000 007C7D8D
	s_or_b32 exec_lo, exec_lo, s6                              // 000000105924: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000105928: BF89FC07
	v_div_scale_f32 v125, null, v132, v132, 1.0                // 00000010592C: D6FC7C7D 03CB0984
	v_div_scale_f32 v143, vcc_lo, 1.0, v132, 1.0               // 000000105934: D6FC6A8F 03CB08F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010593C: BF870292
	v_rcp_f32_e32 v141, v125                                   // 000000105940: 7F1A557D
	v_fma_f32 v142, -v125, v141, 1.0                           // 000000105944: D613008E 23CB1B7D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010594C: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000105950: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000105954: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105958: BF870091
	v_fma_f32 v144, -v125, v142, v143                          // 00000010595C: D6130090 263F1D7D
	v_fmac_f32_e32 v142, v144, v141                            // 000000105964: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105968: BF870091
	v_fma_f32 v125, -v125, v142, v143                          // 00000010596C: D613007D 263F1D7D
	v_div_fmas_f32 v141, v125, v141, v142                      // 000000105974: D637008D 063B1B7D
	v_or_b32_e32 v125, 12, v140                                // 00000010597C: 38FB188C
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000105980: BF870112
	v_div_fixup_f32 v132, v141, v132, 1.0                      // 000000105984: D6270084 03CB098D
	.long 0xd4440006                                           // 00000010598C: D4440006
	v_cndmask_b32_e32 v1, s14, v125, vcc_lo                    // 000000105990: 0202FA0E
	s_and_saveexec_b32 s7, s6                                  // 000000105994: BE872006
	s_cbranch_execz 69                                         // 000000105998: BFA50045 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3db0>
	v_mad_i64_i32 v[141:142], null, 0x6000, v125, v[130:131]   // 00000010599C: D6FF7C8D 060AFAFF 00006000
	v_mul_f32_e32 v126, v132, v126                             // 0000001059A8: 10FCFD84
	global_load_u16 v141, v[141:142], off offset:512           // 0000001059AC: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000001059B4: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000001059B8: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001059BC: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000001059C0: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000001059C8: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 0000001059D4: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001059D8: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 0000001059DC: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 0000001059E0: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 0000001059E8: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001059F0: BF870121
	v_add_f32_e32 v142, v142, v143                             // 0000001059F4: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 0000001059F8: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 0000001059FC: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105A00: BF870095
	.long 0xd71c008e                                           // 000000105A04: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000105A08: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000105A0C: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 000000105A10: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105A18: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000105A1C: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000105A24: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105A28: BF870091
	v_div_scale_f32 v142, null, v141, v141, v126               // 000000105A2C: D6FC7C8E 05FB1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000105A34: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105A38: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000105A3C: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000105A44: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v126, v141, v126             // 000000105A48: D6FC6A90 05FB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105A50: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000105A54: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000105A58: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105A60: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000105A64: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000105A68: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105A70: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 000000105A74: D637008E 06471F8E
	v_div_fixup_f32 v126, v142, v141, v126                     // 000000105A7C: D627007E 05FB1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v125, v[128:129]   // 000000105A84: D6FF7C8D 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105A90: BF870092
	v_bfe_u32 v143, v126, 16, 1                                // 000000105A94: D610008F 0205217E
	v_add3_u32 v126, v126, v143, 0x7fff                        // 000000105A9C: D655007E 03FF1F7E 00007FFF
	global_store_d16_hi_b16 v[141:142], v126, off              // 000000105AA8: DC960000 007C7E8D
	s_or_b32 exec_lo, exec_lo, s7                              // 000000105AB0: 8C7E077E
	v_div_scale_f32 v126, null, v133, v133, 1.0                // 000000105AB4: D6FC7C7E 03CB0B85
	v_div_scale_f32 v143, vcc_lo, 1.0, v133, 1.0               // 000000105ABC: D6FC6A8F 03CB0AF2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000105AC4: BF870292
	v_rcp_f32_e32 v141, v126                                   // 000000105AC8: 7F1A557E
	v_fma_f32 v142, -v126, v141, 1.0                           // 000000105ACC: D613008E 23CB1B7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105AD4: BF870091
	v_fmac_f32_e32 v141, v142, v141                            // 000000105AD8: 571B1B8E
	v_mul_f32_e32 v142, v143, v141                             // 000000105ADC: 111D1B8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105AE0: BF870091
	v_fma_f32 v144, -v126, v142, v143                          // 000000105AE4: D6130090 263F1D7E
	v_fmac_f32_e32 v142, v144, v141                            // 000000105AEC: 571D1B90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000105AF0: BF870091
	v_fma_f32 v126, -v126, v142, v143                          // 000000105AF4: D613007E 263F1D7E
	v_div_fmas_f32 v141, v126, v141, v142                      // 000000105AFC: D637008D 063B1B7E
	v_or_b32_e32 v126, 14, v140                                // 000000105B04: 38FD188E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000105B08: BF870112
	v_div_fixup_f32 v133, v141, v133, 1.0                      // 000000105B0C: D6270085 03CB0B8D
	.long 0xd4440007                                           // 000000105B14: D4440007
	v_cndmask_b32_e32 v1, s14, v126, vcc_lo                    // 000000105B18: 0202FC0E
	s_and_saveexec_b32 s8, s7                                  // 000000105B1C: BE882007
	s_cbranch_execnz 361                                       // 000000105B20: BFA60169 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x43c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105B24: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000105B28: BE882000
	s_cbranch_execnz 430                                       // 000000105B2C: BFA601AE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x44e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105B30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000105B34: BE882001
	s_cbranch_execnz 499                                       // 000000105B38: BFA601F3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4608>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105B3C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000105B40: BE882002
	s_cbranch_execnz 568                                       // 000000105B44: BFA60238 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4728>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105B48: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000105B4C: BE882003
	s_cbranch_execnz 637                                       // 000000105B50: BFA6027D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4848>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105B54: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000105B58: BE882004
	s_cbranch_execnz 706                                       // 000000105B5C: BFA602C2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4968>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105B60: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000105B64: BE882005
	s_cbranch_execnz 775                                       // 000000105B68: BFA60307 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4a88>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105B6C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000105B70: BE882006
	s_cbranch_execnz 844                                       // 000000105B74: BFA6034C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4ba8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105B78: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000105B7C: BE882007
	s_cbranch_execnz 913                                       // 000000105B80: BFA60391 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4cc8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105B84: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000105B88: BE882000
	s_cbranch_execnz 982                                       // 000000105B8C: BFA603D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4de8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105B90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000105B94: BE882001
	s_cbranch_execnz 1051                                      // 000000105B98: BFA6041B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4f08>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105B9C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000105BA0: BE882002
	s_cbranch_execnz 1120                                      // 000000105BA4: BFA60460 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5028>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105BA8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000105BAC: BE882003
	s_cbranch_execnz 1189                                      // 000000105BB0: BFA604A5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5148>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105BB4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000105BB8: BE882004
	s_cbranch_execnz 1258                                      // 000000105BBC: BFA604EA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5268>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105BC0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000105BC4: BE882005
	s_cbranch_execnz 1327                                      // 000000105BC8: BFA6052F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5388>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105BCC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000105BD0: BE882006
	s_cbranch_execnz 1396                                      // 000000105BD4: BFA60574 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x54a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105BD8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000105BDC: BE882007
	s_cbranch_execnz 1465                                      // 000000105BE0: BFA605B9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x55c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105BE4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000105BE8: BE882000
	s_cbranch_execnz 1534                                      // 000000105BEC: BFA605FE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x56e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105BF0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000105BF4: BE882001
	s_cbranch_execnz 1603                                      // 000000105BF8: BFA60643 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5808>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105BFC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000105C00: BE882002
	s_cbranch_execnz 1672                                      // 000000105C04: BFA60688 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5928>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105C08: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000105C0C: BE882003
	s_cbranch_execnz 1741                                      // 000000105C10: BFA606CD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5a48>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105C14: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000105C18: BE882004
	s_cbranch_execnz 1810                                      // 000000105C1C: BFA60712 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5b68>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105C20: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000105C24: BE882005
	s_cbranch_execnz 1879                                      // 000000105C28: BFA60757 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5c88>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105C2C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000105C30: BE882006
	s_cbranch_execnz 1948                                      // 000000105C34: BFA6079C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5da8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105C38: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000105C3C: BE882007
	s_cbranch_execnz 2017                                      // 000000105C40: BFA607E1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5ec8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105C44: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000105C48: BE882000
	s_cbranch_execnz 2086                                      // 000000105C4C: BFA60826 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x5fe8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105C50: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000105C54: BE882001
	s_cbranch_execnz 2155                                      // 000000105C58: BFA6086B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6108>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105C5C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000105C60: BE882002
	s_cbranch_execnz 2224                                      // 000000105C64: BFA608B0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6228>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105C68: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000105C6C: BE882003
	s_cbranch_execnz 2293                                      // 000000105C70: BFA608F5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6348>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105C74: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000105C78: BE882004
	s_cbranch_execnz 2362                                      // 000000105C7C: BFA6093A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6468>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105C80: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000105C84: BE882005
	s_cbranch_execnz 2431                                      // 000000105C88: BFA6097F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6588>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105C8C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000105C90: BE882006
	s_cbranch_execnz 2500                                      // 000000105C94: BFA609C4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x66a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105C98: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000105C9C: BE882007
	s_cbranch_execnz 2569                                      // 000000105CA0: BFA60A09 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x67c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105CA4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000105CA8: BE882000
	s_cbranch_execnz 2638                                      // 000000105CAC: BFA60A4E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x68e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105CB0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000105CB4: BE882001
	s_cbranch_execnz 2707                                      // 000000105CB8: BFA60A93 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6a08>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105CBC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000105CC0: BE882002
	s_cbranch_execnz 2776                                      // 000000105CC4: BFA60AD8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6b28>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105CC8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000105CCC: BE882003
	s_cbranch_execnz 2845                                      // 000000105CD0: BFA60B1D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6c48>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105CD4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000105CD8: BE882004
	s_cbranch_execnz 2914                                      // 000000105CDC: BFA60B62 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6d68>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105CE0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000105CE4: BE882005
	s_cbranch_execnz 2983                                      // 000000105CE8: BFA60BA7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6e88>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105CEC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000105CF0: BE882006
	s_cbranch_execnz 3052                                      // 000000105CF4: BFA60BEC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x6fa8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105CF8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000105CFC: BE882007
	s_cbranch_execnz 3121                                      // 000000105D00: BFA60C31 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x70c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105D04: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000105D08: BE882000
	s_cbranch_execnz 3190                                      // 000000105D0C: BFA60C76 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x71e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105D10: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000105D14: BE882001
	s_cbranch_execnz 3259                                      // 000000105D18: BFA60CBB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7308>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105D1C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000105D20: BE882002
	s_cbranch_execnz 3328                                      // 000000105D24: BFA60D00 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7428>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105D28: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000105D2C: BE882003
	s_cbranch_execnz 3397                                      // 000000105D30: BFA60D45 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7548>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105D34: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000105D38: BE882004
	s_cbranch_execnz 3466                                      // 000000105D3C: BFA60D8A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7668>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105D40: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000105D44: BE882005
	s_cbranch_execnz 3535                                      // 000000105D48: BFA60DCF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7788>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105D4C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000105D50: BE882006
	s_cbranch_execnz 3604                                      // 000000105D54: BFA60E14 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x78a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105D58: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000105D5C: BE882007
	s_cbranch_execnz 3673                                      // 000000105D60: BFA60E59 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x79c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105D64: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000105D68: BE882000
	s_cbranch_execnz 3742                                      // 000000105D6C: BFA60E9E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7ae8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105D70: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000105D74: BE882001
	s_cbranch_execnz 3811                                      // 000000105D78: BFA60EE3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7c08>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105D7C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000105D80: BE882002
	s_cbranch_execnz 3880                                      // 000000105D84: BFA60F28 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7d28>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105D88: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000105D8C: BE882003
	s_cbranch_execnz 3949                                      // 000000105D90: BFA60F6D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7e48>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105D94: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000105D98: BE882004
	s_cbranch_execnz 4018                                      // 000000105D9C: BFA60FB2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x7f68>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105DA0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000105DA4: BE882005
	s_cbranch_execnz 4087                                      // 000000105DA8: BFA60FF7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8088>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105DAC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000105DB0: BE882006
	s_cbranch_execnz 4156                                      // 000000105DB4: BFA6103C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x81a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105DB8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000105DBC: BE882007
	s_cbranch_execnz 4225                                      // 000000105DC0: BFA61081 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x82c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105DC4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000105DC8: BE882000
	s_cbranch_execnz 4294                                      // 000000105DCC: BFA610C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x83e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105DD0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000105DD4: BE882001
	s_cbranch_execnz 4363                                      // 000000105DD8: BFA6110B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8508>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105DDC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000105DE0: BE882002
	s_cbranch_execnz 4432                                      // 000000105DE4: BFA61150 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8628>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105DE8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000105DEC: BE882003
	s_cbranch_execnz 4501                                      // 000000105DF0: BFA61195 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8748>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105DF4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000105DF8: BE882004
	s_cbranch_execnz 4570                                      // 000000105DFC: BFA611DA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8868>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105E00: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000105E04: BE882005
	s_cbranch_execnz 4639                                      // 000000105E08: BFA6121F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8988>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105E0C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000105E10: BE882006
	s_cbranch_execnz 4708                                      // 000000105E14: BFA61264 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8aa8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105E18: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000105E1C: BE882007
	s_cbranch_execnz 4777                                      // 000000105E20: BFA612A9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8bc8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105E24: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000105E28: BE882000
	s_cbranch_execnz 4846                                      // 000000105E2C: BFA612EE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8ce8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105E30: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000105E34: BE882001
	s_cbranch_execnz 4915                                      // 000000105E38: BFA61333 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8e08>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105E3C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000105E40: BE882002
	s_cbranch_execnz 4984                                      // 000000105E44: BFA61378 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x8f28>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105E48: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000105E4C: BE882003
	s_cbranch_execnz 5053                                      // 000000105E50: BFA613BD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9048>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105E54: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000105E58: BE882004
	s_cbranch_execnz 5122                                      // 000000105E5C: BFA61402 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9168>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105E60: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000105E64: BE882005
	s_cbranch_execnz 5191                                      // 000000105E68: BFA61447 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9288>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105E6C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000105E70: BE882006
	s_cbranch_execnz 5260                                      // 000000105E74: BFA6148C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x93a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105E78: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000105E7C: BE882007
	s_cbranch_execnz 5329                                      // 000000105E80: BFA614D1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x94c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105E84: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000105E88: BE882000
	s_cbranch_execnz 5398                                      // 000000105E8C: BFA61516 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x95e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105E90: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000105E94: BE882001
	s_cbranch_execnz 5467                                      // 000000105E98: BFA6155B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9708>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105E9C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000105EA0: BE882002
	s_cbranch_execnz 5536                                      // 000000105EA4: BFA615A0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9828>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105EA8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000105EAC: BE882003
	s_cbranch_execnz 5605                                      // 000000105EB0: BFA615E5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9948>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105EB4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000105EB8: BE882004
	s_cbranch_execnz 5674                                      // 000000105EBC: BFA6162A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9a68>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105EC0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000105EC4: BE882005
	s_cbranch_execnz 5743                                      // 000000105EC8: BFA6166F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9b88>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105ECC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000105ED0: BE882006
	s_cbranch_execnz 5812                                      // 000000105ED4: BFA616B4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9ca8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105ED8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000105EDC: BE882007
	s_cbranch_execnz 5881                                      // 000000105EE0: BFA616F9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9dc8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105EE4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000105EE8: BE882000
	s_cbranch_execnz 5950                                      // 000000105EEC: BFA6173E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x9ee8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105EF0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000105EF4: BE882001
	s_cbranch_execnz 6019                                      // 000000105EF8: BFA61783 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa008>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105EFC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000105F00: BE882002
	s_cbranch_execnz 6088                                      // 000000105F04: BFA617C8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa128>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105F08: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000105F0C: BE882003
	s_cbranch_execnz 6157                                      // 000000105F10: BFA6180D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa248>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105F14: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000105F18: BE882004
	s_cbranch_execnz 6226                                      // 000000105F1C: BFA61852 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa368>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105F20: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000105F24: BE882005
	s_cbranch_execnz 6295                                      // 000000105F28: BFA61897 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa488>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105F2C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000105F30: BE882006
	s_cbranch_execnz 6364                                      // 000000105F34: BFA618DC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa5a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105F38: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000105F3C: BE882007
	s_cbranch_execnz 6433                                      // 000000105F40: BFA61921 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa6c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105F44: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000105F48: BE882000
	s_cbranch_execnz 6502                                      // 000000105F4C: BFA61966 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa7e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105F50: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000105F54: BE882001
	s_cbranch_execnz 6571                                      // 000000105F58: BFA619AB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xa908>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105F5C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000105F60: BE882002
	s_cbranch_execnz 6640                                      // 000000105F64: BFA619F0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaa28>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105F68: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000105F6C: BE882003
	s_cbranch_execnz 6709                                      // 000000105F70: BFA61A35 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xab48>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105F74: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000105F78: BE882004
	s_cbranch_execnz 6778                                      // 000000105F7C: BFA61A7A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xac68>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105F80: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000105F84: BE882005
	s_cbranch_execnz 6847                                      // 000000105F88: BFA61ABF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xad88>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105F8C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000105F90: BE882006
	s_cbranch_execnz 6916                                      // 000000105F94: BFA61B04 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xaea8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105F98: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000105F9C: BE882007
	s_cbranch_execnz 6985                                      // 000000105FA0: BFA61B49 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xafc8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105FA4: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000105FA8: BE882000
	s_cbranch_execnz 7054                                      // 000000105FAC: BFA61B8E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb0e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105FB0: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000105FB4: BE882001
	s_cbranch_execnz 7123                                      // 000000105FB8: BFA61BD3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb208>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105FBC: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000105FC0: BE882002
	s_cbranch_execnz 7192                                      // 000000105FC4: BFA61C18 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb328>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105FC8: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000105FCC: BE882003
	s_cbranch_execnz 7261                                      // 000000105FD0: BFA61C5D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb448>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105FD4: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000105FD8: BE882004
	s_cbranch_execnz 7330                                      // 000000105FDC: BFA61CA2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb568>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105FE0: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000105FE4: BE882005
	s_cbranch_execnz 7399                                      // 000000105FE8: BFA61CE7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb688>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105FEC: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000105FF0: BE882006
	s_cbranch_execnz 7468                                      // 000000105FF4: BFA61D2C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb7a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000105FF8: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000105FFC: BE882007
	s_cbranch_execnz 7537                                      // 000000106000: BFA61D71 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb8c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000106004: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000106008: BE882000
	s_cbranch_execnz 7606                                      // 00000010600C: BFA61DB6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xb9e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000106010: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000106014: BE882001
	s_cbranch_execnz 7675                                      // 000000106018: BFA61DFB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbb08>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010601C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000106020: BE882002
	s_cbranch_execnz 7744                                      // 000000106024: BFA61E40 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbc28>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000106028: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000010602C: BE882003
	s_cbranch_execnz 7813                                      // 000000106030: BFA61E85 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbd48>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000106034: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000106038: BE882004
	s_cbranch_execnz 7882                                      // 00000010603C: BFA61ECA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbe68>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000106040: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000106044: BE882005
	s_cbranch_execnz 7951                                      // 000000106048: BFA61F0F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xbf88>
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010604C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000106050: BE882006
	s_cbranch_execnz 8020                                      // 000000106054: BFA61F54 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc0a8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000106058: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000010605C: BE882007
	s_cbranch_execnz 8089                                      // 000000106060: BFA61F99 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc1c8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000106064: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000106068: BE882000
	s_cbranch_execnz 8158                                      // 00000010606C: BFA61FDE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc2e8>
	s_or_b32 exec_lo, exec_lo, s8                              // 000000106070: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 000000106074: BE802001
	s_cbranch_execnz 8227                                      // 000000106078: BFA62023 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc408>
	s_or_b32 exec_lo, exec_lo, s0                              // 00000010607C: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 000000106080: BE802002
	s_cbranch_execnz 8296                                      // 000000106084: BFA62068 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc528>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000106088: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000010608C: BE802003
	s_cbranch_execnz 8365                                      // 000000106090: BFA620AD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc648>
	s_or_b32 exec_lo, exec_lo, s0                              // 000000106094: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 000000106098: BE802004
	s_cbranch_execnz 8434                                      // 00000010609C: BFA620F2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc768>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001060A0: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 0000001060A4: BE802005
	s_cbranch_execnz 8503                                      // 0000001060A8: BFA62137 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc888>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001060AC: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 0000001060B0: BE802006
	s_cbranch_execnz 8572                                      // 0000001060B4: BFA6217C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xc9a8>
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001060B8: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 0000001060BC: BE802007
	s_cbranch_execnz 8641                                      // 0000001060C0: BFA621C1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0xcac8>
	s_endpgm                                                   // 0000001060C4: BFB00000
	v_mad_i64_i32 v[141:142], null, 0x6000, v126, v[130:131]   // 0000001060C8: D6FF7C8D 060AFCFF 00006000
	v_mul_f32_e32 v127, v133, v127                             // 0000001060D4: 10FEFF85
	global_load_u16 v141, v[141:142], off offset:512           // 0000001060D8: DC4A0200 8D7C008D
	s_waitcnt vmcnt(0)                                         // 0000001060E0: BF8903F7
	v_lshlrev_b32_e32 v141, 16, v141                           // 0000001060E4: 311B1A90
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001060E8: BF870091
	v_mul_f32_e32 v142, 0xbfb8aa3b, v141                       // 0000001060EC: 111D1AFF BFB8AA3B
	v_fma_f32 v143, 0xbfb8aa3b, v141, -v142                    // 0000001060F4: D613008F 863B1AFF BFB8AA3B
	v_rndne_f32_e32 v144, v142                                 // 000000106100: 7F20478E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000106104: BF870221
	v_sub_f32_e32 v142, v142, v144                             // 000000106108: 091D218E
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v141                 // 00000010610C: 7C3D1AFF 42CE8ED0
	v_fmamk_f32 v143, v141, 0xb2a5705f, v143                   // 000000106114: 591F1F8D B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010611C: BF870121
	v_add_f32_e32 v142, v142, v143                             // 000000106120: 071D1F8E
	v_cvt_i32_f32_e32 v143, v144                               // 000000106124: 7F1E1190
	v_exp_f32_e32 v142, v142                                   // 000000106128: 7F1C4B8E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010612C: BF870095
	.long 0xd71c008e                                           // 000000106130: D71C008E
	v_cndmask_b32_e32 v1, v142, v143, vcc_lo                   // 000000106134: 02031F8E
	v_cndmask_b32_e32 v142, 0, v142, vcc_lo                    // 000000106138: 031D1C80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v141                 // 00000010613C: 7C371AFF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106144: BF870092
	v_cndmask_b32_e32 v141, 0x7f800000, v142, vcc_lo           // 000000106148: 031B1CFF 7F800000
	v_add_f32_e32 v141, 1.0, v141                              // 000000106150: 071B1AF2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106154: BF870091
	v_div_scale_f32 v142, null, v141, v141, v127               // 000000106158: D6FC7C8E 05FF1B8D
	v_rcp_f32_e32 v143, v142                                   // 000000106160: 7F1E558E
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106164: BF870095
	v_fma_f32 v144, -v142, v143, 1.0                           // 000000106168: D6130090 23CB1F8E
	v_fmac_f32_e32 v143, v144, v143                            // 000000106170: 571F1F90
	v_div_scale_f32 v144, vcc_lo, v127, v141, v127             // 000000106174: D6FC6A90 05FF1B7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010617C: BF870091
	v_mul_f32_e32 v145, v144, v143                             // 000000106180: 11231F90
	v_fma_f32 v146, -v142, v145, v144                          // 000000106184: D6130092 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010618C: BF870091
	v_fmac_f32_e32 v145, v146, v143                            // 000000106190: 57231F92
	v_fma_f32 v142, -v142, v145, v144                          // 000000106194: D613008E 2643238E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010619C: BF870091
	v_div_fmas_f32 v142, v142, v143, v145                      // 0000001061A0: D637008E 06471F8E
	v_div_fixup_f32 v127, v142, v141, v127                     // 0000001061A8: D627007F 05FF1B8E
	v_mad_i64_i32 v[141:142], null, 0x3000, v126, v[128:129]   // 0000001061B0: D6FF7C8D 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001061BC: BF870092
	v_bfe_u32 v143, v127, 16, 1                                // 0000001061C0: D610008F 0205217F
	v_add3_u32 v127, v127, v143, 0x7fff                        // 0000001061C8: D655007F 03FF1F7F 00007FFF
	global_store_d16_hi_b16 v[141:142], v127, off              // 0000001061D4: DC960000 007C7F8D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001061DC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001061E0: BE882000
	s_cbranch_execz 65106                                      // 0000001061E4: BFA5FE52 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e30>
	v_mad_i64_i32 v[141:142], null, 0x6000, v140, v[130:131]   // 0000001061E8: D6FF7C8D 060B18FF 00006000
	v_mul_f32_e32 v112, v138, v112                             // 0000001061F4: 10E0E18A
	global_load_u16 v127, v[141:142], off offset:544           // 0000001061F8: DC4A0220 7F7C008D
	s_waitcnt vmcnt(0)                                         // 000000106200: BF8903F7
	v_lshlrev_b32_e32 v127, 16, v127                           // 000000106204: 30FEFE90
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000106208: BF870121
	v_mul_f32_e32 v141, 0xbfb8aa3b, v127                       // 00000010620C: 111AFEFF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v127                 // 000000106214: 7C3CFEFF 42CE8ED0
	v_fma_f32 v142, 0xbfb8aa3b, v127, -v141                    // 00000010621C: D613008E 8636FEFF BFB8AA3B
	v_rndne_f32_e32 v143, v141                                 // 000000106228: 7F1E478D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010622C: BF870091
	v_dual_fmamk_f32 v142, v127, 0xb2a5705f, v142 :: v_dual_sub_f32 v141, v141, v143// 000000106230: C88B1D7F 8E8D1F8D B2A5705F
	v_add_f32_e32 v141, v141, v142                             // 00000010623C: 071B1D8D
	v_cvt_i32_f32_e32 v142, v143                               // 000000106240: 7F1C118F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000106244: BF870292
	v_exp_f32_e32 v141, v141                                   // 000000106248: 7F1A4B8D
	.long 0xd71c008d                                           // 00000010624C: D71C008D
	v_cndmask_b32_e32 v1, v141, v142, vcc_lo                   // 000000106250: 02031D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000106254: BF870121
	v_cndmask_b32_e32 v141, 0, v141, vcc_lo                    // 000000106258: 031B1A80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v127                 // 00000010625C: 7C36FEFF C2B17218
	v_cndmask_b32_e32 v127, 0x7f800000, v141, vcc_lo           // 000000106264: 02FF1AFF 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010626C: BF870091
	v_add_f32_e32 v127, 1.0, v127                              // 000000106270: 06FEFEF2
	v_div_scale_f32 v141, null, v127, v127, v112               // 000000106274: D6FC7C8D 05C2FF7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010627C: BF870291
	v_rcp_f32_e32 v142, v141                                   // 000000106280: 7F1C558D
	v_fma_f32 v143, -v141, v142, 1.0                           // 000000106284: D613008F 23CB1D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000010628C: BF8700A1
	v_fmac_f32_e32 v142, v143, v142                            // 000000106290: 571D1D8F
	v_div_scale_f32 v143, vcc_lo, v112, v127, v112             // 000000106294: D6FC6A8F 05C2FF70
	v_mul_f32_e32 v144, v143, v142                             // 00000010629C: 11211D8F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001062A0: BF870091
	v_fma_f32 v145, -v141, v144, v143                          // 0000001062A4: D6130091 263F218D
	v_fmac_f32_e32 v144, v145, v142                            // 0000001062AC: 57211D91
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001062B0: BF870091
	v_fma_f32 v141, -v141, v144, v143                          // 0000001062B4: D613008D 263F218D
	v_div_fmas_f32 v141, v141, v142, v144                      // 0000001062BC: D637008D 06431D8D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001062C4: BF870121
	v_div_fixup_f32 v112, v141, v127, v112                     // 0000001062C8: D6270070 05C2FF8D
	v_mad_i64_i32 v[141:142], null, 0x3000, v140, v[128:129]   // 0000001062D0: D6FF7C8D 060318FF 00003000
	v_bfe_u32 v127, v112, 16, 1                                // 0000001062DC: D610007F 02052170
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001062E4: BF870001
	v_add3_u32 v112, v112, v127, 0x7fff                        // 0000001062E8: D6550070 03FEFF70 00007FFF
	global_store_d16_hi_b16 v[141:142], v112, off offset:32    // 0000001062F4: DC960020 007C708D
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001062FC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000106300: BE882001
	s_cbranch_execz 65037                                      // 000000106304: BFA5FE0D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e3c>
	v_mad_i64_i32 v[141:142], null, 0x6000, v120, v[130:131]   // 000000106308: D6FF7C8D 060AF0FF 00006000
	v_mul_f32_e32 v113, v139, v113                             // 000000106314: 10E2E38B
	global_load_u16 v112, v[141:142], off offset:544           // 000000106318: DC4A0220 707C008D
	s_waitcnt vmcnt(0)                                         // 000000106320: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 000000106324: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106328: BF870091
	v_mul_f32_e32 v127, 0xbfb8aa3b, v112                       // 00000010632C: 10FEE0FF BFB8AA3B
	v_fma_f32 v141, 0xbfb8aa3b, v112, -v127                    // 000000106334: D613008D 85FEE0FF BFB8AA3B
	v_rndne_f32_e32 v142, v127                                 // 000000106340: 7F1C477F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000106344: BF870191
	v_sub_f32_e32 v127, v127, v142                             // 000000106348: 08FF1D7F
	v_fmamk_f32 v141, v112, 0xb2a5705f, v141                   // 00000010634C: 591B1B70 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 000000106354: 7C3CE0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010635C: BF870122
	v_add_f32_e32 v127, v127, v141                             // 000000106360: 06FF1B7F
	v_cvt_i32_f32_e32 v141, v142                               // 000000106364: 7F1A118E
	v_exp_f32_e32 v127, v127                                   // 000000106368: 7EFE4B7F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010636C: BF870095
	.long 0xd71c007f                                           // 000000106370: D71C007F
	v_cndmask_b32_e32 v1, v127, v141, vcc_lo                   // 000000106374: 02031B7F
	v_cndmask_b32_e32 v127, 0, v127, vcc_lo                    // 000000106378: 02FEFE80
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 00000010637C: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106384: BF870092
	v_cndmask_b32_e32 v112, 0x7f800000, v127, vcc_lo           // 000000106388: 02E0FEFF 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 000000106390: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106394: BF870091
	v_div_scale_f32 v127, null, v112, v112, v113               // 000000106398: D6FC7C7F 05C6E170
	v_rcp_f32_e32 v141, v127                                   // 0000001063A0: 7F1A557F
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001063A4: BF870095
	v_fma_f32 v142, -v127, v141, 1.0                           // 0000001063A8: D613008E 23CB1B7F
	v_fmac_f32_e32 v141, v142, v141                            // 0000001063B0: 571B1B8E
	v_div_scale_f32 v142, vcc_lo, v113, v112, v113             // 0000001063B4: D6FC6A8E 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001063BC: BF870091
	v_mul_f32_e32 v143, v142, v141                             // 0000001063C0: 111F1B8E
	v_fma_f32 v144, -v127, v143, v142                          // 0000001063C4: D6130090 263B1F7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001063CC: BF870091
	v_fmac_f32_e32 v143, v144, v141                            // 0000001063D0: 571F1B90
	v_fma_f32 v127, -v127, v143, v142                          // 0000001063D4: D613007F 263B1F7F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001063DC: BF870091
	v_div_fmas_f32 v127, v127, v141, v143                      // 0000001063E0: D637007F 063F1B7F
	v_div_fixup_f32 v127, v127, v112, v113                     // 0000001063E8: D627007F 05C6E17F
	v_mad_i64_i32 v[112:113], null, 0x3000, v120, v[128:129]   // 0000001063F0: D6FF7C70 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001063FC: BF870092
	v_bfe_u32 v141, v127, 16, 1                                // 000000106400: D610008D 0205217F
	v_add3_u32 v127, v127, v141, 0x7fff                        // 000000106408: D655007F 03FF1B7F 00007FFF
	global_store_d16_hi_b16 v[112:113], v127, off offset:32    // 000000106414: DC960020 007C7F70
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010641C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000106420: BE882002
	s_cbranch_execz 64968                                      // 000000106424: BFA5FDC8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e48>
	v_mad_i64_i32 v[112:113], null, 0x6000, v121, v[130:131]   // 000000106428: D6FF7C70 060AF2FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 000000106434: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 00000010643C: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 000000106440: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106444: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 000000106448: 10E2E0FF BFB8AA3B
	v_fma_f32 v127, 0xbfb8aa3b, v112, -v113                    // 000000106450: D613007F 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v141, v113                                 // 00000010645C: 7F1A4771
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000106460: BF870191
	v_sub_f32_e32 v113, v113, v141                             // 000000106464: 08E31B71
	v_fmamk_f32 v127, v112, 0xb2a5705f, v127                   // 000000106468: 58FEFF70 B2A5705F
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 000000106470: 7C3CE0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000106478: BF870122
	v_add_f32_e32 v113, v113, v127                             // 00000010647C: 06E2FF71
	v_cvt_i32_f32_e32 v127, v141                               // 000000106480: 7EFE118D
	v_exp_f32_e32 v113, v113                                   // 000000106484: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106488: BF870095
	.long 0xd71c0071                                           // 00000010648C: D71C0071
	v_cndmask_b32_e32 v1, v113, v127, vcc_lo                   // 000000106490: 0202FF71
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 000000106494: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 000000106498: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001064A0: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v136, v114// 0000001064A4: CA46E2FF 7070E588 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 0000001064B0: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001064B4: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 0000001064B8: D6FC7C72 05C6E170
	v_rcp_f32_e32 v127, v114                                   // 0000001064C0: 7EFE5572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001064C4: BF870095
	v_fma_f32 v141, -v114, v127, 1.0                           // 0000001064C8: D613008D 23CAFF72
	v_fmac_f32_e32 v127, v141, v127                            // 0000001064D0: 56FEFF8D
	v_div_scale_f32 v141, vcc_lo, v113, v112, v113             // 0000001064D4: D6FC6A8D 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001064DC: BF870091
	v_mul_f32_e32 v142, v141, v127                             // 0000001064E0: 111CFF8D
	v_fma_f32 v143, -v114, v142, v141                          // 0000001064E4: D613008F 26371D72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001064EC: BF870091
	v_fmac_f32_e32 v142, v143, v127                            // 0000001064F0: 571CFF8F
	v_fma_f32 v114, -v114, v142, v141                          // 0000001064F4: D6130072 26371D72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001064FC: BF870091
	v_div_fmas_f32 v114, v114, v127, v142                      // 000000106500: D6370072 063AFF72
	v_div_fixup_f32 v114, v114, v112, v113                     // 000000106508: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v121, v[128:129]   // 000000106510: D6FF7C70 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010651C: BF870092
	v_bfe_u32 v127, v114, 16, 1                                // 000000106520: D610007F 02052172
	v_add3_u32 v114, v114, v127, 0x7fff                        // 000000106528: D6550072 03FEFF72 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 000000106534: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010653C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000106540: BE882003
	s_cbranch_execz 64899                                      // 000000106544: BFA5FD83 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e54>
	v_mad_i64_i32 v[112:113], null, 0x6000, v122, v[130:131]   // 000000106548: D6FF7C70 060AF4FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 000000106554: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 00000010655C: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 000000106560: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106564: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 000000106568: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 000000106570: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v127, v113                                 // 00000010657C: 7EFE4771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000106580: BF870221
	v_sub_f32_e32 v113, v113, v127                             // 000000106584: 08E2FF71
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 000000106588: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 000000106590: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000106598: BF870121
	v_add_f32_e32 v113, v113, v114                             // 00000010659C: 06E2E571
	v_cvt_i32_f32_e32 v114, v127                               // 0000001065A0: 7EE4117F
	v_exp_f32_e32 v113, v113                                   // 0000001065A4: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001065A8: BF870095
	.long 0xd71c0071                                           // 0000001065AC: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000001065B0: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000001065B4: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 0000001065B8: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001065C0: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v137, v115// 0000001065C4: CA46E2FF 7070E789 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 0000001065D0: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001065D4: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 0000001065D8: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 0000001065E0: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001065E4: BF870095
	v_fma_f32 v127, -v114, v115, 1.0                           // 0000001065E8: D613007F 23CAE772
	v_fmac_f32_e32 v115, v127, v115                            // 0000001065F0: 56E6E77F
	v_div_scale_f32 v127, vcc_lo, v113, v112, v113             // 0000001065F4: D6FC6A7F 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001065FC: BF870091
	v_mul_f32_e32 v141, v127, v115                             // 000000106600: 111AE77F
	v_fma_f32 v142, -v114, v141, v127                          // 000000106604: D613008E 25FF1B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010660C: BF870091
	v_fmac_f32_e32 v141, v142, v115                            // 000000106610: 571AE78E
	v_fma_f32 v114, -v114, v141, v127                          // 000000106614: D6130072 25FF1B72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010661C: BF870091
	v_div_fmas_f32 v114, v114, v115, v141                      // 000000106620: D6370072 0636E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 000000106628: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v122, v[128:129]   // 000000106630: D6FF7C70 0602F4FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010663C: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 000000106640: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 000000106648: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 000000106654: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010665C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000106660: BE882004
	s_cbranch_execz 64830                                      // 000000106664: BFA5FD3E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e60>
	v_mad_i64_i32 v[112:113], null, 0x6000, v123, v[130:131]   // 000000106668: D6FF7C70 060AF6FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 000000106674: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 00000010667C: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 000000106680: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106684: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 000000106688: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 000000106690: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 00000010669C: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001066A0: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 0000001066A4: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 0000001066A8: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 0000001066B0: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001066B8: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000001066BC: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000001066C0: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000001066C4: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001066C8: BF870095
	.long 0xd71c0071                                           // 0000001066CC: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000001066D0: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000001066D4: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 0000001066D8: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001066E0: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v134, v116// 0000001066E4: CA46E2FF 7070E986 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 0000001066F0: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001066F4: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 0000001066F8: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 000000106700: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106704: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 000000106708: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 000000106710: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 000000106714: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010671C: BF870091
	v_mul_f32_e32 v127, v116, v115                             // 000000106720: 10FEE774
	v_fma_f32 v141, -v114, v127, v116                          // 000000106724: D613008D 25D2FF72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010672C: BF870091
	v_fmac_f32_e32 v127, v141, v115                            // 000000106730: 56FEE78D
	v_fma_f32 v114, -v114, v127, v116                          // 000000106734: D6130072 25D2FF72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010673C: BF870091
	v_div_fmas_f32 v114, v114, v115, v127                      // 000000106740: D6370072 05FEE772
	v_div_fixup_f32 v114, v114, v112, v113                     // 000000106748: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v123, v[128:129]   // 000000106750: D6FF7C70 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010675C: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 000000106760: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 000000106768: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 000000106774: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010677C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000106780: BE882005
	s_cbranch_execz 64761                                      // 000000106784: BFA5FCF9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e6c>
	v_mad_i64_i32 v[112:113], null, 0x6000, v124, v[130:131]   // 000000106788: D6FF7C70 060AF8FF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 000000106794: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 00000010679C: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 0000001067A0: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001067A4: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 0000001067A8: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 0000001067B0: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000001067BC: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001067C0: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 0000001067C4: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 0000001067C8: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 0000001067D0: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001067D8: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000001067DC: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 0000001067E0: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 0000001067E4: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001067E8: BF870095
	.long 0xd71c0071                                           // 0000001067EC: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 0000001067F0: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 0000001067F4: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 0000001067F8: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106800: BF870092
	v_cndmask_b32_e32 v112, 0x7f800000, v113, vcc_lo           // 000000106804: 02E0E2FF 7F800000
	v_dual_mul_f32 v113, v135, v117 :: v_dual_add_f32 v112, 1.0, v112// 00000010680C: C8C8EB87 7170E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106814: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 000000106818: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 000000106820: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106824: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 000000106828: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 000000106830: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 000000106834: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010683C: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 000000106840: 10EAE774
	v_fma_f32 v127, -v114, v117, v116                          // 000000106844: D613007F 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010684C: BF870091
	v_fmac_f32_e32 v117, v127, v115                            // 000000106850: 56EAE77F
	v_fma_f32 v114, -v114, v117, v116                          // 000000106854: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010685C: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 000000106860: D6370072 05D6E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 000000106868: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v124, v[128:129]   // 000000106870: D6FF7C70 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010687C: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 000000106880: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 000000106888: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 000000106894: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010689C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001068A0: BE882006
	s_cbranch_execz 64692                                      // 0000001068A4: BFA5FCB4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e78>
	v_mad_i64_i32 v[112:113], null, 0x6000, v125, v[130:131]   // 0000001068A8: D6FF7C70 060AFAFF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 0000001068B4: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 0000001068BC: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 0000001068C0: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001068C4: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 0000001068C8: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 0000001068D0: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000001068DC: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001068E0: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 0000001068E4: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 0000001068E8: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 0000001068F0: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001068F8: BF870121
	v_add_f32_e32 v113, v113, v114                             // 0000001068FC: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 000000106900: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 000000106904: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106908: BF870095
	.long 0xd71c0071                                           // 00000010690C: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 000000106910: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 000000106914: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 000000106918: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106920: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v132, v118// 000000106924: CA46E2FF 7070ED84 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 000000106930: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106934: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 000000106938: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 000000106940: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106944: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 000000106948: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 000000106950: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 000000106954: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010695C: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 000000106960: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 000000106964: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010696C: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 000000106970: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 000000106974: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010697C: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 000000106980: D6370072 05D6E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 000000106988: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v125, v[128:129]   // 000000106990: D6FF7C70 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010699C: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 0000001069A0: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 0000001069A8: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 0000001069B4: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001069BC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001069C0: BE882007
	s_cbranch_execz 64623                                      // 0000001069C4: BFA5FC6F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e84>
	v_mad_i64_i32 v[112:113], null, 0x6000, v126, v[130:131]   // 0000001069C8: D6FF7C70 060AFCFF 00006000
	global_load_u16 v112, v[112:113], off offset:544           // 0000001069D4: DC4A0220 707C0070
	s_waitcnt vmcnt(0)                                         // 0000001069DC: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 0000001069E0: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001069E4: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 0000001069E8: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 0000001069F0: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 0000001069FC: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000106A00: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 000000106A04: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 000000106A08: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 000000106A10: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000106A18: BF870121
	v_add_f32_e32 v113, v113, v114                             // 000000106A1C: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 000000106A20: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 000000106A24: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106A28: BF870095
	.long 0xd71c0071                                           // 000000106A2C: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 000000106A30: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 000000106A34: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 000000106A38: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106A40: BF870092
	v_dual_cndmask_b32 v112, 0x7f800000, v113 :: v_dual_mul_f32 v113, v133, v119// 000000106A44: CA46E2FF 7070EF85 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 000000106A50: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106A54: BF870091
	v_div_scale_f32 v114, null, v112, v112, v113               // 000000106A58: D6FC7C72 05C6E170
	v_rcp_f32_e32 v115, v114                                   // 000000106A60: 7EE65572
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106A64: BF870095
	v_fma_f32 v116, -v114, v115, 1.0                           // 000000106A68: D6130074 23CAE772
	v_fmac_f32_e32 v115, v116, v115                            // 000000106A70: 56E6E774
	v_div_scale_f32 v116, vcc_lo, v113, v112, v113             // 000000106A74: D6FC6A74 05C6E171
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106A7C: BF870091
	v_mul_f32_e32 v117, v116, v115                             // 000000106A80: 10EAE774
	v_fma_f32 v118, -v114, v117, v116                          // 000000106A84: D6130076 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106A8C: BF870091
	v_fmac_f32_e32 v117, v118, v115                            // 000000106A90: 56EAE776
	v_fma_f32 v114, -v114, v117, v116                          // 000000106A94: D6130072 25D2EB72
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106A9C: BF870091
	v_div_fmas_f32 v114, v114, v115, v117                      // 000000106AA0: D6370072 05D6E772
	v_div_fixup_f32 v114, v114, v112, v113                     // 000000106AA8: D6270072 05C6E172
	v_mad_i64_i32 v[112:113], null, 0x3000, v126, v[128:129]   // 000000106AB0: D6FF7C70 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106ABC: BF870092
	v_bfe_u32 v115, v114, 16, 1                                // 000000106AC0: D6100073 02052172
	v_add3_u32 v114, v114, v115, 0x7fff                        // 000000106AC8: D6550072 03FEE772 00007FFF
	global_store_d16_hi_b16 v[112:113], v114, off offset:32    // 000000106AD4: DC960020 007C7270
	s_or_b32 exec_lo, exec_lo, s8                              // 000000106ADC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000106AE0: BE882000
	s_cbranch_execz 64554                                      // 000000106AE4: BFA5FC2A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e90>
	v_mad_i64_i32 v[112:113], null, 0x6000, v140, v[130:131]   // 000000106AE8: D6FF7C70 060B18FF 00006000
	v_mul_f32_e32 v104, v138, v104                             // 000000106AF4: 10D0D18A
	global_load_u16 v112, v[112:113], off offset:576           // 000000106AF8: DC4A0240 707C0070
	s_waitcnt vmcnt(0)                                         // 000000106B00: BF8903F7
	v_lshlrev_b32_e32 v112, 16, v112                           // 000000106B04: 30E0E090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106B08: BF870091
	v_mul_f32_e32 v113, 0xbfb8aa3b, v112                       // 000000106B0C: 10E2E0FF BFB8AA3B
	v_fma_f32 v114, 0xbfb8aa3b, v112, -v113                    // 000000106B14: D6130072 85C6E0FF BFB8AA3B
	v_rndne_f32_e32 v115, v113                                 // 000000106B20: 7EE64771
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000106B24: BF870221
	v_sub_f32_e32 v113, v113, v115                             // 000000106B28: 08E2E771
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v112                 // 000000106B2C: 7C3CE0FF 42CE8ED0
	v_fmamk_f32 v114, v112, 0xb2a5705f, v114                   // 000000106B34: 58E4E570 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000106B3C: BF870121
	v_add_f32_e32 v113, v113, v114                             // 000000106B40: 06E2E571
	v_cvt_i32_f32_e32 v114, v115                               // 000000106B44: 7EE41173
	v_exp_f32_e32 v113, v113                                   // 000000106B48: 7EE24B71
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106B4C: BF870095
	.long 0xd71c0071                                           // 000000106B50: D71C0071
	v_cndmask_b32_e32 v1, v113, v114, vcc_lo                   // 000000106B54: 0202E571
	v_cndmask_b32_e32 v113, 0, v113, vcc_lo                    // 000000106B58: 02E2E280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v112                 // 000000106B5C: 7C36E0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106B64: BF870092
	v_cndmask_b32_e32 v112, 0x7f800000, v113, vcc_lo           // 000000106B68: 02E0E2FF 7F800000
	v_add_f32_e32 v112, 1.0, v112                              // 000000106B70: 06E0E0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106B74: BF870091
	v_div_scale_f32 v113, null, v112, v112, v104               // 000000106B78: D6FC7C71 05A2E170
	v_rcp_f32_e32 v114, v113                                   // 000000106B80: 7EE45571
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106B84: BF870095
	v_fma_f32 v115, -v113, v114, 1.0                           // 000000106B88: D6130073 23CAE571
	v_fmac_f32_e32 v114, v115, v114                            // 000000106B90: 56E4E573
	v_div_scale_f32 v115, vcc_lo, v104, v112, v104             // 000000106B94: D6FC6A73 05A2E168
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106B9C: BF870091
	v_mul_f32_e32 v116, v115, v114                             // 000000106BA0: 10E8E573
	v_fma_f32 v117, -v113, v116, v115                          // 000000106BA4: D6130075 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106BAC: BF870091
	v_fmac_f32_e32 v116, v117, v114                            // 000000106BB0: 56E8E575
	v_fma_f32 v113, -v113, v116, v115                          // 000000106BB4: D6130071 25CEE971
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106BBC: BF870091
	v_div_fmas_f32 v113, v113, v114, v116                      // 000000106BC0: D6370071 05D2E571
	v_div_fixup_f32 v104, v113, v112, v104                     // 000000106BC8: D6270068 05A2E171
	v_mad_i64_i32 v[112:113], null, 0x3000, v140, v[128:129]   // 000000106BD0: D6FF7C70 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106BDC: BF870092
	v_bfe_u32 v114, v104, 16, 1                                // 000000106BE0: D6100072 02052168
	v_add3_u32 v104, v104, v114, 0x7fff                        // 000000106BE8: D6550068 03FEE568 00007FFF
	global_store_d16_hi_b16 v[112:113], v104, off offset:64    // 000000106BF4: DC960040 007C6870
	s_or_b32 exec_lo, exec_lo, s8                              // 000000106BFC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000106C00: BE882001
	s_cbranch_execz 64485                                      // 000000106C04: BFA5FBE5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3e9c>
	v_mad_i64_i32 v[112:113], null, 0x6000, v120, v[130:131]   // 000000106C08: D6FF7C70 060AF0FF 00006000
	v_mul_f32_e32 v105, v139, v105                             // 000000106C14: 10D2D38B
	global_load_u16 v104, v[112:113], off offset:576           // 000000106C18: DC4A0240 687C0070
	s_waitcnt vmcnt(0)                                         // 000000106C20: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 000000106C24: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000106C28: BF870121
	v_mul_f32_e32 v112, 0xbfb8aa3b, v104                       // 000000106C2C: 10E0D0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 000000106C34: 7C3CD0FF 42CE8ED0
	v_fma_f32 v113, 0xbfb8aa3b, v104, -v112                    // 000000106C3C: D6130071 85C2D0FF BFB8AA3B
	v_rndne_f32_e32 v114, v112                                 // 000000106C48: 7EE44770
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000106C4C: BF870112
	v_fmamk_f32 v113, v104, 0xb2a5705f, v113                   // 000000106C50: 58E2E368 B2A5705F
	v_sub_f32_e32 v112, v112, v114                             // 000000106C58: 08E0E570
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000106C5C: BF870121
	v_add_f32_e32 v112, v112, v113                             // 000000106C60: 06E0E370
	v_cvt_i32_f32_e32 v113, v114                               // 000000106C64: 7EE21172
	v_exp_f32_e32 v112, v112                                   // 000000106C68: 7EE04B70
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106C6C: BF870095
	.long 0xd71c0070                                           // 000000106C70: D71C0070
	v_cndmask_b32_e32 v1, v112, v113, vcc_lo                   // 000000106C74: 0202E370
	v_cndmask_b32_e32 v112, 0, v112, vcc_lo                    // 000000106C78: 02E0E080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 000000106C7C: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106C84: BF870092
	v_cndmask_b32_e32 v104, 0x7f800000, v112, vcc_lo           // 000000106C88: 02D0E0FF 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 000000106C90: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106C94: BF870091
	v_div_scale_f32 v112, null, v104, v104, v105               // 000000106C98: D6FC7C70 05A6D168
	v_rcp_f32_e32 v113, v112                                   // 000000106CA0: 7EE25570
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106CA4: BF870095
	v_fma_f32 v114, -v112, v113, 1.0                           // 000000106CA8: D6130072 23CAE370
	v_fmac_f32_e32 v113, v114, v113                            // 000000106CB0: 56E2E372
	v_div_scale_f32 v114, vcc_lo, v105, v104, v105             // 000000106CB4: D6FC6A72 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106CBC: BF870091
	v_mul_f32_e32 v115, v114, v113                             // 000000106CC0: 10E6E372
	v_fma_f32 v116, -v112, v115, v114                          // 000000106CC4: D6130074 25CAE770
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106CCC: BF870091
	v_fmac_f32_e32 v115, v116, v113                            // 000000106CD0: 56E6E374
	v_fma_f32 v112, -v112, v115, v114                          // 000000106CD4: D6130070 25CAE770
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106CDC: BF870091
	v_div_fmas_f32 v112, v112, v113, v115                      // 000000106CE0: D6370070 05CEE370
	v_div_fixup_f32 v112, v112, v104, v105                     // 000000106CE8: D6270070 05A6D170
	v_mad_i64_i32 v[104:105], null, 0x3000, v120, v[128:129]   // 000000106CF0: D6FF7C68 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106CFC: BF870092
	v_bfe_u32 v113, v112, 16, 1                                // 000000106D00: D6100071 02052170
	v_add3_u32 v112, v112, v113, 0x7fff                        // 000000106D08: D6550070 03FEE370 00007FFF
	global_store_d16_hi_b16 v[104:105], v112, off offset:64    // 000000106D14: DC960040 007C7068
	s_or_b32 exec_lo, exec_lo, s8                              // 000000106D1C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000106D20: BE882002
	s_cbranch_execz 64416                                      // 000000106D24: BFA5FBA0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ea8>
	v_mad_i64_i32 v[104:105], null, 0x6000, v121, v[130:131]   // 000000106D28: D6FF7C68 060AF2FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 000000106D34: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 000000106D3C: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 000000106D40: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106D44: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 000000106D48: 10D2D0FF BFB8AA3B
	v_fma_f32 v112, 0xbfb8aa3b, v104, -v105                    // 000000106D50: D6130070 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v113, v105                                 // 000000106D5C: 7EE24769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000106D60: BF870221
	v_sub_f32_e32 v105, v105, v113                             // 000000106D64: 08D2E369
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 000000106D68: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v112, v104, 0xb2a5705f, v112                   // 000000106D70: 58E0E168 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000106D78: BF870121
	v_add_f32_e32 v105, v105, v112                             // 000000106D7C: 06D2E169
	v_cvt_i32_f32_e32 v112, v113                               // 000000106D80: 7EE01171
	v_exp_f32_e32 v105, v105                                   // 000000106D84: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106D88: BF870095
	.long 0xd71c0069                                           // 000000106D8C: D71C0069
	v_cndmask_b32_e32 v1, v105, v112, vcc_lo                   // 000000106D90: 0202E169
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000106D94: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 000000106D98: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106DA0: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v136, v106// 000000106DA4: CA46D2FF 6868D588 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 000000106DB0: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106DB4: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 000000106DB8: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v112, v106                                   // 000000106DC0: 7EE0556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106DC4: BF870095
	v_fma_f32 v113, -v106, v112, 1.0                           // 000000106DC8: D6130071 23CAE16A
	v_fmac_f32_e32 v112, v113, v112                            // 000000106DD0: 56E0E171
	v_div_scale_f32 v113, vcc_lo, v105, v104, v105             // 000000106DD4: D6FC6A71 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106DDC: BF870091
	v_mul_f32_e32 v114, v113, v112                             // 000000106DE0: 10E4E171
	v_fma_f32 v115, -v106, v114, v113                          // 000000106DE4: D6130073 25C6E56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106DEC: BF870091
	v_fmac_f32_e32 v114, v115, v112                            // 000000106DF0: 56E4E173
	v_fma_f32 v106, -v106, v114, v113                          // 000000106DF4: D613006A 25C6E56A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106DFC: BF870091
	v_div_fmas_f32 v106, v106, v112, v114                      // 000000106E00: D637006A 05CAE16A
	v_div_fixup_f32 v106, v106, v104, v105                     // 000000106E08: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v121, v[128:129]   // 000000106E10: D6FF7C68 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106E1C: BF870092
	v_bfe_u32 v112, v106, 16, 1                                // 000000106E20: D6100070 0205216A
	v_add3_u32 v106, v106, v112, 0x7fff                        // 000000106E28: D655006A 03FEE16A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 000000106E34: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 000000106E3C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000106E40: BE882003
	s_cbranch_execz 64347                                      // 000000106E44: BFA5FB5B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3eb4>
	v_mad_i64_i32 v[104:105], null, 0x6000, v122, v[130:131]   // 000000106E48: D6FF7C68 060AF4FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 000000106E54: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 000000106E5C: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 000000106E60: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106E64: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 000000106E68: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 000000106E70: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v112, v105                                 // 000000106E7C: 7EE04769
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106E80: BF870091
	v_dual_fmamk_f32 v106, v104, 0xb2a5705f, v106 :: v_dual_sub_f32 v105, v105, v112// 000000106E84: C88AD568 6A68E169 B2A5705F
	v_add_f32_e32 v105, v105, v106                             // 000000106E90: 06D2D569
	v_cvt_i32_f32_e32 v106, v112                               // 000000106E94: 7ED41170
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 000000106E98: 7C3CD0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000106EA0: BF870293
	v_exp_f32_e32 v105, v105                                   // 000000106EA4: 7ED24B69
	.long 0xd71c0069                                           // 000000106EA8: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 000000106EAC: 0202D569
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000106EB0: BF870121
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000106EB4: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 000000106EB8: 7C36D0FF C2B17218
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v137, v107// 000000106EC0: CA46D2FF 6868D789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106ECC: BF870091
	v_add_f32_e32 v104, 1.0, v104                              // 000000106ED0: 06D0D0F2
	v_div_scale_f32 v106, null, v104, v104, v105               // 000000106ED4: D6FC7C6A 05A6D168
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000106EDC: BF870291
	v_rcp_f32_e32 v107, v106                                   // 000000106EE0: 7ED6556A
	v_fma_f32 v112, -v106, v107, 1.0                           // 000000106EE4: D6130070 23CAD76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000106EEC: BF8700A1
	v_fmac_f32_e32 v107, v112, v107                            // 000000106EF0: 56D6D770
	v_div_scale_f32 v112, vcc_lo, v105, v104, v105             // 000000106EF4: D6FC6A70 05A6D169
	v_mul_f32_e32 v113, v112, v107                             // 000000106EFC: 10E2D770
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106F00: BF870091
	v_fma_f32 v114, -v106, v113, v112                          // 000000106F04: D6130072 25C2E36A
	v_fmac_f32_e32 v113, v114, v107                            // 000000106F0C: 56E2D772
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106F10: BF870091
	v_fma_f32 v106, -v106, v113, v112                          // 000000106F14: D613006A 25C2E36A
	v_div_fmas_f32 v106, v106, v107, v113                      // 000000106F1C: D637006A 05C6D76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000106F24: BF870121
	v_div_fixup_f32 v106, v106, v104, v105                     // 000000106F28: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v122, v[128:129]   // 000000106F30: D6FF7C68 0602F4FF 00003000
	v_bfe_u32 v107, v106, 16, 1                                // 000000106F3C: D610006B 0205216A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000106F44: BF870001
	v_add3_u32 v106, v106, v107, 0x7fff                        // 000000106F48: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 000000106F54: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 000000106F5C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000106F60: BE882004
	s_cbranch_execz 64278                                      // 000000106F64: BFA5FB16 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ec0>
	v_mad_i64_i32 v[104:105], null, 0x6000, v123, v[130:131]   // 000000106F68: D6FF7C68 060AF6FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 000000106F74: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 000000106F7C: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 000000106F80: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106F84: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 000000106F88: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 000000106F90: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 000000106F9C: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000106FA0: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 000000106FA4: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 000000106FA8: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 000000106FB0: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000106FB8: BF870121
	v_add_f32_e32 v105, v105, v106                             // 000000106FBC: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 000000106FC0: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 000000106FC4: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106FC8: BF870095
	.long 0xd71c0069                                           // 000000106FCC: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 000000106FD0: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000106FD4: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 000000106FD8: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106FE0: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v134, v108// 000000106FE4: CA46D2FF 6868D986 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 000000106FF0: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000106FF4: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 000000106FF8: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 000000107000: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107004: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 000000107008: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 000000107010: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 000000107014: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010701C: BF870091
	v_mul_f32_e32 v112, v108, v107                             // 000000107020: 10E0D76C
	v_fma_f32 v113, -v106, v112, v108                          // 000000107024: D6130071 25B2E16A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010702C: BF870091
	v_fmac_f32_e32 v112, v113, v107                            // 000000107030: 56E0D771
	v_fma_f32 v106, -v106, v112, v108                          // 000000107034: D613006A 25B2E16A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010703C: BF870091
	v_div_fmas_f32 v106, v106, v107, v112                      // 000000107040: D637006A 05C2D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 000000107048: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v123, v[128:129]   // 000000107050: D6FF7C68 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010705C: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 000000107060: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 000000107068: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 000000107074: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010707C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000107080: BE882005
	s_cbranch_execz 64209                                      // 000000107084: BFA5FAD1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ecc>
	v_mad_i64_i32 v[104:105], null, 0x6000, v124, v[130:131]   // 000000107088: D6FF7C68 060AF8FF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 000000107094: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 00000010709C: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 0000001070A0: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001070A4: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 0000001070A8: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 0000001070B0: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000001070BC: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001070C0: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 0000001070C4: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 0000001070C8: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 0000001070D0: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001070D8: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000001070DC: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 0000001070E0: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 0000001070E4: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001070E8: BF870095
	.long 0xd71c0069                                           // 0000001070EC: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 0000001070F0: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 0000001070F4: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 0000001070F8: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107100: BF870092
	v_cndmask_b32_e32 v104, 0x7f800000, v105, vcc_lo           // 000000107104: 02D0D2FF 7F800000
	v_dual_mul_f32 v105, v135, v109 :: v_dual_add_f32 v104, 1.0, v104// 00000010710C: C8C8DB87 6968D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107114: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 000000107118: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 000000107120: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107124: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 000000107128: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 000000107130: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 000000107134: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010713C: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 000000107140: 10DAD76C
	v_fma_f32 v112, -v106, v109, v108                          // 000000107144: D6130070 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010714C: BF870091
	v_fmac_f32_e32 v109, v112, v107                            // 000000107150: 56DAD770
	v_fma_f32 v106, -v106, v109, v108                          // 000000107154: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010715C: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 000000107160: D637006A 05B6D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 000000107168: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v124, v[128:129]   // 000000107170: D6FF7C68 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010717C: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 000000107180: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 000000107188: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 000000107194: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010719C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001071A0: BE882006
	s_cbranch_execz 64140                                      // 0000001071A4: BFA5FA8C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ed8>
	v_mad_i64_i32 v[104:105], null, 0x6000, v125, v[130:131]   // 0000001071A8: D6FF7C68 060AFAFF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 0000001071B4: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 0000001071BC: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 0000001071C0: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001071C4: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 0000001071C8: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 0000001071D0: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000001071DC: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001071E0: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 0000001071E4: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 0000001071E8: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 0000001071F0: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001071F8: BF870121
	v_add_f32_e32 v105, v105, v106                             // 0000001071FC: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 000000107200: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 000000107204: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107208: BF870095
	.long 0xd71c0069                                           // 00000010720C: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 000000107210: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000107214: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 000000107218: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107220: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v132, v110// 000000107224: CA46D2FF 6868DD84 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 000000107230: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107234: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 000000107238: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 000000107240: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107244: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 000000107248: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 000000107250: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 000000107254: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010725C: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 000000107260: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 000000107264: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010726C: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 000000107270: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 000000107274: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010727C: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 000000107280: D637006A 05B6D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 000000107288: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v125, v[128:129]   // 000000107290: D6FF7C68 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010729C: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 0000001072A0: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 0000001072A8: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 0000001072B4: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001072BC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001072C0: BE882007
	s_cbranch_execz 64071                                      // 0000001072C4: BFA5FA47 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ee4>
	v_mad_i64_i32 v[104:105], null, 0x6000, v126, v[130:131]   // 0000001072C8: D6FF7C68 060AFCFF 00006000
	global_load_u16 v104, v[104:105], off offset:576           // 0000001072D4: DC4A0240 687C0068
	s_waitcnt vmcnt(0)                                         // 0000001072DC: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 0000001072E0: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001072E4: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 0000001072E8: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 0000001072F0: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 0000001072FC: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000107300: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 000000107304: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 000000107308: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 000000107310: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000107318: BF870121
	v_add_f32_e32 v105, v105, v106                             // 00000010731C: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 000000107320: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 000000107324: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107328: BF870095
	.long 0xd71c0069                                           // 00000010732C: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 000000107330: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000107334: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 000000107338: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107340: BF870092
	v_dual_cndmask_b32 v104, 0x7f800000, v105 :: v_dual_mul_f32 v105, v133, v111// 000000107344: CA46D2FF 6868DF85 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 000000107350: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107354: BF870091
	v_div_scale_f32 v106, null, v104, v104, v105               // 000000107358: D6FC7C6A 05A6D168
	v_rcp_f32_e32 v107, v106                                   // 000000107360: 7ED6556A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107364: BF870095
	v_fma_f32 v108, -v106, v107, 1.0                           // 000000107368: D613006C 23CAD76A
	v_fmac_f32_e32 v107, v108, v107                            // 000000107370: 56D6D76C
	v_div_scale_f32 v108, vcc_lo, v105, v104, v105             // 000000107374: D6FC6A6C 05A6D169
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010737C: BF870091
	v_mul_f32_e32 v109, v108, v107                             // 000000107380: 10DAD76C
	v_fma_f32 v110, -v106, v109, v108                          // 000000107384: D613006E 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010738C: BF870091
	v_fmac_f32_e32 v109, v110, v107                            // 000000107390: 56DAD76E
	v_fma_f32 v106, -v106, v109, v108                          // 000000107394: D613006A 25B2DB6A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010739C: BF870091
	v_div_fmas_f32 v106, v106, v107, v109                      // 0000001073A0: D637006A 05B6D76A
	v_div_fixup_f32 v106, v106, v104, v105                     // 0000001073A8: D627006A 05A6D16A
	v_mad_i64_i32 v[104:105], null, 0x3000, v126, v[128:129]   // 0000001073B0: D6FF7C68 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001073BC: BF870092
	v_bfe_u32 v107, v106, 16, 1                                // 0000001073C0: D610006B 0205216A
	v_add3_u32 v106, v106, v107, 0x7fff                        // 0000001073C8: D655006A 03FED76A 00007FFF
	global_store_d16_hi_b16 v[104:105], v106, off offset:64    // 0000001073D4: DC960040 007C6A68
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001073DC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001073E0: BE882000
	s_cbranch_execz 64002                                      // 0000001073E4: BFA5FA02 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ef0>
	v_mad_i64_i32 v[104:105], null, 0x6000, v140, v[130:131]   // 0000001073E8: D6FF7C68 060B18FF 00006000
	v_mul_f32_e32 v96, v138, v96                               // 0000001073F4: 10C0C18A
	global_load_u16 v104, v[104:105], off offset:608           // 0000001073F8: DC4A0260 687C0068
	s_waitcnt vmcnt(0)                                         // 000000107400: BF8903F7
	v_lshlrev_b32_e32 v104, 16, v104                           // 000000107404: 30D0D090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107408: BF870091
	v_mul_f32_e32 v105, 0xbfb8aa3b, v104                       // 00000010740C: 10D2D0FF BFB8AA3B
	v_fma_f32 v106, 0xbfb8aa3b, v104, -v105                    // 000000107414: D613006A 85A6D0FF BFB8AA3B
	v_rndne_f32_e32 v107, v105                                 // 000000107420: 7ED64769
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000107424: BF870221
	v_sub_f32_e32 v105, v105, v107                             // 000000107428: 08D2D769
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v104                 // 00000010742C: 7C3CD0FF 42CE8ED0
	v_fmamk_f32 v106, v104, 0xb2a5705f, v106                   // 000000107434: 58D4D568 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010743C: BF870121
	v_add_f32_e32 v105, v105, v106                             // 000000107440: 06D2D569
	v_cvt_i32_f32_e32 v106, v107                               // 000000107444: 7ED4116B
	v_exp_f32_e32 v105, v105                                   // 000000107448: 7ED24B69
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010744C: BF870095
	.long 0xd71c0069                                           // 000000107450: D71C0069
	v_cndmask_b32_e32 v1, v105, v106, vcc_lo                   // 000000107454: 0202D569
	v_cndmask_b32_e32 v105, 0, v105, vcc_lo                    // 000000107458: 02D2D280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v104                 // 00000010745C: 7C36D0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107464: BF870092
	v_cndmask_b32_e32 v104, 0x7f800000, v105, vcc_lo           // 000000107468: 02D0D2FF 7F800000
	v_add_f32_e32 v104, 1.0, v104                              // 000000107470: 06D0D0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107474: BF870091
	v_div_scale_f32 v105, null, v104, v104, v96                // 000000107478: D6FC7C69 0582D168
	v_rcp_f32_e32 v106, v105                                   // 000000107480: 7ED45569
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107484: BF870095
	v_fma_f32 v107, -v105, v106, 1.0                           // 000000107488: D613006B 23CAD569
	v_fmac_f32_e32 v106, v107, v106                            // 000000107490: 56D4D56B
	v_div_scale_f32 v107, vcc_lo, v96, v104, v96               // 000000107494: D6FC6A6B 0582D160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010749C: BF870091
	v_mul_f32_e32 v108, v107, v106                             // 0000001074A0: 10D8D56B
	v_fma_f32 v109, -v105, v108, v107                          // 0000001074A4: D613006D 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001074AC: BF870091
	v_fmac_f32_e32 v108, v109, v106                            // 0000001074B0: 56D8D56D
	v_fma_f32 v105, -v105, v108, v107                          // 0000001074B4: D6130069 25AED969
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001074BC: BF870091
	v_div_fmas_f32 v105, v105, v106, v108                      // 0000001074C0: D6370069 05B2D569
	v_div_fixup_f32 v96, v105, v104, v96                       // 0000001074C8: D6270060 0582D169
	v_mad_i64_i32 v[104:105], null, 0x3000, v140, v[128:129]   // 0000001074D0: D6FF7C68 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001074DC: BF870092
	v_bfe_u32 v106, v96, 16, 1                                 // 0000001074E0: D610006A 02052160
	v_add3_u32 v96, v96, v106, 0x7fff                          // 0000001074E8: D6550060 03FED560 00007FFF
	global_store_d16_hi_b16 v[104:105], v96, off offset:96     // 0000001074F4: DC960060 007C6068
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001074FC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000107500: BE882001
	s_cbranch_execz 63933                                      // 000000107504: BFA5F9BD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3efc>
	v_mad_i64_i32 v[104:105], null, 0x6000, v120, v[130:131]   // 000000107508: D6FF7C68 060AF0FF 00006000
	v_mul_f32_e32 v97, v139, v97                               // 000000107514: 10C2C38B
	global_load_u16 v96, v[104:105], off offset:608            // 000000107518: DC4A0260 607C0068
	s_waitcnt vmcnt(0)                                         // 000000107520: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000107524: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000107528: BF870121
	v_mul_f32_e32 v104, 0xbfb8aa3b, v96                        // 00000010752C: 10D0C0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 000000107534: 7C3CC0FF 42CE8ED0
	v_fma_f32 v105, 0xbfb8aa3b, v96, -v104                     // 00000010753C: D6130069 85A2C0FF BFB8AA3B
	v_rndne_f32_e32 v106, v104                                 // 000000107548: 7ED44768
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010754C: BF870112
	v_fmamk_f32 v105, v96, 0xb2a5705f, v105                    // 000000107550: 58D2D360 B2A5705F
	v_sub_f32_e32 v104, v104, v106                             // 000000107558: 08D0D568
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010755C: BF870121
	v_add_f32_e32 v104, v104, v105                             // 000000107560: 06D0D368
	v_cvt_i32_f32_e32 v105, v106                               // 000000107564: 7ED2116A
	v_exp_f32_e32 v104, v104                                   // 000000107568: 7ED04B68
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010756C: BF870095
	.long 0xd71c0068                                           // 000000107570: D71C0068
	v_cndmask_b32_e32 v1, v104, v105, vcc_lo                   // 000000107574: 0202D368
	v_cndmask_b32_e32 v104, 0, v104, vcc_lo                    // 000000107578: 02D0D080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 00000010757C: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107584: BF870092
	v_cndmask_b32_e32 v96, 0x7f800000, v104, vcc_lo            // 000000107588: 02C0D0FF 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 000000107590: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107594: BF870091
	v_div_scale_f32 v104, null, v96, v96, v97                  // 000000107598: D6FC7C68 0586C160
	v_rcp_f32_e32 v105, v104                                   // 0000001075A0: 7ED25568
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001075A4: BF870095
	v_fma_f32 v106, -v104, v105, 1.0                           // 0000001075A8: D613006A 23CAD368
	v_fmac_f32_e32 v105, v106, v105                            // 0000001075B0: 56D2D36A
	v_div_scale_f32 v106, vcc_lo, v97, v96, v97                // 0000001075B4: D6FC6A6A 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001075BC: BF870091
	v_mul_f32_e32 v107, v106, v105                             // 0000001075C0: 10D6D36A
	v_fma_f32 v108, -v104, v107, v106                          // 0000001075C4: D613006C 25AAD768
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001075CC: BF870091
	v_fmac_f32_e32 v107, v108, v105                            // 0000001075D0: 56D6D36C
	v_fma_f32 v104, -v104, v107, v106                          // 0000001075D4: D6130068 25AAD768
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001075DC: BF870091
	v_div_fmas_f32 v104, v104, v105, v107                      // 0000001075E0: D6370068 05AED368
	v_div_fixup_f32 v104, v104, v96, v97                       // 0000001075E8: D6270068 0586C168
	v_mad_i64_i32 v[96:97], null, 0x3000, v120, v[128:129]     // 0000001075F0: D6FF7C60 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001075FC: BF870092
	v_bfe_u32 v105, v104, 16, 1                                // 000000107600: D6100069 02052168
	v_add3_u32 v104, v104, v105, 0x7fff                        // 000000107608: D6550068 03FED368 00007FFF
	global_store_d16_hi_b16 v[96:97], v104, off offset:96      // 000000107614: DC960060 007C6860
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010761C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000107620: BE882002
	s_cbranch_execz 63864                                      // 000000107624: BFA5F978 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f08>
	v_mad_i64_i32 v[96:97], null, 0x6000, v121, v[130:131]     // 000000107628: D6FF7C60 060AF2FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 000000107634: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 00000010763C: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000107640: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107644: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 000000107648: 10C2C0FF BFB8AA3B
	v_fma_f32 v104, 0xbfb8aa3b, v96, -v97                      // 000000107650: D6130068 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v105, v97                                  // 00000010765C: 7ED24761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000107660: BF870221
	v_sub_f32_e32 v97, v97, v105                               // 000000107664: 08C2D361
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 000000107668: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v104, v96, 0xb2a5705f, v104                    // 000000107670: 58D0D160 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000107678: BF870121
	v_add_f32_e32 v97, v97, v104                               // 00000010767C: 06C2D161
	v_cvt_i32_f32_e32 v104, v105                               // 000000107680: 7ED01169
	v_exp_f32_e32 v97, v97                                     // 000000107684: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107688: BF870095
	.long 0xd71c0061                                           // 00000010768C: D71C0061
	v_cndmask_b32_e32 v1, v97, v104, vcc_lo                    // 000000107690: 0202D161
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 000000107694: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 000000107698: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001076A0: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v136, v98// 0000001076A4: CA46C2FF 6060C588 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 0000001076B0: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001076B4: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 0000001076B8: D6FC7C62 0586C160
	v_rcp_f32_e32 v104, v98                                    // 0000001076C0: 7ED05562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001076C4: BF870095
	v_fma_f32 v105, -v98, v104, 1.0                            // 0000001076C8: D6130069 23CAD162
	v_fmac_f32_e32 v104, v105, v104                            // 0000001076D0: 56D0D169
	v_div_scale_f32 v105, vcc_lo, v97, v96, v97                // 0000001076D4: D6FC6A69 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001076DC: BF870091
	v_mul_f32_e32 v106, v105, v104                             // 0000001076E0: 10D4D169
	v_fma_f32 v107, -v98, v106, v105                           // 0000001076E4: D613006B 25A6D562
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001076EC: BF870091
	v_fmac_f32_e32 v106, v107, v104                            // 0000001076F0: 56D4D16B
	v_fma_f32 v98, -v98, v106, v105                            // 0000001076F4: D6130062 25A6D562
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001076FC: BF870091
	v_div_fmas_f32 v98, v98, v104, v106                        // 000000107700: D6370062 05AAD162
	v_div_fixup_f32 v98, v98, v96, v97                         // 000000107708: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v121, v[128:129]     // 000000107710: D6FF7C60 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010771C: BF870092
	v_bfe_u32 v104, v98, 16, 1                                 // 000000107720: D6100068 02052162
	v_add3_u32 v98, v98, v104, 0x7fff                          // 000000107728: D6550062 03FED162 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 000000107734: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010773C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000107740: BE882003
	s_cbranch_execz 63795                                      // 000000107744: BFA5F933 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f14>
	v_mad_i64_i32 v[96:97], null, 0x6000, v122, v[130:131]     // 000000107748: D6FF7C60 060AF4FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 000000107754: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 00000010775C: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000107760: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107764: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 000000107768: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 000000107770: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v104, v97                                  // 00000010777C: 7ED04761
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107780: BF870091
	v_dual_fmamk_f32 v98, v96, 0xb2a5705f, v98 :: v_dual_sub_f32 v97, v97, v104// 000000107784: C88AC560 6260D161 B2A5705F
	v_add_f32_e32 v97, v97, v98                                // 000000107790: 06C2C561
	v_cvt_i32_f32_e32 v98, v104                                // 000000107794: 7EC41168
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 000000107798: 7C3CC0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001077A0: BF870293
	v_exp_f32_e32 v97, v97                                     // 0000001077A4: 7EC24B61
	.long 0xd71c0061                                           // 0000001077A8: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000001077AC: 0202C561
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001077B0: BF870121
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000001077B4: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 0000001077B8: 7C36C0FF C2B17218
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v137, v99// 0000001077C0: CA46C2FF 6060C789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001077CC: BF870091
	v_add_f32_e32 v96, 1.0, v96                                // 0000001077D0: 06C0C0F2
	v_div_scale_f32 v98, null, v96, v96, v97                   // 0000001077D4: D6FC7C62 0586C160
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001077DC: BF870291
	v_rcp_f32_e32 v99, v98                                     // 0000001077E0: 7EC65562
	v_fma_f32 v104, -v98, v99, 1.0                             // 0000001077E4: D6130068 23CAC762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001077EC: BF8700A1
	v_fmac_f32_e32 v99, v104, v99                              // 0000001077F0: 56C6C768
	v_div_scale_f32 v104, vcc_lo, v97, v96, v97                // 0000001077F4: D6FC6A68 0586C161
	v_mul_f32_e32 v105, v104, v99                              // 0000001077FC: 10D2C768
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107800: BF870091
	v_fma_f32 v106, -v98, v105, v104                           // 000000107804: D613006A 25A2D362
	v_fmac_f32_e32 v105, v106, v99                             // 00000010780C: 56D2C76A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107810: BF870091
	v_fma_f32 v98, -v98, v105, v104                            // 000000107814: D6130062 25A2D362
	v_div_fmas_f32 v98, v98, v99, v105                         // 00000010781C: D6370062 05A6C762
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000107824: BF870121
	v_div_fixup_f32 v98, v98, v96, v97                         // 000000107828: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v122, v[128:129]     // 000000107830: D6FF7C60 0602F4FF 00003000
	v_bfe_u32 v99, v98, 16, 1                                  // 00000010783C: D6100063 02052162
	s_delay_alu instid0(VALU_DEP_1)                            // 000000107844: BF870001
	v_add3_u32 v98, v98, v99, 0x7fff                           // 000000107848: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 000000107854: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010785C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000107860: BE882004
	s_cbranch_execz 63726                                      // 000000107864: BFA5F8EE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f20>
	v_mad_i64_i32 v[96:97], null, 0x6000, v123, v[130:131]     // 000000107868: D6FF7C60 060AF6FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 000000107874: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 00000010787C: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000107880: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107884: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 000000107888: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 000000107890: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 00000010789C: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001078A0: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 0000001078A4: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000001078A8: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 0000001078B0: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001078B8: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000001078BC: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000001078C0: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000001078C4: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001078C8: BF870095
	.long 0xd71c0061                                           // 0000001078CC: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000001078D0: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000001078D4: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 0000001078D8: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001078E0: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v134, v100// 0000001078E4: CA46C2FF 6060C986 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 0000001078F0: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001078F4: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 0000001078F8: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 000000107900: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107904: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 000000107908: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 000000107910: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 000000107914: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010791C: BF870091
	v_mul_f32_e32 v104, v100, v99                              // 000000107920: 10D0C764
	v_fma_f32 v105, -v98, v104, v100                           // 000000107924: D6130069 2592D162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010792C: BF870091
	v_fmac_f32_e32 v104, v105, v99                             // 000000107930: 56D0C769
	v_fma_f32 v98, -v98, v104, v100                            // 000000107934: D6130062 2592D162
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010793C: BF870091
	v_div_fmas_f32 v98, v98, v99, v104                         // 000000107940: D6370062 05A2C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 000000107948: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v123, v[128:129]     // 000000107950: D6FF7C60 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010795C: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 000000107960: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 000000107968: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 000000107974: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010797C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000107980: BE882005
	s_cbranch_execz 63657                                      // 000000107984: BFA5F8A9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f2c>
	v_mad_i64_i32 v[96:97], null, 0x6000, v124, v[130:131]     // 000000107988: D6FF7C60 060AF8FF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 000000107994: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 00000010799C: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 0000001079A0: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001079A4: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 0000001079A8: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 0000001079B0: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 0000001079BC: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001079C0: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 0000001079C4: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 0000001079C8: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 0000001079D0: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001079D8: BF870121
	v_add_f32_e32 v97, v97, v98                                // 0000001079DC: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 0000001079E0: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 0000001079E4: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001079E8: BF870095
	.long 0xd71c0061                                           // 0000001079EC: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 0000001079F0: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 0000001079F4: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 0000001079F8: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107A00: BF870092
	v_cndmask_b32_e32 v96, 0x7f800000, v97, vcc_lo             // 000000107A04: 02C0C2FF 7F800000
	v_dual_mul_f32 v97, v135, v101 :: v_dual_add_f32 v96, 1.0, v96// 000000107A0C: C8C8CB87 6160C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107A14: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 000000107A18: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 000000107A20: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107A24: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 000000107A28: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 000000107A30: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 000000107A34: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107A3C: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 000000107A40: 10CAC764
	v_fma_f32 v104, -v98, v101, v100                           // 000000107A44: D6130068 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107A4C: BF870091
	v_fmac_f32_e32 v101, v104, v99                             // 000000107A50: 56CAC768
	v_fma_f32 v98, -v98, v101, v100                            // 000000107A54: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107A5C: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 000000107A60: D6370062 0596C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 000000107A68: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v124, v[128:129]     // 000000107A70: D6FF7C60 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107A7C: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 000000107A80: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 000000107A88: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 000000107A94: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 000000107A9C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000107AA0: BE882006
	s_cbranch_execz 63588                                      // 000000107AA4: BFA5F864 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f38>
	v_mad_i64_i32 v[96:97], null, 0x6000, v125, v[130:131]     // 000000107AA8: D6FF7C60 060AFAFF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 000000107AB4: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 000000107ABC: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000107AC0: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107AC4: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 000000107AC8: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 000000107AD0: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 000000107ADC: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000107AE0: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 000000107AE4: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 000000107AE8: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 000000107AF0: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000107AF8: BF870121
	v_add_f32_e32 v97, v97, v98                                // 000000107AFC: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 000000107B00: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 000000107B04: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107B08: BF870095
	.long 0xd71c0061                                           // 000000107B0C: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 000000107B10: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 000000107B14: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 000000107B18: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107B20: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v132, v102// 000000107B24: CA46C2FF 6060CD84 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 000000107B30: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107B34: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 000000107B38: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 000000107B40: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107B44: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 000000107B48: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 000000107B50: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 000000107B54: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107B5C: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 000000107B60: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 000000107B64: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107B6C: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 000000107B70: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 000000107B74: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107B7C: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 000000107B80: D6370062 0596C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 000000107B88: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v125, v[128:129]     // 000000107B90: D6FF7C60 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107B9C: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 000000107BA0: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 000000107BA8: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 000000107BB4: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 000000107BBC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000107BC0: BE882007
	s_cbranch_execz 63519                                      // 000000107BC4: BFA5F81F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f44>
	v_mad_i64_i32 v[96:97], null, 0x6000, v126, v[130:131]     // 000000107BC8: D6FF7C60 060AFCFF 00006000
	global_load_u16 v96, v[96:97], off offset:608              // 000000107BD4: DC4A0260 607C0060
	s_waitcnt vmcnt(0)                                         // 000000107BDC: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000107BE0: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107BE4: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 000000107BE8: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 000000107BF0: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 000000107BFC: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000107C00: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 000000107C04: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 000000107C08: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 000000107C10: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000107C18: BF870121
	v_add_f32_e32 v97, v97, v98                                // 000000107C1C: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 000000107C20: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 000000107C24: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107C28: BF870095
	.long 0xd71c0061                                           // 000000107C2C: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 000000107C30: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 000000107C34: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 000000107C38: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107C40: BF870092
	v_dual_cndmask_b32 v96, 0x7f800000, v97 :: v_dual_mul_f32 v97, v133, v103// 000000107C44: CA46C2FF 6060CF85 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 000000107C50: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107C54: BF870091
	v_div_scale_f32 v98, null, v96, v96, v97                   // 000000107C58: D6FC7C62 0586C160
	v_rcp_f32_e32 v99, v98                                     // 000000107C60: 7EC65562
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107C64: BF870095
	v_fma_f32 v100, -v98, v99, 1.0                             // 000000107C68: D6130064 23CAC762
	v_fmac_f32_e32 v99, v100, v99                              // 000000107C70: 56C6C764
	v_div_scale_f32 v100, vcc_lo, v97, v96, v97                // 000000107C74: D6FC6A64 0586C161
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107C7C: BF870091
	v_mul_f32_e32 v101, v100, v99                              // 000000107C80: 10CAC764
	v_fma_f32 v102, -v98, v101, v100                           // 000000107C84: D6130066 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107C8C: BF870091
	v_fmac_f32_e32 v101, v102, v99                             // 000000107C90: 56CAC766
	v_fma_f32 v98, -v98, v101, v100                            // 000000107C94: D6130062 2592CB62
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107C9C: BF870091
	v_div_fmas_f32 v98, v98, v99, v101                         // 000000107CA0: D6370062 0596C762
	v_div_fixup_f32 v98, v98, v96, v97                         // 000000107CA8: D6270062 0586C162
	v_mad_i64_i32 v[96:97], null, 0x3000, v126, v[128:129]     // 000000107CB0: D6FF7C60 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107CBC: BF870092
	v_bfe_u32 v99, v98, 16, 1                                  // 000000107CC0: D6100063 02052162
	v_add3_u32 v98, v98, v99, 0x7fff                           // 000000107CC8: D6550062 03FEC762 00007FFF
	global_store_d16_hi_b16 v[96:97], v98, off offset:96       // 000000107CD4: DC960060 007C6260
	s_or_b32 exec_lo, exec_lo, s8                              // 000000107CDC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000107CE0: BE882000
	s_cbranch_execz 63450                                      // 000000107CE4: BFA5F7DA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f50>
	v_mad_i64_i32 v[96:97], null, 0x6000, v140, v[130:131]     // 000000107CE8: D6FF7C60 060B18FF 00006000
	v_mul_f32_e32 v88, v138, v88                               // 000000107CF4: 10B0B18A
	global_load_u16 v96, v[96:97], off offset:640              // 000000107CF8: DC4A0280 607C0060
	s_waitcnt vmcnt(0)                                         // 000000107D00: BF8903F7
	v_lshlrev_b32_e32 v96, 16, v96                             // 000000107D04: 30C0C090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107D08: BF870091
	v_mul_f32_e32 v97, 0xbfb8aa3b, v96                         // 000000107D0C: 10C2C0FF BFB8AA3B
	v_fma_f32 v98, 0xbfb8aa3b, v96, -v97                       // 000000107D14: D6130062 8586C0FF BFB8AA3B
	v_rndne_f32_e32 v99, v97                                   // 000000107D20: 7EC64761
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000107D24: BF870221
	v_sub_f32_e32 v97, v97, v99                                // 000000107D28: 08C2C761
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v96                  // 000000107D2C: 7C3CC0FF 42CE8ED0
	v_fmamk_f32 v98, v96, 0xb2a5705f, v98                      // 000000107D34: 58C4C560 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000107D3C: BF870121
	v_add_f32_e32 v97, v97, v98                                // 000000107D40: 06C2C561
	v_cvt_i32_f32_e32 v98, v99                                 // 000000107D44: 7EC41163
	v_exp_f32_e32 v97, v97                                     // 000000107D48: 7EC24B61
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107D4C: BF870095
	.long 0xd71c0061                                           // 000000107D50: D71C0061
	v_cndmask_b32_e32 v1, v97, v98, vcc_lo                     // 000000107D54: 0202C561
	v_cndmask_b32_e32 v97, 0, v97, vcc_lo                      // 000000107D58: 02C2C280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v96                  // 000000107D5C: 7C36C0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107D64: BF870092
	v_cndmask_b32_e32 v96, 0x7f800000, v97, vcc_lo             // 000000107D68: 02C0C2FF 7F800000
	v_add_f32_e32 v96, 1.0, v96                                // 000000107D70: 06C0C0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107D74: BF870091
	v_div_scale_f32 v97, null, v96, v96, v88                   // 000000107D78: D6FC7C61 0562C160
	v_rcp_f32_e32 v98, v97                                     // 000000107D80: 7EC45561
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107D84: BF870095
	v_fma_f32 v99, -v97, v98, 1.0                              // 000000107D88: D6130063 23CAC561
	v_fmac_f32_e32 v98, v99, v98                               // 000000107D90: 56C4C563
	v_div_scale_f32 v99, vcc_lo, v88, v96, v88                 // 000000107D94: D6FC6A63 0562C158
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107D9C: BF870091
	v_mul_f32_e32 v100, v99, v98                               // 000000107DA0: 10C8C563
	v_fma_f32 v101, -v97, v100, v99                            // 000000107DA4: D6130065 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107DAC: BF870091
	v_fmac_f32_e32 v100, v101, v98                             // 000000107DB0: 56C8C565
	v_fma_f32 v97, -v97, v100, v99                             // 000000107DB4: D6130061 258EC961
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107DBC: BF870091
	v_div_fmas_f32 v97, v97, v98, v100                         // 000000107DC0: D6370061 0592C561
	v_div_fixup_f32 v88, v97, v96, v88                         // 000000107DC8: D6270058 0562C161
	v_mad_i64_i32 v[96:97], null, 0x3000, v140, v[128:129]     // 000000107DD0: D6FF7C60 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107DDC: BF870092
	v_bfe_u32 v98, v88, 16, 1                                  // 000000107DE0: D6100062 02052158
	v_add3_u32 v88, v88, v98, 0x7fff                           // 000000107DE8: D6550058 03FEC558 00007FFF
	global_store_d16_hi_b16 v[96:97], v88, off offset:128      // 000000107DF4: DC960080 007C5860
	s_or_b32 exec_lo, exec_lo, s8                              // 000000107DFC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000107E00: BE882001
	s_cbranch_execz 63381                                      // 000000107E04: BFA5F795 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f5c>
	v_mad_i64_i32 v[96:97], null, 0x6000, v120, v[130:131]     // 000000107E08: D6FF7C60 060AF0FF 00006000
	v_mul_f32_e32 v89, v139, v89                               // 000000107E14: 10B2B38B
	global_load_u16 v88, v[96:97], off offset:640              // 000000107E18: DC4A0280 587C0060
	s_waitcnt vmcnt(0)                                         // 000000107E20: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000107E24: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000107E28: BF870121
	v_mul_f32_e32 v96, 0xbfb8aa3b, v88                         // 000000107E2C: 10C0B0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 000000107E34: 7C3CB0FF 42CE8ED0
	v_fma_f32 v97, 0xbfb8aa3b, v88, -v96                       // 000000107E3C: D6130061 8582B0FF BFB8AA3B
	v_rndne_f32_e32 v98, v96                                   // 000000107E48: 7EC44760
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000107E4C: BF870112
	v_fmamk_f32 v97, v88, 0xb2a5705f, v97                      // 000000107E50: 58C2C358 B2A5705F
	v_sub_f32_e32 v96, v96, v98                                // 000000107E58: 08C0C560
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000107E5C: BF870121
	v_add_f32_e32 v96, v96, v97                                // 000000107E60: 06C0C360
	v_cvt_i32_f32_e32 v97, v98                                 // 000000107E64: 7EC21162
	v_exp_f32_e32 v96, v96                                     // 000000107E68: 7EC04B60
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107E6C: BF870095
	.long 0xd71c0060                                           // 000000107E70: D71C0060
	v_cndmask_b32_e32 v1, v96, v97, vcc_lo                     // 000000107E74: 0202C360
	v_cndmask_b32_e32 v96, 0, v96, vcc_lo                      // 000000107E78: 02C0C080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 000000107E7C: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107E84: BF870092
	v_cndmask_b32_e32 v88, 0x7f800000, v96, vcc_lo             // 000000107E88: 02B0C0FF 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 000000107E90: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107E94: BF870091
	v_div_scale_f32 v96, null, v88, v88, v89                   // 000000107E98: D6FC7C60 0566B158
	v_rcp_f32_e32 v97, v96                                     // 000000107EA0: 7EC25560
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107EA4: BF870095
	v_fma_f32 v98, -v96, v97, 1.0                              // 000000107EA8: D6130062 23CAC360
	v_fmac_f32_e32 v97, v98, v97                               // 000000107EB0: 56C2C362
	v_div_scale_f32 v98, vcc_lo, v89, v88, v89                 // 000000107EB4: D6FC6A62 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107EBC: BF870091
	v_mul_f32_e32 v99, v98, v97                                // 000000107EC0: 10C6C362
	v_fma_f32 v100, -v96, v99, v98                             // 000000107EC4: D6130064 258AC760
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107ECC: BF870091
	v_fmac_f32_e32 v99, v100, v97                              // 000000107ED0: 56C6C364
	v_fma_f32 v96, -v96, v99, v98                              // 000000107ED4: D6130060 258AC760
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107EDC: BF870091
	v_div_fmas_f32 v96, v96, v97, v99                          // 000000107EE0: D6370060 058EC360
	v_div_fixup_f32 v96, v96, v88, v89                         // 000000107EE8: D6270060 0566B160
	v_mad_i64_i32 v[88:89], null, 0x3000, v120, v[128:129]     // 000000107EF0: D6FF7C58 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107EFC: BF870092
	v_bfe_u32 v97, v96, 16, 1                                  // 000000107F00: D6100061 02052160
	v_add3_u32 v96, v96, v97, 0x7fff                           // 000000107F08: D6550060 03FEC360 00007FFF
	global_store_d16_hi_b16 v[88:89], v96, off offset:128      // 000000107F14: DC960080 007C6058
	s_or_b32 exec_lo, exec_lo, s8                              // 000000107F1C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000107F20: BE882002
	s_cbranch_execz 63312                                      // 000000107F24: BFA5F750 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f68>
	v_mad_i64_i32 v[88:89], null, 0x6000, v121, v[130:131]     // 000000107F28: D6FF7C58 060AF2FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 000000107F34: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 000000107F3C: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000107F40: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107F44: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 000000107F48: 10B2B0FF BFB8AA3B
	v_fma_f32 v96, 0xbfb8aa3b, v88, -v89                       // 000000107F50: D6130060 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v97, v89                                   // 000000107F5C: 7EC24759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000107F60: BF870221
	v_sub_f32_e32 v89, v89, v97                                // 000000107F64: 08B2C359
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 000000107F68: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v96, v88, 0xb2a5705f, v96                      // 000000107F70: 58C0C158 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000107F78: BF870121
	v_add_f32_e32 v89, v89, v96                                // 000000107F7C: 06B2C159
	v_cvt_i32_f32_e32 v96, v97                                 // 000000107F80: 7EC01161
	v_exp_f32_e32 v89, v89                                     // 000000107F84: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107F88: BF870095
	.long 0xd71c0059                                           // 000000107F8C: D71C0059
	v_cndmask_b32_e32 v1, v89, v96, vcc_lo                     // 000000107F90: 0202C159
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 000000107F94: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 000000107F98: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107FA0: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v136, v90// 000000107FA4: CA46B2FF 5858B588 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 000000107FB0: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107FB4: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 000000107FB8: D6FC7C5A 0566B158
	v_rcp_f32_e32 v96, v90                                     // 000000107FC0: 7EC0555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107FC4: BF870095
	v_fma_f32 v97, -v90, v96, 1.0                              // 000000107FC8: D6130061 23CAC15A
	v_fmac_f32_e32 v96, v97, v96                               // 000000107FD0: 56C0C161
	v_div_scale_f32 v97, vcc_lo, v89, v88, v89                 // 000000107FD4: D6FC6A61 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107FDC: BF870091
	v_mul_f32_e32 v98, v97, v96                                // 000000107FE0: 10C4C161
	v_fma_f32 v99, -v90, v98, v97                              // 000000107FE4: D6130063 2586C55A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107FEC: BF870091
	v_fmac_f32_e32 v98, v99, v96                               // 000000107FF0: 56C4C163
	v_fma_f32 v90, -v90, v98, v97                              // 000000107FF4: D613005A 2586C55A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000107FFC: BF870091
	v_div_fmas_f32 v90, v90, v96, v98                          // 000000108000: D637005A 058AC15A
	v_div_fixup_f32 v90, v90, v88, v89                         // 000000108008: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v121, v[128:129]     // 000000108010: D6FF7C58 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010801C: BF870092
	v_bfe_u32 v96, v90, 16, 1                                  // 000000108020: D6100060 0205215A
	v_add3_u32 v90, v90, v96, 0x7fff                           // 000000108028: D655005A 03FEC15A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 000000108034: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010803C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000108040: BE882003
	s_cbranch_execz 63243                                      // 000000108044: BFA5F70B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f74>
	v_mad_i64_i32 v[88:89], null, 0x6000, v122, v[130:131]     // 000000108048: D6FF7C58 060AF4FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 000000108054: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 00000010805C: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000108060: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108064: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 000000108068: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 000000108070: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v96, v89                                   // 00000010807C: 7EC04759
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108080: BF870091
	v_dual_fmamk_f32 v90, v88, 0xb2a5705f, v90 :: v_dual_sub_f32 v89, v89, v96// 000000108084: C88AB558 5A58C159 B2A5705F
	v_add_f32_e32 v89, v89, v90                                // 000000108090: 06B2B559
	v_cvt_i32_f32_e32 v90, v96                                 // 000000108094: 7EB41160
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 000000108098: 7C3CB0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001080A0: BF870293
	v_exp_f32_e32 v89, v89                                     // 0000001080A4: 7EB24B59
	.long 0xd71c0059                                           // 0000001080A8: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000001080AC: 0202B559
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001080B0: BF870121
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000001080B4: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 0000001080B8: 7C36B0FF C2B17218
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v137, v91// 0000001080C0: CA46B2FF 5858B789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001080CC: BF870091
	v_add_f32_e32 v88, 1.0, v88                                // 0000001080D0: 06B0B0F2
	v_div_scale_f32 v90, null, v88, v88, v89                   // 0000001080D4: D6FC7C5A 0566B158
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001080DC: BF870291
	v_rcp_f32_e32 v91, v90                                     // 0000001080E0: 7EB6555A
	v_fma_f32 v96, -v90, v91, 1.0                              // 0000001080E4: D6130060 23CAB75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001080EC: BF8700A1
	v_fmac_f32_e32 v91, v96, v91                               // 0000001080F0: 56B6B760
	v_div_scale_f32 v96, vcc_lo, v89, v88, v89                 // 0000001080F4: D6FC6A60 0566B159
	v_mul_f32_e32 v97, v96, v91                                // 0000001080FC: 10C2B760
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108100: BF870091
	v_fma_f32 v98, -v90, v97, v96                              // 000000108104: D6130062 2582C35A
	v_fmac_f32_e32 v97, v98, v91                               // 00000010810C: 56C2B762
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108110: BF870091
	v_fma_f32 v90, -v90, v97, v96                              // 000000108114: D613005A 2582C35A
	v_div_fmas_f32 v90, v90, v91, v97                          // 00000010811C: D637005A 0586B75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000108124: BF870121
	v_div_fixup_f32 v90, v90, v88, v89                         // 000000108128: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v122, v[128:129]     // 000000108130: D6FF7C58 0602F4FF 00003000
	v_bfe_u32 v91, v90, 16, 1                                  // 00000010813C: D610005B 0205215A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000108144: BF870001
	v_add3_u32 v90, v90, v91, 0x7fff                           // 000000108148: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 000000108154: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010815C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000108160: BE882004
	s_cbranch_execz 63174                                      // 000000108164: BFA5F6C6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f80>
	v_mad_i64_i32 v[88:89], null, 0x6000, v123, v[130:131]     // 000000108168: D6FF7C58 060AF6FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 000000108174: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 00000010817C: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000108180: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108184: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 000000108188: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 000000108190: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 00000010819C: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001081A0: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 0000001081A4: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 0000001081A8: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 0000001081B0: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001081B8: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000001081BC: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000001081C0: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000001081C4: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001081C8: BF870095
	.long 0xd71c0059                                           // 0000001081CC: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000001081D0: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000001081D4: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 0000001081D8: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001081E0: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v134, v92// 0000001081E4: CA46B2FF 5858B986 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 0000001081F0: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001081F4: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 0000001081F8: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 000000108200: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108204: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 000000108208: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 000000108210: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 000000108214: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010821C: BF870091
	v_mul_f32_e32 v96, v92, v91                                // 000000108220: 10C0B75C
	v_fma_f32 v97, -v90, v96, v92                              // 000000108224: D6130061 2572C15A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010822C: BF870091
	v_fmac_f32_e32 v96, v97, v91                               // 000000108230: 56C0B761
	v_fma_f32 v90, -v90, v96, v92                              // 000000108234: D613005A 2572C15A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010823C: BF870091
	v_div_fmas_f32 v90, v90, v91, v96                          // 000000108240: D637005A 0582B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 000000108248: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v123, v[128:129]     // 000000108250: D6FF7C58 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010825C: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 000000108260: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 000000108268: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 000000108274: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010827C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000108280: BE882005
	s_cbranch_execz 63105                                      // 000000108284: BFA5F681 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f8c>
	v_mad_i64_i32 v[88:89], null, 0x6000, v124, v[130:131]     // 000000108288: D6FF7C58 060AF8FF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 000000108294: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 00000010829C: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 0000001082A0: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001082A4: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 0000001082A8: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 0000001082B0: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000001082BC: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001082C0: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 0000001082C4: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 0000001082C8: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 0000001082D0: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001082D8: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000001082DC: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 0000001082E0: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 0000001082E4: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001082E8: BF870095
	.long 0xd71c0059                                           // 0000001082EC: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 0000001082F0: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 0000001082F4: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 0000001082F8: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108300: BF870092
	v_cndmask_b32_e32 v88, 0x7f800000, v89, vcc_lo             // 000000108304: 02B0B2FF 7F800000
	v_dual_mul_f32 v89, v135, v93 :: v_dual_add_f32 v88, 1.0, v88// 00000010830C: C8C8BB87 5958B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108314: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 000000108318: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 000000108320: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108324: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 000000108328: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 000000108330: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 000000108334: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010833C: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 000000108340: 10BAB75C
	v_fma_f32 v96, -v90, v93, v92                              // 000000108344: D6130060 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010834C: BF870091
	v_fmac_f32_e32 v93, v96, v91                               // 000000108350: 56BAB760
	v_fma_f32 v90, -v90, v93, v92                              // 000000108354: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010835C: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 000000108360: D637005A 0576B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 000000108368: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v124, v[128:129]     // 000000108370: D6FF7C58 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010837C: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 000000108380: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 000000108388: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 000000108394: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010839C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001083A0: BE882006
	s_cbranch_execz 63036                                      // 0000001083A4: BFA5F63C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3f98>
	v_mad_i64_i32 v[88:89], null, 0x6000, v125, v[130:131]     // 0000001083A8: D6FF7C58 060AFAFF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 0000001083B4: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 0000001083BC: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 0000001083C0: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001083C4: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 0000001083C8: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 0000001083D0: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000001083DC: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001083E0: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 0000001083E4: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 0000001083E8: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 0000001083F0: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001083F8: BF870121
	v_add_f32_e32 v89, v89, v90                                // 0000001083FC: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 000000108400: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 000000108404: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108408: BF870095
	.long 0xd71c0059                                           // 00000010840C: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 000000108410: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 000000108414: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 000000108418: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108420: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v132, v94// 000000108424: CA46B2FF 5858BD84 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 000000108430: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108434: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 000000108438: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 000000108440: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108444: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 000000108448: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 000000108450: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 000000108454: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010845C: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 000000108460: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 000000108464: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010846C: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 000000108470: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 000000108474: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010847C: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 000000108480: D637005A 0576B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 000000108488: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v125, v[128:129]     // 000000108490: D6FF7C58 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010849C: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 0000001084A0: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 0000001084A8: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 0000001084B4: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001084BC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001084C0: BE882007
	s_cbranch_execz 62967                                      // 0000001084C4: BFA5F5F7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fa4>
	v_mad_i64_i32 v[88:89], null, 0x6000, v126, v[130:131]     // 0000001084C8: D6FF7C58 060AFCFF 00006000
	global_load_u16 v88, v[88:89], off offset:640              // 0000001084D4: DC4A0280 587C0058
	s_waitcnt vmcnt(0)                                         // 0000001084DC: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 0000001084E0: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001084E4: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 0000001084E8: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 0000001084F0: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 0000001084FC: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000108500: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 000000108504: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 000000108508: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 000000108510: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000108518: BF870121
	v_add_f32_e32 v89, v89, v90                                // 00000010851C: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 000000108520: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 000000108524: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108528: BF870095
	.long 0xd71c0059                                           // 00000010852C: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 000000108530: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 000000108534: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 000000108538: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108540: BF870092
	v_dual_cndmask_b32 v88, 0x7f800000, v89 :: v_dual_mul_f32 v89, v133, v95// 000000108544: CA46B2FF 5858BF85 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 000000108550: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108554: BF870091
	v_div_scale_f32 v90, null, v88, v88, v89                   // 000000108558: D6FC7C5A 0566B158
	v_rcp_f32_e32 v91, v90                                     // 000000108560: 7EB6555A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108564: BF870095
	v_fma_f32 v92, -v90, v91, 1.0                              // 000000108568: D613005C 23CAB75A
	v_fmac_f32_e32 v91, v92, v91                               // 000000108570: 56B6B75C
	v_div_scale_f32 v92, vcc_lo, v89, v88, v89                 // 000000108574: D6FC6A5C 0566B159
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010857C: BF870091
	v_mul_f32_e32 v93, v92, v91                                // 000000108580: 10BAB75C
	v_fma_f32 v94, -v90, v93, v92                              // 000000108584: D613005E 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010858C: BF870091
	v_fmac_f32_e32 v93, v94, v91                               // 000000108590: 56BAB75E
	v_fma_f32 v90, -v90, v93, v92                              // 000000108594: D613005A 2572BB5A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010859C: BF870091
	v_div_fmas_f32 v90, v90, v91, v93                          // 0000001085A0: D637005A 0576B75A
	v_div_fixup_f32 v90, v90, v88, v89                         // 0000001085A8: D627005A 0566B15A
	v_mad_i64_i32 v[88:89], null, 0x3000, v126, v[128:129]     // 0000001085B0: D6FF7C58 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001085BC: BF870092
	v_bfe_u32 v91, v90, 16, 1                                  // 0000001085C0: D610005B 0205215A
	v_add3_u32 v90, v90, v91, 0x7fff                           // 0000001085C8: D655005A 03FEB75A 00007FFF
	global_store_d16_hi_b16 v[88:89], v90, off offset:128      // 0000001085D4: DC960080 007C5A58
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001085DC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001085E0: BE882000
	s_cbranch_execz 62898                                      // 0000001085E4: BFA5F5B2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fb0>
	v_mad_i64_i32 v[88:89], null, 0x6000, v140, v[130:131]     // 0000001085E8: D6FF7C58 060B18FF 00006000
	v_mul_f32_e32 v80, v138, v80                               // 0000001085F4: 10A0A18A
	global_load_u16 v88, v[88:89], off offset:672              // 0000001085F8: DC4A02A0 587C0058
	s_waitcnt vmcnt(0)                                         // 000000108600: BF8903F7
	v_lshlrev_b32_e32 v88, 16, v88                             // 000000108604: 30B0B090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108608: BF870091
	v_mul_f32_e32 v89, 0xbfb8aa3b, v88                         // 00000010860C: 10B2B0FF BFB8AA3B
	v_fma_f32 v90, 0xbfb8aa3b, v88, -v89                       // 000000108614: D613005A 8566B0FF BFB8AA3B
	v_rndne_f32_e32 v91, v89                                   // 000000108620: 7EB64759
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000108624: BF870221
	v_sub_f32_e32 v89, v89, v91                                // 000000108628: 08B2B759
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v88                  // 00000010862C: 7C3CB0FF 42CE8ED0
	v_fmamk_f32 v90, v88, 0xb2a5705f, v90                      // 000000108634: 58B4B558 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010863C: BF870121
	v_add_f32_e32 v89, v89, v90                                // 000000108640: 06B2B559
	v_cvt_i32_f32_e32 v90, v91                                 // 000000108644: 7EB4115B
	v_exp_f32_e32 v89, v89                                     // 000000108648: 7EB24B59
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010864C: BF870095
	.long 0xd71c0059                                           // 000000108650: D71C0059
	v_cndmask_b32_e32 v1, v89, v90, vcc_lo                     // 000000108654: 0202B559
	v_cndmask_b32_e32 v89, 0, v89, vcc_lo                      // 000000108658: 02B2B280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v88                  // 00000010865C: 7C36B0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108664: BF870092
	v_cndmask_b32_e32 v88, 0x7f800000, v89, vcc_lo             // 000000108668: 02B0B2FF 7F800000
	v_add_f32_e32 v88, 1.0, v88                                // 000000108670: 06B0B0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108674: BF870091
	v_div_scale_f32 v89, null, v88, v88, v80                   // 000000108678: D6FC7C59 0542B158
	v_rcp_f32_e32 v90, v89                                     // 000000108680: 7EB45559
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108684: BF870095
	v_fma_f32 v91, -v89, v90, 1.0                              // 000000108688: D613005B 23CAB559
	v_fmac_f32_e32 v90, v91, v90                               // 000000108690: 56B4B55B
	v_div_scale_f32 v91, vcc_lo, v80, v88, v80                 // 000000108694: D6FC6A5B 0542B150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010869C: BF870091
	v_mul_f32_e32 v92, v91, v90                                // 0000001086A0: 10B8B55B
	v_fma_f32 v93, -v89, v92, v91                              // 0000001086A4: D613005D 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001086AC: BF870091
	v_fmac_f32_e32 v92, v93, v90                               // 0000001086B0: 56B8B55D
	v_fma_f32 v89, -v89, v92, v91                              // 0000001086B4: D6130059 256EB959
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001086BC: BF870091
	v_div_fmas_f32 v89, v89, v90, v92                          // 0000001086C0: D6370059 0572B559
	v_div_fixup_f32 v80, v89, v88, v80                         // 0000001086C8: D6270050 0542B159
	v_mad_i64_i32 v[88:89], null, 0x3000, v140, v[128:129]     // 0000001086D0: D6FF7C58 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001086DC: BF870092
	v_bfe_u32 v90, v80, 16, 1                                  // 0000001086E0: D610005A 02052150
	v_add3_u32 v80, v80, v90, 0x7fff                           // 0000001086E8: D6550050 03FEB550 00007FFF
	global_store_d16_hi_b16 v[88:89], v80, off offset:160      // 0000001086F4: DC9600A0 007C5058
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001086FC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000108700: BE882001
	s_cbranch_execz 62829                                      // 000000108704: BFA5F56D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fbc>
	v_mad_i64_i32 v[88:89], null, 0x6000, v120, v[130:131]     // 000000108708: D6FF7C58 060AF0FF 00006000
	v_mul_f32_e32 v81, v139, v81                               // 000000108714: 10A2A38B
	global_load_u16 v80, v[88:89], off offset:672              // 000000108718: DC4A02A0 507C0058
	s_waitcnt vmcnt(0)                                         // 000000108720: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 000000108724: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000108728: BF870121
	v_mul_f32_e32 v88, 0xbfb8aa3b, v80                         // 00000010872C: 10B0A0FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 000000108734: 7C3CA0FF 42CE8ED0
	v_fma_f32 v89, 0xbfb8aa3b, v80, -v88                       // 00000010873C: D6130059 8562A0FF BFB8AA3B
	v_rndne_f32_e32 v90, v88                                   // 000000108748: 7EB44758
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010874C: BF870112
	v_fmamk_f32 v89, v80, 0xb2a5705f, v89                      // 000000108750: 58B2B350 B2A5705F
	v_sub_f32_e32 v88, v88, v90                                // 000000108758: 08B0B558
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010875C: BF870121
	v_add_f32_e32 v88, v88, v89                                // 000000108760: 06B0B358
	v_cvt_i32_f32_e32 v89, v90                                 // 000000108764: 7EB2115A
	v_exp_f32_e32 v88, v88                                     // 000000108768: 7EB04B58
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010876C: BF870095
	.long 0xd71c0058                                           // 000000108770: D71C0058
	v_cndmask_b32_e32 v1, v88, v89, vcc_lo                     // 000000108774: 0202B358
	v_cndmask_b32_e32 v88, 0, v88, vcc_lo                      // 000000108778: 02B0B080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 00000010877C: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108784: BF870092
	v_cndmask_b32_e32 v80, 0x7f800000, v88, vcc_lo             // 000000108788: 02A0B0FF 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 000000108790: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108794: BF870091
	v_div_scale_f32 v88, null, v80, v80, v81                   // 000000108798: D6FC7C58 0546A150
	v_rcp_f32_e32 v89, v88                                     // 0000001087A0: 7EB25558
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001087A4: BF870095
	v_fma_f32 v90, -v88, v89, 1.0                              // 0000001087A8: D613005A 23CAB358
	v_fmac_f32_e32 v89, v90, v89                               // 0000001087B0: 56B2B35A
	v_div_scale_f32 v90, vcc_lo, v81, v80, v81                 // 0000001087B4: D6FC6A5A 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001087BC: BF870091
	v_mul_f32_e32 v91, v90, v89                                // 0000001087C0: 10B6B35A
	v_fma_f32 v92, -v88, v91, v90                              // 0000001087C4: D613005C 256AB758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001087CC: BF870091
	v_fmac_f32_e32 v91, v92, v89                               // 0000001087D0: 56B6B35C
	v_fma_f32 v88, -v88, v91, v90                              // 0000001087D4: D6130058 256AB758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001087DC: BF870091
	v_div_fmas_f32 v88, v88, v89, v91                          // 0000001087E0: D6370058 056EB358
	v_div_fixup_f32 v88, v88, v80, v81                         // 0000001087E8: D6270058 0546A158
	v_mad_i64_i32 v[80:81], null, 0x3000, v120, v[128:129]     // 0000001087F0: D6FF7C50 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001087FC: BF870092
	v_bfe_u32 v89, v88, 16, 1                                  // 000000108800: D6100059 02052158
	v_add3_u32 v88, v88, v89, 0x7fff                           // 000000108808: D6550058 03FEB358 00007FFF
	global_store_d16_hi_b16 v[80:81], v88, off offset:160      // 000000108814: DC9600A0 007C5850
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010881C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000108820: BE882002
	s_cbranch_execz 62760                                      // 000000108824: BFA5F528 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fc8>
	v_mad_i64_i32 v[80:81], null, 0x6000, v121, v[130:131]     // 000000108828: D6FF7C50 060AF2FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 000000108834: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000010883C: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 000000108840: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108844: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 000000108848: 10A2A0FF BFB8AA3B
	v_fma_f32 v88, 0xbfb8aa3b, v80, -v81                       // 000000108850: D6130058 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v89, v81                                   // 00000010885C: 7EB24751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000108860: BF870221
	v_sub_f32_e32 v81, v81, v89                                // 000000108864: 08A2B351
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 000000108868: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v88, v80, 0xb2a5705f, v88                      // 000000108870: 58B0B150 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000108878: BF870121
	v_add_f32_e32 v81, v81, v88                                // 00000010887C: 06A2B151
	v_cvt_i32_f32_e32 v88, v89                                 // 000000108880: 7EB01159
	v_exp_f32_e32 v81, v81                                     // 000000108884: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108888: BF870095
	.long 0xd71c0051                                           // 00000010888C: D71C0051
	v_cndmask_b32_e32 v1, v81, v88, vcc_lo                     // 000000108890: 0202B151
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 000000108894: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 000000108898: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001088A0: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v136, v82// 0000001088A4: CA46A2FF 5050A588 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 0000001088B0: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001088B4: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 0000001088B8: D6FC7C52 0546A150
	v_rcp_f32_e32 v88, v82                                     // 0000001088C0: 7EB05552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001088C4: BF870095
	v_fma_f32 v89, -v82, v88, 1.0                              // 0000001088C8: D6130059 23CAB152
	v_fmac_f32_e32 v88, v89, v88                               // 0000001088D0: 56B0B159
	v_div_scale_f32 v89, vcc_lo, v81, v80, v81                 // 0000001088D4: D6FC6A59 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001088DC: BF870091
	v_mul_f32_e32 v90, v89, v88                                // 0000001088E0: 10B4B159
	v_fma_f32 v91, -v82, v90, v89                              // 0000001088E4: D613005B 2566B552
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001088EC: BF870091
	v_fmac_f32_e32 v90, v91, v88                               // 0000001088F0: 56B4B15B
	v_fma_f32 v82, -v82, v90, v89                              // 0000001088F4: D6130052 2566B552
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001088FC: BF870091
	v_div_fmas_f32 v82, v82, v88, v90                          // 000000108900: D6370052 056AB152
	v_div_fixup_f32 v82, v82, v80, v81                         // 000000108908: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v121, v[128:129]     // 000000108910: D6FF7C50 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010891C: BF870092
	v_bfe_u32 v88, v82, 16, 1                                  // 000000108920: D6100058 02052152
	v_add3_u32 v82, v82, v88, 0x7fff                           // 000000108928: D6550052 03FEB152 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 000000108934: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010893C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000108940: BE882003
	s_cbranch_execz 62691                                      // 000000108944: BFA5F4E3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fd4>
	v_mad_i64_i32 v[80:81], null, 0x6000, v122, v[130:131]     // 000000108948: D6FF7C50 060AF4FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 000000108954: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 00000010895C: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 000000108960: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108964: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 000000108968: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 000000108970: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v88, v81                                   // 00000010897C: 7EB04751
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108980: BF870091
	v_dual_fmamk_f32 v82, v80, 0xb2a5705f, v82 :: v_dual_sub_f32 v81, v81, v88// 000000108984: C88AA550 5250B151 B2A5705F
	v_add_f32_e32 v81, v81, v82                                // 000000108990: 06A2A551
	v_cvt_i32_f32_e32 v82, v88                                 // 000000108994: 7EA41158
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 000000108998: 7C3CA0FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001089A0: BF870293
	v_exp_f32_e32 v81, v81                                     // 0000001089A4: 7EA24B51
	.long 0xd71c0051                                           // 0000001089A8: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 0000001089AC: 0202A551
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001089B0: BF870121
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 0000001089B4: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 0000001089B8: 7C36A0FF C2B17218
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v137, v83// 0000001089C0: CA46A2FF 5050A789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001089CC: BF870091
	v_add_f32_e32 v80, 1.0, v80                                // 0000001089D0: 06A0A0F2
	v_div_scale_f32 v82, null, v80, v80, v81                   // 0000001089D4: D6FC7C52 0546A150
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001089DC: BF870291
	v_rcp_f32_e32 v83, v82                                     // 0000001089E0: 7EA65552
	v_fma_f32 v88, -v82, v83, 1.0                              // 0000001089E4: D6130058 23CAA752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001089EC: BF8700A1
	v_fmac_f32_e32 v83, v88, v83                               // 0000001089F0: 56A6A758
	v_div_scale_f32 v88, vcc_lo, v81, v80, v81                 // 0000001089F4: D6FC6A58 0546A151
	v_mul_f32_e32 v89, v88, v83                                // 0000001089FC: 10B2A758
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108A00: BF870091
	v_fma_f32 v90, -v82, v89, v88                              // 000000108A04: D613005A 2562B352
	v_fmac_f32_e32 v89, v90, v83                               // 000000108A0C: 56B2A75A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108A10: BF870091
	v_fma_f32 v82, -v82, v89, v88                              // 000000108A14: D6130052 2562B352
	v_div_fmas_f32 v82, v82, v83, v89                          // 000000108A1C: D6370052 0566A752
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000108A24: BF870121
	v_div_fixup_f32 v82, v82, v80, v81                         // 000000108A28: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v122, v[128:129]     // 000000108A30: D6FF7C50 0602F4FF 00003000
	v_bfe_u32 v83, v82, 16, 1                                  // 000000108A3C: D6100053 02052152
	s_delay_alu instid0(VALU_DEP_1)                            // 000000108A44: BF870001
	v_add3_u32 v82, v82, v83, 0x7fff                           // 000000108A48: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 000000108A54: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 000000108A5C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000108A60: BE882004
	s_cbranch_execz 62622                                      // 000000108A64: BFA5F49E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fe0>
	v_mad_i64_i32 v[80:81], null, 0x6000, v123, v[130:131]     // 000000108A68: D6FF7C50 060AF6FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 000000108A74: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 000000108A7C: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 000000108A80: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108A84: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 000000108A88: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 000000108A90: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 000000108A9C: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000108AA0: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 000000108AA4: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 000000108AA8: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 000000108AB0: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000108AB8: BF870121
	v_add_f32_e32 v81, v81, v82                                // 000000108ABC: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 000000108AC0: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 000000108AC4: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108AC8: BF870095
	.long 0xd71c0051                                           // 000000108ACC: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 000000108AD0: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 000000108AD4: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 000000108AD8: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108AE0: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v134, v84// 000000108AE4: CA46A2FF 5050A986 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 000000108AF0: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108AF4: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 000000108AF8: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 000000108B00: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108B04: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 000000108B08: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 000000108B10: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 000000108B14: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108B1C: BF870091
	v_mul_f32_e32 v88, v84, v83                                // 000000108B20: 10B0A754
	v_fma_f32 v89, -v82, v88, v84                              // 000000108B24: D6130059 2552B152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108B2C: BF870091
	v_fmac_f32_e32 v88, v89, v83                               // 000000108B30: 56B0A759
	v_fma_f32 v82, -v82, v88, v84                              // 000000108B34: D6130052 2552B152
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108B3C: BF870091
	v_div_fmas_f32 v82, v82, v83, v88                          // 000000108B40: D6370052 0562A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 000000108B48: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v123, v[128:129]     // 000000108B50: D6FF7C50 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108B5C: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 000000108B60: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 000000108B68: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 000000108B74: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 000000108B7C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000108B80: BE882005
	s_cbranch_execz 62553                                      // 000000108B84: BFA5F459 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3fec>
	v_mad_i64_i32 v[80:81], null, 0x6000, v124, v[130:131]     // 000000108B88: D6FF7C50 060AF8FF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 000000108B94: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 000000108B9C: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 000000108BA0: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108BA4: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 000000108BA8: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 000000108BB0: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 000000108BBC: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000108BC0: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 000000108BC4: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 000000108BC8: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 000000108BD0: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000108BD8: BF870121
	v_add_f32_e32 v81, v81, v82                                // 000000108BDC: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 000000108BE0: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 000000108BE4: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108BE8: BF870095
	.long 0xd71c0051                                           // 000000108BEC: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 000000108BF0: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 000000108BF4: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 000000108BF8: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108C00: BF870092
	v_cndmask_b32_e32 v80, 0x7f800000, v81, vcc_lo             // 000000108C04: 02A0A2FF 7F800000
	v_dual_mul_f32 v81, v135, v85 :: v_dual_add_f32 v80, 1.0, v80// 000000108C0C: C8C8AB87 5150A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108C14: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 000000108C18: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 000000108C20: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108C24: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 000000108C28: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 000000108C30: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 000000108C34: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108C3C: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 000000108C40: 10AAA754
	v_fma_f32 v88, -v82, v85, v84                              // 000000108C44: D6130058 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108C4C: BF870091
	v_fmac_f32_e32 v85, v88, v83                               // 000000108C50: 56AAA758
	v_fma_f32 v82, -v82, v85, v84                              // 000000108C54: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108C5C: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 000000108C60: D6370052 0556A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 000000108C68: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v124, v[128:129]     // 000000108C70: D6FF7C50 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108C7C: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 000000108C80: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 000000108C88: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 000000108C94: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 000000108C9C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000108CA0: BE882006
	s_cbranch_execz 62484                                      // 000000108CA4: BFA5F414 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x3ff8>
	v_mad_i64_i32 v[80:81], null, 0x6000, v125, v[130:131]     // 000000108CA8: D6FF7C50 060AFAFF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 000000108CB4: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 000000108CBC: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 000000108CC0: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108CC4: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 000000108CC8: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 000000108CD0: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 000000108CDC: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000108CE0: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 000000108CE4: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 000000108CE8: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 000000108CF0: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000108CF8: BF870121
	v_add_f32_e32 v81, v81, v82                                // 000000108CFC: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 000000108D00: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 000000108D04: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108D08: BF870095
	.long 0xd71c0051                                           // 000000108D0C: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 000000108D10: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 000000108D14: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 000000108D18: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108D20: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v132, v86// 000000108D24: CA46A2FF 5050AD84 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 000000108D30: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108D34: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 000000108D38: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 000000108D40: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108D44: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 000000108D48: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 000000108D50: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 000000108D54: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108D5C: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 000000108D60: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 000000108D64: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108D6C: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 000000108D70: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 000000108D74: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108D7C: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 000000108D80: D6370052 0556A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 000000108D88: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v125, v[128:129]     // 000000108D90: D6FF7C50 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108D9C: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 000000108DA0: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 000000108DA8: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 000000108DB4: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 000000108DBC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000108DC0: BE882007
	s_cbranch_execz 62415                                      // 000000108DC4: BFA5F3CF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4004>
	v_mad_i64_i32 v[80:81], null, 0x6000, v126, v[130:131]     // 000000108DC8: D6FF7C50 060AFCFF 00006000
	global_load_u16 v80, v[80:81], off offset:672              // 000000108DD4: DC4A02A0 507C0050
	s_waitcnt vmcnt(0)                                         // 000000108DDC: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 000000108DE0: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108DE4: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 000000108DE8: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 000000108DF0: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 000000108DFC: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000108E00: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 000000108E04: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 000000108E08: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 000000108E10: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000108E18: BF870121
	v_add_f32_e32 v81, v81, v82                                // 000000108E1C: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 000000108E20: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 000000108E24: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108E28: BF870095
	.long 0xd71c0051                                           // 000000108E2C: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 000000108E30: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 000000108E34: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 000000108E38: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108E40: BF870092
	v_dual_cndmask_b32 v80, 0x7f800000, v81 :: v_dual_mul_f32 v81, v133, v87// 000000108E44: CA46A2FF 5050AF85 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 000000108E50: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108E54: BF870091
	v_div_scale_f32 v82, null, v80, v80, v81                   // 000000108E58: D6FC7C52 0546A150
	v_rcp_f32_e32 v83, v82                                     // 000000108E60: 7EA65552
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108E64: BF870095
	v_fma_f32 v84, -v82, v83, 1.0                              // 000000108E68: D6130054 23CAA752
	v_fmac_f32_e32 v83, v84, v83                               // 000000108E70: 56A6A754
	v_div_scale_f32 v84, vcc_lo, v81, v80, v81                 // 000000108E74: D6FC6A54 0546A151
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108E7C: BF870091
	v_mul_f32_e32 v85, v84, v83                                // 000000108E80: 10AAA754
	v_fma_f32 v86, -v82, v85, v84                              // 000000108E84: D6130056 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108E8C: BF870091
	v_fmac_f32_e32 v85, v86, v83                               // 000000108E90: 56AAA756
	v_fma_f32 v82, -v82, v85, v84                              // 000000108E94: D6130052 2552AB52
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108E9C: BF870091
	v_div_fmas_f32 v82, v82, v83, v85                          // 000000108EA0: D6370052 0556A752
	v_div_fixup_f32 v82, v82, v80, v81                         // 000000108EA8: D6270052 0546A152
	v_mad_i64_i32 v[80:81], null, 0x3000, v126, v[128:129]     // 000000108EB0: D6FF7C50 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108EBC: BF870092
	v_bfe_u32 v83, v82, 16, 1                                  // 000000108EC0: D6100053 02052152
	v_add3_u32 v82, v82, v83, 0x7fff                           // 000000108EC8: D6550052 03FEA752 00007FFF
	global_store_d16_hi_b16 v[80:81], v82, off offset:160      // 000000108ED4: DC9600A0 007C5250
	s_or_b32 exec_lo, exec_lo, s8                              // 000000108EDC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 000000108EE0: BE882000
	s_cbranch_execz 62346                                      // 000000108EE4: BFA5F38A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4010>
	v_mad_i64_i32 v[80:81], null, 0x6000, v140, v[130:131]     // 000000108EE8: D6FF7C50 060B18FF 00006000
	v_mul_f32_e32 v72, v138, v72                               // 000000108EF4: 1090918A
	global_load_u16 v80, v[80:81], off offset:704              // 000000108EF8: DC4A02C0 507C0050
	s_waitcnt vmcnt(0)                                         // 000000108F00: BF8903F7
	v_lshlrev_b32_e32 v80, 16, v80                             // 000000108F04: 30A0A090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108F08: BF870091
	v_mul_f32_e32 v81, 0xbfb8aa3b, v80                         // 000000108F0C: 10A2A0FF BFB8AA3B
	v_fma_f32 v82, 0xbfb8aa3b, v80, -v81                       // 000000108F14: D6130052 8546A0FF BFB8AA3B
	v_rndne_f32_e32 v83, v81                                   // 000000108F20: 7EA64751
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000108F24: BF870221
	v_sub_f32_e32 v81, v81, v83                                // 000000108F28: 08A2A751
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v80                  // 000000108F2C: 7C3CA0FF 42CE8ED0
	v_fmamk_f32 v82, v80, 0xb2a5705f, v82                      // 000000108F34: 58A4A550 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000108F3C: BF870121
	v_add_f32_e32 v81, v81, v82                                // 000000108F40: 06A2A551
	v_cvt_i32_f32_e32 v82, v83                                 // 000000108F44: 7EA41153
	v_exp_f32_e32 v81, v81                                     // 000000108F48: 7EA24B51
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108F4C: BF870095
	.long 0xd71c0051                                           // 000000108F50: D71C0051
	v_cndmask_b32_e32 v1, v81, v82, vcc_lo                     // 000000108F54: 0202A551
	v_cndmask_b32_e32 v81, 0, v81, vcc_lo                      // 000000108F58: 02A2A280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v80                  // 000000108F5C: 7C36A0FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108F64: BF870092
	v_cndmask_b32_e32 v80, 0x7f800000, v81, vcc_lo             // 000000108F68: 02A0A2FF 7F800000
	v_add_f32_e32 v80, 1.0, v80                                // 000000108F70: 06A0A0F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108F74: BF870091
	v_div_scale_f32 v81, null, v80, v80, v72                   // 000000108F78: D6FC7C51 0522A150
	v_rcp_f32_e32 v82, v81                                     // 000000108F80: 7EA45551
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108F84: BF870095
	v_fma_f32 v83, -v81, v82, 1.0                              // 000000108F88: D6130053 23CAA551
	v_fmac_f32_e32 v82, v83, v82                               // 000000108F90: 56A4A553
	v_div_scale_f32 v83, vcc_lo, v72, v80, v72                 // 000000108F94: D6FC6A53 0522A148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108F9C: BF870091
	v_mul_f32_e32 v84, v83, v82                                // 000000108FA0: 10A8A553
	v_fma_f32 v85, -v81, v84, v83                              // 000000108FA4: D6130055 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108FAC: BF870091
	v_fmac_f32_e32 v84, v85, v82                               // 000000108FB0: 56A8A555
	v_fma_f32 v81, -v81, v84, v83                              // 000000108FB4: D6130051 254EA951
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108FBC: BF870091
	v_div_fmas_f32 v81, v81, v82, v84                          // 000000108FC0: D6370051 0552A551
	v_div_fixup_f32 v72, v81, v80, v72                         // 000000108FC8: D6270048 0522A151
	v_mad_i64_i32 v[80:81], null, 0x3000, v140, v[128:129]     // 000000108FD0: D6FF7C50 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000108FDC: BF870092
	v_bfe_u32 v82, v72, 16, 1                                  // 000000108FE0: D6100052 02052148
	v_add3_u32 v72, v72, v82, 0x7fff                           // 000000108FE8: D6550048 03FEA548 00007FFF
	global_store_d16_hi_b16 v[80:81], v72, off offset:192      // 000000108FF4: DC9600C0 007C4850
	s_or_b32 exec_lo, exec_lo, s8                              // 000000108FFC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000109000: BE882001
	s_cbranch_execz 62277                                      // 000000109004: BFA5F345 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x401c>
	v_mad_i64_i32 v[80:81], null, 0x6000, v120, v[130:131]     // 000000109008: D6FF7C50 060AF0FF 00006000
	v_mul_f32_e32 v73, v139, v73                               // 000000109014: 1092938B
	global_load_u16 v72, v[80:81], off offset:704              // 000000109018: DC4A02C0 487C0050
	s_waitcnt vmcnt(0)                                         // 000000109020: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000109024: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000109028: BF870121
	v_mul_f32_e32 v80, 0xbfb8aa3b, v72                         // 00000010902C: 10A090FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 000000109034: 7C3C90FF 42CE8ED0
	v_fma_f32 v81, 0xbfb8aa3b, v72, -v80                       // 00000010903C: D6130051 854290FF BFB8AA3B
	v_rndne_f32_e32 v82, v80                                   // 000000109048: 7EA44750
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010904C: BF870112
	v_fmamk_f32 v81, v72, 0xb2a5705f, v81                      // 000000109050: 58A2A348 B2A5705F
	v_sub_f32_e32 v80, v80, v82                                // 000000109058: 08A0A550
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010905C: BF870121
	v_add_f32_e32 v80, v80, v81                                // 000000109060: 06A0A350
	v_cvt_i32_f32_e32 v81, v82                                 // 000000109064: 7EA21152
	v_exp_f32_e32 v80, v80                                     // 000000109068: 7EA04B50
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010906C: BF870095
	.long 0xd71c0050                                           // 000000109070: D71C0050
	v_cndmask_b32_e32 v1, v80, v81, vcc_lo                     // 000000109074: 0202A350
	v_cndmask_b32_e32 v80, 0, v80, vcc_lo                      // 000000109078: 02A0A080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000010907C: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109084: BF870092
	v_cndmask_b32_e32 v72, 0x7f800000, v80, vcc_lo             // 000000109088: 0290A0FF 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 000000109090: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109094: BF870091
	v_div_scale_f32 v80, null, v72, v72, v73                   // 000000109098: D6FC7C50 05269148
	v_rcp_f32_e32 v81, v80                                     // 0000001090A0: 7EA25550
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001090A4: BF870095
	v_fma_f32 v82, -v80, v81, 1.0                              // 0000001090A8: D6130052 23CAA350
	v_fmac_f32_e32 v81, v82, v81                               // 0000001090B0: 56A2A352
	v_div_scale_f32 v82, vcc_lo, v73, v72, v73                 // 0000001090B4: D6FC6A52 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001090BC: BF870091
	v_mul_f32_e32 v83, v82, v81                                // 0000001090C0: 10A6A352
	v_fma_f32 v84, -v80, v83, v82                              // 0000001090C4: D6130054 254AA750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001090CC: BF870091
	v_fmac_f32_e32 v83, v84, v81                               // 0000001090D0: 56A6A354
	v_fma_f32 v80, -v80, v83, v82                              // 0000001090D4: D6130050 254AA750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001090DC: BF870091
	v_div_fmas_f32 v80, v80, v81, v83                          // 0000001090E0: D6370050 054EA350
	v_div_fixup_f32 v80, v80, v72, v73                         // 0000001090E8: D6270050 05269150
	v_mad_i64_i32 v[72:73], null, 0x3000, v120, v[128:129]     // 0000001090F0: D6FF7C48 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001090FC: BF870092
	v_bfe_u32 v81, v80, 16, 1                                  // 000000109100: D6100051 02052150
	v_add3_u32 v80, v80, v81, 0x7fff                           // 000000109108: D6550050 03FEA350 00007FFF
	global_store_d16_hi_b16 v[72:73], v80, off offset:192      // 000000109114: DC9600C0 007C5048
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010911C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000109120: BE882002
	s_cbranch_execz 62208                                      // 000000109124: BFA5F300 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4028>
	v_mad_i64_i32 v[72:73], null, 0x6000, v121, v[130:131]     // 000000109128: D6FF7C48 060AF2FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 000000109134: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000010913C: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000109140: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109144: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 000000109148: 109290FF BFB8AA3B
	v_fma_f32 v80, 0xbfb8aa3b, v72, -v73                       // 000000109150: D6130050 852690FF BFB8AA3B
	v_rndne_f32_e32 v81, v73                                   // 00000010915C: 7EA24749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000109160: BF870221
	v_sub_f32_e32 v73, v73, v81                                // 000000109164: 0892A349
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 000000109168: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v80, v72, 0xb2a5705f, v80                      // 000000109170: 58A0A148 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000109178: BF870121
	v_add_f32_e32 v73, v73, v80                                // 00000010917C: 0692A149
	v_cvt_i32_f32_e32 v80, v81                                 // 000000109180: 7EA01151
	v_exp_f32_e32 v73, v73                                     // 000000109184: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109188: BF870095
	.long 0xd71c0049                                           // 00000010918C: D71C0049
	v_cndmask_b32_e32 v1, v73, v80, vcc_lo                     // 000000109190: 0202A149
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 000000109194: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 000000109198: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001091A0: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v136, v74// 0000001091A4: CA4692FF 48489588 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 0000001091B0: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001091B4: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 0000001091B8: D6FC7C4A 05269148
	v_rcp_f32_e32 v80, v74                                     // 0000001091C0: 7EA0554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001091C4: BF870095
	v_fma_f32 v81, -v74, v80, 1.0                              // 0000001091C8: D6130051 23CAA14A
	v_fmac_f32_e32 v80, v81, v80                               // 0000001091D0: 56A0A151
	v_div_scale_f32 v81, vcc_lo, v73, v72, v73                 // 0000001091D4: D6FC6A51 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001091DC: BF870091
	v_mul_f32_e32 v82, v81, v80                                // 0000001091E0: 10A4A151
	v_fma_f32 v83, -v74, v82, v81                              // 0000001091E4: D6130053 2546A54A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001091EC: BF870091
	v_fmac_f32_e32 v82, v83, v80                               // 0000001091F0: 56A4A153
	v_fma_f32 v74, -v74, v82, v81                              // 0000001091F4: D613004A 2546A54A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001091FC: BF870091
	v_div_fmas_f32 v74, v74, v80, v82                          // 000000109200: D637004A 054AA14A
	v_div_fixup_f32 v74, v74, v72, v73                         // 000000109208: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v121, v[128:129]     // 000000109210: D6FF7C48 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010921C: BF870092
	v_bfe_u32 v80, v74, 16, 1                                  // 000000109220: D6100050 0205214A
	v_add3_u32 v74, v74, v80, 0x7fff                           // 000000109228: D655004A 03FEA14A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 000000109234: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010923C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000109240: BE882003
	s_cbranch_execz 62139                                      // 000000109244: BFA5F2BB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4034>
	v_mad_i64_i32 v[72:73], null, 0x6000, v122, v[130:131]     // 000000109248: D6FF7C48 060AF4FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 000000109254: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000010925C: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000109260: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109264: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 000000109268: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 000000109270: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v80, v73                                   // 00000010927C: 7EA04749
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109280: BF870091
	v_dual_fmamk_f32 v74, v72, 0xb2a5705f, v74 :: v_dual_sub_f32 v73, v73, v80// 000000109284: C88A9548 4A48A149 B2A5705F
	v_add_f32_e32 v73, v73, v74                                // 000000109290: 06929549
	v_cvt_i32_f32_e32 v74, v80                                 // 000000109294: 7E941150
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 000000109298: 7C3C90FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001092A0: BF870293
	v_exp_f32_e32 v73, v73                                     // 0000001092A4: 7E924B49
	.long 0xd71c0049                                           // 0000001092A8: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000001092AC: 02029549
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001092B0: BF870121
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000001092B4: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000001092B8: 7C3690FF C2B17218
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v137, v75// 0000001092C0: CA4692FF 48489789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001092CC: BF870091
	v_add_f32_e32 v72, 1.0, v72                                // 0000001092D0: 069090F2
	v_div_scale_f32 v74, null, v72, v72, v73                   // 0000001092D4: D6FC7C4A 05269148
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001092DC: BF870291
	v_rcp_f32_e32 v75, v74                                     // 0000001092E0: 7E96554A
	v_fma_f32 v80, -v74, v75, 1.0                              // 0000001092E4: D6130050 23CA974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001092EC: BF8700A1
	v_fmac_f32_e32 v75, v80, v75                               // 0000001092F0: 56969750
	v_div_scale_f32 v80, vcc_lo, v73, v72, v73                 // 0000001092F4: D6FC6A50 05269149
	v_mul_f32_e32 v81, v80, v75                                // 0000001092FC: 10A29750
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109300: BF870091
	v_fma_f32 v82, -v74, v81, v80                              // 000000109304: D6130052 2542A34A
	v_fmac_f32_e32 v81, v82, v75                               // 00000010930C: 56A29752
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109310: BF870091
	v_fma_f32 v74, -v74, v81, v80                              // 000000109314: D613004A 2542A34A
	v_div_fmas_f32 v74, v74, v75, v81                          // 00000010931C: D637004A 0546974A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000109324: BF870121
	v_div_fixup_f32 v74, v74, v72, v73                         // 000000109328: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v122, v[128:129]     // 000000109330: D6FF7C48 0602F4FF 00003000
	v_bfe_u32 v75, v74, 16, 1                                  // 00000010933C: D610004B 0205214A
	s_delay_alu instid0(VALU_DEP_1)                            // 000000109344: BF870001
	v_add3_u32 v74, v74, v75, 0x7fff                           // 000000109348: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 000000109354: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010935C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000109360: BE882004
	s_cbranch_execz 62070                                      // 000000109364: BFA5F276 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4040>
	v_mad_i64_i32 v[72:73], null, 0x6000, v123, v[130:131]     // 000000109368: D6FF7C48 060AF6FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 000000109374: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000010937C: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000109380: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109384: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 000000109388: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 000000109390: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 00000010939C: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001093A0: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 0000001093A4: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000001093A8: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 0000001093B0: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001093B8: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000001093BC: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000001093C0: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000001093C4: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001093C8: BF870095
	.long 0xd71c0049                                           // 0000001093CC: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000001093D0: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000001093D4: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000001093D8: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001093E0: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v134, v76// 0000001093E4: CA4692FF 48489986 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 0000001093F0: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001093F4: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 0000001093F8: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 000000109400: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109404: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 000000109408: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 000000109410: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 000000109414: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010941C: BF870091
	v_mul_f32_e32 v80, v76, v75                                // 000000109420: 10A0974C
	v_fma_f32 v81, -v74, v80, v76                              // 000000109424: D6130051 2532A14A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010942C: BF870091
	v_fmac_f32_e32 v80, v81, v75                               // 000000109430: 56A09751
	v_fma_f32 v74, -v74, v80, v76                              // 000000109434: D613004A 2532A14A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010943C: BF870091
	v_div_fmas_f32 v74, v74, v75, v80                          // 000000109440: D637004A 0542974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 000000109448: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v123, v[128:129]     // 000000109450: D6FF7C48 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010945C: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 000000109460: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 000000109468: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 000000109474: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010947C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000109480: BE882005
	s_cbranch_execz 62001                                      // 000000109484: BFA5F231 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x404c>
	v_mad_i64_i32 v[72:73], null, 0x6000, v124, v[130:131]     // 000000109488: D6FF7C48 060AF8FF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 000000109494: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 00000010949C: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 0000001094A0: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001094A4: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000001094A8: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 0000001094B0: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000001094BC: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001094C0: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 0000001094C4: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000001094C8: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 0000001094D0: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001094D8: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000001094DC: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 0000001094E0: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 0000001094E4: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001094E8: BF870095
	.long 0xd71c0049                                           // 0000001094EC: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 0000001094F0: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 0000001094F4: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 0000001094F8: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109500: BF870092
	v_cndmask_b32_e32 v72, 0x7f800000, v73, vcc_lo             // 000000109504: 029092FF 7F800000
	v_dual_mul_f32 v73, v135, v77 :: v_dual_add_f32 v72, 1.0, v72// 00000010950C: C8C89B87 494890F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109514: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 000000109518: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 000000109520: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109524: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 000000109528: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 000000109530: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 000000109534: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010953C: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 000000109540: 109A974C
	v_fma_f32 v80, -v74, v77, v76                              // 000000109544: D6130050 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010954C: BF870091
	v_fmac_f32_e32 v77, v80, v75                               // 000000109550: 569A9750
	v_fma_f32 v74, -v74, v77, v76                              // 000000109554: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010955C: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 000000109560: D637004A 0536974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 000000109568: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v124, v[128:129]     // 000000109570: D6FF7C48 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010957C: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 000000109580: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 000000109588: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 000000109594: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010959C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 0000001095A0: BE882006
	s_cbranch_execz 61932                                      // 0000001095A4: BFA5F1EC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4058>
	v_mad_i64_i32 v[72:73], null, 0x6000, v125, v[130:131]     // 0000001095A8: D6FF7C48 060AFAFF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 0000001095B4: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 0000001095BC: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 0000001095C0: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001095C4: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000001095C8: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 0000001095D0: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000001095DC: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001095E0: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 0000001095E4: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 0000001095E8: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 0000001095F0: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001095F8: BF870121
	v_add_f32_e32 v73, v73, v74                                // 0000001095FC: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 000000109600: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 000000109604: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109608: BF870095
	.long 0xd71c0049                                           // 00000010960C: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 000000109610: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 000000109614: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 000000109618: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109620: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v132, v78// 000000109624: CA4692FF 48489D84 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 000000109630: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109634: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 000000109638: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 000000109640: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109644: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 000000109648: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 000000109650: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 000000109654: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010965C: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 000000109660: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 000000109664: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010966C: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 000000109670: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 000000109674: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010967C: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 000000109680: D637004A 0536974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 000000109688: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v125, v[128:129]     // 000000109690: D6FF7C48 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010969C: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 0000001096A0: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 0000001096A8: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 0000001096B4: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001096BC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 0000001096C0: BE882007
	s_cbranch_execz 61863                                      // 0000001096C4: BFA5F1A7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4064>
	v_mad_i64_i32 v[72:73], null, 0x6000, v126, v[130:131]     // 0000001096C8: D6FF7C48 060AFCFF 00006000
	global_load_u16 v72, v[72:73], off offset:704              // 0000001096D4: DC4A02C0 487C0048
	s_waitcnt vmcnt(0)                                         // 0000001096DC: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 0000001096E0: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001096E4: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 0000001096E8: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 0000001096F0: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 0000001096FC: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000109700: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 000000109704: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 000000109708: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 000000109710: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000109718: BF870121
	v_add_f32_e32 v73, v73, v74                                // 00000010971C: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 000000109720: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 000000109724: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109728: BF870095
	.long 0xd71c0049                                           // 00000010972C: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 000000109730: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 000000109734: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 000000109738: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109740: BF870092
	v_dual_cndmask_b32 v72, 0x7f800000, v73 :: v_dual_mul_f32 v73, v133, v79// 000000109744: CA4692FF 48489F85 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 000000109750: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109754: BF870091
	v_div_scale_f32 v74, null, v72, v72, v73                   // 000000109758: D6FC7C4A 05269148
	v_rcp_f32_e32 v75, v74                                     // 000000109760: 7E96554A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109764: BF870095
	v_fma_f32 v76, -v74, v75, 1.0                              // 000000109768: D613004C 23CA974A
	v_fmac_f32_e32 v75, v76, v75                               // 000000109770: 5696974C
	v_div_scale_f32 v76, vcc_lo, v73, v72, v73                 // 000000109774: D6FC6A4C 05269149
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010977C: BF870091
	v_mul_f32_e32 v77, v76, v75                                // 000000109780: 109A974C
	v_fma_f32 v78, -v74, v77, v76                              // 000000109784: D613004E 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010978C: BF870091
	v_fmac_f32_e32 v77, v78, v75                               // 000000109790: 569A974E
	v_fma_f32 v74, -v74, v77, v76                              // 000000109794: D613004A 25329B4A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010979C: BF870091
	v_div_fmas_f32 v74, v74, v75, v77                          // 0000001097A0: D637004A 0536974A
	v_div_fixup_f32 v74, v74, v72, v73                         // 0000001097A8: D627004A 0526914A
	v_mad_i64_i32 v[72:73], null, 0x3000, v126, v[128:129]     // 0000001097B0: D6FF7C48 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001097BC: BF870092
	v_bfe_u32 v75, v74, 16, 1                                  // 0000001097C0: D610004B 0205214A
	v_add3_u32 v74, v74, v75, 0x7fff                           // 0000001097C8: D655004A 03FE974A 00007FFF
	global_store_d16_hi_b16 v[72:73], v74, off offset:192      // 0000001097D4: DC9600C0 007C4A48
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001097DC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 0000001097E0: BE882000
	s_cbranch_execz 61794                                      // 0000001097E4: BFA5F162 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4070>
	v_mad_i64_i32 v[72:73], null, 0x6000, v140, v[130:131]     // 0000001097E8: D6FF7C48 060B18FF 00006000
	v_mul_f32_e32 v64, v138, v64                               // 0000001097F4: 1080818A
	global_load_u16 v72, v[72:73], off offset:736              // 0000001097F8: DC4A02E0 487C0048
	s_waitcnt vmcnt(0)                                         // 000000109800: BF8903F7
	v_lshlrev_b32_e32 v72, 16, v72                             // 000000109804: 30909090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109808: BF870091
	v_mul_f32_e32 v73, 0xbfb8aa3b, v72                         // 00000010980C: 109290FF BFB8AA3B
	v_fma_f32 v74, 0xbfb8aa3b, v72, -v73                       // 000000109814: D613004A 852690FF BFB8AA3B
	v_rndne_f32_e32 v75, v73                                   // 000000109820: 7E964749
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000109824: BF870221
	v_sub_f32_e32 v73, v73, v75                                // 000000109828: 08929749
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v72                  // 00000010982C: 7C3C90FF 42CE8ED0
	v_fmamk_f32 v74, v72, 0xb2a5705f, v74                      // 000000109834: 58949548 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010983C: BF870121
	v_add_f32_e32 v73, v73, v74                                // 000000109840: 06929549
	v_cvt_i32_f32_e32 v74, v75                                 // 000000109844: 7E94114B
	v_exp_f32_e32 v73, v73                                     // 000000109848: 7E924B49
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010984C: BF870095
	.long 0xd71c0049                                           // 000000109850: D71C0049
	v_cndmask_b32_e32 v1, v73, v74, vcc_lo                     // 000000109854: 02029549
	v_cndmask_b32_e32 v73, 0, v73, vcc_lo                      // 000000109858: 02929280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v72                  // 00000010985C: 7C3690FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109864: BF870092
	v_cndmask_b32_e32 v72, 0x7f800000, v73, vcc_lo             // 000000109868: 029092FF 7F800000
	v_add_f32_e32 v72, 1.0, v72                                // 000000109870: 069090F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109874: BF870091
	v_div_scale_f32 v73, null, v72, v72, v64                   // 000000109878: D6FC7C49 05029148
	v_rcp_f32_e32 v74, v73                                     // 000000109880: 7E945549
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109884: BF870095
	v_fma_f32 v75, -v73, v74, 1.0                              // 000000109888: D613004B 23CA9549
	v_fmac_f32_e32 v74, v75, v74                               // 000000109890: 5694954B
	v_div_scale_f32 v75, vcc_lo, v64, v72, v64                 // 000000109894: D6FC6A4B 05029140
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010989C: BF870091
	v_mul_f32_e32 v76, v75, v74                                // 0000001098A0: 1098954B
	v_fma_f32 v77, -v73, v76, v75                              // 0000001098A4: D613004D 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001098AC: BF870091
	v_fmac_f32_e32 v76, v77, v74                               // 0000001098B0: 5698954D
	v_fma_f32 v73, -v73, v76, v75                              // 0000001098B4: D6130049 252E9949
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001098BC: BF870091
	v_div_fmas_f32 v73, v73, v74, v76                          // 0000001098C0: D6370049 05329549
	v_div_fixup_f32 v64, v73, v72, v64                         // 0000001098C8: D6270040 05029149
	v_mad_i64_i32 v[72:73], null, 0x3000, v140, v[128:129]     // 0000001098D0: D6FF7C48 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001098DC: BF870092
	v_bfe_u32 v74, v64, 16, 1                                  // 0000001098E0: D610004A 02052140
	v_add3_u32 v64, v64, v74, 0x7fff                           // 0000001098E8: D6550040 03FE9540 00007FFF
	global_store_d16_hi_b16 v[72:73], v64, off offset:224      // 0000001098F4: DC9600E0 007C4048
	s_or_b32 exec_lo, exec_lo, s8                              // 0000001098FC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 000000109900: BE882001
	s_cbranch_execz 61725                                      // 000000109904: BFA5F11D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x407c>
	v_mad_i64_i32 v[72:73], null, 0x6000, v120, v[130:131]     // 000000109908: D6FF7C48 060AF0FF 00006000
	v_mul_f32_e32 v65, v139, v65                               // 000000109914: 1082838B
	global_load_u16 v64, v[72:73], off offset:736              // 000000109918: DC4A02E0 407C0048
	s_waitcnt vmcnt(0)                                         // 000000109920: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000109924: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000109928: BF870121
	v_mul_f32_e32 v72, 0xbfb8aa3b, v64                         // 00000010992C: 109080FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 000000109934: 7C3C80FF 42CE8ED0
	v_fma_f32 v73, 0xbfb8aa3b, v64, -v72                       // 00000010993C: D6130049 852280FF BFB8AA3B
	v_rndne_f32_e32 v74, v72                                   // 000000109948: 7E944748
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010994C: BF870112
	v_fmamk_f32 v73, v64, 0xb2a5705f, v73                      // 000000109950: 58929340 B2A5705F
	v_sub_f32_e32 v72, v72, v74                                // 000000109958: 08909548
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010995C: BF870121
	v_add_f32_e32 v72, v72, v73                                // 000000109960: 06909348
	v_cvt_i32_f32_e32 v73, v74                                 // 000000109964: 7E92114A
	v_exp_f32_e32 v72, v72                                     // 000000109968: 7E904B48
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010996C: BF870095
	.long 0xd71c0048                                           // 000000109970: D71C0048
	v_cndmask_b32_e32 v1, v72, v73, vcc_lo                     // 000000109974: 02029348
	v_cndmask_b32_e32 v72, 0, v72, vcc_lo                      // 000000109978: 02909080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000010997C: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109984: BF870092
	v_cndmask_b32_e32 v64, 0x7f800000, v72, vcc_lo             // 000000109988: 028090FF 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 000000109990: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109994: BF870091
	v_div_scale_f32 v72, null, v64, v64, v65                   // 000000109998: D6FC7C48 05068140
	v_rcp_f32_e32 v73, v72                                     // 0000001099A0: 7E925548
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001099A4: BF870095
	v_fma_f32 v74, -v72, v73, 1.0                              // 0000001099A8: D613004A 23CA9348
	v_fmac_f32_e32 v73, v74, v73                               // 0000001099B0: 5692934A
	v_div_scale_f32 v74, vcc_lo, v65, v64, v65                 // 0000001099B4: D6FC6A4A 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001099BC: BF870091
	v_mul_f32_e32 v75, v74, v73                                // 0000001099C0: 1096934A
	v_fma_f32 v76, -v72, v75, v74                              // 0000001099C4: D613004C 252A9748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001099CC: BF870091
	v_fmac_f32_e32 v75, v76, v73                               // 0000001099D0: 5696934C
	v_fma_f32 v72, -v72, v75, v74                              // 0000001099D4: D6130048 252A9748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001099DC: BF870091
	v_div_fmas_f32 v72, v72, v73, v75                          // 0000001099E0: D6370048 052E9348
	v_div_fixup_f32 v72, v72, v64, v65                         // 0000001099E8: D6270048 05068148
	v_mad_i64_i32 v[64:65], null, 0x3000, v120, v[128:129]     // 0000001099F0: D6FF7C40 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001099FC: BF870092
	v_bfe_u32 v73, v72, 16, 1                                  // 000000109A00: D6100049 02052148
	v_add3_u32 v72, v72, v73, 0x7fff                           // 000000109A08: D6550048 03FE9348 00007FFF
	global_store_d16_hi_b16 v[64:65], v72, off offset:224      // 000000109A14: DC9600E0 007C4840
	s_or_b32 exec_lo, exec_lo, s8                              // 000000109A1C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 000000109A20: BE882002
	s_cbranch_execz 61656                                      // 000000109A24: BFA5F0D8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4088>
	v_mad_i64_i32 v[64:65], null, 0x6000, v121, v[130:131]     // 000000109A28: D6FF7C40 060AF2FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 000000109A34: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 000000109A3C: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000109A40: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109A44: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 000000109A48: 108280FF BFB8AA3B
	v_fma_f32 v72, 0xbfb8aa3b, v64, -v65                       // 000000109A50: D6130048 850680FF BFB8AA3B
	v_rndne_f32_e32 v73, v65                                   // 000000109A5C: 7E924741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000109A60: BF870221
	v_sub_f32_e32 v65, v65, v73                                // 000000109A64: 08829341
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 000000109A68: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v72, v64, 0xb2a5705f, v72                      // 000000109A70: 58909140 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000109A78: BF870121
	v_add_f32_e32 v65, v65, v72                                // 000000109A7C: 06829141
	v_cvt_i32_f32_e32 v72, v73                                 // 000000109A80: 7E901149
	v_exp_f32_e32 v65, v65                                     // 000000109A84: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109A88: BF870095
	.long 0xd71c0041                                           // 000000109A8C: D71C0041
	v_cndmask_b32_e32 v1, v65, v72, vcc_lo                     // 000000109A90: 02029141
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 000000109A94: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 000000109A98: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109AA0: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v136, v66// 000000109AA4: CA4682FF 40408588 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 000000109AB0: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109AB4: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 000000109AB8: D6FC7C42 05068140
	v_rcp_f32_e32 v72, v66                                     // 000000109AC0: 7E905542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109AC4: BF870095
	v_fma_f32 v73, -v66, v72, 1.0                              // 000000109AC8: D6130049 23CA9142
	v_fmac_f32_e32 v72, v73, v72                               // 000000109AD0: 56909149
	v_div_scale_f32 v73, vcc_lo, v65, v64, v65                 // 000000109AD4: D6FC6A49 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109ADC: BF870091
	v_mul_f32_e32 v74, v73, v72                                // 000000109AE0: 10949149
	v_fma_f32 v75, -v66, v74, v73                              // 000000109AE4: D613004B 25269542
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109AEC: BF870091
	v_fmac_f32_e32 v74, v75, v72                               // 000000109AF0: 5694914B
	v_fma_f32 v66, -v66, v74, v73                              // 000000109AF4: D6130042 25269542
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109AFC: BF870091
	v_div_fmas_f32 v66, v66, v72, v74                          // 000000109B00: D6370042 052A9142
	v_div_fixup_f32 v66, v66, v64, v65                         // 000000109B08: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v121, v[128:129]     // 000000109B10: D6FF7C40 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109B1C: BF870092
	v_bfe_u32 v72, v66, 16, 1                                  // 000000109B20: D6100048 02052142
	v_add3_u32 v66, v66, v72, 0x7fff                           // 000000109B28: D6550042 03FE9142 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 000000109B34: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 000000109B3C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 000000109B40: BE882003
	s_cbranch_execz 61587                                      // 000000109B44: BFA5F093 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4094>
	v_mad_i64_i32 v[64:65], null, 0x6000, v122, v[130:131]     // 000000109B48: D6FF7C40 060AF4FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 000000109B54: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 000000109B5C: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000109B60: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109B64: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 000000109B68: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 000000109B70: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v72, v65                                   // 000000109B7C: 7E904741
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109B80: BF870091
	v_dual_fmamk_f32 v66, v64, 0xb2a5705f, v66 :: v_dual_sub_f32 v65, v65, v72// 000000109B84: C88A8540 42409141 B2A5705F
	v_add_f32_e32 v65, v65, v66                                // 000000109B90: 06828541
	v_cvt_i32_f32_e32 v66, v72                                 // 000000109B94: 7E841148
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 000000109B98: 7C3C80FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000109BA0: BF870293
	v_exp_f32_e32 v65, v65                                     // 000000109BA4: 7E824B41
	.long 0xd71c0041                                           // 000000109BA8: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000109BAC: 02028541
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000109BB0: BF870121
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 000000109BB4: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 000000109BB8: 7C3680FF C2B17218
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v137, v67// 000000109BC0: CA4682FF 40408789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109BCC: BF870091
	v_add_f32_e32 v64, 1.0, v64                                // 000000109BD0: 068080F2
	v_div_scale_f32 v66, null, v64, v64, v65                   // 000000109BD4: D6FC7C42 05068140
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000109BDC: BF870291
	v_rcp_f32_e32 v67, v66                                     // 000000109BE0: 7E865542
	v_fma_f32 v72, -v66, v67, 1.0                              // 000000109BE4: D6130048 23CA8742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000109BEC: BF8700A1
	v_fmac_f32_e32 v67, v72, v67                               // 000000109BF0: 56868748
	v_div_scale_f32 v72, vcc_lo, v65, v64, v65                 // 000000109BF4: D6FC6A48 05068141
	v_mul_f32_e32 v73, v72, v67                                // 000000109BFC: 10928748
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109C00: BF870091
	v_fma_f32 v74, -v66, v73, v72                              // 000000109C04: D613004A 25229342
	v_fmac_f32_e32 v73, v74, v67                               // 000000109C0C: 5692874A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109C10: BF870091
	v_fma_f32 v66, -v66, v73, v72                              // 000000109C14: D6130042 25229342
	v_div_fmas_f32 v66, v66, v67, v73                          // 000000109C1C: D6370042 05268742
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000109C24: BF870121
	v_div_fixup_f32 v66, v66, v64, v65                         // 000000109C28: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v122, v[128:129]     // 000000109C30: D6FF7C40 0602F4FF 00003000
	v_bfe_u32 v67, v66, 16, 1                                  // 000000109C3C: D6100043 02052142
	s_delay_alu instid0(VALU_DEP_1)                            // 000000109C44: BF870001
	v_add3_u32 v66, v66, v67, 0x7fff                           // 000000109C48: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 000000109C54: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 000000109C5C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 000000109C60: BE882004
	s_cbranch_execz 61518                                      // 000000109C64: BFA5F04E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40a0>
	v_mad_i64_i32 v[64:65], null, 0x6000, v123, v[130:131]     // 000000109C68: D6FF7C40 060AF6FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 000000109C74: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 000000109C7C: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000109C80: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109C84: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 000000109C88: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 000000109C90: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 000000109C9C: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000109CA0: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 000000109CA4: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 000000109CA8: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 000000109CB0: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000109CB8: BF870121
	v_add_f32_e32 v65, v65, v66                                // 000000109CBC: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000109CC0: 7E841143
	v_exp_f32_e32 v65, v65                                     // 000000109CC4: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109CC8: BF870095
	.long 0xd71c0041                                           // 000000109CCC: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000109CD0: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 000000109CD4: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 000000109CD8: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109CE0: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v134, v68// 000000109CE4: CA4682FF 40408986 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 000000109CF0: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109CF4: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 000000109CF8: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 000000109D00: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109D04: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 000000109D08: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 000000109D10: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 000000109D14: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109D1C: BF870091
	v_mul_f32_e32 v72, v68, v67                                // 000000109D20: 10908744
	v_fma_f32 v73, -v66, v72, v68                              // 000000109D24: D6130049 25129142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109D2C: BF870091
	v_fmac_f32_e32 v72, v73, v67                               // 000000109D30: 56908749
	v_fma_f32 v66, -v66, v72, v68                              // 000000109D34: D6130042 25129142
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109D3C: BF870091
	v_div_fmas_f32 v66, v66, v67, v72                          // 000000109D40: D6370042 05228742
	v_div_fixup_f32 v66, v66, v64, v65                         // 000000109D48: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v123, v[128:129]     // 000000109D50: D6FF7C40 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109D5C: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 000000109D60: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 000000109D68: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 000000109D74: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 000000109D7C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 000000109D80: BE882005
	s_cbranch_execz 61449                                      // 000000109D84: BFA5F009 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40ac>
	v_mad_i64_i32 v[64:65], null, 0x6000, v124, v[130:131]     // 000000109D88: D6FF7C40 060AF8FF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 000000109D94: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 000000109D9C: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000109DA0: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109DA4: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 000000109DA8: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 000000109DB0: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 000000109DBC: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000109DC0: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 000000109DC4: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 000000109DC8: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 000000109DD0: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000109DD8: BF870121
	v_add_f32_e32 v65, v65, v66                                // 000000109DDC: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000109DE0: 7E841143
	v_exp_f32_e32 v65, v65                                     // 000000109DE4: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109DE8: BF870095
	.long 0xd71c0041                                           // 000000109DEC: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000109DF0: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 000000109DF4: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 000000109DF8: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109E00: BF870092
	v_cndmask_b32_e32 v64, 0x7f800000, v65, vcc_lo             // 000000109E04: 028082FF 7F800000
	v_dual_mul_f32 v65, v135, v69 :: v_dual_add_f32 v64, 1.0, v64// 000000109E0C: C8C88B87 414080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109E14: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 000000109E18: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 000000109E20: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109E24: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 000000109E28: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 000000109E30: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 000000109E34: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109E3C: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 000000109E40: 108A8744
	v_fma_f32 v72, -v66, v69, v68                              // 000000109E44: D6130048 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109E4C: BF870091
	v_fmac_f32_e32 v69, v72, v67                               // 000000109E50: 568A8748
	v_fma_f32 v66, -v66, v69, v68                              // 000000109E54: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109E5C: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 000000109E60: D6370042 05168742
	v_div_fixup_f32 v66, v66, v64, v65                         // 000000109E68: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v124, v[128:129]     // 000000109E70: D6FF7C40 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109E7C: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 000000109E80: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 000000109E88: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 000000109E94: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 000000109E9C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 000000109EA0: BE882006
	s_cbranch_execz 61380                                      // 000000109EA4: BFA5EFC4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40b8>
	v_mad_i64_i32 v[64:65], null, 0x6000, v125, v[130:131]     // 000000109EA8: D6FF7C40 060AFAFF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 000000109EB4: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 000000109EBC: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000109EC0: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109EC4: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 000000109EC8: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 000000109ED0: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 000000109EDC: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 000000109EE0: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 000000109EE4: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 000000109EE8: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 000000109EF0: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000109EF8: BF870121
	v_add_f32_e32 v65, v65, v66                                // 000000109EFC: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 000000109F00: 7E841143
	v_exp_f32_e32 v65, v65                                     // 000000109F04: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109F08: BF870095
	.long 0xd71c0041                                           // 000000109F0C: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 000000109F10: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 000000109F14: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 000000109F18: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109F20: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v132, v70// 000000109F24: CA4682FF 40408D84 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 000000109F30: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109F34: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 000000109F38: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 000000109F40: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109F44: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 000000109F48: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 000000109F50: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 000000109F54: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109F5C: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 000000109F60: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 000000109F64: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109F6C: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 000000109F70: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 000000109F74: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109F7C: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 000000109F80: D6370042 05168742
	v_div_fixup_f32 v66, v66, v64, v65                         // 000000109F88: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v125, v[128:129]     // 000000109F90: D6FF7C40 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109F9C: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 000000109FA0: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 000000109FA8: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 000000109FB4: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 000000109FBC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 000000109FC0: BE882007
	s_cbranch_execz 61311                                      // 000000109FC4: BFA5EF7F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40c4>
	v_mad_i64_i32 v[64:65], null, 0x6000, v126, v[130:131]     // 000000109FC8: D6FF7C40 060AFCFF 00006000
	global_load_u16 v64, v[64:65], off offset:736              // 000000109FD4: DC4A02E0 407C0040
	s_waitcnt vmcnt(0)                                         // 000000109FDC: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 000000109FE0: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000109FE4: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 000000109FE8: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 000000109FF0: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 000000109FFC: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010A000: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 00000010A004: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000010A008: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 00000010A010: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010A018: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000010A01C: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000010A020: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000010A024: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A028: BF870095
	.long 0xd71c0041                                           // 00000010A02C: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000010A030: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000010A034: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000010A038: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A040: BF870092
	v_dual_cndmask_b32 v64, 0x7f800000, v65 :: v_dual_mul_f32 v65, v133, v71// 00000010A044: CA4682FF 40408F85 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 00000010A050: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A054: BF870091
	v_div_scale_f32 v66, null, v64, v64, v65                   // 00000010A058: D6FC7C42 05068140
	v_rcp_f32_e32 v67, v66                                     // 00000010A060: 7E865542
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A064: BF870095
	v_fma_f32 v68, -v66, v67, 1.0                              // 00000010A068: D6130044 23CA8742
	v_fmac_f32_e32 v67, v68, v67                               // 00000010A070: 56868744
	v_div_scale_f32 v68, vcc_lo, v65, v64, v65                 // 00000010A074: D6FC6A44 05068141
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A07C: BF870091
	v_mul_f32_e32 v69, v68, v67                                // 00000010A080: 108A8744
	v_fma_f32 v70, -v66, v69, v68                              // 00000010A084: D6130046 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A08C: BF870091
	v_fmac_f32_e32 v69, v70, v67                               // 00000010A090: 568A8746
	v_fma_f32 v66, -v66, v69, v68                              // 00000010A094: D6130042 25128B42
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A09C: BF870091
	v_div_fmas_f32 v66, v66, v67, v69                          // 00000010A0A0: D6370042 05168742
	v_div_fixup_f32 v66, v66, v64, v65                         // 00000010A0A8: D6270042 05068142
	v_mad_i64_i32 v[64:65], null, 0x3000, v126, v[128:129]     // 00000010A0B0: D6FF7C40 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A0BC: BF870092
	v_bfe_u32 v67, v66, 16, 1                                  // 00000010A0C0: D6100043 02052142
	v_add3_u32 v66, v66, v67, 0x7fff                           // 00000010A0C8: D6550042 03FE8742 00007FFF
	global_store_d16_hi_b16 v[64:65], v66, off offset:224      // 00000010A0D4: DC9600E0 007C4240
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010A0DC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000010A0E0: BE882000
	s_cbranch_execz 61242                                      // 00000010A0E4: BFA5EF3A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40d0>
	v_mad_i64_i32 v[64:65], null, 0x6000, v140, v[130:131]     // 00000010A0E8: D6FF7C40 060B18FF 00006000
	v_mul_f32_e32 v56, v138, v56                               // 00000010A0F4: 1070718A
	global_load_u16 v64, v[64:65], off offset:768              // 00000010A0F8: DC4A0300 407C0040
	s_waitcnt vmcnt(0)                                         // 00000010A100: BF8903F7
	v_lshlrev_b32_e32 v64, 16, v64                             // 00000010A104: 30808090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A108: BF870091
	v_mul_f32_e32 v65, 0xbfb8aa3b, v64                         // 00000010A10C: 108280FF BFB8AA3B
	v_fma_f32 v66, 0xbfb8aa3b, v64, -v65                       // 00000010A114: D6130042 850680FF BFB8AA3B
	v_rndne_f32_e32 v67, v65                                   // 00000010A120: 7E864741
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010A124: BF870221
	v_sub_f32_e32 v65, v65, v67                                // 00000010A128: 08828741
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v64                  // 00000010A12C: 7C3C80FF 42CE8ED0
	v_fmamk_f32 v66, v64, 0xb2a5705f, v66                      // 00000010A134: 58848540 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010A13C: BF870121
	v_add_f32_e32 v65, v65, v66                                // 00000010A140: 06828541
	v_cvt_i32_f32_e32 v66, v67                                 // 00000010A144: 7E841143
	v_exp_f32_e32 v65, v65                                     // 00000010A148: 7E824B41
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A14C: BF870095
	.long 0xd71c0041                                           // 00000010A150: D71C0041
	v_cndmask_b32_e32 v1, v65, v66, vcc_lo                     // 00000010A154: 02028541
	v_cndmask_b32_e32 v65, 0, v65, vcc_lo                      // 00000010A158: 02828280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v64                  // 00000010A15C: 7C3680FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A164: BF870092
	v_cndmask_b32_e32 v64, 0x7f800000, v65, vcc_lo             // 00000010A168: 028082FF 7F800000
	v_add_f32_e32 v64, 1.0, v64                                // 00000010A170: 068080F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A174: BF870091
	v_div_scale_f32 v65, null, v64, v64, v56                   // 00000010A178: D6FC7C41 04E28140
	v_rcp_f32_e32 v66, v65                                     // 00000010A180: 7E845541
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A184: BF870095
	v_fma_f32 v67, -v65, v66, 1.0                              // 00000010A188: D6130043 23CA8541
	v_fmac_f32_e32 v66, v67, v66                               // 00000010A190: 56848543
	v_div_scale_f32 v67, vcc_lo, v56, v64, v56                 // 00000010A194: D6FC6A43 04E28138
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A19C: BF870091
	v_mul_f32_e32 v68, v67, v66                                // 00000010A1A0: 10888543
	v_fma_f32 v69, -v65, v68, v67                              // 00000010A1A4: D6130045 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A1AC: BF870091
	v_fmac_f32_e32 v68, v69, v66                               // 00000010A1B0: 56888545
	v_fma_f32 v65, -v65, v68, v67                              // 00000010A1B4: D6130041 250E8941
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A1BC: BF870091
	v_div_fmas_f32 v65, v65, v66, v68                          // 00000010A1C0: D6370041 05128541
	v_div_fixup_f32 v56, v65, v64, v56                         // 00000010A1C8: D6270038 04E28141
	v_mad_i64_i32 v[64:65], null, 0x3000, v140, v[128:129]     // 00000010A1D0: D6FF7C40 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A1DC: BF870092
	v_bfe_u32 v66, v56, 16, 1                                  // 00000010A1E0: D6100042 02052138
	v_add3_u32 v56, v56, v66, 0x7fff                           // 00000010A1E8: D6550038 03FE8538 00007FFF
	global_store_d16_hi_b16 v[64:65], v56, off offset:256      // 00000010A1F4: DC960100 007C3840
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010A1FC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000010A200: BE882001
	s_cbranch_execz 61173                                      // 00000010A204: BFA5EEF5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40dc>
	v_mad_i64_i32 v[64:65], null, 0x6000, v120, v[130:131]     // 00000010A208: D6FF7C40 060AF0FF 00006000
	v_mul_f32_e32 v57, v139, v57                               // 00000010A214: 1072738B
	global_load_u16 v56, v[64:65], off offset:768              // 00000010A218: DC4A0300 387C0040
	s_waitcnt vmcnt(0)                                         // 00000010A220: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000010A224: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010A228: BF870121
	v_mul_f32_e32 v64, 0xbfb8aa3b, v56                         // 00000010A22C: 108070FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000010A234: 7C3C70FF 42CE8ED0
	v_fma_f32 v65, 0xbfb8aa3b, v56, -v64                       // 00000010A23C: D6130041 850270FF BFB8AA3B
	v_rndne_f32_e32 v66, v64                                   // 00000010A248: 7E844740
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010A24C: BF870112
	v_fmamk_f32 v65, v56, 0xb2a5705f, v65                      // 00000010A250: 58828338 B2A5705F
	v_sub_f32_e32 v64, v64, v66                                // 00000010A258: 08808540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010A25C: BF870121
	v_add_f32_e32 v64, v64, v65                                // 00000010A260: 06808340
	v_cvt_i32_f32_e32 v65, v66                                 // 00000010A264: 7E821142
	v_exp_f32_e32 v64, v64                                     // 00000010A268: 7E804B40
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A26C: BF870095
	.long 0xd71c0040                                           // 00000010A270: D71C0040
	v_cndmask_b32_e32 v1, v64, v65, vcc_lo                     // 00000010A274: 02028340
	v_cndmask_b32_e32 v64, 0, v64, vcc_lo                      // 00000010A278: 02808080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000010A27C: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A284: BF870092
	v_cndmask_b32_e32 v56, 0x7f800000, v64, vcc_lo             // 00000010A288: 027080FF 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000010A290: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A294: BF870091
	v_div_scale_f32 v64, null, v56, v56, v57                   // 00000010A298: D6FC7C40 04E67138
	v_rcp_f32_e32 v65, v64                                     // 00000010A2A0: 7E825540
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A2A4: BF870095
	v_fma_f32 v66, -v64, v65, 1.0                              // 00000010A2A8: D6130042 23CA8340
	v_fmac_f32_e32 v65, v66, v65                               // 00000010A2B0: 56828342
	v_div_scale_f32 v66, vcc_lo, v57, v56, v57                 // 00000010A2B4: D6FC6A42 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A2BC: BF870091
	v_mul_f32_e32 v67, v66, v65                                // 00000010A2C0: 10868342
	v_fma_f32 v68, -v64, v67, v66                              // 00000010A2C4: D6130044 250A8740
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A2CC: BF870091
	v_fmac_f32_e32 v67, v68, v65                               // 00000010A2D0: 56868344
	v_fma_f32 v64, -v64, v67, v66                              // 00000010A2D4: D6130040 250A8740
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A2DC: BF870091
	v_div_fmas_f32 v64, v64, v65, v67                          // 00000010A2E0: D6370040 050E8340
	v_div_fixup_f32 v64, v64, v56, v57                         // 00000010A2E8: D6270040 04E67140
	v_mad_i64_i32 v[56:57], null, 0x3000, v120, v[128:129]     // 00000010A2F0: D6FF7C38 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A2FC: BF870092
	v_bfe_u32 v65, v64, 16, 1                                  // 00000010A300: D6100041 02052140
	v_add3_u32 v64, v64, v65, 0x7fff                           // 00000010A308: D6550040 03FE8340 00007FFF
	global_store_d16_hi_b16 v[56:57], v64, off offset:256      // 00000010A314: DC960100 007C4038
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010A31C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000010A320: BE882002
	s_cbranch_execz 61104                                      // 00000010A324: BFA5EEB0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40e8>
	v_mad_i64_i32 v[56:57], null, 0x6000, v121, v[130:131]     // 00000010A328: D6FF7C38 060AF2FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000010A334: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000010A33C: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000010A340: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A344: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000010A348: 107270FF BFB8AA3B
	v_fma_f32 v64, 0xbfb8aa3b, v56, -v57                       // 00000010A350: D6130040 84E670FF BFB8AA3B
	v_rndne_f32_e32 v65, v57                                   // 00000010A35C: 7E824739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010A360: BF870221
	v_sub_f32_e32 v57, v57, v65                                // 00000010A364: 08728339
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000010A368: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v64, v56, 0xb2a5705f, v64                      // 00000010A370: 58808138 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010A378: BF870121
	v_add_f32_e32 v57, v57, v64                                // 00000010A37C: 06728139
	v_cvt_i32_f32_e32 v64, v65                                 // 00000010A380: 7E801141
	v_exp_f32_e32 v57, v57                                     // 00000010A384: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A388: BF870095
	.long 0xd71c0039                                           // 00000010A38C: D71C0039
	v_cndmask_b32_e32 v1, v57, v64, vcc_lo                     // 00000010A390: 02028139
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000010A394: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000010A398: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A3A0: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v136, v58// 00000010A3A4: CA4672FF 38387588 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000010A3B0: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A3B4: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000010A3B8: D6FC7C3A 04E67138
	v_rcp_f32_e32 v64, v58                                     // 00000010A3C0: 7E80553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A3C4: BF870095
	v_fma_f32 v65, -v58, v64, 1.0                              // 00000010A3C8: D6130041 23CA813A
	v_fmac_f32_e32 v64, v65, v64                               // 00000010A3D0: 56808141
	v_div_scale_f32 v65, vcc_lo, v57, v56, v57                 // 00000010A3D4: D6FC6A41 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A3DC: BF870091
	v_mul_f32_e32 v66, v65, v64                                // 00000010A3E0: 10848141
	v_fma_f32 v67, -v58, v66, v65                              // 00000010A3E4: D6130043 2506853A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A3EC: BF870091
	v_fmac_f32_e32 v66, v67, v64                               // 00000010A3F0: 56848143
	v_fma_f32 v58, -v58, v66, v65                              // 00000010A3F4: D613003A 2506853A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A3FC: BF870091
	v_div_fmas_f32 v58, v58, v64, v66                          // 00000010A400: D637003A 050A813A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000010A408: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v121, v[128:129]     // 00000010A410: D6FF7C38 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A41C: BF870092
	v_bfe_u32 v64, v58, 16, 1                                  // 00000010A420: D6100040 0205213A
	v_add3_u32 v58, v58, v64, 0x7fff                           // 00000010A428: D655003A 03FE813A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000010A434: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010A43C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000010A440: BE882003
	s_cbranch_execz 61035                                      // 00000010A444: BFA5EE6B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x40f4>
	v_mad_i64_i32 v[56:57], null, 0x6000, v122, v[130:131]     // 00000010A448: D6FF7C38 060AF4FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000010A454: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000010A45C: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000010A460: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A464: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000010A468: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000010A470: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v64, v57                                   // 00000010A47C: 7E804739
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A480: BF870091
	v_dual_fmamk_f32 v58, v56, 0xb2a5705f, v58 :: v_dual_sub_f32 v57, v57, v64// 00000010A484: C88A7538 3A388139 B2A5705F
	v_add_f32_e32 v57, v57, v58                                // 00000010A490: 06727539
	v_cvt_i32_f32_e32 v58, v64                                 // 00000010A494: 7E741140
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000010A498: 7C3C70FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010A4A0: BF870293
	v_exp_f32_e32 v57, v57                                     // 00000010A4A4: 7E724B39
	.long 0xd71c0039                                           // 00000010A4A8: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000010A4AC: 02027539
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010A4B0: BF870121
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000010A4B4: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000010A4B8: 7C3670FF C2B17218
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v137, v59// 00000010A4C0: CA4672FF 38387789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A4CC: BF870091
	v_add_f32_e32 v56, 1.0, v56                                // 00000010A4D0: 067070F2
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000010A4D4: D6FC7C3A 04E67138
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010A4DC: BF870291
	v_rcp_f32_e32 v59, v58                                     // 00000010A4E0: 7E76553A
	v_fma_f32 v64, -v58, v59, 1.0                              // 00000010A4E4: D6130040 23CA773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000010A4EC: BF8700A1
	v_fmac_f32_e32 v59, v64, v59                               // 00000010A4F0: 56767740
	v_div_scale_f32 v64, vcc_lo, v57, v56, v57                 // 00000010A4F4: D6FC6A40 04E67139
	v_mul_f32_e32 v65, v64, v59                                // 00000010A4FC: 10827740
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A500: BF870091
	v_fma_f32 v66, -v58, v65, v64                              // 00000010A504: D6130042 2502833A
	v_fmac_f32_e32 v65, v66, v59                               // 00000010A50C: 56827742
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A510: BF870091
	v_fma_f32 v58, -v58, v65, v64                              // 00000010A514: D613003A 2502833A
	v_div_fmas_f32 v58, v58, v59, v65                          // 00000010A51C: D637003A 0506773A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010A524: BF870121
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000010A528: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v122, v[128:129]     // 00000010A530: D6FF7C38 0602F4FF 00003000
	v_bfe_u32 v59, v58, 16, 1                                  // 00000010A53C: D610003B 0205213A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010A544: BF870001
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000010A548: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000010A554: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010A55C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000010A560: BE882004
	s_cbranch_execz 60966                                      // 00000010A564: BFA5EE26 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4100>
	v_mad_i64_i32 v[56:57], null, 0x6000, v123, v[130:131]     // 00000010A568: D6FF7C38 060AF6FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000010A574: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000010A57C: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000010A580: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A584: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000010A588: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000010A590: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000010A59C: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010A5A0: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000010A5A4: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000010A5A8: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000010A5B0: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010A5B8: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000010A5BC: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000010A5C0: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000010A5C4: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A5C8: BF870095
	.long 0xd71c0039                                           // 00000010A5CC: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000010A5D0: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000010A5D4: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000010A5D8: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A5E0: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v134, v60// 00000010A5E4: CA4672FF 38387986 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000010A5F0: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A5F4: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000010A5F8: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 00000010A600: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A604: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000010A608: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000010A610: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 00000010A614: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A61C: BF870091
	v_mul_f32_e32 v64, v60, v59                                // 00000010A620: 1080773C
	v_fma_f32 v65, -v58, v64, v60                              // 00000010A624: D6130041 24F2813A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A62C: BF870091
	v_fmac_f32_e32 v64, v65, v59                               // 00000010A630: 56807741
	v_fma_f32 v58, -v58, v64, v60                              // 00000010A634: D613003A 24F2813A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A63C: BF870091
	v_div_fmas_f32 v58, v58, v59, v64                          // 00000010A640: D637003A 0502773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000010A648: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v123, v[128:129]     // 00000010A650: D6FF7C38 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A65C: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 00000010A660: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000010A668: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000010A674: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010A67C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000010A680: BE882005
	s_cbranch_execz 60897                                      // 00000010A684: BFA5EDE1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x410c>
	v_mad_i64_i32 v[56:57], null, 0x6000, v124, v[130:131]     // 00000010A688: D6FF7C38 060AF8FF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000010A694: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000010A69C: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000010A6A0: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A6A4: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000010A6A8: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000010A6B0: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000010A6BC: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010A6C0: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000010A6C4: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000010A6C8: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000010A6D0: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010A6D8: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000010A6DC: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000010A6E0: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000010A6E4: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A6E8: BF870095
	.long 0xd71c0039                                           // 00000010A6EC: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000010A6F0: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000010A6F4: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000010A6F8: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A700: BF870092
	v_cndmask_b32_e32 v56, 0x7f800000, v57, vcc_lo             // 00000010A704: 027072FF 7F800000
	v_dual_mul_f32 v57, v135, v61 :: v_dual_add_f32 v56, 1.0, v56// 00000010A70C: C8C87B87 393870F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A714: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000010A718: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 00000010A720: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A724: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000010A728: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000010A730: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 00000010A734: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A73C: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 00000010A740: 107A773C
	v_fma_f32 v64, -v58, v61, v60                              // 00000010A744: D6130040 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A74C: BF870091
	v_fmac_f32_e32 v61, v64, v59                               // 00000010A750: 567A7740
	v_fma_f32 v58, -v58, v61, v60                              // 00000010A754: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A75C: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 00000010A760: D637003A 04F6773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000010A768: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v124, v[128:129]     // 00000010A770: D6FF7C38 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A77C: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 00000010A780: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000010A788: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000010A794: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010A79C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000010A7A0: BE882006
	s_cbranch_execz 60828                                      // 00000010A7A4: BFA5ED9C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4118>
	v_mad_i64_i32 v[56:57], null, 0x6000, v125, v[130:131]     // 00000010A7A8: D6FF7C38 060AFAFF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000010A7B4: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000010A7BC: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000010A7C0: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A7C4: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000010A7C8: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000010A7D0: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000010A7DC: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010A7E0: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000010A7E4: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000010A7E8: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000010A7F0: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010A7F8: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000010A7FC: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000010A800: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000010A804: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A808: BF870095
	.long 0xd71c0039                                           // 00000010A80C: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000010A810: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000010A814: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000010A818: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A820: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v132, v62// 00000010A824: CA4672FF 38387D84 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000010A830: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A834: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000010A838: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 00000010A840: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A844: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000010A848: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000010A850: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 00000010A854: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A85C: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 00000010A860: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 00000010A864: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A86C: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 00000010A870: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 00000010A874: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A87C: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 00000010A880: D637003A 04F6773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000010A888: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v125, v[128:129]     // 00000010A890: D6FF7C38 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A89C: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 00000010A8A0: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000010A8A8: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000010A8B4: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010A8BC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000010A8C0: BE882007
	s_cbranch_execz 60759                                      // 00000010A8C4: BFA5ED57 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4124>
	v_mad_i64_i32 v[56:57], null, 0x6000, v126, v[130:131]     // 00000010A8C8: D6FF7C38 060AFCFF 00006000
	global_load_u16 v56, v[56:57], off offset:768              // 00000010A8D4: DC4A0300 387C0038
	s_waitcnt vmcnt(0)                                         // 00000010A8DC: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000010A8E0: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A8E4: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000010A8E8: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000010A8F0: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000010A8FC: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010A900: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000010A904: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000010A908: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000010A910: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010A918: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000010A91C: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000010A920: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000010A924: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A928: BF870095
	.long 0xd71c0039                                           // 00000010A92C: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000010A930: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000010A934: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000010A938: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A940: BF870092
	v_dual_cndmask_b32 v56, 0x7f800000, v57 :: v_dual_mul_f32 v57, v133, v63// 00000010A944: CA4672FF 38387F85 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000010A950: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A954: BF870091
	v_div_scale_f32 v58, null, v56, v56, v57                   // 00000010A958: D6FC7C3A 04E67138
	v_rcp_f32_e32 v59, v58                                     // 00000010A960: 7E76553A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A964: BF870095
	v_fma_f32 v60, -v58, v59, 1.0                              // 00000010A968: D613003C 23CA773A
	v_fmac_f32_e32 v59, v60, v59                               // 00000010A970: 5676773C
	v_div_scale_f32 v60, vcc_lo, v57, v56, v57                 // 00000010A974: D6FC6A3C 04E67139
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A97C: BF870091
	v_mul_f32_e32 v61, v60, v59                                // 00000010A980: 107A773C
	v_fma_f32 v62, -v58, v61, v60                              // 00000010A984: D613003E 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A98C: BF870091
	v_fmac_f32_e32 v61, v62, v59                               // 00000010A990: 567A773E
	v_fma_f32 v58, -v58, v61, v60                              // 00000010A994: D613003A 24F27B3A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A99C: BF870091
	v_div_fmas_f32 v58, v58, v59, v61                          // 00000010A9A0: D637003A 04F6773A
	v_div_fixup_f32 v58, v58, v56, v57                         // 00000010A9A8: D627003A 04E6713A
	v_mad_i64_i32 v[56:57], null, 0x3000, v126, v[128:129]     // 00000010A9B0: D6FF7C38 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010A9BC: BF870092
	v_bfe_u32 v59, v58, 16, 1                                  // 00000010A9C0: D610003B 0205213A
	v_add3_u32 v58, v58, v59, 0x7fff                           // 00000010A9C8: D655003A 03FE773A 00007FFF
	global_store_d16_hi_b16 v[56:57], v58, off offset:256      // 00000010A9D4: DC960100 007C3A38
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010A9DC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000010A9E0: BE882000
	s_cbranch_execz 60690                                      // 00000010A9E4: BFA5ED12 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4130>
	v_mad_i64_i32 v[56:57], null, 0x6000, v140, v[130:131]     // 00000010A9E8: D6FF7C38 060B18FF 00006000
	v_mul_f32_e32 v48, v138, v48                               // 00000010A9F4: 1060618A
	global_load_u16 v56, v[56:57], off offset:800              // 00000010A9F8: DC4A0320 387C0038
	s_waitcnt vmcnt(0)                                         // 00000010AA00: BF8903F7
	v_lshlrev_b32_e32 v56, 16, v56                             // 00000010AA04: 30707090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AA08: BF870091
	v_mul_f32_e32 v57, 0xbfb8aa3b, v56                         // 00000010AA0C: 107270FF BFB8AA3B
	v_fma_f32 v58, 0xbfb8aa3b, v56, -v57                       // 00000010AA14: D613003A 84E670FF BFB8AA3B
	v_rndne_f32_e32 v59, v57                                   // 00000010AA20: 7E764739
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010AA24: BF870221
	v_sub_f32_e32 v57, v57, v59                                // 00000010AA28: 08727739
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v56                  // 00000010AA2C: 7C3C70FF 42CE8ED0
	v_fmamk_f32 v58, v56, 0xb2a5705f, v58                      // 00000010AA34: 58747538 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010AA3C: BF870121
	v_add_f32_e32 v57, v57, v58                                // 00000010AA40: 06727539
	v_cvt_i32_f32_e32 v58, v59                                 // 00000010AA44: 7E74113B
	v_exp_f32_e32 v57, v57                                     // 00000010AA48: 7E724B39
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AA4C: BF870095
	.long 0xd71c0039                                           // 00000010AA50: D71C0039
	v_cndmask_b32_e32 v1, v57, v58, vcc_lo                     // 00000010AA54: 02027539
	v_cndmask_b32_e32 v57, 0, v57, vcc_lo                      // 00000010AA58: 02727280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v56                  // 00000010AA5C: 7C3670FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AA64: BF870092
	v_cndmask_b32_e32 v56, 0x7f800000, v57, vcc_lo             // 00000010AA68: 027072FF 7F800000
	v_add_f32_e32 v56, 1.0, v56                                // 00000010AA70: 067070F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AA74: BF870091
	v_div_scale_f32 v57, null, v56, v56, v48                   // 00000010AA78: D6FC7C39 04C27138
	v_rcp_f32_e32 v58, v57                                     // 00000010AA80: 7E745539
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AA84: BF870095
	v_fma_f32 v59, -v57, v58, 1.0                              // 00000010AA88: D613003B 23CA7539
	v_fmac_f32_e32 v58, v59, v58                               // 00000010AA90: 5674753B
	v_div_scale_f32 v59, vcc_lo, v48, v56, v48                 // 00000010AA94: D6FC6A3B 04C27130
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AA9C: BF870091
	v_mul_f32_e32 v60, v59, v58                                // 00000010AAA0: 1078753B
	v_fma_f32 v61, -v57, v60, v59                              // 00000010AAA4: D613003D 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AAAC: BF870091
	v_fmac_f32_e32 v60, v61, v58                               // 00000010AAB0: 5678753D
	v_fma_f32 v57, -v57, v60, v59                              // 00000010AAB4: D6130039 24EE7939
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AABC: BF870091
	v_div_fmas_f32 v57, v57, v58, v60                          // 00000010AAC0: D6370039 04F27539
	v_div_fixup_f32 v48, v57, v56, v48                         // 00000010AAC8: D6270030 04C27139
	v_mad_i64_i32 v[56:57], null, 0x3000, v140, v[128:129]     // 00000010AAD0: D6FF7C38 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AADC: BF870092
	v_bfe_u32 v58, v48, 16, 1                                  // 00000010AAE0: D610003A 02052130
	v_add3_u32 v48, v48, v58, 0x7fff                           // 00000010AAE8: D6550030 03FE7530 00007FFF
	global_store_d16_hi_b16 v[56:57], v48, off offset:288      // 00000010AAF4: DC960120 007C3038
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010AAFC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000010AB00: BE882001
	s_cbranch_execz 60621                                      // 00000010AB04: BFA5ECCD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x413c>
	v_mad_i64_i32 v[56:57], null, 0x6000, v120, v[130:131]     // 00000010AB08: D6FF7C38 060AF0FF 00006000
	v_mul_f32_e32 v49, v139, v49                               // 00000010AB14: 1062638B
	global_load_u16 v48, v[56:57], off offset:800              // 00000010AB18: DC4A0320 307C0038
	s_waitcnt vmcnt(0)                                         // 00000010AB20: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000010AB24: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010AB28: BF870121
	v_mul_f32_e32 v56, 0xbfb8aa3b, v48                         // 00000010AB2C: 107060FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000010AB34: 7C3C60FF 42CE8ED0
	v_fma_f32 v57, 0xbfb8aa3b, v48, -v56                       // 00000010AB3C: D6130039 84E260FF BFB8AA3B
	v_rndne_f32_e32 v58, v56                                   // 00000010AB48: 7E744738
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010AB4C: BF870112
	v_fmamk_f32 v57, v48, 0xb2a5705f, v57                      // 00000010AB50: 58727330 B2A5705F
	v_sub_f32_e32 v56, v56, v58                                // 00000010AB58: 08707538
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010AB5C: BF870121
	v_add_f32_e32 v56, v56, v57                                // 00000010AB60: 06707338
	v_cvt_i32_f32_e32 v57, v58                                 // 00000010AB64: 7E72113A
	v_exp_f32_e32 v56, v56                                     // 00000010AB68: 7E704B38
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AB6C: BF870095
	.long 0xd71c0038                                           // 00000010AB70: D71C0038
	v_cndmask_b32_e32 v1, v56, v57, vcc_lo                     // 00000010AB74: 02027338
	v_cndmask_b32_e32 v56, 0, v56, vcc_lo                      // 00000010AB78: 02707080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000010AB7C: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AB84: BF870092
	v_cndmask_b32_e32 v48, 0x7f800000, v56, vcc_lo             // 00000010AB88: 026070FF 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000010AB90: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AB94: BF870091
	v_div_scale_f32 v56, null, v48, v48, v49                   // 00000010AB98: D6FC7C38 04C66130
	v_rcp_f32_e32 v57, v56                                     // 00000010ABA0: 7E725538
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010ABA4: BF870095
	v_fma_f32 v58, -v56, v57, 1.0                              // 00000010ABA8: D613003A 23CA7338
	v_fmac_f32_e32 v57, v58, v57                               // 00000010ABB0: 5672733A
	v_div_scale_f32 v58, vcc_lo, v49, v48, v49                 // 00000010ABB4: D6FC6A3A 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010ABBC: BF870091
	v_mul_f32_e32 v59, v58, v57                                // 00000010ABC0: 1076733A
	v_fma_f32 v60, -v56, v59, v58                              // 00000010ABC4: D613003C 24EA7738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010ABCC: BF870091
	v_fmac_f32_e32 v59, v60, v57                               // 00000010ABD0: 5676733C
	v_fma_f32 v56, -v56, v59, v58                              // 00000010ABD4: D6130038 24EA7738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010ABDC: BF870091
	v_div_fmas_f32 v56, v56, v57, v59                          // 00000010ABE0: D6370038 04EE7338
	v_div_fixup_f32 v56, v56, v48, v49                         // 00000010ABE8: D6270038 04C66138
	v_mad_i64_i32 v[48:49], null, 0x3000, v120, v[128:129]     // 00000010ABF0: D6FF7C30 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010ABFC: BF870092
	v_bfe_u32 v57, v56, 16, 1                                  // 00000010AC00: D6100039 02052138
	v_add3_u32 v56, v56, v57, 0x7fff                           // 00000010AC08: D6550038 03FE7338 00007FFF
	global_store_d16_hi_b16 v[48:49], v56, off offset:288      // 00000010AC14: DC960120 007C3830
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010AC1C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000010AC20: BE882002
	s_cbranch_execz 60552                                      // 00000010AC24: BFA5EC88 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4148>
	v_mad_i64_i32 v[48:49], null, 0x6000, v121, v[130:131]     // 00000010AC28: D6FF7C30 060AF2FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000010AC34: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000010AC3C: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000010AC40: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AC44: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000010AC48: 106260FF BFB8AA3B
	v_fma_f32 v56, 0xbfb8aa3b, v48, -v49                       // 00000010AC50: D6130038 84C660FF BFB8AA3B
	v_rndne_f32_e32 v57, v49                                   // 00000010AC5C: 7E724731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010AC60: BF870221
	v_sub_f32_e32 v49, v49, v57                                // 00000010AC64: 08627331
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000010AC68: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v56, v48, 0xb2a5705f, v56                      // 00000010AC70: 58707130 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010AC78: BF870121
	v_add_f32_e32 v49, v49, v56                                // 00000010AC7C: 06627131
	v_cvt_i32_f32_e32 v56, v57                                 // 00000010AC80: 7E701139
	v_exp_f32_e32 v49, v49                                     // 00000010AC84: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AC88: BF870095
	.long 0xd71c0031                                           // 00000010AC8C: D71C0031
	v_cndmask_b32_e32 v1, v49, v56, vcc_lo                     // 00000010AC90: 02027131
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000010AC94: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000010AC98: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010ACA0: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v136, v50// 00000010ACA4: CA4662FF 30306588 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000010ACB0: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010ACB4: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000010ACB8: D6FC7C32 04C66130
	v_rcp_f32_e32 v56, v50                                     // 00000010ACC0: 7E705532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010ACC4: BF870095
	v_fma_f32 v57, -v50, v56, 1.0                              // 00000010ACC8: D6130039 23CA7132
	v_fmac_f32_e32 v56, v57, v56                               // 00000010ACD0: 56707139
	v_div_scale_f32 v57, vcc_lo, v49, v48, v49                 // 00000010ACD4: D6FC6A39 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010ACDC: BF870091
	v_mul_f32_e32 v58, v57, v56                                // 00000010ACE0: 10747139
	v_fma_f32 v59, -v50, v58, v57                              // 00000010ACE4: D613003B 24E67532
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010ACEC: BF870091
	v_fmac_f32_e32 v58, v59, v56                               // 00000010ACF0: 5674713B
	v_fma_f32 v50, -v50, v58, v57                              // 00000010ACF4: D6130032 24E67532
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010ACFC: BF870091
	v_div_fmas_f32 v50, v50, v56, v58                          // 00000010AD00: D6370032 04EA7132
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000010AD08: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v121, v[128:129]     // 00000010AD10: D6FF7C30 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AD1C: BF870092
	v_bfe_u32 v56, v50, 16, 1                                  // 00000010AD20: D6100038 02052132
	v_add3_u32 v50, v50, v56, 0x7fff                           // 00000010AD28: D6550032 03FE7132 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000010AD34: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010AD3C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000010AD40: BE882003
	s_cbranch_execz 60483                                      // 00000010AD44: BFA5EC43 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4154>
	v_mad_i64_i32 v[48:49], null, 0x6000, v122, v[130:131]     // 00000010AD48: D6FF7C30 060AF4FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000010AD54: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000010AD5C: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000010AD60: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AD64: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000010AD68: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000010AD70: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v56, v49                                   // 00000010AD7C: 7E704731
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AD80: BF870091
	v_dual_fmamk_f32 v50, v48, 0xb2a5705f, v50 :: v_dual_sub_f32 v49, v49, v56// 00000010AD84: C88A6530 32307131 B2A5705F
	v_add_f32_e32 v49, v49, v50                                // 00000010AD90: 06626531
	v_cvt_i32_f32_e32 v50, v56                                 // 00000010AD94: 7E641138
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000010AD98: 7C3C60FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010ADA0: BF870293
	v_exp_f32_e32 v49, v49                                     // 00000010ADA4: 7E624B31
	.long 0xd71c0031                                           // 00000010ADA8: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000010ADAC: 02026531
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010ADB0: BF870121
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000010ADB4: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000010ADB8: 7C3660FF C2B17218
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v137, v51// 00000010ADC0: CA4662FF 30306789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010ADCC: BF870091
	v_add_f32_e32 v48, 1.0, v48                                // 00000010ADD0: 066060F2
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000010ADD4: D6FC7C32 04C66130
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010ADDC: BF870291
	v_rcp_f32_e32 v51, v50                                     // 00000010ADE0: 7E665532
	v_fma_f32 v56, -v50, v51, 1.0                              // 00000010ADE4: D6130038 23CA6732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000010ADEC: BF8700A1
	v_fmac_f32_e32 v51, v56, v51                               // 00000010ADF0: 56666738
	v_div_scale_f32 v56, vcc_lo, v49, v48, v49                 // 00000010ADF4: D6FC6A38 04C66131
	v_mul_f32_e32 v57, v56, v51                                // 00000010ADFC: 10726738
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AE00: BF870091
	v_fma_f32 v58, -v50, v57, v56                              // 00000010AE04: D613003A 24E27332
	v_fmac_f32_e32 v57, v58, v51                               // 00000010AE0C: 5672673A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AE10: BF870091
	v_fma_f32 v50, -v50, v57, v56                              // 00000010AE14: D6130032 24E27332
	v_div_fmas_f32 v50, v50, v51, v57                          // 00000010AE1C: D6370032 04E66732
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010AE24: BF870121
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000010AE28: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v122, v[128:129]     // 00000010AE30: D6FF7C30 0602F4FF 00003000
	v_bfe_u32 v51, v50, 16, 1                                  // 00000010AE3C: D6100033 02052132
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010AE44: BF870001
	v_add3_u32 v50, v50, v51, 0x7fff                           // 00000010AE48: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000010AE54: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010AE5C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000010AE60: BE882004
	s_cbranch_execz 60414                                      // 00000010AE64: BFA5EBFE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4160>
	v_mad_i64_i32 v[48:49], null, 0x6000, v123, v[130:131]     // 00000010AE68: D6FF7C30 060AF6FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000010AE74: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000010AE7C: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000010AE80: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AE84: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000010AE88: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000010AE90: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000010AE9C: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010AEA0: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 00000010AEA4: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000010AEA8: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 00000010AEB0: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010AEB8: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000010AEBC: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000010AEC0: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000010AEC4: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AEC8: BF870095
	.long 0xd71c0031                                           // 00000010AECC: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000010AED0: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000010AED4: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000010AED8: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AEE0: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v134, v52// 00000010AEE4: CA4662FF 30306986 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000010AEF0: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AEF4: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000010AEF8: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 00000010AF00: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AF04: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000010AF08: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000010AF10: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 00000010AF14: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AF1C: BF870091
	v_mul_f32_e32 v56, v52, v51                                // 00000010AF20: 10706734
	v_fma_f32 v57, -v50, v56, v52                              // 00000010AF24: D6130039 24D27132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AF2C: BF870091
	v_fmac_f32_e32 v56, v57, v51                               // 00000010AF30: 56706739
	v_fma_f32 v50, -v50, v56, v52                              // 00000010AF34: D6130032 24D27132
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AF3C: BF870091
	v_div_fmas_f32 v50, v50, v51, v56                          // 00000010AF40: D6370032 04E26732
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000010AF48: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v123, v[128:129]     // 00000010AF50: D6FF7C30 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AF5C: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 00000010AF60: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 00000010AF68: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000010AF74: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010AF7C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000010AF80: BE882005
	s_cbranch_execz 60345                                      // 00000010AF84: BFA5EBB9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x416c>
	v_mad_i64_i32 v[48:49], null, 0x6000, v124, v[130:131]     // 00000010AF88: D6FF7C30 060AF8FF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000010AF94: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000010AF9C: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000010AFA0: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AFA4: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000010AFA8: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000010AFB0: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000010AFBC: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010AFC0: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 00000010AFC4: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000010AFC8: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 00000010AFD0: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010AFD8: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000010AFDC: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000010AFE0: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000010AFE4: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010AFE8: BF870095
	.long 0xd71c0031                                           // 00000010AFEC: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000010AFF0: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000010AFF4: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000010AFF8: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B000: BF870092
	v_cndmask_b32_e32 v48, 0x7f800000, v49, vcc_lo             // 00000010B004: 026062FF 7F800000
	v_dual_mul_f32 v49, v135, v53 :: v_dual_add_f32 v48, 1.0, v48// 00000010B00C: C8C86B87 313060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B014: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000010B018: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 00000010B020: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B024: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000010B028: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000010B030: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 00000010B034: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B03C: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 00000010B040: 106A6734
	v_fma_f32 v56, -v50, v53, v52                              // 00000010B044: D6130038 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B04C: BF870091
	v_fmac_f32_e32 v53, v56, v51                               // 00000010B050: 566A6738
	v_fma_f32 v50, -v50, v53, v52                              // 00000010B054: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B05C: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 00000010B060: D6370032 04D66732
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000010B068: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v124, v[128:129]     // 00000010B070: D6FF7C30 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B07C: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 00000010B080: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 00000010B088: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000010B094: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010B09C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000010B0A0: BE882006
	s_cbranch_execz 60276                                      // 00000010B0A4: BFA5EB74 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4178>
	v_mad_i64_i32 v[48:49], null, 0x6000, v125, v[130:131]     // 00000010B0A8: D6FF7C30 060AFAFF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000010B0B4: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000010B0BC: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000010B0C0: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B0C4: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000010B0C8: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000010B0D0: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000010B0DC: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010B0E0: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 00000010B0E4: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000010B0E8: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 00000010B0F0: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010B0F8: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000010B0FC: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000010B100: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000010B104: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B108: BF870095
	.long 0xd71c0031                                           // 00000010B10C: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000010B110: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000010B114: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000010B118: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B120: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v132, v54// 00000010B124: CA4662FF 30306D84 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000010B130: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B134: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000010B138: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 00000010B140: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B144: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000010B148: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000010B150: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 00000010B154: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B15C: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 00000010B160: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 00000010B164: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B16C: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 00000010B170: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 00000010B174: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B17C: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 00000010B180: D6370032 04D66732
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000010B188: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v125, v[128:129]     // 00000010B190: D6FF7C30 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B19C: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 00000010B1A0: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 00000010B1A8: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000010B1B4: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010B1BC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000010B1C0: BE882007
	s_cbranch_execz 60207                                      // 00000010B1C4: BFA5EB2F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4184>
	v_mad_i64_i32 v[48:49], null, 0x6000, v126, v[130:131]     // 00000010B1C8: D6FF7C30 060AFCFF 00006000
	global_load_u16 v48, v[48:49], off offset:800              // 00000010B1D4: DC4A0320 307C0030
	s_waitcnt vmcnt(0)                                         // 00000010B1DC: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000010B1E0: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B1E4: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000010B1E8: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000010B1F0: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000010B1FC: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010B200: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 00000010B204: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000010B208: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 00000010B210: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010B218: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000010B21C: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000010B220: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000010B224: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B228: BF870095
	.long 0xd71c0031                                           // 00000010B22C: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000010B230: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000010B234: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000010B238: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B240: BF870092
	v_dual_cndmask_b32 v48, 0x7f800000, v49 :: v_dual_mul_f32 v49, v133, v55// 00000010B244: CA4662FF 30306F85 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000010B250: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B254: BF870091
	v_div_scale_f32 v50, null, v48, v48, v49                   // 00000010B258: D6FC7C32 04C66130
	v_rcp_f32_e32 v51, v50                                     // 00000010B260: 7E665532
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B264: BF870095
	v_fma_f32 v52, -v50, v51, 1.0                              // 00000010B268: D6130034 23CA6732
	v_fmac_f32_e32 v51, v52, v51                               // 00000010B270: 56666734
	v_div_scale_f32 v52, vcc_lo, v49, v48, v49                 // 00000010B274: D6FC6A34 04C66131
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B27C: BF870091
	v_mul_f32_e32 v53, v52, v51                                // 00000010B280: 106A6734
	v_fma_f32 v54, -v50, v53, v52                              // 00000010B284: D6130036 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B28C: BF870091
	v_fmac_f32_e32 v53, v54, v51                               // 00000010B290: 566A6736
	v_fma_f32 v50, -v50, v53, v52                              // 00000010B294: D6130032 24D26B32
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B29C: BF870091
	v_div_fmas_f32 v50, v50, v51, v53                          // 00000010B2A0: D6370032 04D66732
	v_div_fixup_f32 v50, v50, v48, v49                         // 00000010B2A8: D6270032 04C66132
	v_mad_i64_i32 v[48:49], null, 0x3000, v126, v[128:129]     // 00000010B2B0: D6FF7C30 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B2BC: BF870092
	v_bfe_u32 v51, v50, 16, 1                                  // 00000010B2C0: D6100033 02052132
	v_add3_u32 v50, v50, v51, 0x7fff                           // 00000010B2C8: D6550032 03FE6732 00007FFF
	global_store_d16_hi_b16 v[48:49], v50, off offset:288      // 00000010B2D4: DC960120 007C3230
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010B2DC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000010B2E0: BE882000
	s_cbranch_execz 60138                                      // 00000010B2E4: BFA5EAEA <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4190>
	v_mad_i64_i32 v[48:49], null, 0x6000, v140, v[130:131]     // 00000010B2E8: D6FF7C30 060B18FF 00006000
	v_mul_f32_e32 v40, v138, v40                               // 00000010B2F4: 1050518A
	global_load_u16 v48, v[48:49], off offset:832              // 00000010B2F8: DC4A0340 307C0030
	s_waitcnt vmcnt(0)                                         // 00000010B300: BF8903F7
	v_lshlrev_b32_e32 v48, 16, v48                             // 00000010B304: 30606090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B308: BF870091
	v_mul_f32_e32 v49, 0xbfb8aa3b, v48                         // 00000010B30C: 106260FF BFB8AA3B
	v_fma_f32 v50, 0xbfb8aa3b, v48, -v49                       // 00000010B314: D6130032 84C660FF BFB8AA3B
	v_rndne_f32_e32 v51, v49                                   // 00000010B320: 7E664731
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010B324: BF870221
	v_sub_f32_e32 v49, v49, v51                                // 00000010B328: 08626731
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v48                  // 00000010B32C: 7C3C60FF 42CE8ED0
	v_fmamk_f32 v50, v48, 0xb2a5705f, v50                      // 00000010B334: 58646530 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010B33C: BF870121
	v_add_f32_e32 v49, v49, v50                                // 00000010B340: 06626531
	v_cvt_i32_f32_e32 v50, v51                                 // 00000010B344: 7E641133
	v_exp_f32_e32 v49, v49                                     // 00000010B348: 7E624B31
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B34C: BF870095
	.long 0xd71c0031                                           // 00000010B350: D71C0031
	v_cndmask_b32_e32 v1, v49, v50, vcc_lo                     // 00000010B354: 02026531
	v_cndmask_b32_e32 v49, 0, v49, vcc_lo                      // 00000010B358: 02626280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v48                  // 00000010B35C: 7C3660FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B364: BF870092
	v_cndmask_b32_e32 v48, 0x7f800000, v49, vcc_lo             // 00000010B368: 026062FF 7F800000
	v_add_f32_e32 v48, 1.0, v48                                // 00000010B370: 066060F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B374: BF870091
	v_div_scale_f32 v49, null, v48, v48, v40                   // 00000010B378: D6FC7C31 04A26130
	v_rcp_f32_e32 v50, v49                                     // 00000010B380: 7E645531
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B384: BF870095
	v_fma_f32 v51, -v49, v50, 1.0                              // 00000010B388: D6130033 23CA6531
	v_fmac_f32_e32 v50, v51, v50                               // 00000010B390: 56646533
	v_div_scale_f32 v51, vcc_lo, v40, v48, v40                 // 00000010B394: D6FC6A33 04A26128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B39C: BF870091
	v_mul_f32_e32 v52, v51, v50                                // 00000010B3A0: 10686533
	v_fma_f32 v53, -v49, v52, v51                              // 00000010B3A4: D6130035 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B3AC: BF870091
	v_fmac_f32_e32 v52, v53, v50                               // 00000010B3B0: 56686535
	v_fma_f32 v49, -v49, v52, v51                              // 00000010B3B4: D6130031 24CE6931
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B3BC: BF870091
	v_div_fmas_f32 v49, v49, v50, v52                          // 00000010B3C0: D6370031 04D26531
	v_div_fixup_f32 v40, v49, v48, v40                         // 00000010B3C8: D6270028 04A26131
	v_mad_i64_i32 v[48:49], null, 0x3000, v140, v[128:129]     // 00000010B3D0: D6FF7C30 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B3DC: BF870092
	v_bfe_u32 v50, v40, 16, 1                                  // 00000010B3E0: D6100032 02052128
	v_add3_u32 v40, v40, v50, 0x7fff                           // 00000010B3E8: D6550028 03FE6528 00007FFF
	global_store_d16_hi_b16 v[48:49], v40, off offset:320      // 00000010B3F4: DC960140 007C2830
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010B3FC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000010B400: BE882001
	s_cbranch_execz 60069                                      // 00000010B404: BFA5EAA5 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x419c>
	v_mad_i64_i32 v[48:49], null, 0x6000, v120, v[130:131]     // 00000010B408: D6FF7C30 060AF0FF 00006000
	v_mul_f32_e32 v41, v139, v41                               // 00000010B414: 1052538B
	global_load_u16 v40, v[48:49], off offset:832              // 00000010B418: DC4A0340 287C0030
	s_waitcnt vmcnt(0)                                         // 00000010B420: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000010B424: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010B428: BF870121
	v_mul_f32_e32 v48, 0xbfb8aa3b, v40                         // 00000010B42C: 106050FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000010B434: 7C3C50FF 42CE8ED0
	v_fma_f32 v49, 0xbfb8aa3b, v40, -v48                       // 00000010B43C: D6130031 84C250FF BFB8AA3B
	v_rndne_f32_e32 v50, v48                                   // 00000010B448: 7E644730
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010B44C: BF870112
	v_fmamk_f32 v49, v40, 0xb2a5705f, v49                      // 00000010B450: 58626328 B2A5705F
	v_sub_f32_e32 v48, v48, v50                                // 00000010B458: 08606530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010B45C: BF870121
	v_add_f32_e32 v48, v48, v49                                // 00000010B460: 06606330
	v_cvt_i32_f32_e32 v49, v50                                 // 00000010B464: 7E621132
	v_exp_f32_e32 v48, v48                                     // 00000010B468: 7E604B30
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B46C: BF870095
	.long 0xd71c0030                                           // 00000010B470: D71C0030
	v_cndmask_b32_e32 v1, v48, v49, vcc_lo                     // 00000010B474: 02026330
	v_cndmask_b32_e32 v48, 0, v48, vcc_lo                      // 00000010B478: 02606080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000010B47C: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B484: BF870092
	v_cndmask_b32_e32 v40, 0x7f800000, v48, vcc_lo             // 00000010B488: 025060FF 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000010B490: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B494: BF870091
	v_div_scale_f32 v48, null, v40, v40, v41                   // 00000010B498: D6FC7C30 04A65128
	v_rcp_f32_e32 v49, v48                                     // 00000010B4A0: 7E625530
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B4A4: BF870095
	v_fma_f32 v50, -v48, v49, 1.0                              // 00000010B4A8: D6130032 23CA6330
	v_fmac_f32_e32 v49, v50, v49                               // 00000010B4B0: 56626332
	v_div_scale_f32 v50, vcc_lo, v41, v40, v41                 // 00000010B4B4: D6FC6A32 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B4BC: BF870091
	v_mul_f32_e32 v51, v50, v49                                // 00000010B4C0: 10666332
	v_fma_f32 v52, -v48, v51, v50                              // 00000010B4C4: D6130034 24CA6730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B4CC: BF870091
	v_fmac_f32_e32 v51, v52, v49                               // 00000010B4D0: 56666334
	v_fma_f32 v48, -v48, v51, v50                              // 00000010B4D4: D6130030 24CA6730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B4DC: BF870091
	v_div_fmas_f32 v48, v48, v49, v51                          // 00000010B4E0: D6370030 04CE6330
	v_div_fixup_f32 v48, v48, v40, v41                         // 00000010B4E8: D6270030 04A65130
	v_mad_i64_i32 v[40:41], null, 0x3000, v120, v[128:129]     // 00000010B4F0: D6FF7C28 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B4FC: BF870092
	v_bfe_u32 v49, v48, 16, 1                                  // 00000010B500: D6100031 02052130
	v_add3_u32 v48, v48, v49, 0x7fff                           // 00000010B508: D6550030 03FE6330 00007FFF
	global_store_d16_hi_b16 v[40:41], v48, off offset:320      // 00000010B514: DC960140 007C3028
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010B51C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000010B520: BE882002
	s_cbranch_execz 60000                                      // 00000010B524: BFA5EA60 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41a8>
	v_mad_i64_i32 v[40:41], null, 0x6000, v121, v[130:131]     // 00000010B528: D6FF7C28 060AF2FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 00000010B534: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 00000010B53C: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000010B540: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B544: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 00000010B548: 105250FF BFB8AA3B
	v_fma_f32 v48, 0xbfb8aa3b, v40, -v41                       // 00000010B550: D6130030 84A650FF BFB8AA3B
	v_rndne_f32_e32 v49, v41                                   // 00000010B55C: 7E624729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010B560: BF870221
	v_sub_f32_e32 v41, v41, v49                                // 00000010B564: 08526329
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000010B568: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v48, v40, 0xb2a5705f, v48                      // 00000010B570: 58606128 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010B578: BF870121
	v_add_f32_e32 v41, v41, v48                                // 00000010B57C: 06526129
	v_cvt_i32_f32_e32 v48, v49                                 // 00000010B580: 7E601131
	v_exp_f32_e32 v41, v41                                     // 00000010B584: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B588: BF870095
	.long 0xd71c0029                                           // 00000010B58C: D71C0029
	v_cndmask_b32_e32 v1, v41, v48, vcc_lo                     // 00000010B590: 02026129
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000010B594: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000010B598: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B5A0: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v136, v42// 00000010B5A4: CA4652FF 28285588 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000010B5B0: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B5B4: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 00000010B5B8: D6FC7C2A 04A65128
	v_rcp_f32_e32 v48, v42                                     // 00000010B5C0: 7E60552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B5C4: BF870095
	v_fma_f32 v49, -v42, v48, 1.0                              // 00000010B5C8: D6130031 23CA612A
	v_fmac_f32_e32 v48, v49, v48                               // 00000010B5D0: 56606131
	v_div_scale_f32 v49, vcc_lo, v41, v40, v41                 // 00000010B5D4: D6FC6A31 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B5DC: BF870091
	v_mul_f32_e32 v50, v49, v48                                // 00000010B5E0: 10646131
	v_fma_f32 v51, -v42, v50, v49                              // 00000010B5E4: D6130033 24C6652A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B5EC: BF870091
	v_fmac_f32_e32 v50, v51, v48                               // 00000010B5F0: 56646133
	v_fma_f32 v42, -v42, v50, v49                              // 00000010B5F4: D613002A 24C6652A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B5FC: BF870091
	v_div_fmas_f32 v42, v42, v48, v50                          // 00000010B600: D637002A 04CA612A
	v_div_fixup_f32 v42, v42, v40, v41                         // 00000010B608: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v121, v[128:129]     // 00000010B610: D6FF7C28 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B61C: BF870092
	v_bfe_u32 v48, v42, 16, 1                                  // 00000010B620: D6100030 0205212A
	v_add3_u32 v42, v42, v48, 0x7fff                           // 00000010B628: D655002A 03FE612A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 00000010B634: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010B63C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000010B640: BE882003
	s_cbranch_execz 59931                                      // 00000010B644: BFA5EA1B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41b4>
	v_mad_i64_i32 v[40:41], null, 0x6000, v122, v[130:131]     // 00000010B648: D6FF7C28 060AF4FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 00000010B654: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 00000010B65C: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000010B660: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B664: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 00000010B668: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 00000010B670: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v48, v41                                   // 00000010B67C: 7E604729
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B680: BF870091
	v_dual_fmamk_f32 v42, v40, 0xb2a5705f, v42 :: v_dual_sub_f32 v41, v41, v48// 00000010B684: C88A5528 2A286129 B2A5705F
	v_add_f32_e32 v41, v41, v42                                // 00000010B690: 06525529
	v_cvt_i32_f32_e32 v42, v48                                 // 00000010B694: 7E541130
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000010B698: 7C3C50FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010B6A0: BF870293
	v_exp_f32_e32 v41, v41                                     // 00000010B6A4: 7E524B29
	.long 0xd71c0029                                           // 00000010B6A8: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000010B6AC: 02025529
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010B6B0: BF870121
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000010B6B4: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000010B6B8: 7C3650FF C2B17218
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v137, v43// 00000010B6C0: CA4652FF 28285789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B6CC: BF870091
	v_add_f32_e32 v40, 1.0, v40                                // 00000010B6D0: 065050F2
	v_div_scale_f32 v42, null, v40, v40, v41                   // 00000010B6D4: D6FC7C2A 04A65128
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010B6DC: BF870291
	v_rcp_f32_e32 v43, v42                                     // 00000010B6E0: 7E56552A
	v_fma_f32 v48, -v42, v43, 1.0                              // 00000010B6E4: D6130030 23CA572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000010B6EC: BF8700A1
	v_fmac_f32_e32 v43, v48, v43                               // 00000010B6F0: 56565730
	v_div_scale_f32 v48, vcc_lo, v41, v40, v41                 // 00000010B6F4: D6FC6A30 04A65129
	v_mul_f32_e32 v49, v48, v43                                // 00000010B6FC: 10625730
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B700: BF870091
	v_fma_f32 v50, -v42, v49, v48                              // 00000010B704: D6130032 24C2632A
	v_fmac_f32_e32 v49, v50, v43                               // 00000010B70C: 56625732
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B710: BF870091
	v_fma_f32 v42, -v42, v49, v48                              // 00000010B714: D613002A 24C2632A
	v_div_fmas_f32 v42, v42, v43, v49                          // 00000010B71C: D637002A 04C6572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010B724: BF870121
	v_div_fixup_f32 v42, v42, v40, v41                         // 00000010B728: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v122, v[128:129]     // 00000010B730: D6FF7C28 0602F4FF 00003000
	v_bfe_u32 v43, v42, 16, 1                                  // 00000010B73C: D610002B 0205212A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010B744: BF870001
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000010B748: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 00000010B754: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010B75C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000010B760: BE882004
	s_cbranch_execz 59862                                      // 00000010B764: BFA5E9D6 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41c0>
	v_mad_i64_i32 v[40:41], null, 0x6000, v123, v[130:131]     // 00000010B768: D6FF7C28 060AF6FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 00000010B774: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 00000010B77C: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000010B780: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B784: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 00000010B788: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 00000010B790: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000010B79C: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010B7A0: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 00000010B7A4: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000010B7A8: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 00000010B7B0: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010B7B8: BF870121
	v_add_f32_e32 v41, v41, v42                                // 00000010B7BC: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000010B7C0: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000010B7C4: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B7C8: BF870095
	.long 0xd71c0029                                           // 00000010B7CC: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000010B7D0: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000010B7D4: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000010B7D8: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B7E0: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v134, v44// 00000010B7E4: CA4652FF 28285986 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000010B7F0: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B7F4: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 00000010B7F8: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 00000010B800: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B804: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 00000010B808: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000010B810: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 00000010B814: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B81C: BF870091
	v_mul_f32_e32 v48, v44, v43                                // 00000010B820: 1060572C
	v_fma_f32 v49, -v42, v48, v44                              // 00000010B824: D6130031 24B2612A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B82C: BF870091
	v_fmac_f32_e32 v48, v49, v43                               // 00000010B830: 56605731
	v_fma_f32 v42, -v42, v48, v44                              // 00000010B834: D613002A 24B2612A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B83C: BF870091
	v_div_fmas_f32 v42, v42, v43, v48                          // 00000010B840: D637002A 04C2572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 00000010B848: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v123, v[128:129]     // 00000010B850: D6FF7C28 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B85C: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 00000010B860: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000010B868: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 00000010B874: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010B87C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000010B880: BE882005
	s_cbranch_execz 59793                                      // 00000010B884: BFA5E991 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41cc>
	v_mad_i64_i32 v[40:41], null, 0x6000, v124, v[130:131]     // 00000010B888: D6FF7C28 060AF8FF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 00000010B894: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 00000010B89C: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000010B8A0: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B8A4: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 00000010B8A8: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 00000010B8B0: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000010B8BC: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010B8C0: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 00000010B8C4: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000010B8C8: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 00000010B8D0: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010B8D8: BF870121
	v_add_f32_e32 v41, v41, v42                                // 00000010B8DC: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000010B8E0: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000010B8E4: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B8E8: BF870095
	.long 0xd71c0029                                           // 00000010B8EC: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000010B8F0: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000010B8F4: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000010B8F8: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B900: BF870092
	v_cndmask_b32_e32 v40, 0x7f800000, v41, vcc_lo             // 00000010B904: 025052FF 7F800000
	v_dual_mul_f32 v41, v135, v45 :: v_dual_add_f32 v40, 1.0, v40// 00000010B90C: C8C85B87 292850F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B914: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 00000010B918: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 00000010B920: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B924: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 00000010B928: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000010B930: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 00000010B934: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B93C: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 00000010B940: 105A572C
	v_fma_f32 v48, -v42, v45, v44                              // 00000010B944: D6130030 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B94C: BF870091
	v_fmac_f32_e32 v45, v48, v43                               // 00000010B950: 565A5730
	v_fma_f32 v42, -v42, v45, v44                              // 00000010B954: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B95C: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 00000010B960: D637002A 04B6572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 00000010B968: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v124, v[128:129]     // 00000010B970: D6FF7C28 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B97C: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 00000010B980: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000010B988: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 00000010B994: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010B99C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000010B9A0: BE882006
	s_cbranch_execz 59724                                      // 00000010B9A4: BFA5E94C <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41d8>
	v_mad_i64_i32 v[40:41], null, 0x6000, v125, v[130:131]     // 00000010B9A8: D6FF7C28 060AFAFF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 00000010B9B4: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 00000010B9BC: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000010B9C0: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010B9C4: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 00000010B9C8: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 00000010B9D0: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000010B9DC: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010B9E0: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 00000010B9E4: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000010B9E8: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 00000010B9F0: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010B9F8: BF870121
	v_add_f32_e32 v41, v41, v42                                // 00000010B9FC: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000010BA00: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000010BA04: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BA08: BF870095
	.long 0xd71c0029                                           // 00000010BA0C: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000010BA10: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000010BA14: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000010BA18: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BA20: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v132, v46// 00000010BA24: CA4652FF 28285D84 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000010BA30: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BA34: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 00000010BA38: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 00000010BA40: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BA44: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 00000010BA48: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000010BA50: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 00000010BA54: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BA5C: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 00000010BA60: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 00000010BA64: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BA6C: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 00000010BA70: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 00000010BA74: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BA7C: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 00000010BA80: D637002A 04B6572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 00000010BA88: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v125, v[128:129]     // 00000010BA90: D6FF7C28 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BA9C: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 00000010BAA0: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000010BAA8: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 00000010BAB4: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010BABC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000010BAC0: BE882007
	s_cbranch_execz 59655                                      // 00000010BAC4: BFA5E907 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41e4>
	v_mad_i64_i32 v[40:41], null, 0x6000, v126, v[130:131]     // 00000010BAC8: D6FF7C28 060AFCFF 00006000
	global_load_u16 v40, v[40:41], off offset:832              // 00000010BAD4: DC4A0340 287C0028
	s_waitcnt vmcnt(0)                                         // 00000010BADC: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000010BAE0: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BAE4: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 00000010BAE8: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 00000010BAF0: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000010BAFC: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010BB00: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 00000010BB04: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000010BB08: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 00000010BB10: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010BB18: BF870121
	v_add_f32_e32 v41, v41, v42                                // 00000010BB1C: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000010BB20: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000010BB24: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BB28: BF870095
	.long 0xd71c0029                                           // 00000010BB2C: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000010BB30: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000010BB34: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000010BB38: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BB40: BF870092
	v_dual_cndmask_b32 v40, 0x7f800000, v41 :: v_dual_mul_f32 v41, v133, v47// 00000010BB44: CA4652FF 28285F85 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000010BB50: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BB54: BF870091
	v_div_scale_f32 v42, null, v40, v40, v41                   // 00000010BB58: D6FC7C2A 04A65128
	v_rcp_f32_e32 v43, v42                                     // 00000010BB60: 7E56552A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BB64: BF870095
	v_fma_f32 v44, -v42, v43, 1.0                              // 00000010BB68: D613002C 23CA572A
	v_fmac_f32_e32 v43, v44, v43                               // 00000010BB70: 5656572C
	v_div_scale_f32 v44, vcc_lo, v41, v40, v41                 // 00000010BB74: D6FC6A2C 04A65129
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BB7C: BF870091
	v_mul_f32_e32 v45, v44, v43                                // 00000010BB80: 105A572C
	v_fma_f32 v46, -v42, v45, v44                              // 00000010BB84: D613002E 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BB8C: BF870091
	v_fmac_f32_e32 v45, v46, v43                               // 00000010BB90: 565A572E
	v_fma_f32 v42, -v42, v45, v44                              // 00000010BB94: D613002A 24B25B2A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BB9C: BF870091
	v_div_fmas_f32 v42, v42, v43, v45                          // 00000010BBA0: D637002A 04B6572A
	v_div_fixup_f32 v42, v42, v40, v41                         // 00000010BBA8: D627002A 04A6512A
	v_mad_i64_i32 v[40:41], null, 0x3000, v126, v[128:129]     // 00000010BBB0: D6FF7C28 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BBBC: BF870092
	v_bfe_u32 v43, v42, 16, 1                                  // 00000010BBC0: D610002B 0205212A
	v_add3_u32 v42, v42, v43, 0x7fff                           // 00000010BBC8: D655002A 03FE572A 00007FFF
	global_store_d16_hi_b16 v[40:41], v42, off offset:320      // 00000010BBD4: DC960140 007C2A28
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010BBDC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000010BBE0: BE882000
	s_cbranch_execz 59586                                      // 00000010BBE4: BFA5E8C2 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41f0>
	v_mad_i64_i32 v[40:41], null, 0x6000, v140, v[130:131]     // 00000010BBE8: D6FF7C28 060B18FF 00006000
	v_mul_f32_e32 v32, v138, v32                               // 00000010BBF4: 1040418A
	global_load_u16 v40, v[40:41], off offset:864              // 00000010BBF8: DC4A0360 287C0028
	s_waitcnt vmcnt(0)                                         // 00000010BC00: BF8903F7
	v_lshlrev_b32_e32 v40, 16, v40                             // 00000010BC04: 30505090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BC08: BF870091
	v_mul_f32_e32 v41, 0xbfb8aa3b, v40                         // 00000010BC0C: 105250FF BFB8AA3B
	v_fma_f32 v42, 0xbfb8aa3b, v40, -v41                       // 00000010BC14: D613002A 84A650FF BFB8AA3B
	v_rndne_f32_e32 v43, v41                                   // 00000010BC20: 7E564729
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010BC24: BF870221
	v_sub_f32_e32 v41, v41, v43                                // 00000010BC28: 08525729
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v40                  // 00000010BC2C: 7C3C50FF 42CE8ED0
	v_fmamk_f32 v42, v40, 0xb2a5705f, v42                      // 00000010BC34: 58545528 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010BC3C: BF870121
	v_add_f32_e32 v41, v41, v42                                // 00000010BC40: 06525529
	v_cvt_i32_f32_e32 v42, v43                                 // 00000010BC44: 7E54112B
	v_exp_f32_e32 v41, v41                                     // 00000010BC48: 7E524B29
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BC4C: BF870095
	.long 0xd71c0029                                           // 00000010BC50: D71C0029
	v_cndmask_b32_e32 v1, v41, v42, vcc_lo                     // 00000010BC54: 02025529
	v_cndmask_b32_e32 v41, 0, v41, vcc_lo                      // 00000010BC58: 02525280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v40                  // 00000010BC5C: 7C3650FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BC64: BF870092
	v_cndmask_b32_e32 v40, 0x7f800000, v41, vcc_lo             // 00000010BC68: 025052FF 7F800000
	v_add_f32_e32 v40, 1.0, v40                                // 00000010BC70: 065050F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BC74: BF870091
	v_div_scale_f32 v41, null, v40, v40, v32                   // 00000010BC78: D6FC7C29 04825128
	v_rcp_f32_e32 v42, v41                                     // 00000010BC80: 7E545529
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BC84: BF870095
	v_fma_f32 v43, -v41, v42, 1.0                              // 00000010BC88: D613002B 23CA5529
	v_fmac_f32_e32 v42, v43, v42                               // 00000010BC90: 5654552B
	v_div_scale_f32 v43, vcc_lo, v32, v40, v32                 // 00000010BC94: D6FC6A2B 04825120
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BC9C: BF870091
	v_mul_f32_e32 v44, v43, v42                                // 00000010BCA0: 1058552B
	v_fma_f32 v45, -v41, v44, v43                              // 00000010BCA4: D613002D 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BCAC: BF870091
	v_fmac_f32_e32 v44, v45, v42                               // 00000010BCB0: 5658552D
	v_fma_f32 v41, -v41, v44, v43                              // 00000010BCB4: D6130029 24AE5929
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BCBC: BF870091
	v_div_fmas_f32 v41, v41, v42, v44                          // 00000010BCC0: D6370029 04B25529
	v_div_fixup_f32 v32, v41, v40, v32                         // 00000010BCC8: D6270020 04825129
	v_mad_i64_i32 v[40:41], null, 0x3000, v140, v[128:129]     // 00000010BCD0: D6FF7C28 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BCDC: BF870092
	v_bfe_u32 v42, v32, 16, 1                                  // 00000010BCE0: D610002A 02052120
	v_add3_u32 v32, v32, v42, 0x7fff                           // 00000010BCE8: D6550020 03FE5520 00007FFF
	global_store_d16_hi_b16 v[40:41], v32, off offset:352      // 00000010BCF4: DC960160 007C2028
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010BCFC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000010BD00: BE882001
	s_cbranch_execz 59517                                      // 00000010BD04: BFA5E87D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x41fc>
	v_mad_i64_i32 v[40:41], null, 0x6000, v120, v[130:131]     // 00000010BD08: D6FF7C28 060AF0FF 00006000
	v_mul_f32_e32 v33, v139, v33                               // 00000010BD14: 1042438B
	global_load_u16 v32, v[40:41], off offset:864              // 00000010BD18: DC4A0360 207C0028
	s_waitcnt vmcnt(0)                                         // 00000010BD20: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000010BD24: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010BD28: BF870121
	v_mul_f32_e32 v40, 0xbfb8aa3b, v32                         // 00000010BD2C: 105040FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000010BD34: 7C3C40FF 42CE8ED0
	v_fma_f32 v41, 0xbfb8aa3b, v32, -v40                       // 00000010BD3C: D6130029 84A240FF BFB8AA3B
	v_rndne_f32_e32 v42, v40                                   // 00000010BD48: 7E544728
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010BD4C: BF870112
	v_fmamk_f32 v41, v32, 0xb2a5705f, v41                      // 00000010BD50: 58525320 B2A5705F
	v_sub_f32_e32 v40, v40, v42                                // 00000010BD58: 08505528
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010BD5C: BF870121
	v_add_f32_e32 v40, v40, v41                                // 00000010BD60: 06505328
	v_cvt_i32_f32_e32 v41, v42                                 // 00000010BD64: 7E52112A
	v_exp_f32_e32 v40, v40                                     // 00000010BD68: 7E504B28
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BD6C: BF870095
	.long 0xd71c0028                                           // 00000010BD70: D71C0028
	v_cndmask_b32_e32 v1, v40, v41, vcc_lo                     // 00000010BD74: 02025328
	v_cndmask_b32_e32 v40, 0, v40, vcc_lo                      // 00000010BD78: 02505080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000010BD7C: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BD84: BF870092
	v_cndmask_b32_e32 v32, 0x7f800000, v40, vcc_lo             // 00000010BD88: 024050FF 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 00000010BD90: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BD94: BF870091
	v_div_scale_f32 v40, null, v32, v32, v33                   // 00000010BD98: D6FC7C28 04864120
	v_rcp_f32_e32 v41, v40                                     // 00000010BDA0: 7E525528
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BDA4: BF870095
	v_fma_f32 v42, -v40, v41, 1.0                              // 00000010BDA8: D613002A 23CA5328
	v_fmac_f32_e32 v41, v42, v41                               // 00000010BDB0: 5652532A
	v_div_scale_f32 v42, vcc_lo, v33, v32, v33                 // 00000010BDB4: D6FC6A2A 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BDBC: BF870091
	v_mul_f32_e32 v43, v42, v41                                // 00000010BDC0: 1056532A
	v_fma_f32 v44, -v40, v43, v42                              // 00000010BDC4: D613002C 24AA5728
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BDCC: BF870091
	v_fmac_f32_e32 v43, v44, v41                               // 00000010BDD0: 5656532C
	v_fma_f32 v40, -v40, v43, v42                              // 00000010BDD4: D6130028 24AA5728
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BDDC: BF870091
	v_div_fmas_f32 v40, v40, v41, v43                          // 00000010BDE0: D6370028 04AE5328
	v_div_fixup_f32 v40, v40, v32, v33                         // 00000010BDE8: D6270028 04864128
	v_mad_i64_i32 v[32:33], null, 0x3000, v120, v[128:129]     // 00000010BDF0: D6FF7C20 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BDFC: BF870092
	v_bfe_u32 v41, v40, 16, 1                                  // 00000010BE00: D6100029 02052128
	v_add3_u32 v40, v40, v41, 0x7fff                           // 00000010BE08: D6550028 03FE5328 00007FFF
	global_store_d16_hi_b16 v[32:33], v40, off offset:352      // 00000010BE14: DC960160 007C2820
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010BE1C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000010BE20: BE882002
	s_cbranch_execz 59448                                      // 00000010BE24: BFA5E838 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4208>
	v_mad_i64_i32 v[32:33], null, 0x6000, v121, v[130:131]     // 00000010BE28: D6FF7C20 060AF2FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 00000010BE34: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 00000010BE3C: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000010BE40: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BE44: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 00000010BE48: 104240FF BFB8AA3B
	v_fma_f32 v40, 0xbfb8aa3b, v32, -v33                       // 00000010BE50: D6130028 848640FF BFB8AA3B
	v_rndne_f32_e32 v41, v33                                   // 00000010BE5C: 7E524721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010BE60: BF870221
	v_sub_f32_e32 v33, v33, v41                                // 00000010BE64: 08425321
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000010BE68: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v40, v32, 0xb2a5705f, v40                      // 00000010BE70: 58505120 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010BE78: BF870121
	v_add_f32_e32 v33, v33, v40                                // 00000010BE7C: 06425121
	v_cvt_i32_f32_e32 v40, v41                                 // 00000010BE80: 7E501129
	v_exp_f32_e32 v33, v33                                     // 00000010BE84: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BE88: BF870095
	.long 0xd71c0021                                           // 00000010BE8C: D71C0021
	v_cndmask_b32_e32 v1, v33, v40, vcc_lo                     // 00000010BE90: 02025121
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000010BE94: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000010BE98: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BEA0: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v136, v34// 00000010BEA4: CA4642FF 20204588 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 00000010BEB0: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BEB4: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 00000010BEB8: D6FC7C22 04864120
	v_rcp_f32_e32 v40, v34                                     // 00000010BEC0: 7E505522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BEC4: BF870095
	v_fma_f32 v41, -v34, v40, 1.0                              // 00000010BEC8: D6130029 23CA5122
	v_fmac_f32_e32 v40, v41, v40                               // 00000010BED0: 56505129
	v_div_scale_f32 v41, vcc_lo, v33, v32, v33                 // 00000010BED4: D6FC6A29 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BEDC: BF870091
	v_mul_f32_e32 v42, v41, v40                                // 00000010BEE0: 10545129
	v_fma_f32 v43, -v34, v42, v41                              // 00000010BEE4: D613002B 24A65522
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BEEC: BF870091
	v_fmac_f32_e32 v42, v43, v40                               // 00000010BEF0: 5654512B
	v_fma_f32 v34, -v34, v42, v41                              // 00000010BEF4: D6130022 24A65522
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BEFC: BF870091
	v_div_fmas_f32 v34, v34, v40, v42                          // 00000010BF00: D6370022 04AA5122
	v_div_fixup_f32 v34, v34, v32, v33                         // 00000010BF08: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v121, v[128:129]     // 00000010BF10: D6FF7C20 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BF1C: BF870092
	v_bfe_u32 v40, v34, 16, 1                                  // 00000010BF20: D6100028 02052122
	v_add3_u32 v34, v34, v40, 0x7fff                           // 00000010BF28: D6550022 03FE5122 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 00000010BF34: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010BF3C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000010BF40: BE882003
	s_cbranch_execz 59379                                      // 00000010BF44: BFA5E7F3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4214>
	v_mad_i64_i32 v[32:33], null, 0x6000, v122, v[130:131]     // 00000010BF48: D6FF7C20 060AF4FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 00000010BF54: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 00000010BF5C: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000010BF60: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BF64: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 00000010BF68: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 00000010BF70: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v40, v33                                   // 00000010BF7C: 7E504721
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BF80: BF870091
	v_dual_fmamk_f32 v34, v32, 0xb2a5705f, v34 :: v_dual_sub_f32 v33, v33, v40// 00000010BF84: C88A4520 22205121 B2A5705F
	v_add_f32_e32 v33, v33, v34                                // 00000010BF90: 06424521
	v_cvt_i32_f32_e32 v34, v40                                 // 00000010BF94: 7E441128
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000010BF98: 7C3C40FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010BFA0: BF870293
	v_exp_f32_e32 v33, v33                                     // 00000010BFA4: 7E424B21
	.long 0xd71c0021                                           // 00000010BFA8: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000010BFAC: 02024521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010BFB0: BF870121
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000010BFB4: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000010BFB8: 7C3640FF C2B17218
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v137, v35// 00000010BFC0: CA4642FF 20204789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010BFCC: BF870091
	v_add_f32_e32 v32, 1.0, v32                                // 00000010BFD0: 064040F2
	v_div_scale_f32 v34, null, v32, v32, v33                   // 00000010BFD4: D6FC7C22 04864120
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010BFDC: BF870291
	v_rcp_f32_e32 v35, v34                                     // 00000010BFE0: 7E465522
	v_fma_f32 v40, -v34, v35, 1.0                              // 00000010BFE4: D6130028 23CA4722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000010BFEC: BF8700A1
	v_fmac_f32_e32 v35, v40, v35                               // 00000010BFF0: 56464728
	v_div_scale_f32 v40, vcc_lo, v33, v32, v33                 // 00000010BFF4: D6FC6A28 04864121
	v_mul_f32_e32 v41, v40, v35                                // 00000010BFFC: 10524728
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C000: BF870091
	v_fma_f32 v42, -v34, v41, v40                              // 00000010C004: D613002A 24A25322
	v_fmac_f32_e32 v41, v42, v35                               // 00000010C00C: 5652472A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C010: BF870091
	v_fma_f32 v34, -v34, v41, v40                              // 00000010C014: D6130022 24A25322
	v_div_fmas_f32 v34, v34, v35, v41                          // 00000010C01C: D6370022 04A64722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010C024: BF870121
	v_div_fixup_f32 v34, v34, v32, v33                         // 00000010C028: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v122, v[128:129]     // 00000010C030: D6FF7C20 0602F4FF 00003000
	v_bfe_u32 v35, v34, 16, 1                                  // 00000010C03C: D6100023 02052122
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010C044: BF870001
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000010C048: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 00000010C054: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010C05C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000010C060: BE882004
	s_cbranch_execz 59310                                      // 00000010C064: BFA5E7AE <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4220>
	v_mad_i64_i32 v[32:33], null, 0x6000, v123, v[130:131]     // 00000010C068: D6FF7C20 060AF6FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 00000010C074: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 00000010C07C: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000010C080: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C084: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 00000010C088: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 00000010C090: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000010C09C: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010C0A0: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 00000010C0A4: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000010C0A8: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 00000010C0B0: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010C0B8: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000010C0BC: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000010C0C0: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000010C0C4: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C0C8: BF870095
	.long 0xd71c0021                                           // 00000010C0CC: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000010C0D0: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000010C0D4: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000010C0D8: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C0E0: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v134, v36// 00000010C0E4: CA4642FF 20204986 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 00000010C0F0: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C0F4: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 00000010C0F8: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 00000010C100: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C104: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 00000010C108: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 00000010C110: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 00000010C114: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C11C: BF870091
	v_mul_f32_e32 v40, v36, v35                                // 00000010C120: 10504724
	v_fma_f32 v41, -v34, v40, v36                              // 00000010C124: D6130029 24925122
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C12C: BF870091
	v_fmac_f32_e32 v40, v41, v35                               // 00000010C130: 56504729
	v_fma_f32 v34, -v34, v40, v36                              // 00000010C134: D6130022 24925122
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C13C: BF870091
	v_div_fmas_f32 v34, v34, v35, v40                          // 00000010C140: D6370022 04A24722
	v_div_fixup_f32 v34, v34, v32, v33                         // 00000010C148: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v123, v[128:129]     // 00000010C150: D6FF7C20 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C15C: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 00000010C160: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000010C168: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 00000010C174: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010C17C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000010C180: BE882005
	s_cbranch_execz 59241                                      // 00000010C184: BFA5E769 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x422c>
	v_mad_i64_i32 v[32:33], null, 0x6000, v124, v[130:131]     // 00000010C188: D6FF7C20 060AF8FF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 00000010C194: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 00000010C19C: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000010C1A0: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C1A4: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 00000010C1A8: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 00000010C1B0: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000010C1BC: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010C1C0: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 00000010C1C4: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000010C1C8: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 00000010C1D0: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010C1D8: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000010C1DC: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000010C1E0: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000010C1E4: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C1E8: BF870095
	.long 0xd71c0021                                           // 00000010C1EC: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000010C1F0: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000010C1F4: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000010C1F8: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C200: BF870092
	v_cndmask_b32_e32 v32, 0x7f800000, v33, vcc_lo             // 00000010C204: 024042FF 7F800000
	v_dual_mul_f32 v33, v135, v37 :: v_dual_add_f32 v32, 1.0, v32// 00000010C20C: C8C84B87 212040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C214: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 00000010C218: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 00000010C220: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C224: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 00000010C228: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 00000010C230: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 00000010C234: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C23C: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 00000010C240: 104A4724
	v_fma_f32 v40, -v34, v37, v36                              // 00000010C244: D6130028 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C24C: BF870091
	v_fmac_f32_e32 v37, v40, v35                               // 00000010C250: 564A4728
	v_fma_f32 v34, -v34, v37, v36                              // 00000010C254: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C25C: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 00000010C260: D6370022 04964722
	v_div_fixup_f32 v34, v34, v32, v33                         // 00000010C268: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v124, v[128:129]     // 00000010C270: D6FF7C20 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C27C: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 00000010C280: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000010C288: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 00000010C294: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010C29C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000010C2A0: BE882006
	s_cbranch_execz 59172                                      // 00000010C2A4: BFA5E724 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4238>
	v_mad_i64_i32 v[32:33], null, 0x6000, v125, v[130:131]     // 00000010C2A8: D6FF7C20 060AFAFF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 00000010C2B4: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 00000010C2BC: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000010C2C0: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C2C4: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 00000010C2C8: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 00000010C2D0: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000010C2DC: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010C2E0: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 00000010C2E4: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000010C2E8: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 00000010C2F0: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010C2F8: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000010C2FC: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000010C300: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000010C304: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C308: BF870095
	.long 0xd71c0021                                           // 00000010C30C: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000010C310: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000010C314: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000010C318: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C320: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v132, v38// 00000010C324: CA4642FF 20204D84 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 00000010C330: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C334: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 00000010C338: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 00000010C340: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C344: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 00000010C348: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 00000010C350: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 00000010C354: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C35C: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 00000010C360: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 00000010C364: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C36C: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 00000010C370: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 00000010C374: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C37C: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 00000010C380: D6370022 04964722
	v_div_fixup_f32 v34, v34, v32, v33                         // 00000010C388: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v125, v[128:129]     // 00000010C390: D6FF7C20 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C39C: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 00000010C3A0: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000010C3A8: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 00000010C3B4: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010C3BC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000010C3C0: BE882007
	s_cbranch_execz 59103                                      // 00000010C3C4: BFA5E6DF <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4244>
	v_mad_i64_i32 v[32:33], null, 0x6000, v126, v[130:131]     // 00000010C3C8: D6FF7C20 060AFCFF 00006000
	global_load_u16 v32, v[32:33], off offset:864              // 00000010C3D4: DC4A0360 207C0020
	s_waitcnt vmcnt(0)                                         // 00000010C3DC: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000010C3E0: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C3E4: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 00000010C3E8: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 00000010C3F0: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000010C3FC: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010C400: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 00000010C404: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000010C408: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 00000010C410: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010C418: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000010C41C: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000010C420: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000010C424: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C428: BF870095
	.long 0xd71c0021                                           // 00000010C42C: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000010C430: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000010C434: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000010C438: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C440: BF870092
	v_dual_cndmask_b32 v32, 0x7f800000, v33 :: v_dual_mul_f32 v33, v133, v39// 00000010C444: CA4642FF 20204F85 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 00000010C450: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C454: BF870091
	v_div_scale_f32 v34, null, v32, v32, v33                   // 00000010C458: D6FC7C22 04864120
	v_rcp_f32_e32 v35, v34                                     // 00000010C460: 7E465522
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C464: BF870095
	v_fma_f32 v36, -v34, v35, 1.0                              // 00000010C468: D6130024 23CA4722
	v_fmac_f32_e32 v35, v36, v35                               // 00000010C470: 56464724
	v_div_scale_f32 v36, vcc_lo, v33, v32, v33                 // 00000010C474: D6FC6A24 04864121
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C47C: BF870091
	v_mul_f32_e32 v37, v36, v35                                // 00000010C480: 104A4724
	v_fma_f32 v38, -v34, v37, v36                              // 00000010C484: D6130026 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C48C: BF870091
	v_fmac_f32_e32 v37, v38, v35                               // 00000010C490: 564A4726
	v_fma_f32 v34, -v34, v37, v36                              // 00000010C494: D6130022 24924B22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C49C: BF870091
	v_div_fmas_f32 v34, v34, v35, v37                          // 00000010C4A0: D6370022 04964722
	v_div_fixup_f32 v34, v34, v32, v33                         // 00000010C4A8: D6270022 04864122
	v_mad_i64_i32 v[32:33], null, 0x3000, v126, v[128:129]     // 00000010C4B0: D6FF7C20 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C4BC: BF870092
	v_bfe_u32 v35, v34, 16, 1                                  // 00000010C4C0: D6100023 02052122
	v_add3_u32 v34, v34, v35, 0x7fff                           // 00000010C4C8: D6550022 03FE4722 00007FFF
	global_store_d16_hi_b16 v[32:33], v34, off offset:352      // 00000010C4D4: DC960160 007C2220
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010C4DC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000010C4E0: BE882000
	s_cbranch_execz 59034                                      // 00000010C4E4: BFA5E69A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4250>
	v_mad_i64_i32 v[32:33], null, 0x6000, v140, v[130:131]     // 00000010C4E8: D6FF7C20 060B18FF 00006000
	v_mul_f32_e32 v24, v138, v24                               // 00000010C4F4: 1030318A
	global_load_u16 v32, v[32:33], off offset:896              // 00000010C4F8: DC4A0380 207C0020
	s_waitcnt vmcnt(0)                                         // 00000010C500: BF8903F7
	v_lshlrev_b32_e32 v32, 16, v32                             // 00000010C504: 30404090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C508: BF870091
	v_mul_f32_e32 v33, 0xbfb8aa3b, v32                         // 00000010C50C: 104240FF BFB8AA3B
	v_fma_f32 v34, 0xbfb8aa3b, v32, -v33                       // 00000010C514: D6130022 848640FF BFB8AA3B
	v_rndne_f32_e32 v35, v33                                   // 00000010C520: 7E464721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010C524: BF870221
	v_sub_f32_e32 v33, v33, v35                                // 00000010C528: 08424721
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v32                  // 00000010C52C: 7C3C40FF 42CE8ED0
	v_fmamk_f32 v34, v32, 0xb2a5705f, v34                      // 00000010C534: 58444520 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010C53C: BF870121
	v_add_f32_e32 v33, v33, v34                                // 00000010C540: 06424521
	v_cvt_i32_f32_e32 v34, v35                                 // 00000010C544: 7E441123
	v_exp_f32_e32 v33, v33                                     // 00000010C548: 7E424B21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C54C: BF870095
	.long 0xd71c0021                                           // 00000010C550: D71C0021
	v_cndmask_b32_e32 v1, v33, v34, vcc_lo                     // 00000010C554: 02024521
	v_cndmask_b32_e32 v33, 0, v33, vcc_lo                      // 00000010C558: 02424280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v32                  // 00000010C55C: 7C3640FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C564: BF870092
	v_cndmask_b32_e32 v32, 0x7f800000, v33, vcc_lo             // 00000010C568: 024042FF 7F800000
	v_add_f32_e32 v32, 1.0, v32                                // 00000010C570: 064040F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C574: BF870091
	v_div_scale_f32 v33, null, v32, v32, v24                   // 00000010C578: D6FC7C21 04624120
	v_rcp_f32_e32 v34, v33                                     // 00000010C580: 7E445521
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C584: BF870095
	v_fma_f32 v35, -v33, v34, 1.0                              // 00000010C588: D6130023 23CA4521
	v_fmac_f32_e32 v34, v35, v34                               // 00000010C590: 56444523
	v_div_scale_f32 v35, vcc_lo, v24, v32, v24                 // 00000010C594: D6FC6A23 04624118
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C59C: BF870091
	v_mul_f32_e32 v36, v35, v34                                // 00000010C5A0: 10484523
	v_fma_f32 v37, -v33, v36, v35                              // 00000010C5A4: D6130025 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C5AC: BF870091
	v_fmac_f32_e32 v36, v37, v34                               // 00000010C5B0: 56484525
	v_fma_f32 v33, -v33, v36, v35                              // 00000010C5B4: D6130021 248E4921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C5BC: BF870091
	v_div_fmas_f32 v33, v33, v34, v36                          // 00000010C5C0: D6370021 04924521
	v_div_fixup_f32 v24, v33, v32, v24                         // 00000010C5C8: D6270018 04624121
	v_mad_i64_i32 v[32:33], null, 0x3000, v140, v[128:129]     // 00000010C5D0: D6FF7C20 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C5DC: BF870092
	v_bfe_u32 v34, v24, 16, 1                                  // 00000010C5E0: D6100022 02052118
	v_add3_u32 v24, v24, v34, 0x7fff                           // 00000010C5E8: D6550018 03FE4518 00007FFF
	global_store_d16_hi_b16 v[32:33], v24, off offset:384      // 00000010C5F4: DC960180 007C1820
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010C5FC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000010C600: BE882001
	s_cbranch_execz 58965                                      // 00000010C604: BFA5E655 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x425c>
	v_mad_i64_i32 v[32:33], null, 0x6000, v120, v[130:131]     // 00000010C608: D6FF7C20 060AF0FF 00006000
	v_mul_f32_e32 v25, v139, v25                               // 00000010C614: 1032338B
	global_load_u16 v24, v[32:33], off offset:896              // 00000010C618: DC4A0380 187C0020
	s_waitcnt vmcnt(0)                                         // 00000010C620: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000010C624: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010C628: BF870121
	v_mul_f32_e32 v32, 0xbfb8aa3b, v24                         // 00000010C62C: 104030FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000010C634: 7C3C30FF 42CE8ED0
	v_fma_f32 v33, 0xbfb8aa3b, v24, -v32                       // 00000010C63C: D6130021 848230FF BFB8AA3B
	v_rndne_f32_e32 v34, v32                                   // 00000010C648: 7E444720
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010C64C: BF870112
	v_fmamk_f32 v33, v24, 0xb2a5705f, v33                      // 00000010C650: 58424318 B2A5705F
	v_sub_f32_e32 v32, v32, v34                                // 00000010C658: 08404520
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010C65C: BF870121
	v_add_f32_e32 v32, v32, v33                                // 00000010C660: 06404320
	v_cvt_i32_f32_e32 v33, v34                                 // 00000010C664: 7E421122
	v_exp_f32_e32 v32, v32                                     // 00000010C668: 7E404B20
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C66C: BF870095
	.long 0xd71c0020                                           // 00000010C670: D71C0020
	v_cndmask_b32_e32 v1, v32, v33, vcc_lo                     // 00000010C674: 02024320
	v_cndmask_b32_e32 v32, 0, v32, vcc_lo                      // 00000010C678: 02404080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000010C67C: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C684: BF870092
	v_cndmask_b32_e32 v24, 0x7f800000, v32, vcc_lo             // 00000010C688: 023040FF 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 00000010C690: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C694: BF870091
	v_div_scale_f32 v32, null, v24, v24, v25                   // 00000010C698: D6FC7C20 04663118
	v_rcp_f32_e32 v33, v32                                     // 00000010C6A0: 7E425520
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C6A4: BF870095
	v_fma_f32 v34, -v32, v33, 1.0                              // 00000010C6A8: D6130022 23CA4320
	v_fmac_f32_e32 v33, v34, v33                               // 00000010C6B0: 56424322
	v_div_scale_f32 v34, vcc_lo, v25, v24, v25                 // 00000010C6B4: D6FC6A22 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C6BC: BF870091
	v_mul_f32_e32 v35, v34, v33                                // 00000010C6C0: 10464322
	v_fma_f32 v36, -v32, v35, v34                              // 00000010C6C4: D6130024 248A4720
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C6CC: BF870091
	v_fmac_f32_e32 v35, v36, v33                               // 00000010C6D0: 56464324
	v_fma_f32 v32, -v32, v35, v34                              // 00000010C6D4: D6130020 248A4720
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C6DC: BF870091
	v_div_fmas_f32 v32, v32, v33, v35                          // 00000010C6E0: D6370020 048E4320
	v_div_fixup_f32 v32, v32, v24, v25                         // 00000010C6E8: D6270020 04663120
	v_mad_i64_i32 v[24:25], null, 0x3000, v120, v[128:129]     // 00000010C6F0: D6FF7C18 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C6FC: BF870092
	v_bfe_u32 v33, v32, 16, 1                                  // 00000010C700: D6100021 02052120
	v_add3_u32 v32, v32, v33, 0x7fff                           // 00000010C708: D6550020 03FE4320 00007FFF
	global_store_d16_hi_b16 v[24:25], v32, off offset:384      // 00000010C714: DC960180 007C2018
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010C71C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000010C720: BE882002
	s_cbranch_execz 58896                                      // 00000010C724: BFA5E610 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4268>
	v_mad_i64_i32 v[24:25], null, 0x6000, v121, v[130:131]     // 00000010C728: D6FF7C18 060AF2FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 00000010C734: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 00000010C73C: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000010C740: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C744: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 00000010C748: 103230FF BFB8AA3B
	v_fma_f32 v32, 0xbfb8aa3b, v24, -v25                       // 00000010C750: D6130020 846630FF BFB8AA3B
	v_rndne_f32_e32 v33, v25                                   // 00000010C75C: 7E424719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010C760: BF870221
	v_sub_f32_e32 v25, v25, v33                                // 00000010C764: 08324319
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000010C768: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v32, v24, 0xb2a5705f, v32                      // 00000010C770: 58404118 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010C778: BF870121
	v_add_f32_e32 v25, v25, v32                                // 00000010C77C: 06324119
	v_cvt_i32_f32_e32 v32, v33                                 // 00000010C780: 7E401121
	v_exp_f32_e32 v25, v25                                     // 00000010C784: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C788: BF870095
	.long 0xd71c0019                                           // 00000010C78C: D71C0019
	v_cndmask_b32_e32 v1, v25, v32, vcc_lo                     // 00000010C790: 02024119
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000010C794: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000010C798: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C7A0: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v136, v26// 00000010C7A4: CA4632FF 18183588 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 00000010C7B0: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C7B4: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 00000010C7B8: D6FC7C1A 04663118
	v_rcp_f32_e32 v32, v26                                     // 00000010C7C0: 7E40551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C7C4: BF870095
	v_fma_f32 v33, -v26, v32, 1.0                              // 00000010C7C8: D6130021 23CA411A
	v_fmac_f32_e32 v32, v33, v32                               // 00000010C7D0: 56404121
	v_div_scale_f32 v33, vcc_lo, v25, v24, v25                 // 00000010C7D4: D6FC6A21 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C7DC: BF870091
	v_mul_f32_e32 v34, v33, v32                                // 00000010C7E0: 10444121
	v_fma_f32 v35, -v26, v34, v33                              // 00000010C7E4: D6130023 2486451A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C7EC: BF870091
	v_fmac_f32_e32 v34, v35, v32                               // 00000010C7F0: 56444123
	v_fma_f32 v26, -v26, v34, v33                              // 00000010C7F4: D613001A 2486451A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C7FC: BF870091
	v_div_fmas_f32 v26, v26, v32, v34                          // 00000010C800: D637001A 048A411A
	v_div_fixup_f32 v26, v26, v24, v25                         // 00000010C808: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v121, v[128:129]     // 00000010C810: D6FF7C18 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C81C: BF870092
	v_bfe_u32 v32, v26, 16, 1                                  // 00000010C820: D6100020 0205211A
	v_add3_u32 v26, v26, v32, 0x7fff                           // 00000010C828: D655001A 03FE411A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 00000010C834: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010C83C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000010C840: BE882003
	s_cbranch_execz 58827                                      // 00000010C844: BFA5E5CB <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4274>
	v_mad_i64_i32 v[24:25], null, 0x6000, v122, v[130:131]     // 00000010C848: D6FF7C18 060AF4FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 00000010C854: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 00000010C85C: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000010C860: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C864: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 00000010C868: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 00000010C870: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v32, v25                                   // 00000010C87C: 7E404719
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C880: BF870091
	v_dual_fmamk_f32 v26, v24, 0xb2a5705f, v26 :: v_dual_sub_f32 v25, v25, v32// 00000010C884: C88A3518 1A184119 B2A5705F
	v_add_f32_e32 v25, v25, v26                                // 00000010C890: 06323519
	v_cvt_i32_f32_e32 v26, v32                                 // 00000010C894: 7E341120
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000010C898: 7C3C30FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010C8A0: BF870293
	v_exp_f32_e32 v25, v25                                     // 00000010C8A4: 7E324B19
	.long 0xd71c0019                                           // 00000010C8A8: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000010C8AC: 02023519
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010C8B0: BF870121
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000010C8B4: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000010C8B8: 7C3630FF C2B17218
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v137, v27// 00000010C8C0: CA4632FF 18183789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C8CC: BF870091
	v_add_f32_e32 v24, 1.0, v24                                // 00000010C8D0: 063030F2
	v_div_scale_f32 v26, null, v24, v24, v25                   // 00000010C8D4: D6FC7C1A 04663118
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010C8DC: BF870291
	v_rcp_f32_e32 v27, v26                                     // 00000010C8E0: 7E36551A
	v_fma_f32 v32, -v26, v27, 1.0                              // 00000010C8E4: D6130020 23CA371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000010C8EC: BF8700A1
	v_fmac_f32_e32 v27, v32, v27                               // 00000010C8F0: 56363720
	v_div_scale_f32 v32, vcc_lo, v25, v24, v25                 // 00000010C8F4: D6FC6A20 04663119
	v_mul_f32_e32 v33, v32, v27                                // 00000010C8FC: 10423720
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C900: BF870091
	v_fma_f32 v34, -v26, v33, v32                              // 00000010C904: D6130022 2482431A
	v_fmac_f32_e32 v33, v34, v27                               // 00000010C90C: 56423722
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C910: BF870091
	v_fma_f32 v26, -v26, v33, v32                              // 00000010C914: D613001A 2482431A
	v_div_fmas_f32 v26, v26, v27, v33                          // 00000010C91C: D637001A 0486371A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010C924: BF870121
	v_div_fixup_f32 v26, v26, v24, v25                         // 00000010C928: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v122, v[128:129]     // 00000010C930: D6FF7C18 0602F4FF 00003000
	v_bfe_u32 v27, v26, 16, 1                                  // 00000010C93C: D610001B 0205211A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010C944: BF870001
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000010C948: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 00000010C954: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010C95C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000010C960: BE882004
	s_cbranch_execz 58758                                      // 00000010C964: BFA5E586 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4280>
	v_mad_i64_i32 v[24:25], null, 0x6000, v123, v[130:131]     // 00000010C968: D6FF7C18 060AF6FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 00000010C974: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 00000010C97C: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000010C980: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C984: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 00000010C988: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 00000010C990: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000010C99C: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010C9A0: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 00000010C9A4: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000010C9A8: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 00000010C9B0: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010C9B8: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000010C9BC: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000010C9C0: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000010C9C4: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C9C8: BF870095
	.long 0xd71c0019                                           // 00000010C9CC: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000010C9D0: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000010C9D4: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000010C9D8: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C9E0: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v134, v28// 00000010C9E4: CA4632FF 18183986 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 00000010C9F0: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010C9F4: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 00000010C9F8: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 00000010CA00: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CA04: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 00000010CA08: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 00000010CA10: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 00000010CA14: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CA1C: BF870091
	v_mul_f32_e32 v32, v28, v27                                // 00000010CA20: 1040371C
	v_fma_f32 v33, -v26, v32, v28                              // 00000010CA24: D6130021 2472411A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CA2C: BF870091
	v_fmac_f32_e32 v32, v33, v27                               // 00000010CA30: 56403721
	v_fma_f32 v26, -v26, v32, v28                              // 00000010CA34: D613001A 2472411A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CA3C: BF870091
	v_div_fmas_f32 v26, v26, v27, v32                          // 00000010CA40: D637001A 0482371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 00000010CA48: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v123, v[128:129]     // 00000010CA50: D6FF7C18 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CA5C: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 00000010CA60: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000010CA68: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 00000010CA74: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010CA7C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000010CA80: BE882005
	s_cbranch_execz 58689                                      // 00000010CA84: BFA5E541 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x428c>
	v_mad_i64_i32 v[24:25], null, 0x6000, v124, v[130:131]     // 00000010CA88: D6FF7C18 060AF8FF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 00000010CA94: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 00000010CA9C: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000010CAA0: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CAA4: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 00000010CAA8: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 00000010CAB0: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000010CABC: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010CAC0: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 00000010CAC4: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000010CAC8: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 00000010CAD0: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010CAD8: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000010CADC: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000010CAE0: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000010CAE4: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CAE8: BF870095
	.long 0xd71c0019                                           // 00000010CAEC: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000010CAF0: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000010CAF4: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000010CAF8: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CB00: BF870092
	v_cndmask_b32_e32 v24, 0x7f800000, v25, vcc_lo             // 00000010CB04: 023032FF 7F800000
	v_dual_mul_f32 v25, v135, v29 :: v_dual_add_f32 v24, 1.0, v24// 00000010CB0C: C8C83B87 191830F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CB14: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 00000010CB18: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 00000010CB20: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CB24: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 00000010CB28: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 00000010CB30: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 00000010CB34: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CB3C: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 00000010CB40: 103A371C
	v_fma_f32 v32, -v26, v29, v28                              // 00000010CB44: D6130020 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CB4C: BF870091
	v_fmac_f32_e32 v29, v32, v27                               // 00000010CB50: 563A3720
	v_fma_f32 v26, -v26, v29, v28                              // 00000010CB54: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CB5C: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 00000010CB60: D637001A 0476371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 00000010CB68: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v124, v[128:129]     // 00000010CB70: D6FF7C18 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CB7C: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 00000010CB80: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000010CB88: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 00000010CB94: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010CB9C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000010CBA0: BE882006
	s_cbranch_execz 58620                                      // 00000010CBA4: BFA5E4FC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4298>
	v_mad_i64_i32 v[24:25], null, 0x6000, v125, v[130:131]     // 00000010CBA8: D6FF7C18 060AFAFF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 00000010CBB4: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 00000010CBBC: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000010CBC0: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CBC4: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 00000010CBC8: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 00000010CBD0: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000010CBDC: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010CBE0: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 00000010CBE4: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000010CBE8: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 00000010CBF0: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010CBF8: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000010CBFC: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000010CC00: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000010CC04: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CC08: BF870095
	.long 0xd71c0019                                           // 00000010CC0C: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000010CC10: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000010CC14: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000010CC18: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CC20: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v132, v30// 00000010CC24: CA4632FF 18183D84 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 00000010CC30: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CC34: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 00000010CC38: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 00000010CC40: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CC44: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 00000010CC48: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 00000010CC50: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 00000010CC54: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CC5C: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 00000010CC60: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 00000010CC64: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CC6C: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 00000010CC70: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 00000010CC74: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CC7C: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 00000010CC80: D637001A 0476371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 00000010CC88: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v125, v[128:129]     // 00000010CC90: D6FF7C18 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CC9C: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 00000010CCA0: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000010CCA8: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 00000010CCB4: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010CCBC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000010CCC0: BE882007
	s_cbranch_execz 58551                                      // 00000010CCC4: BFA5E4B7 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42a4>
	v_mad_i64_i32 v[24:25], null, 0x6000, v126, v[130:131]     // 00000010CCC8: D6FF7C18 060AFCFF 00006000
	global_load_u16 v24, v[24:25], off offset:896              // 00000010CCD4: DC4A0380 187C0018
	s_waitcnt vmcnt(0)                                         // 00000010CCDC: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000010CCE0: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CCE4: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 00000010CCE8: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 00000010CCF0: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000010CCFC: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010CD00: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 00000010CD04: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000010CD08: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 00000010CD10: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010CD18: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000010CD1C: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000010CD20: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000010CD24: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CD28: BF870095
	.long 0xd71c0019                                           // 00000010CD2C: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000010CD30: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000010CD34: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000010CD38: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CD40: BF870092
	v_dual_cndmask_b32 v24, 0x7f800000, v25 :: v_dual_mul_f32 v25, v133, v31// 00000010CD44: CA4632FF 18183F85 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 00000010CD50: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CD54: BF870091
	v_div_scale_f32 v26, null, v24, v24, v25                   // 00000010CD58: D6FC7C1A 04663118
	v_rcp_f32_e32 v27, v26                                     // 00000010CD60: 7E36551A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CD64: BF870095
	v_fma_f32 v28, -v26, v27, 1.0                              // 00000010CD68: D613001C 23CA371A
	v_fmac_f32_e32 v27, v28, v27                               // 00000010CD70: 5636371C
	v_div_scale_f32 v28, vcc_lo, v25, v24, v25                 // 00000010CD74: D6FC6A1C 04663119
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CD7C: BF870091
	v_mul_f32_e32 v29, v28, v27                                // 00000010CD80: 103A371C
	v_fma_f32 v30, -v26, v29, v28                              // 00000010CD84: D613001E 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CD8C: BF870091
	v_fmac_f32_e32 v29, v30, v27                               // 00000010CD90: 563A371E
	v_fma_f32 v26, -v26, v29, v28                              // 00000010CD94: D613001A 24723B1A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CD9C: BF870091
	v_div_fmas_f32 v26, v26, v27, v29                          // 00000010CDA0: D637001A 0476371A
	v_div_fixup_f32 v26, v26, v24, v25                         // 00000010CDA8: D627001A 0466311A
	v_mad_i64_i32 v[24:25], null, 0x3000, v126, v[128:129]     // 00000010CDB0: D6FF7C18 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CDBC: BF870092
	v_bfe_u32 v27, v26, 16, 1                                  // 00000010CDC0: D610001B 0205211A
	v_add3_u32 v26, v26, v27, 0x7fff                           // 00000010CDC8: D655001A 03FE371A 00007FFF
	global_store_d16_hi_b16 v[24:25], v26, off offset:384      // 00000010CDD4: DC960180 007C1A18
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010CDDC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000010CDE0: BE882000
	s_cbranch_execz 58482                                      // 00000010CDE4: BFA5E472 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42b0>
	v_mad_i64_i32 v[24:25], null, 0x6000, v140, v[130:131]     // 00000010CDE8: D6FF7C18 060B18FF 00006000
	v_mul_f32_e32 v16, v138, v16                               // 00000010CDF4: 1020218A
	global_load_u16 v24, v[24:25], off offset:928              // 00000010CDF8: DC4A03A0 187C0018
	s_waitcnt vmcnt(0)                                         // 00000010CE00: BF8903F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 00000010CE04: 30303090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CE08: BF870091
	v_mul_f32_e32 v25, 0xbfb8aa3b, v24                         // 00000010CE0C: 103230FF BFB8AA3B
	v_fma_f32 v26, 0xbfb8aa3b, v24, -v25                       // 00000010CE14: D613001A 846630FF BFB8AA3B
	v_rndne_f32_e32 v27, v25                                   // 00000010CE20: 7E364719
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010CE24: BF870221
	v_sub_f32_e32 v25, v25, v27                                // 00000010CE28: 08323719
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v24                  // 00000010CE2C: 7C3C30FF 42CE8ED0
	v_fmamk_f32 v26, v24, 0xb2a5705f, v26                      // 00000010CE34: 58343518 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010CE3C: BF870121
	v_add_f32_e32 v25, v25, v26                                // 00000010CE40: 06323519
	v_cvt_i32_f32_e32 v26, v27                                 // 00000010CE44: 7E34111B
	v_exp_f32_e32 v25, v25                                     // 00000010CE48: 7E324B19
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CE4C: BF870095
	.long 0xd71c0019                                           // 00000010CE50: D71C0019
	v_cndmask_b32_e32 v1, v25, v26, vcc_lo                     // 00000010CE54: 02023519
	v_cndmask_b32_e32 v25, 0, v25, vcc_lo                      // 00000010CE58: 02323280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v24                  // 00000010CE5C: 7C3630FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CE64: BF870092
	v_cndmask_b32_e32 v24, 0x7f800000, v25, vcc_lo             // 00000010CE68: 023032FF 7F800000
	v_add_f32_e32 v24, 1.0, v24                                // 00000010CE70: 063030F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CE74: BF870091
	v_div_scale_f32 v25, null, v24, v24, v16                   // 00000010CE78: D6FC7C19 04423118
	v_rcp_f32_e32 v26, v25                                     // 00000010CE80: 7E345519
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CE84: BF870095
	v_fma_f32 v27, -v25, v26, 1.0                              // 00000010CE88: D613001B 23CA3519
	v_fmac_f32_e32 v26, v27, v26                               // 00000010CE90: 5634351B
	v_div_scale_f32 v27, vcc_lo, v16, v24, v16                 // 00000010CE94: D6FC6A1B 04423110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CE9C: BF870091
	v_mul_f32_e32 v28, v27, v26                                // 00000010CEA0: 1038351B
	v_fma_f32 v29, -v25, v28, v27                              // 00000010CEA4: D613001D 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CEAC: BF870091
	v_fmac_f32_e32 v28, v29, v26                               // 00000010CEB0: 5638351D
	v_fma_f32 v25, -v25, v28, v27                              // 00000010CEB4: D6130019 246E3919
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CEBC: BF870091
	v_div_fmas_f32 v25, v25, v26, v28                          // 00000010CEC0: D6370019 04723519
	v_div_fixup_f32 v16, v25, v24, v16                         // 00000010CEC8: D6270010 04423119
	v_mad_i64_i32 v[24:25], null, 0x3000, v140, v[128:129]     // 00000010CED0: D6FF7C18 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CEDC: BF870092
	v_bfe_u32 v26, v16, 16, 1                                  // 00000010CEE0: D610001A 02052110
	v_add3_u32 v16, v16, v26, 0x7fff                           // 00000010CEE8: D6550010 03FE3510 00007FFF
	global_store_d16_hi_b16 v[24:25], v16, off offset:416      // 00000010CEF4: DC9601A0 007C1018
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010CEFC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000010CF00: BE882001
	s_cbranch_execz 58413                                      // 00000010CF04: BFA5E42D <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42bc>
	v_mad_i64_i32 v[24:25], null, 0x6000, v120, v[130:131]     // 00000010CF08: D6FF7C18 060AF0FF 00006000
	v_mul_f32_e32 v17, v139, v17                               // 00000010CF14: 1022238B
	global_load_u16 v16, v[24:25], off offset:928              // 00000010CF18: DC4A03A0 107C0018
	s_waitcnt vmcnt(0)                                         // 00000010CF20: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000010CF24: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010CF28: BF870121
	v_mul_f32_e32 v24, 0xbfb8aa3b, v16                         // 00000010CF2C: 103020FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000010CF34: 7C3C20FF 42CE8ED0
	v_fma_f32 v25, 0xbfb8aa3b, v16, -v24                       // 00000010CF3C: D6130019 846220FF BFB8AA3B
	v_rndne_f32_e32 v26, v24                                   // 00000010CF48: 7E344718
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010CF4C: BF870112
	v_fmamk_f32 v25, v16, 0xb2a5705f, v25                      // 00000010CF50: 58323310 B2A5705F
	v_sub_f32_e32 v24, v24, v26                                // 00000010CF58: 08303518
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010CF5C: BF870121
	v_add_f32_e32 v24, v24, v25                                // 00000010CF60: 06303318
	v_cvt_i32_f32_e32 v25, v26                                 // 00000010CF64: 7E32111A
	v_exp_f32_e32 v24, v24                                     // 00000010CF68: 7E304B18
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CF6C: BF870095
	.long 0xd71c0018                                           // 00000010CF70: D71C0018
	v_cndmask_b32_e32 v1, v24, v25, vcc_lo                     // 00000010CF74: 02023318
	v_cndmask_b32_e32 v24, 0, v24, vcc_lo                      // 00000010CF78: 02303080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000010CF7C: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CF84: BF870092
	v_cndmask_b32_e32 v16, 0x7f800000, v24, vcc_lo             // 00000010CF88: 022030FF 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000010CF90: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CF94: BF870091
	v_div_scale_f32 v24, null, v16, v16, v17                   // 00000010CF98: D6FC7C18 04462110
	v_rcp_f32_e32 v25, v24                                     // 00000010CFA0: 7E325518
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CFA4: BF870095
	v_fma_f32 v26, -v24, v25, 1.0                              // 00000010CFA8: D613001A 23CA3318
	v_fmac_f32_e32 v25, v26, v25                               // 00000010CFB0: 5632331A
	v_div_scale_f32 v26, vcc_lo, v17, v16, v17                 // 00000010CFB4: D6FC6A1A 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CFBC: BF870091
	v_mul_f32_e32 v27, v26, v25                                // 00000010CFC0: 1036331A
	v_fma_f32 v28, -v24, v27, v26                              // 00000010CFC4: D613001C 246A3718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CFCC: BF870091
	v_fmac_f32_e32 v27, v28, v25                               // 00000010CFD0: 5636331C
	v_fma_f32 v24, -v24, v27, v26                              // 00000010CFD4: D6130018 246A3718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CFDC: BF870091
	v_div_fmas_f32 v24, v24, v25, v27                          // 00000010CFE0: D6370018 046E3318
	v_div_fixup_f32 v24, v24, v16, v17                         // 00000010CFE8: D6270018 04462118
	v_mad_i64_i32 v[16:17], null, 0x3000, v120, v[128:129]     // 00000010CFF0: D6FF7C10 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010CFFC: BF870092
	v_bfe_u32 v25, v24, 16, 1                                  // 00000010D000: D6100019 02052118
	v_add3_u32 v24, v24, v25, 0x7fff                           // 00000010D008: D6550018 03FE3318 00007FFF
	global_store_d16_hi_b16 v[16:17], v24, off offset:416      // 00000010D014: DC9601A0 007C1810
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010D01C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000010D020: BE882002
	s_cbranch_execz 58344                                      // 00000010D024: BFA5E3E8 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42c8>
	v_mad_i64_i32 v[16:17], null, 0x6000, v121, v[130:131]     // 00000010D028: D6FF7C10 060AF2FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 00000010D034: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000010D03C: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000010D040: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D044: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 00000010D048: 102220FF BFB8AA3B
	v_fma_f32 v24, 0xbfb8aa3b, v16, -v17                       // 00000010D050: D6130018 844620FF BFB8AA3B
	v_rndne_f32_e32 v25, v17                                   // 00000010D05C: 7E324711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010D060: BF870221
	v_sub_f32_e32 v17, v17, v25                                // 00000010D064: 08223311
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000010D068: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v24, v16, 0xb2a5705f, v24                      // 00000010D070: 58303110 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010D078: BF870121
	v_add_f32_e32 v17, v17, v24                                // 00000010D07C: 06223111
	v_cvt_i32_f32_e32 v24, v25                                 // 00000010D080: 7E301119
	v_exp_f32_e32 v17, v17                                     // 00000010D084: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D088: BF870095
	.long 0xd71c0011                                           // 00000010D08C: D71C0011
	v_cndmask_b32_e32 v1, v17, v24, vcc_lo                     // 00000010D090: 02023111
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000010D094: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000010D098: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D0A0: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v136, v18// 00000010D0A4: CA4622FF 10102588 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000010D0B0: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D0B4: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 00000010D0B8: D6FC7C12 04462110
	v_rcp_f32_e32 v24, v18                                     // 00000010D0C0: 7E305512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D0C4: BF870095
	v_fma_f32 v25, -v18, v24, 1.0                              // 00000010D0C8: D6130019 23CA3112
	v_fmac_f32_e32 v24, v25, v24                               // 00000010D0D0: 56303119
	v_div_scale_f32 v25, vcc_lo, v17, v16, v17                 // 00000010D0D4: D6FC6A19 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D0DC: BF870091
	v_mul_f32_e32 v26, v25, v24                                // 00000010D0E0: 10343119
	v_fma_f32 v27, -v18, v26, v25                              // 00000010D0E4: D613001B 24663512
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D0EC: BF870091
	v_fmac_f32_e32 v26, v27, v24                               // 00000010D0F0: 5634311B
	v_fma_f32 v18, -v18, v26, v25                              // 00000010D0F4: D6130012 24663512
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D0FC: BF870091
	v_div_fmas_f32 v18, v18, v24, v26                          // 00000010D100: D6370012 046A3112
	v_div_fixup_f32 v18, v18, v16, v17                         // 00000010D108: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v121, v[128:129]     // 00000010D110: D6FF7C10 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D11C: BF870092
	v_bfe_u32 v24, v18, 16, 1                                  // 00000010D120: D6100018 02052112
	v_add3_u32 v18, v18, v24, 0x7fff                           // 00000010D128: D6550012 03FE3112 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 00000010D134: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010D13C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000010D140: BE882003
	s_cbranch_execz 58275                                      // 00000010D144: BFA5E3A3 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42d4>
	v_mad_i64_i32 v[16:17], null, 0x6000, v122, v[130:131]     // 00000010D148: D6FF7C10 060AF4FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 00000010D154: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000010D15C: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000010D160: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D164: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 00000010D168: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000010D170: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v24, v17                                   // 00000010D17C: 7E304711
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D180: BF870091
	v_dual_fmamk_f32 v18, v16, 0xb2a5705f, v18 :: v_dual_sub_f32 v17, v17, v24// 00000010D184: C88A2510 12103111 B2A5705F
	v_add_f32_e32 v17, v17, v18                                // 00000010D190: 06222511
	v_cvt_i32_f32_e32 v18, v24                                 // 00000010D194: 7E241118
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000010D198: 7C3C20FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010D1A0: BF870293
	v_exp_f32_e32 v17, v17                                     // 00000010D1A4: 7E224B11
	.long 0xd71c0011                                           // 00000010D1A8: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000010D1AC: 02022511
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010D1B0: BF870121
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000010D1B4: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000010D1B8: 7C3620FF C2B17218
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v137, v19// 00000010D1C0: CA4622FF 10102789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D1CC: BF870091
	v_add_f32_e32 v16, 1.0, v16                                // 00000010D1D0: 062020F2
	v_div_scale_f32 v18, null, v16, v16, v17                   // 00000010D1D4: D6FC7C12 04462110
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010D1DC: BF870291
	v_rcp_f32_e32 v19, v18                                     // 00000010D1E0: 7E265512
	v_fma_f32 v24, -v18, v19, 1.0                              // 00000010D1E4: D6130018 23CA2712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000010D1EC: BF8700A1
	v_fmac_f32_e32 v19, v24, v19                               // 00000010D1F0: 56262718
	v_div_scale_f32 v24, vcc_lo, v17, v16, v17                 // 00000010D1F4: D6FC6A18 04462111
	v_mul_f32_e32 v25, v24, v19                                // 00000010D1FC: 10322718
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D200: BF870091
	v_fma_f32 v26, -v18, v25, v24                              // 00000010D204: D613001A 24623312
	v_fmac_f32_e32 v25, v26, v19                               // 00000010D20C: 5632271A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D210: BF870091
	v_fma_f32 v18, -v18, v25, v24                              // 00000010D214: D6130012 24623312
	v_div_fmas_f32 v18, v18, v19, v25                          // 00000010D21C: D6370012 04662712
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010D224: BF870121
	v_div_fixup_f32 v18, v18, v16, v17                         // 00000010D228: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v122, v[128:129]     // 00000010D230: D6FF7C10 0602F4FF 00003000
	v_bfe_u32 v19, v18, 16, 1                                  // 00000010D23C: D6100013 02052112
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010D244: BF870001
	v_add3_u32 v18, v18, v19, 0x7fff                           // 00000010D248: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 00000010D254: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010D25C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000010D260: BE882004
	s_cbranch_execz 58206                                      // 00000010D264: BFA5E35E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42e0>
	v_mad_i64_i32 v[16:17], null, 0x6000, v123, v[130:131]     // 00000010D268: D6FF7C10 060AF6FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 00000010D274: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000010D27C: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000010D280: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D284: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 00000010D288: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000010D290: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000010D29C: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010D2A0: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 00000010D2A4: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000010D2A8: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000010D2B0: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010D2B8: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000010D2BC: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000010D2C0: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000010D2C4: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D2C8: BF870095
	.long 0xd71c0011                                           // 00000010D2CC: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000010D2D0: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000010D2D4: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000010D2D8: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D2E0: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v134, v20// 00000010D2E4: CA4622FF 10102986 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000010D2F0: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D2F4: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 00000010D2F8: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000010D300: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D304: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 00000010D308: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000010D310: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 00000010D314: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D31C: BF870091
	v_mul_f32_e32 v24, v20, v19                                // 00000010D320: 10302714
	v_fma_f32 v25, -v18, v24, v20                              // 00000010D324: D6130019 24523112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D32C: BF870091
	v_fmac_f32_e32 v24, v25, v19                               // 00000010D330: 56302719
	v_fma_f32 v18, -v18, v24, v20                              // 00000010D334: D6130012 24523112
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D33C: BF870091
	v_div_fmas_f32 v18, v18, v19, v24                          // 00000010D340: D6370012 04622712
	v_div_fixup_f32 v18, v18, v16, v17                         // 00000010D348: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v123, v[128:129]     // 00000010D350: D6FF7C10 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D35C: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 00000010D360: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 00000010D368: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 00000010D374: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010D37C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000010D380: BE882005
	s_cbranch_execz 58137                                      // 00000010D384: BFA5E319 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42ec>
	v_mad_i64_i32 v[16:17], null, 0x6000, v124, v[130:131]     // 00000010D388: D6FF7C10 060AF8FF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 00000010D394: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000010D39C: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000010D3A0: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D3A4: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 00000010D3A8: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000010D3B0: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000010D3BC: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010D3C0: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 00000010D3C4: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000010D3C8: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000010D3D0: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010D3D8: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000010D3DC: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000010D3E0: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000010D3E4: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D3E8: BF870095
	.long 0xd71c0011                                           // 00000010D3EC: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000010D3F0: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000010D3F4: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000010D3F8: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D400: BF870092
	v_cndmask_b32_e32 v16, 0x7f800000, v17, vcc_lo             // 00000010D404: 022022FF 7F800000
	v_dual_mul_f32 v17, v135, v21 :: v_dual_add_f32 v16, 1.0, v16// 00000010D40C: C8C82B87 111020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D414: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 00000010D418: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000010D420: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D424: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 00000010D428: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000010D430: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 00000010D434: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D43C: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 00000010D440: 102A2714
	v_fma_f32 v24, -v18, v21, v20                              // 00000010D444: D6130018 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D44C: BF870091
	v_fmac_f32_e32 v21, v24, v19                               // 00000010D450: 562A2718
	v_fma_f32 v18, -v18, v21, v20                              // 00000010D454: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D45C: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 00000010D460: D6370012 04562712
	v_div_fixup_f32 v18, v18, v16, v17                         // 00000010D468: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v124, v[128:129]     // 00000010D470: D6FF7C10 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D47C: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 00000010D480: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 00000010D488: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 00000010D494: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010D49C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000010D4A0: BE882006
	s_cbranch_execz 58068                                      // 00000010D4A4: BFA5E2D4 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x42f8>
	v_mad_i64_i32 v[16:17], null, 0x6000, v125, v[130:131]     // 00000010D4A8: D6FF7C10 060AFAFF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 00000010D4B4: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000010D4BC: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000010D4C0: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D4C4: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 00000010D4C8: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000010D4D0: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000010D4DC: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010D4E0: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 00000010D4E4: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000010D4E8: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000010D4F0: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010D4F8: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000010D4FC: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000010D500: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000010D504: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D508: BF870095
	.long 0xd71c0011                                           // 00000010D50C: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000010D510: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000010D514: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000010D518: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D520: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v132, v22// 00000010D524: CA4622FF 10102D84 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000010D530: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D534: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 00000010D538: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000010D540: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D544: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 00000010D548: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000010D550: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 00000010D554: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D55C: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 00000010D560: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 00000010D564: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D56C: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 00000010D570: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 00000010D574: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D57C: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 00000010D580: D6370012 04562712
	v_div_fixup_f32 v18, v18, v16, v17                         // 00000010D588: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v125, v[128:129]     // 00000010D590: D6FF7C10 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D59C: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 00000010D5A0: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 00000010D5A8: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 00000010D5B4: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010D5BC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000010D5C0: BE882007
	s_cbranch_execz 57999                                      // 00000010D5C4: BFA5E28F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4304>
	v_mad_i64_i32 v[16:17], null, 0x6000, v126, v[130:131]     // 00000010D5C8: D6FF7C10 060AFCFF 00006000
	global_load_u16 v16, v[16:17], off offset:928              // 00000010D5D4: DC4A03A0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000010D5DC: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000010D5E0: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D5E4: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 00000010D5E8: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000010D5F0: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000010D5FC: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010D600: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 00000010D604: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000010D608: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000010D610: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010D618: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000010D61C: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000010D620: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000010D624: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D628: BF870095
	.long 0xd71c0011                                           // 00000010D62C: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000010D630: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000010D634: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000010D638: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D640: BF870092
	v_dual_cndmask_b32 v16, 0x7f800000, v17 :: v_dual_mul_f32 v17, v133, v23// 00000010D644: CA4622FF 10102F85 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000010D650: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D654: BF870091
	v_div_scale_f32 v18, null, v16, v16, v17                   // 00000010D658: D6FC7C12 04462110
	v_rcp_f32_e32 v19, v18                                     // 00000010D660: 7E265512
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D664: BF870095
	v_fma_f32 v20, -v18, v19, 1.0                              // 00000010D668: D6130014 23CA2712
	v_fmac_f32_e32 v19, v20, v19                               // 00000010D670: 56262714
	v_div_scale_f32 v20, vcc_lo, v17, v16, v17                 // 00000010D674: D6FC6A14 04462111
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D67C: BF870091
	v_mul_f32_e32 v21, v20, v19                                // 00000010D680: 102A2714
	v_fma_f32 v22, -v18, v21, v20                              // 00000010D684: D6130016 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D68C: BF870091
	v_fmac_f32_e32 v21, v22, v19                               // 00000010D690: 562A2716
	v_fma_f32 v18, -v18, v21, v20                              // 00000010D694: D6130012 24522B12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D69C: BF870091
	v_div_fmas_f32 v18, v18, v19, v21                          // 00000010D6A0: D6370012 04562712
	v_div_fixup_f32 v18, v18, v16, v17                         // 00000010D6A8: D6270012 04462112
	v_mad_i64_i32 v[16:17], null, 0x3000, v126, v[128:129]     // 00000010D6B0: D6FF7C10 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D6BC: BF870092
	v_bfe_u32 v19, v18, 16, 1                                  // 00000010D6C0: D6100013 02052112
	v_add3_u32 v18, v18, v19, 0x7fff                           // 00000010D6C8: D6550012 03FE2712 00007FFF
	global_store_d16_hi_b16 v[16:17], v18, off offset:416      // 00000010D6D4: DC9601A0 007C1210
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010D6DC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000010D6E0: BE882000
	s_cbranch_execz 57930                                      // 00000010D6E4: BFA5E24A <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4310>
	v_mad_i64_i32 v[16:17], null, 0x6000, v140, v[130:131]     // 00000010D6E8: D6FF7C10 060B18FF 00006000
	v_mul_f32_e32 v8, v138, v8                                 // 00000010D6F4: 1010118A
	global_load_u16 v16, v[16:17], off offset:960              // 00000010D6F8: DC4A03C0 107C0010
	s_waitcnt vmcnt(0)                                         // 00000010D700: BF8903F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 00000010D704: 30202090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D708: BF870091
	v_mul_f32_e32 v17, 0xbfb8aa3b, v16                         // 00000010D70C: 102220FF BFB8AA3B
	v_fma_f32 v18, 0xbfb8aa3b, v16, -v17                       // 00000010D714: D6130012 844620FF BFB8AA3B
	v_rndne_f32_e32 v19, v17                                   // 00000010D720: 7E264711
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010D724: BF870221
	v_sub_f32_e32 v17, v17, v19                                // 00000010D728: 08222711
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v16                  // 00000010D72C: 7C3C20FF 42CE8ED0
	v_fmamk_f32 v18, v16, 0xb2a5705f, v18                      // 00000010D734: 58242510 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010D73C: BF870121
	v_add_f32_e32 v17, v17, v18                                // 00000010D740: 06222511
	v_cvt_i32_f32_e32 v18, v19                                 // 00000010D744: 7E241113
	v_exp_f32_e32 v17, v17                                     // 00000010D748: 7E224B11
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D74C: BF870095
	.long 0xd71c0011                                           // 00000010D750: D71C0011
	v_cndmask_b32_e32 v1, v17, v18, vcc_lo                     // 00000010D754: 02022511
	v_cndmask_b32_e32 v17, 0, v17, vcc_lo                      // 00000010D758: 02222280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v16                  // 00000010D75C: 7C3620FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D764: BF870092
	v_cndmask_b32_e32 v16, 0x7f800000, v17, vcc_lo             // 00000010D768: 022022FF 7F800000
	v_add_f32_e32 v16, 1.0, v16                                // 00000010D770: 062020F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D774: BF870091
	v_div_scale_f32 v17, null, v16, v16, v8                    // 00000010D778: D6FC7C11 04222110
	v_rcp_f32_e32 v18, v17                                     // 00000010D780: 7E245511
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D784: BF870095
	v_fma_f32 v19, -v17, v18, 1.0                              // 00000010D788: D6130013 23CA2511
	v_fmac_f32_e32 v18, v19, v18                               // 00000010D790: 56242513
	v_div_scale_f32 v19, vcc_lo, v8, v16, v8                   // 00000010D794: D6FC6A13 04222108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D79C: BF870091
	v_mul_f32_e32 v20, v19, v18                                // 00000010D7A0: 10282513
	v_fma_f32 v21, -v17, v20, v19                              // 00000010D7A4: D6130015 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D7AC: BF870091
	v_fmac_f32_e32 v20, v21, v18                               // 00000010D7B0: 56282515
	v_fma_f32 v17, -v17, v20, v19                              // 00000010D7B4: D6130011 244E2911
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D7BC: BF870091
	v_div_fmas_f32 v17, v17, v18, v20                          // 00000010D7C0: D6370011 04522511
	v_div_fixup_f32 v8, v17, v16, v8                           // 00000010D7C8: D6270008 04222111
	v_mad_i64_i32 v[16:17], null, 0x3000, v140, v[128:129]     // 00000010D7D0: D6FF7C10 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D7DC: BF870092
	v_bfe_u32 v18, v8, 16, 1                                   // 00000010D7E0: D6100012 02052108
	v_add3_u32 v8, v8, v18, 0x7fff                             // 00000010D7E8: D6550008 03FE2508 00007FFF
	global_store_d16_hi_b16 v[16:17], v8, off offset:448       // 00000010D7F4: DC9601C0 007C0810
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010D7FC: 8C7E087E
	s_and_saveexec_b32 s8, s1                                  // 00000010D800: BE882001
	s_cbranch_execz 57861                                      // 00000010D804: BFA5E205 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x431c>
	v_mad_i64_i32 v[16:17], null, 0x6000, v120, v[130:131]     // 00000010D808: D6FF7C10 060AF0FF 00006000
	v_mul_f32_e32 v9, v139, v9                                 // 00000010D814: 1012138B
	global_load_u16 v8, v[16:17], off offset:960               // 00000010D818: DC4A03C0 087C0010
	s_waitcnt vmcnt(0)                                         // 00000010D820: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000010D824: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010D828: BF870121
	v_mul_f32_e32 v16, 0xbfb8aa3b, v8                          // 00000010D82C: 102010FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000010D834: 7C3C10FF 42CE8ED0
	v_fma_f32 v17, 0xbfb8aa3b, v8, -v16                        // 00000010D83C: D6130011 844210FF BFB8AA3B
	v_rndne_f32_e32 v18, v16                                   // 00000010D848: 7E244710
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010D84C: BF870112
	v_fmamk_f32 v17, v8, 0xb2a5705f, v17                       // 00000010D850: 58222308 B2A5705F
	v_sub_f32_e32 v16, v16, v18                                // 00000010D858: 08202510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010D85C: BF870121
	v_add_f32_e32 v16, v16, v17                                // 00000010D860: 06202310
	v_cvt_i32_f32_e32 v17, v18                                 // 00000010D864: 7E221112
	v_exp_f32_e32 v16, v16                                     // 00000010D868: 7E204B10
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D86C: BF870095
	.long 0xd71c0010                                           // 00000010D870: D71C0010
	v_cndmask_b32_e32 v1, v16, v17, vcc_lo                     // 00000010D874: 02022310
	v_cndmask_b32_e32 v16, 0, v16, vcc_lo                      // 00000010D878: 02202080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000010D87C: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D884: BF870092
	v_cndmask_b32_e32 v8, 0x7f800000, v16, vcc_lo              // 00000010D888: 021020FF 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 00000010D890: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D894: BF870091
	v_div_scale_f32 v16, null, v8, v8, v9                      // 00000010D898: D6FC7C10 04261108
	v_rcp_f32_e32 v17, v16                                     // 00000010D8A0: 7E225510
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D8A4: BF870095
	v_fma_f32 v18, -v16, v17, 1.0                              // 00000010D8A8: D6130012 23CA2310
	v_fmac_f32_e32 v17, v18, v17                               // 00000010D8B0: 56222312
	v_div_scale_f32 v18, vcc_lo, v9, v8, v9                    // 00000010D8B4: D6FC6A12 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D8BC: BF870091
	v_mul_f32_e32 v19, v18, v17                                // 00000010D8C0: 10262312
	v_fma_f32 v20, -v16, v19, v18                              // 00000010D8C4: D6130014 244A2710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D8CC: BF870091
	v_fmac_f32_e32 v19, v20, v17                               // 00000010D8D0: 56262314
	v_fma_f32 v16, -v16, v19, v18                              // 00000010D8D4: D6130010 244A2710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D8DC: BF870091
	v_div_fmas_f32 v16, v16, v17, v19                          // 00000010D8E0: D6370010 044E2310
	v_div_fixup_f32 v16, v16, v8, v9                           // 00000010D8E8: D6270010 04261110
	v_mad_i64_i32 v[8:9], null, 0x3000, v120, v[128:129]       // 00000010D8F0: D6FF7C08 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D8FC: BF870092
	v_bfe_u32 v17, v16, 16, 1                                  // 00000010D900: D6100011 02052110
	v_add3_u32 v16, v16, v17, 0x7fff                           // 00000010D908: D6550010 03FE2310 00007FFF
	global_store_d16_hi_b16 v[8:9], v16, off offset:448        // 00000010D914: DC9601C0 007C1008
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010D91C: 8C7E087E
	s_and_saveexec_b32 s8, s2                                  // 00000010D920: BE882002
	s_cbranch_execz 57792                                      // 00000010D924: BFA5E1C0 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4328>
	v_mad_i64_i32 v[8:9], null, 0x6000, v121, v[130:131]       // 00000010D928: D6FF7C08 060AF2FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 00000010D934: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000010D93C: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000010D940: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D944: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000010D948: 101210FF BFB8AA3B
	v_fma_f32 v16, 0xbfb8aa3b, v8, -v9                         // 00000010D950: D6130010 842610FF BFB8AA3B
	v_rndne_f32_e32 v17, v9                                    // 00000010D95C: 7E224709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010D960: BF870221
	v_sub_f32_e32 v9, v9, v17                                  // 00000010D964: 08122309
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000010D968: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v16, v8, 0xb2a5705f, v16                       // 00000010D970: 58202108 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010D978: BF870121
	v_add_f32_e32 v9, v9, v16                                  // 00000010D97C: 06122109
	v_cvt_i32_f32_e32 v16, v17                                 // 00000010D980: 7E201111
	v_exp_f32_e32 v9, v9                                       // 00000010D984: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D988: BF870095
	.long 0xd71c0009                                           // 00000010D98C: D71C0009
	v_cndmask_b32_e32 v1, v9, v16, vcc_lo                      // 00000010D990: 02022109
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000010D994: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000010D998: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D9A0: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v136, v10// 00000010D9A4: CA4612FF 08081588 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 00000010D9B0: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D9B4: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 00000010D9B8: D6FC7C0A 04261108
	v_rcp_f32_e32 v16, v10                                     // 00000010D9C0: 7E20550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D9C4: BF870095
	v_fma_f32 v17, -v10, v16, 1.0                              // 00000010D9C8: D6130011 23CA210A
	v_fmac_f32_e32 v16, v17, v16                               // 00000010D9D0: 56202111
	v_div_scale_f32 v17, vcc_lo, v9, v8, v9                    // 00000010D9D4: D6FC6A11 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D9DC: BF870091
	v_mul_f32_e32 v18, v17, v16                                // 00000010D9E0: 10242111
	v_fma_f32 v19, -v10, v18, v17                              // 00000010D9E4: D6130013 2446250A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D9EC: BF870091
	v_fmac_f32_e32 v18, v19, v16                               // 00000010D9F0: 56242113
	v_fma_f32 v10, -v10, v18, v17                              // 00000010D9F4: D613000A 2446250A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010D9FC: BF870091
	v_div_fmas_f32 v10, v10, v16, v18                          // 00000010DA00: D637000A 044A210A
	v_div_fixup_f32 v10, v10, v8, v9                           // 00000010DA08: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v121, v[128:129]       // 00000010DA10: D6FF7C08 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DA1C: BF870092
	v_bfe_u32 v16, v10, 16, 1                                  // 00000010DA20: D6100010 0205210A
	v_add3_u32 v10, v10, v16, 0x7fff                           // 00000010DA28: D655000A 03FE210A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 00000010DA34: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010DA3C: 8C7E087E
	s_and_saveexec_b32 s8, s3                                  // 00000010DA40: BE882003
	s_cbranch_execz 57723                                      // 00000010DA44: BFA5E17B <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4334>
	v_mad_i64_i32 v[8:9], null, 0x6000, v122, v[130:131]       // 00000010DA48: D6FF7C08 060AF4FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 00000010DA54: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000010DA5C: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000010DA60: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DA64: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000010DA68: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 00000010DA70: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v16, v9                                    // 00000010DA7C: 7E204709
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DA80: BF870091
	v_dual_fmamk_f32 v10, v8, 0xb2a5705f, v10 :: v_dual_sub_f32 v9, v9, v16// 00000010DA84: C88A1508 0A082109 B2A5705F
	v_add_f32_e32 v9, v9, v10                                  // 00000010DA90: 06121509
	v_cvt_i32_f32_e32 v10, v16                                 // 00000010DA94: 7E141110
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000010DA98: 7C3C10FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010DAA0: BF870293
	v_exp_f32_e32 v9, v9                                       // 00000010DAA4: 7E124B09
	.long 0xd71c0009                                           // 00000010DAA8: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000010DAAC: 02021509
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010DAB0: BF870121
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000010DAB4: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000010DAB8: 7C3610FF C2B17218
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v137, v11// 00000010DAC0: CA4612FF 08081789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DACC: BF870091
	v_add_f32_e32 v8, 1.0, v8                                  // 00000010DAD0: 061010F2
	v_div_scale_f32 v10, null, v8, v8, v9                      // 00000010DAD4: D6FC7C0A 04261108
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010DADC: BF870291
	v_rcp_f32_e32 v11, v10                                     // 00000010DAE0: 7E16550A
	v_fma_f32 v16, -v10, v11, 1.0                              // 00000010DAE4: D6130010 23CA170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000010DAEC: BF8700A1
	v_fmac_f32_e32 v11, v16, v11                               // 00000010DAF0: 56161710
	v_div_scale_f32 v16, vcc_lo, v9, v8, v9                    // 00000010DAF4: D6FC6A10 04261109
	v_mul_f32_e32 v17, v16, v11                                // 00000010DAFC: 10221710
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DB00: BF870091
	v_fma_f32 v18, -v10, v17, v16                              // 00000010DB04: D6130012 2442230A
	v_fmac_f32_e32 v17, v18, v11                               // 00000010DB0C: 56221712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DB10: BF870091
	v_fma_f32 v10, -v10, v17, v16                              // 00000010DB14: D613000A 2442230A
	v_div_fmas_f32 v10, v10, v11, v17                          // 00000010DB1C: D637000A 0446170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010DB24: BF870121
	v_div_fixup_f32 v10, v10, v8, v9                           // 00000010DB28: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v122, v[128:129]       // 00000010DB30: D6FF7C08 0602F4FF 00003000
	v_bfe_u32 v11, v10, 16, 1                                  // 00000010DB3C: D610000B 0205210A
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010DB44: BF870001
	v_add3_u32 v10, v10, v11, 0x7fff                           // 00000010DB48: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 00000010DB54: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010DB5C: 8C7E087E
	s_and_saveexec_b32 s8, s4                                  // 00000010DB60: BE882004
	s_cbranch_execz 57654                                      // 00000010DB64: BFA5E136 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4340>
	v_mad_i64_i32 v[8:9], null, 0x6000, v123, v[130:131]       // 00000010DB68: D6FF7C08 060AF6FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 00000010DB74: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000010DB7C: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000010DB80: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DB84: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000010DB88: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 00000010DB90: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 00000010DB9C: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010DBA0: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 00000010DBA4: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000010DBA8: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 00000010DBB0: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010DBB8: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 00000010DBBC: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 00000010DBC0: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 00000010DBC4: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DBC8: BF870095
	.long 0xd71c0009                                           // 00000010DBCC: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000010DBD0: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000010DBD4: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000010DBD8: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DBE0: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v134, v12// 00000010DBE4: CA4612FF 08081986 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 00000010DBF0: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DBF4: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 00000010DBF8: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 00000010DC00: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DC04: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 00000010DC08: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000010DC10: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 00000010DC14: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DC1C: BF870091
	v_mul_f32_e32 v16, v12, v11                                // 00000010DC20: 1020170C
	v_fma_f32 v17, -v10, v16, v12                              // 00000010DC24: D6130011 2432210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DC2C: BF870091
	v_fmac_f32_e32 v16, v17, v11                               // 00000010DC30: 56201711
	v_fma_f32 v10, -v10, v16, v12                              // 00000010DC34: D613000A 2432210A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DC3C: BF870091
	v_div_fmas_f32 v10, v10, v11, v16                          // 00000010DC40: D637000A 0442170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 00000010DC48: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v123, v[128:129]       // 00000010DC50: D6FF7C08 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DC5C: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 00000010DC60: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 00000010DC68: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 00000010DC74: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010DC7C: 8C7E087E
	s_and_saveexec_b32 s8, s5                                  // 00000010DC80: BE882005
	s_cbranch_execz 57585                                      // 00000010DC84: BFA5E0F1 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x434c>
	v_mad_i64_i32 v[8:9], null, 0x6000, v124, v[130:131]       // 00000010DC88: D6FF7C08 060AF8FF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 00000010DC94: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000010DC9C: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000010DCA0: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DCA4: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000010DCA8: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 00000010DCB0: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 00000010DCBC: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010DCC0: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 00000010DCC4: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000010DCC8: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 00000010DCD0: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010DCD8: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 00000010DCDC: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 00000010DCE0: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 00000010DCE4: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DCE8: BF870095
	.long 0xd71c0009                                           // 00000010DCEC: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000010DCF0: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000010DCF4: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000010DCF8: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DD00: BF870092
	v_cndmask_b32_e32 v8, 0x7f800000, v9, vcc_lo               // 00000010DD04: 021012FF 7F800000
	v_dual_mul_f32 v9, v135, v13 :: v_dual_add_f32 v8, 1.0, v8 // 00000010DD0C: C8C81B87 090810F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DD14: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 00000010DD18: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 00000010DD20: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DD24: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 00000010DD28: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000010DD30: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 00000010DD34: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DD3C: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 00000010DD40: 101A170C
	v_fma_f32 v16, -v10, v13, v12                              // 00000010DD44: D6130010 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DD4C: BF870091
	v_fmac_f32_e32 v13, v16, v11                               // 00000010DD50: 561A1710
	v_fma_f32 v10, -v10, v13, v12                              // 00000010DD54: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DD5C: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 00000010DD60: D637000A 0436170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 00000010DD68: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v124, v[128:129]       // 00000010DD70: D6FF7C08 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DD7C: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 00000010DD80: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 00000010DD88: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 00000010DD94: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010DD9C: 8C7E087E
	s_and_saveexec_b32 s8, s6                                  // 00000010DDA0: BE882006
	s_cbranch_execz 57516                                      // 00000010DDA4: BFA5E0AC <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4358>
	v_mad_i64_i32 v[8:9], null, 0x6000, v125, v[130:131]       // 00000010DDA8: D6FF7C08 060AFAFF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 00000010DDB4: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000010DDBC: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000010DDC0: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DDC4: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000010DDC8: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 00000010DDD0: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 00000010DDDC: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010DDE0: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 00000010DDE4: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000010DDE8: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 00000010DDF0: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010DDF8: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 00000010DDFC: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 00000010DE00: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 00000010DE04: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DE08: BF870095
	.long 0xd71c0009                                           // 00000010DE0C: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000010DE10: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000010DE14: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000010DE18: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DE20: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v132, v14// 00000010DE24: CA4612FF 08081D84 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 00000010DE30: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DE34: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 00000010DE38: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 00000010DE40: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DE44: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 00000010DE48: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000010DE50: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 00000010DE54: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DE5C: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 00000010DE60: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 00000010DE64: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DE6C: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 00000010DE70: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 00000010DE74: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DE7C: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 00000010DE80: D637000A 0436170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 00000010DE88: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v125, v[128:129]       // 00000010DE90: D6FF7C08 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DE9C: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 00000010DEA0: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 00000010DEA8: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 00000010DEB4: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010DEBC: 8C7E087E
	s_and_saveexec_b32 s8, s7                                  // 00000010DEC0: BE882007
	s_cbranch_execz 57447                                      // 00000010DEC4: BFA5E067 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4364>
	v_mad_i64_i32 v[8:9], null, 0x6000, v126, v[130:131]       // 00000010DEC8: D6FF7C08 060AFCFF 00006000
	global_load_u16 v8, v[8:9], off offset:960                 // 00000010DED4: DC4A03C0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000010DEDC: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000010DEE0: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DEE4: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000010DEE8: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 00000010DEF0: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 00000010DEFC: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010DF00: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 00000010DF04: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000010DF08: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 00000010DF10: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010DF18: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 00000010DF1C: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 00000010DF20: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 00000010DF24: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DF28: BF870095
	.long 0xd71c0009                                           // 00000010DF2C: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000010DF30: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000010DF34: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000010DF38: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DF40: BF870092
	v_dual_cndmask_b32 v8, 0x7f800000, v9 :: v_dual_mul_f32 v9, v133, v15// 00000010DF44: CA4612FF 08081F85 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 00000010DF50: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DF54: BF870091
	v_div_scale_f32 v10, null, v8, v8, v9                      // 00000010DF58: D6FC7C0A 04261108
	v_rcp_f32_e32 v11, v10                                     // 00000010DF60: 7E16550A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DF64: BF870095
	v_fma_f32 v12, -v10, v11, 1.0                              // 00000010DF68: D613000C 23CA170A
	v_fmac_f32_e32 v11, v12, v11                               // 00000010DF70: 5616170C
	v_div_scale_f32 v12, vcc_lo, v9, v8, v9                    // 00000010DF74: D6FC6A0C 04261109
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DF7C: BF870091
	v_mul_f32_e32 v13, v12, v11                                // 00000010DF80: 101A170C
	v_fma_f32 v14, -v10, v13, v12                              // 00000010DF84: D613000E 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DF8C: BF870091
	v_fmac_f32_e32 v13, v14, v11                               // 00000010DF90: 561A170E
	v_fma_f32 v10, -v10, v13, v12                              // 00000010DF94: D613000A 24321B0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DF9C: BF870091
	v_div_fmas_f32 v10, v10, v11, v13                          // 00000010DFA0: D637000A 0436170A
	v_div_fixup_f32 v10, v10, v8, v9                           // 00000010DFA8: D627000A 0426110A
	v_mad_i64_i32 v[8:9], null, 0x3000, v126, v[128:129]       // 00000010DFB0: D6FF7C08 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010DFBC: BF870092
	v_bfe_u32 v11, v10, 16, 1                                  // 00000010DFC0: D610000B 0205210A
	v_add3_u32 v10, v10, v11, 0x7fff                           // 00000010DFC8: D655000A 03FE170A 00007FFF
	global_store_d16_hi_b16 v[8:9], v10, off offset:448        // 00000010DFD4: DC9601C0 007C0A08
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010DFDC: 8C7E087E
	s_and_saveexec_b32 s8, s0                                  // 00000010DFE0: BE882000
	s_cbranch_execz 57378                                      // 00000010DFE4: BFA5E022 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4370>
	v_mad_i64_i32 v[8:9], null, 0x6000, v140, v[130:131]       // 00000010DFE8: D6FF7C08 060B18FF 00006000
	v_mul_f32_e32 v0, v138, v0                                 // 00000010DFF4: 1000018A
	global_load_u16 v8, v[8:9], off offset:992                 // 00000010DFF8: DC4A03E0 087C0008
	s_waitcnt vmcnt(0)                                         // 00000010E000: BF8903F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 00000010E004: 30101090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E008: BF870091
	v_mul_f32_e32 v9, 0xbfb8aa3b, v8                           // 00000010E00C: 101210FF BFB8AA3B
	v_fma_f32 v10, 0xbfb8aa3b, v8, -v9                         // 00000010E014: D613000A 842610FF BFB8AA3B
	v_rndne_f32_e32 v11, v9                                    // 00000010E020: 7E164709
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010E024: BF870221
	v_sub_f32_e32 v9, v9, v11                                  // 00000010E028: 08121709
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v8                   // 00000010E02C: 7C3C10FF 42CE8ED0
	v_fmamk_f32 v10, v8, 0xb2a5705f, v10                       // 00000010E034: 58141508 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010E03C: BF870121
	v_add_f32_e32 v9, v9, v10                                  // 00000010E040: 06121509
	v_cvt_i32_f32_e32 v10, v11                                 // 00000010E044: 7E14110B
	v_exp_f32_e32 v9, v9                                       // 00000010E048: 7E124B09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E04C: BF870095
	.long 0xd71c0009                                           // 00000010E050: D71C0009
	v_cndmask_b32_e32 v1, v9, v10, vcc_lo                      // 00000010E054: 02021509
	v_cndmask_b32_e32 v9, 0, v9, vcc_lo                        // 00000010E058: 02121280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v8                   // 00000010E05C: 7C3610FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E064: BF870092
	v_cndmask_b32_e32 v8, 0x7f800000, v9, vcc_lo               // 00000010E068: 021012FF 7F800000
	v_add_f32_e32 v8, 1.0, v8                                  // 00000010E070: 061010F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E074: BF870091
	v_div_scale_f32 v9, null, v8, v8, v0                       // 00000010E078: D6FC7C09 04021108
	v_rcp_f32_e32 v10, v9                                      // 00000010E080: 7E145509
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E084: BF870095
	v_fma_f32 v11, -v9, v10, 1.0                               // 00000010E088: D613000B 23CA1509
	v_fmac_f32_e32 v10, v11, v10                               // 00000010E090: 5614150B
	v_div_scale_f32 v11, vcc_lo, v0, v8, v0                    // 00000010E094: D6FC6A0B 04021100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E09C: BF870091
	v_mul_f32_e32 v12, v11, v10                                // 00000010E0A0: 1018150B
	v_fma_f32 v13, -v9, v12, v11                               // 00000010E0A4: D613000D 242E1909
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E0AC: BF870091
	v_fmac_f32_e32 v12, v13, v10                               // 00000010E0B0: 5618150D
	v_fma_f32 v9, -v9, v12, v11                                // 00000010E0B4: D6130009 242E1909
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E0BC: BF870091
	v_div_fmas_f32 v9, v9, v10, v12                            // 00000010E0C0: D6370009 04321509
	v_div_fixup_f32 v0, v9, v8, v0                             // 00000010E0C8: D6270000 04021109
	v_mad_i64_i32 v[8:9], null, 0x3000, v140, v[128:129]       // 00000010E0D0: D6FF7C08 060318FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E0DC: BF870092
	v_bfe_u32 v10, v0, 16, 1                                   // 00000010E0E0: D610000A 02052100
	v_add3_u32 v0, v0, v10, 0x7fff                             // 00000010E0E8: D6550000 03FE1500 00007FFF
	global_store_d16_hi_b16 v[8:9], v0, off offset:480         // 00000010E0F4: DC9601E0 007C0008
	s_or_b32 exec_lo, exec_lo, s8                              // 00000010E0FC: 8C7E087E
	s_and_saveexec_b32 s0, s1                                  // 00000010E100: BE802001
	s_cbranch_execz 57309                                      // 00000010E104: BFA5DFDD <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x437c>
	v_mad_i64_i32 v[8:9], null, 0x6000, v120, v[130:131]       // 00000010E108: D6FF7C08 060AF0FF 00006000
	v_mul_f32_e32 v1, v139, v1                                 // 00000010E114: 1002038B
	global_load_u16 v0, v[8:9], off offset:992                 // 00000010E118: DC4A03E0 007C0008
	s_waitcnt vmcnt(0)                                         // 00000010E120: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000010E124: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010E128: BF870121
	v_mul_f32_e32 v8, 0xbfb8aa3b, v0                           // 00000010E12C: 101000FF BFB8AA3B
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000010E134: 7C3C00FF 42CE8ED0
	v_fma_f32 v9, 0xbfb8aa3b, v0, -v8                          // 00000010E13C: D6130009 842200FF BFB8AA3B
	v_rndne_f32_e32 v10, v8                                    // 00000010E148: 7E144708
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000010E14C: BF870112
	v_fmamk_f32 v9, v0, 0xb2a5705f, v9                         // 00000010E150: 58121300 B2A5705F
	v_sub_f32_e32 v8, v8, v10                                  // 00000010E158: 08101508
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010E15C: BF870121
	v_add_f32_e32 v8, v8, v9                                   // 00000010E160: 06101308
	v_cvt_i32_f32_e32 v9, v10                                  // 00000010E164: 7E12110A
	v_exp_f32_e32 v8, v8                                       // 00000010E168: 7E104B08
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E16C: BF870095
	.long 0xd71c0008                                           // 00000010E170: D71C0008
	v_cndmask_b32_e32 v1, v8, v9, vcc_lo                       // 00000010E174: 02021308
	v_cndmask_b32_e32 v8, 0, v8, vcc_lo                        // 00000010E178: 02101080
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000010E17C: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E184: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v8, vcc_lo               // 00000010E188: 020010FF 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000010E190: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E194: BF870091
	v_div_scale_f32 v8, null, v0, v0, v1                       // 00000010E198: D6FC7C08 04060100
	v_rcp_f32_e32 v9, v8                                       // 00000010E1A0: 7E125508
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E1A4: BF870095
	v_fma_f32 v10, -v8, v9, 1.0                                // 00000010E1A8: D613000A 23CA1308
	v_fmac_f32_e32 v9, v10, v9                                 // 00000010E1B0: 5612130A
	v_div_scale_f32 v10, vcc_lo, v1, v0, v1                    // 00000010E1B4: D6FC6A0A 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E1BC: BF870091
	v_mul_f32_e32 v11, v10, v9                                 // 00000010E1C0: 1016130A
	v_fma_f32 v12, -v8, v11, v10                               // 00000010E1C4: D613000C 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E1CC: BF870091
	v_fmac_f32_e32 v11, v12, v9                                // 00000010E1D0: 5616130C
	v_fma_f32 v8, -v8, v11, v10                                // 00000010E1D4: D6130008 242A1708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E1DC: BF870091
	v_div_fmas_f32 v8, v8, v9, v11                             // 00000010E1E0: D6370008 042E1308
	v_div_fixup_f32 v8, v8, v0, v1                             // 00000010E1E8: D6270008 04060108
	v_mad_i64_i32 v[0:1], null, 0x3000, v120, v[128:129]       // 00000010E1F0: D6FF7C00 0602F0FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E1FC: BF870092
	v_bfe_u32 v9, v8, 16, 1                                    // 00000010E200: D6100009 02052108
	v_add3_u32 v8, v8, v9, 0x7fff                              // 00000010E208: D6550008 03FE1308 00007FFF
	global_store_d16_hi_b16 v[0:1], v8, off offset:480         // 00000010E214: DC9601E0 007C0800
	s_or_b32 exec_lo, exec_lo, s0                              // 00000010E21C: 8C7E007E
	s_and_saveexec_b32 s0, s2                                  // 00000010E220: BE802002
	s_cbranch_execz 57240                                      // 00000010E224: BFA5DF98 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4388>
	v_mad_i64_i32 v[0:1], null, 0x6000, v121, v[130:131]       // 00000010E228: D6FF7C00 060AF2FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000010E234: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000010E23C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000010E240: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E244: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000010E248: 100200FF BFB8AA3B
	v_fma_f32 v8, 0xbfb8aa3b, v0, -v1                          // 00000010E250: D6130008 840600FF BFB8AA3B
	v_rndne_f32_e32 v9, v1                                     // 00000010E25C: 7E124701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010E260: BF870221
	v_sub_f32_e32 v1, v1, v9                                   // 00000010E264: 08021301
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000010E268: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v8, v0, 0xb2a5705f, v8                         // 00000010E270: 58101100 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010E278: BF870121
	v_add_f32_e32 v1, v1, v8                                   // 00000010E27C: 06021101
	v_cvt_i32_f32_e32 v8, v9                                   // 00000010E280: 7E101109
	v_exp_f32_e32 v1, v1                                       // 00000010E284: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E288: BF870095
	.long 0xd71c0001                                           // 00000010E28C: D71C0001
	v_cndmask_b32_e32 v1, v1, v8, vcc_lo                       // 00000010E290: 02021101
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000010E294: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000010E298: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E2A0: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v136, v2// 00000010E2A4: CA4602FF 00000588 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000010E2B0: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E2B4: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000010E2B8: D6FC7C02 04060100
	v_rcp_f32_e32 v8, v2                                       // 00000010E2C0: 7E105502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E2C4: BF870095
	v_fma_f32 v9, -v2, v8, 1.0                                 // 00000010E2C8: D6130009 23CA1102
	v_fmac_f32_e32 v8, v9, v8                                  // 00000010E2D0: 56101109
	v_div_scale_f32 v9, vcc_lo, v1, v0, v1                     // 00000010E2D4: D6FC6A09 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E2DC: BF870091
	v_mul_f32_e32 v10, v9, v8                                  // 00000010E2E0: 10141109
	v_fma_f32 v11, -v2, v10, v9                                // 00000010E2E4: D613000B 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E2EC: BF870091
	v_fmac_f32_e32 v10, v11, v8                                // 00000010E2F0: 5614110B
	v_fma_f32 v2, -v2, v10, v9                                 // 00000010E2F4: D6130002 24261502
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E2FC: BF870091
	v_div_fmas_f32 v2, v2, v8, v10                             // 00000010E300: D6370002 042A1102
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000010E308: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v121, v[128:129]       // 00000010E310: D6FF7C00 0602F2FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E31C: BF870092
	v_bfe_u32 v8, v2, 16, 1                                    // 00000010E320: D6100008 02052102
	v_add3_u32 v2, v2, v8, 0x7fff                              // 00000010E328: D6550002 03FE1102 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000010E334: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000010E33C: 8C7E007E
	s_and_saveexec_b32 s0, s3                                  // 00000010E340: BE802003
	s_cbranch_execz 57171                                      // 00000010E344: BFA5DF53 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x4394>
	v_mad_i64_i32 v[0:1], null, 0x6000, v122, v[130:131]       // 00000010E348: D6FF7C00 060AF4FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000010E354: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000010E35C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000010E360: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E364: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000010E368: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000010E370: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v8, v1                                     // 00000010E37C: 7E104701
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E380: BF870091
	v_dual_fmamk_f32 v2, v0, 0xb2a5705f, v2 :: v_dual_sub_f32 v1, v1, v8// 00000010E384: C88A0500 02001101 B2A5705F
	v_add_f32_e32 v1, v1, v2                                   // 00000010E390: 06020501
	v_cvt_i32_f32_e32 v2, v8                                   // 00000010E394: 7E041108
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000010E398: 7C3C00FF 42CE8ED0
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010E3A0: BF870293
	v_exp_f32_e32 v1, v1                                       // 00000010E3A4: 7E024B01
	.long 0xd71c0001                                           // 00000010E3A8: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000010E3AC: 02020501
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010E3B0: BF870121
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000010E3B4: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000010E3B8: 7C3600FF C2B17218
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v137, v3// 00000010E3C0: CA4602FF 00000789 7F800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E3CC: BF870091
	v_add_f32_e32 v0, 1.0, v0                                  // 00000010E3D0: 060000F2
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000010E3D4: D6FC7C02 04060100
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000010E3DC: BF870291
	v_rcp_f32_e32 v3, v2                                       // 00000010E3E0: 7E065502
	v_fma_f32 v8, -v2, v3, 1.0                                 // 00000010E3E4: D6130008 23CA0702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000010E3EC: BF8700A1
	v_fmac_f32_e32 v3, v8, v3                                  // 00000010E3F0: 56060708
	v_div_scale_f32 v8, vcc_lo, v1, v0, v1                     // 00000010E3F4: D6FC6A08 04060101
	v_mul_f32_e32 v9, v8, v3                                   // 00000010E3FC: 10120708
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E400: BF870091
	v_fma_f32 v10, -v2, v9, v8                                 // 00000010E404: D613000A 24221302
	v_fmac_f32_e32 v9, v10, v3                                 // 00000010E40C: 5612070A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E410: BF870091
	v_fma_f32 v2, -v2, v9, v8                                  // 00000010E414: D6130002 24221302
	v_div_fmas_f32 v2, v2, v3, v9                              // 00000010E41C: D6370002 04260702
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010E424: BF870121
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000010E428: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v122, v[128:129]       // 00000010E430: D6FF7C00 0602F4FF 00003000
	v_bfe_u32 v3, v2, 16, 1                                    // 00000010E43C: D6100003 02052102
	s_delay_alu instid0(VALU_DEP_1)                            // 00000010E444: BF870001
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000010E448: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000010E454: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000010E45C: 8C7E007E
	s_and_saveexec_b32 s0, s4                                  // 00000010E460: BE802004
	s_cbranch_execz 57102                                      // 00000010E464: BFA5DF0E <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x43a0>
	v_mad_i64_i32 v[0:1], null, 0x6000, v123, v[130:131]       // 00000010E468: D6FF7C00 060AF6FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000010E474: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000010E47C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000010E480: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E484: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000010E488: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000010E490: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000010E49C: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010E4A0: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000010E4A4: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000010E4A8: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000010E4B0: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010E4B8: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000010E4BC: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000010E4C0: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000010E4C4: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E4C8: BF870095
	.long 0xd71c0001                                           // 00000010E4CC: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000010E4D0: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000010E4D4: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000010E4D8: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E4E0: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v134, v4// 00000010E4E4: CA4602FF 00000986 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000010E4F0: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E4F4: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000010E4F8: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000010E500: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E504: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000010E508: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000010E510: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000010E514: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E51C: BF870091
	v_mul_f32_e32 v8, v4, v3                                   // 00000010E520: 10100704
	v_fma_f32 v9, -v2, v8, v4                                  // 00000010E524: D6130009 24121102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E52C: BF870091
	v_fmac_f32_e32 v8, v9, v3                                  // 00000010E530: 56100709
	v_fma_f32 v2, -v2, v8, v4                                  // 00000010E534: D6130002 24121102
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E53C: BF870091
	v_div_fmas_f32 v2, v2, v3, v8                              // 00000010E540: D6370002 04220702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000010E548: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v123, v[128:129]       // 00000010E550: D6FF7C00 0602F6FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E55C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000010E560: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000010E568: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000010E574: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000010E57C: 8C7E007E
	s_and_saveexec_b32 s0, s5                                  // 00000010E580: BE802005
	s_cbranch_execz 57033                                      // 00000010E584: BFA5DEC9 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x43ac>
	v_mad_i64_i32 v[0:1], null, 0x6000, v124, v[130:131]       // 00000010E588: D6FF7C00 060AF8FF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000010E594: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000010E59C: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000010E5A0: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E5A4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000010E5A8: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000010E5B0: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000010E5BC: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010E5C0: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000010E5C4: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000010E5C8: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000010E5D0: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010E5D8: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000010E5DC: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000010E5E0: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000010E5E4: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E5E8: BF870095
	.long 0xd71c0001                                           // 00000010E5EC: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000010E5F0: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000010E5F4: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000010E5F8: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E600: BF870092
	v_cndmask_b32_e32 v0, 0x7f800000, v1, vcc_lo               // 00000010E604: 020002FF 7F800000
	v_dual_mul_f32 v1, v135, v5 :: v_dual_add_f32 v0, 1.0, v0  // 00000010E60C: C8C80B87 010000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E614: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000010E618: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000010E620: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E624: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000010E628: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000010E630: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000010E634: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E63C: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000010E640: 100A0704
	v_fma_f32 v8, -v2, v5, v4                                  // 00000010E644: D6130008 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E64C: BF870091
	v_fmac_f32_e32 v5, v8, v3                                  // 00000010E650: 560A0708
	v_fma_f32 v2, -v2, v5, v4                                  // 00000010E654: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E65C: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000010E660: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000010E668: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v124, v[128:129]       // 00000010E670: D6FF7C00 0602F8FF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E67C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000010E680: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000010E688: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000010E694: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000010E69C: 8C7E007E
	s_and_saveexec_b32 s0, s6                                  // 00000010E6A0: BE802006
	s_cbranch_execz 56964                                      // 00000010E6A4: BFA5DE84 <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x43b8>
	v_mad_i64_i32 v[0:1], null, 0x6000, v125, v[130:131]       // 00000010E6A8: D6FF7C00 060AFAFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000010E6B4: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000010E6BC: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000010E6C0: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E6C4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000010E6C8: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000010E6D0: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000010E6DC: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010E6E0: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000010E6E4: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000010E6E8: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000010E6F0: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010E6F8: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000010E6FC: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000010E700: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000010E704: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E708: BF870095
	.long 0xd71c0001                                           // 00000010E70C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000010E710: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000010E714: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000010E718: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E720: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v132, v6// 00000010E724: CA4602FF 00000D84 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000010E730: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E734: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000010E738: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000010E740: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E744: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000010E748: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000010E750: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000010E754: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E75C: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000010E760: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000010E764: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E76C: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000010E770: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000010E774: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E77C: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000010E780: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000010E788: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v125, v[128:129]       // 00000010E790: D6FF7C00 0602FAFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E79C: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000010E7A0: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000010E7A8: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000010E7B4: DC9601E0 007C0200
	s_or_b32 exec_lo, exec_lo, s0                              // 00000010E7BC: 8C7E007E
	s_and_saveexec_b32 s0, s7                                  // 00000010E7C0: BE802007
	s_cbranch_execz 56895                                      // 00000010E7C4: BFA5DE3F <_ZN7halogen12_GLOBAL__N_110k_attn_fa2ILi2ELi1ELb1ELi3ELi0ELb0EEEvPKtS3_S3_lS3_PtPKiiiNS_5FaSelE+0x43c4>
	v_mad_i64_i32 v[0:1], null, 0x6000, v126, v[130:131]       // 00000010E7C8: D6FF7C00 060AFCFF 00006000
	global_load_u16 v0, v[0:1], off offset:992                 // 00000010E7D4: DC4A03E0 007C0000
	s_waitcnt vmcnt(0)                                         // 00000010E7DC: BF8903F7
	v_lshlrev_b32_e32 v0, 16, v0                               // 00000010E7E0: 30000090
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E7E4: BF870091
	v_mul_f32_e32 v1, 0xbfb8aa3b, v0                           // 00000010E7E8: 100200FF BFB8AA3B
	v_fma_f32 v2, 0xbfb8aa3b, v0, -v1                          // 00000010E7F0: D6130002 840600FF BFB8AA3B
	v_rndne_f32_e32 v3, v1                                     // 00000010E7FC: 7E064701
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 00000010E800: BF870221
	v_sub_f32_e32 v1, v1, v3                                   // 00000010E804: 08020701
	v_cmp_nlt_f32_e32 vcc_lo, 0x42ce8ed0, v0                   // 00000010E808: 7C3C00FF 42CE8ED0
	v_fmamk_f32 v2, v0, 0xb2a5705f, v2                         // 00000010E810: 58040500 B2A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000010E818: BF870121
	v_add_f32_e32 v1, v1, v2                                   // 00000010E81C: 06020501
	v_cvt_i32_f32_e32 v2, v3                                   // 00000010E820: 7E041103
	v_exp_f32_e32 v1, v1                                       // 00000010E824: 7E024B01
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E828: BF870095
	.long 0xd71c0001                                           // 00000010E82C: D71C0001
	v_cndmask_b32_e32 v1, v1, v2, vcc_lo                       // 00000010E830: 02020501
	v_cndmask_b32_e32 v1, 0, v1, vcc_lo                        // 00000010E834: 02020280
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2b17218, v0                   // 00000010E838: 7C3600FF C2B17218
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E840: BF870092
	v_dual_cndmask_b32 v0, 0x7f800000, v1 :: v_dual_mul_f32 v1, v133, v7// 00000010E844: CA4602FF 00000F85 7F800000
	v_add_f32_e32 v0, 1.0, v0                                  // 00000010E850: 060000F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E854: BF870091
	v_div_scale_f32 v2, null, v0, v0, v1                       // 00000010E858: D6FC7C02 04060100
	v_rcp_f32_e32 v3, v2                                       // 00000010E860: 7E065502
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E864: BF870095
	v_fma_f32 v4, -v2, v3, 1.0                                 // 00000010E868: D6130004 23CA0702
	v_fmac_f32_e32 v3, v4, v3                                  // 00000010E870: 56060704
	v_div_scale_f32 v4, vcc_lo, v1, v0, v1                     // 00000010E874: D6FC6A04 04060101
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E87C: BF870091
	v_mul_f32_e32 v5, v4, v3                                   // 00000010E880: 100A0704
	v_fma_f32 v6, -v2, v5, v4                                  // 00000010E884: D6130006 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E88C: BF870091
	v_fmac_f32_e32 v5, v6, v3                                  // 00000010E890: 560A0706
	v_fma_f32 v2, -v2, v5, v4                                  // 00000010E894: D6130002 24120B02
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E89C: BF870091
	v_div_fmas_f32 v2, v2, v3, v5                              // 00000010E8A0: D6370002 04160702
	v_div_fixup_f32 v2, v2, v0, v1                             // 00000010E8A8: D6270002 04060102
	v_mad_i64_i32 v[0:1], null, 0x3000, v126, v[128:129]       // 00000010E8B0: D6FF7C00 0602FCFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000010E8BC: BF870092
	v_bfe_u32 v3, v2, 16, 1                                    // 00000010E8C0: D6100003 02052102
	v_add3_u32 v2, v2, v3, 0x7fff                              // 00000010E8C8: D6550002 03FE0702 00007FFF
	global_store_d16_hi_b16 v[0:1], v2, off offset:480         // 00000010E8D4: DC9601E0 007C0200
	s_endpgm                                                   // 00000010E8DC: BFB00000
		...

