000000000011eb00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 00000011EB00: BF850001
	s_load_b512 s[4:19], s[0:1], 0x8                           // 00000011EB04: F4100100 F8000008
	s_load_b128 s[20:23], s[0:1], 0x48                         // 00000011EB0C: F4080500 F8000048
	s_lshl_b32 s26, s3, 4                                      // 00000011EB14: 841A8403
	s_ashr_i32 s3, s2, 31                                      // 00000011EB18: 86039F02
	s_ashr_i32 s27, s26, 31                                    // 00000011EB1C: 861B9F1A
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 00000011EB20: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000011EB28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 00000011EB2C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 00000011EB30: BF89FC07
	s_load_b32 s24, s[18:19], null                             // 00000011EB34: F4000609 F8000000
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000011EB3C: 84928214
	s_add_u32 s25, s16, s18                                    // 00000011EB40: 80191210
	s_addc_u32 s28, s17, s19                                   // 00000011EB44: 821C1311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 00000011EB48: 84949002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011EB4C: BF870009
	s_add_u32 s25, s25, s20                                    // 00000011EB50: 80191419
	s_addc_u32 s30, s28, s21                                   // 00000011EB54: 821E151C
	s_waitcnt lgkmcnt(0)                                       // 00000011EB58: BF89FC07
	s_mul_i32 s28, s24, 0x9000000                              // 00000011EB5C: 961CFF18 09000000
	s_mul_hi_i32 s29, s24, 0x9000000                           // 00000011EB64: 971DFF18 09000000
	s_add_u32 s31, s25, s28                                    // 00000011EB6C: 801F1C19
	s_addc_u32 s30, s30, s29                                   // 00000011EB70: 821E1D1E
	s_lshl_b64 s[24:25], s[26:27], 2                           // 00000011EB74: 8498821A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000011EB78: BF8700B9
	s_add_u32 s31, s31, s24                                    // 00000011EB7C: 801F181F
	s_addc_u32 s30, s30, s25                                   // 00000011EB80: 821E191E
	.long 0xd7001f02                                           // 00000011EB84: D7001F02
	v_cndmask_b32_e32 v1, s31, v1, vcc_lo                      // 00000011EB88: 0202021F
	v_add_co_ci_u32_e64 v3, null, s30, 0, s31                  // 00000011EB8C: D5207C03 007D001E
	s_mov_b32 s30, 0                                           // 00000011EB94: BE9E0080
	s_nop 0                                                    // 00000011EB98: BF800000
	s_nop 0                                                    // 00000011EB9C: BF800000
	s_nop 0                                                    // 00000011EBA0: BF800000
	s_nop 0                                                    // 00000011EBA4: BF800000
	s_nop 0                                                    // 00000011EBA8: BF800000
	s_nop 0                                                    // 00000011EBAC: BF800000
	s_nop 0                                                    // 00000011EBB0: BF800000
	s_nop 0                                                    // 00000011EBB4: BF800000
	s_nop 0                                                    // 00000011EBB8: BF800000
	s_nop 0                                                    // 00000011EBBC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 00000011EBC0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 00000011EBC4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EBCC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 00000011EBD0: 300C1089
	.long 0xd7006a06                                           // 00000011EBD4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 00000011EBD8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011EBDC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 00000011EBE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000011EBE8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 00000011EBF0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 00000011EBF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 00000011EBFC: D6FE7C06 040610FF 00000044
	s_or_b32 s30, vcc_lo, s30                                  // 00000011EC08: 8C1E1E6A
	s_waitcnt vmcnt(0)                                         // 00000011EC0C: BF8903F7
	ds_store_b32 v6, v9                                        // 00000011EC10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s30                       // 00000011EC18: 917E1E7E
	s_cbranch_execnz 65512                                     // 00000011EC1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s30                             // 00000011EC20: 8C7E1E7E
	s_load_b32 s30, s[0:1], 0x58                               // 00000011EC24: F4000780 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 00000011EC2C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 00000011EC34: 32040084
	s_mov_b32 s0, 0                                            // 00000011EC38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 00000011EC3C: BF89FC07
	s_barrier                                                  // 00000011EC40: BFBD0000
	buffer_gl0_inv                                             // 00000011EC44: E0AC0000 00000000
	s_cmp_gt_i32 s30, 0                                        // 00000011EC4C: BF02801E
	s_cbranch_scc1 12                                          // 00000011EC50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 00000011EC54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 00000011EC5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011EC64: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 00000011EC68: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 00000011EC70: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000011EC74: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 00000011EC78: 916A007E
	s_cbranch_vccz 2                                           // 00000011EC7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2551                                              // 00000011EC80: BFA009F7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2960>
	v_lshlrev_b32_e32 v39, 2, v5                               // 00000011EC84: 304E0A82
	s_add_i32 s0, s30, 63                                      // 00000011EC88: 8100BF1E
	s_add_i32 s31, s2, 0xbd0                                   // 00000011EC8C: 811FFF02 00000BD0
	s_lshr_b32 s33, s0, 6                                      // 00000011EC94: 85218600
	s_add_u32 s34, s10, s24                                    // 00000011EC98: 8022180A
	s_addc_u32 s35, s11, s25                                   // 00000011EC9C: 8223190B
	s_lshl_b32 s0, s2, 7                                       // 00000011ECA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 00000011ECA4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 00000011ECAC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 00000011ECB0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 00000011ECB4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 00000011ECB8: 301A0488
	s_add_u32 s22, s22, s0                                     // 00000011ECBC: 80160016
	s_addc_u32 s1, s23, s1                                     // 00000011ECC0: 82010117
	s_lshl_b64 s[10:11], s[26:27], 1                           // 00000011ECC4: 848A811A
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 00000011ECC8: D60B0025 049E04FF 00000044
	s_add_u32 s22, s22, s10                                    // 00000011ECD4: 80160A16
	s_addc_u32 s1, s1, s11                                     // 00000011ECD8: 82010B01
	s_movk_i32 s10, 0x204                                      // 00000011ECDC: B00A0204
	.long 0xd7000b2c                                           // 00000011ECE0: D7000B2C
	v_cndmask_b32_e32 v1, s34, v39, vcc_lo                     // 00000011ECE4: 02024E22
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 00000011ECE8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s35, 0, s11                 // 00000011ECEC: D5207C2D 002D0023
	v_mad_u32_u24 v46, v2, s10, 0x3300                         // 00000011ECF4: D60B002E 03FC1502 00003300
	s_lshl_b64 s[10:11], s[2:3], 9                             // 00000011ED00: 848A8902
	v_dual_mov_b32 v12, s11 :: v_dual_add_nc_u32 v41, 0x4320, v40// 00000011ED04: CA20000B 0C2850FF 00004320
	v_or_b32_e32 v11, s10, v40                                 // 00000011ED10: 3816500A
	.long 0xd7000a05                                           // 00000011ED14: D7000A05
	v_cndmask_b32_e32 v1, s22, v5, vcc_lo                      // 00000011ED18: 02020A16
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011ED1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s10                   // 00000011ED20: D5207C06 00290001
	.long 0xd7000107                                           // 00000011ED28: D7000107
	v_cndmask_b32_e32 v1, s12, v11, vcc_lo                     // 00000011ED2C: 0202160C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011ED30: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s13, v12, s1                 // 00000011ED34: D5207C08 0006180D
	.long 0xd7000109                                           // 00000011ED3C: D7000109
	v_cndmask_b32_e32 v1, s4, v11, vcc_lo                      // 00000011ED40: 02021604
	v_add_co_ci_u32_e64 v10, null, s5, v12, s1                 // 00000011ED44: D5207C0A 00061805
	s_lshl_b64 s[4:5], s[2:3], 14                              // 00000011ED4C: 84848E02
	.long 0xd700010b                                           // 00000011ED50: D700010B
	v_cndmask_b32_e32 v1, s6, v11, vcc_lo                      // 00000011ED54: 02021606
	s_add_u32 s4, s14, s4                                      // 00000011ED58: 8004040E
	v_add_co_ci_u32_e64 v12, null, s7, v12, s1                 // 00000011ED5C: D5207C0C 00061807
	s_addc_u32 s5, s15, s5                                     // 00000011ED64: 8205050F
	.long 0xd700010d                                           // 00000011ED68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 00000011ED6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011ED70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 00000011ED74: D5207C0E 00050005
	.long 0xd700010f                                           // 00000011ED7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 00000011ED80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 00000011ED88: D5207C10 00061880
	.long 0xd7000111                                           // 00000011ED90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 00000011ED94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011ED9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 00000011EDA0: D5207C12 00061880
	.long 0xd7000113                                           // 00000011EDA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 00000011EDAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 00000011EDB4: D5207C14 00061880
	.long 0xd7000115                                           // 00000011EDBC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 00000011EDC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011EDC8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 00000011EDCC: D5207C16 00061880
	.long 0xd7000117                                           // 00000011EDD4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 00000011EDD8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 00000011EDE0: D5207C18 00061880
	.long 0xd7000119                                           // 00000011EDE8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 00000011EDEC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011EDF4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 00000011EDF8: D5207C1A 00061880
	.long 0xd700011b                                           // 00000011EE00: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 00000011EE04: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 00000011EE0C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 00000011EE14: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 00000011EE18: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 00000011EE20: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 00000011EE24: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 00000011EE2C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 00000011EE34: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 00000011EE3C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 00000011EE44: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 00000011EE4C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 00000011EE54: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 00000011EE5C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 00000011EE64: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 00000011EE6C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 00000011EE74: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 00000011EE7C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 00000011EE84: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 00000011EE8C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 00000011EE94: 4A7602FF 00002000
	s_mov_b32 s5, 0                                            // 00000011EE9C: BE850080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 00000011EEA0: 7C9800C0
	s_mul_i32 s1, s5, 0xc00                                    // 00000011EEA4: 9601FF05 00000C00
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000011EEAC: BF870499
	s_add_i32 s6, s31, s1                                      // 00000011EEB0: 8106011F
	s_ashr_i32 s7, s6, 31                                      // 00000011EEB4: 86079F06
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000011EEB8: BF870009
	s_lshl_b64 s[10:11], s[6:7], 2                             // 00000011EEBC: 848A8206
	s_lshl_b32 s7, s5, 6                                       // 00000011EEC0: 84078605
	s_add_u32 s10, s8, s10                                     // 00000011EEC4: 800A0A08
	s_addc_u32 s11, s9, s11                                    // 00000011EEC8: 820B0B09
	s_load_b32 s6, s[10:11], null                              // 00000011EECC: F4000185 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 00000011EED4: BE84206A
	s_cbranch_execz 77                                         // 00000011EED8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s7, v0                                   // 00000011EEDC: 383A0007
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EEE0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 00000011EEE4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 00000011EEEC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011EEF0: BF870091
	.long 0xd73c001d                                           // 00000011EEF4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 00000011EEF8: 02023A82
	.long 0xd700011d                                           // 00000011EEFC: D700011D
	v_cndmask_b32_e32 v1, s8, v29, vcc_lo                      // 00000011EF00: 02023A08
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011EF04: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s9, v30, s1                 // 00000011EF08: D5207C1E 00063C09
	global_load_b32 v29, v[29:30], off                         // 00000011EF10: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000011EF18: BF890007
	v_sub_f32_e32 v30, s6, v29                                 // 00000011EF1C: 083C3A06
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 00000011EF20: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000011EF2C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 00000011EF30: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 00000011EF3C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 00000011EF40: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 00000011EF4C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 00000011EF50: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 00000011EF54: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 00000011EF60: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000011EF64: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 00000011EF68: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 00000011EF70: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 00000011EF74: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 00000011EF7C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 00000011EF84: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 00000011EF88: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011EF8C: BF870193
	v_exp_f32_e32 v32, v32                                     // 00000011EF90: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 00000011EF94: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 00000011EF98: BF870296
	.long 0xd71c0020                                           // 00000011EF9C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 00000011EFA0: 02024520
	.long 0xd71c001f                                           // 00000011EFA4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 00000011EFA8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011EFAC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 00000011EFB0: D501001F 00063E80
	.long 0xd41b0001                                           // 00000011EFB8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 00000011EFBC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 00000011EFC4: D5010020 00064080
	.long 0xd41e0001                                           // 00000011EFCC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 00000011EFD0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011EFD8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 00000011EFDC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 00000011EFE8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 00000011EFEC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 00000011EFF4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 00000011F000: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 00000011F008: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 00000011F010: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 00000011F014: CA100108 1E1C0107
	s_mov_b32 s10, 0                                           // 00000011F01C: BE8A0080
	s_waitcnt lgkmcnt(0)                                       // 00000011F020: BF89FC07
	s_barrier                                                  // 00000011F024: BFBD0000
	buffer_gl0_inv                                             // 00000011F028: E0AC0000 00000000
	s_branch 15                                                // 00000011F030: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000011F034: 8C7E047E
	.long 0xd700011d                                           // 00000011F038: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 00000011F03C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011F044: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000011F048: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000011F050: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000011F054: BF08B70A
	s_mov_b32 s10, s1                                          // 00000011F058: BE8A0001
	s_waitcnt lgkmcnt(0)                                       // 00000011F05C: BF89FC07
	s_barrier                                                  // 00000011F060: BFBD0000
	buffer_gl0_inv                                             // 00000011F064: E0AC0000 00000000
	s_cbranch_scc1 677                                         // 00000011F06C: BFA202A5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1004>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 00000011F070: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 00000011F078: CA100128 21220126
	s_mov_b32 s11, 0                                           // 00000011F080: BE8B0080
	s_nop 0                                                    // 00000011F084: BF800000
	s_nop 0                                                    // 00000011F088: BF800000
	s_nop 0                                                    // 00000011F08C: BF800000
	s_nop 0                                                    // 00000011F090: BF800000
	s_nop 0                                                    // 00000011F094: BF800000
	s_nop 0                                                    // 00000011F098: BF800000
	s_nop 0                                                    // 00000011F09C: BF800000
	s_nop 0                                                    // 00000011F0A0: BF800000
	s_nop 0                                                    // 00000011F0A4: BF800000
	s_nop 0                                                    // 00000011F0A8: BF800000
	s_nop 0                                                    // 00000011F0AC: BF800000
	s_nop 0                                                    // 00000011F0B0: BF800000
	s_nop 0                                                    // 00000011F0B4: BF800000
	s_nop 0                                                    // 00000011F0B8: BF800000
	s_nop 0                                                    // 00000011F0BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 00000011F0C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 00000011F0C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 00000011F0D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 00000011F0D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011F0DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000011F0E0: D5207C20 00064080
	.long 0xd4490004                                           // 00000011F0E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 00000011F0EC: 020244FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000011F0F4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000011F0F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 00000011F0FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 00000011F104: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000011F10C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000011F110: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000011F114: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000011F118: BF89FC07
	s_barrier                                                  // 00000011F11C: BFBD0000
	buffer_gl0_inv                                             // 00000011F120: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 00000011F128: BE842000
	s_cbranch_execz 65473                                      // 00000011F12C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_or3_b32 v31, s10, s7, v2                                 // 00000011F130: D658001F 04080E0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F138: BF870091
	v_mad_u64_u32 v[31:32], null, v31, 48, s[2:3]              // 00000011F13C: D6FE7C1F 0009611F
	.long 0xd73c001f                                           // 00000011F144: D73C001F
	v_cndmask_b32_e32 v1, 9, v31, vcc_lo                       // 00000011F148: 02023E89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011F14C: BF870091
	.long 0xd700011f                                           // 00000011F150: D700011F
	v_cndmask_b32_e32 v1, v44, v31, vcc_lo                     // 00000011F154: 02023F2C
	v_add_co_ci_u32_e64 v32, null, v45, v32, s1                // 00000011F158: D5207C20 0006412D
	global_load_b32 v68, v[31:32], off                         // 00000011F160: DC520000 447C001F
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 00000011F168: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v1 offset1:17                  // 00000011F170: D8DC1100 21000001
	ds_load_2addr_b32 v[35:36], v1 offset0:34 offset1:51       // 00000011F178: D8DC3322 23000001
	ds_load_2addr_b32 v[60:61], v46 offset0:2 offset1:3        // 00000011F180: D8DC0302 3C00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:4 offset1:5        // 00000011F188: D8DC0504 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:6 offset1:7        // 00000011F190: D8DC0706 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 00000011F198: D8DC5544 42000001
	s_waitcnt vmcnt(0) lgkmcnt(5)                              // 00000011F1A0: BF890057
	v_fma_f32 v31, -v31, v33, v68                              // 00000011F1A4: D613001F 2512431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F1AC: BF8700C1
	v_fma_f32 v33, -v32, v34, v31                              // 00000011F1B0: D6130021 247E4520
	ds_load_2addr_b32 v[31:32], v1 offset0:102 offset1:119     // 00000011F1B8: D8DC7766 1F000001
	s_waitcnt lgkmcnt(4)                                       // 00000011F1C0: BF89FC47
	v_fma_f32 v33, -v60, v35, v33                              // 00000011F1C4: D6130021 2486473C
	v_fma_f32 v60, -v61, v36, v33                              // 00000011F1CC: D613003C 2486493D
	ds_load_2addr_b32 v[33:34], v46 offset0:8 offset1:9        // 00000011F1D4: D8DC0908 2100002E
	ds_load_2addr_b32 v[35:36], v1 offset0:136 offset1:153     // 00000011F1DC: D8DC9988 23000001
	s_waitcnt lgkmcnt(3)                                       // 00000011F1E4: BF89FC37
	v_fma_f32 v60, -v62, v66, v60                              // 00000011F1E8: D613003C 24F2853E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011F1F0: BF8700D1
	v_fma_f32 v66, -v63, v67, v60                              // 00000011F1F4: D6130042 24F2873F
	ds_load_2addr_b32 v[60:61], v46 offset0:10 offset1:11      // 00000011F1FC: D8DC0B0A 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:170 offset1:187     // 00000011F204: D8DCBBAA 3E000001
	s_waitcnt lgkmcnt(4)                                       // 00000011F20C: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 00000011F210: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 00000011F218: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:12 offset1:13      // 00000011F220: D8DC0D0C 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:14 offset1:15      // 00000011F228: D8DC0F0E 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:204 offset1:221     // 00000011F230: D8DCDDCC 42000001
	s_waitcnt lgkmcnt(5)                                       // 00000011F238: BF89FC57
	v_fma_f32 v33, -v33, v35, v68                              // 00000011F23C: D6130021 25124721
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F244: BF8700C1
	v_fma_f32 v35, -v34, v36, v33                              // 00000011F248: D6130023 24864922
	ds_load_2addr_b32 v[33:34], v1 offset0:238 offset1:255     // 00000011F250: D8DCFFEE 21000001
	s_waitcnt lgkmcnt(4)                                       // 00000011F258: BF89FC47
	v_fma_f32 v35, -v60, v62, v35                              // 00000011F25C: D6130023 248E7D3C
	v_fma_f32 v62, -v61, v63, v35                              // 00000011F264: D613003E 248E7F3D
	ds_load_2addr_b32 v[35:36], v46 offset0:16 offset1:17      // 00000011F26C: D8DC1110 2300002E
	ds_load_2addr_b32 v[60:61], v48 offset0:16 offset1:33      // 00000011F274: D8DC2110 3C000030
	s_waitcnt lgkmcnt(3)                                       // 00000011F27C: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 00000011F280: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011F288: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 00000011F28C: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:18 offset1:19      // 00000011F294: D8DC1312 1F00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:50 offset1:67      // 00000011F29C: D8DC4332 3E000030
	s_waitcnt lgkmcnt(4)                                       // 00000011F2A4: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 00000011F2A8: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 00000011F2B0: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:20 offset1:21      // 00000011F2B8: D8DC1514 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:22 offset1:23      // 00000011F2C0: D8DC1716 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:84 offset1:101     // 00000011F2C8: D8DC6554 42000030
	s_waitcnt lgkmcnt(5)                                       // 00000011F2D0: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 00000011F2D4: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F2DC: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 00000011F2E0: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v48 offset0:118 offset1:135    // 00000011F2E8: D8DC8776 23000030
	s_waitcnt lgkmcnt(4)                                       // 00000011F2F0: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 00000011F2F4: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 00000011F2FC: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 00000011F304: D8DC1918 1F00002E
	ds_load_2addr_b32 v[60:61], v48 offset0:152 offset1:169    // 00000011F30C: D8DCA998 3C000030
	s_waitcnt lgkmcnt(3)                                       // 00000011F314: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 00000011F318: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011F320: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 00000011F324: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:26 offset1:27      // 00000011F32C: D8DC1B1A 2100002E
	ds_load_2addr_b32 v[62:63], v48 offset0:186 offset1:203    // 00000011F334: D8DCCBBA 3E000030
	s_waitcnt lgkmcnt(4)                                       // 00000011F33C: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 00000011F340: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 00000011F348: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:28 offset1:29      // 00000011F350: D8DC1D1C 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:30 offset1:31      // 00000011F358: D8DC1F1E 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:220 offset1:237    // 00000011F360: D8DCEDDC 42000030
	s_waitcnt lgkmcnt(5)                                       // 00000011F368: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 00000011F36C: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F374: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 00000011F378: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v49 offset0:126 offset1:143    // 00000011F380: D8DC8F7E 1F000031
	s_waitcnt lgkmcnt(4)                                       // 00000011F388: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 00000011F38C: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 00000011F394: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:32 offset1:33      // 00000011F39C: D8DC2120 2100002E
	ds_load_2addr_b32 v[60:61], v50 offset0:32 offset1:49      // 00000011F3A4: D8DC3120 3C000032
	s_waitcnt lgkmcnt(3)                                       // 00000011F3AC: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 00000011F3B0: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011F3B8: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 00000011F3BC: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:34 offset1:35      // 00000011F3C4: D8DC2322 2300002E
	ds_load_2addr_b32 v[62:63], v50 offset0:66 offset1:83      // 00000011F3CC: D8DC5342 3E000032
	s_waitcnt lgkmcnt(4)                                       // 00000011F3D4: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 00000011F3D8: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 00000011F3E0: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:36 offset1:37      // 00000011F3E8: D8DC2524 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:38 offset1:39      // 00000011F3F0: D8DC2726 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:100 offset1:117    // 00000011F3F8: D8DC7564 42000032
	s_waitcnt lgkmcnt(5)                                       // 00000011F400: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 00000011F404: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F40C: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 00000011F410: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v50 offset0:134 offset1:151    // 00000011F418: D8DC9786 21000032
	s_waitcnt lgkmcnt(4)                                       // 00000011F420: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 00000011F424: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 00000011F42C: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:40 offset1:41      // 00000011F434: D8DC2928 2300002E
	ds_load_2addr_b32 v[60:61], v50 offset0:168 offset1:185    // 00000011F43C: D8DCB9A8 3C000032
	s_waitcnt lgkmcnt(3)                                       // 00000011F444: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 00000011F448: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011F450: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 00000011F454: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:42 offset1:43      // 00000011F45C: D8DC2B2A 1F00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:202 offset1:219    // 00000011F464: D8DCDBCA 3E000032
	s_waitcnt lgkmcnt(4)                                       // 00000011F46C: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 00000011F470: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 00000011F478: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:44 offset1:45      // 00000011F480: D8DC2D2C 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:46 offset1:47      // 00000011F488: D8DC2F2E 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:236 offset1:253    // 00000011F490: D8DCFDEC 42000032
	s_waitcnt lgkmcnt(5)                                       // 00000011F498: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 00000011F49C: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F4A4: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 00000011F4A8: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v51 offset0:14 offset1:31      // 00000011F4B0: D8DC1F0E 23000033
	s_waitcnt lgkmcnt(4)                                       // 00000011F4B8: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 00000011F4BC: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 00000011F4C4: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 00000011F4CC: D8DC3130 1F00002E
	ds_load_2addr_b32 v[60:61], v51 offset0:48 offset1:65      // 00000011F4D4: D8DC4130 3C000033
	s_waitcnt lgkmcnt(3)                                       // 00000011F4DC: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 00000011F4E0: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011F4E8: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 00000011F4EC: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 00000011F4F4: D8DC3332 2100002E
	ds_load_2addr_b32 v[62:63], v51 offset0:82 offset1:99      // 00000011F4FC: D8DC6352 3E000033
	s_waitcnt lgkmcnt(4)                                       // 00000011F504: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 00000011F508: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 00000011F510: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 00000011F518: D8DC3534 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:54 offset1:55      // 00000011F520: D8DC3736 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:116 offset1:133    // 00000011F528: D8DC8574 42000033
	s_waitcnt lgkmcnt(5)                                       // 00000011F530: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 00000011F534: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F53C: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 00000011F540: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v51 offset0:150 offset1:167    // 00000011F548: D8DCA796 1F000033
	s_waitcnt lgkmcnt(4)                                       // 00000011F550: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 00000011F554: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 00000011F55C: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:56 offset1:57      // 00000011F564: D8DC3938 2100002E
	ds_load_2addr_b32 v[60:61], v51 offset0:184 offset1:201    // 00000011F56C: D8DCC9B8 3C000033
	s_waitcnt lgkmcnt(3)                                       // 00000011F574: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 00000011F578: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011F580: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 00000011F584: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:58 offset1:59      // 00000011F58C: D8DC3B3A 2300002E
	ds_load_2addr_b32 v[62:63], v51 offset0:218 offset1:235    // 00000011F594: D8DCEBDA 3E000033
	s_waitcnt lgkmcnt(4)                                       // 00000011F59C: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 00000011F5A0: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 00000011F5A8: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:60 offset1:61      // 00000011F5B0: D8DC3D3C 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:62 offset1:63      // 00000011F5B8: D8DC3F3E 4000002E
	ds_load_2addr_b32 v[66:67], v52 offset0:124 offset1:141    // 00000011F5C0: D8DC8D7C 42000034
	s_waitcnt lgkmcnt(5)                                       // 00000011F5C8: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 00000011F5CC: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F5D4: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 00000011F5D8: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v53 offset0:30 offset1:47      // 00000011F5E0: D8DC2F1E 21000035
	s_waitcnt lgkmcnt(4)                                       // 00000011F5E8: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 00000011F5EC: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 00000011F5F4: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:64 offset1:65      // 00000011F5FC: D8DC4140 2300002E
	ds_load_2addr_b32 v[60:61], v53 offset0:64 offset1:81      // 00000011F604: D8DC5140 3C000035
	s_waitcnt lgkmcnt(3)                                       // 00000011F60C: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 00000011F610: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011F618: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 00000011F61C: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:66 offset1:67      // 00000011F624: D8DC4342 1F00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:98 offset1:115     // 00000011F62C: D8DC7362 3E000035
	s_waitcnt lgkmcnt(4)                                       // 00000011F634: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 00000011F638: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 00000011F640: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:68 offset1:69      // 00000011F648: D8DC4544 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:70 offset1:71      // 00000011F650: D8DC4746 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:132 offset1:149    // 00000011F658: D8DC9584 42000035
	s_waitcnt lgkmcnt(5)                                       // 00000011F660: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 00000011F664: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F66C: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 00000011F670: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v53 offset0:166 offset1:183    // 00000011F678: D8DCB7A6 23000035
	s_waitcnt lgkmcnt(4)                                       // 00000011F680: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 00000011F684: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 00000011F68C: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 00000011F694: D8DC4948 1F00002E
	ds_load_2addr_b32 v[60:61], v53 offset0:200 offset1:217    // 00000011F69C: D8DCD9C8 3C000035
	s_waitcnt lgkmcnt(3)                                       // 00000011F6A4: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 00000011F6A8: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011F6B0: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 00000011F6B4: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:74 offset1:75      // 00000011F6BC: D8DC4B4A 2100002E
	ds_load_2addr_b32 v[62:63], v53 offset0:234 offset1:251    // 00000011F6C4: D8DCFBEA 3E000035
	s_waitcnt lgkmcnt(4)                                       // 00000011F6CC: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 00000011F6D0: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 00000011F6D8: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:76 offset1:77      // 00000011F6E0: D8DC4D4C 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:78 offset1:79      // 00000011F6E8: D8DC4F4E 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:12 offset1:29      // 00000011F6F0: D8DC1D0C 42000036
	s_waitcnt lgkmcnt(5)                                       // 00000011F6F8: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 00000011F6FC: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F704: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 00000011F708: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v54 offset0:46 offset1:63      // 00000011F710: D8DC3F2E 1F000036
	s_waitcnt lgkmcnt(4)                                       // 00000011F718: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 00000011F71C: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 00000011F724: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:80 offset1:81      // 00000011F72C: D8DC5150 2100002E
	ds_load_2addr_b32 v[60:61], v54 offset0:80 offset1:97      // 00000011F734: D8DC6150 3C000036
	s_waitcnt lgkmcnt(3)                                       // 00000011F73C: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 00000011F740: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011F748: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 00000011F74C: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:82 offset1:83      // 00000011F754: D8DC5352 2300002E
	ds_load_2addr_b32 v[62:63], v54 offset0:114 offset1:131    // 00000011F75C: D8DC8372 3E000036
	s_waitcnt lgkmcnt(4)                                       // 00000011F764: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 00000011F768: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 00000011F770: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:84 offset1:85      // 00000011F778: D8DC5554 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:86 offset1:87      // 00000011F780: D8DC5756 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:148 offset1:165    // 00000011F788: D8DCA594 42000036
	s_waitcnt lgkmcnt(5)                                       // 00000011F790: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 00000011F794: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F79C: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 00000011F7A0: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v54 offset0:182 offset1:199    // 00000011F7A8: D8DCC7B6 21000036
	s_waitcnt lgkmcnt(4)                                       // 00000011F7B0: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 00000011F7B4: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 00000011F7BC: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:88 offset1:89      // 00000011F7C4: D8DC5958 2300002E
	ds_load_2addr_b32 v[60:61], v54 offset0:216 offset1:233    // 00000011F7CC: D8DCE9D8 3C000036
	s_waitcnt lgkmcnt(3)                                       // 00000011F7D4: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 00000011F7D8: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011F7E0: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 00000011F7E4: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:90 offset1:91      // 00000011F7EC: D8DC5B5A 1F00002E
	ds_load_2addr_b32 v[62:63], v55 offset0:122 offset1:139    // 00000011F7F4: D8DC8B7A 3E000037
	s_waitcnt lgkmcnt(4)                                       // 00000011F7FC: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 00000011F800: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 00000011F808: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:92 offset1:93      // 00000011F810: D8DC5D5C 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:94 offset1:95      // 00000011F818: D8DC5F5E 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:28 offset1:45      // 00000011F820: D8DC2D1C 42000038
	s_waitcnt lgkmcnt(5)                                       // 00000011F828: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 00000011F82C: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F834: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 00000011F838: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v56 offset0:62 offset1:79      // 00000011F840: D8DC4F3E 23000038
	s_waitcnt lgkmcnt(4)                                       // 00000011F848: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 00000011F84C: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 00000011F854: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 00000011F85C: D8DC6160 1F00002E
	ds_load_2addr_b32 v[60:61], v56 offset0:96 offset1:113     // 00000011F864: D8DC7160 3C000038
	s_waitcnt lgkmcnt(3)                                       // 00000011F86C: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 00000011F870: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011F878: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 00000011F87C: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 00000011F884: D8DC6362 2100002E
	ds_load_2addr_b32 v[62:63], v56 offset0:130 offset1:147    // 00000011F88C: D8DC9382 3E000038
	s_waitcnt lgkmcnt(4)                                       // 00000011F894: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 00000011F898: D6130023 250A4740
	v_fma_f32 v68, -v65, v36, v35                              // 00000011F8A0: D6130044 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 00000011F8A8: D8DC6564 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:102 offset1:103    // 00000011F8B0: D8DC6766 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:164 offset1:181    // 00000011F8B8: D8DCB5A4 42000038
	s_waitcnt lgkmcnt(5)                                       // 00000011F8C0: BF89FC57
	v_fma_f32 v31, -v31, v60, v68                              // 00000011F8C4: D613001F 2512791F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F8CC: BF8700C1
	v_fma_f32 v60, -v32, v61, v31                              // 00000011F8D0: D613003C 247E7B20
	ds_load_2addr_b32 v[31:32], v56 offset0:198 offset1:215    // 00000011F8D8: D8DCD7C6 1F000038
	s_waitcnt lgkmcnt(4)                                       // 00000011F8E0: BF89FC47
	v_fma_f32 v33, -v33, v62, v60                              // 00000011F8E4: D6130021 24F27D21
	v_fma_f32 v62, -v34, v63, v33                              // 00000011F8EC: D613003E 24867F22
	ds_load_2addr_b32 v[33:34], v46 offset0:104 offset1:105    // 00000011F8F4: D8DC6968 2100002E
	ds_load_2addr_b32 v[60:61], v56 offset0:232 offset1:249    // 00000011F8FC: D8DCF9E8 3C000038
	s_waitcnt lgkmcnt(3)                                       // 00000011F904: BF89FC37
	v_fma_f32 v35, -v35, v66, v62                              // 00000011F908: D6130023 24FA8523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011F910: BF8700D1
	v_fma_f32 v66, -v36, v67, v35                              // 00000011F914: D6130042 248E8724
	ds_load_2addr_b32 v[35:36], v46 offset0:106 offset1:107    // 00000011F91C: D8DC6B6A 2300002E
	ds_load_2addr_b32 v[62:63], v57 offset0:10 offset1:27      // 00000011F924: D8DC1B0A 3E000039
	s_waitcnt lgkmcnt(4)                                       // 00000011F92C: BF89FC47
	v_fma_f32 v31, -v64, v31, v66                              // 00000011F930: D613001F 250A3F40
	v_fma_f32 v68, -v65, v32, v31                              // 00000011F938: D6130044 247E4141
	ds_load_2addr_b32 v[31:32], v46 offset0:108 offset1:109    // 00000011F940: D8DC6D6C 1F00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:110 offset1:111    // 00000011F948: D8DC6F6E 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:44 offset1:61      // 00000011F950: D8DC3D2C 42000039
	s_waitcnt lgkmcnt(5)                                       // 00000011F958: BF89FC57
	v_fma_f32 v33, -v33, v60, v68                              // 00000011F95C: D6130021 25127921
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F964: BF8700C1
	v_fma_f32 v60, -v34, v61, v33                              // 00000011F968: D613003C 24867B22
	ds_load_2addr_b32 v[33:34], v57 offset0:78 offset1:95      // 00000011F970: D8DC5F4E 21000039
	s_waitcnt lgkmcnt(4)                                       // 00000011F978: BF89FC47
	v_fma_f32 v35, -v35, v62, v60                              // 00000011F97C: D6130023 24F27D23
	v_fma_f32 v62, -v36, v63, v35                              // 00000011F984: D613003E 248E7F24
	ds_load_2addr_b32 v[35:36], v46 offset0:112 offset1:113    // 00000011F98C: D8DC7170 2300002E
	ds_load_2addr_b32 v[60:61], v57 offset0:112 offset1:129    // 00000011F994: D8DC8170 3C000039
	s_waitcnt lgkmcnt(3)                                       // 00000011F99C: BF89FC37
	v_fma_f32 v31, -v31, v66, v62                              // 00000011F9A0: D613001F 24FA851F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011F9A8: BF8700D1
	v_fma_f32 v66, -v32, v67, v31                              // 00000011F9AC: D6130042 247E8720
	ds_load_2addr_b32 v[31:32], v46 offset0:114 offset1:115    // 00000011F9B4: D8DC7372 1F00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:146 offset1:163    // 00000011F9BC: D8DCA392 3E000039
	s_waitcnt lgkmcnt(4)                                       // 00000011F9C4: BF89FC47
	v_fma_f32 v33, -v64, v33, v66                              // 00000011F9C8: D6130021 250A4340
	v_fma_f32 v68, -v65, v34, v33                              // 00000011F9D0: D6130044 24864541
	ds_load_2addr_b32 v[33:34], v46 offset0:116 offset1:117    // 00000011F9D8: D8DC7574 2100002E
	ds_load_2addr_b32 v[64:65], v46 offset0:118 offset1:119    // 00000011F9E0: D8DC7776 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:180 offset1:197    // 00000011F9E8: D8DCC5B4 42000039
	s_waitcnt lgkmcnt(5)                                       // 00000011F9F0: BF89FC57
	v_fma_f32 v35, -v35, v60, v68                              // 00000011F9F4: D6130023 25127923
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011F9FC: BF8700C1
	v_fma_f32 v60, -v36, v61, v35                              // 00000011FA00: D613003C 248E7B24
	ds_load_2addr_b32 v[35:36], v57 offset0:214 offset1:231    // 00000011FA08: D8DCE7D6 23000039
	s_waitcnt lgkmcnt(4)                                       // 00000011FA10: BF89FC47
	v_fma_f32 v31, -v31, v62, v60                              // 00000011FA14: D613001F 24F27D1F
	v_fma_f32 v62, -v32, v63, v31                              // 00000011FA1C: D613003E 247E7F20
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 00000011FA24: D8DC7978 1F00002E
	ds_load_2addr_b32 v[60:61], v58 offset0:120 offset1:137    // 00000011FA2C: D8DC8978 3C00003A
	s_waitcnt lgkmcnt(3)                                       // 00000011FA34: BF89FC37
	v_fma_f32 v33, -v33, v66, v62                              // 00000011FA38: D6130021 24FA8521
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FA40: BF8700D1
	v_fma_f32 v66, -v34, v67, v33                              // 00000011FA44: D6130042 24868722
	ds_load_2addr_b32 v[33:34], v46 offset0:122 offset1:123    // 00000011FA4C: D8DC7B7A 2100002E
	ds_load_2addr_b32 v[62:63], v59 offset0:26 offset1:43      // 00000011FA54: D8DC2B1A 3E00003B
	s_waitcnt lgkmcnt(4)                                       // 00000011FA5C: BF89FC47
	v_fma_f32 v35, -v64, v35, v66                              // 00000011FA60: D6130023 250A4740
	v_fma_f32 v66, -v65, v36, v35                              // 00000011FA68: D6130042 248E4941
	ds_load_2addr_b32 v[35:36], v46 offset0:124 offset1:125    // 00000011FA70: D8DC7D7C 2300002E
	ds_load_2addr_b32 v[64:65], v46 offset0:126 offset1:127    // 00000011FA78: D8DC7F7E 4000002E
	s_waitcnt lgkmcnt(4)                                       // 00000011FA80: BF89FC47
	v_fma_f32 v31, -v31, v60, v66                              // 00000011FA84: D613001F 250A791F
	ds_load_2addr_b32 v[66:67], v59 offset0:60 offset1:77      // 00000011FA8C: D8DC4D3C 4200003B
	v_fma_f32 v31, -v32, v61, v31                              // 00000011FA94: D613001F 247E7B20
	s_waitcnt lgkmcnt(3)                                       // 00000011FA9C: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000011FAA0: BF8700C1
	v_fma_f32 v33, -v33, v62, v31                              // 00000011FAA4: D6130021 247E7D21
	ds_load_2addr_b32 v[31:32], v59 offset0:94 offset1:111     // 00000011FAAC: D8DC6F5E 1F00003B
	v_fma_f32 v33, -v34, v63, v33                              // 00000011FAB4: D6130021 24867F22
	s_waitcnt lgkmcnt(1)                                       // 00000011FABC: BF89FC17
	v_fma_f32 v33, -v35, v66, v33                              // 00000011FAC0: D6130021 24868523
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000011FAC8: BF8700A1
	v_fma_f32 v33, -v36, v67, v33                              // 00000011FACC: D6130021 24868724
	s_waitcnt lgkmcnt(0)                                       // 00000011FAD4: BF89FC07
	v_fma_f32 v31, -v64, v31, v33                              // 00000011FAD8: D613001F 24863F40
	v_mad_u64_u32 v[33:34], null, 0x44, s10, v[4:5]            // 00000011FAE0: D6FE7C21 041014FF 00000044
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011FAEC: BF870002
	v_fma_f32 v31, -v65, v32, v31                              // 00000011FAF0: D613001F 247E4141
	ds_store_b32 v33, v31                                      // 00000011FAF8: D8340000 00001F21
	s_branch 64844                                             // 00000011FB00: BFA0FD4C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_dual_mov_b32 v30, v14 :: v_dual_mov_b32 v29, v13         // 00000011FB04: CA10010E 1E1C010D
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v31, v9          // 00000011FB0C: CA10010A 201E0109
	v_mov_b32_e32 v35, v43                                     // 00000011FB14: 7E46032B
	s_mov_b32 s10, 0                                           // 00000011FB18: BE8A0080
	s_branch 21                                                // 00000011FB1C: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1074>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000011FB20: 8C7E0B7E
	.long 0xd700011f                                           // 00000011FB24: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 00000011FB28: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000011FB30: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 00000011FB34: D5207C20 00064080
	.long 0xd700011d                                           // 00000011FB3C: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 00000011FB40: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 00000011FB48: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000011FB4C: D5207C1E 00063C80
	s_add_i32 s1, s10, 8                                       // 00000011FB54: 8101880A
	s_cmp_gt_u32 s10, 55                                       // 00000011FB58: BF08B70A
	s_mov_b32 s10, s1                                          // 00000011FB5C: BE8A0001
	s_waitcnt_vscnt null, 0x0                                  // 00000011FB60: BC7C0000
	s_barrier                                                  // 00000011FB64: BFBD0000
	buffer_gl0_inv                                             // 00000011FB68: E0AC0000 00000000
	s_cbranch_scc1 579                                         // 00000011FB70: BFA20243 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1980>
	s_delay_alu instid0(VALU_DEP_2)                            // 00000011FB74: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 00000011FB78: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 00000011FB80: 7E480328
	v_mov_b32_e32 v60, v38                                     // 00000011FB84: 7E780326
	s_mov_b32 s11, 0                                           // 00000011FB88: BE8B0080
	s_nop 0                                                    // 00000011FB8C: BF800000
	s_nop 0                                                    // 00000011FB90: BF800000
	s_nop 0                                                    // 00000011FB94: BF800000
	s_nop 0                                                    // 00000011FB98: BF800000
	s_nop 0                                                    // 00000011FB9C: BF800000
	s_nop 0                                                    // 00000011FBA0: BF800000
	s_nop 0                                                    // 00000011FBA4: BF800000
	s_nop 0                                                    // 00000011FBA8: BF800000
	s_nop 0                                                    // 00000011FBAC: BF800000
	s_nop 0                                                    // 00000011FBB0: BF800000
	s_nop 0                                                    // 00000011FBB4: BF800000
	s_nop 0                                                    // 00000011FBB8: BF800000
	s_nop 0                                                    // 00000011FBBC: BF800000
	global_load_b32 v61, v[33:34], off                         // 00000011FBC0: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 00000011FBC8: 4A7878FF 00000080
	.long 0xd7000121                                           // 00000011FBD0: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 00000011FBD4: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000011FBDC: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 00000011FBE0: D5207C22 00064480
	.long 0xd4490004                                           // 00000011FBE8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 00000011FBEC: 020278FF 0000037F
	s_or_b32 s11, s4, s11                                      // 00000011FBF4: 8C0B0B04
	s_waitcnt vmcnt(0)                                         // 00000011FBF8: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 00000011FBFC: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 00000011FC04: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s11                       // 00000011FC0C: 917E0B7E
	s_cbranch_execnz 65515                                     // 00000011FC10: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10c0>
	s_or_b32 exec_lo, exec_lo, s11                             // 00000011FC14: 8C7E0B7E
	s_waitcnt lgkmcnt(0)                                       // 00000011FC18: BF89FC07
	s_barrier                                                  // 00000011FC1C: BFBD0000
	buffer_gl0_inv                                             // 00000011FC20: E0AC0000 00000000
	s_and_saveexec_b32 s11, s0                                 // 00000011FC28: BE8B2000
	s_cbranch_execz 65468                                      // 00000011FC2C: BFA5FFBC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1020>
	v_or_b32_e32 v33, s10, v2                                  // 00000011FC30: 3842040A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000011FC34: BF870091
	v_or_b32_e32 v36, s7, v33                                  // 00000011FC38: 38484207
	.long 0xd4440001                                           // 00000011FC3C: D4440001
	v_cndmask_b32_e32 v1, s30, v36, vcc_lo                     // 00000011FC40: 0202481E
	s_and_b32 exec_lo, exec_lo, s1                             // 00000011FC44: 8B7E017E
	s_cbranch_execz 65461                                      // 00000011FC48: BFA5FFB5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1020>
	ds_load_2addr_b32 v[60:61], v1 offset1:17                  // 00000011FC4C: D8DC1100 3C000001
	ds_load_2addr_b32 v[62:63], v46 offset1:1                  // 00000011FC54: D8DC0100 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:2 offset1:3        // 00000011FC5C: D8DC0302 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:34 offset1:51       // 00000011FC64: D8DC3322 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:68 offset1:85       // 00000011FC6C: D8DC5544 44000001
	ds_load_2addr_b32 v[70:71], v46 offset0:4 offset1:5        // 00000011FC74: D8DC0504 4600002E
	s_mov_b32 s12, 0                                           // 00000011FC7C: BE8C0080
	v_lshlrev_b32_e32 v33, 2, v33                              // 00000011FC80: 30424282
	s_waitcnt lgkmcnt(4)                                       // 00000011FC84: BF89FC47
	v_fma_f32 v76, v62, v60, 0                                 // 00000011FC88: D613004C 0202793E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FC90: BF8700D1
	v_fmac_f32_e32 v76, v63, v61                               // 00000011FC94: 56987B3F
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 00000011FC98: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset0:102 offset1:119     // 00000011FCA0: D8DC7766 3E000001
	s_waitcnt lgkmcnt(4)                                       // 00000011FCA8: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000011FCAC: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 00000011FCB0: 56988741
	ds_load_2addr_b32 v[64:65], v46 offset0:8 offset1:9        // 00000011FCB4: D8DC0908 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:136 offset1:153     // 00000011FCBC: D8DC9988 42000001
	s_waitcnt lgkmcnt(4)                                       // 00000011FCC4: BF89FC47
	v_fmac_f32_e32 v76, v70, v68                               // 00000011FCC8: 56988946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FCCC: BF8700D1
	v_fmac_f32_e32 v76, v71, v69                               // 00000011FCD0: 56988B47
	ds_load_2addr_b32 v[68:69], v46 offset0:10 offset1:11      // 00000011FCD4: D8DC0B0A 4400002E
	ds_load_2addr_b32 v[70:71], v1 offset0:170 offset1:187     // 00000011FCDC: D8DCBBAA 46000001
	s_waitcnt lgkmcnt(4)                                       // 00000011FCE4: BF89FC47
	v_fmac_f32_e32 v76, v60, v62                               // 00000011FCE8: 56987D3C
	v_fmac_f32_e32 v76, v61, v63                               // 00000011FCEC: 56987F3D
	ds_load_2addr_b32 v[60:61], v1 offset0:204 offset1:221     // 00000011FCF0: D8DCDDCC 3C000001
	ds_load_2addr_b32 v[62:63], v46 offset0:12 offset1:13      // 00000011FCF8: D8DC0D0C 3E00002E
	s_waitcnt lgkmcnt(4)                                       // 00000011FD00: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000011FD04: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FD08: BF8700D1
	v_fmac_f32_e32 v76, v65, v67                               // 00000011FD0C: 56988741
	ds_load_2addr_b32 v[64:65], v46 offset0:14 offset1:15      // 00000011FD10: D8DC0F0E 4000002E
	ds_load_2addr_b32 v[66:67], v1 offset0:238 offset1:255     // 00000011FD18: D8DCFFEE 42000001
	s_waitcnt lgkmcnt(4)                                       // 00000011FD20: BF89FC47
	v_fmac_f32_e32 v76, v68, v70                               // 00000011FD24: 56988D44
	v_fmac_f32_e32 v76, v69, v71                               // 00000011FD28: 56988F45
	ds_load_2addr_b32 v[68:69], v46 offset0:16 offset1:17      // 00000011FD2C: D8DC1110 4400002E
	ds_load_2addr_b32 v[70:71], v48 offset0:16 offset1:33      // 00000011FD34: D8DC2110 46000030
	s_waitcnt lgkmcnt(4)                                       // 00000011FD3C: BF89FC47
	v_fmac_f32_e32 v76, v62, v60                               // 00000011FD40: 5698793E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FD44: BF8700D1
	v_fmac_f32_e32 v76, v63, v61                               // 00000011FD48: 56987B3F
	ds_load_2addr_b32 v[60:61], v46 offset0:18 offset1:19      // 00000011FD4C: D8DC1312 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:50 offset1:67      // 00000011FD54: D8DC4332 3E000030
	s_waitcnt lgkmcnt(4)                                       // 00000011FD5C: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000011FD60: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 00000011FD64: 56988741
	ds_load_2addr_b32 v[64:65], v48 offset0:84 offset1:101     // 00000011FD68: D8DC6554 40000030
	ds_load_2addr_b32 v[66:67], v46 offset0:20 offset1:21      // 00000011FD70: D8DC1514 4200002E
	s_waitcnt lgkmcnt(4)                                       // 00000011FD78: BF89FC47
	v_fmac_f32_e32 v76, v68, v70                               // 00000011FD7C: 56988D44
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FD80: BF8700D1
	v_fmac_f32_e32 v76, v69, v71                               // 00000011FD84: 56988F45
	ds_load_2addr_b32 v[68:69], v46 offset0:22 offset1:23      // 00000011FD88: D8DC1716 4400002E
	ds_load_2addr_b32 v[70:71], v48 offset0:118 offset1:135    // 00000011FD90: D8DC8776 46000030
	s_waitcnt lgkmcnt(4)                                       // 00000011FD98: BF89FC47
	v_fmac_f32_e32 v76, v60, v62                               // 00000011FD9C: 56987D3C
	v_fmac_f32_e32 v76, v61, v63                               // 00000011FDA0: 56987F3D
	ds_load_2addr_b32 v[60:61], v46 offset0:24 offset1:25      // 00000011FDA4: D8DC1918 3C00002E
	ds_load_2addr_b32 v[62:63], v48 offset0:152 offset1:169    // 00000011FDAC: D8DCA998 3E000030
	s_waitcnt lgkmcnt(4)                                       // 00000011FDB4: BF89FC47
	v_fmac_f32_e32 v76, v66, v64                               // 00000011FDB8: 56988142
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FDBC: BF8700D1
	v_fmac_f32_e32 v76, v67, v65                               // 00000011FDC0: 56988343
	ds_load_2addr_b32 v[64:65], v46 offset0:26 offset1:27      // 00000011FDC4: D8DC1B1A 4000002E
	ds_load_2addr_b32 v[66:67], v48 offset0:186 offset1:203    // 00000011FDCC: D8DCCBBA 42000030
	s_waitcnt lgkmcnt(4)                                       // 00000011FDD4: BF89FC47
	v_fmac_f32_e32 v76, v68, v70                               // 00000011FDD8: 56988D44
	v_fmac_f32_e32 v76, v69, v71                               // 00000011FDDC: 56988F45
	ds_load_2addr_b32 v[68:69], v48 offset0:220 offset1:237    // 00000011FDE0: D8DCEDDC 44000030
	ds_load_2addr_b32 v[70:71], v46 offset0:28 offset1:29      // 00000011FDE8: D8DC1D1C 4600002E
	s_waitcnt lgkmcnt(4)                                       // 00000011FDF0: BF89FC47
	v_fmac_f32_e32 v76, v60, v62                               // 00000011FDF4: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FDF8: BF8700D1
	v_fmac_f32_e32 v76, v61, v63                               // 00000011FDFC: 56987F3D
	ds_load_2addr_b32 v[60:61], v46 offset0:30 offset1:31      // 00000011FE00: D8DC1F1E 3C00002E
	ds_load_2addr_b32 v[62:63], v49 offset0:126 offset1:143    // 00000011FE08: D8DC8F7E 3E000031
	s_waitcnt lgkmcnt(4)                                       // 00000011FE10: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000011FE14: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 00000011FE18: 56988741
	ds_load_2addr_b32 v[64:65], v46 offset0:32 offset1:33      // 00000011FE1C: D8DC2120 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 00000011FE24: D8DC3120 42000032
	s_waitcnt lgkmcnt(4)                                       // 00000011FE2C: BF89FC47
	v_fmac_f32_e32 v76, v70, v68                               // 00000011FE30: 56988946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FE34: BF8700D1
	v_fmac_f32_e32 v76, v71, v69                               // 00000011FE38: 56988B47
	ds_load_2addr_b32 v[68:69], v46 offset0:34 offset1:35      // 00000011FE3C: D8DC2322 4400002E
	ds_load_2addr_b32 v[70:71], v50 offset0:66 offset1:83      // 00000011FE44: D8DC5342 46000032
	s_waitcnt lgkmcnt(4)                                       // 00000011FE4C: BF89FC47
	v_fmac_f32_e32 v76, v60, v62                               // 00000011FE50: 56987D3C
	v_fmac_f32_e32 v76, v61, v63                               // 00000011FE54: 56987F3D
	ds_load_2addr_b32 v[60:61], v50 offset0:100 offset1:117    // 00000011FE58: D8DC7564 3C000032
	ds_load_2addr_b32 v[62:63], v46 offset0:36 offset1:37      // 00000011FE60: D8DC2524 3E00002E
	s_waitcnt lgkmcnt(4)                                       // 00000011FE68: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000011FE6C: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FE70: BF8700D1
	v_fmac_f32_e32 v76, v65, v67                               // 00000011FE74: 56988741
	ds_load_2addr_b32 v[64:65], v46 offset0:38 offset1:39      // 00000011FE78: D8DC2726 4000002E
	ds_load_2addr_b32 v[66:67], v50 offset0:134 offset1:151    // 00000011FE80: D8DC9786 42000032
	s_waitcnt lgkmcnt(4)                                       // 00000011FE88: BF89FC47
	v_fmac_f32_e32 v76, v68, v70                               // 00000011FE8C: 56988D44
	v_fmac_f32_e32 v76, v69, v71                               // 00000011FE90: 56988F45
	ds_load_2addr_b32 v[68:69], v46 offset0:40 offset1:41      // 00000011FE94: D8DC2928 4400002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 00000011FE9C: D8DCB9A8 46000032
	s_waitcnt lgkmcnt(4)                                       // 00000011FEA4: BF89FC47
	v_fmac_f32_e32 v76, v62, v60                               // 00000011FEA8: 5698793E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FEAC: BF8700D1
	v_fmac_f32_e32 v76, v63, v61                               // 00000011FEB0: 56987B3F
	ds_load_2addr_b32 v[60:61], v46 offset0:42 offset1:43      // 00000011FEB4: D8DC2B2A 3C00002E
	ds_load_2addr_b32 v[62:63], v50 offset0:202 offset1:219    // 00000011FEBC: D8DCDBCA 3E000032
	s_waitcnt lgkmcnt(4)                                       // 00000011FEC4: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000011FEC8: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 00000011FECC: 56988741
	ds_load_2addr_b32 v[64:65], v50 offset0:236 offset1:253    // 00000011FED0: D8DCFDEC 40000032
	ds_load_2addr_b32 v[66:67], v46 offset0:44 offset1:45      // 00000011FED8: D8DC2D2C 4200002E
	s_waitcnt lgkmcnt(4)                                       // 00000011FEE0: BF89FC47
	v_fmac_f32_e32 v76, v68, v70                               // 00000011FEE4: 56988D44
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FEE8: BF8700D1
	v_fmac_f32_e32 v76, v69, v71                               // 00000011FEEC: 56988F45
	ds_load_2addr_b32 v[68:69], v46 offset0:46 offset1:47      // 00000011FEF0: D8DC2F2E 4400002E
	ds_load_2addr_b32 v[70:71], v51 offset0:14 offset1:31      // 00000011FEF8: D8DC1F0E 46000033
	s_waitcnt lgkmcnt(4)                                       // 00000011FF00: BF89FC47
	v_fmac_f32_e32 v76, v60, v62                               // 00000011FF04: 56987D3C
	v_fmac_f32_e32 v76, v61, v63                               // 00000011FF08: 56987F3D
	ds_load_2addr_b32 v[60:61], v46 offset0:48 offset1:49      // 00000011FF0C: D8DC3130 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:48 offset1:65      // 00000011FF14: D8DC4130 3E000033
	s_waitcnt lgkmcnt(4)                                       // 00000011FF1C: BF89FC47
	v_fmac_f32_e32 v76, v66, v64                               // 00000011FF20: 56988142
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FF24: BF8700D1
	v_fmac_f32_e32 v76, v67, v65                               // 00000011FF28: 56988343
	ds_load_2addr_b32 v[64:65], v46 offset0:50 offset1:51      // 00000011FF2C: D8DC3332 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:82 offset1:99      // 00000011FF34: D8DC6352 42000033
	s_waitcnt lgkmcnt(4)                                       // 00000011FF3C: BF89FC47
	v_fmac_f32_e32 v76, v68, v70                               // 00000011FF40: 56988D44
	v_fmac_f32_e32 v76, v69, v71                               // 00000011FF44: 56988F45
	ds_load_2addr_b32 v[68:69], v51 offset0:116 offset1:133    // 00000011FF48: D8DC8574 44000033
	ds_load_2addr_b32 v[70:71], v46 offset0:52 offset1:53      // 00000011FF50: D8DC3534 4600002E
	s_waitcnt lgkmcnt(4)                                       // 00000011FF58: BF89FC47
	v_fmac_f32_e32 v76, v60, v62                               // 00000011FF5C: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FF60: BF8700D1
	v_fmac_f32_e32 v76, v61, v63                               // 00000011FF64: 56987F3D
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 00000011FF68: D8DC3736 3C00002E
	ds_load_2addr_b32 v[62:63], v51 offset0:150 offset1:167    // 00000011FF70: D8DCA796 3E000033
	s_waitcnt lgkmcnt(4)                                       // 00000011FF78: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000011FF7C: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 00000011FF80: 56988741
	ds_load_2addr_b32 v[64:65], v46 offset0:56 offset1:57      // 00000011FF84: D8DC3938 4000002E
	ds_load_2addr_b32 v[66:67], v51 offset0:184 offset1:201    // 00000011FF8C: D8DCC9B8 42000033
	s_waitcnt lgkmcnt(4)                                       // 00000011FF94: BF89FC47
	v_fmac_f32_e32 v76, v70, v68                               // 00000011FF98: 56988946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FF9C: BF8700D1
	v_fmac_f32_e32 v76, v71, v69                               // 00000011FFA0: 56988B47
	ds_load_2addr_b32 v[68:69], v46 offset0:58 offset1:59      // 00000011FFA4: D8DC3B3A 4400002E
	ds_load_2addr_b32 v[70:71], v51 offset0:218 offset1:235    // 00000011FFAC: D8DCEBDA 46000033
	s_waitcnt lgkmcnt(4)                                       // 00000011FFB4: BF89FC47
	v_fmac_f32_e32 v76, v60, v62                               // 00000011FFB8: 56987D3C
	v_fmac_f32_e32 v76, v61, v63                               // 00000011FFBC: 56987F3D
	ds_load_2addr_b32 v[60:61], v52 offset0:124 offset1:141    // 00000011FFC0: D8DC8D7C 3C000034
	ds_load_2addr_b32 v[62:63], v46 offset0:60 offset1:61      // 00000011FFC8: D8DC3D3C 3E00002E
	s_waitcnt lgkmcnt(4)                                       // 00000011FFD0: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000011FFD4: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000011FFD8: BF8700D1
	v_fmac_f32_e32 v76, v65, v67                               // 00000011FFDC: 56988741
	ds_load_2addr_b32 v[64:65], v46 offset0:62 offset1:63      // 00000011FFE0: D8DC3F3E 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:30 offset1:47      // 00000011FFE8: D8DC2F1E 42000035
	s_waitcnt lgkmcnt(4)                                       // 00000011FFF0: BF89FC47
	v_fmac_f32_e32 v76, v68, v70                               // 00000011FFF4: 56988D44
	v_fmac_f32_e32 v76, v69, v71                               // 00000011FFF8: 56988F45
	ds_load_2addr_b32 v[68:69], v46 offset0:64 offset1:65      // 00000011FFFC: D8DC4140 4400002E
	ds_load_2addr_b32 v[70:71], v53 offset0:64 offset1:81      // 000000120004: D8DC5140 46000035
	s_waitcnt lgkmcnt(4)                                       // 00000012000C: BF89FC47
	v_fmac_f32_e32 v76, v62, v60                               // 000000120010: 5698793E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000120014: BF8700D1
	v_fmac_f32_e32 v76, v63, v61                               // 000000120018: 56987B3F
	ds_load_2addr_b32 v[60:61], v46 offset0:66 offset1:67      // 00000012001C: D8DC4342 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:98 offset1:115     // 000000120024: D8DC7362 3E000035
	s_waitcnt lgkmcnt(4)                                       // 00000012002C: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000120030: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 000000120034: 56988741
	ds_load_2addr_b32 v[64:65], v53 offset0:132 offset1:149    // 000000120038: D8DC9584 40000035
	ds_load_2addr_b32 v[66:67], v46 offset0:68 offset1:69      // 000000120040: D8DC4544 4200002E
	s_waitcnt lgkmcnt(4)                                       // 000000120048: BF89FC47
	v_fmac_f32_e32 v76, v68, v70                               // 00000012004C: 56988D44
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000120050: BF8700D1
	v_fmac_f32_e32 v76, v69, v71                               // 000000120054: 56988F45
	ds_load_2addr_b32 v[68:69], v46 offset0:70 offset1:71      // 000000120058: D8DC4746 4400002E
	ds_load_2addr_b32 v[70:71], v53 offset0:166 offset1:183    // 000000120060: D8DCB7A6 46000035
	s_waitcnt lgkmcnt(4)                                       // 000000120068: BF89FC47
	v_fmac_f32_e32 v76, v60, v62                               // 00000012006C: 56987D3C
	v_fmac_f32_e32 v76, v61, v63                               // 000000120070: 56987F3D
	ds_load_2addr_b32 v[60:61], v46 offset0:72 offset1:73      // 000000120074: D8DC4948 3C00002E
	ds_load_2addr_b32 v[62:63], v53 offset0:200 offset1:217    // 00000012007C: D8DCD9C8 3E000035
	s_waitcnt lgkmcnt(4)                                       // 000000120084: BF89FC47
	v_fmac_f32_e32 v76, v66, v64                               // 000000120088: 56988142
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000012008C: BF8700D1
	v_fmac_f32_e32 v76, v67, v65                               // 000000120090: 56988343
	ds_load_2addr_b32 v[64:65], v46 offset0:74 offset1:75      // 000000120094: D8DC4B4A 4000002E
	ds_load_2addr_b32 v[66:67], v53 offset0:234 offset1:251    // 00000012009C: D8DCFBEA 42000035
	s_waitcnt lgkmcnt(4)                                       // 0000001200A4: BF89FC47
	v_fmac_f32_e32 v76, v68, v70                               // 0000001200A8: 56988D44
	v_fmac_f32_e32 v76, v69, v71                               // 0000001200AC: 56988F45
	ds_load_2addr_b32 v[68:69], v54 offset0:12 offset1:29      // 0000001200B0: D8DC1D0C 44000036
	ds_load_2addr_b32 v[70:71], v46 offset0:76 offset1:77      // 0000001200B8: D8DC4D4C 4600002E
	s_waitcnt lgkmcnt(4)                                       // 0000001200C0: BF89FC47
	v_fmac_f32_e32 v76, v60, v62                               // 0000001200C4: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001200C8: BF8700D1
	v_fmac_f32_e32 v76, v61, v63                               // 0000001200CC: 56987F3D
	ds_load_2addr_b32 v[60:61], v46 offset0:78 offset1:79      // 0000001200D0: D8DC4F4E 3C00002E
	ds_load_2addr_b32 v[62:63], v54 offset0:46 offset1:63      // 0000001200D8: D8DC3F2E 3E000036
	s_waitcnt lgkmcnt(4)                                       // 0000001200E0: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000001200E4: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 0000001200E8: 56988741
	ds_load_2addr_b32 v[64:65], v46 offset0:80 offset1:81      // 0000001200EC: D8DC5150 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:80 offset1:97      // 0000001200F4: D8DC6150 42000036
	s_waitcnt lgkmcnt(4)                                       // 0000001200FC: BF89FC47
	v_fmac_f32_e32 v76, v70, v68                               // 000000120100: 56988946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000120104: BF8700D1
	v_fmac_f32_e32 v76, v71, v69                               // 000000120108: 56988B47
	ds_load_2addr_b32 v[68:69], v46 offset0:82 offset1:83      // 00000012010C: D8DC5352 4400002E
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 000000120114: D8DC8372 46000036
	s_waitcnt lgkmcnt(4)                                       // 00000012011C: BF89FC47
	v_fmac_f32_e32 v76, v60, v62                               // 000000120120: 56987D3C
	v_fmac_f32_e32 v76, v61, v63                               // 000000120124: 56987F3D
	ds_load_2addr_b32 v[60:61], v54 offset0:148 offset1:165    // 000000120128: D8DCA594 3C000036
	ds_load_2addr_b32 v[62:63], v46 offset0:84 offset1:85      // 000000120130: D8DC5554 3E00002E
	s_waitcnt lgkmcnt(4)                                       // 000000120138: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012013C: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000120140: BF8700D1
	v_fmac_f32_e32 v76, v65, v67                               // 000000120144: 56988741
	ds_load_2addr_b32 v[64:65], v46 offset0:86 offset1:87      // 000000120148: D8DC5756 4000002E
	ds_load_2addr_b32 v[66:67], v54 offset0:182 offset1:199    // 000000120150: D8DCC7B6 42000036
	s_waitcnt lgkmcnt(4)                                       // 000000120158: BF89FC47
	v_fmac_f32_e32 v76, v68, v70                               // 00000012015C: 56988D44
	v_fmac_f32_e32 v76, v69, v71                               // 000000120160: 56988F45
	ds_load_2addr_b32 v[68:69], v46 offset0:88 offset1:89      // 000000120164: D8DC5958 4400002E
	ds_load_2addr_b32 v[70:71], v54 offset0:216 offset1:233    // 00000012016C: D8DCE9D8 46000036
	s_waitcnt lgkmcnt(4)                                       // 000000120174: BF89FC47
	v_fmac_f32_e32 v76, v62, v60                               // 000000120178: 5698793E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000012017C: BF8700D1
	v_fmac_f32_e32 v76, v63, v61                               // 000000120180: 56987B3F
	ds_load_2addr_b32 v[60:61], v46 offset0:90 offset1:91      // 000000120184: D8DC5B5A 3C00002E
	ds_load_2addr_b32 v[62:63], v55 offset0:122 offset1:139    // 00000012018C: D8DC8B7A 3E000037
	s_waitcnt lgkmcnt(4)                                       // 000000120194: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 000000120198: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 00000012019C: 56988741
	ds_load_2addr_b32 v[64:65], v56 offset0:28 offset1:45      // 0000001201A0: D8DC2D1C 40000038
	ds_load_2addr_b32 v[66:67], v46 offset0:92 offset1:93      // 0000001201A8: D8DC5D5C 4200002E
	s_waitcnt lgkmcnt(4)                                       // 0000001201B0: BF89FC47
	v_fmac_f32_e32 v76, v68, v70                               // 0000001201B4: 56988D44
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001201B8: BF8700D1
	v_fmac_f32_e32 v76, v69, v71                               // 0000001201BC: 56988F45
	ds_load_2addr_b32 v[68:69], v46 offset0:94 offset1:95      // 0000001201C0: D8DC5F5E 4400002E
	ds_load_2addr_b32 v[70:71], v56 offset0:62 offset1:79      // 0000001201C8: D8DC4F3E 46000038
	s_waitcnt lgkmcnt(4)                                       // 0000001201D0: BF89FC47
	v_fmac_f32_e32 v76, v60, v62                               // 0000001201D4: 56987D3C
	v_fmac_f32_e32 v76, v61, v63                               // 0000001201D8: 56987F3D
	ds_load_2addr_b32 v[60:61], v46 offset0:96 offset1:97      // 0000001201DC: D8DC6160 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:96 offset1:113     // 0000001201E4: D8DC7160 3E000038
	s_waitcnt lgkmcnt(4)                                       // 0000001201EC: BF89FC47
	v_fmac_f32_e32 v76, v66, v64                               // 0000001201F0: 56988142
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001201F4: BF8700D1
	v_fmac_f32_e32 v76, v67, v65                               // 0000001201F8: 56988343
	ds_load_2addr_b32 v[64:65], v46 offset0:98 offset1:99      // 0000001201FC: D8DC6362 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:130 offset1:147    // 000000120204: D8DC9382 42000038
	s_waitcnt lgkmcnt(4)                                       // 00000012020C: BF89FC47
	v_fmac_f32_e32 v76, v68, v70                               // 000000120210: 56988D44
	v_fmac_f32_e32 v76, v69, v71                               // 000000120214: 56988F45
	ds_load_2addr_b32 v[68:69], v56 offset0:164 offset1:181    // 000000120218: D8DCB5A4 44000038
	ds_load_2addr_b32 v[70:71], v46 offset0:100 offset1:101    // 000000120220: D8DC6564 4600002E
	s_waitcnt lgkmcnt(4)                                       // 000000120228: BF89FC47
	v_fmac_f32_e32 v76, v60, v62                               // 00000012022C: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000120230: BF8700D1
	v_fmac_f32_e32 v76, v61, v63                               // 000000120234: 56987F3D
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 000000120238: D8DC6766 3C00002E
	ds_load_2addr_b32 v[62:63], v56 offset0:198 offset1:215    // 000000120240: D8DCD7C6 3E000038
	s_waitcnt lgkmcnt(4)                                       // 000000120248: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 00000012024C: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 000000120250: 56988741
	ds_load_2addr_b32 v[64:65], v46 offset0:104 offset1:105    // 000000120254: D8DC6968 4000002E
	ds_load_2addr_b32 v[66:67], v56 offset0:232 offset1:249    // 00000012025C: D8DCF9E8 42000038
	s_waitcnt lgkmcnt(4)                                       // 000000120264: BF89FC47
	v_fmac_f32_e32 v76, v70, v68                               // 000000120268: 56988946
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000012026C: BF8700D1
	v_fmac_f32_e32 v76, v71, v69                               // 000000120270: 56988B47
	ds_load_2addr_b32 v[68:69], v46 offset0:106 offset1:107    // 000000120274: D8DC6B6A 4400002E
	ds_load_2addr_b32 v[70:71], v57 offset0:10 offset1:27      // 00000012027C: D8DC1B0A 46000039
	s_waitcnt lgkmcnt(4)                                       // 000000120284: BF89FC47
	v_fmac_f32_e32 v76, v60, v62                               // 000000120288: 56987D3C
	v_fmac_f32_e32 v76, v61, v63                               // 00000012028C: 56987F3D
	ds_load_2addr_b32 v[60:61], v57 offset0:44 offset1:61      // 000000120290: D8DC3D2C 3C000039
	ds_load_2addr_b32 v[62:63], v46 offset0:108 offset1:109    // 000000120298: D8DC6D6C 3E00002E
	s_waitcnt lgkmcnt(4)                                       // 0000001202A0: BF89FC47
	v_fmac_f32_e32 v76, v64, v66                               // 0000001202A4: 56988540
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001202A8: BF8700D1
	v_fmac_f32_e32 v76, v65, v67                               // 0000001202AC: 56988741
	ds_load_2addr_b32 v[64:65], v46 offset0:110 offset1:111    // 0000001202B0: D8DC6F6E 4000002E
	ds_load_2addr_b32 v[66:67], v57 offset0:78 offset1:95      // 0000001202B8: D8DC5F4E 42000039
	s_waitcnt lgkmcnt(4)                                       // 0000001202C0: BF89FC47
	v_fmac_f32_e32 v76, v68, v70                               // 0000001202C4: 56988D44
	v_fmac_f32_e32 v76, v69, v71                               // 0000001202C8: 56988F45
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 0000001202CC: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v46 offset0:116 offset1:117    // 0000001202D4: D8DC7574 4600002E
	ds_load_2addr_b32 v[72:73], v46 offset0:118 offset1:119    // 0000001202DC: D8DC7776 4800002E
	ds_load_2addr_b32 v[74:75], v46 offset0:112 offset1:113    // 0000001202E4: D8DC7170 4A00002E
	s_waitcnt lgkmcnt(6)                                       // 0000001202EC: BF89FC67
	v_fmac_f32_e32 v76, v62, v60                               // 0000001202F0: 5698793E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001202F4: BF8700D1
	v_fmac_f32_e32 v76, v63, v61                               // 0000001202F8: 56987B3F
	ds_load_2addr_b32 v[60:61], v46 offset0:114 offset1:115    // 0000001202FC: D8DC7372 3C00002E
	ds_load_2addr_b32 v[62:63], v57 offset0:146 offset1:163    // 000000120304: D8DCA392 3E000039
	s_waitcnt lgkmcnt(6)                                       // 00000012030C: BF89FC67
	v_fmac_f32_e32 v76, v64, v66                               // 000000120310: 56988540
	v_fmac_f32_e32 v76, v65, v67                               // 000000120314: 56988741
	ds_load_2addr_b32 v[64:65], v57 offset0:180 offset1:197    // 000000120318: D8DCC5B4 40000039
	ds_load_2addr_b32 v[66:67], v57 offset0:214 offset1:231    // 000000120320: D8DCE7D6 42000039
	s_waitcnt lgkmcnt(4)                                       // 000000120328: BF89FC47
	v_fmac_f32_e32 v76, v74, v68                               // 00000012032C: 5698894A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000120330: BF8700A1
	v_fmac_f32_e32 v76, v75, v69                               // 000000120334: 56988B4B
	s_waitcnt lgkmcnt(2)                                       // 000000120338: BF89FC27
	v_fmac_f32_e32 v76, v60, v62                               // 00000012033C: 56987D3C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 000000120340: BF8700D1
	v_fmac_f32_e32 v76, v61, v63                               // 000000120344: 56987F3D
	ds_load_2addr_b32 v[60:61], v46 offset0:120 offset1:121    // 000000120348: D8DC7978 3C00002E
	ds_load_2addr_b32 v[62:63], v58 offset0:120 offset1:137    // 000000120350: D8DC8978 3E00003A
	s_waitcnt lgkmcnt(3)                                       // 000000120358: BF89FC37
	v_fmac_f32_e32 v76, v70, v64                               // 00000012035C: 56988146
	v_fmac_f32_e32 v76, v71, v65                               // 000000120360: 56988347
	ds_load_2addr_b32 v[64:65], v46 offset0:122 offset1:123    // 000000120364: D8DC7B7A 4000002E
	ds_load_2addr_b32 v[68:69], v59 offset0:26 offset1:43      // 00000012036C: D8DC2B1A 4400003B
	s_waitcnt lgkmcnt(4)                                       // 000000120374: BF89FC47
	v_fmac_f32_e32 v76, v72, v66                               // 000000120378: 56988548
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012037C: BF870001
	v_fmac_f32_e32 v76, v73, v67                               // 000000120380: 56988749
	ds_load_2addr_b32 v[66:67], v46 offset0:124 offset1:125    // 000000120384: D8DC7D7C 4200002E
	ds_load_2addr_b32 v[70:71], v46 offset0:126 offset1:127    // 00000012038C: D8DC7F7E 4600002E
	ds_load_2addr_b32 v[72:73], v59 offset0:60 offset1:77      // 000000120394: D8DC4D3C 4800003B
	s_waitcnt lgkmcnt(5)                                       // 00000012039C: BF89FC57
	v_fmac_f32_e32 v76, v60, v62                               // 0000001203A0: 56987D3C
	ds_load_b32 v62, v33 offset:17440                          // 0000001203A4: D8D84420 3E000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 0000001203AC: CA10011E 2220011D
	v_fmac_f32_e32 v76, v61, v63                               // 0000001203B4: 56987F3D
	ds_load_2addr_b32 v[60:61], v59 offset0:94 offset1:111     // 0000001203B8: D8DC6F5E 3C00003B
	s_waitcnt lgkmcnt(5)                                       // 0000001203C0: BF89FC57
	v_fmac_f32_e32 v76, v64, v68                               // 0000001203C4: 56988940
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001203C8: BF8700A1
	v_fmac_f32_e32 v76, v65, v69                               // 0000001203CC: 56988B41
	s_waitcnt lgkmcnt(2)                                       // 0000001203D0: BF89FC27
	v_fmac_f32_e32 v76, v66, v72                               // 0000001203D4: 56989142
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001203D8: BF8700A1
	v_fmac_f32_e32 v76, v67, v73                               // 0000001203DC: 56989343
	s_waitcnt lgkmcnt(0)                                       // 0000001203E0: BF89FC07
	v_fmac_f32_e32 v76, v70, v60                               // 0000001203E4: 56987946
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001203E8: BF870091
	v_dual_fmac_f32 v76, v71, v61 :: v_dual_mov_b32 v61, v1    // 0000001203EC: C8107B47 4C3C0101
	v_mul_f32_e32 v60, v76, v62                                // 0000001203F4: 10787D4C
	v_mov_b32_e32 v62, v35                                     // 0000001203F8: 7E7C0323
	s_nop 0                                                    // 0000001203FC: BF800000
	global_load_b32 v63, v[33:34], off                         // 000000120400: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 000000120408: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 000000120410: 4A7C7CC1
	.long 0xd7000121                                           // 000000120414: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 000000120418: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000012041C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 000000120420: D5207C22 00064480
	.long 0xd44a0004                                           // 000000120428: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 00000012042C: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 000000120430: 4A7A7AFF 00000044
	s_or_b32 s12, s4, s12                                      // 000000120438: 8C0C0C04
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000012043C: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 000000120440: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s12                       // 000000120444: 917E0C7E
	s_cbranch_execnz 65517                                     // 000000120448: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1900>
	s_or_b32 exec_lo, exec_lo, s12                             // 00000012044C: 8C7E0C7E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120450: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 000000120454: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 00000012045C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 000000120468: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 000000120474: DC960000 007C2421
	s_branch 64936                                             // 00000012047C: BFA0FDA8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1020>
	s_mul_f32 s1, s6, 0x3fb8aa3b                               // 000000120480: A201FF06 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 000000120488: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 00000012048C: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 000000120490: 8D04FF01 80000000
	s_rndne_f32 s7, s1                                         // 000000120498: BE876301
	s_fmamk_f32 s4, s6, 0x3fb8aa3b, s4                         // 00000012049C: A3040406 3FB8AA3B
	s_cmp_nlt_f32 s6, 0xc2ce8ed0                               // 0000001204A4: BF4EFF06 C2CE8ED0
	s_sub_f32 s1, s1, s7                                       // 0000001204AC: A0810701
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000001204B0: BF870599
	s_fmamk_f32 s4, s6, 0x32a5705f, s4                         // 0000001204B4: A3040406 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000001204BC: A0010401
	s_mov_b32 s4, 0                                            // 0000001204C0: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 0000001204C4: BF87000A
	v_exp_f32_e32 v29, s1                                      // 0000001204C8: 7E3A4A01
	s_cvt_i32_f32 s1, s7                                       // 0000001204CC: BE816607
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 0000001204D0: BF870585
	.long 0xd71c001d                                           // 0000001204D4: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 0000001204D8: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 0000001204DC: 980180C1
	s_cmp_ngt_f32 s6, 0x42b17218                               // 0000001204E0: BF4BFF06 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001204E8: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 0000001204EC: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 0000001204F4: 980180C1
	v_mov_b32_e32 v29, v37                                     // 0000001204F8: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 0000001204FC: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 000000120508: D8D80000 2000001D
	s_waitcnt lgkmcnt(0)                                       // 000000120510: BF89FC07
	v_dual_mul_f32 v32, v30, v32 :: v_dual_add_nc_u32 v31, 0x80, v31// 000000120514: C8E0411E 201E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000120520: BF8704C1
	.long 0xd4490001                                           // 000000120524: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 000000120528: 02023EFF 0000077F
	ds_store_b32 v29, v32                                      // 000000120530: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 000000120538: 4A3A3AFF 00000220
	s_or_b32 s4, s1, s4                                        // 000000120540: 8C040401
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000120544: 917E047E
	s_cbranch_execnz 65519                                     // 000000120548: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a08>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012054C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 000000120550: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 000000120558: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 000000120560: 7E420326
	s_mov_b32 s6, 0                                            // 000000120564: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000120568: BF89FC07
	s_barrier                                                  // 00000012056C: BFBD0000
	buffer_gl0_inv                                             // 000000120570: E0AC0000 00000000
	s_nop 0                                                    // 000000120578: BF800000
	s_nop 0                                                    // 00000012057C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000120580: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 000000120588: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000120590: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000120598: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012059C: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000001205A4: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000001205A8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001205B0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000001205B4: 10444722
	.long 0xd4490004                                           // 0000001205B8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000001205BC: 020242FF 0000037F
	ds_store_b32 v32, v34 offset:13056                         // 0000001205C4: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 0000001205CC: 4A4040FF 00000204
	s_or_b32 s6, s4, s6                                        // 0000001205D4: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001205D8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 0000001205DC: 917E067E
	s_cbranch_execnz 65511                                     // 0000001205E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a80>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001205E4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000001205E8: BF89FC07
	s_barrier                                                  // 0000001205EC: BFBD0000
	buffer_gl0_inv                                             // 0000001205F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 0000001205F8: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 000000120600: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 000000120608: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 000000120610: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 000000120618: 7E780300
	s_mov_b32 s4, 0                                            // 00000012061C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000120620: BF840001
	s_nop 0                                                    // 000000120624: BF800000
	s_nop 0                                                    // 000000120628: BF800000
	s_nop 0                                                    // 00000012062C: BF800000
	s_nop 0                                                    // 000000120630: BF800000
	s_nop 0                                                    // 000000120634: BF800000
	s_nop 0                                                    // 000000120638: BF800000
	s_nop 0                                                    // 00000012063C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120640: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000120644: 327A7884
	.long 0xd4490001                                           // 000000120648: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012064C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000120654: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000120658: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000120664: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000120668: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 000000120670: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000120678: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 000000120680: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 000000120684: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000120688: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 00000012068C: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 000000120698: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000001206A0: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000001206A8: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000001206B0: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000001206B8: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 0000001206C0: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 0000001206C4: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001206C8: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 0000001206CC: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 0000001206D0: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001206D4: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 0000001206D8: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000001206DC: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001206E8: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000001206EC: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000001206F4: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001206FC: 917E047E
	s_cbranch_execnz 65487                                     // 000000120700: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b40>
	s_set_inst_prefetch_distance 0x2                           // 000000120704: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000120708: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 00000012070C: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000120714: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 00000012071C: 7E420326
	s_mov_b32 s6, 0                                            // 000000120720: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000120724: BF89FC07
	s_barrier                                                  // 000000120728: BFBD0000
	buffer_gl0_inv                                             // 00000012072C: E0AC0000 00000000
	s_nop 0                                                    // 000000120734: BF800000
	s_nop 0                                                    // 000000120738: BF800000
	s_nop 0                                                    // 00000012073C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000120740: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 000000120748: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000120750: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000120758: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012075C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000120764: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000120768: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000120770: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000120774: 10444722
	.long 0xd4490004                                           // 000000120778: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012077C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000120784: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012078C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000120794: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000120798: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012079C: 917E067E
	s_cbranch_execnz 65511                                     // 0000001207A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c40>
	s_or_b32 exec_lo, exec_lo, s6                              // 0000001207A4: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 0000001207A8: BF89FC07
	s_barrier                                                  // 0000001207AC: BFBD0000
	buffer_gl0_inv                                             // 0000001207B0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000001207B8: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 0000001207C0: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 0000001207C8: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 0000001207D0: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 0000001207D8: 7E780300
	s_mov_b32 s4, 0                                            // 0000001207DC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001207E0: BF840001
	s_nop 0                                                    // 0000001207E4: BF800000
	s_nop 0                                                    // 0000001207E8: BF800000
	s_nop 0                                                    // 0000001207EC: BF800000
	s_nop 0                                                    // 0000001207F0: BF800000
	s_nop 0                                                    // 0000001207F4: BF800000
	s_nop 0                                                    // 0000001207F8: BF800000
	s_nop 0                                                    // 0000001207FC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120800: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000120804: 327A7884
	.long 0xd4490001                                           // 000000120808: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012080C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000120814: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000120818: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000120824: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000120828: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 000000120830: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000120838: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 000000120840: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 000000120844: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000120848: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 00000012084C: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 000000120858: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000120860: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000120868: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000120870: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000120878: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 000000120880: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 000000120884: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120888: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 00000012088C: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 000000120890: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120894: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 000000120898: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012089C: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001208A8: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000001208AC: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000001208B4: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000001208BC: 917E047E
	s_cbranch_execnz 65487                                     // 0000001208C0: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1d00>
	s_set_inst_prefetch_distance 0x2                           // 0000001208C4: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000001208C8: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 0000001208CC: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000001208D4: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000001208DC: 7E420326
	s_mov_b32 s6, 0                                            // 0000001208E0: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000001208E4: BF89FC07
	s_barrier                                                  // 0000001208E8: BFBD0000
	buffer_gl0_inv                                             // 0000001208EC: E0AC0000 00000000
	s_nop 0                                                    // 0000001208F4: BF800000
	s_nop 0                                                    // 0000001208F8: BF800000
	s_nop 0                                                    // 0000001208FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000120900: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 000000120908: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000120910: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000120918: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012091C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000120924: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000120928: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000120930: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000120934: 10444722
	.long 0xd4490004                                           // 000000120938: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012093C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000120944: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012094C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000120954: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000120958: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012095C: 917E067E
	s_cbranch_execnz 65511                                     // 000000120960: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e00>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000120964: 8C7E067E
	v_dual_mov_b32 v61, v0 :: v_dual_add_nc_u32 v60, 0x400, v47// 000000120968: CA200100 3D3C5EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 000000120974: BF89FC07
	s_barrier                                                  // 000000120978: BFBD0000
	buffer_gl0_inv                                             // 00000012097C: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 000000120984: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 00000012098C: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 000000120994: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 00000012099C: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000001209A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001209A8: BF840001
	s_nop 0                                                    // 0000001209AC: BF800000
	s_nop 0                                                    // 0000001209B0: BF800000
	s_nop 0                                                    // 0000001209B4: BF800000
	s_nop 0                                                    // 0000001209B8: BF800000
	s_nop 0                                                    // 0000001209BC: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000001209C0: 327C7A84
	.long 0xd4490001                                           // 0000001209C4: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000001209C8: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001209D0: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000001209D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000001209D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000001209E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000001209E8: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 0000001209F0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000001209F8: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000120A00: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000120A04: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000120A08: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 000000120A0C: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000120A18: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 000000120A20: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 000000120A24: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000120A30: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 000000120A38: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 000000120A3C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120A40: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000120A44: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000120A48: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000120A54: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000120A5C: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000120A60: C820473F 463E7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000120A6C: BF870001
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000120A70: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000120A78: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000120A80: 917E047E
	s_cbranch_execnz 65486                                     // 000000120A84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1ec0>
	s_set_inst_prefetch_distance 0x2                           // 000000120A88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000120A8C: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 000000120A90: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000120A98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000120AA0: 7E420326
	s_mov_b32 s6, 0                                            // 000000120AA4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000120AA8: BF89FC07
	s_barrier                                                  // 000000120AAC: BFBD0000
	buffer_gl0_inv                                             // 000000120AB0: E0AC0000 00000000
	s_nop 0                                                    // 000000120AB8: BF800000
	s_nop 0                                                    // 000000120ABC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000120AC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 000000120AC8: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000120AD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000120AD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000120ADC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000120AE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000120AE8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000120AF0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000120AF4: 10444722
	.long 0xd4490004                                           // 000000120AF8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000120AFC: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000120B04: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000120B0C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000120B14: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000120B18: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000120B1C: 917E067E
	s_cbranch_execnz 65511                                     // 000000120B20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1fc0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000120B24: 8C7E067E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 000000120B28: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 000000120B30: BF89FC07
	s_barrier                                                  // 000000120B34: BFBD0000
	buffer_gl0_inv                                             // 000000120B38: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 000000120B40: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 000000120B48: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 000000120B50: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 000000120B58: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000120B60: 7E780300
	s_mov_b32 s4, 0                                            // 000000120B64: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000120B68: BF840001
	s_nop 0                                                    // 000000120B6C: BF800000
	s_nop 0                                                    // 000000120B70: BF800000
	s_nop 0                                                    // 000000120B74: BF800000
	s_nop 0                                                    // 000000120B78: BF800000
	s_nop 0                                                    // 000000120B7C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120B80: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000120B84: 327A7884
	.long 0xd4490001                                           // 000000120B88: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000120B8C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000120B94: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000120B98: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000120BA4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000120BA8: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 000000120BB0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000120BB8: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 000000120BC0: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 000000120BC4: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 000000120BC8: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 000000120BCC: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 000000120BD8: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000120BE0: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000120BE8: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000120BF0: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000120BF8: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 000000120C00: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 000000120C04: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120C08: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 000000120C0C: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 000000120C10: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120C14: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 000000120C18: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000120C1C: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000120C28: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000120C2C: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000120C34: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000120C3C: 917E047E
	s_cbranch_execnz 65487                                     // 000000120C40: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2080>
	s_set_inst_prefetch_distance 0x2                           // 000000120C44: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000120C48: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 000000120C4C: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000120C54: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000120C5C: 7E420326
	s_mov_b32 s6, 0                                            // 000000120C60: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000120C64: BF89FC07
	s_barrier                                                  // 000000120C68: BFBD0000
	buffer_gl0_inv                                             // 000000120C6C: E0AC0000 00000000
	s_nop 0                                                    // 000000120C74: BF800000
	s_nop 0                                                    // 000000120C78: BF800000
	s_nop 0                                                    // 000000120C7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000120C80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 000000120C88: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000120C90: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000120C98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000120C9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000120CA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000120CA8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000120CB0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000120CB4: 10444722
	.long 0xd4490004                                           // 000000120CB8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000120CBC: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000120CC4: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000120CCC: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000120CD4: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000120CD8: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000120CDC: 917E067E
	s_cbranch_execnz 65511                                     // 000000120CE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2180>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000120CE4: 8C7E067E
	v_dual_mov_b32 v60, v0 :: v_dual_add_nc_u32 v61, 0x800, v47// 000000120CE8: CA200100 3C3C5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 000000120CF4: BF89FC07
	s_barrier                                                  // 000000120CF8: BFBD0000
	buffer_gl0_inv                                             // 000000120CFC: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 000000120D04: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 000000120D0C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 000000120D14: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 000000120D1C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 000000120D24: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000120D28: BF840001
	s_nop 0                                                    // 000000120D2C: BF800000
	s_nop 0                                                    // 000000120D30: BF800000
	s_nop 0                                                    // 000000120D34: BF800000
	s_nop 0                                                    // 000000120D38: BF800000
	s_nop 0                                                    // 000000120D3C: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 000000120D40: 327C7884
	.long 0xd4490001                                           // 000000120D44: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000120D48: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000120D50: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000120D54: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000120D58: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000120D64: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000120D68: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 000000120D70: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000120D78: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000120D80: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000120D84: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000120D88: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 000000120D8C: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000120D98: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 000000120DA0: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 000000120DA4: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000120DB0: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 000000120DB8: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 000000120DBC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120DC0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000120DC4: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000120DC8: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000120DD4: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000120DDC: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 000000120DE0: C820473F 463E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000120DEC: BF870111
	v_fmac_f32_e32 v70, v64, v36                               // 000000120DF0: 568C4940
	v_mov_b32_e32 v60, v63                                     // 000000120DF4: 7E78033F
	ds_store_b32 v62, v70                                      // 000000120DF8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000120E00: 917E047E
	s_cbranch_execnz 65486                                     // 000000120E04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2240>
	s_set_inst_prefetch_distance 0x2                           // 000000120E08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000120E0C: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 000000120E10: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000120E18: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000120E20: 7E420326
	s_mov_b32 s6, 0                                            // 000000120E24: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000120E28: BF89FC07
	s_barrier                                                  // 000000120E2C: BFBD0000
	buffer_gl0_inv                                             // 000000120E30: E0AC0000 00000000
	s_nop 0                                                    // 000000120E38: BF800000
	s_nop 0                                                    // 000000120E3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000120E40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 000000120E48: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000120E50: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000120E58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000120E5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000120E64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000120E68: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000120E70: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000120E74: 10444722
	.long 0xd4490004                                           // 000000120E78: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000120E7C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000120E84: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000120E8C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000120E94: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000120E98: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 000000120E9C: 917E067E
	s_cbranch_execnz 65511                                     // 000000120EA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2340>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000120EA4: 8C7E067E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 000000120EA8: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 000000120EB0: BF89FC07
	s_barrier                                                  // 000000120EB4: BFBD0000
	buffer_gl0_inv                                             // 000000120EB8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 000000120EC0: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 000000120EC8: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 000000120ED0: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 000000120ED8: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000120EE0: 7E7A0300
	s_mov_b32 s4, 0                                            // 000000120EE4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000120EE8: BF840001
	s_nop 0                                                    // 000000120EEC: BF800000
	s_nop 0                                                    // 000000120EF0: BF800000
	s_nop 0                                                    // 000000120EF4: BF800000
	s_nop 0                                                    // 000000120EF8: BF800000
	s_nop 0                                                    // 000000120EFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000120F00: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000120F04: 327C7A84
	.long 0xd4490001                                           // 000000120F08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000120F0C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000120F14: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000120F18: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000120F24: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000120F28: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 000000120F30: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000120F38: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000120F40: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000120F44: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000120F48: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 000000120F4C: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000120F58: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 000000120F60: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 000000120F64: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000120F70: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 000000120F78: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 000000120F7C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000120F80: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000120F84: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000120F88: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000120F94: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000120F9C: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000120FA0: C820473F 463E7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000120FAC: BF870001
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000120FB0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000120FB8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000120FC0: 917E047E
	s_cbranch_execnz 65486                                     // 000000120FC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2400>
	s_set_inst_prefetch_distance 0x2                           // 000000120FC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000120FCC: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 000000120FD0: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000120FD8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000120FE0: 7E420326
	s_mov_b32 s6, 0                                            // 000000120FE4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 000000120FE8: BF89FC07
	s_barrier                                                  // 000000120FEC: BFBD0000
	buffer_gl0_inv                                             // 000000120FF0: E0AC0000 00000000
	s_nop 0                                                    // 000000120FF8: BF800000
	s_nop 0                                                    // 000000120FFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000121000: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 000000121008: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000121010: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000121018: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000012101C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000121024: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000121028: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000121030: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000121034: 10444722
	.long 0xd4490004                                           // 000000121038: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000012103C: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000121044: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012104C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000121054: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000121058: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012105C: 917E067E
	s_cbranch_execnz 65511                                     // 000000121060: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2500>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000121064: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000121068: BF89FC07
	s_barrier                                                  // 00000012106C: BFBD0000
	buffer_gl0_inv                                             // 000000121070: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 000000121078: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 000000121080: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 000000121088: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 000000121090: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000121098: 7E7A0300
	s_mov_b32 s4, 0                                            // 00000012109C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000001210A0: BF840001
	s_nop 0                                                    // 0000001210A4: BF800000
	s_nop 0                                                    // 0000001210A8: BF800000
	s_nop 0                                                    // 0000001210AC: BF800000
	s_nop 0                                                    // 0000001210B0: BF800000
	s_nop 0                                                    // 0000001210B4: BF800000
	s_nop 0                                                    // 0000001210B8: BF800000
	s_nop 0                                                    // 0000001210BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001210C0: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 0000001210C4: 327C7A84
	.long 0xd4490001                                           // 0000001210C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 0000001210CC: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 0000001210D4: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 0000001210D8: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000001210E4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 0000001210E8: 4A7E8AFF 00003200
	ds_load_b32 v70, v62                                       // 0000001210F0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 0000001210F8: D8DCC140 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 000000121100: BF89FC07
	v_fmac_f32_e32 v70, v63, v29                               // 000000121104: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1)                            // 000000121108: BF870001
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v65, 0x3600, v69// 00000012110C: C8203D40 46408AFF 00003600
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000121118: D8DCC342 41000041
	s_waitcnt lgkmcnt(0)                                       // 000000121120: BF89FC07
	v_dual_fmac_f32 v70, v65, v31 :: v_dual_add_nc_u32 v67, 0x3a00, v69// 000000121124: C8203F41 46428AFF 00003A00
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000121130: D8DCC544 43000043
	v_fmac_f32_e32 v70, v66, v32                               // 000000121138: 568C4142
	s_waitcnt lgkmcnt(0)                                       // 00000012113C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121140: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000121144: 568C4343
	v_dual_fmac_f32 v70, v68, v34 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000121148: C8204544 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000121154: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(0)                                       // 00000012115C: BF89FC07
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000121160: C820473F 463E7AFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 00000012116C: BF870001
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000121170: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000121178: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000121180: 917E047E
	s_cbranch_execnz 65486                                     // 000000121184: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25c0>
	s_set_inst_prefetch_distance 0x2                           // 000000121188: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000012118C: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 000000121190: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000121198: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000001211A0: 7E420326
	s_mov_b32 s6, 0                                            // 0000001211A4: BE860080
	s_waitcnt lgkmcnt(0)                                       // 0000001211A8: BF89FC07
	s_barrier                                                  // 0000001211AC: BFBD0000
	buffer_gl0_inv                                             // 0000001211B0: E0AC0000 00000000
	s_nop 0                                                    // 0000001211B8: BF800000
	s_nop 0                                                    // 0000001211BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000001211C0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 0000001211C8: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000001211D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000001211D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000001211DC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000001211E4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000001211E8: D5207C1E 00063C80
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001211F0: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000001211F4: 10444722
	.long 0xd4490004                                           // 0000001211F8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000001211FC: 020242FF 0000037F
	ds_store_b32 v31, v34 offset:13056                         // 000000121204: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000012120C: 4A3E3EFF 00000204
	s_or_b32 s6, s4, s6                                        // 000000121214: 8C060604
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000121218: BF870009
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000012121C: 917E067E
	s_cbranch_execnz 65511                                     // 000000121220: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x26c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000121224: 8C7E067E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 000000121228: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 000000121230: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 000000121238: BF89FC07
	s_barrier                                                  // 00000012123C: BFBD0000
	buffer_gl0_inv                                             // 000000121240: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 000000121248: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 000000121250: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 000000121258: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 000000121260: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 000000121268: 7E780300
	s_mov_b32 s4, 0                                            // 00000012126C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000121270: BF840001
	s_nop 0                                                    // 000000121274: BF800000
	s_nop 0                                                    // 000000121278: BF800000
	s_nop 0                                                    // 00000012127C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000121280: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000121284: 327A7884
	.long 0xd4490001                                           // 000000121288: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000012128C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000121294: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000121298: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000001212A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000001212A8: 4A7C88FF 00003200
	ds_load_b32 v69, v61                                       // 0000001212B0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000001212B8: D8DCC140 3E00003E
	s_waitcnt lgkmcnt(0)                                       // 0000001212C0: BF89FC07
	v_fmac_f32_e32 v69, v62, v29                               // 0000001212C4: 568A3B3E
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001212C8: BF870001
	v_dual_fmac_f32 v69, v63, v30 :: v_dual_add_nc_u32 v66, 0x3a00, v68// 0000001212CC: C8203D3F 454288FF 00003A00
	v_add_nc_u32_e32 v62, 0x3e00, v68                          // 0000001212D8: 4A7C88FF 00003E00
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000001212E0: D8DCC544 42000042
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000001212E8: 4A8088FF 00003600
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000001212F0: D8DCC746 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000001212F8: D8DCC342 40000040
	s_waitcnt lgkmcnt(0)                                       // 000000121300: BF89FC07
	v_fmac_f32_e32 v69, v64, v31                               // 000000121304: 568A3F40
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121308: BF870091
	v_fmac_f32_e32 v69, v65, v32                               // 00000012130C: 568A4141
	v_fmac_f32_e32 v69, v66, v33                               // 000000121310: 568A4342
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000121314: BF870091
	v_fmac_f32_e32 v69, v67, v34                               // 000000121318: 568A4543
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000012131C: C820473E 453E78FF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000121328: BF870001
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000012132C: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000121334: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000012133C: 917E047E
	s_cbranch_execnz 65487                                     // 000000121340: BFA6FFCF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2780>
	s_set_inst_prefetch_distance 0x2                           // 000000121344: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000121348: 8C7E047E
	.long 0xd7000107                                           // 00000012134C: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 000000121350: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000121358: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 00000012135C: D5207C08 00061080
	.long 0xd7000109                                           // 000000121364: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 000000121368: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 000000121370: D5207C0A 00061480
	.long 0xd700010d                                           // 000000121378: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 00000012137C: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000121384: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 000000121388: D5207C0E 00061C80
	.long 0xd700010b                                           // 000000121390: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 000000121394: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 00000012139C: D5207C0C 00061880
	.long 0xd700010f                                           // 0000001213A4: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 0000001213A8: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001213B0: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 0000001213B4: D5207C10 00062080
	.long 0xd7000111                                           // 0000001213BC: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 0000001213C0: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 0000001213C8: D5207C12 00062480
	.long 0xd7000113                                           // 0000001213D0: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 0000001213D4: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001213DC: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 0000001213E0: D5207C14 00062880
	.long 0xd7000115                                           // 0000001213E8: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 0000001213EC: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 0000001213F4: D5207C16 00062C80
	.long 0xd7000117                                           // 0000001213FC: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 000000121400: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000121408: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 00000012140C: D5207C18 00063080
	.long 0xd7000119                                           // 000000121414: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 000000121418: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 000000121420: D5207C1A 00063480
	.long 0xd700011b                                           // 000000121428: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 00000012142C: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000121434: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 000000121438: D5207C1C 00063880
	s_add_i32 s5, s5, 1                                        // 000000121440: 81058105
	s_waitcnt lgkmcnt(0)                                       // 000000121444: BF89FC07
	s_cmp_eq_u32 s5, s33                                       // 000000121448: BF062105
	s_barrier                                                  // 00000012144C: BFBD0000
	buffer_gl0_inv                                             // 000000121450: E0AC0000 00000000
	s_cbranch_scc0 63122                                       // 000000121458: BFA1F692 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 00000012145C: 7E080326
	s_add_u32 s0, s28, s20                                     // 000000121460: 8000141C
	.long 0xd73c0000                                           // 000000121464: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 000000121468: 02020489
	s_addc_u32 s1, s29, s21                                    // 00000012146C: 8201151D
	s_add_u32 s2, s24, s18                                     // 000000121470: 80021218
	s_addc_u32 s3, s25, s19                                    // 000000121474: 82031319
	s_add_u32 s0, s2, s0                                       // 000000121478: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000012147C: 82010103
	.long 0xd7006a00                                           // 000000121480: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 000000121484: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000121488: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000012148C: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 000000121494: BE810080
	.long 0xd7006a00                                           // 000000121498: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 00000012149C: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 0000001214A0: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001214A8: BF870092
	.long 0xd7006a00                                           // 0000001214AC: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000001214B0: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000001214B4: D5207C01 01AA0211
	s_nop 0                                                    // 0000001214BC: BF800000
	ds_load_b32 v2, v37                                        // 0000001214C0: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001214C8: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 0000001214D0: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001214D8: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 0000001214DC: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001214E4: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001214E8: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000001214EC: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000001214F4: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 0000001214F8: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 000000121500: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 000000121508: 917E017E
	s_cbranch_execnz 65516                                     // 00000012150C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi4ELb0ELi0ELi15ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x29c0>
	s_endpgm                                                   // 000000121510: BFB00000
		...

