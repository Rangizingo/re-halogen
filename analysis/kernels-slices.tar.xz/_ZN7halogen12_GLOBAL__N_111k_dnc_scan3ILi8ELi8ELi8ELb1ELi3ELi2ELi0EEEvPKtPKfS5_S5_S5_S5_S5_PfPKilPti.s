0000000000087d00 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti>:
; _ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti():
	s_clause 0x1                                               // 000000087D00: BF850001
	s_load_b512 s[8:23], s[0:1], 0x8                           // 000000087D04: F4100200 F8000008
	s_load_b128 s[4:7], s[0:1], 0x48                           // 000000087D0C: F4080100 F8000048
	s_lshl_b32 s28, s3, 4                                      // 000000087D14: 841C8403
	s_ashr_i32 s3, s2, 31                                      // 000000087D18: 86039F02
	s_ashr_i32 s29, s28, 31                                    // 000000087D1C: 861D9F1C
	v_dual_mov_b32 v4, v0 :: v_dual_and_b32 v5, 15, v0         // 000000087D20: CA240100 0404008F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 000000087D28: BF8704C1
	v_lshlrev_b32_e32 v1, 2, v5                                // 000000087D2C: 30020A82
	s_waitcnt lgkmcnt(0)                                       // 000000087D30: BF89FC07
	s_load_b32 s26, s[22:23], null                             // 000000087D34: F400068B F8000000
	s_lshl_b64 s[22:23], s[4:5], 2                             // 000000087D3C: 84968204
	s_add_u32 s4, s20, s22                                     // 000000087D40: 80041614
	s_addc_u32 s5, s21, s23                                    // 000000087D44: 82051715
	s_lshl_b64 s[24:25], s[2:3], 16                            // 000000087D48: 84989002
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000087D4C: BF870009
	s_add_u32 s4, s4, s24                                      // 000000087D50: 80041804
	s_addc_u32 s5, s5, s25                                     // 000000087D54: 82051905
	s_waitcnt lgkmcnt(0)                                       // 000000087D58: BF89FC07
	s_mul_i32 s30, s26, 0x9000000                              // 000000087D5C: 961EFF1A 09000000
	s_mul_hi_i32 s31, s26, 0x9000000                           // 000000087D64: 971FFF1A 09000000
	s_add_u32 s4, s4, s30                                      // 000000087D6C: 80041E04
	s_addc_u32 s5, s5, s31                                     // 000000087D70: 82051F05
	s_lshl_b64 s[26:27], s[28:29], 2                           // 000000087D74: 849A821C
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 000000087D78: BF8700B9
	s_add_u32 s4, s4, s26                                      // 000000087D7C: 80041A04
	s_addc_u32 s5, s5, s27                                     // 000000087D80: 82051B05
	.long 0xd7000402                                           // 000000087D84: D7000402
	v_cndmask_b32_e32 v1, s4, v1, vcc_lo                       // 000000087D88: 02020204
	v_add_co_ci_u32_e64 v3, null, s5, 0, s4                    // 000000087D8C: D5207C03 00110005
	s_mov_b32 s4, 0                                            // 000000087D94: BE840080
	s_nop 0                                                    // 000000087D98: BF800000
	s_nop 0                                                    // 000000087D9C: BF800000
	s_nop 0                                                    // 000000087DA0: BF800000
	s_nop 0                                                    // 000000087DA4: BF800000
	s_nop 0                                                    // 000000087DA8: BF800000
	s_nop 0                                                    // 000000087DAC: BF800000
	s_nop 0                                                    // 000000087DB0: BF800000
	s_nop 0                                                    // 000000087DB4: BF800000
	s_nop 0                                                    // 000000087DB8: BF800000
	s_nop 0                                                    // 000000087DBC: BF800000
	v_lshrrev_b32_e32 v8, 4, v4                                // 000000087DC0: 32100884
	v_add_nc_u32_e32 v10, 0x80, v4                             // 000000087DC4: 4A1408FF 00000080
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000087DCC: BF870092
	v_lshlrev_b32_e32 v6, 9, v8                                // 000000087DD0: 300C1089
	.long 0xd7006a06                                           // 000000087DD4: D7006A06
	v_cndmask_b32_e32 v1, v2, v6, vcc_lo                       // 000000087DD8: 02020D02
	s_delay_alu instid0(VALU_DEP_1)                            // 000000087DDC: BF870001
	v_add_co_ci_u32_e64 v7, null, 0, v3, vcc_lo                // 000000087DE0: D5207C07 01AA0680
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 000000087DE8: 7C9208FF 0000077F
	v_mov_b32_e32 v4, v10                                      // 000000087DF0: 7E08030A
	global_load_b32 v9, v[6:7], off                            // 000000087DF4: DC520000 097C0006
	v_mad_u64_u32 v[6:7], null, 0x44, v8, v[1:2]               // 000000087DFC: D6FE7C06 040610FF 00000044
	s_or_b32 s4, vcc_lo, s4                                    // 000000087E08: 8C04046A
	s_waitcnt vmcnt(0)                                         // 000000087E0C: BF8903F7
	ds_store_b32 v6, v9                                        // 000000087E10: D8340000 00000906
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000087E18: 917E047E
	s_cbranch_execnz 65512                                     // 000000087E1C: BFA6FFE8 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000087E20: 8C7E047E
	s_load_b32 s33, s[0:1], 0x58                               // 000000087E24: F4000840 F8000058
	v_or_b32_e32 v38, 0xffffff80, v0                           // 000000087E2C: 384C00FF FFFFFF80
	v_lshrrev_b32_e32 v2, 4, v0                                // 000000087E34: 32040084
	s_mov_b32 s0, 0                                            // 000000087E38: BE800080
	s_waitcnt lgkmcnt(0)                                       // 000000087E3C: BF89FC07
	s_barrier                                                  // 000000087E40: BFBD0000
	buffer_gl0_inv                                             // 000000087E44: E0AC0000 00000000
	s_cmp_gt_i32 s33, 0                                        // 000000087E4C: BF028021
	s_cbranch_scc1 12                                          // 000000087E50: BFA2000C <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x184>
	v_mul_u32_u24_e32 v3, 0x44, v2                             // 000000087E54: 160604FF 00000044
	v_or_b32_e32 v4, 0xffffff80, v0                            // 000000087E5C: 380800FF FFFFFF80
	s_delay_alu instid0(VALU_DEP_2)                            // 000000087E64: BF870002
	v_lshl_add_u32 v37, v5, 2, v3                              // 000000087E68: D6460025 040D0505
	v_mov_b32_e32 v3, 0                                        // 000000087E70: 7E060280
	v_lshlrev_b32_e32 v39, 2, v5                               // 000000087E74: 304E0A82
	s_and_not1_b32 vcc_lo, exec_lo, s0                         // 000000087E78: 916A007E
	s_cbranch_vccz 2                                           // 000000087E7C: BFA30002 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x188>
	s_branch 2312                                              // 000000087E80: BFA00908 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x25a4>
	v_lshlrev_b32_e32 v39, 2, v5                               // 000000087E84: 304E0A82
	s_add_i32 s0, s33, 63                                      // 000000087E88: 8100BF21
	s_add_i32 s34, s2, 0xbd0                                   // 000000087E8C: 8122FF02 00000BD0
	s_lshr_b32 s35, s0, 6                                      // 000000087E94: 85238600
	s_add_u32 s14, s14, s26                                    // 000000087E98: 800E1A0E
	s_addc_u32 s15, s15, s27                                   // 000000087E9C: 820F1B0F
	s_lshl_b32 s0, s2, 7                                       // 000000087EA0: 84008702
	v_dual_mov_b32 v3, 0 :: v_dual_lshlrev_b32 v40, 2, v0      // 000000087EA4: CA220080 03280082
	s_ashr_i32 s1, s0, 31                                      // 000000087EAC: 86019F00
	v_lshlrev_b32_e32 v5, 1, v5                                // 000000087EB0: 300A0A81
	s_lshl_b64 s[0:1], s[0:1], 1                               // 000000087EB4: 84808100
	v_lshlrev_b32_e32 v13, 8, v2                               // 000000087EB8: 301A0488
	s_add_u32 s6, s6, s0                                       // 000000087EBC: 80060006
	s_addc_u32 s1, s7, s1                                      // 000000087EC0: 82010107
	s_lshl_b64 s[4:5], s[28:29], 1                             // 000000087EC4: 8484811C
	v_mad_u32_u24 v37, 0x44, v2, v39                           // 000000087EC8: D60B0025 049E04FF 00000044
	s_add_u32 s6, s6, s4                                       // 000000087ED4: 80060406
	s_addc_u32 s1, s1, s5                                      // 000000087ED8: 82010501
	s_movk_i32 s4, 0x204                                       // 000000087EDC: B0040204
	.long 0xd700052c                                           // 000000087EE0: D700052C
	v_cndmask_b32_e32 v1, s14, v39, vcc_lo                     // 000000087EE4: 02024E0E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 000000087EE8: BF8704B1
	v_add_co_ci_u32_e64 v45, null, s15, 0, s5                  // 000000087EEC: D5207C2D 0015000F
	v_mad_u32_u24 v46, v2, s4, 0x3300                          // 000000087EF4: D60B002E 03FC0902 00003300
	s_lshl_b64 s[4:5], s[2:3], 9                               // 000000087F00: 84848902
	v_dual_mov_b32 v12, s5 :: v_dual_add_nc_u32 v41, 0x4320, v40// 000000087F04: CA200005 0C2850FF 00004320
	v_or_b32_e32 v11, s4, v40                                  // 000000087F10: 38165004
	.long 0xd7000405                                           // 000000087F14: D7000405
	v_cndmask_b32_e32 v1, s6, v5, vcc_lo                       // 000000087F18: 02020A06
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000087F1C: BF870191
	v_add_co_ci_u32_e64 v6, null, s1, 0, s4                    // 000000087F20: D5207C06 00110001
	.long 0xd7000107                                           // 000000087F28: D7000107
	v_cndmask_b32_e32 v1, s16, v11, vcc_lo                     // 000000087F2C: 02021610
	s_delay_alu instid0(VALU_DEP_1)                            // 000000087F30: BF870001
	v_add_co_ci_u32_e64 v8, null, s17, v12, s1                 // 000000087F34: D5207C08 00061811
	.long 0xd7000109                                           // 000000087F3C: D7000109
	v_cndmask_b32_e32 v1, s8, v11, vcc_lo                      // 000000087F40: 02021608
	s_lshl_b64 s[4:5], s[2:3], 14                              // 000000087F44: 84848E02
	v_add_co_ci_u32_e64 v10, null, s9, v12, s1                 // 000000087F48: D5207C0A 00061809
	.long 0xd700010b                                           // 000000087F50: D700010B
	v_cndmask_b32_e32 v1, s10, v11, vcc_lo                     // 000000087F54: 0202160A
	s_add_u32 s4, s18, s4                                      // 000000087F58: 80040412
	v_add_co_ci_u32_e64 v12, null, s11, v12, s1                // 000000087F5C: D5207C0C 0006180B
	s_addc_u32 s5, s19, s5                                     // 000000087F64: 82050513
	.long 0xd700010d                                           // 000000087F68: D700010D
	v_cndmask_b32_e32 v1, s4, v13, vcc_lo                      // 000000087F6C: 02021A04
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000087F70: BF8700A1
	v_add_co_ci_u32_e64 v14, null, s5, 0, s1                   // 000000087F74: D5207C0E 00050005
	.long 0xd700010f                                           // 000000087F7C: D700010F
	v_cndmask_b32_e32 v1, 0x30000, v11, vcc_lo                 // 000000087F80: 020216FF 00030000
	v_add_co_ci_u32_e64 v16, null, 0, v12, s1                  // 000000087F88: D5207C10 00061880
	.long 0xd7000111                                           // 000000087F90: D7000111
	v_cndmask_b32_e32 v1, 0x60000, v11, vcc_lo                 // 000000087F94: 020216FF 00060000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000087F9C: BF8700A1
	v_add_co_ci_u32_e64 v18, null, 0, v12, s1                  // 000000087FA0: D5207C12 00061880
	.long 0xd7000113                                           // 000000087FA8: D7000113
	v_cndmask_b32_e32 v1, 0x90000, v11, vcc_lo                 // 000000087FAC: 020216FF 00090000
	v_add_co_ci_u32_e64 v20, null, 0, v12, s1                  // 000000087FB4: D5207C14 00061880
	.long 0xd7000115                                           // 000000087FBC: D7000115
	v_cndmask_b32_e32 v1, 0xc0000, v11, vcc_lo                 // 000000087FC0: 020216FF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 000000087FC8: BF8700A1
	v_add_co_ci_u32_e64 v22, null, 0, v12, s1                  // 000000087FCC: D5207C16 00061880
	.long 0xd7000117                                           // 000000087FD4: D7000117
	v_cndmask_b32_e32 v1, 0xf0000, v11, vcc_lo                 // 000000087FD8: 020216FF 000F0000
	v_add_co_ci_u32_e64 v24, null, 0, v12, s1                  // 000000087FE0: D5207C18 00061880
	.long 0xd7000119                                           // 000000087FE8: D7000119
	v_cndmask_b32_e32 v1, 0x120000, v11, vcc_lo                // 000000087FEC: 020216FF 00120000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000087FF4: BF870001
	v_add_co_ci_u32_e64 v26, null, 0, v12, s1                  // 000000087FF8: D5207C1A 00061880
	.long 0xd700011b                                           // 000000088000: D700011B
	v_cndmask_b32_e32 v1, 0x150000, v11, vcc_lo                // 000000088004: 020216FF 00150000
	v_add_nc_u32_e32 v42, 0x4420, v40                          // 00000008800C: 4A5450FF 00004420
	.long 0xd44c0000                                           // 000000088014: D44C0000
	v_cndmask_b32_e32 v1, 0x80, v0, vcc_lo                     // 000000088018: 020200FF 00000080
	v_add_nc_u32_e32 v43, 1, v2                                // 000000088020: 4A560481
	v_add_nc_u32_e32 v4, 0x2200, v37                           // 000000088024: 4A084AFF 00002200
	v_or_b32_e32 v47, 0x2200, v1                               // 00000008802C: 385E02FF 00002200
	v_add_co_ci_u32_e64 v28, null, 0, v12, s1                  // 000000088034: D5207C1C 00061880
	v_add_nc_u32_e32 v48, 0x400, v1                            // 00000008803C: 4A6002FF 00000400
	v_add_nc_u32_e32 v49, 0x600, v1                            // 000000088044: 4A6202FF 00000600
	v_add_nc_u32_e32 v50, 0x800, v1                            // 00000008804C: 4A6402FF 00000800
	v_add_nc_u32_e32 v51, 0xc00, v1                            // 000000088054: 4A6602FF 00000C00
	v_add_nc_u32_e32 v52, 0xe00, v1                            // 00000008805C: 4A6802FF 00000E00
	v_add_nc_u32_e32 v53, 0x1000, v1                           // 000000088064: 4A6A02FF 00001000
	v_add_nc_u32_e32 v54, 0x1400, v1                           // 00000008806C: 4A6C02FF 00001400
	v_add_nc_u32_e32 v55, 0x1600, v1                           // 000000088074: 4A6E02FF 00001600
	v_add_nc_u32_e32 v56, 0x1800, v1                           // 00000008807C: 4A7002FF 00001800
	v_add_nc_u32_e32 v57, 0x1c00, v1                           // 000000088084: 4A7202FF 00001C00
	v_add_nc_u32_e32 v58, 0x1e00, v1                           // 00000008808C: 4A7402FF 00001E00
	v_add_nc_u32_e32 v59, 0x2000, v1                           // 000000088094: 4A7602FF 00002000
	s_mov_b32 s11, 0                                           // 00000008809C: BE8B0080
	v_cmp_gt_u32_e32 vcc_lo, 64, v0                            // 0000000880A0: 7C9800C0
	s_mul_i32 s1, s11, 0xc00                                   // 0000000880A4: 9601FF0B 00000C00
	s_lshl_b32 s15, s11, 6                                     // 0000000880AC: 840F860B
	s_add_i32 s4, s34, s1                                      // 0000000880B0: 81040122
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 0000000880B4: BF870499
	s_ashr_i32 s5, s4, 31                                      // 0000000880B8: 86059F04
	s_lshl_b64 s[4:5], s[4:5], 2                               // 0000000880BC: 84848204
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000000880C0: BF870009
	s_add_u32 s4, s12, s4                                      // 0000000880C4: 8004040C
	s_addc_u32 s5, s13, s5                                     // 0000000880C8: 8205050D
	s_load_b32 s14, s[4:5], null                               // 0000000880CC: F4000382 F8000000
	s_and_saveexec_b32 s4, vcc_lo                              // 0000000880D4: BE84206A
	s_cbranch_execz 77                                         // 0000000880D8: BFA5004D <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x510>
	v_or_b32_e32 v29, s15, v0                                  // 0000000880DC: 383A000F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000880E0: BF870091
	v_mad_u64_u32 v[29:30], null, v29, 48, s[2:3]              // 0000000880E4: D6FE7C1D 0009611D
	v_ashrrev_i32_e32 v30, 31, v29                             // 0000000880EC: 343C3A9F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000880F0: BF870091
	.long 0xd73c001d                                           // 0000000880F4: D73C001D
	v_cndmask_b32_e32 v1, 2, v29, vcc_lo                       // 0000000880F8: 02023A82
	.long 0xd700011d                                           // 0000000880FC: D700011D
	v_cndmask_b32_e32 v1, s12, v29, vcc_lo                     // 000000088100: 02023A0C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000088104: BF8700C1
	v_add_co_ci_u32_e64 v30, null, s13, v30, s1                // 000000088108: D5207C1E 00063C0D
	global_load_b32 v29, v[29:30], off                         // 000000088110: DC520000 1D7C001D
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000088118: BF890007
	v_sub_f32_e32 v30, s14, v29                                // 00000008811C: 083C3A0E
	v_dual_mul_f32 v32, 0x3fb8aa3b, v29 :: v_dual_mul_f32 v31, 0x3fb8aa3b, v30// 000000088120: C8C63AFF 201E3CFF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 00000008812C: BF8701A1
	v_fma_f32 v35, 0x3fb8aa3b, v29, -v32                       // 000000088130: D6130023 84823AFF 3FB8AA3B
	v_rndne_f32_e32 v36, v32                                   // 00000008813C: 7E484720
	v_fma_f32 v33, 0x3fb8aa3b, v30, -v31                       // 000000088140: D6130021 847E3CFF 3FB8AA3B
	v_rndne_f32_e32 v34, v31                                   // 00000008814C: 7E44471F
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 000000088150: BF870113
	v_dual_fmac_f32 v35, 0x32a5705f, v29 :: v_dual_sub_f32 v32, v32, v36// 000000088154: C80A3AFF 23204920 32A5705F
	v_sub_f32_e32 v31, v31, v34                                // 000000088160: 083E451F
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000088164: BF870124
	v_fmac_f32_e32 v33, 0x32a5705f, v30                        // 000000088168: 56423CFF 32A5705F
	.long 0xd41b0001                                           // 000000088170: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v30, vcc_lo              // 000000088174: 02023CFF C2CE8ED0
	v_dual_add_f32 v32, v32, v35 :: v_dual_add_f32 v31, v31, v33// 00000008817C: C9084720 201E431F
	v_cvt_i32_f32_e32 v33, v34                                 // 000000088184: 7E421122
	v_cvt_i32_f32_e32 v34, v36                                 // 000000088188: 7E441124
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000008818C: BF870193
	v_exp_f32_e32 v32, v32                                     // 000000088190: 7E404B20
	v_exp_f32_e32 v31, v31                                     // 000000088194: 7E3E4B1F
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 000000088198: BF870296
	.long 0xd71c0020                                           // 00000008819C: D71C0020
	v_cndmask_b32_e32 v1, v32, v34, vcc_lo                     // 0000000881A0: 02024520
	.long 0xd71c001f                                           // 0000000881A4: D71C001F
	v_cndmask_b32_e32 v1, v31, v33, vcc_lo                     // 0000000881A8: 0202431F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000881AC: BF8700A1
	v_cndmask_b32_e64 v31, 0, v31, s1                          // 0000000881B0: D501001F 00063E80
	.long 0xd41b0001                                           // 0000000881B8: D41B0001
	v_cndmask_b32_e32 v1, 0xc2ce8ed0, v29, vcc_lo              // 0000000881BC: 02023AFF C2CE8ED0
	v_cndmask_b32_e64 v32, 0, v32, s1                          // 0000000881C4: D5010020 00064080
	.long 0xd41e0001                                           // 0000000881CC: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v30, vcc_lo              // 0000000881D0: 02023CFF 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000881D8: BF8700A1
	v_cndmask_b32_e64 v30, 0x7f800000, v31, s1                 // 0000000881DC: D501001E 00063EFF 7F800000
	.long 0xd41e0001                                           // 0000000881E8: D41E0001
	v_cndmask_b32_e32 v1, 0x42b17218, v29, vcc_lo              // 0000000881EC: 02023AFF 42B17218
	v_cndmask_b32_e64 v29, 0x7f800000, v32, s1                 // 0000000881F4: D501001D 000640FF 7F800000
	ds_store_b32 v41, v30                                      // 000000088200: D8340000 00001E29
	ds_store_b32 v42, v29                                      // 000000088208: D8340000 00001D2A
	s_or_b32 exec_lo, exec_lo, s4                              // 000000088210: 8C7E047E
	v_dual_mov_b32 v30, v8 :: v_dual_mov_b32 v29, v7           // 000000088214: CA100108 1E1C0107
	s_mov_b32 s5, 0                                            // 00000008821C: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000088220: BF89FC07
	s_barrier                                                  // 000000088224: BFBD0000
	buffer_gl0_inv                                             // 000000088228: E0AC0000 00000000
	s_branch 15                                                // 000000088230: BFA0000F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x570>
	s_or_b32 exec_lo, exec_lo, s4                              // 000000088234: 8C7E047E
	.long 0xd700011d                                           // 000000088238: D700011D
	v_cndmask_b32_e32 v1, 0x30000, v29, vcc_lo                 // 00000008823C: 02023AFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000088244: BF870001
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000088248: D5207C1E 00063C80
	s_add_i32 s1, s5, 8                                        // 000000088250: 81018805
	s_cmp_gt_u32 s5, 55                                        // 000000088254: BF08B705
	s_mov_b32 s5, s1                                           // 000000088258: BE850001
	s_waitcnt lgkmcnt(0)                                       // 00000008825C: BF89FC07
	s_barrier                                                  // 000000088260: BFBD0000
	buffer_gl0_inv                                             // 000000088264: E0AC0000 00000000
	s_cbranch_scc1 706                                         // 00000008826C: BFA202C2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1078>
	v_dual_mov_b32 v32, v30 :: v_dual_mov_b32 v31, v29         // 000000088270: CA10011E 201E011D
	v_dual_mov_b32 v33, v40 :: v_dual_mov_b32 v34, v38         // 000000088278: CA100128 21220126
	s_mov_b32 s6, 0                                            // 000000088280: BE860080
	s_nop 0                                                    // 000000088284: BF800000
	s_nop 0                                                    // 000000088288: BF800000
	s_nop 0                                                    // 00000008828C: BF800000
	s_nop 0                                                    // 000000088290: BF800000
	s_nop 0                                                    // 000000088294: BF800000
	s_nop 0                                                    // 000000088298: BF800000
	s_nop 0                                                    // 00000008829C: BF800000
	s_nop 0                                                    // 0000000882A0: BF800000
	s_nop 0                                                    // 0000000882A4: BF800000
	s_nop 0                                                    // 0000000882A8: BF800000
	s_nop 0                                                    // 0000000882AC: BF800000
	s_nop 0                                                    // 0000000882B0: BF800000
	s_nop 0                                                    // 0000000882B4: BF800000
	s_nop 0                                                    // 0000000882B8: BF800000
	s_nop 0                                                    // 0000000882BC: BF800000
	global_load_b32 v35, v[31:32], off                         // 0000000882C0: DC520000 237C001F
	v_add_nc_u32_e32 v34, 0x80, v34                            // 0000000882C8: 4A4444FF 00000080
	.long 0xd700011f                                           // 0000000882D0: D700011F
	v_cndmask_b32_e32 v1, 0x6000, v31, vcc_lo                  // 0000000882D4: 02023EFF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000000882DC: BF870191
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 0000000882E0: D5207C20 00064080
	.long 0xd4490004                                           // 0000000882E8: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v34, vcc_lo                   // 0000000882EC: 020244FF 0000037F
	s_or_b32 s6, s4, s6                                        // 0000000882F4: 8C060604
	s_waitcnt vmcnt(0)                                         // 0000000882F8: BF8903F7
	ds_store_b32 v33, v35 offset:13056                         // 0000000882FC: D8343300 00002321
	v_add_nc_u32_e32 v33, 0x204, v33                           // 000000088304: 4A4242FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s6                        // 00000008830C: 917E067E
	s_cbranch_execnz 65515                                     // 000000088310: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x5c0>
	s_or_b32 exec_lo, exec_lo, s6                              // 000000088314: 8C7E067E
	s_waitcnt lgkmcnt(0)                                       // 000000088318: BF89FC07
	s_barrier                                                  // 00000008831C: BFBD0000
	buffer_gl0_inv                                             // 000000088320: E0AC0000 00000000
	s_and_saveexec_b32 s4, s0                                  // 000000088328: BE842000
	s_cbranch_execz 65473                                      // 00000008832C: BFA5FFC1 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	ds_load_2addr_b32 v[31:32], v46 offset1:1                  // 000000088330: D8DC0100 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:2 offset1:3        // 000000088338: D8DC0302 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:4 offset1:5        // 000000088340: D8DC0504 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:6 offset1:7        // 000000088348: D8DC0706 3C00002E
	ds_load_2addr_b32 v[62:63], v1 offset1:17                  // 000000088350: D8DC1100 3E000001
	ds_load_2addr_b32 v[64:65], v1 offset0:34 offset1:51       // 000000088358: D8DC3322 40000001
	ds_load_2addr_b32 v[66:67], v1 offset0:68 offset1:85       // 000000088360: D8DC5544 42000001
	ds_load_2addr_b32 v[68:69], v1 offset0:102 offset1:119     // 000000088368: D8DC7766 44000001
	ds_load_2addr_b32 v[72:73], v46 offset0:14 offset1:15      // 000000088370: D8DC0F0E 4800002E
	ds_load_2addr_b32 v[74:75], v1 offset0:136 offset1:153     // 000000088378: D8DC9988 4A000001
	ds_load_2addr_b32 v[76:77], v1 offset0:170 offset1:187     // 000000088380: D8DCBBAA 4C000001
	ds_load_2addr_b32 v[78:79], v1 offset0:204 offset1:221     // 000000088388: D8DCDDCC 4E000001
	ds_load_2addr_b32 v[80:81], v1 offset0:238 offset1:255     // 000000088390: D8DCFFEE 50000001
	v_or3_b32 v70, s5, s15, v2                                 // 000000088398: D6580046 04081E05
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000883A0: BF870091
	v_mad_u64_u32 v[70:71], null, v70, 48, s[2:3]              // 0000000883A4: D6FE7C46 00096146
	.long 0xd73c0046                                           // 0000000883AC: D73C0046
	v_cndmask_b32_e32 v1, 9, v70, vcc_lo                       // 0000000883B0: 02028C89
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000883B4: BF870091
	.long 0xd7000146                                           // 0000000883B8: D7000146
	v_cndmask_b32_e32 v1, v44, v70, vcc_lo                     // 0000000883BC: 02028D2C
	v_add_co_ci_u32_e64 v71, null, v45, v71, s1                // 0000000883C0: D5207C47 00068F2D
	global_load_b32 v70, v[70:71], off                         // 0000000883C8: DC520000 467C0046
	s_waitcnt vmcnt(0) lgkmcnt(8)                              // 0000000883D0: BF890087
	v_fma_f32 v31, -v31, v62, v70                              // 0000000883D4: D613001F 251A7D1F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000000883DC: BF8700A1
	v_fma_f32 v31, -v32, v63, v31                              // 0000000883E0: D613001F 247E7F20
	s_waitcnt lgkmcnt(7)                                       // 0000000883E8: BF89FC77
	v_fma_f32 v33, -v33, v64, v31                              // 0000000883EC: D6130021 247E8121
	ds_load_2addr_b32 v[31:32], v46 offset0:8 offset1:9        // 0000000883F4: D8DC0908 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:10 offset1:11      // 0000000883FC: D8DC0B0A 3E00002E
	ds_load_2addr_b32 v[70:71], v46 offset0:12 offset1:13      // 000000088404: D8DC0D0C 4600002E
	v_fma_f32 v33, -v34, v65, v33                              // 00000008840C: D6130021 24868322
	s_waitcnt lgkmcnt(9)                                       // 000000088414: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088418: BF870091
	v_fma_f32 v33, -v35, v66, v33                              // 00000008841C: D6130021 24868523
	v_fma_f32 v33, -v36, v67, v33                              // 000000088424: D6130021 24868724
	s_waitcnt lgkmcnt(8)                                       // 00000008842C: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088430: BF870091
	v_fma_f32 v33, -v60, v68, v33                              // 000000088434: D6130021 2486893C
	v_fma_f32 v33, -v61, v69, v33                              // 00000008843C: D6130021 24868B3D
	s_waitcnt lgkmcnt(2)                                       // 000000088444: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088448: BF870091
	v_fma_f32 v31, -v31, v74, v33                              // 00000008844C: D613001F 2486951F
	v_fma_f32 v31, -v32, v75, v31                              // 000000088454: D613001F 247E9720
	s_waitcnt lgkmcnt(1)                                       // 00000008845C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1)                            // 000000088460: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000088464: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:16 offset1:17      // 00000008846C: D8DC1110 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:18 offset1:19      // 000000088474: D8DC1312 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:20 offset1:21      // 00000008847C: D8DC1514 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:22 offset1:23      // 000000088484: D8DC1716 3C00002E
	ds_load_2addr_b32 v[64:65], v48 offset0:16 offset1:33      // 00000008848C: D8DC2110 40000030
	ds_load_2addr_b32 v[66:67], v48 offset0:50 offset1:67      // 000000088494: D8DC4332 42000030
	ds_load_2addr_b32 v[68:69], v48 offset0:84 offset1:101     // 00000008849C: D8DC6554 44000030
	ds_load_2addr_b32 v[74:75], v48 offset0:118 offset1:135    // 0000000884A4: D8DC8776 4A000030
	v_fma_f32 v62, -v63, v77, v62                              // 0000000884AC: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(8)                                       // 0000000884B4: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000884B8: BF870091
	v_fma_f32 v62, -v70, v78, v62                              // 0000000884BC: D613003E 24FA9D46
	v_fma_f32 v62, -v71, v79, v62                              // 0000000884C4: D613003E 24FA9F47
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000884CC: BF870091
	v_fma_f32 v62, -v72, v80, v62                              // 0000000884D0: D613003E 24FAA148
	v_fma_f32 v62, -v73, v81, v62                              // 0000000884D8: D613003E 24FAA349
	s_waitcnt lgkmcnt(3)                                       // 0000000884E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000884E4: BF870091
	v_fma_f32 v31, -v31, v64, v62                              // 0000000884E8: D613001F 24FA811F
	v_fma_f32 v31, -v32, v65, v31                              // 0000000884F0: D613001F 247E8320
	s_waitcnt lgkmcnt(2)                                       // 0000000884F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000884FC: BF870001
	v_fma_f32 v33, -v33, v66, v31                              // 000000088500: D6130021 247E8521
	ds_load_2addr_b32 v[31:32], v46 offset0:24 offset1:25      // 000000088508: D8DC1918 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:26 offset1:27      // 000000088510: D8DC1B1A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:28 offset1:29      // 000000088518: D8DC1D1C 4000002E
	ds_load_2addr_b32 v[70:71], v46 offset0:30 offset1:31      // 000000088520: D8DC1F1E 4600002E
	ds_load_2addr_b32 v[72:73], v48 offset0:152 offset1:169    // 000000088528: D8DCA998 48000030
	ds_load_2addr_b32 v[76:77], v48 offset0:186 offset1:203    // 000000088530: D8DCCBBA 4C000030
	ds_load_2addr_b32 v[78:79], v48 offset0:220 offset1:237    // 000000088538: D8DCEDDC 4E000030
	ds_load_2addr_b32 v[80:81], v49 offset0:126 offset1:143    // 000000088540: D8DC8F7E 50000031
	v_fma_f32 v33, -v34, v67, v33                              // 000000088548: D6130021 24868722
	s_waitcnt lgkmcnt(9)                                       // 000000088550: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088554: BF870091
	v_fma_f32 v33, -v35, v68, v33                              // 000000088558: D6130021 24868923
	v_fma_f32 v33, -v36, v69, v33                              // 000000088560: D6130021 24868B24
	s_waitcnt lgkmcnt(8)                                       // 000000088568: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008856C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000088570: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000088578: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000088580: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088584: BF870091
	v_fma_f32 v31, -v31, v72, v33                              // 000000088588: D613001F 2486911F
	v_fma_f32 v31, -v32, v73, v31                              // 000000088590: D613001F 247E9320
	s_waitcnt lgkmcnt(2)                                       // 000000088598: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008859C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000885A0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:32 offset1:33      // 0000000885A8: D8DC2120 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:34 offset1:35      // 0000000885B0: D8DC2322 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:36 offset1:37      // 0000000885B8: D8DC2524 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:38 offset1:39      // 0000000885C0: D8DC2726 3C00002E
	ds_load_2addr_b32 v[66:67], v50 offset0:32 offset1:49      // 0000000885C8: D8DC3120 42000032
	ds_load_2addr_b32 v[68:69], v50 offset0:66 offset1:83      // 0000000885D0: D8DC5342 44000032
	ds_load_2addr_b32 v[72:73], v50 offset0:100 offset1:117    // 0000000885D8: D8DC7564 48000032
	ds_load_2addr_b32 v[74:75], v50 offset0:134 offset1:151    // 0000000885E0: D8DC9786 4A000032
	v_fma_f32 v62, -v63, v77, v62                              // 0000000885E8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000885F0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000885F4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000885F8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000088600: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000088608: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008860C: BF870091
	v_fma_f32 v62, -v70, v80, v62                              // 000000088610: D613003E 24FAA146
	v_fma_f32 v62, -v71, v81, v62                              // 000000088618: D613003E 24FAA347
	s_waitcnt lgkmcnt(3)                                       // 000000088620: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088624: BF870091
	v_fma_f32 v31, -v31, v66, v62                              // 000000088628: D613001F 24FA851F
	v_fma_f32 v31, -v32, v67, v31                              // 000000088630: D613001F 247E8720
	s_waitcnt lgkmcnt(2)                                       // 000000088638: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008863C: BF870001
	v_fma_f32 v33, -v33, v68, v31                              // 000000088640: D6130021 247E8921
	ds_load_2addr_b32 v[31:32], v46 offset0:40 offset1:41      // 000000088648: D8DC2928 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:42 offset1:43      // 000000088650: D8DC2B2A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:44 offset1:45      // 000000088658: D8DC2D2C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:46 offset1:47      // 000000088660: D8DC2F2E 4200002E
	ds_load_2addr_b32 v[70:71], v50 offset0:168 offset1:185    // 000000088668: D8DCB9A8 46000032
	ds_load_2addr_b32 v[76:77], v50 offset0:202 offset1:219    // 000000088670: D8DCDBCA 4C000032
	ds_load_2addr_b32 v[78:79], v50 offset0:236 offset1:253    // 000000088678: D8DCFDEC 4E000032
	ds_load_2addr_b32 v[80:81], v51 offset0:14 offset1:31      // 000000088680: D8DC1F0E 50000033
	v_fma_f32 v33, -v34, v69, v33                              // 000000088688: D6130021 24868B22
	s_waitcnt lgkmcnt(9)                                       // 000000088690: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088694: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000088698: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000886A0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000886A8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000886AC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000886B0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000886B8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 0000000886C0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000886C4: BF870091
	v_fma_f32 v31, -v31, v70, v33                              // 0000000886C8: D613001F 24868D1F
	v_fma_f32 v31, -v32, v71, v31                              // 0000000886D0: D613001F 247E8F20
	s_waitcnt lgkmcnt(2)                                       // 0000000886D8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000886DC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 0000000886E0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:48 offset1:49      // 0000000886E8: D8DC3130 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:50 offset1:51      // 0000000886F0: D8DC3332 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:52 offset1:53      // 0000000886F8: D8DC3534 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:54 offset1:55      // 000000088700: D8DC3736 3C00002E
	ds_load_2addr_b32 v[68:69], v51 offset0:48 offset1:65      // 000000088708: D8DC4130 44000033
	ds_load_2addr_b32 v[70:71], v51 offset0:82 offset1:99      // 000000088710: D8DC6352 46000033
	ds_load_2addr_b32 v[72:73], v51 offset0:116 offset1:133    // 000000088718: D8DC8574 48000033
	ds_load_2addr_b32 v[74:75], v51 offset0:150 offset1:167    // 000000088720: D8DCA796 4A000033
	v_fma_f32 v62, -v63, v77, v62                              // 000000088728: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000088730: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088734: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000088738: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000088740: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000088748: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008874C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000088750: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000088758: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000088760: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088764: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000088768: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000088770: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000088778: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008877C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000088780: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:56 offset1:57      // 000000088788: D8DC3938 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:58 offset1:59      // 000000088790: D8DC3B3A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:60 offset1:61      // 000000088798: D8DC3D3C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:62 offset1:63      // 0000000887A0: D8DC3F3E 4200002E
	ds_load_2addr_b32 v[68:69], v51 offset0:184 offset1:201    // 0000000887A8: D8DCC9B8 44000033
	ds_load_2addr_b32 v[76:77], v51 offset0:218 offset1:235    // 0000000887B0: D8DCEBDA 4C000033
	ds_load_2addr_b32 v[78:79], v52 offset0:124 offset1:141    // 0000000887B8: D8DC8D7C 4E000034
	ds_load_2addr_b32 v[80:81], v53 offset0:30 offset1:47      // 0000000887C0: D8DC2F1E 50000035
	v_fma_f32 v33, -v34, v71, v33                              // 0000000887C8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 0000000887D0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000887D4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 0000000887D8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 0000000887E0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 0000000887E8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000887EC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 0000000887F0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 0000000887F8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000088800: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088804: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000088808: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000088810: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000088818: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008881C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000088820: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:64 offset1:65      // 000000088828: D8DC4140 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:66 offset1:67      // 000000088830: D8DC4342 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:68 offset1:69      // 000000088838: D8DC4544 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:70 offset1:71      // 000000088840: D8DC4746 3C00002E
	ds_load_2addr_b32 v[68:69], v53 offset0:64 offset1:81      // 000000088848: D8DC5140 44000035
	ds_load_2addr_b32 v[70:71], v53 offset0:98 offset1:115     // 000000088850: D8DC7362 46000035
	ds_load_2addr_b32 v[72:73], v53 offset0:132 offset1:149    // 000000088858: D8DC9584 48000035
	ds_load_2addr_b32 v[74:75], v53 offset0:166 offset1:183    // 000000088860: D8DCB7A6 4A000035
	v_fma_f32 v62, -v63, v77, v62                              // 000000088868: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000088870: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088874: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000088878: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000088880: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000088888: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008888C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000088890: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000088898: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000888A0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000888A4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000888A8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000888B0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000888B8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000888BC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 0000000888C0: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:72 offset1:73      // 0000000888C8: D8DC4948 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:74 offset1:75      // 0000000888D0: D8DC4B4A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:76 offset1:77      // 0000000888D8: D8DC4D4C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:78 offset1:79      // 0000000888E0: D8DC4F4E 4200002E
	ds_load_2addr_b32 v[68:69], v53 offset0:200 offset1:217    // 0000000888E8: D8DCD9C8 44000035
	ds_load_2addr_b32 v[76:77], v53 offset0:234 offset1:251    // 0000000888F0: D8DCFBEA 4C000035
	ds_load_2addr_b32 v[78:79], v54 offset0:12 offset1:29      // 0000000888F8: D8DC1D0C 4E000036
	ds_load_2addr_b32 v[80:81], v54 offset0:46 offset1:63      // 000000088900: D8DC3F2E 50000036
	v_fma_f32 v33, -v34, v71, v33                              // 000000088908: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000088910: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088914: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000088918: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 000000088920: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 000000088928: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008892C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000088930: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000088938: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000088940: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088944: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000088948: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000088950: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000088958: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008895C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000088960: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:80 offset1:81      // 000000088968: D8DC5150 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:82 offset1:83      // 000000088970: D8DC5352 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:84 offset1:85      // 000000088978: D8DC5554 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:86 offset1:87      // 000000088980: D8DC5756 3C00002E
	ds_load_2addr_b32 v[68:69], v54 offset0:80 offset1:97      // 000000088988: D8DC6150 44000036
	ds_load_2addr_b32 v[70:71], v54 offset0:114 offset1:131    // 000000088990: D8DC8372 46000036
	ds_load_2addr_b32 v[72:73], v54 offset0:148 offset1:165    // 000000088998: D8DCA594 48000036
	ds_load_2addr_b32 v[74:75], v54 offset0:182 offset1:199    // 0000000889A0: D8DCC7B6 4A000036
	v_fma_f32 v62, -v63, v77, v62                              // 0000000889A8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 0000000889B0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000889B4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 0000000889B8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 0000000889C0: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 0000000889C8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000889CC: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 0000000889D0: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 0000000889D8: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 0000000889E0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000889E4: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 0000000889E8: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 0000000889F0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 0000000889F8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000889FC: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000088A00: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:88 offset1:89      // 000000088A08: D8DC5958 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:90 offset1:91      // 000000088A10: D8DC5B5A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:92 offset1:93      // 000000088A18: D8DC5D5C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:94 offset1:95      // 000000088A20: D8DC5F5E 4200002E
	ds_load_2addr_b32 v[68:69], v54 offset0:216 offset1:233    // 000000088A28: D8DCE9D8 44000036
	ds_load_2addr_b32 v[76:77], v55 offset0:122 offset1:139    // 000000088A30: D8DC8B7A 4C000037
	ds_load_2addr_b32 v[78:79], v56 offset0:28 offset1:45      // 000000088A38: D8DC2D1C 4E000038
	ds_load_2addr_b32 v[80:81], v56 offset0:62 offset1:79      // 000000088A40: D8DC4F3E 50000038
	v_fma_f32 v33, -v34, v71, v33                              // 000000088A48: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000088A50: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088A54: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000088A58: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 000000088A60: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 000000088A68: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088A6C: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000088A70: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000088A78: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000088A80: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088A84: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000088A88: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000088A90: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000088A98: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000088A9C: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000088AA0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:96 offset1:97      // 000000088AA8: D8DC6160 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:98 offset1:99      // 000000088AB0: D8DC6362 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:100 offset1:101    // 000000088AB8: D8DC6564 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:102 offset1:103    // 000000088AC0: D8DC6766 3C00002E
	ds_load_2addr_b32 v[68:69], v56 offset0:96 offset1:113     // 000000088AC8: D8DC7160 44000038
	ds_load_2addr_b32 v[70:71], v56 offset0:130 offset1:147    // 000000088AD0: D8DC9382 46000038
	ds_load_2addr_b32 v[72:73], v56 offset0:164 offset1:181    // 000000088AD8: D8DCB5A4 48000038
	ds_load_2addr_b32 v[74:75], v56 offset0:198 offset1:215    // 000000088AE0: D8DCD7C6 4A000038
	v_fma_f32 v62, -v63, v77, v62                              // 000000088AE8: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000088AF0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088AF4: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000088AF8: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000088B00: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000088B08: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088B0C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000088B10: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000088B18: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000088B20: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088B24: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000088B28: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000088B30: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000088B38: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000088B3C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000088B40: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:104 offset1:105    // 000000088B48: D8DC6968 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:106 offset1:107    // 000000088B50: D8DC6B6A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:108 offset1:109    // 000000088B58: D8DC6D6C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:110 offset1:111    // 000000088B60: D8DC6F6E 4200002E
	ds_load_2addr_b32 v[68:69], v56 offset0:232 offset1:249    // 000000088B68: D8DCF9E8 44000038
	ds_load_2addr_b32 v[76:77], v57 offset0:10 offset1:27      // 000000088B70: D8DC1B0A 4C000039
	ds_load_2addr_b32 v[78:79], v57 offset0:44 offset1:61      // 000000088B78: D8DC3D2C 4E000039
	ds_load_2addr_b32 v[80:81], v57 offset0:78 offset1:95      // 000000088B80: D8DC5F4E 50000039
	v_fma_f32 v33, -v34, v71, v33                              // 000000088B88: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000088B90: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088B94: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000088B98: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 000000088BA0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 000000088BA8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088BAC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000088BB0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000088BB8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000088BC0: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088BC4: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000088BC8: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000088BD0: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000088BD8: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000088BDC: BF870001
	v_fma_f32 v62, -v62, v76, v31                              // 000000088BE0: D613003E 247E993E
	ds_load_2addr_b32 v[31:32], v46 offset0:112 offset1:113    // 000000088BE8: D8DC7170 1F00002E
	ds_load_2addr_b32 v[33:34], v46 offset0:114 offset1:115    // 000000088BF0: D8DC7372 2100002E
	ds_load_2addr_b32 v[35:36], v46 offset0:116 offset1:117    // 000000088BF8: D8DC7574 2300002E
	ds_load_2addr_b32 v[60:61], v46 offset0:118 offset1:119    // 000000088C00: D8DC7776 3C00002E
	ds_load_2addr_b32 v[68:69], v57 offset0:112 offset1:129    // 000000088C08: D8DC8170 44000039
	ds_load_2addr_b32 v[70:71], v57 offset0:146 offset1:163    // 000000088C10: D8DCA392 46000039
	ds_load_2addr_b32 v[72:73], v57 offset0:180 offset1:197    // 000000088C18: D8DCC5B4 48000039
	ds_load_2addr_b32 v[74:75], v57 offset0:214 offset1:231    // 000000088C20: D8DCE7D6 4A000039
	v_fma_f32 v62, -v63, v77, v62                              // 000000088C28: D613003E 24FA9B3F
	s_waitcnt lgkmcnt(9)                                       // 000000088C30: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088C34: BF870091
	v_fma_f32 v62, -v64, v78, v62                              // 000000088C38: D613003E 24FA9D40
	v_fma_f32 v62, -v65, v79, v62                              // 000000088C40: D613003E 24FA9F41
	s_waitcnt lgkmcnt(8)                                       // 000000088C48: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088C4C: BF870091
	v_fma_f32 v62, -v66, v80, v62                              // 000000088C50: D613003E 24FAA142
	v_fma_f32 v62, -v67, v81, v62                              // 000000088C58: D613003E 24FAA343
	s_waitcnt lgkmcnt(3)                                       // 000000088C60: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088C64: BF870091
	v_fma_f32 v31, -v31, v68, v62                              // 000000088C68: D613001F 24FA891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000088C70: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000088C78: BF89FC27
	s_delay_alu instid0(VALU_DEP_1)                            // 000000088C7C: BF870001
	v_fma_f32 v33, -v33, v70, v31                              // 000000088C80: D6130021 247E8D21
	ds_load_2addr_b32 v[31:32], v46 offset0:120 offset1:121    // 000000088C88: D8DC7978 1F00002E
	ds_load_2addr_b32 v[62:63], v46 offset0:122 offset1:123    // 000000088C90: D8DC7B7A 3E00002E
	ds_load_2addr_b32 v[64:65], v46 offset0:124 offset1:125    // 000000088C98: D8DC7D7C 4000002E
	ds_load_2addr_b32 v[66:67], v46 offset0:126 offset1:127    // 000000088CA0: D8DC7F7E 4200002E
	ds_load_2addr_b32 v[68:69], v58 offset0:120 offset1:137    // 000000088CA8: D8DC8978 4400003A
	ds_load_2addr_b32 v[76:77], v59 offset0:26 offset1:43      // 000000088CB0: D8DC2B1A 4C00003B
	ds_load_2addr_b32 v[78:79], v59 offset0:60 offset1:77      // 000000088CB8: D8DC4D3C 4E00003B
	ds_load_2addr_b32 v[80:81], v59 offset0:94 offset1:111     // 000000088CC0: D8DC6F5E 5000003B
	v_fma_f32 v33, -v34, v71, v33                              // 000000088CC8: D6130021 24868F22
	s_waitcnt lgkmcnt(9)                                       // 000000088CD0: BF89FC97
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088CD4: BF870091
	v_fma_f32 v33, -v35, v72, v33                              // 000000088CD8: D6130021 24869123
	v_fma_f32 v33, -v36, v73, v33                              // 000000088CE0: D6130021 24869324
	s_waitcnt lgkmcnt(8)                                       // 000000088CE8: BF89FC87
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088CEC: BF870091
	v_fma_f32 v33, -v60, v74, v33                              // 000000088CF0: D6130021 2486953C
	v_fma_f32 v33, -v61, v75, v33                              // 000000088CF8: D6130021 2486973D
	s_waitcnt lgkmcnt(3)                                       // 000000088D00: BF89FC37
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088D04: BF870091
	v_fma_f32 v31, -v31, v68, v33                              // 000000088D08: D613001F 2486891F
	v_fma_f32 v31, -v32, v69, v31                              // 000000088D10: D613001F 247E8B20
	s_waitcnt lgkmcnt(2)                                       // 000000088D18: BF89FC27
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088D1C: BF870091
	v_fma_f32 v31, -v62, v76, v31                              // 000000088D20: D613001F 247E993E
	v_fma_f32 v31, -v63, v77, v31                              // 000000088D28: D613001F 247E9B3F
	s_waitcnt lgkmcnt(1)                                       // 000000088D30: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088D34: BF870091
	v_fma_f32 v31, -v64, v78, v31                              // 000000088D38: D613001F 247E9D40
	v_fma_f32 v31, -v65, v79, v31                              // 000000088D40: D613001F 247E9F41
	s_waitcnt lgkmcnt(0)                                       // 000000088D48: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000088D4C: BF870121
	v_fma_f32 v33, -v66, v80, v31                              // 000000088D50: D6130021 247EA142
	v_mad_u64_u32 v[31:32], null, 0x44, s5, v[4:5]             // 000000088D58: D6FE7C1F 04100AFF 00000044
	v_fma_f32 v32, -v67, v81, v33                              // 000000088D64: D6130020 2486A343
	ds_store_b32 v31, v32                                      // 000000088D6C: D8340000 0000201F
	s_branch 64815                                             // 000000088D74: BFA0FD2F <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x534>
	v_mov_b32_e32 v30, v14                                     // 000000088D78: 7E3C030E
	v_dual_mov_b32 v32, v10 :: v_dual_mov_b32 v29, v13         // 000000088D7C: CA10010A 201C010D
	v_mov_b32_e32 v31, v9                                      // 000000088D84: 7E3E0309
	v_mov_b32_e32 v35, v43                                     // 000000088D88: 7E46032B
	s_mov_b32 s16, 0                                           // 000000088D8C: BE900080
	s_branch 21                                                // 000000088D90: BFA00015 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x10e8>
	s_or_b32 exec_lo, exec_lo, s17                             // 000000088D94: 8C7E117E
	.long 0xd700011f                                           // 000000088D98: D700011F
	v_cndmask_b32_e32 v1, 0x30000, v31, vcc_lo                 // 000000088D9C: 02023EFF 00030000
	s_delay_alu instid0(VALU_DEP_1)                            // 000000088DA4: BF870001
	v_add_co_ci_u32_e64 v32, null, 0, v32, s1                  // 000000088DA8: D5207C20 00064080
	.long 0xd700011d                                           // 000000088DB0: D700011D
	v_cndmask_b32_e32 v1, 0x800, v29, vcc_lo                   // 000000088DB4: 02023AFF 00000800
	v_add_nc_u32_e32 v35, 8, v35                               // 000000088DBC: 4A464688
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000088DC0: D5207C1E 00063C80
	s_add_i32 s1, s16, 8                                       // 000000088DC8: 81018810
	s_cmp_gt_u32 s16, 55                                       // 000000088DCC: BF08B710
	s_mov_b32 s16, s1                                          // 000000088DD0: BE900001
	s_waitcnt_vscnt null, 0x0                                  // 000000088DD4: BC7C0000
	s_barrier                                                  // 000000088DD8: BFBD0000
	buffer_gl0_inv                                             // 000000088DDC: E0AC0000 00000000
	s_cbranch_scc1 310                                         // 000000088DE4: BFA20136 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x15c0>
	s_delay_alu instid0(VALU_DEP_2)                            // 000000088DE8: BF870002
	v_dual_mov_b32 v34, v32 :: v_dual_mov_b32 v33, v31         // 000000088DEC: CA100120 2220011F
	v_mov_b32_e32 v36, v40                                     // 000000088DF4: 7E480328
	v_mov_b32_e32 v60, v38                                     // 000000088DF8: 7E780326
	s_mov_b32 s5, 0                                            // 000000088DFC: BE850080
	global_load_b32 v61, v[33:34], off                         // 000000088E00: DC520000 3D7C0021
	v_add_nc_u32_e32 v60, 0x80, v60                            // 000000088E08: 4A7878FF 00000080
	.long 0xd7000121                                           // 000000088E10: D7000121
	v_cndmask_b32_e32 v1, 0x6000, v33, vcc_lo                  // 000000088E14: 020242FF 00006000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 000000088E1C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 000000088E20: D5207C22 00064480
	.long 0xd4490004                                           // 000000088E28: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v60, vcc_lo                   // 000000088E2C: 020278FF 0000037F
	s_or_b32 s5, s4, s5                                        // 000000088E34: 8C050504
	s_waitcnt vmcnt(0)                                         // 000000088E38: BF8903F7
	ds_store_b32 v36, v61 offset:13056                         // 000000088E3C: D8343300 00003D24
	v_add_nc_u32_e32 v36, 0x204, v36                           // 000000088E44: 4A4848FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000088E4C: 917E057E
	s_cbranch_execnz 65515                                     // 000000088E50: BFA6FFEB <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1100>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000088E54: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 000000088E58: BF89FC07
	s_barrier                                                  // 000000088E5C: BFBD0000
	buffer_gl0_inv                                             // 000000088E60: E0AC0000 00000000
	s_and_saveexec_b32 s17, s0                                 // 000000088E68: BE912000
	s_cbranch_execz 65481                                      // 000000088E6C: BFA5FFC9 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_or_b32_e32 v33, s16, v2                                  // 000000088E70: 38420410
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000088E74: BF870091
	v_or_b32_e32 v36, s15, v33                                 // 000000088E78: 3848420F
	.long 0xd4440001                                           // 000000088E7C: D4440001
	v_cndmask_b32_e32 v1, s33, v36, vcc_lo                     // 000000088E80: 02024821
	s_and_b32 exec_lo, exec_lo, s1                             // 000000088E84: 8B7E017E
	s_cbranch_execz 65474                                      // 000000088E88: BFA5FFC2 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	v_mov_b32_e32 v60, 0                                       // 000000088E8C: 7E780280
	s_mov_b32 s18, 0                                           // 000000088E90: BE920080
	s_delay_alu instid0(SALU_CYCLE_1)                          // 000000088E94: BF870009
	v_lshl_add_u32 v34, s18, 2, v46                            // 000000088E98: D6460022 04B90412
	ds_load_2addr_b32 v[76:77], v34 offset1:1                  // 000000088EA0: D8DC0100 4C000022
	ds_load_2addr_b32 v[78:79], v34 offset0:2 offset1:3        // 000000088EA8: D8DC0302 4E000022
	ds_load_2addr_b32 v[80:81], v34 offset0:4 offset1:5        // 000000088EB0: D8DC0504 50000022
	ds_load_2addr_b32 v[82:83], v34 offset0:6 offset1:7        // 000000088EB8: D8DC0706 52000022
	v_mad_u64_u32 v[61:62], null, 0x44, s18, v[1:2]            // 000000088EC0: D6FE7C3D 040424FF 00000044
	ds_load_2addr_b32 v[68:69], v61 offset1:17                 // 000000088ECC: D8DC1100 4400003D
	ds_load_2addr_b32 v[70:71], v61 offset0:34 offset1:51      // 000000088ED4: D8DC3322 4600003D
	ds_load_2addr_b32 v[72:73], v61 offset0:68 offset1:85      // 000000088EDC: D8DC5544 4800003D
	ds_load_2addr_b32 v[74:75], v61 offset0:102 offset1:119    // 000000088EE4: D8DC7766 4A00003D
	s_waitcnt lgkmcnt(7)                                       // 000000088EEC: BF89FC77
	v_cvt_f16_f32_e32 v64, v76                                 // 000000088EF0: 7E80154C
	.long 0xd4130229                                           // 000000088EF4: D4130229
	v_cndmask_b32_e32 v1, 0x38800006, v76, vcc_lo              // 000000088EF8: 020298FF 38800006
	.long 0xd416022a                                           // 000000088F00: D416022A
	v_cndmask_b32_e32 v1, 0x477fe000, v76, vcc_lo              // 000000088F04: 020298FF 477FE000
	.long 0x7f80154d                                           // 000000088F0C: 7F80154D
	.long 0xd413022b                                           // 000000088F10: D413022B
	v_cndmask_b32_e32 v1, 0x38800006, v77, vcc_lo              // 000000088F14: 02029AFF 38800006
	v_cvt_f32_f16_e32 v88, v64                                 // 000000088F1C: 7EB01740
	.long 0xd416022c                                           // 000000088F20: D416022C
	v_cndmask_b32_e32 v1, 0x477fe000, v77, vcc_lo              // 000000088F24: 02029AFF 477FE000
	s_waitcnt lgkmcnt(6)                                       // 000000088F2C: BF89FC67
	v_cvt_f16_f32_e32 v65, v78                                 // 000000088F30: 7E82154E
	v_cvt_f32_f16_e32 v64, v192/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000088F34: 7E8017C0
	.long 0xd413022d                                           // 000000088F38: D413022D
	v_cndmask_b32_e32 v1, 0x38800006, v78, vcc_lo              // 000000088F3C: 02029CFF 38800006
	.long 0xd416022e                                           // 000000088F44: D416022E
	v_cndmask_b32_e32 v1, 0x477fe000, v78, vcc_lo              // 000000088F48: 02029CFF 477FE000
	.long 0x7f82154f                                           // 000000088F50: 7F82154F
	s_waitcnt lgkmcnt(3)                                       // 000000088F54: BF89FC37
	v_cvt_f16_f32_e32 v34, v68                                 // 000000088F58: 7E441544
	.long 0xd4130201                                           // 000000088F5C: D4130201
	v_cndmask_b32_e32 v1, 0x38800006, v68, vcc_lo              // 000000088F60: 020288FF 38800006
	.long 0xd4160204                                           // 000000088F68: D4160204
	v_cndmask_b32_e32 v1, 0x477fe000, v68, vcc_lo              // 000000088F6C: 020288FF 477FE000
	.long 0xd4130205                                           // 000000088F74: D4130205
	v_cndmask_b32_e32 v1, 0x38800006, v69, vcc_lo              // 000000088F78: 02028AFF 38800006
	.long 0xd4160206                                           // 000000088F80: D4160206
	v_cndmask_b32_e32 v1, 0x477fe000, v69, vcc_lo              // 000000088F84: 02028AFF 477FE000
	s_waitcnt lgkmcnt(2)                                       // 000000088F8C: BF89FC27
	.long 0xd4130209                                           // 000000088F90: D4130209
	v_cndmask_b32_e32 v1, 0x38800006, v71, vcc_lo              // 000000088F94: 02028EFF 38800006
	.long 0xd416020a                                           // 000000088F9C: D416020A
	v_cndmask_b32_e32 v1, 0x477fe000, v71, vcc_lo              // 000000088FA0: 02028EFF 477FE000
	.long 0x7f441545                                           // 000000088FA8: 7F441545
	v_cvt_f32_f16_e32 v84, v34                                 // 000000088FAC: 7EA81722
	s_and_b32 s1, s1, s4                                       // 000000088FB0: 8B010401
	s_and_b32 s4, s5, s6                                       // 000000088FB4: 8B040605
	s_and_b32 s6, s9, s10                                      // 000000088FB8: 8B060A09
	s_and_b32 s10, s41, s42                                    // 000000088FBC: 8B0A2A29
	v_cvt_f16_f32_e32 v61, v70                                 // 000000088FC0: 7E7A1546
	v_cvt_f32_f16_e32 v34, v162/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000088FC4: 7E4417A2
	v_cndmask_b32_e64 v68, v68, v84, s1                        // 000000088FC8: D5010044 0006A944
	v_cndmask_b32_e64 v76, v76, v88, s10                       // 000000088FD0: D501004C 002AB14C
	.long 0xd4130207                                           // 000000088FD8: D4130207
	v_cndmask_b32_e32 v1, 0x38800006, v70, vcc_lo              // 000000088FDC: 02028CFF 38800006
	.long 0xd4160208                                           // 000000088FE4: D4160208
	v_cndmask_b32_e32 v1, 0x477fe000, v70, vcc_lo              // 000000088FE8: 02028CFF 477FE000
	s_and_b32 s1, s43, s44                                     // 000000088FF0: 8B012C2B
	.long 0x7f7a1547                                           // 000000088FF4: 7F7A1547
	v_cvt_f32_f16_e32 v85, v61                                 // 000000088FF8: 7EAA173D
	v_cvt_f32_f16_e32 v84, v65                                 // 000000088FFC: 7EA81741
	v_cndmask_b32_e64 v34, v69, v34, s4                        // 000000089000: D5010022 00124545
	v_cndmask_b32_e64 v64, v77, v64, s1                        // 000000089008: D5010040 0006814D
	v_fmac_f32_e32 v60, v76, v68                               // 000000089010: 5678894C
	.long 0xd413022f                                           // 000000089014: D413022F
	v_cndmask_b32_e32 v1, 0x38800006, v79, vcc_lo              // 000000089018: 02029EFF 38800006
	.long 0xd4160230                                           // 000000089020: D4160230
	v_cndmask_b32_e32 v1, 0x477fe000, v79, vcc_lo              // 000000089024: 02029EFF 477FE000
	s_and_b32 s5, s7, s8                                       // 00000008902C: 8B050807
	s_and_b32 s1, s45, s46                                     // 000000089030: 8B012E2D
	s_waitcnt lgkmcnt(1)                                       // 000000089034: BF89FC17
	v_cvt_f16_f32_e32 v62, v72                                 // 000000089038: 7E7C1548
	v_cvt_f16_f32_e32 v66, v80                                 // 00000008903C: 7E841550
	v_cvt_f32_f16_e32 v61, v189/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000089040: 7E7A17BD
	v_cvt_f32_f16_e32 v65, v193/*Invalid register, operand has 'VS_32_Lo128' register class*/// 000000089044: 7E8217C1
	v_cndmask_b32_e64 v68, v70, v85, s5                        // 000000089048: D5010044 0016AB46
	v_cndmask_b32_e64 v69, v78, v84, s1                        // 000000089050: D5010045 0006A94E
	v_fmac_f32_e32 v60, v64, v34                               // 000000089058: 56784540
	.long 0xd4130213                                           // 00000008905C: D4130213
	v_cndmask_b32_e32 v1, 0x38800006, v72, vcc_lo              // 000000089060: 020290FF 38800006
	.long 0xd416021c                                           // 000000089068: D416021C
	v_cndmask_b32_e32 v1, 0x477fe000, v72, vcc_lo              // 00000008906C: 020290FF 477FE000
	.long 0xd4130231                                           // 000000089074: D4130231
	v_cndmask_b32_e32 v1, 0x38800006, v80, vcc_lo              // 000000089078: 0202A0FF 38800006
	.long 0xd4160232                                           // 000000089080: D4160232
	v_cndmask_b32_e32 v1, 0x477fe000, v80, vcc_lo              // 000000089084: 0202A0FF 477FE000
	s_and_b32 s1, s47, s48                                     // 00000008908C: 8B01302F
	.long 0x7f7c1549                                           // 000000089090: 7F7C1549
	.long 0x7f841551                                           // 000000089094: 7F841551
	v_cvt_f32_f16_e32 v86, v62                                 // 000000089098: 7EAC173E
	v_cvt_f32_f16_e32 v34, v66                                 // 00000008909C: 7E441742
	v_cndmask_b32_e64 v61, v71, v61, s6                        // 0000000890A0: D501003D 001A7B47
	v_cndmask_b32_e64 v64, v79, v65, s1                        // 0000000890A8: D5010040 0006834F
	v_fmac_f32_e32 v60, v69, v68                               // 0000000890B0: 56788945
	.long 0xd413021d                                           // 0000000890B4: D413021D
	v_cndmask_b32_e32 v1, 0x38800006, v73, vcc_lo              // 0000000890B8: 020292FF 38800006
	.long 0xd4160224                                           // 0000000890C0: D4160224
	v_cndmask_b32_e32 v1, 0x477fe000, v73, vcc_lo              // 0000000890C4: 020292FF 477FE000
	.long 0xd4130233                                           // 0000000890CC: D4130233
	v_cndmask_b32_e32 v1, 0x38800006, v81, vcc_lo              // 0000000890D0: 0202A2FF 38800006
	.long 0xd4160234                                           // 0000000890D8: D4160234
	v_cndmask_b32_e32 v1, 0x477fe000, v81, vcc_lo              // 0000000890DC: 0202A2FF 477FE000
	s_and_b32 s7, s19, s28                                     // 0000000890E4: 8B071C13
	s_and_b32 s1, s49, s50                                     // 0000000890E8: 8B013231
	s_waitcnt lgkmcnt(0)                                       // 0000000890EC: BF89FC07
	v_cvt_f16_f32_e32 v63, v74                                 // 0000000890F0: 7E7E154A
	v_cvt_f16_f32_e32 v67, v82                                 // 0000000890F4: 7E861552
	v_cvt_f32_f16_e32 v62, v190/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000000890F8: 7E7C17BE
	v_cvt_f32_f16_e32 v65, v194/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000000890FC: 7E8217C2
	v_cndmask_b32_e64 v66, v72, v86, s7                        // 000000089100: D5010042 001EAD48
	v_cndmask_b32_e64 v34, v80, v34, s1                        // 000000089108: D5010022 00064550
	v_fmac_f32_e32 v60, v64, v61                               // 000000089110: 56787B40
	.long 0xd4130225                                           // 000000089114: D4130225
	v_cndmask_b32_e32 v1, 0x38800006, v74, vcc_lo              // 000000089118: 020294FF 38800006
	.long 0xd4160226                                           // 000000089120: D4160226
	v_cndmask_b32_e32 v1, 0x477fe000, v74, vcc_lo              // 000000089124: 020294FF 477FE000
	.long 0xd4130235                                           // 00000008912C: D4130235
	v_cndmask_b32_e32 v1, 0x38800006, v82, vcc_lo              // 000000089130: 0202A4FF 38800006
	.long 0xd4160236                                           // 000000089138: D4160236
	v_cndmask_b32_e32 v1, 0x477fe000, v82, vcc_lo              // 00000008913C: 0202A4FF 477FE000
	s_and_b32 s8, s29, s36                                     // 000000089144: 8B08241D
	s_and_b32 s1, s51, s52                                     // 000000089148: 8B013433
	.long 0x7f7e154b                                           // 00000008914C: 7F7E154B
	.long 0x7f861553                                           // 000000089150: 7F861553
	v_cvt_f32_f16_e32 v87, v63                                 // 000000089154: 7EAE173F
	v_cvt_f32_f16_e32 v61, v67                                 // 000000089158: 7E7A1743
	v_cndmask_b32_e64 v62, v73, v62, s8                        // 00000008915C: D501003E 00227D49
	v_cndmask_b32_e64 v64, v81, v65, s1                        // 000000089164: D5010040 00068351
	v_fmac_f32_e32 v60, v34, v66                               // 00000008916C: 56788522
	.long 0xd4130227                                           // 000000089170: D4130227
	v_cndmask_b32_e32 v1, 0x38800006, v75, vcc_lo              // 000000089174: 020296FF 38800006
	.long 0xd4160228                                           // 00000008917C: D4160228
	v_cndmask_b32_e32 v1, 0x477fe000, v75, vcc_lo              // 000000089180: 020296FF 477FE000
	.long 0xd4130237                                           // 000000089188: D4130237
	v_cndmask_b32_e32 v1, 0x38800006, v83, vcc_lo              // 00000008918C: 0202A6FF 38800006
	.long 0xd4160238                                           // 000000089194: D4160238
	v_cndmask_b32_e32 v1, 0x477fe000, v83, vcc_lo              // 000000089198: 0202A6FF 477FE000
	s_and_b32 s9, s37, s38                                     // 0000000891A0: 8B092625
	s_and_b32 s1, s53, s54                                     // 0000000891A4: 8B013635
	v_cvt_f32_f16_e32 v63, v191/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000000891A8: 7E7E17BF
	v_cvt_f32_f16_e32 v34, v195/*Invalid register, operand has 'VS_32_Lo128' register class*/// 0000000891AC: 7E4417C3
	v_cndmask_b32_e64 v65, v74, v87, s9                        // 0000000891B0: D5010041 0026AF4A
	v_cndmask_b32_e64 v61, v82, v61, s1                        // 0000000891B8: D501003D 00067B52
	v_fmac_f32_e32 v60, v64, v62                               // 0000000891C0: 56787D40
	s_and_b32 s1, s39, s40                                     // 0000000891C4: 8B012827
	s_and_b32 s4, s55, s56                                     // 0000000891C8: 8B043837
	v_cndmask_b32_e64 v62, v75, v63, s1                        // 0000000891CC: D501003E 00067F4B
	v_cndmask_b32_e64 v34, v83, v34, s4                        // 0000000891D4: D5010022 00124553
	v_fmac_f32_e32 v60, v61, v65                               // 0000000891DC: 5678833D
	s_add_i32 s1, s18, 8                                       // 0000000891E0: 81018812
	s_cmpk_lt_u32 s18, 0x78                                    // 0000000891E4: B6920078
	s_mov_b32 s18, s1                                          // 0000000891E8: BE920001
	s_delay_alu instid0(VALU_DEP_1)                            // 0000000891EC: BF870001
	v_fmac_f32_e32 v60, v34, v62                               // 0000000891F0: 56787D22
	s_cbranch_scc1 65319                                       // 0000000891F4: BFA2FF27 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1194>
	v_lshlrev_b32_e32 v33, 2, v33                              // 0000000891F8: 30424282
	v_mov_b32_e32 v61, v1                                      // 0000000891FC: 7E7A0301
	s_mov_b32 s5, 0                                            // 000000089200: BE850080
	ds_load_b32 v62, v33 offset:17440                          // 000000089204: D8D84420 3E000021
	v_dual_mov_b32 v34, v30 :: v_dual_mov_b32 v33, v29         // 00000008920C: CA10011E 2220011D
	s_waitcnt lgkmcnt(0)                                       // 000000089214: BF89FC07
	v_mul_f32_e32 v60, v60, v62                                // 000000089218: 10787D3C
	v_mov_b32_e32 v62, v35                                     // 00000008921C: 7E7C0323
	s_nop 0                                                    // 000000089220: BF800000
	s_nop 0                                                    // 000000089224: BF800000
	s_nop 0                                                    // 000000089228: BF800000
	s_nop 0                                                    // 00000008922C: BF800000
	s_nop 0                                                    // 000000089230: BF800000
	s_nop 0                                                    // 000000089234: BF800000
	s_nop 0                                                    // 000000089238: BF800000
	s_nop 0                                                    // 00000008923C: BF800000
	global_load_b32 v63, v[33:34], off                         // 000000089240: DC520000 3F7C0021
	ds_load_b32 v64, v61 offset:8704                           // 000000089248: D8D82200 4000003D
	v_add_nc_u32_e32 v62, -1, v62                              // 000000089250: 4A7C7CC1
	.long 0xd7000121                                           // 000000089254: D7000121
	v_cndmask_b32_e32 v0, v33, v132, vcc_lo                    // 000000089258: 02010921
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000008925C: BF870191
	v_add_co_ci_u32_e64 v34, null, 0, v34, s1                  // 000000089260: D5207C22 00064480
	.long 0xd44a0004                                           // 000000089268: D44A0004
	v_cndmask_b32_e32 v1, 0, v62, vcc_lo                       // 00000008926C: 02027C80
	v_add_nc_u32_e32 v61, 0x44, v61                            // 000000089270: 4A7A7AFF 00000044
	s_or_b32 s5, s4, s5                                        // 000000089278: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000008927C: BF890007
	v_fmac_f32_e32 v60, v63, v64                               // 000000089280: 5678813F
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000089284: 917E057E
	s_cbranch_execnz 65517                                     // 000000089288: BFA6FFED <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1540>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000008928C: 8C7E057E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000089290: BF870121
	v_bfe_u32 v61, v60, 16, 1                                  // 000000089294: D610003D 0205213C
	v_mad_u64_u32 v[33:34], null, 0x3000, v36, v[5:6]          // 00000008929C: D6FE7C21 041648FF 00003000
	v_add3_u32 v36, v60, v61, 0x7fff                           // 0000000892A8: D6550024 03FE7B3C 00007FFF
	global_store_d16_hi_b16 v[33:34], v36, off                 // 0000000892B4: DC960000 007C2421
	s_branch 65205                                             // 0000000892BC: BFA0FEB5 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1094>
	s_mul_f32 s1, s14, 0x3fb8aa3b                              // 0000000892C0: A201FF0E 3FB8AA3B
	v_mov_b32_e32 v31, v38                                     // 0000000892C8: 7E3E0326
	s_delay_alu instid0(SALU_CYCLE_2) | instskip(SKIP_3) | instid1(SALU_CYCLE_1)// 0000000892CC: BF8704CA
	s_xor_b32 s4, s1, 0x80000000                               // 0000000892D0: 8D04FF01 80000000
	s_rndne_f32 s5, s1                                         // 0000000892D8: BE856301
	s_fmamk_f32 s4, s14, 0x3fb8aa3b, s4                        // 0000000892DC: A304040E 3FB8AA3B
	s_cmp_nlt_f32 s14, 0xc2ce8ed0                              // 0000000892E4: BF4EFF0E C2CE8ED0
	s_sub_f32 s1, s1, s5                                       // 0000000892EC: A0810501
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_3)// 0000000892F0: BF870599
	s_fmamk_f32 s4, s14, 0x32a5705f, s4                        // 0000000892F4: A304040E 32A5705F
	s_add_f32 s1, s1, s4                                       // 0000000892FC: A0010401
	s_mov_b32 s4, 0                                            // 000000089300: BE840080
	s_delay_alu instid0(SALU_CYCLE_2)                          // 000000089304: BF87000A
	v_exp_f32_e32 v29, s1                                      // 000000089308: 7E3A4A01
	s_cvt_i32_f32 s1, s5                                       // 00000008930C: BE816605
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(SALU_CYCLE_3) // 000000089310: BF870585
	.long 0xd71c001d                                           // 000000089314: D71C001D
	v_cndmask_b32_e32 v0, v29, v1, vcc_lo                      // 000000089318: 0200031D
	s_cselect_b32 s1, -1, 0                                    // 00000008931C: 980180C1
	s_cmp_ngt_f32 s14, 0x42b17218                              // 000000089320: BF4BFF0E 42B17218
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 000000089328: BF870131
	v_cndmask_b32_e64 v30, 0, v29, s1                          // 00000008932C: D501001E 00063A80
	s_cselect_b32 s1, -1, 0                                    // 000000089334: 980180C1
	v_mov_b32_e32 v29, v37                                     // 000000089338: 7E3A0325
	v_cndmask_b32_e64 v30, 0x7f800000, v30, s1                 // 00000008933C: D501001E 00063CFF 7F800000
	ds_load_b32 v32, v29                                       // 000000089348: D8D80000 2000001D
	v_add_nc_u32_e32 v31, 0x80, v31                            // 000000089350: 4A3E3EFF 00000080
	s_delay_alu instid0(VALU_DEP_1)                            // 000000089358: BF870001
	.long 0xd4490001                                           // 00000008935C: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v31, vcc_lo                   // 000000089360: 02023EFF 0000077F
	s_or_b32 s4, s1, s4                                        // 000000089368: 8C040401
	s_waitcnt lgkmcnt(0)                                       // 00000008936C: BF89FC07
	v_mul_f32_e32 v32, v30, v32                                // 000000089370: 1040411E
	ds_store_b32 v29, v32                                      // 000000089374: D8340000 0000201D
	v_add_nc_u32_e32 v29, 0x220, v29                           // 00000008937C: 4A3A3AFF 00000220
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000089384: 917E047E
	s_cbranch_execnz 65519                                     // 000000089388: BFA6FFEF <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1648>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008938C: 8C7E047E
	v_dual_mov_b32 v30, v12 :: v_dual_mov_b32 v29, v11         // 000000089390: CA10010C 1E1C010B
	v_dual_mov_b32 v31, 0 :: v_dual_mov_b32 v32, v40           // 000000089398: CA100080 1F200128
	v_mov_b32_e32 v33, v38                                     // 0000000893A0: 7E420326
	s_mov_b32 s5, 0                                            // 0000000893A4: BE850080
	s_waitcnt lgkmcnt(0)                                       // 0000000893A8: BF89FC07
	s_barrier                                                  // 0000000893AC: BFBD0000
	buffer_gl0_inv                                             // 0000000893B0: E0AC0000 00000000
	s_nop 0                                                    // 0000000893B8: BF800000
	s_nop 0                                                    // 0000000893BC: BF800000
	global_load_b32 v34, v[29:30], off                         // 0000000893C0: DC520000 227C001D
	ds_load_b32 v35, v31 offset:17184                          // 0000000893C8: D8D84320 2300001F
	v_add_nc_u32_e32 v33, 0x80, v33                            // 0000000893D0: 4A4242FF 00000080
	.long 0xd700011d                                           // 0000000893D8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 0000000893DC: 02023AFF 00006000
	v_add_nc_u32_e32 v31, 4, v31                               // 0000000893E4: 4A3E3E84
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000893E8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000893F0: BF870004
	.long 0xd4490004                                           // 0000000893F4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000893F8: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 000000089400: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000089404: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000089408: 10444722
	ds_store_b32 v32, v34 offset:13056                         // 00000008940C: D8343300 00002220
	v_add_nc_u32_e32 v32, 0x204, v32                           // 000000089414: 4A4040FF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000008941C: 917E057E
	s_cbranch_execnz 65511                                     // 000000089420: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x16c0>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000089424: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 000000089428: BF89FC07
	s_barrier                                                  // 00000008942C: BFBD0000
	buffer_gl0_inv                                             // 000000089430: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset1:17                 // 000000089438: D8DC1100 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:34 offset1:51      // 000000089440: D8DC3322 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:68 offset1:85      // 000000089448: D8DC5544 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:102 offset1:119    // 000000089450: D8DC7766 2300002F
	v_mov_b32_e32 v60, v0                                      // 000000089458: 7E780300
	s_mov_b32 s4, 0                                            // 00000008945C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000089460: BF840001
	s_nop 0                                                    // 000000089464: BF800000
	s_nop 0                                                    // 000000089468: BF800000
	s_nop 0                                                    // 00000008946C: BF800000
	s_nop 0                                                    // 000000089470: BF800000
	s_nop 0                                                    // 000000089474: BF800000
	s_nop 0                                                    // 000000089478: BF800000
	s_nop 0                                                    // 00000008947C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000089480: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000089484: 327A7884
	.long 0xd4490001                                           // 000000089488: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000008948C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000089494: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000089498: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000894A4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000894A8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000894B0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000894B8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 0000000894C0: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 0000000894C8: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 0000000894D0: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 0000000894D8: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000894E0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000894E4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000894F0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000894F4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000894F8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000089500: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000089504: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000089508: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000008950C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000089510: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000089514: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000089518: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000008951C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000089520: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000089524: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000089530: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000089538: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000089540: 917E047E
	s_cbranch_execnz 65486                                     // 000000089544: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1780>
	s_set_inst_prefetch_distance 0x2                           // 000000089548: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008954C: 8C7E047E
	v_dual_mov_b32 v30, v16 :: v_dual_mov_b32 v29, v15         // 000000089550: CA100110 1E1C010F
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000089558: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000089560: 7E420326
	s_mov_b32 s5, 0                                            // 000000089564: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000089568: BF89FC07
	s_barrier                                                  // 00000008956C: BFBD0000
	buffer_gl0_inv                                             // 000000089570: E0AC0000 00000000
	s_nop 0                                                    // 000000089578: BF800000
	s_nop 0                                                    // 00000008957C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000089580: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17216                          // 000000089588: D8D84340 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000089590: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000089598: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008959C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 0000000895A4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 0000000895A8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 0000000895B0: BF870004
	.long 0xd4490004                                           // 0000000895B4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 0000000895B8: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 0000000895C0: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000000895C4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 0000000895C8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 0000000895CC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 0000000895D4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 0000000895DC: 917E057E
	s_cbranch_execnz 65511                                     // 0000000895E0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1880>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000895E4: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 0000000895E8: BF89FC07
	s_barrier                                                  // 0000000895EC: BFBD0000
	buffer_gl0_inv                                             // 0000000895F0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v47 offset0:136 offset1:153    // 0000000895F8: D8DC9988 1D00002F
	ds_load_2addr_b32 v[31:32], v47 offset0:170 offset1:187    // 000000089600: D8DCBBAA 1F00002F
	ds_load_2addr_b32 v[33:34], v47 offset0:204 offset1:221    // 000000089608: D8DCDDCC 2100002F
	ds_load_2addr_b32 v[35:36], v47 offset0:238 offset1:255    // 000000089610: D8DCFFEE 2300002F
	v_mov_b32_e32 v60, v0                                      // 000000089618: 7E780300
	s_mov_b32 s4, 0                                            // 00000008961C: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000089620: BF840001
	s_nop 0                                                    // 000000089624: BF800000
	s_nop 0                                                    // 000000089628: BF800000
	s_nop 0                                                    // 00000008962C: BF800000
	s_nop 0                                                    // 000000089630: BF800000
	s_nop 0                                                    // 000000089634: BF800000
	s_nop 0                                                    // 000000089638: BF800000
	s_nop 0                                                    // 00000008963C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000089640: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 000000089644: 327A7884
	.long 0xd4490001                                           // 000000089648: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000008964C: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 000000089654: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 000000089658: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000089664: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 000000089668: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 000000089670: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 000000089678: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000089680: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000089688: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000089690: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000089698: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 0000000896A0: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 0000000896A4: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000000896B0: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 0000000896B4: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 0000000896B8: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 0000000896C0: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 0000000896C4: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 0000000896C8: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 0000000896CC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000896D0: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 0000000896D4: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 0000000896D8: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 0000000896DC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000896E0: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 0000000896E4: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 0000000896F0: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 0000000896F8: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000089700: 917E047E
	s_cbranch_execnz 65486                                     // 000000089704: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1940>
	s_set_inst_prefetch_distance 0x2                           // 000000089708: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008970C: 8C7E047E
	v_dual_mov_b32 v30, v18 :: v_dual_mov_b32 v29, v17         // 000000089710: CA100112 1E1C0111
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000089718: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000089720: 7E420326
	s_mov_b32 s5, 0                                            // 000000089724: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000089728: BF89FC07
	s_barrier                                                  // 00000008972C: BFBD0000
	buffer_gl0_inv                                             // 000000089730: E0AC0000 00000000
	s_nop 0                                                    // 000000089738: BF800000
	s_nop 0                                                    // 00000008973C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000089740: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17248                          // 000000089748: D8D84360 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000089750: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000089758: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008975C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000089764: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000089768: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000089770: BF870004
	.long 0xd4490004                                           // 000000089774: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000089778: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 000000089780: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000089784: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000089788: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008978C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000089794: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000008979C: 917E057E
	s_cbranch_execnz 65511                                     // 0000000897A0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1a40>
	s_or_b32 exec_lo, exec_lo, s5                              // 0000000897A4: 8C7E057E
	v_add_nc_u32_e32 v60, 0x400, v47                           // 0000000897A8: 4A785EFF 00000400
	s_waitcnt lgkmcnt(0)                                       // 0000000897B0: BF89FC07
	s_barrier                                                  // 0000000897B4: BFBD0000
	buffer_gl0_inv                                             // 0000000897B8: E0AC0000 00000000
	v_mov_b32_e32 v61, v0                                      // 0000000897C0: 7E7A0300
	ds_load_2addr_b32 v[29:30], v60 offset0:16 offset1:33      // 0000000897C4: D8DC2110 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:50 offset1:67      // 0000000897CC: D8DC4332 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:84 offset1:101     // 0000000897D4: D8DC6554 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:118 offset1:135    // 0000000897DC: D8DC8776 2300003C
	s_mov_b32 s4, 0                                            // 0000000897E4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000897E8: BF840001
	s_nop 0                                                    // 0000000897EC: BF800000
	s_nop 0                                                    // 0000000897F0: BF800000
	s_nop 0                                                    // 0000000897F4: BF800000
	s_nop 0                                                    // 0000000897F8: BF800000
	s_nop 0                                                    // 0000000897FC: BF800000
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000089800: 327C7A84
	.long 0xd4490001                                           // 000000089804: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000089808: 02027AFF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000089810: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000089814: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000089818: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000089824: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000089828: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000089830: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000089838: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000089840: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000089848: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000089850: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000089858: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000089860: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000089864: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000089868: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 00000008986C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000089878: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000089880: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000089884: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000089888: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 00000008988C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000089890: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000089894: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000089898: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 00000008989C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000000898A0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 0000000898A4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 0000000898B0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 0000000898B8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 0000000898C0: 917E047E
	s_cbranch_execnz 65486                                     // 0000000898C4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1b00>
	s_set_inst_prefetch_distance 0x2                           // 0000000898C8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 0000000898CC: 8C7E047E
	v_dual_mov_b32 v30, v20 :: v_dual_mov_b32 v29, v19         // 0000000898D0: CA100114 1E1C0113
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 0000000898D8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 0000000898E0: 7E420326
	s_mov_b32 s5, 0                                            // 0000000898E4: BE850080
	s_waitcnt lgkmcnt(0)                                       // 0000000898E8: BF89FC07
	s_barrier                                                  // 0000000898EC: BFBD0000
	buffer_gl0_inv                                             // 0000000898F0: E0AC0000 00000000
	s_nop 0                                                    // 0000000898F8: BF800000
	s_nop 0                                                    // 0000000898FC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000089900: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17280                          // 000000089908: D8D84380 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000089910: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000089918: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008991C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000089924: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000089928: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000089930: BF870004
	.long 0xd4490004                                           // 000000089934: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000089938: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 000000089940: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000089944: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000089948: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008994C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000089954: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000008995C: 917E057E
	s_cbranch_execnz 65511                                     // 000000089960: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1c00>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000089964: 8C7E057E
	v_add_nc_u32_e32 v35, 0x600, v47                           // 000000089968: 4A465EFF 00000600
	s_waitcnt lgkmcnt(0)                                       // 000000089970: BF89FC07
	s_barrier                                                  // 000000089974: BFBD0000
	buffer_gl0_inv                                             // 000000089978: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:152 offset1:169    // 000000089980: D8DCA998 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:186 offset1:203    // 000000089988: D8DCCBBA 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:220 offset1:237    // 000000089990: D8DCEDDC 2100003C
	ds_load_2addr_b32 v[35:36], v35 offset0:126 offset1:143    // 000000089998: D8DC8F7E 23000023
	v_mov_b32_e32 v60, v0                                      // 0000000899A0: 7E780300
	s_mov_b32 s4, 0                                            // 0000000899A4: BE840080
	s_set_inst_prefetch_distance 0x1                           // 0000000899A8: BF840001
	s_nop 0                                                    // 0000000899AC: BF800000
	s_nop 0                                                    // 0000000899B0: BF800000
	s_nop 0                                                    // 0000000899B4: BF800000
	s_nop 0                                                    // 0000000899B8: BF800000
	s_nop 0                                                    // 0000000899BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000000899C0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 0000000899C4: 327A7884
	.long 0xd4490001                                           // 0000000899C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 0000000899CC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 0000000899D4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 0000000899D8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 0000000899E4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 0000000899E8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 0000000899F0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 0000000899F8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 000000089A00: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 000000089A08: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 000000089A10: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 000000089A18: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 000000089A20: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 000000089A24: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000089A30: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 000000089A34: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 000000089A38: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 000000089A40: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 000000089A44: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 000000089A48: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 000000089A4C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000089A50: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 000000089A54: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 000000089A58: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 000000089A5C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000089A60: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 000000089A64: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 000000089A70: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 000000089A78: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000089A80: 917E047E
	s_cbranch_execnz 65486                                     // 000000089A84: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1cc0>
	s_set_inst_prefetch_distance 0x2                           // 000000089A88: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000089A8C: 8C7E047E
	v_dual_mov_b32 v30, v22 :: v_dual_mov_b32 v29, v21         // 000000089A90: CA100116 1E1C0115
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000089A98: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000089AA0: 7E420326
	s_mov_b32 s5, 0                                            // 000000089AA4: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000089AA8: BF89FC07
	s_barrier                                                  // 000000089AAC: BFBD0000
	buffer_gl0_inv                                             // 000000089AB0: E0AC0000 00000000
	s_nop 0                                                    // 000000089AB8: BF800000
	s_nop 0                                                    // 000000089ABC: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000089AC0: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17312                          // 000000089AC8: D8D843A0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000089AD0: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000089AD8: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000089ADC: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000089AE4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000089AE8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000089AF0: BF870004
	.long 0xd4490004                                           // 000000089AF4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000089AF8: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 000000089B00: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000089B04: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000089B08: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000089B0C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000089B14: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000089B1C: 917E057E
	s_cbranch_execnz 65511                                     // 000000089B20: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1dc0>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000089B24: 8C7E057E
	v_add_nc_u32_e32 v61, 0x800, v47                           // 000000089B28: 4A7A5EFF 00000800
	s_waitcnt lgkmcnt(0)                                       // 000000089B30: BF89FC07
	s_barrier                                                  // 000000089B34: BFBD0000
	buffer_gl0_inv                                             // 000000089B38: E0AC0000 00000000
	v_mov_b32_e32 v60, v0                                      // 000000089B40: 7E780300
	ds_load_2addr_b32 v[29:30], v61 offset0:32 offset1:49      // 000000089B44: D8DC3120 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:66 offset1:83      // 000000089B4C: D8DC5342 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:100 offset1:117    // 000000089B54: D8DC7564 2100003D
	ds_load_2addr_b32 v[35:36], v61 offset0:134 offset1:151    // 000000089B5C: D8DC9786 2300003D
	s_mov_b32 s4, 0                                            // 000000089B64: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000089B68: BF840001
	s_nop 0                                                    // 000000089B6C: BF800000
	s_nop 0                                                    // 000000089B70: BF800000
	s_nop 0                                                    // 000000089B74: BF800000
	s_nop 0                                                    // 000000089B78: BF800000
	s_nop 0                                                    // 000000089B7C: BF800000
	v_lshrrev_b32_e32 v62, 4, v60                              // 000000089B80: 327C7884
	.long 0xd4490001                                           // 000000089B84: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 000000089B88: 020278FF 0000077F
	s_delay_alu instid0(VALU_DEP_2)                            // 000000089B90: BF870002
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000089B94: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000089B98: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000089BA4: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000089BA8: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000089BB0: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000089BB8: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000089BC0: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000089BC8: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000089BD0: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000089BD8: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000089BE0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000089BE4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000089BE8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000089BEC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000089BF8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000089C00: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000089C04: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000089C08: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 000000089C0C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000089C10: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000089C14: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000089C18: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 000000089C1C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000089C20: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v60// 000000089C24: C820473F 463E78FF 00000080
	v_fmac_f32_e32 v70, v64, v36                               // 000000089C30: 568C4940
	s_delay_alu instid0(VALU_DEP_2)                            // 000000089C34: BF870002
	v_mov_b32_e32 v60, v63                                     // 000000089C38: 7E78033F
	ds_store_b32 v62, v70                                      // 000000089C3C: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000089C44: 917E047E
	s_cbranch_execnz 65485                                     // 000000089C48: BFA6FFCD <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1e80>
	s_set_inst_prefetch_distance 0x2                           // 000000089C4C: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000089C50: 8C7E047E
	v_dual_mov_b32 v30, v24 :: v_dual_mov_b32 v29, v23         // 000000089C54: CA100118 1E1C0117
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000089C5C: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000089C64: 7E420326
	s_mov_b32 s5, 0                                            // 000000089C68: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000089C6C: BF89FC07
	s_barrier                                                  // 000000089C70: BFBD0000
	buffer_gl0_inv                                             // 000000089C74: E0AC0000 00000000
	s_nop 0                                                    // 000000089C7C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000089C80: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17344                          // 000000089C88: D8D843C0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000089C90: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000089C98: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000089C9C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000089CA4: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000089CA8: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000089CB0: BF870004
	.long 0xd4490004                                           // 000000089CB4: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000089CB8: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 000000089CC0: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000089CC4: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000089CC8: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000089CCC: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000089CD4: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000089CDC: 917E057E
	s_cbranch_execnz 65511                                     // 000000089CE0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x1f80>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000089CE4: 8C7E057E
	v_add_nc_u32_e32 v60, 0xc00, v47                           // 000000089CE8: 4A785EFF 00000C00
	s_waitcnt lgkmcnt(0)                                       // 000000089CF0: BF89FC07
	s_barrier                                                  // 000000089CF4: BFBD0000
	buffer_gl0_inv                                             // 000000089CF8: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v61 offset0:168 offset1:185    // 000000089D00: D8DCB9A8 1D00003D
	ds_load_2addr_b32 v[31:32], v61 offset0:202 offset1:219    // 000000089D08: D8DCDBCA 1F00003D
	ds_load_2addr_b32 v[33:34], v61 offset0:236 offset1:253    // 000000089D10: D8DCFDEC 2100003D
	ds_load_2addr_b32 v[35:36], v60 offset0:14 offset1:31      // 000000089D18: D8DC1F0E 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000089D20: 7E7A0300
	s_mov_b32 s4, 0                                            // 000000089D24: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000089D28: BF840001
	s_nop 0                                                    // 000000089D2C: BF800000
	s_nop 0                                                    // 000000089D30: BF800000
	s_nop 0                                                    // 000000089D34: BF800000
	s_nop 0                                                    // 000000089D38: BF800000
	s_nop 0                                                    // 000000089D3C: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000089D40: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000089D44: 327C7A84
	.long 0xd4490001                                           // 000000089D48: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000089D4C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000089D54: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000089D58: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000089D64: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000089D68: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000089D70: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000089D78: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000089D80: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000089D88: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000089D90: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000089D98: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000089DA0: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000089DA4: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000089DA8: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000089DAC: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000089DB8: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000089DC0: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000089DC4: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000089DC8: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 000000089DCC: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000089DD0: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000089DD4: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000089DD8: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 000000089DDC: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000089DE0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000089DE4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000089DF0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000089DF8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000089E00: 917E047E
	s_cbranch_execnz 65486                                     // 000000089E04: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2040>
	s_set_inst_prefetch_distance 0x2                           // 000000089E08: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000089E0C: 8C7E047E
	v_dual_mov_b32 v30, v26 :: v_dual_mov_b32 v29, v25         // 000000089E10: CA10011A 1E1C0119
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000089E18: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000089E20: 7E420326
	s_mov_b32 s5, 0                                            // 000000089E24: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000089E28: BF89FC07
	s_barrier                                                  // 000000089E2C: BFBD0000
	buffer_gl0_inv                                             // 000000089E30: E0AC0000 00000000
	s_nop 0                                                    // 000000089E38: BF800000
	s_nop 0                                                    // 000000089E3C: BF800000
	global_load_b32 v34, v[29:30], off                         // 000000089E40: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17376                          // 000000089E48: D8D843E0 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 000000089E50: 4A4242FF 00000080
	.long 0xd700011d                                           // 000000089E58: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 000000089E5C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 000000089E64: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 000000089E68: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 000000089E70: BF870004
	.long 0xd4490004                                           // 000000089E74: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 000000089E78: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 000000089E80: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 000000089E84: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 000000089E88: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 000000089E8C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 000000089E94: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 000000089E9C: 917E057E
	s_cbranch_execnz 65511                                     // 000000089EA0: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2140>
	s_or_b32 exec_lo, exec_lo, s5                              // 000000089EA4: 8C7E057E
	s_waitcnt lgkmcnt(0)                                       // 000000089EA8: BF89FC07
	s_barrier                                                  // 000000089EAC: BFBD0000
	buffer_gl0_inv                                             // 000000089EB0: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:48 offset1:65      // 000000089EB8: D8DC4130 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:82 offset1:99      // 000000089EC0: D8DC6352 1F00003C
	ds_load_2addr_b32 v[33:34], v60 offset0:116 offset1:133    // 000000089EC8: D8DC8574 2100003C
	ds_load_2addr_b32 v[35:36], v60 offset0:150 offset1:167    // 000000089ED0: D8DCA796 2300003C
	v_mov_b32_e32 v61, v0                                      // 000000089ED8: 7E7A0300
	s_mov_b32 s4, 0                                            // 000000089EDC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 000000089EE0: BF840001
	s_nop 0                                                    // 000000089EE4: BF800000
	s_nop 0                                                    // 000000089EE8: BF800000
	s_nop 0                                                    // 000000089EEC: BF800000
	s_nop 0                                                    // 000000089EF0: BF800000
	s_nop 0                                                    // 000000089EF4: BF800000
	s_nop 0                                                    // 000000089EF8: BF800000
	s_nop 0                                                    // 000000089EFC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 000000089F00: BF870121
	v_lshrrev_b32_e32 v62, 4, v61                              // 000000089F04: 327C7A84
	.long 0xd4490001                                           // 000000089F08: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v61, vcc_lo                   // 000000089F0C: 02027AFF 0000077F
	v_lshlrev_b32_e32 v69, 2, v62                              // 000000089F14: 308A7C82
	v_mad_u64_u32 v[62:63], null, 0x44, v62, v[1:2]            // 000000089F18: D6FE7C3E 04067CFF 00000044
	s_or_b32 s4, s1, s4                                        // 000000089F24: 8C040401
	v_add_nc_u32_e32 v63, 0x3200, v69                          // 000000089F28: 4A7E8AFF 00003200
	v_add_nc_u32_e32 v65, 0x3600, v69                          // 000000089F30: 4A828AFF 00003600
	v_add_nc_u32_e32 v67, 0x3a00, v69                          // 000000089F38: 4A868AFF 00003A00
	ds_load_b32 v70, v62                                       // 000000089F40: D8D80000 4600003E
	ds_load_2addr_b32 v[63:64], v63 offset0:64 offset1:193     // 000000089F48: D8DCC140 3F00003F
	ds_load_2addr_b32 v[65:66], v65 offset0:66 offset1:195     // 000000089F50: D8DCC342 41000041
	ds_load_2addr_b32 v[67:68], v67 offset0:68 offset1:197     // 000000089F58: D8DCC544 43000043
	s_waitcnt lgkmcnt(2)                                       // 000000089F60: BF89FC27
	v_fmac_f32_e32 v70, v63, v29                               // 000000089F64: 568C3B3F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 000000089F68: BF8700C1
	v_dual_fmac_f32 v70, v64, v30 :: v_dual_add_nc_u32 v63, 0x3e00, v69// 000000089F6C: C8203D40 463E8AFF 00003E00
	ds_load_2addr_b32 v[63:64], v63 offset0:70 offset1:199     // 000000089F78: D8DCC746 3F00003F
	s_waitcnt lgkmcnt(2)                                       // 000000089F80: BF89FC27
	v_fmac_f32_e32 v70, v65, v31                               // 000000089F84: 568C3F41
	v_fmac_f32_e32 v70, v66, v32                               // 000000089F88: 568C4142
	s_waitcnt lgkmcnt(1)                                       // 000000089F8C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000089F90: BF870091
	v_fmac_f32_e32 v70, v67, v33                               // 000000089F94: 568C4343
	v_fmac_f32_e32 v70, v68, v34                               // 000000089F98: 568C4544
	s_waitcnt lgkmcnt(0)                                       // 000000089F9C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 000000089FA0: BF870091
	v_dual_fmac_f32 v70, v63, v35 :: v_dual_add_nc_u32 v63, 0x80, v61// 000000089FA4: C820473F 463E7AFF 00000080
	v_dual_fmac_f32 v70, v64, v36 :: v_dual_mov_b32 v61, v63   // 000000089FB0: C8104940 463C013F
	ds_store_b32 v62, v70                                      // 000000089FB8: D8340000 0000463E
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 000000089FC0: 917E047E
	s_cbranch_execnz 65486                                     // 000000089FC4: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2200>
	s_set_inst_prefetch_distance 0x2                           // 000000089FC8: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 000000089FCC: 8C7E047E
	v_dual_mov_b32 v30, v28 :: v_dual_mov_b32 v29, v27         // 000000089FD0: CA10011C 1E1C011B
	v_dual_mov_b32 v31, v40 :: v_dual_mov_b32 v32, 0           // 000000089FD8: CA100128 1F200080
	v_mov_b32_e32 v33, v38                                     // 000000089FE0: 7E420326
	s_mov_b32 s5, 0                                            // 000000089FE4: BE850080
	s_waitcnt lgkmcnt(0)                                       // 000000089FE8: BF89FC07
	s_barrier                                                  // 000000089FEC: BFBD0000
	buffer_gl0_inv                                             // 000000089FF0: E0AC0000 00000000
	s_nop 0                                                    // 000000089FF8: BF800000
	s_nop 0                                                    // 000000089FFC: BF800000
	global_load_b32 v34, v[29:30], off                         // 00000008A000: DC520000 227C001D
	ds_load_b32 v35, v32 offset:17408                          // 00000008A008: D8D84400 23000020
	v_add_nc_u32_e32 v33, 0x80, v33                            // 00000008A010: 4A4242FF 00000080
	.long 0xd700011d                                           // 00000008A018: D700011D
	v_cndmask_b32_e32 v1, 0x6000, v29, vcc_lo                  // 00000008A01C: 02023AFF 00006000
	v_add_nc_u32_e32 v32, 4, v32                               // 00000008A024: 4A404084
	v_add_co_ci_u32_e64 v30, null, 0, v30, s1                  // 00000008A028: D5207C1E 00063C80
	s_delay_alu instid0(VALU_DEP_4)                            // 00000008A030: BF870004
	.long 0xd4490004                                           // 00000008A034: D4490004
	v_cndmask_b32_e32 v1, 0x37f, v33, vcc_lo                   // 00000008A038: 020242FF 0000037F
	s_or_b32 s5, s4, s5                                        // 00000008A040: 8C050504
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 00000008A044: BF890007
	v_mul_f32_e32 v34, v34, v35                                // 00000008A048: 10444722
	ds_store_b32 v31, v34 offset:13056                         // 00000008A04C: D8343300 0000221F
	v_add_nc_u32_e32 v31, 0x204, v31                           // 00000008A054: 4A3E3EFF 00000204
	s_and_not1_b32 exec_lo, exec_lo, s5                        // 00000008A05C: 917E057E
	s_cbranch_execnz 65511                                     // 00000008A060: BFA6FFE7 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2300>
	s_or_b32 exec_lo, exec_lo, s5                              // 00000008A064: 8C7E057E
	v_add_nc_u32_e32 v33, 0xe00, v47                           // 00000008A068: 4A425EFF 00000E00
	v_add_nc_u32_e32 v35, 0x1000, v47                          // 00000008A070: 4A465EFF 00001000
	s_waitcnt lgkmcnt(0)                                       // 00000008A078: BF89FC07
	s_barrier                                                  // 00000008A07C: BFBD0000
	buffer_gl0_inv                                             // 00000008A080: E0AC0000 00000000
	ds_load_2addr_b32 v[29:30], v60 offset0:184 offset1:201    // 00000008A088: D8DCC9B8 1D00003C
	ds_load_2addr_b32 v[31:32], v60 offset0:218 offset1:235    // 00000008A090: D8DCEBDA 1F00003C
	ds_load_2addr_b32 v[33:34], v33 offset0:124 offset1:141    // 00000008A098: D8DC8D7C 21000021
	ds_load_2addr_b32 v[35:36], v35 offset0:30 offset1:47      // 00000008A0A0: D8DC2F1E 23000023
	v_mov_b32_e32 v60, v0                                      // 00000008A0A8: 7E780300
	s_mov_b32 s4, 0                                            // 00000008A0AC: BE840080
	s_set_inst_prefetch_distance 0x1                           // 00000008A0B0: BF840001
	s_nop 0                                                    // 00000008A0B4: BF800000
	s_nop 0                                                    // 00000008A0B8: BF800000
	s_nop 0                                                    // 00000008A0BC: BF800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000008A0C0: BF870121
	v_lshrrev_b32_e32 v61, 4, v60                              // 00000008A0C4: 327A7884
	.long 0xd4490001                                           // 00000008A0C8: D4490001
	v_cndmask_b32_e32 v1, 0x77f, v60, vcc_lo                   // 00000008A0CC: 020278FF 0000077F
	v_lshlrev_b32_e32 v68, 2, v61                              // 00000008A0D4: 30887A82
	v_mad_u64_u32 v[61:62], null, 0x44, v61, v[1:2]            // 00000008A0D8: D6FE7C3D 04067AFF 00000044
	s_or_b32 s4, s1, s4                                        // 00000008A0E4: 8C040401
	v_add_nc_u32_e32 v62, 0x3200, v68                          // 00000008A0E8: 4A7C88FF 00003200
	v_add_nc_u32_e32 v64, 0x3600, v68                          // 00000008A0F0: 4A8088FF 00003600
	v_add_nc_u32_e32 v66, 0x3a00, v68                          // 00000008A0F8: 4A8488FF 00003A00
	ds_load_b32 v69, v61                                       // 00000008A100: D8D80000 4500003D
	ds_load_2addr_b32 v[62:63], v62 offset0:64 offset1:193     // 00000008A108: D8DCC140 3E00003E
	ds_load_2addr_b32 v[64:65], v64 offset0:66 offset1:195     // 00000008A110: D8DCC342 40000040
	ds_load_2addr_b32 v[66:67], v66 offset0:68 offset1:197     // 00000008A118: D8DCC544 42000042
	s_waitcnt lgkmcnt(2)                                       // 00000008A120: BF89FC27
	v_dual_fmac_f32 v69, v62, v29 :: v_dual_add_nc_u32 v62, 0x3e00, v68// 00000008A124: C8203B3E 453E88FF 00003E00
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 00000008A130: BF8700C1
	v_fmac_f32_e32 v69, v63, v30                               // 00000008A134: 568A3D3F
	ds_load_2addr_b32 v[62:63], v62 offset0:70 offset1:199     // 00000008A138: D8DCC746 3E00003E
	s_waitcnt lgkmcnt(2)                                       // 00000008A140: BF89FC27
	v_fmac_f32_e32 v69, v64, v31                               // 00000008A144: 568A3F40
	v_fmac_f32_e32 v69, v65, v32                               // 00000008A148: 568A4141
	s_waitcnt lgkmcnt(1)                                       // 00000008A14C: BF89FC17
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008A150: BF870091
	v_fmac_f32_e32 v69, v66, v33                               // 00000008A154: 568A4342
	v_fmac_f32_e32 v69, v67, v34                               // 00000008A158: 568A4543
	s_waitcnt lgkmcnt(0)                                       // 00000008A15C: BF89FC07
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008A160: BF870091
	v_dual_fmac_f32 v69, v62, v35 :: v_dual_add_nc_u32 v62, 0x80, v60// 00000008A164: C820473E 453E78FF 00000080
	v_dual_fmac_f32 v69, v63, v36 :: v_dual_mov_b32 v60, v62   // 00000008A170: C810493F 453C013E
	ds_store_b32 v61, v69                                      // 00000008A178: D8340000 0000453D
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000008A180: 917E047E
	s_cbranch_execnz 65486                                     // 00000008A184: BFA6FFCE <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x23c0>
	s_set_inst_prefetch_distance 0x2                           // 00000008A188: BF840002
	s_or_b32 exec_lo, exec_lo, s4                              // 00000008A18C: 8C7E047E
	.long 0xd7000107                                           // 00000008A190: D7000107
	v_cndmask_b32_e32 v1, 0x180000, v7, vcc_lo                 // 00000008A194: 02020EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008A19C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, 0, v8, s1                    // 00000008A1A0: D5207C08 00061080
	.long 0xd7000109                                           // 00000008A1A8: D7000109
	v_cndmask_b32_e32 v1, 0x180000, v9, vcc_lo                 // 00000008A1AC: 020212FF 00180000
	v_add_co_ci_u32_e64 v10, null, 0, v10, s1                  // 00000008A1B4: D5207C0A 00061480
	.long 0xd700010d                                           // 00000008A1BC: D700010D
	v_cndmask_b32_e32 v1, 0xc0000, v13, vcc_lo                 // 00000008A1C0: 02021AFF 000C0000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008A1C8: BF8700A1
	v_add_co_ci_u32_e64 v14, null, 0, v14, s1                  // 00000008A1CC: D5207C0E 00061C80
	.long 0xd700010b                                           // 00000008A1D4: D700010B
	v_cndmask_b32_e32 v1, 0x180000, v11, vcc_lo                // 00000008A1D8: 020216FF 00180000
	v_add_co_ci_u32_e64 v12, null, 0, v12, s1                  // 00000008A1E0: D5207C0C 00061880
	.long 0xd700010f                                           // 00000008A1E8: D700010F
	v_cndmask_b32_e32 v1, 0x180000, v15, vcc_lo                // 00000008A1EC: 02021EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008A1F4: BF8700A1
	v_add_co_ci_u32_e64 v16, null, 0, v16, s1                  // 00000008A1F8: D5207C10 00062080
	.long 0xd7000111                                           // 00000008A200: D7000111
	v_cndmask_b32_e32 v1, 0x180000, v17, vcc_lo                // 00000008A204: 020222FF 00180000
	v_add_co_ci_u32_e64 v18, null, 0, v18, s1                  // 00000008A20C: D5207C12 00062480
	.long 0xd7000113                                           // 00000008A214: D7000113
	v_cndmask_b32_e32 v1, 0x180000, v19, vcc_lo                // 00000008A218: 020226FF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008A220: BF8700A1
	v_add_co_ci_u32_e64 v20, null, 0, v20, s1                  // 00000008A224: D5207C14 00062880
	.long 0xd7000115                                           // 00000008A22C: D7000115
	v_cndmask_b32_e32 v1, 0x180000, v21, vcc_lo                // 00000008A230: 02022AFF 00180000
	v_add_co_ci_u32_e64 v22, null, 0, v22, s1                  // 00000008A238: D5207C16 00062C80
	.long 0xd7000117                                           // 00000008A240: D7000117
	v_cndmask_b32_e32 v1, 0x180000, v23, vcc_lo                // 00000008A244: 02022EFF 00180000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000008A24C: BF8700A1
	v_add_co_ci_u32_e64 v24, null, 0, v24, s1                  // 00000008A250: D5207C18 00063080
	.long 0xd7000119                                           // 00000008A258: D7000119
	v_cndmask_b32_e32 v1, 0x180000, v25, vcc_lo                // 00000008A25C: 020232FF 00180000
	v_add_co_ci_u32_e64 v26, null, 0, v26, s1                  // 00000008A264: D5207C1A 00063480
	.long 0xd700011b                                           // 00000008A26C: D700011B
	v_cndmask_b32_e32 v1, 0x180000, v27, vcc_lo                // 00000008A270: 020236FF 00180000
	s_delay_alu instid0(VALU_DEP_1)                            // 00000008A278: BF870001
	v_add_co_ci_u32_e64 v28, null, 0, v28, s1                  // 00000008A27C: D5207C1C 00063880
	s_add_i32 s11, s11, 1                                      // 00000008A284: 810B810B
	s_waitcnt lgkmcnt(0)                                       // 00000008A288: BF89FC07
	s_cmp_eq_u32 s11, s35                                      // 00000008A28C: BF06230B
	s_barrier                                                  // 00000008A290: BFBD0000
	buffer_gl0_inv                                             // 00000008A294: E0AC0000 00000000
	s_cbranch_scc0 63361                                       // 00000008A29C: BFA1F781 <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x3a4>
	v_mov_b32_e32 v4, v38                                      // 00000008A2A0: 7E080326
	s_add_u32 s0, s30, s24                                     // 00000008A2A4: 8000181E
	.long 0xd73c0000                                           // 00000008A2A8: D73C0000
	v_cndmask_b32_e32 v1, 9, v2, vcc_lo                        // 00000008A2AC: 02020489
	s_addc_u32 s1, s31, s25                                    // 00000008A2B0: 8201191F
	s_add_u32 s2, s26, s22                                     // 00000008A2B4: 8002161A
	s_addc_u32 s3, s27, s23                                    // 00000008A2B8: 8203171B
	s_add_u32 s0, s2, s0                                       // 00000008A2BC: 80000002
	s_addc_u32 s1, s3, s1                                      // 00000008A2C0: 82010103
	.long 0xd7006a00                                           // 00000008A2C4: D7006A00
	v_cndmask_b32_e32 v1, s0, v0, vcc_lo                       // 00000008A2C8: 02020000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000008A2CC: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 00000008A2D0: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 00000008A2D8: BE810080
	.long 0xd7006a00                                           // 00000008A2DC: D7006A00
	v_cndmask_b32_e32 v1, v0, v39, vcc_lo                      // 00000008A2E0: 02024F00
	v_add_co_ci_u32_e64 v1, null, 0, v1, vcc_lo                // 00000008A2E4: D5207C01 01AA0280
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000008A2EC: BF870092
	.long 0xd7006a00                                           // 00000008A2F0: D7006A00
	v_cndmask_b32_e32 v1, s20, v0, vcc_lo                      // 00000008A2F4: 02020014
	v_add_co_ci_u32_e64 v1, null, s21, v1, vcc_lo              // 00000008A2F8: D5207C01 01AA0215
	ds_load_b32 v2, v37                                        // 00000008A300: D8D80000 02000025
	v_add_nc_u32_e32 v4, 0x80, v4                              // 00000008A308: 4A0808FF 00000080
	v_add_nc_u32_e32 v37, 0x220, v37                           // 00000008A310: 4A4A4AFF 00000220
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000008A318: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x77f, v4                         // 00000008A31C: 7C9208FF 0000077F
	s_or_b32 s1, vcc_lo, s1                                    // 00000008A324: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 00000008A328: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 00000008A32C: DC6A0000 007C0200
	.long 0xd7000000                                           // 00000008A334: D7000000
	v_cndmask_b32_e32 v1, 0x1000, v0, vcc_lo                   // 00000008A338: 020200FF 00001000
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 00000008A340: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 00000008A348: 917E017E
	s_cbranch_execnz 65516                                     // 00000008A34C: BFA6FFEC <_ZN7halogen12_GLOBAL__N_111k_dnc_scan3ILi8ELi8ELi8ELb1ELi3ELi2ELi0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPti+0x2600>
	s_endpgm                                                   // 00000008A350: BFB00000
		...

