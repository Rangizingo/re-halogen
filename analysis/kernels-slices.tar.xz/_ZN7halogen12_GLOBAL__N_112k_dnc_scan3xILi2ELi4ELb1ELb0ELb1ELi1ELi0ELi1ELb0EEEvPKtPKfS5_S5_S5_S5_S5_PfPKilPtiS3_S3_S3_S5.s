000000000019fa00 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE>:
; _ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE():
	s_load_b256 s[16:23], s[0:1], 0x38                         // 00000019FA00: F40C0400 F8000038
	s_lshl_b32 s6, s3, 6                                       // 00000019FA08: 84068603
	s_ashr_i32 s3, s2, 31                                      // 00000019FA0C: 86039F02
	s_ashr_i32 s7, s6, 31                                      // 00000019FA10: 86079F06
	v_and_b32_e32 v1, 63, v0                                   // 00000019FA14: 360200BF
	v_mov_b32_e32 v5, v0                                       // 00000019FA18: 7E0A0300
	s_waitcnt lgkmcnt(0)                                       // 00000019FA1C: BF89FC07
	s_load_b32 s4, s[18:19], null                              // 00000019FA20: F4000109 F8000000
	s_clause 0x1                                               // 00000019FA28: BF850001
	s_load_b256 s[24:31], s[0:1], 0xa8                         // 00000019FA2C: F40C0600 F80000A8
	s_load_b32 s8, s[0:1], 0xc8                                // 00000019FA34: F4000200 F80000C8
	s_lshl_b64 s[18:19], s[20:21], 2                           // 00000019FA3C: 84928214
	v_lshlrev_b32_e32 v3, 2, v1                                // 00000019FA40: 30060282
	s_add_u32 s5, s16, s18                                     // 00000019FA44: 80051210
	s_addc_u32 s9, s17, s19                                    // 00000019FA48: 82091311
	s_lshl_b64 s[20:21], s[2:3], 16                            // 00000019FA4C: 84949002
	v_mul_u32_u24_e32 v2, 0x210, v1                            // 00000019FA50: 160402FF 00000210
	s_add_u32 s5, s5, s20                                      // 00000019FA58: 80051405
	s_addc_u32 s9, s9, s21                                     // 00000019FA5C: 82091509
	s_waitcnt lgkmcnt(0)                                       // 00000019FA60: BF89FC07
	s_mul_i32 s66, s4, 0x9000000                               // 00000019FA64: 9642FF04 09000000
	s_mul_hi_i32 s33, s4, 0x9000000                            // 00000019FA6C: 9721FF04 09000000
	s_add_u32 s4, s5, s66                                      // 00000019FA74: 80044205
	s_addc_u32 s5, s9, s33                                     // 00000019FA78: 82052109
	s_lshl_b64 s[34:35], s[6:7], 2                             // 00000019FA7C: 84A28206
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 00000019FA80: BF8700B9
	s_add_u32 s4, s4, s34                                      // 00000019FA84: 80042204
	s_addc_u32 s5, s5, s35                                     // 00000019FA88: 82052305
	.long 0xd7000403                                           // 00000019FA8C: D7000403
	v_cndmask_b32_e32 v1, s4, v3, vcc_lo                       // 00000019FA90: 02020604
	v_add_co_ci_u32_e64 v4, null, s5, 0, s4                    // 00000019FA94: D5207C04 00110005
	s_mov_b32 s4, 0                                            // 00000019FA9C: BE840080
	s_nop 0                                                    // 00000019FAA0: BF800000
	s_nop 0                                                    // 00000019FAA4: BF800000
	s_nop 0                                                    // 00000019FAA8: BF800000
	s_nop 0                                                    // 00000019FAAC: BF800000
	s_nop 0                                                    // 00000019FAB0: BF800000
	s_nop 0                                                    // 00000019FAB4: BF800000
	s_nop 0                                                    // 00000019FAB8: BF800000
	s_nop 0                                                    // 00000019FABC: BF800000
	v_lshrrev_b32_e32 v8, 6, v5                                // 00000019FAC0: 32100A86
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 00000019FAC4: BF870121
	v_lshlrev_b32_e32 v6, 9, v8                                // 00000019FAC8: 300C1089
	v_lshl_add_u32 v8, v8, 2, v2                               // 00000019FACC: D6460008 04090508
	.long 0xd7006a06                                           // 00000019FAD4: D7006A06
	v_cndmask_b32_e32 v1, v3, v6, vcc_lo                       // 00000019FAD8: 02020D03
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 00000019FADC: BF8700D1
	v_add_co_ci_u32_e64 v7, null, 0, v4, vcc_lo                // 00000019FAE0: D5207C07 01AA0880
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v5                        // 00000019FAE8: 7C920AFF 00001F7F
	global_load_b32 v6, v[6:7], off                            // 00000019FAF0: DC520000 067C0006
	v_add_nc_u32_e32 v7, 0x80, v5                              // 00000019FAF8: 4A0E0AFF 00000080
	s_or_b32 s4, vcc_lo, s4                                    // 00000019FB00: 8C04046A
	v_mov_b32_e32 v5, v7                                       // 00000019FB04: 7E0A0307
	s_waitcnt vmcnt(0)                                         // 00000019FB08: BF8903F7
	ds_store_b32 v8, v6                                        // 00000019FB0C: D8340000 00000608
	s_and_not1_b32 exec_lo, exec_lo, s4                        // 00000019FB14: 917E047E
	s_cbranch_execnz 65513                                     // 00000019FB18: BFA6FFE9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xc0>
	s_or_b32 exec_lo, exec_lo, s4                              // 00000019FB1C: 8C7E047E
	s_load_b32 s67, s[0:1], 0x58                               // 00000019FB20: F40010C0 F8000058
	v_or_b32_e32 v125, 0xffffff80, v0                          // 00000019FB28: 38FA00FF FFFFFF80
	v_lshlrev_b32_e32 v5, 3, v0                                // 00000019FB30: 300A0083
	v_lshlrev_b32_e32 v124, 2, v1                              // 00000019FB34: 30F80282
	v_mul_u32_u24_e32 v3, 0x210, v1                            // 00000019FB38: 160602FF 00000210
	v_lshrrev_b32_e32 v4, 4, v0                                // 00000019FB40: 32080084
	s_mov_b32 s4, 0                                            // 00000019FB44: BE840080
	s_waitcnt lgkmcnt(0)                                       // 00000019FB48: BF89FC07
	s_barrier                                                  // 00000019FB4C: BFBD0000
	buffer_gl0_inv                                             // 00000019FB50: E0AC0000 00000000
	s_cmp_gt_i32 s67, 0                                        // 00000019FB58: BF028043
	s_cbranch_scc1 14                                          // 00000019FB5C: BFA2000E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	v_dual_mov_b32 v107, 0 :: v_dual_and_b32 v106, 0x200, v5   // 00000019FB60: CA240080 6B6A0AFF 00000200
	v_or_b32_e32 v6, 0xffffff80, v0                            // 00000019FB6C: 380C00FF FFFFFF80
	v_and_or_b32 v135, v4, 4, v3                               // 00000019FB74: D6570087 040D0904
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019FB7C: BF870003
	v_dual_mov_b32 v1, s34 :: v_dual_mov_b32 v140, v107        // 00000019FB80: CA100022 018C016B
	v_mov_b32_e32 v2, s35                                      // 00000019FB88: 7E040223
	s_and_not1_b32 vcc_lo, exec_lo, s4                         // 00000019FB8C: 916A047E
	s_cbranch_vccz 1                                           // 00000019FB90: BFA30001 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x198>
	s_branch 13140                                             // 00000019FB94: BFA03354 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xcee8>
	s_clause 0x2                                               // 00000019FB98: BF850002
	s_load_b256 s[36:43], s[0:1], 0x60                         // 00000019FB9C: F40C0900 F8000060
	s_load_b64 s[64:65], s[0:1], null                          // 00000019FBA4: F4041000 F8000000
	s_load_b128 s[60:63], s[0:1], 0x18                         // 00000019FBAC: F4080F00 F8000018
	s_lshl_b64 s[10:11], s[2:3], 2                             // 00000019FBB4: 848A8202
	s_mul_hi_i32 s9, s2, 0x55555556                            // 00000019FBB8: 9709FF02 55555556
	v_dual_mov_b32 v107, 0 :: v_dual_lshlrev_b32 v6, 2, v0     // 00000019FBC0: CA220080 6B060082
	v_dual_mov_b32 v148, 0xf004 :: v_dual_lshlrev_b32 v7, 1, v0// 00000019FBC8: CA2200FF 94060081 0000F004
	v_and_b32_e32 v1, 31, v0                                   // 00000019FBD4: 3602009F
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019FBD8: BF870003
	v_or_b32_e32 v126, 0xf000, v6                              // 00000019FBDC: 38FC0CFF 0000F000
	v_add_nc_u32_e32 v127, 0xf100, v6                          // 00000019FBE4: 4AFE0CFF 0000F100
	v_lshrrev_b32_e32 v2, 5, v0                                // 00000019FBEC: 32040085
	s_mov_b32 s44, 0xcc00                                      // 00000019FBF0: BEAC00FF 0000CC00
	v_dual_mov_b32 v140, v107 :: v_dual_lshlrev_b32 v9, 1, v1  // 00000019FBF8: CA22016B 8C080281
	v_mov_b32_e32 v150, 0xf014                                 // 00000019FC00: 7F2C02FF 0000F014
	s_delay_alu instid0(VALU_DEP_3)                            // 00000019FC08: BF870003
	v_dual_mov_b32 v149, 0xf00c :: v_dual_lshlrev_b32 v132, 4, v2// 00000019FC0C: CA2200FF 95840484 0000F00C
	v_bfe_u32 v133, v0, 4, 1                                   // 00000019FC18: D6100085 02050900
	s_load_b256 s[52:59], s[0:1], 0x80                         // 00000019FC20: F40C0D00 F8000080
	s_waitcnt lgkmcnt(0)                                       // 00000019FC28: BF89FC07
	s_add_u32 s42, s42, s10                                    // 00000019FC2C: 802A0A2A
	s_addc_u32 s43, s43, s11                                   // 00000019FC30: 822B0B2B
	s_add_u32 s68, s30, s10                                    // 00000019FC34: 80440A1E
	s_addc_u32 s69, s31, s11                                   // 00000019FC38: 82450B1F
	s_lshr_b32 s11, s9, 31                                     // 00000019FC3C: 850B9F09
	s_add_i32 s10, s67, 63                                     // 00000019FC40: 810ABF43
	s_add_i32 s9, s9, s11                                      // 00000019FC44: 81090B09
	s_add_i32 s71, s67, -1                                     // 00000019FC48: 8147C143
	s_lshr_b32 s72, s10, 6                                     // 00000019FC4C: 8548860A
	s_lshl_b32 s10, s9, 7                                      // 00000019FC50: 840A8709
	s_mul_i32 s9, s71, 0x5000                                  // 00000019FC54: 9609FF47 00005000
	s_add_i32 s70, s2, 0xbd0                                   // 00000019FC5C: 8146FF02 00000BD0
	s_mul_hi_u32 s12, s71, 0x5000                              // 00000019FC64: 968CFF47 00005000
	s_ashr_i32 s11, s10, 31                                    // 00000019FC6C: 860B9F0A
	s_add_u32 s9, s64, s9                                      // 00000019FC70: 80090940
	s_addc_u32 s12, s65, s12                                   // 00000019FC74: 820C0C41
	s_lshl_b64 s[30:31], s[10:11], 1                           // 00000019FC78: 849E810A
	s_load_b64 s[0:1], s[0:1], 0xa0                            // 00000019FC7C: F4040000 F80000A0
	s_add_u32 s9, s9, s30                                      // 00000019FC84: 80091E09
	s_addc_u32 s10, s12, s31                                   // 00000019FC88: 820A1F0C
	.long 0xd7000906                                           // 00000019FC8C: D7000906
	v_cndmask_b32_e32 v1, s9, v7, vcc_lo                       // 00000019FC90: 02020E09
	s_delay_alu instid0(VALU_DEP_1)                            // 00000019FC94: BF870001
	v_add_co_ci_u32_e64 v7, null, s10, 0, s9                   // 00000019FC98: D5207C07 0025000A
	s_mul_i32 s9, s71, 0xc0                                    // 00000019FCA0: 9609FF47 000000C0
	s_mul_hi_u32 s10, s71, 0xc0                                // 00000019FCA8: 968AFF47 000000C0
	s_add_u32 s73, s42, s9                                     // 00000019FCB0: 8049092A
	s_addc_u32 s74, s43, s10                                   // 00000019FCB4: 824A0A2B
	s_add_u32 s14, s62, s34                                    // 00000019FCB8: 800E223E
	s_addc_u32 s15, s63, s35                                   // 00000019FCBC: 820F233F
	s_lshl_b32 s10, s2, 7                                      // 00000019FCC0: 840A8702
	.long 0xd7006a80                                           // 00000019FCC4: D7006A80
	v_cndmask_b32_e32 v1, 0x1000, v6, vcc_lo                   // 00000019FCC8: 02020CFF 00001000
	s_ashr_i32 s11, s10, 31                                    // 00000019FCD0: 860B9F0A
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 00000019FCD4: BF870139
	v_dual_mov_b32 v111, s11 :: v_dual_and_b32 v130, 15, v0    // 00000019FCD8: CA24000B 6F82008F
	s_lshl_b64 s[12:13], s[10:11], 1                           // 00000019FCE0: 848C810A
	v_add_co_ci_u32_e64 v129, null, 0, v7, vcc_lo              // 00000019FCE4: D5207C81 01AA0E80
	v_mad_u32_u24 v136, 0x90, v130, s44                        // 00000019FCEC: D60B0088 00B304FF 00000090
	s_add_u32 s44, s22, s12                                    // 00000019FCF8: 802C0C16
	v_mul_u32_u24_e32 v7, 0x2100, v2                           // 00000019FCFC: 160E04FF 00002100
	s_addc_u32 s45, s23, s13                                   // 00000019FD04: 822D0D17
	s_lshl_b64 s[6:7], s[6:7], 1                               // 00000019FD08: 84868106
	v_or_b32_e32 v110, s10, v1                                 // 00000019FD0C: 38DC020A
	v_dual_mov_b32 v152, 0xf024 :: v_dual_lshlrev_b32 v1, 2, v130// 00000019FD10: CA2200FF 98010482 0000F024
	s_add_u32 s46, s44, s6                                     // 00000019FD1C: 802E062C
	s_addc_u32 s45, s45, s7                                    // 00000019FD20: 822D072D
	.long 0xd700076c                                           // 00000019FD24: D700076C
	v_cndmask_b32_e32 v1, s24, v9, vcc_lo                      // 00000019FD28: 02021218
	v_or_b32_e32 v8, v132, v130                                // 00000019FD2C: 38110584
	v_mad_u32_u24 v7, 0x210, v130, v7                          // 00000019FD30: D60B0007 041F04FF 00000210
	v_add_co_ci_u32_e64 v109, null, s25, 0, s7                 // 00000019FD3C: D5207C6D 001D0019
	.long 0xd700078d                                           // 00000019FD44: D700078D
	v_cndmask_b32_e32 v1, s14, v1, vcc_lo                      // 00000019FD48: 0202020E
	v_dual_mov_b32 v156, 0xf044 :: v_dual_lshlrev_b32 v1, 1, v130// 00000019FD4C: CA2200FF 9C010481 0000F044
	s_movk_i32 s9, 0x90                                        // 00000019FD58: B0090090
	v_lshl_or_b32 v139, v133, 2, v7                            // 00000019FD5C: D656008B 041D0585
	v_dual_mov_b32 v154, 0xf034 :: v_dual_lshlrev_b32 v7, 7, v8// 00000019FD64: CA2200FF 9A061087 0000F034
	v_dual_mov_b32 v179, 1 :: v_dual_and_b32 v106, 0x200, v5   // 00000019FD70: CA240081 B36A0AFF 00000200
	v_mad_u32_u24 v131, v0, s9, 0x8400                         // 00000019FD7C: D60B0083 03FC1300 00008400
	v_mad_u32_u24 v138, v130, s9, 0x8400                       // 00000019FD88: D60B008A 03FC1382 00008400
	s_add_u32 s9, s28, s12                                     // 00000019FD94: 80090C1C
	.long 0xd7000b70                                           // 00000019FD98: D7000B70
	v_cndmask_b32_e32 v1, s46, v1, vcc_lo                      // 00000019FD9C: 0202022E
	s_addc_u32 s10, s29, s13                                   // 00000019FDA0: 820A0D1D
	v_add_co_ci_u32_e64 v113, null, s45, 0, s11                // 00000019FDA4: D5207C71 002D002D
	s_add_u32 s11, s34, s20                                    // 00000019FDAC: 800B1422
	v_add_co_ci_u32_e64 v142, null, s15, 0, s7                 // 00000019FDB0: D5207C8E 001D000F
	.long 0xd7000790                                           // 00000019FDB8: D7000790
	v_cndmask_b32_e32 v1, s40, v7, vcc_lo                      // 00000019FDBC: 02020E28
	s_addc_u32 s12, s35, s21                                   // 00000019FDC0: 820C1523
	.long 0xd7000b01                                           // 00000019FDC4: D7000B01
	v_cndmask_b32_e32 v1, s11, v106, vcc_lo                    // 00000019FDC8: 0202D40B
	v_mad_u32_u24 v137, 0x900, v2, v136                        // 00000019FDCC: D60B0089 062204FF 00000900
	v_add_co_ci_u32_e64 v145, null, s41, 0, s7                 // 00000019FDD8: D5207C91 001D0029
	.long 0xd44d0007                                           // 00000019FDE0: D44D0007
	v_cndmask_b32_e32 v1, 0, v2, vcc_lo                        // 00000019FDE4: 02020480
	v_add_co_ci_u32_e64 v2, null, s12, 0, s11                  // 00000019FDE8: D5207C02 002D000C
	.long 0xd7006a01                                           // 00000019FDF0: D7006A01
	v_cndmask_b32_e32 v1, v1, v124, vcc_lo                     // 00000019FDF4: 0202F901
	v_or_b32_e32 v6, v132, v133                                // 00000019FDF8: 380D0B84
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 00000019FDFC: BF870193
	v_add_co_ci_u32_e64 v2, null, 0, v2, vcc_lo                // 00000019FE00: D5207C02 01AA0480
	.long 0xd7006a74                                           // 00000019FE08: D7006A74
	v_cndmask_b32_e32 v1, s56, v1, vcc_lo                      // 00000019FE0C: 02020238
	.long 0xd7000972                                           // 00000019FE10: D7000972
	v_cndmask_b32_e32 v1, s9, v9, vcc_lo                       // 00000019FE14: 02021209
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 00000019FE18: BF8700A3
	v_add_co_ci_u32_e64 v117, null, s57, v2, vcc_lo            // 00000019FE1C: D5207C75 01AA0439
	.long 0xd7006a76                                           // 00000019FE24: D7006A76
	v_cndmask_b32_e32 v1, s58, v1, vcc_lo                      // 00000019FE28: 0202023A
	v_add_co_ci_u32_e64 v119, null, s59, v2, vcc_lo            // 00000019FE2C: D5207C77 01AA043B
	s_waitcnt lgkmcnt(0)                                       // 00000019FE34: BF89FC07
	.long 0xd7006a78                                           // 00000019FE38: D7006A78
	v_cndmask_b32_e32 v1, s0, v1, vcc_lo                       // 00000019FE3C: 02020200
	.long 0xd44c0004                                           // 00000019FE40: D44C0004
	v_cndmask_b32_e32 v1, 64, v0, vcc_lo                       // 00000019FE44: 020200C0
	.long 0xd4490005                                           // 00000019FE48: D4490005
	v_cndmask_b32_e32 v1, 63, v0, vcc_lo                       // 00000019FE4C: 020200BF
	v_mul_u32_u24_e32 v134, 0x210, v130                        // 00000019FE50: 170D04FF 00000210
	.long 0xd44a0006                                           // 00000019FE58: D44A0006
	v_cndmask_b32_e32 v1, 0, v0, vcc_lo                        // 00000019FE5C: 02020080
	s_cvt_f32_i32 s62, s8                                      // 00000019FE60: BEBE6408
	v_lshl_add_u32 v143, v6, 1, v136                           // 00000019FE64: D646008F 06210306
	.long 0xd4490008                                           // 00000019FE6C: D4490008
	v_cndmask_b32_e32 v1, 0x5f, v0, vcc_lo                     // 00000019FE70: 020200FF 0000005F
	v_lshl_or_b32 v146, v6, 2, 0xf100                          // 00000019FE78: D6560092 03FD0506 0000F100
	v_add_co_ci_u32_e64 v115, null, s10, 0, s9                 // 00000019FE84: D5207C73 0025000A
	v_and_or_b32 v135, v4, 4, v3                               // 00000019FE8C: D6570087 040D0904
	v_add_co_ci_u32_e64 v121, null, s1, v2, vcc_lo             // 00000019FE94: D5207C79 01AA0401
	v_dual_mov_b32 v158, 0xf054 :: v_dual_lshlrev_b32 v147, 1, v0// 00000019FE9C: CA2200FF 9E920081 0000F054
	v_mov_b32_e32 v151, 0xf01c                                 // 00000019FEA8: 7F2E02FF 0000F01C
	v_mov_b32_e32 v153, 0xf02c                                 // 00000019FEB0: 7F3202FF 0000F02C
	v_mov_b32_e32 v155, 0xf03c                                 // 00000019FEB8: 7F3602FF 0000F03C
	v_mov_b32_e32 v157, 0xf04c                                 // 00000019FEC0: 7F3A02FF 0000F04C
	v_mov_b32_e32 v159, 0xf05c                                 // 00000019FEC8: 7F3E02FF 0000F05C
	v_mov_b32_e32 v160, 0xf064                                 // 00000019FED0: 7F4002FF 0000F064
	v_mov_b32_e32 v161, 0xf06c                                 // 00000019FED8: 7F4202FF 0000F06C
	v_mov_b32_e32 v162, 0xf074                                 // 00000019FEE0: 7F4402FF 0000F074
	v_mov_b32_e32 v163, 0xf07c                                 // 00000019FEE8: 7F4602FF 0000F07C
	v_mov_b32_e32 v164, 0xf084                                 // 00000019FEF0: 7F4802FF 0000F084
	v_mov_b32_e32 v165, 0xf08c                                 // 00000019FEF8: 7F4A02FF 0000F08C
	v_mov_b32_e32 v166, 0xf094                                 // 00000019FF00: 7F4C02FF 0000F094
	v_mov_b32_e32 v167, 0xf09c                                 // 00000019FF08: 7F4E02FF 0000F09C
	v_mov_b32_e32 v168, 0xf0a4                                 // 00000019FF10: 7F5002FF 0000F0A4
	v_mov_b32_e32 v169, 0xf0ac                                 // 00000019FF18: 7F5202FF 0000F0AC
	v_mov_b32_e32 v170, 0xf0b4                                 // 00000019FF20: 7F5402FF 0000F0B4
	v_mov_b32_e32 v171, 0xf0bc                                 // 00000019FF28: 7F5602FF 0000F0BC
	v_mov_b32_e32 v172, 0xf0c4                                 // 00000019FF30: 7F5802FF 0000F0C4
	v_mov_b32_e32 v173, 0xf0cc                                 // 00000019FF38: 7F5A02FF 0000F0CC
	v_mov_b32_e32 v174, 0xf0d4                                 // 00000019FF40: 7F5C02FF 0000F0D4
	v_mov_b32_e32 v175, 0xf0dc                                 // 00000019FF48: 7F5E02FF 0000F0DC
	v_mov_b32_e32 v176, 0xf0e4                                 // 00000019FF50: 7F6002FF 0000F0E4
	v_mov_b32_e32 v177, 0xf0ec                                 // 00000019FF58: 7F6202FF 0000F0EC
	v_mov_b32_e32 v178, 0xf0f4                                 // 00000019FF60: 7F6402FF 0000F0F4
	.long 0xd71f00b4                                           // 00000019FF68: D71F00B4
	v_cndmask_b32_e32 v0, -1, v128, vcc_lo                     // 00000019FF6C: 020100C1
	s_mov_b32 s44, 0                                           // 00000019FF70: BEAC0080
	s_mov_b32 s28, 0x41800000                                  // 00000019FF74: BE9C00FF 41800000
	s_mov_b32 s45, s44                                         // 00000019FF7C: BEAD002C
	s_mov_b32 s46, s44                                         // 00000019FF80: BEAE002C
	s_mov_b32 s47, s44                                         // 00000019FF84: BEAF002C
	s_mov_b32 s48, s44                                         // 00000019FF88: BEB0002C
	s_mov_b32 s49, s44                                         // 00000019FF8C: BEB1002C
	s_mov_b32 s50, s44                                         // 00000019FF90: BEB2002C
	s_mov_b32 s51, s44                                         // 00000019FF94: BEB3002C
	s_mov_b32 s29, s44                                         // 00000019FF98: BE9D002C
	s_branch 4                                                 // 00000019FF9C: BFA00004 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5b0>
	s_add_i32 s29, s29, 1                                      // 00000019FFA0: 811D811D
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000019FFA4: BF870009
	s_cmp_eq_u32 s29, s72                                      // 00000019FFA8: BF06481D
	s_cbranch_scc1 12874                                       // 00000019FFAC: BFA2324A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xced8>
	s_mul_i32 s0, s29, 0xc00                                   // 00000019FFB0: 9600FF1D 00000C00
	s_lshl_b32 s41, s29, 6                                     // 00000019FFB8: 8429861D
	s_add_i32 s0, s70, s0                                      // 00000019FFBC: 81000046
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(SALU_CYCLE_1)// 00000019FFC0: BF870499
	s_ashr_i32 s1, s0, 31                                      // 00000019FFC4: 86019F00
	s_lshl_b64 s[0:1], s[0:1], 2                               // 00000019FFC8: 84808200
	s_delay_alu instid0(SALU_CYCLE_1)                          // 00000019FFCC: BF870009
	s_add_u32 s0, s60, s0                                      // 00000019FFD0: 8000003C
	s_addc_u32 s1, s61, s1                                     // 00000019FFD4: 8201013D
	global_load_b32 v1, v107, s[0:1]                           // 00000019FFD8: DC520000 0100006B
	s_waitcnt vmcnt(0)                                         // 00000019FFE0: BF8903F7
	v_readfirstlane_b32 s40, v1                                // 00000019FFE4: 7E500501
	s_and_saveexec_b32 s0, s4                                  // 00000019FFE8: BE802004
	s_cbranch_execz 69                                         // 00000019FFEC: BFA50045 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x704>
	v_or_b32_e32 v1, s41, v0                                   // 00000019FFF0: 38020029
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 00000019FFF4: BF870091
	v_mad_u64_u32 v[1:2], null, v1, 48, s[2:3]                 // 00000019FFF8: D6FE7C01 00096101
	v_ashrrev_i32_e32 v2, 31, v1                               // 0000001A0000: 3404029F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0004: BF870091
	.long 0xd73c0001                                           // 0000001A0008: D73C0001
	v_cndmask_b32_e32 v1, 2, v1, vcc_lo                        // 0000001A000C: 02020282
	.long 0xd7006a01                                           // 0000001A0010: D7006A01
	v_cndmask_b32_e32 v1, s60, v1, vcc_lo                      // 0000001A0014: 0202023C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_1)// 0000001A0018: BF8700C1
	v_add_co_ci_u32_e64 v2, null, s61, v2, vcc_lo              // 0000001A001C: D5207C02 01AA043D
	global_load_b32 v1, v[1:2], off                            // 0000001A0024: DC520000 017C0001
	s_waitcnt vmcnt(0)                                         // 0000001A002C: BF8903F7
	v_sub_f32_e32 v2, s40, v1                                  // 0000001A0030: 08040228
	v_dual_mul_f32 v4, 0x3fb8aa3b, v1 :: v_dual_mul_f32 v3, 0x3fb8aa3b, v2// 0000001A0034: C8C602FF 040204FF 3FB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A0040: BF8701A1
	v_rndne_f32_e32 v8, v4                                     // 0000001A0044: 7E104704
	v_fma_f32 v7, 0x3fb8aa3b, v1, -v4                          // 0000001A0048: D6130007 841202FF 3FB8AA3B
	v_fma_f32 v5, 0x3fb8aa3b, v2, -v3                          // 0000001A0054: D6130005 840E04FF 3FB8AA3B
	v_rndne_f32_e32 v6, v3                                     // 0000001A0060: 7E0C4703
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A0064: BF870191
	v_dual_sub_f32 v4, v4, v8 :: v_dual_sub_f32 v3, v3, v6     // 0000001A0068: C94A1104 04020D03
	v_fmac_f32_e32 v5, 0x32a5705f, v2                          // 0000001A0070: 560A04FF 32A5705F
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v2                   // 0000001A0078: 7C3604FF C2CE8ED0
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001A0080: BF8701B2
	v_add_f32_e32 v3, v3, v5                                   // 0000001A0084: 06060B03
	v_cvt_i32_f32_e32 v5, v6                                   // 0000001A0088: 7E0A1106
	v_cvt_i32_f32_e32 v6, v8                                   // 0000001A008C: 7E0C1108
	v_exp_f32_e32 v3, v3                                       // 0000001A0090: 7E064B03
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A0094: BF870095
	.long 0xd71c0003                                           // 0000001A0098: D71C0003
	v_cndmask_b32_e32 v1, v3, v5, vcc_lo                       // 0000001A009C: 02020B03
	v_cndmask_b32_e32 v3, 0, v3, vcc_lo                        // 0000001A00A0: 02060680
	v_cmp_ngt_f32_e32 vcc_lo, 0xc2ce8ed0, v1                   // 0000001A00A4: 7C3602FF C2CE8ED0
	v_fmac_f32_e32 v7, 0x32a5705f, v1                          // 0000001A00AC: 560E02FF 32A5705F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A00B4: BF870091
	v_add_f32_e32 v4, v4, v7                                   // 0000001A00B8: 06080F04
	v_exp_f32_e32 v4, v4                                       // 0000001A00BC: 7E084B04
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A00C0: BF870095
	.long 0xd71c0004                                           // 0000001A00C4: D71C0004
	v_cndmask_b32_e32 v1, v4, v6, vcc_lo                       // 0000001A00C8: 02020D04
	v_cndmask_b32_e32 v4, 0, v4, vcc_lo                        // 0000001A00CC: 02080880
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v2                   // 0000001A00D0: 7C3C04FF 42B17218
	v_cndmask_b32_e32 v2, 0x7f800000, v3, vcc_lo               // 0000001A00D8: 020406FF 7F800000
	v_cmp_nlt_f32_e32 vcc_lo, 0x42b17218, v1                   // 0000001A00E0: 7C3C02FF 42B17218
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A00E8: BF870004
	v_cndmask_b32_e32 v1, 0x7f800000, v4, vcc_lo               // 0000001A00EC: 020208FF 7F800000
	ds_store_b32 v126, v2                                      // 0000001A00F4: D8340000 0000027E
	ds_store_b32 v127, v1                                      // 0000001A00FC: D8340000 0000017F
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001A0104: 8C7E007E
	s_mul_i32 s0, s29, 0x140000                                // 0000001A0108: 9600FF1D 00140000
	s_sub_i32 s9, s67, s41                                     // 0000001A0110: 81892943
	s_mul_hi_u32 s1, s29, 0x140000                             // 0000001A0114: 9681FF1D 00140000
	s_add_u32 s0, s64, s0                                      // 0000001A011C: 80000040
	s_addc_u32 s1, s65, s1                                     // 0000001A0120: 82010141
	s_add_u32 s0, s0, s30                                      // 0000001A0124: 80001E00
	s_addc_u32 s1, s1, s31                                     // 0000001A0128: 82011F01
	.long 0xd7000011                                           // 0000001A012C: D7000011
	v_cndmask_b32_e32 v1, s0, v147, vcc_lo                     // 0000001A0130: 02032600
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A0134: BF870001
	v_add_co_ci_u32_e64 v64, null, s1, 0, s0                   // 0000001A0138: D5207C40 00010001
	s_mul_i32 s0, s29, 0x3000                                  // 0000001A0140: 9600FF1D 00003000
	s_mul_hi_u32 s1, s29, 0x3000                               // 0000001A0148: 9681FF1D 00003000
	s_add_u32 s25, s42, s0                                     // 0000001A0150: 8019002A
	s_addc_u32 s24, s43, s1                                    // 0000001A0154: 8218012B
	.long 0xd7006a01                                           // 0000001A0158: D7006A01
	v_cndmask_b32_e32 v1, 0x1000, v17, vcc_lo                  // 0000001A015C: 020222FF 00001000
	s_cmp_gt_i32 s9, 0                                         // 0000001A0164: BF028009
	v_add_co_ci_u32_e64 v2, null, 0, v64, vcc_lo               // 0000001A0168: D5207C02 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0170: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0174: BF870009
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001A0178: 8B007E6A
	s_cselect_b32 s11, s24, s74                                // 0000001A017C: 980B4A18
	s_cselect_b32 s10, s25, s73                                // 0000001A0180: 980A4919
	s_add_u32 s0, s25, 0xc0                                    // 0000001A0184: 8000FF19 000000C0
	s_addc_u32 s1, s24, 0                                      // 0000001A018C: 82018018
	v_dual_cndmask_b32 v2, v129, v2 :: v_dual_cndmask_b32 v1, v128, v1// 0000001A0190: CA520581 02000380
	.long 0xd7006a04                                           // 0000001A0198: D7006A04
	v_cndmask_b32_e32 v1, 0x6000, v17, vcc_lo                  // 0000001A019C: 020222FF 00006000
	s_cmp_gt_i32 s9, 1                                         // 0000001A01A4: BF028109
	v_add_co_ci_u32_e64 v3, null, 0, v64, vcc_lo               // 0000001A01A8: D5207C03 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A01B0: 986A80C1
	global_load_d16_b16 v1, v[1:2], off                        // 0000001A01B4: DC820000 017C0001
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001A01BC: 8B0C7E6A
	s_cselect_b32 s13, s1, s74                                 // 0000001A01C0: 980D4A01
	s_cselect_b32 s12, s0, s73                                 // 0000001A01C4: 980C4900
	s_add_u32 s0, s25, 0x180                                   // 0000001A01C8: 8000FF19 00000180
	s_addc_u32 s1, s24, 0                                      // 0000001A01D0: 82018018
	v_dual_cndmask_b32 v3, v129, v3 :: v_dual_cndmask_b32 v2, v128, v4// 0000001A01D4: CA520781 03020980
	.long 0xd7006a05                                           // 0000001A01DC: D7006A05
	v_cndmask_b32_e32 v1, 0xb000, v17, vcc_lo                  // 0000001A01E0: 020222FF 0000B000
	s_cmp_gt_i32 s9, 2                                         // 0000001A01E8: BF028209
	v_add_co_ci_u32_e64 v4, null, 0, v64, vcc_lo               // 0000001A01EC: D5207C04 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A01F4: 986A80C1
	global_load_d16_b16 v2, v[2:3], off                        // 0000001A01F8: DC820000 027C0002
	s_and_b32 s14, vcc_lo, exec_lo                             // 0000001A0200: 8B0E7E6A
	s_cselect_b32 s15, s1, s74                                 // 0000001A0204: 980F4A01
	s_cselect_b32 s14, s0, s73                                 // 0000001A0208: 980E4900
	s_add_u32 s0, s25, 0x240                                   // 0000001A020C: 8000FF19 00000240
	s_addc_u32 s1, s24, 0                                      // 0000001A0214: 82018018
	v_dual_cndmask_b32 v4, v129, v4 :: v_dual_cndmask_b32 v3, v128, v5// 0000001A0218: CA520981 04020B80
	.long 0xd7006a06                                           // 0000001A0220: D7006A06
	v_cndmask_b32_e32 v1, 0x10000, v17, vcc_lo                 // 0000001A0224: 020222FF 00010000
	s_cmp_gt_i32 s9, 3                                         // 0000001A022C: BF028309
	v_add_co_ci_u32_e64 v5, null, 0, v64, vcc_lo               // 0000001A0230: D5207C05 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0238: 986A80C1
	global_load_d16_b16 v3, v[3:4], off                        // 0000001A023C: DC820000 037C0003
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0244: 8B377E6A
	s_cselect_b32 s56, s0, s73                                 // 0000001A0248: 98384900
	.long 0xd7000008                                           // 0000001A024C: D7000008
	v_cndmask_b32_e32 v1, 0x15000, v17, vcc_lo                 // 0000001A0250: 020222FF 00015000
	s_cselect_b32 s57, s1, s74                                 // 0000001A0258: 98394A01
	s_add_u32 s1, s25, 0x300                                   // 0000001A025C: 8001FF19 00000300
	v_add_co_ci_u32_e64 v7, null, 0, v64, s0                   // 0000001A0264: D5207C07 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A026C: 82008018
	s_cmp_gt_i32 s9, 4                                         // 0000001A0270: BF028409
	v_dual_cndmask_b32 v5, v129, v5 :: v_dual_cndmask_b32 v4, v128, v6// 0000001A0274: CA520B81 05040D80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A027C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0280: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0284: 8B377E6A
	s_cselect_b32 s59, s0, s74                                 // 0000001A0288: 983B4A00
	.long 0xd7000009                                           // 0000001A028C: D7000009
	v_cndmask_b32_e32 v1, 0x1a000, v17, vcc_lo                 // 0000001A0290: 020222FF 0001A000
	s_cselect_b32 s58, s1, s73                                 // 0000001A0298: 983A4901
	s_add_u32 s1, s25, 0x3c0                                   // 0000001A029C: 8001FF19 000003C0
	v_add_co_ci_u32_e64 v10, null, 0, v64, s0                  // 0000001A02A4: D5207C0A 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A02AC: 82008018
	s_cmp_gt_i32 s9, 5                                         // 0000001A02B0: BF028509
	v_dual_cndmask_b32 v7, v129, v7 :: v_dual_cndmask_b32 v6, v128, v8// 0000001A02B4: CA520F81 07061180
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A02BC: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A02C0: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A02C4: 8B377E6A
	s_cselect_b32 s77, s0, s74                                 // 0000001A02C8: 984D4A00
	.long 0xd7000008                                           // 0000001A02CC: D7000008
	v_cndmask_b32_e32 v1, 0x1f000, v17, vcc_lo                 // 0000001A02D0: 020222FF 0001F000
	s_cselect_b32 s76, s1, s73                                 // 0000001A02D8: 984C4901
	s_add_u32 s1, s25, 0x480                                   // 0000001A02DC: 8001FF19 00000480
	v_add_co_ci_u32_e64 v11, null, 0, v64, s0                  // 0000001A02E4: D5207C0B 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A02EC: 82008018
	s_cmp_gt_i32 s9, 6                                         // 0000001A02F0: BF028609
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001A02F4: CA521581 0A081380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A02FC: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0300: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0304: 8B377E6A
	s_cselect_b32 s79, s0, s74                                 // 0000001A0308: 984F4A00
	.long 0xd700000d                                           // 0000001A030C: D700000D
	v_cndmask_b32_e32 v1, 0x24000, v17, vcc_lo                 // 0000001A0310: 020222FF 00024000
	s_cselect_b32 s78, s1, s73                                 // 0000001A0318: 984E4901
	s_add_u32 s55, s25, 0x540                                  // 0000001A031C: 8037FF19 00000540
	v_add_co_ci_u32_e64 v14, null, 0, v64, s0                  // 0000001A0324: D5207C0E 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A032C: 82008018
	s_cmp_gt_i32 s9, 7                                         // 0000001A0330: BF028709
	v_dual_cndmask_b32 v12, v129, v11 :: v_dual_cndmask_b32 v11, v128, v8// 0000001A0334: CA521781 0C0A1180
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A033C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0340: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001A0344: 8B017E6A
	s_cselect_b32 s1, s0, s74                                  // 0000001A0348: 98014A00
	s_cselect_b32 s0, s55, s73                                 // 0000001A034C: 98004937
	s_add_u32 s55, s25, 0x600                                  // 0000001A0350: 8037FF19 00000600
	v_dual_cndmask_b32 v14, v129, v14 :: v_dual_cndmask_b32 v13, v128, v13// 0000001A0358: CA521D81 0E0C1B80
	s_addc_u32 s63, s24, 0                                     // 0000001A0360: 823F8018
	global_load_d16_b16 v8, v[4:5], off                        // 0000001A0364: DC820000 087C0004
	global_load_d16_b16 v7, v[6:7], off                        // 0000001A036C: DC820000 077C0006
	global_load_d16_b16 v6, v[9:10], off                       // 0000001A0374: DC820000 067C0009
	global_load_d16_b16 v5, v[11:12], off                      // 0000001A037C: DC820000 057C000B
	global_load_d16_b16 v4, v[13:14], off                      // 0000001A0384: DC820000 047C000D
	s_cmp_gt_i32 s9, 8                                         // 0000001A038C: BF028809
	.long 0xd7006a09                                           // 0000001A0390: D7006A09
	v_cndmask_b32_e32 v1, 0x29000, v17, vcc_lo                 // 0000001A0394: 020222FF 00029000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A039C: BF870001
	v_add_co_ci_u32_e64 v10, null, 0, v64, vcc_lo              // 0000001A03A0: D5207C0A 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A03A8: 986A80C1
	s_clause 0x7                                               // 0000001A03AC: BF850007
	global_load_b32 v73, v107, s[10:11]                        // 0000001A03B0: DC520000 490A006B
	global_load_b32 v71, v107, s[12:13]                        // 0000001A03B8: DC520000 470C006B
	global_load_b32 v72, v107, s[14:15]                        // 0000001A03C0: DC520000 480E006B
	global_load_b32 v69, v107, s[56:57]                        // 0000001A03C8: DC520000 4538006B
	global_load_b32 v70, v107, s[58:59]                        // 0000001A03D0: DC520000 463A006B
	global_load_b32 v68, v107, s[76:77]                        // 0000001A03D8: DC520000 444C006B
	global_load_b32 v67, v107, s[78:79]                        // 0000001A03E0: DC520000 434E006B
	global_load_b32 v66, v107, s[0:1]                          // 0000001A03E8: DC520000 4200006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001A03F0: 8B007E6A
	s_cselect_b32 s11, s63, s74                                // 0000001A03F4: 980B4A3F
	s_cselect_b32 s10, s55, s73                                // 0000001A03F8: 980A4937
	s_add_u32 s0, s25, 0x6c0                                   // 0000001A03FC: 8000FF19 000006C0
	s_addc_u32 s1, s24, 0                                      // 0000001A0404: 82018018
	v_dual_cndmask_b32 v10, v129, v10 :: v_dual_cndmask_b32 v9, v128, v9// 0000001A0408: CA521581 0A081380
	.long 0xd7006a0c                                           // 0000001A0410: D7006A0C
	v_cndmask_b32_e32 v1, 0x2e000, v17, vcc_lo                 // 0000001A0414: 020222FF 0002E000
	s_cmp_gt_i32 s9, 9                                         // 0000001A041C: BF028909
	v_add_co_ci_u32_e64 v11, null, 0, v64, vcc_lo              // 0000001A0420: D5207C0B 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0428: 986A80C1
	global_load_d16_b16 v9, v[9:10], off                       // 0000001A042C: DC820000 097C0009
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001A0434: 8B0C7E6A
	s_cselect_b32 s13, s1, s74                                 // 0000001A0438: 980D4A01
	s_cselect_b32 s12, s0, s73                                 // 0000001A043C: 980C4900
	s_add_u32 s0, s25, 0x780                                   // 0000001A0440: 8000FF19 00000780
	s_addc_u32 s1, s24, 0                                      // 0000001A0448: 82018018
	v_dual_cndmask_b32 v11, v129, v11 :: v_dual_cndmask_b32 v10, v128, v12// 0000001A044C: CA521781 0B0A1980
	.long 0xd7006a0d                                           // 0000001A0454: D7006A0D
	v_cndmask_b32_e32 v1, 0x33000, v17, vcc_lo                 // 0000001A0458: 020222FF 00033000
	s_cmp_gt_i32 s9, 10                                        // 0000001A0460: BF028A09
	v_add_co_ci_u32_e64 v12, null, 0, v64, vcc_lo              // 0000001A0464: D5207C0C 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A046C: 986A80C1
	global_load_d16_b16 v10, v[10:11], off                     // 0000001A0470: DC820000 0A7C000A
	s_and_b32 s14, vcc_lo, exec_lo                             // 0000001A0478: 8B0E7E6A
	s_cselect_b32 s15, s1, s74                                 // 0000001A047C: 980F4A01
	s_cselect_b32 s14, s0, s73                                 // 0000001A0480: 980E4900
	s_add_u32 s0, s25, 0x840                                   // 0000001A0484: 8000FF19 00000840
	s_addc_u32 s1, s24, 0                                      // 0000001A048C: 82018018
	v_dual_cndmask_b32 v12, v129, v12 :: v_dual_cndmask_b32 v11, v128, v13// 0000001A0490: CA521981 0C0A1B80
	.long 0xd7006a0e                                           // 0000001A0498: D7006A0E
	v_cndmask_b32_e32 v1, 0x38000, v17, vcc_lo                 // 0000001A049C: 020222FF 00038000
	s_cmp_gt_i32 s9, 11                                        // 0000001A04A4: BF028B09
	v_add_co_ci_u32_e64 v13, null, 0, v64, vcc_lo              // 0000001A04A8: D5207C0D 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A04B0: 986A80C1
	global_load_d16_b16 v11, v[11:12], off                     // 0000001A04B4: DC820000 0B7C000B
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A04BC: 8B377E6A
	s_cselect_b32 s56, s0, s73                                 // 0000001A04C0: 98384900
	.long 0xd7000010                                           // 0000001A04C4: D7000010
	v_cndmask_b32_e32 v1, 0x3d000, v17, vcc_lo                 // 0000001A04C8: 020222FF 0003D000
	s_cselect_b32 s57, s1, s74                                 // 0000001A04D0: 98394A01
	s_add_u32 s1, s25, 0x900                                   // 0000001A04D4: 8001FF19 00000900
	v_add_co_ci_u32_e64 v15, null, 0, v64, s0                  // 0000001A04DC: D5207C0F 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A04E4: 82008018
	s_cmp_gt_i32 s9, 12                                        // 0000001A04E8: BF028C09
	v_dual_cndmask_b32 v13, v129, v13 :: v_dual_cndmask_b32 v12, v128, v14// 0000001A04EC: CA521B81 0D0C1D80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A04F4: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A04F8: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A04FC: 8B377E6A
	s_cselect_b32 s59, s0, s74                                 // 0000001A0500: 983B4A00
	.long 0xd7000012                                           // 0000001A0504: D7000012
	v_cndmask_b32_e32 v1, 0x42000, v17, vcc_lo                 // 0000001A0508: 020222FF 00042000
	s_cselect_b32 s58, s1, s73                                 // 0000001A0510: 983A4901
	s_add_u32 s1, s25, 0x9c0                                   // 0000001A0514: 8001FF19 000009C0
	v_add_co_ci_u32_e64 v19, null, 0, v64, s0                  // 0000001A051C: D5207C13 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A0524: 82008018
	s_cmp_gt_i32 s9, 13                                        // 0000001A0528: BF028D09
	v_dual_cndmask_b32 v15, v129, v15 :: v_dual_cndmask_b32 v14, v128, v16// 0000001A052C: CA521F81 0F0E2180
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0534: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0538: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A053C: 8B377E6A
	s_cselect_b32 s77, s0, s74                                 // 0000001A0540: 984D4A00
	.long 0xd7000010                                           // 0000001A0544: D7000010
	v_cndmask_b32_e32 v1, 0x47000, v17, vcc_lo                 // 0000001A0548: 020222FF 00047000
	s_cselect_b32 s76, s1, s73                                 // 0000001A0550: 984C4901
	s_add_u32 s1, s25, 0xa80                                   // 0000001A0554: 8001FF19 00000A80
	v_add_co_ci_u32_e64 v20, null, 0, v64, s0                  // 0000001A055C: D5207C14 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A0564: 82008018
	s_cmp_gt_i32 s9, 14                                        // 0000001A0568: BF028E09
	v_dual_cndmask_b32 v19, v129, v19 :: v_dual_cndmask_b32 v18, v128, v18// 0000001A056C: CA522781 13122580
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0574: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0578: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A057C: 8B377E6A
	s_cselect_b32 s79, s0, s74                                 // 0000001A0580: 984F4A00
	.long 0xd7000016                                           // 0000001A0584: D7000016
	v_cndmask_b32_e32 v1, 0x4c000, v17, vcc_lo                 // 0000001A0588: 020222FF 0004C000
	s_cselect_b32 s78, s1, s73                                 // 0000001A0590: 984E4901
	s_add_u32 s55, s25, 0xb40                                  // 0000001A0594: 8037FF19 00000B40
	v_add_co_ci_u32_e64 v23, null, 0, v64, s0                  // 0000001A059C: D5207C17 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A05A4: 82008018
	s_cmp_gt_i32 s9, 15                                        // 0000001A05A8: BF028F09
	v_cndmask_b32_e32 v21, v129, v20, vcc_lo                   // 0000001A05AC: 022A2981
	v_cndmask_b32_e32 v20, v128, v16, vcc_lo                   // 0000001A05B0: 02282180
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A05B4: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A05B8: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001A05BC: 8B017E6A
	s_cselect_b32 s1, s0, s74                                  // 0000001A05C0: 98014A00
	s_cselect_b32 s0, s55, s73                                 // 0000001A05C4: 98004937
	s_add_u32 s55, s25, 0xc00                                  // 0000001A05C8: 8037FF19 00000C00
	v_dual_cndmask_b32 v23, v129, v23 :: v_dual_cndmask_b32 v22, v128, v22// 0000001A05D0: CA522F81 17162D80
	s_addc_u32 s63, s24, 0                                     // 0000001A05D8: 823F8018
	global_load_d16_b16 v16, v[12:13], off                     // 0000001A05DC: DC820000 107C000C
	global_load_d16_b16 v15, v[14:15], off                     // 0000001A05E4: DC820000 0F7C000E
	global_load_d16_b16 v14, v[18:19], off                     // 0000001A05EC: DC820000 0E7C0012
	global_load_d16_b16 v13, v[20:21], off                     // 0000001A05F4: DC820000 0D7C0014
	global_load_d16_b16 v12, v[22:23], off                     // 0000001A05FC: DC820000 0C7C0016
	s_cmp_gt_i32 s9, 16                                        // 0000001A0604: BF029009
	.long 0xd7006a12                                           // 0000001A0608: D7006A12
	v_cndmask_b32_e32 v1, 0x51000, v17, vcc_lo                 // 0000001A060C: 020222FF 00051000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A0614: BF870001
	v_add_co_ci_u32_e64 v19, null, 0, v64, vcc_lo              // 0000001A0618: D5207C13 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0620: 986A80C1
	s_clause 0x7                                               // 0000001A0624: BF850007
	global_load_b32 v80, v107, s[10:11]                        // 0000001A0628: DC520000 500A006B
	global_load_b32 v81, v107, s[12:13]                        // 0000001A0630: DC520000 510C006B
	global_load_b32 v79, v107, s[14:15]                        // 0000001A0638: DC520000 4F0E006B
	global_load_b32 v78, v107, s[56:57]                        // 0000001A0640: DC520000 4E38006B
	global_load_b32 v77, v107, s[58:59]                        // 0000001A0648: DC520000 4D3A006B
	global_load_b32 v75, v107, s[76:77]                        // 0000001A0650: DC520000 4B4C006B
	global_load_b32 v76, v107, s[78:79]                        // 0000001A0658: DC520000 4C4E006B
	global_load_b32 v74, v107, s[0:1]                          // 0000001A0660: DC520000 4A00006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001A0668: 8B007E6A
	s_cselect_b32 s11, s63, s74                                // 0000001A066C: 980B4A3F
	s_cselect_b32 s10, s55, s73                                // 0000001A0670: 980A4937
	s_add_u32 s0, s25, 0xcc0                                   // 0000001A0674: 8000FF19 00000CC0
	s_addc_u32 s1, s24, 0                                      // 0000001A067C: 82018018
	v_dual_cndmask_b32 v19, v129, v19 :: v_dual_cndmask_b32 v18, v128, v18// 0000001A0680: CA522781 13122580
	.long 0xd7006a15                                           // 0000001A0688: D7006A15
	v_cndmask_b32_e32 v1, 0x56000, v17, vcc_lo                 // 0000001A068C: 020222FF 00056000
	s_cmp_gt_i32 s9, 17                                        // 0000001A0694: BF029109
	v_add_co_ci_u32_e64 v20, null, 0, v64, vcc_lo              // 0000001A0698: D5207C14 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A06A0: 986A80C1
	global_load_d16_b16 v18, v[18:19], off                     // 0000001A06A4: DC820000 127C0012
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001A06AC: 8B0C7E6A
	s_cselect_b32 s13, s1, s74                                 // 0000001A06B0: 980D4A01
	s_cselect_b32 s12, s0, s73                                 // 0000001A06B4: 980C4900
	s_add_u32 s0, s25, 0xd80                                   // 0000001A06B8: 8000FF19 00000D80
	s_addc_u32 s1, s24, 0                                      // 0000001A06C0: 82018018
	v_dual_cndmask_b32 v20, v129, v20 :: v_dual_cndmask_b32 v19, v128, v21// 0000001A06C4: CA522981 14122B80
	.long 0xd7006a16                                           // 0000001A06CC: D7006A16
	v_cndmask_b32_e32 v1, 0x5b000, v17, vcc_lo                 // 0000001A06D0: 020222FF 0005B000
	s_cmp_gt_i32 s9, 18                                        // 0000001A06D8: BF029209
	v_add_co_ci_u32_e64 v21, null, 0, v64, vcc_lo              // 0000001A06DC: D5207C15 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A06E4: 986A80C1
	global_load_d16_b16 v19, v[19:20], off                     // 0000001A06E8: DC820000 137C0013
	s_and_b32 s14, vcc_lo, exec_lo                             // 0000001A06F0: 8B0E7E6A
	s_cselect_b32 s15, s1, s74                                 // 0000001A06F4: 980F4A01
	s_cselect_b32 s14, s0, s73                                 // 0000001A06F8: 980E4900
	s_add_u32 s0, s25, 0xe40                                   // 0000001A06FC: 8000FF19 00000E40
	s_addc_u32 s1, s24, 0                                      // 0000001A0704: 82018018
	v_dual_cndmask_b32 v21, v129, v21 :: v_dual_cndmask_b32 v20, v128, v22// 0000001A0708: CA522B81 15142D80
	.long 0xd7006a17                                           // 0000001A0710: D7006A17
	v_cndmask_b32_e32 v1, 0x60000, v17, vcc_lo                 // 0000001A0714: 020222FF 00060000
	s_cmp_gt_i32 s9, 19                                        // 0000001A071C: BF029309
	v_add_co_ci_u32_e64 v22, null, 0, v64, vcc_lo              // 0000001A0720: D5207C16 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0728: 986A80C1
	global_load_d16_b16 v20, v[20:21], off                     // 0000001A072C: DC820000 147C0014
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0734: 8B377E6A
	s_cselect_b32 s56, s0, s73                                 // 0000001A0738: 98384900
	.long 0xd7000019                                           // 0000001A073C: D7000019
	v_cndmask_b32_e32 v1, 0x65000, v17, vcc_lo                 // 0000001A0740: 020222FF 00065000
	s_cselect_b32 s57, s1, s74                                 // 0000001A0748: 98394A01
	s_add_u32 s1, s25, 0xf00                                   // 0000001A074C: 8001FF19 00000F00
	v_add_co_ci_u32_e64 v24, null, 0, v64, s0                  // 0000001A0754: D5207C18 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A075C: 82008018
	s_cmp_gt_i32 s9, 20                                        // 0000001A0760: BF029409
	v_dual_cndmask_b32 v22, v129, v22 :: v_dual_cndmask_b32 v21, v128, v23// 0000001A0764: CA522D81 16142F80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A076C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0770: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0774: 8B377E6A
	s_cselect_b32 s59, s0, s74                                 // 0000001A0778: 983B4A00
	.long 0xd700001a                                           // 0000001A077C: D700001A
	v_cndmask_b32_e32 v1, 0x6a000, v17, vcc_lo                 // 0000001A0780: 020222FF 0006A000
	s_cselect_b32 s58, s1, s73                                 // 0000001A0788: 983A4901
	s_add_u32 s1, s25, 0xfc0                                   // 0000001A078C: 8001FF19 00000FC0
	v_add_co_ci_u32_e64 v27, null, 0, v64, s0                  // 0000001A0794: D5207C1B 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A079C: 82008018
	s_cmp_gt_i32 s9, 21                                        // 0000001A07A0: BF029509
	v_dual_cndmask_b32 v24, v129, v24 :: v_dual_cndmask_b32 v23, v128, v25// 0000001A07A4: CA523181 18163380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A07AC: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A07B0: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A07B4: 8B377E6A
	s_cselect_b32 s77, s0, s74                                 // 0000001A07B8: 984D4A00
	.long 0xd7000019                                           // 0000001A07BC: D7000019
	v_cndmask_b32_e32 v1, 0x6f000, v17, vcc_lo                 // 0000001A07C0: 020222FF 0006F000
	s_cselect_b32 s76, s1, s73                                 // 0000001A07C8: 984C4901
	s_add_u32 s1, s25, 0x1080                                  // 0000001A07CC: 8001FF19 00001080
	v_add_co_ci_u32_e64 v28, null, 0, v64, s0                  // 0000001A07D4: D5207C1C 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A07DC: 82008018
	s_cmp_gt_i32 s9, 22                                        // 0000001A07E0: BF029609
	v_dual_cndmask_b32 v27, v129, v27 :: v_dual_cndmask_b32 v26, v128, v26// 0000001A07E4: CA523781 1B1A3580
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A07EC: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A07F0: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A07F4: 8B377E6A
	s_cselect_b32 s79, s0, s74                                 // 0000001A07F8: 984F4A00
	.long 0xd700001e                                           // 0000001A07FC: D700001E
	v_cndmask_b32_e32 v1, 0x74000, v17, vcc_lo                 // 0000001A0800: 020222FF 00074000
	s_cselect_b32 s78, s1, s73                                 // 0000001A0808: 984E4901
	s_add_u32 s55, s25, 0x1140                                 // 0000001A080C: 8037FF19 00001140
	v_add_co_ci_u32_e64 v31, null, 0, v64, s0                  // 0000001A0814: D5207C1F 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A081C: 82008018
	s_cmp_gt_i32 s9, 23                                        // 0000001A0820: BF029709
	v_dual_cndmask_b32 v29, v129, v28 :: v_dual_cndmask_b32 v28, v128, v25// 0000001A0824: CA523981 1D1C3380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A082C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0830: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001A0834: 8B017E6A
	s_cselect_b32 s1, s0, s74                                  // 0000001A0838: 98014A00
	s_cselect_b32 s0, s55, s73                                 // 0000001A083C: 98004937
	s_add_u32 s55, s25, 0x1200                                 // 0000001A0840: 8037FF19 00001200
	v_dual_cndmask_b32 v31, v129, v31 :: v_dual_cndmask_b32 v30, v128, v30// 0000001A0848: CA523F81 1F1E3D80
	s_addc_u32 s63, s24, 0                                     // 0000001A0850: 823F8018
	global_load_d16_b16 v25, v[21:22], off                     // 0000001A0854: DC820000 197C0015
	global_load_d16_b16 v24, v[23:24], off                     // 0000001A085C: DC820000 187C0017
	global_load_d16_b16 v23, v[26:27], off                     // 0000001A0864: DC820000 177C001A
	global_load_d16_b16 v22, v[28:29], off                     // 0000001A086C: DC820000 167C001C
	global_load_d16_b16 v21, v[30:31], off                     // 0000001A0874: DC820000 157C001E
	s_cmp_gt_i32 s9, 24                                        // 0000001A087C: BF029809
	.long 0xd7006a1a                                           // 0000001A0880: D7006A1A
	v_cndmask_b32_e32 v1, 0x79000, v17, vcc_lo                 // 0000001A0884: 020222FF 00079000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A088C: BF870001
	v_add_co_ci_u32_e64 v27, null, 0, v64, vcc_lo              // 0000001A0890: D5207C1B 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0898: 986A80C1
	s_clause 0x7                                               // 0000001A089C: BF850007
	global_load_b32 v89, v107, s[10:11]                        // 0000001A08A0: DC520000 590A006B
	global_load_b32 v88, v107, s[12:13]                        // 0000001A08A8: DC520000 580C006B
	global_load_b32 v86, v107, s[14:15]                        // 0000001A08B0: DC520000 560E006B
	global_load_b32 v87, v107, s[56:57]                        // 0000001A08B8: DC520000 5738006B
	global_load_b32 v85, v107, s[58:59]                        // 0000001A08C0: DC520000 553A006B
	global_load_b32 v84, v107, s[76:77]                        // 0000001A08C8: DC520000 544C006B
	global_load_b32 v83, v107, s[78:79]                        // 0000001A08D0: DC520000 534E006B
	global_load_b32 v82, v107, s[0:1]                          // 0000001A08D8: DC520000 5200006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001A08E0: 8B007E6A
	s_cselect_b32 s11, s63, s74                                // 0000001A08E4: 980B4A3F
	s_cselect_b32 s10, s55, s73                                // 0000001A08E8: 980A4937
	s_add_u32 s0, s25, 0x12c0                                  // 0000001A08EC: 8000FF19 000012C0
	s_addc_u32 s1, s24, 0                                      // 0000001A08F4: 82018018
	v_dual_cndmask_b32 v27, v129, v27 :: v_dual_cndmask_b32 v26, v128, v26// 0000001A08F8: CA523781 1B1A3580
	.long 0xd7006a1d                                           // 0000001A0900: D7006A1D
	v_cndmask_b32_e32 v1, 0x7e000, v17, vcc_lo                 // 0000001A0904: 020222FF 0007E000
	s_cmp_gt_i32 s9, 25                                        // 0000001A090C: BF029909
	v_add_co_ci_u32_e64 v28, null, 0, v64, vcc_lo              // 0000001A0910: D5207C1C 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0918: 986A80C1
	global_load_d16_b16 v26, v[26:27], off                     // 0000001A091C: DC820000 1A7C001A
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001A0924: 8B0C7E6A
	s_cselect_b32 s13, s1, s74                                 // 0000001A0928: 980D4A01
	s_cselect_b32 s12, s0, s73                                 // 0000001A092C: 980C4900
	s_add_u32 s0, s25, 0x1380                                  // 0000001A0930: 8000FF19 00001380
	s_addc_u32 s1, s24, 0                                      // 0000001A0938: 82018018
	v_dual_cndmask_b32 v28, v129, v28 :: v_dual_cndmask_b32 v27, v128, v29// 0000001A093C: CA523981 1C1A3B80
	.long 0xd7006a1e                                           // 0000001A0944: D7006A1E
	v_cndmask_b32_e32 v1, 0x83000, v17, vcc_lo                 // 0000001A0948: 020222FF 00083000
	s_cmp_gt_i32 s9, 26                                        // 0000001A0950: BF029A09
	v_add_co_ci_u32_e64 v29, null, 0, v64, vcc_lo              // 0000001A0954: D5207C1D 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A095C: 986A80C1
	global_load_d16_b16 v27, v[27:28], off                     // 0000001A0960: DC820000 1B7C001B
	s_and_b32 s14, vcc_lo, exec_lo                             // 0000001A0968: 8B0E7E6A
	s_cselect_b32 s15, s1, s74                                 // 0000001A096C: 980F4A01
	s_cselect_b32 s14, s0, s73                                 // 0000001A0970: 980E4900
	s_add_u32 s0, s25, 0x1440                                  // 0000001A0974: 8000FF19 00001440
	s_addc_u32 s1, s24, 0                                      // 0000001A097C: 82018018
	v_dual_cndmask_b32 v29, v129, v29 :: v_dual_cndmask_b32 v28, v128, v30// 0000001A0980: CA523B81 1D1C3D80
	.long 0xd7006a1f                                           // 0000001A0988: D7006A1F
	v_cndmask_b32_e32 v1, 0x88000, v17, vcc_lo                 // 0000001A098C: 020222FF 00088000
	s_cmp_gt_i32 s9, 27                                        // 0000001A0994: BF029B09
	v_add_co_ci_u32_e64 v30, null, 0, v64, vcc_lo              // 0000001A0998: D5207C1E 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A09A0: 986A80C1
	global_load_d16_b16 v28, v[28:29], off                     // 0000001A09A4: DC820000 1C7C001C
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A09AC: 8B377E6A
	s_cselect_b32 s56, s0, s73                                 // 0000001A09B0: 98384900
	.long 0xd7000021                                           // 0000001A09B4: D7000021
	v_cndmask_b32_e32 v1, 0x8d000, v17, vcc_lo                 // 0000001A09B8: 020222FF 0008D000
	s_cselect_b32 s57, s1, s74                                 // 0000001A09C0: 98394A01
	s_add_u32 s1, s25, 0x1500                                  // 0000001A09C4: 8001FF19 00001500
	v_add_co_ci_u32_e64 v32, null, 0, v64, s0                  // 0000001A09CC: D5207C20 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A09D4: 82008018
	s_cmp_gt_i32 s9, 28                                        // 0000001A09D8: BF029C09
	v_dual_cndmask_b32 v30, v129, v30 :: v_dual_cndmask_b32 v29, v128, v31// 0000001A09DC: CA523D81 1E1C3F80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A09E4: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A09E8: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A09EC: 8B377E6A
	s_cselect_b32 s59, s0, s74                                 // 0000001A09F0: 983B4A00
	.long 0xd7000022                                           // 0000001A09F4: D7000022
	v_cndmask_b32_e32 v1, 0x92000, v17, vcc_lo                 // 0000001A09F8: 020222FF 00092000
	s_cselect_b32 s58, s1, s73                                 // 0000001A0A00: 983A4901
	s_add_u32 s1, s25, 0x15c0                                  // 0000001A0A04: 8001FF19 000015C0
	v_add_co_ci_u32_e64 v35, null, 0, v64, s0                  // 0000001A0A0C: D5207C23 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A0A14: 82008018
	s_cmp_gt_i32 s9, 29                                        // 0000001A0A18: BF029D09
	v_dual_cndmask_b32 v32, v129, v32 :: v_dual_cndmask_b32 v31, v128, v33// 0000001A0A1C: CA524181 201E4380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0A24: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0A28: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0A2C: 8B377E6A
	s_cselect_b32 s77, s0, s74                                 // 0000001A0A30: 984D4A00
	.long 0xd7000021                                           // 0000001A0A34: D7000021
	v_cndmask_b32_e32 v1, 0x97000, v17, vcc_lo                 // 0000001A0A38: 020222FF 00097000
	s_cselect_b32 s76, s1, s73                                 // 0000001A0A40: 984C4901
	s_add_u32 s1, s25, 0x1680                                  // 0000001A0A44: 8001FF19 00001680
	v_add_co_ci_u32_e64 v36, null, 0, v64, s0                  // 0000001A0A4C: D5207C24 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A0A54: 82008018
	s_cmp_gt_i32 s9, 30                                        // 0000001A0A58: BF029E09
	v_dual_cndmask_b32 v35, v129, v35 :: v_dual_cndmask_b32 v34, v128, v34// 0000001A0A5C: CA524781 23224580
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0A64: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0A68: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0A6C: 8B377E6A
	s_cselect_b32 s79, s0, s74                                 // 0000001A0A70: 984F4A00
	.long 0xd7000026                                           // 0000001A0A74: D7000026
	v_cndmask_b32_e32 v1, 0x9c000, v17, vcc_lo                 // 0000001A0A78: 020222FF 0009C000
	s_cselect_b32 s78, s1, s73                                 // 0000001A0A80: 984E4901
	s_add_u32 s55, s25, 0x1740                                 // 0000001A0A84: 8037FF19 00001740
	v_add_co_ci_u32_e64 v39, null, 0, v64, s0                  // 0000001A0A8C: D5207C27 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A0A94: 82008018
	s_cmp_gt_i32 s9, 31                                        // 0000001A0A98: BF029F09
	v_dual_cndmask_b32 v37, v129, v36 :: v_dual_cndmask_b32 v36, v128, v33// 0000001A0A9C: CA524981 25244380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0AA4: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0AA8: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001A0AAC: 8B017E6A
	s_cselect_b32 s1, s0, s74                                  // 0000001A0AB0: 98014A00
	s_cselect_b32 s0, s55, s73                                 // 0000001A0AB4: 98004937
	s_add_u32 s55, s25, 0x1800                                 // 0000001A0AB8: 8037FF19 00001800
	v_dual_cndmask_b32 v39, v129, v39 :: v_dual_cndmask_b32 v38, v128, v38// 0000001A0AC0: CA524F81 27264D80
	s_addc_u32 s63, s24, 0                                     // 0000001A0AC8: 823F8018
	global_load_d16_b16 v33, v[29:30], off                     // 0000001A0ACC: DC820000 217C001D
	global_load_d16_b16 v32, v[31:32], off                     // 0000001A0AD4: DC820000 207C001F
	global_load_d16_b16 v31, v[34:35], off                     // 0000001A0ADC: DC820000 1F7C0022
	global_load_d16_b16 v30, v[36:37], off                     // 0000001A0AE4: DC820000 1E7C0024
	global_load_d16_b16 v29, v[38:39], off                     // 0000001A0AEC: DC820000 1D7C0026
	s_cmp_gt_i32 s9, 32                                        // 0000001A0AF4: BF02A009
	.long 0xd7006a22                                           // 0000001A0AF8: D7006A22
	v_cndmask_b32_e32 v1, 0xa1000, v17, vcc_lo                 // 0000001A0AFC: 020222FF 000A1000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A0B04: BF870001
	v_add_co_ci_u32_e64 v35, null, 0, v64, vcc_lo              // 0000001A0B08: D5207C23 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0B10: 986A80C1
	s_clause 0x7                                               // 0000001A0B14: BF850007
	global_load_b32 v97, v107, s[10:11]                        // 0000001A0B18: DC520000 610A006B
	global_load_b32 v96, v107, s[12:13]                        // 0000001A0B20: DC520000 600C006B
	global_load_b32 v95, v107, s[14:15]                        // 0000001A0B28: DC520000 5F0E006B
	global_load_b32 v94, v107, s[56:57]                        // 0000001A0B30: DC520000 5E38006B
	global_load_b32 v92, v107, s[58:59]                        // 0000001A0B38: DC520000 5C3A006B
	global_load_b32 v93, v107, s[76:77]                        // 0000001A0B40: DC520000 5D4C006B
	global_load_b32 v91, v107, s[78:79]                        // 0000001A0B48: DC520000 5B4E006B
	global_load_b32 v90, v107, s[0:1]                          // 0000001A0B50: DC520000 5A00006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001A0B58: 8B007E6A
	s_cselect_b32 s11, s63, s74                                // 0000001A0B5C: 980B4A3F
	s_cselect_b32 s10, s55, s73                                // 0000001A0B60: 980A4937
	s_add_u32 s0, s25, 0x18c0                                  // 0000001A0B64: 8000FF19 000018C0
	s_addc_u32 s1, s24, 0                                      // 0000001A0B6C: 82018018
	v_dual_cndmask_b32 v35, v129, v35 :: v_dual_cndmask_b32 v34, v128, v34// 0000001A0B70: CA524781 23224580
	.long 0xd7006a25                                           // 0000001A0B78: D7006A25
	v_cndmask_b32_e32 v1, 0xa6000, v17, vcc_lo                 // 0000001A0B7C: 020222FF 000A6000
	s_cmp_gt_i32 s9, 33                                        // 0000001A0B84: BF02A109
	v_add_co_ci_u32_e64 v36, null, 0, v64, vcc_lo              // 0000001A0B88: D5207C24 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0B90: 986A80C1
	global_load_d16_b16 v34, v[34:35], off                     // 0000001A0B94: DC820000 227C0022
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001A0B9C: 8B0C7E6A
	s_cselect_b32 s13, s1, s74                                 // 0000001A0BA0: 980D4A01
	s_cselect_b32 s12, s0, s73                                 // 0000001A0BA4: 980C4900
	s_add_u32 s0, s25, 0x1980                                  // 0000001A0BA8: 8000FF19 00001980
	s_addc_u32 s1, s24, 0                                      // 0000001A0BB0: 82018018
	v_dual_cndmask_b32 v36, v129, v36 :: v_dual_cndmask_b32 v35, v128, v37// 0000001A0BB4: CA524981 24224B80
	.long 0xd7006a26                                           // 0000001A0BBC: D7006A26
	v_cndmask_b32_e32 v1, 0xab000, v17, vcc_lo                 // 0000001A0BC0: 020222FF 000AB000
	s_cmp_gt_i32 s9, 34                                        // 0000001A0BC8: BF02A209
	v_add_co_ci_u32_e64 v37, null, 0, v64, vcc_lo              // 0000001A0BCC: D5207C25 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0BD4: 986A80C1
	global_load_d16_b16 v35, v[35:36], off                     // 0000001A0BD8: DC820000 237C0023
	s_and_b32 s14, vcc_lo, exec_lo                             // 0000001A0BE0: 8B0E7E6A
	s_cselect_b32 s15, s1, s74                                 // 0000001A0BE4: 980F4A01
	s_cselect_b32 s14, s0, s73                                 // 0000001A0BE8: 980E4900
	s_add_u32 s0, s25, 0x1a40                                  // 0000001A0BEC: 8000FF19 00001A40
	s_addc_u32 s1, s24, 0                                      // 0000001A0BF4: 82018018
	v_dual_cndmask_b32 v37, v129, v37 :: v_dual_cndmask_b32 v36, v128, v38// 0000001A0BF8: CA524B81 25244D80
	.long 0xd7006a27                                           // 0000001A0C00: D7006A27
	v_cndmask_b32_e32 v1, 0xb0000, v17, vcc_lo                 // 0000001A0C04: 020222FF 000B0000
	s_cmp_gt_i32 s9, 35                                        // 0000001A0C0C: BF02A309
	v_add_co_ci_u32_e64 v38, null, 0, v64, vcc_lo              // 0000001A0C10: D5207C26 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0C18: 986A80C1
	global_load_d16_b16 v36, v[36:37], off                     // 0000001A0C1C: DC820000 247C0024
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0C24: 8B377E6A
	s_cselect_b32 s56, s0, s73                                 // 0000001A0C28: 98384900
	.long 0xd7000029                                           // 0000001A0C2C: D7000029
	v_cndmask_b32_e32 v1, 0xb5000, v17, vcc_lo                 // 0000001A0C30: 020222FF 000B5000
	s_cselect_b32 s57, s1, s74                                 // 0000001A0C38: 98394A01
	s_add_u32 s1, s25, 0x1b00                                  // 0000001A0C3C: 8001FF19 00001B00
	v_add_co_ci_u32_e64 v40, null, 0, v64, s0                  // 0000001A0C44: D5207C28 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A0C4C: 82008018
	s_cmp_gt_i32 s9, 36                                        // 0000001A0C50: BF02A409
	v_dual_cndmask_b32 v38, v129, v38 :: v_dual_cndmask_b32 v37, v128, v39// 0000001A0C54: CA524D81 26244F80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0C5C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0C60: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0C64: 8B377E6A
	s_cselect_b32 s59, s0, s74                                 // 0000001A0C68: 983B4A00
	.long 0xd700002a                                           // 0000001A0C6C: D700002A
	v_cndmask_b32_e32 v1, 0xba000, v17, vcc_lo                 // 0000001A0C70: 020222FF 000BA000
	s_cselect_b32 s58, s1, s73                                 // 0000001A0C78: 983A4901
	s_add_u32 s1, s25, 0x1bc0                                  // 0000001A0C7C: 8001FF19 00001BC0
	v_add_co_ci_u32_e64 v43, null, 0, v64, s0                  // 0000001A0C84: D5207C2B 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A0C8C: 82008018
	s_cmp_gt_i32 s9, 37                                        // 0000001A0C90: BF02A509
	v_dual_cndmask_b32 v40, v129, v40 :: v_dual_cndmask_b32 v39, v128, v41// 0000001A0C94: CA525181 28265380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0C9C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0CA0: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0CA4: 8B377E6A
	s_cselect_b32 s77, s0, s74                                 // 0000001A0CA8: 984D4A00
	.long 0xd7000029                                           // 0000001A0CAC: D7000029
	v_cndmask_b32_e32 v1, 0xbf000, v17, vcc_lo                 // 0000001A0CB0: 020222FF 000BF000
	s_cselect_b32 s76, s1, s73                                 // 0000001A0CB8: 984C4901
	s_add_u32 s1, s25, 0x1c80                                  // 0000001A0CBC: 8001FF19 00001C80
	v_add_co_ci_u32_e64 v44, null, 0, v64, s0                  // 0000001A0CC4: D5207C2C 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A0CCC: 82008018
	s_cmp_gt_i32 s9, 38                                        // 0000001A0CD0: BF02A609
	v_dual_cndmask_b32 v43, v129, v43 :: v_dual_cndmask_b32 v42, v128, v42// 0000001A0CD4: CA525781 2B2A5580
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0CDC: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0CE0: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0CE4: 8B377E6A
	s_cselect_b32 s79, s0, s74                                 // 0000001A0CE8: 984F4A00
	.long 0xd700002e                                           // 0000001A0CEC: D700002E
	v_cndmask_b32_e32 v1, 0xc4000, v17, vcc_lo                 // 0000001A0CF0: 020222FF 000C4000
	s_cselect_b32 s78, s1, s73                                 // 0000001A0CF8: 984E4901
	s_add_u32 s55, s25, 0x1d40                                 // 0000001A0CFC: 8037FF19 00001D40
	v_add_co_ci_u32_e64 v47, null, 0, v64, s0                  // 0000001A0D04: D5207C2F 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A0D0C: 82008018
	s_cmp_gt_i32 s9, 39                                        // 0000001A0D10: BF02A709
	v_dual_cndmask_b32 v45, v129, v44 :: v_dual_cndmask_b32 v44, v128, v41// 0000001A0D14: CA525981 2D2C5380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0D1C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0D20: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001A0D24: 8B017E6A
	s_cselect_b32 s1, s0, s74                                  // 0000001A0D28: 98014A00
	s_cselect_b32 s0, s55, s73                                 // 0000001A0D2C: 98004937
	s_add_u32 s55, s25, 0x1e00                                 // 0000001A0D30: 8037FF19 00001E00
	v_dual_cndmask_b32 v47, v129, v47 :: v_dual_cndmask_b32 v46, v128, v46// 0000001A0D38: CA525F81 2F2E5D80
	s_addc_u32 s63, s24, 0                                     // 0000001A0D40: 823F8018
	global_load_d16_b16 v41, v[37:38], off                     // 0000001A0D44: DC820000 297C0025
	global_load_d16_b16 v40, v[39:40], off                     // 0000001A0D4C: DC820000 287C0027
	global_load_d16_b16 v39, v[42:43], off                     // 0000001A0D54: DC820000 277C002A
	global_load_d16_b16 v37, v[44:45], off                     // 0000001A0D5C: DC820000 257C002C
	global_load_d16_b16 v38, v[46:47], off                     // 0000001A0D64: DC820000 267C002E
	s_cmp_gt_i32 s9, 40                                        // 0000001A0D6C: BF02A809
	.long 0xd7006a2a                                           // 0000001A0D70: D7006A2A
	v_cndmask_b32_e32 v1, 0xc9000, v17, vcc_lo                 // 0000001A0D74: 020222FF 000C9000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A0D7C: BF870001
	v_add_co_ci_u32_e64 v43, null, 0, v64, vcc_lo              // 0000001A0D80: D5207C2B 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0D88: 986A80C1
	s_clause 0x7                                               // 0000001A0D8C: BF850007
	global_load_b32 v105, v107, s[10:11]                       // 0000001A0D90: DC520000 690A006B
	global_load_b32 v103, v107, s[12:13]                       // 0000001A0D98: DC520000 670C006B
	global_load_b32 v104, v107, s[14:15]                       // 0000001A0DA0: DC520000 680E006B
	global_load_b32 v102, v107, s[56:57]                       // 0000001A0DA8: DC520000 6638006B
	global_load_b32 v101, v107, s[58:59]                       // 0000001A0DB0: DC520000 653A006B
	global_load_b32 v100, v107, s[76:77]                       // 0000001A0DB8: DC520000 644C006B
	global_load_b32 v98, v107, s[78:79]                        // 0000001A0DC0: DC520000 624E006B
	global_load_b32 v99, v107, s[0:1]                          // 0000001A0DC8: DC520000 6300006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001A0DD0: 8B007E6A
	s_cselect_b32 s11, s63, s74                                // 0000001A0DD4: 980B4A3F
	s_cselect_b32 s10, s55, s73                                // 0000001A0DD8: 980A4937
	s_add_u32 s0, s25, 0x1ec0                                  // 0000001A0DDC: 8000FF19 00001EC0
	s_addc_u32 s1, s24, 0                                      // 0000001A0DE4: 82018018
	v_dual_cndmask_b32 v43, v129, v43 :: v_dual_cndmask_b32 v42, v128, v42// 0000001A0DE8: CA525781 2B2A5580
	.long 0xd7006a2d                                           // 0000001A0DF0: D7006A2D
	v_cndmask_b32_e32 v1, 0xce000, v17, vcc_lo                 // 0000001A0DF4: 020222FF 000CE000
	s_cmp_gt_i32 s9, 41                                        // 0000001A0DFC: BF02A909
	v_add_co_ci_u32_e64 v44, null, 0, v64, vcc_lo              // 0000001A0E00: D5207C2C 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0E08: 986A80C1
	global_load_d16_b16 v42, v[42:43], off                     // 0000001A0E0C: DC820000 2A7C002A
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001A0E14: 8B0C7E6A
	s_cselect_b32 s13, s1, s74                                 // 0000001A0E18: 980D4A01
	s_cselect_b32 s12, s0, s73                                 // 0000001A0E1C: 980C4900
	s_add_u32 s0, s25, 0x1f80                                  // 0000001A0E20: 8000FF19 00001F80
	s_addc_u32 s1, s24, 0                                      // 0000001A0E28: 82018018
	v_dual_cndmask_b32 v44, v129, v44 :: v_dual_cndmask_b32 v43, v128, v45// 0000001A0E2C: CA525981 2C2A5B80
	.long 0xd7006a2e                                           // 0000001A0E34: D7006A2E
	v_cndmask_b32_e32 v1, 0xd3000, v17, vcc_lo                 // 0000001A0E38: 020222FF 000D3000
	s_cmp_gt_i32 s9, 42                                        // 0000001A0E40: BF02AA09
	v_add_co_ci_u32_e64 v45, null, 0, v64, vcc_lo              // 0000001A0E44: D5207C2D 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0E4C: 986A80C1
	global_load_d16_b16 v43, v[43:44], off                     // 0000001A0E50: DC820000 2B7C002B
	s_and_b32 s14, vcc_lo, exec_lo                             // 0000001A0E58: 8B0E7E6A
	s_cselect_b32 s15, s1, s74                                 // 0000001A0E5C: 980F4A01
	s_cselect_b32 s14, s0, s73                                 // 0000001A0E60: 980E4900
	s_add_u32 s0, s25, 0x2040                                  // 0000001A0E64: 8000FF19 00002040
	s_addc_u32 s1, s24, 0                                      // 0000001A0E6C: 82018018
	v_dual_cndmask_b32 v45, v129, v45 :: v_dual_cndmask_b32 v44, v128, v46// 0000001A0E70: CA525B81 2D2C5D80
	.long 0xd7006a2f                                           // 0000001A0E78: D7006A2F
	v_cndmask_b32_e32 v1, 0xd8000, v17, vcc_lo                 // 0000001A0E7C: 020222FF 000D8000
	s_cmp_gt_i32 s9, 43                                        // 0000001A0E84: BF02AB09
	v_add_co_ci_u32_e64 v46, null, 0, v64, vcc_lo              // 0000001A0E88: D5207C2E 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0E90: 986A80C1
	global_load_d16_b16 v44, v[44:45], off                     // 0000001A0E94: DC820000 2C7C002C
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0E9C: 8B377E6A
	s_cselect_b32 s56, s0, s73                                 // 0000001A0EA0: 98384900
	.long 0xd7000031                                           // 0000001A0EA4: D7000031
	v_cndmask_b32_e32 v1, 0xdd000, v17, vcc_lo                 // 0000001A0EA8: 020222FF 000DD000
	s_cselect_b32 s57, s1, s74                                 // 0000001A0EB0: 98394A01
	s_add_u32 s1, s25, 0x2100                                  // 0000001A0EB4: 8001FF19 00002100
	v_add_co_ci_u32_e64 v48, null, 0, v64, s0                  // 0000001A0EBC: D5207C30 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A0EC4: 82008018
	s_cmp_gt_i32 s9, 44                                        // 0000001A0EC8: BF02AC09
	v_dual_cndmask_b32 v46, v129, v46 :: v_dual_cndmask_b32 v45, v128, v47// 0000001A0ECC: CA525D81 2E2C5F80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0ED4: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0ED8: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0EDC: 8B377E6A
	s_cselect_b32 s59, s0, s74                                 // 0000001A0EE0: 983B4A00
	.long 0xd7000032                                           // 0000001A0EE4: D7000032
	v_cndmask_b32_e32 v1, 0xe2000, v17, vcc_lo                 // 0000001A0EE8: 020222FF 000E2000
	s_cselect_b32 s58, s1, s73                                 // 0000001A0EF0: 983A4901
	s_add_u32 s1, s25, 0x21c0                                  // 0000001A0EF4: 8001FF19 000021C0
	v_add_co_ci_u32_e64 v51, null, 0, v64, s0                  // 0000001A0EFC: D5207C33 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A0F04: 82008018
	s_cmp_gt_i32 s9, 45                                        // 0000001A0F08: BF02AD09
	v_dual_cndmask_b32 v48, v129, v48 :: v_dual_cndmask_b32 v47, v128, v49// 0000001A0F0C: CA526181 302E6380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0F14: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0F18: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0F1C: 8B377E6A
	s_cselect_b32 s77, s0, s74                                 // 0000001A0F20: 984D4A00
	.long 0xd7000031                                           // 0000001A0F24: D7000031
	v_cndmask_b32_e32 v1, 0xe7000, v17, vcc_lo                 // 0000001A0F28: 020222FF 000E7000
	s_cselect_b32 s76, s1, s73                                 // 0000001A0F30: 984C4901
	s_add_u32 s1, s25, 0x2280                                  // 0000001A0F34: 8001FF19 00002280
	v_add_co_ci_u32_e64 v52, null, 0, v64, s0                  // 0000001A0F3C: D5207C34 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A0F44: 82008018
	s_cmp_gt_i32 s9, 46                                        // 0000001A0F48: BF02AE09
	v_dual_cndmask_b32 v51, v129, v51 :: v_dual_cndmask_b32 v50, v128, v50// 0000001A0F4C: CA526781 33326580
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0F54: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0F58: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A0F5C: 8B377E6A
	s_cselect_b32 s79, s0, s74                                 // 0000001A0F60: 984F4A00
	.long 0xd7000036                                           // 0000001A0F64: D7000036
	v_cndmask_b32_e32 v1, 0xec000, v17, vcc_lo                 // 0000001A0F68: 020222FF 000EC000
	s_cselect_b32 s78, s1, s73                                 // 0000001A0F70: 984E4901
	s_add_u32 s55, s25, 0x2340                                 // 0000001A0F74: 8037FF19 00002340
	v_add_co_ci_u32_e64 v55, null, 0, v64, s0                  // 0000001A0F7C: D5207C37 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A0F84: 82008018
	s_cmp_gt_i32 s9, 47                                        // 0000001A0F88: BF02AF09
	v_dual_cndmask_b32 v53, v129, v52 :: v_dual_cndmask_b32 v52, v128, v49// 0000001A0F8C: CA526981 35346380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A0F94: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A0F98: BF870009
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001A0F9C: 8B017E6A
	s_cselect_b32 s1, s0, s74                                  // 0000001A0FA0: 98014A00
	s_cselect_b32 s0, s55, s73                                 // 0000001A0FA4: 98004937
	s_add_u32 s55, s25, 0x2400                                 // 0000001A0FA8: 8037FF19 00002400
	v_dual_cndmask_b32 v55, v129, v55 :: v_dual_cndmask_b32 v54, v128, v54// 0000001A0FB0: CA526F81 37366D80
	s_addc_u32 s63, s24, 0                                     // 0000001A0FB8: 823F8018
	global_load_d16_b16 v49, v[45:46], off                     // 0000001A0FBC: DC820000 317C002D
	global_load_d16_b16 v48, v[47:48], off                     // 0000001A0FC4: DC820000 307C002F
	global_load_d16_b16 v47, v[50:51], off                     // 0000001A0FCC: DC820000 2F7C0032
	global_load_d16_b16 v46, v[52:53], off                     // 0000001A0FD4: DC820000 2E7C0034
	global_load_d16_b16 v45, v[54:55], off                     // 0000001A0FDC: DC820000 2D7C0036
	s_cmp_gt_i32 s9, 48                                        // 0000001A0FE4: BF02B009
	.long 0xd7006a32                                           // 0000001A0FE8: D7006A32
	v_cndmask_b32_e32 v1, 0xf1000, v17, vcc_lo                 // 0000001A0FEC: 020222FF 000F1000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A0FF4: BF870001
	v_add_co_ci_u32_e64 v51, null, 0, v64, vcc_lo              // 0000001A0FF8: D5207C33 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A1000: 986A80C1
	s_clause 0x7                                               // 0000001A1004: BF850007
	global_load_b32 v205, v107, s[10:11]                       // 0000001A1008: DC520000 CD0A006B
	global_load_b32 v204, v107, s[12:13]                       // 0000001A1010: DC520000 CC0C006B
	global_load_b32 v203, v107, s[14:15]                       // 0000001A1018: DC520000 CB0E006B
	global_load_b32 v201, v107, s[56:57]                       // 0000001A1020: DC520000 C938006B
	global_load_b32 v202, v107, s[58:59]                       // 0000001A1028: DC520000 CA3A006B
	global_load_b32 v200, v107, s[76:77]                       // 0000001A1030: DC520000 C84C006B
	global_load_b32 v199, v107, s[78:79]                       // 0000001A1038: DC520000 C74E006B
	global_load_b32 v181, v107, s[0:1]                         // 0000001A1040: DC520000 B500006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001A1048: 8B007E6A
	s_cselect_b32 s11, s63, s74                                // 0000001A104C: 980B4A3F
	s_cselect_b32 s10, s55, s73                                // 0000001A1050: 980A4937
	s_add_u32 s0, s25, 0x24c0                                  // 0000001A1054: 8000FF19 000024C0
	s_addc_u32 s1, s24, 0                                      // 0000001A105C: 82018018
	v_dual_cndmask_b32 v51, v129, v51 :: v_dual_cndmask_b32 v50, v128, v50// 0000001A1060: CA526781 33326580
	.long 0xd7006a35                                           // 0000001A1068: D7006A35
	v_cndmask_b32_e32 v1, 0xf6000, v17, vcc_lo                 // 0000001A106C: 020222FF 000F6000
	s_cmp_gt_i32 s9, 49                                        // 0000001A1074: BF02B109
	v_add_co_ci_u32_e64 v52, null, 0, v64, vcc_lo              // 0000001A1078: D5207C34 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A1080: 986A80C1
	global_load_d16_b16 v50, v[50:51], off                     // 0000001A1084: DC820000 327C0032
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001A108C: 8B0C7E6A
	s_cselect_b32 s13, s1, s74                                 // 0000001A1090: 980D4A01
	s_cselect_b32 s12, s0, s73                                 // 0000001A1094: 980C4900
	s_add_u32 s0, s25, 0x2580                                  // 0000001A1098: 8000FF19 00002580
	s_addc_u32 s1, s24, 0                                      // 0000001A10A0: 82018018
	v_dual_cndmask_b32 v52, v129, v52 :: v_dual_cndmask_b32 v51, v128, v53// 0000001A10A4: CA526981 34326B80
	.long 0xd7006a36                                           // 0000001A10AC: D7006A36
	v_cndmask_b32_e32 v1, 0xfb000, v17, vcc_lo                 // 0000001A10B0: 020222FF 000FB000
	s_cmp_gt_i32 s9, 50                                        // 0000001A10B8: BF02B209
	v_add_co_ci_u32_e64 v53, null, 0, v64, vcc_lo              // 0000001A10BC: D5207C35 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A10C4: 986A80C1
	global_load_d16_b16 v51, v[51:52], off                     // 0000001A10C8: DC820000 337C0033
	s_and_b32 s14, vcc_lo, exec_lo                             // 0000001A10D0: 8B0E7E6A
	s_cselect_b32 s15, s1, s74                                 // 0000001A10D4: 980F4A01
	s_cselect_b32 s14, s0, s73                                 // 0000001A10D8: 980E4900
	s_add_u32 s0, s25, 0x2640                                  // 0000001A10DC: 8000FF19 00002640
	s_addc_u32 s1, s24, 0                                      // 0000001A10E4: 82018018
	v_dual_cndmask_b32 v53, v129, v53 :: v_dual_cndmask_b32 v52, v128, v54// 0000001A10E8: CA526B81 35346D80
	.long 0xd7006a37                                           // 0000001A10F0: D7006A37
	v_cndmask_b32_e32 v1, 0x100000, v17, vcc_lo                // 0000001A10F4: 020222FF 00100000
	s_cmp_gt_i32 s9, 51                                        // 0000001A10FC: BF02B309
	v_add_co_ci_u32_e64 v54, null, 0, v64, vcc_lo              // 0000001A1100: D5207C36 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A1108: 986A80C1
	global_load_d16_b16 v52, v[52:53], off                     // 0000001A110C: DC820000 347C0034
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A1114: 8B377E6A
	s_cselect_b32 s56, s0, s73                                 // 0000001A1118: 98384900
	.long 0xd7000039                                           // 0000001A111C: D7000039
	v_cndmask_b32_e32 v1, 0x105000, v17, vcc_lo                // 0000001A1120: 020222FF 00105000
	s_cselect_b32 s57, s1, s74                                 // 0000001A1128: 98394A01
	s_add_u32 s1, s25, 0x2700                                  // 0000001A112C: 8001FF19 00002700
	v_add_co_ci_u32_e64 v56, null, 0, v64, s0                  // 0000001A1134: D5207C38 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A113C: 82008018
	s_cmp_gt_i32 s9, 52                                        // 0000001A1140: BF02B409
	v_dual_cndmask_b32 v54, v129, v54 :: v_dual_cndmask_b32 v53, v128, v55// 0000001A1144: CA526D81 36346F80
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A114C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A1150: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A1154: 8B377E6A
	s_cselect_b32 s59, s0, s74                                 // 0000001A1158: 983B4A00
	.long 0xd700003a                                           // 0000001A115C: D700003A
	v_cndmask_b32_e32 v1, 0x10a000, v17, vcc_lo                // 0000001A1160: 020222FF 0010A000
	s_cselect_b32 s58, s1, s73                                 // 0000001A1168: 983A4901
	s_add_u32 s1, s25, 0x27c0                                  // 0000001A116C: 8001FF19 000027C0
	v_add_co_ci_u32_e64 v59, null, 0, v64, s0                  // 0000001A1174: D5207C3B 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A117C: 82008018
	s_cmp_gt_i32 s9, 53                                        // 0000001A1180: BF02B509
	v_dual_cndmask_b32 v56, v129, v56 :: v_dual_cndmask_b32 v55, v128, v57// 0000001A1184: CA527181 38367380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A118C: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A1190: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A1194: 8B377E6A
	s_cselect_b32 s77, s0, s74                                 // 0000001A1198: 984D4A00
	.long 0xd7000039                                           // 0000001A119C: D7000039
	v_cndmask_b32_e32 v1, 0x10f000, v17, vcc_lo                // 0000001A11A0: 020222FF 0010F000
	s_cselect_b32 s76, s1, s73                                 // 0000001A11A8: 984C4901
	s_add_u32 s1, s25, 0x2880                                  // 0000001A11AC: 8001FF19 00002880
	v_add_co_ci_u32_e64 v60, null, 0, v64, s0                  // 0000001A11B4: D5207C3C 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A11BC: 82008018
	s_cmp_gt_i32 s9, 54                                        // 0000001A11C0: BF02B609
	v_dual_cndmask_b32 v59, v129, v59 :: v_dual_cndmask_b32 v58, v128, v58// 0000001A11C4: CA527781 3B3A7580
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A11CC: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A11D0: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A11D4: 8B377E6A
	s_cselect_b32 s79, s0, s74                                 // 0000001A11D8: 984F4A00
	.long 0xd700003e                                           // 0000001A11DC: D700003E
	v_cndmask_b32_e32 v1, 0x114000, v17, vcc_lo                // 0000001A11E0: 020222FF 00114000
	s_cselect_b32 s78, s1, s73                                 // 0000001A11E8: 984E4901
	s_add_u32 s55, s25, 0x2940                                 // 0000001A11EC: 8037FF19 00002940
	v_add_co_ci_u32_e64 v63, null, 0, v64, s0                  // 0000001A11F4: D5207C3F 00028080
	s_addc_u32 s0, s24, 0                                      // 0000001A11FC: 82008018
	s_cmp_gt_i32 s9, 55                                        // 0000001A1200: BF02B709
	v_dual_cndmask_b32 v61, v129, v60 :: v_dual_cndmask_b32 v60, v128, v57// 0000001A1204: CA527981 3D3C7380
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A120C: 986A80C1
	v_dual_cndmask_b32 v63, v129, v63 :: v_dual_cndmask_b32 v62, v128, v62// 0000001A1210: CA527F81 3F3E7D80
	s_and_b32 s1, vcc_lo, exec_lo                              // 0000001A1218: 8B017E6A
	global_load_d16_b16 v57, v[53:54], off                     // 0000001A121C: DC820000 397C0035
	global_load_d16_b16 v56, v[55:56], off                     // 0000001A1224: DC820000 387C0037
	global_load_d16_b16 v55, v[58:59], off                     // 0000001A122C: DC820000 377C003A
	global_load_d16_b16 v54, v[60:61], off                     // 0000001A1234: DC820000 367C003C
	global_load_d16_b16 v53, v[62:63], off                     // 0000001A123C: DC820000 357C003E
	s_cselect_b32 s1, s0, s74                                  // 0000001A1244: 98014A00
	s_cselect_b32 s0, s55, s73                                 // 0000001A1248: 98004937
	s_add_u32 s55, s25, 0x2a00                                 // 0000001A124C: 8037FF19 00002A00
	.long 0xd7006a3a                                           // 0000001A1254: D7006A3A
	v_cndmask_b32_e32 v1, 0x119000, v17, vcc_lo                // 0000001A1258: 020222FF 00119000
	s_addc_u32 s63, s24, 0                                     // 0000001A1260: 823F8018
	s_cmp_gt_i32 s9, 56                                        // 0000001A1264: BF02B809
	v_add_co_ci_u32_e64 v59, null, 0, v64, vcc_lo              // 0000001A1268: D5207C3B 01AA8080
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A1270: 986A80C1
	s_clause 0x7                                               // 0000001A1274: BF850007
	global_load_b32 v212, v107, s[10:11]                       // 0000001A1278: DC520000 D40A006B
	global_load_b32 v213, v107, s[12:13]                       // 0000001A1280: DC520000 D50C006B
	global_load_b32 v211, v107, s[14:15]                       // 0000001A1288: DC520000 D30E006B
	global_load_b32 v210, v107, s[56:57]                       // 0000001A1290: DC520000 D238006B
	global_load_b32 v209, v107, s[58:59]                       // 0000001A1298: DC520000 D13A006B
	global_load_b32 v207, v107, s[76:77]                       // 0000001A12A0: DC520000 CF4C006B
	global_load_b32 v208, v107, s[78:79]                       // 0000001A12A8: DC520000 D04E006B
	global_load_b32 v206, v107, s[0:1]                         // 0000001A12B0: DC520000 CE00006B
	s_and_b32 s0, vcc_lo, exec_lo                              // 0000001A12B8: 8B007E6A
	v_dual_cndmask_b32 v59, v129, v59 :: v_dual_cndmask_b32 v58, v128, v58// 0000001A12BC: CA527781 3B3A7580
	s_cselect_b32 s1, s63, s74                                 // 0000001A12C4: 98014A3F
	s_cselect_b32 s0, s55, s73                                 // 0000001A12C8: 98004937
	s_add_u32 s10, s25, 0x2ac0                                 // 0000001A12CC: 800AFF19 00002AC0
	.long 0xd7006a3d                                           // 0000001A12D4: D7006A3D
	v_cndmask_b32_e32 v1, 0x11e000, v17, vcc_lo                // 0000001A12D8: 020222FF 0011E000
	s_addc_u32 s11, s24, 0                                     // 0000001A12E0: 820B8018
	v_add_co_ci_u32_e64 v60, null, 0, v64, vcc_lo              // 0000001A12E4: D5207C3C 01AA8080
	s_cmp_gt_i32 s9, 57                                        // 0000001A12EC: BF02B909
	global_load_d16_b16 v58, v[58:59], off                     // 0000001A12F0: DC820000 3A7C003A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A12F8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A12FC: BF870009
	s_and_b32 s12, vcc_lo, exec_lo                             // 0000001A1300: 8B0C7E6A
	v_dual_cndmask_b32 v60, v129, v60 :: v_dual_cndmask_b32 v59, v128, v61// 0000001A1304: CA527981 3C3A7B80
	s_cselect_b32 s11, s11, s74                                // 0000001A130C: 980B4A0B
	s_cselect_b32 s10, s10, s73                                // 0000001A1310: 980A490A
	s_add_u32 s12, s25, 0x2b80                                 // 0000001A1314: 800CFF19 00002B80
	.long 0xd7006a3e                                           // 0000001A131C: D7006A3E
	v_cndmask_b32_e32 v1, 0x123000, v17, vcc_lo                // 0000001A1320: 020222FF 00123000
	s_addc_u32 s13, s24, 0                                     // 0000001A1328: 820D8018
	v_add_co_ci_u32_e64 v61, null, 0, v64, vcc_lo              // 0000001A132C: D5207C3D 01AA8080
	s_cmp_gt_i32 s9, 58                                        // 0000001A1334: BF02BA09
	global_load_d16_b16 v59, v[59:60], off                     // 0000001A1338: DC820000 3B7C003B
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A1340: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A1344: BF870009
	s_and_b32 s14, vcc_lo, exec_lo                             // 0000001A1348: 8B0E7E6A
	v_dual_cndmask_b32 v61, v129, v61 :: v_dual_cndmask_b32 v60, v128, v62// 0000001A134C: CA527B81 3D3C7D80
	s_cselect_b32 s13, s13, s74                                // 0000001A1354: 980D4A0D
	s_cselect_b32 s12, s12, s73                                // 0000001A1358: 980C490C
	s_add_u32 s14, s25, 0x2c40                                 // 0000001A135C: 800EFF19 00002C40
	.long 0xd7006a3e                                           // 0000001A1364: D7006A3E
	v_cndmask_b32_e32 v1, 0x128000, v17, vcc_lo                // 0000001A1368: 020222FF 00128000
	s_addc_u32 s15, s24, 0                                     // 0000001A1370: 820F8018
	v_add_co_ci_u32_e64 v63, null, 0, v64, vcc_lo              // 0000001A1374: D5207C3F 01AA8080
	s_cmp_gt_i32 s9, 59                                        // 0000001A137C: BF02BB09
	global_load_d16_b16 v61, v[60:61], off                     // 0000001A1380: DC820000 3D7C003C
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A1388: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A138C: BF870009
	s_and_b32 s55, vcc_lo, exec_lo                             // 0000001A1390: 8B377E6A
	v_dual_cndmask_b32 v63, v129, v63 :: v_dual_cndmask_b32 v62, v128, v62// 0000001A1394: CA527F81 3F3E7D80
	s_cselect_b32 s15, s15, s74                                // 0000001A139C: 980F4A0F
	s_cselect_b32 s14, s14, s73                                // 0000001A13A0: 980E490E
	s_add_u32 s55, s25, 0x2d00                                 // 0000001A13A4: 8037FF19 00002D00
	.long 0xd7006a41                                           // 0000001A13AC: D7006A41
	v_cndmask_b32_e32 v1, 0x12d000, v17, vcc_lo                // 0000001A13B0: 020222FF 0012D000
	s_addc_u32 s56, s24, 0                                     // 0000001A13B8: 82388018
	v_add_co_ci_u32_e64 v122, null, 0, v64, vcc_lo             // 0000001A13BC: D5207C7A 01AA8080
	s_cmp_gt_i32 s9, 60                                        // 0000001A13C4: BF02BC09
	global_load_d16_b16 v60, v[62:63], off                     // 0000001A13C8: DC820000 3C7C003E
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A13D0: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A13D4: BF870009
	s_and_b32 s57, vcc_lo, exec_lo                             // 0000001A13D8: 8B397E6A
	v_dual_cndmask_b32 v63, v129, v122 :: v_dual_cndmask_b32 v62, v128, v65// 0000001A13DC: CA52F581 3F3E8380
	s_cselect_b32 s57, s56, s74                                // 0000001A13E4: 98394A38
	s_cselect_b32 s56, s55, s73                                // 0000001A13E8: 98384937
	s_add_u32 s55, s25, 0x2dc0                                 // 0000001A13EC: 8037FF19 00002DC0
	.long 0xd7006a41                                           // 0000001A13F4: D7006A41
	v_cndmask_b32_e32 v1, 0x132000, v17, vcc_lo                // 0000001A13F8: 020222FF 00132000
	s_addc_u32 s58, s24, 0                                     // 0000001A1400: 823A8018
	v_add_co_ci_u32_e64 v122, null, 0, v64, vcc_lo             // 0000001A1404: D5207C7A 01AA8080
	s_cmp_gt_i32 s9, 61                                        // 0000001A140C: BF02BD09
	global_load_d16_b16 v62, v[62:63], off                     // 0000001A1410: DC820000 3E7C003E
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A1418: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A141C: BF870009
	s_and_b32 s59, vcc_lo, exec_lo                             // 0000001A1420: 8B3B7E6A
	v_dual_cndmask_b32 v123, v129, v122 :: v_dual_cndmask_b32 v122, v128, v65// 0000001A1424: CA52F581 7B7A8380
	s_cselect_b32 s59, s58, s74                                // 0000001A142C: 983B4A3A
	s_cselect_b32 s58, s55, s73                                // 0000001A1430: 983A4937
	s_add_u32 s55, s25, 0x2e80                                 // 0000001A1434: 8037FF19 00002E80
	.long 0xd7006a41                                           // 0000001A143C: D7006A41
	v_cndmask_b32_e32 v1, 0x137000, v17, vcc_lo                // 0000001A1440: 020222FF 00137000
	s_addc_u32 s63, s24, 0                                     // 0000001A1448: 823F8018
	v_add_co_ci_u32_e64 v182, null, 0, v64, vcc_lo             // 0000001A144C: D5207CB6 01AA8080
	s_cmp_gt_i32 s9, 62                                        // 0000001A1454: BF02BE09
	global_load_d16_b16 v63, v[122:123], off                   // 0000001A1458: DC820000 3F7C007A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A1460: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A1464: BF870009
	s_and_b32 s75, vcc_lo, exec_lo                             // 0000001A1468: 8B4B7E6A
	v_dual_cndmask_b32 v123, v129, v182 :: v_dual_cndmask_b32 v122, v128, v65// 0000001A146C: CA536D81 7B7A8380
	s_cselect_b32 s77, s63, s74                                // 0000001A1474: 984D4A3F
	s_cselect_b32 s76, s55, s73                                // 0000001A1478: 984C4937
	s_add_u32 s55, s25, 0x2f40                                 // 0000001A147C: 8037FF19 00002F40
	.long 0xd7006a11                                           // 0000001A1484: D7006A11
	v_cndmask_b32_e32 v1, 0x13c000, v17, vcc_lo                // 0000001A1488: 020222FF 0013C000
	s_addc_u32 s24, s24, 0                                     // 0000001A1490: 82188018
	v_add_co_ci_u32_e64 v65, null, 0, v64, vcc_lo              // 0000001A1494: D5207C41 01AA8080
	s_cmp_gt_i32 s9, 63                                        // 0000001A149C: BF02BF09
	global_load_d16_b16 v64, v[122:123], off                   // 0000001A14A0: DC820000 407C007A
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A14A8: 986A80C1
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A14AC: BF870009
	s_and_b32 s9, vcc_lo, exec_lo                              // 0000001A14B0: 8B097E6A
	v_cndmask_b32_e32 v123, v129, v65, vcc_lo                  // 0000001A14B4: 02F68381
	v_cndmask_b32_e32 v122, v128, v17, vcc_lo                  // 0000001A14B8: 02F42380
	s_cselect_b32 s25, s24, s74                                // 0000001A14BC: 98194A18
	s_cselect_b32 s24, s55, s73                                // 0000001A14C0: 98184937
	s_clause 0x7                                               // 0000001A14C4: BF850007
	global_load_b32 v220, v107, s[0:1]                         // 0000001A14C8: DC520000 DC00006B
	global_load_b32 v221, v107, s[10:11]                       // 0000001A14D0: DC520000 DD0A006B
	global_load_b32 v219, v107, s[12:13]                       // 0000001A14D8: DC520000 DB0C006B
	global_load_b32 v217, v107, s[14:15]                       // 0000001A14E0: DC520000 D90E006B
	global_load_b32 v218, v107, s[56:57]                       // 0000001A14E8: DC520000 DA38006B
	global_load_b32 v215, v107, s[58:59]                       // 0000001A14F0: DC520000 D73A006B
	global_load_b32 v216, v107, s[76:77]                       // 0000001A14F8: DC520000 D84C006B
	global_load_b32 v214, v107, s[24:25]                       // 0000001A1500: DC520000 D618006B
	global_load_d16_b16 v65, v[122:123], off                   // 0000001A1508: DC820000 417C007A
	.long 0x7e223880                                           // 0000001A1510: 7E223880
	s_cmp_gt_i32 s67, s41                                      // 0000001A1514: BF022943
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001A1518: BF890007
	s_barrier                                                  // 0000001A151C: BFBD0000
	buffer_gl0_inv                                             // 0000001A1520: E0AC0000 00000000
	s_cbranch_scc0 10                                          // 0000001A1528: BFA1000A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x1b54>
	ds_load_b32 v17, v107 offset:61440                         // 0000001A152C: D8D8F000 1100006B
	v_lshlrev_b32_e32 v1, 16, v1                               // 0000001A1534: 30020290
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A1538: BF8700A1
	v_mul_f32_e32 v1, v73, v1                                  // 0000001A153C: 10020349
	s_waitcnt lgkmcnt(0)                                       // 0000001A1540: BF89FC07
	v_mul_f32_e32 v1, v1, v17                                  // 0000001A1544: 10022301
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A1548: BF870001
	v_fma_mixlo_f16 v17, v1, s28, 0                            // 0000001A154C: CC210011 02003901
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000001A1554: 300E0E90
	v_lshlrev_b32_e32 v1, 16, v2                               // 0000001A1558: 30020490
	s_or_b32 s0, s41, 1                                        // 0000001A155C: 8C008129
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A1560: BF870119
	s_cmp_lt_i32 s0, s67                                       // 0000001A1564: BF044300
	v_mul_f32_e32 v70, v70, v7                                 // 0000001A1568: 108C0F46
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001A156C: BF8701C2
	v_dual_mul_f32 v71, v71, v1 :: v_dual_lshlrev_b32 v2, 16, v3// 0000001A1570: C8E20347 47020690
	v_lshlrev_b32_e32 v3, 16, v8                               // 0000001A1578: 30061090
	v_lshlrev_b32_e32 v7, 16, v20                              // 0000001A157C: 300E2890
	s_cselect_b32 s0, -1, 0                                    // 0000001A1580: 980080C1
	v_mul_f32_e32 v72, v72, v2                                 // 0000001A1584: 10900548
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001A1588: BF8701B3
	v_dual_mul_f32 v69, v69, v3 :: v_dual_lshlrev_b32 v2, 16, v4// 0000001A158C: C8E20745 45020890
	v_lshlrev_b32_e32 v3, 16, v10                              // 0000001A1594: 30061490
	v_lshlrev_b32_e32 v1, 16, v6                               // 0000001A1598: 30020C90
	v_mul_f32_e32 v66, v66, v2                                 // 0000001A159C: 10840542
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001A15A0: BF870132
	v_mul_f32_e32 v68, v68, v1                                 // 0000001A15A4: 10880344
	v_lshlrev_b32_e32 v1, 16, v5                               // 0000001A15A8: 30020A90
	v_lshlrev_b32_e32 v2, 16, v11                              // 0000001A15AC: 30041690
	v_dual_mul_f32 v198, v86, v7 :: v_dual_mul_f32 v67, v67, v1// 0000001A15B0: C8C60F56 C6420343
	v_lshlrev_b32_e32 v1, 16, v9                               // 0000001A15B8: 30021290
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A15BC: BF870233
	v_dual_mul_f32 v79, v79, v2 :: v_dual_lshlrev_b32 v2, 16, v15// 0000001A15C0: C8E2054F 4F021E90
	v_lshlrev_b32_e32 v6, 16, v19                              // 0000001A15C8: 300C2690
	v_lshlrev_b32_e32 v8, 16, v25                              // 0000001A15CC: 30103290
	v_mul_f32_e32 v73, v80, v1                                 // 0000001A15D0: 10920350
	v_lshlrev_b32_e32 v1, 16, v16                              // 0000001A15D4: 30022090
	v_dual_mul_f32 v5, v77, v2 :: v_dual_lshlrev_b32 v2, 16, v12// 0000001A15D8: C8E2054D 05021890
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A15E0: BF870194
	v_dual_mul_f32 v197, v88, v6 :: v_dual_mul_f32 v192, v87, v8// 0000001A15E4: C8C60D58 C5C01157
	v_mul_f32_e32 v15, v78, v1                                 // 0000001A15EC: 101E034E
	v_lshlrev_b32_e32 v1, 16, v14                              // 0000001A15F0: 30021C90
	v_lshlrev_b32_e32 v6, 16, v24                              // 0000001A15F4: 300C3090
	v_lshlrev_b32_e32 v8, 16, v26                              // 0000001A15F8: 30103490
	v_lshlrev_b32_e32 v7, 16, v22                              // 0000001A15FC: 300E2C90
	.long 0x7e12392e                                           // 0000001A1600: 7E12392E
	v_dual_mul_f32 v4, v75, v1 :: v_dual_mul_f32 v1, v74, v2   // 0000001A1604: C8C6034B 0400054A
	v_mul_f32_e32 v80, v81, v3                                 // 0000001A160C: 10A00751
	v_dual_mul_f32 v193, v85, v6 :: v_dual_lshlrev_b32 v6, 16, v23// 0000001A1610: C8E20D55 C1062E90
	v_dual_mul_f32 v186, v97, v8 :: v_dual_lshlrev_b32 v3, 16, v13// 0000001A1618: C8E21161 BA021A90
	v_dual_mul_f32 v195, v83, v7 :: v_dual_lshlrev_b32 v16, 16, v64// 0000001A1620: C8E20F53 C3108090
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A1628: BF870193
	v_mul_f32_e32 v196, v84, v6                                // 0000001A162C: 11880D54
	v_dual_mul_f32 v3, v76, v3 :: v_dual_lshlrev_b32 v6, 16, v21// 0000001A1630: C8E2074C 03062A90
	v_lshlrev_b32_e32 v14, 16, v63                             // 0000001A1638: 301C7E90
	v_lshlrev_b32_e32 v2, 16, v18                              // 0000001A163C: 30042490
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A1640: BF8701A3
	v_mul_f32_e32 v194, v82, v6                                // 0000001A1644: 11840D52
	v_lshlrev_b32_e32 v6, 16, v28                              // 0000001A1648: 300C3890
	v_dual_mul_f32 v2, v89, v2 :: v_dual_lshlrev_b32 v7, 16, v27// 0000001A164C: C8E20559 02063690
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_2)// 0000001A1654: BF870131
	v_dual_mul_f32 v190, v95, v6 :: v_dual_mul_f32 v187, v96, v7// 0000001A1658: C8C60D5F BEBA0F60
	v_lshlrev_b32_e32 v6, 16, v32                              // 0000001A1660: 300C4090
	v_lshlrev_b32_e32 v8, 16, v31                              // 0000001A1664: 30103E90
	v_mul_f32_e32 v189, v92, v6                                // 0000001A1668: 117A0D5C
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A166C: BF870122
	v_dual_mul_f32 v184, v93, v8 :: v_dual_lshlrev_b32 v7, 16, v33// 0000001A1670: C8E2115D B8064290
	v_lshlrev_b32_e32 v8, 16, v36                              // 0000001A1678: 30104890
	v_dual_mul_f32 v188, v94, v7 :: v_dual_lshlrev_b32 v7, 16, v30// 0000001A167C: C8E20F5E BC063C90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A1684: BF8701A2
	v_mul_f32_e32 v122, v104, v8                               // 0000001A1688: 10F41168
	v_lshlrev_b32_e32 v8, 16, v38                              // 0000001A168C: 30104C90
	v_mul_f32_e32 v185, v91, v7                                // 0000001A1690: 11720F5B
	v_lshlrev_b32_e32 v7, 16, v34                              // 0000001A1694: 300E4490
	v_lshlrev_b32_e32 v6, 16, v29                              // 0000001A1698: 300C3A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A169C: BF870112
	v_mul_f32_e32 v183, v105, v7                               // 0000001A16A0: 116E0F69
	v_dual_mul_f32 v191, v90, v6 :: v_dual_lshlrev_b32 v6, 16, v35// 0000001A16A4: C8E20D5A BF064690
	v_lshlrev_b32_e32 v7, 16, v41                              // 0000001A16AC: 300E5290
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A16B0: BF870112
	v_mul_f32_e32 v182, v103, v6                               // 0000001A16B4: 116C0D67
	v_mul_f32_e32 v102, v102, v7                               // 0000001A16B8: 10CC0F66
	v_lshlrev_b32_e32 v7, 16, v39                              // 0000001A16BC: 300E4E90
	v_mul_f32_e32 v103, v99, v8                                // 0000001A16C0: 10CE1163
	v_lshlrev_b32_e32 v8, 16, v48                              // 0000001A16C4: 30106090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A16C8: BF8701A3
	v_dual_mul_f32 v104, v100, v7 :: v_dual_lshlrev_b32 v7, 16, v42// 0000001A16CC: C8E20F64 68065490
	v_lshlrev_b32_e32 v6, 16, v40                              // 0000001A16D4: 300C5090
	v_mul_f32_e32 v46, v202, v8                                // 0000001A16D8: 105C11CA
	v_lshlrev_b32_e32 v8, 16, v45                              // 0000001A16DC: 30105A90
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A16E0: BF870214
	v_mul_f32_e32 v99, v205, v7                                // 0000001A16E4: 10C60FCD
	v_mul_f32_e32 v123, v101, v6                               // 0000001A16E8: 10F60D65
	v_lshlrev_b32_e32 v7, 16, v44                              // 0000001A16EC: 300E5890
	v_lshlrev_b32_e32 v6, 16, v37                              // 0000001A16F0: 300C4A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A16F4: BF870112
	v_mul_f32_e32 v101, v203, v7                               // 0000001A16F8: 10CA0FCB
	v_dual_mul_f32 v105, v98, v6 :: v_dual_lshlrev_b32 v6, 16, v43// 0000001A16FC: C8E20D62 69065690
	v_lshlrev_b32_e32 v7, 16, v47                              // 0000001A1704: 300E5E90
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A1708: BF870232
	v_mul_f32_e32 v100, v204, v6                               // 0000001A170C: 10C80DCC
	v_dual_mul_f32 v49, v181, v8 :: v_dual_lshlrev_b32 v6, 16, v49// 0000001A1710: C8E211B5 31066290
	v_lshlrev_b32_e32 v8, 16, v52                              // 0000001A1718: 30106890
	v_mul_f32_e32 v42, v200, v7                                // 0000001A171C: 10540FC8
	.long 0x7e0e3932                                           // 0000001A1720: 7E0E3932
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A1724: BF870004
	v_mul_f32_e32 v48, v201, v6                                // 0000001A1728: 10600DC9
	v_mul_f32_e32 v52, v215, v14                               // 0000001A172C: 10681DD7
	v_mul_f32_e32 v30, v211, v8                                // 0000001A1730: 103C11D3
	v_lshlrev_b32_e32 v8, 16, v54                              // 0000001A1734: 30106C90
	v_lshlrev_b32_e32 v6, 16, v9                               // 0000001A1738: 300C1290
	v_lshlrev_b32_e32 v14, 16, v65                             // 0000001A173C: 301C8290
	v_lshlrev_b32_e32 v10, 16, v61                             // 0000001A1740: 30147A90
	ds_load_2addr_b32 v[201:202], v158 offset1:1               // 0000001A1744: D8DC0100 C900009E
	ds_load_2addr_b32 v[203:204], v159 offset1:1               // 0000001A174C: D8DC0100 CB00009F
	v_dual_mul_f32 v25, v208, v8 :: v_dual_mul_f32 v50, v199, v6// 0000001A1754: C8C611D0 19320DC7
	v_lshlrev_b32_e32 v8, 16, v58                              // 0000001A175C: 30107490
	v_lshlrev_b32_e32 v6, 16, v7                               // 0000001A1760: 300C0E90
	v_lshlrev_b32_e32 v7, 16, v51                              // 0000001A1764: 300E6690
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A1768: BF870193
	v_mul_f32_e32 v47, v220, v8                                // 0000001A176C: 105E11DC
	v_mul_f32_e32 v43, v212, v6                                // 0000001A1770: 10560DD4
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001A1774: BF8701C3
	v_mul_f32_e32 v29, v213, v7                                // 0000001A1778: 103A0FD5
	v_lshlrev_b32_e32 v7, 16, v56                              // 0000001A177C: 300E7090
	v_lshlrev_b32_e32 v8, 16, v60                              // 0000001A1780: 30107890
	v_lshlrev_b32_e32 v9, 16, v59                              // 0000001A1784: 30127690
	v_dual_mul_f32 v32, v209, v7 :: v_dual_lshlrev_b32 v7, 16, v53// 0000001A1788: C8E20FD1 20066A90
	v_dual_mul_f32 v53, v214, v14 :: v_dual_lshlrev_b32 v6, 16, v57// 0000001A1790: C8E21DD6 35067290
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A1798: BF870004
	v_dual_mul_f32 v45, v219, v10 :: v_dual_mul_f32 v28, v217, v8// 0000001A179C: C8C615DB 2D1C11D9
	ds_load_2addr_b32 v[10:11], v150 offset1:1                 // 0000001A17A4: D8DC0100 0A000096
	ds_load_2addr_b32 v[12:13], v151 offset1:1                 // 0000001A17AC: D8DC0100 0C000097
	v_dual_mul_f32 v44, v221, v9 :: v_dual_mul_f32 v31, v210, v6// 0000001A17B4: C8C613DD 2C1E0DD2
	v_lshlrev_b32_e32 v9, 16, v62                              // 0000001A17BC: 30127C90
	v_lshlrev_b32_e32 v6, 16, v55                              // 0000001A17C0: 300C6E90
	v_mul_f32_e32 v26, v206, v7                                // 0000001A17C4: 10340FCE
	ds_load_2addr_b32 v[55:56], v156 offset1:1                 // 0000001A17C8: D8DC0100 3700009C
	v_add_nc_u32_e32 v181, s41, v132                           // 0000001A17D0: 4B6B0829
	v_mul_f32_e32 v27, v218, v9                                // 0000001A17D4: 103613DA
	v_mul_f32_e32 v41, v207, v6                                // 0000001A17D8: 10520DCF
	ds_load_2addr_b32 v[6:7], v148 offset1:1                   // 0000001A17DC: D8DC0100 06000094
	ds_load_2addr_b32 v[8:9], v149 offset1:1                   // 0000001A17E4: D8DC0100 08000095
	v_or_b32_e32 v205, v181, v130                              // 0000001A17EC: 399B05B5
	ds_load_2addr_b32 v[199:200], v157 offset1:1               // 0000001A17F0: D8DC0100 C700009D
	s_waitcnt lgkmcnt(2)                                       // 0000001A17F8: BF89FC27
	v_dual_mul_f32 v6, v71, v6 :: v_dual_mul_f32 v7, v72, v7   // 0000001A17FC: C8C60D47 06060F48
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1804: BF870091
	v_fma_mixlo_f16 v6, v6, s28, 0                             // 0000001A1808: CC210006 02003906
	v_cndmask_b16 v17, 0, v6, s0                               // 0000001A1810: D65D4011 00020C80
	s_or_b32 s0, s41, 2                                        // 0000001A1818: 8C008229
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A181C: BF870003
	v_fma_mixlo_f16 v6, v7, s28, 0                             // 0000001A1820: CC210006 02003907
	s_waitcnt lgkmcnt(1)                                       // 0000001A1828: BF89FC17
	v_mul_f32_e32 v7, v69, v8                                  // 0000001A182C: 100E1145
	s_cmp_lt_i32 s0, s67                                       // 0000001A1830: BF044300
	v_mul_f32_e32 v56, v198, v56                               // 0000001A1834: 107071C6
	s_cselect_b32 s0, -1, 0                                    // 0000001A1838: 980080C1
	s_or_b32 s1, s41, 3                                        // 0000001A183C: 8C018329
	v_cndmask_b16 v18, 0, v6, s0                               // 0000001A1840: D65D0012 00020C80
	v_fma_mixlo_f16 v6, v7, s28, 0                             // 0000001A1848: CC210006 02003907
	v_mul_f32_e32 v7, v70, v9                                  // 0000001A1850: 100E1346
	s_cmp_lt_i32 s1, s67                                       // 0000001A1854: BF044301
	v_mul_f32_e32 v9, v68, v10                                 // 0000001A1858: 10121544
	s_cselect_b32 s0, -1, 0                                    // 0000001A185C: 980080C1
	s_or_b32 s1, s41, 4                                        // 0000001A1860: 8C018429
	v_cndmask_b16 v18, 0, v6, s0                               // 0000001A1864: D65D4012 00020C80
	v_fma_mixlo_f16 v6, v7, s28, 0                             // 0000001A186C: CC210006 02003907
	ds_load_2addr_b32 v[7:8], v152 offset1:1                   // 0000001A1874: D8DC0100 07000098
	s_cmp_lt_i32 s1, s67                                       // 0000001A187C: BF044301
	v_mul_f32_e32 v10, v67, v11                                // 0000001A1880: 10141743
	s_cselect_b32 s0, -1, 0                                    // 0000001A1884: 980080C1
	s_or_b32 s1, s41, 5                                        // 0000001A1888: 8C018529
	v_cndmask_b16 v19, 0, v6, s0                               // 0000001A188C: D65D0013 00020C80
	s_cmp_lt_i32 s1, s67                                       // 0000001A1894: BF044301
	v_fma_mixlo_f16 v6, v10, s28, 0                            // 0000001A1898: CC210006 0200390A
	s_cselect_b32 s1, -1, 0                                    // 0000001A18A0: 980180C1
	s_or_b32 s9, s41, 6                                        // 0000001A18A4: 8C098629
	v_mul_f32_e32 v11, v66, v12                                // 0000001A18A8: 10161942
	s_cmp_lt_i32 s9, s67                                       // 0000001A18AC: BF044309
	v_fma_mixhi_f16 v6, v9, s28, 0                             // 0000001A18B0: CC220006 02003909
	s_cselect_b32 s0, -1, 0                                    // 0000001A18B8: 980080C1
	ds_load_2addr_b32 v[9:10], v153 offset1:1                  // 0000001A18BC: D8DC0100 09000099
	v_cndmask_b16 v20, 0, v6, s0                               // 0000001A18C4: D65D0014 00020C80
	v_fma_mixlo_f16 v6, v11, s28, 0                            // 0000001A18CC: CC210006 0200390B
	s_or_b32 s9, s41, 7                                        // 0000001A18D4: 8C098729
	v_cndmask_b16 v19, 0, v6, s1                               // 0000001A18D8: D65D5013 00060C80
	s_cmp_lt_i32 s9, s67                                       // 0000001A18E0: BF044309
	s_waitcnt lgkmcnt(1)                                       // 0000001A18E4: BF89FC17
	v_mul_f32_e32 v7, v80, v7                                  // 0000001A18E8: 100E0F50
	v_dual_mul_f32 v51, v216, v16 :: v_dual_mul_f32 v16, v73, v13// 0000001A18EC: C8C621D8 33101B49
	ds_load_2addr_b32 v[11:12], v154 offset1:1                 // 0000001A18F4: D8DC0100 0B00009A
	ds_load_2addr_b32 v[13:14], v155 offset1:1                 // 0000001A18FC: D8DC0100 0D00009B
	s_cselect_b32 s0, -1, 0                                    // 0000001A1904: 980080C1
	s_or_b32 s1, s41, 8                                        // 0000001A1908: 8C018829
	v_cndmask_b16 v20, 0, v6, s0                               // 0000001A190C: D65D4014 00020C80
	s_cmp_lt_i32 s1, s67                                       // 0000001A1914: BF044301
	v_fma_mixhi_f16 v6, v7, s28, 0                             // 0000001A1918: CC220006 02003907
	s_cselect_b32 s0, -1, 0                                    // 0000001A1920: 980080C1
	s_or_b32 s1, s41, 9                                        // 0000001A1924: 8C018929
	v_mul_f32_e32 v7, v79, v8                                  // 0000001A1928: 100E114F
	s_cmp_lt_i32 s1, s67                                       // 0000001A192C: BF044301
	v_mul_f32_e32 v55, v197, v55                               // 0000001A1930: 106E6FC5
	s_cselect_b32 s1, -1, 0                                    // 0000001A1934: 980180C1
	s_waitcnt lgkmcnt(2)                                       // 0000001A1938: BF89FC27
	v_mul_f32_e32 v5, v5, v10                                  // 0000001A193C: 100A1505
	v_cndmask_b16 v21, 0, v6, s1                               // 0000001A1940: D65D5015 00060C80
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A1948: BF870002
	v_fma_mixlo_f16 v5, v5, s28, 0                             // 0000001A194C: CC210005 02003905
	s_waitcnt lgkmcnt(1)                                       // 0000001A1954: BF89FC17
	v_mul_f32_e32 v3, v3, v12                                  // 0000001A1958: 10061903
	v_fma_mixlo_f16 v6, v16, s28, 0                            // 0000001A195C: CC210006 02003910
	s_waitcnt lgkmcnt(0)                                       // 0000001A1964: BF89FC07
	v_dual_mul_f32 v4, v4, v11 :: v_dual_mul_f32 v1, v1, v13   // 0000001A1968: C8C61704 04001B01
	v_mul_f32_e32 v54, v2, v14                                 // 0000001A1970: 106C1D02
	v_fma_mixlo_f16 v3, v3, s28, 0                             // 0000001A1974: CC210003 02003903
	v_cndmask_b16 v21, 0, v6, s0                               // 0000001A197C: D65D0015 00020C80
	s_or_b32 s0, s41, 10                                       // 0000001A1984: 8C008A29
	v_fma_mixlo_f16 v6, v7, s28, 0                             // 0000001A1988: CC210006 02003907
	v_mul_f32_e32 v7, v15, v9                                  // 0000001A1990: 100E130F
	s_cmp_lt_i32 s0, s67                                       // 0000001A1994: BF044300
	v_fma_mixlo_f16 v4, v4, s28, 0                             // 0000001A1998: CC210004 02003904
	s_cselect_b32 s0, -1, 0                                    // 0000001A19A0: 980080C1
	s_or_b32 s1, s41, 11                                       // 0000001A19A4: 8C018B29
	v_cndmask_b16 v22, 0, v6, s0                               // 0000001A19A8: D65D0016 00020C80
	v_fma_mixlo_f16 v6, v7, s28, 0                             // 0000001A19B0: CC210006 02003907
	s_cmp_lt_i32 s1, s67                                       // 0000001A19B8: BF044301
	v_fma_mixhi_f16 v24, v1, s28, 0                            // 0000001A19BC: CC220018 02003901
	s_cselect_b32 s0, -1, 0                                    // 0000001A19C4: 980080C1
	s_or_b32 s1, s41, 12                                       // 0000001A19C8: 8C018C29
	v_cndmask_b16 v22, 0, v6, s0                               // 0000001A19CC: D65D4016 00020C80
	v_min_i32_e32 v6, s71, v205                                // 0000001A19D4: 220D9A47
	s_cmp_lt_i32 s1, s67                                       // 0000001A19D8: BF044301
	v_fma_mixlo_f16 v54, v54, s28, 0                           // 0000001A19DC: CC210036 02003936
	s_cselect_b32 s0, -1, 0                                    // 0000001A19E4: 980080C1
	s_or_b32 s1, s41, 13                                       // 0000001A19E8: 8C018D29
	v_cndmask_b16 v23, 0, v5, s0                               // 0000001A19EC: D65D0017 00020A80
	v_mad_i64_i32 v[5:6], null, v6, 48, s[2:3]                 // 0000001A19F4: D6FF7C05 00096106
	s_cmp_lt_i32 s1, s67                                       // 0000001A19FC: BF044301
	v_fma_mixhi_f16 v54, v56, s28, 0                           // 0000001A1A00: CC220036 02003938
	s_cselect_b32 s0, -1, 0                                    // 0000001A1A08: 980080C1
	s_or_b32 s1, s41, 14                                       // 0000001A1A0C: 8C018E29
	v_cndmask_b16 v23, 0, v4, s0                               // 0000001A1A10: D65D4017 00020880
	s_cmp_lt_i32 s1, s67                                       // 0000001A1A18: BF044301
	.long 0xd73c0061                                           // 0000001A1A1C: D73C0061
	v_cndmask_b32_e32 v1, 8, v5, vcc_lo                        // 0000001A1A20: 02020A88
	s_cselect_b32 s0, -1, 0                                    // 0000001A1A24: 980080C1
	s_or_b32 s1, s41, 15                                       // 0000001A1A28: 8C018F29
	v_cndmask_b16 v24, 0, v3, s0                               // 0000001A1A2C: D65D0018 00020680
	s_cmp_lt_i32 s1, s67                                       // 0000001A1A34: BF044301
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A1A38: BF870092
	.long 0xd7006a05                                           // 0000001A1A3C: D7006A05
	v_cndmask_b32_e32 v1, s38, v97, vcc_lo                     // 0000001A1A40: 0202C226
	v_add_co_ci_u32_e64 v6, null, s39, v98, vcc_lo             // 0000001A1A44: D5207C06 01AAC427
	s_clause 0xf                                               // 0000001A1A4C: BF85000F
	global_load_b128 v[89:92], v[5:6], off                     // 0000001A1A50: DC5E0000 597C0005
	global_load_b128 v[93:96], v[5:6], off offset:16           // 0000001A1A58: DC5E0010 5D7C0005
	global_load_b128 v[81:84], v[5:6], off offset:32           // 0000001A1A60: DC5E0020 517C0005
	global_load_b128 v[85:88], v[5:6], off offset:48           // 0000001A1A68: DC5E0030 557C0005
	global_load_b128 v[73:76], v[5:6], off offset:64           // 0000001A1A70: DC5E0040 497C0005
	global_load_b128 v[77:80], v[5:6], off offset:80           // 0000001A1A78: DC5E0050 4D7C0005
	global_load_b128 v[65:68], v[5:6], off offset:96           // 0000001A1A80: DC5E0060 417C0005
	global_load_b128 v[69:72], v[5:6], off offset:112          // 0000001A1A88: DC5E0070 457C0005
	global_load_b128 v[57:60], v[5:6], off offset:128          // 0000001A1A90: DC5E0080 397C0005
	global_load_b128 v[61:64], v[5:6], off offset:144          // 0000001A1A98: DC5E0090 3D7C0005
	global_load_b128 v[33:36], v[5:6], off offset:160          // 0000001A1AA0: DC5E00A0 217C0005
	global_load_b128 v[37:40], v[5:6], off offset:176          // 0000001A1AA8: DC5E00B0 257C0005
	global_load_b128 v[9:12], v[5:6], off offset:192           // 0000001A1AB0: DC5E00C0 097C0005
	global_load_b128 v[13:16], v[5:6], off offset:208          // 0000001A1AB8: DC5E00D0 0D7C0005
	global_load_b128 v[1:4], v[5:6], off offset:224            // 0000001A1AC0: DC5E00E0 017C0005
	global_load_b128 v[5:8], v[5:6], off offset:240            // 0000001A1AC8: DC5E00F0 057C0005
	s_cselect_b32 s0, -1, 0                                    // 0000001A1AD0: 980080C1
	s_or_b32 s1, s41, 16                                       // 0000001A1AD4: 8C019029
	v_cndmask_b16 v24, 0, v24, s0                              // 0000001A1AD8: D65D5018 00023080
	s_cmp_lt_i32 s1, s67                                       // 0000001A1AE0: BF044301
	ds_store_b128 v131, v[17:20]                               // 0000001A1AE4: DB7C0000 00001183
	ds_store_b128 v131, v[21:24] offset:16                     // 0000001A1AEC: DB7C0010 00001583
	s_cselect_b32 s0, -1, 0                                    // 0000001A1AF4: 980080C1
	ds_load_2addr_b32 v[19:20], v165 offset1:1                 // 0000001A1AF8: D8DC0100 130000A5
	v_cndmask_b16 v197, 0, v54, s0                             // 0000001A1B00: D65D00C5 00026C80
	s_or_b32 s0, s41, 17                                       // 0000001A1B08: 8C009129
	v_fma_mixlo_f16 v54, v55, s28, 0                           // 0000001A1B0C: CC210036 02003937
	s_cmp_lt_i32 s0, s67                                       // 0000001A1B14: BF044300
	v_mul_f32_e32 v55, v193, v200                              // 0000001A1B18: 106F91C1
	s_cselect_b32 s0, -1, 0                                    // 0000001A1B1C: 980080C1
	s_or_b32 s1, s41, 18                                       // 0000001A1B20: 8C019229
	v_cndmask_b16 v197, 0, v54, s0                             // 0000001A1B24: D65D40C5 00026C80
	s_cmp_lt_i32 s1, s67                                       // 0000001A1B2C: BF044301
	v_mul_f32_e32 v193, v195, v202                             // 0000001A1B30: 118395C3
	s_cselect_b32 s0, -1, 0                                    // 0000001A1B34: 980080C1
	s_or_b32 s1, s41, 19                                       // 0000001A1B38: 8C019329
	v_cndmask_b16 v198, 0, v54, s0                             // 0000001A1B3C: D65D10C6 00026C80
	v_mul_f32_e32 v54, v192, v199                              // 0000001A1B44: 106D8FC0
	s_cmp_lt_i32 s1, s67                                       // 0000001A1B48: BF044301
	ds_load_2addr_b32 v[21:22], v166 offset1:1                 // 0000001A1B4C: D8DC0100 150000A6
	ds_load_2addr_b32 v[23:24], v167 offset1:1                 // 0000001A1B54: D8DC0100 170000A7
	s_cselect_b32 s0, -1, 0                                    // 0000001A1B5C: 980080C1
	s_or_b32 s1, s41, 20                                       // 0000001A1B60: 8C019429
	v_fma_mixlo_f16 v54, v54, s28, 0                           // 0000001A1B64: CC210036 02003936
	v_fma_mixhi_f16 v54, v55, s28, 0                           // 0000001A1B6C: CC220036 02003937
	ds_load_2addr_b32 v[55:56], v160 offset1:1                 // 0000001A1B74: D8DC0100 370000A0
	v_mul_f32_e32 v192, v196, v201                             // 0000001A1B7C: 118193C4
	s_cmp_lt_i32 s1, s67                                       // 0000001A1B80: BF044301
	v_cndmask_b16 v198, 0, v54, s0                             // 0000001A1B84: D65D40C6 00026C80
	s_cselect_b32 s1, -1, 0                                    // 0000001A1B8C: 980180C1
	s_or_b32 s9, s41, 21                                       // 0000001A1B90: 8C099529
	v_fma_mixlo_f16 v54, v192, s28, 0                          // 0000001A1B94: CC210036 020039C0
	v_mul_f32_e32 v192, v194, v203                             // 0000001A1B9C: 118197C2
	s_cmp_lt_i32 s9, s67                                       // 0000001A1BA0: BF044309
	v_cndmask_b16 v199, 0, v54, s1                             // 0000001A1BA4: D65D10C7 00066C80
	s_cselect_b32 s0, -1, 0                                    // 0000001A1BAC: 980080C1
	v_fma_mixhi_f16 v54, v193, s28, 0                          // 0000001A1BB0: CC220036 020039C1
	v_cndmask_b16 v199, 0, v54, s0                             // 0000001A1BB8: D65D40C7 00026C80
	v_fma_mixlo_f16 v54, v192, s28, 0                          // 0000001A1BC0: CC210036 020039C0
	ds_load_2addr_b32 v[192:193], v161 offset1:1               // 0000001A1BC8: D8DC0100 C00000A1
	s_or_b32 s9, s41, 22                                       // 0000001A1BD0: 8C099629
	ds_load_2addr_b32 v[194:195], v162 offset1:1               // 0000001A1BD4: D8DC0100 C20000A2
	ds_load_2addr_b32 v[201:202], v163 offset1:1               // 0000001A1BDC: D8DC0100 C90000A3
	s_cmp_lt_i32 s9, s67                                       // 0000001A1BE4: BF044309
	s_waitcnt lgkmcnt(6)                                       // 0000001A1BE8: BF89FC67
	v_dual_mul_f32 v19, v102, v19 :: v_dual_mul_f32 v20, v123, v20// 0000001A1BEC: C8C62766 1314297B
	s_cselect_b32 s1, -1, 0                                    // 0000001A1BF4: 980180C1
	s_or_b32 s9, s41, 23                                       // 0000001A1BF8: 8C099729
	v_cndmask_b16 v200, 0, v54, s1                             // 0000001A1BFC: D65D10C8 00066C80
	s_cmp_lt_i32 s9, s67                                       // 0000001A1C04: BF044309
	s_waitcnt lgkmcnt(3)                                       // 0000001A1C08: BF89FC37
	v_mul_f32_e32 v55, v187, v55                               // 0000001A1C0C: 106E6FBB
	s_cselect_b32 s0, -1, 0                                    // 0000001A1C10: 980080C1
	s_or_b32 s9, s41, 24                                       // 0000001A1C14: 8C099829
	v_cndmask_b16 v200, 0, v54, s0                             // 0000001A1C18: D65D40C8 00026C80
	v_mul_f32_e32 v54, v186, v204                              // 0000001A1C20: 106D99BA
	s_cmp_lt_i32 s9, s67                                       // 0000001A1C24: BF044309
	v_cmp_le_i32_e32 vcc_lo, s67, v205                         // 0000001A1C28: 7C879A43
	s_cselect_b32 s0, -1, 0                                    // 0000001A1C2C: 980080C1
	s_or_b32 s1, s41, 25                                       // 0000001A1C30: 8C019929
	v_fma_mixlo_f16 v54, v54, s28, 0                           // 0000001A1C34: CC210036 02003936
	v_fma_mixhi_f16 v54, v55, s28, 0                           // 0000001A1C3C: CC220036 02003937
	v_mul_f32_e32 v55, v190, v56                               // 0000001A1C44: 106E71BE
	s_waitcnt lgkmcnt(2)                                       // 0000001A1C48: BF89FC27
	v_mul_f32_e32 v56, v188, v192                              // 0000001A1C4C: 107181BC
	s_cmp_lt_i32 s1, s67                                       // 0000001A1C50: BF044301
	v_cndmask_b16 v186, 0, v54, s0                             // 0000001A1C54: D65D00BA 00026C80
	s_cselect_b32 s1, -1, 0                                    // 0000001A1C5C: 980180C1
	s_or_b32 s9, s41, 26                                       // 0000001A1C60: 8C099A29
	v_cndmask_b16 v186, 0, v54, s1                             // 0000001A1C64: D65D50BA 00066C80
	s_cmp_lt_i32 s9, s67                                       // 0000001A1C6C: BF044309
	v_fma_mixhi_f16 v54, v56, s28, 0                           // 0000001A1C70: CC220036 02003938
	s_waitcnt lgkmcnt(1)                                       // 0000001A1C78: BF89FC17
	v_mul_f32_e32 v56, v185, v195                              // 0000001A1C7C: 107187B9
	v_fma_mixlo_f16 v54, v55, s28, 0                           // 0000001A1C80: CC210036 02003937
	v_mul_f32_e32 v55, v189, v193                              // 0000001A1C88: 106F83BD
	s_cselect_b32 s0, -1, 0                                    // 0000001A1C8C: 980080C1
	s_or_b32 s9, s41, 27                                       // 0000001A1C90: 8C099B29
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A1C94: BF870009
	s_cmp_lt_i32 s9, s67                                       // 0000001A1C98: BF044309
	v_cndmask_b16 v187, 0, v54, s0                             // 0000001A1C9C: D65D00BB 00026C80
	v_fma_mixlo_f16 v54, v55, s28, 0                           // 0000001A1CA4: CC210036 02003937
	v_mul_f32_e32 v55, v184, v194                              // 0000001A1CAC: 106F85B8
	ds_load_2addr_b32 v[184:185], v164 offset1:1               // 0000001A1CB0: D8DC0100 B80000A4
	s_cselect_b32 s1, -1, 0                                    // 0000001A1CB8: 980180C1
	s_or_b32 s9, s41, 28                                       // 0000001A1CBC: 8C099C29
	v_cndmask_b16 v187, 0, v54, s1                             // 0000001A1CC0: D65D50BB 00066C80
	s_cmp_lt_i32 s9, s67                                       // 0000001A1CC8: BF044309
	s_waitcnt lgkmcnt(1)                                       // 0000001A1CCC: BF89FC17
	v_mul_f32_e32 v17, v183, v202                              // 0000001A1CD0: 102395B7
	s_cselect_b32 s0, -1, 0                                    // 0000001A1CD4: 980080C1
	s_or_b32 s9, s41, 29                                       // 0000001A1CD8: 8C099D29
	v_cndmask_b16 v188, 0, v54, s0                             // 0000001A1CDC: D65D00BC 00026C80
	s_cmp_lt_i32 s9, s67                                       // 0000001A1CE4: BF044309
	v_fma_mixlo_f16 v54, v55, s28, 0                           // 0000001A1CE8: CC210036 02003937
	s_cselect_b32 s0, -1, 0                                    // 0000001A1CF0: 980080C1
	s_or_b32 s1, s41, 30                                       // 0000001A1CF4: 8C019E29
	v_mul_f32_e32 v55, v191, v201                              // 0000001A1CF8: 106F93BF
	s_cmp_lt_i32 s1, s67                                       // 0000001A1CFC: BF044301
	v_cndmask_b16 v188, 0, v54, s0                             // 0000001A1D00: D65D40BC 00026C80
	s_cselect_b32 s1, -1, 0                                    // 0000001A1D08: 980180C1
	s_or_b32 s9, s41, 31                                       // 0000001A1D0C: 8C099F29
	v_fma_mixlo_f16 v55, v55, s28, 0                           // 0000001A1D10: CC210037 02003937
	s_cmp_lt_i32 s9, s67                                       // 0000001A1D18: BF044309
	s_waitcnt lgkmcnt(0)                                       // 0000001A1D1C: BF89FC07
	v_mul_f32_e32 v18, v182, v184                              // 0000001A1D20: 102571B6
	s_cselect_b32 s0, -1, 0                                    // 0000001A1D24: 980080C1
	v_fma_mixlo_f16 v17, v17, s28, 0                           // 0000001A1D28: CC210011 02003911
	v_cndmask_b16 v189, 0, v55, s0                             // 0000001A1D30: D65D40BD 00026E80
	s_or_b32 s0, s41, 32                                       // 0000001A1D38: 8C00A029
	v_fma_mixhi_f16 v54, v56, s28, 0                           // 0000001A1D3C: CC220036 02003938
	s_cmp_lt_i32 s0, s67                                       // 0000001A1D44: BF044300
	v_fma_mixhi_f16 v17, v18, s28, 0                           // 0000001A1D48: CC220011 02003912
	s_cselect_b32 s0, -1, 0                                    // 0000001A1D50: 980080C1
	v_fma_mixhi_f16 v18, v19, s28, 0                           // 0000001A1D54: CC220012 02003913
	v_cndmask_b16 v17, 0, v17, s0                              // 0000001A1D5C: D65D0011 00022280
	s_or_b32 s0, s41, 33                                       // 0000001A1D64: 8C00A129
	v_cndmask_b16 v189, 0, v54, s1                             // 0000001A1D68: D65D10BD 00066C80
	v_mul_f32_e32 v54, v122, v185                              // 0000001A1D70: 106D737A
	s_cmp_lt_i32 s0, s67                                       // 0000001A1D74: BF044300
	v_fma_mixlo_f16 v19, v20, s28, 0                           // 0000001A1D78: CC210013 02003914
	s_cselect_b32 s0, -1, 0                                    // 0000001A1D80: 980080C1
	s_or_b32 s1, s41, 34                                       // 0000001A1D84: 8C01A229
	v_mul_f32_e32 v20, v104, v21                               // 0000001A1D88: 10282B68
	s_cmp_lt_i32 s1, s67                                       // 0000001A1D8C: BF044301
	v_mul_f32_e32 v21, v105, v22                               // 0000001A1D90: 102A2D69
	v_fma_mixlo_f16 v18, v54, s28, 0                           // 0000001A1D94: CC210012 02003936
	v_cndmask_b16 v17, 0, v17, s0                              // 0000001A1D9C: D65D5011 00022280
	s_cselect_b32 s0, -1, 0                                    // 0000001A1DA4: 980080C1
	s_or_b32 s1, s41, 35                                       // 0000001A1DA8: 8C01A329
	ds_load_2addr_b32 v[54:55], v168 offset1:1                 // 0000001A1DAC: D8DC0100 360000A8
	s_cmp_lt_i32 s1, s67                                       // 0000001A1DB4: BF044301
	v_cndmask_b16 v18, 0, v18, s0                              // 0000001A1DB8: D65D0012 00022480
	s_cselect_b32 s0, -1, 0                                    // 0000001A1DC0: 980080C1
	s_or_b32 s1, s41, 36                                       // 0000001A1DC4: 8C01A429
	v_fma_mixhi_f16 v19, v20, s28, 0                           // 0000001A1DC8: CC220013 02003914
	v_mul_f32_e32 v22, v103, v23                               // 0000001A1DD0: 102C2F67
	v_fma_mixlo_f16 v20, v21, s28, 0                           // 0000001A1DD4: CC210014 02003915
	v_mul_f32_e32 v21, v99, v24                                // 0000001A1DDC: 102A3163
	ds_load_2addr_b32 v[23:24], v169 offset1:1                 // 0000001A1DE0: D8DC0100 170000A9
	s_cmp_lt_i32 s1, s67                                       // 0000001A1DE8: BF044301
	ds_load_2addr_b32 v[102:103], v170 offset1:1               // 0000001A1DEC: D8DC0100 660000AA
	ds_load_2addr_b32 v[104:105], v171 offset1:1               // 0000001A1DF4: D8DC0100 680000AB
	s_cselect_b32 s1, -1, 0                                    // 0000001A1DFC: 980180C1
	s_or_b32 s9, s41, 37                                       // 0000001A1E00: 8C09A529
	v_cndmask_b16 v18, 0, v18, s0                              // 0000001A1E04: D65D5012 00022480
	s_cmp_lt_i32 s9, s67                                       // 0000001A1E0C: BF044309
	v_cndmask_b16 v19, 0, v19, s1                              // 0000001A1E10: D65D0013 00062680
	s_cselect_b32 s0, -1, 0                                    // 0000001A1E18: 980080C1
	s_or_b32 s9, s41, 38                                       // 0000001A1E1C: 8C09A629
	v_fma_mixhi_f16 v20, v22, s28, 0                           // 0000001A1E20: CC220014 02003916
	s_cmp_lt_i32 s9, s67                                       // 0000001A1E28: BF044309
	v_cndmask_b16 v19, 0, v19, s0                              // 0000001A1E2C: D65D5013 00022680
	s_cselect_b32 s1, -1, 0                                    // 0000001A1E34: 980180C1
	s_or_b32 s9, s41, 39                                       // 0000001A1E38: 8C09A729
	v_cndmask_b16 v20, 0, v20, s1                              // 0000001A1E3C: D65D0014 00062880
	s_cmp_lt_i32 s9, s67                                       // 0000001A1E44: BF044309
	v_fma_mixlo_f16 v21, v21, s28, 0                           // 0000001A1E48: CC210015 02003915
	s_cselect_b32 s0, -1, 0                                    // 0000001A1E50: 980080C1
	s_or_b32 s1, s41, 40                                       // 0000001A1E54: 8C01A829
	v_cndmask_b16 v20, 0, v20, s0                              // 0000001A1E58: D65D5014 00022880
	s_cmp_lt_i32 s1, s67                                       // 0000001A1E60: BF044301
	s_waitcnt lgkmcnt(3)                                       // 0000001A1E64: BF89FC37
	v_mul_f32_e32 v22, v100, v54                               // 0000001A1E68: 102C6D64
	s_cselect_b32 s0, -1, 0                                    // 0000001A1E6C: 980080C1
	s_waitcnt lgkmcnt(2)                                       // 0000001A1E70: BF89FC27
	v_dual_mul_f32 v23, v48, v23 :: v_dual_mul_f32 v24, v46, v24// 0000001A1E74: C8C62F30 1718312E
	v_cndmask_b16 v21, 0, v21, s0                              // 0000001A1E7C: D65D0015 00022A80
	s_or_b32 s0, s41, 41                                       // 0000001A1E84: 8C00A929
	v_mul_f32_e32 v54, v101, v55                               // 0000001A1E88: 106C6F65
	s_cmp_lt_i32 s0, s67                                       // 0000001A1E8C: BF044300
	v_fma_mixhi_f16 v21, v22, s28, 0                           // 0000001A1E90: CC220015 02003916
	s_cselect_b32 s0, -1, 0                                    // 0000001A1E98: 980080C1
	s_or_b32 s1, s41, 42                                       // 0000001A1E9C: 8C01AA29
	v_fma_mixhi_f16 v22, v23, s28, 0                           // 0000001A1EA0: CC220016 02003917
	v_fma_mixlo_f16 v23, v24, s28, 0                           // 0000001A1EA8: CC210017 02003918
	s_waitcnt lgkmcnt(1)                                       // 0000001A1EB0: BF89FC17
	v_mul_f32_e32 v24, v42, v102                               // 0000001A1EB4: 1030CD2A
	ds_load_2addr_b32 v[99:100], v174 offset1:1                // 0000001A1EB8: D8DC0100 630000AE
	ds_load_2addr_b32 v[101:102], v175 offset1:1               // 0000001A1EC0: D8DC0100 650000AF
	s_cmp_lt_i32 s1, s67                                       // 0000001A1EC8: BF044301
	v_fma_mixlo_f16 v22, v54, s28, 0                           // 0000001A1ECC: CC210016 02003936
	v_cndmask_b16 v21, 0, v21, s0                              // 0000001A1ED4: D65D5015 00022A80
	s_cselect_b32 s0, -1, 0                                    // 0000001A1EDC: 980080C1
	s_or_b32 s1, s41, 43                                       // 0000001A1EE0: 8C01AB29
	ds_load_2addr_b32 v[54:55], v172 offset1:1                 // 0000001A1EE4: D8DC0100 360000AC
	s_cmp_lt_i32 s1, s67                                       // 0000001A1EEC: BF044301
	v_cndmask_b16 v22, 0, v22, s0                              // 0000001A1EF0: D65D0016 00022C80
	s_cselect_b32 s0, -1, 0                                    // 0000001A1EF8: 980080C1
	s_or_b32 s1, s41, 44                                       // 0000001A1EFC: 8C01AC29
	v_mul_f32_e32 v42, v50, v103                               // 0000001A1F00: 1054CF32
	s_cmp_lt_i32 s1, s67                                       // 0000001A1F04: BF044301
	v_cndmask_b16 v22, 0, v22, s0                              // 0000001A1F08: D65D5016 00022C80
	s_cselect_b32 s1, -1, 0                                    // 0000001A1F10: 980180C1
	s_or_b32 s9, s41, 45                                       // 0000001A1F14: 8C09AD29
	s_waitcnt lgkmcnt(3)                                       // 0000001A1F18: BF89FC37
	v_mul_f32_e32 v46, v49, v104                               // 0000001A1F1C: 105CD131
	s_cmp_lt_i32 s9, s67                                       // 0000001A1F20: BF044309
	ds_load_2addr_b32 v[48:49], v173 offset1:1                 // 0000001A1F24: D8DC0100 300000AD
	s_cselect_b32 s0, -1, 0                                    // 0000001A1F2C: 980080C1
	s_or_b32 s9, s41, 46                                       // 0000001A1F30: 8C09AE29
	s_waitcnt lgkmcnt(3)                                       // 0000001A1F34: BF89FC37
	v_mul_f32_e32 v41, v41, v99                                // 0000001A1F38: 1052C729
	s_cmp_lt_i32 s9, s67                                       // 0000001A1F3C: BF044309
	v_fma_mixhi_f16 v23, v24, s28, 0                           // 0000001A1F40: CC220017 02003918
	v_mul_f32_e32 v25, v25, v100                               // 0000001A1F48: 1032C919
	v_fma_mixlo_f16 v24, v42, s28, 0                           // 0000001A1F4C: CC210018 0200392A
	v_cndmask_b16 v23, 0, v23, s1                              // 0000001A1F54: D65D0017 00062E80
	s_cselect_b32 s1, -1, 0                                    // 0000001A1F5C: 980180C1
	s_or_b32 s9, s41, 47                                       // 0000001A1F60: 8C09AF29
	v_mul_f32_e32 v42, v43, v105                               // 0000001A1F64: 1054D32B
	s_cmp_lt_i32 s9, s67                                       // 0000001A1F68: BF044309
	v_fma_mixhi_f16 v24, v46, s28, 0                           // 0000001A1F6C: CC220018 0200392E
	v_cndmask_b16 v23, 0, v23, s0                              // 0000001A1F74: D65D5017 00022E80
	v_cndmask_b16 v24, 0, v24, s1                              // 0000001A1F7C: D65D0018 00063080
	s_cselect_b32 s0, -1, 0                                    // 0000001A1F84: 980080C1
	s_or_b32 s1, s41, 48                                       // 0000001A1F88: 8C01B029
	v_fma_mixlo_f16 v42, v42, s28, 0                           // 0000001A1F8C: CC21002A 0200392A
	s_cmp_lt_i32 s1, s67                                       // 0000001A1F94: BF044301
	v_cndmask_b16 v24, 0, v24, s0                              // 0000001A1F98: D65D5018 00023080
	s_cselect_b32 s0, -1, 0                                    // 0000001A1FA0: 980080C1
	s_waitcnt lgkmcnt(1)                                       // 0000001A1FA4: BF89FC17
	v_mul_f32_e32 v43, v29, v54                                // 0000001A1FA8: 10566D1D
	v_cndmask_b16 v29, 0, v42, s0                              // 0000001A1FAC: D65D001D 00025480
	s_or_b32 s0, s41, 49                                       // 0000001A1FB4: 8C00B129
	v_mul_f32_e32 v30, v30, v55                                // 0000001A1FB8: 103C6F1E
	s_cmp_lt_i32 s0, s67                                       // 0000001A1FBC: BF044300
	v_fma_mixhi_f16 v29, v43, s28, 0                           // 0000001A1FC0: CC22001D 0200392B
	s_cselect_b32 s0, -1, 0                                    // 0000001A1FC8: 980080C1
	s_or_b32 s1, s41, 50                                       // 0000001A1FCC: 8C01B229
	v_fma_mixlo_f16 v30, v30, s28, 0                           // 0000001A1FD0: CC21001E 0200391E
	s_cmp_lt_i32 s1, s67                                       // 0000001A1FD8: BF044301
	s_waitcnt lgkmcnt(0)                                       // 0000001A1FDC: BF89FC07
	v_mul_f32_e32 v31, v31, v48                                // 0000001A1FE0: 103E611F
	v_cndmask_b16 v29, 0, v29, s0                              // 0000001A1FE4: D65D501D 00023A80
	s_cselect_b32 s0, -1, 0                                    // 0000001A1FEC: 980080C1
	s_or_b32 s1, s41, 51                                       // 0000001A1FF0: 8C01B329
	v_cndmask_b16 v30, 0, v30, s0                              // 0000001A1FF4: D65D001E 00023C80
	s_cmp_lt_i32 s1, s67                                       // 0000001A1FFC: BF044301
	v_fma_mixhi_f16 v30, v31, s28, 0                           // 0000001A2000: CC22001E 0200391F
	s_cselect_b32 s0, -1, 0                                    // 0000001A2008: 980080C1
	s_or_b32 s1, s41, 52                                       // 0000001A200C: 8C01B429
	v_fma_mixhi_f16 v31, v41, s28, 0                           // 0000001A2010: CC22001F 02003929
	ds_load_2addr_b32 v[41:42], v176 offset1:1                 // 0000001A2018: D8DC0100 290000B0
	s_cmp_lt_i32 s1, s67                                       // 0000001A2020: BF044301
	v_mul_f32_e32 v32, v32, v49                                // 0000001A2024: 10406320
	s_cselect_b32 s1, -1, 0                                    // 0000001A2028: 980180C1
	s_or_b32 s9, s41, 53                                       // 0000001A202C: 8C09B529
	v_cndmask_b16 v30, 0, v30, s0                              // 0000001A2030: D65D501E 00023C80
	s_cmp_lt_i32 s9, s67                                       // 0000001A2038: BF044309
	v_fma_mixlo_f16 v31, v32, s28, 0                           // 0000001A203C: CC21001F 02003920
	s_cselect_b32 s0, -1, 0                                    // 0000001A2044: 980080C1
	v_mul_f32_e32 v26, v26, v101                               // 0000001A2048: 1034CB1A
	v_cndmask_b16 v31, 0, v31, s0                              // 0000001A204C: D65D501F 00023E80
	s_or_b32 s0, s41, 54                                       // 0000001A2054: 8C00B629
	v_fma_mixlo_f16 v25, v25, s28, 0                           // 0000001A2058: CC210019 02003919
	s_cmp_lt_i32 s0, s67                                       // 0000001A2060: BF044300
	v_cndmask_b16 v31, 0, v31, s1                              // 0000001A2064: D65D001F 00063E80
	s_cselect_b32 s0, -1, 0                                    // 0000001A206C: 980080C1
	s_or_b32 s1, s41, 55                                       // 0000001A2070: 8C01B729
	v_fma_mixhi_f16 v25, v26, s28, 0                           // 0000001A2074: CC220019 0200391A
	s_cmp_lt_i32 s1, s67                                       // 0000001A207C: BF044301
	v_cndmask_b16 v32, 0, v25, s0                              // 0000001A2080: D65D0020 00023280
	s_cselect_b32 s0, -1, 0                                    // 0000001A2088: 980080C1
	ds_load_2addr_b32 v[48:49], v177 offset1:1                 // 0000001A208C: D8DC0100 300000B1
	v_cndmask_b16 v32, 0, v25, s0                              // 0000001A2094: D65D5020 00023280
	v_mul_f32_e32 v25, v47, v102                               // 0000001A209C: 1032CD2F
	ds_load_2addr_b32 v[46:47], v178 offset1:1                 // 0000001A20A0: D8DC0100 2E0000B2
	s_waitcnt lgkmcnt(2)                                       // 0000001A20A8: BF89FC27
	v_dual_mul_f32 v26, v44, v41 :: v_dual_mul_f32 v41, v45, v42// 0000001A20AC: C8C6532C 1A28552D
	s_or_b32 s1, s41, 56                                       // 0000001A20B4: 8C01B829
	v_fma_mixlo_f16 v25, v25, s28, 0                           // 0000001A20B8: CC210019 02003919
	s_cmp_lt_i32 s1, s67                                       // 0000001A20C0: BF044301
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A20C4: BF870002
	v_fma_mixhi_f16 v25, v26, s28, 0                           // 0000001A20C8: CC220019 0200391A
	v_fma_mixlo_f16 v26, v41, s28, 0                           // 0000001A20D0: CC21001A 02003929
	ds_load_b32 v41, v107 offset:61692                         // 0000001A20D8: D8D8F0FC 2900006B
	s_cselect_b32 s0, -1, 0                                    // 0000001A20E0: 980080C1
	s_or_b32 s1, s41, 57                                       // 0000001A20E4: 8C01B929
	v_cndmask_b16 v25, 0, v25, s0                              // 0000001A20E8: D65D0019 00023280
	s_cmp_lt_i32 s1, s67                                       // 0000001A20F0: BF044301
	ds_store_b128 v131, v[197:200] offset:32                   // 0000001A20F4: DB7C0020 0000C583
	ds_store_b128 v131, v[186:189] offset:48                   // 0000001A20FC: DB7C0030 0000BA83
	s_cselect_b32 s1, -1, 0                                    // 0000001A2104: 980180C1
	s_or_b32 s9, s41, 58                                       // 0000001A2108: 8C09BA29
	v_cndmask_b16 v25, 0, v25, s1                              // 0000001A210C: D65D5019 00063280
	s_cmp_lt_i32 s9, s67                                       // 0000001A2114: BF044309
	s_waitcnt lgkmcnt(4)                                       // 0000001A2118: BF89FC47
	v_mul_f32_e32 v28, v28, v48                                // 0000001A211C: 1038611C
	s_cselect_b32 s0, -1, 0                                    // 0000001A2120: 980080C1
	v_mul_f32_e32 v27, v27, v49                                // 0000001A2124: 1036631B
	v_cndmask_b16 v26, 0, v26, s0                              // 0000001A2128: D65D001A 00023480
	s_or_b32 s0, s41, 59                                       // 0000001A2130: 8C00BB29
	s_waitcnt lgkmcnt(3)                                       // 0000001A2134: BF89FC37
	v_mul_f32_e32 v42, v51, v47                                // 0000001A2138: 10545F33
	s_cmp_lt_i32 s0, s67                                       // 0000001A213C: BF044300
	v_fma_mixlo_f16 v27, v27, s28, 0                           // 0000001A2140: CC21001B 0200391B
	s_cselect_b32 s0, -1, 0                                    // 0000001A2148: 980080C1
	s_or_b32 s1, s41, 60                                       // 0000001A214C: 8C01BC29
	s_waitcnt lgkmcnt(2)                                       // 0000001A2150: BF89FC27
	v_mul_f32_e32 v41, v53, v41                                // 0000001A2154: 10525335
	s_cmp_lt_i32 s1, s67                                       // 0000001A2158: BF044301
	v_fma_mixhi_f16 v26, v28, s28, 0                           // 0000001A215C: CC22001A 0200391C
	s_cselect_b32 s1, -1, 0                                    // 0000001A2164: 980180C1
	s_or_b32 s9, s41, 61                                       // 0000001A2168: 8C09BD29
	v_mul_f32_e32 v28, v52, v46                                // 0000001A216C: 10385D34
	s_cmp_lt_i32 s9, s67                                       // 0000001A2170: BF044309
	v_cndmask_b16 v26, 0, v26, s0                              // 0000001A2174: D65D501A 00023480
	v_cndmask_b16 v27, 0, v27, s1                              // 0000001A217C: D65D001B 00063680
	s_cselect_b32 s0, -1, 0                                    // 0000001A2184: 980080C1
	s_or_b32 s1, s41, 62                                       // 0000001A2188: 8C01BE29
	v_fma_mixhi_f16 v27, v28, s28, 0                           // 0000001A218C: CC22001B 0200391C
	s_cmp_lt_i32 s1, s67                                       // 0000001A2194: BF044301
	v_fma_mixlo_f16 v28, v42, s28, 0                           // 0000001A2198: CC21001C 0200392A
	s_cselect_b32 s1, -1, 0                                    // 0000001A21A0: 980180C1
	s_or_b32 s9, s41, 63                                       // 0000001A21A4: 8C09BF29
	v_fma_mixhi_f16 v28, v41, s28, 0                           // 0000001A21A8: CC22001C 02003929
	s_cmp_lt_i32 s9, s67                                       // 0000001A21B0: BF044309
	v_cndmask_b16 v27, 0, v27, s0                              // 0000001A21B4: D65D501B 00023680
	s_cselect_b32 s0, -1, 0                                    // 0000001A21BC: 980080C1
	v_cndmask_b16 v28, 0, v28, s1                              // 0000001A21C0: D65D001C 00063880
	v_cndmask_b16 v28, 0, v28, s0                              // 0000001A21C8: D65D501C 00023880
	ds_store_b128 v131, v[17:20] offset:64                     // 0000001A21D0: DB7C0040 00001183
	ds_store_b128 v131, v[21:24] offset:80                     // 0000001A21D8: DB7C0050 00001583
	ds_store_b128 v131, v[29:32] offset:96                     // 0000001A21E0: DB7C0060 00001D83
	ds_store_b128 v131, v[25:28] offset:112                    // 0000001A21E8: DB7C0070 00001983
	s_and_saveexec_b32 s0, vcc_lo                              // 0000001A21F0: BE80206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A21F4: BF870009
	s_xor_b32 s0, exec_lo, s0                                  // 0000001A21F8: 8D00007E
	s_cbranch_execz 67                                         // 0000001A21FC: BFA50043 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x290c>
	s_waitcnt vmcnt(1)                                         // 0000001A2200: BF8907F7
	v_mov_b32_e32 v1, 0                                        // 0000001A2204: 7E020280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A2208: BF870001
	v_mov_b32_e32 v2, v1                                       // 0000001A220C: 7E040301
	v_mov_b32_e32 v3, v1                                       // 0000001A2210: 7E060301
	v_mov_b32_e32 v4, v1                                       // 0000001A2214: 7E080301
	s_waitcnt vmcnt(0)                                         // 0000001A2218: BF8903F7
	v_mov_b32_e32 v5, v1                                       // 0000001A221C: 7E0A0301
	v_mov_b32_e32 v6, v1                                       // 0000001A2220: 7E0C0301
	v_mov_b32_e32 v7, v1                                       // 0000001A2224: 7E0E0301
	v_mov_b32_e32 v8, v1                                       // 0000001A2228: 7E100301
	v_mov_b32_e32 v9, v1                                       // 0000001A222C: 7E120301
	v_mov_b32_e32 v10, v1                                      // 0000001A2230: 7E140301
	v_mov_b32_e32 v11, v1                                      // 0000001A2234: 7E160301
	v_mov_b32_e32 v12, v1                                      // 0000001A2238: 7E180301
	v_mov_b32_e32 v13, v1                                      // 0000001A223C: 7E1A0301
	v_mov_b32_e32 v14, v1                                      // 0000001A2240: 7E1C0301
	v_mov_b32_e32 v15, v1                                      // 0000001A2244: 7E1E0301
	v_mov_b32_e32 v16, v1                                      // 0000001A2248: 7E200301
	v_mov_b32_e32 v33, v1                                      // 0000001A224C: 7E420301
	v_mov_b32_e32 v34, v1                                      // 0000001A2250: 7E440301
	v_mov_b32_e32 v35, v1                                      // 0000001A2254: 7E460301
	v_mov_b32_e32 v36, v1                                      // 0000001A2258: 7E480301
	v_mov_b32_e32 v37, v1                                      // 0000001A225C: 7E4A0301
	v_mov_b32_e32 v38, v1                                      // 0000001A2260: 7E4C0301
	v_mov_b32_e32 v39, v1                                      // 0000001A2264: 7E4E0301
	v_mov_b32_e32 v40, v1                                      // 0000001A2268: 7E500301
	v_mov_b32_e32 v57, v1                                      // 0000001A226C: 7E720301
	v_mov_b32_e32 v58, v1                                      // 0000001A2270: 7E740301
	v_mov_b32_e32 v59, v1                                      // 0000001A2274: 7E760301
	v_mov_b32_e32 v60, v1                                      // 0000001A2278: 7E780301
	v_mov_b32_e32 v61, v1                                      // 0000001A227C: 7E7A0301
	v_mov_b32_e32 v62, v1                                      // 0000001A2280: 7E7C0301
	v_mov_b32_e32 v63, v1                                      // 0000001A2284: 7E7E0301
	v_mov_b32_e32 v64, v1                                      // 0000001A2288: 7E800301
	v_mov_b32_e32 v65, v1                                      // 0000001A228C: 7E820301
	v_mov_b32_e32 v66, v1                                      // 0000001A2290: 7E840301
	v_mov_b32_e32 v67, v1                                      // 0000001A2294: 7E860301
	v_mov_b32_e32 v68, v1                                      // 0000001A2298: 7E880301
	v_mov_b32_e32 v69, v1                                      // 0000001A229C: 7E8A0301
	v_mov_b32_e32 v70, v1                                      // 0000001A22A0: 7E8C0301
	v_mov_b32_e32 v71, v1                                      // 0000001A22A4: 7E8E0301
	v_mov_b32_e32 v72, v1                                      // 0000001A22A8: 7E900301
	v_mov_b32_e32 v73, v1                                      // 0000001A22AC: 7E920301
	v_mov_b32_e32 v74, v1                                      // 0000001A22B0: 7E940301
	v_mov_b32_e32 v75, v1                                      // 0000001A22B4: 7E960301
	v_mov_b32_e32 v76, v1                                      // 0000001A22B8: 7E980301
	v_mov_b32_e32 v77, v1                                      // 0000001A22BC: 7E9A0301
	v_mov_b32_e32 v78, v1                                      // 0000001A22C0: 7E9C0301
	v_mov_b32_e32 v79, v1                                      // 0000001A22C4: 7E9E0301
	v_mov_b32_e32 v80, v1                                      // 0000001A22C8: 7EA00301
	v_mov_b32_e32 v81, v1                                      // 0000001A22CC: 7EA20301
	v_mov_b32_e32 v82, v1                                      // 0000001A22D0: 7EA40301
	v_mov_b32_e32 v83, v1                                      // 0000001A22D4: 7EA60301
	v_mov_b32_e32 v84, v1                                      // 0000001A22D8: 7EA80301
	v_mov_b32_e32 v85, v1                                      // 0000001A22DC: 7EAA0301
	v_mov_b32_e32 v86, v1                                      // 0000001A22E0: 7EAC0301
	v_mov_b32_e32 v87, v1                                      // 0000001A22E4: 7EAE0301
	v_mov_b32_e32 v88, v1                                      // 0000001A22E8: 7EB00301
	v_mov_b32_e32 v89, v1                                      // 0000001A22EC: 7EB20301
	v_mov_b32_e32 v90, v1                                      // 0000001A22F0: 7EB40301
	v_mov_b32_e32 v91, v1                                      // 0000001A22F4: 7EB60301
	v_mov_b32_e32 v92, v1                                      // 0000001A22F8: 7EB80301
	v_mov_b32_e32 v93, v1                                      // 0000001A22FC: 7EBA0301
	v_mov_b32_e32 v94, v1                                      // 0000001A2300: 7EBC0301
	v_mov_b32_e32 v95, v1                                      // 0000001A2304: 7EBE0301
	v_mov_b32_e32 v96, v1                                      // 0000001A2308: 7EC00301
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001A230C: 8C7E007E
	ds_load_b128 v[17:20], v134                                // 0000001A2310: DBFC0000 11000086
	ds_load_b128 v[21:24], v134 offset:16                      // 0000001A2318: DBFC0010 15000086
	ds_load_b128 v[25:28], v134 offset:32                      // 0000001A2320: DBFC0020 19000086
	ds_load_b128 v[29:32], v134 offset:48                      // 0000001A2328: DBFC0030 1D000086
	ds_load_b128 v[41:44], v134 offset:8448                    // 0000001A2330: DBFC2100 29000086
	ds_load_b128 v[45:48], v134 offset:8464                    // 0000001A2338: DBFC2110 2D000086
	ds_load_b128 v[49:52], v134 offset:8480                    // 0000001A2340: DBFC2120 31000086
	ds_load_b128 v[53:56], v134 offset:8496                    // 0000001A2348: DBFC2130 35000086
	ds_load_b128 v[99:102], v134 offset:16896                  // 0000001A2350: DBFC4200 63000086
	ds_load_b128 v[190:193], v134 offset:16912                 // 0000001A2358: DBFC4210 BE000086
	v_dual_mov_b32 v189, s51 :: v_dual_mov_b32 v188, s50       // 0000001A2360: CA100033 BDBC0032
	v_dual_mov_b32 v187, s49 :: v_dual_mov_b32 v186, s48       // 0000001A2368: CA100031 BBBA0030
	v_dual_mov_b32 v185, s47 :: v_dual_mov_b32 v184, s46       // 0000001A2370: CA10002F B9B8002E
	v_dual_mov_b32 v183, s45 :: v_dual_mov_b32 v182, s44       // 0000001A2378: CA10002D B7B6002C
	ds_load_b128 v[194:197], v134 offset:25344                 // 0000001A2380: DBFC6300 C2000086
	ds_load_b128 v[198:201], v134 offset:25360                 // 0000001A2388: DBFC6310 C6000086
	s_waitcnt lgkmcnt(11)                                      // 0000001A2390: BF89FCB7
	v_fma_mixlo_f16 v17, v17, s28, 0                           // 0000001A2394: CC210011 02003911
	v_fma_mixhi_f16 v17, v18, s28, 0                           // 0000001A239C: CC220011 02003912
	v_fma_mixlo_f16 v18, v19, s28, 0                           // 0000001A23A4: CC210012 02003913
	v_fma_mixhi_f16 v18, v20, s28, 0                           // 0000001A23AC: CC220012 02003914
	s_waitcnt lgkmcnt(10)                                      // 0000001A23B4: BF89FCA7
	v_fma_mixlo_f16 v19, v21, s28, 0                           // 0000001A23B8: CC210013 02003915
	v_fma_mixhi_f16 v19, v22, s28, 0                           // 0000001A23C0: CC220013 02003916
	v_fma_mixlo_f16 v20, v23, s28, 0                           // 0000001A23C8: CC210014 02003917
	v_fma_mixhi_f16 v20, v24, s28, 0                           // 0000001A23D0: CC220014 02003918
	s_waitcnt lgkmcnt(9)                                       // 0000001A23D8: BF89FC97
	v_fma_mixlo_f16 v21, v25, s28, 0                           // 0000001A23DC: CC210015 02003919
	v_fma_mixhi_f16 v21, v26, s28, 0                           // 0000001A23E4: CC220015 0200391A
	v_fma_mixlo_f16 v22, v27, s28, 0                           // 0000001A23EC: CC210016 0200391B
	v_fma_mixhi_f16 v22, v28, s28, 0                           // 0000001A23F4: CC220016 0200391C
	s_waitcnt lgkmcnt(8)                                       // 0000001A23FC: BF89FC87
	v_fma_mixlo_f16 v23, v29, s28, 0                           // 0000001A2400: CC210017 0200391D
	v_fma_mixhi_f16 v23, v30, s28, 0                           // 0000001A2408: CC220017 0200391E
	v_fma_mixlo_f16 v24, v31, s28, 0                           // 0000001A2410: CC210018 0200391F
	v_fma_mixhi_f16 v24, v32, s28, 0                           // 0000001A2418: CC220018 02003920
	s_waitcnt lgkmcnt(7)                                       // 0000001A2420: BF89FC77
	v_fma_mixlo_f16 v25, v41, s28, 0                           // 0000001A2424: CC210019 02003929
	v_fma_mixhi_f16 v25, v42, s28, 0                           // 0000001A242C: CC220019 0200392A
	v_fma_mixlo_f16 v26, v43, s28, 0                           // 0000001A2434: CC21001A 0200392B
	v_fma_mixhi_f16 v26, v44, s28, 0                           // 0000001A243C: CC22001A 0200392C
	s_waitcnt lgkmcnt(6)                                       // 0000001A2444: BF89FC67
	v_fma_mixlo_f16 v27, v45, s28, 0                           // 0000001A2448: CC21001B 0200392D
	v_fma_mixhi_f16 v27, v46, s28, 0                           // 0000001A2450: CC22001B 0200392E
	v_fma_mixlo_f16 v28, v47, s28, 0                           // 0000001A2458: CC21001C 0200392F
	v_fma_mixhi_f16 v28, v48, s28, 0                           // 0000001A2460: CC22001C 02003930
	s_waitcnt lgkmcnt(5)                                       // 0000001A2468: BF89FC57
	v_fma_mixlo_f16 v29, v49, s28, 0                           // 0000001A246C: CC21001D 02003931
	v_fma_mixhi_f16 v29, v50, s28, 0                           // 0000001A2474: CC22001D 02003932
	v_fma_mixlo_f16 v30, v51, s28, 0                           // 0000001A247C: CC21001E 02003933
	v_fma_mixhi_f16 v30, v52, s28, 0                           // 0000001A2484: CC22001E 02003934
	s_waitcnt lgkmcnt(4)                                       // 0000001A248C: BF89FC47
	v_fma_mixlo_f16 v31, v53, s28, 0                           // 0000001A2490: CC21001F 02003935
	v_fma_mixhi_f16 v31, v54, s28, 0                           // 0000001A2498: CC22001F 02003936
	v_fma_mixlo_f16 v32, v55, s28, 0                           // 0000001A24A0: CC210020 02003937
	v_fma_mixhi_f16 v32, v56, s28, 0                           // 0000001A24A8: CC220020 02003938
	s_waitcnt vmcnt(14)                                        // 0000001A24B0: BF893BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[17:24], v[182:189]// 0000001A24B4: CC404029 1EDA2359
	ds_load_b128 v[49:52], v134 offset:16928                   // 0000001A24BC: DBFC4220 31000086
	ds_load_b128 v[53:56], v134 offset:16944                   // 0000001A24C4: DBFC4230 35000086
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[25:32], v[182:189]// 0000001A24CC: CC404011 1EDA3359
	s_waitcnt lgkmcnt(5)                                       // 0000001A24D4: BF89FC57
	v_fma_mixlo_f16 v25, v99, s28, 0                           // 0000001A24D8: CC210019 02003963
	v_fma_mixhi_f16 v25, v100, s28, 0                          // 0000001A24E0: CC220019 02003964
	v_fma_mixlo_f16 v26, v101, s28, 0                          // 0000001A24E8: CC21001A 02003965
	v_fma_mixhi_f16 v26, v102, s28, 0                          // 0000001A24F0: CC22001A 02003966
	ds_load_b128 v[99:102], v134 offset:25376                  // 0000001A24F8: DBFC6320 63000086
	ds_load_b128 v[202:205], v134 offset:25392                 // 0000001A2500: DBFC6330 CA000086
	s_waitcnt lgkmcnt(6)                                       // 0000001A2508: BF89FC67
	v_fma_mixlo_f16 v27, v190, s28, 0                          // 0000001A250C: CC21001B 020039BE
	s_waitcnt lgkmcnt(5)                                       // 0000001A2514: BF89FC57
	v_fma_mixlo_f16 v190, v194, s28, 0                         // 0000001A2518: CC2100BE 020039C2
	v_fma_mixhi_f16 v190, v195, s28, 0                         // 0000001A2520: CC2200BE 020039C3
	v_fma_mixhi_f16 v27, v191, s28, 0                          // 0000001A2528: CC22001B 020039BF
	v_fma_mixlo_f16 v28, v192, s28, 0                          // 0000001A2530: CC21001C 020039C0
	v_fma_mixhi_f16 v28, v193, s28, 0                          // 0000001A2538: CC22001C 020039C1
	v_fma_mixlo_f16 v191, v196, s28, 0                         // 0000001A2540: CC2100BF 020039C4
	v_fma_mixhi_f16 v191, v197, s28, 0                         // 0000001A2548: CC2200BF 020039C5
	s_waitcnt lgkmcnt(4)                                       // 0000001A2550: BF89FC47
	v_fma_mixlo_f16 v192, v198, s28, 0                         // 0000001A2554: CC2100C0 020039C6
	v_fma_mixhi_f16 v192, v199, s28, 0                         // 0000001A255C: CC2200C0 020039C7
	s_waitcnt lgkmcnt(3)                                       // 0000001A2564: BF89FC37
	v_fma_mixlo_f16 v29, v49, s28, 0                           // 0000001A2568: CC21001D 02003931
	v_fma_mixhi_f16 v29, v50, s28, 0                           // 0000001A2570: CC22001D 02003932
	v_fma_mixlo_f16 v30, v51, s28, 0                           // 0000001A2578: CC21001E 02003933
	v_fma_mixhi_f16 v30, v52, s28, 0                           // 0000001A2580: CC22001E 02003934
	s_waitcnt lgkmcnt(2)                                       // 0000001A2588: BF89FC27
	v_fma_mixlo_f16 v31, v53, s28, 0                           // 0000001A258C: CC21001F 02003935
	v_fma_mixhi_f16 v31, v54, s28, 0                           // 0000001A2594: CC22001F 02003936
	v_fma_mixlo_f16 v32, v55, s28, 0                           // 0000001A259C: CC210020 02003937
	v_fma_mixhi_f16 v32, v56, s28, 0                           // 0000001A25A4: CC220020 02003938
	s_waitcnt lgkmcnt(1)                                       // 0000001A25AC: BF89FC17
	v_fma_mixlo_f16 v194, v99, s28, 0                          // 0000001A25B0: CC2100C2 02003963
	v_fma_mixhi_f16 v194, v100, s28, 0                         // 0000001A25B8: CC2200C2 02003964
	v_fma_mixlo_f16 v195, v101, s28, 0                         // 0000001A25C0: CC2100C3 02003965
	v_fma_mixhi_f16 v195, v102, s28, 0                         // 0000001A25C8: CC2200C3 02003966
	ds_load_b128 v[99:102], v134 offset:96                     // 0000001A25D0: DBFC0060 63000086
	v_fma_mixlo_f16 v193, v200, s28, 0                         // 0000001A25D8: CC2100C1 020039C8
	v_fma_mixhi_f16 v193, v201, s28, 0                         // 0000001A25E0: CC2200C1 020039C9
	s_waitcnt lgkmcnt(1)                                       // 0000001A25E8: BF89FC17
	v_fma_mixlo_f16 v196, v202, s28, 0                         // 0000001A25EC: CC2100C4 020039CA
	v_fma_mixhi_f16 v196, v203, s28, 0                         // 0000001A25F4: CC2200C4 020039CB
	v_fma_mixlo_f16 v197, v204, s28, 0                         // 0000001A25FC: CC2100C5 020039CC
	v_fma_mixhi_f16 v197, v205, s28, 0                         // 0000001A2604: CC2200C5 020039CD
	ds_load_b128 v[206:209], v134 offset:64                    // 0000001A260C: DBFC0040 CE000086
	ds_load_b128 v[198:201], v134 offset:80                    // 0000001A2614: DBFC0050 C6000086
	ds_load_b128 v[202:205], v134 offset:112                   // 0000001A261C: DBFC0070 CA000086
	v_wmma_f32_16x16x16_f16 v[49:56], v[89:96], v[25:32], v[182:189]// 0000001A2624: CC404031 1EDA3359
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[190:197], v[182:189]// 0000001A262C: CC404019 1EDB7D59
	ds_load_b128 v[182:185], v134 offset:8512                  // 0000001A2634: DBFC2140 B6000086
	ds_load_b128 v[186:189], v134 offset:8528                  // 0000001A263C: DBFC2150 BA000086
	ds_load_b128 v[190:193], v134 offset:8544                  // 0000001A2644: DBFC2160 BE000086
	ds_load_b128 v[194:197], v134 offset:16960                 // 0000001A264C: DBFC4240 C2000086
	ds_load_b128 v[210:213], v134 offset:25424                 // 0000001A2654: DBFC6350 D2000086
	ds_load_b128 v[214:217], v134 offset:25440                 // 0000001A265C: DBFC6360 D6000086
	ds_load_b128 v[218:221], v134 offset:25456                 // 0000001A2664: DBFC6370 DA000086
	s_waitcnt lgkmcnt(10)                                      // 0000001A266C: BF89FCA7
	v_fma_mixlo_f16 v93, v99, s28, 0                           // 0000001A2670: CC21005D 02003963
	v_fma_mixhi_f16 v93, v100, s28, 0                          // 0000001A2678: CC22005D 02003964
	v_fma_mixlo_f16 v94, v101, s28, 0                          // 0000001A2680: CC21005E 02003965
	v_fma_mixhi_f16 v94, v102, s28, 0                          // 0000001A2688: CC22005E 02003966
	ds_load_b128 v[99:102], v134 offset:8560                   // 0000001A2690: DBFC2170 63000086
	s_waitcnt lgkmcnt(10)                                      // 0000001A2698: BF89FCA7
	v_fma_mixlo_f16 v89, v206, s28, 0                          // 0000001A269C: CC210059 020039CE
	s_waitcnt lgkmcnt(9)                                       // 0000001A26A4: BF89FC97
	v_fma_mixlo_f16 v91, v198, s28, 0                          // 0000001A26A8: CC21005B 020039C6
	v_fma_mixhi_f16 v91, v199, s28, 0                          // 0000001A26B0: CC22005B 020039C7
	v_fma_mixlo_f16 v92, v200, s28, 0                          // 0000001A26B8: CC21005C 020039C8
	v_fma_mixhi_f16 v92, v201, s28, 0                          // 0000001A26C0: CC22005C 020039C9
	ds_load_b128 v[198:201], v134 offset:16976                 // 0000001A26C8: DBFC4250 C6000086
	v_fma_mixhi_f16 v89, v207, s28, 0                          // 0000001A26D0: CC220059 020039CF
	s_waitcnt lgkmcnt(8)                                       // 0000001A26D8: BF89FC87
	v_fma_mixlo_f16 v182, v182, s28, 0                         // 0000001A26DC: CC2100B6 020039B6
	v_fma_mixhi_f16 v182, v183, s28, 0                         // 0000001A26E4: CC2200B6 020039B7
	v_fma_mixhi_f16 v183, v185, s28, 0                         // 0000001A26EC: CC2200B7 020039B9
	s_waitcnt lgkmcnt(7)                                       // 0000001A26F4: BF89FC77
	v_fma_mixlo_f16 v185, v188, s28, 0                         // 0000001A26F8: CC2100B9 020039BC
	v_fma_mixhi_f16 v185, v189, s28, 0                         // 0000001A2700: CC2200B9 020039BD
	v_fma_mixlo_f16 v90, v208, s28, 0                          // 0000001A2708: CC21005A 020039D0
	v_fma_mixhi_f16 v90, v209, s28, 0                          // 0000001A2710: CC22005A 020039D1
	v_fma_mixlo_f16 v95, v202, s28, 0                          // 0000001A2718: CC21005F 020039CA
	v_fma_mixhi_f16 v95, v203, s28, 0                          // 0000001A2720: CC22005F 020039CB
	v_fma_mixlo_f16 v96, v204, s28, 0                          // 0000001A2728: CC210060 020039CC
	v_fma_mixhi_f16 v96, v205, s28, 0                          // 0000001A2730: CC220060 020039CD
	s_waitcnt lgkmcnt(1)                                       // 0000001A2738: BF89FC17
	v_fma_mixlo_f16 v188, v99, s28, 0                          // 0000001A273C: CC2100BC 02003963
	v_fma_mixhi_f16 v188, v100, s28, 0                         // 0000001A2744: CC2200BC 02003964
	v_fma_mixlo_f16 v189, v101, s28, 0                         // 0000001A274C: CC2100BD 02003965
	v_fma_mixhi_f16 v189, v102, s28, 0                         // 0000001A2754: CC2200BD 02003966
	ds_load_b128 v[99:102], v134 offset:25408                  // 0000001A275C: DBFC6340 63000086
	ds_load_b128 v[202:205], v134 offset:16992                 // 0000001A2764: DBFC4260 CA000086
	ds_load_b128 v[206:209], v134 offset:17008                 // 0000001A276C: DBFC4270 CE000086
	v_fma_mixlo_f16 v183, v184, s28, 0                         // 0000001A2774: CC2100B7 020039B8
	v_fma_mixhi_f16 v184, v187, s28, 0                         // 0000001A277C: CC2200B8 020039BB
	v_fma_mixlo_f16 v187, v192, s28, 0                         // 0000001A2784: CC2100BB 020039C0
	s_waitcnt lgkmcnt(3)                                       // 0000001A278C: BF89FC37
	v_fma_mixlo_f16 v192, v198, s28, 0                         // 0000001A2790: CC2100C0 020039C6
	v_fma_mixhi_f16 v192, v199, s28, 0                         // 0000001A2798: CC2200C0 020039C7
	v_fma_mixlo_f16 v184, v186, s28, 0                         // 0000001A27A0: CC2100B8 020039BA
	v_fma_mixlo_f16 v186, v190, s28, 0                         // 0000001A27A8: CC2100BA 020039BE
	v_fma_mixhi_f16 v186, v191, s28, 0                         // 0000001A27B0: CC2200BA 020039BF
	v_fma_mixhi_f16 v187, v193, s28, 0                         // 0000001A27B8: CC2200BB 020039C1
	v_fma_mixlo_f16 v190, v194, s28, 0                         // 0000001A27C0: CC2100BE 020039C2
	v_fma_mixhi_f16 v190, v195, s28, 0                         // 0000001A27C8: CC2200BE 020039C3
	v_fma_mixlo_f16 v191, v196, s28, 0                         // 0000001A27D0: CC2100BF 020039C4
	v_fma_mixhi_f16 v191, v197, s28, 0                         // 0000001A27D8: CC2200BF 020039C5
	v_fma_mixlo_f16 v193, v200, s28, 0                         // 0000001A27E0: CC2100C1 020039C8
	v_fma_mixhi_f16 v193, v201, s28, 0                         // 0000001A27E8: CC2200C1 020039C9
	v_fma_mixlo_f16 v200, v210, s28, 0                         // 0000001A27F0: CC2100C8 020039D2
	v_fma_mixhi_f16 v200, v211, s28, 0                         // 0000001A27F8: CC2200C8 020039D3
	s_waitcnt lgkmcnt(2)                                       // 0000001A2800: BF89FC27
	v_fma_mixlo_f16 v198, v99, s28, 0                          // 0000001A2804: CC2100C6 02003963
	v_fma_mixhi_f16 v198, v100, s28, 0                         // 0000001A280C: CC2200C6 02003964
	v_fma_mixlo_f16 v199, v101, s28, 0                         // 0000001A2814: CC2100C7 02003965
	v_fma_mixhi_f16 v199, v102, s28, 0                         // 0000001A281C: CC2200C7 02003966
	ds_load_b128 v[99:102], v134 offset:128                    // 0000001A2824: DBFC0080 63000086
	s_waitcnt lgkmcnt(2)                                       // 0000001A282C: BF89FC27
	v_fma_mixlo_f16 v194, v202, s28, 0                         // 0000001A2830: CC2100C2 020039CA
	v_fma_mixhi_f16 v194, v203, s28, 0                         // 0000001A2838: CC2200C2 020039CB
	v_fma_mixlo_f16 v195, v204, s28, 0                         // 0000001A2840: CC2100C3 020039CC
	v_fma_mixhi_f16 v195, v205, s28, 0                         // 0000001A2848: CC2200C3 020039CD
	s_waitcnt lgkmcnt(1)                                       // 0000001A2850: BF89FC17
	v_fma_mixlo_f16 v196, v206, s28, 0                         // 0000001A2854: CC2100C4 020039CE
	v_fma_mixhi_f16 v196, v207, s28, 0                         // 0000001A285C: CC2200C4 020039CF
	v_fma_mixlo_f16 v197, v208, s28, 0                         // 0000001A2864: CC2100C5 020039D0
	v_fma_mixhi_f16 v197, v209, s28, 0                         // 0000001A286C: CC2200C5 020039D1
	v_fma_mixlo_f16 v201, v212, s28, 0                         // 0000001A2874: CC2100C9 020039D4
	v_fma_mixhi_f16 v201, v213, s28, 0                         // 0000001A287C: CC2200C9 020039D5
	v_fma_mixlo_f16 v202, v214, s28, 0                         // 0000001A2884: CC2100CA 020039D6
	v_fma_mixhi_f16 v202, v215, s28, 0                         // 0000001A288C: CC2200CA 020039D7
	v_fma_mixlo_f16 v203, v216, s28, 0                         // 0000001A2894: CC2100CB 020039D8
	v_fma_mixhi_f16 v203, v217, s28, 0                         // 0000001A289C: CC2200CB 020039D9
	v_fma_mixlo_f16 v204, v218, s28, 0                         // 0000001A28A4: CC2100CC 020039DA
	v_fma_mixhi_f16 v204, v219, s28, 0                         // 0000001A28AC: CC2200CC 020039DB
	v_fma_mixlo_f16 v205, v220, s28, 0                         // 0000001A28B4: CC2100CD 020039DC
	v_fma_mixhi_f16 v205, v221, s28, 0                         // 0000001A28BC: CC2200CD 020039DD
	ds_load_b128 v[206:209], v134 offset:144                   // 0000001A28C4: DBFC0090 CE000086
	ds_load_b128 v[210:213], v134 offset:160                   // 0000001A28CC: DBFC00A0 D2000086
	s_waitcnt vmcnt(12)                                        // 0000001A28D4: BF8933F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[81:88], v[89:96], v[41:48]// 0000001A28D8: CC404029 1CA6B351
	ds_load_b128 v[89:92], v134 offset:176                     // 0000001A28E0: DBFC00B0 59000086
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[182:189], v[17:24]// 0000001A28E8: CC404011 1C476D51
	v_wmma_f32_16x16x16_f16 v[49:56], v[81:88], v[190:197], v[49:56]// 0000001A28F0: CC404031 1CC77D51
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[198:205], v[25:32]// 0000001A28F8: CC404019 1C678D51
	ds_load_b128 v[93:96], v134 offset:8576                    // 0000001A2900: DBFC2180 5D000086
	s_waitcnt lgkmcnt(4)                                       // 0000001A2908: BF89FC47
	v_fma_mixlo_f16 v81, v99, s28, 0                           // 0000001A290C: CC210051 02003963
	v_fma_mixhi_f16 v81, v100, s28, 0                          // 0000001A2914: CC220051 02003964
	v_fma_mixlo_f16 v82, v101, s28, 0                          // 0000001A291C: CC210052 02003965
	v_fma_mixhi_f16 v82, v102, s28, 0                          // 0000001A2924: CC220052 02003966
	ds_load_b128 v[99:102], v134 offset:8592                   // 0000001A292C: DBFC2190 63000086
	ds_load_b128 v[182:185], v134 offset:8608                  // 0000001A2934: DBFC21A0 B6000086
	ds_load_b128 v[186:189], v134 offset:8624                  // 0000001A293C: DBFC21B0 BA000086
	ds_load_b128 v[190:193], v134 offset:17024                 // 0000001A2944: DBFC4280 BE000086
	ds_load_b128 v[194:197], v134 offset:17040                 // 0000001A294C: DBFC4290 C2000086
	ds_load_b128 v[198:201], v134 offset:17072                 // 0000001A2954: DBFC42B0 C6000086
	ds_load_b128 v[202:205], v134 offset:25472                 // 0000001A295C: DBFC6380 CA000086
	ds_load_b128 v[214:217], v134 offset:25520                 // 0000001A2964: DBFC63B0 D6000086
	s_waitcnt lgkmcnt(11)                                      // 0000001A296C: BF89FCB7
	v_fma_mixlo_f16 v83, v206, s28, 0                          // 0000001A2970: CC210053 020039CE
	v_fma_mixhi_f16 v83, v207, s28, 0                          // 0000001A2978: CC220053 020039CF
	v_fma_mixlo_f16 v84, v208, s28, 0                          // 0000001A2980: CC210054 020039D0
	s_waitcnt lgkmcnt(9)                                       // 0000001A2988: BF89FC97
	v_fma_mixlo_f16 v88, v91, s28, 0                           // 0000001A298C: CC210058 0200395B
	v_fma_mixhi_f16 v88, v92, s28, 0                           // 0000001A2994: CC220058 0200395C
	v_fma_mixhi_f16 v84, v209, s28, 0                          // 0000001A299C: CC220054 020039D1
	v_fma_mixlo_f16 v85, v210, s28, 0                          // 0000001A29A4: CC210055 020039D2
	v_fma_mixhi_f16 v85, v211, s28, 0                          // 0000001A29AC: CC220055 020039D3
	v_fma_mixlo_f16 v86, v212, s28, 0                          // 0000001A29B4: CC210056 020039D4
	v_fma_mixhi_f16 v86, v213, s28, 0                          // 0000001A29BC: CC220056 020039D5
	ds_load_b128 v[206:209], v134 offset:25488                 // 0000001A29C4: DBFC6390 CE000086
	ds_load_b128 v[210:213], v134 offset:25504                 // 0000001A29CC: DBFC63A0 D2000086
	s_waitcnt lgkmcnt(9)                                       // 0000001A29D4: BF89FC97
	v_fma_mixlo_f16 v91, v99, s28, 0                           // 0000001A29D8: CC21005B 02003963
	v_fma_mixhi_f16 v91, v100, s28, 0                          // 0000001A29E0: CC22005B 02003964
	v_fma_mixlo_f16 v92, v101, s28, 0                          // 0000001A29E8: CC21005C 02003965
	v_fma_mixhi_f16 v92, v102, s28, 0                          // 0000001A29F0: CC22005C 02003966
	ds_load_b128 v[99:102], v134 offset:17056                  // 0000001A29F8: DBFC42A0 63000086
	v_fma_mixhi_f16 v87, v90, s28, 0                           // 0000001A2A00: CC220057 0200395A
	v_fma_mixlo_f16 v90, v95, s28, 0                           // 0000001A2A08: CC21005A 0200395F
	s_waitcnt lgkmcnt(8)                                       // 0000001A2A10: BF89FC87
	v_fma_mixlo_f16 v95, v186, s28, 0                          // 0000001A2A14: CC21005F 020039BA
	v_fma_mixhi_f16 v95, v187, s28, 0                          // 0000001A2A1C: CC22005F 020039BB
	v_fma_mixlo_f16 v87, v89, s28, 0                           // 0000001A2A24: CC210057 02003959
	v_fma_mixlo_f16 v89, v93, s28, 0                           // 0000001A2A2C: CC210059 0200395D
	v_fma_mixhi_f16 v89, v94, s28, 0                           // 0000001A2A34: CC220059 0200395E
	v_fma_mixhi_f16 v90, v96, s28, 0                           // 0000001A2A3C: CC22005A 02003960
	v_fma_mixlo_f16 v93, v182, s28, 0                          // 0000001A2A44: CC21005D 020039B6
	v_fma_mixhi_f16 v93, v183, s28, 0                          // 0000001A2A4C: CC22005D 020039B7
	v_fma_mixlo_f16 v94, v184, s28, 0                          // 0000001A2A54: CC21005E 020039B8
	v_fma_mixhi_f16 v94, v185, s28, 0                          // 0000001A2A5C: CC22005E 020039B9
	v_fma_mixlo_f16 v96, v188, s28, 0                          // 0000001A2A64: CC210060 020039BC
	v_fma_mixhi_f16 v96, v189, s28, 0                          // 0000001A2A6C: CC220060 020039BD
	s_waitcnt lgkmcnt(7)                                       // 0000001A2A74: BF89FC77
	v_fma_mixlo_f16 v182, v190, s28, 0                         // 0000001A2A78: CC2100B6 020039BE
	v_fma_mixhi_f16 v182, v191, s28, 0                         // 0000001A2A80: CC2200B6 020039BF
	v_fma_mixlo_f16 v183, v192, s28, 0                         // 0000001A2A88: CC2100B7 020039C0
	v_fma_mixhi_f16 v183, v193, s28, 0                         // 0000001A2A90: CC2200B7 020039C1
	s_waitcnt lgkmcnt(6)                                       // 0000001A2A98: BF89FC67
	v_fma_mixlo_f16 v184, v194, s28, 0                         // 0000001A2A9C: CC2100B8 020039C2
	s_waitcnt lgkmcnt(0)                                       // 0000001A2AA4: BF89FC07
	v_fma_mixlo_f16 v186, v99, s28, 0                          // 0000001A2AA8: CC2100BA 02003963
	v_fma_mixhi_f16 v186, v100, s28, 0                         // 0000001A2AB0: CC2200BA 02003964
	v_fma_mixlo_f16 v187, v101, s28, 0                         // 0000001A2AB8: CC2100BB 02003965
	v_fma_mixhi_f16 v187, v102, s28, 0                         // 0000001A2AC0: CC2200BB 02003966
	ds_load_b128 v[99:102], v134 offset:192                    // 0000001A2AC8: DBFC00C0 63000086
	v_fma_mixhi_f16 v184, v195, s28, 0                         // 0000001A2AD0: CC2200B8 020039C3
	v_fma_mixlo_f16 v185, v196, s28, 0                         // 0000001A2AD8: CC2100B9 020039C4
	v_fma_mixhi_f16 v185, v197, s28, 0                         // 0000001A2AE0: CC2200B9 020039C5
	v_fma_mixlo_f16 v188, v198, s28, 0                         // 0000001A2AE8: CC2100BC 020039C6
	v_fma_mixhi_f16 v188, v199, s28, 0                         // 0000001A2AF0: CC2200BC 020039C7
	v_fma_mixlo_f16 v189, v200, s28, 0                         // 0000001A2AF8: CC2100BD 020039C8
	v_fma_mixhi_f16 v189, v201, s28, 0                         // 0000001A2B00: CC2200BD 020039C9
	v_fma_mixlo_f16 v190, v202, s28, 0                         // 0000001A2B08: CC2100BE 020039CA
	v_fma_mixhi_f16 v190, v203, s28, 0                         // 0000001A2B10: CC2200BE 020039CB
	v_fma_mixlo_f16 v191, v204, s28, 0                         // 0000001A2B18: CC2100BF 020039CC
	v_fma_mixhi_f16 v191, v205, s28, 0                         // 0000001A2B20: CC2200BF 020039CD
	v_fma_mixlo_f16 v192, v206, s28, 0                         // 0000001A2B28: CC2100C0 020039CE
	v_fma_mixhi_f16 v192, v207, s28, 0                         // 0000001A2B30: CC2200C0 020039CF
	v_fma_mixlo_f16 v193, v208, s28, 0                         // 0000001A2B38: CC2100C1 020039D0
	v_fma_mixhi_f16 v193, v209, s28, 0                         // 0000001A2B40: CC2200C1 020039D1
	v_fma_mixlo_f16 v194, v210, s28, 0                         // 0000001A2B48: CC2100C2 020039D2
	v_fma_mixhi_f16 v194, v211, s28, 0                         // 0000001A2B50: CC2200C2 020039D3
	v_fma_mixlo_f16 v195, v212, s28, 0                         // 0000001A2B58: CC2100C3 020039D4
	v_fma_mixhi_f16 v195, v213, s28, 0                         // 0000001A2B60: CC2200C3 020039D5
	v_fma_mixlo_f16 v196, v214, s28, 0                         // 0000001A2B68: CC2100C4 020039D6
	v_fma_mixhi_f16 v196, v215, s28, 0                         // 0000001A2B70: CC2200C4 020039D7
	v_fma_mixlo_f16 v197, v216, s28, 0                         // 0000001A2B78: CC2100C5 020039D8
	v_fma_mixhi_f16 v197, v217, s28, 0                         // 0000001A2B80: CC2200C5 020039D9
	ds_load_b128 v[198:201], v134 offset:208                   // 0000001A2B88: DBFC00D0 C6000086
	ds_load_b128 v[202:205], v134 offset:224                   // 0000001A2B90: DBFC00E0 CA000086
	s_waitcnt vmcnt(10)                                        // 0000001A2B98: BF892BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[73:80], v[81:88], v[41:48]// 0000001A2B9C: CC404029 1CA6A349
	ds_load_b128 v[81:84], v134 offset:240                     // 0000001A2BA4: DBFC00F0 51000086
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[89:96], v[17:24]// 0000001A2BAC: CC404011 1C46B349
	v_wmma_f32_16x16x16_f16 v[49:56], v[73:80], v[182:189], v[49:56]// 0000001A2BB4: CC404031 1CC76D49
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[190:197], v[25:32]// 0000001A2BBC: CC404019 1C677D49
	ds_load_b128 v[85:88], v134 offset:8640                    // 0000001A2BC4: DBFC21C0 55000086
	ds_load_b128 v[89:92], v134 offset:8656                    // 0000001A2BCC: DBFC21D0 59000086
	s_waitcnt lgkmcnt(5)                                       // 0000001A2BD4: BF89FC57
	v_fma_mixlo_f16 v73, v99, s28, 0                           // 0000001A2BD8: CC210049 02003963
	v_fma_mixhi_f16 v73, v100, s28, 0                          // 0000001A2BE0: CC220049 02003964
	v_fma_mixlo_f16 v74, v101, s28, 0                          // 0000001A2BE8: CC21004A 02003965
	v_fma_mixhi_f16 v74, v102, s28, 0                          // 0000001A2BF0: CC22004A 02003966
	ds_load_b128 v[93:96], v134 offset:8672                    // 0000001A2BF8: DBFC21E0 5D000086
	ds_load_b128 v[99:102], v134 offset:8688                   // 0000001A2C00: DBFC21F0 63000086
	ds_load_b128 v[182:185], v134 offset:17088                 // 0000001A2C08: DBFC42C0 B6000086
	ds_load_b128 v[186:189], v134 offset:17104                 // 0000001A2C10: DBFC42D0 BA000086
	ds_load_b128 v[190:193], v134 offset:17120                 // 0000001A2C18: DBFC42E0 BE000086
	ds_load_b128 v[194:197], v134 offset:17136                 // 0000001A2C20: DBFC42F0 C2000086
	s_waitcnt lgkmcnt(10)                                      // 0000001A2C28: BF89FCA7
	v_fma_mixlo_f16 v75, v198, s28, 0                          // 0000001A2C2C: CC21004B 020039C6
	v_fma_mixhi_f16 v75, v199, s28, 0                          // 0000001A2C34: CC22004B 020039C7
	v_fma_mixlo_f16 v76, v200, s28, 0                          // 0000001A2C3C: CC21004C 020039C8
	s_waitcnt lgkmcnt(8)                                       // 0000001A2C44: BF89FC87
	v_fma_mixhi_f16 v79, v82, s28, 0                           // 0000001A2C48: CC22004F 02003952
	v_fma_mixhi_f16 v76, v201, s28, 0                          // 0000001A2C50: CC22004C 020039C9
	v_fma_mixlo_f16 v77, v202, s28, 0                          // 0000001A2C58: CC21004D 020039CA
	v_fma_mixhi_f16 v77, v203, s28, 0                          // 0000001A2C60: CC22004D 020039CB
	s_waitcnt lgkmcnt(7)                                       // 0000001A2C68: BF89FC77
	v_fma_mixlo_f16 v82, v87, s28, 0                           // 0000001A2C6C: CC210052 02003957
	v_fma_mixhi_f16 v82, v88, s28, 0                           // 0000001A2C74: CC220052 02003958
	v_fma_mixlo_f16 v78, v204, s28, 0                          // 0000001A2C7C: CC21004E 020039CC
	v_fma_mixhi_f16 v78, v205, s28, 0                          // 0000001A2C84: CC22004E 020039CD
	v_fma_mixlo_f16 v79, v81, s28, 0                           // 0000001A2C8C: CC21004F 02003951
	v_fma_mixhi_f16 v80, v84, s28, 0                           // 0000001A2C94: CC220050 02003954
	v_fma_mixlo_f16 v81, v85, s28, 0                           // 0000001A2C9C: CC210051 02003955
	s_waitcnt lgkmcnt(4)                                       // 0000001A2CA4: BF89FC47
	v_fma_mixlo_f16 v87, v99, s28, 0                           // 0000001A2CA8: CC210057 02003963
	v_fma_mixhi_f16 v87, v100, s28, 0                          // 0000001A2CB0: CC220057 02003964
	v_fma_mixlo_f16 v88, v101, s28, 0                          // 0000001A2CB8: CC210058 02003965
	v_fma_mixhi_f16 v88, v102, s28, 0                          // 0000001A2CC0: CC220058 02003966
	ds_load_b128 v[99:102], v134 offset:25536                  // 0000001A2CC8: DBFC63C0 63000086
	ds_load_b128 v[198:201], v134 offset:25552                 // 0000001A2CD0: DBFC63D0 C6000086
	v_fma_mixhi_f16 v84, v92, s28, 0                           // 0000001A2CD8: CC220054 0200395C
	v_fma_mixlo_f16 v85, v93, s28, 0                           // 0000001A2CE0: CC210055 0200395D
	s_waitcnt lgkmcnt(4)                                       // 0000001A2CE8: BF89FC47
	v_fma_mixlo_f16 v92, v188, s28, 0                          // 0000001A2CEC: CC21005C 020039BC
	ds_load_b128 v[202:205], v134 offset:25568                 // 0000001A2CF4: DBFC63E0 CA000086
	v_fma_mixhi_f16 v92, v189, s28, 0                          // 0000001A2CFC: CC22005C 020039BD
	s_waitcnt lgkmcnt(4)                                       // 0000001A2D04: BF89FC47
	v_fma_mixlo_f16 v93, v190, s28, 0                          // 0000001A2D08: CC21005D 020039BE
	v_fma_mixhi_f16 v93, v191, s28, 0                          // 0000001A2D10: CC22005D 020039BF
	ds_load_b128 v[188:191], v134 offset:25584                 // 0000001A2D18: DBFC63F0 BC000086
	v_fma_mixlo_f16 v80, v83, s28, 0                           // 0000001A2D20: CC210050 02003953
	v_fma_mixlo_f16 v83, v89, s28, 0                           // 0000001A2D28: CC210053 02003959
	v_fma_mixlo_f16 v89, v182, s28, 0                          // 0000001A2D30: CC210059 020039B6
	v_fma_mixhi_f16 v89, v183, s28, 0                          // 0000001A2D38: CC220059 020039B7
	v_fma_mixhi_f16 v81, v86, s28, 0                           // 0000001A2D40: CC220051 02003956
	v_fma_mixhi_f16 v83, v90, s28, 0                           // 0000001A2D48: CC220053 0200395A
	v_fma_mixlo_f16 v84, v91, s28, 0                           // 0000001A2D50: CC210054 0200395B
	v_fma_mixhi_f16 v85, v94, s28, 0                           // 0000001A2D58: CC220055 0200395E
	v_fma_mixlo_f16 v86, v95, s28, 0                           // 0000001A2D60: CC210056 0200395F
	v_fma_mixhi_f16 v86, v96, s28, 0                           // 0000001A2D68: CC220056 02003960
	s_waitcnt lgkmcnt(3)                                       // 0000001A2D70: BF89FC37
	v_fma_mixlo_f16 v182, v99, s28, 0                          // 0000001A2D74: CC2100B6 02003963
	v_fma_mixhi_f16 v182, v100, s28, 0                         // 0000001A2D7C: CC2200B6 02003964
	v_fma_mixlo_f16 v183, v101, s28, 0                         // 0000001A2D84: CC2100B7 02003965
	v_fma_mixhi_f16 v183, v102, s28, 0                         // 0000001A2D8C: CC2200B7 02003966
	ds_load_b128 v[99:102], v134 offset:256                    // 0000001A2D94: DBFC0100 63000086
	v_fma_mixlo_f16 v90, v184, s28, 0                          // 0000001A2D9C: CC21005A 020039B8
	v_fma_mixhi_f16 v90, v185, s28, 0                          // 0000001A2DA4: CC22005A 020039B9
	v_fma_mixlo_f16 v91, v186, s28, 0                          // 0000001A2DAC: CC21005B 020039BA
	v_fma_mixhi_f16 v91, v187, s28, 0                          // 0000001A2DB4: CC22005B 020039BB
	v_fma_mixlo_f16 v94, v192, s28, 0                          // 0000001A2DBC: CC21005E 020039C0
	v_fma_mixhi_f16 v94, v193, s28, 0                          // 0000001A2DC4: CC22005E 020039C1
	v_fma_mixlo_f16 v95, v194, s28, 0                          // 0000001A2DCC: CC21005F 020039C2
	v_fma_mixhi_f16 v95, v195, s28, 0                          // 0000001A2DD4: CC22005F 020039C3
	v_fma_mixlo_f16 v96, v196, s28, 0                          // 0000001A2DDC: CC210060 020039C4
	v_fma_mixhi_f16 v96, v197, s28, 0                          // 0000001A2DE4: CC220060 020039C5
	s_waitcnt lgkmcnt(3)                                       // 0000001A2DEC: BF89FC37
	v_fma_mixlo_f16 v184, v198, s28, 0                         // 0000001A2DF0: CC2100B8 020039C6
	v_fma_mixhi_f16 v184, v199, s28, 0                         // 0000001A2DF8: CC2200B8 020039C7
	v_fma_mixlo_f16 v185, v200, s28, 0                         // 0000001A2E00: CC2100B9 020039C8
	v_fma_mixhi_f16 v185, v201, s28, 0                         // 0000001A2E08: CC2200B9 020039C9
	s_waitcnt lgkmcnt(2)                                       // 0000001A2E10: BF89FC27
	v_fma_mixlo_f16 v186, v202, s28, 0                         // 0000001A2E14: CC2100BA 020039CA
	v_fma_mixhi_f16 v186, v203, s28, 0                         // 0000001A2E1C: CC2200BA 020039CB
	v_fma_mixlo_f16 v187, v204, s28, 0                         // 0000001A2E24: CC2100BB 020039CC
	v_fma_mixhi_f16 v187, v205, s28, 0                         // 0000001A2E2C: CC2200BB 020039CD
	s_waitcnt lgkmcnt(1)                                       // 0000001A2E34: BF89FC17
	v_fma_mixlo_f16 v188, v188, s28, 0                         // 0000001A2E38: CC2100BC 020039BC
	v_fma_mixhi_f16 v188, v189, s28, 0                         // 0000001A2E40: CC2200BC 020039BD
	v_fma_mixlo_f16 v189, v190, s28, 0                         // 0000001A2E48: CC2100BD 020039BE
	v_fma_mixhi_f16 v189, v191, s28, 0                         // 0000001A2E50: CC2200BD 020039BF
	ds_load_b128 v[192:195], v134 offset:272                   // 0000001A2E58: DBFC0110 C0000086
	ds_load_b128 v[196:199], v134 offset:288                   // 0000001A2E60: DBFC0120 C4000086
	s_waitcnt vmcnt(8)                                         // 0000001A2E68: BF8923F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[73:80], v[41:48]// 0000001A2E6C: CC404029 1CA69341
	ds_load_b128 v[73:76], v134 offset:304                     // 0000001A2E74: DBFC0130 49000086
	v_wmma_f32_16x16x16_f16 v[17:24], v[65:72], v[81:88], v[17:24]// 0000001A2E7C: CC404011 1C46A341
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[89:96], v[49:56]// 0000001A2E84: CC404031 1CC6B341
	v_wmma_f32_16x16x16_f16 v[25:32], v[65:72], v[182:189], v[25:32]// 0000001A2E8C: CC404019 1C676D41
	ds_load_b128 v[77:80], v134 offset:8704                    // 0000001A2E94: DBFC2200 4D000086
	ds_load_b128 v[81:84], v134 offset:8720                    // 0000001A2E9C: DBFC2210 51000086
	s_waitcnt lgkmcnt(5)                                       // 0000001A2EA4: BF89FC57
	v_fma_mixlo_f16 v65, v99, s28, 0                           // 0000001A2EA8: CC210041 02003963
	v_fma_mixhi_f16 v65, v100, s28, 0                          // 0000001A2EB0: CC220041 02003964
	v_fma_mixlo_f16 v66, v101, s28, 0                          // 0000001A2EB8: CC210042 02003965
	v_fma_mixhi_f16 v66, v102, s28, 0                          // 0000001A2EC0: CC220042 02003966
	ds_load_b128 v[85:88], v134 offset:8736                    // 0000001A2EC8: DBFC2220 55000086
	ds_load_b128 v[89:92], v134 offset:8752                    // 0000001A2ED0: DBFC2230 59000086
	ds_load_b128 v[93:96], v134 offset:17152                   // 0000001A2ED8: DBFC4300 5D000086
	ds_load_b128 v[99:102], v134 offset:17168                  // 0000001A2EE0: DBFC4310 63000086
	ds_load_b128 v[182:185], v134 offset:17184                 // 0000001A2EE8: DBFC4320 B6000086
	ds_load_b128 v[186:189], v134 offset:17200                 // 0000001A2EF0: DBFC4330 BA000086
	s_waitcnt lgkmcnt(10)                                      // 0000001A2EF8: BF89FCA7
	v_fma_mixlo_f16 v67, v192, s28, 0                          // 0000001A2EFC: CC210043 020039C0
	v_fma_mixhi_f16 v67, v193, s28, 0                          // 0000001A2F04: CC220043 020039C1
	ds_load_b128 v[190:193], v134 offset:25616                 // 0000001A2F0C: DBFC6410 BE000086
	s_waitcnt lgkmcnt(9)                                       // 0000001A2F14: BF89FC97
	v_fma_mixhi_f16 v71, v74, s28, 0                           // 0000001A2F18: CC220047 0200394A
	v_fma_mixlo_f16 v72, v75, s28, 0                           // 0000001A2F20: CC210048 0200394B
	v_fma_mixhi_f16 v72, v76, s28, 0                           // 0000001A2F28: CC220048 0200394C
	v_fma_mixlo_f16 v68, v194, s28, 0                          // 0000001A2F30: CC210044 020039C2
	s_waitcnt lgkmcnt(8)                                       // 0000001A2F38: BF89FC87
	v_fma_mixlo_f16 v74, v79, s28, 0                           // 0000001A2F3C: CC21004A 0200394F
	v_fma_mixhi_f16 v74, v80, s28, 0                           // 0000001A2F44: CC22004A 02003950
	s_waitcnt lgkmcnt(7)                                       // 0000001A2F4C: BF89FC77
	v_fma_mixlo_f16 v75, v81, s28, 0                           // 0000001A2F50: CC21004B 02003951
	v_fma_mixhi_f16 v75, v82, s28, 0                           // 0000001A2F58: CC22004B 02003952
	v_fma_mixlo_f16 v76, v83, s28, 0                           // 0000001A2F60: CC21004C 02003953
	v_fma_mixhi_f16 v76, v84, s28, 0                           // 0000001A2F68: CC22004C 02003954
	v_fma_mixhi_f16 v68, v195, s28, 0                          // 0000001A2F70: CC220044 020039C3
	s_waitcnt lgkmcnt(5)                                       // 0000001A2F78: BF89FC57
	v_fma_mixlo_f16 v79, v89, s28, 0                           // 0000001A2F7C: CC21004F 02003959
	v_fma_mixhi_f16 v79, v90, s28, 0                           // 0000001A2F84: CC22004F 0200395A
	v_fma_mixlo_f16 v80, v91, s28, 0                           // 0000001A2F8C: CC210050 0200395B
	v_fma_mixhi_f16 v80, v92, s28, 0                           // 0000001A2F94: CC220050 0200395C
	ds_load_b128 v[89:92], v134 offset:25600                   // 0000001A2F9C: DBFC6400 59000086
	s_waitcnt lgkmcnt(5)                                       // 0000001A2FA4: BF89FC57
	v_fma_mixlo_f16 v81, v93, s28, 0                           // 0000001A2FA8: CC210051 0200395D
	v_fma_mixhi_f16 v81, v94, s28, 0                           // 0000001A2FB0: CC220051 0200395E
	v_fma_mixlo_f16 v82, v95, s28, 0                           // 0000001A2FB8: CC210052 0200395F
	v_fma_mixhi_f16 v82, v96, s28, 0                           // 0000001A2FC0: CC220052 02003960
	s_waitcnt lgkmcnt(4)                                       // 0000001A2FC8: BF89FC47
	v_fma_mixlo_f16 v83, v99, s28, 0                           // 0000001A2FCC: CC210053 02003963
	v_fma_mixhi_f16 v83, v100, s28, 0                          // 0000001A2FD4: CC220053 02003964
	v_fma_mixlo_f16 v84, v101, s28, 0                          // 0000001A2FDC: CC210054 02003965
	ds_load_b128 v[93:96], v134 offset:25632                   // 0000001A2FE4: DBFC6420 5D000086
	v_fma_mixhi_f16 v84, v102, s28, 0                          // 0000001A2FEC: CC220054 02003966
	ds_load_b128 v[99:102], v134 offset:25648                  // 0000001A2FF4: DBFC6430 63000086
	v_fma_mixlo_f16 v69, v196, s28, 0                          // 0000001A2FFC: CC210045 020039C4
	v_fma_mixhi_f16 v69, v197, s28, 0                          // 0000001A3004: CC220045 020039C5
	v_fma_mixlo_f16 v70, v198, s28, 0                          // 0000001A300C: CC210046 020039C6
	v_fma_mixhi_f16 v70, v199, s28, 0                          // 0000001A3014: CC220046 020039C7
	v_fma_mixlo_f16 v71, v73, s28, 0                           // 0000001A301C: CC210047 02003949
	v_fma_mixlo_f16 v73, v77, s28, 0                           // 0000001A3024: CC210049 0200394D
	v_fma_mixhi_f16 v73, v78, s28, 0                           // 0000001A302C: CC220049 0200394E
	v_fma_mixlo_f16 v77, v85, s28, 0                           // 0000001A3034: CC21004D 02003955
	v_fma_mixhi_f16 v77, v86, s28, 0                           // 0000001A303C: CC22004D 02003956
	v_fma_mixlo_f16 v78, v87, s28, 0                           // 0000001A3044: CC21004E 02003957
	v_fma_mixhi_f16 v78, v88, s28, 0                           // 0000001A304C: CC22004E 02003958
	s_waitcnt lgkmcnt(5)                                       // 0000001A3054: BF89FC57
	v_fma_mixlo_f16 v85, v182, s28, 0                          // 0000001A3058: CC210055 020039B6
	v_fma_mixhi_f16 v85, v183, s28, 0                          // 0000001A3060: CC220055 020039B7
	v_fma_mixlo_f16 v86, v184, s28, 0                          // 0000001A3068: CC210056 020039B8
	v_fma_mixhi_f16 v86, v185, s28, 0                          // 0000001A3070: CC220056 020039B9
	s_waitcnt lgkmcnt(4)                                       // 0000001A3078: BF89FC47
	v_fma_mixlo_f16 v87, v186, s28, 0                          // 0000001A307C: CC210057 020039BA
	v_fma_mixhi_f16 v87, v187, s28, 0                          // 0000001A3084: CC220057 020039BB
	v_fma_mixlo_f16 v88, v188, s28, 0                          // 0000001A308C: CC210058 020039BC
	v_fma_mixhi_f16 v88, v189, s28, 0                          // 0000001A3094: CC220058 020039BD
	s_waitcnt lgkmcnt(2)                                       // 0000001A309C: BF89FC27
	v_fma_mixlo_f16 v89, v89, s28, 0                           // 0000001A30A0: CC210059 02003959
	v_fma_mixhi_f16 v89, v90, s28, 0                           // 0000001A30A8: CC220059 0200395A
	v_fma_mixlo_f16 v90, v91, s28, 0                           // 0000001A30B0: CC21005A 0200395B
	v_fma_mixhi_f16 v90, v92, s28, 0                           // 0000001A30B8: CC22005A 0200395C
	v_fma_mixlo_f16 v91, v190, s28, 0                          // 0000001A30C0: CC21005B 020039BE
	v_fma_mixhi_f16 v91, v191, s28, 0                          // 0000001A30C8: CC22005B 020039BF
	v_fma_mixlo_f16 v92, v192, s28, 0                          // 0000001A30D0: CC21005C 020039C0
	v_fma_mixhi_f16 v92, v193, s28, 0                          // 0000001A30D8: CC22005C 020039C1
	s_waitcnt lgkmcnt(1)                                       // 0000001A30E0: BF89FC17
	v_fma_mixlo_f16 v93, v93, s28, 0                           // 0000001A30E4: CC21005D 0200395D
	v_fma_mixhi_f16 v93, v94, s28, 0                           // 0000001A30EC: CC22005D 0200395E
	v_fma_mixlo_f16 v94, v95, s28, 0                           // 0000001A30F4: CC21005E 0200395F
	v_fma_mixhi_f16 v94, v96, s28, 0                           // 0000001A30FC: CC22005E 02003960
	s_waitcnt lgkmcnt(0)                                       // 0000001A3104: BF89FC07
	v_fma_mixlo_f16 v95, v99, s28, 0                           // 0000001A3108: CC21005F 02003963
	v_fma_mixhi_f16 v95, v100, s28, 0                          // 0000001A3110: CC22005F 02003964
	v_fma_mixlo_f16 v96, v101, s28, 0                          // 0000001A3118: CC210060 02003965
	v_fma_mixhi_f16 v96, v102, s28, 0                          // 0000001A3120: CC220060 02003966
	ds_load_b128 v[182:185], v134 offset:320                   // 0000001A3128: DBFC0140 B6000086
	ds_load_b128 v[186:189], v134 offset:336                   // 0000001A3130: DBFC0150 BA000086
	ds_load_b128 v[190:193], v134 offset:352                   // 0000001A3138: DBFC0160 BE000086
	s_waitcnt vmcnt(6)                                         // 0000001A3140: BF891BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[57:64], v[65:72], v[41:48]// 0000001A3144: CC404029 1CA68339
	ds_load_b128 v[65:68], v134 offset:368                     // 0000001A314C: DBFC0170 41000086
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[73:80], v[17:24]// 0000001A3154: CC404011 1C469339
	v_wmma_f32_16x16x16_f16 v[49:56], v[57:64], v[81:88], v[49:56]// 0000001A315C: CC404031 1CC6A339
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[89:96], v[25:32]// 0000001A3164: CC404019 1C66B339
	ds_load_b128 v[69:72], v134 offset:8768                    // 0000001A316C: DBFC2240 45000086
	ds_load_b128 v[73:76], v134 offset:8784                    // 0000001A3174: DBFC2250 49000086
	ds_load_b128 v[77:80], v134 offset:8800                    // 0000001A317C: DBFC2260 4D000086
	ds_load_b128 v[81:84], v134 offset:8816                    // 0000001A3184: DBFC2270 51000086
	ds_load_b128 v[85:88], v134 offset:17216                   // 0000001A318C: DBFC4340 55000086
	ds_load_b128 v[89:92], v134 offset:17232                   // 0000001A3194: DBFC4350 59000086
	ds_load_b128 v[93:96], v134 offset:17248                   // 0000001A319C: DBFC4360 5D000086
	ds_load_b128 v[99:102], v134 offset:17264                  // 0000001A31A4: DBFC4370 63000086
	s_waitcnt lgkmcnt(11)                                      // 0000001A31AC: BF89FCB7
	v_fma_mixlo_f16 v57, v182, s28, 0                          // 0000001A31B0: CC210039 020039B6
	v_fma_mixhi_f16 v57, v183, s28, 0                          // 0000001A31B8: CC220039 020039B7
	v_fma_mixlo_f16 v58, v184, s28, 0                          // 0000001A31C0: CC21003A 020039B8
	v_fma_mixhi_f16 v58, v185, s28, 0                          // 0000001A31C8: CC22003A 020039B9
	s_waitcnt lgkmcnt(8)                                       // 0000001A31D0: BF89FC87
	v_fma_mixhi_f16 v63, v66, s28, 0                           // 0000001A31D4: CC22003F 02003942
	v_fma_mixlo_f16 v64, v67, s28, 0                           // 0000001A31DC: CC210040 02003943
	v_fma_mixhi_f16 v64, v68, s28, 0                           // 0000001A31E4: CC220040 02003944
	ds_load_b128 v[182:185], v134 offset:25680                 // 0000001A31EC: DBFC6450 B6000086
	s_waitcnt lgkmcnt(8)                                       // 0000001A31F4: BF89FC87
	v_fma_mixlo_f16 v66, v71, s28, 0                           // 0000001A31F8: CC210042 02003947
	v_fma_mixhi_f16 v66, v72, s28, 0                           // 0000001A3200: CC220042 02003948
	s_waitcnt lgkmcnt(7)                                       // 0000001A3208: BF89FC77
	v_fma_mixlo_f16 v67, v73, s28, 0                           // 0000001A320C: CC210043 02003949
	v_fma_mixhi_f16 v67, v74, s28, 0                           // 0000001A3214: CC220043 0200394A
	v_fma_mixlo_f16 v68, v75, s28, 0                           // 0000001A321C: CC210044 0200394B
	v_fma_mixhi_f16 v68, v76, s28, 0                           // 0000001A3224: CC220044 0200394C
	s_waitcnt lgkmcnt(5)                                       // 0000001A322C: BF89FC57
	v_fma_mixlo_f16 v71, v81, s28, 0                           // 0000001A3230: CC210047 02003951
	v_fma_mixhi_f16 v71, v82, s28, 0                           // 0000001A3238: CC220047 02003952
	v_fma_mixlo_f16 v72, v83, s28, 0                           // 0000001A3240: CC210048 02003953
	v_fma_mixhi_f16 v72, v84, s28, 0                           // 0000001A3248: CC220048 02003954
	ds_load_b128 v[81:84], v134 offset:25664                   // 0000001A3250: DBFC6440 51000086
	s_waitcnt lgkmcnt(5)                                       // 0000001A3258: BF89FC57
	v_fma_mixlo_f16 v73, v85, s28, 0                           // 0000001A325C: CC210049 02003955
	v_fma_mixhi_f16 v73, v86, s28, 0                           // 0000001A3264: CC220049 02003956
	v_fma_mixlo_f16 v74, v87, s28, 0                           // 0000001A326C: CC21004A 02003957
	v_fma_mixhi_f16 v74, v88, s28, 0                           // 0000001A3274: CC22004A 02003958
	s_waitcnt lgkmcnt(4)                                       // 0000001A327C: BF89FC47
	v_fma_mixlo_f16 v75, v89, s28, 0                           // 0000001A3280: CC21004B 02003959
	v_fma_mixhi_f16 v75, v90, s28, 0                           // 0000001A3288: CC22004B 0200395A
	v_fma_mixlo_f16 v76, v91, s28, 0                           // 0000001A3290: CC21004C 0200395B
	ds_load_b128 v[85:88], v134 offset:25696                   // 0000001A3298: DBFC6460 55000086
	v_fma_mixhi_f16 v76, v92, s28, 0                           // 0000001A32A0: CC22004C 0200395C
	ds_load_b128 v[89:92], v134 offset:25712                   // 0000001A32A8: DBFC6470 59000086
	v_fma_mixlo_f16 v59, v186, s28, 0                          // 0000001A32B0: CC21003B 020039BA
	v_fma_mixhi_f16 v59, v187, s28, 0                          // 0000001A32B8: CC22003B 020039BB
	v_fma_mixlo_f16 v60, v188, s28, 0                          // 0000001A32C0: CC21003C 020039BC
	v_fma_mixhi_f16 v60, v189, s28, 0                          // 0000001A32C8: CC22003C 020039BD
	v_fma_mixlo_f16 v61, v190, s28, 0                          // 0000001A32D0: CC21003D 020039BE
	v_fma_mixhi_f16 v61, v191, s28, 0                          // 0000001A32D8: CC22003D 020039BF
	v_fma_mixlo_f16 v62, v192, s28, 0                          // 0000001A32E0: CC21003E 020039C0
	v_fma_mixhi_f16 v62, v193, s28, 0                          // 0000001A32E8: CC22003E 020039C1
	v_fma_mixlo_f16 v63, v65, s28, 0                           // 0000001A32F0: CC21003F 02003941
	v_fma_mixlo_f16 v65, v69, s28, 0                           // 0000001A32F8: CC210041 02003945
	v_fma_mixhi_f16 v65, v70, s28, 0                           // 0000001A3300: CC220041 02003946
	v_fma_mixlo_f16 v69, v77, s28, 0                           // 0000001A3308: CC210045 0200394D
	v_fma_mixhi_f16 v69, v78, s28, 0                           // 0000001A3310: CC220045 0200394E
	v_fma_mixlo_f16 v70, v79, s28, 0                           // 0000001A3318: CC210046 0200394F
	v_fma_mixhi_f16 v70, v80, s28, 0                           // 0000001A3320: CC220046 02003950
	s_waitcnt lgkmcnt(5)                                       // 0000001A3328: BF89FC57
	v_fma_mixlo_f16 v77, v93, s28, 0                           // 0000001A332C: CC21004D 0200395D
	v_fma_mixhi_f16 v77, v94, s28, 0                           // 0000001A3334: CC22004D 0200395E
	v_fma_mixlo_f16 v78, v95, s28, 0                           // 0000001A333C: CC21004E 0200395F
	v_fma_mixhi_f16 v78, v96, s28, 0                           // 0000001A3344: CC22004E 02003960
	s_waitcnt lgkmcnt(4)                                       // 0000001A334C: BF89FC47
	v_fma_mixlo_f16 v79, v99, s28, 0                           // 0000001A3350: CC21004F 02003963
	v_fma_mixhi_f16 v79, v100, s28, 0                          // 0000001A3358: CC22004F 02003964
	v_fma_mixlo_f16 v80, v101, s28, 0                          // 0000001A3360: CC210050 02003965
	v_fma_mixhi_f16 v80, v102, s28, 0                          // 0000001A3368: CC220050 02003966
	s_waitcnt lgkmcnt(2)                                       // 0000001A3370: BF89FC27
	v_fma_mixlo_f16 v81, v81, s28, 0                           // 0000001A3374: CC210051 02003951
	v_fma_mixhi_f16 v81, v82, s28, 0                           // 0000001A337C: CC220051 02003952
	v_fma_mixlo_f16 v82, v83, s28, 0                           // 0000001A3384: CC210052 02003953
	v_fma_mixhi_f16 v82, v84, s28, 0                           // 0000001A338C: CC220052 02003954
	v_fma_mixlo_f16 v83, v182, s28, 0                          // 0000001A3394: CC210053 020039B6
	v_fma_mixhi_f16 v83, v183, s28, 0                          // 0000001A339C: CC220053 020039B7
	v_fma_mixlo_f16 v84, v184, s28, 0                          // 0000001A33A4: CC210054 020039B8
	v_fma_mixhi_f16 v84, v185, s28, 0                          // 0000001A33AC: CC220054 020039B9
	s_waitcnt lgkmcnt(1)                                       // 0000001A33B4: BF89FC17
	v_fma_mixlo_f16 v85, v85, s28, 0                           // 0000001A33B8: CC210055 02003955
	v_fma_mixhi_f16 v85, v86, s28, 0                           // 0000001A33C0: CC220055 02003956
	v_fma_mixlo_f16 v86, v87, s28, 0                           // 0000001A33C8: CC210056 02003957
	v_fma_mixhi_f16 v86, v88, s28, 0                           // 0000001A33D0: CC220056 02003958
	s_waitcnt lgkmcnt(0)                                       // 0000001A33D8: BF89FC07
	v_fma_mixlo_f16 v87, v89, s28, 0                           // 0000001A33DC: CC210057 02003959
	v_fma_mixhi_f16 v87, v90, s28, 0                           // 0000001A33E4: CC220057 0200395A
	v_fma_mixlo_f16 v88, v91, s28, 0                           // 0000001A33EC: CC210058 0200395B
	v_fma_mixhi_f16 v88, v92, s28, 0                           // 0000001A33F4: CC220058 0200395C
	ds_load_b128 v[93:96], v134 offset:384                     // 0000001A33FC: DBFC0180 5D000086
	ds_load_b128 v[99:102], v134 offset:400                    // 0000001A3404: DBFC0190 63000086
	ds_load_b128 v[182:185], v134 offset:416                   // 0000001A340C: DBFC01A0 B6000086
	s_waitcnt vmcnt(4)                                         // 0000001A3414: BF8913F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[33:40], v[57:64], v[41:48]// 0000001A3418: CC404029 1CA67321
	ds_load_b128 v[57:60], v134 offset:432                     // 0000001A3420: DBFC01B0 39000086
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[65:72], v[17:24]// 0000001A3428: CC404011 1C468321
	v_wmma_f32_16x16x16_f16 v[49:56], v[33:40], v[73:80], v[49:56]// 0000001A3430: CC404031 1CC69321
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[81:88], v[25:32]// 0000001A3438: CC404019 1C66A321
	ds_load_b128 v[61:64], v134 offset:8832                    // 0000001A3440: DBFC2280 3D000086
	ds_load_b128 v[65:68], v134 offset:8848                    // 0000001A3448: DBFC2290 41000086
	ds_load_b128 v[69:72], v134 offset:8864                    // 0000001A3450: DBFC22A0 45000086
	ds_load_b128 v[73:76], v134 offset:8880                    // 0000001A3458: DBFC22B0 49000086
	ds_load_b128 v[77:80], v134 offset:17280                   // 0000001A3460: DBFC4380 4D000086
	ds_load_b128 v[81:84], v134 offset:17296                   // 0000001A3468: DBFC4390 51000086
	ds_load_b128 v[85:88], v134 offset:17312                   // 0000001A3470: DBFC43A0 55000086
	ds_load_b128 v[89:92], v134 offset:17328                   // 0000001A3478: DBFC43B0 59000086
	s_waitcnt lgkmcnt(11)                                      // 0000001A3480: BF89FCB7
	v_fma_mixlo_f16 v33, v93, s28, 0                           // 0000001A3484: CC210021 0200395D
	v_fma_mixhi_f16 v33, v94, s28, 0                           // 0000001A348C: CC220021 0200395E
	v_fma_mixlo_f16 v34, v95, s28, 0                           // 0000001A3494: CC210022 0200395F
	v_fma_mixhi_f16 v34, v96, s28, 0                           // 0000001A349C: CC220022 02003960
	s_waitcnt lgkmcnt(8)                                       // 0000001A34A4: BF89FC87
	v_fma_mixhi_f16 v39, v58, s28, 0                           // 0000001A34A8: CC220027 0200393A
	v_fma_mixlo_f16 v40, v59, s28, 0                           // 0000001A34B0: CC210028 0200393B
	v_fma_mixhi_f16 v40, v60, s28, 0                           // 0000001A34B8: CC220028 0200393C
	ds_load_b128 v[93:96], v134 offset:25744                   // 0000001A34C0: DBFC6490 5D000086
	s_waitcnt lgkmcnt(8)                                       // 0000001A34C8: BF89FC87
	v_fma_mixlo_f16 v58, v63, s28, 0                           // 0000001A34CC: CC21003A 0200393F
	v_fma_mixhi_f16 v58, v64, s28, 0                           // 0000001A34D4: CC22003A 02003940
	s_waitcnt lgkmcnt(7)                                       // 0000001A34DC: BF89FC77
	v_fma_mixlo_f16 v59, v65, s28, 0                           // 0000001A34E0: CC21003B 02003941
	v_fma_mixhi_f16 v59, v66, s28, 0                           // 0000001A34E8: CC22003B 02003942
	v_fma_mixlo_f16 v60, v67, s28, 0                           // 0000001A34F0: CC21003C 02003943
	v_fma_mixhi_f16 v60, v68, s28, 0                           // 0000001A34F8: CC22003C 02003944
	s_waitcnt lgkmcnt(5)                                       // 0000001A3500: BF89FC57
	v_fma_mixlo_f16 v63, v73, s28, 0                           // 0000001A3504: CC21003F 02003949
	v_fma_mixhi_f16 v63, v74, s28, 0                           // 0000001A350C: CC22003F 0200394A
	v_fma_mixlo_f16 v64, v75, s28, 0                           // 0000001A3514: CC210040 0200394B
	v_fma_mixhi_f16 v64, v76, s28, 0                           // 0000001A351C: CC220040 0200394C
	ds_load_b128 v[73:76], v134 offset:25728                   // 0000001A3524: DBFC6480 49000086
	s_waitcnt lgkmcnt(5)                                       // 0000001A352C: BF89FC57
	v_fma_mixlo_f16 v65, v77, s28, 0                           // 0000001A3530: CC210041 0200394D
	v_fma_mixhi_f16 v65, v78, s28, 0                           // 0000001A3538: CC220041 0200394E
	v_fma_mixlo_f16 v66, v79, s28, 0                           // 0000001A3540: CC210042 0200394F
	v_fma_mixhi_f16 v66, v80, s28, 0                           // 0000001A3548: CC220042 02003950
	s_waitcnt lgkmcnt(4)                                       // 0000001A3550: BF89FC47
	v_fma_mixlo_f16 v67, v81, s28, 0                           // 0000001A3554: CC210043 02003951
	v_fma_mixhi_f16 v67, v82, s28, 0                           // 0000001A355C: CC220043 02003952
	v_fma_mixlo_f16 v68, v83, s28, 0                           // 0000001A3564: CC210044 02003953
	ds_load_b128 v[77:80], v134 offset:25760                   // 0000001A356C: DBFC64A0 4D000086
	v_fma_mixhi_f16 v68, v84, s28, 0                           // 0000001A3574: CC220044 02003954
	ds_load_b128 v[81:84], v134 offset:25776                   // 0000001A357C: DBFC64B0 51000086
	v_fma_mixlo_f16 v35, v99, s28, 0                           // 0000001A3584: CC210023 02003963
	v_fma_mixhi_f16 v35, v100, s28, 0                          // 0000001A358C: CC220023 02003964
	v_fma_mixlo_f16 v36, v101, s28, 0                          // 0000001A3594: CC210024 02003965
	v_fma_mixhi_f16 v36, v102, s28, 0                          // 0000001A359C: CC220024 02003966
	v_fma_mixlo_f16 v37, v182, s28, 0                          // 0000001A35A4: CC210025 020039B6
	v_fma_mixhi_f16 v37, v183, s28, 0                          // 0000001A35AC: CC220025 020039B7
	v_fma_mixlo_f16 v38, v184, s28, 0                          // 0000001A35B4: CC210026 020039B8
	v_fma_mixhi_f16 v38, v185, s28, 0                          // 0000001A35BC: CC220026 020039B9
	v_fma_mixlo_f16 v39, v57, s28, 0                           // 0000001A35C4: CC210027 02003939
	v_fma_mixlo_f16 v57, v61, s28, 0                           // 0000001A35CC: CC210039 0200393D
	v_fma_mixhi_f16 v57, v62, s28, 0                           // 0000001A35D4: CC220039 0200393E
	v_fma_mixlo_f16 v61, v69, s28, 0                           // 0000001A35DC: CC21003D 02003945
	v_fma_mixhi_f16 v61, v70, s28, 0                           // 0000001A35E4: CC22003D 02003946
	v_fma_mixlo_f16 v62, v71, s28, 0                           // 0000001A35EC: CC21003E 02003947
	v_fma_mixhi_f16 v62, v72, s28, 0                           // 0000001A35F4: CC22003E 02003948
	s_waitcnt lgkmcnt(5)                                       // 0000001A35FC: BF89FC57
	v_fma_mixlo_f16 v69, v85, s28, 0                           // 0000001A3600: CC210045 02003955
	v_fma_mixhi_f16 v69, v86, s28, 0                           // 0000001A3608: CC220045 02003956
	v_fma_mixlo_f16 v70, v87, s28, 0                           // 0000001A3610: CC210046 02003957
	v_fma_mixhi_f16 v70, v88, s28, 0                           // 0000001A3618: CC220046 02003958
	s_waitcnt lgkmcnt(4)                                       // 0000001A3620: BF89FC47
	v_fma_mixlo_f16 v71, v89, s28, 0                           // 0000001A3624: CC210047 02003959
	v_fma_mixhi_f16 v71, v90, s28, 0                           // 0000001A362C: CC220047 0200395A
	v_fma_mixlo_f16 v72, v91, s28, 0                           // 0000001A3634: CC210048 0200395B
	v_fma_mixhi_f16 v72, v92, s28, 0                           // 0000001A363C: CC220048 0200395C
	s_waitcnt lgkmcnt(2)                                       // 0000001A3644: BF89FC27
	v_fma_mixlo_f16 v73, v73, s28, 0                           // 0000001A3648: CC210049 02003949
	v_fma_mixhi_f16 v73, v74, s28, 0                           // 0000001A3650: CC220049 0200394A
	v_fma_mixlo_f16 v74, v75, s28, 0                           // 0000001A3658: CC21004A 0200394B
	v_fma_mixhi_f16 v74, v76, s28, 0                           // 0000001A3660: CC22004A 0200394C
	v_fma_mixlo_f16 v75, v93, s28, 0                           // 0000001A3668: CC21004B 0200395D
	v_fma_mixhi_f16 v75, v94, s28, 0                           // 0000001A3670: CC22004B 0200395E
	v_fma_mixlo_f16 v76, v95, s28, 0                           // 0000001A3678: CC21004C 0200395F
	v_fma_mixhi_f16 v76, v96, s28, 0                           // 0000001A3680: CC22004C 02003960
	s_waitcnt lgkmcnt(1)                                       // 0000001A3688: BF89FC17
	v_fma_mixlo_f16 v77, v77, s28, 0                           // 0000001A368C: CC21004D 0200394D
	v_fma_mixhi_f16 v77, v78, s28, 0                           // 0000001A3694: CC22004D 0200394E
	v_fma_mixlo_f16 v78, v79, s28, 0                           // 0000001A369C: CC21004E 0200394F
	v_fma_mixhi_f16 v78, v80, s28, 0                           // 0000001A36A4: CC22004E 02003950
	s_waitcnt lgkmcnt(0)                                       // 0000001A36AC: BF89FC07
	v_fma_mixlo_f16 v79, v81, s28, 0                           // 0000001A36B0: CC21004F 02003951
	v_fma_mixhi_f16 v79, v82, s28, 0                           // 0000001A36B8: CC22004F 02003952
	v_fma_mixlo_f16 v80, v83, s28, 0                           // 0000001A36C0: CC210050 02003953
	v_fma_mixhi_f16 v80, v84, s28, 0                           // 0000001A36C8: CC220050 02003954
	ds_load_b128 v[85:88], v134 offset:448                     // 0000001A36D0: DBFC01C0 55000086
	ds_load_b128 v[89:92], v134 offset:464                     // 0000001A36D8: DBFC01D0 59000086
	ds_load_b128 v[93:96], v134 offset:480                     // 0000001A36E0: DBFC01E0 5D000086
	s_waitcnt vmcnt(2)                                         // 0000001A36E8: BF890BF7
	v_wmma_f32_16x16x16_f16 v[41:48], v[9:16], v[33:40], v[41:48]// 0000001A36EC: CC404029 1CA64309
	ds_load_b128 v[33:36], v134 offset:496                     // 0000001A36F4: DBFC01F0 21000086
	v_wmma_f32_16x16x16_f16 v[17:24], v[9:16], v[57:64], v[17:24]// 0000001A36FC: CC404011 1C467309
	v_wmma_f32_16x16x16_f16 v[49:56], v[9:16], v[65:72], v[49:56]// 0000001A3704: CC404031 1CC68309
	v_wmma_f32_16x16x16_f16 v[25:32], v[9:16], v[73:80], v[25:32]// 0000001A370C: CC404019 1C669309
	ds_load_b128 v[37:40], v134 offset:8896                    // 0000001A3714: DBFC22C0 25000086
	ds_load_b128 v[57:60], v134 offset:8912                    // 0000001A371C: DBFC22D0 39000086
	ds_load_b128 v[61:64], v134 offset:8928                    // 0000001A3724: DBFC22E0 3D000086
	ds_load_b128 v[65:68], v134 offset:8944                    // 0000001A372C: DBFC22F0 41000086
	ds_load_b128 v[69:72], v134 offset:17344                   // 0000001A3734: DBFC43C0 45000086
	ds_load_b128 v[73:76], v134 offset:17360                   // 0000001A373C: DBFC43D0 49000086
	ds_load_b128 v[77:80], v134 offset:17376                   // 0000001A3744: DBFC43E0 4D000086
	ds_load_b128 v[81:84], v134 offset:17392                   // 0000001A374C: DBFC43F0 51000086
	s_waitcnt lgkmcnt(11)                                      // 0000001A3754: BF89FCB7
	v_fma_mixlo_f16 v9, v85, s28, 0                            // 0000001A3758: CC210009 02003955
	v_fma_mixhi_f16 v9, v86, s28, 0                            // 0000001A3760: CC220009 02003956
	v_fma_mixlo_f16 v10, v87, s28, 0                           // 0000001A3768: CC21000A 02003957
	v_fma_mixhi_f16 v10, v88, s28, 0                           // 0000001A3770: CC22000A 02003958
	s_waitcnt lgkmcnt(8)                                       // 0000001A3778: BF89FC87
	v_fma_mixhi_f16 v15, v34, s28, 0                           // 0000001A377C: CC22000F 02003922
	v_fma_mixlo_f16 v16, v35, s28, 0                           // 0000001A3784: CC210010 02003923
	v_fma_mixhi_f16 v16, v36, s28, 0                           // 0000001A378C: CC220010 02003924
	ds_load_b128 v[85:88], v134 offset:25808                   // 0000001A3794: DBFC64D0 55000086
	s_waitcnt lgkmcnt(8)                                       // 0000001A379C: BF89FC87
	v_fma_mixlo_f16 v34, v39, s28, 0                           // 0000001A37A0: CC210022 02003927
	v_fma_mixhi_f16 v34, v40, s28, 0                           // 0000001A37A8: CC220022 02003928
	s_waitcnt lgkmcnt(7)                                       // 0000001A37B0: BF89FC77
	v_fma_mixlo_f16 v35, v57, s28, 0                           // 0000001A37B4: CC210023 02003939
	v_fma_mixhi_f16 v35, v58, s28, 0                           // 0000001A37BC: CC220023 0200393A
	v_fma_mixlo_f16 v36, v59, s28, 0                           // 0000001A37C4: CC210024 0200393B
	v_fma_mixhi_f16 v36, v60, s28, 0                           // 0000001A37CC: CC220024 0200393C
	s_waitcnt lgkmcnt(5)                                       // 0000001A37D4: BF89FC57
	v_fma_mixlo_f16 v39, v65, s28, 0                           // 0000001A37D8: CC210027 02003941
	v_fma_mixhi_f16 v39, v66, s28, 0                           // 0000001A37E0: CC220027 02003942
	v_fma_mixlo_f16 v40, v67, s28, 0                           // 0000001A37E8: CC210028 02003943
	v_fma_mixhi_f16 v40, v68, s28, 0                           // 0000001A37F0: CC220028 02003944
	ds_load_b128 v[65:68], v134 offset:25792                   // 0000001A37F8: DBFC64C0 41000086
	s_waitcnt lgkmcnt(5)                                       // 0000001A3800: BF89FC57
	v_fma_mixlo_f16 v57, v69, s28, 0                           // 0000001A3804: CC210039 02003945
	v_fma_mixhi_f16 v57, v70, s28, 0                           // 0000001A380C: CC220039 02003946
	v_fma_mixlo_f16 v58, v71, s28, 0                           // 0000001A3814: CC21003A 02003947
	v_fma_mixhi_f16 v58, v72, s28, 0                           // 0000001A381C: CC22003A 02003948
	s_waitcnt lgkmcnt(4)                                       // 0000001A3824: BF89FC47
	v_fma_mixlo_f16 v59, v73, s28, 0                           // 0000001A3828: CC21003B 02003949
	v_fma_mixhi_f16 v59, v74, s28, 0                           // 0000001A3830: CC22003B 0200394A
	ds_load_b128 v[69:72], v134 offset:25824                   // 0000001A3838: DBFC64E0 45000086
	v_fma_mixlo_f16 v60, v75, s28, 0                           // 0000001A3840: CC21003C 0200394B
	v_fma_mixhi_f16 v60, v76, s28, 0                           // 0000001A3848: CC22003C 0200394C
	ds_load_b128 v[73:76], v134 offset:25840                   // 0000001A3850: DBFC64F0 49000086
	v_fma_mixlo_f16 v11, v89, s28, 0                           // 0000001A3858: CC21000B 02003959
	v_fma_mixhi_f16 v11, v90, s28, 0                           // 0000001A3860: CC22000B 0200395A
	v_fma_mixlo_f16 v12, v91, s28, 0                           // 0000001A3868: CC21000C 0200395B
	v_fma_mixhi_f16 v12, v92, s28, 0                           // 0000001A3870: CC22000C 0200395C
	v_fma_mixlo_f16 v13, v93, s28, 0                           // 0000001A3878: CC21000D 0200395D
	v_fma_mixhi_f16 v13, v94, s28, 0                           // 0000001A3880: CC22000D 0200395E
	v_fma_mixlo_f16 v14, v95, s28, 0                           // 0000001A3888: CC21000E 0200395F
	v_fma_mixhi_f16 v14, v96, s28, 0                           // 0000001A3890: CC22000E 02003960
	v_fma_mixlo_f16 v15, v33, s28, 0                           // 0000001A3898: CC21000F 02003921
	v_fma_mixlo_f16 v33, v37, s28, 0                           // 0000001A38A0: CC210021 02003925
	v_fma_mixhi_f16 v33, v38, s28, 0                           // 0000001A38A8: CC220021 02003926
	v_fma_mixlo_f16 v37, v61, s28, 0                           // 0000001A38B0: CC210025 0200393D
	v_fma_mixhi_f16 v37, v62, s28, 0                           // 0000001A38B8: CC220025 0200393E
	v_fma_mixlo_f16 v38, v63, s28, 0                           // 0000001A38C0: CC210026 0200393F
	v_fma_mixhi_f16 v38, v64, s28, 0                           // 0000001A38C8: CC220026 02003940
	s_waitcnt lgkmcnt(5)                                       // 0000001A38D0: BF89FC57
	v_fma_mixlo_f16 v61, v77, s28, 0                           // 0000001A38D4: CC21003D 0200394D
	v_fma_mixhi_f16 v61, v78, s28, 0                           // 0000001A38DC: CC22003D 0200394E
	v_fma_mixlo_f16 v62, v79, s28, 0                           // 0000001A38E4: CC21003E 0200394F
	v_fma_mixhi_f16 v62, v80, s28, 0                           // 0000001A38EC: CC22003E 02003950
	s_waitcnt lgkmcnt(4)                                       // 0000001A38F4: BF89FC47
	v_fma_mixlo_f16 v63, v81, s28, 0                           // 0000001A38F8: CC21003F 02003951
	v_fma_mixhi_f16 v63, v82, s28, 0                           // 0000001A3900: CC22003F 02003952
	v_fma_mixlo_f16 v64, v83, s28, 0                           // 0000001A3908: CC210040 02003953
	v_fma_mixhi_f16 v64, v84, s28, 0                           // 0000001A3910: CC220040 02003954
	s_waitcnt lgkmcnt(2)                                       // 0000001A3918: BF89FC27
	v_fma_mixlo_f16 v65, v65, s28, 0                           // 0000001A391C: CC210041 02003941
	v_fma_mixhi_f16 v65, v66, s28, 0                           // 0000001A3924: CC220041 02003942
	v_fma_mixlo_f16 v66, v67, s28, 0                           // 0000001A392C: CC210042 02003943
	v_fma_mixhi_f16 v66, v68, s28, 0                           // 0000001A3934: CC220042 02003944
	v_fma_mixlo_f16 v67, v85, s28, 0                           // 0000001A393C: CC210043 02003955
	v_fma_mixhi_f16 v67, v86, s28, 0                           // 0000001A3944: CC220043 02003956
	v_fma_mixlo_f16 v68, v87, s28, 0                           // 0000001A394C: CC210044 02003957
	v_fma_mixhi_f16 v68, v88, s28, 0                           // 0000001A3954: CC220044 02003958
	s_waitcnt lgkmcnt(1)                                       // 0000001A395C: BF89FC17
	v_fma_mixlo_f16 v69, v69, s28, 0                           // 0000001A3960: CC210045 02003945
	v_fma_mixhi_f16 v69, v70, s28, 0                           // 0000001A3968: CC220045 02003946
	v_fma_mixlo_f16 v70, v71, s28, 0                           // 0000001A3970: CC210046 02003947
	v_fma_mixhi_f16 v70, v72, s28, 0                           // 0000001A3978: CC220046 02003948
	s_waitcnt lgkmcnt(0)                                       // 0000001A3980: BF89FC07
	v_fma_mixlo_f16 v71, v73, s28, 0                           // 0000001A3984: CC210047 02003949
	v_fma_mixhi_f16 v71, v74, s28, 0                           // 0000001A398C: CC220047 0200394A
	v_fma_mixlo_f16 v72, v75, s28, 0                           // 0000001A3994: CC210048 0200394B
	v_fma_mixhi_f16 v72, v76, s28, 0                           // 0000001A399C: CC220048 0200394C
	s_waitcnt vmcnt(0)                                         // 0000001A39A4: BF8903F7
	v_wmma_f32_16x16x16_f16 v[41:48], v[1:8], v[9:16], v[41:48]// 0000001A39A8: CC404029 1CA61301
	v_wmma_f32_16x16x16_f16 v[17:24], v[1:8], v[33:40], v[17:24]// 0000001A39B0: CC404011 1C464301
	v_wmma_f32_16x16x16_f16 v[49:56], v[1:8], v[57:64], v[49:56]// 0000001A39B8: CC404031 1CC67301
	v_wmma_f32_16x16x16_f16 v[25:32], v[1:8], v[65:72], v[25:32]// 0000001A39C0: CC404019 1C668301
	v_add_nc_u32_e32 v182, v181, v133                          // 0000001A39C8: 4B6D0BB5
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A39CC: BF870001
	v_or_b32_e32 v1, 2, v182                                   // 0000001A39D0: 38036C82
	v_or_b32_e32 v2, 4, v182                                   // 0000001A39D4: 38056C84
	v_or_b32_e32 v5, 6, v182                                   // 0000001A39D8: 380B6C86
	v_or_b32_e32 v7, 8, v182                                   // 0000001A39DC: 380F6C88
	v_or_b32_e32 v8, 10, v182                                  // 0000001A39E0: 38116C8A
	v_min_i32_e32 v1, s71, v1                                  // 0000001A39E4: 22020247
	v_min_i32_e32 v6, s71, v2                                  // 0000001A39E8: 220C0447
	v_min_i32_e32 v10, s71, v5                                 // 0000001A39EC: 22140A47
	v_or_b32_e32 v9, 12, v182                                  // 0000001A39F0: 38136C8C
	v_min_i32_e32 v11, s71, v7                                 // 0000001A39F4: 22160E47
	v_mad_i64_i32 v[1:2], null, v1, 48, s[2:3]                 // 0000001A39F8: D6FF7C01 00096101
	v_mad_i64_i32 v[5:6], null, v6, 48, s[2:3]                 // 0000001A3A00: D6FF7C05 00096106
	v_min_i32_e32 v13, s71, v8                                 // 0000001A3A08: 221A1047
	v_mad_i64_i32 v[7:8], null, v10, 48, s[2:3]                // 0000001A3A0C: D6FF7C07 0009610A
	v_min_i32_e32 v14, s71, v9                                 // 0000001A3A14: 221C1247
	v_mad_i64_i32 v[9:10], null, v11, 48, s[2:3]               // 0000001A3A18: D6FF7C09 0009610B
	v_or_b32_e32 v15, 14, v182                                 // 0000001A3A20: 381F6C8E
	v_min_i32_e32 v3, s71, v182                                // 0000001A3A24: 22076C47
	.long 0xd73c0001                                           // 0000001A3A28: D73C0001
	v_cndmask_b32_e32 v1, 9, v1, vcc_lo                        // 0000001A3A2C: 02020289
	.long 0xd73c0005                                           // 0000001A3A30: D73C0005
	v_cndmask_b32_e32 v1, 9, v5, vcc_lo                        // 0000001A3A34: 02020A89
	.long 0xd444000b                                           // 0000001A3A38: D444000B
	v_cndmask_b32_e32 v1, s67, v182, vcc_lo                    // 0000001A3A3C: 02036C43
	v_min_i32_e32 v15, s71, v15                                // 0000001A3A40: 221E1E47
	v_mad_i64_i32 v[3:4], null, v3, 48, s[2:3]                 // 0000001A3A44: D6FF7C03 00096103
	.long 0xd73c0009                                           // 0000001A3A4C: D73C0009
	v_cndmask_b32_e32 v1, 9, v9, vcc_lo                        // 0000001A3A50: 02021289
	.long 0xd700000b                                           // 0000001A3A54: D700000B
	v_cndmask_b32_e32 v1, v141, v1, vcc_lo                     // 0000001A3A58: 0202038D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001A3A5C: BF8700D1
	v_add_co_ci_u32_e64 v12, null, v142, v2, s0                // 0000001A3A60: D5207C0C 0002058E
	.long 0xd73c0001                                           // 0000001A3A68: D73C0001
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 0000001A3A6C: 02020E89
	v_mad_i64_i32 v[7:8], null, v13, 48, s[2:3]                // 0000001A3A70: D6FF7C07 0009610D
	v_mad_i64_i32 v[13:14], null, v14, 48, s[2:3]              // 0000001A3A78: D6FF7C0D 0009610E
	.long 0xd7000005                                           // 0000001A3A80: D7000005
	v_cndmask_b32_e32 v1, v141, v5, vcc_lo                     // 0000001A3A84: 02020B8D
	v_add_co_ci_u32_e64 v6, null, v142, v6, s0                 // 0000001A3A88: D5207C06 00020D8E
	.long 0xd7000024                                           // 0000001A3A90: D7000024
	v_cndmask_b32_e32 v1, v141, v1, vcc_lo                     // 0000001A3A94: 0202038D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001A3A98: BF8700B1
	v_add_co_ci_u32_e64 v37, null, v142, v2, s0                // 0000001A3A9C: D5207C25 0002058E
	.long 0xd73c0001                                           // 0000001A3AA4: D73C0001
	v_cndmask_b32_e32 v1, 9, v7, vcc_lo                        // 0000001A3AA8: 02020E89
	.long 0xd7000007                                           // 0000001A3AAC: D7000007
	v_cndmask_b32_e32 v1, v141, v9, vcc_lo                     // 0000001A3AB0: 0202138D
	v_add_co_ci_u32_e64 v8, null, v142, v10, s0                // 0000001A3AB4: D5207C08 0002158E
	.long 0xd73c0009                                           // 0000001A3ABC: D73C0009
	v_cndmask_b32_e32 v1, 9, v13, vcc_lo                       // 0000001A3AC0: 02021A89
	v_mad_i64_i32 v[13:14], null, v15, 48, s[2:3]              // 0000001A3AC4: D6FF7C0D 0009610F
	.long 0xd7000026                                           // 0000001A3ACC: D7000026
	v_cndmask_b32_e32 v1, v141, v1, vcc_lo                     // 0000001A3AD0: 0202038D
	.long 0xd73c0003                                           // 0000001A3AD4: D73C0003
	v_cndmask_b32_e32 v1, 9, v3, vcc_lo                        // 0000001A3AD8: 02020689
	v_add_co_ci_u32_e64 v39, null, v142, v2, s0                // 0000001A3ADC: D5207C27 0002058E
	.long 0xd7000043                                           // 0000001A3AE4: D7000043
	v_cndmask_b32_e32 v1, v141, v9, vcc_lo                     // 0000001A3AE8: 0202138D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001A3AEC: BF8700B1
	v_add_co_ci_u32_e64 v68, null, v142, v10, s0               // 0000001A3AF0: D5207C44 0002158E
	.long 0xd73c0009                                           // 0000001A3AF8: D73C0009
	v_cndmask_b32_e32 v1, 9, v13, vcc_lo                       // 0000001A3AFC: 02021A89
	.long 0xd7000002                                           // 0000001A3B00: D7000002
	v_cndmask_b32_e32 v1, v141, v3, vcc_lo                     // 0000001A3B04: 0202078D
	v_add_co_ci_u32_e64 v3, null, v142, v4, s0                 // 0000001A3B08: D5207C03 0002098E
	.long 0x7e023880                                           // 0000001A3B10: 7E023880
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A3B14: BF870094
	.long 0xd7000045                                           // 0000001A3B18: D7000045
	v_cndmask_b32_e32 v1, v141, v9, vcc_lo                     // 0000001A3B1C: 0202138D
	v_add_co_ci_u32_e64 v70, null, v142, v10, s0               // 0000001A3B20: D5207C46 0002158E
	s_clause 0x1e                                              // 0000001A3B28: BF85001E
	global_load_b32 v63, v[11:12], off                         // 0000001A3B2C: DC520000 3F7C000B
	global_load_b32 v60, v[5:6], off                           // 0000001A3B34: DC520000 3C7C0005
	global_load_b32 v40, v[2:3], off offset:64                 // 0000001A3B3C: DC520040 287C0002
	global_load_b32 v57, v[11:12], off offset:64               // 0000001A3B44: DC520040 397C000B
	global_load_b32 v35, v[2:3], off offset:128                // 0000001A3B4C: DC520080 237C0002
	global_load_b32 v15, v[11:12], off offset:128              // 0000001A3B54: DC520080 0F7C000B
	global_load_b32 v9, v[11:12], off offset:192               // 0000001A3B5C: DC5200C0 097C000B
	global_load_b32 v10, v[2:3], off offset:192                // 0000001A3B64: DC5200C0 0A7C0002
	global_load_b32 v66, v[36:37], off                         // 0000001A3B6C: DC520000 427C0024
	global_load_b32 v65, v[7:8], off                           // 0000001A3B74: DC520000 417C0007
	global_load_b32 v59, v[5:6], off offset:64                 // 0000001A3B7C: DC520040 3B7C0005
	global_load_b32 v58, v[36:37], off offset:64               // 0000001A3B84: DC520040 3A7C0024
	global_load_b32 v34, v[5:6], off offset:128                // 0000001A3B8C: DC520080 227C0005
	global_load_b32 v12, v[36:37], off offset:128              // 0000001A3B94: DC520080 0C7C0024
	global_load_b32 v4, v[36:37], off offset:192               // 0000001A3B9C: DC5200C0 047C0024
	global_load_b32 v11, v[5:6], off offset:192                // 0000001A3BA4: DC5200C0 0B7C0005
	global_load_b32 v64, v[38:39], off                         // 0000001A3BAC: DC520000 407C0026
	global_load_b32 v61, v[67:68], off                         // 0000001A3BB4: DC520000 3D7C0043
	global_load_b32 v36, v[7:8], off offset:64                 // 0000001A3BBC: DC520040 247C0007
	global_load_b32 v37, v[38:39], off offset:64               // 0000001A3BC4: DC520040 257C0026
	global_load_b32 v16, v[7:8], off offset:128                // 0000001A3BCC: DC520080 107C0007
	global_load_b32 v33, v[38:39], off offset:128              // 0000001A3BD4: DC520080 217C0026
	global_load_b32 v5, v[38:39], off offset:192               // 0000001A3BDC: DC5200C0 057C0026
	global_load_b32 v6, v[7:8], off offset:192                 // 0000001A3BE4: DC5200C0 067C0007
	global_load_b32 v62, v[69:70], off                         // 0000001A3BEC: DC520000 3E7C0045
	global_load_b32 v38, v[67:68], off offset:64               // 0000001A3BF4: DC520040 267C0043
	global_load_b32 v39, v[69:70], off offset:64               // 0000001A3BFC: DC520040 277C0045
	global_load_b32 v13, v[67:68], off offset:128              // 0000001A3C04: DC520080 0D7C0043
	global_load_b32 v14, v[69:70], off offset:128              // 0000001A3C0C: DC520080 0E7C0045
	global_load_b32 v7, v[69:70], off offset:192               // 0000001A3C14: DC5200C0 077C0045
	global_load_b32 v8, v[67:68], off offset:192               // 0000001A3C1C: DC5200C0 087C0043
	s_and_saveexec_b32 s0, s11                                 // 0000001A3C24: BE80200B
	s_cbranch_execz 8                                          // 0000001A3C28: BFA50008 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x424c>
	global_load_b32 v1, v[2:3], off                            // 0000001A3C2C: DC520000 017C0002
	s_waitcnt vmcnt(0)                                         // 0000001A3C34: BF8903F7
	v_fmac_f32_e32 v1, 0xbb800000, v41                         // 0000001A3C38: 560252FF BB800000
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A3C40: BF870001
	v_fma_mixlo_f16 v1, v1, s28, 0                             // 0000001A3C44: CC210001 02003901
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001A3C4C: 8C7E007E
	s_waitcnt vmcnt(29)                                        // 0000001A3C50: BF8977F7
	v_dual_fmac_f32 v60, 0xbb800000, v43 :: v_dual_add_nc_u32 v189, 2, v182// 0000001A3C54: C82056FF 3CBD6C82 BB800000
	s_waitcnt vmcnt(22)                                        // 0000001A3C60: BF895BF7
	v_dual_fmac_f32 v63, 0xbb800000, v42 :: v_dual_fmac_f32 v66, 0xbb800000, v44// 0000001A3C64: C80054FF 3F4258FF BB800000
	s_waitcnt vmcnt(21)                                        // 0000001A3C70: BF8957F7
	v_dual_fmac_f32 v65, 0xbb800000, v45 :: v_dual_add_nc_u32 v188, 4, v182// 0000001A3C74: C8205AFF 41BD6C84 BB800000
	s_waitcnt vmcnt(6)                                         // 0000001A3C80: BF891BF7
	v_dual_fmac_f32 v62, 0xbb800000, v48 :: v_dual_add_nc_u32 v187, 6, v182// 0000001A3C84: C82060FF 3EBB6C86 BB800000
	v_dual_fmac_f32 v61, 0xbb800000, v47 :: v_dual_add_nc_u32 v186, 8, v182// 0000001A3C90: C8205EFF 3DBB6C88 BB800000
	v_dual_fmac_f32 v40, 0xbb800000, v17 :: v_dual_add_nc_u32 v185, 10, v182// 0000001A3C9C: C82022FF 28B96C8A BB800000
	v_dual_fmac_f32 v64, 0xbb800000, v46 :: v_dual_fmac_f32 v59, 0xbb800000, v19// 0000001A3CA8: C8005CFF 403A26FF BB800000
	s_waitcnt vmcnt(4)                                         // 0000001A3CB4: BF8913F7
	v_dual_fmac_f32 v39, 0xbb800000, v24 :: v_dual_add_nc_u32 v184, 12, v182// 0000001A3CB8: C82030FF 27B96C8C BB800000
	v_dual_fmac_f32 v58, 0xbb800000, v20 :: v_dual_add_nc_u32 v183, 14, v182// 0000001A3CC4: C82028FF 3AB76C8E BB800000
	.long 0xd444000e                                           // 0000001A3CD0: D444000E
	v_cndmask_b32_e32 v1, s67, v189, vcc_lo                    // 0000001A3CD4: 02037A43
	v_fma_mixhi_f16 v1, v63, s28, 0                            // 0000001A3CD8: CC220001 0200393F
	.long 0xd444000d                                           // 0000001A3CE0: D444000D
	v_cndmask_b32_e32 v1, s67, v188, vcc_lo                    // 0000001A3CE4: 02037843
	v_fma_mixlo_f16 v2, v60, s28, 0                            // 0000001A3CE8: CC210002 0200393C
	.long 0xd444000c                                           // 0000001A3CF0: D444000C
	v_cndmask_b32_e32 v1, s67, v187, vcc_lo                    // 0000001A3CF4: 02037643
	v_fma_mixhi_f16 v2, v66, s28, 0                            // 0000001A3CF8: CC220002 02003942
	v_dual_fmac_f32 v57, 0xbb800000, v18 :: v_dual_fmac_f32 v36, 0xbb800000, v21// 0000001A3D00: C80024FF 39242AFF BB800000
	.long 0xd444000a                                           // 0000001A3D0C: D444000A
	v_cndmask_b32_e32 v1, s67, v186, vcc_lo                    // 0000001A3D10: 02037443
	v_fma_mixlo_f16 v3, v65, s28, 0                            // 0000001A3D14: CC210003 02003941
	.long 0xd4440001                                           // 0000001A3D1C: D4440001
	v_cndmask_b32_e32 v1, s67, v185, vcc_lo                    // 0000001A3D20: 02037243
	v_fma_mixhi_f16 v3, v64, s28, 0                            // 0000001A3D24: CC220003 02003940
	.long 0xd4440009                                           // 0000001A3D2C: D4440009
	v_cndmask_b32_e32 v1, s67, v184, vcc_lo                    // 0000001A3D30: 02037043
	v_fma_mixlo_f16 v41, v61, s28, 0                           // 0000001A3D34: CC210029 0200393D
	.long 0xd4440000                                           // 0000001A3D3C: D4440000
	v_cndmask_b32_e32 v1, s67, v183, vcc_lo                    // 0000001A3D40: 02036E43
	v_fma_mixhi_f16 v41, v62, s28, 0                           // 0000001A3D44: CC220029 0200393E
	v_cndmask_b16 v1, 0, v1, s14                               // 0000001A3D4C: D65D5001 003A0280
	v_cndmask_b16 v2, 0, v2, s13                               // 0000001A3D54: D65D0002 00360480
	v_fma_mixlo_f16 v18, v40, s28, 0                           // 0000001A3D5C: CC210012 02003928
	v_dual_fmac_f32 v37, 0xbb800000, v22 :: v_dual_fmac_f32 v38, 0xbb800000, v23// 0000001A3D64: C8002CFF 25262EFF BB800000
	v_cndmask_b16 v2, 0, v2, s12                               // 0000001A3D70: D65D5002 00320480
	v_fma_mixhi_f16 v18, v57, s28, 0                           // 0000001A3D78: CC220012 02003939
	v_cndmask_b16 v3, 0, v3, s10                               // 0000001A3D80: D65D0003 002A0680
	v_fma_mixlo_f16 v19, v59, s28, 0                           // 0000001A3D88: CC210013 0200393B
	v_cndmask_b16 v3, 0, v3, s1                                // 0000001A3D90: D65D5003 00060680
	v_cndmask_b16 v17, 0, v41, s9                              // 0000001A3D98: D65D0011 00265280
	v_cndmask_b16 v17, 0, v41, s0                              // 0000001A3DA0: D65D5011 00025280
	ds_store_b16 v143, v1                                      // 0000001A3DA8: D87C0000 0000018F
	ds_store_b16_d16_hi v143, v1 offset:4                      // 0000001A3DB0: DA840004 0000018F
	ds_store_b16 v143, v2 offset:8                             // 0000001A3DB8: D87C0008 0000028F
	ds_store_b16_d16_hi v143, v2 offset:12                     // 0000001A3DC0: DA84000C 0000028F
	ds_store_b16 v143, v3 offset:16                            // 0000001A3DC8: D87C0010 0000038F
	ds_store_b16_d16_hi v143, v3 offset:20                     // 0000001A3DD0: DA840014 0000038F
	ds_store_b16 v143, v17 offset:24                           // 0000001A3DD8: D87C0018 0000118F
	ds_store_b16_d16_hi v143, v17 offset:28                    // 0000001A3DE0: DA84001C 0000118F
	v_fma_mixhi_f16 v2, v58, s28, 0                            // 0000001A3DE8: CC220002 0200393A
	v_fma_mixlo_f16 v3, v36, s28, 0                            // 0000001A3DF0: CC210003 02003924
	v_dual_fmac_f32 v35, 0xbb800000, v49 :: v_dual_fmac_f32 v34, 0xbb800000, v51// 0000001A3DF8: C80062FF 232266FF BB800000
	v_cndmask_b16 v1, 0, v18, s11                              // 0000001A3E04: D65D0001 002E2480
	v_fma_mixhi_f16 v3, v37, s28, 0                            // 0000001A3E0C: CC220003 02003925
	v_fma_mixlo_f16 v17, v38, s28, 0                           // 0000001A3E14: CC210011 02003926
	v_fma_mixhi_f16 v17, v39, s28, 0                           // 0000001A3E1C: CC220011 02003927
	v_dual_fmac_f32 v15, 0xbb800000, v50 :: v_dual_fmac_f32 v12, 0xbb800000, v52// 0000001A3E24: C80064FF 0F0C68FF BB800000
	v_cndmask_b16 v1, 0, v18, s14                              // 0000001A3E30: D65D5001 003A2480
	v_cndmask_b16 v2, 0, v19, s13                              // 0000001A3E38: D65D0002 00362680
	v_cndmask_b16 v2, 0, v2, s12                               // 0000001A3E40: D65D5002 00320480
	v_dual_fmac_f32 v16, 0xbb800000, v53 :: v_dual_fmac_f32 v33, 0xbb800000, v54// 0000001A3E48: C8006AFF 10206CFF BB800000
	v_cndmask_b16 v3, 0, v3, s10                               // 0000001A3E54: D65D0003 002A0680
	v_fma_mixlo_f16 v18, v35, s28, 0                           // 0000001A3E5C: CC210012 02003923
	s_waitcnt vmcnt(2)                                         // 0000001A3E64: BF890BF7
	v_dual_fmac_f32 v13, 0xbb800000, v55 :: v_dual_fmac_f32 v14, 0xbb800000, v56// 0000001A3E68: C8006EFF 0D0E70FF BB800000
	v_cndmask_b16 v3, 0, v3, s1                                // 0000001A3E74: D65D5003 00060680
	v_cndmask_b16 v17, 0, v17, s9                              // 0000001A3E7C: D65D0011 00262280
	v_cndmask_b16 v17, 0, v17, s0                              // 0000001A3E84: D65D5011 00022280
	ds_store_b16 v143, v1 offset:2304                          // 0000001A3E8C: D87C0900 0000018F
	ds_store_b16_d16_hi v143, v1 offset:2308                   // 0000001A3E94: DA840904 0000018F
	ds_store_b16 v143, v2 offset:2312                          // 0000001A3E9C: D87C0908 0000028F
	ds_store_b16_d16_hi v143, v2 offset:2316                   // 0000001A3EA4: DA84090C 0000028F
	ds_store_b16 v143, v3 offset:2320                          // 0000001A3EAC: D87C0910 0000038F
	ds_store_b16_d16_hi v143, v3 offset:2324                   // 0000001A3EB4: DA840914 0000038F
	ds_store_b16 v143, v17 offset:2328                         // 0000001A3EBC: D87C0918 0000118F
	ds_store_b16_d16_hi v143, v17 offset:2332                  // 0000001A3EC4: DA84091C 0000118F
	v_fma_mixhi_f16 v1, v15, s28, 0                            // 0000001A3ECC: CC220001 0200390F
	v_fma_mixlo_f16 v2, v34, s28, 0                            // 0000001A3ED4: CC210002 02003922
	v_dual_fmac_f32 v10, 0xbb800000, v25 :: v_dual_fmac_f32 v9, 0xbb800000, v26// 0000001A3EDC: C80032FF 0A0834FF BB800000
	v_fma_mixhi_f16 v2, v12, s28, 0                            // 0000001A3EE8: CC220002 0200390C
	v_fma_mixlo_f16 v3, v16, s28, 0                            // 0000001A3EF0: CC210003 02003910
	v_dual_fmac_f32 v11, 0xbb800000, v27 :: v_dual_fmac_f32 v4, 0xbb800000, v28// 0000001A3EF8: C80036FF 0B0438FF BB800000
	v_cndmask_b16 v1, 0, v18, s11                              // 0000001A3F04: D65D0001 002E2480
	v_fma_mixhi_f16 v3, v33, s28, 0                            // 0000001A3F0C: CC220003 02003921
	v_fma_mixlo_f16 v12, v13, s28, 0                           // 0000001A3F14: CC21000C 0200390D
	v_fma_mixhi_f16 v12, v14, s28, 0                           // 0000001A3F1C: CC22000C 0200390E
	v_cndmask_b16 v1, 0, v1, s14                               // 0000001A3F24: D65D5001 003A0280
	v_dual_fmac_f32 v6, 0xbb800000, v29 :: v_dual_fmac_f32 v5, 0xbb800000, v30// 0000001A3F2C: C8003AFF 06043CFF BB800000
	v_cndmask_b16 v2, 0, v2, s13                               // 0000001A3F38: D65D0002 00360480
	v_fma_mixlo_f16 v10, v10, s28, 0                           // 0000001A3F40: CC21000A 0200390A
	s_waitcnt vmcnt(0)                                         // 0000001A3F48: BF8903F7
	v_dual_fmac_f32 v8, 0xbb800000, v31 :: v_dual_fmac_f32 v7, 0xbb800000, v32// 0000001A3F4C: C8003EFF 080640FF BB800000
	v_cndmask_b16 v2, 0, v2, s12                               // 0000001A3F58: D65D5002 00320480
	v_fma_mixlo_f16 v9, v9, s28, 0                             // 0000001A3F60: CC210009 02003909
	v_cndmask_b16 v3, 0, v3, s10                               // 0000001A3F68: D65D0003 002A0680
	v_fma_mixhi_f16 v9, v11, s28, 0                            // 0000001A3F70: CC220009 0200390B
	v_cndmask_b16 v3, 0, v3, s1                                // 0000001A3F78: D65D5003 00060680
	v_cndmask_b16 v12, 0, v12, s9                              // 0000001A3F80: D65D000C 00261880
	v_cndmask_b16 v12, 0, v12, s0                              // 0000001A3F88: D65D500C 00021880
	ds_store_b16 v143, v1 offset:4608                          // 0000001A3F90: D87C1200 0000018F
	ds_store_b16_d16_hi v143, v1 offset:4612                   // 0000001A3F98: DA841204 0000018F
	ds_store_b16 v143, v2 offset:4616                          // 0000001A3FA0: D87C1208 0000028F
	ds_store_b16_d16_hi v143, v2 offset:4620                   // 0000001A3FA8: DA84120C 0000028F
	ds_store_b16 v143, v3 offset:4624                          // 0000001A3FB0: D87C1210 0000038F
	ds_store_b16_d16_hi v143, v3 offset:4628                   // 0000001A3FB8: DA841214 0000038F
	ds_store_b16 v143, v12 offset:4632                         // 0000001A3FC0: D87C1218 00000C8F
	ds_store_b16_d16_hi v143, v12 offset:4636                  // 0000001A3FC8: DA84121C 00000C8F
	v_fma_mixhi_f16 v2, v4, s28, 0                             // 0000001A3FD0: CC220002 02003904
	v_fma_mixlo_f16 v3, v6, s28, 0                             // 0000001A3FD8: CC210003 02003906
	v_cndmask_b16 v1, 0, v10, s11                              // 0000001A3FE0: D65D0001 002E1480
	v_fma_mixhi_f16 v3, v5, s28, 0                             // 0000001A3FE8: CC220003 02003905
	v_fma_mixlo_f16 v4, v8, s28, 0                             // 0000001A3FF0: CC210004 02003908
	v_fma_mixhi_f16 v4, v7, s28, 0                             // 0000001A3FF8: CC220004 02003907
	v_cndmask_b16 v1, 0, v9, s14                               // 0000001A4000: D65D4001 003A1280
	v_cndmask_b16 v2, 0, v9, s13                               // 0000001A4008: D65D1002 00361280
	v_cndmask_b16 v2, 0, v2, s12                               // 0000001A4010: D65D5002 00320480
	v_cndmask_b16 v3, 0, v3, s10                               // 0000001A4018: D65D0003 002A0680
	v_cndmask_b16 v3, 0, v3, s1                                // 0000001A4020: D65D5003 00060680
	v_cndmask_b16 v4, 0, v4, s9                                // 0000001A4028: D65D0004 00260880
	v_cndmask_b16 v4, 0, v4, s0                                // 0000001A4030: D65D5004 00020880
	ds_store_b16 v143, v1 offset:6912                          // 0000001A4038: D87C1B00 0000018F
	ds_store_b16_d16_hi v143, v1 offset:6916                   // 0000001A4040: DA841B04 0000018F
	ds_store_b16 v143, v2 offset:6920                          // 0000001A4048: D87C1B08 0000028F
	ds_store_b16_d16_hi v143, v2 offset:6924                   // 0000001A4050: DA841B0C 0000028F
	ds_store_b16 v143, v3 offset:6928                          // 0000001A4058: D87C1B10 0000038F
	ds_store_b16_d16_hi v143, v3 offset:6932                   // 0000001A4060: DA841B14 0000038F
	ds_store_b16 v143, v4 offset:6936                          // 0000001A4068: D87C1B18 0000048F
	ds_store_b16_d16_hi v143, v4 offset:6940                   // 0000001A4070: DA841B1C 0000048F
	.long 0xd7000f01                                           // 0000001A4078: D7000F01
	v_cndmask_b32_e32 v1, s36, v97, vcc_lo                     // 0000001A407C: 0202C224
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A4080: BF870001
	v_add_co_ci_u32_e64 v2, null, s37, v98, s15                // 0000001A4084: D5207C02 003EC425
	s_waitcnt lgkmcnt(0)                                       // 0000001A408C: BF89FC07
	s_barrier                                                  // 0000001A4090: BFBD0000
	buffer_gl0_inv                                             // 0000001A4094: E0AC0000 00000000
	s_clause 0xf                                               // 0000001A409C: BF85000F
	global_load_b128 v[97:100], v[1:2], off                    // 0000001A40A0: DC5E0000 617C0001
	global_load_b128 v[101:104], v[1:2], off offset:16         // 0000001A40A8: DC5E0010 657C0001
	global_load_b128 v[89:92], v[1:2], off offset:32           // 0000001A40B0: DC5E0020 597C0001
	global_load_b128 v[93:96], v[1:2], off offset:48           // 0000001A40B8: DC5E0030 5D7C0001
	global_load_b128 v[81:84], v[1:2], off offset:64           // 0000001A40C0: DC5E0040 517C0001
	global_load_b128 v[85:88], v[1:2], off offset:80           // 0000001A40C8: DC5E0050 557C0001
	global_load_b128 v[73:76], v[1:2], off offset:96           // 0000001A40D0: DC5E0060 497C0001
	global_load_b128 v[77:80], v[1:2], off offset:112          // 0000001A40D8: DC5E0070 4D7C0001
	global_load_b128 v[57:60], v[1:2], off offset:128          // 0000001A40E0: DC5E0080 397C0001
	global_load_b128 v[61:64], v[1:2], off offset:144          // 0000001A40E8: DC5E0090 3D7C0001
	global_load_b128 v[49:52], v[1:2], off offset:160          // 0000001A40F0: DC5E00A0 317C0001
	global_load_b128 v[53:56], v[1:2], off offset:176          // 0000001A40F8: DC5E00B0 357C0001
	global_load_b128 v[41:44], v[1:2], off offset:192          // 0000001A4100: DC5E00C0 297C0001
	global_load_b128 v[45:48], v[1:2], off offset:208          // 0000001A4108: DC5E00D0 2D7C0001
	global_load_b128 v[33:36], v[1:2], off offset:224          // 0000001A4110: DC5E00E0 217C0001
	global_load_b128 v[37:40], v[1:2], off offset:240          // 0000001A4118: DC5E00F0 257C0001
	s_and_saveexec_b32 s15, vcc_lo                             // 0000001A4120: BE8F206A
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A4124: BF870009
	s_xor_b32 s15, exec_lo, s15                                // 0000001A4128: 8D0F0F7E
	s_cbranch_execz 81                                         // 0000001A412C: BFA50051 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x4874>
	s_waitcnt vmcnt(15)                                        // 0000001A4130: BF893FF7
	v_mov_b32_e32 v97, 0                                       // 0000001A4134: 7EC20280
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A4138: BF870001
	v_mov_b32_e32 v98, v97                                     // 0000001A413C: 7EC40361
	v_mov_b32_e32 v99, v97                                     // 0000001A4140: 7EC60361
	v_mov_b32_e32 v100, v97                                    // 0000001A4144: 7EC80361
	s_waitcnt vmcnt(14)                                        // 0000001A4148: BF893BF7
	v_mov_b32_e32 v101, v97                                    // 0000001A414C: 7ECA0361
	v_mov_b32_e32 v102, v97                                    // 0000001A4150: 7ECC0361
	v_mov_b32_e32 v103, v97                                    // 0000001A4154: 7ECE0361
	v_mov_b32_e32 v104, v97                                    // 0000001A4158: 7ED00361
	s_waitcnt vmcnt(13)                                        // 0000001A415C: BF8937F7
	v_mov_b32_e32 v89, v97                                     // 0000001A4160: 7EB20361
	v_mov_b32_e32 v90, v97                                     // 0000001A4164: 7EB40361
	v_mov_b32_e32 v91, v97                                     // 0000001A4168: 7EB60361
	v_mov_b32_e32 v92, v97                                     // 0000001A416C: 7EB80361
	s_waitcnt vmcnt(12)                                        // 0000001A4170: BF8933F7
	v_mov_b32_e32 v93, v97                                     // 0000001A4174: 7EBA0361
	v_mov_b32_e32 v94, v97                                     // 0000001A4178: 7EBC0361
	v_mov_b32_e32 v95, v97                                     // 0000001A417C: 7EBE0361
	v_mov_b32_e32 v96, v97                                     // 0000001A4180: 7EC00361
	s_waitcnt vmcnt(11)                                        // 0000001A4184: BF892FF7
	v_mov_b32_e32 v81, v97                                     // 0000001A4188: 7EA20361
	v_mov_b32_e32 v82, v97                                     // 0000001A418C: 7EA40361
	v_mov_b32_e32 v83, v97                                     // 0000001A4190: 7EA60361
	v_mov_b32_e32 v84, v97                                     // 0000001A4194: 7EA80361
	s_waitcnt vmcnt(10)                                        // 0000001A4198: BF892BF7
	v_mov_b32_e32 v85, v97                                     // 0000001A419C: 7EAA0361
	v_mov_b32_e32 v86, v97                                     // 0000001A41A0: 7EAC0361
	v_mov_b32_e32 v87, v97                                     // 0000001A41A4: 7EAE0361
	v_mov_b32_e32 v88, v97                                     // 0000001A41A8: 7EB00361
	s_waitcnt vmcnt(9)                                         // 0000001A41AC: BF8927F7
	v_mov_b32_e32 v73, v97                                     // 0000001A41B0: 7E920361
	v_mov_b32_e32 v74, v97                                     // 0000001A41B4: 7E940361
	v_mov_b32_e32 v75, v97                                     // 0000001A41B8: 7E960361
	v_mov_b32_e32 v76, v97                                     // 0000001A41BC: 7E980361
	s_waitcnt vmcnt(8)                                         // 0000001A41C0: BF8923F7
	v_mov_b32_e32 v77, v97                                     // 0000001A41C4: 7E9A0361
	v_mov_b32_e32 v78, v97                                     // 0000001A41C8: 7E9C0361
	v_mov_b32_e32 v79, v97                                     // 0000001A41CC: 7E9E0361
	v_mov_b32_e32 v80, v97                                     // 0000001A41D0: 7EA00361
	s_waitcnt vmcnt(7)                                         // 0000001A41D4: BF891FF7
	v_mov_b32_e32 v57, v97                                     // 0000001A41D8: 7E720361
	v_mov_b32_e32 v58, v97                                     // 0000001A41DC: 7E740361
	v_mov_b32_e32 v59, v97                                     // 0000001A41E0: 7E760361
	v_mov_b32_e32 v60, v97                                     // 0000001A41E4: 7E780361
	s_waitcnt vmcnt(6)                                         // 0000001A41E8: BF891BF7
	v_mov_b32_e32 v61, v97                                     // 0000001A41EC: 7E7A0361
	v_mov_b32_e32 v62, v97                                     // 0000001A41F0: 7E7C0361
	v_mov_b32_e32 v63, v97                                     // 0000001A41F4: 7E7E0361
	v_mov_b32_e32 v64, v97                                     // 0000001A41F8: 7E800361
	s_waitcnt vmcnt(5)                                         // 0000001A41FC: BF8917F7
	v_mov_b32_e32 v49, v97                                     // 0000001A4200: 7E620361
	v_mov_b32_e32 v50, v97                                     // 0000001A4204: 7E640361
	v_mov_b32_e32 v51, v97                                     // 0000001A4208: 7E660361
	v_mov_b32_e32 v52, v97                                     // 0000001A420C: 7E680361
	s_waitcnt vmcnt(4)                                         // 0000001A4210: BF8913F7
	v_mov_b32_e32 v53, v97                                     // 0000001A4214: 7E6A0361
	v_mov_b32_e32 v54, v97                                     // 0000001A4218: 7E6C0361
	v_mov_b32_e32 v55, v97                                     // 0000001A421C: 7E6E0361
	v_mov_b32_e32 v56, v97                                     // 0000001A4220: 7E700361
	s_waitcnt vmcnt(3)                                         // 0000001A4224: BF890FF7
	v_mov_b32_e32 v41, v97                                     // 0000001A4228: 7E520361
	v_mov_b32_e32 v42, v97                                     // 0000001A422C: 7E540361
	v_mov_b32_e32 v43, v97                                     // 0000001A4230: 7E560361
	v_mov_b32_e32 v44, v97                                     // 0000001A4234: 7E580361
	s_waitcnt vmcnt(2)                                         // 0000001A4238: BF890BF7
	v_mov_b32_e32 v45, v97                                     // 0000001A423C: 7E5A0361
	v_mov_b32_e32 v46, v97                                     // 0000001A4240: 7E5C0361
	v_mov_b32_e32 v47, v97                                     // 0000001A4244: 7E5E0361
	v_mov_b32_e32 v48, v97                                     // 0000001A4248: 7E600361
	s_waitcnt vmcnt(1)                                         // 0000001A424C: BF8907F7
	v_mov_b32_e32 v33, v97                                     // 0000001A4250: 7E420361
	v_mov_b32_e32 v34, v97                                     // 0000001A4254: 7E440361
	v_mov_b32_e32 v35, v97                                     // 0000001A4258: 7E460361
	v_mov_b32_e32 v36, v97                                     // 0000001A425C: 7E480361
	s_waitcnt vmcnt(0)                                         // 0000001A4260: BF8903F7
	v_mov_b32_e32 v37, v97                                     // 0000001A4264: 7E4A0361
	v_mov_b32_e32 v38, v97                                     // 0000001A4268: 7E4C0361
	v_mov_b32_e32 v39, v97                                     // 0000001A426C: 7E4E0361
	v_mov_b32_e32 v40, v97                                     // 0000001A4270: 7E500361
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A4274: 8C7E0F7E
	ds_load_b128 v[1:4], v134                                  // 0000001A4278: DBFC0000 01000086
	ds_load_b128 v[5:8], v134 offset:16                        // 0000001A4280: DBFC0010 05000086
	ds_load_b128 v[9:12], v134 offset:32                       // 0000001A4288: DBFC0020 09000086
	ds_load_b128 v[13:16], v134 offset:48                      // 0000001A4290: DBFC0030 0D000086
	ds_load_b128 v[17:20], v134 offset:8448                    // 0000001A4298: DBFC2100 11000086
	ds_load_b128 v[21:24], v134 offset:8464                    // 0000001A42A0: DBFC2110 15000086
	ds_load_b128 v[25:28], v134 offset:8480                    // 0000001A42A8: DBFC2120 19000086
	ds_load_b128 v[29:32], v134 offset:8496                    // 0000001A42B0: DBFC2130 1D000086
	ds_load_b128 v[190:193], v134 offset:16896                 // 0000001A42B8: DBFC4200 BE000086
	ds_load_b128 v[194:197], v134 offset:16912                 // 0000001A42C0: DBFC4210 C2000086
	ds_load_b128 v[198:201], v134 offset:16928                 // 0000001A42C8: DBFC4220 C6000086
	ds_load_b128 v[202:205], v134 offset:16944                 // 0000001A42D0: DBFC4230 CA000086
	ds_load_b128 v[206:209], v134 offset:25376                 // 0000001A42D8: DBFC6320 CE000086
	v_dual_mov_b32 v72, s51 :: v_dual_mov_b32 v71, s50         // 0000001A42E0: CA100033 48460032
	v_dual_mov_b32 v70, s49 :: v_dual_mov_b32 v69, s48         // 0000001A42E8: CA100031 46440030
	v_dual_mov_b32 v68, s47 :: v_dual_mov_b32 v67, s46         // 0000001A42F0: CA10002F 4442002E
	v_dual_mov_b32 v66, s45 :: v_dual_mov_b32 v65, s44         // 0000001A42F8: CA10002D 4240002C
	s_waitcnt lgkmcnt(12)                                      // 0000001A4300: BF89FCC7
	v_fma_mixlo_f16 v1, v1, s28, 0                             // 0000001A4304: CC210001 02003901
	v_fma_mixhi_f16 v1, v2, s28, 0                             // 0000001A430C: CC220001 02003902
	v_fma_mixlo_f16 v2, v3, s28, 0                             // 0000001A4314: CC210002 02003903
	v_fma_mixhi_f16 v2, v4, s28, 0                             // 0000001A431C: CC220002 02003904
	s_waitcnt lgkmcnt(11)                                      // 0000001A4324: BF89FCB7
	v_fma_mixlo_f16 v3, v5, s28, 0                             // 0000001A4328: CC210003 02003905
	v_fma_mixhi_f16 v3, v6, s28, 0                             // 0000001A4330: CC220003 02003906
	v_fma_mixlo_f16 v4, v7, s28, 0                             // 0000001A4338: CC210004 02003907
	v_fma_mixhi_f16 v4, v8, s28, 0                             // 0000001A4340: CC220004 02003908
	s_waitcnt lgkmcnt(10)                                      // 0000001A4348: BF89FCA7
	v_fma_mixlo_f16 v5, v9, s28, 0                             // 0000001A434C: CC210005 02003909
	v_fma_mixhi_f16 v5, v10, s28, 0                            // 0000001A4354: CC220005 0200390A
	v_fma_mixlo_f16 v6, v11, s28, 0                            // 0000001A435C: CC210006 0200390B
	v_fma_mixhi_f16 v6, v12, s28, 0                            // 0000001A4364: CC220006 0200390C
	s_waitcnt lgkmcnt(9)                                       // 0000001A436C: BF89FC97
	v_fma_mixlo_f16 v7, v13, s28, 0                            // 0000001A4370: CC210007 0200390D
	v_fma_mixhi_f16 v7, v14, s28, 0                            // 0000001A4378: CC220007 0200390E
	v_fma_mixlo_f16 v8, v15, s28, 0                            // 0000001A4380: CC210008 0200390F
	v_fma_mixhi_f16 v8, v16, s28, 0                            // 0000001A4388: CC220008 02003910
	s_waitcnt lgkmcnt(8)                                       // 0000001A4390: BF89FC87
	v_fma_mixlo_f16 v17, v17, s28, 0                           // 0000001A4394: CC210011 02003911
	v_fma_mixhi_f16 v17, v18, s28, 0                           // 0000001A439C: CC220011 02003912
	v_fma_mixlo_f16 v18, v19, s28, 0                           // 0000001A43A4: CC210012 02003913
	v_fma_mixhi_f16 v18, v20, s28, 0                           // 0000001A43AC: CC220012 02003914
	s_waitcnt lgkmcnt(7)                                       // 0000001A43B4: BF89FC77
	v_fma_mixlo_f16 v19, v21, s28, 0                           // 0000001A43B8: CC210013 02003915
	v_fma_mixhi_f16 v19, v22, s28, 0                           // 0000001A43C0: CC220013 02003916
	v_fma_mixlo_f16 v20, v23, s28, 0                           // 0000001A43C8: CC210014 02003917
	v_fma_mixhi_f16 v20, v24, s28, 0                           // 0000001A43D0: CC220014 02003918
	s_waitcnt lgkmcnt(6)                                       // 0000001A43D8: BF89FC67
	v_fma_mixlo_f16 v21, v25, s28, 0                           // 0000001A43DC: CC210015 02003919
	v_fma_mixhi_f16 v21, v26, s28, 0                           // 0000001A43E4: CC220015 0200391A
	v_fma_mixlo_f16 v22, v27, s28, 0                           // 0000001A43EC: CC210016 0200391B
	v_fma_mixhi_f16 v22, v28, s28, 0                           // 0000001A43F4: CC220016 0200391C
	s_waitcnt lgkmcnt(5)                                       // 0000001A43FC: BF89FC57
	v_fma_mixlo_f16 v23, v29, s28, 0                           // 0000001A4400: CC210017 0200391D
	v_fma_mixhi_f16 v23, v30, s28, 0                           // 0000001A4408: CC220017 0200391E
	v_fma_mixlo_f16 v24, v31, s28, 0                           // 0000001A4410: CC210018 0200391F
	v_fma_mixhi_f16 v24, v32, s28, 0                           // 0000001A4418: CC220018 02003920
	s_waitcnt vmcnt(14)                                        // 0000001A4420: BF893BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[97:104], v[1:8], v[65:72]// 0000001A4424: CC404019 1D060361
	s_waitcnt lgkmcnt(3)                                       // 0000001A442C: BF89FC37
	v_fma_mixlo_f16 v4, v196, s28, 0                           // 0000001A4430: CC210004 020039C4
	v_fma_mixhi_f16 v4, v197, s28, 0                           // 0000001A4438: CC220004 020039C5
	v_wmma_f32_16x16x16_f16 v[9:16], v[97:104], v[17:24], v[65:72]// 0000001A4440: CC404009 1D062361
	ds_load_b128 v[17:20], v134 offset:25344                   // 0000001A4448: DBFC6300 11000086
	ds_load_b128 v[21:24], v134 offset:25360                   // 0000001A4450: DBFC6310 15000086
	s_waitcnt lgkmcnt(4)                                       // 0000001A4458: BF89FC47
	v_fma_mixlo_f16 v5, v198, s28, 0                           // 0000001A445C: CC210005 020039C6
	v_fma_mixhi_f16 v5, v199, s28, 0                           // 0000001A4464: CC220005 020039C7
	ds_load_b128 v[196:199], v134 offset:25392                 // 0000001A446C: DBFC6330 C4000086
	v_fma_mixlo_f16 v3, v194, s28, 0                           // 0000001A4474: CC210003 020039C2
	v_fma_mixlo_f16 v6, v200, s28, 0                           // 0000001A447C: CC210006 020039C8
	v_fma_mixhi_f16 v6, v201, s28, 0                           // 0000001A4484: CC220006 020039C9
	s_waitcnt lgkmcnt(4)                                       // 0000001A448C: BF89FC47
	v_fma_mixlo_f16 v7, v202, s28, 0                           // 0000001A4490: CC210007 020039CA
	v_fma_mixhi_f16 v7, v203, s28, 0                           // 0000001A4498: CC220007 020039CB
	v_fma_mixlo_f16 v8, v204, s28, 0                           // 0000001A44A0: CC210008 020039CC
	v_fma_mixhi_f16 v8, v205, s28, 0                           // 0000001A44A8: CC220008 020039CD
	ds_load_b128 v[200:203], v134 offset:64                    // 0000001A44B0: DBFC0040 C8000086
	ds_load_b128 v[210:213], v134 offset:80                    // 0000001A44B8: DBFC0050 D2000086
	s_waitcnt lgkmcnt(5)                                       // 0000001A44C0: BF89FC57
	v_fma_mixlo_f16 v194, v206, s28, 0                         // 0000001A44C4: CC2100C2 020039CE
	v_fma_mixhi_f16 v194, v207, s28, 0                         // 0000001A44CC: CC2200C2 020039CF
	ds_load_b128 v[204:207], v134 offset:96                    // 0000001A44D4: DBFC0060 CC000086
	ds_load_b128 v[214:217], v134 offset:112                   // 0000001A44DC: DBFC0070 D6000086
	v_fma_mixlo_f16 v1, v190, s28, 0                           // 0000001A44E4: CC210001 020039BE
	v_fma_mixhi_f16 v1, v191, s28, 0                           // 0000001A44EC: CC220001 020039BF
	v_fma_mixlo_f16 v2, v192, s28, 0                           // 0000001A44F4: CC210002 020039C0
	v_fma_mixhi_f16 v2, v193, s28, 0                           // 0000001A44FC: CC220002 020039C1
	v_fma_mixhi_f16 v3, v195, s28, 0                           // 0000001A4504: CC220003 020039C3
	s_waitcnt lgkmcnt(6)                                       // 0000001A450C: BF89FC67
	v_fma_mixlo_f16 v190, v17, s28, 0                          // 0000001A4510: CC2100BE 02003911
	v_fma_mixhi_f16 v190, v18, s28, 0                          // 0000001A4518: CC2200BE 02003912
	v_fma_mixlo_f16 v191, v19, s28, 0                          // 0000001A4520: CC2100BF 02003913
	v_fma_mixhi_f16 v191, v20, s28, 0                          // 0000001A4528: CC2200BF 02003914
	s_waitcnt lgkmcnt(5)                                       // 0000001A4530: BF89FC57
	v_fma_mixlo_f16 v192, v21, s28, 0                          // 0000001A4534: CC2100C0 02003915
	v_fma_mixhi_f16 v192, v22, s28, 0                          // 0000001A453C: CC2200C0 02003916
	v_fma_mixlo_f16 v193, v23, s28, 0                          // 0000001A4544: CC2100C1 02003917
	v_fma_mixhi_f16 v193, v24, s28, 0                          // 0000001A454C: CC2200C1 02003918
	v_fma_mixlo_f16 v195, v208, s28, 0                         // 0000001A4554: CC2100C3 020039D0
	v_fma_mixhi_f16 v195, v209, s28, 0                         // 0000001A455C: CC2200C3 020039D1
	s_waitcnt lgkmcnt(4)                                       // 0000001A4564: BF89FC47
	v_fma_mixlo_f16 v196, v196, s28, 0                         // 0000001A4568: CC2100C4 020039C4
	v_fma_mixhi_f16 v196, v197, s28, 0                         // 0000001A4570: CC2200C4 020039C5
	v_fma_mixlo_f16 v197, v198, s28, 0                         // 0000001A4578: CC2100C5 020039C6
	v_fma_mixhi_f16 v197, v199, s28, 0                         // 0000001A4580: CC2200C5 020039C7
	v_wmma_f32_16x16x16_f16 v[17:24], v[97:104], v[1:8], v[65:72]// 0000001A4588: CC404011 1D060361
	ds_load_b128 v[218:221], v134 offset:17008                 // 0000001A4590: DBFC4270 DA000086
	ds_load_b128 v[222:225], v134 offset:25408                 // 0000001A4598: DBFC6340 DE000086
	ds_load_b128 v[226:229], v134 offset:25424                 // 0000001A45A0: DBFC6350 E2000086
	v_wmma_f32_16x16x16_f16 v[1:8], v[97:104], v[190:197], v[65:72]// 0000001A45A8: CC404001 1D077D61
	ds_load_b128 v[190:193], v134 offset:8512                  // 0000001A45B0: DBFC2140 BE000086
	ds_load_b128 v[194:197], v134 offset:8528                  // 0000001A45B8: DBFC2150 C2000086
	s_waitcnt lgkmcnt(8)                                       // 0000001A45C0: BF89FC87
	v_fma_mixlo_f16 v97, v200, s28, 0                          // 0000001A45C4: CC210061 020039C8
	v_fma_mixhi_f16 v97, v201, s28, 0                          // 0000001A45CC: CC220061 020039C9
	v_fma_mixlo_f16 v98, v202, s28, 0                          // 0000001A45D4: CC210062 020039CA
	v_fma_mixhi_f16 v98, v203, s28, 0                          // 0000001A45DC: CC220062 020039CB
	s_waitcnt lgkmcnt(7)                                       // 0000001A45E4: BF89FC77
	v_fma_mixlo_f16 v99, v210, s28, 0                          // 0000001A45E8: CC210063 020039D2
	v_fma_mixhi_f16 v99, v211, s28, 0                          // 0000001A45F0: CC220063 020039D3
	v_fma_mixlo_f16 v100, v212, s28, 0                         // 0000001A45F8: CC210064 020039D4
	v_fma_mixhi_f16 v100, v213, s28, 0                         // 0000001A4600: CC220064 020039D5
	ds_load_b128 v[198:201], v134 offset:8544                  // 0000001A4608: DBFC2160 C6000086
	s_waitcnt lgkmcnt(7)                                       // 0000001A4610: BF89FC77
	v_fma_mixlo_f16 v101, v204, s28, 0                         // 0000001A4614: CC210065 020039CC
	v_fma_mixhi_f16 v101, v205, s28, 0                         // 0000001A461C: CC220065 020039CD
	v_fma_mixlo_f16 v102, v206, s28, 0                         // 0000001A4624: CC210066 020039CE
	v_fma_mixhi_f16 v102, v207, s28, 0                         // 0000001A462C: CC220066 020039CF
	ds_load_b128 v[202:205], v134 offset:8560                  // 0000001A4634: DBFC2170 CA000086
	s_waitcnt lgkmcnt(7)                                       // 0000001A463C: BF89FC77
	v_fma_mixlo_f16 v103, v214, s28, 0                         // 0000001A4640: CC210067 020039D6
	v_fma_mixhi_f16 v103, v215, s28, 0                         // 0000001A4648: CC220067 020039D7
	v_fma_mixlo_f16 v104, v216, s28, 0                         // 0000001A4650: CC210068 020039D8
	v_fma_mixhi_f16 v104, v217, s28, 0                         // 0000001A4658: CC220068 020039D9
	ds_load_b128 v[206:209], v134 offset:16960                 // 0000001A4660: DBFC4240 CE000086
	ds_load_b128 v[210:213], v134 offset:16976                 // 0000001A4668: DBFC4250 D2000086
	ds_load_b128 v[214:217], v134 offset:16992                 // 0000001A4670: DBFC4260 D6000086
	s_waitcnt lgkmcnt(6)                                       // 0000001A4678: BF89FC67
	v_fma_mixlo_f16 v190, v190, s28, 0                         // 0000001A467C: CC2100BE 020039BE
	v_fma_mixhi_f16 v190, v191, s28, 0                         // 0000001A4684: CC2200BE 020039BF
	v_fma_mixlo_f16 v191, v192, s28, 0                         // 0000001A468C: CC2100BF 020039C0
	v_fma_mixhi_f16 v191, v193, s28, 0                         // 0000001A4694: CC2200BF 020039C1
	s_waitcnt lgkmcnt(5)                                       // 0000001A469C: BF89FC57
	v_fma_mixhi_f16 v192, v195, s28, 0                         // 0000001A46A0: CC2200C0 020039C3
	v_fma_mixlo_f16 v193, v196, s28, 0                         // 0000001A46A8: CC2100C1 020039C4
	ds_load_b128 v[230:233], v134 offset:25440                 // 0000001A46B0: DBFC6360 E6000086
	s_waitcnt lgkmcnt(5)                                       // 0000001A46B8: BF89FC57
	v_fma_mixhi_f16 v195, v201, s28, 0                         // 0000001A46BC: CC2200C3 020039C9
	v_fma_mixlo_f16 v192, v194, s28, 0                         // 0000001A46C4: CC2100C0 020039C2
	v_fma_mixhi_f16 v193, v197, s28, 0                         // 0000001A46CC: CC2200C1 020039C5
	v_fma_mixlo_f16 v194, v198, s28, 0                         // 0000001A46D4: CC2100C2 020039C6
	v_fma_mixhi_f16 v194, v199, s28, 0                         // 0000001A46DC: CC2200C2 020039C7
	s_waitcnt lgkmcnt(4)                                       // 0000001A46E4: BF89FC47
	v_fma_mixlo_f16 v196, v202, s28, 0                         // 0000001A46E8: CC2100C4 020039CA
	v_fma_mixlo_f16 v195, v200, s28, 0                         // 0000001A46F0: CC2100C3 020039C8
	v_fma_mixhi_f16 v196, v203, s28, 0                         // 0000001A46F8: CC2200C4 020039CB
	v_fma_mixlo_f16 v197, v204, s28, 0                         // 0000001A4700: CC2100C5 020039CC
	v_fma_mixhi_f16 v197, v205, s28, 0                         // 0000001A4708: CC2200C5 020039CD
	s_waitcnt lgkmcnt(3)                                       // 0000001A4710: BF89FC37
	v_fma_mixlo_f16 v198, v206, s28, 0                         // 0000001A4714: CC2100C6 020039CE
	s_waitcnt lgkmcnt(2)                                       // 0000001A471C: BF89FC27
	v_fma_mixlo_f16 v201, v212, s28, 0                         // 0000001A4720: CC2100C9 020039D4
	v_fma_mixhi_f16 v201, v213, s28, 0                         // 0000001A4728: CC2200C9 020039D5
	s_waitcnt lgkmcnt(1)                                       // 0000001A4730: BF89FC17
	v_fma_mixlo_f16 v202, v214, s28, 0                         // 0000001A4734: CC2100CA 020039D6
	v_fma_mixhi_f16 v202, v215, s28, 0                         // 0000001A473C: CC2200CA 020039D7
	ds_load_b128 v[212:215], v134 offset:25456                 // 0000001A4744: DBFC6370 D4000086
	v_fma_mixhi_f16 v198, v207, s28, 0                         // 0000001A474C: CC2200C6 020039CF
	v_fma_mixlo_f16 v199, v208, s28, 0                         // 0000001A4754: CC2100C7 020039D0
	v_fma_mixhi_f16 v199, v209, s28, 0                         // 0000001A475C: CC2200C7 020039D1
	v_fma_mixlo_f16 v200, v210, s28, 0                         // 0000001A4764: CC2100C8 020039D2
	v_fma_mixhi_f16 v200, v211, s28, 0                         // 0000001A476C: CC2200C8 020039D3
	v_fma_mixlo_f16 v203, v216, s28, 0                         // 0000001A4774: CC2100CB 020039D8
	v_fma_mixhi_f16 v203, v217, s28, 0                         // 0000001A477C: CC2200CB 020039D9
	v_fma_mixlo_f16 v204, v218, s28, 0                         // 0000001A4784: CC2100CC 020039DA
	v_fma_mixhi_f16 v204, v219, s28, 0                         // 0000001A478C: CC2200CC 020039DB
	v_fma_mixlo_f16 v205, v220, s28, 0                         // 0000001A4794: CC2100CD 020039DC
	v_fma_mixhi_f16 v205, v221, s28, 0                         // 0000001A479C: CC2200CD 020039DD
	v_fma_mixlo_f16 v206, v222, s28, 0                         // 0000001A47A4: CC2100CE 020039DE
	v_fma_mixhi_f16 v206, v223, s28, 0                         // 0000001A47AC: CC2200CE 020039DF
	v_fma_mixlo_f16 v207, v224, s28, 0                         // 0000001A47B4: CC2100CF 020039E0
	v_fma_mixhi_f16 v207, v225, s28, 0                         // 0000001A47BC: CC2200CF 020039E1
	v_fma_mixlo_f16 v208, v226, s28, 0                         // 0000001A47C4: CC2100D0 020039E2
	v_fma_mixhi_f16 v208, v227, s28, 0                         // 0000001A47CC: CC2200D0 020039E3
	v_fma_mixlo_f16 v209, v228, s28, 0                         // 0000001A47D4: CC2100D1 020039E4
	v_fma_mixhi_f16 v209, v229, s28, 0                         // 0000001A47DC: CC2200D1 020039E5
	s_waitcnt lgkmcnt(1)                                       // 0000001A47E4: BF89FC17
	v_fma_mixlo_f16 v210, v230, s28, 0                         // 0000001A47E8: CC2100D2 020039E6
	v_fma_mixhi_f16 v210, v231, s28, 0                         // 0000001A47F0: CC2200D2 020039E7
	v_fma_mixlo_f16 v211, v232, s28, 0                         // 0000001A47F8: CC2100D3 020039E8
	v_fma_mixhi_f16 v211, v233, s28, 0                         // 0000001A4800: CC2200D3 020039E9
	s_waitcnt lgkmcnt(0)                                       // 0000001A4808: BF89FC07
	v_fma_mixlo_f16 v212, v212, s28, 0                         // 0000001A480C: CC2100D4 020039D4
	v_fma_mixhi_f16 v212, v213, s28, 0                         // 0000001A4814: CC2200D4 020039D5
	v_fma_mixlo_f16 v213, v214, s28, 0                         // 0000001A481C: CC2100D5 020039D6
	v_fma_mixhi_f16 v213, v215, s28, 0                         // 0000001A4824: CC2200D5 020039D7
	ds_load_b128 v[216:219], v134 offset:128                   // 0000001A482C: DBFC0080 D8000086
	ds_load_b128 v[220:223], v134 offset:144                   // 0000001A4834: DBFC0090 DC000086
	ds_load_b128 v[224:227], v134 offset:160                   // 0000001A483C: DBFC00A0 E0000086
	s_waitcnt vmcnt(12)                                        // 0000001A4844: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[89:96], v[97:104], v[25:32]// 0000001A4848: CC404019 1C66C359
	ds_load_b128 v[97:100], v134 offset:176                    // 0000001A4850: DBFC00B0 61000086
	v_wmma_f32_16x16x16_f16 v[9:16], v[89:96], v[190:197], v[9:16]// 0000001A4858: CC404009 1C277D59
	v_wmma_f32_16x16x16_f16 v[17:24], v[89:96], v[198:205], v[17:24]// 0000001A4860: CC404011 1C478D59
	v_wmma_f32_16x16x16_f16 v[1:8], v[89:96], v[206:213], v[1:8]// 0000001A4868: CC404001 1C079D59
	ds_load_b128 v[101:104], v134 offset:8576                  // 0000001A4870: DBFC2180 65000086
	ds_load_b128 v[190:193], v134 offset:8592                  // 0000001A4878: DBFC2190 BE000086
	ds_load_b128 v[194:197], v134 offset:8608                  // 0000001A4880: DBFC21A0 C2000086
	ds_load_b128 v[198:201], v134 offset:8624                  // 0000001A4888: DBFC21B0 C6000086
	ds_load_b128 v[202:205], v134 offset:17024                 // 0000001A4890: DBFC4280 CA000086
	ds_load_b128 v[206:209], v134 offset:17040                 // 0000001A4898: DBFC4290 CE000086
	ds_load_b128 v[210:213], v134 offset:17056                 // 0000001A48A0: DBFC42A0 D2000086
	s_mul_i32 s24, s29, 48                                     // 0000001A48A8: 9618B01D
	s_mul_hi_u32 s25, s29, 48                                  // 0000001A48AC: 9699B01D
	s_add_u32 s56, s24, s2                                     // 0000001A48B0: 80380218
	s_addc_u32 s57, s25, s3                                    // 0000001A48B4: 82390319
	ds_load_b128 v[230:233], v134 offset:25648                 // 0000001A48B8: DBFC6430 E6000086
	s_waitcnt lgkmcnt(11)                                      // 0000001A48C0: BF89FCB7
	v_fma_mixlo_f16 v89, v216, s28, 0                          // 0000001A48C4: CC210059 020039D8
	v_fma_mixhi_f16 v89, v217, s28, 0                          // 0000001A48CC: CC220059 020039D9
	v_fma_mixlo_f16 v90, v218, s28, 0                          // 0000001A48D4: CC21005A 020039DA
	v_fma_mixhi_f16 v90, v219, s28, 0                          // 0000001A48DC: CC22005A 020039DB
	s_waitcnt lgkmcnt(10)                                      // 0000001A48E4: BF89FCA7
	v_fma_mixlo_f16 v91, v220, s28, 0                          // 0000001A48E8: CC21005B 020039DC
	v_fma_mixhi_f16 v91, v221, s28, 0                          // 0000001A48F0: CC22005B 020039DD
	s_waitcnt lgkmcnt(8)                                       // 0000001A48F8: BF89FC87
	v_fma_mixhi_f16 v95, v98, s28, 0                           // 0000001A48FC: CC22005F 02003962
	v_fma_mixlo_f16 v96, v99, s28, 0                           // 0000001A4904: CC210060 02003963
	v_fma_mixhi_f16 v96, v100, s28, 0                          // 0000001A490C: CC220060 02003964
	s_waitcnt lgkmcnt(7)                                       // 0000001A4914: BF89FC77
	v_fma_mixlo_f16 v98, v103, s28, 0                          // 0000001A4918: CC210062 02003967
	v_fma_mixhi_f16 v98, v104, s28, 0                          // 0000001A4920: CC220062 02003968
	s_waitcnt lgkmcnt(6)                                       // 0000001A4928: BF89FC67
	v_fma_mixlo_f16 v99, v190, s28, 0                          // 0000001A492C: CC210063 020039BE
	v_fma_mixhi_f16 v99, v191, s28, 0                          // 0000001A4934: CC220063 020039BF
	v_fma_mixlo_f16 v100, v192, s28, 0                         // 0000001A493C: CC210064 020039C0
	v_fma_mixhi_f16 v100, v193, s28, 0                         // 0000001A4944: CC220064 020039C1
	s_waitcnt lgkmcnt(4)                                       // 0000001A494C: BF89FC47
	v_fma_mixlo_f16 v103, v198, s28, 0                         // 0000001A4950: CC210067 020039C6
	ds_load_b128 v[214:217], v134 offset:17072                 // 0000001A4958: DBFC42B0 D6000086
	v_fma_mixhi_f16 v103, v199, s28, 0                         // 0000001A4960: CC220067 020039C7
	v_fma_mixlo_f16 v104, v200, s28, 0                         // 0000001A4968: CC210068 020039C8
	v_fma_mixhi_f16 v104, v201, s28, 0                         // 0000001A4970: CC220068 020039C9
	ds_load_b128 v[198:201], v134 offset:25472                 // 0000001A4978: DBFC6380 C6000086
	ds_load_b128 v[218:221], v134 offset:25488                 // 0000001A4980: DBFC6390 DA000086
	s_waitcnt lgkmcnt(6)                                       // 0000001A4988: BF89FC67
	v_fma_mixlo_f16 v190, v202, s28, 0                         // 0000001A498C: CC2100BE 020039CA
	v_fma_mixhi_f16 v190, v203, s28, 0                         // 0000001A4994: CC2200BE 020039CB
	v_fma_mixlo_f16 v191, v204, s28, 0                         // 0000001A499C: CC2100BF 020039CC
	v_fma_mixhi_f16 v191, v205, s28, 0                         // 0000001A49A4: CC2200BF 020039CD
	s_waitcnt lgkmcnt(5)                                       // 0000001A49AC: BF89FC57
	v_fma_mixlo_f16 v192, v206, s28, 0                         // 0000001A49B0: CC2100C0 020039CE
	v_fma_mixhi_f16 v192, v207, s28, 0                         // 0000001A49B8: CC2200C0 020039CF
	v_fma_mixlo_f16 v193, v208, s28, 0                         // 0000001A49C0: CC2100C1 020039D0
	ds_load_b128 v[202:205], v134 offset:25504                 // 0000001A49C8: DBFC63A0 CA000086
	v_fma_mixhi_f16 v193, v209, s28, 0                         // 0000001A49D0: CC2200C1 020039D1
	ds_load_b128 v[206:209], v134 offset:25520                 // 0000001A49D8: DBFC63B0 CE000086
	v_fma_mixlo_f16 v92, v222, s28, 0                          // 0000001A49E0: CC21005C 020039DE
	v_fma_mixhi_f16 v92, v223, s28, 0                          // 0000001A49E8: CC22005C 020039DF
	v_fma_mixlo_f16 v93, v224, s28, 0                          // 0000001A49F0: CC21005D 020039E0
	v_fma_mixhi_f16 v93, v225, s28, 0                          // 0000001A49F8: CC22005D 020039E1
	v_fma_mixlo_f16 v94, v226, s28, 0                          // 0000001A4A00: CC21005E 020039E2
	v_fma_mixhi_f16 v94, v227, s28, 0                          // 0000001A4A08: CC22005E 020039E3
	v_fma_mixlo_f16 v95, v97, s28, 0                           // 0000001A4A10: CC21005F 02003961
	v_fma_mixlo_f16 v97, v101, s28, 0                          // 0000001A4A18: CC210061 02003965
	v_fma_mixhi_f16 v97, v102, s28, 0                          // 0000001A4A20: CC220061 02003966
	v_fma_mixlo_f16 v101, v194, s28, 0                         // 0000001A4A28: CC210065 020039C2
	v_fma_mixhi_f16 v101, v195, s28, 0                         // 0000001A4A30: CC220065 020039C3
	v_fma_mixlo_f16 v102, v196, s28, 0                         // 0000001A4A38: CC210066 020039C4
	v_fma_mixhi_f16 v102, v197, s28, 0                         // 0000001A4A40: CC220066 020039C5
	s_waitcnt lgkmcnt(6)                                       // 0000001A4A48: BF89FC67
	v_fma_mixlo_f16 v194, v210, s28, 0                         // 0000001A4A4C: CC2100C2 020039D2
	v_fma_mixhi_f16 v194, v211, s28, 0                         // 0000001A4A54: CC2200C2 020039D3
	v_fma_mixlo_f16 v195, v212, s28, 0                         // 0000001A4A5C: CC2100C3 020039D4
	v_fma_mixhi_f16 v195, v213, s28, 0                         // 0000001A4A64: CC2200C3 020039D5
	s_waitcnt lgkmcnt(4)                                       // 0000001A4A6C: BF89FC47
	v_fma_mixlo_f16 v196, v214, s28, 0                         // 0000001A4A70: CC2100C4 020039D6
	v_fma_mixhi_f16 v196, v215, s28, 0                         // 0000001A4A78: CC2200C4 020039D7
	v_fma_mixlo_f16 v197, v216, s28, 0                         // 0000001A4A80: CC2100C5 020039D8
	v_fma_mixhi_f16 v197, v217, s28, 0                         // 0000001A4A88: CC2200C5 020039D9
	s_waitcnt lgkmcnt(3)                                       // 0000001A4A90: BF89FC37
	v_fma_mixlo_f16 v198, v198, s28, 0                         // 0000001A4A94: CC2100C6 020039C6
	v_fma_mixhi_f16 v198, v199, s28, 0                         // 0000001A4A9C: CC2200C6 020039C7
	v_fma_mixlo_f16 v199, v200, s28, 0                         // 0000001A4AA4: CC2100C7 020039C8
	v_fma_mixhi_f16 v199, v201, s28, 0                         // 0000001A4AAC: CC2200C7 020039C9
	s_waitcnt lgkmcnt(2)                                       // 0000001A4AB4: BF89FC27
	v_fma_mixlo_f16 v200, v218, s28, 0                         // 0000001A4AB8: CC2100C8 020039DA
	v_fma_mixhi_f16 v200, v219, s28, 0                         // 0000001A4AC0: CC2200C8 020039DB
	v_fma_mixlo_f16 v201, v220, s28, 0                         // 0000001A4AC8: CC2100C9 020039DC
	v_fma_mixhi_f16 v201, v221, s28, 0                         // 0000001A4AD0: CC2200C9 020039DD
	s_waitcnt lgkmcnt(1)                                       // 0000001A4AD8: BF89FC17
	v_fma_mixlo_f16 v202, v202, s28, 0                         // 0000001A4ADC: CC2100CA 020039CA
	v_fma_mixhi_f16 v202, v203, s28, 0                         // 0000001A4AE4: CC2200CA 020039CB
	v_fma_mixlo_f16 v203, v204, s28, 0                         // 0000001A4AEC: CC2100CB 020039CC
	v_fma_mixhi_f16 v203, v205, s28, 0                         // 0000001A4AF4: CC2200CB 020039CD
	s_waitcnt lgkmcnt(0)                                       // 0000001A4AFC: BF89FC07
	v_fma_mixlo_f16 v204, v206, s28, 0                         // 0000001A4B00: CC2100CC 020039CE
	v_fma_mixhi_f16 v204, v207, s28, 0                         // 0000001A4B08: CC2200CC 020039CF
	v_fma_mixlo_f16 v205, v208, s28, 0                         // 0000001A4B10: CC2100CD 020039D0
	v_fma_mixhi_f16 v205, v209, s28, 0                         // 0000001A4B18: CC2200CD 020039D1
	ds_load_b128 v[210:213], v134 offset:192                   // 0000001A4B20: DBFC00C0 D2000086
	ds_load_b128 v[214:217], v134 offset:208                   // 0000001A4B28: DBFC00D0 D6000086
	ds_load_b128 v[218:221], v134 offset:224                   // 0000001A4B30: DBFC00E0 DA000086
	s_waitcnt vmcnt(10)                                        // 0000001A4B38: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[81:88], v[89:96], v[25:32]// 0000001A4B3C: CC404019 1C66B351
	ds_load_b128 v[89:92], v134 offset:240                     // 0000001A4B44: DBFC00F0 59000086
	v_wmma_f32_16x16x16_f16 v[9:16], v[81:88], v[97:104], v[9:16]// 0000001A4B4C: CC404009 1C26C351
	v_wmma_f32_16x16x16_f16 v[17:24], v[81:88], v[190:197], v[17:24]// 0000001A4B54: CC404011 1C477D51
	v_wmma_f32_16x16x16_f16 v[1:8], v[81:88], v[198:205], v[1:8]// 0000001A4B5C: CC404001 1C078D51
	ds_load_b128 v[93:96], v134 offset:8640                    // 0000001A4B64: DBFC21C0 5D000086
	ds_load_b128 v[97:100], v134 offset:8656                   // 0000001A4B6C: DBFC21D0 61000086
	ds_load_b128 v[101:104], v134 offset:8672                  // 0000001A4B74: DBFC21E0 65000086
	ds_load_b128 v[190:193], v134 offset:8688                  // 0000001A4B7C: DBFC21F0 BE000086
	ds_load_b128 v[194:197], v134 offset:17088                 // 0000001A4B84: DBFC42C0 C2000086
	ds_load_b128 v[198:201], v134 offset:17104                 // 0000001A4B8C: DBFC42D0 C6000086
	ds_load_b128 v[202:205], v134 offset:17120                 // 0000001A4B94: DBFC42E0 CA000086
	ds_load_b128 v[206:209], v134 offset:17136                 // 0000001A4B9C: DBFC42F0 CE000086
	s_lshl_b64 s[56:57], s[56:57], 13                          // 0000001A4BA4: 84B88D38
	ds_load_b128 v[222:225], v134 offset:25616                 // 0000001A4BA8: DBFC6410 DE000086
	.long 0xd7006a7a                                           // 0000001A4BB0: D7006A7A
	v_cndmask_b32_e32 v0, v144, v56, vcc_lo                    // 0000001A4BB4: 02007190
	s_waitcnt lgkmcnt(12)                                      // 0000001A4BB8: BF89FCC7
	v_fma_mixlo_f16 v81, v210, s28, 0                          // 0000001A4BBC: CC210051 020039D2
	v_fma_mixhi_f16 v81, v211, s28, 0                          // 0000001A4BC4: CC220051 020039D3
	v_fma_mixlo_f16 v82, v212, s28, 0                          // 0000001A4BCC: CC210052 020039D4
	v_fma_mixhi_f16 v82, v213, s28, 0                          // 0000001A4BD4: CC220052 020039D5
	s_waitcnt lgkmcnt(9)                                       // 0000001A4BDC: BF89FC97
	v_fma_mixhi_f16 v87, v90, s28, 0                           // 0000001A4BE0: CC220057 0200395A
	v_fma_mixlo_f16 v88, v91, s28, 0                           // 0000001A4BE8: CC210058 0200395B
	v_fma_mixhi_f16 v88, v92, s28, 0                           // 0000001A4BF0: CC220058 0200395C
	ds_load_b128 v[210:213], v134 offset:25552                 // 0000001A4BF8: DBFC63D0 D2000086
	s_waitcnt lgkmcnt(9)                                       // 0000001A4C00: BF89FC97
	v_fma_mixlo_f16 v90, v95, s28, 0                           // 0000001A4C04: CC21005A 0200395F
	v_fma_mixhi_f16 v90, v96, s28, 0                           // 0000001A4C0C: CC22005A 02003960
	s_waitcnt lgkmcnt(8)                                       // 0000001A4C14: BF89FC87
	v_fma_mixlo_f16 v91, v97, s28, 0                           // 0000001A4C18: CC21005B 02003961
	v_fma_mixhi_f16 v91, v98, s28, 0                           // 0000001A4C20: CC22005B 02003962
	v_fma_mixlo_f16 v92, v99, s28, 0                           // 0000001A4C28: CC21005C 02003963
	v_fma_mixhi_f16 v92, v100, s28, 0                          // 0000001A4C30: CC22005C 02003964
	s_waitcnt lgkmcnt(6)                                       // 0000001A4C38: BF89FC67
	v_fma_mixlo_f16 v95, v190, s28, 0                          // 0000001A4C3C: CC21005F 020039BE
	v_fma_mixhi_f16 v95, v191, s28, 0                          // 0000001A4C44: CC22005F 020039BF
	v_fma_mixlo_f16 v96, v192, s28, 0                          // 0000001A4C4C: CC210060 020039C0
	v_fma_mixhi_f16 v96, v193, s28, 0                          // 0000001A4C54: CC220060 020039C1
	ds_load_b128 v[190:193], v134 offset:25536                 // 0000001A4C5C: DBFC63C0 BE000086
	s_waitcnt lgkmcnt(6)                                       // 0000001A4C64: BF89FC67
	v_fma_mixlo_f16 v97, v194, s28, 0                          // 0000001A4C68: CC210061 020039C2
	v_fma_mixhi_f16 v97, v195, s28, 0                          // 0000001A4C70: CC220061 020039C3
	v_fma_mixlo_f16 v98, v196, s28, 0                          // 0000001A4C78: CC210062 020039C4
	v_fma_mixhi_f16 v98, v197, s28, 0                          // 0000001A4C80: CC220062 020039C5
	s_waitcnt lgkmcnt(5)                                       // 0000001A4C88: BF89FC57
	v_fma_mixlo_f16 v99, v198, s28, 0                          // 0000001A4C8C: CC210063 020039C6
	v_fma_mixhi_f16 v99, v199, s28, 0                          // 0000001A4C94: CC220063 020039C7
	v_fma_mixlo_f16 v100, v200, s28, 0                         // 0000001A4C9C: CC210064 020039C8
	v_fma_mixhi_f16 v100, v201, s28, 0                         // 0000001A4CA4: CC220064 020039C9
	ds_load_b128 v[194:197], v134 offset:25568                 // 0000001A4CAC: DBFC63E0 C2000086
	ds_load_b128 v[198:201], v134 offset:25584                 // 0000001A4CB4: DBFC63F0 C6000086
	v_fma_mixlo_f16 v83, v214, s28, 0                          // 0000001A4CBC: CC210053 020039D6
	v_fma_mixhi_f16 v83, v215, s28, 0                          // 0000001A4CC4: CC220053 020039D7
	v_fma_mixlo_f16 v84, v216, s28, 0                          // 0000001A4CCC: CC210054 020039D8
	v_fma_mixhi_f16 v84, v217, s28, 0                          // 0000001A4CD4: CC220054 020039D9
	v_fma_mixlo_f16 v85, v218, s28, 0                          // 0000001A4CDC: CC210055 020039DA
	v_fma_mixhi_f16 v85, v219, s28, 0                          // 0000001A4CE4: CC220055 020039DB
	v_fma_mixlo_f16 v86, v220, s28, 0                          // 0000001A4CEC: CC210056 020039DC
	v_fma_mixhi_f16 v86, v221, s28, 0                          // 0000001A4CF4: CC220056 020039DD
	v_fma_mixlo_f16 v87, v89, s28, 0                           // 0000001A4CFC: CC210057 02003959
	v_fma_mixlo_f16 v89, v93, s28, 0                           // 0000001A4D04: CC210059 0200395D
	v_fma_mixhi_f16 v89, v94, s28, 0                           // 0000001A4D0C: CC220059 0200395E
	v_fma_mixlo_f16 v93, v101, s28, 0                          // 0000001A4D14: CC21005D 02003965
	v_fma_mixhi_f16 v93, v102, s28, 0                          // 0000001A4D1C: CC22005D 02003966
	v_fma_mixlo_f16 v94, v103, s28, 0                          // 0000001A4D24: CC21005E 02003967
	v_fma_mixhi_f16 v94, v104, s28, 0                          // 0000001A4D2C: CC22005E 02003968
	s_waitcnt lgkmcnt(6)                                       // 0000001A4D34: BF89FC67
	v_fma_mixlo_f16 v101, v202, s28, 0                         // 0000001A4D38: CC210065 020039CA
	v_fma_mixhi_f16 v101, v203, s28, 0                         // 0000001A4D40: CC220065 020039CB
	v_fma_mixlo_f16 v102, v204, s28, 0                         // 0000001A4D48: CC210066 020039CC
	v_fma_mixhi_f16 v102, v205, s28, 0                         // 0000001A4D50: CC220066 020039CD
	s_waitcnt lgkmcnt(5)                                       // 0000001A4D58: BF89FC57
	v_fma_mixlo_f16 v103, v206, s28, 0                         // 0000001A4D5C: CC210067 020039CE
	v_fma_mixhi_f16 v103, v207, s28, 0                         // 0000001A4D64: CC220067 020039CF
	v_fma_mixlo_f16 v104, v208, s28, 0                         // 0000001A4D6C: CC210068 020039D0
	v_fma_mixhi_f16 v104, v209, s28, 0                         // 0000001A4D74: CC220068 020039D1
	s_waitcnt vmcnt(8)                                         // 0000001A4D7C: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[73:80], v[81:88], v[25:32]// 0000001A4D80: CC404019 1C66A349
	ds_load_b128 v[81:84], v134 offset:8704                    // 0000001A4D88: DBFC2200 51000086
	ds_load_b128 v[85:88], v134 offset:8720                    // 0000001A4D90: DBFC2210 55000086
	s_waitcnt lgkmcnt(4)                                       // 0000001A4D98: BF89FC47
	v_fma_mixlo_f16 v190, v190, s28, 0                         // 0000001A4D9C: CC2100BE 020039BE
	v_wmma_f32_16x16x16_f16 v[17:24], v[73:80], v[97:104], v[17:24]// 0000001A4DA4: CC404011 1C46C349
	ds_load_b128 v[102:105], v134 offset:8736                  // 0000001A4DAC: DBFC2220 66000086
	v_fma_mixhi_f16 v190, v191, s28, 0                         // 0000001A4DB4: CC2200BE 020039BF
	v_fma_mixlo_f16 v191, v192, s28, 0                         // 0000001A4DBC: CC2100BF 020039C0
	v_fma_mixhi_f16 v191, v193, s28, 0                         // 0000001A4DC4: CC2200BF 020039C1
	v_fma_mixlo_f16 v192, v210, s28, 0                         // 0000001A4DCC: CC2100C0 020039D2
	v_fma_mixhi_f16 v192, v211, s28, 0                         // 0000001A4DD4: CC2200C0 020039D3
	v_fma_mixlo_f16 v193, v212, s28, 0                         // 0000001A4DDC: CC2100C1 020039D4
	v_fma_mixhi_f16 v193, v213, s28, 0                         // 0000001A4DE4: CC2200C1 020039D5
	s_waitcnt lgkmcnt(4)                                       // 0000001A4DEC: BF89FC47
	v_fma_mixlo_f16 v194, v194, s28, 0                         // 0000001A4DF0: CC2100C2 020039C2
	v_fma_mixhi_f16 v194, v195, s28, 0                         // 0000001A4DF8: CC2200C2 020039C3
	v_fma_mixlo_f16 v195, v196, s28, 0                         // 0000001A4E00: CC2100C3 020039C4
	v_fma_mixhi_f16 v195, v197, s28, 0                         // 0000001A4E08: CC2200C3 020039C5
	s_waitcnt lgkmcnt(3)                                       // 0000001A4E10: BF89FC37
	v_fma_mixlo_f16 v196, v198, s28, 0                         // 0000001A4E14: CC2100C4 020039C6
	v_fma_mixhi_f16 v196, v199, s28, 0                         // 0000001A4E1C: CC2200C4 020039C7
	v_fma_mixlo_f16 v197, v200, s28, 0                         // 0000001A4E24: CC2100C5 020039C8
	v_fma_mixhi_f16 v197, v201, s28, 0                         // 0000001A4E2C: CC2200C5 020039C9
	v_add_co_ci_u32_e64 v123, null, s57, v145, vcc_lo          // 0000001A4E34: D5207C7B 01AB2239
	v_wmma_f32_16x16x16_f16 v[9:16], v[73:80], v[89:96], v[9:16]// 0000001A4E3C: CC404009 1C26B349
	s_waitcnt lgkmcnt(2)                                       // 0000001A4E44: BF89FC27
	v_fma_mixlo_f16 v81, v81, s28, 0                           // 0000001A4E48: CC210051 02003951
	v_wmma_f32_16x16x16_f16 v[1:8], v[73:80], v[190:197], v[1:8]// 0000001A4E50: CC404001 1C077D49
	s_clause 0x1                                               // 0000001A4E58: BF850001
	global_load_b128 v[194:197], v[122:123], off offset:16     // 0000001A4E5C: DC5E0010 C27C007A
	global_load_b128 v[190:193], v[122:123], off               // 0000001A4E64: DC5E0000 BE7C007A
	v_fma_mixhi_f16 v81, v82, s28, 0                           // 0000001A4E6C: CC220051 02003952
	v_fma_mixlo_f16 v82, v83, s28, 0                           // 0000001A4E74: CC210052 02003953
	ds_load_b128 v[198:201], v134 offset:8752                  // 0000001A4E7C: DBFC2230 C6000086
	s_waitcnt lgkmcnt(2)                                       // 0000001A4E84: BF89FC27
	v_fma_mixlo_f16 v83, v85, s28, 0                           // 0000001A4E88: CC210053 02003955
	v_fma_mixhi_f16 v83, v86, s28, 0                           // 0000001A4E90: CC220053 02003956
	s_waitcnt lgkmcnt(1)                                       // 0000001A4E98: BF89FC17
	v_fma_mixlo_f16 v85, v102, s28, 0                          // 0000001A4E9C: CC210055 02003966
	v_fma_mixhi_f16 v85, v103, s28, 0                          // 0000001A4EA4: CC220055 02003967
	v_fma_mixlo_f16 v86, v104, s28, 0                          // 0000001A4EAC: CC210056 02003968
	s_clause 0x3                                               // 0000001A4EB4: BF850003
	global_load_b128 v[101:104], v[122:123], off offset:80     // 0000001A4EB8: DC5E0050 657C007A
	global_load_b128 v[97:100], v[122:123], off offset:64      // 0000001A4EC0: DC5E0040 617C007A
	global_load_b128 v[93:96], v[122:123], off offset:112      // 0000001A4EC8: DC5E0070 5D7C007A
	global_load_b128 v[89:92], v[122:123], off offset:96       // 0000001A4ED0: DC5E0060 597C007A
	ds_load_b128 v[202:205], v134 offset:256                   // 0000001A4ED8: DBFC0100 CA000086
	ds_load_b128 v[206:209], v134 offset:272                   // 0000001A4EE0: DBFC0110 CE000086
	ds_load_b128 v[210:213], v134 offset:288                   // 0000001A4EE8: DBFC0120 D2000086
	ds_load_b128 v[214:217], v134 offset:304                   // 0000001A4EF0: DBFC0130 D6000086
	ds_load_b128 v[218:221], v134 offset:25600                 // 0000001A4EF8: DBFC6400 DA000086
	ds_load_b128 v[226:229], v134 offset:25632                 // 0000001A4F00: DBFC6420 E2000086
	v_fma_mixhi_f16 v82, v84, s28, 0                           // 0000001A4F08: CC220052 02003954
	v_fma_mixlo_f16 v84, v87, s28, 0                           // 0000001A4F10: CC210054 02003957
	v_fma_mixhi_f16 v84, v88, s28, 0                           // 0000001A4F18: CC220054 02003958
	v_fma_mixhi_f16 v86, v105, s28, 0                          // 0000001A4F20: CC220056 02003969
	s_waitcnt lgkmcnt(6)                                       // 0000001A4F28: BF89FC67
	v_fma_mixlo_f16 v87, v198, s28, 0                          // 0000001A4F2C: CC210057 020039C6
	v_fma_mixhi_f16 v87, v199, s28, 0                          // 0000001A4F34: CC220057 020039C7
	v_fma_mixlo_f16 v88, v200, s28, 0                          // 0000001A4F3C: CC210058 020039C8
	v_fma_mixhi_f16 v88, v201, s28, 0                          // 0000001A4F44: CC220058 020039C9
	s_waitcnt lgkmcnt(5)                                       // 0000001A4F4C: BF89FC57
	v_fma_mixlo_f16 v73, v202, s28, 0                          // 0000001A4F50: CC210049 020039CA
	v_fma_mixhi_f16 v73, v203, s28, 0                          // 0000001A4F58: CC220049 020039CB
	v_fma_mixlo_f16 v74, v204, s28, 0                          // 0000001A4F60: CC21004A 020039CC
	v_fma_mixhi_f16 v74, v205, s28, 0                          // 0000001A4F68: CC22004A 020039CD
	s_waitcnt lgkmcnt(4)                                       // 0000001A4F70: BF89FC47
	v_fma_mixlo_f16 v75, v206, s28, 0                          // 0000001A4F74: CC21004B 020039CE
	v_fma_mixhi_f16 v75, v207, s28, 0                          // 0000001A4F7C: CC22004B 020039CF
	v_fma_mixlo_f16 v76, v208, s28, 0                          // 0000001A4F84: CC21004C 020039D0
	v_fma_mixhi_f16 v76, v209, s28, 0                          // 0000001A4F8C: CC22004C 020039D1
	s_waitcnt lgkmcnt(3)                                       // 0000001A4F94: BF89FC37
	v_fma_mixlo_f16 v77, v210, s28, 0                          // 0000001A4F98: CC21004D 020039D2
	v_fma_mixhi_f16 v77, v211, s28, 0                          // 0000001A4FA0: CC22004D 020039D3
	v_fma_mixlo_f16 v78, v212, s28, 0                          // 0000001A4FA8: CC21004E 020039D4
	v_fma_mixhi_f16 v78, v213, s28, 0                          // 0000001A4FB0: CC22004E 020039D5
	s_waitcnt lgkmcnt(2)                                       // 0000001A4FB8: BF89FC27
	v_fma_mixlo_f16 v79, v214, s28, 0                          // 0000001A4FBC: CC21004F 020039D6
	v_fma_mixhi_f16 v79, v215, s28, 0                          // 0000001A4FC4: CC22004F 020039D7
	v_fma_mixlo_f16 v80, v216, s28, 0                          // 0000001A4FCC: CC210050 020039D8
	v_fma_mixhi_f16 v80, v217, s28, 0                          // 0000001A4FD4: CC220050 020039D9
	ds_load_b128 v[202:205], v134 offset:17152                 // 0000001A4FDC: DBFC4300 CA000086
	ds_load_b128 v[206:209], v134 offset:17168                 // 0000001A4FE4: DBFC4310 CE000086
	ds_load_b128 v[210:213], v134 offset:17184                 // 0000001A4FEC: DBFC4320 D2000086
	ds_load_b128 v[214:217], v134 offset:17200                 // 0000001A4FF4: DBFC4330 D6000086
	s_waitcnt vmcnt(12)                                        // 0000001A4FFC: BF8933F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[57:64], v[73:80], v[25:32]// 0000001A5000: CC404019 1C669339
	ds_load_b128 v[73:76], v134 offset:368                     // 0000001A5008: DBFC0170 49000086
	v_wmma_f32_16x16x16_f16 v[9:16], v[57:64], v[81:88], v[9:16]// 0000001A5010: CC404009 1C26A339
	ds_load_b128 v[77:80], v134 offset:8768                    // 0000001A5018: DBFC2240 4D000086
	ds_load_b128 v[81:84], v134 offset:8784                    // 0000001A5020: DBFC2250 51000086
	ds_load_b128 v[85:88], v134 offset:8800                    // 0000001A5028: DBFC2260 55000086
	s_waitcnt lgkmcnt(7)                                       // 0000001A5030: BF89FC77
	v_fma_mixlo_f16 v198, v202, s28, 0                         // 0000001A5034: CC2100C6 020039CA
	v_fma_mixhi_f16 v198, v203, s28, 0                         // 0000001A503C: CC2200C6 020039CB
	v_fma_mixlo_f16 v199, v204, s28, 0                         // 0000001A5044: CC2100C7 020039CC
	v_fma_mixhi_f16 v199, v205, s28, 0                         // 0000001A504C: CC2200C7 020039CD
	s_waitcnt lgkmcnt(6)                                       // 0000001A5054: BF89FC67
	v_fma_mixlo_f16 v200, v206, s28, 0                         // 0000001A5058: CC2100C8 020039CE
	v_fma_mixhi_f16 v200, v207, s28, 0                         // 0000001A5060: CC2200C8 020039CF
	v_fma_mixlo_f16 v201, v208, s28, 0                         // 0000001A5068: CC2100C9 020039D0
	v_fma_mixhi_f16 v201, v209, s28, 0                         // 0000001A5070: CC2200C9 020039D1
	s_waitcnt lgkmcnt(5)                                       // 0000001A5078: BF89FC57
	v_fma_mixlo_f16 v202, v210, s28, 0                         // 0000001A507C: CC2100CA 020039D2
	v_fma_mixhi_f16 v202, v211, s28, 0                         // 0000001A5084: CC2200CA 020039D3
	v_fma_mixlo_f16 v203, v212, s28, 0                         // 0000001A508C: CC2100CB 020039D4
	v_fma_mixhi_f16 v203, v213, s28, 0                         // 0000001A5094: CC2200CB 020039D5
	s_waitcnt lgkmcnt(4)                                       // 0000001A509C: BF89FC47
	v_fma_mixlo_f16 v204, v214, s28, 0                         // 0000001A50A0: CC2100CC 020039D6
	v_fma_mixhi_f16 v204, v215, s28, 0                         // 0000001A50A8: CC2200CC 020039D7
	v_fma_mixlo_f16 v205, v216, s28, 0                         // 0000001A50B0: CC2100CD 020039D8
	v_fma_mixhi_f16 v205, v217, s28, 0                         // 0000001A50B8: CC2200CD 020039D9
	v_fma_mixlo_f16 v206, v218, s28, 0                         // 0000001A50C0: CC2100CE 020039DA
	v_fma_mixhi_f16 v206, v219, s28, 0                         // 0000001A50C8: CC2200CE 020039DB
	v_fma_mixlo_f16 v207, v220, s28, 0                         // 0000001A50D0: CC2100CF 020039DC
	v_fma_mixhi_f16 v207, v221, s28, 0                         // 0000001A50D8: CC2200CF 020039DD
	v_fma_mixlo_f16 v208, v222, s28, 0                         // 0000001A50E0: CC2100D0 020039DE
	v_fma_mixhi_f16 v208, v223, s28, 0                         // 0000001A50E8: CC2200D0 020039DF
	v_fma_mixlo_f16 v209, v224, s28, 0                         // 0000001A50F0: CC2100D1 020039E0
	v_fma_mixhi_f16 v209, v225, s28, 0                         // 0000001A50F8: CC2200D1 020039E1
	v_fma_mixlo_f16 v210, v226, s28, 0                         // 0000001A5100: CC2100D2 020039E2
	v_fma_mixhi_f16 v210, v227, s28, 0                         // 0000001A5108: CC2200D2 020039E3
	v_fma_mixlo_f16 v211, v228, s28, 0                         // 0000001A5110: CC2100D3 020039E4
	v_fma_mixhi_f16 v211, v229, s28, 0                         // 0000001A5118: CC2200D3 020039E5
	v_fma_mixlo_f16 v212, v230, s28, 0                         // 0000001A5120: CC2100D4 020039E6
	v_fma_mixhi_f16 v212, v231, s28, 0                         // 0000001A5128: CC2200D4 020039E7
	v_fma_mixlo_f16 v213, v232, s28, 0                         // 0000001A5130: CC2100D5 020039E8
	v_fma_mixhi_f16 v213, v233, s28, 0                         // 0000001A5138: CC2200D5 020039E9
	ds_load_b128 v[214:217], v134 offset:320                   // 0000001A5140: DBFC0140 D6000086
	ds_load_b128 v[218:221], v134 offset:336                   // 0000001A5148: DBFC0150 DA000086
	ds_load_b128 v[222:225], v134 offset:352                   // 0000001A5150: DBFC0160 DE000086
	v_wmma_f32_16x16x16_f16 v[17:24], v[57:64], v[198:205], v[17:24]// 0000001A5158: CC404011 1C478D39
	v_wmma_f32_16x16x16_f16 v[1:8], v[57:64], v[206:213], v[1:8]// 0000001A5160: CC404001 1C079D39
	ds_load_b128 v[198:201], v134 offset:8816                  // 0000001A5168: DBFC2270 C6000086
	ds_load_b128 v[202:205], v134 offset:17216                 // 0000001A5170: DBFC4340 CA000086
	ds_load_b128 v[206:209], v134 offset:17232                 // 0000001A5178: DBFC4350 CE000086
	s_waitcnt lgkmcnt(9)                                       // 0000001A5180: BF89FC97
	v_fma_mixhi_f16 v63, v74, s28, 0                           // 0000001A5184: CC22003F 0200394A
	v_fma_mixlo_f16 v64, v75, s28, 0                           // 0000001A518C: CC210040 0200394B
	v_fma_mixhi_f16 v64, v76, s28, 0                           // 0000001A5194: CC220040 0200394C
	s_waitcnt lgkmcnt(8)                                       // 0000001A519C: BF89FC87
	v_fma_mixlo_f16 v74, v79, s28, 0                           // 0000001A51A0: CC21004A 0200394F
	v_fma_mixhi_f16 v74, v80, s28, 0                           // 0000001A51A8: CC22004A 02003950
	s_waitcnt lgkmcnt(7)                                       // 0000001A51B0: BF89FC77
	v_fma_mixlo_f16 v75, v81, s28, 0                           // 0000001A51B4: CC21004B 02003951
	v_fma_mixhi_f16 v75, v82, s28, 0                           // 0000001A51BC: CC22004B 02003952
	v_fma_mixlo_f16 v76, v83, s28, 0                           // 0000001A51C4: CC21004C 02003953
	v_fma_mixhi_f16 v76, v84, s28, 0                           // 0000001A51CC: CC22004C 02003954
	ds_load_b128 v[210:213], v134 offset:17248                 // 0000001A51D4: DBFC4360 D2000086
	v_fma_mixlo_f16 v63, v73, s28, 0                           // 0000001A51DC: CC21003F 02003949
	v_fma_mixlo_f16 v73, v77, s28, 0                           // 0000001A51E4: CC210049 0200394D
	s_waitcnt lgkmcnt(6)                                       // 0000001A51EC: BF89FC67
	v_fma_mixlo_f16 v57, v214, s28, 0                          // 0000001A51F0: CC210039 020039D6
	v_fma_mixhi_f16 v57, v215, s28, 0                          // 0000001A51F8: CC220039 020039D7
	v_fma_mixlo_f16 v58, v216, s28, 0                          // 0000001A5200: CC21003A 020039D8
	v_fma_mixhi_f16 v58, v217, s28, 0                          // 0000001A5208: CC22003A 020039D9
	s_waitcnt lgkmcnt(5)                                       // 0000001A5210: BF89FC57
	v_fma_mixlo_f16 v59, v218, s28, 0                          // 0000001A5214: CC21003B 020039DA
	v_fma_mixhi_f16 v59, v219, s28, 0                          // 0000001A521C: CC22003B 020039DB
	v_fma_mixlo_f16 v60, v220, s28, 0                          // 0000001A5224: CC21003C 020039DC
	v_fma_mixhi_f16 v60, v221, s28, 0                          // 0000001A522C: CC22003C 020039DD
	s_waitcnt lgkmcnt(3)                                       // 0000001A5234: BF89FC37
	v_fma_mixlo_f16 v79, v198, s28, 0                          // 0000001A5238: CC21004F 020039C6
	ds_load_b128 v[214:217], v134 offset:17264                 // 0000001A5240: DBFC4370 D6000086
	v_fma_mixhi_f16 v79, v199, s28, 0                          // 0000001A5248: CC22004F 020039C7
	v_fma_mixlo_f16 v80, v200, s28, 0                          // 0000001A5250: CC210050 020039C8
	v_fma_mixhi_f16 v80, v201, s28, 0                          // 0000001A5258: CC220050 020039C9
	ds_load_b128 v[198:201], v134 offset:25664                 // 0000001A5260: DBFC6440 C6000086
	ds_load_b128 v[218:221], v134 offset:25680                 // 0000001A5268: DBFC6450 DA000086
	s_waitcnt lgkmcnt(5)                                       // 0000001A5270: BF89FC57
	v_fma_mixlo_f16 v81, v202, s28, 0                          // 0000001A5274: CC210051 020039CA
	v_fma_mixhi_f16 v81, v203, s28, 0                          // 0000001A527C: CC220051 020039CB
	v_fma_mixlo_f16 v82, v204, s28, 0                          // 0000001A5284: CC210052 020039CC
	v_fma_mixhi_f16 v82, v205, s28, 0                          // 0000001A528C: CC220052 020039CD
	s_waitcnt lgkmcnt(4)                                       // 0000001A5294: BF89FC47
	v_fma_mixlo_f16 v83, v206, s28, 0                          // 0000001A5298: CC210053 020039CE
	v_fma_mixhi_f16 v83, v207, s28, 0                          // 0000001A52A0: CC220053 020039CF
	v_fma_mixlo_f16 v84, v208, s28, 0                          // 0000001A52A8: CC210054 020039D0
	ds_load_b128 v[202:205], v134 offset:25696                 // 0000001A52B0: DBFC6460 CA000086
	v_fma_mixhi_f16 v84, v209, s28, 0                          // 0000001A52B8: CC220054 020039D1
	ds_load_b128 v[206:209], v134 offset:25712                 // 0000001A52C0: DBFC6470 CE000086
	v_fma_mixlo_f16 v61, v222, s28, 0                          // 0000001A52C8: CC21003D 020039DE
	v_fma_mixhi_f16 v61, v223, s28, 0                          // 0000001A52D0: CC22003D 020039DF
	v_fma_mixlo_f16 v62, v224, s28, 0                          // 0000001A52D8: CC21003E 020039E0
	v_fma_mixhi_f16 v62, v225, s28, 0                          // 0000001A52E0: CC22003E 020039E1
	v_fma_mixhi_f16 v73, v78, s28, 0                           // 0000001A52E8: CC220049 0200394E
	v_fma_mixlo_f16 v77, v85, s28, 0                           // 0000001A52F0: CC21004D 02003955
	v_fma_mixhi_f16 v77, v86, s28, 0                           // 0000001A52F8: CC22004D 02003956
	v_fma_mixlo_f16 v78, v87, s28, 0                           // 0000001A5300: CC21004E 02003957
	v_fma_mixhi_f16 v78, v88, s28, 0                           // 0000001A5308: CC22004E 02003958
	s_waitcnt lgkmcnt(5)                                       // 0000001A5310: BF89FC57
	v_fma_mixlo_f16 v85, v210, s28, 0                          // 0000001A5314: CC210055 020039D2
	v_fma_mixhi_f16 v85, v211, s28, 0                          // 0000001A531C: CC220055 020039D3
	v_fma_mixlo_f16 v86, v212, s28, 0                          // 0000001A5324: CC210056 020039D4
	v_fma_mixhi_f16 v86, v213, s28, 0                          // 0000001A532C: CC220056 020039D5
	s_waitcnt lgkmcnt(4)                                       // 0000001A5334: BF89FC47
	v_fma_mixlo_f16 v87, v214, s28, 0                          // 0000001A5338: CC210057 020039D6
	v_fma_mixhi_f16 v87, v215, s28, 0                          // 0000001A5340: CC220057 020039D7
	v_fma_mixlo_f16 v88, v216, s28, 0                          // 0000001A5348: CC210058 020039D8
	v_fma_mixhi_f16 v88, v217, s28, 0                          // 0000001A5350: CC220058 020039D9
	s_waitcnt lgkmcnt(3)                                       // 0000001A5358: BF89FC37
	v_fma_mixlo_f16 v198, v198, s28, 0                         // 0000001A535C: CC2100C6 020039C6
	v_fma_mixhi_f16 v198, v199, s28, 0                         // 0000001A5364: CC2200C6 020039C7
	v_fma_mixlo_f16 v199, v200, s28, 0                         // 0000001A536C: CC2100C7 020039C8
	v_fma_mixhi_f16 v199, v201, s28, 0                         // 0000001A5374: CC2200C7 020039C9
	s_waitcnt lgkmcnt(2)                                       // 0000001A537C: BF89FC27
	v_fma_mixlo_f16 v200, v218, s28, 0                         // 0000001A5380: CC2100C8 020039DA
	v_fma_mixhi_f16 v200, v219, s28, 0                         // 0000001A5388: CC2200C8 020039DB
	v_fma_mixlo_f16 v201, v220, s28, 0                         // 0000001A5390: CC2100C9 020039DC
	v_fma_mixhi_f16 v201, v221, s28, 0                         // 0000001A5398: CC2200C9 020039DD
	s_waitcnt lgkmcnt(1)                                       // 0000001A53A0: BF89FC17
	v_fma_mixlo_f16 v202, v202, s28, 0                         // 0000001A53A4: CC2100CA 020039CA
	v_fma_mixhi_f16 v202, v203, s28, 0                         // 0000001A53AC: CC2200CA 020039CB
	v_fma_mixlo_f16 v203, v204, s28, 0                         // 0000001A53B4: CC2100CB 020039CC
	v_fma_mixhi_f16 v203, v205, s28, 0                         // 0000001A53BC: CC2200CB 020039CD
	s_waitcnt lgkmcnt(0)                                       // 0000001A53C4: BF89FC07
	v_fma_mixlo_f16 v204, v206, s28, 0                         // 0000001A53C8: CC2100CC 020039CE
	v_fma_mixhi_f16 v204, v207, s28, 0                         // 0000001A53D0: CC2200CC 020039CF
	v_fma_mixlo_f16 v205, v208, s28, 0                         // 0000001A53D8: CC2100CD 020039D0
	v_fma_mixhi_f16 v205, v209, s28, 0                         // 0000001A53E0: CC2200CD 020039D1
	ds_load_b128 v[210:213], v134 offset:384                   // 0000001A53E8: DBFC0180 D2000086
	ds_load_b128 v[214:217], v134 offset:400                   // 0000001A53F0: DBFC0190 D6000086
	ds_load_b128 v[218:221], v134 offset:416                   // 0000001A53F8: DBFC01A0 DA000086
	s_waitcnt vmcnt(10)                                        // 0000001A5400: BF892BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[49:56], v[57:64], v[25:32]// 0000001A5404: CC404019 1C667331
	ds_load_b128 v[57:60], v134 offset:432                     // 0000001A540C: DBFC01B0 39000086
	v_wmma_f32_16x16x16_f16 v[9:16], v[49:56], v[73:80], v[9:16]// 0000001A5414: CC404009 1C269331
	v_wmma_f32_16x16x16_f16 v[17:24], v[49:56], v[81:88], v[17:24]// 0000001A541C: CC404011 1C46A331
	v_wmma_f32_16x16x16_f16 v[1:8], v[49:56], v[198:205], v[1:8]// 0000001A5424: CC404001 1C078D31
	ds_load_b128 v[61:64], v134 offset:8832                    // 0000001A542C: DBFC2280 3D000086
	ds_load_b128 v[73:76], v134 offset:8848                    // 0000001A5434: DBFC2290 49000086
	ds_load_b128 v[77:80], v134 offset:8864                    // 0000001A543C: DBFC22A0 4D000086
	ds_load_b128 v[81:84], v134 offset:8880                    // 0000001A5444: DBFC22B0 51000086
	ds_load_b128 v[85:88], v134 offset:17280                   // 0000001A544C: DBFC4380 55000086
	ds_load_b128 v[198:201], v134 offset:17296                 // 0000001A5454: DBFC4390 C6000086
	ds_load_b128 v[202:205], v134 offset:17312                 // 0000001A545C: DBFC43A0 CA000086
	ds_load_b128 v[206:209], v134 offset:17328                 // 0000001A5464: DBFC43B0 CE000086
	ds_load_b128 v[225:228], v134 offset:25840                 // 0000001A546C: DBFC64F0 E1000086
	s_waitcnt lgkmcnt(12)                                      // 0000001A5474: BF89FCC7
	v_fma_mixlo_f16 v49, v210, s28, 0                          // 0000001A5478: CC210031 020039D2
	v_fma_mixhi_f16 v49, v211, s28, 0                          // 0000001A5480: CC220031 020039D3
	v_fma_mixlo_f16 v50, v212, s28, 0                          // 0000001A5488: CC210032 020039D4
	v_fma_mixhi_f16 v50, v213, s28, 0                          // 0000001A5490: CC220032 020039D5
	s_waitcnt lgkmcnt(9)                                       // 0000001A5498: BF89FC97
	v_fma_mixhi_f16 v55, v58, s28, 0                           // 0000001A549C: CC220037 0200393A
	v_fma_mixlo_f16 v56, v59, s28, 0                           // 0000001A54A4: CC210038 0200393B
	v_fma_mixhi_f16 v56, v60, s28, 0                           // 0000001A54AC: CC220038 0200393C
	ds_load_b128 v[210:213], v134 offset:25744                 // 0000001A54B4: DBFC6490 D2000086
	s_waitcnt lgkmcnt(9)                                       // 0000001A54BC: BF89FC97
	v_fma_mixlo_f16 v58, v63, s28, 0                           // 0000001A54C0: CC21003A 0200393F
	v_fma_mixhi_f16 v58, v64, s28, 0                           // 0000001A54C8: CC22003A 02003940
	s_waitcnt lgkmcnt(8)                                       // 0000001A54D0: BF89FC87
	v_fma_mixlo_f16 v59, v73, s28, 0                           // 0000001A54D4: CC21003B 02003949
	v_fma_mixhi_f16 v59, v74, s28, 0                           // 0000001A54DC: CC22003B 0200394A
	v_fma_mixlo_f16 v60, v75, s28, 0                           // 0000001A54E4: CC21003C 0200394B
	v_fma_mixhi_f16 v60, v76, s28, 0                           // 0000001A54EC: CC22003C 0200394C
	s_waitcnt lgkmcnt(6)                                       // 0000001A54F4: BF89FC67
	v_fma_mixlo_f16 v63, v81, s28, 0                           // 0000001A54F8: CC21003F 02003951
	v_fma_mixhi_f16 v63, v82, s28, 0                           // 0000001A5500: CC22003F 02003952
	v_fma_mixlo_f16 v64, v83, s28, 0                           // 0000001A5508: CC210040 02003953
	v_fma_mixhi_f16 v64, v84, s28, 0                           // 0000001A5510: CC220040 02003954
	ds_load_b128 v[81:84], v134 offset:25728                   // 0000001A5518: DBFC6480 51000086
	s_waitcnt lgkmcnt(6)                                       // 0000001A5520: BF89FC67
	v_fma_mixlo_f16 v73, v85, s28, 0                           // 0000001A5524: CC210049 02003955
	v_fma_mixhi_f16 v73, v86, s28, 0                           // 0000001A552C: CC220049 02003956
	v_fma_mixlo_f16 v74, v87, s28, 0                           // 0000001A5534: CC21004A 02003957
	v_fma_mixhi_f16 v74, v88, s28, 0                           // 0000001A553C: CC22004A 02003958
	s_waitcnt lgkmcnt(5)                                       // 0000001A5544: BF89FC57
	v_fma_mixlo_f16 v75, v198, s28, 0                          // 0000001A5548: CC21004B 020039C6
	v_fma_mixhi_f16 v75, v199, s28, 0                          // 0000001A5550: CC22004B 020039C7
	v_fma_mixlo_f16 v76, v200, s28, 0                          // 0000001A5558: CC21004C 020039C8
	ds_load_b128 v[85:88], v134 offset:25760                   // 0000001A5560: DBFC64A0 55000086
	v_fma_mixhi_f16 v76, v201, s28, 0                          // 0000001A5568: CC22004C 020039C9
	ds_load_b128 v[198:201], v134 offset:25776                 // 0000001A5570: DBFC64B0 C6000086
	v_fma_mixlo_f16 v55, v57, s28, 0                           // 0000001A5578: CC210037 02003939
	v_fma_mixlo_f16 v57, v61, s28, 0                           // 0000001A5580: CC210039 0200393D
	v_fma_mixlo_f16 v61, v77, s28, 0                           // 0000001A5588: CC21003D 0200394D
	v_fma_mixhi_f16 v61, v78, s28, 0                           // 0000001A5590: CC22003D 0200394E
	s_waitcnt lgkmcnt(6)                                       // 0000001A5598: BF89FC67
	v_fma_mixlo_f16 v77, v202, s28, 0                          // 0000001A559C: CC21004D 020039CA
	v_fma_mixhi_f16 v77, v203, s28, 0                          // 0000001A55A4: CC22004D 020039CB
	v_fma_mixlo_f16 v78, v204, s28, 0                          // 0000001A55AC: CC21004E 020039CC
	v_fma_mixhi_f16 v78, v205, s28, 0                          // 0000001A55B4: CC22004E 020039CD
	ds_load_b128 v[202:205], v134 offset:448                   // 0000001A55BC: DBFC01C0 CA000086
	s_waitcnt lgkmcnt(3)                                       // 0000001A55C4: BF89FC37
	v_fma_mixlo_f16 v81, v81, s28, 0                           // 0000001A55C8: CC210051 02003951
	v_fma_mixhi_f16 v81, v82, s28, 0                           // 0000001A55D0: CC220051 02003952
	v_fma_mixlo_f16 v82, v83, s28, 0                           // 0000001A55D8: CC210052 02003953
	v_fma_mixhi_f16 v82, v84, s28, 0                           // 0000001A55E0: CC220052 02003954
	v_fma_mixlo_f16 v83, v210, s28, 0                          // 0000001A55E8: CC210053 020039D2
	v_fma_mixhi_f16 v83, v211, s28, 0                          // 0000001A55F0: CC220053 020039D3
	v_fma_mixlo_f16 v84, v212, s28, 0                          // 0000001A55F8: CC210054 020039D4
	v_fma_mixhi_f16 v84, v213, s28, 0                          // 0000001A5600: CC220054 020039D5
	s_waitcnt lgkmcnt(2)                                       // 0000001A5608: BF89FC27
	v_fma_mixlo_f16 v85, v85, s28, 0                           // 0000001A560C: CC210055 02003955
	v_fma_mixhi_f16 v85, v86, s28, 0                           // 0000001A5614: CC220055 02003956
	v_fma_mixlo_f16 v86, v87, s28, 0                           // 0000001A561C: CC210056 02003957
	v_fma_mixhi_f16 v86, v88, s28, 0                           // 0000001A5624: CC220056 02003958
	s_waitcnt lgkmcnt(1)                                       // 0000001A562C: BF89FC17
	v_fma_mixlo_f16 v87, v198, s28, 0                          // 0000001A5630: CC210057 020039C6
	ds_load_b128 v[210:213], v134 offset:480                   // 0000001A5638: DBFC01E0 D2000086
	v_fma_mixhi_f16 v87, v199, s28, 0                          // 0000001A5640: CC220057 020039C7
	v_fma_mixlo_f16 v88, v200, s28, 0                          // 0000001A5648: CC210058 020039C8
	v_fma_mixhi_f16 v88, v201, s28, 0                          // 0000001A5650: CC220058 020039C9
	ds_load_b128 v[198:201], v134 offset:496                   // 0000001A5658: DBFC01F0 C6000086
	v_fma_mixlo_f16 v51, v214, s28, 0                          // 0000001A5660: CC210033 020039D6
	v_fma_mixhi_f16 v51, v215, s28, 0                          // 0000001A5668: CC220033 020039D7
	v_fma_mixlo_f16 v52, v216, s28, 0                          // 0000001A5670: CC210034 020039D8
	v_fma_mixhi_f16 v52, v217, s28, 0                          // 0000001A5678: CC220034 020039D9
	v_fma_mixlo_f16 v53, v218, s28, 0                          // 0000001A5680: CC210035 020039DA
	v_fma_mixhi_f16 v53, v219, s28, 0                          // 0000001A5688: CC220035 020039DB
	v_fma_mixlo_f16 v54, v220, s28, 0                          // 0000001A5690: CC210036 020039DC
	v_fma_mixhi_f16 v54, v221, s28, 0                          // 0000001A5698: CC220036 020039DD
	v_fma_mixhi_f16 v57, v62, s28, 0                           // 0000001A56A0: CC220039 0200393E
	v_fma_mixlo_f16 v62, v79, s28, 0                           // 0000001A56A8: CC21003E 0200394F
	v_fma_mixhi_f16 v62, v80, s28, 0                           // 0000001A56B0: CC22003E 02003950
	v_fma_mixlo_f16 v79, v206, s28, 0                          // 0000001A56B8: CC21004F 020039CE
	v_fma_mixhi_f16 v79, v207, s28, 0                          // 0000001A56C0: CC22004F 020039CF
	v_fma_mixlo_f16 v80, v208, s28, 0                          // 0000001A56C8: CC210050 020039D0
	v_fma_mixhi_f16 v80, v209, s28, 0                          // 0000001A56D0: CC220050 020039D1
	ds_load_b128 v[206:209], v134 offset:464                   // 0000001A56D8: DBFC01D0 CE000086
	s_waitcnt vmcnt(8)                                         // 0000001A56E0: BF8923F7
	v_wmma_f32_16x16x16_f16 v[25:32], v[41:48], v[49:56], v[25:32]// 0000001A56E4: CC404019 1C666329
	v_wmma_f32_16x16x16_f16 v[9:16], v[41:48], v[57:64], v[9:16]// 0000001A56EC: CC404009 1C267329
	v_wmma_f32_16x16x16_f16 v[1:8], v[41:48], v[81:88], v[1:8] // 0000001A56F4: CC404001 1C06A329
	v_wmma_f32_16x16x16_f16 v[17:24], v[41:48], v[73:80], v[17:24]// 0000001A56FC: CC404011 1C469329
	ds_load_b128 v[49:52], v134 offset:8896                    // 0000001A5704: DBFC22C0 31000086
	ds_load_b128 v[53:56], v134 offset:8912                    // 0000001A570C: DBFC22D0 35000086
	s_waitcnt lgkmcnt(5)                                       // 0000001A5714: BF89FC57
	v_fma_mixlo_f16 v41, v202, s28, 0                          // 0000001A5718: CC210029 020039CA
	v_fma_mixhi_f16 v41, v203, s28, 0                          // 0000001A5720: CC220029 020039CB
	v_fma_mixlo_f16 v42, v204, s28, 0                          // 0000001A5728: CC21002A 020039CC
	v_fma_mixhi_f16 v42, v205, s28, 0                          // 0000001A5730: CC22002A 020039CD
	ds_load_b128 v[57:60], v134 offset:8928                    // 0000001A5738: DBFC22E0 39000086
	ds_load_b128 v[61:64], v134 offset:8944                    // 0000001A5740: DBFC22F0 3D000086
	s_waitcnt lgkmcnt(5)                                       // 0000001A5748: BF89FC57
	v_fma_mixlo_f16 v47, v198, s28, 0                          // 0000001A574C: CC21002F 020039C6
	v_fma_mixhi_f16 v47, v199, s28, 0                          // 0000001A5754: CC22002F 020039C7
	v_fma_mixlo_f16 v48, v200, s28, 0                          // 0000001A575C: CC210030 020039C8
	v_fma_mixhi_f16 v48, v201, s28, 0                          // 0000001A5764: CC220030 020039C9
	ds_load_b128 v[73:76], v134 offset:17344                   // 0000001A576C: DBFC43C0 49000086
	ds_load_b128 v[77:80], v134 offset:17360                   // 0000001A5774: DBFC43D0 4D000086
	ds_load_b128 v[81:84], v134 offset:17376                   // 0000001A577C: DBFC43E0 51000086
	ds_load_b128 v[85:88], v134 offset:17392                   // 0000001A5784: DBFC43F0 55000086
	ds_load_b128 v[198:201], v134 offset:25792                 // 0000001A578C: DBFC64C0 C6000086
	ds_load_b128 v[202:205], v134 offset:25808                 // 0000001A5794: DBFC64D0 CA000086
	ds_load_b128 v[221:224], v134 offset:25824                 // 0000001A579C: DBFC64E0 DD000086
	s_waitcnt lgkmcnt(11)                                      // 0000001A57A4: BF89FCB7
	v_fma_mixlo_f16 v43, v206, s28, 0                          // 0000001A57A8: CC21002B 020039CE
	v_fma_mixhi_f16 v43, v207, s28, 0                          // 0000001A57B0: CC22002B 020039CF
	v_fma_mixlo_f16 v44, v208, s28, 0                          // 0000001A57B8: CC21002C 020039D0
	v_fma_mixhi_f16 v44, v209, s28, 0                          // 0000001A57C0: CC22002C 020039D1
	v_fma_mixlo_f16 v45, v210, s28, 0                          // 0000001A57C8: CC21002D 020039D2
	v_fma_mixhi_f16 v45, v211, s28, 0                          // 0000001A57D0: CC22002D 020039D3
	v_fma_mixlo_f16 v46, v212, s28, 0                          // 0000001A57D8: CC21002E 020039D4
	v_fma_mixhi_f16 v46, v213, s28, 0                          // 0000001A57E0: CC22002E 020039D5
	s_waitcnt lgkmcnt(10)                                      // 0000001A57E8: BF89FCA7
	v_fma_mixlo_f16 v49, v49, s28, 0                           // 0000001A57EC: CC210031 02003931
	v_fma_mixhi_f16 v49, v50, s28, 0                           // 0000001A57F4: CC220031 02003932
	v_fma_mixlo_f16 v50, v51, s28, 0                           // 0000001A57FC: CC210032 02003933
	v_fma_mixhi_f16 v50, v52, s28, 0                           // 0000001A5804: CC220032 02003934
	s_waitcnt lgkmcnt(9)                                       // 0000001A580C: BF89FC97
	v_fma_mixlo_f16 v51, v53, s28, 0                           // 0000001A5810: CC210033 02003935
	v_fma_mixhi_f16 v51, v54, s28, 0                           // 0000001A5818: CC220033 02003936
	v_fma_mixlo_f16 v52, v55, s28, 0                           // 0000001A5820: CC210034 02003937
	v_fma_mixhi_f16 v52, v56, s28, 0                           // 0000001A5828: CC220034 02003938
	s_waitcnt lgkmcnt(8)                                       // 0000001A5830: BF89FC87
	v_fma_mixlo_f16 v53, v57, s28, 0                           // 0000001A5834: CC210035 02003939
	v_fma_mixhi_f16 v53, v58, s28, 0                           // 0000001A583C: CC220035 0200393A
	v_fma_mixlo_f16 v54, v59, s28, 0                           // 0000001A5844: CC210036 0200393B
	s_waitcnt lgkmcnt(7)                                       // 0000001A584C: BF89FC77
	v_fma_mixlo_f16 v55, v61, s28, 0                           // 0000001A5850: CC210037 0200393D
	v_fma_mixhi_f16 v55, v62, s28, 0                           // 0000001A5858: CC220037 0200393E
	v_fma_mixlo_f16 v56, v63, s28, 0                           // 0000001A5860: CC210038 0200393F
	v_fma_mixhi_f16 v56, v64, s28, 0                           // 0000001A5868: CC220038 02003940
	s_waitcnt lgkmcnt(6)                                       // 0000001A5870: BF89FC67
	v_fma_mixlo_f16 v57, v73, s28, 0                           // 0000001A5874: CC210039 02003949
	v_fma_mixhi_f16 v57, v74, s28, 0                           // 0000001A587C: CC220039 0200394A
	v_fma_mixlo_f16 v58, v75, s28, 0                           // 0000001A5884: CC21003A 0200394B
	v_fma_mixhi_f16 v58, v76, s28, 0                           // 0000001A588C: CC22003A 0200394C
	s_waitcnt lgkmcnt(5)                                       // 0000001A5894: BF89FC57
	v_fma_mixlo_f16 v59, v77, s28, 0                           // 0000001A5898: CC21003B 0200394D
	s_waitcnt lgkmcnt(4)                                       // 0000001A58A0: BF89FC47
	v_fma_mixlo_f16 v61, v81, s28, 0                           // 0000001A58A4: CC21003D 02003951
	v_fma_mixhi_f16 v61, v82, s28, 0                           // 0000001A58AC: CC22003D 02003952
	v_fma_mixlo_f16 v62, v83, s28, 0                           // 0000001A58B4: CC21003E 02003953
	v_fma_mixhi_f16 v62, v84, s28, 0                           // 0000001A58BC: CC22003E 02003954
	s_waitcnt lgkmcnt(3)                                       // 0000001A58C4: BF89FC37
	v_fma_mixlo_f16 v63, v85, s28, 0                           // 0000001A58C8: CC21003F 02003955
	v_fma_mixhi_f16 v63, v86, s28, 0                           // 0000001A58D0: CC22003F 02003956
	v_fma_mixlo_f16 v64, v87, s28, 0                           // 0000001A58D8: CC210040 02003957
	v_fma_mixhi_f16 v64, v88, s28, 0                           // 0000001A58E0: CC220040 02003958
	s_waitcnt lgkmcnt(2)                                       // 0000001A58E8: BF89FC27
	v_fma_mixlo_f16 v73, v198, s28, 0                          // 0000001A58EC: CC210049 020039C6
	v_fma_mixhi_f16 v73, v199, s28, 0                          // 0000001A58F4: CC220049 020039C7
	v_fma_mixlo_f16 v74, v200, s28, 0                          // 0000001A58FC: CC21004A 020039C8
	v_fma_mixhi_f16 v74, v201, s28, 0                          // 0000001A5904: CC22004A 020039C9
	s_waitcnt lgkmcnt(1)                                       // 0000001A590C: BF89FC17
	v_fma_mixlo_f16 v75, v202, s28, 0                          // 0000001A5910: CC21004B 020039CA
	v_fma_mixhi_f16 v75, v203, s28, 0                          // 0000001A5918: CC22004B 020039CB
	v_fma_mixlo_f16 v76, v204, s28, 0                          // 0000001A5920: CC21004C 020039CC
	v_fma_mixhi_f16 v76, v205, s28, 0                          // 0000001A5928: CC22004C 020039CD
	s_waitcnt lgkmcnt(0)                                       // 0000001A5930: BF89FC07
	v_fma_mixlo_f16 v77, v221, s28, 0                          // 0000001A5934: CC21004D 020039DD
	ds_load_b128 v[81:84], v136                                // 0000001A593C: DBFC0000 51000088
	ds_load_b128 v[85:88], v136 offset:16                      // 0000001A5944: DBFC0010 55000088
	ds_load_b128 v[202:205], v136 offset:2320                  // 0000001A594C: DBFC0910 CA000088
	ds_load_b128 v[198:201], v136 offset:2304                  // 0000001A5954: DBFC0900 C6000088
	ds_load_b128 v[210:213], v136 offset:4624                  // 0000001A595C: DBFC1210 D2000088
	ds_load_b128 v[206:209], v136 offset:4608                  // 0000001A5964: DBFC1200 CE000088
	ds_load_b128 v[218:221], v136 offset:6928                  // 0000001A596C: DBFC1B10 DA000088
	ds_load_b128 v[214:217], v136 offset:6912                  // 0000001A5974: DBFC1B00 D6000088
	v_fma_mixhi_f16 v54, v60, s28, 0                           // 0000001A597C: CC220036 0200393C
	v_fma_mixhi_f16 v59, v78, s28, 0                           // 0000001A5984: CC22003B 0200394E
	v_fma_mixlo_f16 v60, v79, s28, 0                           // 0000001A598C: CC21003C 0200394F
	v_fma_mixhi_f16 v60, v80, s28, 0                           // 0000001A5994: CC22003C 02003950
	v_fma_mixhi_f16 v77, v222, s28, 0                          // 0000001A599C: CC22004D 020039DE
	v_fma_mixlo_f16 v78, v223, s28, 0                          // 0000001A59A4: CC21004E 020039DF
	v_fma_mixhi_f16 v78, v224, s28, 0                          // 0000001A59AC: CC22004E 020039E0
	v_fma_mixlo_f16 v79, v225, s28, 0                          // 0000001A59B4: CC21004F 020039E1
	v_fma_mixhi_f16 v79, v226, s28, 0                          // 0000001A59BC: CC22004F 020039E2
	v_fma_mixlo_f16 v80, v227, s28, 0                          // 0000001A59C4: CC210050 020039E3
	v_fma_mixhi_f16 v80, v228, s28, 0                          // 0000001A59CC: CC220050 020039E4
	s_waitcnt vmcnt(6)                                         // 0000001A59D4: BF891BF7
	v_wmma_f32_16x16x16_f16 v[25:32], v[33:40], v[41:48], v[25:32]// 0000001A59D8: CC404019 1C665321
	v_wmma_f32_16x16x16_f16 v[9:16], v[33:40], v[49:56], v[9:16]// 0000001A59E0: CC404009 1C266321
	v_wmma_f32_16x16x16_f16 v[17:24], v[33:40], v[57:64], v[17:24]// 0000001A59E8: CC404011 1C467321
	s_waitcnt vmcnt(4) lgkmcnt(6)                              // 0000001A59F0: BF891067
	v_wmma_f32_16x16x16_f16 v[57:64], v[190:197], v[81:88], v[65:72]// 0000001A59F4: CC404039 1D06A3BE
	v_wmma_f32_16x16x16_f16 v[1:8], v[33:40], v[73:80], v[1:8] // 0000001A59FC: CC404001 1C069321
	s_waitcnt lgkmcnt(4)                                       // 0000001A5A04: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[190:197], v[198:205], v[65:72]// 0000001A5A08: CC404031 1D078DBE
	s_waitcnt lgkmcnt(2)                                       // 0000001A5A10: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[190:197], v[206:213], v[65:72]// 0000001A5A14: CC404029 1D079DBE
	s_waitcnt lgkmcnt(0)                                       // 0000001A5A1C: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[190:197], v[214:221], v[65:72]// 0000001A5A20: CC404021 1D07ADBE
	s_and_saveexec_b32 s15, s7                                 // 0000001A5A28: BE8F2007
	s_cbranch_execnz 1198                                      // 0000001A5A2C: BFA604AE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x72e8>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A5A30: 8C7E0F7E
	s_and_saveexec_b32 s15, s5                                 // 0000001A5A34: BE8F2005
	s_cbranch_execnz 1231                                      // 0000001A5A38: BFA604CF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7378>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A5A3C: 8C7E0F7E
	s_and_saveexec_b32 s15, s8                                 // 0000001A5A40: BE8F2008
	s_cbranch_execz 30                                         // 0000001A5A44: BFA5001E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x60c0>
	ds_load_b128 v[65:68], v136 offset:96                      // 0000001A5A48: DBFC0060 41000088
	ds_load_b128 v[69:72], v136 offset:112                     // 0000001A5A50: DBFC0070 45000088
	ds_load_b128 v[77:80], v136 offset:2416                    // 0000001A5A58: DBFC0970 4D000088
	ds_load_b128 v[73:76], v136 offset:2400                    // 0000001A5A60: DBFC0960 49000088
	ds_load_b128 v[85:88], v136 offset:4720                    // 0000001A5A68: DBFC1270 55000088
	ds_load_b128 v[81:84], v136 offset:4704                    // 0000001A5A70: DBFC1260 51000088
	s_waitcnt vmcnt(3)                                         // 0000001A5A78: BF890FF7
	ds_load_b128 v[101:104], v136 offset:7024                  // 0000001A5A7C: DBFC1B70 65000088
	s_waitcnt vmcnt(2)                                         // 0000001A5A84: BF890BF7
	ds_load_b128 v[97:100], v136 offset:7008                   // 0000001A5A88: DBFC1B60 61000088
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001A5A90: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[89:96], v[65:72], v[57:64]// 0000001A5A94: CC404039 1CE68359
	s_waitcnt lgkmcnt(4)                                       // 0000001A5A9C: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[89:96], v[73:80], v[49:56]// 0000001A5AA0: CC404031 1CC69359
	s_waitcnt lgkmcnt(2)                                       // 0000001A5AA8: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[89:96], v[81:88], v[41:48]// 0000001A5AAC: CC404029 1CA6A359
	s_waitcnt lgkmcnt(0)                                       // 0000001A5AB4: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[89:96], v[97:104], v[33:40]// 0000001A5AB8: CC404021 1C86C359
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A5AC0: 8C7E0F7E
	s_add_i32 s41, s41, 64                                     // 0000001A5AC4: 8129C029
	s_mov_b32 s15, -1                                          // 0000001A5AC8: BE8F00C1
	s_cmp_le_i32 s41, s67                                      // 0000001A5ACC: BF054329
	s_cbranch_scc0 392                                         // 0000001A5AD0: BFA10188 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x66f4>
	ds_load_2addr_b32 v[65:66], v146 offset1:2                 // 0000001A5AD4: D8DC0200 41000092
	ds_load_2addr_b32 v[67:68], v146 offset0:4 offset1:6       // 0000001A5ADC: D8DC0604 43000092
	ds_load_2addr_b32 v[69:70], v146 offset0:8 offset1:10      // 0000001A5AE4: D8DC0A08 45000092
	ds_load_2addr_b32 v[71:72], v146 offset0:12 offset1:14     // 0000001A5AEC: D8DC0E0C 47000092
	v_mad_u64_u32 v[73:74], null, 0x3000, v182, v[112:113]     // 0000001A5AF4: D6FE7C49 05C36CFF 00003000
	v_mad_u64_u32 v[75:76], null, 0x3000, v189, v[112:113]     // 0000001A5B00: D6FE7C4B 05C37AFF 00003000
	v_mad_u64_u32 v[77:78], null, 0x3000, v188, v[112:113]     // 0000001A5B0C: D6FE7C4D 05C378FF 00003000
	v_mad_u64_u32 v[79:80], null, 0x3000, v187, v[112:113]     // 0000001A5B18: D6FE7C4F 05C376FF 00003000
	s_mov_b32 s15, 0                                           // 0000001A5B24: BE8F0080
	s_waitcnt vmcnt(1) lgkmcnt(3)                              // 0000001A5B28: BF890437
	v_fma_f32 v96, v9, v65, v49                                // 0000001A5B2C: D6130060 04C68309
	v_fma_f32 v97, v10, v66, v50                               // 0000001A5B34: D6130061 04CA850A
	s_waitcnt lgkmcnt(2)                                       // 0000001A5B3C: BF89FC27
	v_fma_f32 v98, v11, v67, v51                               // 0000001A5B40: D6130062 04CE870B
	v_fma_f32 v100, v12, v68, v52                              // 0000001A5B48: D6130064 04D2890C
	s_waitcnt lgkmcnt(1)                                       // 0000001A5B50: BF89FC17
	v_fma_f32 v104, v13, v69, v53                              // 0000001A5B54: D6130068 04D68B0D
	v_dual_mul_f32 v96, 0x3b800000, v96 :: v_dual_mul_f32 v97, 0x3b800000, v97// 0000001A5B5C: C8C6C0FF 6060C2FF 3B800000
	v_mul_f32_e32 v98, 0x3b800000, v98                         // 0000001A5B68: 10C4C4FF 3B800000
	s_waitcnt lgkmcnt(0)                                       // 0000001A5B70: BF89FC07
	v_fma_f32 v105, v16, v72, v56                              // 0000001A5B74: D6130069 04E29110
	v_mul_f32_e32 v100, 0x3b800000, v100                       // 0000001A5B7C: 10C8C8FF 3B800000
	v_bfe_u32 v101, v96, 16, 1                                 // 0000001A5B84: D6100065 02052160
	v_bfe_u32 v102, v97, 16, 1                                 // 0000001A5B8C: D6100066 02052161
	v_bfe_u32 v103, v98, 16, 1                                 // 0000001A5B94: D6100067 02052162
	v_mul_f32_e32 v105, 0x3b800000, v105                       // 0000001A5B9C: 10D2D2FF 3B800000
	v_fma_f32 v191, v18, v66, v42                              // 0000001A5BA4: D61300BF 04AA8512
	v_add3_u32 v96, v96, v101, 0x7fff                          // 0000001A5BAC: D6550060 03FECB60 00007FFF
	v_add3_u32 v97, v97, v102, 0x7fff                          // 0000001A5BB8: D6550061 03FECD61 00007FFF
	v_add3_u32 v98, v98, v103, 0x7fff                          // 0000001A5BC4: D6550062 03FECF62 00007FFF
	v_bfe_u32 v101, v100, 16, 1                                // 0000001A5BD0: D6100065 02052164
	v_mul_f32_e32 v102, 0x3b800000, v104                       // 0000001A5BD8: 10CCD0FF 3B800000
	v_fma_f32 v103, v14, v70, v54                              // 0000001A5BE0: D6130067 04DA8D0E
	v_fma_f32 v104, v15, v71, v55                              // 0000001A5BE8: D6130068 04DE8F0F
	v_fma_f32 v122, v17, v65, v41                              // 0000001A5BF0: D613007A 04A68311
	v_add3_u32 v100, v100, v101, 0x7fff                        // 0000001A5BF8: D6550064 03FECB64 00007FFF
	v_bfe_u32 v101, v102, 16, 1                                // 0000001A5C04: D6100065 02052166
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A5C0C: BF870234
	v_dual_mul_f32 v103, 0x3b800000, v103 :: v_dual_mul_f32 v104, 0x3b800000, v104// 0000001A5C10: C8C6CEFF 6768D0FF 3B800000
	v_bfe_u32 v190, v105, 16, 1                                // 0000001A5C1C: D61000BE 02052169
	v_fma_f32 v193, v22, v70, v46                              // 0000001A5C24: D61300C1 04BA8D16
	v_add3_u32 v101, v102, v101, 0x7fff                        // 0000001A5C2C: D6550065 03FECB66 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_4)// 0000001A5C38: BF870224
	v_bfe_u32 v102, v103, 16, 1                                // 0000001A5C3C: D6100066 02052167
	v_bfe_u32 v123, v104, 16, 1                                // 0000001A5C44: D610007B 02052168
	v_dual_mul_f32 v122, 0x3b800000, v122 :: v_dual_mul_f32 v193, 0x3b800000, v193// 0000001A5C4C: C8C6F4FF 7AC182FF 3B800000
	v_fma_f32 v192, v21, v69, v45                              // 0000001A5C58: D61300C0 04B68B15
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A5C60: BF870214
	v_add3_u32 v102, v103, v102, 0x7fff                        // 0000001A5C64: D6550066 03FECD67 00007FFF
	v_add3_u32 v103, v104, v123, 0x7fff                        // 0000001A5C70: D6550067 03FEF768 00007FFF
	v_add3_u32 v104, v105, v190, 0x7fff                        // 0000001A5C7C: D6550068 03FF7D69 00007FFF
	v_bfe_u32 v105, v122, 16, 1                                // 0000001A5C88: D6100069 0205217A
	v_mul_f32_e32 v123, 0x3b800000, v191                       // 0000001A5C90: 10F77EFF 3B800000
	v_fma_f32 v190, v19, v67, v43                              // 0000001A5C98: D61300BE 04AE8713
	v_fma_f32 v191, v20, v68, v44                              // 0000001A5CA0: D61300BF 04B28914
	v_fma_f32 v81, v25, v65, v57                               // 0000001A5CA8: D6130051 04E68319
	v_add3_u32 v105, v122, v105, 0x7fff                        // 0000001A5CB0: D6550069 03FED37A 00007FFF
	v_bfe_u32 v122, v123, 16, 1                                // 0000001A5CBC: D610007A 0205217B
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A5CC4: BF870234
	v_dual_mul_f32 v190, 0x3b800000, v190 :: v_dual_mul_f32 v191, 0x3b800000, v191// 0000001A5CC8: C8C77CFF BEBF7EFF 3B800000
	v_fma_f32 v65, v1, v65, v33                                // 0000001A5CD4: D6130041 04868301
	v_mul_f32_e32 v192, 0x3b800000, v192                       // 0000001A5CDC: 118180FF 3B800000
	v_add3_u32 v122, v123, v122, 0x7fff                        // 0000001A5CE4: D655007A 03FEF57B 00007FFF
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A5CF0: BF870004
	v_bfe_u32 v123, v190, 16, 1                                // 0000001A5CF4: D610007B 020521BE
	v_bfe_u32 v194, v191, 16, 1                                // 0000001A5CFC: D61000C2 020521BF
	v_fma_f32 v196, v23, v71, v47                              // 0000001A5D04: D61300C4 04BE8F17
	v_mul_f32_e32 v65, 0x3b800000, v65                         // 0000001A5D0C: 108282FF 3B800000
	v_bfe_u32 v195, v192, 16, 1                                // 0000001A5D14: D61000C3 020521C0
	v_fma_f32 v83, v27, v67, v59                               // 0000001A5D1C: D6130053 04EE871B
	v_add3_u32 v123, v190, v123, 0x7fff                        // 0000001A5D24: D655007B 03FEF7BE 00007FFF
	v_add3_u32 v190, v191, v194, 0x7fff                        // 0000001A5D30: D65500BE 03FF85BF 00007FFF
	v_fma_f32 v67, v3, v67, v35                                // 0000001A5D3C: D6130043 048E8703
	v_add3_u32 v191, v192, v195, 0x7fff                        // 0000001A5D44: D65500BF 03FF87C0 00007FFF
	v_bfe_u32 v192, v193, 16, 1                                // 0000001A5D50: D61000C0 020521C1
	v_mul_f32_e32 v194, 0x3b800000, v196                       // 0000001A5D58: 118588FF 3B800000
	v_fma_f32 v195, v24, v72, v48                              // 0000001A5D60: D61300C3 04C29118
	v_fma_f32 v82, v26, v66, v58                               // 0000001A5D68: D6130052 04EA851A
	v_fma_f32 v66, v2, v66, v34                                // 0000001A5D70: D6130042 048A8502
	v_mul_f32_e32 v81, 0x3b800000, v81                         // 0000001A5D78: 10A2A2FF 3B800000
	v_add3_u32 v192, v193, v192, 0x7fff                        // 0000001A5D80: D65500C0 03FF81C1 00007FFF
	v_mul_f32_e32 v195, 0x3b800000, v195                       // 0000001A5D8C: 118786FF 3B800000
	v_mul_f32_e32 v67, 0x3b800000, v67                         // 0000001A5D94: 108686FF 3B800000
	v_bfe_u32 v193, v194, 16, 1                                // 0000001A5D9C: D61000C1 020521C2
	v_mul_f32_e32 v82, 0x3b800000, v82                         // 0000001A5DA4: 10A4A4FF 3B800000
	v_fma_f32 v85, v29, v69, v61                               // 0000001A5DAC: D6130055 04F68B1D
	v_fma_f32 v69, v5, v69, v37                                // 0000001A5DB4: D6130045 04968B05
	v_mul_f32_e32 v66, 0x3b800000, v66                         // 0000001A5DBC: 108484FF 3B800000
	v_fma_f32 v84, v28, v68, v60                               // 0000001A5DC4: D6130054 04F2891C
	v_fma_f32 v87, v31, v71, v63                               // 0000001A5DCC: D6130057 04FE8F1F
	s_waitcnt vmcnt(0)                                         // 0000001A5DD4: BF8903F7
	v_bfe_u32 v89, v81, 16, 1                                  // 0000001A5DD8: D6100059 02052151
	v_add3_u32 v193, v194, v193, 0x7fff                        // 0000001A5DE0: D65500C1 03FF83C2 00007FFF
	v_bfe_u32 v194, v195, 16, 1                                // 0000001A5DEC: D61000C2 020521C3
	v_fma_f32 v68, v4, v68, v36                                // 0000001A5DF4: D6130044 04928904
	v_fma_f32 v86, v30, v70, v62                               // 0000001A5DFC: D6130056 04FA8D1E
	v_bfe_u32 v90, v82, 16, 1                                  // 0000001A5E04: D610005A 02052152
	v_bfe_u32 v196, v65, 16, 1                                 // 0000001A5E0C: D61000C4 02052141
	v_bfe_u32 v197, v66, 16, 1                                 // 0000001A5E14: D61000C5 02052142
	v_fma_f32 v88, v32, v72, v64                               // 0000001A5E1C: D6130058 05029120
	v_dual_mul_f32 v83, 0x3b800000, v83 :: v_dual_mul_f32 v84, 0x3b800000, v84// 0000001A5E24: C8C6A6FF 5354A8FF 3B800000
	v_mul_f32_e32 v87, 0x3b800000, v87                         // 0000001A5E30: 10AEAEFF 3B800000
	v_add3_u32 v89, v81, v89, 0x7fff                           // 0000001A5E38: D6550059 03FEB351 00007FFF
	v_add3_u32 v194, v195, v194, 0x7fff                        // 0000001A5E44: D65500C2 03FF85C3 00007FFF
	v_bfe_u32 v195, v67, 16, 1                                 // 0000001A5E50: D61000C3 02052143
	v_fma_f32 v70, v6, v70, v38                                // 0000001A5E58: D6130046 049A8D06
	v_dual_mul_f32 v68, 0x3b800000, v68 :: v_dual_mul_f32 v85, 0x3b800000, v85// 0000001A5E60: C8C688FF 4454AAFF 3B800000
	v_mul_f32_e32 v86, 0x3b800000, v86                         // 0000001A5E6C: 10ACACFF 3B800000
	v_add3_u32 v90, v82, v90, 0x7fff                           // 0000001A5E74: D655005A 03FEB552 00007FFF
	v_add3_u32 v65, v65, v196, 0x7fff                          // 0000001A5E80: D6550041 03FF8941 00007FFF
	v_add3_u32 v66, v66, v197, 0x7fff                          // 0000001A5E8C: D6550042 03FF8B42 00007FFF
	v_mul_f32_e32 v88, 0x3b800000, v88                         // 0000001A5E98: 10B0B0FF 3B800000
	v_bfe_u32 v91, v83, 16, 1                                  // 0000001A5EA0: D610005B 02052153
	v_bfe_u32 v95, v87, 16, 1                                  // 0000001A5EA8: D610005F 02052157
	s_clause 0x7                                               // 0000001A5EB0: BF850007
	global_store_d16_hi_b16 v[73:74], v89, off                 // 0000001A5EB4: DC960000 007C5949
	global_store_d16_hi_b16 v[73:74], v96, off offset:32       // 0000001A5EBC: DC960020 007C6049
	global_store_d16_hi_b16 v[73:74], v105, off offset:64      // 0000001A5EC4: DC960040 007C6949
	global_store_d16_hi_b16 v[75:76], v90, off                 // 0000001A5ECC: DC960000 007C5A4B
	global_store_d16_hi_b16 v[75:76], v97, off offset:32       // 0000001A5ED4: DC960020 007C614B
	global_store_d16_hi_b16 v[75:76], v122, off offset:64      // 0000001A5EDC: DC960040 007C7A4B
	global_store_d16_hi_b16 v[73:74], v65, off offset:96       // 0000001A5EE4: DC960060 007C4149
	global_store_d16_hi_b16 v[75:76], v66, off offset:96       // 0000001A5EEC: DC960060 007C424B
	v_add3_u32 v65, v67, v195, 0x7fff                          // 0000001A5EF4: D6550041 03FF8743 00007FFF
	v_mul_f32_e32 v67, 0x3b800000, v69                         // 0000001A5F00: 10868AFF 3B800000
	v_mul_f32_e32 v69, 0x3b800000, v70                         // 0000001A5F08: 108A8CFF 3B800000
	v_bfe_u32 v66, v68, 16, 1                                  // 0000001A5F10: D6100042 02052144
	v_fma_f32 v70, v7, v71, v39                                // 0000001A5F18: D6130046 049E8F07
	v_fma_f32 v71, v8, v72, v40                                // 0000001A5F20: D6130047 04A29108
	v_bfe_u32 v93, v85, 16, 1                                  // 0000001A5F28: D610005D 02052155
	v_bfe_u32 v94, v86, 16, 1                                  // 0000001A5F30: D610005E 02052156
	v_bfe_u32 v92, v84, 16, 1                                  // 0000001A5F38: D610005C 02052154
	v_add3_u32 v91, v83, v91, 0x7fff                           // 0000001A5F40: D655005B 03FEB753 00007FFF
	v_add3_u32 v95, v87, v95, 0x7fff                           // 0000001A5F4C: D655005F 03FEBF57 00007FFF
	v_bfe_u32 v87, v88, 16, 1                                  // 0000001A5F58: D6100057 02052158
	v_add3_u32 v66, v68, v66, 0x7fff                           // 0000001A5F60: D6550042 03FE8544 00007FFF
	v_bfe_u32 v68, v67, 16, 1                                  // 0000001A5F6C: D6100044 02052143
	v_dual_mul_f32 v70, 0x3b800000, v70 :: v_dual_mul_f32 v71, 0x3b800000, v71// 0000001A5F74: C8C68CFF 46468EFF 3B800000
	v_add3_u32 v93, v85, v93, 0x7fff                           // 0000001A5F80: D655005D 03FEBB55 00007FFF
	v_mad_u64_u32 v[81:82], null, 0x3000, v186, v[112:113]     // 0000001A5F8C: D6FE7C51 05C374FF 00003000
	v_add3_u32 v94, v86, v94, 0x7fff                           // 0000001A5F98: D655005E 03FEBD56 00007FFF
	v_mad_u64_u32 v[85:86], null, 0x3000, v184, v[112:113]     // 0000001A5FA4: D6FE7C55 05C370FF 00003000
	v_add3_u32 v92, v84, v92, 0x7fff                           // 0000001A5FB0: D655005C 03FEB954 00007FFF
	v_bfe_u32 v72, v69, 16, 1                                  // 0000001A5FBC: D6100048 02052145
	v_mad_u64_u32 v[83:84], null, 0x3000, v185, v[112:113]     // 0000001A5FC4: D6FE7C53 05C372FF 00003000
	v_add3_u32 v99, v88, v87, 0x7fff                           // 0000001A5FD0: D6550063 03FEAF58 00007FFF
	v_mad_u64_u32 v[87:88], null, 0x3000, v183, v[112:113]     // 0000001A5FDC: D6FE7C57 05C36EFF 00003000
	s_clause 0x7                                               // 0000001A5FE8: BF850007
	global_store_d16_hi_b16 v[77:78], v91, off                 // 0000001A5FEC: DC960000 007C5B4D
	global_store_d16_hi_b16 v[77:78], v98, off offset:32       // 0000001A5FF4: DC960020 007C624D
	global_store_d16_hi_b16 v[77:78], v123, off offset:64      // 0000001A5FFC: DC960040 007C7B4D
	global_store_d16_hi_b16 v[79:80], v92, off                 // 0000001A6004: DC960000 007C5C4F
	global_store_d16_hi_b16 v[79:80], v100, off offset:32      // 0000001A600C: DC960020 007C644F
	global_store_d16_hi_b16 v[79:80], v190, off offset:64      // 0000001A6014: DC960040 007CBE4F
	global_store_d16_hi_b16 v[77:78], v65, off offset:96       // 0000001A601C: DC960060 007C414D
	global_store_d16_hi_b16 v[79:80], v66, off offset:96       // 0000001A6024: DC960060 007C424F
	v_add3_u32 v65, v67, v68, 0x7fff                           // 0000001A602C: D6550041 03FE8943 00007FFF
	v_bfe_u32 v67, v70, 16, 1                                  // 0000001A6038: D6100043 02052146
	v_bfe_u32 v68, v71, 16, 1                                  // 0000001A6040: D6100044 02052147
	v_add3_u32 v66, v69, v72, 0x7fff                           // 0000001A6048: D6550042 03FE9145 00007FFF
	s_clause 0x7                                               // 0000001A6054: BF850007
	global_store_d16_hi_b16 v[81:82], v93, off                 // 0000001A6058: DC960000 007C5D51
	global_store_d16_hi_b16 v[81:82], v101, off offset:32      // 0000001A6060: DC960020 007C6551
	global_store_d16_hi_b16 v[81:82], v191, off offset:64      // 0000001A6068: DC960040 007CBF51
	global_store_d16_hi_b16 v[83:84], v94, off                 // 0000001A6070: DC960000 007C5E53
	global_store_d16_hi_b16 v[83:84], v102, off offset:32      // 0000001A6078: DC960020 007C6653
	global_store_d16_hi_b16 v[83:84], v192, off offset:64      // 0000001A6080: DC960040 007CC053
	global_store_d16_hi_b16 v[81:82], v65, off offset:96       // 0000001A6088: DC960060 007C4151
	global_store_d16_hi_b16 v[83:84], v66, off offset:96       // 0000001A6090: DC960060 007C4253
	v_add3_u32 v65, v70, v67, 0x7fff                           // 0000001A6098: D6550041 03FE8746 00007FFF
	v_add3_u32 v66, v71, v68, 0x7fff                           // 0000001A60A4: D6550042 03FE8947 00007FFF
	s_clause 0x7                                               // 0000001A60B0: BF850007
	global_store_d16_hi_b16 v[85:86], v95, off                 // 0000001A60B4: DC960000 007C5F55
	global_store_d16_hi_b16 v[85:86], v103, off offset:32      // 0000001A60BC: DC960020 007C6755
	global_store_d16_hi_b16 v[85:86], v193, off offset:64      // 0000001A60C4: DC960040 007CC155
	global_store_d16_hi_b16 v[87:88], v99, off                 // 0000001A60CC: DC960000 007C6357
	global_store_d16_hi_b16 v[87:88], v104, off offset:32      // 0000001A60D4: DC960020 007C6857
	global_store_d16_hi_b16 v[87:88], v194, off offset:64      // 0000001A60DC: DC960040 007CC257
	global_store_d16_hi_b16 v[85:86], v65, off offset:96       // 0000001A60E4: DC960060 007C4155
	global_store_d16_hi_b16 v[87:88], v66, off offset:96       // 0000001A60EC: DC960060 007C4257
	s_and_not1_b32 vcc_lo, exec_lo, s15                        // 0000001A60F4: 916A0F7E
	s_cbranch_vccnz 114                                        // 0000001A60F8: BFA40072 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68c4>
	s_and_saveexec_b32 s15, s11                                // 0000001A60FC: BE8F200B
	s_cbranch_execnz 2548                                      // 0000001A6100: BFA609F4 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8ed4>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6104: 8C7E0F7E
	s_and_saveexec_b32 s15, s14                                // 0000001A6108: BE8F200E
	s_cbranch_execnz 2567                                      // 0000001A610C: BFA60A07 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8f2c>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6110: 8C7E0F7E
	s_and_saveexec_b32 s15, s13                                // 0000001A6114: BE8F200D
	s_cbranch_execnz 2586                                      // 0000001A6118: BFA60A1A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8f84>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A611C: 8C7E0F7E
	s_and_saveexec_b32 s15, s12                                // 0000001A6120: BE8F200C
	s_cbranch_execnz 2605                                      // 0000001A6124: BFA60A2D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8fdc>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6128: 8C7E0F7E
	s_and_saveexec_b32 s15, s10                                // 0000001A612C: BE8F200A
	s_cbranch_execnz 2624                                      // 0000001A6130: BFA60A40 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x9034>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6134: 8C7E0F7E
	s_and_saveexec_b32 s15, s1                                 // 0000001A6138: BE8F2001
	s_cbranch_execnz 2643                                      // 0000001A613C: BFA60A53 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x908c>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6140: 8C7E0F7E
	s_and_saveexec_b32 s15, s9                                 // 0000001A6144: BE8F2009
	s_cbranch_execnz 2662                                      // 0000001A6148: BFA60A66 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x90e4>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A614C: 8C7E0F7E
	s_and_saveexec_b32 s15, s0                                 // 0000001A6150: BE8F2000
	s_cbranch_execnz 2681                                      // 0000001A6154: BFA60A79 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x913c>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6158: 8C7E0F7E
	s_and_saveexec_b32 s15, s11                                // 0000001A615C: BE8F200B
	s_cbranch_execnz 2700                                      // 0000001A6160: BFA60A8C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x9194>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6164: 8C7E0F7E
	s_and_saveexec_b32 s15, s14                                // 0000001A6168: BE8F200E
	s_cbranch_execnz 2719                                      // 0000001A616C: BFA60A9F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x91ec>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6170: 8C7E0F7E
	s_and_saveexec_b32 s15, s13                                // 0000001A6174: BE8F200D
	s_cbranch_execnz 2738                                      // 0000001A6178: BFA60AB2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x9244>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A617C: 8C7E0F7E
	s_and_saveexec_b32 s15, s12                                // 0000001A6180: BE8F200C
	s_cbranch_execnz 2757                                      // 0000001A6184: BFA60AC5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x929c>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6188: 8C7E0F7E
	s_and_saveexec_b32 s15, s10                                // 0000001A618C: BE8F200A
	s_cbranch_execnz 2776                                      // 0000001A6190: BFA60AD8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x92f4>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6194: 8C7E0F7E
	s_and_saveexec_b32 s15, s1                                 // 0000001A6198: BE8F2001
	s_cbranch_execnz 2795                                      // 0000001A619C: BFA60AEB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x934c>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A61A0: 8C7E0F7E
	s_and_saveexec_b32 s15, s9                                 // 0000001A61A4: BE8F2009
	s_cbranch_execnz 2814                                      // 0000001A61A8: BFA60AFE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x93a4>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A61AC: 8C7E0F7E
	s_and_saveexec_b32 s15, s0                                 // 0000001A61B0: BE8F2000
	s_cbranch_execnz 2833                                      // 0000001A61B4: BFA60B11 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x93fc>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A61B8: 8C7E0F7E
	s_and_saveexec_b32 s15, s11                                // 0000001A61BC: BE8F200B
	s_cbranch_execnz 2852                                      // 0000001A61C0: BFA60B24 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x9454>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A61C4: 8C7E0F7E
	s_and_saveexec_b32 s15, s14                                // 0000001A61C8: BE8F200E
	s_cbranch_execnz 2871                                      // 0000001A61CC: BFA60B37 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x94ac>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A61D0: 8C7E0F7E
	s_and_saveexec_b32 s15, s13                                // 0000001A61D4: BE8F200D
	s_cbranch_execnz 2890                                      // 0000001A61D8: BFA60B4A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x9504>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A61DC: 8C7E0F7E
	s_and_saveexec_b32 s15, s12                                // 0000001A61E0: BE8F200C
	s_cbranch_execnz 2909                                      // 0000001A61E4: BFA60B5D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x955c>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A61E8: 8C7E0F7E
	s_and_saveexec_b32 s15, s10                                // 0000001A61EC: BE8F200A
	s_cbranch_execnz 2928                                      // 0000001A61F0: BFA60B70 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x95b4>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A61F4: 8C7E0F7E
	s_and_saveexec_b32 s15, s1                                 // 0000001A61F8: BE8F2001
	s_cbranch_execnz 2947                                      // 0000001A61FC: BFA60B83 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x960c>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6200: 8C7E0F7E
	s_and_saveexec_b32 s15, s9                                 // 0000001A6204: BE8F2009
	s_cbranch_execnz 2966                                      // 0000001A6208: BFA60B96 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x9664>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A620C: 8C7E0F7E
	s_and_saveexec_b32 s15, s0                                 // 0000001A6210: BE8F2000
	s_cbranch_execnz 2985                                      // 0000001A6214: BFA60BA9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x96bc>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6218: 8C7E0F7E
	s_and_saveexec_b32 s15, s11                                // 0000001A621C: BE8F200B
	s_cbranch_execnz 3004                                      // 0000001A6220: BFA60BBC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x9714>
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6224: 8C7E0F7E
	s_and_saveexec_b32 s11, s14                                // 0000001A6228: BE8B200E
	s_cbranch_execnz 3023                                      // 0000001A622C: BFA60BCF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x976c>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001A6230: 8C7E0B7E
	s_and_saveexec_b32 s11, s13                                // 0000001A6234: BE8B200D
	s_cbranch_execnz 3042                                      // 0000001A6238: BFA60BE2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x97c4>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001A623C: 8C7E0B7E
	s_and_saveexec_b32 s11, s12                                // 0000001A6240: BE8B200C
	s_cbranch_execnz 3061                                      // 0000001A6244: BFA60BF5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x981c>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001A6248: 8C7E0B7E
	s_and_saveexec_b32 s11, s10                                // 0000001A624C: BE8B200A
	s_cbranch_execnz 3080                                      // 0000001A6250: BFA60C08 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x9874>
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001A6254: 8C7E0B7E
	s_and_saveexec_b32 s10, s1                                 // 0000001A6258: BE8A2001
	s_cbranch_execnz 3099                                      // 0000001A625C: BFA60C1B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x98cc>
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001A6260: 8C7E0A7E
	s_and_saveexec_b32 s1, s9                                  // 0000001A6264: BE812009
	s_cbranch_execnz 3118                                      // 0000001A6268: BFA60C2E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x9924>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001A626C: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000001A6270: BE812000
	s_cbranch_execz 18                                         // 0000001A6274: BFA50012 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68c0>
	ds_load_b32 v1, v146 offset:56                             // 0000001A6278: D8D80038 01000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A6280: BF89FC07
	v_fmac_f32_e32 v40, v8, v1                                 // 0000001A6284: 56500308
	v_mad_u64_u32 v[1:2], null, 0x3000, v183, v[112:113]       // 0000001A6288: D6FE7C01 05C36EFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A6294: BF870092
	v_mul_f32_e32 v3, 0x3b800000, v40                          // 0000001A6298: 100650FF 3B800000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001A62A0: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A62A8: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001A62AC: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001A62B8: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001A62C0: 8C7E017E
	v_mov_b32_e32 v41, 0                                       // 0000001A62C4: 7E520280
	s_waitcnt vmcnt(0)                                         // 0000001A62C8: BF8903F7
	s_waitcnt_vscnt null, 0x0                                  // 0000001A62CC: BC7C0000
	s_barrier                                                  // 0000001A62D0: BFBD0000
	buffer_gl0_inv                                             // 0000001A62D4: E0AC0000 00000000
	s_and_saveexec_b32 s0, s6                                  // 0000001A62DC: BE802006
	s_cbranch_execz 6                                          // 0000001A62E0: BFA50006 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68fc>
	s_lshl_b64 s[10:11], s[24:25], 2                           // 0000001A62E4: 848A8218
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A62E8: BF870009
	s_add_u32 s10, s68, s10                                    // 0000001A62EC: 800A0A44
	s_addc_u32 s11, s69, s11                                   // 0000001A62F0: 820B0B45
	global_atomic_inc_u32 v41, v107, v179, s[10:11] glc        // 0000001A62F4: DCFE4000 290AB36B
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001A62FC: 8C7E007E
	s_mul_f32 s0, s40, 0x3fb8aa3b                              // 0000001A6300: A200FF28 3FB8AA3B
	ds_load_b128 v[1:4], v137                                  // 0000001A6308: DBFC0000 01000089
	ds_load_b128 v[5:8], v137 offset:16                        // 0000001A6310: DBFC0010 05000089
	ds_load_b128 v[42:45], v138                                // 0000001A6318: DBFC0000 2A00008A
	ds_load_b128 v[46:49], v138 offset:16                      // 0000001A6320: DBFC0010 2E00008A
	ds_load_b128 v[17:20], v137 offset:32                      // 0000001A6328: DBFC0020 11000089
	ds_load_b128 v[21:24], v137 offset:48                      // 0000001A6330: DBFC0030 15000089
	ds_load_b128 v[50:53], v138 offset:32                      // 0000001A6338: DBFC0020 3200008A
	ds_load_b128 v[54:57], v138 offset:48                      // 0000001A6340: DBFC0030 3600008A
	s_xor_b32 s1, s0, 0x80000000                               // 0000001A6348: 8D01FF00 80000000
	s_rndne_f32 s9, s0                                         // 0000001A6350: BE896300
	s_fmamk_f32 s1, s40, 0x3fb8aa3b, s1                        // 0000001A6354: A3010128 3FB8AA3B
	ds_load_b128 v[13:16], v137 offset:80                      // 0000001A635C: DBFC0050 0D000089
	ds_load_b128 v[9:12], v137 offset:64                       // 0000001A6364: DBFC0040 09000089
	ds_load_b128 v[62:65], v138 offset:80                      // 0000001A636C: DBFC0050 3E00008A
	ds_load_b128 v[58:61], v138 offset:64                      // 0000001A6374: DBFC0040 3A00008A
	ds_load_b128 v[29:32], v137 offset:112                     // 0000001A637C: DBFC0070 1D000089
	ds_load_b128 v[25:28], v137 offset:96                      // 0000001A6384: DBFC0060 19000089
	s_sub_f32 s0, s0, s9                                       // 0000001A638C: A0800900
	s_fmamk_f32 s1, s40, 0x32a5705f, s1                        // 0000001A6390: A3010128 32A5705F
	v_dual_mov_b32 v33, s44 :: v_dual_mov_b32 v34, s45         // 0000001A6398: CA10002C 2122002D
	v_dual_mov_b32 v35, s46 :: v_dual_mov_b32 v36, s47         // 0000001A63A0: CA10002E 2324002F
	s_delay_alu instid0(SALU_CYCLE_1) | instskip(SKIP_2) | instid1(SALU_CYCLE_1)// 0000001A63A8: BF8704B9
	s_add_f32 s0, s0, s1                                       // 0000001A63AC: A0000100
	v_dual_mov_b32 v37, s48 :: v_dual_mov_b32 v38, s49         // 0000001A63B0: CA100030 25260031
	v_dual_mov_b32 v39, s50 :: v_dual_mov_b32 v40, s51         // 0000001A63B8: CA100032 27280033
	v_exp_f32_e32 v84, s0                                      // 0000001A63C0: 7EA84A00
	ds_load_b128 v[70:73], v138 offset:112                     // 0000001A63C4: DBFC0070 4600008A
	ds_load_b128 v[66:69], v138 offset:96                      // 0000001A63CC: DBFC0060 4200008A
	ds_load_2addr_b32 v[82:83], v139 offset1:2                 // 0000001A63D4: D8DC0200 5200008B
	s_cvt_i32_f32 s0, s9                                       // 0000001A63DC: BE806609
	s_cmp_nlt_f32 s40, 0xc2ce8ed0                              // 0000001A63E0: BF4EFF28 C2CE8ED0
	s_waitcnt lgkmcnt(13)                                      // 0000001A63E8: BF89FCD7
	v_wmma_f32_16x16x16_f16 v[74:81], v[42:49], v[1:8], v[33:40]// 0000001A63EC: CC40404A 1C86032A
	ds_load_2addr_b32 v[86:87], v139 offset0:8 offset1:10      // 0000001A63F4: D8DC0A08 5600008B
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A63FC: 986A80C1
	s_cmp_ngt_f32 s40, 0x42b17218                              // 0000001A6400: BF4BFF28 42B17218
	s_waitcnt lgkmcnt(10)                                      // 0000001A6408: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[74:81], v[50:57], v[17:24], v[74:81]// 0000001A640C: CC40404A 1D2A2332
	.long 0xd71c002a                                           // 0000001A6414: D71C002A
	v_cndmask_b32_e32 v0, v84, v0, vcc_lo                      // 0000001A6418: 02000154
	ds_load_2addr_b32 v[84:85], v139 offset0:4 offset1:6       // 0000001A641C: D8DC0604 5400008B
	ds_load_2addr_b32 v[90:91], v139 offset0:12 offset1:14     // 0000001A6424: D8DC0E0C 5A00008B
	ds_load_b128 v[43:46], v138 offset:2304                    // 0000001A642C: DBFC0900 2B00008A
	ds_load_b128 v[47:50], v138 offset:2320                    // 0000001A6434: DBFC0910 2F00008A
	s_waitcnt lgkmcnt(10)                                      // 0000001A643C: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[74:81], v[58:65], v[9:16], v[74:81]// 0000001A6440: CC40404A 1D2A133A
	ds_load_b128 v[51:54], v138 offset:2336                    // 0000001A6448: DBFC0920 3300008A
	ds_load_b128 v[55:58], v138 offset:2352                    // 0000001A6450: DBFC0930 3700008A
	s_waitcnt lgkmcnt(8)                                       // 0000001A6458: BF89FC87
	v_wmma_f32_16x16x16_f16 v[74:81], v[66:73], v[25:32], v[74:81]// 0000001A645C: CC40404A 1D2A3342
	v_cndmask_b32_e32 v42, 0, v42, vcc_lo                      // 0000001A6464: 02545480
	s_cselect_b32 vcc_lo, -1, 0                                // 0000001A6468: 986A80C1
	ds_load_b128 v[63:66], v138 offset:2384                    // 0000001A646C: DBFC0950 3F00008A
	ds_load_b128 v[59:62], v138 offset:2368                    // 0000001A6474: DBFC0940 3B00008A
	v_cndmask_b32_e32 v42, 0x7f800000, v42, vcc_lo             // 0000001A647C: 025454FF 7F800000
	s_waitcnt lgkmcnt(7)                                       // 0000001A6484: BF89FC77
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A6488: BF870091
	v_mul_f32_e32 v95, v42, v85                                // 0000001A648C: 10BEAB2A
	v_dual_mul_f32 v92, v42, v82 :: v_dual_fmac_f32 v95, 0x3b800000, v77// 0000001A6490: C8C0A52A 5C5E9AFF 3B800000
	v_mul_f32_e32 v77, v42, v87                                // 0000001A649C: 109AAF2A
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A64A0: BF870002
	v_dual_mul_f32 v93, v42, v83 :: v_dual_fmac_f32 v92, 0x3b800000, v74// 0000001A64A4: C8C0A72A 5D5C94FF 3B800000
	v_mul_f32_e32 v94, v42, v84                                // 0000001A64B0: 10BCA92A
	ds_load_b128 v[71:74], v138 offset:2416                    // 0000001A64B4: DBFC0970 4700008A
	ds_load_b128 v[67:70], v138 offset:2400                    // 0000001A64BC: DBFC0960 4300008A
	v_fmac_f32_e32 v77, 0x3b800000, v79                        // 0000001A64C4: 569A9EFF 3B800000
	s_waitcnt lgkmcnt(8)                                       // 0000001A64CC: BF89FC87
	v_mul_f32_e32 v79, v42, v90                                // 0000001A64D0: 109EB52A
	v_dual_mul_f32 v96, v42, v86 :: v_dual_fmac_f32 v93, 0x3b800000, v75// 0000001A64D4: C8C0AD2A 605C96FF 3B800000
	v_fmac_f32_e32 v94, 0x3b800000, v76                        // 0000001A64E0: 56BC98FF 3B800000
	ds_load_2addr_b32 v[75:76], v139 offset0:16 offset1:18     // 0000001A64E8: D8DC1210 4B00008B
	v_dual_fmac_f32 v79, 0x3b800000, v80 :: v_dual_fmac_f32 v96, 0x3b800000, v78// 0000001A64F0: C800A0FF 4F609CFF 3B800000
	s_waitcnt lgkmcnt(7)                                       // 0000001A64FC: BF89FC77
	v_wmma_f32_16x16x16_f16 v[82:89], v[43:50], v[1:8], v[33:40]// 0000001A6500: CC404052 1C86032B
	ds_store_2addr_b32 v139, v92, v93 offset1:2                // 0000001A6508: D8380200 005D5C8B
	ds_store_2addr_b32 v139, v94, v95 offset0:4 offset1:6      // 0000001A6510: D8380604 005F5E8B
	ds_load_2addr_b32 v[92:93], v139 offset0:28 offset1:30     // 0000001A6518: D8DC1E1C 5C00008B
	ds_store_2addr_b32 v139, v96, v77 offset0:8 offset1:10     // 0000001A6520: D8380A08 004D608B
	ds_load_2addr_b32 v[77:78], v139 offset0:20 offset1:22     // 0000001A6528: D8DC1614 4D00008B
	s_waitcnt lgkmcnt(10)                                      // 0000001A6530: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[82:89], v[51:58], v[17:24], v[82:89]// 0000001A6534: CC404052 1D4A2333
	ds_load_b128 v[51:54], v138 offset:4640                    // 0000001A653C: DBFC1220 3300008A
	ds_load_b128 v[55:58], v138 offset:4656                    // 0000001A6544: DBFC1230 3700008A
	s_waitcnt lgkmcnt(10)                                      // 0000001A654C: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[82:89], v[59:66], v[9:16], v[82:89]// 0000001A6550: CC404052 1D4A133B
	ds_load_b128 v[63:66], v138 offset:4688                    // 0000001A6558: DBFC1250 3F00008A
	ds_load_b128 v[59:62], v138 offset:4672                    // 0000001A6560: DBFC1240 3B00008A
	s_waitcnt lgkmcnt(10)                                      // 0000001A6568: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[82:89], v[67:74], v[25:32], v[82:89]// 0000001A656C: CC404052 1D4A3343
	s_waitcnt lgkmcnt(9)                                       // 0000001A6574: BF89FC97
	v_mul_f32_e32 v96, v42, v75                                // 0000001A6578: 10C0972A
	v_mul_f32_e32 v97, v42, v76                                // 0000001A657C: 10C2992A
	ds_load_b128 v[71:74], v138 offset:4720                    // 0000001A6580: DBFC1270 4700008A
	ds_load_b128 v[67:70], v138 offset:4704                    // 0000001A6588: DBFC1260 4300008A
	ds_load_2addr_b32 v[94:95], v139 offset0:32 offset1:34     // 0000001A6590: D8DC2220 5E00008B
	v_dual_fmac_f32 v96, 0x3b800000, v82 :: v_dual_fmac_f32 v97, 0x3b800000, v83// 0000001A6598: C800A4FF 6060A6FF 3B800000
	s_waitcnt lgkmcnt(7)                                       // 0000001A65A4: BF89FC77
	v_mul_f32_e32 v98, v42, v77                                // 0000001A65A8: 10C49B2A
	v_mul_f32_e32 v99, v42, v78                                // 0000001A65AC: 10C69D2A
	ds_store_2addr_b32 v139, v96, v97 offset0:16 offset1:18    // 0000001A65B0: D8381210 0061608B
	v_fmac_f32_e32 v98, 0x3b800000, v84                        // 0000001A65B8: 56C4A8FF 3B800000
	v_dual_mul_f32 v80, v42, v91 :: v_dual_fmac_f32 v99, 0x3b800000, v85// 0000001A65C0: C8C0B72A 5062AAFF 3B800000
	ds_load_b128 v[43:46], v138 offset:4608                    // 0000001A65CC: DBFC1200 2B00008A
	ds_load_b128 v[47:50], v138 offset:4624                    // 0000001A65D4: DBFC1210 2F00008A
	ds_load_2addr_b32 v[90:91], v139 offset0:24 offset1:26     // 0000001A65DC: D8DC1A18 5A00008B
	ds_load_2addr_b32 v[83:84], v139 offset0:36 offset1:38     // 0000001A65E4: D8DC2624 5300008B
	v_dual_mul_f32 v85, v42, v92 :: v_dual_fmac_f32 v80, 0x3b800000, v81// 0000001A65EC: C8C0B92A 5550A2FF 3B800000
	ds_store_2addr_b32 v139, v98, v99 offset0:20 offset1:22    // 0000001A65F8: D8381614 0063628B
	v_fmac_f32_e32 v85, 0x3b800000, v88                        // 0000001A6600: 56AAB0FF 3B800000
	ds_store_2addr_b32 v139, v79, v80 offset0:12 offset1:14    // 0000001A6608: D8380E0C 00504F8B
	s_waitcnt lgkmcnt(4)                                       // 0000001A6610: BF89FC47
	v_wmma_f32_16x16x16_f16 v[75:82], v[43:50], v[1:8], v[33:40]// 0000001A6614: CC40404B 1C86032B
	s_waitcnt lgkmcnt(3)                                       // 0000001A661C: BF89FC37
	v_mul_f32_e32 v44, v42, v91                                // 0000001A6620: 1058B72A
	v_mul_f32_e32 v43, v42, v90                                // 0000001A6624: 1056B52A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A6628: BF870003
	v_wmma_f32_16x16x16_f16 v[75:82], v[51:58], v[17:24], v[75:82]// 0000001A662C: CC40404B 1D2E2333
	ds_load_2addr_b32 v[91:92], v139 offset0:40 offset1:42     // 0000001A6634: D8DC2A28 5B00008B
	ds_load_b128 v[51:54], v138 offset:6944                    // 0000001A663C: DBFC1B20 3300008A
	ds_load_b128 v[55:58], v138 offset:6960                    // 0000001A6644: DBFC1B30 3700008A
	v_dual_fmac_f32 v44, 0x3b800000, v87 :: v_dual_fmac_f32 v43, 0x3b800000, v86// 0000001A664C: C800AEFF 2C2AACFF 3B800000
	v_wmma_f32_16x16x16_f16 v[75:82], v[59:66], v[9:16], v[75:82]// 0000001A6658: CC40404B 1D2E133B
	ds_load_b128 v[63:66], v138 offset:6992                    // 0000001A6660: DBFC1B50 3F00008A
	ds_load_b128 v[59:62], v138 offset:6976                    // 0000001A6668: DBFC1B40 3B00008A
	ds_store_2addr_b32 v139, v43, v44 offset0:24 offset1:26    // 0000001A6670: D8381A18 002C2B8B
	ds_load_b128 v[43:46], v138 offset:6912                    // 0000001A6678: DBFC1B00 2B00008A
	ds_load_b128 v[47:50], v138 offset:6928                    // 0000001A6680: DBFC1B10 2F00008A
	v_wmma_f32_16x16x16_f16 v[75:82], v[67:74], v[25:32], v[75:82]// 0000001A6688: CC40404B 1D2E3343
	s_waitcnt lgkmcnt(10)                                      // 0000001A6690: BF89FCA7
	v_mul_f32_e32 v98, v42, v84                                // 0000001A6694: 10C4A92A
	v_mul_f32_e32 v95, v42, v95                                // 0000001A6698: 10BEBF2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A669C: BF870112
	v_dual_mul_f32 v97, v42, v83 :: v_dual_fmac_f32 v98, 0x3b800000, v78// 0000001A66A0: C8C0A72A 61629CFF 3B800000
	v_dual_mul_f32 v86, v42, v93 :: v_dual_fmac_f32 v95, 0x3b800000, v76// 0000001A66AC: C8C0BB2A 565E98FF 3B800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000001A66B8: BF870151
	v_fmac_f32_e32 v86, 0x3b800000, v89                        // 0000001A66BC: 56ACB2FF 3B800000
	ds_store_2addr_b32 v139, v85, v86 offset0:28 offset1:30    // 0000001A66C4: D8381E1C 0056558B
	s_waitcnt lgkmcnt(1)                                       // 0000001A66CC: BF89FC17
	v_wmma_f32_16x16x16_f16 v[83:90], v[43:50], v[1:8], v[33:40]// 0000001A66D0: CC404053 1C86032B
	v_mul_f32_e32 v44, v42, v92                                // 0000001A66D8: 1058B92A
	v_wmma_f32_16x16x16_f16 v[83:90], v[51:58], v[17:24], v[83:90]// 0000001A66DC: CC404053 1D4E2333
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A66E4: BF870002
	v_fmac_f32_e32 v44, 0x3b800000, v80                        // 0000001A66E8: 5658A0FF 3B800000
	v_dual_mul_f32 v96, v42, v94 :: v_dual_fmac_f32 v97, 0x3b800000, v77// 0000001A66F0: C8C0BD2A 60609AFF 3B800000
	ds_load_2addr_b32 v[93:94], v139 offset0:44 offset1:46     // 0000001A66FC: D8DC2E2C 5D00008B
	ds_load_2addr_b32 v[77:78], v139 offset0:52 offset1:54     // 0000001A6704: D8DC3634 4D00008B
	v_wmma_f32_16x16x16_f16 v[83:90], v[59:66], v[9:16], v[83:90]// 0000001A670C: CC404053 1D4E133B
	v_fmac_f32_e32 v96, 0x3b800000, v75                        // 0000001A6714: 56C096FF 3B800000
	ds_load_b128 v[71:74], v138 offset:7024                    // 0000001A671C: DBFC1B70 4700008A
	ds_load_b128 v[67:70], v138 offset:7008                    // 0000001A6724: DBFC1B60 4300008A
	ds_load_2addr_b32 v[75:76], v139 offset0:48 offset1:50     // 0000001A672C: D8DC3230 4B00008B
	ds_load_b128 v[63:66], v138 offset:9296                    // 0000001A6734: DBFC2450 3F00008A
	ds_load_b128 v[59:62], v138 offset:9280                    // 0000001A673C: DBFC2440 3B00008A
	s_waitcnt lgkmcnt(6)                                       // 0000001A6744: BF89FC67
	v_mul_f32_e32 v45, v42, v93                                // 0000001A6748: 105ABB2A
	ds_store_2addr_b32 v139, v96, v95 offset0:32 offset1:34    // 0000001A674C: D8382220 005F608B
	ds_store_2addr_b32 v139, v97, v98 offset0:36 offset1:38    // 0000001A6754: D8382624 0062618B
	s_waitcnt lgkmcnt(5)                                       // 0000001A675C: BF89FC57
	v_wmma_f32_16x16x16_f16 v[83:90], v[67:74], v[25:32], v[83:90]// 0000001A6760: CC404053 1D4E3343
	s_waitcnt lgkmcnt(4)                                       // 0000001A6768: BF89FC47
	v_mul_f32_e32 v68, v42, v76                                // 0000001A676C: 1088992A
	v_mul_f32_e32 v67, v42, v75                                // 0000001A6770: 1086972A
	v_mul_f32_e32 v76, v42, v78                                // 0000001A6774: 10989D2A
	v_mul_f32_e32 v75, v42, v77                                // 0000001A6778: 10969B2A
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A677C: BF870112
	v_dual_fmac_f32 v45, 0x3b800000, v81 :: v_dual_fmac_f32 v76, 0x3b800000, v86// 0000001A6780: C800A2FF 2D4CACFF 3B800000
	v_dual_fmac_f32 v75, 0x3b800000, v85 :: v_dual_fmac_f32 v68, 0x3b800000, v84// 0000001A678C: C800AAFF 4B44A8FF 3B800000
	v_dual_mul_f32 v46, v42, v94 :: v_dual_fmac_f32 v67, 0x3b800000, v83// 0000001A6798: C8C0BD2A 2E42A6FF 3B800000
	v_mul_f32_e32 v43, v42, v91                                // 0000001A67A4: 1056B72A
	ds_load_2addr_b32 v[93:94], v139 offset0:60 offset1:62     // 0000001A67A8: D8DC3E3C 5D00008B
	ds_load_b128 v[51:54], v138 offset:9248                    // 0000001A67B0: DBFC2420 3300008A
	ds_load_b128 v[55:58], v138 offset:9264                    // 0000001A67B8: DBFC2430 3700008A
	ds_load_2addr_b32 v[91:92], v139 offset0:56 offset1:58     // 0000001A67C0: D8DC3A38 5B00008B
	v_fmac_f32_e32 v46, 0x3b800000, v82                        // 0000001A67C8: 565CA4FF 3B800000
	ds_store_2addr_b32 v139, v67, v68 offset0:48 offset1:50    // 0000001A67D0: D8383230 0044438B
	v_fmac_f32_e32 v43, 0x3b800000, v79                        // 0000001A67D8: 56569EFF 3B800000
	ds_store_2addr_b32 v139, v43, v44 offset0:40 offset1:42    // 0000001A67E0: D8382A28 002C2B8B
	ds_store_2addr_b32 v139, v45, v46 offset0:44 offset1:46    // 0000001A67E8: D8382E2C 002E2D8B
	ds_load_b128 v[43:46], v138 offset:9216                    // 0000001A67F0: DBFC2400 2B00008A
	ds_load_b128 v[47:50], v138 offset:9232                    // 0000001A67F8: DBFC2410 2F00008A
	ds_load_b128 v[71:74], v138 offset:9328                    // 0000001A6800: DBFC2470 4700008A
	ds_load_b128 v[67:70], v138 offset:9312                    // 0000001A6808: DBFC2460 4300008A
	ds_load_2addr_b32 v[85:86], v139 offset0:68 offset1:70     // 0000001A6810: D8DC4644 5500008B
	ds_store_2addr_b32 v139, v75, v76 offset0:52 offset1:54    // 0000001A6818: D8383634 004C4B8B
	ds_load_2addr_b32 v[83:84], v139 offset0:64 offset1:66     // 0000001A6820: D8DC4240 5300008B
	s_waitcnt lgkmcnt(10)                                      // 0000001A6828: BF89FCA7
	v_mul_f32_e32 v95, v42, v91                                // 0000001A682C: 10BEB72A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_4) | instid1(VALU_DEP_2)// 0000001A6830: BF870151
	v_fmac_f32_e32 v95, 0x3b800000, v87                        // 0000001A6834: 56BEAEFF 3B800000
	s_waitcnt lgkmcnt(5)                                       // 0000001A683C: BF89FC57
	v_wmma_f32_16x16x16_f16 v[75:82], v[43:50], v[1:8], v[33:40]// 0000001A6840: CC40404B 1C86032B
	s_waitcnt lgkmcnt(2)                                       // 0000001A6848: BF89FC27
	v_mul_f32_e32 v97, v42, v86                                // 0000001A684C: 10C2AD2A
	v_wmma_f32_16x16x16_f16 v[75:82], v[51:58], v[17:24], v[75:82]// 0000001A6850: CC40404B 1D2E2333
	ds_load_b128 v[51:54], v138 offset:11552                   // 0000001A6858: DBFC2D20 3300008A
	ds_load_b128 v[55:58], v138 offset:11568                   // 0000001A6860: DBFC2D30 3700008A
	v_wmma_f32_16x16x16_f16 v[75:82], v[59:66], v[9:16], v[75:82]// 0000001A6868: CC40404B 1D2E133B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001A6870: BF8701B1
	v_wmma_f32_16x16x16_f16 v[75:82], v[67:74], v[25:32], v[75:82]// 0000001A6874: CC40404B 1D2E3343
	v_mul_f32_e32 v87, v42, v92                                // 0000001A687C: 10AEB92A
	v_mul_f32_e32 v92, v42, v93                                // 0000001A6880: 10B8BB2A
	v_dual_mul_f32 v96, v42, v85 :: v_dual_fmac_f32 v97, 0x3b800000, v78// 0000001A6884: C8C0AB2A 60609CFF 3B800000
	v_mul_f32_e32 v93, v42, v94                                // 0000001A6890: 10BABD2A
	s_waitcnt lgkmcnt(2)                                       // 0000001A6894: BF89FC27
	v_mul_f32_e32 v94, v42, v83                                // 0000001A6898: 10BCA72A
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A689C: BF870003
	v_fmac_f32_e32 v96, 0x3b800000, v77                        // 0000001A68A0: 56C09AFF 3B800000
	ds_load_2addr_b32 v[77:78], v139 offset0:84 offset1:86     // 0000001A68A8: D8DC5654 4D00008B
	v_fmac_f32_e32 v93, 0x3b800000, v90                        // 0000001A68B0: 56BAB4FF 3B800000
	ds_load_2addr_b32 v[90:91], v139 offset0:72 offset1:74     // 0000001A68B8: D8DC4A48 5A00008B
	ds_load_b128 v[43:46], v138 offset:11520                   // 0000001A68C0: DBFC2D00 2B00008A
	ds_load_b128 v[47:50], v138 offset:11536                   // 0000001A68C8: DBFC2D10 2F00008A
	v_dual_fmac_f32 v94, 0x3b800000, v75 :: v_dual_fmac_f32 v87, 0x3b800000, v88// 0000001A68D0: C80096FF 5E56B0FF 3B800000
	v_fmac_f32_e32 v92, 0x3b800000, v89                        // 0000001A68DC: 56B8B2FF 3B800000
	ds_store_2addr_b32 v139, v95, v87 offset0:56 offset1:58    // 0000001A68E4: D8383A38 00575F8B
	ds_store_2addr_b32 v139, v92, v93 offset0:60 offset1:62    // 0000001A68EC: D8383E3C 005D5C8B
	ds_load_2addr_b32 v[92:93], v139 offset0:76 offset1:78     // 0000001A68F4: D8DC4E4C 5C00008B
	ds_load_b128 v[63:66], v138 offset:11600                   // 0000001A68FC: DBFC2D50 3F00008A
	ds_load_b128 v[59:62], v138 offset:11584                   // 0000001A6904: DBFC2D40 3B00008A
	s_waitcnt lgkmcnt(7)                                       // 0000001A690C: BF89FC77
	v_mul_f32_e32 v98, v42, v90                                // 0000001A6910: 10C4B52A
	v_mul_f32_e32 v95, v42, v84                                // 0000001A6914: 10BEA92A
	s_waitcnt lgkmcnt(5)                                       // 0000001A6918: BF89FC57
	v_wmma_f32_16x16x16_f16 v[83:90], v[43:50], v[1:8], v[33:40]// 0000001A691C: CC404053 1C86032B
	v_mul_f32_e32 v43, v42, v91                                // 0000001A6924: 1056B72A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001A6928: BF8701B2
	v_wmma_f32_16x16x16_f16 v[83:90], v[51:58], v[17:24], v[83:90]// 0000001A692C: CC404053 1D4E2333
	s_waitcnt lgkmcnt(2)                                       // 0000001A6934: BF89FC27
	v_mul_f32_e32 v91, v42, v92                                // 0000001A6938: 10B6B92A
	v_dual_fmac_f32 v43, 0x3b800000, v80 :: v_dual_fmac_f32 v98, 0x3b800000, v79// 0000001A693C: C800A0FF 2B629EFF 3B800000
	v_fmac_f32_e32 v95, 0x3b800000, v76                        // 0000001A6948: 56BE98FF 3B800000
	ds_load_b128 v[71:74], v138 offset:11632                   // 0000001A6950: DBFC2D70 4700008A
	ds_load_b128 v[67:70], v138 offset:11616                   // 0000001A6958: DBFC2D60 4300008A
	ds_load_2addr_b32 v[75:76], v139 offset0:80 offset1:82     // 0000001A6960: D8DC5250 4B00008B
	ds_load_2addr_b32 v[79:80], v139 offset0:88 offset1:90     // 0000001A6968: D8DC5A58 4F00008B
	s_waitcnt lgkmcnt(4)                                       // 0000001A6970: BF89FC47
	v_wmma_f32_16x16x16_f16 v[83:90], v[59:66], v[9:16], v[83:90]// 0000001A6974: CC404053 1D4E133B
	ds_store_2addr_b32 v139, v96, v97 offset0:68 offset1:70    // 0000001A697C: D8384644 0061608B
	ds_store_2addr_b32 v139, v98, v43 offset0:72 offset1:74    // 0000001A6984: D8384A48 002B628B
	ds_load_b128 v[43:46], v138 offset:13824                   // 0000001A698C: DBFC3600 2B00008A
	ds_load_b128 v[47:50], v138 offset:13840                   // 0000001A6994: DBFC3610 2F00008A
	v_dual_fmac_f32 v91, 0x3b800000, v81 :: v_dual_mul_f32 v96, v42, v78// 0000001A699C: C806A2FF 5B609D2A 3B800000
	ds_store_2addr_b32 v139, v94, v95 offset0:64 offset1:66    // 0000001A69A8: D8384240 005F5E8B
	v_mul_f32_e32 v95, v42, v77                                // 0000001A69B0: 10BE9B2A
	s_waitcnt lgkmcnt(7)                                       // 0000001A69B4: BF89FC77
	v_wmma_f32_16x16x16_f16 v[83:90], v[67:74], v[25:32], v[83:90]// 0000001A69B8: CC404053 1D4E3343
	s_waitcnt lgkmcnt(6)                                       // 0000001A69C0: BF89FC67
	v_mul_f32_e32 v67, v42, v75                                // 0000001A69C4: 1086972A
	s_waitcnt lgkmcnt(5)                                       // 0000001A69C8: BF89FC57
	v_mul_f32_e32 v98, v42, v80                                // 0000001A69CC: 10C4A12A
	v_mul_f32_e32 v59, v42, v93                                // 0000001A69D0: 1076BB2A
	v_mul_f32_e32 v68, v42, v76                                // 0000001A69D4: 1088992A
	v_dual_fmac_f32 v96, 0x3b800000, v86 :: v_dual_fmac_f32 v67, 0x3b800000, v83// 0000001A69D8: C800ACFF 6042A6FF 3B800000
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A69E4: BF870193
	v_dual_fmac_f32 v98, 0x3b800000, v88 :: v_dual_fmac_f32 v59, 0x3b800000, v82// 0000001A69E8: C800B0FF 623AA4FF 3B800000
	v_fmac_f32_e32 v68, 0x3b800000, v84                        // 0000001A69F4: 5688A8FF 3B800000
	ds_load_b128 v[51:54], v138 offset:13856                   // 0000001A69FC: DBFC3620 3300008A
	ds_load_b128 v[55:58], v138 offset:13872                   // 0000001A6A04: DBFC3630 3700008A
	ds_load_2addr_b32 v[83:84], v139 offset0:92 offset1:94     // 0000001A6A0C: D8DC5E5C 5300008B
	v_mul_f32_e32 v97, v42, v79                                // 0000001A6A14: 10C29F2A
	s_waitcnt lgkmcnt(4)                                       // 0000001A6A18: BF89FC47
	v_wmma_f32_16x16x16_f16 v[75:82], v[43:50], v[1:8], v[33:40]// 0000001A6A1C: CC40404B 1C86032B
	ds_store_2addr_b32 v139, v91, v59 offset0:76 offset1:78    // 0000001A6A24: D8384E4C 003B5B8B
	ds_load_b128 v[63:66], v138 offset:13904                   // 0000001A6A2C: DBFC3650 3F00008A
	ds_load_b128 v[59:62], v138 offset:13888                   // 0000001A6A34: DBFC3640 3B00008A
	ds_store_2addr_b32 v139, v67, v68 offset0:80 offset1:82    // 0000001A6A3C: D8385250 0044438B
	ds_load_b128 v[71:74], v138 offset:13936                   // 0000001A6A44: DBFC3670 4700008A
	ds_load_b128 v[67:70], v138 offset:13920                   // 0000001A6A4C: DBFC3660 4300008A
	ds_load_2addr_b32 v[91:92], v139 offset0:96 offset1:98     // 0000001A6A54: D8DC6260 5B00008B
	v_fmac_f32_e32 v95, 0x3b800000, v85                        // 0000001A6A5C: 56BEAAFF 3B800000
	ds_load_2addr_b32 v[85:86], v139 offset0:100 offset1:102   // 0000001A6A64: D8DC6664 5500008B
	ds_load_b128 v[43:46], v138 offset:16128                   // 0000001A6A6C: DBFC3F00 2B00008A
	ds_load_b128 v[47:50], v138 offset:16144                   // 0000001A6A74: DBFC3F10 2F00008A
	v_fmac_f32_e32 v97, 0x3b800000, v87                        // 0000001A6A7C: 56C2AEFF 3B800000
	ds_load_2addr_b32 v[93:94], v139 offset0:104 offset1:106   // 0000001A6A84: D8DC6A68 5D00008B
	s_waitcnt lgkmcnt(12)                                      // 0000001A6A8C: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[75:82], v[51:58], v[17:24], v[75:82]// 0000001A6A90: CC40404B 1D2E2333
	ds_load_b128 v[51:54], v138 offset:16160                   // 0000001A6A98: DBFC3F20 3300008A
	ds_load_b128 v[55:58], v138 offset:16176                   // 0000001A6AA0: DBFC3F30 3700008A
	s_waitcnt lgkmcnt(13)                                      // 0000001A6AA8: BF89FCD7
	v_mul_f32_e32 v99, v42, v83                                // 0000001A6AAC: 10C6A72A
	s_waitcnt lgkmcnt(10)                                      // 0000001A6AB0: BF89FCA7
	v_wmma_f32_16x16x16_f16 v[75:82], v[59:66], v[9:16], v[75:82]// 0000001A6AB4: CC40404B 1D2E133B
	ds_load_b128 v[63:66], v138 offset:16208                   // 0000001A6ABC: DBFC3F50 3F00008A
	ds_load_b128 v[59:62], v138 offset:16192                   // 0000001A6AC4: DBFC3F40 3B00008A
	s_waitcnt lgkmcnt(8)                                       // 0000001A6ACC: BF89FC87
	v_mul_f32_e32 v100, v42, v92                               // 0000001A6AD0: 10C8B92A
	s_waitcnt lgkmcnt(7)                                       // 0000001A6AD4: BF89FC77
	v_mul_f32_e32 v102, v42, v86                               // 0000001A6AD8: 10CCAD2A
	ds_store_2addr_b32 v139, v95, v96 offset0:84 offset1:86    // 0000001A6ADC: D8385654 00605F8B
	ds_store_2addr_b32 v139, v97, v98 offset0:88 offset1:90    // 0000001A6AE4: D8385A58 0062618B
	v_wmma_f32_16x16x16_f16 v[75:82], v[67:74], v[25:32], v[75:82]// 0000001A6AEC: CC40404B 1D2E3343
	v_mul_f32_e32 v98, v42, v91                                // 0000001A6AF4: 10C4B72A
	v_mul_f32_e32 v97, v42, v84                                // 0000001A6AF8: 10C2A92A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A6AFC: BF870193
	v_dual_mul_f32 v101, v42, v85 :: v_dual_fmac_f32 v100, 0x3b800000, v76// 0000001A6B00: C8C0AB2A 656498FF 3B800000
	v_fmac_f32_e32 v98, 0x3b800000, v75                        // 0000001A6B0C: 56C496FF 3B800000
	ds_load_2addr_b32 v[75:76], v139 offset0:108 offset1:110   // 0000001A6B14: D8DC6E6C 4B00008B
	ds_load_b128 v[71:74], v138 offset:16240                   // 0000001A6B1C: DBFC3F70 4700008A
	ds_load_b128 v[67:70], v138 offset:16224                   // 0000001A6B24: DBFC3F60 4300008A
	ds_load_2addr_b32 v[91:92], v139 offset0:112 offset1:114   // 0000001A6B2C: D8DC7270 5B00008B
	ds_load_2addr_b32 v[95:96], v139 offset0:116 offset1:118   // 0000001A6B34: D8DC7674 5F00008B
	v_fmac_f32_e32 v99, 0x3b800000, v89                        // 0000001A6B3C: 56C6B2FF 3B800000
	v_fmac_f32_e32 v97, 0x3b800000, v90                        // 0000001A6B44: 56C2B4FF 3B800000
	s_waitcnt lgkmcnt(12)                                      // 0000001A6B4C: BF89FCC7
	v_wmma_f32_16x16x16_f16 v[83:90], v[43:50], v[1:8], v[33:40]// 0000001A6B50: CC404053 1C86032B
	ds_load_2addr_b32 v[3:4], v139 offset0:124 offset1:126     // 0000001A6B58: D8DC7E7C 0300008B
	ds_load_2addr_b32 v[1:2], v139 offset0:120 offset1:122     // 0000001A6B60: D8DC7A78 0100008B
	s_waitcnt lgkmcnt(13)                                      // 0000001A6B68: BF89FCD7
	v_mul_f32_e32 v5, v42, v94                                 // 0000001A6B6C: 100ABD2A
	s_waitcnt lgkmcnt(11)                                      // 0000001A6B70: BF89FCB7
	v_wmma_f32_16x16x16_f16 v[83:90], v[51:58], v[17:24], v[83:90]// 0000001A6B74: CC404053 1D4E2333
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A6B7C: BF870122
	v_dual_fmac_f32 v102, 0x3b800000, v78 :: v_dual_fmac_f32 v5, 0x3b800000, v80// 0000001A6B80: C8009CFF 6604A0FF 3B800000
	s_waitcnt lgkmcnt(9)                                       // 0000001A6B8C: BF89FC97
	v_wmma_f32_16x16x16_f16 v[83:90], v[59:66], v[9:16], v[83:90]// 0000001A6B90: CC404053 1D4E133B
	s_waitcnt lgkmcnt(6)                                       // 0000001A6B98: BF89FC67
	v_mul_f32_e32 v6, v42, v76                                 // 0000001A6B9C: 100C992A
	s_waitcnt lgkmcnt(4)                                       // 0000001A6BA0: BF89FC47
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A6BA4: BF870002
	v_wmma_f32_16x16x16_f16 v[83:90], v[67:74], v[25:32], v[83:90]// 0000001A6BA8: CC404053 1D4E3343
	s_waitcnt lgkmcnt(3)                                       // 0000001A6BB0: BF89FC37
	v_mul_f32_e32 v7, v42, v91                                 // 0000001A6BB4: 100EB72A
	s_waitcnt lgkmcnt(2)                                       // 0000001A6BB8: BF89FC27
	v_mul_f32_e32 v10, v42, v96                                // 0000001A6BBC: 1014C12A
	v_mul_f32_e32 v8, v42, v92                                 // 0000001A6BC0: 1010B92A
	v_dual_mul_f32 v9, v42, v95 :: v_dual_fmac_f32 v6, 0x3b800000, v82// 0000001A6BC4: C8C0BF2A 0906A4FF 3B800000
	s_waitcnt lgkmcnt(1)                                       // 0000001A6BD0: BF89FC17
	v_dual_fmac_f32 v7, 0x3b800000, v83 :: v_dual_mul_f32 v4, v42, v4// 0000001A6BD4: C806A6FF 0704092A 3B800000
	v_mul_f32_e32 v93, v42, v93                                // 0000001A6BE0: 10BABB2A
	s_waitcnt lgkmcnt(0)                                       // 0000001A6BE4: BF89FC07
	v_mul_f32_e32 v2, v42, v2                                  // 0000001A6BE8: 1004052A
	v_mul_f32_e32 v1, v42, v1                                  // 0000001A6BEC: 1002032A
	v_dual_mul_f32 v3, v42, v3 :: v_dual_fmac_f32 v4, 0x3b800000, v90// 0000001A6BF0: C8C0072A 0304B4FF 3B800000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A6BFC: BF870003
	v_dual_fmac_f32 v93, 0x3b800000, v79 :: v_dual_fmac_f32 v2, 0x3b800000, v88// 0000001A6C00: C8009EFF 5D02B0FF 3B800000
	v_fmac_f32_e32 v101, 0x3b800000, v77                       // 0000001A6C0C: 56CA9AFF 3B800000
	ds_store_2addr_b32 v139, v101, v102 offset0:100 offset1:102// 0000001A6C14: D8386664 0066658B
	ds_store_2addr_b32 v139, v93, v5 offset0:104 offset1:106   // 0000001A6C1C: D8386A68 00055D8B
	v_dual_mul_f32 v5, v42, v75 :: v_dual_fmac_f32 v8, 0x3b800000, v84// 0000001A6C24: C8C0972A 0508A8FF 3B800000
	v_dual_fmac_f32 v9, 0x3b800000, v85 :: v_dual_fmac_f32 v10, 0x3b800000, v86// 0000001A6C30: C800AAFF 090AACFF 3B800000
	v_fmac_f32_e32 v1, 0x3b800000, v87                         // 0000001A6C3C: 5602AEFF 3B800000
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A6C44: BF870003
	v_fmac_f32_e32 v5, 0x3b800000, v81                         // 0000001A6C48: 560AA2FF 3B800000
	v_fmac_f32_e32 v3, 0x3b800000, v89                         // 0000001A6C50: 5606B2FF 3B800000
	ds_store_2addr_b32 v139, v99, v97 offset0:92 offset1:94    // 0000001A6C58: D8385E5C 0061638B
	ds_store_2addr_b32 v139, v98, v100 offset0:96 offset1:98   // 0000001A6C60: D8386260 0064628B
	ds_store_2addr_b32 v139, v5, v6 offset0:108 offset1:110    // 0000001A6C68: D8386E6C 0006058B
	ds_store_2addr_b32 v139, v7, v8 offset0:112 offset1:114    // 0000001A6C70: D8387270 0008078B
	ds_store_2addr_b32 v139, v9, v10 offset0:116 offset1:118   // 0000001A6C78: D8387674 000A098B
	ds_store_2addr_b32 v139, v1, v2 offset0:120 offset1:122    // 0000001A6C80: D8387A78 0002018B
	ds_store_2addr_b32 v139, v3, v4 offset0:124 offset1:126    // 0000001A6C88: D8387E7C 0004038B
	s_and_saveexec_b32 s0, s6                                  // 0000001A6C90: BE802006
	s_cbranch_execz 3                                          // 0000001A6C94: BFA50003 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x72a4>
	s_waitcnt vmcnt(0)                                         // 0000001A6C98: BF8903F7
	ds_store_b32 v107, v41 offset:61952                        // 0000001A6C9C: D834F200 0000296B
	s_or_b32 exec_lo, exec_lo, s0                              // 0000001A6CA4: 8C7E007E
	s_waitcnt vmcnt(0) lgkmcnt(0)                              // 0000001A6CA8: BF890007
	s_barrier                                                  // 0000001A6CAC: BFBD0000
	buffer_gl0_inv                                             // 0000001A6CB0: E0AC0000 00000000
	ds_load_b32 v1, v107 offset:61952                          // 0000001A6CB8: D8D8F200 0100006B
	s_waitcnt lgkmcnt(0)                                       // 0000001A6CC0: BF89FC07
	v_cmp_ne_u32_e32 vcc_lo, 1, v1                             // 0000001A6CC4: 7C9A0281
	s_cbranch_vccz 75                                          // 0000001A6CC8: BFA3004B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x73f8>
	s_cmp_lg_u32 s29, s52                                      // 0000001A6CCC: BF07341D
	s_cbranch_scc0 1698                                        // 0000001A6CD0: BFA106A2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8d5c>
	s_cmp_lg_u32 s29, s53                                      // 0000001A6CD4: BF07351D
	s_cbranch_scc0 1727                                        // 0000001A6CD8: BFA106BF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8dd8>
	s_cmp_lg_u32 s29, s54                                      // 0000001A6CDC: BF07361D
	s_cbranch_scc1 58543                                       // 0000001A6CE0: BFA2E4AF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a0>
	s_branch 1756                                              // 0000001A6CE4: BFA006DC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8e58>
	s_clause 0x1                                               // 0000001A6CE8: BF850001
	global_load_b128 v[69:72], v[122:123], off offset:48       // 0000001A6CEC: DC5E0030 457C007A
	global_load_b128 v[65:68], v[122:123], off offset:32       // 0000001A6CF4: DC5E0020 417C007A
	ds_load_b128 v[73:76], v136 offset:32                      // 0000001A6CFC: DBFC0020 49000088
	ds_load_b128 v[77:80], v136 offset:48                      // 0000001A6D04: DBFC0030 4D000088
	ds_load_b128 v[85:88], v136 offset:2352                    // 0000001A6D0C: DBFC0930 55000088
	ds_load_b128 v[81:84], v136 offset:2336                    // 0000001A6D14: DBFC0920 51000088
	ds_load_b128 v[194:197], v136 offset:4656                  // 0000001A6D1C: DBFC1230 C2000088
	ds_load_b128 v[190:193], v136 offset:4640                  // 0000001A6D24: DBFC1220 BE000088
	ds_load_b128 v[202:205], v136 offset:6960                  // 0000001A6D2C: DBFC1B30 CA000088
	ds_load_b128 v[198:201], v136 offset:6944                  // 0000001A6D34: DBFC1B20 C6000088
	s_waitcnt vmcnt(0) lgkmcnt(6)                              // 0000001A6D3C: BF890067
	v_wmma_f32_16x16x16_f16 v[57:64], v[65:72], v[73:80], v[57:64]// 0000001A6D40: CC404039 1CE69341
	s_waitcnt lgkmcnt(4)                                       // 0000001A6D48: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[65:72], v[81:88], v[49:56]// 0000001A6D4C: CC404031 1CC6A341
	s_waitcnt lgkmcnt(2)                                       // 0000001A6D54: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[65:72], v[190:197], v[41:48]// 0000001A6D58: CC404029 1CA77D41
	s_waitcnt lgkmcnt(0)                                       // 0000001A6D60: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[65:72], v[198:205], v[33:40]// 0000001A6D64: CC404021 1C878D41
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6D6C: 8C7E0F7E
	s_and_saveexec_b32 s15, s5                                 // 0000001A6D70: BE8F2005
	s_cbranch_execz 64305                                      // 0000001A6D74: BFA5FB31 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x603c>
	ds_load_b128 v[65:68], v136 offset:64                      // 0000001A6D78: DBFC0040 41000088
	ds_load_b128 v[69:72], v136 offset:80                      // 0000001A6D80: DBFC0050 45000088
	ds_load_b128 v[77:80], v136 offset:2384                    // 0000001A6D88: DBFC0950 4D000088
	ds_load_b128 v[73:76], v136 offset:2368                    // 0000001A6D90: DBFC0940 49000088
	ds_load_b128 v[85:88], v136 offset:4688                    // 0000001A6D98: DBFC1250 55000088
	ds_load_b128 v[81:84], v136 offset:4672                    // 0000001A6DA0: DBFC1240 51000088
	ds_load_b128 v[194:197], v136 offset:6992                  // 0000001A6DA8: DBFC1B50 C2000088
	ds_load_b128 v[190:193], v136 offset:6976                  // 0000001A6DB0: DBFC1B40 BE000088
	s_waitcnt vmcnt(2) lgkmcnt(6)                              // 0000001A6DB8: BF890867
	v_wmma_f32_16x16x16_f16 v[57:64], v[97:104], v[65:72], v[57:64]// 0000001A6DBC: CC404039 1CE68361
	s_waitcnt lgkmcnt(4)                                       // 0000001A6DC4: BF89FC47
	v_wmma_f32_16x16x16_f16 v[49:56], v[97:104], v[73:80], v[49:56]// 0000001A6DC8: CC404031 1CC69361
	s_waitcnt lgkmcnt(2)                                       // 0000001A6DD0: BF89FC27
	v_wmma_f32_16x16x16_f16 v[41:48], v[97:104], v[81:88], v[41:48]// 0000001A6DD4: CC404029 1CA6A361
	s_waitcnt lgkmcnt(0)                                       // 0000001A6DDC: BF89FC07
	v_wmma_f32_16x16x16_f16 v[33:40], v[97:104], v[190:197], v[33:40]// 0000001A6DE0: CC404021 1C877D61
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A6DE8: 8C7E0F7E
	s_and_saveexec_b32 s15, s8                                 // 0000001A6DEC: BE8F2008
	s_cbranch_execnz 64277                                     // 0000001A6DF0: BFA6FB15 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6048>
	s_branch 64306                                             // 0000001A6DF4: BFA0FB32 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x60c0>
	v_or_b32_e32 v32, 1, v181                                  // 0000001A6DF8: 38416A81
	v_or_b32_e32 v31, 2, v181                                  // 0000001A6DFC: 383F6A82
	v_or_b32_e32 v30, 3, v181                                  // 0000001A6E00: 383D6A83
	buffer_gl1_inv                                             // 0000001A6E04: E0B00000 00000000
	buffer_gl0_inv                                             // 0000001A6E0C: E0AC0000 00000000
	s_clause 0x3                                               // 0000001A6E14: BF850003
	global_load_u16 v27, v[108:109], off                       // 0000001A6E18: DC4A0000 1B7C006C
	global_load_u16 v28, v[108:109], off offset:64             // 0000001A6E20: DC4A0040 1C7C006C
	global_load_u16 v29, v[108:109], off offset:128            // 0000001A6E28: DC4A0080 1D7C006C
	global_load_u16 v33, v[108:109], off offset:192            // 0000001A6E30: DC4A00C0 217C006C
	v_min_i32_e32 v1, s71, v32                                 // 0000001A6E38: 22024047
	v_min_i32_e32 v3, s71, v31                                 // 0000001A6E3C: 22063E47
	s_mov_b32 s12, exec_lo                                     // 0000001A6E40: BE8C007E
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A6E44: BF870112
	v_mad_i64_i32 v[1:2], null, 0x1800, v1, v[110:111]         // 0000001A6E48: D6FF7C01 05BA02FF 00001800
	v_mad_i64_i32 v[3:4], null, 0x1800, v3, v[110:111]         // 0000001A6E54: D6FF7C03 05BA06FF 00001800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A6E60: BF870112
	.long 0xd73c0001                                           // 0000001A6E64: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000001A6E68: 02020281
	.long 0xd73c0003                                           // 0000001A6E6C: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000001A6E70: 02020681
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A6E74: BF870092
	.long 0xd7006a05                                           // 0000001A6E78: D7006A05
	v_cndmask_b32_e32 v1, s22, v1, vcc_lo                      // 0000001A6E7C: 02020216
	v_add_co_ci_u32_e64 v6, null, s23, v2, vcc_lo              // 0000001A6E80: D5207C06 01AA0417
	.long 0xd7006a01                                           // 0000001A6E88: D7006A01
	v_cndmask_b32_e32 v1, s26, v1, vcc_lo                      // 0000001A6E8C: 0202021A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A6E90: BF870001
	v_add_co_ci_u32_e64 v2, null, s27, v2, vcc_lo              // 0000001A6E94: D5207C02 01AA041B
	s_clause 0x3                                               // 0000001A6E9C: BF850003
	global_load_d16_b16 v21, v[5:6], off                       // 0000001A6EA0: DC820000 157C0005
	global_load_d16_b16 v22, v[5:6], off offset:64             // 0000001A6EA8: DC820040 167C0005
	global_load_d16_b16 v23, v[5:6], off offset:128            // 0000001A6EB0: DC820080 177C0005
	global_load_d16_b16 v24, v[5:6], off offset:192            // 0000001A6EB8: DC8200C0 187C0005
	s_clause 0x3                                               // 0000001A6EC0: BF850003
	global_load_d16_b16 v20, v[1:2], off                       // 0000001A6EC4: DC820000 147C0001
	global_load_d16_b16 v19, v[1:2], off offset:64             // 0000001A6ECC: DC820040 137C0001
	global_load_d16_b16 v18, v[1:2], off offset:128            // 0000001A6ED4: DC820080 127C0001
	global_load_d16_b16 v17, v[1:2], off offset:192            // 0000001A6EDC: DC8200C0 117C0001
	v_min_i32_e32 v5, s71, v30                                 // 0000001A6EE4: 220A3C47
	.long 0xd7006a01                                           // 0000001A6EE8: D7006A01
	v_cndmask_b32_e32 v1, s22, v3, vcc_lo                      // 0000001A6EEC: 02020616
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A6EF0: BF870191
	v_add_co_ci_u32_e64 v2, null, s23, v4, vcc_lo              // 0000001A6EF4: D5207C02 01AA0817
	v_mad_i64_i32 v[5:6], null, 0x1800, v5, v[110:111]         // 0000001A6EFC: D6FF7C05 05BA0AFF 00001800
	.long 0xd7006a03                                           // 0000001A6F08: D7006A03
	v_cndmask_b32_e32 v1, s26, v3, vcc_lo                      // 0000001A6F0C: 0202061A
	s_clause 0x3                                               // 0000001A6F10: BF850003
	global_load_d16_b16 v13, v[1:2], off                       // 0000001A6F14: DC820000 0D7C0001
	global_load_d16_b16 v14, v[1:2], off offset:64             // 0000001A6F1C: DC820040 0E7C0001
	global_load_d16_b16 v15, v[1:2], off offset:128            // 0000001A6F24: DC820080 0F7C0001
	global_load_d16_b16 v16, v[1:2], off offset:192            // 0000001A6F2C: DC8200C0 107C0001
	v_add_co_ci_u32_e64 v4, null, s27, v4, vcc_lo              // 0000001A6F34: D5207C04 01AA081B
	s_clause 0x3                                               // 0000001A6F3C: BF850003
	global_load_d16_b16 v12, v[3:4], off                       // 0000001A6F40: DC820000 0C7C0003
	global_load_d16_b16 v11, v[3:4], off offset:64             // 0000001A6F48: DC820040 0B7C0003
	global_load_d16_b16 v10, v[3:4], off offset:128            // 0000001A6F50: DC820080 0A7C0003
	global_load_d16_b16 v9, v[3:4], off offset:192             // 0000001A6F58: DC8200C0 097C0003
	.long 0xd73c0001                                           // 0000001A6F60: D73C0001
	v_cndmask_b32_e32 v1, 1, v5, vcc_lo                        // 0000001A6F64: 02020A81
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A6F68: BF870091
	.long 0xd7006a03                                           // 0000001A6F6C: D7006A03
	v_cndmask_b32_e32 v1, s22, v1, vcc_lo                      // 0000001A6F70: 02020216
	v_add_co_ci_u32_e64 v4, null, s23, v2, vcc_lo              // 0000001A6F74: D5207C04 01AA0417
	.long 0xd7006a19                                           // 0000001A6F7C: D7006A19
	v_cndmask_b32_e32 v1, s26, v1, vcc_lo                      // 0000001A6F80: 0202021A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A6F84: BF870001
	v_add_co_ci_u32_e64 v26, null, s27, v2, vcc_lo             // 0000001A6F88: D5207C1A 01AA041B
	s_clause 0x3                                               // 0000001A6F90: BF850003
	global_load_d16_b16 v5, v[3:4], off                        // 0000001A6F94: DC820000 057C0003
	global_load_d16_b16 v6, v[3:4], off offset:64              // 0000001A6F9C: DC820040 067C0003
	global_load_d16_b16 v7, v[3:4], off offset:128             // 0000001A6FA4: DC820080 077C0003
	global_load_d16_b16 v8, v[3:4], off offset:192             // 0000001A6FAC: DC8200C0 087C0003
	s_clause 0x3                                               // 0000001A6FB4: BF850003
	global_load_d16_b16 v4, v[25:26], off                      // 0000001A6FB8: DC820000 047C0019
	global_load_d16_b16 v3, v[25:26], off offset:64            // 0000001A6FC0: DC820040 037C0019
	global_load_d16_b16 v2, v[25:26], off offset:128           // 0000001A6FC8: DC820080 027C0019
	global_load_d16_b16 v1, v[25:26], off offset:192           // 0000001A6FD0: DC8200C0 017C0019
	s_waitcnt vmcnt(27)                                        // 0000001A6FD8: BF896FF7
	v_lshlrev_b32_e32 v25, 16, v27                             // 0000001A6FDC: 30323690
	s_waitcnt vmcnt(26)                                        // 0000001A6FE0: BF896BF7
	v_lshlrev_b32_e32 v26, 16, v28                             // 0000001A6FE4: 30343890
	s_waitcnt vmcnt(25)                                        // 0000001A6FE8: BF8967F7
	v_lshlrev_b32_e32 v27, 16, v29                             // 0000001A6FEC: 30363A90
	s_waitcnt vmcnt(24)                                        // 0000001A6FF0: BF8963F7
	v_lshlrev_b32_e32 v28, 16, v33                             // 0000001A6FF4: 30384290
	v_xor_b32_e32 v29, 31, v180                                // 0000001A6FF8: 3A3B689F
	.long 0xd4c4007e                                           // 0000001A6FFC: D4C4007E
	v_cndmask_b32_e32 v1, s67, v181, vcc_lo                    // 0000001A7000: 02036A43
	s_cbranch_execnz 2270                                      // 0000001A7004: BFA608DE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x9980>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A7008: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A700C: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001A7010: BE8C007E
	.long 0xd4c4007e                                           // 0000001A7014: D4C4007E
	v_cndmask_b32_e32 v1, s67, v32, vcc_lo                     // 0000001A7018: 02024043
	s_cbranch_execnz 2567                                      // 0000001A701C: BFA60A07 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x9e3c>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A7020: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A7024: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001A7028: BE8C007E
	.long 0xd4c4007e                                           // 0000001A702C: D4C4007E
	v_cndmask_b32_e32 v1, s67, v31, vcc_lo                     // 0000001A7030: 02023E43
	s_cbranch_execnz 2837                                      // 0000001A7034: BFA60B15 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xa28c>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A7038: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A703C: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001A7040: BE8C007E
	.long 0xd4c4007e                                           // 0000001A7044: D4C4007E
	v_cndmask_b32_e32 v1, s67, v30, vcc_lo                     // 0000001A7048: 02023C43
	s_cbranch_execz 269                                        // 0000001A704C: BFA5010D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7a84>
	s_waitcnt vmcnt(6)                                         // 0000001A7050: BF891BF7
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000001A7054: 300C0C90
	s_waitcnt vmcnt(5)                                         // 0000001A7058: BF8917F7
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000001A705C: 300E0E90
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001A7060: 7C983A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A7064: BF870193
	v_dual_mul_f32 v12, v6, v6 :: v_dual_lshlrev_b32 v5, 16, v5// 0000001A7068: C8E20D06 0C040A90
	v_mul_f32_e32 v10, v7, v7                                  // 0000001A7070: 10140F07
	s_waitcnt vmcnt(4)                                         // 0000001A7074: BF8913F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 0000001A7078: 30101090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A707C: BF8701A3
	v_mul_f32_e32 v11, v5, v5                                  // 0000001A7080: 10160B05
	v_and_b32_e32 v13, 16, v29                                 // 0000001A7084: 361A3A90
	v_mul_f32_e32 v9, v8, v8                                   // 0000001A7088: 10121108
	s_waitcnt vmcnt(3)                                         // 0000001A708C: BF890FF7
	v_lshlrev_b32_e32 v4, 16, v4                               // 0000001A7090: 30080890
	v_add_f32_e32 v10, v11, v10                                // 0000001A7094: 0614150B
	v_add_lshl_u32 v11, v13, v180, 2                           // 0000001A7098: D647000B 020B690D
	v_add_f32_e32 v9, v12, v9                                  // 0000001A70A0: 0612130C
	s_waitcnt vmcnt(1)                                         // 0000001A70A4: BF8907F7
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000001A70A8: 30040490
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A70AC: BF870112
	v_dual_add_f32 v9, v10, v9 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 0000001A70B0: C906130A 090408FF BFB8AA3B
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 0000001A70BC: 100404FF BFB8AA3B
	ds_bpermute_b32 v10, v11, v9                               // 0000001A70C4: DACC0000 0A00090B
	v_cndmask_b32_e64 v11, 8, 0, vcc_lo                        // 0000001A70CC: D501000B 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001A70D4: 7C983A84
	v_exp_f32_e32 v4, v4                                       // 0000001A70D8: 7E084B04
	v_exp_f32_e32 v2, v2                                       // 0000001A70DC: 7E044B02
	v_lshlrev_b32_e32 v3, 16, v3                               // 0000001A70E0: 30060690
	v_add_lshl_u32 v11, v11, v180, 2                           // 0000001A70E4: D647000B 020B690B
	s_delay_alu instid0(TRANS32_DEP_2)                         // 0000001A70EC: BF870006
	v_add_f32_e32 v4, 1.0, v4                                  // 0000001A70F0: 060808F2
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001A70F4: BF870185
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v3// 0000001A70F8: C90604F2 020206FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A7104: BF870002
	v_div_scale_f32 v14, null, v4, v4, 1.0                     // 0000001A7108: D6FC7C0E 03CA0904
	v_div_scale_f32 v21, s0, 1.0, v4, 1.0                      // 0000001A7110: D6FC0015 03CA08F2
	s_waitcnt lgkmcnt(0)                                       // 0000001A7118: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A711C: 06121509
	v_exp_f32_e32 v3, v3                                       // 0000001A7120: 7E064B03
	v_div_scale_f32 v24, s9, 1.0, v2, 1.0                      // 0000001A7124: D6FC0918 03CA04F2
	v_rcp_f32_e32 v19, v14                                     // 0000001A712C: 7E26550E
	v_div_scale_f32 v16, null, v2, v2, 1.0                     // 0000001A7130: D6FC7C10 03CA0502
	ds_bpermute_b32 v10, v11, v9                               // 0000001A7138: DACC0000 0A00090B
	v_cndmask_b32_e64 v11, 4, 0, vcc_lo                        // 0000001A7140: D501000B 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001A7148: 7C983A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A714C: BF8700A2
	v_add_lshl_u32 v11, v11, v180, 2                           // 0000001A7150: D647000B 020B690B
	v_add_f32_e32 v3, 1.0, v3                                  // 0000001A7158: 060606F2
	v_div_scale_f32 v15, null, v3, v3, 1.0                     // 0000001A715C: D6FC7C0F 03CA0703
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A7164: BF870001
	v_rcp_f32_e32 v20, v15                                     // 0000001A7168: 7E28550F
	s_waitcnt lgkmcnt(0)                                       // 0000001A716C: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A7170: 06121509
	ds_bpermute_b32 v10, v11, v9                               // 0000001A7174: DACC0000 0A00090B
	v_cndmask_b32_e64 v11, 2, 0, vcc_lo                        // 0000001A717C: D501000B 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001A7184: 7C9B689F
	v_fma_f32 v32, -v15, v20, 1.0                              // 0000001A7188: D6130020 23CA290F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A7190: BF870123
	v_add_lshl_u32 v11, v11, v180, 2                           // 0000001A7194: D647000B 020B690B
	s_waitcnt lgkmcnt(0)                                       // 0000001A719C: BF89FC07
	v_dual_fmac_f32 v20, v32, v20 :: v_dual_add_f32 v9, v9, v10// 0000001A71A0: C8082920 14081509
	ds_bpermute_b32 v10, v11, v9                               // 0000001A71A8: DACC0000 0A00090B
	v_add_co_ci_u32_e64 v11, null, 0, v180, vcc_lo             // 0000001A71B0: D5207C0B 01AB6880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A71B8: BF870001
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000001A71BC: 30161682
	s_waitcnt lgkmcnt(0)                                       // 0000001A71C0: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A71C4: 06121509
	ds_bpermute_b32 v10, v11, v9                               // 0000001A71C8: DACC0000 0A00090B
	s_waitcnt lgkmcnt(0)                                       // 0000001A71D0: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A71D4: 06121509
	ds_bpermute_b32 v9, v107, v9                               // 0000001A71D8: DACC0000 0900096B
	s_waitcnt lgkmcnt(0)                                       // 0000001A71E0: BF89FC07
	v_div_scale_f32 v10, null, s62, s62, v9                    // 0000001A71E4: D6FC7C0A 04247C3E
	v_div_scale_f32 v13, vcc_lo, v9, s62, v9                   // 0000001A71EC: D6FC6A0D 04247D09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A71F4: BF870292
	v_rcp_f32_e32 v11, v10                                     // 0000001A71F8: 7E16550A
	v_fma_f32 v12, -v10, v11, 1.0                              // 0000001A71FC: D613000C 23CA170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A7204: BF8700A1
	v_fmac_f32_e32 v11, v12, v11                               // 0000001A7208: 5616170C
	s_waitcnt vmcnt(0)                                         // 0000001A720C: BF8903F7
	v_dual_mul_f32 v12, v13, v11 :: v_dual_lshlrev_b32 v1, 16, v1// 0000001A7210: C8E2170D 0C000290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A7218: BF870091
	v_fma_f32 v18, -v10, v12, v13                              // 0000001A721C: D6130012 2436190A
	v_fmac_f32_e32 v12, v18, v11                               // 0000001A7224: 56181712
	v_rcp_f32_e32 v18, v16                                     // 0000001A7228: 7E245510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A722C: BF870121
	v_fma_f32 v10, -v10, v12, v13                              // 0000001A7230: D613000A 2436190A
	v_fma_f32 v13, -v14, v19, 1.0                              // 0000001A7238: D613000D 23CA270E
	v_div_fmas_f32 v10, v10, v11, v12                          // 0000001A7240: D637000A 0432170A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A7248: BF870125
	v_fma_f32 v11, -v16, v18, 1.0                              // 0000001A724C: D613000B 23CA2510
	s_mov_b32 vcc_lo, s0                                       // 0000001A7254: BEEA0000
	v_div_fixup_f32 v9, v10, s62, v9                           // 0000001A7258: D6270009 04247D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A7260: BF870091
	v_dual_fmac_f32 v18, v11, v18 :: v_dual_add_f32 v9, 0x358637bd, v9// 0000001A7264: C808250B 120812FF 358637BD
	v_mul_f32_e32 v34, 0x4b800000, v9                          // 0000001A7270: 104412FF 4B800000
	.long 0xd414000b                                           // 0000001A7278: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v9, vcc_lo                 // 0000001A727C: 020212FF 00800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A7284: BF870091
	v_cndmask_b32_e64 v9, v9, v34, s11                         // 0000001A7288: D5010009 002E4509
	v_rsq_f32_e32 v9, v9                                       // 0000001A7290: 7E125D09
	v_fmac_f32_e32 v19, v13, v19                               // 0000001A7294: 5626270D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A7298: BF870091
	v_dual_mul_f32 v1, 0xbfb8aa3b, v1 :: v_dual_mul_f32 v10, v21, v19// 0000001A729C: C8C602FF 010A2715 BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000001A72A8: 7E024B01
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A72AC: BF870001
	v_fma_f32 v32, -v14, v10, v21                              // 0000001A72B0: D6130020 2456150E
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000001A72B8: BF870085
	v_dual_fmac_f32 v10, v32, v19 :: v_dual_add_f32 v1, 1.0, v1// 0000001A72BC: C8082720 0A0002F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A72C4: BF870111
	v_fma_f32 v14, -v14, v10, v21                              // 0000001A72C8: D613000E 2456150E
	v_div_scale_f32 v17, null, v1, v1, 1.0                     // 0000001A72D0: D6FC7C11 03CA0301
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A72D8: BF870112
	v_div_fmas_f32 v10, v14, v19, v10                          // 0000001A72DC: D637000A 042A270E
	v_rcp_f32_e32 v23, v17                                     // 0000001A72E4: 7E2E5511
	v_mul_f32_e32 v14, 0x45800000, v9                          // 0000001A72E8: 101C12FF 45800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A72F0: BF870112
	v_div_fixup_f32 v4, v10, v4, 1.0                           // 0000001A72F4: D6270004 03CA090A
	v_cndmask_b32_e64 v9, v9, v14, s11                         // 0000001A72FC: D5010009 002E1D09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A7304: BF870115
	v_fma_f32 v12, -v17, v23, 1.0                              // 0000001A7308: D613000C 23CA2F11
	v_mul_f32_e32 v7, v9, v7                                   // 0000001A7310: 100E0F09
	v_mul_f32_e32 v6, v9, v6                                   // 0000001A7314: 100C0D09
	v_mul_f32_e32 v8, v9, v8                                   // 0000001A7318: 10101109
	v_mul_f32_e32 v5, v9, v5                                   // 0000001A731C: 100A0B09
	v_fmac_f32_e32 v23, v12, v23                               // 0000001A7320: 562E2F0C
	v_mul_f32_e32 v12, v24, v18                                // 0000001A7324: 10182518
	v_div_scale_f32 v22, s1, 1.0, v3, 1.0                      // 0000001A7328: D6FC0116 03CA06F2
	v_mul_f32_e32 v6, v6, v26                                  // 0000001A7330: 100C3506
	s_mov_b32 vcc_lo, s1                                       // 0000001A7334: BEEA0001
	v_mul_f32_e32 v7, v7, v27                                  // 0000001A7338: 100E3707
	v_fma_f32 v35, -v16, v12, v24                              // 0000001A733C: D6130023 24621910
	v_dual_mul_f32 v8, v8, v28 :: v_dual_mul_f32 v5, v5, v25   // 0000001A7344: C8C63908 08043305
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A734C: BF8701A2
	v_dual_mul_f32 v11, v22, v20 :: v_dual_fmac_f32 v12, v35, v18// 0000001A7350: C8C02916 0B0C2523
	v_div_scale_f32 v31, s10, 1.0, v1, 1.0                     // 0000001A7358: D6FC0A1F 03CA02F2
	v_mul_f32_e32 v4, v4, v5                                   // 0000001A7360: 10080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A7364: BF870213
	v_fma_f32 v33, -v15, v11, v22                              // 0000001A7368: D6130021 245A170F
	v_fma_f32 v16, -v16, v12, v24                              // 0000001A7370: D6130010 24621910
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A7378: BF870194
	v_mul_f32_e32 v13, v31, v23                                // 0000001A737C: 101A2F1F
	v_fmac_f32_e32 v11, v33, v20                               // 0000001A7380: 56162921
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A7384: BF870112
	v_fma_f32 v36, -v17, v13, v31                              // 0000001A7388: D6130024 247E1B11
	v_fma_f32 v15, -v15, v11, v22                              // 0000001A7390: D613000F 245A170F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A7398: BF870112
	v_fmac_f32_e32 v13, v36, v23                               // 0000001A739C: 561A2F24
	v_div_fmas_f32 v11, v15, v20, v11                          // 0000001A73A0: D637000B 042E290F
	s_mov_b32 vcc_lo, s9                                       // 0000001A73A8: BEEA0009
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001A73AC: BF8701C2
	v_fma_f32 v17, -v17, v13, v31                              // 0000001A73B0: D6130011 247E1B11
	v_div_fmas_f32 v12, v16, v18, v12                          // 0000001A73B8: D637000C 04322510
	s_mov_b32 vcc_lo, s10                                      // 0000001A73C0: BEEA000A
	v_div_fixup_f32 v3, v11, v3, 1.0                           // 0000001A73C4: D6270003 03CA070B
	v_div_fmas_f32 v10, v17, v23, v13                          // 0000001A73CC: D637000A 04362F11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A73D4: BF870193
	v_div_fixup_f32 v2, v12, v2, 1.0                           // 0000001A73D8: D6270002 03CA050C
	v_mul_f32_e32 v3, v3, v6                                   // 0000001A73E0: 10060D03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A73E4: BF870193
	v_div_fixup_f32 v1, v10, v1, 1.0                           // 0000001A73E8: D6270001 03CA030A
	v_mul_f32_e32 v5, v2, v7                                   // 0000001A73F0: 100A0F02
	v_bfe_u32 v7, v4, 16, 1                                    // 0000001A73F4: D6100007 02052104
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A73FC: BF870003
	v_mul_f32_e32 v6, v1, v8                                   // 0000001A7400: 100C1101
	v_mad_u64_u32 v[1:2], null, 0x3000, v30, v[114:115]        // 0000001A7404: D6FE7C01 05CA3CFF 00003000
	v_bfe_u32 v8, v3, 16, 1                                    // 0000001A7410: D6100008 02052103
	v_bfe_u32 v9, v5, 16, 1                                    // 0000001A7418: D6100009 02052105
	v_add3_u32 v4, v4, v7, 0x7fff                              // 0000001A7420: D6550004 03FE0F04 00007FFF
	v_bfe_u32 v10, v6, 16, 1                                   // 0000001A742C: D610000A 02052106
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A7434: BF870214
	v_add3_u32 v3, v3, v8, 0x7fff                              // 0000001A7438: D6550003 03FE1103 00007FFF
	v_add3_u32 v5, v5, v9, 0x7fff                              // 0000001A7444: D6550005 03FE1305 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A7450: BF870003
	v_add3_u32 v6, v6, v10, 0x7fff                             // 0000001A7454: D6550006 03FE1506 00007FFF
	s_clause 0x3                                               // 0000001A7460: BF850003
	global_store_d16_hi_b16 v[1:2], v4, off                    // 0000001A7464: DC960000 007C0401
	global_store_d16_hi_b16 v[1:2], v3, off offset:64          // 0000001A746C: DC960040 007C0301
	global_store_d16_hi_b16 v[1:2], v5, off offset:128         // 0000001A7474: DC960080 007C0501
	global_store_d16_hi_b16 v[1:2], v6, off offset:192         // 0000001A747C: DC9600C0 007C0601
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A7484: 8C7E0C7E
	v_or_b32_e32 v32, 5, v181                                  // 0000001A7488: 38416A85
	v_or_b32_e32 v31, 6, v181                                  // 0000001A748C: 383F6A86
	v_or_b32_e32 v30, 7, v181                                  // 0000001A7490: 383D6A87
	s_mov_b32 s12, exec_lo                                     // 0000001A7494: BE8C007E
	s_waitcnt vmcnt(0)                                         // 0000001A7498: BF8903F7
	v_min_i32_e32 v1, s71, v32                                 // 0000001A749C: 22024047
	v_min_i32_e32 v3, s71, v31                                 // 0000001A74A0: 22063E47
	v_min_i32_e32 v9, s71, v30                                 // 0000001A74A4: 22123C47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A74A8: BF870193
	v_mad_i64_i32 v[1:2], null, 0x1800, v1, v[110:111]         // 0000001A74AC: D6FF7C01 05BA02FF 00001800
	v_mad_i64_i32 v[3:4], null, 0x1800, v3, v[110:111]         // 0000001A74B8: D6FF7C03 05BA06FF 00001800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A74C4: BF870112
	.long 0xd73c0001                                           // 0000001A74C8: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000001A74CC: 02020281
	.long 0xd73c0003                                           // 0000001A74D0: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000001A74D4: 02020681
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A74D8: BF870092
	.long 0xd7006a05                                           // 0000001A74DC: D7006A05
	v_cndmask_b32_e32 v1, s22, v1, vcc_lo                      // 0000001A74E0: 02020216
	v_add_co_ci_u32_e64 v6, null, s23, v2, vcc_lo              // 0000001A74E4: D5207C06 01AA0417
	.long 0xd7006a01                                           // 0000001A74EC: D7006A01
	v_cndmask_b32_e32 v1, s26, v1, vcc_lo                      // 0000001A74F0: 0202021A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A74F4: BF870001
	v_add_co_ci_u32_e64 v2, null, s27, v2, vcc_lo              // 0000001A74F8: D5207C02 01AA041B
	s_clause 0x3                                               // 0000001A7500: BF850003
	global_load_d16_b16 v21, v[5:6], off                       // 0000001A7504: DC820000 157C0005
	global_load_d16_b16 v22, v[5:6], off offset:64             // 0000001A750C: DC820040 167C0005
	global_load_d16_b16 v23, v[5:6], off offset:128            // 0000001A7514: DC820080 177C0005
	global_load_d16_b16 v24, v[5:6], off offset:192            // 0000001A751C: DC8200C0 187C0005
	s_clause 0x3                                               // 0000001A7524: BF850003
	global_load_d16_b16 v20, v[1:2], off                       // 0000001A7528: DC820000 147C0001
	global_load_d16_b16 v19, v[1:2], off offset:64             // 0000001A7530: DC820040 137C0001
	global_load_d16_b16 v18, v[1:2], off offset:128            // 0000001A7538: DC820080 127C0001
	global_load_d16_b16 v17, v[1:2], off offset:192            // 0000001A7540: DC8200C0 117C0001
	v_mad_i64_i32 v[1:2], null, 0x1800, v9, v[110:111]         // 0000001A7548: D6FF7C01 05BA12FF 00001800
	.long 0xd7006a07                                           // 0000001A7554: D7006A07
	v_cndmask_b32_e32 v1, s22, v3, vcc_lo                      // 0000001A7558: 02020616
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A755C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s23, v4, vcc_lo              // 0000001A7560: D5207C08 01AA0817
	.long 0xd7006a03                                           // 0000001A7568: D7006A03
	v_cndmask_b32_e32 v1, s26, v3, vcc_lo                      // 0000001A756C: 0202061A
	v_add_co_ci_u32_e64 v4, null, s27, v4, vcc_lo              // 0000001A7570: D5207C04 01AA081B
	.long 0xd73c0001                                           // 0000001A7578: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000001A757C: 02020281
	s_clause 0x3                                               // 0000001A7580: BF850003
	global_load_d16_b16 v12, v[3:4], off                       // 0000001A7584: DC820000 0C7C0003
	global_load_d16_b16 v11, v[3:4], off offset:64             // 0000001A758C: DC820040 0B7C0003
	global_load_d16_b16 v10, v[3:4], off offset:128            // 0000001A7594: DC820080 0A7C0003
	global_load_d16_b16 v9, v[3:4], off offset:192             // 0000001A759C: DC8200C0 097C0003
	s_clause 0x3                                               // 0000001A75A4: BF850003
	global_load_d16_b16 v13, v[7:8], off                       // 0000001A75A8: DC820000 0D7C0007
	global_load_d16_b16 v14, v[7:8], off offset:64             // 0000001A75B0: DC820040 0E7C0007
	global_load_d16_b16 v15, v[7:8], off offset:128            // 0000001A75B8: DC820080 0F7C0007
	global_load_d16_b16 v16, v[7:8], off offset:192            // 0000001A75C0: DC8200C0 107C0007
	.long 0xd7006a03                                           // 0000001A75C8: D7006A03
	v_cndmask_b32_e32 v1, s22, v1, vcc_lo                      // 0000001A75CC: 02020216
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A75D0: BF8700A1
	v_add_co_ci_u32_e64 v4, null, s23, v2, vcc_lo              // 0000001A75D4: D5207C04 01AA0417
	.long 0xd7006a21                                           // 0000001A75DC: D7006A21
	v_cndmask_b32_e32 v1, s26, v1, vcc_lo                      // 0000001A75E0: 0202021A
	v_add_co_ci_u32_e64 v34, null, s27, v2, vcc_lo             // 0000001A75E4: D5207C22 01AA041B
	s_clause 0x3                                               // 0000001A75EC: BF850003
	global_load_d16_b16 v5, v[3:4], off                        // 0000001A75F0: DC820000 057C0003
	global_load_d16_b16 v6, v[3:4], off offset:64              // 0000001A75F8: DC820040 067C0003
	global_load_d16_b16 v7, v[3:4], off offset:128             // 0000001A7600: DC820080 077C0003
	global_load_d16_b16 v8, v[3:4], off offset:192             // 0000001A7608: DC8200C0 087C0003
	s_clause 0x3                                               // 0000001A7610: BF850003
	global_load_d16_b16 v4, v[33:34], off                      // 0000001A7614: DC820000 047C0021
	global_load_d16_b16 v3, v[33:34], off offset:64            // 0000001A761C: DC820040 037C0021
	global_load_d16_b16 v2, v[33:34], off offset:128           // 0000001A7624: DC820080 027C0021
	global_load_d16_b16 v1, v[33:34], off offset:192           // 0000001A762C: DC8200C0 017C0021
	v_or_b32_e32 v33, 4, v181                                  // 0000001A7634: 38436A84
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A7638: BF870001
	.long 0xd4c4007e                                           // 0000001A763C: D4C4007E
	v_cndmask_b32_e32 v1, s67, v33, vcc_lo                     // 0000001A7640: 02024243
	s_cbranch_execnz 2722                                      // 0000001A7644: BFA60AA2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xa6d0>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A7648: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A764C: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001A7650: BE8C007E
	.long 0xd4c4007e                                           // 0000001A7654: D4C4007E
	v_cndmask_b32_e32 v1, s67, v32, vcc_lo                     // 0000001A7658: 02024043
	s_cbranch_execnz 3022                                      // 0000001A765C: BFA60BCE <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xab98>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A7660: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A7664: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001A7668: BE8C007E
	.long 0xd4c4007e                                           // 0000001A766C: D4C4007E
	v_cndmask_b32_e32 v1, s67, v31, vcc_lo                     // 0000001A7670: 02023E43
	s_cbranch_execnz 3292                                      // 0000001A7674: BFA60CDC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xafe8>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A7678: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A767C: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001A7680: BE8C007E
	.long 0xd4c4007e                                           // 0000001A7684: D4C4007E
	v_cndmask_b32_e32 v1, s67, v30, vcc_lo                     // 0000001A7688: 02023C43
	s_cbranch_execz 269                                        // 0000001A768C: BFA5010D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x80c4>
	s_waitcnt vmcnt(6)                                         // 0000001A7690: BF891BF7
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000001A7694: 300C0C90
	s_waitcnt vmcnt(5)                                         // 0000001A7698: BF8917F7
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000001A769C: 300E0E90
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001A76A0: 7C983A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A76A4: BF870193
	v_dual_mul_f32 v12, v6, v6 :: v_dual_lshlrev_b32 v5, 16, v5// 0000001A76A8: C8E20D06 0C040A90
	v_mul_f32_e32 v10, v7, v7                                  // 0000001A76B0: 10140F07
	s_waitcnt vmcnt(4)                                         // 0000001A76B4: BF8913F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 0000001A76B8: 30101090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A76BC: BF8701A3
	v_mul_f32_e32 v11, v5, v5                                  // 0000001A76C0: 10160B05
	v_and_b32_e32 v13, 16, v29                                 // 0000001A76C4: 361A3A90
	v_mul_f32_e32 v9, v8, v8                                   // 0000001A76C8: 10121108
	s_waitcnt vmcnt(3)                                         // 0000001A76CC: BF890FF7
	v_lshlrev_b32_e32 v4, 16, v4                               // 0000001A76D0: 30080890
	v_add_f32_e32 v10, v11, v10                                // 0000001A76D4: 0614150B
	v_add_lshl_u32 v11, v13, v180, 2                           // 0000001A76D8: D647000B 020B690D
	v_add_f32_e32 v9, v12, v9                                  // 0000001A76E0: 0612130C
	s_waitcnt vmcnt(1)                                         // 0000001A76E4: BF8907F7
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000001A76E8: 30040490
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A76EC: BF870112
	v_dual_add_f32 v9, v10, v9 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 0000001A76F0: C906130A 090408FF BFB8AA3B
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 0000001A76FC: 100404FF BFB8AA3B
	ds_bpermute_b32 v10, v11, v9                               // 0000001A7704: DACC0000 0A00090B
	v_cndmask_b32_e64 v11, 8, 0, vcc_lo                        // 0000001A770C: D501000B 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001A7714: 7C983A84
	v_exp_f32_e32 v4, v4                                       // 0000001A7718: 7E084B04
	v_exp_f32_e32 v2, v2                                       // 0000001A771C: 7E044B02
	v_lshlrev_b32_e32 v3, 16, v3                               // 0000001A7720: 30060690
	v_add_lshl_u32 v11, v11, v180, 2                           // 0000001A7724: D647000B 020B690B
	s_delay_alu instid0(TRANS32_DEP_2)                         // 0000001A772C: BF870006
	v_add_f32_e32 v4, 1.0, v4                                  // 0000001A7730: 060808F2
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001A7734: BF870185
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v3// 0000001A7738: C90604F2 020206FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A7744: BF870002
	v_div_scale_f32 v14, null, v4, v4, 1.0                     // 0000001A7748: D6FC7C0E 03CA0904
	v_div_scale_f32 v21, s0, 1.0, v4, 1.0                      // 0000001A7750: D6FC0015 03CA08F2
	s_waitcnt lgkmcnt(0)                                       // 0000001A7758: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A775C: 06121509
	v_exp_f32_e32 v3, v3                                       // 0000001A7760: 7E064B03
	v_div_scale_f32 v24, s9, 1.0, v2, 1.0                      // 0000001A7764: D6FC0918 03CA04F2
	v_rcp_f32_e32 v19, v14                                     // 0000001A776C: 7E26550E
	v_div_scale_f32 v16, null, v2, v2, 1.0                     // 0000001A7770: D6FC7C10 03CA0502
	ds_bpermute_b32 v10, v11, v9                               // 0000001A7778: DACC0000 0A00090B
	v_cndmask_b32_e64 v11, 4, 0, vcc_lo                        // 0000001A7780: D501000B 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001A7788: 7C983A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A778C: BF8700A2
	v_add_lshl_u32 v11, v11, v180, 2                           // 0000001A7790: D647000B 020B690B
	v_add_f32_e32 v3, 1.0, v3                                  // 0000001A7798: 060606F2
	v_div_scale_f32 v15, null, v3, v3, 1.0                     // 0000001A779C: D6FC7C0F 03CA0703
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A77A4: BF870001
	v_rcp_f32_e32 v20, v15                                     // 0000001A77A8: 7E28550F
	s_waitcnt lgkmcnt(0)                                       // 0000001A77AC: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A77B0: 06121509
	ds_bpermute_b32 v10, v11, v9                               // 0000001A77B4: DACC0000 0A00090B
	v_cndmask_b32_e64 v11, 2, 0, vcc_lo                        // 0000001A77BC: D501000B 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001A77C4: 7C9B689F
	v_fma_f32 v32, -v15, v20, 1.0                              // 0000001A77C8: D6130020 23CA290F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A77D0: BF870123
	v_add_lshl_u32 v11, v11, v180, 2                           // 0000001A77D4: D647000B 020B690B
	s_waitcnt lgkmcnt(0)                                       // 0000001A77DC: BF89FC07
	v_dual_fmac_f32 v20, v32, v20 :: v_dual_add_f32 v9, v9, v10// 0000001A77E0: C8082920 14081509
	ds_bpermute_b32 v10, v11, v9                               // 0000001A77E8: DACC0000 0A00090B
	v_add_co_ci_u32_e64 v11, null, 0, v180, vcc_lo             // 0000001A77F0: D5207C0B 01AB6880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A77F8: BF870001
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000001A77FC: 30161682
	s_waitcnt lgkmcnt(0)                                       // 0000001A7800: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A7804: 06121509
	ds_bpermute_b32 v10, v11, v9                               // 0000001A7808: DACC0000 0A00090B
	s_waitcnt lgkmcnt(0)                                       // 0000001A7810: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A7814: 06121509
	ds_bpermute_b32 v9, v107, v9                               // 0000001A7818: DACC0000 0900096B
	s_waitcnt lgkmcnt(0)                                       // 0000001A7820: BF89FC07
	v_div_scale_f32 v10, null, s62, s62, v9                    // 0000001A7824: D6FC7C0A 04247C3E
	v_div_scale_f32 v13, vcc_lo, v9, s62, v9                   // 0000001A782C: D6FC6A0D 04247D09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A7834: BF870292
	v_rcp_f32_e32 v11, v10                                     // 0000001A7838: 7E16550A
	v_fma_f32 v12, -v10, v11, 1.0                              // 0000001A783C: D613000C 23CA170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A7844: BF8700A1
	v_fmac_f32_e32 v11, v12, v11                               // 0000001A7848: 5616170C
	s_waitcnt vmcnt(0)                                         // 0000001A784C: BF8903F7
	v_dual_mul_f32 v12, v13, v11 :: v_dual_lshlrev_b32 v1, 16, v1// 0000001A7850: C8E2170D 0C000290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A7858: BF870091
	v_fma_f32 v18, -v10, v12, v13                              // 0000001A785C: D6130012 2436190A
	v_fmac_f32_e32 v12, v18, v11                               // 0000001A7864: 56181712
	v_rcp_f32_e32 v18, v16                                     // 0000001A7868: 7E245510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A786C: BF870121
	v_fma_f32 v10, -v10, v12, v13                              // 0000001A7870: D613000A 2436190A
	v_fma_f32 v13, -v14, v19, 1.0                              // 0000001A7878: D613000D 23CA270E
	v_div_fmas_f32 v10, v10, v11, v12                          // 0000001A7880: D637000A 0432170A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A7888: BF870125
	v_fma_f32 v11, -v16, v18, 1.0                              // 0000001A788C: D613000B 23CA2510
	s_mov_b32 vcc_lo, s0                                       // 0000001A7894: BEEA0000
	v_div_fixup_f32 v9, v10, s62, v9                           // 0000001A7898: D6270009 04247D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A78A0: BF870091
	v_dual_fmac_f32 v18, v11, v18 :: v_dual_add_f32 v9, 0x358637bd, v9// 0000001A78A4: C808250B 120812FF 358637BD
	v_mul_f32_e32 v34, 0x4b800000, v9                          // 0000001A78B0: 104412FF 4B800000
	.long 0xd414000b                                           // 0000001A78B8: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v9, vcc_lo                 // 0000001A78BC: 020212FF 00800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A78C4: BF870091
	v_cndmask_b32_e64 v9, v9, v34, s11                         // 0000001A78C8: D5010009 002E4509
	v_rsq_f32_e32 v9, v9                                       // 0000001A78D0: 7E125D09
	v_fmac_f32_e32 v19, v13, v19                               // 0000001A78D4: 5626270D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A78D8: BF870091
	v_dual_mul_f32 v1, 0xbfb8aa3b, v1 :: v_dual_mul_f32 v10, v21, v19// 0000001A78DC: C8C602FF 010A2715 BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000001A78E8: 7E024B01
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A78EC: BF870001
	v_fma_f32 v32, -v14, v10, v21                              // 0000001A78F0: D6130020 2456150E
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000001A78F8: BF870085
	v_dual_fmac_f32 v10, v32, v19 :: v_dual_add_f32 v1, 1.0, v1// 0000001A78FC: C8082720 0A0002F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A7904: BF870111
	v_fma_f32 v14, -v14, v10, v21                              // 0000001A7908: D613000E 2456150E
	v_div_scale_f32 v17, null, v1, v1, 1.0                     // 0000001A7910: D6FC7C11 03CA0301
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A7918: BF870112
	v_div_fmas_f32 v10, v14, v19, v10                          // 0000001A791C: D637000A 042A270E
	v_rcp_f32_e32 v23, v17                                     // 0000001A7924: 7E2E5511
	v_mul_f32_e32 v14, 0x45800000, v9                          // 0000001A7928: 101C12FF 45800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A7930: BF870112
	v_div_fixup_f32 v4, v10, v4, 1.0                           // 0000001A7934: D6270004 03CA090A
	v_cndmask_b32_e64 v9, v9, v14, s11                         // 0000001A793C: D5010009 002E1D09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A7944: BF870115
	v_fma_f32 v12, -v17, v23, 1.0                              // 0000001A7948: D613000C 23CA2F11
	v_mul_f32_e32 v7, v9, v7                                   // 0000001A7950: 100E0F09
	v_mul_f32_e32 v6, v9, v6                                   // 0000001A7954: 100C0D09
	v_mul_f32_e32 v8, v9, v8                                   // 0000001A7958: 10101109
	v_mul_f32_e32 v5, v9, v5                                   // 0000001A795C: 100A0B09
	v_fmac_f32_e32 v23, v12, v23                               // 0000001A7960: 562E2F0C
	v_mul_f32_e32 v12, v24, v18                                // 0000001A7964: 10182518
	v_div_scale_f32 v22, s1, 1.0, v3, 1.0                      // 0000001A7968: D6FC0116 03CA06F2
	v_mul_f32_e32 v6, v6, v26                                  // 0000001A7970: 100C3506
	s_mov_b32 vcc_lo, s1                                       // 0000001A7974: BEEA0001
	v_mul_f32_e32 v7, v7, v27                                  // 0000001A7978: 100E3707
	v_fma_f32 v35, -v16, v12, v24                              // 0000001A797C: D6130023 24621910
	v_dual_mul_f32 v8, v8, v28 :: v_dual_mul_f32 v5, v5, v25   // 0000001A7984: C8C63908 08043305
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A798C: BF8701A2
	v_dual_mul_f32 v11, v22, v20 :: v_dual_fmac_f32 v12, v35, v18// 0000001A7990: C8C02916 0B0C2523
	v_div_scale_f32 v31, s10, 1.0, v1, 1.0                     // 0000001A7998: D6FC0A1F 03CA02F2
	v_mul_f32_e32 v4, v4, v5                                   // 0000001A79A0: 10080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A79A4: BF870213
	v_fma_f32 v33, -v15, v11, v22                              // 0000001A79A8: D6130021 245A170F
	v_fma_f32 v16, -v16, v12, v24                              // 0000001A79B0: D6130010 24621910
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A79B8: BF870194
	v_mul_f32_e32 v13, v31, v23                                // 0000001A79BC: 101A2F1F
	v_fmac_f32_e32 v11, v33, v20                               // 0000001A79C0: 56162921
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A79C4: BF870112
	v_fma_f32 v36, -v17, v13, v31                              // 0000001A79C8: D6130024 247E1B11
	v_fma_f32 v15, -v15, v11, v22                              // 0000001A79D0: D613000F 245A170F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A79D8: BF870112
	v_fmac_f32_e32 v13, v36, v23                               // 0000001A79DC: 561A2F24
	v_div_fmas_f32 v11, v15, v20, v11                          // 0000001A79E0: D637000B 042E290F
	s_mov_b32 vcc_lo, s9                                       // 0000001A79E8: BEEA0009
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001A79EC: BF8701C2
	v_fma_f32 v17, -v17, v13, v31                              // 0000001A79F0: D6130011 247E1B11
	v_div_fmas_f32 v12, v16, v18, v12                          // 0000001A79F8: D637000C 04322510
	s_mov_b32 vcc_lo, s10                                      // 0000001A7A00: BEEA000A
	v_div_fixup_f32 v3, v11, v3, 1.0                           // 0000001A7A04: D6270003 03CA070B
	v_div_fmas_f32 v10, v17, v23, v13                          // 0000001A7A0C: D637000A 04362F11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A7A14: BF870193
	v_div_fixup_f32 v2, v12, v2, 1.0                           // 0000001A7A18: D6270002 03CA050C
	v_mul_f32_e32 v3, v3, v6                                   // 0000001A7A20: 10060D03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A7A24: BF870193
	v_div_fixup_f32 v1, v10, v1, 1.0                           // 0000001A7A28: D6270001 03CA030A
	v_mul_f32_e32 v5, v2, v7                                   // 0000001A7A30: 100A0F02
	v_bfe_u32 v7, v4, 16, 1                                    // 0000001A7A34: D6100007 02052104
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A7A3C: BF870003
	v_mul_f32_e32 v6, v1, v8                                   // 0000001A7A40: 100C1101
	v_mad_u64_u32 v[1:2], null, 0x3000, v30, v[114:115]        // 0000001A7A44: D6FE7C01 05CA3CFF 00003000
	v_bfe_u32 v8, v3, 16, 1                                    // 0000001A7A50: D6100008 02052103
	v_bfe_u32 v9, v5, 16, 1                                    // 0000001A7A58: D6100009 02052105
	v_add3_u32 v4, v4, v7, 0x7fff                              // 0000001A7A60: D6550004 03FE0F04 00007FFF
	v_bfe_u32 v10, v6, 16, 1                                   // 0000001A7A6C: D610000A 02052106
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A7A74: BF870214
	v_add3_u32 v3, v3, v8, 0x7fff                              // 0000001A7A78: D6550003 03FE1103 00007FFF
	v_add3_u32 v5, v5, v9, 0x7fff                              // 0000001A7A84: D6550005 03FE1305 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A7A90: BF870003
	v_add3_u32 v6, v6, v10, 0x7fff                             // 0000001A7A94: D6550006 03FE1506 00007FFF
	s_clause 0x3                                               // 0000001A7AA0: BF850003
	global_store_d16_hi_b16 v[1:2], v4, off                    // 0000001A7AA4: DC960000 007C0401
	global_store_d16_hi_b16 v[1:2], v3, off offset:64          // 0000001A7AAC: DC960040 007C0301
	global_store_d16_hi_b16 v[1:2], v5, off offset:128         // 0000001A7AB4: DC960080 007C0501
	global_store_d16_hi_b16 v[1:2], v6, off offset:192         // 0000001A7ABC: DC9600C0 007C0601
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A7AC4: 8C7E0C7E
	v_or_b32_e32 v32, 9, v181                                  // 0000001A7AC8: 38416A89
	v_or_b32_e32 v31, 10, v181                                 // 0000001A7ACC: 383F6A8A
	v_or_b32_e32 v30, 11, v181                                 // 0000001A7AD0: 383D6A8B
	s_mov_b32 s12, exec_lo                                     // 0000001A7AD4: BE8C007E
	s_waitcnt vmcnt(0)                                         // 0000001A7AD8: BF8903F7
	v_min_i32_e32 v1, s71, v32                                 // 0000001A7ADC: 22024047
	v_min_i32_e32 v3, s71, v31                                 // 0000001A7AE0: 22063E47
	v_min_i32_e32 v9, s71, v30                                 // 0000001A7AE4: 22123C47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A7AE8: BF870193
	v_mad_i64_i32 v[1:2], null, 0x1800, v1, v[110:111]         // 0000001A7AEC: D6FF7C01 05BA02FF 00001800
	v_mad_i64_i32 v[3:4], null, 0x1800, v3, v[110:111]         // 0000001A7AF8: D6FF7C03 05BA06FF 00001800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A7B04: BF870112
	.long 0xd73c0001                                           // 0000001A7B08: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000001A7B0C: 02020281
	.long 0xd73c0003                                           // 0000001A7B10: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000001A7B14: 02020681
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A7B18: BF870092
	.long 0xd7006a05                                           // 0000001A7B1C: D7006A05
	v_cndmask_b32_e32 v1, s22, v1, vcc_lo                      // 0000001A7B20: 02020216
	v_add_co_ci_u32_e64 v6, null, s23, v2, vcc_lo              // 0000001A7B24: D5207C06 01AA0417
	.long 0xd7006a01                                           // 0000001A7B2C: D7006A01
	v_cndmask_b32_e32 v1, s26, v1, vcc_lo                      // 0000001A7B30: 0202021A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A7B34: BF870001
	v_add_co_ci_u32_e64 v2, null, s27, v2, vcc_lo              // 0000001A7B38: D5207C02 01AA041B
	s_clause 0x3                                               // 0000001A7B40: BF850003
	global_load_d16_b16 v21, v[5:6], off                       // 0000001A7B44: DC820000 157C0005
	global_load_d16_b16 v22, v[5:6], off offset:64             // 0000001A7B4C: DC820040 167C0005
	global_load_d16_b16 v23, v[5:6], off offset:128            // 0000001A7B54: DC820080 177C0005
	global_load_d16_b16 v24, v[5:6], off offset:192            // 0000001A7B5C: DC8200C0 187C0005
	s_clause 0x3                                               // 0000001A7B64: BF850003
	global_load_d16_b16 v20, v[1:2], off                       // 0000001A7B68: DC820000 147C0001
	global_load_d16_b16 v19, v[1:2], off offset:64             // 0000001A7B70: DC820040 137C0001
	global_load_d16_b16 v18, v[1:2], off offset:128            // 0000001A7B78: DC820080 127C0001
	global_load_d16_b16 v17, v[1:2], off offset:192            // 0000001A7B80: DC8200C0 117C0001
	v_mad_i64_i32 v[1:2], null, 0x1800, v9, v[110:111]         // 0000001A7B88: D6FF7C01 05BA12FF 00001800
	.long 0xd7006a07                                           // 0000001A7B94: D7006A07
	v_cndmask_b32_e32 v1, s22, v3, vcc_lo                      // 0000001A7B98: 02020616
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A7B9C: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s23, v4, vcc_lo              // 0000001A7BA0: D5207C08 01AA0817
	.long 0xd7006a03                                           // 0000001A7BA8: D7006A03
	v_cndmask_b32_e32 v1, s26, v3, vcc_lo                      // 0000001A7BAC: 0202061A
	v_add_co_ci_u32_e64 v4, null, s27, v4, vcc_lo              // 0000001A7BB0: D5207C04 01AA081B
	.long 0xd73c0001                                           // 0000001A7BB8: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000001A7BBC: 02020281
	s_clause 0x3                                               // 0000001A7BC0: BF850003
	global_load_d16_b16 v12, v[3:4], off                       // 0000001A7BC4: DC820000 0C7C0003
	global_load_d16_b16 v11, v[3:4], off offset:64             // 0000001A7BCC: DC820040 0B7C0003
	global_load_d16_b16 v10, v[3:4], off offset:128            // 0000001A7BD4: DC820080 0A7C0003
	global_load_d16_b16 v9, v[3:4], off offset:192             // 0000001A7BDC: DC8200C0 097C0003
	s_clause 0x3                                               // 0000001A7BE4: BF850003
	global_load_d16_b16 v13, v[7:8], off                       // 0000001A7BE8: DC820000 0D7C0007
	global_load_d16_b16 v14, v[7:8], off offset:64             // 0000001A7BF0: DC820040 0E7C0007
	global_load_d16_b16 v15, v[7:8], off offset:128            // 0000001A7BF8: DC820080 0F7C0007
	global_load_d16_b16 v16, v[7:8], off offset:192            // 0000001A7C00: DC8200C0 107C0007
	.long 0xd7006a03                                           // 0000001A7C08: D7006A03
	v_cndmask_b32_e32 v1, s22, v1, vcc_lo                      // 0000001A7C0C: 02020216
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A7C10: BF8700A1
	v_add_co_ci_u32_e64 v4, null, s23, v2, vcc_lo              // 0000001A7C14: D5207C04 01AA0417
	.long 0xd7006a21                                           // 0000001A7C1C: D7006A21
	v_cndmask_b32_e32 v1, s26, v1, vcc_lo                      // 0000001A7C20: 0202021A
	v_add_co_ci_u32_e64 v34, null, s27, v2, vcc_lo             // 0000001A7C24: D5207C22 01AA041B
	s_clause 0x3                                               // 0000001A7C2C: BF850003
	global_load_d16_b16 v5, v[3:4], off                        // 0000001A7C30: DC820000 057C0003
	global_load_d16_b16 v6, v[3:4], off offset:64              // 0000001A7C38: DC820040 067C0003
	global_load_d16_b16 v7, v[3:4], off offset:128             // 0000001A7C40: DC820080 077C0003
	global_load_d16_b16 v8, v[3:4], off offset:192             // 0000001A7C48: DC8200C0 087C0003
	s_clause 0x3                                               // 0000001A7C50: BF850003
	global_load_d16_b16 v4, v[33:34], off                      // 0000001A7C54: DC820000 047C0021
	global_load_d16_b16 v3, v[33:34], off offset:64            // 0000001A7C5C: DC820040 037C0021
	global_load_d16_b16 v2, v[33:34], off offset:128           // 0000001A7C64: DC820080 027C0021
	global_load_d16_b16 v1, v[33:34], off offset:192           // 0000001A7C6C: DC8200C0 017C0021
	v_or_b32_e32 v33, 8, v181                                  // 0000001A7C74: 38436A88
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A7C78: BF870001
	.long 0xd4c4007e                                           // 0000001A7C7C: D4C4007E
	v_cndmask_b32_e32 v1, s67, v33, vcc_lo                     // 0000001A7C80: 02024243
	s_cbranch_execnz 3176                                      // 0000001A7C84: BFA60C68 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xb428>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A7C88: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A7C8C: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001A7C90: BE8C007E
	.long 0xd4c4007e                                           // 0000001A7C94: D4C4007E
	v_cndmask_b32_e32 v1, s67, v32, vcc_lo                     // 0000001A7C98: 02024043
	s_cbranch_execnz 3476                                      // 0000001A7C9C: BFA60D94 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xb8f0>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A7CA0: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A7CA4: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001A7CA8: BE8C007E
	.long 0xd4c4007e                                           // 0000001A7CAC: D4C4007E
	v_cndmask_b32_e32 v1, s67, v31, vcc_lo                     // 0000001A7CB0: 02023E43
	s_cbranch_execnz 3746                                      // 0000001A7CB4: BFA60EA2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xbd40>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A7CB8: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A7CBC: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001A7CC0: BE8C007E
	.long 0xd4c4007e                                           // 0000001A7CC4: D4C4007E
	v_cndmask_b32_e32 v1, s67, v30, vcc_lo                     // 0000001A7CC8: 02023C43
	s_cbranch_execz 269                                        // 0000001A7CCC: BFA5010D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8704>
	s_waitcnt vmcnt(6)                                         // 0000001A7CD0: BF891BF7
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000001A7CD4: 300C0C90
	s_waitcnt vmcnt(5)                                         // 0000001A7CD8: BF8917F7
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000001A7CDC: 300E0E90
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001A7CE0: 7C983A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A7CE4: BF870193
	v_dual_mul_f32 v12, v6, v6 :: v_dual_lshlrev_b32 v5, 16, v5// 0000001A7CE8: C8E20D06 0C040A90
	v_mul_f32_e32 v10, v7, v7                                  // 0000001A7CF0: 10140F07
	s_waitcnt vmcnt(4)                                         // 0000001A7CF4: BF8913F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 0000001A7CF8: 30101090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A7CFC: BF8701A3
	v_mul_f32_e32 v11, v5, v5                                  // 0000001A7D00: 10160B05
	v_and_b32_e32 v13, 16, v29                                 // 0000001A7D04: 361A3A90
	v_mul_f32_e32 v9, v8, v8                                   // 0000001A7D08: 10121108
	s_waitcnt vmcnt(3)                                         // 0000001A7D0C: BF890FF7
	v_lshlrev_b32_e32 v4, 16, v4                               // 0000001A7D10: 30080890
	v_add_f32_e32 v10, v11, v10                                // 0000001A7D14: 0614150B
	v_add_lshl_u32 v11, v13, v180, 2                           // 0000001A7D18: D647000B 020B690D
	v_add_f32_e32 v9, v12, v9                                  // 0000001A7D20: 0612130C
	s_waitcnt vmcnt(1)                                         // 0000001A7D24: BF8907F7
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000001A7D28: 30040490
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A7D2C: BF870112
	v_dual_add_f32 v9, v10, v9 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 0000001A7D30: C906130A 090408FF BFB8AA3B
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 0000001A7D3C: 100404FF BFB8AA3B
	ds_bpermute_b32 v10, v11, v9                               // 0000001A7D44: DACC0000 0A00090B
	v_cndmask_b32_e64 v11, 8, 0, vcc_lo                        // 0000001A7D4C: D501000B 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001A7D54: 7C983A84
	v_exp_f32_e32 v4, v4                                       // 0000001A7D58: 7E084B04
	v_exp_f32_e32 v2, v2                                       // 0000001A7D5C: 7E044B02
	v_lshlrev_b32_e32 v3, 16, v3                               // 0000001A7D60: 30060690
	v_add_lshl_u32 v11, v11, v180, 2                           // 0000001A7D64: D647000B 020B690B
	s_delay_alu instid0(TRANS32_DEP_2)                         // 0000001A7D6C: BF870006
	v_add_f32_e32 v4, 1.0, v4                                  // 0000001A7D70: 060808F2
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001A7D74: BF870185
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v3// 0000001A7D78: C90604F2 020206FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A7D84: BF870002
	v_div_scale_f32 v14, null, v4, v4, 1.0                     // 0000001A7D88: D6FC7C0E 03CA0904
	v_div_scale_f32 v21, s0, 1.0, v4, 1.0                      // 0000001A7D90: D6FC0015 03CA08F2
	s_waitcnt lgkmcnt(0)                                       // 0000001A7D98: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A7D9C: 06121509
	v_exp_f32_e32 v3, v3                                       // 0000001A7DA0: 7E064B03
	v_div_scale_f32 v24, s9, 1.0, v2, 1.0                      // 0000001A7DA4: D6FC0918 03CA04F2
	v_rcp_f32_e32 v19, v14                                     // 0000001A7DAC: 7E26550E
	v_div_scale_f32 v16, null, v2, v2, 1.0                     // 0000001A7DB0: D6FC7C10 03CA0502
	ds_bpermute_b32 v10, v11, v9                               // 0000001A7DB8: DACC0000 0A00090B
	v_cndmask_b32_e64 v11, 4, 0, vcc_lo                        // 0000001A7DC0: D501000B 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001A7DC8: 7C983A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A7DCC: BF8700A2
	v_add_lshl_u32 v11, v11, v180, 2                           // 0000001A7DD0: D647000B 020B690B
	v_add_f32_e32 v3, 1.0, v3                                  // 0000001A7DD8: 060606F2
	v_div_scale_f32 v15, null, v3, v3, 1.0                     // 0000001A7DDC: D6FC7C0F 03CA0703
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A7DE4: BF870001
	v_rcp_f32_e32 v20, v15                                     // 0000001A7DE8: 7E28550F
	s_waitcnt lgkmcnt(0)                                       // 0000001A7DEC: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A7DF0: 06121509
	ds_bpermute_b32 v10, v11, v9                               // 0000001A7DF4: DACC0000 0A00090B
	v_cndmask_b32_e64 v11, 2, 0, vcc_lo                        // 0000001A7DFC: D501000B 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001A7E04: 7C9B689F
	v_fma_f32 v32, -v15, v20, 1.0                              // 0000001A7E08: D6130020 23CA290F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A7E10: BF870123
	v_add_lshl_u32 v11, v11, v180, 2                           // 0000001A7E14: D647000B 020B690B
	s_waitcnt lgkmcnt(0)                                       // 0000001A7E1C: BF89FC07
	v_dual_fmac_f32 v20, v32, v20 :: v_dual_add_f32 v9, v9, v10// 0000001A7E20: C8082920 14081509
	ds_bpermute_b32 v10, v11, v9                               // 0000001A7E28: DACC0000 0A00090B
	v_add_co_ci_u32_e64 v11, null, 0, v180, vcc_lo             // 0000001A7E30: D5207C0B 01AB6880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A7E38: BF870001
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000001A7E3C: 30161682
	s_waitcnt lgkmcnt(0)                                       // 0000001A7E40: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A7E44: 06121509
	ds_bpermute_b32 v10, v11, v9                               // 0000001A7E48: DACC0000 0A00090B
	s_waitcnt lgkmcnt(0)                                       // 0000001A7E50: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A7E54: 06121509
	ds_bpermute_b32 v9, v107, v9                               // 0000001A7E58: DACC0000 0900096B
	s_waitcnt lgkmcnt(0)                                       // 0000001A7E60: BF89FC07
	v_div_scale_f32 v10, null, s62, s62, v9                    // 0000001A7E64: D6FC7C0A 04247C3E
	v_div_scale_f32 v13, vcc_lo, v9, s62, v9                   // 0000001A7E6C: D6FC6A0D 04247D09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A7E74: BF870292
	v_rcp_f32_e32 v11, v10                                     // 0000001A7E78: 7E16550A
	v_fma_f32 v12, -v10, v11, 1.0                              // 0000001A7E7C: D613000C 23CA170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A7E84: BF8700A1
	v_fmac_f32_e32 v11, v12, v11                               // 0000001A7E88: 5616170C
	s_waitcnt vmcnt(0)                                         // 0000001A7E8C: BF8903F7
	v_dual_mul_f32 v12, v13, v11 :: v_dual_lshlrev_b32 v1, 16, v1// 0000001A7E90: C8E2170D 0C000290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A7E98: BF870091
	v_fma_f32 v18, -v10, v12, v13                              // 0000001A7E9C: D6130012 2436190A
	v_fmac_f32_e32 v12, v18, v11                               // 0000001A7EA4: 56181712
	v_rcp_f32_e32 v18, v16                                     // 0000001A7EA8: 7E245510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A7EAC: BF870121
	v_fma_f32 v10, -v10, v12, v13                              // 0000001A7EB0: D613000A 2436190A
	v_fma_f32 v13, -v14, v19, 1.0                              // 0000001A7EB8: D613000D 23CA270E
	v_div_fmas_f32 v10, v10, v11, v12                          // 0000001A7EC0: D637000A 0432170A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A7EC8: BF870125
	v_fma_f32 v11, -v16, v18, 1.0                              // 0000001A7ECC: D613000B 23CA2510
	s_mov_b32 vcc_lo, s0                                       // 0000001A7ED4: BEEA0000
	v_div_fixup_f32 v9, v10, s62, v9                           // 0000001A7ED8: D6270009 04247D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A7EE0: BF870091
	v_dual_fmac_f32 v18, v11, v18 :: v_dual_add_f32 v9, 0x358637bd, v9// 0000001A7EE4: C808250B 120812FF 358637BD
	v_mul_f32_e32 v34, 0x4b800000, v9                          // 0000001A7EF0: 104412FF 4B800000
	.long 0xd414000b                                           // 0000001A7EF8: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v9, vcc_lo                 // 0000001A7EFC: 020212FF 00800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A7F04: BF870091
	v_cndmask_b32_e64 v9, v9, v34, s11                         // 0000001A7F08: D5010009 002E4509
	v_rsq_f32_e32 v9, v9                                       // 0000001A7F10: 7E125D09
	v_fmac_f32_e32 v19, v13, v19                               // 0000001A7F14: 5626270D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A7F18: BF870091
	v_dual_mul_f32 v1, 0xbfb8aa3b, v1 :: v_dual_mul_f32 v10, v21, v19// 0000001A7F1C: C8C602FF 010A2715 BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000001A7F28: 7E024B01
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A7F2C: BF870001
	v_fma_f32 v32, -v14, v10, v21                              // 0000001A7F30: D6130020 2456150E
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000001A7F38: BF870085
	v_dual_fmac_f32 v10, v32, v19 :: v_dual_add_f32 v1, 1.0, v1// 0000001A7F3C: C8082720 0A0002F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A7F44: BF870111
	v_fma_f32 v14, -v14, v10, v21                              // 0000001A7F48: D613000E 2456150E
	v_div_scale_f32 v17, null, v1, v1, 1.0                     // 0000001A7F50: D6FC7C11 03CA0301
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A7F58: BF870112
	v_div_fmas_f32 v10, v14, v19, v10                          // 0000001A7F5C: D637000A 042A270E
	v_rcp_f32_e32 v23, v17                                     // 0000001A7F64: 7E2E5511
	v_mul_f32_e32 v14, 0x45800000, v9                          // 0000001A7F68: 101C12FF 45800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A7F70: BF870112
	v_div_fixup_f32 v4, v10, v4, 1.0                           // 0000001A7F74: D6270004 03CA090A
	v_cndmask_b32_e64 v9, v9, v14, s11                         // 0000001A7F7C: D5010009 002E1D09
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A7F84: BF870115
	v_fma_f32 v12, -v17, v23, 1.0                              // 0000001A7F88: D613000C 23CA2F11
	v_mul_f32_e32 v7, v9, v7                                   // 0000001A7F90: 100E0F09
	v_mul_f32_e32 v6, v9, v6                                   // 0000001A7F94: 100C0D09
	v_mul_f32_e32 v8, v9, v8                                   // 0000001A7F98: 10101109
	v_mul_f32_e32 v5, v9, v5                                   // 0000001A7F9C: 100A0B09
	v_fmac_f32_e32 v23, v12, v23                               // 0000001A7FA0: 562E2F0C
	v_mul_f32_e32 v12, v24, v18                                // 0000001A7FA4: 10182518
	v_div_scale_f32 v22, s1, 1.0, v3, 1.0                      // 0000001A7FA8: D6FC0116 03CA06F2
	v_mul_f32_e32 v6, v6, v26                                  // 0000001A7FB0: 100C3506
	s_mov_b32 vcc_lo, s1                                       // 0000001A7FB4: BEEA0001
	v_mul_f32_e32 v7, v7, v27                                  // 0000001A7FB8: 100E3707
	v_fma_f32 v35, -v16, v12, v24                              // 0000001A7FBC: D6130023 24621910
	v_dual_mul_f32 v8, v8, v28 :: v_dual_mul_f32 v5, v5, v25   // 0000001A7FC4: C8C63908 08043305
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A7FCC: BF8701A2
	v_dual_mul_f32 v11, v22, v20 :: v_dual_fmac_f32 v12, v35, v18// 0000001A7FD0: C8C02916 0B0C2523
	v_div_scale_f32 v31, s10, 1.0, v1, 1.0                     // 0000001A7FD8: D6FC0A1F 03CA02F2
	v_mul_f32_e32 v4, v4, v5                                   // 0000001A7FE0: 10080B04
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A7FE4: BF870213
	v_fma_f32 v33, -v15, v11, v22                              // 0000001A7FE8: D6130021 245A170F
	v_fma_f32 v16, -v16, v12, v24                              // 0000001A7FF0: D6130010 24621910
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A7FF8: BF870194
	v_mul_f32_e32 v13, v31, v23                                // 0000001A7FFC: 101A2F1F
	v_fmac_f32_e32 v11, v33, v20                               // 0000001A8000: 56162921
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A8004: BF870112
	v_fma_f32 v36, -v17, v13, v31                              // 0000001A8008: D6130024 247E1B11
	v_fma_f32 v15, -v15, v11, v22                              // 0000001A8010: D613000F 245A170F
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A8018: BF870112
	v_fmac_f32_e32 v13, v36, v23                               // 0000001A801C: 561A2F24
	v_div_fmas_f32 v11, v15, v20, v11                          // 0000001A8020: D637000B 042E290F
	s_mov_b32 vcc_lo, s9                                       // 0000001A8028: BEEA0009
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001A802C: BF8701C2
	v_fma_f32 v17, -v17, v13, v31                              // 0000001A8030: D6130011 247E1B11
	v_div_fmas_f32 v12, v16, v18, v12                          // 0000001A8038: D637000C 04322510
	s_mov_b32 vcc_lo, s10                                      // 0000001A8040: BEEA000A
	v_div_fixup_f32 v3, v11, v3, 1.0                           // 0000001A8044: D6270003 03CA070B
	v_div_fmas_f32 v10, v17, v23, v13                          // 0000001A804C: D637000A 04362F11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A8054: BF870193
	v_div_fixup_f32 v2, v12, v2, 1.0                           // 0000001A8058: D6270002 03CA050C
	v_mul_f32_e32 v3, v3, v6                                   // 0000001A8060: 10060D03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A8064: BF870193
	v_div_fixup_f32 v1, v10, v1, 1.0                           // 0000001A8068: D6270001 03CA030A
	v_mul_f32_e32 v5, v2, v7                                   // 0000001A8070: 100A0F02
	v_bfe_u32 v7, v4, 16, 1                                    // 0000001A8074: D6100007 02052104
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A807C: BF870003
	v_mul_f32_e32 v6, v1, v8                                   // 0000001A8080: 100C1101
	v_mad_u64_u32 v[1:2], null, 0x3000, v30, v[114:115]        // 0000001A8084: D6FE7C01 05CA3CFF 00003000
	v_bfe_u32 v8, v3, 16, 1                                    // 0000001A8090: D6100008 02052103
	v_bfe_u32 v9, v5, 16, 1                                    // 0000001A8098: D6100009 02052105
	v_add3_u32 v4, v4, v7, 0x7fff                              // 0000001A80A0: D6550004 03FE0F04 00007FFF
	v_bfe_u32 v10, v6, 16, 1                                   // 0000001A80AC: D610000A 02052106
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A80B4: BF870214
	v_add3_u32 v3, v3, v8, 0x7fff                              // 0000001A80B8: D6550003 03FE1103 00007FFF
	v_add3_u32 v5, v5, v9, 0x7fff                              // 0000001A80C4: D6550005 03FE1305 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A80D0: BF870003
	v_add3_u32 v6, v6, v10, 0x7fff                             // 0000001A80D4: D6550006 03FE1506 00007FFF
	s_clause 0x3                                               // 0000001A80E0: BF850003
	global_store_d16_hi_b16 v[1:2], v4, off                    // 0000001A80E4: DC960000 007C0401
	global_store_d16_hi_b16 v[1:2], v3, off offset:64          // 0000001A80EC: DC960040 007C0301
	global_store_d16_hi_b16 v[1:2], v5, off offset:128         // 0000001A80F4: DC960080 007C0501
	global_store_d16_hi_b16 v[1:2], v6, off offset:192         // 0000001A80FC: DC9600C0 007C0601
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A8104: 8C7E0C7E
	v_or_b32_e32 v32, 13, v181                                 // 0000001A8108: 38416A8D
	v_or_b32_e32 v31, 14, v181                                 // 0000001A810C: 383F6A8E
	v_or_b32_e32 v30, 15, v181                                 // 0000001A8110: 383D6A8F
	s_mov_b32 s12, exec_lo                                     // 0000001A8114: BE8C007E
	s_waitcnt vmcnt(0)                                         // 0000001A8118: BF8903F7
	v_min_i32_e32 v1, s71, v32                                 // 0000001A811C: 22024047
	v_min_i32_e32 v3, s71, v31                                 // 0000001A8120: 22063E47
	v_min_i32_e32 v9, s71, v30                                 // 0000001A8124: 22123C47
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A8128: BF870193
	v_mad_i64_i32 v[1:2], null, 0x1800, v1, v[110:111]         // 0000001A812C: D6FF7C01 05BA02FF 00001800
	v_mad_i64_i32 v[3:4], null, 0x1800, v3, v[110:111]         // 0000001A8138: D6FF7C03 05BA06FF 00001800
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A8144: BF870112
	.long 0xd73c0001                                           // 0000001A8148: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000001A814C: 02020281
	.long 0xd73c0003                                           // 0000001A8150: D73C0003
	v_cndmask_b32_e32 v1, 1, v3, vcc_lo                        // 0000001A8154: 02020681
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A8158: BF870092
	.long 0xd7006a05                                           // 0000001A815C: D7006A05
	v_cndmask_b32_e32 v1, s22, v1, vcc_lo                      // 0000001A8160: 02020216
	v_add_co_ci_u32_e64 v6, null, s23, v2, vcc_lo              // 0000001A8164: D5207C06 01AA0417
	.long 0xd7006a01                                           // 0000001A816C: D7006A01
	v_cndmask_b32_e32 v1, s26, v1, vcc_lo                      // 0000001A8170: 0202021A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8174: BF870001
	v_add_co_ci_u32_e64 v2, null, s27, v2, vcc_lo              // 0000001A8178: D5207C02 01AA041B
	s_clause 0x3                                               // 0000001A8180: BF850003
	global_load_d16_b16 v21, v[5:6], off                       // 0000001A8184: DC820000 157C0005
	global_load_d16_b16 v22, v[5:6], off offset:64             // 0000001A818C: DC820040 167C0005
	global_load_d16_b16 v23, v[5:6], off offset:128            // 0000001A8194: DC820080 177C0005
	global_load_d16_b16 v24, v[5:6], off offset:192            // 0000001A819C: DC8200C0 187C0005
	s_clause 0x3                                               // 0000001A81A4: BF850003
	global_load_d16_b16 v20, v[1:2], off                       // 0000001A81A8: DC820000 147C0001
	global_load_d16_b16 v19, v[1:2], off offset:64             // 0000001A81B0: DC820040 137C0001
	global_load_d16_b16 v18, v[1:2], off offset:128            // 0000001A81B8: DC820080 127C0001
	global_load_d16_b16 v17, v[1:2], off offset:192            // 0000001A81C0: DC8200C0 117C0001
	v_mad_i64_i32 v[1:2], null, 0x1800, v9, v[110:111]         // 0000001A81C8: D6FF7C01 05BA12FF 00001800
	.long 0xd7006a07                                           // 0000001A81D4: D7006A07
	v_cndmask_b32_e32 v1, s22, v3, vcc_lo                      // 0000001A81D8: 02020616
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A81DC: BF8700A1
	v_add_co_ci_u32_e64 v8, null, s23, v4, vcc_lo              // 0000001A81E0: D5207C08 01AA0817
	.long 0xd7006a03                                           // 0000001A81E8: D7006A03
	v_cndmask_b32_e32 v1, s26, v3, vcc_lo                      // 0000001A81EC: 0202061A
	v_add_co_ci_u32_e64 v4, null, s27, v4, vcc_lo              // 0000001A81F0: D5207C04 01AA081B
	.long 0xd73c0001                                           // 0000001A81F8: D73C0001
	v_cndmask_b32_e32 v1, 1, v1, vcc_lo                        // 0000001A81FC: 02020281
	s_clause 0x3                                               // 0000001A8200: BF850003
	global_load_d16_b16 v12, v[3:4], off                       // 0000001A8204: DC820000 0C7C0003
	global_load_d16_b16 v11, v[3:4], off offset:64             // 0000001A820C: DC820040 0B7C0003
	global_load_d16_b16 v10, v[3:4], off offset:128            // 0000001A8214: DC820080 0A7C0003
	global_load_d16_b16 v9, v[3:4], off offset:192             // 0000001A821C: DC8200C0 097C0003
	s_clause 0x3                                               // 0000001A8224: BF850003
	global_load_d16_b16 v13, v[7:8], off                       // 0000001A8228: DC820000 0D7C0007
	global_load_d16_b16 v14, v[7:8], off offset:64             // 0000001A8230: DC820040 0E7C0007
	global_load_d16_b16 v15, v[7:8], off offset:128            // 0000001A8238: DC820080 0F7C0007
	global_load_d16_b16 v16, v[7:8], off offset:192            // 0000001A8240: DC8200C0 107C0007
	.long 0xd7006a03                                           // 0000001A8248: D7006A03
	v_cndmask_b32_e32 v1, s22, v1, vcc_lo                      // 0000001A824C: 02020216
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A8250: BF8700A1
	v_add_co_ci_u32_e64 v4, null, s23, v2, vcc_lo              // 0000001A8254: D5207C04 01AA0417
	.long 0xd7006a21                                           // 0000001A825C: D7006A21
	v_cndmask_b32_e32 v1, s26, v1, vcc_lo                      // 0000001A8260: 0202021A
	v_add_co_ci_u32_e64 v34, null, s27, v2, vcc_lo             // 0000001A8264: D5207C22 01AA041B
	s_clause 0x3                                               // 0000001A826C: BF850003
	global_load_d16_b16 v5, v[3:4], off                        // 0000001A8270: DC820000 057C0003
	global_load_d16_b16 v6, v[3:4], off offset:64              // 0000001A8278: DC820040 067C0003
	global_load_d16_b16 v7, v[3:4], off offset:128             // 0000001A8280: DC820080 077C0003
	global_load_d16_b16 v8, v[3:4], off offset:192             // 0000001A8288: DC8200C0 087C0003
	s_clause 0x3                                               // 0000001A8290: BF850003
	global_load_d16_b16 v4, v[33:34], off                      // 0000001A8294: DC820000 047C0021
	global_load_d16_b16 v3, v[33:34], off offset:64            // 0000001A829C: DC820040 037C0021
	global_load_d16_b16 v2, v[33:34], off offset:128           // 0000001A82A4: DC820080 027C0021
	global_load_d16_b16 v1, v[33:34], off offset:192           // 0000001A82AC: DC8200C0 017C0021
	v_or_b32_e32 v33, 12, v181                                 // 0000001A82B4: 38436A8C
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A82B8: BF870001
	.long 0xd4c4007e                                           // 0000001A82BC: D4C4007E
	v_cndmask_b32_e32 v1, s67, v33, vcc_lo                     // 0000001A82C0: 02024243
	s_cbranch_execnz 3630                                      // 0000001A82C4: BFA60E2E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xc180>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A82C8: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A82CC: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001A82D0: BE8C007E
	.long 0xd4c4007e                                           // 0000001A82D4: D4C4007E
	v_cndmask_b32_e32 v1, s67, v32, vcc_lo                     // 0000001A82D8: 02024043
	s_cbranch_execnz 3930                                      // 0000001A82DC: BFA60F5A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xc648>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A82E0: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A82E4: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001A82E8: BE8C007E
	.long 0xd4c4007e                                           // 0000001A82EC: D4C4007E
	v_cndmask_b32_e32 v1, s67, v31, vcc_lo                     // 0000001A82F0: 02023E43
	s_cbranch_execnz 4200                                      // 0000001A82F4: BFA61068 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xca98>
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A82F8: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A82FC: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001A8300: BE8C007E
	.long 0xd4c4007e                                           // 0000001A8304: D4C4007E
	v_cndmask_b32_e32 v1, s67, v30, vcc_lo                     // 0000001A8308: 02023C43
	s_cbranch_execz 272                                        // 0000001A830C: BFA50110 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8d50>
	s_waitcnt vmcnt(6)                                         // 0000001A8310: BF891BF7
	v_lshlrev_b32_e32 v6, 16, v6                               // 0000001A8314: 300C0C90
	s_waitcnt vmcnt(5)                                         // 0000001A8318: BF8917F7
	v_lshlrev_b32_e32 v7, 16, v7                               // 0000001A831C: 300E0E90
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001A8320: 7C983A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A8324: BF870193
	v_dual_mul_f32 v12, v6, v6 :: v_dual_lshlrev_b32 v5, 16, v5// 0000001A8328: C8E20D06 0C040A90
	v_mul_f32_e32 v10, v7, v7                                  // 0000001A8330: 10140F07
	s_waitcnt vmcnt(4)                                         // 0000001A8334: BF8913F7
	v_lshlrev_b32_e32 v8, 16, v8                               // 0000001A8338: 30101090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A833C: BF8701A3
	v_mul_f32_e32 v11, v5, v5                                  // 0000001A8340: 10160B05
	v_and_b32_e32 v13, 16, v29                                 // 0000001A8344: 361A3A90
	v_mul_f32_e32 v9, v8, v8                                   // 0000001A8348: 10121108
	s_waitcnt vmcnt(3)                                         // 0000001A834C: BF890FF7
	v_lshlrev_b32_e32 v4, 16, v4                               // 0000001A8350: 30080890
	v_add_f32_e32 v10, v11, v10                                // 0000001A8354: 0614150B
	v_add_lshl_u32 v11, v13, v180, 2                           // 0000001A8358: D647000B 020B690D
	v_add_f32_e32 v9, v12, v9                                  // 0000001A8360: 0612130C
	s_waitcnt vmcnt(1)                                         // 0000001A8364: BF8907F7
	v_lshlrev_b32_e32 v2, 16, v2                               // 0000001A8368: 30040490
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A836C: BF870112
	v_dual_add_f32 v9, v10, v9 :: v_dual_mul_f32 v4, 0xbfb8aa3b, v4// 0000001A8370: C906130A 090408FF BFB8AA3B
	v_mul_f32_e32 v2, 0xbfb8aa3b, v2                           // 0000001A837C: 100404FF BFB8AA3B
	ds_bpermute_b32 v10, v11, v9                               // 0000001A8384: DACC0000 0A00090B
	v_cndmask_b32_e64 v11, 8, 0, vcc_lo                        // 0000001A838C: D501000B 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001A8394: 7C983A84
	v_exp_f32_e32 v4, v4                                       // 0000001A8398: 7E084B04
	v_exp_f32_e32 v2, v2                                       // 0000001A839C: 7E044B02
	v_lshlrev_b32_e32 v3, 16, v3                               // 0000001A83A0: 30060690
	v_add_lshl_u32 v11, v11, v180, 2                           // 0000001A83A4: D647000B 020B690B
	s_delay_alu instid0(TRANS32_DEP_2)                         // 0000001A83AC: BF870006
	v_add_f32_e32 v4, 1.0, v4                                  // 0000001A83B0: 060808F2
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001A83B4: BF870185
	v_dual_add_f32 v2, 1.0, v2 :: v_dual_mul_f32 v3, 0xbfb8aa3b, v3// 0000001A83B8: C90604F2 020206FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A83C4: BF870002
	v_div_scale_f32 v14, null, v4, v4, 1.0                     // 0000001A83C8: D6FC7C0E 03CA0904
	v_div_scale_f32 v21, s0, 1.0, v4, 1.0                      // 0000001A83D0: D6FC0015 03CA08F2
	s_waitcnt lgkmcnt(0)                                       // 0000001A83D8: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A83DC: 06121509
	v_exp_f32_e32 v3, v3                                       // 0000001A83E0: 7E064B03
	v_div_scale_f32 v24, s9, 1.0, v2, 1.0                      // 0000001A83E4: D6FC0918 03CA04F2
	v_rcp_f32_e32 v19, v14                                     // 0000001A83EC: 7E26550E
	v_div_scale_f32 v16, null, v2, v2, 1.0                     // 0000001A83F0: D6FC7C10 03CA0502
	ds_bpermute_b32 v10, v11, v9                               // 0000001A83F8: DACC0000 0A00090B
	v_cndmask_b32_e64 v11, 4, 0, vcc_lo                        // 0000001A8400: D501000B 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001A8408: 7C983A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A840C: BF8700A2
	v_add_lshl_u32 v11, v11, v180, 2                           // 0000001A8410: D647000B 020B690B
	v_add_f32_e32 v3, 1.0, v3                                  // 0000001A8418: 060606F2
	v_div_scale_f32 v15, null, v3, v3, 1.0                     // 0000001A841C: D6FC7C0F 03CA0703
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8424: BF870001
	v_rcp_f32_e32 v20, v15                                     // 0000001A8428: 7E28550F
	s_waitcnt lgkmcnt(0)                                       // 0000001A842C: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A8430: 06121509
	ds_bpermute_b32 v10, v11, v9                               // 0000001A8434: DACC0000 0A00090B
	v_cndmask_b32_e64 v11, 2, 0, vcc_lo                        // 0000001A843C: D501000B 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001A8444: 7C9B689F
	v_fma_f32 v31, -v15, v20, 1.0                              // 0000001A8448: D613001F 23CA290F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8450: BF870123
	v_add_lshl_u32 v11, v11, v180, 2                           // 0000001A8454: D647000B 020B690B
	s_waitcnt lgkmcnt(0)                                       // 0000001A845C: BF89FC07
	v_dual_fmac_f32 v20, v31, v20 :: v_dual_add_f32 v9, v9, v10// 0000001A8460: C808291F 14081509
	ds_bpermute_b32 v10, v11, v9                               // 0000001A8468: DACC0000 0A00090B
	v_add_co_ci_u32_e64 v11, null, 0, v180, vcc_lo             // 0000001A8470: D5207C0B 01AB6880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8478: BF870001
	v_lshlrev_b32_e32 v11, 2, v11                              // 0000001A847C: 30161682
	s_waitcnt lgkmcnt(0)                                       // 0000001A8480: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A8484: 06121509
	ds_bpermute_b32 v10, v11, v9                               // 0000001A8488: DACC0000 0A00090B
	s_waitcnt lgkmcnt(0)                                       // 0000001A8490: BF89FC07
	v_add_f32_e32 v9, v9, v10                                  // 0000001A8494: 06121509
	ds_bpermute_b32 v9, v107, v9                               // 0000001A8498: DACC0000 0900096B
	s_waitcnt lgkmcnt(0)                                       // 0000001A84A0: BF89FC07
	v_div_scale_f32 v10, null, s62, s62, v9                    // 0000001A84A4: D6FC7C0A 04247C3E
	v_div_scale_f32 v13, vcc_lo, v9, s62, v9                   // 0000001A84AC: D6FC6A0D 04247D09
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A84B4: BF870292
	v_rcp_f32_e32 v11, v10                                     // 0000001A84B8: 7E16550A
	v_fma_f32 v12, -v10, v11, 1.0                              // 0000001A84BC: D613000C 23CA170A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A84C4: BF8700A1
	v_fmac_f32_e32 v11, v12, v11                               // 0000001A84C8: 5616170C
	s_waitcnt vmcnt(0)                                         // 0000001A84CC: BF8903F7
	v_dual_mul_f32 v12, v13, v11 :: v_dual_lshlrev_b32 v1, 16, v1// 0000001A84D0: C8E2170D 0C000290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A84D8: BF870091
	v_fma_f32 v18, -v10, v12, v13                              // 0000001A84DC: D6130012 2436190A
	v_fmac_f32_e32 v12, v18, v11                               // 0000001A84E4: 56181712
	v_rcp_f32_e32 v18, v16                                     // 0000001A84E8: 7E245510
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A84EC: BF870121
	v_fma_f32 v10, -v10, v12, v13                              // 0000001A84F0: D613000A 2436190A
	v_fma_f32 v13, -v14, v19, 1.0                              // 0000001A84F8: D613000D 23CA270E
	v_div_fmas_f32 v10, v10, v11, v12                          // 0000001A8500: D637000A 0432170A
	s_mov_b32 vcc_lo, s0                                       // 0000001A8508: BEEA0000
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A850C: BF870115
	v_fma_f32 v11, -v16, v18, 1.0                              // 0000001A8510: D613000B 23CA2510
	v_div_fixup_f32 v9, v10, s62, v9                           // 0000001A8518: D6270009 04247D0A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A8520: BF870091
	v_dual_fmac_f32 v18, v11, v18 :: v_dual_add_f32 v9, 0x358637bd, v9// 0000001A8524: C808250B 120812FF 358637BD
	v_mul_f32_e32 v33, 0x4b800000, v9                          // 0000001A8530: 104212FF 4B800000
	.long 0xd414000b                                           // 0000001A8538: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v9, vcc_lo                 // 0000001A853C: 020212FF 00800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A8544: BF870091
	v_cndmask_b32_e64 v9, v9, v33, s11                         // 0000001A8548: D5010009 002E4309
	v_rsq_f32_e32 v9, v9                                       // 0000001A8550: 7E125D09
	v_fmac_f32_e32 v19, v13, v19                               // 0000001A8554: 5626270D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A8558: BF870091
	v_dual_mul_f32 v1, 0xbfb8aa3b, v1 :: v_dual_mul_f32 v10, v21, v19// 0000001A855C: C8C602FF 010A2715 BFB8AA3B
	v_exp_f32_e32 v1, v1                                       // 0000001A8568: 7E024B01
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A856C: BF870091
	v_fma_f32 v31, -v14, v10, v21                              // 0000001A8570: D613001F 2456150E
	v_fmac_f32_e32 v10, v31, v19                               // 0000001A8578: 5614271F
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A857C: BF870091
	v_fma_f32 v14, -v14, v10, v21                              // 0000001A8580: D613000E 2456150E
	v_div_fmas_f32 v10, v14, v19, v10                          // 0000001A8588: D637000A 042A270E
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A8590: BF870116
	v_mul_f32_e32 v14, 0x45800000, v9                          // 0000001A8594: 101C12FF 45800000
	v_div_fixup_f32 v4, v10, v4, 1.0                           // 0000001A859C: D6270004 03CA090A
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A85A4: BF870002
	v_cndmask_b32_e64 v9, v9, v14, s11                         // 0000001A85A8: D5010009 002E1D09
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000001A85B0: BF870085
	v_dual_add_f32 v1, 1.0, v1 :: v_dual_mul_f32 v6, v9, v6    // 0000001A85B4: C90602F2 01060D09
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A85BC: BF870231
	v_div_scale_f32 v17, null, v1, v1, 1.0                     // 0000001A85C0: D6FC7C11 03CA0301
	v_mul_f32_e32 v5, v9, v5                                   // 0000001A85C8: 100A0B09
	v_div_scale_f32 v29, s10, 1.0, v1, 1.0                     // 0000001A85CC: D6FC0A1D 03CA02F2
	v_dual_mul_f32 v7, v9, v7 :: v_dual_mul_f32 v6, v6, v26    // 0000001A85D4: C8C60F09 07063506
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A85DC: BF870194
	v_rcp_f32_e32 v23, v17                                     // 0000001A85E0: 7E2E5511
	v_mul_f32_e32 v5, v5, v25                                  // 0000001A85E4: 100A3305
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A85E8: BF870112
	v_dual_mul_f32 v8, v9, v8 :: v_dual_mul_f32 v7, v7, v27    // 0000001A85EC: C8C61109 08063707
	v_mul_f32_e32 v4, v4, v5                                   // 0000001A85F4: 10080B04
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A85F8: BF870292
	v_mul_f32_e32 v8, v8, v28                                  // 0000001A85FC: 10103908
	v_fma_f32 v12, -v17, v23, 1.0                              // 0000001A8600: D613000C 23CA2F11
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8608: BF870001
	v_fmac_f32_e32 v23, v12, v23                               // 0000001A860C: 562E2F0C
	v_mul_f32_e32 v12, v24, v18                                // 0000001A8610: 10182518
	v_div_scale_f32 v22, s1, 1.0, v3, 1.0                      // 0000001A8614: D6FC0116 03CA06F2
	s_mov_b32 vcc_lo, s1                                       // 0000001A861C: BEEA0001
	v_mul_f32_e32 v13, v29, v23                                // 0000001A8620: 101A2F1D
	v_fma_f32 v34, -v16, v12, v24                              // 0000001A8624: D6130022 24621910
	v_mul_f32_e32 v11, v22, v20                                // 0000001A862C: 10162916
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A8630: BF870193
	v_fma_f32 v35, -v17, v13, v29                              // 0000001A8634: D6130023 24761B11
	v_fmac_f32_e32 v12, v34, v18                               // 0000001A863C: 56182522
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A8640: BF870193
	v_fma_f32 v32, -v15, v11, v22                              // 0000001A8644: D6130020 245A170F
	v_fmac_f32_e32 v13, v35, v23                               // 0000001A864C: 561A2F23
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A8650: BF870193
	v_fma_f32 v16, -v16, v12, v24                              // 0000001A8654: D6130010 24621910
	v_fmac_f32_e32 v11, v32, v20                               // 0000001A865C: 56162920
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A8660: BF870113
	v_fma_f32 v17, -v17, v13, v29                              // 0000001A8664: D6130011 24761B11
	v_fma_f32 v15, -v15, v11, v22                              // 0000001A866C: D613000F 245A170F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_2)// 0000001A8674: BF870141
	v_div_fmas_f32 v11, v15, v20, v11                          // 0000001A8678: D637000B 042E290F
	s_mov_b32 vcc_lo, s9                                       // 0000001A8680: BEEA0009
	v_div_fmas_f32 v12, v16, v18, v12                          // 0000001A8684: D637000C 04322510
	s_mov_b32 vcc_lo, s10                                      // 0000001A868C: BEEA000A
	v_div_fixup_f32 v3, v11, v3, 1.0                           // 0000001A8690: D6270003 03CA070B
	v_div_fmas_f32 v10, v17, v23, v13                          // 0000001A8698: D637000A 04362F11
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A86A0: BF870193
	v_div_fixup_f32 v2, v12, v2, 1.0                           // 0000001A86A4: D6270002 03CA050C
	v_mul_f32_e32 v3, v3, v6                                   // 0000001A86AC: 10060D03
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A86B0: BF870193
	v_div_fixup_f32 v1, v10, v1, 1.0                           // 0000001A86B4: D6270001 03CA030A
	v_mul_f32_e32 v5, v2, v7                                   // 0000001A86BC: 100A0F02
	v_bfe_u32 v7, v4, 16, 1                                    // 0000001A86C0: D6100007 02052104
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A86C8: BF870003
	v_mul_f32_e32 v6, v1, v8                                   // 0000001A86CC: 100C1101
	v_mad_u64_u32 v[1:2], null, 0x3000, v30, v[114:115]        // 0000001A86D0: D6FE7C01 05CA3CFF 00003000
	v_bfe_u32 v8, v3, 16, 1                                    // 0000001A86DC: D6100008 02052103
	v_bfe_u32 v9, v5, 16, 1                                    // 0000001A86E4: D6100009 02052105
	v_add3_u32 v4, v4, v7, 0x7fff                              // 0000001A86EC: D6550004 03FE0F04 00007FFF
	v_bfe_u32 v10, v6, 16, 1                                   // 0000001A86F8: D610000A 02052106
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A8700: BF870214
	v_add3_u32 v3, v3, v8, 0x7fff                              // 0000001A8704: D6550003 03FE1103 00007FFF
	v_add3_u32 v5, v5, v9, 0x7fff                              // 0000001A8710: D6550005 03FE1305 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A871C: BF870003
	v_add3_u32 v6, v6, v10, 0x7fff                             // 0000001A8720: D6550006 03FE1506 00007FFF
	s_clause 0x3                                               // 0000001A872C: BF850003
	global_store_d16_hi_b16 v[1:2], v4, off                    // 0000001A8730: DC960000 007C0401
	global_store_d16_hi_b16 v[1:2], v3, off offset:64          // 0000001A8738: DC960040 007C0301
	global_store_d16_hi_b16 v[1:2], v5, off offset:128         // 0000001A8740: DC960080 007C0501
	global_store_d16_hi_b16 v[1:2], v6, off offset:192         // 0000001A8748: DC9600C0 007C0601
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A8750: 8C7E0C7E
	s_cmp_lg_u32 s29, s52                                      // 0000001A8754: BF07341D
	s_cbranch_scc1 63838                                       // 0000001A8758: BFA2F95E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x72d4>
	s_waitcnt vmcnt(0)                                         // 0000001A875C: BF8903F7
	v_dual_mov_b32 v1, v116 :: v_dual_mov_b32 v4, v125         // 0000001A8760: CA100174 0104017D
	v_dual_mov_b32 v3, v135 :: v_dual_mov_b32 v2, v117         // 0000001A8768: CA100187 03020175
	s_mov_b32 s1, 0                                            // 0000001A8770: BE810080
	s_nop 0                                                    // 0000001A8774: BF800000
	s_nop 0                                                    // 0000001A8778: BF800000
	s_nop 0                                                    // 0000001A877C: BF800000
	ds_load_b32 v5, v3                                         // 0000001A8780: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001A8788: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001A8790: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001A8794: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001A8798: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001A87A0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001A87A4: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001A87A8: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001A87B0: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001A87B4: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001A87BC: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001A87C4: 917E017E
	s_cbranch_execnz 65517                                     // 0000001A87C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8d80>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001A87CC: 8C7E017E
	s_cmp_lg_u32 s29, s53                                      // 0000001A87D0: BF07351D
	s_cbranch_scc1 63809                                       // 0000001A87D4: BFA2F941 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x72dc>
	s_waitcnt vmcnt(2)                                         // 0000001A87D8: BF890BF7
	v_dual_mov_b32 v3, v135 :: v_dual_mov_b32 v4, v125         // 0000001A87DC: CA100187 0304017D
	s_waitcnt vmcnt(0)                                         // 0000001A87E4: BF8903F7
	v_dual_mov_b32 v1, v118 :: v_dual_mov_b32 v2, v119         // 0000001A87E8: CA100176 01020177
	s_mov_b32 s1, 0                                            // 0000001A87F0: BE810080
	s_nop 0                                                    // 0000001A87F4: BF800000
	s_nop 0                                                    // 0000001A87F8: BF800000
	s_nop 0                                                    // 0000001A87FC: BF800000
	ds_load_b32 v5, v3                                         // 0000001A8800: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001A8808: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001A8810: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001A8814: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001A8818: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001A8820: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001A8824: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001A8828: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001A8830: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001A8834: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001A883C: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001A8844: 917E017E
	s_cbranch_execnz 65517                                     // 0000001A8848: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8e00>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001A884C: 8C7E017E
	s_cmp_lg_u32 s29, s54                                      // 0000001A8850: BF07361D
	s_cbranch_scc1 56786                                       // 0000001A8854: BFA2DDD2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a0>
	s_waitcnt vmcnt(0)                                         // 0000001A8858: BF8903F7
	v_dual_mov_b32 v1, v120 :: v_dual_mov_b32 v4, v125         // 0000001A885C: CA100178 0104017D
	v_dual_mov_b32 v3, v135 :: v_dual_mov_b32 v2, v121         // 0000001A8864: CA100187 03020179
	s_mov_b32 s1, 0                                            // 0000001A886C: BE810080
	s_nop 0                                                    // 0000001A8870: BF800000
	s_nop 0                                                    // 0000001A8874: BF800000
	s_nop 0                                                    // 0000001A8878: BF800000
	s_nop 0                                                    // 0000001A887C: BF800000
	ds_load_b32 v5, v3                                         // 0000001A8880: D8D80000 05000003
	v_add_nc_u32_e32 v4, 0x80, v4                              // 0000001A8888: 4A0808FF 00000080
	v_add_nc_u32_e32 v3, 8, v3                                 // 0000001A8890: 4A060688
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001A8894: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v4                        // 0000001A8898: 7C9208FF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001A88A0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001A88A4: BF89FC07
	global_store_b32 v[1:2], v5, off                           // 0000001A88A8: DC6A0000 007C0501
	.long 0xd7000001                                           // 0000001A88B0: D7000001
	v_cndmask_b32_e32 v1, 0x400, v1, vcc_lo                    // 0000001A88B4: 020202FF 00000400
	v_add_co_ci_u32_e64 v2, null, 0, v2, s0                    // 0000001A88BC: D5207C02 00020480
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001A88C4: 917E017E
	s_cbranch_execnz 65517                                     // 0000001A88C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8e80>
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001A88CC: 8C7E017E
	s_branch 56755                                             // 0000001A88D0: BFA0DDB3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x5a0>
	ds_load_b32 v65, v146                                      // 0000001A88D4: D8D80000 41000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A88DC: BF89FC07
	v_fma_f32 v25, v25, v65, v57                               // 0000001A88E0: D6130019 04E68319
	v_mad_u64_u32 v[65:66], null, 0x3000, v182, v[112:113]     // 0000001A88E8: D6FE7C41 05C36CFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A88F4: BF870092
	v_mul_f32_e32 v25, 0x3b800000, v25                         // 0000001A88F8: 103232FF 3B800000
	v_bfe_u32 v57, v25, 16, 1                                  // 0000001A8900: D6100039 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8908: BF870001
	v_add3_u32 v25, v25, v57, 0x7fff                           // 0000001A890C: D6550019 03FE7319 00007FFF
	global_store_d16_hi_b16 v[65:66], v25, off                 // 0000001A8918: DC960000 007C1941
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8920: 8C7E0F7E
	s_and_saveexec_b32 s15, s14                                // 0000001A8924: BE8F200E
	s_cbranch_execz 62969                                      // 0000001A8928: BFA5F5F9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6710>
	ds_load_b32 v25, v146 offset:8                             // 0000001A892C: D8D80008 19000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8934: BF89FC07
	v_fma_f32 v25, v26, v25, v58                               // 0000001A8938: D6130019 04EA331A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8940: BF870121
	v_mul_f32_e32 v57, 0x3b800000, v25                         // 0000001A8944: 107232FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v189, v[112:113]     // 0000001A894C: D6FE7C19 05C37AFF 00003000
	v_bfe_u32 v58, v57, 16, 1                                  // 0000001A8958: D610003A 02052139
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8960: BF870001
	v_add3_u32 v57, v57, v58, 0x7fff                           // 0000001A8964: D6550039 03FE7539 00007FFF
	global_store_d16_hi_b16 v[25:26], v57, off                 // 0000001A8970: DC960000 007C3919
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8978: 8C7E0F7E
	s_and_saveexec_b32 s15, s13                                // 0000001A897C: BE8F200D
	s_cbranch_execz 62950                                      // 0000001A8980: BFA5F5E6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x671c>
	ds_load_b32 v25, v146 offset:16                            // 0000001A8984: D8D80010 19000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A898C: BF89FC07
	v_fma_f32 v25, v27, v25, v59                               // 0000001A8990: D6130019 04EE331B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8998: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001A899C: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v188, v[112:113]     // 0000001A89A4: D6FE7C19 05C378FF 00003000
	v_bfe_u32 v57, v27, 16, 1                                  // 0000001A89B0: D6100039 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A89B8: BF870001
	v_add3_u32 v27, v27, v57, 0x7fff                           // 0000001A89BC: D655001B 03FE731B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001A89C8: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A89D0: 8C7E0F7E
	s_and_saveexec_b32 s15, s12                                // 0000001A89D4: BE8F200C
	s_cbranch_execz 62931                                      // 0000001A89D8: BFA5F5D3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6728>
	ds_load_b32 v25, v146 offset:24                            // 0000001A89DC: D8D80018 19000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A89E4: BF89FC07
	v_fma_f32 v25, v28, v25, v60                               // 0000001A89E8: D6130019 04F2331C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A89F0: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001A89F4: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v187, v[112:113]     // 0000001A89FC: D6FE7C19 05C376FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001A8A08: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8A10: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001A8A14: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001A8A20: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8A28: 8C7E0F7E
	s_and_saveexec_b32 s15, s10                                // 0000001A8A2C: BE8F200A
	s_cbranch_execz 62912                                      // 0000001A8A30: BFA5F5C0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6734>
	ds_load_b32 v25, v146 offset:32                            // 0000001A8A34: D8D80020 19000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8A3C: BF89FC07
	v_fma_f32 v25, v29, v25, v61                               // 0000001A8A40: D6130019 04F6331D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8A48: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001A8A4C: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v186, v[112:113]     // 0000001A8A54: D6FE7C19 05C374FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001A8A60: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8A68: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001A8A6C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001A8A78: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8A80: 8C7E0F7E
	s_and_saveexec_b32 s15, s1                                 // 0000001A8A84: BE8F2001
	s_cbranch_execz 62893                                      // 0000001A8A88: BFA5F5AD <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6740>
	ds_load_b32 v25, v146 offset:40                            // 0000001A8A8C: D8D80028 19000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8A94: BF89FC07
	v_fma_f32 v25, v30, v25, v62                               // 0000001A8A98: D6130019 04FA331E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8AA0: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001A8AA4: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v185, v[112:113]     // 0000001A8AAC: D6FE7C19 05C372FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001A8AB8: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8AC0: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001A8AC4: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001A8AD0: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8AD8: 8C7E0F7E
	s_and_saveexec_b32 s15, s9                                 // 0000001A8ADC: BE8F2009
	s_cbranch_execz 62874                                      // 0000001A8AE0: BFA5F59A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x674c>
	ds_load_b32 v25, v146 offset:48                            // 0000001A8AE4: D8D80030 19000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8AEC: BF89FC07
	v_fma_f32 v25, v31, v25, v63                               // 0000001A8AF0: D6130019 04FE331F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8AF8: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001A8AFC: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v184, v[112:113]     // 0000001A8B04: D6FE7C19 05C370FF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001A8B10: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8B18: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001A8B1C: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001A8B28: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8B30: 8C7E0F7E
	s_and_saveexec_b32 s15, s0                                 // 0000001A8B34: BE8F2000
	s_cbranch_execz 62855                                      // 0000001A8B38: BFA5F587 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6758>
	ds_load_b32 v25, v146 offset:56                            // 0000001A8B3C: D8D80038 19000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8B44: BF89FC07
	v_fma_f32 v25, v32, v25, v64                               // 0000001A8B48: D6130019 05023320
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8B50: BF870121
	v_mul_f32_e32 v27, 0x3b800000, v25                         // 0000001A8B54: 103632FF 3B800000
	v_mad_u64_u32 v[25:26], null, 0x3000, v183, v[112:113]     // 0000001A8B5C: D6FE7C19 05C36EFF 00003000
	v_bfe_u32 v28, v27, 16, 1                                  // 0000001A8B68: D610001C 0205211B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8B70: BF870001
	v_add3_u32 v27, v27, v28, 0x7fff                           // 0000001A8B74: D655001B 03FE391B 00007FFF
	global_store_d16_hi_b16 v[25:26], v27, off                 // 0000001A8B80: DC960000 007C1B19
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8B88: 8C7E0F7E
	s_and_saveexec_b32 s15, s11                                // 0000001A8B8C: BE8F200B
	s_cbranch_execz 62836                                      // 0000001A8B90: BFA5F574 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6764>
	ds_load_b32 v25, v146                                      // 0000001A8B94: D8D80000 19000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8B9C: BF89FC07
	v_fma_f32 v9, v9, v25, v49                                 // 0000001A8BA0: D6130009 04C63309
	v_mad_u64_u32 v[25:26], null, 0x3000, v182, v[112:113]     // 0000001A8BA8: D6FE7C19 05C36CFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A8BB4: BF870092
	v_mul_f32_e32 v9, 0x3b800000, v9                           // 0000001A8BB8: 101212FF 3B800000
	v_bfe_u32 v27, v9, 16, 1                                   // 0000001A8BC0: D610001B 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8BC8: BF870001
	v_add3_u32 v9, v9, v27, 0x7fff                             // 0000001A8BCC: D6550009 03FE3709 00007FFF
	global_store_d16_hi_b16 v[25:26], v9, off offset:32        // 0000001A8BD8: DC960020 007C0919
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8BE0: 8C7E0F7E
	s_and_saveexec_b32 s15, s14                                // 0000001A8BE4: BE8F200E
	s_cbranch_execz 62817                                      // 0000001A8BE8: BFA5F561 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6770>
	ds_load_b32 v9, v146 offset:8                              // 0000001A8BEC: D8D80008 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8BF4: BF89FC07
	v_fma_f32 v9, v10, v9, v50                                 // 0000001A8BF8: D6130009 04CA130A
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8C00: BF870121
	v_mul_f32_e32 v25, 0x3b800000, v9                          // 0000001A8C04: 103212FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v189, v[112:113]      // 0000001A8C0C: D6FE7C09 05C37AFF 00003000
	v_bfe_u32 v26, v25, 16, 1                                  // 0000001A8C18: D610001A 02052119
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8C20: BF870001
	v_add3_u32 v25, v25, v26, 0x7fff                           // 0000001A8C24: D6550019 03FE3519 00007FFF
	global_store_d16_hi_b16 v[9:10], v25, off offset:32        // 0000001A8C30: DC960020 007C1909
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8C38: 8C7E0F7E
	s_and_saveexec_b32 s15, s13                                // 0000001A8C3C: BE8F200D
	s_cbranch_execz 62798                                      // 0000001A8C40: BFA5F54E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x677c>
	ds_load_b32 v9, v146 offset:16                             // 0000001A8C44: D8D80010 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8C4C: BF89FC07
	v_fma_f32 v9, v11, v9, v51                                 // 0000001A8C50: D6130009 04CE130B
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8C58: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001A8C5C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v188, v[112:113]      // 0000001A8C64: D6FE7C09 05C378FF 00003000
	v_bfe_u32 v25, v11, 16, 1                                  // 0000001A8C70: D6100019 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8C78: BF870001
	v_add3_u32 v11, v11, v25, 0x7fff                           // 0000001A8C7C: D655000B 03FE330B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001A8C88: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8C90: 8C7E0F7E
	s_and_saveexec_b32 s15, s12                                // 0000001A8C94: BE8F200C
	s_cbranch_execz 62779                                      // 0000001A8C98: BFA5F53B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6788>
	ds_load_b32 v9, v146 offset:24                             // 0000001A8C9C: D8D80018 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8CA4: BF89FC07
	v_fma_f32 v9, v12, v9, v52                                 // 0000001A8CA8: D6130009 04D2130C
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8CB0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001A8CB4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v187, v[112:113]      // 0000001A8CBC: D6FE7C09 05C376FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001A8CC8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8CD0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001A8CD4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001A8CE0: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8CE8: 8C7E0F7E
	s_and_saveexec_b32 s15, s10                                // 0000001A8CEC: BE8F200A
	s_cbranch_execz 62760                                      // 0000001A8CF0: BFA5F528 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6794>
	ds_load_b32 v9, v146 offset:32                             // 0000001A8CF4: D8D80020 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8CFC: BF89FC07
	v_fma_f32 v9, v13, v9, v53                                 // 0000001A8D00: D6130009 04D6130D
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8D08: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001A8D0C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v186, v[112:113]      // 0000001A8D14: D6FE7C09 05C374FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001A8D20: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8D28: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001A8D2C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001A8D38: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8D40: 8C7E0F7E
	s_and_saveexec_b32 s15, s1                                 // 0000001A8D44: BE8F2001
	s_cbranch_execz 62741                                      // 0000001A8D48: BFA5F515 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67a0>
	ds_load_b32 v9, v146 offset:40                             // 0000001A8D4C: D8D80028 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8D54: BF89FC07
	v_fma_f32 v9, v14, v9, v54                                 // 0000001A8D58: D6130009 04DA130E
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8D60: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001A8D64: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v185, v[112:113]      // 0000001A8D6C: D6FE7C09 05C372FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001A8D78: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8D80: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001A8D84: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001A8D90: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8D98: 8C7E0F7E
	s_and_saveexec_b32 s15, s9                                 // 0000001A8D9C: BE8F2009
	s_cbranch_execz 62722                                      // 0000001A8DA0: BFA5F502 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67ac>
	ds_load_b32 v9, v146 offset:48                             // 0000001A8DA4: D8D80030 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8DAC: BF89FC07
	v_fma_f32 v9, v15, v9, v55                                 // 0000001A8DB0: D6130009 04DE130F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8DB8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001A8DBC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v184, v[112:113]      // 0000001A8DC4: D6FE7C09 05C370FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001A8DD0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8DD8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001A8DDC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001A8DE8: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8DF0: 8C7E0F7E
	s_and_saveexec_b32 s15, s0                                 // 0000001A8DF4: BE8F2000
	s_cbranch_execz 62703                                      // 0000001A8DF8: BFA5F4EF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67b8>
	ds_load_b32 v9, v146 offset:56                             // 0000001A8DFC: D8D80038 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8E04: BF89FC07
	v_fma_f32 v9, v16, v9, v56                                 // 0000001A8E08: D6130009 04E21310
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8E10: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001A8E14: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v183, v[112:113]      // 0000001A8E1C: D6FE7C09 05C36EFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001A8E28: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8E30: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001A8E34: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:32        // 0000001A8E40: DC960020 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8E48: 8C7E0F7E
	s_and_saveexec_b32 s15, s11                                // 0000001A8E4C: BE8F200B
	s_cbranch_execz 62684                                      // 0000001A8E50: BFA5F4DC <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67c4>
	ds_load_b32 v9, v146                                       // 0000001A8E54: D8D80000 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8E5C: BF89FC07
	v_fma_f32 v9, v17, v9, v41                                 // 0000001A8E60: D6130009 04A61311
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8E68: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001A8E6C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v182, v[112:113]      // 0000001A8E74: D6FE7C09 05C36CFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001A8E80: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8E88: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001A8E8C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001A8E98: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8EA0: 8C7E0F7E
	s_and_saveexec_b32 s15, s14                                // 0000001A8EA4: BE8F200E
	s_cbranch_execz 62665                                      // 0000001A8EA8: BFA5F4C9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67d0>
	ds_load_b32 v9, v146 offset:8                              // 0000001A8EAC: D8D80008 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8EB4: BF89FC07
	v_fma_f32 v9, v18, v9, v42                                 // 0000001A8EB8: D6130009 04AA1312
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8EC0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001A8EC4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v189, v[112:113]      // 0000001A8ECC: D6FE7C09 05C37AFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001A8ED8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8EE0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001A8EE4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001A8EF0: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8EF8: 8C7E0F7E
	s_and_saveexec_b32 s15, s13                                // 0000001A8EFC: BE8F200D
	s_cbranch_execz 62646                                      // 0000001A8F00: BFA5F4B6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67dc>
	ds_load_b32 v9, v146 offset:16                             // 0000001A8F04: D8D80010 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8F0C: BF89FC07
	v_fma_f32 v9, v19, v9, v43                                 // 0000001A8F10: D6130009 04AE1313
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8F18: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001A8F1C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v188, v[112:113]      // 0000001A8F24: D6FE7C09 05C378FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001A8F30: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8F38: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001A8F3C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001A8F48: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8F50: 8C7E0F7E
	s_and_saveexec_b32 s15, s12                                // 0000001A8F54: BE8F200C
	s_cbranch_execz 62627                                      // 0000001A8F58: BFA5F4A3 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67e8>
	ds_load_b32 v9, v146 offset:24                             // 0000001A8F5C: D8D80018 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8F64: BF89FC07
	v_fma_f32 v9, v20, v9, v44                                 // 0000001A8F68: D6130009 04B21314
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8F70: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001A8F74: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v187, v[112:113]      // 0000001A8F7C: D6FE7C09 05C376FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001A8F88: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8F90: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001A8F94: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001A8FA0: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A8FA8: 8C7E0F7E
	s_and_saveexec_b32 s15, s10                                // 0000001A8FAC: BE8F200A
	s_cbranch_execz 62608                                      // 0000001A8FB0: BFA5F490 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x67f4>
	ds_load_b32 v9, v146 offset:32                             // 0000001A8FB4: D8D80020 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A8FBC: BF89FC07
	v_fma_f32 v9, v21, v9, v45                                 // 0000001A8FC0: D6130009 04B61315
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A8FC8: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001A8FCC: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v186, v[112:113]      // 0000001A8FD4: D6FE7C09 05C374FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001A8FE0: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A8FE8: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001A8FEC: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001A8FF8: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A9000: 8C7E0F7E
	s_and_saveexec_b32 s15, s1                                 // 0000001A9004: BE8F2001
	s_cbranch_execz 62589                                      // 0000001A9008: BFA5F47D <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6800>
	ds_load_b32 v9, v146 offset:40                             // 0000001A900C: D8D80028 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A9014: BF89FC07
	v_fma_f32 v9, v22, v9, v46                                 // 0000001A9018: D6130009 04BA1316
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A9020: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001A9024: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v185, v[112:113]      // 0000001A902C: D6FE7C09 05C372FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001A9038: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A9040: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001A9044: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001A9050: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A9058: 8C7E0F7E
	s_and_saveexec_b32 s15, s9                                 // 0000001A905C: BE8F2009
	s_cbranch_execz 62570                                      // 0000001A9060: BFA5F46A <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x680c>
	ds_load_b32 v9, v146 offset:48                             // 0000001A9064: D8D80030 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A906C: BF89FC07
	v_fma_f32 v9, v23, v9, v47                                 // 0000001A9070: D6130009 04BE1317
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A9078: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001A907C: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v184, v[112:113]      // 0000001A9084: D6FE7C09 05C370FF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001A9090: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A9098: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001A909C: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001A90A8: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A90B0: 8C7E0F7E
	s_and_saveexec_b32 s15, s0                                 // 0000001A90B4: BE8F2000
	s_cbranch_execz 62551                                      // 0000001A90B8: BFA5F457 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6818>
	ds_load_b32 v9, v146 offset:56                             // 0000001A90BC: D8D80038 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A90C4: BF89FC07
	v_fma_f32 v9, v24, v9, v48                                 // 0000001A90C8: D6130009 04C21318
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A90D0: BF870121
	v_mul_f32_e32 v11, 0x3b800000, v9                          // 0000001A90D4: 101612FF 3B800000
	v_mad_u64_u32 v[9:10], null, 0x3000, v183, v[112:113]      // 0000001A90DC: D6FE7C09 05C36EFF 00003000
	v_bfe_u32 v12, v11, 16, 1                                  // 0000001A90E8: D610000C 0205210B
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A90F0: BF870001
	v_add3_u32 v11, v11, v12, 0x7fff                           // 0000001A90F4: D655000B 03FE190B 00007FFF
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001A9100: DC960040 007C0B09
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A9108: 8C7E0F7E
	s_and_saveexec_b32 s15, s11                                // 0000001A910C: BE8F200B
	s_cbranch_execz 62532                                      // 0000001A9110: BFA5F444 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6824>
	ds_load_b32 v9, v146                                       // 0000001A9114: D8D80000 09000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A911C: BF89FC07
	v_fma_f32 v1, v1, v9, v33                                  // 0000001A9120: D6130001 04861301
	v_mad_u64_u32 v[9:10], null, 0x3000, v182, v[112:113]      // 0000001A9128: D6FE7C09 05C36CFF 00003000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9134: BF870092
	v_mul_f32_e32 v1, 0x3b800000, v1                           // 0000001A9138: 100202FF 3B800000
	v_bfe_u32 v11, v1, 16, 1                                   // 0000001A9140: D610000B 02052101
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A9148: BF870001
	v_add3_u32 v1, v1, v11, 0x7fff                             // 0000001A914C: D6550001 03FE1701 00007FFF
	global_store_d16_hi_b16 v[9:10], v1, off offset:96         // 0000001A9158: DC960060 007C0109
	s_or_b32 exec_lo, exec_lo, s15                             // 0000001A9160: 8C7E0F7E
	s_and_saveexec_b32 s11, s14                                // 0000001A9164: BE8B200E
	s_cbranch_execz 62513                                      // 0000001A9168: BFA5F431 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6830>
	ds_load_b32 v1, v146 offset:8                              // 0000001A916C: D8D80008 01000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A9174: BF89FC07
	v_fma_f32 v1, v2, v1, v34                                  // 0000001A9178: D6130001 048A0302
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A9180: BF870121
	v_mul_f32_e32 v9, 0x3b800000, v1                           // 0000001A9184: 101202FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v189, v[112:113]       // 0000001A918C: D6FE7C01 05C37AFF 00003000
	v_bfe_u32 v10, v9, 16, 1                                   // 0000001A9198: D610000A 02052109
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A91A0: BF870001
	v_add3_u32 v9, v9, v10, 0x7fff                             // 0000001A91A4: D6550009 03FE1509 00007FFF
	global_store_d16_hi_b16 v[1:2], v9, off offset:96          // 0000001A91B0: DC960060 007C0901
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001A91B8: 8C7E0B7E
	s_and_saveexec_b32 s11, s13                                // 0000001A91BC: BE8B200D
	s_cbranch_execz 62494                                      // 0000001A91C0: BFA5F41E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x683c>
	ds_load_b32 v1, v146 offset:16                             // 0000001A91C4: D8D80010 01000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A91CC: BF89FC07
	v_fma_f32 v1, v3, v1, v35                                  // 0000001A91D0: D6130001 048E0303
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A91D8: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001A91DC: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v188, v[112:113]       // 0000001A91E4: D6FE7C01 05C378FF 00003000
	v_bfe_u32 v9, v3, 16, 1                                    // 0000001A91F0: D6100009 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A91F8: BF870001
	v_add3_u32 v3, v3, v9, 0x7fff                              // 0000001A91FC: D6550003 03FE1303 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001A9208: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001A9210: 8C7E0B7E
	s_and_saveexec_b32 s11, s12                                // 0000001A9214: BE8B200C
	s_cbranch_execz 62475                                      // 0000001A9218: BFA5F40B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6848>
	ds_load_b32 v1, v146 offset:24                             // 0000001A921C: D8D80018 01000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A9224: BF89FC07
	v_fma_f32 v1, v4, v1, v36                                  // 0000001A9228: D6130001 04920304
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A9230: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001A9234: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v187, v[112:113]       // 0000001A923C: D6FE7C01 05C376FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001A9248: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A9250: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001A9254: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001A9260: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001A9268: 8C7E0B7E
	s_and_saveexec_b32 s11, s10                                // 0000001A926C: BE8B200A
	s_cbranch_execz 62456                                      // 0000001A9270: BFA5F3F8 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6854>
	ds_load_b32 v1, v146 offset:32                             // 0000001A9274: D8D80020 01000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A927C: BF89FC07
	v_fma_f32 v1, v5, v1, v37                                  // 0000001A9280: D6130001 04960305
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A9288: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001A928C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v186, v[112:113]       // 0000001A9294: D6FE7C01 05C374FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001A92A0: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A92A8: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001A92AC: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001A92B8: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s11                             // 0000001A92C0: 8C7E0B7E
	s_and_saveexec_b32 s10, s1                                 // 0000001A92C4: BE8A2001
	s_cbranch_execz 62437                                      // 0000001A92C8: BFA5F3E5 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6860>
	ds_load_b32 v1, v146 offset:40                             // 0000001A92CC: D8D80028 01000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A92D4: BF89FC07
	v_fma_f32 v1, v6, v1, v38                                  // 0000001A92D8: D6130001 049A0306
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A92E0: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001A92E4: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v185, v[112:113]       // 0000001A92EC: D6FE7C01 05C372FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001A92F8: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A9300: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001A9304: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001A9310: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s10                             // 0000001A9318: 8C7E0A7E
	s_and_saveexec_b32 s1, s9                                  // 0000001A931C: BE812009
	s_cbranch_execz 62418                                      // 0000001A9320: BFA5F3D2 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x686c>
	ds_load_b32 v1, v146 offset:48                             // 0000001A9324: D8D80030 01000092
	s_waitcnt lgkmcnt(0)                                       // 0000001A932C: BF89FC07
	v_fma_f32 v1, v7, v1, v39                                  // 0000001A9330: D6130001 049E0307
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A9338: BF870121
	v_mul_f32_e32 v3, 0x3b800000, v1                           // 0000001A933C: 100602FF 3B800000
	v_mad_u64_u32 v[1:2], null, 0x3000, v184, v[112:113]       // 0000001A9344: D6FE7C01 05C370FF 00003000
	v_bfe_u32 v4, v3, 16, 1                                    // 0000001A9350: D6100004 02052103
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A9358: BF870001
	v_add3_u32 v3, v3, v4, 0x7fff                              // 0000001A935C: D6550003 03FE0903 00007FFF
	global_store_d16_hi_b16 v[1:2], v3, off offset:96          // 0000001A9368: DC960060 007C0301
	s_or_b32 exec_lo, exec_lo, s1                              // 0000001A9370: 8C7E017E
	s_and_saveexec_b32 s1, s0                                  // 0000001A9374: BE812000
	s_cbranch_execnz 62399                                     // 0000001A9378: BFA6F3BF <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x6878>
	s_branch 62416                                             // 0000001A937C: BFA0F3D0 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x68c0>
	v_mad_u64_u32 v[33:34], null, 0x1800, v181, v[110:111]     // 0000001A9380: D6FE7C21 05BB6AFF 00001800
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A938C: BF870091
	.long 0xd73c0021                                           // 0000001A9390: D73C0021
	v_cndmask_b32_e32 v1, 1, v33, vcc_lo                       // 0000001A9394: 02024281
	.long 0xd7006a23                                           // 0000001A9398: D7006A23
	v_cndmask_b32_e32 v1, s22, v33, vcc_lo                     // 0000001A939C: 02024216
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A93A0: BF8700A1
	v_add_co_ci_u32_e64 v36, null, s23, v34, vcc_lo            // 0000001A93A4: D5207C24 01AA4417
	.long 0xd7006a21                                           // 0000001A93AC: D7006A21
	v_cndmask_b32_e32 v1, s26, v33, vcc_lo                     // 0000001A93B0: 0202421A
	v_add_co_ci_u32_e64 v34, null, s27, v34, vcc_lo            // 0000001A93B4: D5207C22 01AA441B
	s_clause 0x3                                               // 0000001A93BC: BF850003
	global_load_u16 v37, v[35:36], off offset:192              // 0000001A93C0: DC4A00C0 257C0023
	global_load_u16 v38, v[35:36], off offset:64               // 0000001A93C8: DC4A0040 267C0023
	global_load_u16 v39, v[35:36], off                         // 0000001A93D0: DC4A0000 277C0023
	global_load_u16 v35, v[35:36], off offset:128              // 0000001A93D8: DC4A0080 237C0023
	s_clause 0x3                                               // 0000001A93E0: BF850003
	global_load_u16 v36, v[33:34], off offset:128              // 0000001A93E4: DC4A0080 247C0021
	global_load_u16 v40, v[33:34], off                         // 0000001A93EC: DC4A0000 287C0021
	global_load_u16 v41, v[33:34], off offset:64               // 0000001A93F4: DC4A0040 297C0021
	global_load_u16 v33, v[33:34], off offset:192              // 0000001A93FC: DC4A00C0 217C0021
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001A9404: 7C983A88
	s_waitcnt vmcnt(4)                                         // 0000001A9408: BF8913F7
	v_lshlrev_b32_e32 v35, 16, v35                             // 0000001A940C: 30464690
	v_lshlrev_b32_e32 v34, 16, v38                             // 0000001A9410: 30444C90
	s_waitcnt vmcnt(1)                                         // 0000001A9414: BF8907F7
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000001A9418: 30525290
	v_lshlrev_b32_e32 v40, 16, v40                             // 0000001A941C: 30505090
	v_and_b32_e32 v45, 16, v29                                 // 0000001A9420: 365A3A90
	v_mul_f32_e32 v43, v35, v35                                // 0000001A9424: 10564723
	v_dual_mul_f32 v39, v34, v34 :: v_dual_lshlrev_b32 v38, 16, v39// 0000001A9428: C8E24522 27264E90
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A9430: BF8701A4
	v_mul_f32_e32 v40, 0xbfb8aa3b, v40                         // 0000001A9434: 105050FF BFB8AA3B
	v_lshlrev_b32_e32 v36, 16, v36                             // 0000001A943C: 30484890
	v_dual_mul_f32 v42, v38, v38 :: v_dual_lshlrev_b32 v37, 16, v37// 0000001A9440: C8E24D26 2A244A90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9448: BF870113
	v_exp_f32_e32 v40, v40                                     // 0000001A944C: 7E504B28
	v_mul_f32_e32 v36, 0xbfb8aa3b, v36                         // 0000001A9450: 104848FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A9458: BF870192
	v_add_f32_e32 v42, v43, v42                                // 0000001A945C: 0654552B
	v_mul_f32_e32 v44, v37, v37                                // 0000001A9460: 10584B25
	v_add_lshl_u32 v43, v45, v180, 2                           // 0000001A9464: D647002B 020B692D
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A946C: BF870004
	v_exp_f32_e32 v36, v36                                     // 0000001A9470: 7E484B24
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_2)   // 0000001A9474: BF870106
	v_dual_add_f32 v39, v44, v39 :: v_dual_add_f32 v40, 1.0, v40// 0000001A9478: C9084F2C 272850F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9480: BF870111
	v_add_f32_e32 v39, v39, v42                                // 0000001A9484: 064E5527
	v_div_scale_f32 v46, null, v40, v40, 1.0                   // 0000001A9488: D6FC7C2E 03CA5128
	v_div_scale_f32 v53, s0, 1.0, v40, 1.0                     // 0000001A9490: D6FC0035 03CA50F2
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001A9498: BF870005
	v_add_f32_e32 v36, 1.0, v36                                // 0000001A949C: 064848F2
	ds_bpermute_b32 v42, v43, v39                              // 0000001A94A0: DACC0000 2A00272B
	v_cndmask_b32_e64 v43, 8, 0, vcc_lo                        // 0000001A94A8: D501002B 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001A94B0: 7C983A84
	v_rcp_f32_e32 v51, v46                                     // 0000001A94B4: 7E66552E
	v_div_scale_f32 v48, null, v36, v36, 1.0                   // 0000001A94B8: D6FC7C30 03CA4924
	v_div_scale_f32 v56, s9, 1.0, v36, 1.0                     // 0000001A94C0: D6FC0938 03CA48F2
	v_add_lshl_u32 v43, v43, v180, 2                           // 0000001A94C8: D647002B 020B692B
	s_waitcnt lgkmcnt(0)                                       // 0000001A94D0: BF89FC07
	v_add_f32_e32 v39, v39, v42                                // 0000001A94D4: 064E5527
	ds_bpermute_b32 v42, v43, v39                              // 0000001A94D8: DACC0000 2A00272B
	v_cndmask_b32_e64 v43, 4, 0, vcc_lo                        // 0000001A94E0: D501002B 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001A94E8: 7C983A82
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A94EC: BF870002
	v_add_lshl_u32 v43, v43, v180, 2                           // 0000001A94F0: D647002B 020B692B
	s_waitcnt lgkmcnt(0)                                       // 0000001A94F8: BF89FC07
	v_add_f32_e32 v39, v39, v42                                // 0000001A94FC: 064E5527
	ds_bpermute_b32 v42, v43, v39                              // 0000001A9500: DACC0000 2A00272B
	v_cndmask_b32_e64 v43, 2, 0, vcc_lo                        // 0000001A9508: D501002B 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001A9510: 7C9B689F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001A9514: BF8700D2
	v_add_lshl_u32 v43, v43, v180, 2                           // 0000001A9518: D647002B 020B692B
	s_waitcnt lgkmcnt(0)                                       // 0000001A9520: BF89FC07
	v_add_f32_e32 v39, v39, v42                                // 0000001A9524: 064E5527
	ds_bpermute_b32 v42, v43, v39                              // 0000001A9528: DACC0000 2A00272B
	v_add_co_ci_u32_e64 v43, null, 0, v180, vcc_lo             // 0000001A9530: D5207C2B 01AB6880
	v_lshlrev_b32_e32 v43, 2, v43                              // 0000001A9538: 30565682
	s_waitcnt lgkmcnt(0)                                       // 0000001A953C: BF89FC07
	v_add_f32_e32 v39, v39, v42                                // 0000001A9540: 064E5527
	ds_bpermute_b32 v42, v43, v39                              // 0000001A9544: DACC0000 2A00272B
	s_waitcnt lgkmcnt(0)                                       // 0000001A954C: BF89FC07
	v_add_f32_e32 v39, v39, v42                                // 0000001A9550: 064E5527
	ds_bpermute_b32 v39, v107, v39                             // 0000001A9554: DACC0000 2700276B
	s_waitcnt lgkmcnt(0)                                       // 0000001A955C: BF89FC07
	v_div_scale_f32 v42, null, s62, s62, v39                   // 0000001A9560: D6FC7C2A 049C7C3E
	v_div_scale_f32 v45, vcc_lo, v39, s62, v39                 // 0000001A9568: D6FC6A2D 049C7D27
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A9570: BF870292
	v_rcp_f32_e32 v43, v42                                     // 0000001A9574: 7E56552A
	v_fma_f32 v44, -v42, v43, 1.0                              // 0000001A9578: D613002C 23CA572A
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9580: BF870091
	v_fmac_f32_e32 v43, v44, v43                               // 0000001A9584: 5656572C
	v_mul_f32_e32 v44, v45, v43                                // 0000001A9588: 1058572D
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A958C: BF870091
	v_fma_f32 v50, -v42, v44, v45                              // 0000001A9590: D6130032 24B6592A
	v_fmac_f32_e32 v44, v50, v43                               // 0000001A9598: 56585732
	v_rcp_f32_e32 v50, v48                                     // 0000001A959C: 7E645530
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A95A0: BF870121
	v_fma_f32 v42, -v42, v44, v45                              // 0000001A95A4: D613002A 24B6592A
	v_fma_f32 v45, -v46, v51, 1.0                              // 0000001A95AC: D613002D 23CA672E
	v_div_fmas_f32 v42, v42, v43, v44                          // 0000001A95B4: D637002A 04B2572A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001A95BC: BF8702A2
	v_fmac_f32_e32 v51, v45, v51                               // 0000001A95C0: 5666672D
	v_mul_f32_e32 v41, 0xbfb8aa3b, v41                         // 0000001A95C4: 105252FF BFB8AA3B
	v_fma_f32 v43, -v48, v50, 1.0                              // 0000001A95CC: D613002B 23CA6530
	s_waitcnt vmcnt(0)                                         // 0000001A95D4: BF8903F7
	v_lshlrev_b32_e32 v33, 16, v33                             // 0000001A95D8: 30424290
	v_div_fixup_f32 v39, v42, s62, v39                         // 0000001A95DC: D6270027 049C7D2A
	v_mul_f32_e32 v42, v53, v51                                // 0000001A95E4: 10546735
	v_exp_f32_e32 v41, v41                                     // 0000001A95E8: 7E524B29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A95EC: BF870193
	v_dual_fmac_f32 v50, v43, v50 :: v_dual_mul_f32 v33, 0xbfb8aa3b, v33// 0000001A95F0: C806652B 322042FF BFB8AA3B
	v_add_f32_e32 v39, 0x358637bd, v39                         // 0000001A95FC: 064E4EFF 358637BD
	s_mov_b32 vcc_lo, s0                                       // 0000001A9604: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9608: BF870092
	v_exp_f32_e32 v33, v33                                     // 0000001A960C: 7E424B21
	v_mul_f32_e32 v60, 0x4b800000, v39                         // 0000001A9610: 10784EFF 4B800000
	.long 0xd414000b                                           // 0000001A9618: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v39, vcc_lo                // 0000001A961C: 02024EFF 00800000
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9624: BF870116
	v_add_f32_e32 v41, 1.0, v41                                // 0000001A9628: 065252F2
	v_cndmask_b32_e64 v39, v39, v60, s11                       // 0000001A962C: D5010027 002E7927
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A9634: BF8701A2
	v_div_scale_f32 v47, null, v41, v41, 1.0                   // 0000001A9638: D6FC7C2F 03CA5329
	v_div_scale_f32 v54, s1, 1.0, v41, 1.0                     // 0000001A9640: D6FC0136 03CA52F2
	v_rsq_f32_e32 v39, v39                                     // 0000001A9648: 7E4E5D27
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A964C: BF870292
	v_rcp_f32_e32 v52, v47                                     // 0000001A9650: 7E68552F
	v_fma_f32 v58, -v47, v52, 1.0                              // 0000001A9654: D613003A 23CA692F
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001A965C: BF8701B1
	v_fmac_f32_e32 v52, v58, v52                               // 0000001A9660: 5668693A
	v_fma_f32 v58, -v46, v42, v53                              // 0000001A9664: D613003A 24D6552E
	v_add_f32_e32 v33, 1.0, v33                                // 0000001A966C: 064242F2
	v_mul_f32_e32 v43, v54, v52                                // 0000001A9670: 10566936
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A9674: BF870193
	v_fmac_f32_e32 v42, v58, v51                               // 0000001A9678: 5654673A
	v_div_scale_f32 v49, null, v33, v33, 1.0                   // 0000001A967C: D6FC7C31 03CA4321
	v_div_scale_f32 v57, s10, 1.0, v33, 1.0                    // 0000001A9684: D6FC0A39 03CA42F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A968C: BF870193
	v_fma_f32 v46, -v46, v42, v53                              // 0000001A9690: D613002E 24D6552E
	v_rcp_f32_e32 v55, v49                                     // 0000001A9698: 7E6E5531
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001A969C: BF8701C1
	v_div_fmas_f32 v42, v46, v51, v42                          // 0000001A96A0: D637002A 04AA672E
	v_mul_f32_e32 v46, 0x45800000, v39                         // 0000001A96A8: 105C4EFF 45800000
	v_fma_f32 v59, -v47, v43, v54                              // 0000001A96B0: D613003B 24DA572F
	s_mov_b32 vcc_lo, s1                                       // 0000001A96B8: BEEA0001
	v_div_fixup_f32 v40, v42, v40, 1.0                         // 0000001A96BC: D6270028 03CA512A
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A96C4: BF8700A5
	v_fma_f32 v44, -v49, v55, 1.0                              // 0000001A96C8: D613002C 23CA6F31
	v_cndmask_b32_e64 v39, v39, v46, s11                       // 0000001A96D0: D5010027 002E5D27
	v_dual_fmac_f32 v55, v44, v55 :: v_dual_mul_f32 v34, v39, v34// 0000001A96D8: C8066F2C 37224527
	v_mul_f32_e32 v44, v56, v50                                // 0000001A96E0: 10586538
	v_mul_f32_e32 v38, v39, v38                                // 0000001A96E4: 104C4D27
	v_mul_f32_e32 v37, v39, v37                                // 0000001A96E8: 104A4B27
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A96EC: BF870214
	v_dual_mul_f32 v45, v57, v55 :: v_dual_mul_f32 v34, v34, v26// 0000001A96F0: C8C66F39 2D223522
	v_fma_f32 v61, -v48, v44, v56                              // 0000001A96F8: D613003D 24E25930
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A9700: BF870194
	v_dual_mul_f32 v38, v38, v25 :: v_dual_fmac_f32 v43, v59, v52// 0000001A9704: C8C03326 262A693B
	v_fma_f32 v62, -v49, v45, v57                              // 0000001A970C: D613003E 24E65B31
	v_mul_f32_e32 v37, v37, v28                                // 0000001A9714: 104A3925
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A9718: BF870214
	v_fmac_f32_e32 v44, v61, v50                               // 0000001A971C: 5658653D
	v_mul_f32_e32 v38, v40, v38                                // 0000001A9720: 104C4D28
	v_fma_f32 v47, -v47, v43, v54                              // 0000001A9724: D613002F 24DA572F
	v_fmac_f32_e32 v45, v62, v55                               // 0000001A972C: 565A6F3E
	v_mul_f32_e32 v35, v39, v35                                // 0000001A9730: 10464727
	v_fma_f32 v48, -v48, v44, v56                              // 0000001A9734: D6130030 24E25930
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A973C: BF870214
	v_div_fmas_f32 v43, v47, v52, v43                          // 0000001A9740: D637002B 04AE692F
	v_fma_f32 v49, -v49, v45, v57                              // 0000001A9748: D6130031 24E65B31
	s_mov_b32 vcc_lo, s9                                       // 0000001A9750: BEEA0009
	v_mul_f32_e32 v35, v35, v27                                // 0000001A9754: 10463723
	v_div_fmas_f32 v44, v48, v50, v44                          // 0000001A9758: D637002C 04B26530
	s_mov_b32 vcc_lo, s10                                      // 0000001A9760: BEEA000A
	v_div_fixup_f32 v41, v43, v41, 1.0                         // 0000001A9764: D6270029 03CA532B
	v_div_fmas_f32 v42, v49, v55, v45                          // 0000001A976C: D637002A 04B66F31
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A9774: BF870193
	v_div_fixup_f32 v36, v44, v36, 1.0                         // 0000001A9778: D6270024 03CA492C
	v_mul_f32_e32 v39, v41, v34                                // 0000001A9780: 104E4529
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A9784: BF870193
	v_div_fixup_f32 v33, v42, v33, 1.0                         // 0000001A9788: D6270021 03CA432A
	v_mul_f32_e32 v35, v36, v35                                // 0000001A9790: 10464724
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A9794: BF870193
	v_bfe_u32 v40, v39, 16, 1                                  // 0000001A9798: D6100028 02052127
	v_mul_f32_e32 v36, v33, v37                                // 0000001A97A0: 10484B21
	v_bfe_u32 v37, v38, 16, 1                                  // 0000001A97A4: D6100025 02052126
	v_mad_u64_u32 v[33:34], null, 0x3000, v181, v[114:115]     // 0000001A97AC: D6FE7C21 05CB6AFF 00003000
	v_bfe_u32 v41, v35, 16, 1                                  // 0000001A97B8: D6100029 02052123
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A97C0: BF870214
	v_bfe_u32 v42, v36, 16, 1                                  // 0000001A97C4: D610002A 02052124
	v_add3_u32 v37, v38, v37, 0x7fff                           // 0000001A97CC: D6550025 03FE4B26 00007FFF
	v_add3_u32 v38, v39, v40, 0x7fff                           // 0000001A97D8: D6550026 03FE5127 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A97E4: BF870214
	v_add3_u32 v35, v35, v41, 0x7fff                           // 0000001A97E8: D6550023 03FE5323 00007FFF
	v_add3_u32 v36, v36, v42, 0x7fff                           // 0000001A97F4: D6550024 03FE5524 00007FFF
	s_clause 0x3                                               // 0000001A9800: BF850003
	global_store_d16_hi_b16 v[33:34], v37, off                 // 0000001A9804: DC960000 007C2521
	global_store_d16_hi_b16 v[33:34], v38, off offset:64       // 0000001A980C: DC960040 007C2621
	global_store_d16_hi_b16 v[33:34], v35, off offset:128      // 0000001A9814: DC960080 007C2321
	global_store_d16_hi_b16 v[33:34], v36, off offset:192      // 0000001A981C: DC9600C0 007C2421
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A9824: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A9828: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001A982C: BE8C007E
	.long 0xd4c4007e                                           // 0000001A9830: D4C4007E
	v_cndmask_b32_e32 v1, s67, v32, vcc_lo                     // 0000001A9834: 02024043
	s_cbranch_execz 62969                                      // 0000001A9838: BFA5F5F9 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7620>
	s_waitcnt vmcnt(22)                                        // 0000001A983C: BF895BF7
	v_lshlrev_b32_e32 v22, 16, v22                             // 0000001A9840: 302C2C90
	s_waitcnt vmcnt(21)                                        // 0000001A9844: BF8957F7
	v_lshlrev_b32_e32 v23, 16, v23                             // 0000001A9848: 302E2E90
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001A984C: 7C983A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A9850: BF870193
	v_dual_mul_f32 v36, v22, v22 :: v_dual_lshlrev_b32 v21, 16, v21// 0000001A9854: C8E22D16 24142A90
	v_mul_f32_e32 v34, v23, v23                                // 0000001A985C: 10442F17
	s_waitcnt vmcnt(20)                                        // 0000001A9860: BF8953F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 0000001A9864: 30303090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A9868: BF8701A3
	v_mul_f32_e32 v35, v21, v21                                // 0000001A986C: 10462B15
	v_and_b32_e32 v37, 16, v29                                 // 0000001A9870: 364A3A90
	v_mul_f32_e32 v33, v24, v24                                // 0000001A9874: 10423118
	s_waitcnt vmcnt(19)                                        // 0000001A9878: BF894FF7
	v_lshlrev_b32_e32 v20, 16, v20                             // 0000001A987C: 30282890
	v_add_f32_e32 v34, v35, v34                                // 0000001A9880: 06444523
	v_add_lshl_u32 v35, v37, v180, 2                           // 0000001A9884: D6470023 020B6925
	v_add_f32_e32 v33, v36, v33                                // 0000001A988C: 06424324
	s_waitcnt vmcnt(17)                                        // 0000001A9890: BF8947F7
	v_lshlrev_b32_e32 v18, 16, v18                             // 0000001A9894: 30242490
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9898: BF870112
	v_dual_add_f32 v33, v34, v33 :: v_dual_mul_f32 v20, 0xbfb8aa3b, v20// 0000001A989C: C9064322 211428FF BFB8AA3B
	v_mul_f32_e32 v18, 0xbfb8aa3b, v18                         // 0000001A98A8: 102424FF BFB8AA3B
	ds_bpermute_b32 v34, v35, v33                              // 0000001A98B0: DACC0000 22002123
	v_cndmask_b32_e64 v35, 8, 0, vcc_lo                        // 0000001A98B8: D5010023 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001A98C0: 7C983A84
	v_exp_f32_e32 v20, v20                                     // 0000001A98C4: 7E284B14
	v_exp_f32_e32 v18, v18                                     // 0000001A98C8: 7E244B12
	v_lshlrev_b32_e32 v19, 16, v19                             // 0000001A98CC: 30262690
	v_add_lshl_u32 v35, v35, v180, 2                           // 0000001A98D0: D6470023 020B6923
	s_delay_alu instid0(TRANS32_DEP_2)                         // 0000001A98D8: BF870006
	v_add_f32_e32 v20, 1.0, v20                                // 0000001A98DC: 062828F2
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001A98E0: BF870185
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_mul_f32 v19, 0xbfb8aa3b, v19// 0000001A98E4: C90624F2 121226FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A98F0: BF870002
	v_div_scale_f32 v38, null, v20, v20, 1.0                   // 0000001A98F4: D6FC7C26 03CA2914
	v_div_scale_f32 v45, s0, 1.0, v20, 1.0                     // 0000001A98FC: D6FC002D 03CA28F2
	s_waitcnt lgkmcnt(0)                                       // 0000001A9904: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001A9908: 06424521
	v_exp_f32_e32 v19, v19                                     // 0000001A990C: 7E264B13
	v_div_scale_f32 v48, s9, 1.0, v18, 1.0                     // 0000001A9910: D6FC0930 03CA24F2
	v_rcp_f32_e32 v43, v38                                     // 0000001A9918: 7E565526
	v_div_scale_f32 v40, null, v18, v18, 1.0                   // 0000001A991C: D6FC7C28 03CA2512
	ds_bpermute_b32 v34, v35, v33                              // 0000001A9924: DACC0000 22002123
	v_cndmask_b32_e64 v35, 4, 0, vcc_lo                        // 0000001A992C: D5010023 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001A9934: 7C983A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A9938: BF8700A2
	v_add_lshl_u32 v35, v35, v180, 2                           // 0000001A993C: D6470023 020B6923
	v_add_f32_e32 v19, 1.0, v19                                // 0000001A9944: 062626F2
	v_div_scale_f32 v39, null, v19, v19, 1.0                   // 0000001A9948: D6FC7C27 03CA2713
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A9950: BF870001
	v_rcp_f32_e32 v44, v39                                     // 0000001A9954: 7E585527
	s_waitcnt lgkmcnt(0)                                       // 0000001A9958: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001A995C: 06424521
	ds_bpermute_b32 v34, v35, v33                              // 0000001A9960: DACC0000 22002123
	v_cndmask_b32_e64 v35, 2, 0, vcc_lo                        // 0000001A9968: D5010023 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001A9970: 7C9B689F
	v_fma_f32 v50, -v39, v44, 1.0                              // 0000001A9974: D6130032 23CA5927
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A997C: BF870123
	v_add_lshl_u32 v35, v35, v180, 2                           // 0000001A9980: D6470023 020B6923
	s_waitcnt lgkmcnt(0)                                       // 0000001A9988: BF89FC07
	v_dual_fmac_f32 v44, v50, v44 :: v_dual_add_f32 v33, v33, v34// 0000001A998C: C8085932 2C204521
	ds_bpermute_b32 v34, v35, v33                              // 0000001A9994: DACC0000 22002123
	v_add_co_ci_u32_e64 v35, null, 0, v180, vcc_lo             // 0000001A999C: D5207C23 01AB6880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A99A4: BF870001
	v_lshlrev_b32_e32 v35, 2, v35                              // 0000001A99A8: 30464682
	s_waitcnt lgkmcnt(0)                                       // 0000001A99AC: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001A99B0: 06424521
	ds_bpermute_b32 v34, v35, v33                              // 0000001A99B4: DACC0000 22002123
	s_waitcnt lgkmcnt(0)                                       // 0000001A99BC: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001A99C0: 06424521
	ds_bpermute_b32 v33, v107, v33                             // 0000001A99C4: DACC0000 2100216B
	s_waitcnt lgkmcnt(0)                                       // 0000001A99CC: BF89FC07
	v_div_scale_f32 v34, null, s62, s62, v33                   // 0000001A99D0: D6FC7C22 04847C3E
	v_div_scale_f32 v37, vcc_lo, v33, s62, v33                 // 0000001A99D8: D6FC6A25 04847D21
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A99E0: BF870292
	v_rcp_f32_e32 v35, v34                                     // 0000001A99E4: 7E465522
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000001A99E8: D6130024 23CA4722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A99F0: BF8700A1
	v_fmac_f32_e32 v35, v36, v35                               // 0000001A99F4: 56464724
	s_waitcnt vmcnt(16)                                        // 0000001A99F8: BF8943F7
	v_dual_mul_f32 v36, v37, v35 :: v_dual_lshlrev_b32 v17, 16, v17// 0000001A99FC: C8E24725 24102290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9A04: BF870091
	v_fma_f32 v42, -v34, v36, v37                              // 0000001A9A08: D613002A 24964922
	v_fmac_f32_e32 v36, v42, v35                               // 0000001A9A10: 5648472A
	v_rcp_f32_e32 v42, v40                                     // 0000001A9A14: 7E545528
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A9A18: BF870121
	v_fma_f32 v34, -v34, v36, v37                              // 0000001A9A1C: D6130022 24964922
	v_fma_f32 v37, -v38, v43, 1.0                              // 0000001A9A24: D6130025 23CA5726
	v_div_fmas_f32 v34, v34, v35, v36                          // 0000001A9A2C: D6370022 04924722
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001A9A34: BF870125
	v_fma_f32 v35, -v40, v42, 1.0                              // 0000001A9A38: D6130023 23CA5528
	s_mov_b32 vcc_lo, s0                                       // 0000001A9A40: BEEA0000
	v_div_fixup_f32 v33, v34, s62, v33                         // 0000001A9A44: D6270021 04847D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9A4C: BF870091
	v_dual_fmac_f32 v42, v35, v42 :: v_dual_add_f32 v33, 0x358637bd, v33// 0000001A9A50: C8085523 2A2042FF 358637BD
	v_mul_f32_e32 v52, 0x4b800000, v33                         // 0000001A9A5C: 106842FF 4B800000
	.long 0xd414000b                                           // 0000001A9A64: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v33, vcc_lo                // 0000001A9A68: 020242FF 00800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9A70: BF870091
	v_cndmask_b32_e64 v33, v33, v52, s11                       // 0000001A9A74: D5010021 002E6921
	v_rsq_f32_e32 v33, v33                                     // 0000001A9A7C: 7E425D21
	v_fmac_f32_e32 v43, v37, v43                               // 0000001A9A80: 56565725
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9A84: BF870091
	v_dual_mul_f32 v17, 0xbfb8aa3b, v17 :: v_dual_mul_f32 v34, v45, v43// 0000001A9A88: C8C622FF 1122572D BFB8AA3B
	v_exp_f32_e32 v17, v17                                     // 0000001A9A94: 7E224B11
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001A9A98: BF870001
	v_fma_f32 v50, -v38, v34, v45                              // 0000001A9A9C: D6130032 24B64526
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000001A9AA4: BF870085
	v_dual_fmac_f32 v34, v50, v43 :: v_dual_add_f32 v17, 1.0, v17// 0000001A9AA8: C8085732 221022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9AB0: BF870111
	v_fma_f32 v38, -v38, v34, v45                              // 0000001A9AB4: D6130026 24B64526
	v_div_scale_f32 v41, null, v17, v17, 1.0                   // 0000001A9ABC: D6FC7C29 03CA2311
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9AC4: BF870112
	v_div_fmas_f32 v34, v38, v43, v34                          // 0000001A9AC8: D6370022 048A5726
	v_rcp_f32_e32 v47, v41                                     // 0000001A9AD0: 7E5E5529
	v_mul_f32_e32 v38, 0x45800000, v33                         // 0000001A9AD4: 104C42FF 45800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9ADC: BF870112
	v_div_fixup_f32 v20, v34, v20, 1.0                         // 0000001A9AE0: D6270014 03CA2922
	v_cndmask_b32_e64 v33, v33, v38, s11                       // 0000001A9AE8: D5010021 002E4D21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9AF0: BF870115
	v_fma_f32 v36, -v41, v47, 1.0                              // 0000001A9AF4: D6130024 23CA5F29
	v_mul_f32_e32 v21, v33, v21                                // 0000001A9AFC: 102A2B21
	v_mul_f32_e32 v23, v33, v23                                // 0000001A9B00: 102E2F21
	v_mul_f32_e32 v24, v33, v24                                // 0000001A9B04: 10303121
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001A9B08: BF870004
	v_dual_mul_f32 v22, v33, v22 :: v_dual_fmac_f32 v47, v36, v47// 0000001A9B0C: C8C02D21 162E5F24
	v_mul_f32_e32 v36, v48, v42                                // 0000001A9B14: 10485530
	v_div_scale_f32 v46, s1, 1.0, v19, 1.0                     // 0000001A9B18: D6FC012E 03CA26F2
	v_mul_f32_e32 v21, v21, v25                                // 0000001A9B20: 102A3315
	v_mul_f32_e32 v23, v23, v27                                // 0000001A9B24: 102E3717
	s_mov_b32 vcc_lo, s1                                       // 0000001A9B28: BEEA0001
	v_fma_f32 v53, -v40, v36, v48                              // 0000001A9B2C: D6130035 24C24928
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001A9B34: BF870233
	v_dual_mul_f32 v35, v46, v44 :: v_dual_mul_f32 v20, v20, v21// 0000001A9B38: C8C6592E 23142B14
	v_mul_f32_e32 v22, v22, v26                                // 0000001A9B40: 102C3516
	v_mul_f32_e32 v24, v24, v28                                // 0000001A9B44: 10303918
	v_fmac_f32_e32 v36, v53, v42                               // 0000001A9B48: 56485535
	v_div_scale_f32 v49, s10, 1.0, v17, 1.0                    // 0000001A9B4C: D6FC0A31 03CA22F2
	v_fma_f32 v51, -v39, v35, v46                              // 0000001A9B54: D6130033 24BA4727
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A9B5C: BF870193
	v_fma_f32 v40, -v40, v36, v48                              // 0000001A9B60: D6130028 24C24928
	v_mul_f32_e32 v37, v49, v47                                // 0000001A9B68: 104A5F31
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9B6C: BF870113
	v_fmac_f32_e32 v35, v51, v44                               // 0000001A9B70: 56465933
	v_fma_f32 v54, -v41, v37, v49                              // 0000001A9B74: D6130036 24C64B29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9B7C: BF870112
	v_fma_f32 v39, -v39, v35, v46                              // 0000001A9B80: D6130027 24BA4727
	v_fmac_f32_e32 v37, v54, v47                               // 0000001A9B88: 564A5F36
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A9B8C: BF870002
	v_div_fmas_f32 v35, v39, v44, v35                          // 0000001A9B90: D6370023 048E5927
	s_mov_b32 vcc_lo, s9                                       // 0000001A9B98: BEEA0009
	v_div_fmas_f32 v36, v40, v42, v36                          // 0000001A9B9C: D6370024 04925528
	s_mov_b32 vcc_lo, s10                                      // 0000001A9BA4: BEEA000A
	v_fma_f32 v41, -v41, v37, v49                              // 0000001A9BA8: D6130029 24C64B29
	v_div_fixup_f32 v19, v35, v19, 1.0                         // 0000001A9BB0: D6270013 03CA2723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A9BB8: BF870193
	v_div_fixup_f32 v18, v36, v18, 1.0                         // 0000001A9BBC: D6270012 03CA2524
	v_div_fmas_f32 v34, v41, v47, v37                          // 0000001A9BC4: D6370022 04965F29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A9BCC: BF870193
	v_mul_f32_e32 v19, v19, v22                                // 0000001A9BD0: 10262D13
	v_mul_f32_e32 v21, v18, v23                                // 0000001A9BD4: 102A2F12
	v_bfe_u32 v23, v20, 16, 1                                  // 0000001A9BD8: D6100017 02052114
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9BE0: BF870114
	v_div_fixup_f32 v17, v34, v17, 1.0                         // 0000001A9BE4: D6270011 03CA2322
	v_add3_u32 v20, v20, v23, 0x7fff                           // 0000001A9BEC: D6550014 03FE2F14 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001A9BF8: BF870242
	v_mul_f32_e32 v22, v17, v24                                // 0000001A9BFC: 102C3111
	v_bfe_u32 v24, v19, 16, 1                                  // 0000001A9C00: D6100018 02052113
	v_mad_u64_u32 v[17:18], null, 0x3000, v32, v[114:115]      // 0000001A9C08: D6FE7C11 05CA40FF 00003000
	v_bfe_u32 v32, v21, 16, 1                                  // 0000001A9C14: D6100020 02052115
	v_bfe_u32 v33, v22, 16, 1                                  // 0000001A9C1C: D6100021 02052116
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A9C24: BF870194
	v_add3_u32 v19, v19, v24, 0x7fff                           // 0000001A9C28: D6550013 03FE3113 00007FFF
	v_add3_u32 v21, v21, v32, 0x7fff                           // 0000001A9C34: D6550015 03FE4115 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001A9C40: BF870003
	v_add3_u32 v22, v22, v33, 0x7fff                           // 0000001A9C44: D6550016 03FE4316 00007FFF
	s_clause 0x3                                               // 0000001A9C50: BF850003
	global_store_d16_hi_b16 v[17:18], v20, off                 // 0000001A9C54: DC960000 007C1411
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 0000001A9C5C: DC960040 007C1311
	global_store_d16_hi_b16 v[17:18], v21, off offset:128      // 0000001A9C64: DC960080 007C1511
	global_store_d16_hi_b16 v[17:18], v22, off offset:192      // 0000001A9C6C: DC9600C0 007C1611
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001A9C74: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001A9C78: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001A9C7C: BE8C007E
	.long 0xd4c4007e                                           // 0000001A9C80: D4C4007E
	v_cndmask_b32_e32 v1, s67, v31, vcc_lo                     // 0000001A9C84: 02023E43
	s_cbranch_execz 62699                                      // 0000001A9C88: BFA5F4EB <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7638>
	s_waitcnt vmcnt(14)                                        // 0000001A9C8C: BF893BF7
	v_lshlrev_b32_e32 v14, 16, v14                             // 0000001A9C90: 301C1C90
	s_waitcnt vmcnt(13)                                        // 0000001A9C94: BF8937F7
	v_lshlrev_b32_e32 v15, 16, v15                             // 0000001A9C98: 301E1E90
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001A9C9C: 7C983A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A9CA0: BF870193
	v_dual_mul_f32 v20, v14, v14 :: v_dual_lshlrev_b32 v13, 16, v13// 0000001A9CA4: C8E21D0E 140C1A90
	v_mul_f32_e32 v18, v15, v15                                // 0000001A9CAC: 10241F0F
	s_waitcnt vmcnt(12)                                        // 0000001A9CB0: BF8933F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 0000001A9CB4: 30202090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A9CB8: BF8701A3
	v_mul_f32_e32 v19, v13, v13                                // 0000001A9CBC: 10261B0D
	v_and_b32_e32 v21, 16, v29                                 // 0000001A9CC0: 362A3A90
	v_mul_f32_e32 v17, v16, v16                                // 0000001A9CC4: 10222110
	s_waitcnt vmcnt(11)                                        // 0000001A9CC8: BF892FF7
	v_lshlrev_b32_e32 v12, 16, v12                             // 0000001A9CCC: 30181890
	v_add_f32_e32 v18, v19, v18                                // 0000001A9CD0: 06242513
	v_add_lshl_u32 v19, v21, v180, 2                           // 0000001A9CD4: D6470013 020B6915
	v_add_f32_e32 v17, v20, v17                                // 0000001A9CDC: 06222314
	s_waitcnt vmcnt(9)                                         // 0000001A9CE0: BF8927F7
	v_lshlrev_b32_e32 v10, 16, v10                             // 0000001A9CE4: 30141490
	v_lshlrev_b32_e32 v11, 16, v11                             // 0000001A9CE8: 30161690
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001A9CEC: BF870193
	v_add_f32_e32 v17, v18, v17                                // 0000001A9CF0: 06222312
	v_mul_f32_e32 v10, 0xbfb8aa3b, v10                         // 0000001A9CF4: 101414FF BFB8AA3B
	v_mul_f32_e32 v12, 0xbfb8aa3b, v12                         // 0000001A9CFC: 101818FF BFB8AA3B
	ds_bpermute_b32 v18, v19, v17                              // 0000001A9D04: DACC0000 12001113
	v_cndmask_b32_e64 v19, 8, 0, vcc_lo                        // 0000001A9D0C: D5010013 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001A9D14: 7C983A84
	v_exp_f32_e32 v10, v10                                     // 0000001A9D18: 7E144B0A
	s_waitcnt vmcnt(8)                                         // 0000001A9D1C: BF8923F7
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000001A9D20: 30121290
	v_exp_f32_e32 v12, v12                                     // 0000001A9D24: 7E184B0C
	v_add_lshl_u32 v19, v19, v180, 2                           // 0000001A9D28: D6470013 020B6913
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A9D30: BF870296
	v_add_f32_e32 v10, 1.0, v10                                // 0000001A9D34: 061414F2
	v_add_f32_e32 v12, 1.0, v12                                // 0000001A9D38: 061818F2
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A9D3C: BF870002
	v_div_scale_f32 v39, s9, 1.0, v10, 1.0                     // 0000001A9D40: D6FC0927 03CA14F2
	v_div_scale_f32 v24, null, v10, v10, 1.0                   // 0000001A9D48: D6FC7C18 03CA150A
	s_waitcnt lgkmcnt(0)                                       // 0000001A9D50: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001A9D54: 06222511
	v_div_scale_f32 v22, null, v12, v12, 1.0                   // 0000001A9D58: D6FC7C16 03CA190C
	v_div_scale_f32 v36, s0, 1.0, v12, 1.0                     // 0000001A9D60: D6FC0024 03CA18F2
	ds_bpermute_b32 v18, v19, v17                              // 0000001A9D68: DACC0000 12001113
	v_cndmask_b32_e64 v19, 4, 0, vcc_lo                        // 0000001A9D70: D5010013 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001A9D78: 7C983A82
	v_rcp_f32_e32 v34, v22                                     // 0000001A9D7C: 7E445516
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001A9D80: BF870002
	v_add_lshl_u32 v19, v19, v180, 2                           // 0000001A9D84: D6470013 020B6913
	s_waitcnt lgkmcnt(0)                                       // 0000001A9D8C: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001A9D90: 06222511
	ds_bpermute_b32 v18, v19, v17                              // 0000001A9D94: DACC0000 12001113
	v_cndmask_b32_e64 v19, 2, 0, vcc_lo                        // 0000001A9D9C: D5010013 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001A9DA4: 7C9B689F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001A9DA8: BF8700D2
	v_add_lshl_u32 v19, v19, v180, 2                           // 0000001A9DAC: D6470013 020B6913
	s_waitcnt lgkmcnt(0)                                       // 0000001A9DB4: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001A9DB8: 06222511
	ds_bpermute_b32 v18, v19, v17                              // 0000001A9DBC: DACC0000 12001113
	v_add_co_ci_u32_e64 v19, null, 0, v180, vcc_lo             // 0000001A9DC4: D5207C13 01AB6880
	v_lshlrev_b32_e32 v19, 2, v19                              // 0000001A9DCC: 30262682
	s_waitcnt lgkmcnt(0)                                       // 0000001A9DD0: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001A9DD4: 06222511
	ds_bpermute_b32 v18, v19, v17                              // 0000001A9DD8: DACC0000 12001113
	s_waitcnt lgkmcnt(0)                                       // 0000001A9DE0: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001A9DE4: 06222511
	ds_bpermute_b32 v17, v107, v17                             // 0000001A9DE8: DACC0000 1100116B
	s_waitcnt lgkmcnt(0)                                       // 0000001A9DF0: BF89FC07
	v_div_scale_f32 v18, null, s62, s62, v17                   // 0000001A9DF4: D6FC7C12 04447C3E
	v_div_scale_f32 v21, vcc_lo, v17, s62, v17                 // 0000001A9DFC: D6FC6A15 04447D11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A9E04: BF870292
	v_rcp_f32_e32 v19, v18                                     // 0000001A9E08: 7E265512
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000001A9E0C: D6130014 23CA2712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9E14: BF870091
	v_fmac_f32_e32 v19, v20, v19                               // 0000001A9E18: 56262714
	v_dual_mul_f32 v9, 0xbfb8aa3b, v9 :: v_dual_mul_f32 v20, v21, v19// 0000001A9E1C: C8C612FF 09142715 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9E28: BF870091
	v_exp_f32_e32 v9, v9                                       // 0000001A9E2C: 7E124B09
	v_fma_f32 v33, -v18, v20, v21                              // 0000001A9E30: D6130021 24562912
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000001A9E38: BF870085
	v_dual_fmac_f32 v20, v33, v19 :: v_dual_add_f32 v9, 1.0, v9// 0000001A9E3C: C8082721 140812F2
	v_rcp_f32_e32 v33, v24                                     // 0000001A9E44: 7E425518
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9E48: BF870111
	v_fma_f32 v18, -v18, v20, v21                              // 0000001A9E4C: D6130012 24562912
	v_div_scale_f32 v32, null, v9, v9, 1.0                     // 0000001A9E54: D6FC7C20 03CA1309
	v_fma_f32 v21, -v22, v34, 1.0                              // 0000001A9E5C: D6130015 23CA4516
	v_div_scale_f32 v40, s10, 1.0, v9, 1.0                     // 0000001A9E64: D6FC0A28 03CA12F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A9E6C: BF870214
	v_div_fmas_f32 v18, v18, v19, v20                          // 0000001A9E70: D6370012 04522712
	v_rcp_f32_e32 v38, v32                                     // 0000001A9E78: 7E4C5520
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 0000001A9E7C: BF870323
	v_fmac_f32_e32 v34, v21, v34                               // 0000001A9E80: 56444515
	s_mov_b32 vcc_lo, s0                                       // 0000001A9E84: BEEA0000
	v_fma_f32 v19, -v24, v33, 1.0                              // 0000001A9E88: D6130013 23CA4318
	v_div_fixup_f32 v17, v18, s62, v17                         // 0000001A9E90: D6270011 04447D12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A9E98: BF870291
	v_dual_mul_f32 v18, v36, v34 :: v_dual_add_f32 v17, 0x358637bd, v17// 0000001A9E9C: C8C84524 121022FF 358637BD
	v_fma_f32 v20, -v32, v38, 1.0                              // 0000001A9EA8: D6130014 23CA4D20
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 0000001A9EB0: 101616FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9EB8: BF870112
	v_dual_mul_f32 v43, 0x4b800000, v17 :: v_dual_fmac_f32 v38, v20, v38// 0000001A9EBC: C8C022FF 2B264D14 4B800000
	v_exp_f32_e32 v11, v11                                     // 0000001A9EC8: 7E164B0B
	.long 0xd414000b                                           // 0000001A9ECC: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v17, vcc_lo                // 0000001A9ED0: 020222FF 00800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A9ED8: BF870291
	v_cndmask_b32_e64 v17, v17, v43, s11                       // 0000001A9EDC: D5010011 002E5711
	v_add_f32_e32 v11, 1.0, v11                                // 0000001A9EE4: 061616F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9EE8: BF870092
	v_rsq_f32_e32 v17, v17                                     // 0000001A9EEC: 7E225D11
	v_div_scale_f32 v23, null, v11, v11, 1.0                   // 0000001A9EF0: D6FC7C17 03CA170B
	v_div_scale_f32 v37, s1, 1.0, v11, 1.0                     // 0000001A9EF8: D6FC0125 03CA16F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001A9F00: BF870292
	v_rcp_f32_e32 v35, v23                                     // 0000001A9F04: 7E465517
	v_fma_f32 v41, -v23, v35, 1.0                              // 0000001A9F08: D6130029 23CA4717
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001A9F10: BF8700A1
	v_fmac_f32_e32 v35, v41, v35                               // 0000001A9F14: 56464729
	v_fma_f32 v41, -v22, v18, v36                              // 0000001A9F18: D6130029 24922516
	v_fmac_f32_e32 v18, v41, v34                               // 0000001A9F20: 56244529
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001A9F24: BF870091
	v_fma_f32 v22, -v22, v18, v36                              // 0000001A9F28: D6130016 24922516
	v_div_fmas_f32 v18, v22, v34, v18                          // 0000001A9F30: D6370012 044A4516
	v_mul_f32_e32 v22, 0x45800000, v17                         // 0000001A9F38: 102C22FF 45800000
	s_mov_b32 vcc_lo, s1                                       // 0000001A9F40: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001A9F44: BF870112
	v_div_fixup_f32 v12, v18, v12, 1.0                         // 0000001A9F48: D627000C 03CA1912
	v_cndmask_b32_e64 v17, v17, v22, s11                       // 0000001A9F50: D5010011 002E2D11
	v_fmac_f32_e32 v33, v19, v33                               // 0000001A9F58: 56424313
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A9F5C: BF8701A2
	v_dual_mul_f32 v21, v40, v38 :: v_dual_mul_f32 v16, v17, v16// 0000001A9F60: C8C64D28 15102111
	v_mul_f32_e32 v14, v17, v14                                // 0000001A9F68: 101C1D11
	v_dual_mul_f32 v19, v37, v35 :: v_dual_mul_f32 v20, v39, v33// 0000001A9F6C: C8C64725 13144327
	v_mul_f32_e32 v13, v17, v13                                // 0000001A9F74: 101A1B11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A9F78: BF870214
	v_fma_f32 v45, -v32, v21, v40                              // 0000001A9F7C: D613002D 24A22B20
	v_mul_f32_e32 v14, v14, v26                                // 0000001A9F84: 101C350E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001A9F88: BF870254
	v_fma_f32 v42, -v23, v19, v37                              // 0000001A9F8C: D613002A 24962717
	v_fma_f32 v44, -v24, v20, v39                              // 0000001A9F94: D613002C 249E2918
	v_mul_f32_e32 v13, v13, v25                                // 0000001A9F9C: 101A330D
	v_fmac_f32_e32 v21, v45, v38                               // 0000001A9FA0: 562A4D2D
	v_mul_f32_e32 v15, v17, v15                                // 0000001A9FA4: 101E1F11
	v_dual_fmac_f32 v19, v42, v35 :: v_dual_fmac_f32 v20, v44, v33// 0000001A9FA8: C800472A 1314432C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A9FB0: BF870214
	v_mul_f32_e32 v12, v12, v13                                // 0000001A9FB4: 10181B0C
	v_fma_f32 v32, -v32, v21, v40                              // 0000001A9FB8: D6130020 24A22B20
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001A9FC0: BF870214
	v_mul_f32_e32 v15, v15, v27                                // 0000001A9FC4: 101E370F
	v_fma_f32 v23, -v23, v19, v37                              // 0000001A9FC8: D6130017 24962717
	v_fma_f32 v24, -v24, v20, v39                              // 0000001A9FD0: D6130018 249E2918
	v_mul_f32_e32 v16, v16, v28                                // 0000001A9FD8: 10203910
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A9FDC: BF8701A3
	v_div_fmas_f32 v19, v23, v35, v19                          // 0000001A9FE0: D6370013 044E4717
	s_mov_b32 vcc_lo, s9                                       // 0000001A9FE8: BEEA0009
	v_div_fmas_f32 v20, v24, v33, v20                          // 0000001A9FEC: D6370014 04524318
	s_mov_b32 vcc_lo, s10                                      // 0000001A9FF4: BEEA000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001A9FF8: BF8701A2
	v_div_fixup_f32 v11, v19, v11, 1.0                         // 0000001A9FFC: D627000B 03CA1713
	v_div_fmas_f32 v18, v32, v38, v21                          // 0000001AA004: D6370012 04564D20
	v_div_fixup_f32 v10, v20, v10, 1.0                         // 0000001AA00C: D627000A 03CA1514
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA014: BF870193
	v_mul_f32_e32 v11, v11, v14                                // 0000001AA018: 10161D0B
	v_div_fixup_f32 v9, v18, v9, 1.0                           // 0000001AA01C: D6270009 03CA1312
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AA024: BF8701A3
	v_mul_f32_e32 v13, v10, v15                                // 0000001AA028: 101A1F0A
	v_bfe_u32 v15, v12, 16, 1                                  // 0000001AA02C: D610000F 0205210C
	v_mul_f32_e32 v14, v9, v16                                 // 0000001AA034: 101C2109
	v_bfe_u32 v16, v11, 16, 1                                  // 0000001AA038: D6100010 0205210B
	v_mad_u64_u32 v[9:10], null, 0x3000, v31, v[114:115]       // 0000001AA040: D6FE7C09 05CA3EFF 00003000
	v_bfe_u32 v17, v13, 16, 1                                  // 0000001AA04C: D6100011 0205210D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 0000001AA054: D655000C 03FE1F0C 00007FFF
	v_bfe_u32 v18, v14, 16, 1                                  // 0000001AA060: D6100012 0205210E
	v_add3_u32 v11, v11, v16, 0x7fff                           // 0000001AA068: D655000B 03FE210B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA074: BF870194
	v_add3_u32 v13, v13, v17, 0x7fff                           // 0000001AA078: D655000D 03FE230D 00007FFF
	v_add3_u32 v14, v14, v18, 0x7fff                           // 0000001AA084: D655000E 03FE250E 00007FFF
	s_clause 0x3                                               // 0000001AA090: BF850003
	global_store_d16_hi_b16 v[9:10], v12, off                  // 0000001AA094: DC960000 007C0C09
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001AA09C: DC960040 007C0B09
	global_store_d16_hi_b16 v[9:10], v13, off offset:128       // 0000001AA0A4: DC960080 007C0D09
	global_store_d16_hi_b16 v[9:10], v14, off offset:192       // 0000001AA0AC: DC9600C0 007C0E09
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001AA0B4: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AA0B8: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001AA0BC: BE8C007E
	.long 0xd4c4007e                                           // 0000001AA0C0: D4C4007E
	v_cndmask_b32_e32 v1, s67, v30, vcc_lo                     // 0000001AA0C4: 02023C43
	s_cbranch_execnz 62433                                     // 0000001AA0C8: BFA6F3E1 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7650>
	s_branch 62701                                             // 0000001AA0CC: BFA0F4ED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7a84>
	v_mad_u64_u32 v[34:35], null, 0x1800, v33, v[110:111]      // 0000001AA0D0: D6FE7C22 05BA42FF 00001800
	v_and_b32_e32 v46, 16, v29                                 // 0000001AA0DC: 365C3A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA0E0: BF870092
	.long 0xd73c0022                                           // 0000001AA0E4: D73C0022
	v_cndmask_b32_e32 v1, 1, v34, vcc_lo                       // 0000001AA0E8: 02024481
	.long 0xd7006a24                                           // 0000001AA0EC: D7006A24
	v_cndmask_b32_e32 v1, s22, v34, vcc_lo                     // 0000001AA0F0: 02024416
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AA0F4: BF870001
	v_add_co_ci_u32_e64 v37, null, s23, v35, vcc_lo            // 0000001AA0F8: D5207C25 01AA4617
	s_clause 0x3                                               // 0000001AA100: BF850003
	global_load_u16 v38, v[36:37], off offset:192              // 0000001AA104: DC4A00C0 267C0024
	global_load_u16 v39, v[36:37], off offset:64               // 0000001AA10C: DC4A0040 277C0024
	global_load_u16 v40, v[36:37], off                         // 0000001AA114: DC4A0000 287C0024
	global_load_u16 v36, v[36:37], off offset:128              // 0000001AA11C: DC4A0080 247C0024
	.long 0xd7006a22                                           // 0000001AA124: D7006A22
	v_cndmask_b32_e32 v1, s26, v34, vcc_lo                     // 0000001AA128: 0202441A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AA12C: BF870001
	v_add_co_ci_u32_e64 v35, null, s27, v35, vcc_lo            // 0000001AA130: D5207C23 01AA461B
	s_clause 0x3                                               // 0000001AA138: BF850003
	global_load_u16 v37, v[34:35], off offset:128              // 0000001AA13C: DC4A0080 257C0022
	global_load_u16 v41, v[34:35], off                         // 0000001AA144: DC4A0000 297C0022
	global_load_u16 v42, v[34:35], off offset:64               // 0000001AA14C: DC4A0040 2A7C0022
	global_load_u16 v34, v[34:35], off offset:192              // 0000001AA154: DC4A00C0 227C0022
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001AA15C: 7C983A88
	s_waitcnt vmcnt(4)                                         // 0000001AA160: BF8913F7
	v_lshlrev_b32_e32 v36, 16, v36                             // 0000001AA164: 30484890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA168: BF870091
	v_dual_mul_f32 v44, v36, v36 :: v_dual_lshlrev_b32 v35, 16, v39// 0000001AA16C: C8E24924 2C224E90
	v_dual_mul_f32 v40, v35, v35 :: v_dual_lshlrev_b32 v39, 16, v40// 0000001AA174: C8E24723 28265090
	s_waitcnt vmcnt(1)                                         // 0000001AA17C: BF8907F7
	v_lshlrev_b32_e32 v42, 16, v42                             // 0000001AA180: 30545490
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000001AA184: 30525290
	v_lshlrev_b32_e32 v37, 16, v37                             // 0000001AA188: 304A4A90
	v_dual_mul_f32 v43, v39, v39 :: v_dual_lshlrev_b32 v38, 16, v38// 0000001AA18C: C8E24F27 2B264C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA194: BF870193
	v_mul_f32_e32 v41, 0xbfb8aa3b, v41                         // 0000001AA198: 105252FF BFB8AA3B
	v_mul_f32_e32 v37, 0xbfb8aa3b, v37                         // 0000001AA1A0: 104A4AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AA1A8: BF870213
	v_add_f32_e32 v43, v44, v43                                // 0000001AA1AC: 0656572C
	v_mul_f32_e32 v45, v38, v38                                // 0000001AA1B0: 105A4D26
	v_add_lshl_u32 v44, v46, v180, 2                           // 0000001AA1B4: D647002C 020B692E
	v_exp_f32_e32 v41, v41                                     // 0000001AA1BC: 7E524B29
	v_exp_f32_e32 v37, v37                                     // 0000001AA1C0: 7E4A4B25
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AA1C4: BF870002
	v_add_f32_e32 v40, v45, v40                                // 0000001AA1C8: 0650512D
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_1)   // 0000001AA1CC: BF870086
	v_dual_add_f32 v40, v40, v43 :: v_dual_add_f32 v41, 1.0, v41// 0000001AA1D0: C9085728 282852F2
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001AA1D8: BF870005
	v_add_f32_e32 v37, 1.0, v37                                // 0000001AA1DC: 064A4AF2
	ds_bpermute_b32 v43, v44, v40                              // 0000001AA1E0: DACC0000 2B00282C
	v_cndmask_b32_e64 v44, 8, 0, vcc_lo                        // 0000001AA1E8: D501002C 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001AA1F0: 7C983A84
	v_div_scale_f32 v47, null, v41, v41, 1.0                   // 0000001AA1F4: D6FC7C2F 03CA5329
	v_div_scale_f32 v54, s0, 1.0, v41, 1.0                     // 0000001AA1FC: D6FC0036 03CA52F2
	v_div_scale_f32 v49, null, v37, v37, 1.0                   // 0000001AA204: D6FC7C31 03CA4B25
	v_add_lshl_u32 v44, v44, v180, 2                           // 0000001AA20C: D647002C 020B692C
	v_div_scale_f32 v57, s9, 1.0, v37, 1.0                     // 0000001AA214: D6FC0939 03CA4AF2
	v_rcp_f32_e32 v52, v47                                     // 0000001AA21C: 7E68552F
	s_waitcnt lgkmcnt(0)                                       // 0000001AA220: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001AA224: 06505728
	ds_bpermute_b32 v43, v44, v40                              // 0000001AA228: DACC0000 2B00282C
	v_cndmask_b32_e64 v44, 4, 0, vcc_lo                        // 0000001AA230: D501002C 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001AA238: 7C983A82
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AA23C: BF870002
	v_add_lshl_u32 v44, v44, v180, 2                           // 0000001AA240: D647002C 020B692C
	s_waitcnt lgkmcnt(0)                                       // 0000001AA248: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001AA24C: 06505728
	ds_bpermute_b32 v43, v44, v40                              // 0000001AA250: DACC0000 2B00282C
	v_cndmask_b32_e64 v44, 2, 0, vcc_lo                        // 0000001AA258: D501002C 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001AA260: 7C9B689F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001AA264: BF8700D2
	v_add_lshl_u32 v44, v44, v180, 2                           // 0000001AA268: D647002C 020B692C
	s_waitcnt lgkmcnt(0)                                       // 0000001AA270: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001AA274: 06505728
	ds_bpermute_b32 v43, v44, v40                              // 0000001AA278: DACC0000 2B00282C
	v_add_co_ci_u32_e64 v44, null, 0, v180, vcc_lo             // 0000001AA280: D5207C2C 01AB6880
	v_lshlrev_b32_e32 v44, 2, v44                              // 0000001AA288: 30585882
	s_waitcnt lgkmcnt(0)                                       // 0000001AA28C: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001AA290: 06505728
	ds_bpermute_b32 v43, v44, v40                              // 0000001AA294: DACC0000 2B00282C
	s_waitcnt lgkmcnt(0)                                       // 0000001AA29C: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001AA2A0: 06505728
	ds_bpermute_b32 v40, v107, v40                             // 0000001AA2A4: DACC0000 2800286B
	s_waitcnt lgkmcnt(0)                                       // 0000001AA2AC: BF89FC07
	v_div_scale_f32 v43, null, s62, s62, v40                   // 0000001AA2B0: D6FC7C2B 04A07C3E
	v_div_scale_f32 v46, vcc_lo, v40, s62, v40                 // 0000001AA2B8: D6FC6A2E 04A07D28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AA2C0: BF870292
	v_rcp_f32_e32 v44, v43                                     // 0000001AA2C4: 7E58552B
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000001AA2C8: D613002D 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA2D0: BF870091
	v_fmac_f32_e32 v44, v45, v44                               // 0000001AA2D4: 5658592D
	v_mul_f32_e32 v45, v46, v44                                // 0000001AA2D8: 105A592E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA2DC: BF870091
	v_fma_f32 v51, -v43, v45, v46                              // 0000001AA2E0: D6130033 24BA5B2B
	v_fmac_f32_e32 v45, v51, v44                               // 0000001AA2E8: 565A5933
	v_rcp_f32_e32 v51, v49                                     // 0000001AA2EC: 7E665531
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA2F0: BF870121
	v_fma_f32 v43, -v43, v45, v46                              // 0000001AA2F4: D613002B 24BA5B2B
	v_fma_f32 v46, -v47, v52, 1.0                              // 0000001AA2FC: D613002E 23CA692F
	v_div_fmas_f32 v43, v43, v44, v45                          // 0000001AA304: D637002B 04B6592B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001AA30C: BF8702A2
	v_fmac_f32_e32 v52, v46, v52                               // 0000001AA310: 5668692E
	v_mul_f32_e32 v42, 0xbfb8aa3b, v42                         // 0000001AA314: 105454FF BFB8AA3B
	v_fma_f32 v44, -v49, v51, 1.0                              // 0000001AA31C: D613002C 23CA6731
	s_waitcnt vmcnt(0)                                         // 0000001AA324: BF8903F7
	v_lshlrev_b32_e32 v34, 16, v34                             // 0000001AA328: 30444490
	v_div_fixup_f32 v40, v43, s62, v40                         // 0000001AA32C: D6270028 04A07D2B
	v_mul_f32_e32 v43, v54, v52                                // 0000001AA334: 10566936
	v_exp_f32_e32 v42, v42                                     // 0000001AA338: 7E544B2A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA33C: BF870193
	v_dual_fmac_f32 v51, v44, v51 :: v_dual_mul_f32 v34, 0xbfb8aa3b, v34// 0000001AA340: C806672C 332244FF BFB8AA3B
	v_add_f32_e32 v40, 0x358637bd, v40                         // 0000001AA34C: 065050FF 358637BD
	s_mov_b32 vcc_lo, s0                                       // 0000001AA354: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA358: BF870092
	v_exp_f32_e32 v34, v34                                     // 0000001AA35C: 7E444B22
	v_mul_f32_e32 v61, 0x4b800000, v40                         // 0000001AA360: 107A50FF 4B800000
	.long 0xd414000b                                           // 0000001AA368: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v40, vcc_lo                // 0000001AA36C: 020250FF 00800000
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA374: BF870116
	v_add_f32_e32 v42, 1.0, v42                                // 0000001AA378: 065454F2
	v_cndmask_b32_e64 v40, v40, v61, s11                       // 0000001AA37C: D5010028 002E7B28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AA384: BF8701A2
	v_div_scale_f32 v48, null, v42, v42, 1.0                   // 0000001AA388: D6FC7C30 03CA552A
	v_div_scale_f32 v55, s1, 1.0, v42, 1.0                     // 0000001AA390: D6FC0137 03CA54F2
	v_rsq_f32_e32 v40, v40                                     // 0000001AA398: 7E505D28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AA39C: BF870292
	v_rcp_f32_e32 v53, v48                                     // 0000001AA3A0: 7E6A5530
	v_fma_f32 v59, -v48, v53, 1.0                              // 0000001AA3A4: D613003B 23CA6B30
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AA3AC: BF8701B1
	v_fmac_f32_e32 v53, v59, v53                               // 0000001AA3B0: 566A6B3B
	v_fma_f32 v59, -v47, v43, v54                              // 0000001AA3B4: D613003B 24DA572F
	v_add_f32_e32 v34, 1.0, v34                                // 0000001AA3BC: 064444F2
	v_mul_f32_e32 v44, v55, v53                                // 0000001AA3C0: 10586B37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA3C4: BF870193
	v_fmac_f32_e32 v43, v59, v52                               // 0000001AA3C8: 5656693B
	v_div_scale_f32 v50, null, v34, v34, 1.0                   // 0000001AA3CC: D6FC7C32 03CA4522
	v_div_scale_f32 v58, s10, 1.0, v34, 1.0                    // 0000001AA3D4: D6FC0A3A 03CA44F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA3DC: BF870193
	v_fma_f32 v47, -v47, v43, v54                              // 0000001AA3E0: D613002F 24DA572F
	v_rcp_f32_e32 v56, v50                                     // 0000001AA3E8: 7E705532
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001AA3EC: BF8701C1
	v_div_fmas_f32 v43, v47, v52, v43                          // 0000001AA3F0: D637002B 04AE692F
	v_mul_f32_e32 v47, 0x45800000, v40                         // 0000001AA3F8: 105E50FF 45800000
	v_fma_f32 v60, -v48, v44, v55                              // 0000001AA400: D613003C 24DE5930
	s_mov_b32 vcc_lo, s1                                       // 0000001AA408: BEEA0001
	v_div_fixup_f32 v41, v43, v41, 1.0                         // 0000001AA40C: D6270029 03CA532B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AA414: BF870293
	v_cndmask_b32_e64 v40, v40, v47, s11                       // 0000001AA418: D5010028 002E5F28
	v_fma_f32 v45, -v50, v56, 1.0                              // 0000001AA420: D613002D 23CA7132
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AA428: BF8701B1
	v_dual_mul_f32 v39, v40, v39 :: v_dual_fmac_f32 v56, v45, v56// 0000001AA42C: C8C04F28 2738712D
	v_mul_f32_e32 v35, v40, v35                                // 0000001AA434: 10464728
	v_dual_mul_f32 v45, v57, v51 :: v_dual_mul_f32 v38, v40, v38// 0000001AA438: C8C66739 2D264D28
	v_mul_f32_e32 v39, v39, v25                                // 0000001AA440: 104E3327
	v_fmac_f32_e32 v44, v60, v53                               // 0000001AA444: 56586B3C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AA448: BF870214
	v_dual_mul_f32 v46, v58, v56 :: v_dual_mul_f32 v35, v35, v26// 0000001AA44C: C8C6713A 2E223523
	v_fma_f32 v62, -v49, v45, v57                              // 0000001AA454: D613003E 24E65B31
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AA45C: BF870214
	v_mul_f32_e32 v39, v41, v39                                // 0000001AA460: 104E4F29
	v_fma_f32 v48, -v48, v44, v55                              // 0000001AA464: D6130030 24DE5930
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001AA46C: BF870234
	v_fma_f32 v63, -v50, v46, v58                              // 0000001AA470: D613003F 24EA5D32
	v_mul_f32_e32 v38, v38, v28                                // 0000001AA478: 104C3926
	v_fmac_f32_e32 v45, v62, v51                               // 0000001AA47C: 565A673E
	v_div_fmas_f32 v44, v48, v53, v44                          // 0000001AA480: D637002C 04B26B30
	s_mov_b32 vcc_lo, s9                                       // 0000001AA488: BEEA0009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA48C: BF870112
	v_fma_f32 v49, -v49, v45, v57                              // 0000001AA490: D6130031 24E65B31
	v_div_fixup_f32 v42, v44, v42, 1.0                         // 0000001AA498: D627002A 03CA552C
	v_fmac_f32_e32 v46, v63, v56                               // 0000001AA4A0: 565C713F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AA4A4: BF8701A3
	v_div_fmas_f32 v45, v49, v51, v45                          // 0000001AA4A8: D637002D 04B66731
	s_mov_b32 vcc_lo, s10                                      // 0000001AA4B0: BEEA000A
	v_mul_f32_e32 v35, v42, v35                                // 0000001AA4B4: 1046472A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA4B8: BF870193
	v_fma_f32 v50, -v50, v46, v58                              // 0000001AA4BC: D6130032 24EA5D32
	v_div_fixup_f32 v37, v45, v37, 1.0                         // 0000001AA4C4: D6270025 03CA4B2D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA4CC: BF870092
	v_div_fmas_f32 v43, v50, v56, v46                          // 0000001AA4D0: D637002B 04BA7132
	v_div_fixup_f32 v34, v43, v34, 1.0                         // 0000001AA4D8: D6270022 03CA452B
	v_mul_f32_e32 v36, v40, v36                                // 0000001AA4E0: 10484928
	v_bfe_u32 v40, v35, 16, 1                                  // 0000001AA4E4: D6100028 02052123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA4EC: BF870112
	v_mul_f32_e32 v36, v36, v27                                // 0000001AA4F0: 10483724
	v_add3_u32 v35, v35, v40, 0x7fff                           // 0000001AA4F4: D6550023 03FE5123 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AA500: BF8701B2
	v_dual_mul_f32 v36, v37, v36 :: v_dual_mul_f32 v37, v34, v38// 0000001AA504: C8C64925 24244D22
	v_bfe_u32 v38, v39, 16, 1                                  // 0000001AA50C: D6100026 02052127
	v_mad_u64_u32 v[33:34], null, 0x3000, v33, v[114:115]      // 0000001AA514: D6FE7C21 05CA42FF 00003000
	v_bfe_u32 v41, v36, 16, 1                                  // 0000001AA520: D6100029 02052124
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AA528: BF870214
	v_bfe_u32 v42, v37, 16, 1                                  // 0000001AA52C: D610002A 02052125
	v_add3_u32 v38, v39, v38, 0x7fff                           // 0000001AA534: D6550026 03FE4D27 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA540: BF870193
	v_add3_u32 v36, v36, v41, 0x7fff                           // 0000001AA544: D6550024 03FE5324 00007FFF
	v_add3_u32 v37, v37, v42, 0x7fff                           // 0000001AA550: D6550025 03FE5525 00007FFF
	s_clause 0x3                                               // 0000001AA55C: BF850003
	global_store_d16_hi_b16 v[33:34], v38, off                 // 0000001AA560: DC960000 007C2621
	global_store_d16_hi_b16 v[33:34], v35, off offset:64       // 0000001AA568: DC960040 007C2321
	global_store_d16_hi_b16 v[33:34], v36, off offset:128      // 0000001AA570: DC960080 007C2421
	global_store_d16_hi_b16 v[33:34], v37, off offset:192      // 0000001AA578: DC9600C0 007C2521
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001AA580: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AA584: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001AA588: BE8C007E
	.long 0xd4c4007e                                           // 0000001AA58C: D4C4007E
	v_cndmask_b32_e32 v1, s67, v32, vcc_lo                     // 0000001AA590: 02024043
	s_cbranch_execz 62514                                      // 0000001AA594: BFA5F432 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7c60>
	s_waitcnt vmcnt(22)                                        // 0000001AA598: BF895BF7
	v_lshlrev_b32_e32 v22, 16, v22                             // 0000001AA59C: 302C2C90
	s_waitcnt vmcnt(21)                                        // 0000001AA5A0: BF8957F7
	v_lshlrev_b32_e32 v23, 16, v23                             // 0000001AA5A4: 302E2E90
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001AA5A8: 7C983A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA5AC: BF870193
	v_dual_mul_f32 v36, v22, v22 :: v_dual_lshlrev_b32 v21, 16, v21// 0000001AA5B0: C8E22D16 24142A90
	v_mul_f32_e32 v34, v23, v23                                // 0000001AA5B8: 10442F17
	s_waitcnt vmcnt(20)                                        // 0000001AA5BC: BF8953F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 0000001AA5C0: 30303090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AA5C4: BF8701A3
	v_mul_f32_e32 v35, v21, v21                                // 0000001AA5C8: 10462B15
	v_and_b32_e32 v37, 16, v29                                 // 0000001AA5CC: 364A3A90
	v_mul_f32_e32 v33, v24, v24                                // 0000001AA5D0: 10423118
	s_waitcnt vmcnt(19)                                        // 0000001AA5D4: BF894FF7
	v_lshlrev_b32_e32 v20, 16, v20                             // 0000001AA5D8: 30282890
	v_add_f32_e32 v34, v35, v34                                // 0000001AA5DC: 06444523
	v_add_lshl_u32 v35, v37, v180, 2                           // 0000001AA5E0: D6470023 020B6925
	v_add_f32_e32 v33, v36, v33                                // 0000001AA5E8: 06424324
	s_waitcnt vmcnt(17)                                        // 0000001AA5EC: BF8947F7
	v_lshlrev_b32_e32 v18, 16, v18                             // 0000001AA5F0: 30242490
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA5F4: BF870112
	v_dual_add_f32 v33, v34, v33 :: v_dual_mul_f32 v20, 0xbfb8aa3b, v20// 0000001AA5F8: C9064322 211428FF BFB8AA3B
	v_mul_f32_e32 v18, 0xbfb8aa3b, v18                         // 0000001AA604: 102424FF BFB8AA3B
	ds_bpermute_b32 v34, v35, v33                              // 0000001AA60C: DACC0000 22002123
	v_cndmask_b32_e64 v35, 8, 0, vcc_lo                        // 0000001AA614: D5010023 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001AA61C: 7C983A84
	v_exp_f32_e32 v20, v20                                     // 0000001AA620: 7E284B14
	v_exp_f32_e32 v18, v18                                     // 0000001AA624: 7E244B12
	v_lshlrev_b32_e32 v19, 16, v19                             // 0000001AA628: 30262690
	v_add_lshl_u32 v35, v35, v180, 2                           // 0000001AA62C: D6470023 020B6923
	s_delay_alu instid0(TRANS32_DEP_2)                         // 0000001AA634: BF870006
	v_add_f32_e32 v20, 1.0, v20                                // 0000001AA638: 062828F2
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001AA63C: BF870185
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_mul_f32 v19, 0xbfb8aa3b, v19// 0000001AA640: C90624F2 121226FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AA64C: BF870002
	v_div_scale_f32 v38, null, v20, v20, 1.0                   // 0000001AA650: D6FC7C26 03CA2914
	v_div_scale_f32 v45, s0, 1.0, v20, 1.0                     // 0000001AA658: D6FC002D 03CA28F2
	s_waitcnt lgkmcnt(0)                                       // 0000001AA660: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001AA664: 06424521
	v_exp_f32_e32 v19, v19                                     // 0000001AA668: 7E264B13
	v_div_scale_f32 v48, s9, 1.0, v18, 1.0                     // 0000001AA66C: D6FC0930 03CA24F2
	v_rcp_f32_e32 v43, v38                                     // 0000001AA674: 7E565526
	v_div_scale_f32 v40, null, v18, v18, 1.0                   // 0000001AA678: D6FC7C28 03CA2512
	ds_bpermute_b32 v34, v35, v33                              // 0000001AA680: DACC0000 22002123
	v_cndmask_b32_e64 v35, 4, 0, vcc_lo                        // 0000001AA688: D5010023 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001AA690: 7C983A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AA694: BF8700A2
	v_add_lshl_u32 v35, v35, v180, 2                           // 0000001AA698: D6470023 020B6923
	v_add_f32_e32 v19, 1.0, v19                                // 0000001AA6A0: 062626F2
	v_div_scale_f32 v39, null, v19, v19, 1.0                   // 0000001AA6A4: D6FC7C27 03CA2713
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AA6AC: BF870001
	v_rcp_f32_e32 v44, v39                                     // 0000001AA6B0: 7E585527
	s_waitcnt lgkmcnt(0)                                       // 0000001AA6B4: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001AA6B8: 06424521
	ds_bpermute_b32 v34, v35, v33                              // 0000001AA6BC: DACC0000 22002123
	v_cndmask_b32_e64 v35, 2, 0, vcc_lo                        // 0000001AA6C4: D5010023 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001AA6CC: 7C9B689F
	v_fma_f32 v50, -v39, v44, 1.0                              // 0000001AA6D0: D6130032 23CA5927
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA6D8: BF870123
	v_add_lshl_u32 v35, v35, v180, 2                           // 0000001AA6DC: D6470023 020B6923
	s_waitcnt lgkmcnt(0)                                       // 0000001AA6E4: BF89FC07
	v_dual_fmac_f32 v44, v50, v44 :: v_dual_add_f32 v33, v33, v34// 0000001AA6E8: C8085932 2C204521
	ds_bpermute_b32 v34, v35, v33                              // 0000001AA6F0: DACC0000 22002123
	v_add_co_ci_u32_e64 v35, null, 0, v180, vcc_lo             // 0000001AA6F8: D5207C23 01AB6880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AA700: BF870001
	v_lshlrev_b32_e32 v35, 2, v35                              // 0000001AA704: 30464682
	s_waitcnt lgkmcnt(0)                                       // 0000001AA708: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001AA70C: 06424521
	ds_bpermute_b32 v34, v35, v33                              // 0000001AA710: DACC0000 22002123
	s_waitcnt lgkmcnt(0)                                       // 0000001AA718: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001AA71C: 06424521
	ds_bpermute_b32 v33, v107, v33                             // 0000001AA720: DACC0000 2100216B
	s_waitcnt lgkmcnt(0)                                       // 0000001AA728: BF89FC07
	v_div_scale_f32 v34, null, s62, s62, v33                   // 0000001AA72C: D6FC7C22 04847C3E
	v_div_scale_f32 v37, vcc_lo, v33, s62, v33                 // 0000001AA734: D6FC6A25 04847D21
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AA73C: BF870292
	v_rcp_f32_e32 v35, v34                                     // 0000001AA740: 7E465522
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000001AA744: D6130024 23CA4722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AA74C: BF8700A1
	v_fmac_f32_e32 v35, v36, v35                               // 0000001AA750: 56464724
	s_waitcnt vmcnt(16)                                        // 0000001AA754: BF8943F7
	v_dual_mul_f32 v36, v37, v35 :: v_dual_lshlrev_b32 v17, 16, v17// 0000001AA758: C8E24725 24102290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA760: BF870091
	v_fma_f32 v42, -v34, v36, v37                              // 0000001AA764: D613002A 24964922
	v_fmac_f32_e32 v36, v42, v35                               // 0000001AA76C: 5648472A
	v_rcp_f32_e32 v42, v40                                     // 0000001AA770: 7E545528
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA774: BF870121
	v_fma_f32 v34, -v34, v36, v37                              // 0000001AA778: D6130022 24964922
	v_fma_f32 v37, -v38, v43, 1.0                              // 0000001AA780: D6130025 23CA5726
	v_div_fmas_f32 v34, v34, v35, v36                          // 0000001AA788: D6370022 04924722
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AA790: BF870125
	v_fma_f32 v35, -v40, v42, 1.0                              // 0000001AA794: D6130023 23CA5528
	s_mov_b32 vcc_lo, s0                                       // 0000001AA79C: BEEA0000
	v_div_fixup_f32 v33, v34, s62, v33                         // 0000001AA7A0: D6270021 04847D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA7A8: BF870091
	v_dual_fmac_f32 v42, v35, v42 :: v_dual_add_f32 v33, 0x358637bd, v33// 0000001AA7AC: C8085523 2A2042FF 358637BD
	v_mul_f32_e32 v52, 0x4b800000, v33                         // 0000001AA7B8: 106842FF 4B800000
	.long 0xd414000b                                           // 0000001AA7C0: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v33, vcc_lo                // 0000001AA7C4: 020242FF 00800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA7CC: BF870091
	v_cndmask_b32_e64 v33, v33, v52, s11                       // 0000001AA7D0: D5010021 002E6921
	v_rsq_f32_e32 v33, v33                                     // 0000001AA7D8: 7E425D21
	v_fmac_f32_e32 v43, v37, v43                               // 0000001AA7DC: 56565725
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AA7E0: BF870091
	v_dual_mul_f32 v17, 0xbfb8aa3b, v17 :: v_dual_mul_f32 v34, v45, v43// 0000001AA7E4: C8C622FF 1122572D BFB8AA3B
	v_exp_f32_e32 v17, v17                                     // 0000001AA7F0: 7E224B11
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AA7F4: BF870001
	v_fma_f32 v50, -v38, v34, v45                              // 0000001AA7F8: D6130032 24B64526
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000001AA800: BF870085
	v_dual_fmac_f32 v34, v50, v43 :: v_dual_add_f32 v17, 1.0, v17// 0000001AA804: C8085732 221022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA80C: BF870111
	v_fma_f32 v38, -v38, v34, v45                              // 0000001AA810: D6130026 24B64526
	v_div_scale_f32 v41, null, v17, v17, 1.0                   // 0000001AA818: D6FC7C29 03CA2311
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA820: BF870112
	v_div_fmas_f32 v34, v38, v43, v34                          // 0000001AA824: D6370022 048A5726
	v_rcp_f32_e32 v47, v41                                     // 0000001AA82C: 7E5E5529
	v_mul_f32_e32 v38, 0x45800000, v33                         // 0000001AA830: 104C42FF 45800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA838: BF870112
	v_div_fixup_f32 v20, v34, v20, 1.0                         // 0000001AA83C: D6270014 03CA2922
	v_cndmask_b32_e64 v33, v33, v38, s11                       // 0000001AA844: D5010021 002E4D21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA84C: BF870115
	v_fma_f32 v36, -v41, v47, 1.0                              // 0000001AA850: D6130024 23CA5F29
	v_mul_f32_e32 v21, v33, v21                                // 0000001AA858: 102A2B21
	v_mul_f32_e32 v23, v33, v23                                // 0000001AA85C: 102E2F21
	v_mul_f32_e32 v24, v33, v24                                // 0000001AA860: 10303121
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AA864: BF870004
	v_dual_mul_f32 v22, v33, v22 :: v_dual_fmac_f32 v47, v36, v47// 0000001AA868: C8C02D21 162E5F24
	v_mul_f32_e32 v36, v48, v42                                // 0000001AA870: 10485530
	v_div_scale_f32 v46, s1, 1.0, v19, 1.0                     // 0000001AA874: D6FC012E 03CA26F2
	v_mul_f32_e32 v21, v21, v25                                // 0000001AA87C: 102A3315
	v_mul_f32_e32 v23, v23, v27                                // 0000001AA880: 102E3717
	s_mov_b32 vcc_lo, s1                                       // 0000001AA884: BEEA0001
	v_fma_f32 v53, -v40, v36, v48                              // 0000001AA888: D6130035 24C24928
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001AA890: BF870233
	v_dual_mul_f32 v35, v46, v44 :: v_dual_mul_f32 v20, v20, v21// 0000001AA894: C8C6592E 23142B14
	v_mul_f32_e32 v22, v22, v26                                // 0000001AA89C: 102C3516
	v_mul_f32_e32 v24, v24, v28                                // 0000001AA8A0: 10303918
	v_fmac_f32_e32 v36, v53, v42                               // 0000001AA8A4: 56485535
	v_div_scale_f32 v49, s10, 1.0, v17, 1.0                    // 0000001AA8A8: D6FC0A31 03CA22F2
	v_fma_f32 v51, -v39, v35, v46                              // 0000001AA8B0: D6130033 24BA4727
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA8B8: BF870193
	v_fma_f32 v40, -v40, v36, v48                              // 0000001AA8BC: D6130028 24C24928
	v_mul_f32_e32 v37, v49, v47                                // 0000001AA8C4: 104A5F31
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA8C8: BF870113
	v_fmac_f32_e32 v35, v51, v44                               // 0000001AA8CC: 56465933
	v_fma_f32 v54, -v41, v37, v49                              // 0000001AA8D0: D6130036 24C64B29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA8D8: BF870112
	v_fma_f32 v39, -v39, v35, v46                              // 0000001AA8DC: D6130027 24BA4727
	v_fmac_f32_e32 v37, v54, v47                               // 0000001AA8E4: 564A5F36
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AA8E8: BF870002
	v_div_fmas_f32 v35, v39, v44, v35                          // 0000001AA8EC: D6370023 048E5927
	s_mov_b32 vcc_lo, s9                                       // 0000001AA8F4: BEEA0009
	v_div_fmas_f32 v36, v40, v42, v36                          // 0000001AA8F8: D6370024 04925528
	s_mov_b32 vcc_lo, s10                                      // 0000001AA900: BEEA000A
	v_fma_f32 v41, -v41, v37, v49                              // 0000001AA904: D6130029 24C64B29
	v_div_fixup_f32 v19, v35, v19, 1.0                         // 0000001AA90C: D6270013 03CA2723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA914: BF870193
	v_div_fixup_f32 v18, v36, v18, 1.0                         // 0000001AA918: D6270012 03CA2524
	v_div_fmas_f32 v34, v41, v47, v37                          // 0000001AA920: D6370022 04965F29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA928: BF870193
	v_mul_f32_e32 v19, v19, v22                                // 0000001AA92C: 10262D13
	v_mul_f32_e32 v21, v18, v23                                // 0000001AA930: 102A2F12
	v_bfe_u32 v23, v20, 16, 1                                  // 0000001AA934: D6100017 02052114
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AA93C: BF870114
	v_div_fixup_f32 v17, v34, v17, 1.0                         // 0000001AA940: D6270011 03CA2322
	v_add3_u32 v20, v20, v23, 0x7fff                           // 0000001AA948: D6550014 03FE2F14 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001AA954: BF870242
	v_mul_f32_e32 v22, v17, v24                                // 0000001AA958: 102C3111
	v_bfe_u32 v24, v19, 16, 1                                  // 0000001AA95C: D6100018 02052113
	v_mad_u64_u32 v[17:18], null, 0x3000, v32, v[114:115]      // 0000001AA964: D6FE7C11 05CA40FF 00003000
	v_bfe_u32 v32, v21, 16, 1                                  // 0000001AA970: D6100020 02052115
	v_bfe_u32 v33, v22, 16, 1                                  // 0000001AA978: D6100021 02052116
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA980: BF870194
	v_add3_u32 v19, v19, v24, 0x7fff                           // 0000001AA984: D6550013 03FE3113 00007FFF
	v_add3_u32 v21, v21, v32, 0x7fff                           // 0000001AA990: D6550015 03FE4115 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001AA99C: BF870003
	v_add3_u32 v22, v22, v33, 0x7fff                           // 0000001AA9A0: D6550016 03FE4316 00007FFF
	s_clause 0x3                                               // 0000001AA9AC: BF850003
	global_store_d16_hi_b16 v[17:18], v20, off                 // 0000001AA9B0: DC960000 007C1411
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 0000001AA9B8: DC960040 007C1311
	global_store_d16_hi_b16 v[17:18], v21, off offset:128      // 0000001AA9C0: DC960080 007C1511
	global_store_d16_hi_b16 v[17:18], v22, off offset:192      // 0000001AA9C8: DC9600C0 007C1611
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001AA9D0: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AA9D4: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001AA9D8: BE8C007E
	.long 0xd4c4007e                                           // 0000001AA9DC: D4C4007E
	v_cndmask_b32_e32 v1, s67, v31, vcc_lo                     // 0000001AA9E0: 02023E43
	s_cbranch_execz 62244                                      // 0000001AA9E4: BFA5F324 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7c78>
	s_waitcnt vmcnt(10)                                        // 0000001AA9E8: BF892BF7
	v_lshlrev_b32_e32 v14, 16, v14                             // 0000001AA9EC: 301C1C90
	s_waitcnt vmcnt(9)                                         // 0000001AA9F0: BF8927F7
	v_lshlrev_b32_e32 v15, 16, v15                             // 0000001AA9F4: 301E1E90
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001AA9F8: 7C983A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AA9FC: BF870193
	v_dual_mul_f32 v20, v14, v14 :: v_dual_lshlrev_b32 v13, 16, v13// 0000001AAA00: C8E21D0E 140C1A90
	v_mul_f32_e32 v18, v15, v15                                // 0000001AAA08: 10241F0F
	s_waitcnt vmcnt(8)                                         // 0000001AAA0C: BF8923F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 0000001AAA10: 30202090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AAA14: BF8701A3
	v_mul_f32_e32 v19, v13, v13                                // 0000001AAA18: 10261B0D
	v_and_b32_e32 v21, 16, v29                                 // 0000001AAA1C: 362A3A90
	v_mul_f32_e32 v17, v16, v16                                // 0000001AAA20: 10222110
	v_lshlrev_b32_e32 v12, 16, v12                             // 0000001AAA24: 30181890
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AAA28: BF870214
	v_add_f32_e32 v18, v19, v18                                // 0000001AAA2C: 06242513
	v_add_lshl_u32 v19, v21, v180, 2                           // 0000001AAA30: D6470013 020B6915
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AAA38: BF8701B4
	v_add_f32_e32 v17, v20, v17                                // 0000001AAA3C: 06222314
	v_lshlrev_b32_e32 v10, 16, v10                             // 0000001AAA40: 30141490
	v_lshlrev_b32_e32 v11, 16, v11                             // 0000001AAA44: 30161690
	v_add_f32_e32 v17, v18, v17                                // 0000001AAA48: 06222312
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001AAA4C: BF870003
	v_mul_f32_e32 v10, 0xbfb8aa3b, v10                         // 0000001AAA50: 101414FF BFB8AA3B
	v_mul_f32_e32 v12, 0xbfb8aa3b, v12                         // 0000001AAA58: 101818FF BFB8AA3B
	ds_bpermute_b32 v18, v19, v17                              // 0000001AAA60: DACC0000 12001113
	v_cndmask_b32_e64 v19, 8, 0, vcc_lo                        // 0000001AAA68: D5010013 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001AAA70: 7C983A84
	v_exp_f32_e32 v10, v10                                     // 0000001AAA74: 7E144B0A
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000001AAA78: 30121290
	v_exp_f32_e32 v12, v12                                     // 0000001AAA7C: 7E184B0C
	v_add_lshl_u32 v19, v19, v180, 2                           // 0000001AAA80: D6470013 020B6913
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AAA88: BF870296
	v_add_f32_e32 v10, 1.0, v10                                // 0000001AAA8C: 061414F2
	v_add_f32_e32 v12, 1.0, v12                                // 0000001AAA90: 061818F2
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AAA94: BF870002
	v_div_scale_f32 v39, s9, 1.0, v10, 1.0                     // 0000001AAA98: D6FC0927 03CA14F2
	v_div_scale_f32 v24, null, v10, v10, 1.0                   // 0000001AAAA0: D6FC7C18 03CA150A
	s_waitcnt lgkmcnt(0)                                       // 0000001AAAA8: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AAAAC: 06222511
	v_div_scale_f32 v22, null, v12, v12, 1.0                   // 0000001AAAB0: D6FC7C16 03CA190C
	v_div_scale_f32 v36, s0, 1.0, v12, 1.0                     // 0000001AAAB8: D6FC0024 03CA18F2
	ds_bpermute_b32 v18, v19, v17                              // 0000001AAAC0: DACC0000 12001113
	v_cndmask_b32_e64 v19, 4, 0, vcc_lo                        // 0000001AAAC8: D5010013 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001AAAD0: 7C983A82
	v_rcp_f32_e32 v34, v22                                     // 0000001AAAD4: 7E445516
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AAAD8: BF870002
	v_add_lshl_u32 v19, v19, v180, 2                           // 0000001AAADC: D6470013 020B6913
	s_waitcnt lgkmcnt(0)                                       // 0000001AAAE4: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AAAE8: 06222511
	ds_bpermute_b32 v18, v19, v17                              // 0000001AAAEC: DACC0000 12001113
	v_cndmask_b32_e64 v19, 2, 0, vcc_lo                        // 0000001AAAF4: D5010013 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001AAAFC: 7C9B689F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001AAB00: BF8700D2
	v_add_lshl_u32 v19, v19, v180, 2                           // 0000001AAB04: D6470013 020B6913
	s_waitcnt lgkmcnt(0)                                       // 0000001AAB0C: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AAB10: 06222511
	ds_bpermute_b32 v18, v19, v17                              // 0000001AAB14: DACC0000 12001113
	v_add_co_ci_u32_e64 v19, null, 0, v180, vcc_lo             // 0000001AAB1C: D5207C13 01AB6880
	v_lshlrev_b32_e32 v19, 2, v19                              // 0000001AAB24: 30262682
	s_waitcnt lgkmcnt(0)                                       // 0000001AAB28: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AAB2C: 06222511
	ds_bpermute_b32 v18, v19, v17                              // 0000001AAB30: DACC0000 12001113
	s_waitcnt lgkmcnt(0)                                       // 0000001AAB38: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AAB3C: 06222511
	ds_bpermute_b32 v17, v107, v17                             // 0000001AAB40: DACC0000 1100116B
	s_waitcnt lgkmcnt(0)                                       // 0000001AAB48: BF89FC07
	v_div_scale_f32 v18, null, s62, s62, v17                   // 0000001AAB4C: D6FC7C12 04447C3E
	v_div_scale_f32 v21, vcc_lo, v17, s62, v17                 // 0000001AAB54: D6FC6A15 04447D11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AAB5C: BF870292
	v_rcp_f32_e32 v19, v18                                     // 0000001AAB60: 7E265512
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000001AAB64: D6130014 23CA2712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAB6C: BF870091
	v_fmac_f32_e32 v19, v20, v19                               // 0000001AAB70: 56262714
	v_dual_mul_f32 v9, 0xbfb8aa3b, v9 :: v_dual_mul_f32 v20, v21, v19// 0000001AAB74: C8C612FF 09142715 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAB80: BF870091
	v_exp_f32_e32 v9, v9                                       // 0000001AAB84: 7E124B09
	v_fma_f32 v33, -v18, v20, v21                              // 0000001AAB88: D6130021 24562912
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000001AAB90: BF870085
	v_dual_fmac_f32 v20, v33, v19 :: v_dual_add_f32 v9, 1.0, v9// 0000001AAB94: C8082721 140812F2
	v_rcp_f32_e32 v33, v24                                     // 0000001AAB9C: 7E425518
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AABA0: BF870111
	v_fma_f32 v18, -v18, v20, v21                              // 0000001AABA4: D6130012 24562912
	v_div_scale_f32 v32, null, v9, v9, 1.0                     // 0000001AABAC: D6FC7C20 03CA1309
	v_fma_f32 v21, -v22, v34, 1.0                              // 0000001AABB4: D6130015 23CA4516
	v_div_scale_f32 v40, s10, 1.0, v9, 1.0                     // 0000001AABBC: D6FC0A28 03CA12F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AABC4: BF870214
	v_div_fmas_f32 v18, v18, v19, v20                          // 0000001AABC8: D6370012 04522712
	v_rcp_f32_e32 v38, v32                                     // 0000001AABD0: 7E4C5520
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 0000001AABD4: BF870323
	v_fmac_f32_e32 v34, v21, v34                               // 0000001AABD8: 56444515
	s_mov_b32 vcc_lo, s0                                       // 0000001AABDC: BEEA0000
	v_fma_f32 v19, -v24, v33, 1.0                              // 0000001AABE0: D6130013 23CA4318
	v_div_fixup_f32 v17, v18, s62, v17                         // 0000001AABE8: D6270011 04447D12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AABF0: BF870291
	v_dual_mul_f32 v18, v36, v34 :: v_dual_add_f32 v17, 0x358637bd, v17// 0000001AABF4: C8C84524 121022FF 358637BD
	v_fma_f32 v20, -v32, v38, 1.0                              // 0000001AAC00: D6130014 23CA4D20
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 0000001AAC08: 101616FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AAC10: BF870112
	v_dual_mul_f32 v43, 0x4b800000, v17 :: v_dual_fmac_f32 v38, v20, v38// 0000001AAC14: C8C022FF 2B264D14 4B800000
	v_exp_f32_e32 v11, v11                                     // 0000001AAC20: 7E164B0B
	.long 0xd414000b                                           // 0000001AAC24: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v17, vcc_lo                // 0000001AAC28: 020222FF 00800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AAC30: BF870291
	v_cndmask_b32_e64 v17, v17, v43, s11                       // 0000001AAC34: D5010011 002E5711
	v_add_f32_e32 v11, 1.0, v11                                // 0000001AAC3C: 061616F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAC40: BF870092
	v_rsq_f32_e32 v17, v17                                     // 0000001AAC44: 7E225D11
	v_div_scale_f32 v23, null, v11, v11, 1.0                   // 0000001AAC48: D6FC7C17 03CA170B
	v_div_scale_f32 v37, s1, 1.0, v11, 1.0                     // 0000001AAC50: D6FC0125 03CA16F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AAC58: BF870292
	v_rcp_f32_e32 v35, v23                                     // 0000001AAC5C: 7E465517
	v_fma_f32 v41, -v23, v35, 1.0                              // 0000001AAC60: D6130029 23CA4717
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AAC68: BF8700A1
	v_fmac_f32_e32 v35, v41, v35                               // 0000001AAC6C: 56464729
	v_fma_f32 v41, -v22, v18, v36                              // 0000001AAC70: D6130029 24922516
	v_fmac_f32_e32 v18, v41, v34                               // 0000001AAC78: 56244529
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAC7C: BF870091
	v_fma_f32 v22, -v22, v18, v36                              // 0000001AAC80: D6130016 24922516
	v_div_fmas_f32 v18, v22, v34, v18                          // 0000001AAC88: D6370012 044A4516
	v_mul_f32_e32 v22, 0x45800000, v17                         // 0000001AAC90: 102C22FF 45800000
	s_mov_b32 vcc_lo, s1                                       // 0000001AAC98: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AAC9C: BF870112
	v_div_fixup_f32 v12, v18, v12, 1.0                         // 0000001AACA0: D627000C 03CA1912
	v_cndmask_b32_e64 v17, v17, v22, s11                       // 0000001AACA8: D5010011 002E2D11
	v_fmac_f32_e32 v33, v19, v33                               // 0000001AACB0: 56424313
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AACB4: BF8701A2
	v_dual_mul_f32 v21, v40, v38 :: v_dual_mul_f32 v16, v17, v16// 0000001AACB8: C8C64D28 15102111
	v_mul_f32_e32 v14, v17, v14                                // 0000001AACC0: 101C1D11
	v_dual_mul_f32 v19, v37, v35 :: v_dual_mul_f32 v20, v39, v33// 0000001AACC4: C8C64725 13144327
	v_mul_f32_e32 v13, v17, v13                                // 0000001AACCC: 101A1B11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AACD0: BF870214
	v_fma_f32 v45, -v32, v21, v40                              // 0000001AACD4: D613002D 24A22B20
	v_mul_f32_e32 v14, v14, v26                                // 0000001AACDC: 101C350E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001AACE0: BF870254
	v_fma_f32 v42, -v23, v19, v37                              // 0000001AACE4: D613002A 24962717
	v_fma_f32 v44, -v24, v20, v39                              // 0000001AACEC: D613002C 249E2918
	v_mul_f32_e32 v13, v13, v25                                // 0000001AACF4: 101A330D
	v_fmac_f32_e32 v21, v45, v38                               // 0000001AACF8: 562A4D2D
	v_mul_f32_e32 v15, v17, v15                                // 0000001AACFC: 101E1F11
	v_dual_fmac_f32 v19, v42, v35 :: v_dual_fmac_f32 v20, v44, v33// 0000001AAD00: C800472A 1314432C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AAD08: BF870214
	v_mul_f32_e32 v12, v12, v13                                // 0000001AAD0C: 10181B0C
	v_fma_f32 v32, -v32, v21, v40                              // 0000001AAD10: D6130020 24A22B20
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AAD18: BF870214
	v_mul_f32_e32 v15, v15, v27                                // 0000001AAD1C: 101E370F
	v_fma_f32 v23, -v23, v19, v37                              // 0000001AAD20: D6130017 24962717
	v_fma_f32 v24, -v24, v20, v39                              // 0000001AAD28: D6130018 249E2918
	v_mul_f32_e32 v16, v16, v28                                // 0000001AAD30: 10203910
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AAD34: BF8701A3
	v_div_fmas_f32 v19, v23, v35, v19                          // 0000001AAD38: D6370013 044E4717
	s_mov_b32 vcc_lo, s9                                       // 0000001AAD40: BEEA0009
	v_div_fmas_f32 v20, v24, v33, v20                          // 0000001AAD44: D6370014 04524318
	s_mov_b32 vcc_lo, s10                                      // 0000001AAD4C: BEEA000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AAD50: BF8701A2
	v_div_fixup_f32 v11, v19, v11, 1.0                         // 0000001AAD54: D627000B 03CA1713
	v_div_fmas_f32 v18, v32, v38, v21                          // 0000001AAD5C: D6370012 04564D20
	v_div_fixup_f32 v10, v20, v10, 1.0                         // 0000001AAD64: D627000A 03CA1514
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AAD6C: BF870193
	v_mul_f32_e32 v11, v11, v14                                // 0000001AAD70: 10161D0B
	v_div_fixup_f32 v9, v18, v9, 1.0                           // 0000001AAD74: D6270009 03CA1312
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AAD7C: BF8701A3
	v_mul_f32_e32 v13, v10, v15                                // 0000001AAD80: 101A1F0A
	v_bfe_u32 v15, v12, 16, 1                                  // 0000001AAD84: D610000F 0205210C
	v_mul_f32_e32 v14, v9, v16                                 // 0000001AAD8C: 101C2109
	v_bfe_u32 v16, v11, 16, 1                                  // 0000001AAD90: D6100010 0205210B
	v_mad_u64_u32 v[9:10], null, 0x3000, v31, v[114:115]       // 0000001AAD98: D6FE7C09 05CA3EFF 00003000
	v_bfe_u32 v17, v13, 16, 1                                  // 0000001AADA4: D6100011 0205210D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 0000001AADAC: D655000C 03FE1F0C 00007FFF
	v_bfe_u32 v18, v14, 16, 1                                  // 0000001AADB8: D6100012 0205210E
	v_add3_u32 v11, v11, v16, 0x7fff                           // 0000001AADC0: D655000B 03FE210B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AADCC: BF870194
	v_add3_u32 v13, v13, v17, 0x7fff                           // 0000001AADD0: D655000D 03FE230D 00007FFF
	v_add3_u32 v14, v14, v18, 0x7fff                           // 0000001AADDC: D655000E 03FE250E 00007FFF
	s_clause 0x3                                               // 0000001AADE8: BF850003
	global_store_d16_hi_b16 v[9:10], v12, off                  // 0000001AADEC: DC960000 007C0C09
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001AADF4: DC960040 007C0B09
	global_store_d16_hi_b16 v[9:10], v13, off offset:128       // 0000001AADFC: DC960080 007C0D09
	global_store_d16_hi_b16 v[9:10], v14, off offset:192       // 0000001AAE04: DC9600C0 007C0E09
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001AAE0C: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AAE10: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001AAE14: BE8C007E
	.long 0xd4c4007e                                           // 0000001AAE18: D4C4007E
	v_cndmask_b32_e32 v1, s67, v30, vcc_lo                     // 0000001AAE1C: 02023C43
	s_cbranch_execnz 61979                                     // 0000001AAE20: BFA6F21B <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x7c90>
	s_branch 62247                                             // 0000001AAE24: BFA0F327 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x80c4>
	v_mad_u64_u32 v[34:35], null, 0x1800, v33, v[110:111]      // 0000001AAE28: D6FE7C22 05BA42FF 00001800
	v_and_b32_e32 v46, 16, v29                                 // 0000001AAE34: 365C3A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAE38: BF870092
	.long 0xd73c0022                                           // 0000001AAE3C: D73C0022
	v_cndmask_b32_e32 v1, 1, v34, vcc_lo                       // 0000001AAE40: 02024481
	.long 0xd7006a24                                           // 0000001AAE44: D7006A24
	v_cndmask_b32_e32 v1, s22, v34, vcc_lo                     // 0000001AAE48: 02024416
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AAE4C: BF870001
	v_add_co_ci_u32_e64 v37, null, s23, v35, vcc_lo            // 0000001AAE50: D5207C25 01AA4617
	s_clause 0x3                                               // 0000001AAE58: BF850003
	global_load_u16 v38, v[36:37], off offset:192              // 0000001AAE5C: DC4A00C0 267C0024
	global_load_u16 v39, v[36:37], off offset:64               // 0000001AAE64: DC4A0040 277C0024
	global_load_u16 v40, v[36:37], off                         // 0000001AAE6C: DC4A0000 287C0024
	global_load_u16 v36, v[36:37], off offset:128              // 0000001AAE74: DC4A0080 247C0024
	.long 0xd7006a22                                           // 0000001AAE7C: D7006A22
	v_cndmask_b32_e32 v1, s26, v34, vcc_lo                     // 0000001AAE80: 0202441A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AAE84: BF870001
	v_add_co_ci_u32_e64 v35, null, s27, v35, vcc_lo            // 0000001AAE88: D5207C23 01AA461B
	s_clause 0x3                                               // 0000001AAE90: BF850003
	global_load_u16 v37, v[34:35], off offset:128              // 0000001AAE94: DC4A0080 257C0022
	global_load_u16 v41, v[34:35], off                         // 0000001AAE9C: DC4A0000 297C0022
	global_load_u16 v42, v[34:35], off offset:64               // 0000001AAEA4: DC4A0040 2A7C0022
	global_load_u16 v34, v[34:35], off offset:192              // 0000001AAEAC: DC4A00C0 227C0022
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001AAEB4: 7C983A88
	s_waitcnt vmcnt(4)                                         // 0000001AAEB8: BF8913F7
	v_lshlrev_b32_e32 v36, 16, v36                             // 0000001AAEBC: 30484890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AAEC0: BF870091
	v_dual_mul_f32 v44, v36, v36 :: v_dual_lshlrev_b32 v35, 16, v39// 0000001AAEC4: C8E24924 2C224E90
	v_dual_mul_f32 v40, v35, v35 :: v_dual_lshlrev_b32 v39, 16, v40// 0000001AAECC: C8E24723 28265090
	s_waitcnt vmcnt(1)                                         // 0000001AAED4: BF8907F7
	v_lshlrev_b32_e32 v42, 16, v42                             // 0000001AAED8: 30545490
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000001AAEDC: 30525290
	v_lshlrev_b32_e32 v37, 16, v37                             // 0000001AAEE0: 304A4A90
	v_dual_mul_f32 v43, v39, v39 :: v_dual_lshlrev_b32 v38, 16, v38// 0000001AAEE4: C8E24F27 2B264C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AAEEC: BF870193
	v_mul_f32_e32 v41, 0xbfb8aa3b, v41                         // 0000001AAEF0: 105252FF BFB8AA3B
	v_mul_f32_e32 v37, 0xbfb8aa3b, v37                         // 0000001AAEF8: 104A4AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AAF00: BF870213
	v_add_f32_e32 v43, v44, v43                                // 0000001AAF04: 0656572C
	v_mul_f32_e32 v45, v38, v38                                // 0000001AAF08: 105A4D26
	v_add_lshl_u32 v44, v46, v180, 2                           // 0000001AAF0C: D647002C 020B692E
	v_exp_f32_e32 v41, v41                                     // 0000001AAF14: 7E524B29
	v_exp_f32_e32 v37, v37                                     // 0000001AAF18: 7E4A4B25
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AAF1C: BF870002
	v_add_f32_e32 v40, v45, v40                                // 0000001AAF20: 0650512D
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_1)   // 0000001AAF24: BF870086
	v_dual_add_f32 v40, v40, v43 :: v_dual_add_f32 v41, 1.0, v41// 0000001AAF28: C9085728 282852F2
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001AAF30: BF870005
	v_add_f32_e32 v37, 1.0, v37                                // 0000001AAF34: 064A4AF2
	ds_bpermute_b32 v43, v44, v40                              // 0000001AAF38: DACC0000 2B00282C
	v_cndmask_b32_e64 v44, 8, 0, vcc_lo                        // 0000001AAF40: D501002C 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001AAF48: 7C983A84
	v_div_scale_f32 v47, null, v41, v41, 1.0                   // 0000001AAF4C: D6FC7C2F 03CA5329
	v_div_scale_f32 v54, s0, 1.0, v41, 1.0                     // 0000001AAF54: D6FC0036 03CA52F2
	v_div_scale_f32 v49, null, v37, v37, 1.0                   // 0000001AAF5C: D6FC7C31 03CA4B25
	v_add_lshl_u32 v44, v44, v180, 2                           // 0000001AAF64: D647002C 020B692C
	v_div_scale_f32 v57, s9, 1.0, v37, 1.0                     // 0000001AAF6C: D6FC0939 03CA4AF2
	v_rcp_f32_e32 v52, v47                                     // 0000001AAF74: 7E68552F
	s_waitcnt lgkmcnt(0)                                       // 0000001AAF78: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001AAF7C: 06505728
	ds_bpermute_b32 v43, v44, v40                              // 0000001AAF80: DACC0000 2B00282C
	v_cndmask_b32_e64 v44, 4, 0, vcc_lo                        // 0000001AAF88: D501002C 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001AAF90: 7C983A82
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AAF94: BF870002
	v_add_lshl_u32 v44, v44, v180, 2                           // 0000001AAF98: D647002C 020B692C
	s_waitcnt lgkmcnt(0)                                       // 0000001AAFA0: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001AAFA4: 06505728
	ds_bpermute_b32 v43, v44, v40                              // 0000001AAFA8: DACC0000 2B00282C
	v_cndmask_b32_e64 v44, 2, 0, vcc_lo                        // 0000001AAFB0: D501002C 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001AAFB8: 7C9B689F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001AAFBC: BF8700D2
	v_add_lshl_u32 v44, v44, v180, 2                           // 0000001AAFC0: D647002C 020B692C
	s_waitcnt lgkmcnt(0)                                       // 0000001AAFC8: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001AAFCC: 06505728
	ds_bpermute_b32 v43, v44, v40                              // 0000001AAFD0: DACC0000 2B00282C
	v_add_co_ci_u32_e64 v44, null, 0, v180, vcc_lo             // 0000001AAFD8: D5207C2C 01AB6880
	v_lshlrev_b32_e32 v44, 2, v44                              // 0000001AAFE0: 30585882
	s_waitcnt lgkmcnt(0)                                       // 0000001AAFE4: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001AAFE8: 06505728
	ds_bpermute_b32 v43, v44, v40                              // 0000001AAFEC: DACC0000 2B00282C
	s_waitcnt lgkmcnt(0)                                       // 0000001AAFF4: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001AAFF8: 06505728
	ds_bpermute_b32 v40, v107, v40                             // 0000001AAFFC: DACC0000 2800286B
	s_waitcnt lgkmcnt(0)                                       // 0000001AB004: BF89FC07
	v_div_scale_f32 v43, null, s62, s62, v40                   // 0000001AB008: D6FC7C2B 04A07C3E
	v_div_scale_f32 v46, vcc_lo, v40, s62, v40                 // 0000001AB010: D6FC6A2E 04A07D28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AB018: BF870292
	v_rcp_f32_e32 v44, v43                                     // 0000001AB01C: 7E58552B
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000001AB020: D613002D 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AB028: BF870091
	v_fmac_f32_e32 v44, v45, v44                               // 0000001AB02C: 5658592D
	v_mul_f32_e32 v45, v46, v44                                // 0000001AB030: 105A592E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AB034: BF870091
	v_fma_f32 v51, -v43, v45, v46                              // 0000001AB038: D6130033 24BA5B2B
	v_fmac_f32_e32 v45, v51, v44                               // 0000001AB040: 565A5933
	v_rcp_f32_e32 v51, v49                                     // 0000001AB044: 7E665531
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AB048: BF870121
	v_fma_f32 v43, -v43, v45, v46                              // 0000001AB04C: D613002B 24BA5B2B
	v_fma_f32 v46, -v47, v52, 1.0                              // 0000001AB054: D613002E 23CA692F
	v_div_fmas_f32 v43, v43, v44, v45                          // 0000001AB05C: D637002B 04B6592B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001AB064: BF8702A2
	v_fmac_f32_e32 v52, v46, v52                               // 0000001AB068: 5668692E
	v_mul_f32_e32 v42, 0xbfb8aa3b, v42                         // 0000001AB06C: 105454FF BFB8AA3B
	v_fma_f32 v44, -v49, v51, 1.0                              // 0000001AB074: D613002C 23CA6731
	s_waitcnt vmcnt(0)                                         // 0000001AB07C: BF8903F7
	v_lshlrev_b32_e32 v34, 16, v34                             // 0000001AB080: 30444490
	v_div_fixup_f32 v40, v43, s62, v40                         // 0000001AB084: D6270028 04A07D2B
	v_mul_f32_e32 v43, v54, v52                                // 0000001AB08C: 10566936
	v_exp_f32_e32 v42, v42                                     // 0000001AB090: 7E544B2A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB094: BF870193
	v_dual_fmac_f32 v51, v44, v51 :: v_dual_mul_f32 v34, 0xbfb8aa3b, v34// 0000001AB098: C806672C 332244FF BFB8AA3B
	v_add_f32_e32 v40, 0x358637bd, v40                         // 0000001AB0A4: 065050FF 358637BD
	s_mov_b32 vcc_lo, s0                                       // 0000001AB0AC: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AB0B0: BF870092
	v_exp_f32_e32 v34, v34                                     // 0000001AB0B4: 7E444B22
	v_mul_f32_e32 v61, 0x4b800000, v40                         // 0000001AB0B8: 107A50FF 4B800000
	.long 0xd414000b                                           // 0000001AB0C0: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v40, vcc_lo                // 0000001AB0C4: 020250FF 00800000
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB0CC: BF870116
	v_add_f32_e32 v42, 1.0, v42                                // 0000001AB0D0: 065454F2
	v_cndmask_b32_e64 v40, v40, v61, s11                       // 0000001AB0D4: D5010028 002E7B28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AB0DC: BF8701A2
	v_div_scale_f32 v48, null, v42, v42, 1.0                   // 0000001AB0E0: D6FC7C30 03CA552A
	v_div_scale_f32 v55, s1, 1.0, v42, 1.0                     // 0000001AB0E8: D6FC0137 03CA54F2
	v_rsq_f32_e32 v40, v40                                     // 0000001AB0F0: 7E505D28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AB0F4: BF870292
	v_rcp_f32_e32 v53, v48                                     // 0000001AB0F8: 7E6A5530
	v_fma_f32 v59, -v48, v53, 1.0                              // 0000001AB0FC: D613003B 23CA6B30
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AB104: BF8701B1
	v_fmac_f32_e32 v53, v59, v53                               // 0000001AB108: 566A6B3B
	v_fma_f32 v59, -v47, v43, v54                              // 0000001AB10C: D613003B 24DA572F
	v_add_f32_e32 v34, 1.0, v34                                // 0000001AB114: 064444F2
	v_mul_f32_e32 v44, v55, v53                                // 0000001AB118: 10586B37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB11C: BF870193
	v_fmac_f32_e32 v43, v59, v52                               // 0000001AB120: 5656693B
	v_div_scale_f32 v50, null, v34, v34, 1.0                   // 0000001AB124: D6FC7C32 03CA4522
	v_div_scale_f32 v58, s10, 1.0, v34, 1.0                    // 0000001AB12C: D6FC0A3A 03CA44F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB134: BF870193
	v_fma_f32 v47, -v47, v43, v54                              // 0000001AB138: D613002F 24DA572F
	v_rcp_f32_e32 v56, v50                                     // 0000001AB140: 7E705532
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001AB144: BF8701C1
	v_div_fmas_f32 v43, v47, v52, v43                          // 0000001AB148: D637002B 04AE692F
	v_mul_f32_e32 v47, 0x45800000, v40                         // 0000001AB150: 105E50FF 45800000
	v_fma_f32 v60, -v48, v44, v55                              // 0000001AB158: D613003C 24DE5930
	s_mov_b32 vcc_lo, s1                                       // 0000001AB160: BEEA0001
	v_div_fixup_f32 v41, v43, v41, 1.0                         // 0000001AB164: D6270029 03CA532B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AB16C: BF870293
	v_cndmask_b32_e64 v40, v40, v47, s11                       // 0000001AB170: D5010028 002E5F28
	v_fma_f32 v45, -v50, v56, 1.0                              // 0000001AB178: D613002D 23CA7132
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AB180: BF8701B1
	v_dual_mul_f32 v39, v40, v39 :: v_dual_fmac_f32 v56, v45, v56// 0000001AB184: C8C04F28 2738712D
	v_mul_f32_e32 v35, v40, v35                                // 0000001AB18C: 10464728
	v_dual_mul_f32 v45, v57, v51 :: v_dual_mul_f32 v38, v40, v38// 0000001AB190: C8C66739 2D264D28
	v_mul_f32_e32 v39, v39, v25                                // 0000001AB198: 104E3327
	v_fmac_f32_e32 v44, v60, v53                               // 0000001AB19C: 56586B3C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AB1A0: BF870214
	v_dual_mul_f32 v46, v58, v56 :: v_dual_mul_f32 v35, v35, v26// 0000001AB1A4: C8C6713A 2E223523
	v_fma_f32 v62, -v49, v45, v57                              // 0000001AB1AC: D613003E 24E65B31
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AB1B4: BF870214
	v_mul_f32_e32 v39, v41, v39                                // 0000001AB1B8: 104E4F29
	v_fma_f32 v48, -v48, v44, v55                              // 0000001AB1BC: D6130030 24DE5930
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001AB1C4: BF870234
	v_fma_f32 v63, -v50, v46, v58                              // 0000001AB1C8: D613003F 24EA5D32
	v_mul_f32_e32 v38, v38, v28                                // 0000001AB1D0: 104C3926
	v_fmac_f32_e32 v45, v62, v51                               // 0000001AB1D4: 565A673E
	v_div_fmas_f32 v44, v48, v53, v44                          // 0000001AB1D8: D637002C 04B26B30
	s_mov_b32 vcc_lo, s9                                       // 0000001AB1E0: BEEA0009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB1E4: BF870112
	v_fma_f32 v49, -v49, v45, v57                              // 0000001AB1E8: D6130031 24E65B31
	v_div_fixup_f32 v42, v44, v42, 1.0                         // 0000001AB1F0: D627002A 03CA552C
	v_fmac_f32_e32 v46, v63, v56                               // 0000001AB1F8: 565C713F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AB1FC: BF8701A3
	v_div_fmas_f32 v45, v49, v51, v45                          // 0000001AB200: D637002D 04B66731
	s_mov_b32 vcc_lo, s10                                      // 0000001AB208: BEEA000A
	v_mul_f32_e32 v35, v42, v35                                // 0000001AB20C: 1046472A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB210: BF870193
	v_fma_f32 v50, -v50, v46, v58                              // 0000001AB214: D6130032 24EA5D32
	v_div_fixup_f32 v37, v45, v37, 1.0                         // 0000001AB21C: D6270025 03CA4B2D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AB224: BF870092
	v_div_fmas_f32 v43, v50, v56, v46                          // 0000001AB228: D637002B 04BA7132
	v_div_fixup_f32 v34, v43, v34, 1.0                         // 0000001AB230: D6270022 03CA452B
	v_mul_f32_e32 v36, v40, v36                                // 0000001AB238: 10484928
	v_bfe_u32 v40, v35, 16, 1                                  // 0000001AB23C: D6100028 02052123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB244: BF870112
	v_mul_f32_e32 v36, v36, v27                                // 0000001AB248: 10483724
	v_add3_u32 v35, v35, v40, 0x7fff                           // 0000001AB24C: D6550023 03FE5123 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AB258: BF8701B2
	v_dual_mul_f32 v36, v37, v36 :: v_dual_mul_f32 v37, v34, v38// 0000001AB25C: C8C64925 24244D22
	v_bfe_u32 v38, v39, 16, 1                                  // 0000001AB264: D6100026 02052127
	v_mad_u64_u32 v[33:34], null, 0x3000, v33, v[114:115]      // 0000001AB26C: D6FE7C21 05CA42FF 00003000
	v_bfe_u32 v41, v36, 16, 1                                  // 0000001AB278: D6100029 02052124
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AB280: BF870214
	v_bfe_u32 v42, v37, 16, 1                                  // 0000001AB284: D610002A 02052125
	v_add3_u32 v38, v39, v38, 0x7fff                           // 0000001AB28C: D6550026 03FE4D27 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB298: BF870193
	v_add3_u32 v36, v36, v41, 0x7fff                           // 0000001AB29C: D6550024 03FE5324 00007FFF
	v_add3_u32 v37, v37, v42, 0x7fff                           // 0000001AB2A8: D6550025 03FE5525 00007FFF
	s_clause 0x3                                               // 0000001AB2B4: BF850003
	global_store_d16_hi_b16 v[33:34], v38, off                 // 0000001AB2B8: DC960000 007C2621
	global_store_d16_hi_b16 v[33:34], v35, off offset:64       // 0000001AB2C0: DC960040 007C2321
	global_store_d16_hi_b16 v[33:34], v36, off offset:128      // 0000001AB2C8: DC960080 007C2421
	global_store_d16_hi_b16 v[33:34], v37, off offset:192      // 0000001AB2D0: DC9600C0 007C2521
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001AB2D8: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AB2DC: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001AB2E0: BE8C007E
	.long 0xd4c4007e                                           // 0000001AB2E4: D4C4007E
	v_cndmask_b32_e32 v1, s67, v32, vcc_lo                     // 0000001AB2E8: 02024043
	s_cbranch_execz 62060                                      // 0000001AB2EC: BFA5F26C <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x82a0>
	s_waitcnt vmcnt(22)                                        // 0000001AB2F0: BF895BF7
	v_lshlrev_b32_e32 v22, 16, v22                             // 0000001AB2F4: 302C2C90
	s_waitcnt vmcnt(21)                                        // 0000001AB2F8: BF8957F7
	v_lshlrev_b32_e32 v23, 16, v23                             // 0000001AB2FC: 302E2E90
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001AB300: 7C983A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB304: BF870193
	v_dual_mul_f32 v36, v22, v22 :: v_dual_lshlrev_b32 v21, 16, v21// 0000001AB308: C8E22D16 24142A90
	v_mul_f32_e32 v34, v23, v23                                // 0000001AB310: 10442F17
	s_waitcnt vmcnt(20)                                        // 0000001AB314: BF8953F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 0000001AB318: 30303090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AB31C: BF8701A3
	v_mul_f32_e32 v35, v21, v21                                // 0000001AB320: 10462B15
	v_and_b32_e32 v37, 16, v29                                 // 0000001AB324: 364A3A90
	v_mul_f32_e32 v33, v24, v24                                // 0000001AB328: 10423118
	s_waitcnt vmcnt(19)                                        // 0000001AB32C: BF894FF7
	v_lshlrev_b32_e32 v20, 16, v20                             // 0000001AB330: 30282890
	v_add_f32_e32 v34, v35, v34                                // 0000001AB334: 06444523
	v_add_lshl_u32 v35, v37, v180, 2                           // 0000001AB338: D6470023 020B6925
	v_add_f32_e32 v33, v36, v33                                // 0000001AB340: 06424324
	s_waitcnt vmcnt(17)                                        // 0000001AB344: BF8947F7
	v_lshlrev_b32_e32 v18, 16, v18                             // 0000001AB348: 30242490
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB34C: BF870112
	v_dual_add_f32 v33, v34, v33 :: v_dual_mul_f32 v20, 0xbfb8aa3b, v20// 0000001AB350: C9064322 211428FF BFB8AA3B
	v_mul_f32_e32 v18, 0xbfb8aa3b, v18                         // 0000001AB35C: 102424FF BFB8AA3B
	ds_bpermute_b32 v34, v35, v33                              // 0000001AB364: DACC0000 22002123
	v_cndmask_b32_e64 v35, 8, 0, vcc_lo                        // 0000001AB36C: D5010023 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001AB374: 7C983A84
	v_exp_f32_e32 v20, v20                                     // 0000001AB378: 7E284B14
	v_exp_f32_e32 v18, v18                                     // 0000001AB37C: 7E244B12
	v_lshlrev_b32_e32 v19, 16, v19                             // 0000001AB380: 30262690
	v_add_lshl_u32 v35, v35, v180, 2                           // 0000001AB384: D6470023 020B6923
	s_delay_alu instid0(TRANS32_DEP_2)                         // 0000001AB38C: BF870006
	v_add_f32_e32 v20, 1.0, v20                                // 0000001AB390: 062828F2
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001AB394: BF870185
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_mul_f32 v19, 0xbfb8aa3b, v19// 0000001AB398: C90624F2 121226FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AB3A4: BF870002
	v_div_scale_f32 v38, null, v20, v20, 1.0                   // 0000001AB3A8: D6FC7C26 03CA2914
	v_div_scale_f32 v45, s0, 1.0, v20, 1.0                     // 0000001AB3B0: D6FC002D 03CA28F2
	s_waitcnt lgkmcnt(0)                                       // 0000001AB3B8: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001AB3BC: 06424521
	v_exp_f32_e32 v19, v19                                     // 0000001AB3C0: 7E264B13
	v_div_scale_f32 v48, s9, 1.0, v18, 1.0                     // 0000001AB3C4: D6FC0930 03CA24F2
	v_rcp_f32_e32 v43, v38                                     // 0000001AB3CC: 7E565526
	v_div_scale_f32 v40, null, v18, v18, 1.0                   // 0000001AB3D0: D6FC7C28 03CA2512
	ds_bpermute_b32 v34, v35, v33                              // 0000001AB3D8: DACC0000 22002123
	v_cndmask_b32_e64 v35, 4, 0, vcc_lo                        // 0000001AB3E0: D5010023 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001AB3E8: 7C983A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AB3EC: BF8700A2
	v_add_lshl_u32 v35, v35, v180, 2                           // 0000001AB3F0: D6470023 020B6923
	v_add_f32_e32 v19, 1.0, v19                                // 0000001AB3F8: 062626F2
	v_div_scale_f32 v39, null, v19, v19, 1.0                   // 0000001AB3FC: D6FC7C27 03CA2713
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AB404: BF870001
	v_rcp_f32_e32 v44, v39                                     // 0000001AB408: 7E585527
	s_waitcnt lgkmcnt(0)                                       // 0000001AB40C: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001AB410: 06424521
	ds_bpermute_b32 v34, v35, v33                              // 0000001AB414: DACC0000 22002123
	v_cndmask_b32_e64 v35, 2, 0, vcc_lo                        // 0000001AB41C: D5010023 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001AB424: 7C9B689F
	v_fma_f32 v50, -v39, v44, 1.0                              // 0000001AB428: D6130032 23CA5927
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AB430: BF870123
	v_add_lshl_u32 v35, v35, v180, 2                           // 0000001AB434: D6470023 020B6923
	s_waitcnt lgkmcnt(0)                                       // 0000001AB43C: BF89FC07
	v_dual_fmac_f32 v44, v50, v44 :: v_dual_add_f32 v33, v33, v34// 0000001AB440: C8085932 2C204521
	ds_bpermute_b32 v34, v35, v33                              // 0000001AB448: DACC0000 22002123
	v_add_co_ci_u32_e64 v35, null, 0, v180, vcc_lo             // 0000001AB450: D5207C23 01AB6880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AB458: BF870001
	v_lshlrev_b32_e32 v35, 2, v35                              // 0000001AB45C: 30464682
	s_waitcnt lgkmcnt(0)                                       // 0000001AB460: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001AB464: 06424521
	ds_bpermute_b32 v34, v35, v33                              // 0000001AB468: DACC0000 22002123
	s_waitcnt lgkmcnt(0)                                       // 0000001AB470: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001AB474: 06424521
	ds_bpermute_b32 v33, v107, v33                             // 0000001AB478: DACC0000 2100216B
	s_waitcnt lgkmcnt(0)                                       // 0000001AB480: BF89FC07
	v_div_scale_f32 v34, null, s62, s62, v33                   // 0000001AB484: D6FC7C22 04847C3E
	v_div_scale_f32 v37, vcc_lo, v33, s62, v33                 // 0000001AB48C: D6FC6A25 04847D21
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AB494: BF870292
	v_rcp_f32_e32 v35, v34                                     // 0000001AB498: 7E465522
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000001AB49C: D6130024 23CA4722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AB4A4: BF8700A1
	v_fmac_f32_e32 v35, v36, v35                               // 0000001AB4A8: 56464724
	s_waitcnt vmcnt(16)                                        // 0000001AB4AC: BF8943F7
	v_dual_mul_f32 v36, v37, v35 :: v_dual_lshlrev_b32 v17, 16, v17// 0000001AB4B0: C8E24725 24102290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AB4B8: BF870091
	v_fma_f32 v42, -v34, v36, v37                              // 0000001AB4BC: D613002A 24964922
	v_fmac_f32_e32 v36, v42, v35                               // 0000001AB4C4: 5648472A
	v_rcp_f32_e32 v42, v40                                     // 0000001AB4C8: 7E545528
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AB4CC: BF870121
	v_fma_f32 v34, -v34, v36, v37                              // 0000001AB4D0: D6130022 24964922
	v_fma_f32 v37, -v38, v43, 1.0                              // 0000001AB4D8: D6130025 23CA5726
	v_div_fmas_f32 v34, v34, v35, v36                          // 0000001AB4E0: D6370022 04924722
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AB4E8: BF870125
	v_fma_f32 v35, -v40, v42, 1.0                              // 0000001AB4EC: D6130023 23CA5528
	s_mov_b32 vcc_lo, s0                                       // 0000001AB4F4: BEEA0000
	v_div_fixup_f32 v33, v34, s62, v33                         // 0000001AB4F8: D6270021 04847D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AB500: BF870091
	v_dual_fmac_f32 v42, v35, v42 :: v_dual_add_f32 v33, 0x358637bd, v33// 0000001AB504: C8085523 2A2042FF 358637BD
	v_mul_f32_e32 v52, 0x4b800000, v33                         // 0000001AB510: 106842FF 4B800000
	.long 0xd414000b                                           // 0000001AB518: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v33, vcc_lo                // 0000001AB51C: 020242FF 00800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AB524: BF870091
	v_cndmask_b32_e64 v33, v33, v52, s11                       // 0000001AB528: D5010021 002E6921
	v_rsq_f32_e32 v33, v33                                     // 0000001AB530: 7E425D21
	v_fmac_f32_e32 v43, v37, v43                               // 0000001AB534: 56565725
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AB538: BF870091
	v_dual_mul_f32 v17, 0xbfb8aa3b, v17 :: v_dual_mul_f32 v34, v45, v43// 0000001AB53C: C8C622FF 1122572D BFB8AA3B
	v_exp_f32_e32 v17, v17                                     // 0000001AB548: 7E224B11
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AB54C: BF870001
	v_fma_f32 v50, -v38, v34, v45                              // 0000001AB550: D6130032 24B64526
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000001AB558: BF870085
	v_dual_fmac_f32 v34, v50, v43 :: v_dual_add_f32 v17, 1.0, v17// 0000001AB55C: C8085732 221022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB564: BF870111
	v_fma_f32 v38, -v38, v34, v45                              // 0000001AB568: D6130026 24B64526
	v_div_scale_f32 v41, null, v17, v17, 1.0                   // 0000001AB570: D6FC7C29 03CA2311
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB578: BF870112
	v_div_fmas_f32 v34, v38, v43, v34                          // 0000001AB57C: D6370022 048A5726
	v_rcp_f32_e32 v47, v41                                     // 0000001AB584: 7E5E5529
	v_mul_f32_e32 v38, 0x45800000, v33                         // 0000001AB588: 104C42FF 45800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB590: BF870112
	v_div_fixup_f32 v20, v34, v20, 1.0                         // 0000001AB594: D6270014 03CA2922
	v_cndmask_b32_e64 v33, v33, v38, s11                       // 0000001AB59C: D5010021 002E4D21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB5A4: BF870115
	v_fma_f32 v36, -v41, v47, 1.0                              // 0000001AB5A8: D6130024 23CA5F29
	v_mul_f32_e32 v21, v33, v21                                // 0000001AB5B0: 102A2B21
	v_mul_f32_e32 v23, v33, v23                                // 0000001AB5B4: 102E2F21
	v_mul_f32_e32 v24, v33, v24                                // 0000001AB5B8: 10303121
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AB5BC: BF870004
	v_dual_mul_f32 v22, v33, v22 :: v_dual_fmac_f32 v47, v36, v47// 0000001AB5C0: C8C02D21 162E5F24
	v_mul_f32_e32 v36, v48, v42                                // 0000001AB5C8: 10485530
	v_div_scale_f32 v46, s1, 1.0, v19, 1.0                     // 0000001AB5CC: D6FC012E 03CA26F2
	v_mul_f32_e32 v21, v21, v25                                // 0000001AB5D4: 102A3315
	v_mul_f32_e32 v23, v23, v27                                // 0000001AB5D8: 102E3717
	s_mov_b32 vcc_lo, s1                                       // 0000001AB5DC: BEEA0001
	v_fma_f32 v53, -v40, v36, v48                              // 0000001AB5E0: D6130035 24C24928
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001AB5E8: BF870233
	v_dual_mul_f32 v35, v46, v44 :: v_dual_mul_f32 v20, v20, v21// 0000001AB5EC: C8C6592E 23142B14
	v_mul_f32_e32 v22, v22, v26                                // 0000001AB5F4: 102C3516
	v_mul_f32_e32 v24, v24, v28                                // 0000001AB5F8: 10303918
	v_fmac_f32_e32 v36, v53, v42                               // 0000001AB5FC: 56485535
	v_div_scale_f32 v49, s10, 1.0, v17, 1.0                    // 0000001AB600: D6FC0A31 03CA22F2
	v_fma_f32 v51, -v39, v35, v46                              // 0000001AB608: D6130033 24BA4727
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB610: BF870193
	v_fma_f32 v40, -v40, v36, v48                              // 0000001AB614: D6130028 24C24928
	v_mul_f32_e32 v37, v49, v47                                // 0000001AB61C: 104A5F31
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB620: BF870113
	v_fmac_f32_e32 v35, v51, v44                               // 0000001AB624: 56465933
	v_fma_f32 v54, -v41, v37, v49                              // 0000001AB628: D6130036 24C64B29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB630: BF870112
	v_fma_f32 v39, -v39, v35, v46                              // 0000001AB634: D6130027 24BA4727
	v_fmac_f32_e32 v37, v54, v47                               // 0000001AB63C: 564A5F36
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AB640: BF870002
	v_div_fmas_f32 v35, v39, v44, v35                          // 0000001AB644: D6370023 048E5927
	s_mov_b32 vcc_lo, s9                                       // 0000001AB64C: BEEA0009
	v_div_fmas_f32 v36, v40, v42, v36                          // 0000001AB650: D6370024 04925528
	s_mov_b32 vcc_lo, s10                                      // 0000001AB658: BEEA000A
	v_fma_f32 v41, -v41, v37, v49                              // 0000001AB65C: D6130029 24C64B29
	v_div_fixup_f32 v19, v35, v19, 1.0                         // 0000001AB664: D6270013 03CA2723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB66C: BF870193
	v_div_fixup_f32 v18, v36, v18, 1.0                         // 0000001AB670: D6270012 03CA2524
	v_div_fmas_f32 v34, v41, v47, v37                          // 0000001AB678: D6370022 04965F29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB680: BF870193
	v_mul_f32_e32 v19, v19, v22                                // 0000001AB684: 10262D13
	v_mul_f32_e32 v21, v18, v23                                // 0000001AB688: 102A2F12
	v_bfe_u32 v23, v20, 16, 1                                  // 0000001AB68C: D6100017 02052114
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB694: BF870114
	v_div_fixup_f32 v17, v34, v17, 1.0                         // 0000001AB698: D6270011 03CA2322
	v_add3_u32 v20, v20, v23, 0x7fff                           // 0000001AB6A0: D6550014 03FE2F14 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001AB6AC: BF870242
	v_mul_f32_e32 v22, v17, v24                                // 0000001AB6B0: 102C3111
	v_bfe_u32 v24, v19, 16, 1                                  // 0000001AB6B4: D6100018 02052113
	v_mad_u64_u32 v[17:18], null, 0x3000, v32, v[114:115]      // 0000001AB6BC: D6FE7C11 05CA40FF 00003000
	v_bfe_u32 v32, v21, 16, 1                                  // 0000001AB6C8: D6100020 02052115
	v_bfe_u32 v33, v22, 16, 1                                  // 0000001AB6D0: D6100021 02052116
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB6D8: BF870194
	v_add3_u32 v19, v19, v24, 0x7fff                           // 0000001AB6DC: D6550013 03FE3113 00007FFF
	v_add3_u32 v21, v21, v32, 0x7fff                           // 0000001AB6E8: D6550015 03FE4115 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001AB6F4: BF870003
	v_add3_u32 v22, v22, v33, 0x7fff                           // 0000001AB6F8: D6550016 03FE4316 00007FFF
	s_clause 0x3                                               // 0000001AB704: BF850003
	global_store_d16_hi_b16 v[17:18], v20, off                 // 0000001AB708: DC960000 007C1411
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 0000001AB710: DC960040 007C1311
	global_store_d16_hi_b16 v[17:18], v21, off offset:128      // 0000001AB718: DC960080 007C1511
	global_store_d16_hi_b16 v[17:18], v22, off offset:192      // 0000001AB720: DC9600C0 007C1611
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001AB728: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AB72C: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001AB730: BE8C007E
	.long 0xd4c4007e                                           // 0000001AB734: D4C4007E
	v_cndmask_b32_e32 v1, s67, v31, vcc_lo                     // 0000001AB738: 02023E43
	s_cbranch_execz 61790                                      // 0000001AB73C: BFA5F15E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x82b8>
	s_waitcnt vmcnt(10)                                        // 0000001AB740: BF892BF7
	v_lshlrev_b32_e32 v14, 16, v14                             // 0000001AB744: 301C1C90
	s_waitcnt vmcnt(9)                                         // 0000001AB748: BF8927F7
	v_lshlrev_b32_e32 v15, 16, v15                             // 0000001AB74C: 301E1E90
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001AB750: 7C983A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AB754: BF870193
	v_dual_mul_f32 v20, v14, v14 :: v_dual_lshlrev_b32 v13, 16, v13// 0000001AB758: C8E21D0E 140C1A90
	v_mul_f32_e32 v18, v15, v15                                // 0000001AB760: 10241F0F
	s_waitcnt vmcnt(8)                                         // 0000001AB764: BF8923F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 0000001AB768: 30202090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AB76C: BF8701A3
	v_mul_f32_e32 v19, v13, v13                                // 0000001AB770: 10261B0D
	v_and_b32_e32 v21, 16, v29                                 // 0000001AB774: 362A3A90
	v_mul_f32_e32 v17, v16, v16                                // 0000001AB778: 10222110
	v_lshlrev_b32_e32 v12, 16, v12                             // 0000001AB77C: 30181890
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AB780: BF870214
	v_add_f32_e32 v18, v19, v18                                // 0000001AB784: 06242513
	v_add_lshl_u32 v19, v21, v180, 2                           // 0000001AB788: D6470013 020B6915
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AB790: BF8701B4
	v_add_f32_e32 v17, v20, v17                                // 0000001AB794: 06222314
	v_lshlrev_b32_e32 v10, 16, v10                             // 0000001AB798: 30141490
	v_lshlrev_b32_e32 v11, 16, v11                             // 0000001AB79C: 30161690
	v_add_f32_e32 v17, v18, v17                                // 0000001AB7A0: 06222312
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001AB7A4: BF870003
	v_mul_f32_e32 v10, 0xbfb8aa3b, v10                         // 0000001AB7A8: 101414FF BFB8AA3B
	v_mul_f32_e32 v12, 0xbfb8aa3b, v12                         // 0000001AB7B0: 101818FF BFB8AA3B
	ds_bpermute_b32 v18, v19, v17                              // 0000001AB7B8: DACC0000 12001113
	v_cndmask_b32_e64 v19, 8, 0, vcc_lo                        // 0000001AB7C0: D5010013 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001AB7C8: 7C983A84
	v_exp_f32_e32 v10, v10                                     // 0000001AB7CC: 7E144B0A
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000001AB7D0: 30121290
	v_exp_f32_e32 v12, v12                                     // 0000001AB7D4: 7E184B0C
	v_add_lshl_u32 v19, v19, v180, 2                           // 0000001AB7D8: D6470013 020B6913
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AB7E0: BF870296
	v_add_f32_e32 v10, 1.0, v10                                // 0000001AB7E4: 061414F2
	v_add_f32_e32 v12, 1.0, v12                                // 0000001AB7E8: 061818F2
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AB7EC: BF870002
	v_div_scale_f32 v39, s9, 1.0, v10, 1.0                     // 0000001AB7F0: D6FC0927 03CA14F2
	v_div_scale_f32 v24, null, v10, v10, 1.0                   // 0000001AB7F8: D6FC7C18 03CA150A
	s_waitcnt lgkmcnt(0)                                       // 0000001AB800: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AB804: 06222511
	v_div_scale_f32 v22, null, v12, v12, 1.0                   // 0000001AB808: D6FC7C16 03CA190C
	v_div_scale_f32 v36, s0, 1.0, v12, 1.0                     // 0000001AB810: D6FC0024 03CA18F2
	ds_bpermute_b32 v18, v19, v17                              // 0000001AB818: DACC0000 12001113
	v_cndmask_b32_e64 v19, 4, 0, vcc_lo                        // 0000001AB820: D5010013 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001AB828: 7C983A82
	v_rcp_f32_e32 v34, v22                                     // 0000001AB82C: 7E445516
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AB830: BF870002
	v_add_lshl_u32 v19, v19, v180, 2                           // 0000001AB834: D6470013 020B6913
	s_waitcnt lgkmcnt(0)                                       // 0000001AB83C: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AB840: 06222511
	ds_bpermute_b32 v18, v19, v17                              // 0000001AB844: DACC0000 12001113
	v_cndmask_b32_e64 v19, 2, 0, vcc_lo                        // 0000001AB84C: D5010013 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001AB854: 7C9B689F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001AB858: BF8700D2
	v_add_lshl_u32 v19, v19, v180, 2                           // 0000001AB85C: D6470013 020B6913
	s_waitcnt lgkmcnt(0)                                       // 0000001AB864: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AB868: 06222511
	ds_bpermute_b32 v18, v19, v17                              // 0000001AB86C: DACC0000 12001113
	v_add_co_ci_u32_e64 v19, null, 0, v180, vcc_lo             // 0000001AB874: D5207C13 01AB6880
	v_lshlrev_b32_e32 v19, 2, v19                              // 0000001AB87C: 30262682
	s_waitcnt lgkmcnt(0)                                       // 0000001AB880: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AB884: 06222511
	ds_bpermute_b32 v18, v19, v17                              // 0000001AB888: DACC0000 12001113
	s_waitcnt lgkmcnt(0)                                       // 0000001AB890: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AB894: 06222511
	ds_bpermute_b32 v17, v107, v17                             // 0000001AB898: DACC0000 1100116B
	s_waitcnt lgkmcnt(0)                                       // 0000001AB8A0: BF89FC07
	v_div_scale_f32 v18, null, s62, s62, v17                   // 0000001AB8A4: D6FC7C12 04447C3E
	v_div_scale_f32 v21, vcc_lo, v17, s62, v17                 // 0000001AB8AC: D6FC6A15 04447D11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AB8B4: BF870292
	v_rcp_f32_e32 v19, v18                                     // 0000001AB8B8: 7E265512
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000001AB8BC: D6130014 23CA2712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AB8C4: BF870091
	v_fmac_f32_e32 v19, v20, v19                               // 0000001AB8C8: 56262714
	v_dual_mul_f32 v9, 0xbfb8aa3b, v9 :: v_dual_mul_f32 v20, v21, v19// 0000001AB8CC: C8C612FF 09142715 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AB8D8: BF870091
	v_exp_f32_e32 v9, v9                                       // 0000001AB8DC: 7E124B09
	v_fma_f32 v33, -v18, v20, v21                              // 0000001AB8E0: D6130021 24562912
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000001AB8E8: BF870085
	v_dual_fmac_f32 v20, v33, v19 :: v_dual_add_f32 v9, 1.0, v9// 0000001AB8EC: C8082721 140812F2
	v_rcp_f32_e32 v33, v24                                     // 0000001AB8F4: 7E425518
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB8F8: BF870111
	v_fma_f32 v18, -v18, v20, v21                              // 0000001AB8FC: D6130012 24562912
	v_div_scale_f32 v32, null, v9, v9, 1.0                     // 0000001AB904: D6FC7C20 03CA1309
	v_fma_f32 v21, -v22, v34, 1.0                              // 0000001AB90C: D6130015 23CA4516
	v_div_scale_f32 v40, s10, 1.0, v9, 1.0                     // 0000001AB914: D6FC0A28 03CA12F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AB91C: BF870214
	v_div_fmas_f32 v18, v18, v19, v20                          // 0000001AB920: D6370012 04522712
	v_rcp_f32_e32 v38, v32                                     // 0000001AB928: 7E4C5520
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 0000001AB92C: BF870323
	v_fmac_f32_e32 v34, v21, v34                               // 0000001AB930: 56444515
	s_mov_b32 vcc_lo, s0                                       // 0000001AB934: BEEA0000
	v_fma_f32 v19, -v24, v33, 1.0                              // 0000001AB938: D6130013 23CA4318
	v_div_fixup_f32 v17, v18, s62, v17                         // 0000001AB940: D6270011 04447D12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AB948: BF870291
	v_dual_mul_f32 v18, v36, v34 :: v_dual_add_f32 v17, 0x358637bd, v17// 0000001AB94C: C8C84524 121022FF 358637BD
	v_fma_f32 v20, -v32, v38, 1.0                              // 0000001AB958: D6130014 23CA4D20
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 0000001AB960: 101616FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB968: BF870112
	v_dual_mul_f32 v43, 0x4b800000, v17 :: v_dual_fmac_f32 v38, v20, v38// 0000001AB96C: C8C022FF 2B264D14 4B800000
	v_exp_f32_e32 v11, v11                                     // 0000001AB978: 7E164B0B
	.long 0xd414000b                                           // 0000001AB97C: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v17, vcc_lo                // 0000001AB980: 020222FF 00800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AB988: BF870291
	v_cndmask_b32_e64 v17, v17, v43, s11                       // 0000001AB98C: D5010011 002E5711
	v_add_f32_e32 v11, 1.0, v11                                // 0000001AB994: 061616F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AB998: BF870092
	v_rsq_f32_e32 v17, v17                                     // 0000001AB99C: 7E225D11
	v_div_scale_f32 v23, null, v11, v11, 1.0                   // 0000001AB9A0: D6FC7C17 03CA170B
	v_div_scale_f32 v37, s1, 1.0, v11, 1.0                     // 0000001AB9A8: D6FC0125 03CA16F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AB9B0: BF870292
	v_rcp_f32_e32 v35, v23                                     // 0000001AB9B4: 7E465517
	v_fma_f32 v41, -v23, v35, 1.0                              // 0000001AB9B8: D6130029 23CA4717
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AB9C0: BF8700A1
	v_fmac_f32_e32 v35, v41, v35                               // 0000001AB9C4: 56464729
	v_fma_f32 v41, -v22, v18, v36                              // 0000001AB9C8: D6130029 24922516
	v_fmac_f32_e32 v18, v41, v34                               // 0000001AB9D0: 56244529
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AB9D4: BF870091
	v_fma_f32 v22, -v22, v18, v36                              // 0000001AB9D8: D6130016 24922516
	v_div_fmas_f32 v18, v22, v34, v18                          // 0000001AB9E0: D6370012 044A4516
	v_mul_f32_e32 v22, 0x45800000, v17                         // 0000001AB9E8: 102C22FF 45800000
	s_mov_b32 vcc_lo, s1                                       // 0000001AB9F0: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AB9F4: BF870112
	v_div_fixup_f32 v12, v18, v12, 1.0                         // 0000001AB9F8: D627000C 03CA1912
	v_cndmask_b32_e64 v17, v17, v22, s11                       // 0000001ABA00: D5010011 002E2D11
	v_fmac_f32_e32 v33, v19, v33                               // 0000001ABA08: 56424313
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001ABA0C: BF8701A2
	v_dual_mul_f32 v21, v40, v38 :: v_dual_mul_f32 v16, v17, v16// 0000001ABA10: C8C64D28 15102111
	v_mul_f32_e32 v14, v17, v14                                // 0000001ABA18: 101C1D11
	v_dual_mul_f32 v19, v37, v35 :: v_dual_mul_f32 v20, v39, v33// 0000001ABA1C: C8C64725 13144327
	v_mul_f32_e32 v13, v17, v13                                // 0000001ABA24: 101A1B11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ABA28: BF870214
	v_fma_f32 v45, -v32, v21, v40                              // 0000001ABA2C: D613002D 24A22B20
	v_mul_f32_e32 v14, v14, v26                                // 0000001ABA34: 101C350E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001ABA38: BF870254
	v_fma_f32 v42, -v23, v19, v37                              // 0000001ABA3C: D613002A 24962717
	v_fma_f32 v44, -v24, v20, v39                              // 0000001ABA44: D613002C 249E2918
	v_mul_f32_e32 v13, v13, v25                                // 0000001ABA4C: 101A330D
	v_fmac_f32_e32 v21, v45, v38                               // 0000001ABA50: 562A4D2D
	v_mul_f32_e32 v15, v17, v15                                // 0000001ABA54: 101E1F11
	v_dual_fmac_f32 v19, v42, v35 :: v_dual_fmac_f32 v20, v44, v33// 0000001ABA58: C800472A 1314432C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ABA60: BF870214
	v_mul_f32_e32 v12, v12, v13                                // 0000001ABA64: 10181B0C
	v_fma_f32 v32, -v32, v21, v40                              // 0000001ABA68: D6130020 24A22B20
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ABA70: BF870214
	v_mul_f32_e32 v15, v15, v27                                // 0000001ABA74: 101E370F
	v_fma_f32 v23, -v23, v19, v37                              // 0000001ABA78: D6130017 24962717
	v_fma_f32 v24, -v24, v20, v39                              // 0000001ABA80: D6130018 249E2918
	v_mul_f32_e32 v16, v16, v28                                // 0000001ABA88: 10203910
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001ABA8C: BF8701A3
	v_div_fmas_f32 v19, v23, v35, v19                          // 0000001ABA90: D6370013 044E4717
	s_mov_b32 vcc_lo, s9                                       // 0000001ABA98: BEEA0009
	v_div_fmas_f32 v20, v24, v33, v20                          // 0000001ABA9C: D6370014 04524318
	s_mov_b32 vcc_lo, s10                                      // 0000001ABAA4: BEEA000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001ABAA8: BF8701A2
	v_div_fixup_f32 v11, v19, v11, 1.0                         // 0000001ABAAC: D627000B 03CA1713
	v_div_fmas_f32 v18, v32, v38, v21                          // 0000001ABAB4: D6370012 04564D20
	v_div_fixup_f32 v10, v20, v10, 1.0                         // 0000001ABABC: D627000A 03CA1514
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ABAC4: BF870193
	v_mul_f32_e32 v11, v11, v14                                // 0000001ABAC8: 10161D0B
	v_div_fixup_f32 v9, v18, v9, 1.0                           // 0000001ABACC: D6270009 03CA1312
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001ABAD4: BF8701A3
	v_mul_f32_e32 v13, v10, v15                                // 0000001ABAD8: 101A1F0A
	v_bfe_u32 v15, v12, 16, 1                                  // 0000001ABADC: D610000F 0205210C
	v_mul_f32_e32 v14, v9, v16                                 // 0000001ABAE4: 101C2109
	v_bfe_u32 v16, v11, 16, 1                                  // 0000001ABAE8: D6100010 0205210B
	v_mad_u64_u32 v[9:10], null, 0x3000, v31, v[114:115]       // 0000001ABAF0: D6FE7C09 05CA3EFF 00003000
	v_bfe_u32 v17, v13, 16, 1                                  // 0000001ABAFC: D6100011 0205210D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 0000001ABB04: D655000C 03FE1F0C 00007FFF
	v_bfe_u32 v18, v14, 16, 1                                  // 0000001ABB10: D6100012 0205210E
	v_add3_u32 v11, v11, v16, 0x7fff                           // 0000001ABB18: D655000B 03FE210B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ABB24: BF870194
	v_add3_u32 v13, v13, v17, 0x7fff                           // 0000001ABB28: D655000D 03FE230D 00007FFF
	v_add3_u32 v14, v14, v18, 0x7fff                           // 0000001ABB34: D655000E 03FE250E 00007FFF
	s_clause 0x3                                               // 0000001ABB40: BF850003
	global_store_d16_hi_b16 v[9:10], v12, off                  // 0000001ABB44: DC960000 007C0C09
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001ABB4C: DC960040 007C0B09
	global_store_d16_hi_b16 v[9:10], v13, off offset:128       // 0000001ABB54: DC960080 007C0D09
	global_store_d16_hi_b16 v[9:10], v14, off offset:192       // 0000001ABB5C: DC9600C0 007C0E09
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001ABB64: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001ABB68: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001ABB6C: BE8C007E
	.long 0xd4c4007e                                           // 0000001ABB70: D4C4007E
	v_cndmask_b32_e32 v1, s67, v30, vcc_lo                     // 0000001ABB74: 02023C43
	s_cbranch_execnz 61525                                     // 0000001ABB78: BFA6F055 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x82d0>
	s_branch 61793                                             // 0000001ABB7C: BFA0F161 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8704>
	v_mad_u64_u32 v[34:35], null, 0x1800, v33, v[110:111]      // 0000001ABB80: D6FE7C22 05BA42FF 00001800
	v_and_b32_e32 v46, 16, v29                                 // 0000001ABB8C: 365C3A90
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ABB90: BF870092
	.long 0xd73c0022                                           // 0000001ABB94: D73C0022
	v_cndmask_b32_e32 v1, 1, v34, vcc_lo                       // 0000001ABB98: 02024481
	.long 0xd7006a24                                           // 0000001ABB9C: D7006A24
	v_cndmask_b32_e32 v1, s22, v34, vcc_lo                     // 0000001ABBA0: 02024416
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001ABBA4: BF870001
	v_add_co_ci_u32_e64 v37, null, s23, v35, vcc_lo            // 0000001ABBA8: D5207C25 01AA4617
	s_clause 0x3                                               // 0000001ABBB0: BF850003
	global_load_u16 v38, v[36:37], off offset:192              // 0000001ABBB4: DC4A00C0 267C0024
	global_load_u16 v39, v[36:37], off offset:64               // 0000001ABBBC: DC4A0040 277C0024
	global_load_u16 v40, v[36:37], off                         // 0000001ABBC4: DC4A0000 287C0024
	global_load_u16 v36, v[36:37], off offset:128              // 0000001ABBCC: DC4A0080 247C0024
	.long 0xd7006a22                                           // 0000001ABBD4: D7006A22
	v_cndmask_b32_e32 v1, s26, v34, vcc_lo                     // 0000001ABBD8: 0202441A
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001ABBDC: BF870001
	v_add_co_ci_u32_e64 v35, null, s27, v35, vcc_lo            // 0000001ABBE0: D5207C23 01AA461B
	s_clause 0x3                                               // 0000001ABBE8: BF850003
	global_load_u16 v37, v[34:35], off offset:128              // 0000001ABBEC: DC4A0080 257C0022
	global_load_u16 v41, v[34:35], off                         // 0000001ABBF4: DC4A0000 297C0022
	global_load_u16 v42, v[34:35], off offset:64               // 0000001ABBFC: DC4A0040 2A7C0022
	global_load_u16 v34, v[34:35], off offset:192              // 0000001ABC04: DC4A00C0 227C0022
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001ABC0C: 7C983A88
	s_waitcnt vmcnt(4)                                         // 0000001ABC10: BF8913F7
	v_lshlrev_b32_e32 v36, 16, v36                             // 0000001ABC14: 30484890
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ABC18: BF870091
	v_dual_mul_f32 v44, v36, v36 :: v_dual_lshlrev_b32 v35, 16, v39// 0000001ABC1C: C8E24924 2C224E90
	v_dual_mul_f32 v40, v35, v35 :: v_dual_lshlrev_b32 v39, 16, v40// 0000001ABC24: C8E24723 28265090
	s_waitcnt vmcnt(1)                                         // 0000001ABC2C: BF8907F7
	v_lshlrev_b32_e32 v42, 16, v42                             // 0000001ABC30: 30545490
	v_lshlrev_b32_e32 v41, 16, v41                             // 0000001ABC34: 30525290
	v_lshlrev_b32_e32 v37, 16, v37                             // 0000001ABC38: 304A4A90
	v_dual_mul_f32 v43, v39, v39 :: v_dual_lshlrev_b32 v38, 16, v38// 0000001ABC3C: C8E24F27 2B264C90
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ABC44: BF870193
	v_mul_f32_e32 v41, 0xbfb8aa3b, v41                         // 0000001ABC48: 105252FF BFB8AA3B
	v_mul_f32_e32 v37, 0xbfb8aa3b, v37                         // 0000001ABC50: 104A4AFF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ABC58: BF870213
	v_add_f32_e32 v43, v44, v43                                // 0000001ABC5C: 0656572C
	v_mul_f32_e32 v45, v38, v38                                // 0000001ABC60: 105A4D26
	v_add_lshl_u32 v44, v46, v180, 2                           // 0000001ABC64: D647002C 020B692E
	v_exp_f32_e32 v41, v41                                     // 0000001ABC6C: 7E524B29
	v_exp_f32_e32 v37, v37                                     // 0000001ABC70: 7E4A4B25
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001ABC74: BF870002
	v_add_f32_e32 v40, v45, v40                                // 0000001ABC78: 0650512D
	s_delay_alu instid0(TRANS32_DEP_2) | instid1(VALU_DEP_1)   // 0000001ABC7C: BF870086
	v_dual_add_f32 v40, v40, v43 :: v_dual_add_f32 v41, 1.0, v41// 0000001ABC80: C9085728 282852F2
	s_delay_alu instid0(TRANS32_DEP_1)                         // 0000001ABC88: BF870005
	v_add_f32_e32 v37, 1.0, v37                                // 0000001ABC8C: 064A4AF2
	ds_bpermute_b32 v43, v44, v40                              // 0000001ABC90: DACC0000 2B00282C
	v_cndmask_b32_e64 v44, 8, 0, vcc_lo                        // 0000001ABC98: D501002C 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001ABCA0: 7C983A84
	v_div_scale_f32 v47, null, v41, v41, 1.0                   // 0000001ABCA4: D6FC7C2F 03CA5329
	v_div_scale_f32 v54, s0, 1.0, v41, 1.0                     // 0000001ABCAC: D6FC0036 03CA52F2
	v_div_scale_f32 v49, null, v37, v37, 1.0                   // 0000001ABCB4: D6FC7C31 03CA4B25
	v_add_lshl_u32 v44, v44, v180, 2                           // 0000001ABCBC: D647002C 020B692C
	v_div_scale_f32 v57, s9, 1.0, v37, 1.0                     // 0000001ABCC4: D6FC0939 03CA4AF2
	v_rcp_f32_e32 v52, v47                                     // 0000001ABCCC: 7E68552F
	s_waitcnt lgkmcnt(0)                                       // 0000001ABCD0: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001ABCD4: 06505728
	ds_bpermute_b32 v43, v44, v40                              // 0000001ABCD8: DACC0000 2B00282C
	v_cndmask_b32_e64 v44, 4, 0, vcc_lo                        // 0000001ABCE0: D501002C 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001ABCE8: 7C983A82
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001ABCEC: BF870002
	v_add_lshl_u32 v44, v44, v180, 2                           // 0000001ABCF0: D647002C 020B692C
	s_waitcnt lgkmcnt(0)                                       // 0000001ABCF8: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001ABCFC: 06505728
	ds_bpermute_b32 v43, v44, v40                              // 0000001ABD00: DACC0000 2B00282C
	v_cndmask_b32_e64 v44, 2, 0, vcc_lo                        // 0000001ABD08: D501002C 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001ABD10: 7C9B689F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001ABD14: BF8700D2
	v_add_lshl_u32 v44, v44, v180, 2                           // 0000001ABD18: D647002C 020B692C
	s_waitcnt lgkmcnt(0)                                       // 0000001ABD20: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001ABD24: 06505728
	ds_bpermute_b32 v43, v44, v40                              // 0000001ABD28: DACC0000 2B00282C
	v_add_co_ci_u32_e64 v44, null, 0, v180, vcc_lo             // 0000001ABD30: D5207C2C 01AB6880
	v_lshlrev_b32_e32 v44, 2, v44                              // 0000001ABD38: 30585882
	s_waitcnt lgkmcnt(0)                                       // 0000001ABD3C: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001ABD40: 06505728
	ds_bpermute_b32 v43, v44, v40                              // 0000001ABD44: DACC0000 2B00282C
	s_waitcnt lgkmcnt(0)                                       // 0000001ABD4C: BF89FC07
	v_add_f32_e32 v40, v40, v43                                // 0000001ABD50: 06505728
	ds_bpermute_b32 v40, v107, v40                             // 0000001ABD54: DACC0000 2800286B
	s_waitcnt lgkmcnt(0)                                       // 0000001ABD5C: BF89FC07
	v_div_scale_f32 v43, null, s62, s62, v40                   // 0000001ABD60: D6FC7C2B 04A07C3E
	v_div_scale_f32 v46, vcc_lo, v40, s62, v40                 // 0000001ABD68: D6FC6A2E 04A07D28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001ABD70: BF870292
	v_rcp_f32_e32 v44, v43                                     // 0000001ABD74: 7E58552B
	v_fma_f32 v45, -v43, v44, 1.0                              // 0000001ABD78: D613002D 23CA592B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ABD80: BF870091
	v_fmac_f32_e32 v44, v45, v44                               // 0000001ABD84: 5658592D
	v_mul_f32_e32 v45, v46, v44                                // 0000001ABD88: 105A592E
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ABD8C: BF870091
	v_fma_f32 v51, -v43, v45, v46                              // 0000001ABD90: D6130033 24BA5B2B
	v_fmac_f32_e32 v45, v51, v44                               // 0000001ABD98: 565A5933
	v_rcp_f32_e32 v51, v49                                     // 0000001ABD9C: 7E665531
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001ABDA0: BF870121
	v_fma_f32 v43, -v43, v45, v46                              // 0000001ABDA4: D613002B 24BA5B2B
	v_fma_f32 v46, -v47, v52, 1.0                              // 0000001ABDAC: D613002E 23CA692F
	v_div_fmas_f32 v43, v43, v44, v45                          // 0000001ABDB4: D637002B 04B6592B
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(TRANS32_DEP_1)// 0000001ABDBC: BF8702A2
	v_fmac_f32_e32 v52, v46, v52                               // 0000001ABDC0: 5668692E
	v_mul_f32_e32 v42, 0xbfb8aa3b, v42                         // 0000001ABDC4: 105454FF BFB8AA3B
	v_fma_f32 v44, -v49, v51, 1.0                              // 0000001ABDCC: D613002C 23CA6731
	s_waitcnt vmcnt(0)                                         // 0000001ABDD4: BF8903F7
	v_lshlrev_b32_e32 v34, 16, v34                             // 0000001ABDD8: 30444490
	v_div_fixup_f32 v40, v43, s62, v40                         // 0000001ABDDC: D6270028 04A07D2B
	v_mul_f32_e32 v43, v54, v52                                // 0000001ABDE4: 10566936
	v_exp_f32_e32 v42, v42                                     // 0000001ABDE8: 7E544B2A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ABDEC: BF870193
	v_dual_fmac_f32 v51, v44, v51 :: v_dual_mul_f32 v34, 0xbfb8aa3b, v34// 0000001ABDF0: C806672C 332244FF BFB8AA3B
	v_add_f32_e32 v40, 0x358637bd, v40                         // 0000001ABDFC: 065050FF 358637BD
	s_mov_b32 vcc_lo, s0                                       // 0000001ABE04: BEEA0000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ABE08: BF870092
	v_exp_f32_e32 v34, v34                                     // 0000001ABE0C: 7E444B22
	v_mul_f32_e32 v61, 0x4b800000, v40                         // 0000001ABE10: 107A50FF 4B800000
	.long 0xd414000b                                           // 0000001ABE18: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v40, vcc_lo                // 0000001ABE1C: 020250FF 00800000
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ABE24: BF870116
	v_add_f32_e32 v42, 1.0, v42                                // 0000001ABE28: 065454F2
	v_cndmask_b32_e64 v40, v40, v61, s11                       // 0000001ABE2C: D5010028 002E7B28
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001ABE34: BF8701A2
	v_div_scale_f32 v48, null, v42, v42, 1.0                   // 0000001ABE38: D6FC7C30 03CA552A
	v_div_scale_f32 v55, s1, 1.0, v42, 1.0                     // 0000001ABE40: D6FC0137 03CA54F2
	v_rsq_f32_e32 v40, v40                                     // 0000001ABE48: 7E505D28
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001ABE4C: BF870292
	v_rcp_f32_e32 v53, v48                                     // 0000001ABE50: 7E6A5530
	v_fma_f32 v59, -v48, v53, 1.0                              // 0000001ABE54: D613003B 23CA6B30
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001ABE5C: BF8701B1
	v_fmac_f32_e32 v53, v59, v53                               // 0000001ABE60: 566A6B3B
	v_fma_f32 v59, -v47, v43, v54                              // 0000001ABE64: D613003B 24DA572F
	v_add_f32_e32 v34, 1.0, v34                                // 0000001ABE6C: 064444F2
	v_mul_f32_e32 v44, v55, v53                                // 0000001ABE70: 10586B37
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ABE74: BF870193
	v_fmac_f32_e32 v43, v59, v52                               // 0000001ABE78: 5656693B
	v_div_scale_f32 v50, null, v34, v34, 1.0                   // 0000001ABE7C: D6FC7C32 03CA4522
	v_div_scale_f32 v58, s10, 1.0, v34, 1.0                    // 0000001ABE84: D6FC0A3A 03CA44F2
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ABE8C: BF870193
	v_fma_f32 v47, -v47, v43, v54                              // 0000001ABE90: D613002F 24DA572F
	v_rcp_f32_e32 v56, v50                                     // 0000001ABE98: 7E705532
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_3) | instid1(VALU_DEP_3)// 0000001ABE9C: BF8701C1
	v_div_fmas_f32 v43, v47, v52, v43                          // 0000001ABEA0: D637002B 04AE692F
	v_mul_f32_e32 v47, 0x45800000, v40                         // 0000001ABEA8: 105E50FF 45800000
	v_fma_f32 v60, -v48, v44, v55                              // 0000001ABEB0: D613003C 24DE5930
	s_mov_b32 vcc_lo, s1                                       // 0000001ABEB8: BEEA0001
	v_div_fixup_f32 v41, v43, v41, 1.0                         // 0000001ABEBC: D6270029 03CA532B
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001ABEC4: BF870293
	v_cndmask_b32_e64 v40, v40, v47, s11                       // 0000001ABEC8: D5010028 002E5F28
	v_fma_f32 v45, -v50, v56, 1.0                              // 0000001ABED0: D613002D 23CA7132
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001ABED8: BF8701B1
	v_dual_mul_f32 v39, v40, v39 :: v_dual_fmac_f32 v56, v45, v56// 0000001ABEDC: C8C04F28 2738712D
	v_mul_f32_e32 v35, v40, v35                                // 0000001ABEE4: 10464728
	v_dual_mul_f32 v45, v57, v51 :: v_dual_mul_f32 v38, v40, v38// 0000001ABEE8: C8C66739 2D264D28
	v_mul_f32_e32 v39, v39, v25                                // 0000001ABEF0: 104E3327
	v_fmac_f32_e32 v44, v60, v53                               // 0000001ABEF4: 56586B3C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ABEF8: BF870214
	v_dual_mul_f32 v46, v58, v56 :: v_dual_mul_f32 v35, v35, v26// 0000001ABEFC: C8C6713A 2E223523
	v_fma_f32 v62, -v49, v45, v57                              // 0000001ABF04: D613003E 24E65B31
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ABF0C: BF870214
	v_mul_f32_e32 v39, v41, v39                                // 0000001ABF10: 104E4F29
	v_fma_f32 v48, -v48, v44, v55                              // 0000001ABF14: D6130030 24DE5930
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001ABF1C: BF870234
	v_fma_f32 v63, -v50, v46, v58                              // 0000001ABF20: D613003F 24EA5D32
	v_mul_f32_e32 v38, v38, v28                                // 0000001ABF28: 104C3926
	v_fmac_f32_e32 v45, v62, v51                               // 0000001ABF2C: 565A673E
	v_div_fmas_f32 v44, v48, v53, v44                          // 0000001ABF30: D637002C 04B26B30
	s_mov_b32 vcc_lo, s9                                       // 0000001ABF38: BEEA0009
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ABF3C: BF870112
	v_fma_f32 v49, -v49, v45, v57                              // 0000001ABF40: D6130031 24E65B31
	v_div_fixup_f32 v42, v44, v42, 1.0                         // 0000001ABF48: D627002A 03CA552C
	v_fmac_f32_e32 v46, v63, v56                               // 0000001ABF50: 565C713F
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001ABF54: BF8701A3
	v_div_fmas_f32 v45, v49, v51, v45                          // 0000001ABF58: D637002D 04B66731
	s_mov_b32 vcc_lo, s10                                      // 0000001ABF60: BEEA000A
	v_mul_f32_e32 v35, v42, v35                                // 0000001ABF64: 1046472A
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ABF68: BF870193
	v_fma_f32 v50, -v50, v46, v58                              // 0000001ABF6C: D6130032 24EA5D32
	v_div_fixup_f32 v37, v45, v37, 1.0                         // 0000001ABF74: D6270025 03CA4B2D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001ABF7C: BF870092
	v_div_fmas_f32 v43, v50, v56, v46                          // 0000001ABF80: D637002B 04BA7132
	v_div_fixup_f32 v34, v43, v34, 1.0                         // 0000001ABF88: D6270022 03CA452B
	v_mul_f32_e32 v36, v40, v36                                // 0000001ABF90: 10484928
	v_bfe_u32 v40, v35, 16, 1                                  // 0000001ABF94: D6100028 02052123
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001ABF9C: BF870112
	v_mul_f32_e32 v36, v36, v27                                // 0000001ABFA0: 10483724
	v_add3_u32 v35, v35, v40, 0x7fff                           // 0000001ABFA4: D6550023 03FE5123 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001ABFB0: BF8701B2
	v_dual_mul_f32 v36, v37, v36 :: v_dual_mul_f32 v37, v34, v38// 0000001ABFB4: C8C64925 24244D22
	v_bfe_u32 v38, v39, 16, 1                                  // 0000001ABFBC: D6100026 02052127
	v_mad_u64_u32 v[33:34], null, 0x3000, v33, v[114:115]      // 0000001ABFC4: D6FE7C21 05CA42FF 00003000
	v_bfe_u32 v41, v36, 16, 1                                  // 0000001ABFD0: D6100029 02052124
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001ABFD8: BF870214
	v_bfe_u32 v42, v37, 16, 1                                  // 0000001ABFDC: D610002A 02052125
	v_add3_u32 v38, v39, v38, 0x7fff                           // 0000001ABFE4: D6550026 03FE4D27 00007FFF
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001ABFF0: BF870193
	v_add3_u32 v36, v36, v41, 0x7fff                           // 0000001ABFF4: D6550024 03FE5324 00007FFF
	v_add3_u32 v37, v37, v42, 0x7fff                           // 0000001AC000: D6550025 03FE5525 00007FFF
	s_clause 0x3                                               // 0000001AC00C: BF850003
	global_store_d16_hi_b16 v[33:34], v38, off                 // 0000001AC010: DC960000 007C2621
	global_store_d16_hi_b16 v[33:34], v35, off offset:64       // 0000001AC018: DC960040 007C2321
	global_store_d16_hi_b16 v[33:34], v36, off offset:128      // 0000001AC020: DC960080 007C2421
	global_store_d16_hi_b16 v[33:34], v37, off offset:192      // 0000001AC028: DC9600C0 007C2521
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001AC030: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AC034: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001AC038: BE8C007E
	.long 0xd4c4007e                                           // 0000001AC03C: D4C4007E
	v_cndmask_b32_e32 v1, s67, v32, vcc_lo                     // 0000001AC040: 02024043
	s_cbranch_execz 61606                                      // 0000001AC044: BFA5F0A6 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x88e0>
	s_waitcnt vmcnt(22)                                        // 0000001AC048: BF895BF7
	v_lshlrev_b32_e32 v22, 16, v22                             // 0000001AC04C: 302C2C90
	s_waitcnt vmcnt(21)                                        // 0000001AC050: BF8957F7
	v_lshlrev_b32_e32 v23, 16, v23                             // 0000001AC054: 302E2E90
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001AC058: 7C983A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC05C: BF870193
	v_dual_mul_f32 v36, v22, v22 :: v_dual_lshlrev_b32 v21, 16, v21// 0000001AC060: C8E22D16 24142A90
	v_mul_f32_e32 v34, v23, v23                                // 0000001AC068: 10442F17
	s_waitcnt vmcnt(20)                                        // 0000001AC06C: BF8953F7
	v_lshlrev_b32_e32 v24, 16, v24                             // 0000001AC070: 30303090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AC074: BF8701A3
	v_mul_f32_e32 v35, v21, v21                                // 0000001AC078: 10462B15
	v_and_b32_e32 v37, 16, v29                                 // 0000001AC07C: 364A3A90
	v_mul_f32_e32 v33, v24, v24                                // 0000001AC080: 10423118
	s_waitcnt vmcnt(19)                                        // 0000001AC084: BF894FF7
	v_lshlrev_b32_e32 v20, 16, v20                             // 0000001AC088: 30282890
	v_add_f32_e32 v34, v35, v34                                // 0000001AC08C: 06444523
	v_add_lshl_u32 v35, v37, v180, 2                           // 0000001AC090: D6470023 020B6925
	v_add_f32_e32 v33, v36, v33                                // 0000001AC098: 06424324
	s_waitcnt vmcnt(17)                                        // 0000001AC09C: BF8947F7
	v_lshlrev_b32_e32 v18, 16, v18                             // 0000001AC0A0: 30242490
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC0A4: BF870112
	v_dual_add_f32 v33, v34, v33 :: v_dual_mul_f32 v20, 0xbfb8aa3b, v20// 0000001AC0A8: C9064322 211428FF BFB8AA3B
	v_mul_f32_e32 v18, 0xbfb8aa3b, v18                         // 0000001AC0B4: 102424FF BFB8AA3B
	ds_bpermute_b32 v34, v35, v33                              // 0000001AC0BC: DACC0000 22002123
	v_cndmask_b32_e64 v35, 8, 0, vcc_lo                        // 0000001AC0C4: D5010023 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001AC0CC: 7C983A84
	v_exp_f32_e32 v20, v20                                     // 0000001AC0D0: 7E284B14
	v_exp_f32_e32 v18, v18                                     // 0000001AC0D4: 7E244B12
	v_lshlrev_b32_e32 v19, 16, v19                             // 0000001AC0D8: 30262690
	v_add_lshl_u32 v35, v35, v180, 2                           // 0000001AC0DC: D6470023 020B6923
	s_delay_alu instid0(TRANS32_DEP_2)                         // 0000001AC0E4: BF870006
	v_add_f32_e32 v20, 1.0, v20                                // 0000001AC0E8: 062828F2
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_3)   // 0000001AC0EC: BF870185
	v_dual_add_f32 v18, 1.0, v18 :: v_dual_mul_f32 v19, 0xbfb8aa3b, v19// 0000001AC0F0: C90624F2 121226FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AC0FC: BF870002
	v_div_scale_f32 v38, null, v20, v20, 1.0                   // 0000001AC100: D6FC7C26 03CA2914
	v_div_scale_f32 v45, s0, 1.0, v20, 1.0                     // 0000001AC108: D6FC002D 03CA28F2
	s_waitcnt lgkmcnt(0)                                       // 0000001AC110: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001AC114: 06424521
	v_exp_f32_e32 v19, v19                                     // 0000001AC118: 7E264B13
	v_div_scale_f32 v48, s9, 1.0, v18, 1.0                     // 0000001AC11C: D6FC0930 03CA24F2
	v_rcp_f32_e32 v43, v38                                     // 0000001AC124: 7E565526
	v_div_scale_f32 v40, null, v18, v18, 1.0                   // 0000001AC128: D6FC7C28 03CA2512
	ds_bpermute_b32 v34, v35, v33                              // 0000001AC130: DACC0000 22002123
	v_cndmask_b32_e64 v35, 4, 0, vcc_lo                        // 0000001AC138: D5010023 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001AC140: 7C983A82
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AC144: BF8700A2
	v_add_lshl_u32 v35, v35, v180, 2                           // 0000001AC148: D6470023 020B6923
	v_add_f32_e32 v19, 1.0, v19                                // 0000001AC150: 062626F2
	v_div_scale_f32 v39, null, v19, v19, 1.0                   // 0000001AC154: D6FC7C27 03CA2713
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AC15C: BF870001
	v_rcp_f32_e32 v44, v39                                     // 0000001AC160: 7E585527
	s_waitcnt lgkmcnt(0)                                       // 0000001AC164: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001AC168: 06424521
	ds_bpermute_b32 v34, v35, v33                              // 0000001AC16C: DACC0000 22002123
	v_cndmask_b32_e64 v35, 2, 0, vcc_lo                        // 0000001AC174: D5010023 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001AC17C: 7C9B689F
	v_fma_f32 v50, -v39, v44, 1.0                              // 0000001AC180: D6130032 23CA5927
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AC188: BF870123
	v_add_lshl_u32 v35, v35, v180, 2                           // 0000001AC18C: D6470023 020B6923
	s_waitcnt lgkmcnt(0)                                       // 0000001AC194: BF89FC07
	v_dual_fmac_f32 v44, v50, v44 :: v_dual_add_f32 v33, v33, v34// 0000001AC198: C8085932 2C204521
	ds_bpermute_b32 v34, v35, v33                              // 0000001AC1A0: DACC0000 22002123
	v_add_co_ci_u32_e64 v35, null, 0, v180, vcc_lo             // 0000001AC1A8: D5207C23 01AB6880
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AC1B0: BF870001
	v_lshlrev_b32_e32 v35, 2, v35                              // 0000001AC1B4: 30464682
	s_waitcnt lgkmcnt(0)                                       // 0000001AC1B8: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001AC1BC: 06424521
	ds_bpermute_b32 v34, v35, v33                              // 0000001AC1C0: DACC0000 22002123
	s_waitcnt lgkmcnt(0)                                       // 0000001AC1C8: BF89FC07
	v_add_f32_e32 v33, v33, v34                                // 0000001AC1CC: 06424521
	ds_bpermute_b32 v33, v107, v33                             // 0000001AC1D0: DACC0000 2100216B
	s_waitcnt lgkmcnt(0)                                       // 0000001AC1D8: BF89FC07
	v_div_scale_f32 v34, null, s62, s62, v33                   // 0000001AC1DC: D6FC7C22 04847C3E
	v_div_scale_f32 v37, vcc_lo, v33, s62, v33                 // 0000001AC1E4: D6FC6A25 04847D21
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AC1EC: BF870292
	v_rcp_f32_e32 v35, v34                                     // 0000001AC1F0: 7E465522
	v_fma_f32 v36, -v34, v35, 1.0                              // 0000001AC1F4: D6130024 23CA4722
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AC1FC: BF8700A1
	v_fmac_f32_e32 v35, v36, v35                               // 0000001AC200: 56464724
	s_waitcnt vmcnt(16)                                        // 0000001AC204: BF8943F7
	v_dual_mul_f32 v36, v37, v35 :: v_dual_lshlrev_b32 v17, 16, v17// 0000001AC208: C8E24725 24102290
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC210: BF870091
	v_fma_f32 v42, -v34, v36, v37                              // 0000001AC214: D613002A 24964922
	v_fmac_f32_e32 v36, v42, v35                               // 0000001AC21C: 5648472A
	v_rcp_f32_e32 v42, v40                                     // 0000001AC220: 7E545528
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AC224: BF870121
	v_fma_f32 v34, -v34, v36, v37                              // 0000001AC228: D6130022 24964922
	v_fma_f32 v37, -v38, v43, 1.0                              // 0000001AC230: D6130025 23CA5726
	v_div_fmas_f32 v34, v34, v35, v36                          // 0000001AC238: D6370022 04924722
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_2)// 0000001AC240: BF870125
	v_fma_f32 v35, -v40, v42, 1.0                              // 0000001AC244: D6130023 23CA5528
	s_mov_b32 vcc_lo, s0                                       // 0000001AC24C: BEEA0000
	v_div_fixup_f32 v33, v34, s62, v33                         // 0000001AC250: D6270021 04847D22
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC258: BF870091
	v_dual_fmac_f32 v42, v35, v42 :: v_dual_add_f32 v33, 0x358637bd, v33// 0000001AC25C: C8085523 2A2042FF 358637BD
	v_mul_f32_e32 v52, 0x4b800000, v33                         // 0000001AC268: 106842FF 4B800000
	.long 0xd414000b                                           // 0000001AC270: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v33, vcc_lo                // 0000001AC274: 020242FF 00800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC27C: BF870091
	v_cndmask_b32_e64 v33, v33, v52, s11                       // 0000001AC280: D5010021 002E6921
	v_rsq_f32_e32 v33, v33                                     // 0000001AC288: 7E425D21
	v_fmac_f32_e32 v43, v37, v43                               // 0000001AC28C: 56565725
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC290: BF870091
	v_dual_mul_f32 v17, 0xbfb8aa3b, v17 :: v_dual_mul_f32 v34, v45, v43// 0000001AC294: C8C622FF 1122572D BFB8AA3B
	v_exp_f32_e32 v17, v17                                     // 0000001AC2A0: 7E224B11
	s_delay_alu instid0(VALU_DEP_1)                            // 0000001AC2A4: BF870001
	v_fma_f32 v50, -v38, v34, v45                              // 0000001AC2A8: D6130032 24B64526
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000001AC2B0: BF870085
	v_dual_fmac_f32 v34, v50, v43 :: v_dual_add_f32 v17, 1.0, v17// 0000001AC2B4: C8085732 221022F2
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC2BC: BF870111
	v_fma_f32 v38, -v38, v34, v45                              // 0000001AC2C0: D6130026 24B64526
	v_div_scale_f32 v41, null, v17, v17, 1.0                   // 0000001AC2C8: D6FC7C29 03CA2311
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC2D0: BF870112
	v_div_fmas_f32 v34, v38, v43, v34                          // 0000001AC2D4: D6370022 048A5726
	v_rcp_f32_e32 v47, v41                                     // 0000001AC2DC: 7E5E5529
	v_mul_f32_e32 v38, 0x45800000, v33                         // 0000001AC2E0: 104C42FF 45800000
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC2E8: BF870112
	v_div_fixup_f32 v20, v34, v20, 1.0                         // 0000001AC2EC: D6270014 03CA2922
	v_cndmask_b32_e64 v33, v33, v38, s11                       // 0000001AC2F4: D5010021 002E4D21
	s_delay_alu instid0(TRANS32_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC2FC: BF870115
	v_fma_f32 v36, -v41, v47, 1.0                              // 0000001AC300: D6130024 23CA5F29
	v_mul_f32_e32 v21, v33, v21                                // 0000001AC308: 102A2B21
	v_mul_f32_e32 v23, v33, v23                                // 0000001AC30C: 102E2F21
	v_mul_f32_e32 v24, v33, v24                                // 0000001AC310: 10303121
	s_delay_alu instid0(VALU_DEP_4)                            // 0000001AC314: BF870004
	v_dual_mul_f32 v22, v33, v22 :: v_dual_fmac_f32 v47, v36, v47// 0000001AC318: C8C02D21 162E5F24
	v_mul_f32_e32 v36, v48, v42                                // 0000001AC320: 10485530
	v_div_scale_f32 v46, s1, 1.0, v19, 1.0                     // 0000001AC324: D6FC012E 03CA26F2
	v_mul_f32_e32 v21, v21, v25                                // 0000001AC32C: 102A3315
	v_mul_f32_e32 v23, v23, v27                                // 0000001AC330: 102E3717
	s_mov_b32 vcc_lo, s1                                       // 0000001AC334: BEEA0001
	v_fma_f32 v53, -v40, v36, v48                              // 0000001AC338: D6130035 24C24928
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_2) | instid1(VALU_DEP_4)// 0000001AC340: BF870233
	v_dual_mul_f32 v35, v46, v44 :: v_dual_mul_f32 v20, v20, v21// 0000001AC344: C8C6592E 23142B14
	v_mul_f32_e32 v22, v22, v26                                // 0000001AC34C: 102C3516
	v_mul_f32_e32 v24, v24, v28                                // 0000001AC350: 10303918
	v_fmac_f32_e32 v36, v53, v42                               // 0000001AC354: 56485535
	v_div_scale_f32 v49, s10, 1.0, v17, 1.0                    // 0000001AC358: D6FC0A31 03CA22F2
	v_fma_f32 v51, -v39, v35, v46                              // 0000001AC360: D6130033 24BA4727
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC368: BF870193
	v_fma_f32 v40, -v40, v36, v48                              // 0000001AC36C: D6130028 24C24928
	v_mul_f32_e32 v37, v49, v47                                // 0000001AC374: 104A5F31
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC378: BF870113
	v_fmac_f32_e32 v35, v51, v44                               // 0000001AC37C: 56465933
	v_fma_f32 v54, -v41, v37, v49                              // 0000001AC380: D6130036 24C64B29
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC388: BF870112
	v_fma_f32 v39, -v39, v35, v46                              // 0000001AC38C: D6130027 24BA4727
	v_fmac_f32_e32 v37, v54, v47                               // 0000001AC394: 564A5F36
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AC398: BF870002
	v_div_fmas_f32 v35, v39, v44, v35                          // 0000001AC39C: D6370023 048E5927
	s_mov_b32 vcc_lo, s9                                       // 0000001AC3A4: BEEA0009
	v_div_fmas_f32 v36, v40, v42, v36                          // 0000001AC3A8: D6370024 04925528
	s_mov_b32 vcc_lo, s10                                      // 0000001AC3B0: BEEA000A
	v_fma_f32 v41, -v41, v37, v49                              // 0000001AC3B4: D6130029 24C64B29
	v_div_fixup_f32 v19, v35, v19, 1.0                         // 0000001AC3BC: D6270013 03CA2723
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC3C4: BF870193
	v_div_fixup_f32 v18, v36, v18, 1.0                         // 0000001AC3C8: D6270012 03CA2524
	v_div_fmas_f32 v34, v41, v47, v37                          // 0000001AC3D0: D6370022 04965F29
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC3D8: BF870193
	v_mul_f32_e32 v19, v19, v22                                // 0000001AC3DC: 10262D13
	v_mul_f32_e32 v21, v18, v23                                // 0000001AC3E0: 102A2F12
	v_bfe_u32 v23, v20, 16, 1                                  // 0000001AC3E4: D6100017 02052114
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC3EC: BF870114
	v_div_fixup_f32 v17, v34, v17, 1.0                         // 0000001AC3F0: D6270011 03CA2322
	v_add3_u32 v20, v20, v23, 0x7fff                           // 0000001AC3F8: D6550014 03FE2F14 00007FFF
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_3) | instid1(VALU_DEP_4)// 0000001AC404: BF870242
	v_mul_f32_e32 v22, v17, v24                                // 0000001AC408: 102C3111
	v_bfe_u32 v24, v19, 16, 1                                  // 0000001AC40C: D6100018 02052113
	v_mad_u64_u32 v[17:18], null, 0x3000, v32, v[114:115]      // 0000001AC414: D6FE7C11 05CA40FF 00003000
	v_bfe_u32 v32, v21, 16, 1                                  // 0000001AC420: D6100020 02052115
	v_bfe_u32 v33, v22, 16, 1                                  // 0000001AC428: D6100021 02052116
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC430: BF870194
	v_add3_u32 v19, v19, v24, 0x7fff                           // 0000001AC434: D6550013 03FE3113 00007FFF
	v_add3_u32 v21, v21, v32, 0x7fff                           // 0000001AC440: D6550015 03FE4115 00007FFF
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001AC44C: BF870003
	v_add3_u32 v22, v22, v33, 0x7fff                           // 0000001AC450: D6550016 03FE4316 00007FFF
	s_clause 0x3                                               // 0000001AC45C: BF850003
	global_store_d16_hi_b16 v[17:18], v20, off                 // 0000001AC460: DC960000 007C1411
	global_store_d16_hi_b16 v[17:18], v19, off offset:64       // 0000001AC468: DC960040 007C1311
	global_store_d16_hi_b16 v[17:18], v21, off offset:128      // 0000001AC470: DC960080 007C1511
	global_store_d16_hi_b16 v[17:18], v22, off offset:192      // 0000001AC478: DC9600C0 007C1611
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001AC480: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AC484: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001AC488: BE8C007E
	.long 0xd4c4007e                                           // 0000001AC48C: D4C4007E
	v_cndmask_b32_e32 v1, s67, v31, vcc_lo                     // 0000001AC490: 02023E43
	s_cbranch_execz 61336                                      // 0000001AC494: BFA5EF98 <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x88f8>
	s_waitcnt vmcnt(10)                                        // 0000001AC498: BF892BF7
	v_lshlrev_b32_e32 v14, 16, v14                             // 0000001AC49C: 301C1C90
	s_waitcnt vmcnt(9)                                         // 0000001AC4A0: BF8927F7
	v_lshlrev_b32_e32 v15, 16, v15                             // 0000001AC4A4: 301E1E90
	v_cmp_gt_u32_e32 vcc_lo, 8, v29                            // 0000001AC4A8: 7C983A88
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC4AC: BF870193
	v_dual_mul_f32 v20, v14, v14 :: v_dual_lshlrev_b32 v13, 16, v13// 0000001AC4B0: C8E21D0E 140C1A90
	v_mul_f32_e32 v18, v15, v15                                // 0000001AC4B8: 10241F0F
	s_waitcnt vmcnt(8)                                         // 0000001AC4BC: BF8923F7
	v_lshlrev_b32_e32 v16, 16, v16                             // 0000001AC4C0: 30202090
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AC4C4: BF8701A3
	v_mul_f32_e32 v19, v13, v13                                // 0000001AC4C8: 10261B0D
	v_and_b32_e32 v21, 16, v29                                 // 0000001AC4CC: 362A3A90
	v_mul_f32_e32 v17, v16, v16                                // 0000001AC4D0: 10222110
	v_lshlrev_b32_e32 v12, 16, v12                             // 0000001AC4D4: 30181890
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC4D8: BF870214
	v_add_f32_e32 v18, v19, v18                                // 0000001AC4DC: 06242513
	v_add_lshl_u32 v19, v21, v180, 2                           // 0000001AC4E0: D6470013 020B6915
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_2) | instid1(VALU_DEP_3)// 0000001AC4E8: BF8701B4
	v_add_f32_e32 v17, v20, v17                                // 0000001AC4EC: 06222314
	v_lshlrev_b32_e32 v10, 16, v10                             // 0000001AC4F0: 30141490
	v_lshlrev_b32_e32 v11, 16, v11                             // 0000001AC4F4: 30161690
	v_add_f32_e32 v17, v18, v17                                // 0000001AC4F8: 06222312
	s_delay_alu instid0(VALU_DEP_3)                            // 0000001AC4FC: BF870003
	v_mul_f32_e32 v10, 0xbfb8aa3b, v10                         // 0000001AC500: 101414FF BFB8AA3B
	v_mul_f32_e32 v12, 0xbfb8aa3b, v12                         // 0000001AC508: 101818FF BFB8AA3B
	ds_bpermute_b32 v18, v19, v17                              // 0000001AC510: DACC0000 12001113
	v_cndmask_b32_e64 v19, 8, 0, vcc_lo                        // 0000001AC518: D5010013 01A90088
	v_cmp_gt_u32_e32 vcc_lo, 4, v29                            // 0000001AC520: 7C983A84
	v_exp_f32_e32 v10, v10                                     // 0000001AC524: 7E144B0A
	v_lshlrev_b32_e32 v9, 16, v9                               // 0000001AC528: 30121290
	v_exp_f32_e32 v12, v12                                     // 0000001AC52C: 7E184B0C
	v_add_lshl_u32 v19, v19, v180, 2                           // 0000001AC530: D6470013 020B6913
	s_delay_alu instid0(TRANS32_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AC538: BF870296
	v_add_f32_e32 v10, 1.0, v10                                // 0000001AC53C: 061414F2
	v_add_f32_e32 v12, 1.0, v12                                // 0000001AC540: 061818F2
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AC544: BF870002
	v_div_scale_f32 v39, s9, 1.0, v10, 1.0                     // 0000001AC548: D6FC0927 03CA14F2
	v_div_scale_f32 v24, null, v10, v10, 1.0                   // 0000001AC550: D6FC7C18 03CA150A
	s_waitcnt lgkmcnt(0)                                       // 0000001AC558: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AC55C: 06222511
	v_div_scale_f32 v22, null, v12, v12, 1.0                   // 0000001AC560: D6FC7C16 03CA190C
	v_div_scale_f32 v36, s0, 1.0, v12, 1.0                     // 0000001AC568: D6FC0024 03CA18F2
	ds_bpermute_b32 v18, v19, v17                              // 0000001AC570: DACC0000 12001113
	v_cndmask_b32_e64 v19, 4, 0, vcc_lo                        // 0000001AC578: D5010013 01A90084
	v_cmp_gt_u32_e32 vcc_lo, 2, v29                            // 0000001AC580: 7C983A82
	v_rcp_f32_e32 v34, v22                                     // 0000001AC584: 7E445516
	s_delay_alu instid0(VALU_DEP_2)                            // 0000001AC588: BF870002
	v_add_lshl_u32 v19, v19, v180, 2                           // 0000001AC58C: D6470013 020B6913
	s_waitcnt lgkmcnt(0)                                       // 0000001AC594: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AC598: 06222511
	ds_bpermute_b32 v18, v19, v17                              // 0000001AC59C: DACC0000 12001113
	v_cndmask_b32_e64 v19, 2, 0, vcc_lo                        // 0000001AC5A4: D5010013 01A90082
	v_cmp_ne_u32_e32 vcc_lo, 31, v180                          // 0000001AC5AC: 7C9B689F
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001AC5B0: BF8700D2
	v_add_lshl_u32 v19, v19, v180, 2                           // 0000001AC5B4: D6470013 020B6913
	s_waitcnt lgkmcnt(0)                                       // 0000001AC5BC: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AC5C0: 06222511
	ds_bpermute_b32 v18, v19, v17                              // 0000001AC5C4: DACC0000 12001113
	v_add_co_ci_u32_e64 v19, null, 0, v180, vcc_lo             // 0000001AC5CC: D5207C13 01AB6880
	v_lshlrev_b32_e32 v19, 2, v19                              // 0000001AC5D4: 30262682
	s_waitcnt lgkmcnt(0)                                       // 0000001AC5D8: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AC5DC: 06222511
	ds_bpermute_b32 v18, v19, v17                              // 0000001AC5E0: DACC0000 12001113
	s_waitcnt lgkmcnt(0)                                       // 0000001AC5E8: BF89FC07
	v_add_f32_e32 v17, v17, v18                                // 0000001AC5EC: 06222511
	ds_bpermute_b32 v17, v107, v17                             // 0000001AC5F0: DACC0000 1100116B
	s_waitcnt lgkmcnt(0)                                       // 0000001AC5F8: BF89FC07
	v_div_scale_f32 v18, null, s62, s62, v17                   // 0000001AC5FC: D6FC7C12 04447C3E
	v_div_scale_f32 v21, vcc_lo, v17, s62, v17                 // 0000001AC604: D6FC6A15 04447D11
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AC60C: BF870292
	v_rcp_f32_e32 v19, v18                                     // 0000001AC610: 7E265512
	v_fma_f32 v20, -v18, v19, 1.0                              // 0000001AC614: D6130014 23CA2712
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC61C: BF870091
	v_fmac_f32_e32 v19, v20, v19                               // 0000001AC620: 56262714
	v_dual_mul_f32 v9, 0xbfb8aa3b, v9 :: v_dual_mul_f32 v20, v21, v19// 0000001AC624: C8C612FF 09142715 BFB8AA3B
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC630: BF870091
	v_exp_f32_e32 v9, v9                                       // 0000001AC634: 7E124B09
	v_fma_f32 v33, -v18, v20, v21                              // 0000001AC638: D6130021 24562912
	s_delay_alu instid0(TRANS32_DEP_1) | instid1(VALU_DEP_1)   // 0000001AC640: BF870085
	v_dual_fmac_f32 v20, v33, v19 :: v_dual_add_f32 v9, 1.0, v9// 0000001AC644: C8082721 140812F2
	v_rcp_f32_e32 v33, v24                                     // 0000001AC64C: 7E425518
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC650: BF870111
	v_fma_f32 v18, -v18, v20, v21                              // 0000001AC654: D6130012 24562912
	v_div_scale_f32 v32, null, v9, v9, 1.0                     // 0000001AC65C: D6FC7C20 03CA1309
	v_fma_f32 v21, -v22, v34, 1.0                              // 0000001AC664: D6130015 23CA4516
	v_div_scale_f32 v40, s10, 1.0, v9, 1.0                     // 0000001AC66C: D6FC0A28 03CA12F2
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC674: BF870214
	v_div_fmas_f32 v18, v18, v19, v20                          // 0000001AC678: D6370012 04522712
	v_rcp_f32_e32 v38, v32                                     // 0000001AC680: 7E4C5520
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(TRANS32_DEP_2)// 0000001AC684: BF870323
	v_fmac_f32_e32 v34, v21, v34                               // 0000001AC688: 56444515
	s_mov_b32 vcc_lo, s0                                       // 0000001AC68C: BEEA0000
	v_fma_f32 v19, -v24, v33, 1.0                              // 0000001AC690: D6130013 23CA4318
	v_div_fixup_f32 v17, v18, s62, v17                         // 0000001AC698: D6270011 04447D12
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AC6A0: BF870291
	v_dual_mul_f32 v18, v36, v34 :: v_dual_add_f32 v17, 0x358637bd, v17// 0000001AC6A4: C8C84524 121022FF 358637BD
	v_fma_f32 v20, -v32, v38, 1.0                              // 0000001AC6B0: D6130014 23CA4D20
	v_mul_f32_e32 v11, 0xbfb8aa3b, v11                         // 0000001AC6B8: 101616FF BFB8AA3B
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC6C0: BF870112
	v_dual_mul_f32 v43, 0x4b800000, v17 :: v_dual_fmac_f32 v38, v20, v38// 0000001AC6C4: C8C022FF 2B264D14 4B800000
	v_exp_f32_e32 v11, v11                                     // 0000001AC6D0: 7E164B0B
	.long 0xd414000b                                           // 0000001AC6D4: D414000B
	v_cndmask_b32_e32 v1, 0x800000, v17, vcc_lo                // 0000001AC6D8: 020222FF 00800000
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AC6E0: BF870291
	v_cndmask_b32_e64 v17, v17, v43, s11                       // 0000001AC6E4: D5010011 002E5711
	v_add_f32_e32 v11, 1.0, v11                                // 0000001AC6EC: 061616F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC6F0: BF870092
	v_rsq_f32_e32 v17, v17                                     // 0000001AC6F4: 7E225D11
	v_div_scale_f32 v23, null, v11, v11, 1.0                   // 0000001AC6F8: D6FC7C17 03CA170B
	v_div_scale_f32 v37, s1, 1.0, v11, 1.0                     // 0000001AC700: D6FC0125 03CA16F2
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(TRANS32_DEP_1)// 0000001AC708: BF870292
	v_rcp_f32_e32 v35, v23                                     // 0000001AC70C: 7E465517
	v_fma_f32 v41, -v23, v35, 1.0                              // 0000001AC710: D6130029 23CA4717
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_1) | instid1(VALU_DEP_1)// 0000001AC718: BF8700A1
	v_fmac_f32_e32 v35, v41, v35                               // 0000001AC71C: 56464729
	v_fma_f32 v41, -v22, v18, v36                              // 0000001AC720: D6130029 24922516
	v_fmac_f32_e32 v18, v41, v34                               // 0000001AC728: 56244529
	s_delay_alu instid0(VALU_DEP_1) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC72C: BF870091
	v_fma_f32 v22, -v22, v18, v36                              // 0000001AC730: D6130016 24922516
	v_div_fmas_f32 v18, v22, v34, v18                          // 0000001AC738: D6370012 044A4516
	v_mul_f32_e32 v22, 0x45800000, v17                         // 0000001AC740: 102C22FF 45800000
	s_mov_b32 vcc_lo, s1                                       // 0000001AC748: BEEA0001
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_2)// 0000001AC74C: BF870112
	v_div_fixup_f32 v12, v18, v12, 1.0                         // 0000001AC750: D627000C 03CA1912
	v_cndmask_b32_e64 v17, v17, v22, s11                       // 0000001AC758: D5010011 002E2D11
	v_fmac_f32_e32 v33, v19, v33                               // 0000001AC760: 56424313
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AC764: BF8701A2
	v_dual_mul_f32 v21, v40, v38 :: v_dual_mul_f32 v16, v17, v16// 0000001AC768: C8C64D28 15102111
	v_mul_f32_e32 v14, v17, v14                                // 0000001AC770: 101C1D11
	v_dual_mul_f32 v19, v37, v35 :: v_dual_mul_f32 v20, v39, v33// 0000001AC774: C8C64725 13144327
	v_mul_f32_e32 v13, v17, v13                                // 0000001AC77C: 101A1B11
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC780: BF870214
	v_fma_f32 v45, -v32, v21, v40                              // 0000001AC784: D613002D 24A22B20
	v_mul_f32_e32 v14, v14, v26                                // 0000001AC78C: 101C350E
	s_delay_alu instid0(VALU_DEP_4) | instskip(SKIP_4) | instid1(VALU_DEP_4)// 0000001AC790: BF870254
	v_fma_f32 v42, -v23, v19, v37                              // 0000001AC794: D613002A 24962717
	v_fma_f32 v44, -v24, v20, v39                              // 0000001AC79C: D613002C 249E2918
	v_mul_f32_e32 v13, v13, v25                                // 0000001AC7A4: 101A330D
	v_fmac_f32_e32 v21, v45, v38                               // 0000001AC7A8: 562A4D2D
	v_mul_f32_e32 v15, v17, v15                                // 0000001AC7AC: 101E1F11
	v_dual_fmac_f32 v19, v42, v35 :: v_dual_fmac_f32 v20, v44, v33// 0000001AC7B0: C800472A 1314432C
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC7B8: BF870214
	v_mul_f32_e32 v12, v12, v13                                // 0000001AC7BC: 10181B0C
	v_fma_f32 v32, -v32, v21, v40                              // 0000001AC7C0: D6130020 24A22B20
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_4)// 0000001AC7C8: BF870214
	v_mul_f32_e32 v15, v15, v27                                // 0000001AC7CC: 101E370F
	v_fma_f32 v23, -v23, v19, v37                              // 0000001AC7D0: D6130017 24962717
	v_fma_f32 v24, -v24, v20, v39                              // 0000001AC7D8: D6130018 249E2918
	v_mul_f32_e32 v16, v16, v28                                // 0000001AC7E0: 10203910
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AC7E4: BF8701A3
	v_div_fmas_f32 v19, v23, v35, v19                          // 0000001AC7E8: D6370013 044E4717
	s_mov_b32 vcc_lo, s9                                       // 0000001AC7F0: BEEA0009
	v_div_fmas_f32 v20, v24, v33, v20                          // 0000001AC7F4: D6370014 04524318
	s_mov_b32 vcc_lo, s10                                      // 0000001AC7FC: BEEA000A
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AC800: BF8701A2
	v_div_fixup_f32 v11, v19, v11, 1.0                         // 0000001AC804: D627000B 03CA1713
	v_div_fmas_f32 v18, v32, v38, v21                          // 0000001AC80C: D6370012 04564D20
	v_div_fixup_f32 v10, v20, v10, 1.0                         // 0000001AC814: D627000A 03CA1514
	s_delay_alu instid0(VALU_DEP_3) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC81C: BF870193
	v_mul_f32_e32 v11, v11, v14                                // 0000001AC820: 10161D0B
	v_div_fixup_f32 v9, v18, v9, 1.0                           // 0000001AC824: D6270009 03CA1312
	s_delay_alu instid0(VALU_DEP_3) | instskip(SKIP_1) | instid1(VALU_DEP_3)// 0000001AC82C: BF8701A3
	v_mul_f32_e32 v13, v10, v15                                // 0000001AC830: 101A1F0A
	v_bfe_u32 v15, v12, 16, 1                                  // 0000001AC834: D610000F 0205210C
	v_mul_f32_e32 v14, v9, v16                                 // 0000001AC83C: 101C2109
	v_bfe_u32 v16, v11, 16, 1                                  // 0000001AC840: D6100010 0205210B
	v_mad_u64_u32 v[9:10], null, 0x3000, v31, v[114:115]       // 0000001AC848: D6FE7C09 05CA3EFF 00003000
	v_bfe_u32 v17, v13, 16, 1                                  // 0000001AC854: D6100011 0205210D
	v_add3_u32 v12, v12, v15, 0x7fff                           // 0000001AC85C: D655000C 03FE1F0C 00007FFF
	v_bfe_u32 v18, v14, 16, 1                                  // 0000001AC868: D6100012 0205210E
	v_add3_u32 v11, v11, v16, 0x7fff                           // 0000001AC870: D655000B 03FE210B 00007FFF
	s_delay_alu instid0(VALU_DEP_4) | instskip(NEXT) | instid1(VALU_DEP_3)// 0000001AC87C: BF870194
	v_add3_u32 v13, v13, v17, 0x7fff                           // 0000001AC880: D655000D 03FE230D 00007FFF
	v_add3_u32 v14, v14, v18, 0x7fff                           // 0000001AC88C: D655000E 03FE250E 00007FFF
	s_clause 0x3                                               // 0000001AC898: BF850003
	global_store_d16_hi_b16 v[9:10], v12, off                  // 0000001AC89C: DC960000 007C0C09
	global_store_d16_hi_b16 v[9:10], v11, off offset:64        // 0000001AC8A4: DC960040 007C0B09
	global_store_d16_hi_b16 v[9:10], v13, off offset:128       // 0000001AC8AC: DC960080 007C0D09
	global_store_d16_hi_b16 v[9:10], v14, off offset:192       // 0000001AC8B4: DC9600C0 007C0E09
	s_or_b32 exec_lo, exec_lo, s12                             // 0000001AC8BC: 8C7E0C7E
	s_delay_alu instid0(SALU_CYCLE_1)                          // 0000001AC8C0: BF870009
	s_mov_b32 s12, exec_lo                                     // 0000001AC8C4: BE8C007E
	.long 0xd4c4007e                                           // 0000001AC8C8: D4C4007E
	v_cndmask_b32_e32 v1, s67, v30, vcc_lo                     // 0000001AC8CC: 02023C43
	s_cbranch_execnz 61071                                     // 0000001AC8D0: BFA6EE8F <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8910>
	s_branch 61342                                             // 0000001AC8D4: BFA0EF9E <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0x8d50>
	s_waitcnt vmcnt(0)                                         // 0000001AC8D8: BF8903F7
	v_dual_mov_b32 v1, s34 :: v_dual_mov_b32 v2, s35           // 0000001AC8DC: CA100022 01020023
	v_mov_b32_e32 v6, v125                                     // 0000001AC8E4: 7E0C037D
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC8E8: BF870092
	.long 0xd7006a00                                           // 0000001AC8EC: D7006A00
	v_cndmask_b32_e32 v0, v1, v18, vcc_lo                      // 0000001AC8F0: 02002501
	v_add_co_ci_u32_e64 v1, null, s19, v2, vcc_lo              // 0000001AC8F4: D5207C01 01AA0413
	s_add_u32 s0, s66, s20                                     // 0000001AC8FC: 80001442
	s_addc_u32 s1, s33, s21                                    // 0000001AC900: 82011521
	.long 0xd7006a00                                           // 0000001AC904: D7006A00
	v_cndmask_b32_e32 v0, v0, v0, vcc_lo                       // 0000001AC908: 02000100
	s_delay_alu instid0(VALU_DEP_1) | instskip(SKIP_2) | instid1(VALU_DEP_1)// 0000001AC90C: BF8700B1
	v_add_co_ci_u32_e64 v1, null, s1, v1, vcc_lo               // 0000001AC910: D5207C01 01AA0201
	s_mov_b32 s1, 0                                            // 0000001AC918: BE810080
	.long 0xd7006a00                                           // 0000001AC91C: D7006A00
	v_cndmask_b32_e32 v1, v0, v106, vcc_lo                     // 0000001AC920: 0202D500
	v_add_co_ci_u32_e64 v1, null, v1, v107, vcc_lo             // 0000001AC924: D5207C01 01AAD701
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC92C: BF870092
	.long 0xd7006a00                                           // 0000001AC930: D7006A00
	v_cndmask_b32_e32 v1, v0, v124, vcc_lo                     // 0000001AC934: 0202F900
	v_add_co_ci_u32_e64 v1, null, v1, v140, vcc_lo             // 0000001AC938: D5207C01 01AB1901
	s_delay_alu instid0(VALU_DEP_2) | instskip(NEXT) | instid1(VALU_DEP_1)// 0000001AC940: BF870092
	.long 0xd7006a00                                           // 0000001AC944: D7006A00
	v_cndmask_b32_e32 v1, s16, v0, vcc_lo                      // 0000001AC948: 02020010
	v_add_co_ci_u32_e64 v1, null, s17, v1, vcc_lo              // 0000001AC94C: D5207C01 01AA0211
	s_nop 0                                                    // 0000001AC954: BF800000
	s_nop 0                                                    // 0000001AC958: BF800000
	s_nop 0                                                    // 0000001AC95C: BF800000
	s_nop 0                                                    // 0000001AC960: BF800000
	s_nop 0                                                    // 0000001AC964: BF800000
	s_nop 0                                                    // 0000001AC968: BF800000
	s_nop 0                                                    // 0000001AC96C: BF800000
	s_nop 0                                                    // 0000001AC970: BF800000
	s_nop 0                                                    // 0000001AC974: BF800000
	s_nop 0                                                    // 0000001AC978: BF800000
	s_nop 0                                                    // 0000001AC97C: BF800000
	ds_load_b32 v2, v135                                       // 0000001AC980: D8D80000 02000087
	v_add_nc_u32_e32 v6, 0x80, v6                              // 0000001AC988: 4A0C0CFF 00000080
	v_add_nc_u32_e32 v135, 8, v135                             // 0000001AC990: 4B0F0E88
	s_delay_alu instid0(VALU_DEP_2) | instskip(SKIP_4) | instid1(VALU_DEP_1)// 0000001AC994: BF8700D2
	v_cmp_lt_u32_e32 vcc_lo, 0x1f7f, v6                        // 0000001AC998: 7C920CFF 00001F7F
	s_or_b32 s1, vcc_lo, s1                                    // 0000001AC9A0: 8C01016A
	s_waitcnt lgkmcnt(0)                                       // 0000001AC9A4: BF89FC07
	global_store_b32 v[0:1], v2, off                           // 0000001AC9A8: DC6A0000 007C0200
	.long 0xd7000000                                           // 0000001AC9B0: D7000000
	v_cndmask_b32_e32 v1, 0x400, v0, vcc_lo                    // 0000001AC9B4: 020200FF 00000400
	v_add_co_ci_u32_e64 v1, null, 0, v1, s0                    // 0000001AC9BC: D5207C01 00020280
	s_and_not1_b32 exec_lo, exec_lo, s1                        // 0000001AC9C4: 917E017E
	s_cbranch_execnz 65517                                     // 0000001AC9C8: BFA6FFED <_ZN7halogen12_GLOBAL__N_112k_dnc_scan3xILi2ELi4ELb1ELb0ELb1ELi1ELi0ELi1ELb0EEEvPKtPKfS5_S5_S5_S5_S5_PfPKilPtiS3_S3_S3_S5_NS_10DncTapArgsENS_11DncNormFoldE+0xcf80>
	s_nop 0                                                    // 0000001AC9CC: BF800000
	s_sendmsg sendmsg(MSG_DEALLOC_VGPRS)                       // 0000001AC9D0: BFB60003
	s_endpgm                                                   // 0000001AC9D4: BFB00000
		...

